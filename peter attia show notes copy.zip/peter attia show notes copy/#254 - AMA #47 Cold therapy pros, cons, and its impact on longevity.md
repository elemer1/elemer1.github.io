# #254 – AMA #47: Cold therapy: pros, cons, and its impact on longevity

**Source:** [https://peterattiamd.com/ama47/](https://peterattiamd.com/ama47/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves deep into the data surrounding different forms of cold therapy, including cold water immersion, cryotherapy, and cold showers, aiming to unveil the potential benefits and drawbacks associated with cold therapy. He dissects the studies examining the effects of cold therapy on delayed onset muscle soreness (DOMS), activation of brown adipose tissue, and its potential impact on mood and as a therapeutic approach for depression. Furthermore, Peter discusses the potential negative impact cold therapy may have on muscular hypertrophy and offers his perspective on the extent to which the data support the notion of cold therapy providing longevity benefits. Finally, he also discusses the existing consensus, or lack thereof, regarding the optimal structure of an effective cold therapy protocol.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #47 show notes page](https://peterattiamd.com/ama47). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of discussion on cold therapy (and a Formula 1 tangent) [1:45];
- The most common cold exposure therapies [5:45];
- Potential benefits of cold water immersion: a look at the data [9:30];
- Comparing the effects of cold water immersion with whole-body cryotherapy [18:30];
- The potential impact of cold exposure on mood and as a treatment for depression [20:45];
- How do cold showers compare to cold water immersion? [28:15];
- Cold exposure and the activation of brown adipose tissue (BAT) [34:15];
- Exercising in cold temperatures: impact on exercise performance [38:30];
- Potential downsides of cold therapy and its impact on hypertrophy, strength, and recovery [44:45];
- Are the blunting effects of cold on hypertrophy due to the effects on inflammation? [50:45];
- Does cold exposure offer any potential geroprotective benefits? [53:15];
- Cold therapy protocols for delayed onset muscle soreness (DOMS) [56:30];
- Summarizing the data and takeaways from Peter [1:01:00]; and
- More.

§

The Peter Attia Drive

Cold therapy: pros, cons, and its impact on longevity

§

## Show Notes

## Overview of discussion on cold therapy (and a Formula 1 tangent) [1:45]

- Focusing on one core topic today — cold therapy
  - Since we’ve spent some time recently talking about the benefits of sauna and heat and some thoughts on cold therapy as well on [AMA #16](https://peterattiamd.com/ama16/)
  - Peter has provided some of his updated thoughts on hot therapy ([AMA #42](https://peterattiamd.com/ama42/)) but today will be an update to his thoughts on cold

Today, we plan to cover:

- what we know and don’t know about cold therapy
- how it can affect mood or be a treatment for depression
- what we know about the claims that it helps activation of brown adipose tissue for metabolic health
- Any potential cons around cold therapy
- whether there are any possible geroprotective of cold therapy
- if there are any benefits of exercising in the cold
- Ultimately, do we know anything around a consensus for an effective cold therapy protocol?

**Tangent on F1 [3:00]**

- Peter is excited about the upcoming [2023 Formula 1 season](https://www.formula1.com/en/racing/2023.html)
- He’s also a fan of the Netflix show called [Drive to Survive](https://www.netflix.com/title/80204890)

*Any early predictions from Peter?*

- Going by what we saw in the testing week, Red Bull looked incredibly strong
- The top three look predictably strong: Red Bull, Mercedes and Ferrari
- Two biggest surprises were the strength of Aston Martin and the continued weakness of McLaren
- McLaren has a new rookie driver, [Oscar Piastri](https://en.wikipedia.org/wiki/Oscar_Piastri) who seems like the real deal and people are thinking that he will have a great future in F1
- Ferrari has a new team principal which should help them
- Peter hopes it’s a better season than last season from a competitive standpoint which he thinks it will be
- “*If it were a four-horse race this year, that would be amazing*.” says Peter

## The most common cold exposure therapies [5:45]

***What are even the most common cold exposure therapies?***

- Two most common would be:
  - i) cold water immersion (CWI) and
  - ii) whole body cryotherapy (WBC)

**Cold water immersion (CWI)**

- As the name suggests, this is when you are immersed in cold water
- The most common protocols you’ll see could be as cold as ice water (32 degrees)
- In research studies, you’re more likely to see 40 degrees Fahrenheit up into the 60s
- The variability you see in temperatures comes down to the duration of immersion
- When you’re in the 30s and 40s, we’re talking about two to three minutes
- With the 30 minute protocols, you’re typically up at slightly higher temperatures (50s-60s)
- A couple other terms to know:
  - “Head out immersion” refers to a submersion, basically to the sternum or neck,
  - But there are some protocols that will be submersion to waist only

*\*Challenge of studying cold therapy*

- The problem with this subject matter is that we have to rely heavily on meta-analysis
- And as the old saying goes “1000 sows ears makes not a pearl necklace”
- In other words, a meta-analysis can only be as good as the sum of its parts
- And if its parts are very heterogeneous, which they often are, but not heterogeneous in the right way, then your analyses are somewhat limited
- So one of the challenges here is we’re trying to ascertain information from highly variable studies

**Whole body cryo (WBC)**

- You wouldn’t do this at home as it’s quite expensive to have your own chamber and your own nitrogen tank
- Typically you go to a facility with a cryogenic chamber
- You basically stand in a tube that blasts liquid nitrogen inside
- Temperatures are pretty cold—anywhere from minus 160 to minus 260 degrees Fahrenheit (-110 to -160 degrees celsius)
- How can a person tolerate that?
- You have to remember there’s a totally different conductivity of gas versus liquid
- Because it’s a gas that’s coming at you, it’s not going to be nearly as capable of extracting heat from your body
- Nevertheless, you tend to sit in these things for about three minutes.
- Worth noting that cold water immersion is subjectively much colder than whole body cryo

## Potential benefits of cold water immersion: a look at the data [9:30]

**Overview**:

- Cold plunge/ice bath is much more accessible to people compared to WBC and therefore people have more questions about it
- It can be as simple as buying ice at the grocery store and dropping it into the bathtub
- The other reason we’re going to spend more time talking about cold water immersion is there’s simply much more literature on it

**Most common finding**:

- The most important findings of cold water immersion appear around the improvement with respect to [delayed onset muscle soreness](https://www.sciencedirect.com/science/article/abs/pii/S1466853X21000055) (DOMS)
- Anybody who’s done a hard workout will have no trouble identifying what that feels like
- And that’s probably where we see the bulk of the analysis
- Because most of the studies for cold therapy are done with small sample sizes, combining similar studies in a meta analysis is probably a better way to do it than looking at any individual study

**An important term to understand: standardized mean difference (SMD)**

- Imagine for a moment that you’ve got a whole bunch of studies and you want to compare the findings between them, you use a tool called **standardized mean difference or SMD**
- This tool normalizes study to study results by looking at differences in the means versus the pooled standard deviations and spits out a number

The SMD formula:

![](https://peterattiamd.com/wp-content/uploads/2023/05/f1.-SMD-calc-ama47.png)

**Figure 1.** The formula for standardized mean difference.

- The numerator is the delta between the means
- The denominator is the pooled standard deviations
- A bit of a complex formula for the pooled standard deviations, but it basically is a way to weight the standard deviations by the sample size
- And as is often the case, it’s the square root of a sum of squares
- So it reduces the dimensions back to the same as that of the mean, and therefore, they cancel out
- So the numerator of the SMD is then the difference of means
- The denominator pools the standard deviations, again, weighting them by the populations of each studies
- what you get then is this elegant number, SMD, which is basically an expression of the difference between the two groups in a dimensional or standard unit
- the bigger that number, the bigger the effect

If you’re pooling these data and you’re looking at this to see how one group behaved and compare it to how another group behaved

- An SMD of 0.2 would be considered a small effect
- An SMD of 0.5 would generally be considered a moderate effect
- An SMD say greater than 0.8 would be considered a large effect

![](https://peterattiamd.com/wp-content/uploads/2023/05/f2.-SMD-graph-ama47-1024x483.png)

**Figure 2.** Standardized mean difference of 1 (assuming normality, equal standard deviations and equal sample size in both groups).

**Meta-analysis on cold water immersion**

A [2022 meta-analysis](https://link.springer.com/article/10.1007/s40279-022-01644-9#Tab2) of 52 studies of adults who exercised regularly:

- These were all looked at together b/c these were all studies that were based on cold water immersion (CWI)
- They were all done within 15 minutes following a single bout of strenuous exercise versus a group of controls that were using passive recovery
- Water temps in these studies varied from 41 to 68 degrees Fahrenheit
- The immersion time was up to 30 minutes for those that were at the higher end in the high ’60s, the average was somewhere between about 10 and 15 minutes, and for the people that were in the coldest groups, the low 40s, those studies tended to do repeated bursts at about two minutes a pop
- These were divided up between people that were doing eccentric exercise and high intensity exercise

***What did this meta-analysis find?***

*When looking at muscular power…*

- Overall, CWI had a small, but significant effect on **muscular power** 24 hrs after exercise
- Eccentric phase: standard mean difference: small significant effect in favor of CWI
  - SMD = 0.34 (95% CI 0.06 0.62)
- High intensity output: small significant effect in favor of CWI
  - SMD = 0.22 (95% CI 0.00 0.43)
- The most common power tests found in the studies:
  - Countermovement jumps—a great test of power—jump off a box and land on the floor and then see how high you can jump after
  - 20 meter sprints
  - Repeat sprint ability (e.g. change in each trial time for 6 x20m)

*When they looked at DOMS…*

- CWI had a large effect on reducing DOMS 24 hrs after high intensity exercise
  - SMD = -0.89 (95% CI -1.48 -0.29) p = 0.003
- CWI had a moderate effect in reducing DOMS after eccentric exercise but not until at least 48 hours after
  - SMD = − 0.48 (− 0.79 to − 0.16) p = 0.003

*When they looked at “perceived recovery”…*

- CWI increased feelings of perceived recovery (significant moderate effect) only after high-intensity exercise
  - SMD = 0.66 (0.29 to 1.03) p = 0.001

**In summary**:

- The best meta-analysis we have of cold water immersion suggests that—
  - It improves DOMS more so after high intensity exercise than after eccentric-focused exercise
  - It also improves the feeling of recovery
  - And it even slightly improved high intensity performance and eccentric strength performance, though those were a little bit smaller

## Comparing the effects of cold water immersion with whole-body cryotherapy [18:30]

- The majority of the data looks at CWI, and we don’t have nearly the volume of data on whole-body cryotherapy (WBC)
- On top of that, there aren’t many studies that are comparing cold water immersion directly to whole body cryo, and those that do have conflicted findings

A few studies comparing CWI to WBC:

- After [downhill running](https://www.frontiersin.org/articles/10.3389/fspor.2022.940516/full) (eccentric exercise) – found no difference in the effects of WBC vs CWI
- In a [study](https://meridian.allenpress.com/jat/article/55/4/329/433867/Cryotherapy-Models-and-Timing-Sequence-Recovery-of) of the treatment of middle- and long-distance runners, WBC was more effective than CWI in reducing perceived soreness
- Whereas in a post-marathon [study](https://link.springer.com/article/10.1007/s00421-017-3757-z), WBC had a negative impact on perception of soreness and muscle function compared to CWI
- A [study](https://journals.humankinetics.com/view/journals/ijspp/12/3/article-p402.xml) of single-leg eccentric hamstring exercise showed that CWI was more effective than WBC in accelerating recovery kinetics for countermovement-jump performance at 72 h post exercise. CWI also demonstrated lower soreness and higher perceived recovery levels across 24–48 h postexercise.

Peter’s take:

- When Peter started diving into this literature, whole body cryo was being pitched as superior, however, the data shows that it is clearly not superior
- Its only superiority might be the time commitment and that it’s less painful, but then you have to contrast that with the cost and the inconvenience of it

> “I think the data slightly lean in favor of cold water immersion being superior.” —Peter Attia

## The potential impact of cold exposure on mood and as a treatment for depression [20:45]

***Has there been any new studies that have come out as it relates to cold improving mood or even treatment for depression?***

Consider this [2020 study](https://link.springer.com/article/10.1007/s004210050065#citeas)

- 10 subjects – measured physiologic responses to cold water immersion
- They underwent 1 hour of head-out water immersions, sitting on a chair
- Temperature was 57 degrees Fahrenheit — “57 for an hour is not comfortable”
- Then they would check plasma norepinephrine, dopamine, and epinephrine concentrations at different time periods: 0, 30, 60, 120 minutes
  - Plasma norepinephrine concentration increased a little over 500% (from 1.17 to 6.20 picomole per milliliter) from baseline to one hour and it was statistically significant
  - Plasmic dopamine concentration and it increased 250% over that same period of time
  - Interestingly, epinephrine concentration did not change significantly
  - So, they had a very significant change in norepinephrine and dopamine and no real change in epinephrine
  - And even though the levels decreased from their peak levels at 120 minutes, which was now an hour out of immersion, both norepinephrine and dopamine levels remained elevated over baseline
- Peter says that this neurotransmitter response is potentially one of the reasons why we think cold therapy might be a viable tool in depression and why it’s being studied, even though catecholamines are generally unable to penetrate the blood-brain barrier
- Some interesting [animal research](https://pubmed.ncbi.nlm.nih.gov/17993252/) in rats looking at chronic exposure to cold and it is shown to enhance synaptic release of norepinephrine in two areas of the brain, the locus coeruleus, and the hippocampus

Peter summarizes, “*It’s still not entirely clear what the mechanisms of action are here in the brain, but I will say that subjectively, most people find it* ***very mood stabilizing*** *to have even a* ***fraction*** *of the cold immersion that is talked about in these studies.*”

**Challenges of studying cold therapy**

- A study like this is tough on subjects – to ask them to sit in a bath of 57 degrees for an hour every day
  - But sitting at a temperature cooler than that for three minutes a day might not be as tough
  - Or taking an ice-cold shower for three minutes a day might not be
- Clinically, we definitely see better responses here, but there’s always a catch to this such as it’s very hard to generate a true placebo—Unlike a study looking at a pill where you can clearly give someone a pill that has nothing in it, it’s a little harder to give a fake cold water exposure
- In the [study](https://link.springer.com/article/10.1007/s004210050065#citeas) just discussed, which was looking at objective findings such as catecholamine release, dopamine release….
  - The good news is in those studies, because you’re looking for objective findings, it’s much easier to have a placebo and control group because you’re simply measuring the catecholamine change in the serum
- When you start to get into feelings (DOMS or mood), you don’t have a way to create a sham control group
  - So you can’t put people into water that is not cold and make them think it’s cold just like the people who are in the cold water think it is.

**Plausible mechanism that could explain an improvement in mood**:

- Meta-analysis that have [suggested](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7327519/) that inflammation may be connected with depression
- And we have data that suggests that cold exposure reduces inflammation
- So you now at least have these two plausible mechanisms:
  - i) which is a reduction of inflammation and
  - ii) an increase in potentially favorable neurotransmitters

In one [RCT](https://www.frontiersin.org/articles/10.3389/fpsyt.2020.00522/full), participants from the experimental group undertook 10 whole body cryo sessions at the usual temperatures, so -166 to -256 degrees Fahrenheit five days each week for two weeks

- Then the control group undertook 10 sessions over two weeks, so Monday to Friday back to back, but at a low temperature that was not “cryogenic” (-58 Fahrenheit)
- 30 subjects in the whole body cryo group and 26 in the control group
- Primary outcome was measured looking at depressive symptoms, and this was evaluated using something called the Beck Depression Inventory-II and the Ham-D 17  (validated questionnaires for depression)
- This found a statistically significant difference in the clinical depression assessment for the patients in the WBC group versus the control group
- This is a pretty good study because at least the control group was in a cold chamber

> “It points to there being some smoke here that’s real. I think there’s a fire somewhere because I think there’s a lot of smoke.” —Peter Attia

## How do cold showers compare to cold water immersion? [28:15]

***What do we know about what areas of the body need to be exposed to the cold?***

*if you’re in complete cold water immersion up to your neck, obviously your whole body is touching cold at the same time*

*If you’re in a shower, you’re going to get the cold water on your head, but your whole body’s not going to be submerged*

***Do we know anything about the potential differences between those two types of cold therapy?***

- Cold showers are a great way to [help someone habituate](https://link.springer.com/article/10.1007/s00421-004-1239-6) to cold water immersion—So you could certainly make a case that it’s a decent practice to end your shower every morning with a little bit of cold water
- But it does not appear that the cold shower necessarily needs to involve your head
- The upper torso is probably the most thermally sensitive region for eliciting the cold shock response from a sub maximal stimulus
- You can feel the sensation of your breath being taken away when cold water hits your upper chest
- You don’t have to have your head under to get the effect—you’ll get most of the benefit if you are having the water hit your torso, neck and down the front of your body

Caveats:

- It’s harder to get shower temperatures down as low as ice baths (especially in summer time)
- At some point, you’re going to be limited to probably a water temperature in the high 50s and you’re probably not going to get into the low 50s, high 40s or even the low 40s where you could easily get a cold plunge
- And when we’re just talking about shorter durations, there’s still a little bit of an unknown
- But you can also work up to colder and colder temperatures: go from warm to less warm, from warm to lukewarm, to cool, to cold, etc.

Protocols:

- Some protocols out there say three minutes at 50 degrees
- An modification could be something like:
  - 3 minutes of as cold as you can go on your back
  - 3 minutes at a little bit warmer on the back
  - Then 30 seconds as cold as you can go on the back, as cold as you can go on the front

**Paying attention to breath**:

- Try to pay attention to the impact of the cold on your breath
- Peter says he’s become pretty attuned to this gasp when he enters cold water
- He finds it really fascinating and he assumes it’s mediated by the vagus nerve (part of that mammalian dive reflex)
- This concept is a whole other issue, *Is there a parasympathetic override that’s happening in response to that cold water hitting your chest?*
  - And if there is, again, that would be a beneficial thing
  - We’re so hyper tuned, most of us are over sympathetic, so anything that puts you in a slightly more parasympathetic state is going to be good

Another point Peter would like to emphasize:

- There’s some benefit to immersing more of yourself than less of yourself, even if you want to think about the systemic benefits
- Peter’s wife just ran a marathon recently and sometimes she’d come home and would just put her legs in the cold plunge because running’s a pretty leg only sport
- Peter thinks if she had the time and decided to do the full to neck submersion, she’d get all of those benefits and she might get more of these systemic benefits

“*It’s still a bit too soon to say because I don’t think it’s been studied that clearly, that if you’re looking for all of the benefits, including some of the mood benefits, how much immersion do you need?*” -Peter

## Cold exposure and the activation of brown adipose tissue (BAT) [34:15]

***Is there anything we know and any evidence to support the use of cold plunges specifically trying to activate brown adipose tissue (BAT)?***

- Part of the original storyline around the [episode 2 of Limitless](https://www.imdb.com/title/tt16058472/?ref_=ttep_ep2) was exploring the body’s reaction to extreme temperatures especially the impact on BAT
- Peter and Chris were monitored with a thermal sensors around their neck and upper chest which is where you have the most brown fat
- The thermal sensor would basically sense the activation of your brown fat.
- They were in the middle of the winter in Norway above the Arctic circle and they we went outside, took their shirts off and just hung out for 20 minutes
- In short, the cold air activated the brown fat and induced a lot of “non-shivering thermogenesis”

***More about brown fat and “non-shivering thermogenesis”***

- Brown adipose tissue is a much narrower subset of your adipose tissue (as opposed to white fat)
- The reason that the brown one is denoted brown is it has lots of mitochondria in it, so it’s a much more energy consumptive cell and therefore, it can increase thermogenesis, but not through shivering
- If you are cold and you’re shivering and energy expenditure goes up for that reason, it’s obvious
- But this is now saying, “No, no, no, the brown adipose tissue is being activated in a non-shivering way and you’re getting this thermogenesis that goes up.”

*But why is this interesting?*

- It’s interesting to people because there’s this view that says, “the more brown adipose tissue you have or the colder you are, the more energy you’ll expend”
- It’s a long-winded way of saying, “*Hey, should cold exposure be viewed as a hack for weight loss?*” ⇒ The short answer is “no, it just doesn’t move the needle enough”
- There is no great evidence that cold exposure meaningfully increases, in a clinically relevant way, the quantity of BAT that a person has
- And given the relatively limited amount of BAT that adults have, it’s not clear that this is a reasonable way to move the needle in terms of energy expenditure
- Now that might be different in young kids as young kids actually have a lot more brown adipose tissue, but we readily lose it through adolescence
- The amount of brown fat a person has is probably a decent marker for metabolic health, however, trying to exploit it by cold exposure as a means for increasing thermogenesis is a rounding error

> “*If we’re talking about [activating brown adipose tissue] as a solution for overweight or obesity in adults, it’s not a needle mover.*” —Peter Attia

## Exercising in cold temperatures: impact on exercise performance [38:30]

**Exercising in the cold**

*Anything notable about exercising in the cold? Anything from swimming in cold water to going for a run outside in the winter if you live in a cold climate?*

- There’s actually less data here than some of the other extremes
- There is a lot more data on exercise performance in heat or at altitude, for example

What the [data](https://www.researchgate.net/profile/John-Castellani/publication/280581154_Cold_Stress_Effects_on_Exposure_Tolerance_and_Exercise_Performance/links/600ac1ff45851553a0606f04/Cold-Stress-Effects-on-Exposure-Tolerance-and-Exercise-Performance.pdf) says about exercise in the cold:

- It seems that exercise in the cold runs a slightly higher risk of injury in addition to cold-induced asthma
- Certain things like maximum heart rate are going to be lower in cold environments
- And the general trend is that VO2 max is lower in cold temperatures
- (in the [podcast with Mike Joyner](https://peterattiamd.com/mikejoyner/) it’s discussed how a big part of VO2 max comes down to heart rate, therefore, things that are going to acutely drop maximum heart rate are going to drop VO2 max)
- The physiologic responses to cold air exposure are similar to those of cold water exposure
- So you’re going to see more vasoconstriction, and that’s probably the thing that makes it the most challenging
- If you think about it, when you’re exercising, you’re trying to get as much oxygen and nutrients to the muscles as possible—those are the things that are primarily working the hardest when you’re exercising.
- And if you’re cold and you undergo vasoconstriction, then you’re basically creating a traffic jam which makes it much harder to get the stuff where you need to go
- There’s some conflicting evidence about the effects of cold air on time to exhaustion (TTE) in aerobic testing, but there seems to be an Inverted-U with the maximal TTE

**Peter’s anecdote about the possibility of an “inverted-U with the maximal TTE”**:

“*When I was a cyclist and I was a time trialist, so this was a very reproducible type of sport. It’s the same race every single time. It’s either a 20-kilometer or 40-kilometer race. Those are the only things you did. So it’s either a slightly sub 30 or slightly sub one hour race. And we trained at Fiesta Island… And you can probably imagine. There were a few people who were more fastidious with all the data, like what produced my best times in terms of temperature, barometric pressure, humidity, et cetera, et cetera. And again, cycling’s a bit different because you’re moving, so the speed and temperature becomes more amplified. But hands down, for me, 50 degrees Fahrenheit produced the best results by far. Once it even got to 60, performance would start to go off a little bit, maybe low 50s, 50, 52, 53. But if it was much cooler than that, and it didn’t get cooler than that, except in the winter and the mornings in San Diego, but sometimes you would race at 45 degrees, performance would actually drop off a little bit. But again, the wind chill when you’re riding at 42 kilometers an hour or whatever, it feels a lot cooler than that. So there really is something to this Inverted-U that I think makes sense*.”

- That said, it’s going to look different if you’re a runner and it’s going to look different if you’re a swimmer
- Peter is surprised that this is not known in excruciating detail what the Inverted-U curves look like for various sports, even if we just did it for swimming, biking and running

**Data on VO2 max and cold**

- One [study](https://www.researchgate.net/profile/John-Castellani/publication/280581154_Cold_Stress_Effects_on_Exposure_Tolerance_and_Exercise_Performance/links/600ac1ff45851553a0606f04/Cold-Stress-Effects-on-Exposure-Tolerance-and-Exercise-Performance.pdf) looked at cold water immersion and found that for every degree Celsius drop (if you’re starting at an optimal temperature) there was about a 5% reduction in VO2 max
- This was mostly transmitted through the reduction in maximum heart rate, which between warm and cold could be up to 30 beats per minute if core body temp was down by as much as 3.6 degrees Fahrenheit

For one of Peter’s [Catalina swims](https://www.youtube.com/watch?v=yMQFd9q07Zo&t=5s&pp=ygUZcGV0ZXIgYXR0aWEgY2F0YWxpbmEgc3dpbQ%3D%3D), he did rectal temperature right before and right after the swim (more accurate temperature than an oral)

- His rectal temp went from 99 to 93, so it’s about a six degree drop—pretty big temp drop
- But that was after 10 hours in sub-60 degree water, so on the one hand, it’s actually remarkable that the body is able to thermoregulate that well, but at that point you are starting to get a performance hit

***At what temperature does the body start to shut down and it becomes dangerous?***

- Peter’s team thought that 91, 92 was a dangerous zone in swimming
- And certainly once you get below about 88, you really start to run the risk of ventricular ectopy and adverse ventricular rhythms
- Peter knew a guy who had a cardiac arrest while swimming the Catalina Channel due to hypothermia
- His temp when they got him out of the water was about 88

## Potential downsides of cold therapy and its impact on hypertrophy, strength, and recovery [44:45]

***What do we know about the potential cons of cold therapy?***

*Are there any use cases where this may be a detriment and people should think about and be aware of?*

- One [study](https://link.springer.com/article/10.1007/s40279-020-01362-0) showed that cold water therapy immediately after strength training can attenuate hypertrophy gains and *certain* strength gains
- With certain types of gains it might be preserved such as some of the eccentric tasks and maybe some of the higher intensity tasks
- But in terms of pure strength and hypertrophy, it does appear to be a negative

**2015** [**RCT**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4594298/)

- Looked at 24 physically active, healthy young men, average age about 21
- Put them on a 12-week lower body strength training program
- Half of them underwent cold water immersion, which was sitting in a bath of 50 degrees for 10 minutes – so both legs immersed up to the waist for 10 minutes at 50 degrees after each training session for 12 weeks
- Then the controls didn’t do anything
- The other thing is the participants were not encouraged to rewarm following the cold immersion—they had to wait at least two hours before they could take a warm shower, for instance
- Results:
  - Both groups increased muscle mass and strength compared to pre-training
  - That tells us that this protocol did not completely blunt the effects of training
  - However, the cold water immersion group had less muscle mass and strength than the active recovery group
  - The active recovery group increased their leg press strength by about 200 kilograms whereas the cold water immersion group increased by only 133 kilograms
  - Both of those are really big numbers, but one is clearly bigger than the other

**Another [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4594298/)**

- Looked at 10 men (so small study like most of these types of studies)
- The participants completed two bouts of single leg strength exercises on separate days
- Each session was followed by a) cold water immersion or b) an active recovery
- What’s nice about this study is each guy is his own control because you’re doing single leg exercises
- Muscle biopsies were then taken from the vastus lateralis on each leg before and after the training sessions
- The normal increase in satellite cells (skeletal muscle stem cells) that occurred after the acute strength exercise, which facilitates muscle growth, was blocked or delayed in the cold water immersion group
- This would lead us to suggest that cold water immersion suppresses the activation of a protein kinase that’s required for cell growth

**Another** [**study**](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/JP278996)

- Found that cold water immersion lowers the capacity of the muscle to take up and/or direct dietary protein-derived amino acids towards the de novo myofibrillar protein accretion
- In other words, cold water is making it harder for the body to direct amino acids into the creation of new protein
- This was small, but it was rigorous
- It took 12 healthy strong young guys, 21 years old
- Single resistance type exercises followed by water immersion in both legs for 20 minutes
- The way this study worked was after the exercise, they would put one leg into cold water immersion, and the other leg obviously did nothing
- The cold water immersion here was 46 degrees Fahrenheit, whereas the control arm was like 86 (like a perfect bath)
- Each subject is his own control—So one leg is in cold, one leg is in warm
- After the water immersion, each of the subjects drank a beverage that consisted of 20 grams of radiolabeled milk protein
- What you’re trying to look at is: *what’s the incorporation of the labeled protein in each leg?*
  - And what they found was there was 24% less incorporation of the labeled protein in the cold water immersion leg than in the control leg
- Peter could be critical and say,
  - “but we don’t know what the total amino acid incorporation was, because remember you’re turning over amino acids all the time”
  - “Part of what’s getting incorporated is other amino acids. So it could be that you still saw the same amount of amino acid being incorporated, even though 24% was less of what you just ingested but that could have been made up by proteins that were broken down”

**Takeaway**

- The limited data is all pointing in the same direction
- Peter’s takeaway would be, “If your absolute objective is maximum hypertrophy, cold water therapy may not make sense, at least in the day or so after heavy resistance training.”

## Are the blunting effects of cold on hypertrophy due to the effects on inflammation? [50:45]

***Are the blunting effects of cold on hypertrophy due to the effects on inflammation?***

*And from that, can systemic changes in inflammation be measured?*

*Or are the effects of cold really only beneficial in reducing pain from a localized inflammation scenario (e.g., ankle sprain)?*

- In short, it’s not entirely clear but “I historically always assumed it was due to the reduction in inflammation” says Peter
- That same group that found blunted strength and hypertrophy specifically asked the question of whether reduced inflammation was a factor
- The [study](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/JP272881) compared the effects of cold water immersion versus active recovery on inflammatory cells and pro-inflammatory cytokines, heat shock proteins and things like that
  - They took nine men in a crossover study, performed unilateral lower body resistance exercises on separate days, at least a week apart
  - On one day, they immersed their lower body in cold water, 50 degrees Fahrenheit for 10 minutes after exercise
  - On the other day, they just cycled at low intensity for 10 minutes as a recovery
  - Muscle biopsies were taken on the exercise leg, two, 24, 48 hours after exercise in both trials
  - Interestingly, in this study, there weren’t really significant changes in inflammatory cell cytokines, heat shock proteins, etc., between these different treatments
  - So although cold therapy seems to reduce subjective pain, it doesn’t seem to have much of an effect on circulating inflammatory markers

This finding was supported by a very recent [2023 meta-analysis](https://www.frontiersin.org/articles/10.3389/fphys.2023.1006512/full?utm_source=dlvr.it)

- It that found no significant effect either immediately, or at 24 or 48 hours, of levels of Interleukin 6 (IL-6) following cold water immersion
- But that analysis was really only based on a couple of studies, therefore, “the jury’s still out on this”
- There was a similar meta-analysis that looked at C-reactive protein (admittedly a pretty crude marker of inflammation)
- But they looked at seven studies in this meta-analysis and found no significant differences either immediately, 24 or 48 hours following cold water immersion when looking at circulating CRP

## Does cold exposure offer any potential geroprotective benefits? [53:15]

***What do we know about cold and any potential geroprotective benefits?  Is there anything there?***

- “I don’t believe there is” says Peter
- There’s at least some evidence to suggest that sauna is geroprotective, at least when it comes to a couple of disease states
- But Peter and his research team just simply couldn’t find any meaningful evidence to suggest that cold exposure has any geroprotective benefit beyond what we’ve already discussed

[**2022 review**](https://www.tandfonline.com/doi/full/10.1080/22423982.2022.2111789)

- It basically looks at all the literature on cold and its effects on what are the health benefits of it potentially
- One of the problems with this study is it didn’t really distinguish between cold water swimming and cold water immersion
- So posit for a moment that we have no way to know if these benefits are brought on by the exercise, i.e. the swimming or the cold immersion
- The study found:
  - a reduction in adipose tissue
  - some increase in immune function
  - increased insulin sensitivity,
  - and other metabolic benefits that could certainly indirectly make the case for longevity

But Peter says, “I have a very hard time looking at these studies and trying to impute any benefit.”

- We have to look at the immersion studies if we’re going to do that
- And if we look at the immersion studies, we just don’t see anything there that would say that it’s broadly geroprotective

## Cold therapy protocols for delayed onset muscle soreness (DOMS) [56:30]

**Sauna protocol**

- In terms of sauna, Peter’s protocol is base on the “least bad data” available
- So if you look at the most rigorous protocols or studies based on protocols in Finland, we come away with this it needs to be at least four times a week, at least 20 minutes per session, and at a temp of at least 179 degrees Fahrenheit

**Cold therapy protocol**

- When it comes to cold water immersion, probably the most agreed upon protocol for DOMS
- Again, if your objective is to reduce the delayed onset of muscle soreness that accompanies intense exercise… and assuming your objective is not purely hypertrophy, in which case you’re solving one problem and creating another
- A [2016 meta-analysis](https://link.springer.com/article/10.1007/s40279-015-0431-7) came to the conclusion that 10 to 15 minutes immediately following exercise in water between 50 and 59 degrees Fahrenheit (10 to 15 celsius) was probably the sweet spot
  - In that analysis it could be within an hour of the end of exercise (so not immediate)
  - And going back to the metric we talked about, the SMD, these were not huge effect sizes—0.29, 0.315
  - So that is somewhere between what we would call a small effect and an intermediate effect
  - But an interesting thing noted by that study was that there was no improvement when you went below 50 degrees
    - So if you went 41 to 50, had no improvement relative to 50 to 59 for DOMS.
  - But this has all the limitations that we’ve talked about—very small studies, variable quality of the studies

**Cold therapy for mood**

- For some of the other adaptations (i.e., not for DOMS), we have even less of a consensus
- We don’t really have a consensus around what’s the optimal treatment for mood
- given that it’s also quite subjective and certainly what Peter has seen empirically, it can be **colder and shorter** for mood compared to DOMS
- In other words, there’s a temperature duration axis that you’re playing off
- So colder temperature requires shorter duration
- As you move towards DOMS, you need to be at the longer end of those, so meaning the greater product of temperature and duration
- As you’re moving towards mood effects, you can move towards a lower end of that

## Summarizing the data and takeaways from Peter [1:01:00]

- This is one of those areas where the fact that we don’t know answers to these questions is infuriating
- You do have to understand that there’s no financial incentive to study these things
- But there’s potentially benefit here
- “It disappoints me that, for example, the NIH wouldn’t devote enormous resources to this, to study this correctly and to study sauna correctly for that matter”
- To study all sorts of things that don’t have enormous financial upside, but are relatively low cost interventions that could be valuable
- For example, when you think about how much money goes into funding a drug trial that’s trying to figure out if this drug has efficacy versus that drug in the treatment of depression…
- That’s an important question to ask, and it’s important to get the answer to that question
- But you could take the cost of doing one Phase III drug trial, one Phase III drug trial, and the cost of that study could answer everything we want to know about temperature full stop, not even close.

> “That’s just a frustration I have, is I don’t know that we’re ever going to get answers to these questions because we’re just generating more and more sow’s ears and just hoping that somehow enough of them are going to give us a pearl necklace” —Peter Attia

**Summarizing the evidence [1:02:30]**

- There’s a ton of variability in the results of the post exercise cold therapy literature
- What you don’t want to do is be in the business of looking at one study and saying you know the answer
- There’s really pretty clear signal that cold has somewhere between small and medium effects on the reduction of DOMS
  - Probably after any training, but you’ll want to minimize your use of it after resistance training if your objectives are strength and or hypertrophy
  - If you’re doing more high intensity training, especially training that has a focus on **eccentric**, so running and things like that, and you’re not as concerned with strength and hypertrophy, then the trade-off might be worth it
- And Peter says we don’t know that it matters a whole heck of a lot how you’re getting your cold exposure
  - Do you need to buy a super-duper fancy cold plunger?
    - No. You can just take a cold bath or a cold shower
    - You certainly don’t need to do whole body cryo. Don’t be sucked into that game.

**Cold therapy and mood**

- One of the most interesting things in all of this is the mood stuff
- Peter really wishes we had more info on that
- He wishes we could say that with a high degree of confidence that a cold shower every day is sufficient to do it because that’s a more achievable thing to do than asking people to sit for 60 minutes in a 57-degree path

**Final thoughts from Peter**:

“*If we’re talking about a zero-sum game here and the opportunity cost is really high, you should not be putting any time into sauna or long cold plunging if you’re not spending the appropriate amount of time already exercising. To spend an hour in the sauna or cold plunge a day and not exercise is a strategic error*.”

“*I worry that this wasn’t the answer people wanted. I know that sometimes, we want the answer to be different. Sometimes, we want to believe or want to believe that this is the elixir here. This is the holy grail, but I think there’s something good here*.”

“*I still do spend minutes each day in cold, and that probably means, by the way, I’m taking a bit of a hit on hypertrophy and strength. But I think for me personally, I like to optimize more around mood. So that’s why I find my affection for cold water, but I don’t think it’s a panacea either*.”

§

## Selected Links / Related Material

**Previous AMA episode discussing cold therapy**: [#132 – AMA #16: Exploring hot and cold therapy](https://peterattiamd.com/ama16/) | Peter Attia (peterattiamd.com) [2:00, 20:45]

**More recent AMA episode that touched on cold therapy for sleep**: [AMA #42](https://peterattiamd.com/ama42/) | Peter Attia (peterattiamd.com) [2:00]

**Netflix show about Formula 1 that Peter enjoys**: [Watch Formula 1: Drive to Survive](https://www.netflix.com/title/80204890) | (netflix.com) [3:30]

**2022 meta-analysis looking at cold water immersion and its effect on muscular power, DOMS, and perceived recovery**: [Impact of Cold-Water Immersion Compared with Passive Recovery Following a Single Bout of Strenuous Exercise on Athletic Performance in Physically Active Participants: A Systematic Review with Meta-analysis and Meta-regression](https://link.springer.com/article/10.1007/s40279-022-01644-9#Tab2) (Moore et al., 2022) [15:00]

**Studies comparing the effects of cold water immersion against whole-body cryotherapy**:

- One study looked at downhill running (eccentric exercise): [The Comparative Effect of Different Timings of Whole Body Cryotherapy Treatment With Cold Water Immersion for Post-Exercise Recovery](https://www.frontiersin.org/articles/10.3389/fspor.2022.940516/full) (Haq et al., 2022) [18:45]
- A study that found CWI was more effective than WBC for perceived soreness in distance runners: [Cryotherapy Models and Timing-Sequence Recovery of Exercise-Induced Muscle Damage in Middle- and Long-Distance Runners](https://meridian.allenpress.com/jat/article/55/4/329/433867/Cryotherapy-Models-and-Timing-Sequence-Recovery-of) (Qu et al., 2020) [19:00]
- in a post-marathon study, WBC had a negative impact on perception of soreness and muscle function compared to CWI: [Recovery following a marathon: a comparison of cold water immersion, whole body cryotherapy and a placebo control](https://link.springer.com/article/10.1007/s00421-017-3757-z) (Wilson et al., 2017) [19:15]
- study of single-leg eccentric hamstring exercise showed that CWI was more effective than WBC in accelerating recovery kinetics for countermovement-jump performance as well as lower soreness and higher perceived recovery levels across 24–48 h postexercise: [Recovery From Exercise-Induced Muscle Damage: Cold-Water Immersion Versus Whole-Body Cryotherapy](https://journals.humankinetics.com/view/journals/ijspp/12/3/article-p402.xml) (Abaïdia et al., 2016) [19:30]

**2000 study suggesting that the neurotransmitter response is potentially one of the reasons why we think cold therapy might be a viable tool in depression**: [Human physiological responses to immersion into water of different temperatures](https://link.springer.com/article/10.1007/s004210050065) (Šrámek et al. 2000) [21:30]

**Animal research in rats looking at chronic exposure to cold which has shown to enhance synaptic release of norepinephrine in two areas of the brain, the locus coeruleus, and the hippocampus**: [Adapted cold shower as a potential treatment for depression](https://pubmed.ncbi.nlm.nih.gov/17993252/) (Shevchuk, 2008)[23:30]

**Example of a meta-analysis suggesting that inflammation may be connected with depression**: [Inflammatory markers in depression: A meta-analysis of mean differences and variability in 5,166 patients and 5,083 controls](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7327519/) (Osimo et al., 2020) [26:00]

**In one RCT, it found statistically significant difference in the clinical depression assessment for the patients in the WBC group versus the control group**: [Efficacy of the Whole-Body Cryotherapy as Add-on Therapy to Pharmacological Treatment of Depression—A Randomized Controlled Trial](https://www.frontiersin.org/articles/10.3389/fpsyt.2020.00522/full) (Rymaszewska et at al., 2020) [26:30]

**Episode of Limitless where they explored cold air exposure and its effect on BAT**: [Shock](https://www.imdb.com/title/tt16058472/?ref_=ttep_ep2) | (imdb.com) [34:45]

**Episode of The Drive with Mike Joyner discussing HR and VO2 max**: [#217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.](https://peterattiamd.com/mikejoyner/) | Peter Attia (peterattiamd.com) [40:00]

**Conflicting evidence about the effects of cold air on time to exhaustion (TTE) in aerobic testing, but there seems to be an Inverted-U with the maximal TTE**: [Cold Stress Effects on Exposure Tolerance and Exercise Performance](https://www.researchgate.net/profile/John-Castellani/publication/280581154_Cold_Stress_Effects_on_Exposure_Tolerance_and_Exercise_Performance/links/600ac1ff45851553a0606f04/Cold-Stress-Effects-on-Exposure-Tolerance-and-Exercise-Performance.pdf) (Castellani et al., 2016) [40:30]

**One study looked at cold water immersion and found that for every degree Celsius drop (if you’re starting at an optimal temperature) there was about a 5% reduction in VO2 max**: [Cold Stress Effects on Exposure Tolerance and Exercise Performance](https://www.researchgate.net/profile/John-Castellani/publication/280581154_Cold_Stress_Effects_on_Exposure_Tolerance_and_Exercise_Performance/links/600ac1ff45851553a0606f04/Cold-Stress-Effects-on-Exposure-Tolerance-and-Exercise-Performance.pdf) (Castellani et al., 2016) [42:30]

**One study showed that cold water therapy immediately after strength training can attenuate hypertrophy gains and certain strength gains**: [The Effects of Regular Cold-Water Immersion Use on Training-Induced Changes in Strength and Endurance Performance: A Systematic Review with Meta-Analysis](https://link.springer.com/article/10.1007/s40279-020-01362-0) (Malta et al., 2020) [45:00]

**2015 RCT that show some level of blunting of hypertrophy with CWI compared to active recovery**: [Post-exercise cold water immersion attenuates acute anabolic signalling and long-term adaptations in muscle to strength training](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4594298/) (Roberts et al., 2015) [45:30]

**Study that found that cold water is making it harder for the body to direct amino acids into the creation of new protein**: [Postexercise cooling impairs muscle protein synthesis rates in recreational athletes](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/JP278996) (Fuchs et al., 2019) [48:00]

**Crossover study that found that, although cold therapy seems to reduce subjective pain, it does not have effects on circulating inflammatory markers**: [The effects of cold water immersion and active recovery on inflammation and cell stress responses in human skeletal muscle after resistance exercise](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/JP272881) (Peake et al., 2016) [51:30]

**2023 meta-analysis that found no significant effect on levels of interleukin 6 following cold water immersion**: [Effects of cold water immersion after exercise on fatigue recovery and exercise performance–meta analysis](https://www.frontiersin.org/articles/10.3389/fphys.2023.1006512/full?utm_source=dlvr.it) (Xiao et al., 2023) [52:30]

**2022 review study that looked at all the literature on cold and its potential beneficial effects on health**: [Health effects of voluntary exposure to cold water – a continuing subject of debate](https://www.tandfonline.com/doi/full/10.1080/22423982.2022.2111789) (Espeland et al., 2022) [54:45]

**2016 analysis looking at the best protocol for cold water therapy for muscle soreness/DOMS**: [Can Water Temperature and Immersion Time Influence the Effect of Cold Water Immersion on Muscle Soreness? A Systematic Review and Meta-Analysis](https://link.springer.com/article/10.1007/s40279-015-0431-7) (Machado et al., 2015) [58:00]

§

## People Mentioned

- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [2:00]
- [Oscar Piastri](https://en.wikipedia.org/wiki/Oscar_Piastri) [4:30]
- [Mike Joyner](https://twitter.com/drmjoyner) [40:00]

§