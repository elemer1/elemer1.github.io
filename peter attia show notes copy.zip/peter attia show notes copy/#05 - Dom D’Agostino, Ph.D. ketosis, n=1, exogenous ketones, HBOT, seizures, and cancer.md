# #05 – Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer

**Source:** [https://peterattiamd.com/domdagostino/](https://peterattiamd.com/domdagostino/)

---

##### Check out more content with Dom D’Agostino:

- *(July 16, 2018)* [Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](/domdagostino/)
- *(June 22, 2020)* [AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](/domdagostinoama01/)
- *(July 20, 2020)* [AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health](/domdagostinoama02/)

In this episode, Dom D’Agostino, one of the smartest people on all things related to ketones, digs deep into the research and application of these molecules. We discuss ketone esters, diesters and monoesters, racemic ketones, medium-chain triglycerides (MCTs), C8 (caprylic acid) on the [exogenous ketone](/experience-exogenous-ketones-2/) (EK) side of things. We also cover a lot of Dom’s fascinating work with hyperbaric oxygen therapy (HBOT). If you’re just curious about [ketosis](/ketosis-advantaged-or-misunderstood-state-part-i/) and/or HBOT, or working on a dissertation related to nutritional biochemistry, there’s probably something in this episode for you to take away.

##### **Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)**

![The Peter Attia Drive](images/domdagostino/the_Drive_public.png)

Play

#05 - Dom D'Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer

#05 - Dom D'Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer

1x15s30s

0:002:43:06

Dom also discusses the strategy and tactics of the metabolic management of cancer, which includes, but is certainly not limited to, a ketogenic diet (KD). Cancer is covered throughout this episode, but if there’s one section to listen to, skip ahead to the 2-hour mark and listen to what Dom has to say about the Press-Pulse approach.

## We discuss:

- Dom’s early medical training in hyperbaric chambers [7:00];
- Effect of ketones on cancer cells [20:00];
- Ketones and oxygen toxicity seizures [32:00];
- HBOT & its many applications [40:00];
- Ketones, MCTs, and exogenous ketones [59:15];
- How ketones affect blood glucose [1:20:00];
- Ketone esters, salts, enantiomers vs. racemic BOHB [1:38:00];
- Dom’s ketone tolerance test [1:56:00];
- The metabolic management of cancer using a Press-Pulse approach [1:59:45]; and
- More.

---

## Show Notes

### How Peter and Dom met [5:30]

- Peter [gave a talk in 2013](https://peterattiamd.com/my-quantified-self-part-i/) at the Institute for Human & Machine Cognition (IHMC) and met Dom:
  - [Dom asked a question during Peter’s Q&A](https://youtu.be/NqwvcrA7oe8?t=1h9m51s) (‘what do you think about exogenous ketones?’).
- Ken Ford arranged for them to have dinner after the talk;
- Dom [gave a talk around the same time](https://www.youtube.com/watch?v=gONeCxtyH18) (2014) at IHMC (Dom is a Visiting Senior Research Scientist at the IHMC).

### Dom’s early medical training [7:15]

- Ph.D. in neuroscience and physiology;
- Postdoc in neurocontrol of autonomic regulation;
- Fellowship was developing technologies to study hyperbaric atomic force microscopy;
- What the heck is [atomic force microscopy](https://en.wikipedia.org/wiki/Atomic_force_microscopy) (AFM), how it led to multiple grants from the Department of Defense, and what it informs us about cancer;
  - **Atomic force microscopy (AFM):** a microscope that has the capacity to image living cells at the nanoscopic level to see what’s happening to the mitochondria and cell membrane among other things.
- Dom, and team, developed a way to use this technology reliably inside a [hyperbaric chamber](https://en.wikipedia.org/wiki/Hypobaric_chamber), and also added a [confocal microscope](https://en.wikipedia.org/wiki/Confocal_microscopy);
- Dept of Defense interested in this technology because it could give insight into how Navy SEALs might react to being exposed to graded levels of oxygen and hyperbaric pressure during stealth diving missions.

##### **AFM leads to a serendipitous discovery about cancer cells**

While doing research for the military (Navy) about seizures related to oxygen toxicity:

- Dom noticed cancer cells (glioblastoma astrocytes – [U87 glioblastoma cells](https://en.wikipedia.org/wiki/U87)) were dying, more so than a control cell, when exposed to certain levels of hyperbaric oxygen pressure;
- Cancer cells first grow and proliferate in the presence of free radicals/oxidative species, but eventually die ([apoptosis](https://en.wikipedia.org/wiki/Apoptosis)) due to the overwhelming oxidative stress, a U-Shaped curve;
- They were reversing tumor hypoxia in tumor cells using HBOT ([Poff et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3673985/));
- Cancer cells were producing more Superoxide anion;
  - In normal O2, environment things were relatively “normal”;
  - but, when they were hit with hyperbaric O2, excess free radicals, accelerating lipid peroxidation;
  - Normal O2 at 0.2 [atmospheric absolute (ATA)](https://en.wikipedia.org/wiki/Atmosphere_(unit));
  - big jump up at 0.95 (about 5 times the pressure) ATA: superoxide anion production;
  - At 3.5 ATA, they were essentially cooking the cells from the inside out, mitochondria started producing so much ROS, that the mitochondria basically exploding.

##### **‘What was obvious is that cancer cells have elevated rates of reactive oxygen species that they use for growth and proliferation…and it also fuels metastasis and invasiveness of cancer cells. And because they overproduce oxygen free radicals in the context of high oxygen, you can push the cells above their antioxidant potential and then trigger apoptosis.’**

- Dom thought cancer cells should be more hearty, but found the opposite in his experiments;
- Dom also looked at O2 toxicity seizures, including [grand mal, or tonic clonic](https://en.wikipedia.org/wiki/Generalised_tonic-clonic_seizure) seizures;
- The tumor mitochondria are defective in many ways:
  - You have the Warburg effect where tumor cells are fermenting in the presence of O2;
  - You have the aberrant activity of the mitochondria, which are creating excess free radicals;
  - HBOT is a therapeutic modality that can be used to exploit this.

### What is the military’s interest in HBOT? [16:00]

- Military wanted Dom to help them to understand the cellular and molecular mechanisms of oxygen toxicity seizures in order to protect Navy SEAL divers using a rebreather during stealth diving missions;
- Example: [US Navy CNS oxygen toxicity hit](https://www.youtube.com/watch?v=z7Hi0HO24Vk)
- Why diving increases the risk of oxygen toxicity when using an oxygen rebreather (military uses these to reduce bubbles to be more hidden from the enemy);
- Free radicals are powerful signaling molecules for growth and proliferation.

### Effect of ketones on cancer cells and seizures [20:00]

##### **Ketones and cancer**

- Dom noticed cancer cells ([glioblastoma](https://en.wikipedia.org/wiki/Glioblastoma) astrocytes) didn’t grow as rapidly in the presence of β-hydroxybutyrate (BOHB);
- Ketones allowed neurons to preserve their membrane potential and normal cellular function even in the context of extreme oxidative stress;
- In the lab, Dom started doing glucose subtraction and adding ketones, and noticed that normal healthy neurons thrived in a low-glucose environment if ketones were present;
  - but the cancer cells would die;
  - Also replicated and published in various neuroblastoma cell lines ([Skinner et al., 2009](https://www.ncbi.nlm.nih.gov/pubmed/19159745)).

##### **‘Studying cancer … was like a pet project that was completely intellectually stimulating to me, and something that I could not just shelf, and come back to a later time… I just kept reaching out to scientists, top-level cancer biologists, and showing them my data, and asking them to explain it. Then I stumbled across Tom Seyfried.’**

- (More on cancer @ [1:59:45]).

##### **Ketones and seizures**

- Dom believes the ketogenic diet is grossly underutilized as an anti-seizure strategy;
- Found a KD was a very effective anti-seizure strategy, even when drugs fail;
  - 2/3rds of patients respond favorably;
  - 10-15% are super-responders (never have seizures again, off meds);
- (More on seizures @ [32:30, 58:00, 1:15:00, 1:46:00]).

##### **A big focus for Dom and his colleagues is answering the question: do ketone bodies mediate the anti-seizure effects of the ketogenic diet? A [recent paper](https://www.ncbi.nlm.nih.gov/pubmed/29325899) looked into this very question.**

![](https://peterattiamd.com/wp-content/uploads/2018/07/classic-1024x1024-300x300.jpg)

**Figure 1. The Classic Ketogenic Diet.** An individualized and structured diet that provides specific meal plans. Foods are weighed and meals should be consumed in their entirety for best results. Macronutrient Ratio: 4:1 (fat in grams to protein + carbs in grams). [[Charlie Foundation](https://charliefoundation.org/)]

### The influence of metabolism on cancer and the Warburg Effect [25:00]

##### **What is the Warburg effect?**

- The Warburg effect is essentially insufficient respiration (i.e., mitochondrial OXPHOS) resulting in compensatory fermentation through glycolysis and substrate level phosphorylation (SLP);
- ~ 90% of cancer cells have a Warburg phenotype.

### What is the controversy around the Warburg effect? [32:00]

- Too long to go into: Dom recommends [Tripping over The Truth](https://www.amazon.com/Tripping-over-Truth-Overturning-Entrenched/dp/1603587292) to understand it;
- There’s also an [article by Sam Apple in the New York Times](https://www.nytimes.com/2016/05/15/magazine/warburg-effect-an-old-idea-revived-starve-cancer-to-death.html) covering some of it;
- And a [comprehensive book by Tom Seyfried](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920/ref=pd_sim_14_3?_encoding=UTF8&pd_rd_i=0470584920&pd_rd_r=90f3d9c6-86db-11e8-ad3a-631c770a9f40&pd_rd_w=u76CX&pd_rd_wg=CHMLW&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=7967298517161621930&pf_rd_r=13NHW1020TB3Y10Y187H&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=13NHW1020TB3Y10Y187H);
- While there is a dynamic interplay between metabolism and genetics, too much focus has been on the genetic pathways leading to cancer and not enough on how metabolism can be an epigenetic regulator;
  - to the extent that James Watson [wrote an op-ed in the New York Times](https://www.nytimes.com/2009/08/06/opinion/06watson.html) calling for more research into cancer metabolism;
- (One controversy is that many researchers believe that the mitochondria in tumor cells are not damaged and therefore “choose” to ferment in the presence of oxygen, while also utilizing OXPHOS. They see ATP generated outside of glucose fermentation. One of the counters to this, [lodged in 2012 by Tom Seyfried](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920/ref=pd_sim_14_3?_encoding=UTF8&pd_rd_i=0470584920&pd_rd_r=90f3d9c6-86db-11e8-ad3a-631c770a9f40&pd_rd_w=u76CX&pd_rd_wg=CHMLW&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=7967298517161621930&pf_rd_r=13NHW1020TB3Y10Y187H&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=13NHW1020TB3Y10Y187H), is that tumor cells ferment both glucose and glutamine, the latter of which is generated in the TCA cycle via SLP and can be mistaken for ATP generated through OXPHOS);
- Dom points out that ketones are a “non-fermentable fuel,” whereas cancer cells will use glucose and glutamine as the two primary fermentable fuels.
- How Dom thinks about ketones in terms of cancer metabolism:
  - Glutamine can make glutamate, alanine, aspartate, and lactate;
  - and [glutaminolysis](https://www.ncbi.nlm.nih.gov/pubmed/28301735) is driven by the malate-aspartate shuttle and that has become a major focus of cancer researchers (e.g., [Yang et al., 2017](https://www.ncbi.nlm.nih.gov/pubmed/28301735));
  - Cancer researchers are looking at targeting glutamine (e.g., [Shelton et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/20473919/)), and it’s not easy, because it has huge toxicity side effects (in mice);
  - “The glutaminase inhibitor DON (6-diazo-5-oxo-L-norleucine) has shown therapeutic benefit in the clinic, as long as toxicity can be managed ([Seyfried et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5324220/)).”

### Exploring Dom’s research for the Office of Navy Research [32:30]

##### **Can ketone esters prevent oxygen toxicity seizures in divers?**

- Why are seizures occurring (sometimes fatal) in soldiers using underwater rebreathers in their secret stealth dives?
  - Can occur after only 10 minutes under 50 ft of water.
- Ketone esters help to prevent oxygen toxicity in stealthy navy divers, can increase resilience to oxygen toxicity by 600%;
- Ketone esters can increase the efficacy of HBOT ;
- What is the mechanistic cause of seizures induced by oxygen toxicity?
- Dom typically shows a video of a guy in a chamber, where he has a mask breathing 100% O2, and the guy inside the chamber is breathing hyperbaric air;
- At 2.7 ATA, he gets hit with a seizure, and has a severe tonic clonic seizure;
- And it stops as soon as you remove the O2 mask, and start breathing air, even if it’s at the same barometric pressure;
- If there’s a beneficial component to these seizures, it’s that they quickly stop as soon as you remove the hyperbaric oxygen source; where you go from breathing 100% O2, to hyperbaric air;
  - The high levels of O2 are creating oxidative stress and impeding various metabolic processes in the brain;
  - The brain is becoming hyperexcitable;
  - The neurons are firing so many action potentials, that the cells can’t maintain their membrane potential;
  - you get excitotoxicity, that causes mass firing of the neurons that you see in a seizure;
- The reason for it is you have s-nitrosylation of glutamic acid decarboxylase;
  - You have more glutamate to GABA ratio;
  - GABA is created from glutamate;
  - You have much more excitatory (glutamate) than inhibitory (GABA) neuronal activity.

### Can anything we’ve learned in the super extreme environment offer any insight into normal age and disease progression due to oxidative stress? [38:15]

- The oxidative stimulus is a trigger for adaptive processes that can allow our systems to be more resilient against the same level of oxidative stress;
  - This happens very robustly in a young animal, and is significantly attenuated in an older animal;
  - The adaptive response to the stimulus varies genetically bt the individual…even if you take the same person under different conditions (sleep, food, virus)…their susceptibility.

### What are the applications of hyperbaric oxygen therapy? [40:15]

FDA approved uses:

1. [HBOT for Air or Gas Embolism](https://www.uhms.org/hbo-indications.html).
2. [HBOT for Carbon Monoxide Poisoning](https://www.uhms.org/carbon-monoxide-poisoning/carbon-monoxide-poisoning.html).
3. [HBOT for Gas Gangrene](https://www.uhms.org/3-clostridial-myositis-and-myonecrosis-gas-gangrene.html).
4. [HBOT for Crush injury](https://www.uhms.org/4-crush-injury-compartment-syndrome-and-other-acute-traumatic-ischemias.html).
5. [HBOT for Decompression Sickness](https://www.uhms.org/5-decompression-sickness.html).
6. [HBOT for Arterial Insufficiencies](https://www.uhms.org/resources/hbo-indications.html#).
7. [HBOT for Severe Anemia](https://www.uhms.org/7-severe-anemia.html).
8. [HBOT for Intracranial Abscess](https://www.uhms.org/8-intracranial-abscess.html).
9. [HBOT for Necrotizing soft tissue infections](https://www.uhms.org/9-necrotizing-soft-tissue-infections.html).
10. [HBOT for Osteomyelitis](https://www.uhms.org/10-osteomyelitis-refractory.html).
11. [HBOT for Delayed Radiation Injury](https://www.uhms.org/11-delayed-radiation-injury-soft-tissue-and-bony-necrosis.html).
12. [HBOT for Compromised Skin Grafts and Flaps](https://www.uhms.org/12-compromised-grafts-and-flaps.html).
13. [HBOT for Thermal burn Injury](https://www.uhms.org/13-acute-thermal-burn-injury.html).
14. [HBOT for Idiopathic Sudden Sensorineural Hearing Loss](https://www.uhms.org/14-idiopathic-sudden-sensorineural-hearing-loss-new-approved-on-october-8-2011-by-the-uhms-board-of-directors.html).

Unapproved:

1. HBOT for Stroke ([Ding et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4188156/)).
2. HBOT for Traumatic Brain Injury (TBI) ([Hu et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5110132/)).
3. HBOT for Cardiac Problems ([Bennett et al., 2015](https://www.cochrane.org/CD004818/VASC_does-hyperbaric-oxygen-therapy-improve-outcome-after-heart-attack)).
4. HBOT Treatment for Migraine ([Bennett et al., 2015](https://www.cochrane.org/CD005219/SYMPT_normal-pressure-oxygen-therapy-and-hyperbaric-oxygen-therapy-migraine-and-cluster-headaches)).
5. HBOT Treatment for Autism ([Sakulchit et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5471082/)).

### What about traumatic brain injury (TBI)? [43:00]

Dom wants to study traumatic brain injury treated with HBOT combined with ketone esters.

Dom mentions Dr. Paul Harch: he [helped a young girl (2 years old) regenerate brain tissue after drowning using HBOT](https://www.cnn.com/2017/07/21/health/oxygen-therapy-drowning-brain-damage/index.html).

### What is the resistance to using HBOT with TBI? [44:45]

- They want devices to quantify TBI;
- Rat studies where repeated doses of HBOT worsened the brain injury in a rat;
- whereas a single dose of HBOT immediately after injury decreased infarct size by 30% ([Eve et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5077240/)).

### A word of caution to people considering doing HBOT on themselves [46:15]

- If you’re going to do it, make sure to be in strong nutritional ketosis (NK) because a consequence of HBOT is oxygen toxicity and you can have a seizure;
  - Go for “soft chamber” HBOT at 1.5 ATA;
  - 85% of penetrating TBI have seizures.

### How ketones affect blood glucose, and the Cahill study that launched Dom’s interest in ketosis [48:00]

- George Cahill did a starvation study ([Owen et al., 1969](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC535723/)) that really motivated Dom to research this topic;
  - Study participants fasted 40 days, and after 7 days BOHB level matched the glucose level and stayed that way the rest of the way;
  - Glucose got to 3 mmol and then stayed level (very interesting);
    - tells you that by definition the liver still had glycogen.
- Dom explains how the body is hardwired to maintain glucose levels;
- Glucose can come from the breakdown of muscle (Amino acids), Backbone of triglycerides (a storage form of free fatty acids);
- In Cahill study, insulin levels hit rock bottom at day 7 and stayed there;
- One of the interesting things about the experiment: he was able to give insulin (referenced in [Cahill and Aoki](https://coconutketones.com/wp-content/uploads/2016/10/CahillGF_CerebMetabolism.pdf)), lower glucose levels, but not generate CNS trauma;
- Infused insulin to push glucose to ~ 1 mmol (like less than 20 mg/dl) which is basically FATAL in most cases (2 mmol puts you in a coma normally);
- Peter almost died during self-experiment insulin suppression test at Stanford (see [episode 65 of the Tim Ferriss Show](https://overcast.fm/+Kebuu8VmE)).

### What did we learn about how the brain partitioned fuel in the fasted state during this study? [55:00]

- Brain “eats” what’s in your blood, so in this state, they fueled up with Glucose (30%), BOHB (60%), and acetoacetate (10%);
- It changed our understanding of brain energy metabolism as glucose being the exclusive predominant fuel;
- In the fed state, 100% of their brain’s fuel was glucose;
- Cahill and Richard Veech wrote a number of reviews together;
  - Veech actually studied under Hans Krebs;

![](https://peterattiamd.com/wp-content/uploads/2018/07/krebs-fig-genealogy-lineage-2.png)

**Figure 2. Scientific genealogy.** Adapted from [Krebs, 1967: The Making of a Scientist](https://www.nature.com/articles/2151441a0).

- Cahill shared some unpublished data with Dom about the study;
- Animal work suggested glucose could go EVEN lower;
- You could really transition your metabolism to be fueled by fats and ketones;
  - that was against what we “knew” about metabolic physiology and brain-energy metabolism.

### Can the brain use lactate directly as a fuel without going through the Cori Cycle? [57:30]

- Yes, and Dom thinks lactate is a great fuel;
- Dom’s interest in lactate actually led him to ketones as a fuel.

### When did Dom first get interested in the ketogenic diet (KD) and exogenous ketones? [59:15]

- Dom discovered esters on the DARPA website in 2008 for warfighter performance;
- Dom reached out to Johns Hopkins when he decided to go down the route of a ketogenic diet;
- protocols for the diet were developed there;
- he got a [book written by Eric Kossoff and John Freeman](https://www.amazon.com/Ketogenic-Diets-Treatments-Epilepsy-Disorders/dp/1936303108);
- Dom started eating like this around 2008 when Eric Kossoff [published the modified ketogenic diet](https://www.amazon.com/Ketogenic-Modified-Atkins-Diets-Treatments/dp/1936303949/ref=sr_1_1?s=books&ie=UTF8&qid=1531241138&sr=1-1&keywords=eric+kossoff+modified+ketogenic+diet);
- Dom talks about what he ate when first starting out on the keto diet;
- Dom really wanted to know what it felt like to have a brain that ran on ketones;
- In 2009, started to incorporate MCTs with the modified keto diet, raised ketones higher.

![](https://peterattiamd.com/wp-content/uploads/2018/07/modifiedatkins-1024x1024-300x300.jpg)

**Figure 3. Modified Atkins.** Limits the amount of carbohydrate, encourages fat, and does not limit protein. Carbohydrates are to be accompanied by fat when consumed. Macronutrient Ratio: 0.8:1. [[The Charlie Foundation](https://charliefoundation.org/diet-plans/)]

![](https://peterattiamd.com/wp-content/uploads/2018/07/mct-1024x1024-300x300.jpg)

**Figure 4. Modified MCT.** An individualized and structured diet containing highly ketogenic Medium Chain Triglycerides (MCT), allowing for more carb and protein than classic keto. Macronutrient Ratio: 1.9:1. [[The Charlie Foundation](https://charliefoundation.org/diet-plans/)]

### How we make and use ketones [1:02:15]

- While in starvation, you first burn up your liver glycogen;
- about 24-48 hours later you’re down to about 25-50% of its supply;
- insulin is suppressed and therefore we start mobilizing more fat from fat cells;
- Fat is a superior fuel for muscle and heart cells, in particular;
- Long-chain fatty acids don’t effectively cross the blood brain barrier (BBB);
- Ultimately, BOHB and ketone bodies become available for the BBB, CNS, and peripheral tissues;
- Individuals seem to have a different ratio of BOHB to acetoacetate (AcAc);
- How do AcAc and BOHB enter the [krebs cycle](https://simple.wikipedia.org/wiki/Krebs_cycle) ([youtube](https://www.youtube.com/watch?v=juM2ROSLWfw)), where do we get ATP from them?
  - Depends on cells, each have a number of different pathways and ketolytic enzymes.

##### **‘The Krebs cycle is not as simple as we thought it was, especially as it relates to cancer cells.’**

###

**Figure 5. Ketones and ATP production in the brain.** Image provided by Dom D’Agostino.

### Dom’s experience with MCTs, and their possible advantages [1:08:30]

- Different ketogenic diets explained;
- MCT defined and how they work;
- Caprylic acid (C8) mentioned;
- Why taking MCTs may make the ketogenesis process easier (how MCT turns into ketones quicker);
  - Metabolised quicker and ready for energy use, much less likely to be stored as fat, further enhance ketone levels or even with carbs you can elevate ketones in the blood;
- Taking MCT can be consumed on a high-carb diet and still elevate ketones (see [this post and media](https://chrismasterjohnphd.com/2016/07/28/ketogenesis-isnt-all-about-carbs-and-insulin/) from Chris Masterjohn on this topic).

##### **How high can BOHB get on 2-3 tbsp of MCT?**

- 0.5 to 1 mmol per Dom, with pure C8;
- With C-8 you can get 20-30% higher than typical MCT (mix of C8 and C10 or higher);
- C8 products mentioned:
  - Dave Asprey, [Brain Octane Oil](https://www.bulletproof.com/brain-octane-oil-16-oz);
  - Parrillo Performance makes [CapTri](https://www.parrilloperformance.com/product/captri-mct-oil/).
- Dom almost kills himself with C8 acid;
  - Pro-tip: Don’t buy pure C8 **acid** instead of the triglyceride, it will kill you, Dom accidentally bought pure acid from Sigma, put a bit on his tongue and burned himself;
  - and then realized: wait a minute…

##### **Dom’s experience with powdered MCT**

- Allowed Dom to increase ketones (by [Quest](https://www.questnutrition.com/products/mct-oil-powder)) even higher than oil;
- more tolerable to GI;
- Dom went from 30 ml to 150 ml per day by building up a tolerance;
- Peter is shocked by how much this is;
- Dom had to spread it out over 4 meals and have it with food to avoid disaster pants;
- Dom now does IF so he can’t consume as much MCT bc just doesn’t eat as often.

##### **MCTs can actually cross the BBB, unlike long-chain fatty acids (LCFAs)**

- Dom did studies on rats that showed that when they took out the hippocampus in rats that are eating a high MCT diet, their MCT levels are elevated ([Kesl et al., 2015](https://www.fasebj.org/doi/abs/10.1096/fasebj.29.1_supplement.745.4));
- About 50% of MCTs converted to ketones, maybe 20% MCTs get across the BBB.
- There’s a lot of research on MCT as “functional fats,” fats with drug-like properties;
  - C10 has anti-seizure properties;
  - There are arguments that the effects of the KD with MCT is not due to ketones, but due to the MCTs;
  - Dom thinks there’s a case for this, but believes it’s a combo of the two.
- Dom says for different types of seizures a low-glycemic (as opposed to full keto) can have a positive effect;
- But for severe seizure disorders, you want to go straight to a KD.

![](https://peterattiamd.com/wp-content/uploads/2018/07/lgi-1024x1024-300x300.jpg)

**Figure 6. Low Glycemic Index Treatment (LGIT).** An individualized but less structured diet, it uses exchange lists for planning meal and emphasizes complex carbohydrates. It is not intended to promote ketosis. Macronutrient Ratio: 2:3. [[The Charlie Foundation](https://charliefoundation.org/diet-plans/)]

##### **What about a fully carbed diet and giving them exogenous ketones (EK), does that have an anti-seizure benefit?**

- Dom says those studies have not been done yet, but they are recruiting for a study with people with [Angelman Syndrome](https://en.wikipedia.org/wiki/Angelman_syndrome) where EK is the therapy;
- Anecdotally, there are people using EK for this stuff because they don’t or won’t do a KD;
  - Feedback Dom is getting is it does have an effect;
- And in animal models, Dom sees an effect with EK on top of standard high carb rat chow and it works very well for certain seizures.

### Why do Ketones drive down blood glucose? [1:20:00]

- Dom has seen in his experiments, rats going from 140-150 mg/dL (typical blood glucose level in rats), it will push it down to 40 on the maximal tolerable dose of the ketone ester;
- Glucose actually spikes when you go beyond the maximal tolerable dose.

##### **Steve Phinney and Peter were pondering the question: why is it that ketones drive down the glucose levels? And why does someone in NK, after doing really aggressive exercise (e.g., 500m row TT), the ketones go way down, and the glucose goes way up?**

- We may not have a solid answer, but Dom has some potential explanations:
- An exogenous ketone induced release of insulin;
  - which then feeds back on the liver, which facilitates glucose disposal.
- Insulin sensitivity is increased;
  - The insulin you have available, and the associated signaling is being enhanced in the presence of ketones (a long-standing issue);
    - Richard Veech [did a study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5102124/) where rats were given standard chow but with 20-30% ketone ester;
    - and their baseline insulin levels went down like 50%;
    - simply by the addition of ketones over a week, it decreased baseline levels of insulin.
- Dom looked at this in himself [n=dom]
  - If he gets a significant amount of his kcals from exogenous ketones over several weeks, he notices the same drop in insulin;
  - He did notice that insulin goes up with big doses of ketones, but not nearly as much as protein or carbs;
  - When he consumes the max ketone ester, insulin bumps a little, 1.5-3.0 on insulin;
  - Dom’s baseline insulin level is 1-2 (very low).

### How can we measure our ketone levels? [1:25:45]

- Blood test, at home options, include [Precision Xtra](https://www.amazon.com/Precision-Glucose-Ketone-Monitoring-System/dp/B07BTHSCFD/ref=sr_1_1_sspa/135-3947140-6731003?ie=UTF8&qid=1531422693&sr=8-1-spons&keywords=precision+xtra+blood+ketone+meter&psc=1) and [Keto Mojo](https://www.amazon.com/KETO-MOJO-Glucose-Testing-ketogenic-Carrying/dp/B0789G8KTG/ref=sr_1_1_sspa?s=hpc&ie=UTF8&qid=1531423099&sr=1-1-spons&keywords=keto+mojo&psc=1);
- Urine test (there’s now a urine BOHB test in addition to AcAc), Dom mentions the [Clinitek Status Device](https://www.healthcare.siemens.com/urinalysis-products/urinalysis-systems/clinitek-status-analyzer) takes the [Siemens 10 SG multistix](https://www.healthcare.siemens.com/urinalysis-products/urinalysis-reagents/multistix-10-sg-reagent-strips) and measures 10 things to give you a more quantified number;
- If urine AcAc 40 mg/dl or more, you are likely at BOHB of 1.0 mmol/L+;
  - but typically need 80 mg/dl to be in ketosis ;
  - 15 is light pink, probably not in ketosis.

##### **Does body retain ketones more as you adapt to it (and stop peeing it out)? Does this affect urine results?**

- The more Dom uses urine strips the more he appreciates its usefulness…as long you are not dehydrated it is pretty accurate;
- Dom mentions the [Clinitek Status Device](https://www.healthcare.siemens.com/urinalysis-products/urinalysis-systems/clinitek-status-analyzer) takes the [Siemens 10 SG multistix](https://www.healthcare.siemens.com/urinalysis-products/urinalysis-reagents/multistix-10-sg-reagent-strips) and measures 10 things to give you a more quantified number.

### What Dom learned about HBOT, ketosis, blood glucose, and more, while spending weeks underwater during the NASA Neemo Extreme Missions Operations Trip [1:29:00]

##### **Dom went on the [NASA Neemo Extreme Missions Operations Trip #22](https://www.flickr.com/photos/40054892@N06/sets/72157683015049201) where he lived underwater for weeks**

##### **What did Dom see about his own measurements?**

- Inflammation from the elevated CO2 and also oxidative state;
- Testerone down by 25%;
- Surprisingly, more deep sleep (2 hours) than his normal (1.5 hours) measured with [Oura](https://ouraring.com);
- Water temp made him close to hypothermic, pushing him into a “fat burning machine” where ketones went way up and glucose went way down;
- Lost weight due to a combo of calorie deficit and increased metabolic rate due to the underwater elements.

##### **What surprised Dom the most?**

- Dom thinks undereating led to his weight loss because he underestimated activity, his cortisol increased but was still in the normal range;
- During NEEMO trip #23 Dom will be able to test metabolic numbers on all the participants;
- For #23 they are doing studies on Sleep ([Oura Ring](https://ouraring.com/)), Heart Rate variability ([Polar V800](https://www.polar.com/en/products/pro/V800)), gut microbiome, body comp, stress, and cognitive psych patterns ([NIH Toolbox](https://www.healthmeasures.net/explore-measurement-systems/nih-toolbox) and [Joggle](https://admin.joggleresearch.com/)).

### All things exogenous ketones [1:38:00]

##### **What was the first exogenous ketone ever made?**

- [1,3-butanediol](https://en.wikipedia.org/wiki/1,3-Butanediol) has been around since the 1950s — MIT used it for research as a “space fuel”;
- Sodium BOHB first used clinically for rare metabolic disorders.

### What is the difference between ketone salts and esters? [1:39:15]

- Ionic bonding agents are sodium, potassium, calcium, and magnesium used for bonding in salts;
- How to take salts properly to tolerate them best;
- Spread them out across several meals;
- Peter revisits [the jet-fuel story](https://peterattiamd.com/experience-exogenous-ketones-2/), taste of ketones have gotten better, but why does the ester taste so much worse (even though they are better today) than salts?
  - More ketogenic potentancy compounds seem to taste worse;
- Making an ester with 1,3 butanediol is great because you get more substrate.

### What is the difference between the D (or R) and the L enantiomers? [1:43:30]

- Available ketone esters include [Delta G HVMN](https://deltagketone.com);
- Explaining the R BOHB vs the L BOHB;
- Predominant BOHB in the body is D, when in nutritional ketosis;
- 99% of the ketone supplements are racemic, so they are a mix of the D and the L; ([more on this from HVMN](https://hvmn.com/blog/exogenous-ketones/beta-hydroxybutyrate-or-bhb-all-you-need-to-know)).
- 90% D-BOHB and 10% L-BOHB naturally in us;
  - Racemic bhb is 50/50 D and L.
- Why D only doesn’t have an anti-seizure effect, you also need to elevate AcAc as well;
- Dom started using the ester 1,3-butanediol AcAc diester in his studies because of this;
- They discuss how this ester was what Dom sent Peter (jet fuel) and they discuss how this ester was formed;
- They talk about how great [Patrick Arnold’s](https://tim.blog/2016/03/02/patrick-arnold/) work is on endocrinology and hormones, and how he helped to synthesize the ester compound for Dom;
- Racemic salts and esters are not a health concern.

##### **Are salts or esters “better” physiologically?**

- Dom says as a metabolic fuel, the pure D has advantages;
- R salts could have a stronger anti-inflammatory effect due to the presence of L;
- Dom mentions a *Nature* paper ([Youm et al., 2015](https://www.nature.com/articles/nm.3804)) regarding the NLRP3 inflammasome pathway, and how it was suppressed by BOHB;
- Dom has observed the racemic salts have a glucose lowering effect (but so does pure D, such as the HVMN);
- Does Dom see more than 20-30% (pure D) with the racemic? Dom says yes;
- Dom is consuming D salts that bring him up to levels as high as esters.

### Dom’s KTT: Ketone Tolerance Test [1:56:00]

- Athletes dispose of ketones and use it remarkably well;
- Why are athletes better at disposing of it? Are fat adapted athletes even better?
- Keto adapted athletes clear lactate faster and this might explain why certain athletes don’t feel the lactate burn and can keep pushing;
- [Ryan Flaherty](https://ryanjflaherty.com) mentioned, he and Peter wanted to get an n=1 IRB to do muscle biopsies pre/post exercise;
- Peter was trying to understand how the upregulation of MCT might improve performance and then how ketones might improve this process as well.

### If you, or someone you cared about deeply, is diagnosed with cancer (a cancer in which all standard of care [SOC] therapies have been exhausted), what do you do, pulling out all the stops? [1:59:45]

- Peter suggests to use glioblastoma and metastatic breast cancer as examples;
- Dom has research experience with glioblastoma, one of the worst-case scenarios in terms of 5-year survival, working with Tom Seyfried and colleagues;
  - Tom Seyfried has actually published two papers demonstrating complete remission in a GBM patient and a patient with widespread metastatic triple negative breast cancer (TNBC) using metabolic therapy and modified SOC:
    - [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/);
    - [Management of Glioblastoma Multiforme in a Patient Treated With Ketogenic Metabolic Therapy and Modified Standard of Care: A 24-Month Follow-Up](https://www.frontiersin.org/articles/10.3389/fnut.2018.00020/full).
- Get an FDG-PET to document the (highly glycolytic) cancer;
- For GBM, SOC is not efficacious, and GBM is fatal ([5-year survival rate for someone 55-64 is 5%](https://www.cancer.org/cancer/brain-spinal-cord-tumors-adults/detection-diagnosis-staging/survival-rates.html));
- Dom would default to [Press-Pulse](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Dom co-authored a paper with Tom Seyfried, Joe Maroon, and George Yu: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2)).

##### **Dom recently ([2018](https://www.dropbox.com/s/2ito6deehzore6o/%23poff%20%23dagastino%20%232018%20Targeting%20the%20Warburg%20effect%20for%20cancer%20treatment-%20Ketogenic%20diets%20for%20management%20of%20glioma%20%23ketogenic%20%23caamd.pdf?dl=0)) published a paper discussing how the ketogenic diet targets the Warburg effect, and Hanahan & Weinberg’s Hallmarks of Cancer**

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-1-dagostino-scheck-poff-936x1024.jpg)

**Figure 7. Metabolic regulation of the hallmarks of cancer.** An illustration of the interconnections between tumor metabolism with Hanahan and Weinberg’s Hallmarks of Cancer (Lewis and Abdel-Haleem, 2013). [[Poff et al., 2018](https://www.ncbi.nlm.nih.gov/pubmed/29294371)]

Press-Pulse: “This general concept can be applied to the management of cancer by creating chronic metabolic stresses on tumor cell energy metabolism (**press disturbance**) that are coupled to a series of acute metabolic stressors that restrict glucose and glutamine availability while also stimulating cancer-specific oxidative stress (**pulse disturbances**). The elevation of non-fermentable ketone bodies protect normal cells from energy stress while further enhancing energy stress in tumor cells that lack the metabolic flexibility to use ketones as an efficient energy source. Mitochondrial abnormalities and genetic mutations make tumor cells vulnerable metabolic stress.” [[Seyfried et al., 2017](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2)]

Dom is looking for a glucose ketone index (GKI) of 1 (typically 3 mmol/L of glucose and 3 mmol/L BOHB), ideally < 1, approaching 0.5 (simply look at glucose and ketones in mmol/L: glucose/BOHB=GKI). Generally speaking (and within reasonable limits), the lower the glucose, and the higher the BOHB, the better.

![](https://peterattiamd.com/wp-content/uploads/2018/07/gki-fig-1024x615.png)

**Figure 8. GKI: The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer.** [[Meidenbauer et al., 2015](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2)]

- To get to a GKI of 0.5 almost assuredly requires help beyond a ketogenic diet and fasting: Dom looks to a supplemented ketogenic intermittent fasting (Peter once did [“IFIK” [intermittent fasting, intermittent ketosis]](https://peterattiamd.com/what-i-actually-eat-part-ii-ifik-2/) as an n=1 experiment) to lower glucose and raise ketones;
- Probably a form of time-restricted feeding (TRF), eating in a 6 hour window, and within the fasting window, you could consume kcals in the form of exogenous ketones;
- and that would further lower glucose and elevate ketones;
- When you get to this 0.5 GKI, you are limiting fermentable fuels (particularly glucose) to the cancer cells, and also suppressing insulin (and IGF-1) tremendously to get there;
- Dom says you only need exogenous ketones during fasted state if you’re having trouble getting to a 0.5 GKI;
- And you can also consume them during the feeding window.

##### **The press protocol is all about a continuous and persistent lowering of glucose and glutamine (i.e., fermentable fuels)**

This not only includes diet, but can also include:

- stress management;
- Yoga;
- meditation;
- adequate sleep.

##### **Metformin: a low-dose (500-2000 mg/d) metformin to activate AMPK, lower insulin, lower glucose, maybe increase ketones a little, may be helpful**

Once that is achieved, you think about the different modalities for the Pulse (i.e., stimulating cancer-specific oxidative stress) protocol.

SOC therapies that have failed in the past may actually be more effective once the patient has reached a GKI of 0.5-1.0 (i.e., radiation, chemotherapy, and immune-based therapies).

Peter recaps the four pillars of cancer treatment today:

1. Surgical.
2. Radiation.
3. Chemotherapy.
4. Immunotherapy.

##### **Why don’t we have a metabolic oncologist?**

- Many of the genetic researchers are now turning to how the metabolism influences genetics (i.e., epigenetics);
- Adrienne Scheck showed in a mouse model study of glioblastoma, using radiation while being in ketosis made radiation therapy more effective, it cured GBM in that mouse model ([Abdelwahab et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3341352/)).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-3-poff-dagostino-1024x562.png)

**Figure 9. Ketogenic diet enhances the efficacy of radiotherapy in a mouse glioma model.** Radiation therapy and ketogenic diet prolonged survival as monotherapies, but complete and permanent remission were observed in 82% of mice when the two therapies were delivered concomitantly. This study suggests that ketosis may provide an effective adjuvant to standard of care therapy in glioma. Reprinted with permission from Abdelwahab, et al. PLOS One, 2012 [60]. [[Poff et al., 2018](https://www.dropbox.com/s/2ito6deehzore6o/%23poff%20%23dagastino%20%232018%20Targeting%20the%20Warburg%20effect%20for%20cancer%20treatment-%20Ketogenic%20diets%20for%20management%20of%20glioma%20%23ketogenic%20%23caamd.pdf?dl=0)]

##### **What’s in the Pulse protocol?**

- HBOT;
- You have to be very careful with GBM due to seizure risk;
- Therefore, start low, about 1.5 ATA and work up gradually;
- 3 times per week, and work up to 2.5 ATA ;
- Ultimately this will reverse tumor hypoxia;
- HBOT increased tissue oxygenation by saturating the plasma (a very important point since hemoglobin is already essentially saturated: think about a pulse oximeter with a saturation around 98% when you’re sitting comfortably);
- This is the key to the increase in pressure in HBOT: it’s needed to drive the O2 into the plasma;
- Tumors have an erratic vasculature;
- If the O2 is in the plasma, it can get into the nooks and crannies and reverse tumor hypoxia;
- And tumor hypoxia is driving HIF-1a, VEGF, and causing “oncogenic” activation;
- There is a dual effect:
  - You are silencing the “oncogenes”;
  - By hyperoxygenating the tumor, which has damaged mitochondria (tumor hypoxia further damages mitochondria), it ramps up ROS (superanion in particular);
- Which through Fenton chemistry, when you have a whole bunch of iron or heme being broken down in the tumor (you have a whole lotta iron driving the Fenton reaction), created hydroxyl radicals, and that causes a massive oxidative stress, specifically to the tumor;
- You’re delivering a massive oxidative stress to the tumor while it’s relatively nontoxic to the healthy cells that have normal metabolism;
- You can trigger apoptosis (i.e., cell suicide) and necrosis (i.e., cell death) in the tumor cells.

##### **Basically, HBOT at the maximum tolerable dose, 3 times per week**

##### **You can further enhance the oxidative stress on the tumor with an IV of Vitamin C (you cannot achieve this orally)**

- Vitamin C is both an antioxidant (you don’t want to use antioxidants in cancer therapy), and a prooxidant at higher concentrations: it can create oxidative stress, driving the Fenton reaction;
- It’s also a glucose antagonist — it can drop glucose levels;
- Remember, the patient is in therapeutic ketosis, which allows for lower levels of glucose without adverse effects (see Cahill);
- Aside: you get a false-positive on the glucose meter (at least the Abbott Precision Xtra) when taking supraphysiological doses of vitamin C (the meter’s assay is also sensitive to pH, and ascorbic acid causes a redox shift, it’s a powerful reducing agent);
- n=Dom: he took a big hit of vitamin C to see what would happen.

##### **Antioxidants can actually blunt the effects of cancer therapies and should be avoided**

- Because, many therapies, like radiation, work through enhancing oxidative stress:
  - 20% of the tumor-killing effects of radiation is through breaks in DNA, but;
  - 80% of the tumor-killing effect is through is by the generation of ROS;
- You don’t want to do a glutathione (GSH) push, for example, after vitamin C;
- None of the evidence suggests (in animals or humans) are supportive of the use of antioxidants;
- You don’t want tumor cells to get antioxidants.

##### **Pulse modalities:**

- HBOT;
- IV vitamin C;
- Cancer-specific glycolytic inhibitors such as
  - [2-DG](https://en.wikipedia.org/wiki/2-Deoxy-D-glucose) (25 mg/kg safe dose for humans) it inhibits a glycolytic pathway;
  - [3-BP;](https://www.sciencedirect.com/science/article/pii/S1574789108000045)
  - [Lonidamine;](https://en.wikipedia.org/wiki/Lonidamine)
- These are very powerful drugs: probably a 2 weeks on / 2 weeks off strategy;
- There are also glutamine inhibitors like 6-Diazo-5-oxo-L-norleucine, that can inhibit glutamine, but researchers are still working out the toxicity, dosage, timing, and frequency;
  - a drug Dichloroacetate (DCA) inhibits PDH complex (normally used for lactic acidosis).

##### **‘2-deoxyglucose (2-DG): in the context of epilepsy, 2-DG is almost like a ketogenic diet in a drug.’**

- 25 mg/kg safe dose for epileptic patients, so may be safe and effective for cancer patients;
- There’s also synergy with the Press protocol;
- 2-DG will inhibit the glycolytic pathway that drives the Pentose Phosphate Pathway (PPP);
- And that PPP is responsible for enhancing the endogenous antioxidant capacity of the cells;
- Therefore, 2-DG makes the tumor cells even more vulnerable to oxidative stress.

##### **Dichloroacetate (DCA): inhibits the PDH complex**

- Normally used for lactic acidosis;
- Note that metformin, once you start escalating the dose, its effects are primarily through the liver, inhibiting gluconeogenesis, it’s a mitochondrial toxin;
- It inhibits Complex I of the mitochondria;
- Dom published a paper, it increases ROS production from Complex I
- Triggering what the cell experiences as an energetic crisis, which activates AMPK;
- Creates a scenario where you’re putting persistent metabolic stress on the tumor cells;
- You’re adding overlapping, but independent, mechanisms at putting oxidative stress on the tumor.

### Summary of Press-Pulse treatments

##### **Press:**

- Ketogenic diet (relatively lower kcal);
- Stress reduction (can include exercise, yoga, meditation, music, etc.);
  - Target is to 1:1 or lower GKI;
- Metformin.

##### **Pulse:**

- Glucose inhibition;
- Glutamine inhibition;
- HBOT.

![](https://peterattiamd.com/wp-content/uploads/2018/07/null-6.png)

**Figure 10. Illustration of the Press-Pulse Therapeutic Strategy for Cancer Management.** The “Press-Pulse” therapeutic strategy considers cancer as a singular systemic disease regardless of the specific tissue or organ system containing invasive or metastatic tumor cells. This strategy is designed to target the glucose and glutamine dependency of tumor cells, while enhancing the metabolic efficiency in normal cells. Press therapies are designed to reduce systemic glucose availability while elevating blood levels of ketone bodies, which tumor cells cannot effectively use for energy generation. This approach pits the metabolic demands of normal cells against those of the mutated tumor cells, which are less capable than normal cells in adapting to metabolic stress from nutrient deprivation. Ketone body supplements could further reduce glucose levels while enhancing the respiratory energy metabolism in normal cells. Stress management techniques together with exercise could further stress tumor cell metabolism while improving general health. The press therapies would be designed to work synergistically with acute pulse therapies to further target glucose and glutamine metabolism. HBOT will work together with the press therapies to selectively increase oxidative stress in tumor cells. The spacing between the various pulse therapies is designed to stress tumor cell metabolism while minimizing toxicity to normal body cells. This therapeutic strategy will target the fermentation metabolism common to most tumor cells, thus gradually degrading tumor burden. The progressive color change in the Vitruvian man drawing from red (diseased with darker red spots indicative of metastatic lesions), to yellow (reduced metastasis), to green (resolution) symbolizes a gradual metabolic management and resolution of cancer. The pill symbol is indicative of glycolysis targeting that could be delivered orally. The Rx symbol is indicative of glutamine targeting that could be delivered intravenously. Pulse therapies would terminate with evidence of management or resolution while press therapies could continue under modification or adjustment (arrow). Optimization of dosing, timing, and scheduling of the press-pulse therapeutic strategy will facilitate the eradication of tumor cells with minimal patient toxicity. This therapeutic strategy can be used as a framework for the design of clinical trials for the majority of cancers. HBOT, hyperbaric oxygen therapy; KD-R, calorie restricted ketogenic diet. [[Seyfried et al., 2017](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2)]

##### **Are there doctors doing this stuff?**

- There are probably physicians out there doing this, but they haven’t made it public;
- They are having success doing about 25% of what Dom just laid out;
- Physicians have used metabolic therapy in Egypt and Turkey, demonstrating its effectiveness on a [patient with GBM](https://www.frontiersin.org/articles/10.3389/fnut.2018.00020/full) and [metastatic TNBC](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/), respectively.

##### **‘Radiation therapy is like going into your body with a flamethrower, there’s a lot of collateral damage.’**

##### **‘HBOT naturally elevates the precursor for oxygen free radicals, and the cancer cells selectively produce more oxygen free radicals, so it’s a gentle approach.’**

Instead of going in and thinking we’re just going to eradicate the tumor, it’s more appropriate to give a gentle stress to the tumor.

##### **When patients go into the therapy Dom’s describing, they’re going to come out of it stronger than they were going into it.**

##### **‘When you go in for chemo and radiation, you are an inflammatory mess after those therapies, you’re metabolically deranged, you’re insulin resistant, you have “chemo-brain,” your immune system getting depressed sets you up for more cancer.’**

![](https://peterattiamd.com/wp-content/uploads/2018/07/chemo-radiation-seyfried-fig.png)

**Figure 11. How the standard of care can provoke glioblastoma growth and recurrence**. RAC=reactive astrocytes. TAM=tumour-associated macrophages. Gln=glutamine. Glu=glutamate. [[Seyfried et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/20634134)]

##### **Another tactic is you can also use acute insulin potentiation: give someone some insulin to drive glucose down further, and then deliver agents where you really restrict the fermentable fuels.**

- Facilitates glucose uptake in the skeletal muscle and making it less available for the tumor;
- You’ll also likely sensitize the tumor cells even further to the other modalities.

### Dom’s Cahill-inspired 7-day fast [2:27:15]

Dom did a 7-day fast a few years ago:

- He got his glucose levels down really low and got to a GKI of 1:1;
- 3 mmol/L glucose and 4-5 mmol/L BOHB;
- Inspired by the Cahill study, he used various pharmacological strategies to lower glucose further;
- Dom brought his glucose down to where it was unmeasurable (< 20 I think on the Xtra);
- This motivated Dom more to focus on this area of research as his life’s research;
- Ketones are an alternative energy source that can be a game changer;
- How Dom’s 7 day fast motivated him to basically focus on ketones are an alternative energy source which can be game changers for metabolic therapies.
- [Glucose transporter type 1 deficiency syndrome](https://en.wikipedia.org/wiki/Glut1_deficiency), people with GLUT1-DS don’t get cancer;
  - Dom talked to the doctors, and they’ve never come across someone with a GLUT1-DS and has cancer.
- Old school science, self-experimenting, looking at unnatural or extreme environments;
- Dom deadlifted 500 for 10 (his 5RM was about 555 for 10 at the time), and 1 rep at 585 lbs after fasting for 7 days;
  - Validation that in a keto-adapted state your body is very resilient.
- Military application: if fat-adapted, they can stay physically and cognitively sharp, even in a bad situation, with limited food availability;
- You can maintain size and strength without eating 6 meals a day, etc., you don’t have to eat very much to maintain muscle and strength once fat-adapted.

### What does Dom believe today to be true that 5 years ago he did not believe to be true? [2:32:10]

This idea that you could develop, and even engineer, nutrition, to have powerful effects on gene transcription and epigenetic regulation, is something Dom would have never predicted.

- Five years ago Don was more singularly immersed in this idea of ketones as an alternative energy source;
- But then he came to realized BOHB is a powerful endogenous metabolite that is also a signaling molecule through its HDAC activity (it’s a class 1 histone deacetylase inhibitor);
- more recently he’s been working with an organization ([All Things Kabuki](https://www.allthingskabuki.org)) involved with a rare disease a gene defect in the KMT2D (an acetylase enzyme).

In a mouse model of Kabuki, two things work:

1. HDAC inhibitors like AR42 restores neurons;
2. nutritional ketosis, which functions as an HDAC inhibitor.

BOHB (and other metabolites) are epigenetic drivers:

- Here’s an endogenous metabolite that can epigenetically control gene transcription;
- An epigenetic driver; and probably other metabolites;
- The mitochondria are the ones calling the shots, not the nucleus, health of mitochondria is a tumor suppressor, by preserving genome stability.

##### **‘Mitochondrial health and mitochondrial vitality would be the ultimate tumor suppressor.’**

![](https://peterattiamd.com/wp-content/uploads/2018/07/hallmarks-cancer-warburg-mitochondria.png)

**Figure 12. Linking the hallmarks of cancer to impaired energy metabolism.** SLP and OxPhos represent substrate level phosphorylation and oxidative phosphorylation, respectively. The progressive damage to mitochondria during carcinogenesis is illustrated with a change in shape. [[Seyfried and Shelton, 2010](https://www.ncbi.nlm.nih.gov/pubmed/20181022)]

You can take a germline acquired mutation, and silence it with an epigenetic overlay, with something like BOHB and ketones.

##### **‘Bioenergetic efficiency is going to preserve genome stability.’**

### Where people can go to follow Dom’s work [2:36:45]

- Dom’s lab is sponsoring the 2019 [Metabolic Health Summit](https://metabolichealthsummit.com/), Jan 30-Feb 3 in Long Beach, CA;
- Dom helped a friend with cancer, who was part of a trial in which she was the only survivor, and has been on a ketogenic diet for six years;
- Lew Cantley and his colleagues just [published a paper](https://www.nature.com/articles/s41586-018-0343-4) related to the potential mechanisms;
- Dom also mentioned after the recording that he gets multiple inquiries daily about LDL and he now directs people to [Peter’s podcast with Ron Krauss](https://peterattiamd.com/ronkrauss/);
- He also pointed out [this recent study](https://www.ncbi.nlm.nih.gov/pubmed/29712560) on a ketogenic diet and cardiovascular disease risk by Jeff Volek, Steve Phinney, and colleagues.

# §

§

## Selected Links / Related Material

**Peter’s talk at the IHMC in 2013**: [My Quantified Self, Part I](https://peterattiamd.com/my-quantified-self-part-i/) | Peter Attia (peterattiamd.com) [5:30]

**Dom’s talk at the IHMC in 2014**: [Dominic D’Agostino: Metabolic Therapies: Therapeutic Implications and Practical Application](https://www.youtube.com/watch?v=gONeCxtyH18) | IHMC (youtube.com) [5:30]

**Reversing tumor hypoxia in tumor cells with HBOT**: [The Ketogenic Diet and Hyperbaric Oxygen Therapy Prolong Survival in Mice with Systemic Metastatic Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3673985/) (Poff et al., 2013) [15:50]

**Navy SEAL ketone ester research**: [Deep Dive: ONR-Supported Research Combats Oxygen Toxicity in Navy Divers](https://www.onr.navy.mil/en/Media-Center/Press-Releases/2015/Oxygen-Toxicity-Navy-Divers) | Warren Duffle, [Office of Naval Research](https://www.onr.navy.mil) [16:00]

**Example of a CNS oxygen toxicity event**: [US Navy CNS oxygen toxicity hit](https://www.youtube.com/watch?v=z7Hi0HO24Vk) | (youtube.com)

**Ketone bodies anti-seizure effects**: [Do ketone bodies mediate the anti-seizure effects of the ketogenic diet?](https://www.ncbi.nlm.nih.gov/pubmed/29325899) (Simeone et al., 2018)

**Study showing cancer cells dying in the presence of ketones**: [Ketone bodies inhibit the viability of human neuroblastoma cells](https://www.ncbi.nlm.nih.gov/pubmed/19159745) (Skinner et al., 2009) [24:30]

**Watson call for more metabolism research in cancer**: [To Fight Cancer, Know the Enemy](https://www.nytimes.com/2009/08/06/opinion/06watson.html) | James Watson (nytimes.com) [25:00]

**Warburg controversy**: [An Old Idea, Revived: Starve Cancer to Death](https://www.nytimes.com/2016/05/15/magazine/warburg-effect-an-old-idea-revived-starve-cancer-to-death.html) | Sam Apple (nytimes.com) [25:00]

**Warburg controversy**: [EXCLUSIVE: Unpublished Material from NYT Magazine Story on Cancer Metabolism](https://tim.blog/2016/06/06/exclusive-unpublished-material-from-nyt-magazine-story-on-cancer/) | Tim Ferriss (tim.blog) [25:00]

**Book discussing the Warburg controversy**: [Tripping Over the Truth](https://www.amazon.com/Tripping-over-Truth-Overturning-Entrenched/dp/1603587292/ref=sr_1_1?ie=UTF8&qid=1531513819&sr=8-1&keywords=tripping+over+the+truth+by+travis+christofferson) by Travis Christofferson [25:00]

**Book discussing the Warburg controversy**: [Cancer as a Metabolic Disease](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920/ref=pd_sim_14_3?_encoding=UTF8&pd_rd_i=0470584920&pd_rd_r=90f3d9c6-86db-11e8-ad3a-631c770a9f40&pd_rd_w=u76CX&pd_rd_wg=CHMLW&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=7967298517161621930&pf_rd_r=13NHW1020TB3Y10Y187H&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=13NHW1020TB3Y10Y187H) by Thomas Seyfried [25:00]

**Alternative view of the Warburg effect**: [Understanding the Warburg Effect: The Metabolic Requirements of Cell Proliferation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) (Vander Heiden et al., 2009) [25:30]

**The Warburg effect**: [On the origin of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/13298683) (Warburg, 1956) [27:00]

**Press Pulse cancer management**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Seyfried et al., 2017) [27:00; 2:03:00]

**Glutaminolysis becoming a focus in cancer research**: [Glutaminolysis: A Hallmark of Cancer Metabolism](https://www.ncbi.nlm.nih.gov/pubmed/28301735) (Yang et al., 2017) [27:00]

**Cancer researchers looking at targeting glutamine**: [Glutamine targeting inhibits systemic metastasis in the VM-M3 murine tumor model](https://www.ncbi.nlm.nih.gov/pubmed/20473919/) (Shelton et al., 2010) [27:00]

**Dom’s review of HBOT**: [Hyperbaric Environment: Oxygen and Cellular Damage versus Protection](https://onlinelibrary.wiley.com/doi/abs/10.1002/cphy.c150032) (Poff et al., 2016) [40:00]

**HBOT for stroke**: [Hyperbaric Oxygen Therapy in Acute Ischemic Stroke: A Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4188156/) (Ding et al., 2014) [40:15]

**HBOT for TBI**: [Hyperbaric oxygen therapy for traumatic brain injury: bench-to-bedside](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5110132/) (Hu et al., 2016) [40:15]

**HBOT for cardiac problems**: [Does hyperbaric oxygen therapy improve outcome after heart attack?](https://www.cochrane.org/CD004818/VASC_does-hyperbaric-oxygen-therapy-improve-outcome-after-heart-attack) (Bennett et al., 2015) [40:15]

**HBOT for treatment of migraines**: [Normal pressure oxygen therapy and hyperbaric oxygen therapy for migraine and cluster headaches](https://www.cochrane.org/CD005219/SYMPT_normal-pressure-oxygen-therapy-and-hyperbaric-oxygen-therapy-migraine-and-cluster-headaches) (Bennett et al., 2015) [40:15]

**HBOT for treatment of autism**: [Hyperbaric oxygen therapy for children with autism spectrum disorder](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5471082/) (Sakulchit et al., 2017) [40:15]

**Dr. Paul Harch treats drowned child with HBOT**: [Oxygen therapy brings ‘remarkable’ turnaround for toddler who fell in pool](https://www.cnn.com/2017/07/21/health/oxygen-therapy-drowning-brain-damage/index.html) | Susan Scutti ([cnn.com](https://www.cnn.com/)) [44:00]

**HBOT and TBI, mouse study**: [Hyperbaric oxygen therapy as a potential treatment for post-traumatic stress disorder associated with traumatic brain injury](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5077240/) (Eve et al., 2016) [46:00]

**Cahill’s starvation study**: [Liver and kidney metabolism during prolonged starvation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC535723/) (Owen et al., 1969) [48:00]

**Cahill’s insulin infusion, noted in**: [Chapter 26 of Cerebral Metabolism and Neural Function: Alternate Fuel Utilization by Brain](https://coconutketones.com/wp-content/uploads/2016/10/CahillGF_CerebMetabolism.pdf) (Cahill and Aoki, 1980) [48:00]

**Insulin infusion experiment**: Metabolic effects of insulin, glucagon, and glucose in man: Clinical application (Aoki and Cahill, In *Endocrinology*, edited by DeGroot et al., p. 1843, New York: Grune and Stratten, 1979) [48:00]

**Near-death for n=Peter, insulin suppression test**: [Ep 65: Supplements, Blood Tests, and Near-Death Experiences (Dr. Peter Attia)](https://overcast.fm/+Kebuu8VmE) | Tim Ferriss Show, 2015 (overcast.fm) [48:00]

**Veech paper on ketones, mitochondria, and ATP production in the brain (this paper has been a guide for Dom and his team’s studies)**: [Insulin, ketone bodies, and mitochondrial energy transduction](https://www.ncbi.nlm.nih.gov/pubmed/7768357) (Sato et al., 1995) [55:00]

**Scientific genealogy: From Kekule to Warburg to Krebs to Veech**: [The Making of a Scientist](https://www.nature.com/articles/2151441a0) (Krebs, 1967) [55:00]

**Eric Kossoff’s (and colleagues) book on ketogenic diets**: [Ketogenic Diets: Treatments for Epilepsy and Other Disorders](https://www.amazon.com/Ketogenic-Diets-Treatments-Epilepsy-Disorders/dp/1936303108) by Eric Kossoff et al., 2011 (5th ed.) [59:00]

**Eric Kossoff’s (and colleagues) book on the modified Atkins diet**: [The Ketogenic and Modified Atkins Diets: Treatments for Epilepsy and Other Disorders](https://www.amazon.com/Ketogenic-Modified-Atkins-Diets-Treatments/dp/1936303949/ref=sr_1_1?s=books&ie=UTF8&qid=1531241138&sr=1-1&keywords=eric+kossoff+modified+ketogenic+diet) by Eric Kossoff et al., 2016 (6th ed.)[59:00]

**Ketogenesis on a high-carb diet**: [Mastering Nutrition Episode 22: Ketogenesis Isn’t All About Carbs and Insulin](https://chrismasterjohnphd.com/2016/07/28/ketogenesis-isnt-all-about-carbs-and-insulin/) | Chris Masterjohn (chrismasterjohnphd.com) [1:08:30]

**Blood glucose lowering effect of ketones**: [Effects of exogenous ketone supplementation on blood ketone, glucose, triglyceride, and lipoprotein levels in Sprague–Dawley rats](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-016-0069-y) (Kesl et al., 2016) [1:10:00]

**Behavioral effects of ketones**: [Exogenous Ketone Supplements Reduce Anxiety-Related Behavior in Sprague-Dawley and Wistar Albino Glaxo/Rijswijk Rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5138218/) (Ari et al., 2016) [1:10:00]

**MCTs elevated in rats**: [Effect of Sustaining Dietary Ketosis on the Hippocampal and Serum Metabolome of Sprague-Dawley Rats](https://www.fasebj.org/doi/abs/10.1096/fasebj.29.1_supplement.745.4) (Kesl et al., 2015) [1:10:00]

**Elizabeth Thiele on a low GI diet**: [Elizabeth Thiele – Low Glycemic Index Treatment (LGIT)](https://www.youtube.com/watch?v=BXOtTttYzFw) | The Charlie Foundation (youtube.com) [1:16:45]

**Dom’s thoughts on ketones for performance**: [Fueling Performance: Ketones Enter the Mix](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(16)30438-7) | (Egan and D’Agostino, 2016) [1:20:00]

**Insulin sensitivity increase in rats given ketones**: [Novel ketone diet enhances physical and cognitive performance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5102124/) (Murray et al., 2016) [1:23:30]

**Dom’s efforts to move nutritional ketosis to space**: [NASA NEEMO 22: USF Health researcher joins NASA deep-sea mission](https://hscweb3.hsc.usf.edu/blog/2017/06/08/usf-researcher-joins-nasa-deep-sea-mission/) | Tina Meketa (health.usf.edu) [1:29:00]

**Peter’s jet fuel story**: [My experience with exogenous ketones](https://peterattiamd.com/experience-exogenous-ketones-2/) | Peter Attia (peterattiamd.com) [1:39:15]

**Patrick Arnold on Tim Ferriss podcast**: [The World’s Most Famous Performance-Enhancement Chemist](https://tim.blog/2016/03/02/patrick-arnold/) | The Tim Ferriss Show (tim.blog) [1:49:15]

**Ketone suppresses inflammation signaling, study that used Dom’s ester**: [The ketone metabolite β-hydroxybutyrate blocks NLRP3 inflammasome–mediated inflammatory disease](https://www.nature.com/articles/nm.3804) (Youm et al., 2015) [1:54:15]

**Dom’s blog**: [Keto Nutrition](https://www.ketonutrition.org/blog/) (Dom: “planning a post on the ‘ketone tolerance test’ soon!”) [1:56:00]

**Keto diet, Warburg Effect and Cancer**: [Targeting the Warburg effect for cancer treatment: Ketogenic diets for management of glioma](https://www.sciencedirect.com/science/article/pii/S1044579X17301244?via%3Dihub) (Poff et al., 2017) [1:59:45]

**Efficacy of metabolic therapy on GBM**: [Management of Glioblastoma Multiforme in a Patient Treated With Ketogenic Metabolic Therapy and Modified Standard of Care: A 24-Month Follow-Up](https://www.frontiersin.org/articles/10.3389/fnut.2018.00020/full) (Elsakka et al., 2018) [1:59:45]

**Efficacy of metabolic therapy on stage IV TNBC**: [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/) (Iyikesici et al., 2017) [1:59:45]

**The glucose ketone index (GKI)**: [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2) (Meidenbauer et al., 2015)

**Targeting the Warburg effect**: [Targeting the Warburg effect for cancer treatment: Ketogenic diets for management of glioma](https://www.ncbi.nlm.nih.gov/pubmed/29294371) (Poff et al., 2018)

**Nutritional ketosis improves efficacy of cancer radiation**: [The Ketogenic Diet Is an Effective Adjuvant to Radiation Therapy for the Treatment of Malignant Glioma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3341352/) (Abdelwahab et al., 2012) [2:10:00]

**Potential consequences of chemo and radiation in GBM**: [Does the existing standard of care increase glioblastoma energy metabolism?](https://www.ncbi.nlm.nih.gov/pubmed/20634134) (Seyfried et al., 2010) [2:20:00]

**Ketones rescue Kabuki Syndrome**: [A ketogenic diet rescues hippocampal memory defects in a mouse model of Kabuki syndrome](https://www.pnas.org/content/114/1/125) (Benjamin et al., 2017) [2:33:15]

**Mitochondria as a tumor suppressor**: [Cancer as a metabolic disease](https://www.ncbi.nlm.nih.gov/pubmed/20181022) (Seyfried and Shelton, 2010) [2:36:00]

**More information about Dom’s n=1 experiments**: [Keto Nutrition](https://www.ketonutrition.org/) | Dom D’Agostino (ketonutrition.org) [2:37:30]

**Dom’s lab, along with Epigenix Foundation is sponsoring a conference**: [Metabolic Health Summit](https://metabolichealthsummit.com/), 2019 | (metabolichealthsummit.com) [2:38:30]

**Recent Lew Cantley *Nature* paper**: [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.nature.com/articles/s41586-018-0343-4) (Hopkins et al., 2018) [2:36:45]

**Peter’s podcast with Ron Kraus**s: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia (peterattiamd.com)

**Ketogenic diet and cardiovascular disease risk**: [Cardiovascular disease risk factor responses to a type 2 diabetes care model including nutritional ketosis induced by sustained carbohydrate restriction at 1 year: an open label, non-randomized, controlled study](https://www.ncbi.nlm.nih.gov/pubmed/29712560) (Bhanpuri et al., 2018)

# §

§

## People Mentioned

- [Ken Ford](https://www.ihmc.us/groups/kford/) (Peter met Dom through Ken) [6:00 ]
- [Robert Skinner](https://www.researchgate.net/profile/Robert_Skinner) (ketones and cancer) [24:30]
- [Tom Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) (Press-Pulse cancer therapy, Book: [Cancer as a Metabolic Disease](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920)) [25:15]
- [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) (ketosis, Warburg effect) [25:15]
- [Lewis Cantley](https://cantleylab.weill.cornell.edu/labteam) (ketones and seizures, Warburg) [25:15]
- [Craig Thompson](https://www.mskcc.org/research-areas/labs/craig-thompson) (cancer, Warburg) [25:15]
- [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) (Warburg Effect, Nobel Prize winner) [28:45]
- [Travis Christofferson](https://www.reconnectedhuman.com/podcast/travischristofferson) (Book: [Tripping Over the Truth](https://www.amazon.com/Tripping-over-Truth-Overturning-Entrenched/dp/1603587292/ref=sr_1_1?ie=UTF8&qid=1531516554&sr=8-1&keywords=tripping+over+the+truth+book)) [29:30]
- [Michael Bishop](https://profiles.ucsf.edu/j.michael.bishop) (Nobel prize winner for cancer research) [31:00]
- [Steve Rosenberg](https://ccr.cancer.gov/Surgery-Branch/steven-a-rosenberg) (immunotherapies for cancer, Peter’s mentor, Book: [The Transformed Cell](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491/ref=sr_1_1?s=books&ie=UTF8&qid=1531653342&sr=1-1&keywords=transformed+cell)) [31:00]
- [David Sabatini](https://sabatinilab.wi.mit.edu/membersDS.html#p7TPMc1_1) (mTOR, rapamycin) [31:00]
- [Matthew Pollak](https://www.mcgill.ca/translational-research-cancer/researcher-biographies/pollak) (developing novel cancer strategies) [31:00]
- [Paul Harch](https://www.hbot.com/about) (HBOT) [44:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (study motivated Dom’s research) [48:15]
- [Richard Veech](https://irp.nih.gov/pi/richard-veech) (ketosis expert) [56:00]
- [Hans Krebs](https://en.wikipedia.org/wiki/Hans_Adolf_Krebs) (famous for the [Krebs Cycle](https://simple.wikipedia.org/wiki/Krebs_cycle)) [56:15]
- [Eric Kossoff](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0012386/eric-kossoff) (co-authored keto diet book that Dom used) [1:00:15]
- [John Freeman](https://en.wikipedia.org/wiki/John_M._Freeman) (co-authored keto diet book that Dom used) [1:00:15]
- [Dave Asprey](https://blog.bulletproof.com/about-dave-asprey/) (developed [C-8 product](https://www.bulletproof.com/brain-octane-oil-16-oz)) [1:11:30]
- [Elizabeth Thiele](https://www.ceconcepts.com/search/faculty/35) (ketosis and seizures) [1:16:45]
- [Stephen Phinney](https://www.virtahealth.com/team) (ketosis expert) [1:21:00]
- [Henri Brunengraber](https://case.edu/medicine/nutrition/about-us/faculty/henri-brunengraber) (helped Dom synthesize ketone esters) [1:48:30]
- [Patrick Arnold](https://patrickarnoldblog.com/about/) (famous chemist, helps Dom) [1:49:15]
- [Tim Ferriss](https://tim.blog/about/) (great [interview](https://tim.blog/2016/03/02/patrick-arnold/) with Patrick Arnold) [1:50:00]
- [Ryan Flaherty](https://ryanjflaherty.com) (exercise expert, Peter’s friend) [1:59:00]
- [Adrienne Scheck](https://sols.asu.edu/adrienne-scheck) (ketosis and radiation therapy) [2:10:15]
- [Eric Verdin](https://www.buckinstitute.org/content/eric-verdin-md-president-and-ceo) (ketones as epigenetic drivers) [2:36:30]

§

![](https://peterattiamd.com/wp-content/uploads/2018/07/dom-profile-1-e1531649711516-300x300.jpg)

##### Dom D'Agostino, Ph.D.

Dominic D’Agostino, Ph.D., has maintained involvement in a vast array of professional, academic and personal endeavors. As an Associate Professor with tenure at the University of South Florida, Dom teaches students of the Morsani College of Medicine and the Department of Molecular Pharmacology and Physiology, with a focus on such topics as neuropharmacology, medical biochemistry, physiology, neuroscience, and neuropharmacology. He is also a Research Scientist at the Institute for Human and Machine Cognition (IHMC) to assist with their efforts towards optimizing the safety, health and resilience of the warfighter and astronaut.

His laboratory develops and tests metabolic-based strategies for targeting CNS oxygen toxicity (seizures), epilepsy, neurodegenerative diseases, and cancer. To investigate the mechanism of these pathologies he uses a variety of in vivo and in vitro techniques, including radio-telemetry (EEG, EMG), electrophysiology, fluorescence microscopy, confocal microscopy, atomic force microscopy (AFM), biochemical assays and in vivo bioluminescence imaging. His laboratory has adapted many of these techniques for use inside environmental chambers, which allows them to manipulate oxygen concentrations (from hypoxia to hyperbaric oxygen). His current project is to identify cellular mechanisms of seizures from CNS oxygen toxicity and to develop mitigation strategies against it. His efforts have focused specifically on measuring brain EEG, neuronal excitability, reactive oxygen species (ROS) production and biomarkers of oxidative stress. The main focus of his lab over the last 10 years has been understanding the anticonvulsant and neuroprotective mechanism of the ketogenic diet and ketone metabolite supplementation. The shift in brain metabolism (from glucose to ketones) reduces neuronal hyperexcitability, oxidative stress and enhances brain energy metabolism. This approach can be used to treat a wide variety of pathologies linked pathophysiologically to metabolic dysregulation, including cancer. Other areas of interest include researching drugs that target cancer-specific metabolic pathways. He was a research investigator and crew member on NASA’s Extreme Environment Mission Operation (NEEMO 22) and has a personal interest in environmental medicine and methods to enhance safety and physiological resilience in extreme environments. His research is supported by the Office of Naval Research (ONR), Department of Defense (DoD), private organizations and foundations.

With a wide range of research interests, Dominic D’Agostino holds membership in the Undersea and Hyperbaric Medicine Society, Aerospace Medical Association, Society of Neuroscience, American Physiological Society, and the American Association of Cancer Research, additionally serving on numerous editorial boards and as a Reviewer for dozens scholarly publications. Before joining the faculty at USF, D’Agostino completed a postdoctoral fellowship in neuroscience at Boonshoft School of Medicine at Wright State University. A graduate of Robert Wood Johnson Medical School and Rutgers University, Dominic D’Agostino earned his Ph.D. and B.S. from these respective institutions. [[ketonutrition.org](https://www.ketonutrition.org/about/)]

Dom on Facebook: [Dominic D’Agostino](https://www.facebook.com/dominic.dagostino.1)

Dom on Instagram: [@dominic.dagostino.1](https://www.instagram.com/dominic.dagostino.1/?hl=en)

Dom on Twitter: [@dominicdagosti2](https://twitter.com/dominicdagosti2?lang=en)

Dom’s website: [ketonutrition.org](https://www.ketonutrition.org)

Dom’s blog: [ketonutrition.org/blog/](https://www.ketonutrition.org/blog/)