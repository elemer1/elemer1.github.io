# #119 – Terry Real: Breaking the cycle of shame, anger, and depression

**Source:** [https://peterattiamd.com/terryreal/](https://peterattiamd.com/terryreal/)

---

Terry Real, a renowned family therapist and best-selling author, helps people create the connections they desire in their relationships. In this episode, Terry describes how his upbringing with an abusive father forged his path to become a therapist, develop his Relational Life Therapy (RLT) framework, and write [I Don’t Want to Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)—a book that reveals the hidden legacy of male depression. Terry discusses the link between childhood trauma and the deep-rooted shame, anger, and depression, which can result in feeling disconnected. Using real-life examples, Terry explains how he implements RLT to confront trauma, discover its origin, and teach the skills to break the cycle of pain, in order to live a satisfying life.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/terryreal/the_Drive_public.png)

Play

#119 - Terry Real: Breaking the cycle of shame, anger, and depression

#119 - Terry Real: Breaking the cycle of shame, anger, and depression

1x15s30s

0:001:39:46

## We discuss:

- Terry’s upbringing with a depressed and abusive father [3:15];
- The importance of the repair process, after relational disharmony, to break the trauma cycle [15:15];
- The impact of a patriarchal society, and relational growth as the next step for feminism [19:00];
- Origins of deep-rooted shame, and the difference between feeling ashamed and feeling guilty [27:15];
- Preventing the propagation of trauma without over-coddling kids [35:30];
- The one-up/one-down cycle from grandiosity to shame [37:30];
- Covert depression—Steps to fixing the secret legacy of male depression [40:00];
- Three forms of false self-esteem [50:00];
- Narcissism—a misunderstood concept [51:45];
- The interplay of shame, anger, and grandiosity, and how to break the cycle [54:15];
- The Relational Life Therapy framework [1:06:30];
- How the adaptive child becomes the maladaptive adult [1:15:30];
- Speaking the language of social relationships [1:21:45];
- When does it make sense for a couple to separate? [1:26:30];
- Witness abuse—Consequences of screaming at your partner in the presence of children [1:28:15];
- Cases of instantaneous change, and others which take more time [1:30:45];
- Reconciling with his father—Terry’s final conversation with his dad [1:33:45]; and
- More.

§

## Show Notes

## Terry’s upbringing with a depressed and abusive father [3:15]

**How peter found Terry**

- Peter was working with his therapist, [Esther Perel](https://www.estherperel.com/)
- She recommended Peter read Terry’s book, [I Don’t Want to Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)
- The book really resonated Peter and he then started seeing Terry for therapy sessions

**Terry’s upbringing with a violent father:**

- Grew up poor in Camden, New Jersey
- His parents were under a lot of stress
- Terry describes his father as a loving, smart, violent, emotionally brutal man
- Terry says it’s not uncommon that a parent can be loving and nurturing in one moment and then turn on you and become brutal — “*It’s very confusing, and it breathes a great deal of mistrust because the rug is always being pulled out from under you.*”
- This traumatic childhood was the reason Terry decided to go to therapy school when he grew up

> “I had to go to therapy school to get the skills I needed to talk to this man, to get him to open up to me, and I needed to understand what the hell had happened to him. I needed to make sense out of my father and his violence so that I would not repeat it, and I have.”

**The three children**

- Hero child—the good one, the achiever
- Scapegoat child—the bad one, the rebel
- Lost child—the one that nobody pays any attention to

-Terry says he was the scapegoat child

- He was not the best behaved
- But he says he was “invited to be a bad kid” and he took the invitation — and then was punished for it
- A scapegoat child is the one that wants to bring up to the surface all of the pathology and the truth that’s being denied and suppressed (usually through action rather than words)
- And then they get punished for it
- Sometimes they literally tell the truth about the family. “Dad is an alcoholic.” … only the scapegoat would say that

Schooling

- He was a D student all the way through high school
- He says this stemmed from something his father said to him in 2nd grade
- After bringing home a bad report card his father said to him, “It’s just because those assholes are so stupid and you’re so bright, they don’t know what to do with you.”
- The technical term for this is **false empowerment** — “He was pumping me up. It was no favor to a little boy.”

College

- Went to Atlantic Community College (only college he could get into)
- Got straight A’s and then transferred to Rutgers

**Terry’s father’s story [11:00]**

- When Terry’s father was only 9 years old, his mother passed away
- His father, who he describes as a passive loser of a man, owned a little candy store and lost it during the Great Depression
- The family broke up and lived in various people’s houses
- One day in a fit of depression, **Terry’s father’s father tried to kill himself along with Terry’s father and his younger brother** by gassing them in the garage with his car
- Terry’s father knew something was wrong and kicked out the window of the car and pulled out his younger brother
- That day was was the last authentic contact Terry’s dad had with his father

*-Depression*

- “Depression runs up and down my family” says Terry (who is “happily” on antidepressants himself to this day)
- Depression typically manifests in hurting others around you
- “Hurt people hurt people” as the saying goes

**Where most instances of violence and abuse comes from**

- Central to Terry’s work on masculinity is the **translation of shame into grandiosity**
- Feeling less than, inadequate, unlovable pushes people into the “*one down*” of **shame**
- From there you flip into the “*one up*” of **grandiosity**—superiority, better than, attack, avenging angel, righteous indignation
- This “*one down/one up*”—from victim to avenger—is central to masculinity and traditional manhood
- What’s devilish about shifting from shame (injury) into grandiosity (attack) is that it ***makes you feel better in the short run, but it just creates havoc in your life***
- Terry’s father *despised vulnerability* because he despised his own father, who he saw as weak
- So when Terry’s dad perceived weakness and vulnerability in Terry–that’s precisely when he would “attack”
- Terry calls his father’s actions a **hyper-masculine response to trauma**

## The importance of the repair process, after relational disharmony, to break the trauma cycle [15:15]

- [Pia Mellody](https://www.piamellody.com/) defined trauma or injury as any significantly less than nurturant transaction between parent and child
- But the most important thing is–whether or not there is **repair**
- All parents are imperfect — and a child’s character is shaped by those injuries which creates the “**adaptive child self**”

**A model for relationships**

- Terry’s model for relationships comes from [Ed Tronick](https://en.wikipedia.org/wiki/Edward_Tronick) — the basic rhythm of all relationships is **harmony, disharmony, and repair**
- Terry finds that most of the dysfunctional families have **little to no repair process**

> “In all the dysfunctional families I’ve treated over the years, there’s little to no repair. The repair process has gotten jammed up somehow, and so there’s just injury, and then you live with it until the next injury.”

**Terry tells a story of a mistake he made with his young son:**

- Terry son was playing hockey and he was complaining about his feet hurting
- Terry basically told him to suck it up and stop whining
- Turns out Terry, in a rush, had put his son’s skates on the wrong feet resulting which he only found out after the practice was over and he had blisters on his feet
- Terry hypothesizes that if his son had actually been his daughter, he would have listened more — an example of masculinity/patriarchy inflicting this pain on his son

> “If it had been Justina instead of Justin, would I have been so firm? Or would I have listened to my daughter? I think the honest answer is I would have listened more. This is masculinity. In that moment, I was the voice of patriarchy inflicting itself on my son.”

## The impact of a patriarchal society, and relational growth as the next step for feminism [19:00]

> “Most of the men that I see simply don’t know what living in healthy, satisfying, rich emotional connection feels like.”

**Patriarchy and the traditional gender roles**

- When Terry says patriarchy, he referring to the traditional gender roles for men and women (pre-feminism) — which is still “very much with us”
- Traditional role for women—accommodating and resentful, to lose their voice—leading to being manipulative
- So you’ve got an accommodating, resentful woman
- Traditional role for men—shutdown-driven, inwardly haunted, shame-based, outwardly successful
- “One of the things I say is an inwardly shame-based, outwardly driven man coupled with inwardly resentful, outwardly accommodating woman, **that’s America’s power couple.**”
- Peter adds that this is a dangerous combination because there’s not enough tension between those two roles that could potentially drive a change
- Feminism is the tension that eventually drove that change, says Terry

**Feminism, personal growth, and relational growth**

Terry poses the question: *What is the shared value by mainstream patriarchy and the personal growth movements?*

- His answer—**The sanctity of the individual**
- Personal growth is all about **personal** growth, not **relational growth**
- So feminism took a step in the right direction by empowering **themselves**
  - I.e, “*I was weak. Now I’m strong. Go screw yourself.*”
- But the next step is **relational empowerment**  (e.g., “loving boys”)
  - I.e., “*I’m going to be strong and loving at the same time—in the same breath.*”

> “Under the patriarchal system, you can either be connected, as affiliative feminine, or you can be powerful, as independent masculine, but you can’t be both at the same time.”

⇒ *Example in practice:*

- In his practice, Terry will say to women—
- “After 50 years of feminism, you have earned the right to be as I’m obnoxious as men have always been.”
- “The next step of loving boys—that’s standing up for yourself and cherishing the other person in the relationship in the same breath.”
  - E.g., “Honey, I love you to pieces. Could you please tone down the way you’re speaking to me right now so I can hear you?” versus, “I don’t like how you’re talking to me!”
    - You’re really saying the same thing in both cases, says Terry

**The two aspects of patriarchy for men—**

1 | The denial of vulnerability

- Invulnerable=manly
- Vulnerable=girly

2 | The delusion of dominance

- The entitlement, and this concept that you have responsibility to be above your  wife, your kids, or your body, your own thinking, or Mother Nature

> “That’s the masculine part of the traditional gender role. Cutoff, and false empowerment.”

## Origins of deep-rooted shame, and the difference between feeling ashamed and feeling guilty [27:15]

**Healthy self-esteem**

- Healthy self-esteem=The capacity to cherish yourself, to “esteem” yourself, in the face of your imperfections
- We want to do the same that with ourselves as we do with our children when they screw up—
  - i) You hold the person in warm regard
  - ii) You cast a very sober eye on the bad behavior
- Feel bad about the bad behavior you’ve done, but don’t beat yourself up—you’re a good, flawed person who made a mistake…
  - “*Learn from it, make amends, and get on with it.*”

**Shame**

- Shame is the opposite reaction—”I feel bad about behavior. I feel bad about who I am as a person.”
- This will eat you alive, says Terry
- For people who were unloved or shamed as children will carry this feeling with them into adulthood whenever they make a mistake
- Shame is the feeling of—
  - Unworthiness
  - Impedance
  - Helplessness
  - Unlovability
  - Defectiveness
- This is not something we’re born with — this is usually learned behavior from childhood mistreatment

**Guilt**

- Guilt is feeling bad about the bad behavior
- However, it can also be a form of self-preoccupation
- So in a state of grandiosity, and you’re in a state of self-entitlement and self-preoccupation
- When that deflates into guilt you land in another form of self-preoccupation—you just went from positive to negative
- Instead of sitting in guilt (feeling bad for yourself), you should focus on making amends with those that you hurt — “*let them energy go out to [them]*”

**The deep-rooted forces of shame**

- The reason people feel shame goes far beyond the emotional logic of “*I feel guilty about what I’ve done therefore the right thing to do is to dwell on it for a very long period of time and despise myself for it.*”
- Most shame starts in childhood—“*there are big forces at play.*”

**People “do shame” for 2 main reasons:**

1 | To protect themselves

- *If you mistreat children—*
- - They will blame themselves
  - Then they will try to contort themselves into whatever the parent needs in order to win that connection and love
  - Why? ⇒ Because it’s **safer to blame yourself than to come to grips with a random hostile universe**

> “For most children, it’s safer to blame yourself than to come to grips with a random hostile universe. It makes a lot more sense that I brought this on myself. . . ‘If I do something different, I might be able to control it’, versus, ‘The people who are supposed to protect me from the world are inflicting me with the brutality of the world, and I’m completely in their care and helpless.’ That is a scary thought.”

2 | Because it’s a multi-generational legacy

- We pass this on from generation to generation until somebody does something about it
- “Every man is a bridge spanning two legacies, the one he inherits and the one he passes on.”
- As a therapist and father, Terry is attempting to be the facilitator of stopping this cycle

> “Family pathology rolls from generation to generation like a fire in the woods taking down everything in its path until one person, in one generation, has the courage to turn and face the flames. That person brings peace to his ancestors and spares the children that follow.”

## Preventing the propagation of trauma without over-coddling kids [35:30]

**The problem of over-coddling kids**

- Peter poses the idea that, as a society, we seem to have over-coddled a generation
  - See this book: [The Coddling of the American Mind](https://www.amazon.com/dp/B079P7PDWB/ref=dp-kindle-redirect?_encoding=UTF8&btkr=1)

*How do we make sure to not traumatize our kids without over-coddling them?*

- First, trust your gut and civilize the little creachers, Terry says
- The thing to understand is that **self-esteem is spiritual**
- Most people think of as self-esteem as confidence and mastery
- But the reality is that you have worth and dignity as a human being simply because you’re here on this planet
- Your worth cannot be better or worse than the guy who left of the guy to the right no matter what you say or do
- “It can’t be added to. It can’t be subtracted from. It’s a spiritual fact.”
- We all know this in the abstract, but most of us don’t live it—you judge other people as better than or less than, and you judge yourself as better than or less than all day long

## The one-up/one-down cycle from grandiosity to shame [37:30]

> “I’ve been doing recovery work for 40 years ever since I was a teenager. At 69, I don’t do that anymore inside my head. I don’t go up, and I don’t go down. Not much. It’s not my baseline. And if I do, 9 out of 10 times, I’ll catch it.”

**Defining “one up” and “one down”**

- When someone is “one up,” they are feeling **superior/grandiose**
- When someone is “one down,” they are feeling **inferior/ashamed**

*Coming up from the “one down”*

- The field of psychotherapy (and self-help industry) has done a great job of helping people come up from the one down of shame
- Think [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey)

*Coming down from the “one up”*

- But we’ve done a terrible job with the the flip side of the same coin—helping people come down from the one up of grandiosity
- Our grandiosity is what gets us into so much trouble in our relationships
- Shame is an *im*plosion
- Grandiosity is acting out—an *ex*plosion
- \*The takeaway: **It’s much harder to come down from grandiose than it is to come up from shame.**

> “Shame feels bad. Grandiosity feels good. That’s the open secret. It feels good to get drunk. It feels good to get high. It feels good to make out with your secretary. It feels good to tell your boss to shove his job. In the moment that you’re being grandiose, it’s like an intoxicant. It feels good, so you have to think your way down from grandiosity. It takes a smarter person, and you think your way down. You come down from grandiosity even though it feels good because it’s in your interest to come down from it.”

**Grandiosity – men vs. women**

- Men’s grandiosity in this culture *tends to* be more **overt**—they lead from the one up grandiose position and have **covert** shame
- Women *tend to* lead more from the one down position (victim) and have **covert** issues of grandiosity

## Covert depression—steps to fixing the secret legacy of male depression [40:00]

Book: [I Don’t Want to Talk About It: Overcoming the Secret Legacy of Male Depression](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)

- On average, men tend to be more **covert** in their depression
- Women tend to be more **overt**
- When Terry wrote his book In 1997, depression was seen as a woman’s disease — his book was the first book written about male depression
- The thought was that women were 2-4 times more prone to depression than men
- But in fact, Terry argues that there was a **hidden** epidemic of depression in men

**Why men hide their depression**: *Men are ashamed of it*—it’s “unmanly” to be overwhelmed by feelings and vulnerable

- For this reason, men hide it and the people around them will often collude with their hiding it
- Terry estimates that 70% of family physicians do not diagnose a patient with depression
  - Terry’s intuition is that doctors (and the man’s family) are afraid to unmask that poor man and further shame him
- Covert depression—hiding depression from yourself
- Terry says some men do such a good job of hiding the depression that they hide it from themselves
- The man will erect defenses against the depression such as: Acting out (sexually), porn addiction, anger, sudden isolation and withdrawal, and self-medication (alcohol and drugs)
- The “unholy triad of covert depression”—radical isolation, anger, and sexual acting out

*Depression in men vs. women*

- So while OVERT depression might be 2-4x more prevalent in women vs men…when you add in cases of domestic violence, alcoholism and drugs, **it comes right back up to equal**
- **For example**, in areas where men lose their job, there’s a dramatic rise in domestic violence—and the *missing link between those two points is depression/low self-esteem*
- What we are seeing is the transliteration of shame into grandiosity, of helplessness into righteousness, of victimhood into attack — which is a “*central motif of traditional American masculinity*”

*Why do men tend to act out violently?*

*-Is it a biological thing or a social/cultural thing?*

- “It’s both, of course” says Terry, “but just because it’s something biological that doesn’t necessarily mean we’re supposed to go with them. The thing between our raw biological impulses and our behavior is called civilization.”

**Steps to fixing the hidden depression/shame**

-The first step to fixing covert depression in men is recognizing it

-Next is figuring out where it came from

-Then it’s about learning to live a relational life—

- how to open their hearts
- how to open their voices
- how to listen
- how to respond without getting defensive and egotistical

> “It’s what we’re born for. It’s the only thing that really makes us happy, and I do believe that the best way of teaching somebody how to live a relational life is to get their partner and maybe their kids in and work on the relationship rather than do it abstractly on the side.”

**The need for a crisis**

- *Do you find that most men need to be in crisis to hear what you’re saying right now?*
  - “Yes. You want a crisis.” says Terry

-Terry’s definition of mid-life crisis:

- This is the age when a man has “peaked”
- At this peak, he has either failed to reach his potential
- Or he has reached success but it feels hollow and he’s just as miserable as before
- “You fail or the agenda fails you, and that’s a great opportunity.”

-Relational crisis

- A relational crisis is when there is major strife in the relationship
- Many men are “wife-mandated referrals”
- Men are taught that just being who you are is not enough, that you have to earn connection through achievement (Icarus syndrome)

> “*Guys go off and work a hundred hours a week to be worthy of the wife and kids who just want them to come home already*.”

## Three forms of false self-esteem [50:00]

**Where is this feeling of inferiority and shame coming from?**

- Terry says it generally comes from seeds that were sown as little kids
- We’re taught to supplement our lack of **inside-out, healthy self-esteem** with **outside-in, false self-esteem**,

Three forms of false self-esteem—

- 1) Performance-based esteem–“I have worth because of what I can do,” and that’s a big one for men.
- 2) Other-based esteem–“I have worth because you think I do,” and of course pushed to extreme, that’s love addiction, and that’s big to women.
- 3) Attribute-based esteem–“I have worth because of what I have. I have big muscles. I have a beautiful wife. I am in Boston. I have a kid in Harvard. That’s the be all and end all.”
  - Attribute-based esteem is what our culture runs on.

> “If everybody woke up tomorrow with healthy self-esteem and full recovery, our economy would collapse. The whole advertising industry is built on, ‘Use this deodorant and be a special person.’”

## Narcissism—a misunderstood concept [51:45]

> “Narcissism is largely misunderstood. . .it is not a disorder of too much self-love, but too little.”

**The story of** [**Echo and Narcissus**](https://en.wikipedia.org/wiki/Echo_and_Narcissus)

- In Greek mythology, [Narcissus](https://en.wikipedia.org/wiki/Narcissus_(mythology)) is an addict “You’re going to fall in love with the next thing you see.”
- The next thing he sees as he bends over the well to get some water is the image of himself
- From then on he is endlessly rooted to the well, bent over, endlessly sighing as he tries to grasp the beautiful creature in the reflection and every time he tries to touch it, it dissolves.
- The lesson: If a narcissist had true self-love (of the inner self), he could leave the well, but he is rooted to the well because he’s addicted to his image, the constructive self that comes when you have no internal self.
- Also from this myth is the “essence of heterosexual relationships traditionally”—
  - Narcissus is bent over the well and [Echo](https://en.wikipedia.org/wiki/Echo_(mythology)) has bent over narcissism. Narcissist has no motility and Echo has no voice. So Narcissist endlessly sighs at his own beautiful reflection, and Echo endlessly repeats those sighs as she sighs for him.

**Is there a healthy narcissism or it is always pathologic?**

- Yes, there is healthy narcissism, healthy entitlement
  - But does your healthy entitlement get strained through patriarchy?
- The great anthropologist, [Riane Eisler](https://en.wikipedia.org/wiki/Riane_Eisler), talks about the difference between “power over” and “power with”
  - Is your narcissism about agency, and assertiveness, and “power with”? = Good
  - Is your narcissism about superiority and contempt? = Not good.

## The interplay of shame, anger, and grandiosity, and how to break the cycle [54:15[

**David Foster Wallace on grandiosity**

- David Foster Wallace commencement speech he delivered 2005 at Kenyon College, [This is Water](https://www.youtube.com/watch?v=8CrOL-ydFMI)
- He’s talking about grandiosity which he describes as being the root of so much misery
- In the short run, that grandiosity is an amazing anesthetic, but it has a very bitter aftertaste.
- *Analogy*: It’s like drinking three martinis—you’re really would have been better with just one, and that third one makes you feel better in the moment, but oh boy, do you pay for it.

**Self-interested reason to let go of grandiosity**

- Terry tells the story of getting cut off in traffic and then having that driver slow down to rub it in your face
- In his old days, Terry would have rolled down his window and “let him have it”
- But in his new state, he starts by breathing himself down from my anger/indignation/superiority
- Finally, Terry will say something like this himself, directed towards the person who cut him off , “You may deserve to have somebody pull next to you and blow you away, but I deserve to not be that person.”
- This is coming from a self-preservation standpoint—there is no upside to you being upset about this

**Coming down from anger/grandiosity by having compassion and empathy for others**

- Peter tells the story about how he became enraged when his grocery delivery service kept getting delayed
- He was ready to rip into the delivery person when they arrived — his wife even saw this boiling and made sure to be the first one to the door
- When the delivery person arrived, Peter saw that she was overweight, dripping in sweat, and extremely apologetic (and had broken the eggs)
- Peter’s attitude dramatically shifted in that moment from rage to total empathy
- Peter says he can’t really explain the flip but says he “got lucky”
- And that “If I could reproduce this at every moment of my life, I would be a happy man. I wouldn’t be the piece of shit that I’m probably hardwired to be.”

⇒ Terry’s reaction to this story: “*You’re not a piece of shit. You’re just like the rest of us. Listen, that’s a beautiful story, Peter, and what you had was a moment of empathy, of compassion, of humanity. . . You got past your* ***entitled indignation*****.**”

> “The more helpless you felt, the more angry you got. That’s how it works. The helplessness is one down in shame. The anger is grandiosity and righteousness, and like a lot of men, the longer that food took, the more helpless you got, the more angry you got. That’s the formula.”

**Real life example of putting these insights into action—**

-The man in the following story was feel dependent and helpful which was manifesting in anger and screaming at his wife

-Here’s how it played out:

- 25 years of marriage—Both in their 70s—on the brink of breaking up
- They got along great, except once or twice a day, when he’ll scream at her with utter annoyance and contempt
- He was raised by two alcoholics and his father would talk to his mother this way all day long
- He had “adult childhood alcoholic” stamped on his forehead, says Terry
- The issue when you grow up with alcoholics is trust—you learn not to trust people because it backfires on you
- He described that he was waiting for her, and they were late to get to somewhere, and he got annoyed with her—If she were “responsible” and “competent”, and if she loved him, then she wouldn’t be dragging her feet like that

–*The intervention*:

- Terry says to the man: “I’ll bet every time you get angry there’s a moment when you feel you’re dependent on her and she’s not coming through for you because you’re anti-dependent. The more dependent on her and the more she doesn’t come through for you, the more helpless you feel, and the angrier you feel, and then it all comes out.”
- He got it immediately, and he started to cry.
- Terry offered the following solution:
- First, ten times a day he needs to repeat this phrase to himself— “When I’m annoyed, it means that I’m dependent and I don’t like it or trust it.”
- Next, when he starts to feel helpless and simply says to his one word, “**Vulnerable.**”
- Terry then told his wife, “When you hear ‘vulnerable’, you stop on a dime and you go give your husband a hug because he just did a good piece of work.”
- Terry honestly believes that after that day he won’t scream at her anymore—“*That’s leading a couple out of patriarchy.*”

## The Relational Life Therapy framework [1:06:30]

**Relational Life Therapy – 3 phases**

-Phase 1: **Loving confrontation**

- Waking them up to the behavior that is hurting themselves and others around them

-Phase 2: **Family of origin**

- Deep family of origin, inner-child, trauma work in the *presence of the other partner*
- Important questions for finding the origin of the negative behavior—
  - Who did you see do it?
  - Who did it to you?
  - Who did you do it to and nobody stopped you and corrected you?

-Phase 3: **Teaching**

- Giving them the skills and tactics
- I.e.,
  - This is how you stand up for yourself in a *loving* voice
  - This is how you listen to your partner’s complaints without getting defensive, but rather with compassionation

**A Christmas story –** *The best rendition of Relational Life Therapy*

- The main character is Scrooge—this anti-relational and self-medicating person with attribute-based esteem
- He’s visited by three ghosts—
  - First, the Ghost of Christmas Future **confronts** him with the consequences of his actions by showing him how everybody is delighted that he’s dead at his funeral
  - Secondly, the Ghost of Christmas Past shows him his miserable childhood (**family of origin**) where all this comes from
  - Finally, Ghost of Christmas Present **teaches** him what a functional family looks like and and he’s a transformed human being.
- W*hat was the transformation?* ⇒ **He is relational. He’s in connection**.

**Real life example of “waking up” a man**

- Terry’s clients, “Harry” and “Shirley” had a habit of explosive verbal arguments
- Harry went so far as to spit on Shirley’s windshield as she was leaving the house
- **Confronting**—
  - Very quickly, Terry confronted Harry about his actions, “ I barely know you, but it occurs to me you don’t know the difference between standing up for yourself and attacking somebody.”
- **Family of origin**—
  - “*Who was the angry person in your family growing up*?”
  - He found out that Harry’s father was very angry and Harry had to protect his 3 year old sister when he was just 5 years old
  - Terry says to Harry, “you defend yourself like an angry five-year-old”
- **Teaching**—
  - Finally, he says to Harry “Would you let me teach you how to do this in a more civilized way?”
  - He responds, “I think you’d better.”

NOTE: Terry takes the uncommon stance as a therapist who “takes sides” when in a session with a couple…

> “There are some serious design flaws in therapy, and the biggest design flaw is that were all taught to be terminally nice to our clients. . .we therapists are taught to hold back, and I think it’s a great, great disservice to everyone.”

## The adaptive child becomes the maladaptive adult [1:15:30]

Bad adult behavior usually comes from mirroring things they’ve witnessed while growing up:

- And Terry can typically find out where it’s coming from with this series of questions—
  - Who did this to you?
  - Who did you see do it?
  - Who did you do it to and no one stopped you?

> “This is how this stuff gets transmitted from one generation to the next. This is exactly how it’s done.”

**Adaptive child, maladaptive adult**

- The adaptive child becomes the maladaptive adult
- A child will adapt to survive his/her environment as a child
- The term maladaptive adult refers to the dysfunctional or non-productive behavior that the adult still continues

⇒ Example,

- A child has an intrusive and emotional mother
- The adaption for the child is to erect thick walls
- As an adult, that person might marry someone and when she gets emotional he will erect thick walls around himself

> “I’m using the same adaptations that I used when I was 4, now at 45. Exactly what I needed to do at 4 is getting me into a world of trouble at 45.”

**An exercise to help people  dealing with their own adaptive child**

- Terry often has his clients write a letter to their adaptive child
- First, **thank the adaptive child**— E.g., “*I want to thank you. You really saved my ass. You protected my autonomy. Thank you.*“
- Secondly, this is what you **gave me**—E.g., Drive, goals, ambition, intelligence, etc.
- Next, this is what you **cost me**—E.g., You cost me connection, love, honesty with myself, getting comfort from anybody else, etc.
- Lastly, the **adult is now in charge**—E.g., “*I’m here now, the inner adult, and I can take care of both of us. From now on, what that’s going to look like is…XYZ*”

***Does the adaptive child ever completely go away?***

- It never vanishes. . .I think we contend with these little parts of us
- The difference is as you move into deeper and deeper recovery, the baseline is not this little boy, the baseline is my adult
- As your recovery work deepens…
  - The little boy only takes over episodically
  - And it happens less and less frequently
  - And you catch it earlier so you can bring yourself down from that one up (grandiosity/anger), or up from that one down (shame)

> “It’s like physical training. It’s like core work. This is core work, and the stronger your core, the more you spend your time in health, and the more ill-health becomes the exception.”

## Speaking the language of social relationships [1:21:45]

**How long does the skill of relationality take to acquire?**

After you’ve been “woken up” to your issues and maladaptive behaviors, and after you’ve done the family of origin work, you are now at the teaching skill/development stage…**Does this new skill take years to acquire?**

- “*Yes, but it doesn’t mean you have to be in therapy for years.*”

**Mastering “relational technology”**

- Just like learning piano, or a new language, as an adult…it’s going to take time
- It takes about **3 to 5 years** of practice until you’re really pretty fluent in the language of relationality
- The time it takes also depends on the **sincerity** of the person and how committed they are
- That said, the skills of relationality work so much better than the default that **doing it poorly is enough to transform your life and your relationship**…and you can start doing them poorly **right away**

> “These ways of handling yourself are so different from the defaults that you were raised with in the culture at large, and they work so much better that doing them poorly will transform your life and your relationship, and you can start doing them poorly right away.”

## When does it make sense for a couple to separate? [1:26:30]

***Are there times when Terry recommends that a couple split or get a divorce?***

This article by Terry helps therapists discern when a couple needs to break up: [Rowing to Nowhere: When is Enough Enough?](https://www.terryreal.com/rowing-to-nowhere/)

- It depends on the nature of the disagreement
- But there are certainly some deal-breakers—A person with a substance abuse problem that won’t get help, Violence, etc.
- Less clear situations include—
  - A serious discrepancy in the level of maturity between the two people
  - Difference of level of health—If one person gets healthy and the other one doesn’t, eventually the pathology of the unhealthy person is too hard for the healthy person to stomach and they will leave

## Witness abuse—Consequences of screaming at your partner in the presence of children [1:28:15]

When a child witnesses his/her parents fighting or screaming at eachother, they internalize as if they are being screamed at—

- If there is yelling and screaming in the house, Terry will always recommend a physical separation
- There’s something called **witness abuse**—If your child is listening to you scream at your wife, **it goes into them as if you were screaming at them**, there’s no difference.
- Terry will often give couples 30 days to clean up, and if they haven’t stopped yelling then one of them will leave the home
- Terry says even a child as old or 12 will internalize the yelling as if it was aimed towards them

Terry did a [piece for 20/20](https://www.youtube.com/watch?v=rD8yqZ1avIs) –

- He confronted a couple who were screaming at each other in front of their children
- Terry took the mother aside and told her, “*Before you rage at your husband, I want you to take the picture of your children, and I watch you to look them in the eyes, and I want you to say, ‘I know that what I’m about to do is going to cause you harm, but right now, my anger is more important to me than you are, so screw you.’*”
- She starts to sob and she says, “I will never yell at my husband again.”

## Cases of instantaneous change, and others which take more time [1:30:45]

- Typically, people need 3-5 years to fully change
- However, there are plenty of example of immediate turnarounds
- “People routinely sit on my couch, swear off behavior they’ve engaged in their entire lives, get up, and it’s gone permanently. Gone.”

Real life example—

- A man and a wife had been married for decades
- But each time he was “annoyed” with his wife we would really lay into her
- To the man, it seemed like no big deal
- But the wife felt a level of contempt 10 times greater than what the man felt he was delivering
- Turns out that the man grew up in a household filled with constant contempt amongst the family
- “*He thinks it’s just a love tap, and she’s flat on the floor.*” says Terry
- When Terry was able to convey this to the man, he really got it, and turned her with tears in his eyes and said, “*You are the most delicate, precious thing in the world to me. My in the world, have I been punching you? . . .Never again. Never again. Never again.*”

**Substance addiction takes more time**

- When it comes to substance abuse (drugs/alcohol), it is much less likely to be an instant turnaround
- Most of those people need intensive treatment

*“But why is anger any different?”* asks Peter…

- It also has dopamine-producing effects
- Grandiosity, anger, shame–*Doesn’t that have all of the same attributes as alcohol addiction?*
  - I don’t know the answer to this one, says Terry, because there are many behaviors that will kick out endogenous chemicals that mimic the substances that you ingest
- The reality is that there are rare instances of marvelous one-session turn-arounds, but 99 out of a 100 times people have to have ongoing support for a while — whether it be anger issues, substance abuse, etc.

## Reconciling with his father—Terry’s final conversation with his dad [1:33:45]

Terry was able to reconcile with his father prior to his passing (he died from [ALS](https://en.wikipedia.org/wiki/Amyotrophic_lateral_sclerosis))

On his deathbed, Terry’s father apologized to Terry and Terry’s brother about the way he had treated them growing up:

“*When you’re looking at this the way I’m looking at this right now in this hospital bed, it’s only about love. Everything else is just fucking bullshit.*” —Terry’s father in his last conversation with Terry

§

## Selected Links / Related Material

**Terry’s book about the hidden legacy of male depression**: [I Don’t Want to Talk About It: Overcoming the Secret Legacy of Male Depression](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398) by Terry Real | (amazon.com) [4:00, 8:15, 40:00, 48:30, 1:35:15]

**Carol Gilligan wrote about women’s loss of voice in her 1982 book**: [In a Different Voice: Psychological Theory and Women’s Development](https://www.amazon.com/Different-Voice-Psychological-Theory-Development/dp/0674970969) by Carol Gilligan | (amazon.com) [21:00]

**Book explaining how children will blame themselves if you don’t meet their needs**: [The Drama of the Gifted Child: The Search for the True Self](https://www.amazon.com/Drama-Gifted-Child-Search-Revised/dp/0465016901) by Alice Miller | (amazon.com) [31:45]

**Quote by Sigmund Freud**: [“The first human being who hurled an insult instead of a stone was the founder of civilization.”](https://quoteinvestigator.com/2015/08/05/spear/#:~:text=The%20first%20human%20being%20who%20hurled%20an%20insult%20instead%20of,was%20the%20founder%20of%20civilization.&text=In%20conclusion%2C%20Sigmund%20Freud%20helped,credited%20an%20unnamed%20English%20writer.) | (quoteinvestigator.com) [44:15]

**The story Echo and Narcissus**: [Echo and Narcissus](https://en.wikipedia.org/wiki/Echo_and_Narcissus) | (wikipedia.org) [51:45]

**Highly recommended commencement speech by David Foster Wallace highlighting the harm of grandiosity**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) | Jamie Sullivan (youtube.com) [54:15]

**Terry’s rendition of Terry approach to therapy is modeled after A Christmas Carol by Dickens**: [A Christmas Carol](https://en.wikipedia.org/wiki/A_Christmas_Carol) | (wikipedia.org) [1:06:30]

**This article by Terry helps therapists discern when a couple needs to break up**: [Rowing to Nowhere: When is Enough Enough?](https://www.terryreal.com/rowing-to-nowhere/) | Terry Real (terryreal.com) [1:26:45]

**Terry’s appearance on 20/20 helping a raging woman to stop screaming at her husband in front of her kids**: [Terry Real on 20 / 20](https://www.youtube.com/watch?v=8CrOL-ydFMI) | TheTerryReal (youtube.com) [1:29:45]

§

## People Mentioned

- [Esther Perel](https://www.estherperel.com/) [3:45]
- [Pia Mellody](https://www.piamellody.com/) [15:30, 50:15]
- [Ed Tronick](https://en.wikipedia.org/wiki/Edward_Tronick) [16:45]
- [Carol Gilligan](https://en.wikipedia.org/wiki/Carol_Gilligan) [21:00]
- [Brené Brown](https://en.wikipedia.org/wiki/Bren%C3%A9_Brown) [27:30]
- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) [38:15]
- [Riane Eisler](https://en.wikipedia.org/wiki/Riane_Eisler) [53:45]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [54:15]
- [Charles Dickens](https://en.wikipedia.org/wiki/Charles_Dickens) [1:06:30]

§

![](https://peterattiamd.com/wp-content/uploads/2020/07/1x1-terryreal-500x500.jpg)

##### Terry Real

Terry Real is an author, speaker, and family therapist. As a family therapist and teacher for more than 25 years, Terry helps his clients live in connection with others using his Relational Life Therapy (RLT) framework. He is also the bestselling author of a number of books including, [I Don’t Want to Talk About It: Overcoming the Secret Legacy of Male Depression](https://www.amazon.com/Dont-Want-Talk-About-Overcoming-dp-0684835398/dp/0684835398/ref=mt_other?_encoding=UTF8&me=&qid=), [How Can I Get Through to You?: Closing the Intimacy Gap Between Men and Women](https://www.amazon.com/How-Can-Get-Through-You/dp/0684868776/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), and [The New Rules of Marriage: What You Need to Know to Make Love Work](https://www.amazon.com/New-Rules-Marriage-What-Need/dp/0345480864/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=). Terry also founded the Relational Love Institute, offering workshops for couples, individuals, and patients around the country along with a professional training program for clinicians.