# #56 – Jocko Willink, retired Navy SEAL, Part II of II: Sleep, fasting, raising kids, discipline, taking ownership, and the impact of war

**Source:** [https://peterattiamd.com/jockowillink2/](https://peterattiamd.com/jockowillink2/)

---

In the second installment of this 2 part series, Jocko shares his sleep routine and attitude towards sleep, we talk about his meals (and occasional indulgences), his experience with fasting, and touch briefly on his workout routine. Jocko explains his approach to leading a family, instilling values in his kids, and working with others who may not share your same principles. We also find out what prompted Jocko to make discipline the underpinning principle of his life, when it might make sense to quit, and the philosophical topics such as free will, mindset, and whether or not you can change someone. We also discuss 9/11 and the war in Iraq and Afghanistan, the future of warfare, and perhaps more importantly, how Jocko’s experience in combat has shaped and impacted his life to this day.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jockowillink2/the_Drive_public.png)

Play

#56 - Jocko Willink, retired Navy SEAL, Part II of II: Sleep, fasting, raising kids, discipline, taking ownership, and the impact of war

#56 - Jocko Willink, retired Navy SEAL, Part II of II: Sleep, fasting, raising kids, discipline, taking ownership, and the impact of war

1x15s30s

0:001:31:44

## We discuss:

- Where was Jocko when the 9/11 attack occurred? What did he think? [5:45];
- How SEAL teams are structured, and which teams Jocko was on [10:45];
- War in Afghanistan: Unique challenges, how it differs from Iraq, and the lessons learned [13:00];
- Iraq War: Differing public opinions on war, Jocko’s experiences in Iraq, strategic mistake of ISIS, and the Saddam regime [19:15];
- The future of warfare: machine technology in war and medicine [27:30];
- Raising kids, instilling values, and leading a family [33:45];
- Sleep: Jocko’s habits, routine, and attitude towards sleep [40:15];
- When it makes sense to quit [53:30];
- What makes Jocko different, the existence of free will, and whether or not you can change people [1:01:45];
- How to work with people with a bad attitude and opposing mindset [1:07:45];
- Does Jocko ever indulge? Favorite foods and treats [1:11:00];
- Fasting and meal timing [1:16:30];
- Olivia (Peter’s daughter) interviews Jocko [1:21:45];
- What prompted Jocko to start prioritizing discipline in his life? [1:22:15];
- What does Jocko do in his workouts? [1:23:30];
- Where did the nickname, Jocko, come from? [1:24:20];
- Jocko’s favorite book, his best advice, and secret to getting up early [1:25:50];
- The impact that war had on Jocko [1:28:00]; and
- More.

§

## Show Notes

## Where was Jocko when the 9/11 attack occurred? What did he think? [5:45]

*Where was Jocko when 9/11 happened?*

- In college at the University of San Diego (only because they Navy made him go)
- As soon as the second plane hit, Jocko was certain that we were under attack
- Jocko saw this attack as a game changer, a “Pearl Harbor like moment”
- Within a day or two Jocko was calling his [Navy detailer](https://www.public.navy.mil/bupers-npc/enlisted/detailing/Pages/default2.aspx) asking to be taken out of college and put on a SEAL team immediately
- The detailer said no… “*Finish college. This war is going to last a long time.*”
- Jocko finished college and returned to the SEALs in the Spring of 2003 (6 months after the Iraqi invasion)

## How SEAL teams are structured, and which teams Jocko was on [10:45]

- SEAL teams consist of multiple platoons
- Generally, you work just within your platoon
- Sometimes two or three platoons will work together on a particular mission (4 in rare cases)
- There are a total of 8 SEAL teams,  numbered 1 through 8
- Odd numbers are on the west coast
- Even numbers are on the east coast
- The numbers are simply the order in which the SEAL teams were created (starting with 1 and 2 back in the 1960s)
- Jocko was on: SEAL Team One, SEAL Team Two, SEAL Team Seven and SEAL Team Three (in that order)
- After college, Jocko joined SEAL Team Seven
- Jocko was put in command of a platoon that then deployed to Iraq

> “I’m the luckiest guy in the world because to show up at a SEAL Team and get a SEAL platoon that’s getting ready to deploy to Iraq. It doesn’t get much better than that.”

## War in Afghanistan: Unique challenges, how it differs from Iraq, and the lessons learned [13:00]

*How is fighting similar and different in Iraq vs. Afghanistan*?

- Similarities:
  - The principles of combat don’t change
  - In Ramadi, you got streets and you’ve got buildings, that’s your low ground and high ground
  - In Afghanistan, you had valleys (low ground) and peaks (high ground)
  - Just like the city, you want to control the high ground and get good angles
- Differences:
  - But the distances are further
  - In urban combat (Iraqi), the rapidity with which things unfold is a lot tighter so you don’t have much time to make decisions
  - “They both have incredible challenges and both situations were brutal in many ways.”
  - Very few US troops remain in Afghanistan

**Fighting in Afghanistan: the difference between the American vs. Russian experience**

[*Soviet–Afghan War*](https://en.wikipedia.org/wiki/Soviet%E2%80%93Afghan_War) *(1979-1989)*

- The Russian military couldn’t be more different the American military, says Jocko

Book rec: [One Soldier’s War](https://www.amazon.com/One-Soldiers-War-Arkady-Babchenko/dp/0802144039)

- Written by [Arkady Babchenko](https://en.wikipedia.org/wiki/Arkady_Babchenko), a Russian soldier that fought in [Chechnya](https://en.wikipedia.org/wiki/Chechnya)
- The books tells the brutal account of Russian soldiers in Afghanistan having to fight the brutal insurgency (who were sawing heads off) only to come back to then get physically beaten by their own sergeants
- The beatings/hazing apparently happened all the way up and down the chain of command
- “Everyone is getting beaten. Like, really? They’re going to beat the shit out of you. Why? Because they’re bored. Why? Because you didn’t get water for them when they wanted you to. You’re going to get beaten and that’s what they’re living through. So you have that going into Afghanistan.”
- The point: **Morale is absolutely horrible**

The other thing: *Only the downtrodden Russian people fight in wars*

- In America, you have people from all walks of life *choosing* to be there
- In Russia, if you’ve got money, you’re not going to war
- It’s only the people that didn’t have any other choice that are going to end up there

Movie about US involvement in the Soviet-Afghan War: [Charlie Wilson’s War](https://en.wikipedia.org/wiki/Charlie_Wilson%27s_War_(film))

The US supported the Afghan [mujahideen](https://en.wikipedia.org/wiki/Mujahideen) by providing them with [Stinger missiles](https://en.wikipedia.org/wiki/FIM-92_Stinger) (which has some faults including exploding when firing and killing the operator of the gun)

*The Afghan’s fought off the Soviet, how did they do it?*

- Classic case of insurgency (Afghan’s) discovering that this big organization (Soviet army) can’t maneuver like you can
- The Soviets may have been bigger, more advances, etc. but they were NOT going to win a war of attrition
- The Americans ran into the same thing with fighting in Vietnam

**Analogy to business:**

“*You’re up against titans and you will not beat them in a war of attrition. They can outspend you. They can out hire you, they can out work you. They can outproduce you, literally. So the only way you’re going to beat them, is* ***you have to be more maneuverable than them****. You have to find out what their weaknesses are because they do have weaknesses. . .That’s what you have to figure out, because you can’t beat him in a war of attrition.*”

## Iraq War: Differing public opinions on war, Jocko’s experiences in Iraq, strategic mistake of ISIS, and the Saddam regime [19:15]

![](https://peterattiamd.com/wp-content/uploads/2019/06/Jocko-and-Babin-1024x631.png)

**Figure 1. Jocko and Leif Babin in Iraq.** Image credit: [samharris.org](https://samharris.org/podcasts/the-logic-of-violence/)

*Why were soldiers treated so differently upon their return from Vietnam compared to other wars*?

- People hated the Vietnam war
- And the public was unable to separate the war from the soldier
- Not everyone was treated badly
  - For example, Roger Hayden, a SEAL Jocko has always looked up to, [appeared on Jocko Podcast](https://jockopodcast.com/2017/05/31/77-war-stories-mental-toughness-and-clever-tactics-in-vietnam-and-for-life-with-cwo-roger-hayden/) and said he wasn’t treated badly when he returned from Vietnam
- By contrast, some vets faced undeserved harsh treatment (one vet lost his arm in Vietnam and was spit on at college)
- You still see the hate from some Americans with radical views, but most people “*realize that that’s not a good target for your anger.*”

**Experiencing war will change your perspective**

- When you know what the insurgents are doing to the civilian populace, it will change your mindset on what we should be doing

> “When we know that the insurgents have decapitated the head of the household in a neighborhood with five families. . .or you know that they skin the guy alive, when you hear that, you go, ‘okay, we should be doing something about this. We have some kind of an obligation to help these people that are under the oppressive insurgency that’s here.’ And when you see a little kid, you see this little family that’s just trying to live their normal live, you think ‘we can help them.’ They don’t want these insurgents there.”

*Did Jocko feel welcome by the Iraqi populace?*

- Yes. . .without question
- A [Vice News article](https://news.vice.com/en_us/article/yw4yyk/with-the-islamic-state-closing-in-on-ramadi-iraqi-officials-demand-help-from-the-us) told the story of a the Ramadi people calling the Americans and begging them to return when ISIS was returning to Ramadi after the Americans had pulled out of the country
- Unfortunately, the US didn’t come back, and ISIS killed 500+ men, women, and children as retribution for helping coalition forces

*What is the presence of ISIS in Iraq today*?

- “Nil.”

*What about in Syria*?

- None, “they’re dead”

**The strategic mistake of ISIS**

- Once ISIS decided to fight like a nation state
- They got vehicles, uniforms, and flags
- So they decided easy to differentiate from the populace so it became like “fighting a nation state that was inferior.”

*If you could return to Iraq with your family, where would you visit*?

- Ramadi and Baghdad
- Baghdad was a surprisingly westernized city with large highways
- In fact, Iraq used to be (and sort of is again) one of the most secular places in the middle east
- Iraq is a stark contrast to Iran, for example

**Iraq under** [**Saddam Hussein**](https://en.wikipedia.org/wiki/Saddam_Hussein)

- As bad as he was, he was not as religiously intolerant as many past and present leaders
- Peter’s parents (from Egypt), placed “such a premium on the fact that he was religiously more tolerant than other leaders in the Middle East”

Weapons of mass destruction:

- Saddam was bluffing about his WOD
- Yet, it was very believable considering he has used them in the recent past (e.g. [Halabja chemical attack](https://en.wikipedia.org/wiki/Halabja_chemical_attack))
- Saddam’s big mistake was pushing this belief that he has WOD (presumably to show power) but it ultimately lead to him getting overthrown

## The future of warfare: machine technology in war and medicine [27:30]

**Technology in warfare**

- We already have drones that can be operated remotely
- At some point we will have more sophisticated robots fighting and making decisions
- “*You’re going to end up with drones killing each other and hopefully the drones will all fight the wars*.”

What has been the net impact of the introduction of drones in the last 15 years?

- Less humans in danger (for the good guys, at least)
- What scares people most about robots/drones?
  - Less discernment
  - It can kill with “no thought, no guilt, no remorse”
  - But Jocko points out that there is **still a human making a decision** operating the drone (for now, at least)

**Robots in medicine: Surgery**

- When robots became capable of doing surgery, people thought that was the end of humans doing surgery
- But there are still humans doing the operations but they are just assisted by robots
- However, there are certain operations where the robot make so much sense (best example is the [radical prostatectomy](https://www.webmd.com/prostate-cancer/guide/prostate-cancer-radical-prostatectomy))
- Robot has much finer motor control and better visibility
- But there are other examples where the robot makes less sense such as when visibility and tactile ability to do the operation are not remotely problematic (e.g. breast augmentation)

**We still trust humans more than robots**

Jocko’s says we trust humans over robots even when statistically robots are superior at the task

- If a robot kills someone on the operating table, then it’s like, ‘oh my God, how could that happen?’
- But surgeons kill people on the operating table as well and you think, ‘oh well it must have been an accident’
- So we inherently trust that the human being is going to do a better job than the robot’s going to do.

Robots in combat

- At this juncture, there is still a human making decisions on the other end of the drone
- So the mistakes that occur are the humans fault
- In the future, however, robots will likely take over more and more of the decisions
- And even though they might be better decision makers, “*that really can scare some people. I think people inherently don’t trust robots to make decisions that are life and death*.”

Example, driverless cars:

- Driverless cars are far superior to human drivers in terms of vigilence and accidents
- Over a million people a year die in car accidents at the hands of other human drivers
- Yet when a Tesla makes a rare mistake it’s front page news
- “*We don’t trust [driverless cars], but we trust a 16 year old.*”

## Raising kids, instilling values, and leading a family [33:45]

Jocko is the author of several children’s books

- The books contain what he believes are the most important lessons for kids
  - [Way of the Warrior Kid](https://www.amazon.com/Way-Warrior-Kid-Wimpy-Novel/dp/1250151074)
  - [Marc’s Mission: Way of the Warrior Kid](https://www.amazon.com/Marcs-Mission-Way-Warrior-Novel/dp/1250156793)
  - [Mikey and the Dragons](https://www.amazon.com/Mikey-Dragons-Jocko-Willink/dp/1942549431)
  - [Way of the Warrior Kid 3: Where there’s a Will…](https://www.amazon.com/Way-Warrior-Kid-Where-theres/dp/1942549482)

*How does Jocko instill those lessons in his own kids?*

1. Jocko is **careful not to impose things** on his kids ⇒ “I don’t impose things that don’t make sense on them in the things that I steer them towards.”
2. **Be helpful** ⇒ His kids know that dad is correct, so it’s hard to get mad when it’s clear someone is trying to help you
3. **Don’t force it** ⇒ Jocko has learned not to force things on his kids… he forced jiu-jitsu on them too hard, he says, making them compete above their level so they’d always get beat and it wasn’t fun for them
4. **Allow them to discover truths for themselves** ⇒ “As they got a little bit older, I started to try and actually incorporate the values and the principles that I kind of attempt to live my life by, [but] I was careful not to make the same mistake of imposing these things so hard, but instead allowing them to discover the principals truths for themselves.”

**Admitting your mistakes to your kids**

- I’m not hiding my mistakes when I screw up, says Jocko, “I laugh at it”
- I have **no ego** when it comes to that kind of thing
- Jocko sucks at technology and allows himself to get “angry” at inanimate objects

**How to lead your family**

> “Leading a family and leading your kids is the same way you lead an organization or lead a team. And if you bark orders at your team, your team doesn’t like you, they don’t respect you, and they’re not going to carry out those orders with any sort of commitment.”

How to lead:

- Let them know what the goal
- Then allow them to forge what their idea is and then what their plan is going to be
- They’re going to commit to that plan and they’re going to go execute it because it’s their plan
- “That’s **decentralized command**. It’s the one of the major lessons that I learned in my military career and now working with civilians, and the minute you decide you’re going to bark orders at people and impose your discipline upon them, they’re going to reject it. And so you’ve got to be careful about that.”

## Sleep: Jocko’s habits, routine, and attitude towards sleep [40:15]

The recent trio of episodes of The Drive with Matthew Walker ([Part 1](https://peterattiamd.com/matthewwalker1/), [Part 2](https://peterattiamd.com/matthewwalker2/), [Part 3](https://peterattiamd.com/matthewwalker3/)) has spurred a lot of people wanting to hear about Jocko’s sleep

Jocko’s typical sleep schedule:

- Bed at 11 pm
- Wakes up at 4:30 am

Evening routine:

- Finishes jiu-jitsu around 7:30 or 8:00
- Dinner, his biggest meal, is shortly after that
- He then spends some time with kids
- Does a little bit of work
- In bed by 10:40, asleep by 11 (falls asleep immediately)

Does he use an alarm?

- Yes
- If he doesn’t set an alarm, he can’t sleep b/c he’s worried about oversleeping
- He’s says the alarm wakes him up only about half the time
- Other half of the time he wakes up before the alarm goes off

Does he ever wake up tired?

- He feels physically tired, especially when he’s doing a lot of jiu-jitsu training
- But he **never feels tired in the sense that he wants to go back to sleep**

Take naps?

- A couple times a week
- Not planned, but will do it if feels tired
- Naps are only **8 minutes long**

Jocko’s napping protocol:

- Elevate your feet above your heart
- Set alarm for 10-12 minutes
- Any more than that you’ll feel groggy
- “*Eight minutes…I feel like I slept for eight hours*.”

Does Jocko have caffeine?

- “When I need it”
- Jocko drinks white tea
- He developed his own brand, [Jocko White Tea](https://www.jockotea.com/) (which Peter loves)

Does he wear a sleep tracker?

- No
- Peter wishes he would
- Considering Jocko only get 6 hours/night, Peter suspects he might be “efficient” in his sleeping

Night sweats

- Jocko wakes up in a pool of sweat frequently
- Usually when he’s dreaming
- But he also uses a [ChiliPad](https://www.chilitechnology.com/), which he says helps

[Kirk Parsley](https://twitter.com/docparsley?lang=en), sleep expert and mutual friend

- Kirk is a former Navy SEAL
- Jock and Kirk joke on twitter: “He tells me to sleep more. I tell him no.”
- Kirk once told Peter about an interesting experiment:
  - Took a bunch of guys in the military
  - Highly sleep deprived
  - Then put them in an environment where they were forced to be in darkness for some period of time
  - 12 hours of pure darkness, 12 hours of light, but with no sense of time (i.e. no clocks)
  - Within two weeks they were all basically sleeping something like seven and a half to nine hours a night even though they hadn’t been sleeping close to that in the past

**Jocko is NOT telling people to sleep less**

> “I don’t discourage sleep. I think sleep is important. I’ve watched people’s cognitive abilities go down when they’re tired. I’ve seen it, I’ve watched it happen. A guy gets tired and all of a sudden he can’t make good decisions. I’ve seen that over and over and over again. So I know that people should sleep and should sleep as much as they need.”

- Jocko believes the amount of sleep needed depends on the person
- He says his four kids all seem to naturally have drastically different sleep needs
- There has to be a genetic role, says Jocko

Peter’s changing sleep habits

- Peter used to sleep 6 hours per night
- He thought that was all he needed and he also liked the extra time awake to be productive
- But after “experimenting” with getting 8 hours per night he found the benefit far outweighed the “less time”
- Jocko says he feel groggy and physically weak if he sleeps more than 6 hours

> “I look back at my most unhealthy period of my life when I was overweight and heavily insulin resistant and all of those things, and I had historically placed a lot of that blame just on my diet. I now believe **at least half of that blame belongs on my sleep deprivation**.” —Peter Attia

## When it makes sense to quit [53:30]

How do you tell a difference between giving up (quitting) versus the smarter, “calling it quits”?

- Strategy versus tactics, says Jocko
- He is happy to give up when a tactic isn’t working as expected
- What you **don’t want to give up on is your strategic goal**

What about quitting in a moment of weakness?

- Peter tells a personal example of a time when he really, really wanted to give up on a marathon swim
- Jocko struggles to find a good example of quitting and says one time on a surfboard he was unable to paddle out past the waves and then “he could have tried more”
- Peter joking says, “Okay. But that’s like me saying, Jocko, I want you to fly. I want you to flap your arms really, really hard until you get onto my roof.”

## What makes Jocko different, the existence of free will, and whether or not you can change people [1:01:45]

- Jocko takes issue with this question
- He says he knows he’s “not normal” but says “nobody is 100% normal”
- Peter says maybe the person asking the above question is looking for some kind of acknowledgement that Jocko has some internal thing that makes him more capable of certain things

Free will

- Peter asks Jocko and he and Sam Harris (mutual friend) have discussed the concept for free will (Sam wrote a book called [Free Will](https://www.amazon.com/Free-Will-Deckle-Edge-Harris/dp/1451683405))
- Jocko says a little bit but he hasn’t gone deep on it

⇒ Peter’s take:

- “*I still don’t know if I believe in free will. I would say this. I used to absolutely believe in free will. Today I’m a freewill agnostic.*”
- Peter says it’s given him me a little bit more understanding of people that don’t share his same values (e.g. work ethic)  ⇒ “It used to be so hard for me to acknowledge the existence of people who didn’t just want to crush it every minute of every day. It just bugged me. It just bothered me and I tried to separate it from the person, but deep down I think I harbored a resentment that I think has melted away significantly as a result.”

⇒ Jocko’s take:

- Where Jocko might agree with the lack of free will argument…
  - “I tell people all the time, from a leadership perspective, people are the way they are. And so that basically is saying they don’t have free will.”
  - You can have *some* level of influence on a person and their underlying attitude (you can move it a little bit to the left or to the right)
  - You can give him a little bit of course correction, but they’re going to be that person and **the only thing that can change them is them**
- Where Jocko might push back against the lack of free will argument…
  - People can radically transform their life (take a recovered drug addict, for example)
  - But you can’t impose that transformation upon them. They have to come to that conclusion that they want to change.

*Can you really change a person?*

- Jocko says first reaction is “No.”
- However, digging a little deeper, Jocko says you can illuminate that path for someone to make a change but they have to be the one who makes that transition

## How to work with people with a bad attitude and opposing mindset [1:07:45]

How does Jocko recommend you work with/lead people who have the opposite mindset (examples: make excuses, externalize, blame others, procrastinate, etc.)?

- “You get the best out of people that you can.”
- Jocko suggests taking ownership of their excuses
  - Need more people? Resources? ⇒ Tell them, “that’s my fault” and get them what they need
- In other words, take ownership of everything (even the failures and excuses of those you are leading)

> “Not everyone is going to like that. Some people do not like to take ownership. . .some people will never take ownership of everything because it hurts their ego and they don’t want to be blamed for everything. . . And what’s great about those people is **they won’t last inside my organization. They will get eaten up**.”

**Applying these lessons to your kids**

⇒ Example: Your child isn’t doing their homework…

- Instead of saying “you didn’t do your homework!”
- Try saying…
  - “I feel like I’m not even being a good dad because here is the most important thing that you can do in your life, become smarter and somehow I haven’t made that impression on you and now you’re missing out on simple things that are going to improve your ability to contend with the world by being the smartest possible human you can be and I haven’t done a good job…
  - …Is there anything that I can do that will help you realize why it’s so important that you improve your intellect at every chance possible that you get you become smarter, because you’re going to be out there in the world one day. And I’m not going to be there. You’re going to be on your own and the only way you’re going to be able to survive is because of your brain. And right now I haven’t done a good job of explaining to you that that’s the most important weapon that you have.”

## Does Jocko ever indulge? Favorite foods and treats [1:11:00]

Alcohol

- Jocko doesn’t drink
- Once he retired from the Navy, he gave up alcohol

Dark chocolate

- What percentage?
- 72%
- Jocko laughs at himself and says “I lie to myself that that’s still dark chocolate, we know it’s not.”
- “The way I can tell when something is the right level of darkness is when it tastes good but you don’t want more. When you get a good for me, 2 squares of 80% to 85% and I’m satisfied and I don’t even want anymore. 72% I want that whole bar and the box that the bar came in.”

*Favorite food*: Steak is his favorite

*Favorite treat*: Mint chocolate chip milkshakes

- Jocko turned his love into a supplement: [JOCKO MÖLK](https://originmaine.com/origin-usa/nutrition/jocko/health/jocko-molk-mint-chocolate-protein/) protein powder
- Mix with milk (or cashew milk) or water

Non-sugar sweeteners:

- Jocko’s favorite is monk fruit (used in JOCKO MÖLK)
- [Allulose](https://en.wikipedia.org/wiki/Psicose):
  - Peter is very excited about allulose
  - Just [approved recently by the FDA to correctly acknowledge it for what it is](https://www.instagram.com/p/BxDzZ6EAvkA/)
  - Allulose is an enantiomer of fructose, meaning it is something that has the same chemical nomenclature as fructose, but it has one different position of a bond
  - About 70% the sweetness of fructose
  - Most importantly are two things make it different from sugar
    - One, it has the exact same flavor-esque and mouth feel as sugar, but here’s the best part…**It’s not absorbed. It’s excreted by the kidneys.**
      - So for every grams you ingest you’re only getting like one 10th of the absorption
    - Secondly, **it seems to drag glucose out** with it
      - Consuming allulose will actually lower your blood sugar (and doing so not into your gut where you get gastrointestinal distress but actually into your kidney)
  - Up until recently, the FDA was basically calling it basically an added sugar so food companies weren’t getting “credit” for using it since it showed up as sugar on the labels
  - Companies using allulose in some of their products:
    - [Quest Nutrition](https://www.questnutrition.com/)
    - [Know Foods](https://knowfoods.com/)

## Fasting and meal timing [1:16:30]

How many meals does Jocko eat per day?

- Between 0 and 2

Does he eat breakfast?

- No, just lunch and/or dinner

Longest he went without eating in combat?

- Probably a few days

Does Jocko do any fasting?

- Once or twice a week he will not eat anything
- Once a quarter he does a 72 hour fast (but plans to do longer fasts in the future like Peter’s 5-7 day fasts)
- Jocko says the 3 days fasts he does and really not bad, “I feel fine, totally normal.”

Jocko asks about Peter’s fasting

- Peter says he does quarterly fasting of 5-7 days
- He aims for seven days
- Peter says there is a real tipping point of glycogen release after 3 days
- Jocko says he plans to go past 3 days in future fasts

Why Peter wants his patients to try fasting:

- Peter says it’s super empowering for them
- Mentally they may feel like it can’t be done since they’ve been used to a constant “drip” of food for so many years
- So once they realize they can do it, it’s like “they are a little more in touch with our ancestors. Like you did something that you were genetically equipped to do.”

## Olivia (Peter’s daughter) interviews Jocko [1:21:45]

## What prompted Jocko to start prioritizing discipline in his life? [1:22:15]

- When Jocko got in the SEALs he quickly realized the people that were best at their jobs were:
- Getting to work early
- Taking great care of their gear
- Putting forth effort above their peers
- The more disciplined they were, the better they were, and the more latitude they had to do what they wanted to do (i.e. more freedom)
- As a child, Jocko says he was a bit misbehaved, and he realized how things would backfire on him, this opened his mind up to be able to see the benefit of discipline

## What does Jocko do in his workouts? [1:23:30]

![](https://peterattiamd.com/wp-content/uploads/2019/06/jocko-deadlift-1024x652.jpg)

**Figure 2. Jocko deadlifting.** Image credit: [success.com](https://www.success.com/the-jocko-willink-way/)

A lot of variety, but all common exercises

- Body weight stuff:
  - Push ups
  - Pull ups
  - Dips
- Lifting weights:
  - Uses kettlebells
  - Deadlifts
  - Squats (front squats, back squats, overhead squats)
- Cardio:
  - Sprints
  - Rowing machine
  - Air cycle
  - Burpees

> “There’s no secret exercise that I do that’s different than what normal people that work out do.”

## Where did the nickname, Jocko, come from? [1:24:20]

- Real name is John (named after his father)
- Jocko’s father was named after his father’s uncle, who was name John Oglethorpe (and his nickname was John-O)
- Jocko’s father really wanted his boy to be an athlete (a “jock”)
- So they decided to call him “Jocko”

## Jocko’s favorite book, his best advice, and secret to getting up early [1:25:50]

Jocko’s favorite book: [About Face](https://www.amazon.com/About-Face-Odyssey-American-Warrior/dp/0671695347)

Jocko asks Olivia, *what is your favorite book*?

- Her answer: [Way of the Warrior Kid](https://www.amazon.com/Way-Warrior-Kid-Wimpy-Novel/dp/1250151074) (says she’s read it 10 times)
- Jocko says she needs to read the second one called: [Marc’s Mission: Way of the Warrior Kid](https://www.amazon.com/Marcs-Mission-Way-Warrior-Novel/dp/1250156793/ref=pd_bxgy_14_img_2/134-2599105-6416143?_encoding=UTF8&pd_rd_i=1250156793&pd_rd_r=436bf729-7b06-11e9-a109-d74889de0019&pd_rd_w=iAMgI&pd_rd_wg=wkTSb&pf_rd_p=a2006322-0bc0-4db9-a08e-d168c18ce6f0&pf_rd_r=FD6DX9FNXBKQ7NVWFW2V&psc=1&refRID=FD6DX9FNXBKQ7NVWFW2V)

⇒ *What did Olivia learn from Way of the Warrior Kid*?

- “What I learned is that the kid Mark, he wasn’t very disciplined in the beginning, but then he got the training and he learned to eating right and he learned how to be disciplined and then he had more success in school and he was better at all of these things.”
- Jocko: “**The best advice I can give someone is have discipline because then you’ll end up with more freedom.**”

Watch Jocko’s CNBC video about his secret to getting up early and overcoming laziness:

## The impact that war had on Jocko [1:28:00]

> “There’s a lot of people that are scared of what war does to people and they think that war has a massively negative impact on people. And I can tell you without a doubt, I am grateful that I had the opportunity to serve. I’m grateful and unbelievably humbled that I had the opportunity to serve with the guys that I served with and fight alongside them on the battlefield. And I know that it’s made me better being around people like that, seeing what real sacrifice is. And it’s an honor to be sitting here.”

§

## Selected Links / Related Material

**Jocko was the commander of**: [SEAL Team 3’s Task Unit Bruiser in Iraq during the 2006 Battle of Ramadi](https://en.wikipedia.org/wiki/Jocko_Willink#Military_career) | (wikipedia.org) [4:15]

**Jocko’s leadership consulting company**: [Echelon Front](https://echelonfront.com/) | (echelonfront.com) [4:15]

**Books written by Jocko**: [4:30]

- [Extreme Ownership](https://www.amazon.com/Extreme-Ownership-U-S-Navy-SEALs-ebook/dp/B00VE4Y0Z2)
- [Dichotomy of Leadership](https://www.amazon.com/Dichotomy-Leadership-Balancing-Challenges-Ownership/dp/1250195772)
- [Discipline Equals Freedom](https://www.amazon.com/Discipline-Equals-Freedom-Field-Manual/dp/1250156947)
- [Way of the Warrior Kid](https://www.amazon.com/Way-Warrior-Kid-Wimpy-Novel/dp/1250151074) (children’s book) [34:30, 1:25:45]
- [Marc’s Mission: Way of the Warrior Kid](https://www.amazon.com/Marcs-Mission-Way-Warrior-Novel/dp/1250156793) (children’s book) [34:30, 1:25:45]
- [Mikey and the Dragons](https://www.amazon.com/Mikey-Dragons-Jocko-Willink/dp/1942549431) (children’s book) [34:30]
- [Way of the Warrior Kid 3: Where there’s a Will…](https://www.amazon.com/Way-Warrior-Kid-Where-theres/dp/1942549482) (children’s book) [34:30, 1:25:45]

**Podcast hosted by Jocko**: [Jocko Podcast](https://jockopodcast.com/) | (jockopodcast.come) [4:45]

**Episode of Jocko Podcast with Peter as his guest**: [56: OVERCOMING STRESS, SLEEP DEPRIVATION, AND THE DARKNESS WITH PETER ATTIA](https://jockopodcast.com/2017/01/04/56-overcoming-stress-sleep-deprivation-and-the-darkness-with-peter-attia/) | (jockopodcast.com) [4:45]

**Co-founder of Victory MMA in San Diego**: [Victory MMA and Fitness](https://www.victorygyms.com/) | (victorygyms.com) [5:00]

**Most famous SEAL team**: [SEAL Team Six](https://en.wikipedia.org/wiki/SEAL_Team_Six) | (wikipedia.org) [10:45]

**Book written by a Russian soldier that fought in Chechnya**: [One Soldier’s War](https://www.amazon.com/One-Soldiers-War-Arkady-Babchenko/dp/0802144039) by Arkady Babchenko (amazon.com) [14:30]

**Arkady Babchenko faked his own death**: [Arkady Babchenko: Staged death](https://en.wikipedia.org/wiki/Arkady_Babchenko#Staged_death) | (wikipedia.org) [14:45]

**Movie about the American’s role in helping the Afghans fight the Russians**: [Charlie Wilson’s War](https://en.wikipedia.org/wiki/Charlie_Wilson%27s_War_(film)) | (wikipedia.org) [17:15]

**Episode of Jocko Podcast with a SEAL from Vietnam**: [77: WAR STORIES. MENTAL TOUGHNESS AND CLEVER TACTICS IN VIETNAM AND FOR LIFE. WITH CWO ROGER HAYDEN](https://jockopodcast.com/2017/05/31/77-war-stories-mental-toughness-and-clever-tactics-in-vietnam-and-for-life-with-cwo-roger-hayden/) | (jockopodcast.com) [20:30]

**Vice News article about when ISIS was coming to Ramadi and the people of Ramadi were pleading for the American troops to come back**: [With the Islamic State Closing In on Ramadi, Iraqi Officials Demand Help from the US](https://news.vice.com/en_us/article/yw4yyk/with-the-islamic-state-closing-in-on-ramadi-iraqi-officials-demand-help-from-the-us) | David Enders (vice.com) [22:45]

**Scene from Office Space where they beat up the printer**: [Office Space – Printer Scene (UNCENSORED)](https://www.youtube.com/watch?v=N9wsjroVlu8) | RP (youtube.com) [38:45]

**Matthew Walker 3-part series on The Drive**: [40:30]

- Part 1: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
- Part 2: [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)
- Part 3: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/)

**Matthew Walker on the Joe Rogan Podcast**: [Joe Rogan Experience #1109 – Matthew Walker](https://www.youtube.com/watch?v=pwaWilO_Pig) | PowerfulJRE (youtube.com [40:30]

**Jocko’s tea**: [Jocko White Tea](https://www.jockotea.com/) | (jockotea.com) [44:00]

**Sleep tracking ring that Peter uses (and what Peter wants Jocko to use)**: [Oura Ring](https://ouraring.com/how-oura-works/?utm_source=google&utm_medium=cpc&gclid=Cj0KCQjwuLPnBRDjARIsACDzGL2IKA7sPYcYRcfff9Dsz0uNum6yt18ZJ1tRLqqTWpBRthdqskkh5sUaAmpHEALw_wcB) | (ouraring.com) [45:30]

**Product that cools your bedding from underneath that Jocko and Peter both use**: [ChiliPad](https://www.chilitechnology.com/) | ([chilitechnology.com](https://www.chilitechnology.com/)) [46:00]

**Peter’s favorite beverage**: [Topo Chico](https://www.topochicousa.net/) | (topochicousa.net) [49:00]

**A single night of missed sleep would alter the brain’s ability to clear amyloid and tau**: [Effect of 1 night of total sleep deprivation on cerebrospinal fluid β-amyloid 42 in healthy middle-aged men: a randomized clinical trial.](https://www.ncbi.nlm.nih.gov/pubmed/24887018) (Ooms et al., 2014) [50:30]

**The long swim Peter completed after contemplating quitting**: [Chesapeake Bay Bridge Swim](https://www.bayswim.com/) | (bayswim.com) [55:00]

**Jocko on Sam Harris’s podcast**: [#26 – THE LOGIC OF VIOLENCE](https://samharris.org/podcasts/the-logic-of-violence/) | (samharris.org) [1:04:15]

**Jocko on Tim Ferriss’s podcast**: [1:11:00]

- [The Scariest Navy SEAL Imaginable…And What He Taught Me (#107)](https://tim.blog/2015/09/25/jocko-willink/)
- [Jocko Willink on Discipline, Leadership, and Overcoming Doubt (#187)](https://tim.blog/2016/09/21/jocko-willink-on-discipline-leadership-and-overcoming-doubt/)
- [Discipline Equals Freedom — Jocko Willink (#275)](https://tim.blog/2017/10/20/discipline-equals-freedom/)

**Jocko’s mink chocolate chip protein supplement**: [JOCKO MÖLK](https://originmaine.com/origin-usa/nutrition/jocko/health/jocko-molk-mint-chocolate-protein/) | (originmaine.com) [1:13:15]

**Allulose recently approved by the FDA**: [Peter’s instagram post 5/4/2019](https://www.instagram.com/p/BxDzZ6EAvkA/) | (instagram.com) [1:14:30]

**Companies using allulose in their products**: [1:15:45]

- [Quest Nutrition](https://www.questnutrition.com/)
- [Know Foods](https://knowfoods.com/)

**Sleep supplements Peter uses for sleep while fasting**: [1:17:15]

- [Sleep Remedy by Doc Parsley](https://store.docparsley.com/) | (docparsley.com)
- [Phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine) | (wikipedia.org)

**Jocko’s favorite book**: [About Face](https://www.amazon.com/About-Face-Odyssey-American-Warrior/dp/0671695347) by Colonel David H. Hackworth (amazon.com) [1:25:45]

**Jocko’s video about the secret to waking up early**: [The Navy SEAL Spiritual Ritual For Overcoming Laziness](https://www.youtube.com/watch?v=h3U_VnOJ_UI) | CNBC Make It. (youtube.com) [1:26:45]

**Peter says Jocko is like a superhero to many people and shares his favorite quote from Spiderman movies**: [with great power comes great responsibility](https://www.youtube.com/watch?v=b23wrRfy7SM) | Tony Sokolski (youtube.com) [1:28:00]

§

## People Mentioned

- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (former SEAL, sleep expert, mutual friend) [5:00, 47:00]
- [Olivia Attia](https://peterattiamd.com/sneak-peek-peter-attia-drive/) (Peter’s daughter, guest Q&A session with Jocko) [5:30, 1:21:45]
- [Arkady Babchenko](https://en.wikipedia.org/wiki/Arkady_Babchenko) (Russian soldier who wrote about his experience in Chechnya: One Soldier’s War) [14:30]
- [Roger Hayden](https://www.youtube.com/watch?v=74JqZ2JgEPg) (SEAL vet from Vietnam, guest on Jocko Podcast) [20:30]
- [Saddam Hussein](https://en.wikipedia.org/wiki/Saddam_Hussein) (horrible person, however, not as religiously strict as some other dictators) [25:45]
- [Matthew Walker](https://twitter.com/sleepdiplomat?lang=en) (sleep expert, previous guest on The Drive) [40:30]
- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (former SEAL, sleep expert, and mutual friend) [47:00]
- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (free will) [1:03:30]
- [Tim Ferriss](https://twitter.com/tferriss) (has interviewed Jocko on his podcast) [1:11:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/05/jocko-bio-image-2-500x500.png)

##### Jocko Willink

Jocko Willink is a retired U.S. Navy SEAL officer, co-author of the #1 New York Times bestseller Extreme Ownership: How U.S. Navy SEALs Lead and Win, host of the top-rated Jocko Podcast, and co-founder of Echelon Front, where he serves as Chief Executive Officer, leadership instructor, speaker and strategic advisor. Jocko spent 20 years in the SEAL Teams, starting as an enlisted SEAL and rising through the ranks to become a SEAL officer. As commander of SEAL Team Three’s Task Unit Bruiser during the battle of Ramadi, he orchestrated SEAL operations that helped the “Ready First” Brigade of the U.S. Army’s First Armored Division bring stability to the violent, war-torn city. Task Unit Bruiser became the most highly decorated Special Operations Unit of the Iraq War.

Jocko returned from Iraq to serve as Officer-in-Charge of training for all West Coast SEAL Teams. There, he spearheaded the development of leadership training and personally instructed and mentored the next generation of SEAL leaders who have continued to perform with great success on the battlefield. Jocko is the recipient of the Silver Star, the Bronze Star, and numerous other personal and unit awards.

Upon retiring from the Navy, Jocko co-founded Echelon Front, a premier leadership consulting company, where he teaches the leadership principles he learned on the battlefield to help others lead and win. Jocko also authored the Discipline Equals Freedom Field Manual, a New York Times Bestseller, and the best selling children’s books: The Way of the Warrior Kid, and The Way of the Warrior Kid: Marc’s Mission.

[echelonfront.com]