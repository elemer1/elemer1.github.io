# Navigating bone health: early life influences and advanced strategies for improvement and injury prevention (#214 rebroadcast)

**Source:** [https://peterattiamd.com/bonehealth/](https://peterattiamd.com/bonehealth/)

---

In this episode from July 2022, Peter dives deep into the topic of bone health and explains why this is an important topic for everyone, from children to the elderly. He begins with an overview of bone mineral density, how it’s measured, how it changes over the course of life, and the variability between sexes largely due to changes in estrogen levels. From there he provides insights into ways that one can improve bone health, from exercise to nutrition supplements to drugs. Additionally, Peter discusses what happens when one may be forced to be sedentary (e.g., bedrest) and how you can work to minimize the damage during these periods.

While this original episode is an AMA, it is available in full to all listeners as a special rebroadcast.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/bonehealth/the_Drive_public.png)

Play

Navigating bone health: early life influences and advanced strategies for improvement and injury prevention (#214 rebroadcast)

Navigating bone health: early life influences and advanced strategies for improvement and injury prevention (#214 rebroadcast)

1x15s30s

0:001:31:43

## We discuss:

- Overview of bone health topics to be discussed [2:30];
- Bones 101: bone function, structure, and more [6:15];
- Bone mineral density (BMD), minerals in bone, role of osteoblasts and osteoclasts, and more [9:30];
- The consequences of poor bone health [14:30];
- The devastating nature of hip fractures: morbidity and mortality data [18:00];
- Where fractures tend to occur in the body [23:45];
- Defining osteopenia and osteoporosis [25:30];
- Measuring BMD with DEXA and how to interpret scores [28:00];
- Variability in BMD between sexes [35:15];
- When should people have their first bone mineral density scan? [37:45];
- How BMD changes throughout the life and how it differs between men and women [40:15];
- How changes in estrogen levels (e.g., menopause) impact bone health [45:15];
- Why HRT is not considered a standard of care for postmenopausal bone loss [49:00];
- Factors determining who may be at higher risk of poor bone health [52:00];
- Common drugs that can negatively impact BMD [55:45];
- How children can optimize bone health and lay the foundation for the future [59:30];
- Types of physical activity that can positively impact bone health [1:03:30];
- How weight loss can negatively impact bone health and how exercise can counteract those effects [1:12:15];
- Nutrition and supplements for bone health [1:16:00];
- Pharmaceutical drugs prescribed for those with low BMD [1:18:45];
- Impact of extreme sedentary periods (e.g., bedrest) and how to minimize their damage to bone [1:23:30]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Welcome to a special episode of *The Drive*, this week we are rebroadcasting our in-depth AMA #37 on bone health
- This was initially released to subscribers only, but we’re opening this one up to everybody
  - Those of you who are not subscribers can get a sense of what the AMAs are all about

In this episode, we discuss

- Why fracture related death rises steeply after the age of 65
  - Especially following hip and pelvic breaks
  - Why prevention must start decades earlier
- What bone mineral density [BMD] is and how DEXA scans measure it
  - How to read at T-score and Z-score
- How bone changes with age in men and women
- The outsize effects of menopause and estrogen loss
- The role of vitamin D, calcium, parathyroid hormone, and magnesium in bone turnover
- The difference between healthy bone, osteopenia, and osteoporosis
  - When each diagnosis is made
- Major risk factors for low BMD
- When to start screening (sooner than most guidelines suggest), and how often to repeat DEXA
- Which type of exercises best improve or preserve BMD
- Nutritional priorities for bone
- How weight loss without resistance training accelerates bone loss
  - Why combining diet with heavy load exercise can offset this
- Pharmacologic options when lifestyle options are not enough
- Strategies to minimize bone loss during bedrest or injury

## Overview of bone health topics to be discussed [2:30]

Today’s episode is all things bone health: bone mineral density, osteopenia, osteoporosis, things of that nature

- Why is this important?
- Why should people care about this?

“*Our hope is in the beginning at least we’ll walk through why they should care about this and why they should focus on it early on in life*.”

- We’ll talk about how bone health changes as people age, the differences between sexes in men and women
- Then we’ll also focus on things on how people can improve or help their bone health become better from physical activity to nutrition, supplements, drugs, and more

## Bones 101: bone function, structure, and more [6:15]

**What is bone?**

- Bone is a living tissue
- It’s easy to forget this fact and think of bone as somewhat inert
- But bone is heavily vascularized
- Bone is an organ that plays a very important role in a lot of things

**Common bone types**

- **Cortical/compact** bone is what forms the “shaft” and the exterior of long bones
  - Femur, humerus, etc. — they have the long shaft and then the nubbins at the end
  - The shaft of that is the cortical or compact bone
- You also have the **trabecular bone/spongy bone**
  - There are some differences amongst those in terms of their vascularization and things like that
- For the purpose of this discussion…
  - when discussing the compact or cortical bone, Peter is referring to the shaft
  - And when speaking about the spongy/trabecular part, he’s talking about the end

**Bone marrow**

- Marrow is important because it is what’s producing our white cells and our red blood cells
- In a post COVID world, it’s important to understand that the memory B cells and memory T-cells that are going to provide lasting immunity against this virus and other viruses, reside in the bone marrow
- The whole purpose of being infected and then having a subsequent infection that’s less devastating, (and purpose of being vaccinated) for the same reason is to have memory B cells and T-cells that are sitting there in the bone marrow that can respond immediately and quickly upon reintroduction of the same antigen

## Bone mineral density (BMD), minerals in bone, role of osteoblasts and osteoclasts, and more [9:30]

**Osteoblasts and osteoclasts**

- Osteoblasts—“B” for blast
  - These are responsible for building bone by producing collagen bone matrix and mineralizing it
- Osteoclasts
  - These remove bone by reabsorbing calcified bone and the matrix
- So osteoblasts contribute to increasing bone mineral density
- Osteoclasts the opposite
- This exists in an equilibrium—We’re constantly remodeling bone, adding to and subtracting from this and basically turning over calcium

Bone minerals

- bone is 50 to 70% mineral
- It’s about 20 to 40% organic matrix
- What does organic mean?
  - Organic is carbon, hydrogen, oxygen, etc.
- Then the rest of it is a bit of water and lipid.
- In an adult, the entire human skeletal system can be remodeled in a really long cycle
  - It might take 10 years to turn over all of the mineral and organic content within the bone over and over again
- At the micro level, **calcium balance**is happening quite frequently
  - virtually all of the body’s calcium is contained within bone and therefore bone plays a very important role in calcium homeostasis
- Calcium signaling is important to *everything within a cell*
- We think of these bones as structural entities, which of course first and foremost they are. But remember, they’re also a very important reservoir for calcium, which is another very important ion in the activity of every cell

*What role does vitamin D play in the bones?*

- There’s two forms of vitamin D, vitamin D2 and D3
- D3 is the active form
- What’s the problem with being deficient in vitamin D?
  - There’s a disease called rickets
  - And you see this often in developing parts of the world where people are really malnourished and they have really, really soft sort of spongy bone
- Vitamin D increases the gut’s absorption of calcium
- If you’re woefully deficient in vitamin D, you’re going to have trouble absorbing calcium through the gut

**Parathyroid hormone**

- The other thing that you can’t avoid here is understanding the role of calcium and [parathyroid hormone](https://en.wikipedia.org/wiki/Parathyroid_hormone)
- Most people are probably familiar with their thyroid gland—sits in the neck and it’s got two main lobes and then each lobe has two poles
  - At each of those poles is a little tiny gland called the parathyroid gland (so you have four of those glands)
- And the parathyroid gland is really the **master gland for regulating calcium levels**
- Low levels of calcium in the blood stimulate parathyroid hormone secretion
- As parathyroid hormone level goes up, it stimulates the release of calcium from the bone into the blood
- Now it also induces enzymes in the kidney, which then convert vitamin D into its active form to then aid and speed up in the process of reabsorbing more calcium from the diet

So all of this stuff—*parathyroid hormone, calcium, vitamin D*—are very important to maintaining bone health

- Anytime you have things that disrupt that system, you’re going to see disruptions potentially in the bones

## The consequences of poor bone health [14:30]

Five years ago, Peter was not paying nearly as much attention to bone health as he is today

![](https://peterattiamd.com/wp-content/uploads/2022/07/f1-ama37-1024x549.png)

**Figure 1. Accidental deaths.** Source: CDC database (<https://www.cdc.gov/nchs>), 2019

- - We use 2019 b/c by the time you get to 2020, you start to get some COVID data mixed in there
  - Although the accidental stuff only changes in that you see a higher rate of overdose
  - In Figure 1, you’re looking at the absolute number of deaths by decade for people age 25 to 35, all the way up to 85 and up
  - It breaks down accidental deaths into four categories:
    - 1) Overdoses
    - 2) Transportation accidents (car accidents)
    - 3) Falls
    - 4) And everything else.
  - Those first three represent virtually all accidental deaths
- T*wo main things stand out when looking at this*:
- - The first is that for people younger than 60, overdoses are the predominant cause of accidental death
  - The second is that for people over 65, falling is the primary cause

![](https://peterattiamd.com/wp-content/uploads/2022/07/f2-ama37-1024x532.png)

**Figure 2. Accidental deaths (Population Adjusted).**Source: CDC database ([www.cdc.gov/nchs](https://www.cdc.gov/nchs)), 2019

- Figure 2 tells a more important story when you adjust for the population
- In Figure 1, you’re seeing total number of deaths, but what you don’t realize is that as you move left to right, the denominator, the population is getting smaller and smaller and smaller
  - There are fewer and fewer people in each bucket as you go to the right
- So to correct for that, we would ask the question which is: *how many of these deaths per hundred thousand people occur in each group*?
- Figure 2 tells a story that is readily apparent: **By the time you’re 75, the risk of death from a fall is enormous**
  - It’s not as high as Alzheimer’s disease, cancer, or heart disease, but it comes in pretty much just after that
- On the one hand, you can look at these data and say, “wow, this is really problematic”
- But the other point is that **you can’t wait until you’re in that bucket to decide you’re going to do something about it**
  - Just as for atherosclerosis, we don’t want to wait until we’ve had our first heart attack. I really need to worry about my ApoB and maybe I should stop smoking and make sure my blood pressure’s okay.
  - In the same way, you don’t want to wait until you have osteopenia or osteoporosis and you’re 60 years old to say, it’s time to do something about this
  - Now, if you’re there, there’s lots to do about
  - But it’s just as important if you’re 25 years old.
- It’s just as important as a parent if you’re thinking about what your 5 year-old and 10 year-old and 15 year-old should be doing to make sure that they’re setting themselves up for the best outcomes possible as they age

## The devastating nature of hip fractures: morbidity and mortality data [18:00]

![](https://peterattiamd.com/wp-content/uploads/2022/07/f3-ama37-922x1024.png)

**Figure 3. Absolute risk for all-cause mortality for women and men following hip fracture.** Source: [Haentjens. et al., Ann Intern Med, 2010](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3010729/)

- Figure 3 is showing excess mortality following a hip fracture for women (top chart) and men (bottom chart)
- Fractures that end lives tend to be hip fractures first, followed by pelvic fractures
- This shows mortality following a hip fracture as a function of age
- “*This is kind of staggering*”, says Peter
- If you’re a man that is 90 years old or above and you have a hip fracture, more than 40% of you will be dead within a year
  - Now that total mortality comes down because there’s fewer people in that group (i.e., most people die before 90)
- But you can see for the younger demographics, the numbers go up
- The “good” news? ⇒ If you’re 70 years old and you break your hip, only 10% of those people are going to be dead in three years, but that number just keeps going up and up and up.
- The important thing to notice in this data set is that **for people over the age of 80, your mortality is in the neighborhood of a third within a year after a hip fracture**

\*Peter is going to have [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) on the podcast coming up soon

- He wrote a book called [The Comfort Crisis](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) – a book Peter highly recommends
- In the book, Easter makes some references to a few studies that talk about some of the unbelievable high mortalities in other fractions

One [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845770/#:~:text=Despite%20improvements%20in%20the%20treatment,care%20(4-6).) had about 200 people in it

- It looked at the six-month mortality in people who were 65 or older who fractured their hip and the mortality was 25%
- Obviously, when you include younger people, that mortality goes way down.
- If they lowered the threshold in that study to people 50 and older, that mortality came down to just under 14%.

A [Finnish study](https://bmcmusculoskeletdisord.biomedcentral.com/articles/10.1186/1471-2474-12-105) that looked at a little over 400 consecutive hip fractures in patients

- found that the one year postoperative mortality was just over 27%.
- totally different patient population, and by the way, a different country, very similar trend

The most rigorous of these studies was a [large study](https://onlinelibrary.wiley.com/doi/10.1111/joim.12586) that looked at about 122,000 participants who were at least 60 years old from various cohorts

- Followed them for 12 or 13 years on average
- During that time found 4,200 hip fractures
- This study was able to then compare total mortality and look at the hazard ratio in the first year following the hip fracture
- So now this is asking the question, *what is the probability or what is the increased risk of death one year following the hip fracture in this patient population*?
- Again, these are people enrolled at the age of 60 or beyond
- The hazard ratio is 2.78
  - For reference, the hazard ratio for smoking is less than 2.0
- This means a 178% increase in the risk of mortality within one year following a hip fracture

> “Regardless of how you slice and dice these data, a hip fracture is a devastating outcome and it’s something that we really want to avoid at any age, but especially when we’re into our seventh decade and beyond.” —Peter Attia

## Where fractures tend to occur in the body [23:45]

![](https://peterattiamd.com/wp-content/uploads/2022/07/f4-ama37-1024x732.png)

**Figure 4. Fracture statistics, in order of decreasing mean age, in patients over 50, 65, and 75 years of age.** Source: [Bergh et al., PLoS One, 2020](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0244291)

- This table is looking at all the sites of fractures
- In the first column, it’s showing you how many fractures occurred in this study
- It’s ranking it by *median age*
- Peter highlighted the first one, which is proximal femur (hip fractures)
- Not only are those highly frequent—4,000 fractures—but look at the median age of 81.1
  - Pelvis is 73.2
  - Neck of the femur, 70
  - Distal femur, 70
  - Acetabulum, which is the cup that holds the femoral head, 68
  - Then down to proximal humerus, so the top of the humeral bone, 66
  - Those are the big fractures for people over the age of 65.
- You can see the frequency of proximal humerus and proximal femur are very high

You can go through this list and it’s really telling about how people fall…

- What’s a distal radius fracture? ⇒ It’s a fracture at the end of your hand
  - How does someone break that? ⇒ They break that by falling
- “***You sort of get a sense of how balance, strength impact a lot of these things***.”

## Defining osteopenia and osteoporosis [25:30]

![](https://peterattiamd.com/wp-content/uploads/2022/07/f5-ama37-1024x661.png)

**Figure 5. Loss of bone mass in decline from healthy bone to osteoporosis.** Source: [Advocate Medical Group](https://adscresources.advocatehealth.com/resources/osteoporosis-and-osteopenia-low-bone-density/): Adult Down Syndrome Center.

- - On the left of this figure, you see the healthy bone
    - It’s got that little inlet beneath it—that’s showing you the density of the calcified mineral that makes up the strong part of the bone
  - Osteopenia and osteoporosis just **exists on a continuum relative to healthy bone**
    - When you go from healthy bone to osteopenia, that represents about a 10% reduction in bone mineral density relative to a young healthy adult
    - Osteoporosis is a further degradation where you hit about 25% reduction.
- *There are two things to add to this to make it sort of rigorous*

- - The first is the diagnosis of osteopenia and osteoporosis is based on two locations
    - 1) the hips
    - 2) the lumbar spine
  - For anybody who’s gone and had a DEXA scan before, you may notice that they report the Z-score and T-score of the lumbar spine, of the left hip, the right hip, and usually of the entire body
  - The reason for that is: we use left hip, right hip, lumbar spine (L1 to L5) to make this diagnosis
  - The reason for that is that’s where the fractures are
  - We see people that have atraumatic fractures, compression fractures in the lumbar spine
  - The majority of fractures in older people are in the hip and the mortality for those fractures is very high
- Summary: osteopenia means 10% reduction in BMD and osteoporosis means 25% reduction in BMD

“***Healthy bone to osteopenia, to osteoporosis, it’s just a continuum, but osteoporosis and osteopenia are distinct in the degrees to which BMD has been reduced***.”

## Measuring BMD with DEXA and how to interpret scores [28:00]

***What’s the best way for listeners to figure out what their BMD is?***

- DEXA is a super, super low radiation scan, nothing like a CT scan
- Takes 10 minutes, you lay on a table, a little scanner moves over your body, and it’s using two very low dose X-rays that are absorbed differentially by bones and soft tissues, so it’s able to differentiate between adipose tissue, bone and lean tissue, or non-adipose tissue
- That said, not all DEXA scanners are created equal
- Before you go and get the DEXA scan confirm with the entity doing this that they are giving you **segmental bone analysis for left hip, right hip, lumbar spine**.
- A lot of DEXA places can only give you whole body BMD so they’ll just spit out the Z-score for that one metric, but they won’t give it to you segmentally
- And that’s sometimes okay, like if a person’s BMD is very high, you don’t need the segmental analysis, but if you’re doing this to screen for BMD, you have to make sure of course that the DEXA is capable of doing that

**Getting a DEXA scan for yourself**

- It’s pretty easy to find places near you offering DEXA scans, however, you need to know what you are getting
- You want to make sure when you’re doing a DEXA, again, if you care about knowing the full BMD, you’re going to pay more for that segmental analysis
- Many times places will quote a price in the $100 range but a lot of times they aren’t showing everything — they’re just giving you body composition, and usually visceral fat
- Price is probably closer to $400, typically, if you want to see everything
- The other things you want to look at, you obviously want to make sure you’re getting full segmental lean tissue analysis, so you can look at appendicular lean mass index that you can calculate for yourself
- Fat-free mass index you can calculate for yourself
- Those are the things you want to see along with BMD

*Is there variability among people? How to interpret your DEXA scores (Z score and T score)?*

- The number you’re going to get is not typically going to be reported in grams per centimeter cubed for your BMD because that information is not that helpful
- What you really need to know is statistically, *where do you rank?*
- And this is done via:
  - T-score (comparing you to a young, healthy adult); and a
  - Z-score (comparing you to an adult that is your age)

**Understanding Z-score**:

- A Z-Score of 0 means you are right in the middle of the distribution—meaning you have a higher bone mineral density than 50% of people your age, and a lower bone density than 50% of people you age
- If your Z-Score is 1.0 it means you are one standard deviation above the mean, which means you have a higher bone density than 82.5% of the people your age and a lower bone density than 17.5% of the population your age
- A Z-Score of 2.0 means you are two standard deviations above the mean (higher than 97.5% of the population your age)
- Of course, this works in reverse so a Z-Score of -2.0 means you have a lower bone density than 97.5% of people your age

**T-score**

- Your T-score compares you to a young, healthy adult
- So for someone who’s older, the Z-Score is always going to be more favorable than the T-score

*For BMD, if someone is at that 50th percentile, does that worry you, or is it a little different in how you look at this?*

- Peter says other things factor into this
  - Family history
  - history of smoking
  - current lifestyle
  - How active is that person?
  - How much weight-bearing activity are they doing?
  - Being male versus female also factors into it a lot
- Let’s say I’ve got a 42-year-old female patient who is three to five years out from menopause and she already has a low Z-Score
  - “That worries me a lot because of what we’ll talk about shortly, vis-à-vis the effect of estrogen here and why women are disproportionately affected by estrogen withdrawal”

> “Never in the history of civilization has a 90-year-old person ever been heard uttering, ‘I wish I was less strong. I wish I had less muscle. I wish my bone density wasn’t so high.’” —Peter Attia

## Variability in BMD between sexes [35:15]

![](https://peterattiamd.com/wp-content/uploads/2022/07/f6-ama37-782x1024.png)

**Figure 6. Smoothed mean total lumbar spine bone mineral density, United States, 2005–2008.**Source: [Looker et al., Vital Health Stat 11, 2012](https://pubmed.ncbi.nlm.nih.gov/24261130/)

- Here we’re looking at males versus females top to bottom
- Then we’re looking at Mexican-American, non-Hispanic White, non-Hispanic Black
- On the Y axis here, you’re seeing units of grams centimeter squared — Earlier, Peter said grams centimeter cubed. *Why the difference?*
  - The difference is even though density in real life is measured in grams per centimeter cubed, because you need mass per unit volume, with bone density it’s actually done as grams per centimeter squared, because it’s a plainer measurement
  - So the DEXA scan is compressing everything to 2D
  - Because the scanner is kind of looking at the area of the bone and imputing the density by what electron beam doesn’t go through it

*Two observations that one would pretty quickly take away from this*

- The first is that up until the twenties, men and women are kind of similar
  - You go through a profound increase in BMD from the time you’re 8 years old until you’re about 20 years old
- Difference number one is that, while women maintain a reasonable plateau, they tend to fall quite precipitously in midlife, and that’s obviously due to menopause
- The second thing that jumps out here is the racial difference
  - Non-Hispanic Black has a higher BMD for both men and women than non-Hispanic White, which has a higher BMD than Mexican-American
  - So there are slight differences in race on average
- However, Peter says “I’ve never, to be honest with you, factored [race] into my risk assessment, except for the male female one.”

## When should people have their first bone mineral density scan? [37:45]

**The standard recommendations**

- Using the American Association of Family Physicians, the American College of Obstetricians and Gynecologists, the American College of Preventative Medicine, the International Society of Clinical Densitometry, the National Osteoporosis Foundation and more
- The typical recommendation is for high risk people to be 50, but typically 65 is when they want to start screening women, and for men it’s typically 70
- For someone who is at serious risk of osteoporosis, which includes men and women over the age of 50, we can adjust those and come down a little bit
- The WHO is a little bit more aggressive and recommends screening women by the age of 40

*Peter’s thoughts*

- Peter tends to be closer in his thinking to the WHO
- Peter believes women in their thirties, when we’re doing DEXA scans for many reasons, he’s just as interested in their bone mineral density
- When he’s reporting the DEXA results to patients, he has a template that he’s made that lays all of the DEXA information out
  - Segmental BMD
  - VAT
  - FFMI
  - ALMI
  - FMI
  - Body fat
    - NOTE: Body fat is the number Peter is least concerned about
- Example: When Peter’s looking at a 35-year-old patient and their Z-Score is already -1.0, that’s just as concerning as if their OGTT shows very elevated postprandial glucose and insulin levels

## How BMD changes throughout the life and how it differs between men and women [40:15]

**Men vs. women**

- Men and women differ quite a bit
- Most of the growth in the length of a bone and the size of the bone is happening during childhood and adolescence
- That’s also when you’re really accumulating the bulk of BMD
  - For instance, between about the ages of about 8 and 20, BMD was doubling
  - That doesn’t just mean that the size of the bones are increasing, but that the density of those bones is also increasing dramatically
  - BMD will actually potentially improve up to about the age of 30
  - It can stay quite flat, in both sexes, until you’re about 40 or 50, and then bone loss effectively sinks in
- For **women**, it is much more pronounced
  - For women, about seven to 10 years around the onset of menopause, bone loss can be three to 7% annually
  - By the time they reach 65, it starts to slow down a bit, so it might be half a percent to 2% per year
- Whereas in **men** over 65, it’s actually a higher rate of bone loss, but they’re starting at a much higher point, because they didn’t suffer that precipitous loss the way women did after menopause
  - For men at age of 65, it’s more typically about 1% to 2% per year

![](https://peterattiamd.com/wp-content/uploads/2022/07/f7-ama37-1024x741.png)

**Figure 7. Bone Mass Versus Age With Optimal and Suboptimal Bone Acquisition.**Source: [Heaney et al., Osteoporosis Int, 2000](https://www.ncbi.nlm.nih.gov/books/NBK45503/figure/ch6.f2/?report=objectonly#)

- This figure is showing bone mass by age for women
- “*When I came across this figure…I was really surprised*.” says Peter

*Two things really stand out*

- First, you have this pretty significant rise in bone density between birth and age 20
  - It then remains relatively plateaued until menopause kicks in around 50, and then you really start to see the fall.
- Secondly, look at the dotted line
  - The dotted line tells you that there’s really a totally separate trajectory for this woman
  - If she didn’t reach her full genetic potential by the age of 20, she’s missed an enormous opportunity later in life
  - This is why you want to make sure that your kid’s doing the right things when they’re 10 to 20, so that they reach their full genetic potential.
- *The good news*:
  - Let’s say you’re on that dotted line and you’re 30 years old with a z-score of -2.0
  - The good news is we can get her closer to that solid line by working really, really hard
  - There’s this window in time before menopause when we can try to ratchet up that bone mass so that you get to the highest point when menopause kicks in

![](https://peterattiamd.com/wp-content/uploads/2022/07/f8-ama37-1024x650.png)

**Figure 8. Age-related BMD loss in both cortical and trabecular bones in women and men.**Source: [Qin et al., J Orthop Translat., 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6718925/)

- This really shows where the bone loss is occurring
- For both male and female, you’re the difference between cortical and trabecular bone
- Remember cortical is the long shaft part of the bone, the trabeculae are the end
- So you’re seeing the decline for men and women in both of these segments
- What stands out here is where females are losing this BMD—They’re losing it primarily in the trabecular/spongy part of the bone
- Interestingly, women are no different than men when it comes to the cortical section of bone

## How changes in estrogen levels (e.g., menopause) impact bone health [45:15]

*Think about how muscles act…*

- A muscle by definition has to have attachments to bones
- a muscle’s never attached to the same bone, because then it wouldn’t do anything, the muscles have to go across joints
- For instance, your bicep actually crosses a couple of joints. You have a bicep that is attached to the bones of the lower arm and then attached to the bones of the upper arm, and so then when it contracts, it actually closes that angle of the arm
- so muscles are attached via tendons to bones

*Now think about the load we put on those muscles…*

- The very simple laws of physics tell you that the bones have to feel that load
- We often just think about if you’re doing a curl with 40 pounds and your bicep muscle is exposed to that
- But guess what? … The tendon that is attaching the bicep above and below the joint of the elbow is also feeling that
- The bone cells actually sense that load
- So if you’re lifting something heavy, or climbing stairs, your bone senses that they need to support a greater force, and in response to that it remodels by depositing more and more bone tissue

> “Bone mass increases in the presence of stress.” —Peter Attia

**Role of estrogen**

- It turns out that signaling process to deposit more bone tissue is regulated very heavily by estrogen (although it’s unclear WHY estrogen is the hormone that does this as opposed to a different hormone)
- But for what it’s worth, that signal of stress that is basically being relayed by the strain gauge within the bone to say, “hey, it’s time to deposit more bone here.” And that’s modulated by estrogen
- In the absence of estrogen, that signal gets reduced and that’s effectively why menopause, which is a sudden withdrawal of estrogen, is such a devastating thing for women who don’t have their hormones replaced
- And that’s why BMD loss is significant in the postmenopausal woman

***What about men?***

- Men are also losing estrogen as they age
- Because for men, estrogen comes primarily from testosterone conversion—testosterone is aromatized into estrogen
- A man with a testosterone of 800 nanograms per deciliter, all things equal, is going to have a higher estrogen level than one with 300 nanograms per deciliter
  - Now there are other factors that go into that, such as adiposity wich can give you more estrogen—This might be one example where adiposity helps because you have the additional weight and load that is a strain signal, and you have more estrogen, all things equal
- “But men lose estrogen at a far more gradual rate than women, and that’s why **women experience this loss more significantly making them at greater risk for osteopenia and osteoporosis**

## Why HRT is not considered a standard of care for postmenopausal bone loss [49:00]

***Knowing estrogen’s role in bone health for postmenopausal women, should bone health be a factor to consider in women who are thinking about starting HRT?***

- The consensus answer? “*No, HRT is not considered standard of care for postmenopausal bone loss*”

*Why is this the current consensus?*

- The reason for that is NOT because HRT was NOT found to decrease fracture risk
- The [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative), [published](https://jamanetwork.com/journals/jama/fullarticle/195120) over 20 years ago, was a seven-year study looking at the administration of hormone replacement therapy on postmenopausal women
- In that study, there was no ambiguity that the **fracture risk was decreased** in the women taking HRT
- However, that study came to an erroneous conclusion (in Peter’s opinion) that the risk of breast cancer and cardiovascular disease went up
- And those risks seem to outweigh the benefits of the reduced fracture risk
- Peter thinks the increase in the risk of breast cancer was virtually nonexistent—It had an absolute risk increase of 0.1%
- Today, we can say with much more clarity that the risk of breast cancer from hormone replacement therapy is virtually nonexistent
- Secondly, the risk of cardiovascular disease has been completely ameliorated by the adoption of topical forms of estradiol, as opposed to oral forms of estradiol
- In that trial, they used oral estrogen, which actually does slightly increase the viscosity of blood in a susceptible woman, that would indeed increase the risk of cardiovascular disease.
- But again, we don’t use oral estrogen anymore, and so that also becomes a moot point
- Today, we actually know that HRT reduces the risk of cardiovascular disease in women, and does not increase it
- Taking all together, these suggest to Peter that bone health should in fact be a consideration for women as they consider whether or not HRT makes sense for them

⇒ For people who want to get a better sense of HRT should listen to [podcast #37 with Avrum Bluming and Carol Tavris](https://peterattiamd.com/caroltavris-avrumbluming/)

## Factors determining who may be at higher risk of poor bone health [52:00]

Some factors that matter:

- Family history
- Genetics accounted for up to 50% of bone health
- Having either parent that’s had a history of a hip fracture, that’s a huge red flag

There are other things we want to care about:

- So we want to look at fractures related to mild or moderate trauma
- You look at somebody who’s had a fall from a standing height or less, someone who’s fallen from such a low height and still had a fracture, that’s a huge problem

Female Athletes

- Another thing we look at is in female athletes
- This is really common actually in female endurance athletes, especially runners where weight is such an important part of the sport
- You’re punished a lot in terms of performance for extra weight, same as true in cycling, not as true in swimming
- When you look at high-end female endurance athletes, we care a lot about poor nutritional state, which can lead to a very low BMI, low body fat percent, and eventually estrogen deficiency
- These interrelated conditions of the low bone health, hormone dysfunction, and low BMI are collectively known as the female athlete triad
- Low BMI in general, so anything below about 18 or 19.

The other thing we look at is people who have had high exposure to drugs that affect bone metabolism

- The most common of these that we see is corticosteroids
- that’s not always systemic corticosteroids, not always people that have had to take lots of steroids for an illness
- It can also be inhaled corticosteroids
- this actually in a number of patients who had significant asthma as children, and used a lot of inhaled corticosteroids

\*Note: The above is not an exhaustive list, but that’s a pretty good list to get you thinking about who is at high risk here.

**Smoking and bone density [52:30]**

- Peter saw a patient recently who didn’t have any other risk factors, except for the fact that they have a 20 pack-year smoke history that is more than 15 years old
- That is an independent risk factor for low BMD, which in this case, this patient had very low BMD.
- Peter had to actually refer them to an endocrinologist

*-Smoking in youth*

- The 8 to 20 age is such a big age range—And if you have someone who is smoking in that age range while bone mineral density is really going up, *do you see it become even worse?*
- There are actually [data](https://asbmr.onlinelibrary.wiley.com/doi/full/10.1359/jbmr.090809) looking at never smokers, early smokers and late smokers
- Early smokers were defined as people who started smoking before the age of 16
- The never smokers, not surprisingly, had the best bone density
- The early smokers had the worst, and the late smokers were in the middle

## Common drugs that can negatively impact BMD [55:45]

**Corticosteroids**

- These have to be considered the first and most important one of these drugs you want to be considerate about
- They impair the mineralization of bone by favoring bone reabsorption during the early phase
- And then they kind of inhibit calcium absorption in the gut.
- And it really doesn’t need to be mega doses of steroids
- A dose of prednisone of 5mg a day is not enormous
- Nevertheless, that amount is associated with significant reductions in bone mineral density, and an increased risk fracture within as little as three to six months of initiation ([source](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4319192/))
- That doesn’t mean you should never take corticosteroids, there are lots of conditions where corticosteroids are going to save your life
- It means you have to be aware of these things, and you’re going to have to work a lot harder to counter their effects

**Proton pump inhibitors (PPIs)**

- There are [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6540255/) that have assessed the relationship between PPIs, and they do show an increase in osteoporotic fracture
- The most likely mechanism suggested is intestinal calcium absorption—anything that interrupts that, which then goes on to interrupt osteoclast formation and bone remodeling
- This is not nearly as well understood as the case is for corticosteroids
- There’s a number of observational studies that show an increase in the risk of fracture.
- Then we look at large [meta-analyses](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3101476/#:~:text=In%20this%20study%20level%20meta,in%20both%20men%20and%20women.) that don’t find a statistically significant decline in BMD with PPI use
- you just have to be smart about this.
- There are lots of reasons we’re going to put patients on PPIs
- If a patient has significant reflux that is not amenable to other treatments, we’re going to put them on a PPI
- If a patient has Barrett’s esophagus, we’re putting them on a PPI, it’s non-negotiable
- So it just means that we have to be thoughtful about is the drug really indicated? And if it is, what else can we do to reduce the risk down the line?

**Antiepileptic drugs**

- the final class of drugs that tend to have a similar association, although probably from a different mechanism are some of the antiepileptic drugs
- one in particular, which is [phenytoin](https://en.wikipedia.org/wiki/Phenytoin), so a super common anti-seizure drug
- The mechanism might have more to do with liver inducing an enzyme called cytochrome P450, that leads to increased catabolism of vitamin D
- And that, of course you may recall, will lead to decreased absorption of calcium in the gut.
- Peter says, “it seems to me that a no-brainer study would be taking patients on phenytoin and supplementing them with lots of vitamin D to see if you can overcome tha”
- But again, phenytoin is a common drug within the world of antiseizure meds, but in the big picture, nowhere near as common as corticosteroids and proton pump inhibitors

## How children can optimize bone health and lay the foundation for the future [59:30]

***Any advice Peter can give that would have for people who have kids, on those very important ages, the 8 to 20, on what they can do so they can really optimize bone health?***

- During this relatively narrow window that your kids are in your house, and therefore somewhat amenable to your influence
- The most important thing probably comes down to being **adequately nourished** and being **very active**
- And in particular, being very active in things that load bones.

*Surprising finding*

- One of the things that was a bit surprising was that running didn’t have a greater impact on BMD
- Peter posits that there is a confounder in there
- Because if you think about it, running puts a lot of force on muscles, especially when you think about the hips, which are two of the three bones that are attached to muscles, that experience great force during running
- Why is it that running where you’re potentially at least at the knees experiencing eight times your body weight with each impact, why wouldn’t that do more?
- Peter’s suspicion is that the confounder here is body weight and BMI
- And that when you talk about elite runners, and usually these are studied in elite runners, they’re very weight conscious
- Running and cycling are the ultimate strength to weight ratio sports
- So Peter wonders if we’re seeing basically malnourished runners
- Basically, people that are, BMI is too low which might be perfect for being a runner, but it’s too low for optimizing bone mineral density
- This is a “long winded way of saying, running might not be enough”
- You probably want to make sure that your kids, both boys and girls, are doing other sports that involve more power—things that involve j*umping, and actually lifting heavy things*

**Rucking**

- Peter emphasizes [rucking](https://www.goruck.com/pages/what-is-rucking) as a great exercise for BMD
- Michael Easter writes about rucking in his book, [The Comfort Crisis](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) about the importance of just walking with heavy stuff, either doing a farmer’s carry or doing a ruck
- Peter personally tries to ruck five days a week backpack with weight in it and just walking around, and always trying to find a hill to walk up and down

*Going back to advice for kids…*

- Make sure BMI is not too low
- Hormone dysfunction is not there
- Energy availability is there
- Body fat is not too low
- Make sure kids are not smoking
- Summary: Lots of nutrition, lots of physical activity—and specifically physical activity that builds muscular strength
- Now, this doesn’t mean that 12-year-olds need to be deadlifting three times their body weight, but we also don’t want to shy away from kids lifting things

> “*The bones are mechanical sensory entities that are going to remodel in proportion to how much mechanical stress they’re under…so lifting heavy stuff matters*.” —Peter Attia

## Types of physical activity that can positively impact bone health [1:03:30]

**Overview**:

- Peter wants to go back to what it is about muscles that have such an impact on bones
- The more force that a muscle is applying to a bone, which is directly related to how much force you are trying to put on the muscle, picking something up, contracting a muscle under an enormous external load
- “I don’t even think the muscle has to change in length necessarily for that force to be experienced. So there are lots of safe ways to do this”
- You’re applying force to the receptors there, those receptors are translating that tension into signals that say, lay down more bone

Looking at the [literature](https://www.journalofexerciseandnutrition.com/index.php/JEN/article/view/10/7) on this

- Peter was surprised about the data on running – he thought it would be more impactful on BMD than it was
- It turned out that studies looking at resistance training found it to be significantly better at retaining BMD when compared to anything aerobic (running, swimming, cycling, and even impact things like pure jumping)
- power lifting turned out to be more effective than just regular strength training in maintaining BMD in postmenopausal women
  - When we talk about powerlifting as a sport, we’re talking about someone doing a squat, a deadlift, and a bench press
  - And the squat and the deadlift, that is lumbar spine, that is hip and that is really stressing the lower body more than just going into the gym and lifting
- Then we talk about high force impact sports, such as football and MMA, were associated with the highest BMD values
- At dinner with [Joe Rogan](https://twitter.com/joerogan/), Peter says Joe claimed that nothing is more exhausting than his jiu-jitsu workouts

On the flip side…

- These low weight bearing, low impact things like walking, swimming and cycling, don’t really seem to do a lot to improve BMD
- Peter’s suspicion is that when you make those things a little bit harder, especially with walking with a rucksack and walking uphill, you’re going to apply more strain
- Also walking downhill is great
- Peter says to find the maximum elevation change
- Walking uphill is harder cardio, but the walking downhill puts more strain on the muscle

> “The take home point here is, the more this strains your muscles, the better this is for your bones.” —Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2022/07/f9-ama37-1024x433.png)

**Figure 9. BMD and T-scores from DXA scans collected for n=135 competitive athletes. MMA = mixed martial arts, RT = resistance training, SUP = stand up paddling.**Source: [Antonio et al., J Exerc & Nut., 2018](https://www.journalofexerciseandnutrition.com/index.php/JEN/article/view/10/7)

- On the left, you’re just looking at the absolute BMDs
- All of these athletes have very high BMDs compared to what we were looking at as the average man and the average woman
- 1.2 grams per centimeter squared was considered a really good BMD for a middle aged man or woman
- Just to put in perspective, even the swimmers or the resistance training females, and females are tend to going to be a little bit lower than men. They still have excellent BMDs

The **take-home message**: if you really have to juice it, *what do you want to be doing?*

- Even the distance runners here, look at which ones separate men versus women—So for example, red (men) versus green (women) is showing you the difference between male and female **resistance training**
- Whereas all the swimmers, all the distance runners, all the track and field athletes are in the same bucket
- Compare distance to track and field, what’s the difference?
  - Track and field, more power.
  - A sprinter has more force being applied than a distance runner
- The amazing result is the MMA and the football
  - The purpose of this analysis is not to say you got to go be a college football player — it’s to just give you a sense of what types of forces are involved in generating higher BMD
  - Most people who have even watched a football game can appreciate the kind of forces that those athletes are experiencing
  - With MMA, there are incredibly strong forces applied across muscles, transmitted to bones.

***So what’s the sweet spot?***

- The sweet spot is resistance training
- All of these things come with risk if you don’t do them correctly
- we just have to think about this through a risk/reward lens
- If you’re going to take one thing away from this, just notice that walking isn’t on here and gardening is not on here and golf is not on here

> “I want people to understand that if they’re in the business of trying to increase their BMD, they have to get wicked forces on their muscles.” —Peter Attia

## How weight loss can negatively impact bone health and how exercise can counteract those effects [1:12:15]

***What about people who are overweight and they lose body weight? Does that have an impact on their BMD?***

- It does
- We know for example, that when people lose significant amounts of weight, they’re usually losing lean tissue as well
- It’s one of the trade offs—and in some people it’s a totally reasonable trade off
  - For instance, you see somebody who’s already got an appendicular lean mass index at the 90th percentile and their fat mass index is at the 99th percentile
  - You’re going to have them lift like crazy during weight loss, because you want to keep that lean mass up
  - Maybe it falls to 70th or 80th percentile while you try to get fat mass index down to 60th or 70th percentile

*What about the impact on BMD?*

- There’s no question that the correlation between weight loss and a decrease in BMD
- In the obese, in particular in the elderly, it is very strong
- But it turns out that there are two different strategies for how you can go about losing weight and the strategy may impact the outcome:
  - Any time you lose weight, there has to be a caloric deficit
  - You can’t lose weight without a change in stored energy. Losing weight is changing stored energy. Stored energy requires caloric imbalance
  - But when you look at [data](https://pubmed.ncbi.nlm.nih.gov/31797417/) for people who have lost weight purely through nutritional manipulations… i.e., purely through manners of reducing caloric intake…Those people tend to lose bone mineral density
  - When you look at people who are doing it in combination with significant exercise, they actually tend to gain bone mineral density

In other words, **you can have people losing the same amount of weight, some of them are losing BMD, some of them are slightly gaining it**.

*What could be going on there?*

- It’s been suggested that the BMD reduction due to weight loss may be caused less by the mechanical loading of bones and more by a change in some of the adipose derived factors like leptin and adiponectin and other hormones that move around when weight loss changes
- So leptin goes down, adiponectin goes down—This is especially in men when they lose weight, but potentially in women too, we see estrogen going down
- It could be that when you’re loading the muscles and therefore transmitting that load to bones, you’re offsetting some of that
- The [study](https://pubmed.ncbi.nlm.nih.gov/31797417/) Peter is citing is relatively small
- And the group that was using exercise as their primary tool to lose weight didn’t lose quite as much weight
- So even when that’s corrected for, it could be a little bit of a confounder
- That said, intuitively, this makes sense; And more importantly, from a longevity standpoint, it makes sense.

**Importance of Exercise**

- Exercise is the single most important tool we have anyway
- Why wouldn’t we employ it as an important part of a weight loss strategy if this is just one of the other bonuses that comes with it, which is an ability to minimize the BMD loss that is almost inevitable with weight loss?

## Nutrition and supplements for bone health [1:16:00]

***What are some essential nutrients that are important for optimizing bone deposition that people should think about?***

![](https://peterattiamd.com/wp-content/uploads/2022/07/f10-ama37-1024x601.png)

**Figure 10. Dietary sources for Calcium, Vitamin D, and Magnesium.**Source: [US Department of Agriculture](https://fdc.nal.usda.gov/)

- When we think about the **micronutrient side**, the big three things that matter are:
  - 1 – Calcium
  - 2 – Vitamin D (D3 specifically)
  - 3 – magnesium
  - (Note: There are other things that matter. Protein matters, total calories matter, all of those things other matter)
- In the first column, you can see the required daily amounts (Peter considers these values a bare MINIMUM)
  - Calcium, about 1000 to 1200 milligrams daily
  - Vitamin D, 800 to 1000 IU daily
  - Magnesium, 300 to 500 milligrams daily
  - And these can be supplemented if you can’t get this sufficiently in food or through sunlight in the case of vitamin D
- Supplementing calcium
  - calcium carbonate and calcium citrate are reasonable options.
- On the magnesium side, it really depends on what your gut can tolerate
  - Magnesium citrate, glycinate, and oxide are fantastic if you’re looking for a little speed up of the bowel
  - If you aren’t, you want magnesium carbonate
  - It’s also worth noting magnesium carbonate is more fully absorbed than mag oxide, citrate, or glycinate which is actually why those three help with bowel regularity
  - Peter’s person magnesium strategy:
    - He likes to mix them up by supplementing with…
    - mag carbonate in the mornings
    - mag oxide at night
    - And also use a bit of mag glycinate with L-threonate as well
    - He’s routinely hitting about a gram of magnesium supplementally
- In the final column, you can see the foods where these things reside
  - And you can see why I believe most people are magnesium deficient
    - It’s pretty hard to get 500 grams predictably of absorbed magnesium every single day
    - And that’s a real minimum — a gram is really where you want to be
  - Calcium’s a bit easier to get if you consume dairy, but a lot of plant-based people aren’t going to eat dairy so they have to look to other things
  - some of those other things you don’t really want to be eating a bunch of
    - Dried figs, for example:
      - A cup of those is 300 milligrams of calcium (a quarter of your daily minimum amount) but you don’t want to be eating a cup of dried figs every day for other reasons
  - So this is something we need to be paying reasonable attention to, both from a dietary standpoint and then for a number of us, also from a supplementary standpoint

## Pharmaceutical drugs prescribed for those with low BMD [1:18:45]

***What about pharma drugs? What are the benefits? What are the trade offs? What should people be thinking about there as they explore their options?***

- Drugs are typically last line of defense (and Peter would will refer people out of his practice for this as he’s not enough of an expert)

*There’s three big classes*

- 1 – Bisphosphonates – this is the main class of drug for this purpose
- 2 – monoclonal antibodies
- 3 – synthetic parathyroid hormone

**Bisphosphonates**

- This is a class of drug that strengthen bones by basically slowing the rate at which the osteoclasts remove bone
  - Remember: osteoblast=B for build; osteoclasts being the opposite
- These exist in two subtypes, nitrogen containing versus non-nitrogen containing
  - The nitrogen containing ones are the much more common one
  - Common brands include Boniva, Fosamax, and Actonel
  - The data is pretty clear that they increase BMD by about four to 6% in the critical areas that matter, the femoral, neck, the hip, the lumbar spine, and they reduce the risk of fractures
  - The drawback:
    - they’re typically not used for indefinite periods of time
    - So they’re discontinued after about five years
    - the evidence suggests that that might not increase the risk of fracture going forward
    - It might be that you get the value during that five year window

*The other two classes of drugs:*

- monoclonal antibodies
- synthetic parathyroid hormone
- There’s a pretty good [meta-analysis](https://academic.oup.com/jcem/article/97/6/1871/2536568) that shows the efficacy (see figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f11-ama37-1024x683.png)

**Figure 11. Agents for the prevention of fragility fractures compared against placebo.** Source: [Murad et al., J Clin Endo & Metab, 2012](https://academic.oup.com/jcem/article/97/6/1871/2536568)

Here you’re looking at the classes of drugs

- The first drug there on each list is synthetic PTH.
- Anytime you see an AB on something at the end of it, that’s the monoclonal antibody
- The other drugs that end in ATE, those are all the bisphosphonates.
- And then the rest are pretty straightforward, calcium, vitamin D, etc.

If you go over to the right, you’re looking at odds ratios

- Anything that is on or crossing the unity line of 1.0 means it’s not significant
- Anything that’s to the left of that line, if the confidence interval doesn’t cross, the one is significant
- What you can see here is nothing that’s on this list is increasing the risk of fractures
- About 2/3 of these things, in their various formats, are reducing the risk of fracture for either hip fractures, vertebral fractures or nonvertebral fractures.

The whole black line has to be to the left of 1.0 for it to be significant

- The black line is your confidence interval
- For example, let’s look at the very first one (Teriparatide)
  - You’ll notice that the little white dot is way to the left
  - It tells you it’s 0.42—That’s a 58% risk reduction
  - However, it doesn’t matter because the confidence interval is so wide that it crosses one
  - “That tells me, without looking at anything, that the P value is greater than 0.05 and the confidence interval crosses unity”
  - So when you look over, sure enough, lower limit 0.1, upper limit 1.82, P value 0.24.
- Let’s pick a winner
  - the one beneath (Alendronate) that has a very similar little white dot
  - It’s 0.45. So it’s not quite as low, but it’s a 55% reduction
  - I know it’s going to be significant because the confidence interval doesn’t cross one and sure enough, it doesn’t
  - It’s 0.27 to 0.68. And the P value is probably 0.000. It’s less than 0.004

⇒ See [AMA #30 on studying studies](https://peterattiamd.com/ama30/)

## Impact of extreme sedentary periods (e.g., bedrest) and how to minimize their damage to bone [1:23:30]

**Extreme example: Astronauts returning from outer space**

- Space is just the most extreme version of what we would call disuse osteopenia
- As the name suggests, disuse osteopenia occurs when bones are chronically unloaded, leaving to a very unfavorable combination of high bone resorption and low bone formation
- It’s the same thing that’s happening with the osteopenia from aging. It’s just much more accelerated and much more extreme
- the most extreme version of this is astronauts
- I suspect that they go out of their way to figure out ways to load astronauts in space so that they don’t have to deal with this in its highest form

**Bedrest**

- For most people where this is relevant is bedrest
- Pregnant women often are placed on bedrest if they are experiencing fetal retardation
  - If, in the third trimester, the fetus isn’t growing at the rate that is expected, not uncommon that the OB will ask the mother to gradually reduce her impact until more and more energy can be reserved for the fetus
- You can also see bedrest being necessary for various types of injuries
- We know today that we don’t want to rest people nearly as much as we used to
- Bone loss due to disuse osteopenia is incremental and it’s progressive with time and it occurs more rapidly, as you would guess, in the trabecular bone than in the cortical bone
- Paralysis based injuries or immobilizaton with injury
- Bone density decreases by about [2% each month](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7493450/) through microgravity, partial paralysis, and in the most extreme setting with complete paralysis, it can be [*up to 7% per month*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7493450/).

*For people who are experiencing that type of immobility, is there anything in particular they should be thinking about or they can do to help with the BMD concern?*

- The first would be any form of PT that can actively load muscles
- One of the things Peter finds very interesting is cyclic blood flow restriction training (BFR)
  - The minute Peter was out of shoulder surgery, he got permission from his surgeon to put on his [Kaatsu cuffs](https://kaatsu.com/) on his arm and just start cycling the BFR
  - “I did not have a bicep tendon repaired. If I did, I would not have been allowed to do that. I had to keep my arm completely immobilized, but I was still able to get compression on the bicep.”

Let’s say you’re bedridden with a certain injury, there are still other muscles in your body that don’t pertain to that injury that can still be moved and put under load

- And even if you’re doing these things isometrically, right.
  - So a person is holding you and you’re resisting against them without actually moving in the bed. That’s important.

There was a super interesting [mouse study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6016491/)

- They used a bisphosphonate to inhibit the osteoclastic bone resorption in a mouse model where the mice were given botulotoxin to basically prevent them from moving one part of their leg

![](https://peterattiamd.com/wp-content/uploads/2022/07/f12-ama37-1024x875.png)

**Figure 12. 16-week-old female mice immobilized with botulinum toxin (BTX) and treated with zoledronic acid (Zol) compared with baseline (Base) and control (Ctrl) mice.**Source: [Vegger, Bruel & Thomson, J Musculoskelet Neuronal Interact., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6016491/)

- The first bar on the left is the baseline
- Then you have control mice in black
- Then in white you have what happens to the animal that were just given botulotoxin—So these were the animals that were basically immobilized
- Then the botulotoxin plus the bisphosphonate on the right

*They found a pretty profound result*

- Looking at this in the femoral neck and in the middle of the upper part of the femoral bone below the neck
- you can see that the bisphosphonate plus the immobility really looks no different from the control
- It’s a clear contrast to how the untreated animals look

*Is this going to be true in humans?*

- It’s unclear, but this type of research very interesting
- Peter hopes these types of studies are being done because immobility is a huge problem with everybody, but once you start to deal with an aging population, it becomes more significant

[Peter and Inigo San Milan discussed](https://peterattiamd.com/inigosanmillan2/) the impact of bedrest in an ICU setting

---

## Selected Links / Related Material

**The show mentioned call Ozark**: [Ozark (TV series)](https://en.wikipedia.org/wiki/Ozark_(TV_series)) | (wikipedia.org) [2:45]

**Rubens Barrichello horrible accident on Friday, April 29th in 1994**: [Barrichello survives horror crash as F1’s darkest weekend begins](https://www.racefans.net/2014/04/29/1994-san-marino-grand-prix-friday/) | Keith Collantine (racefans.net) [3:00]

**Roland Ratzenberger was killed in a crash—the first fatality in Formula One in 12 years—on Saturday, April 30th, 1994**: [Roland Ratzenberger: A dream cut short](https://www.espn.com/f1/story/_/id/29116759/roland-ratzenberger-dream-cut-short) | Nate Saunders (espn.com) [3:30]

**The previous fatality in F1 before Rolan Ratzenberger was Gilles Villeneuve in 1982**: [The inside story of Villeneuve’s final F1 weekend](https://us.motorsport.com/f1/news/gilles-villeneuve-ferrari-death-zolder/4789836/) | Adam Cooper (us.motorsport.com) [3:30]

**Ayrton Senna’s death on Sunday, May 1st, 1994**: [Death of Ayrton Senna](https://en.wikipedia.org/wiki/Death_of_Ayrton_Senna#:~:text=On%201%20May%201994%2C%20Brazilian,e%20Dino%20Ferrari%20in%20Italy.) | (wikipedia.org) [3:45]

**Episode of The Drive with Michael Easter**: [Michael Easter on The Drive](https://peterattiamd.com/michaeleaster) [20:00]

**Michael Easter’s book**: [The Comfort Crisis: Embrace Discomfort To Reclaim Your Wild, Happy, Healthy Self](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) by Michael Easter | (amazon.com) [20:15, 1:01:45]

**Study with ~200 subject that looked at six-month mortality in people who were 65 or older who fractured their hip**: [Factors Influencing The Six-Month Mortality Rate In Patients With A Hip Fracture](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845770/#:~:text=Despite%20improvements%20in%20the%20treatment,care%20(4-6).) (Prodovic et al., 2016) [21:00]

**Finnish study looking at mortality and hip fractures**: [Mortality and cause of death in hip fracture patients aged 65 or older – a population-based study](https://bmcmusculoskeletdisord.biomedcentral.com/articles/10.1186/1471-2474-12-105) (Panula et al., 2011) [21:30]

**Hip fracture study with ~122,000 participants who were at least 60 years old from various cohorts**: [Excess mortality after hip fracture in elderly persons from Europe and the USA: the CHANCES project](https://onlinelibrary.wiley.com/doi/10.1111/joim.12586) (Katsoulis et al., 2017) [21:45]

**The Women’s Health Initiative publication from over 20 years ago**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women](https://jamanetwork.com/journals/jama/fullarticle/195120) (Rossouw et al., 2002) [49:15]

**Episode of The Drive discussing HRT and the erroneous association with breast cancer**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [49:30]

**Study looking at smokers and bone health**: [Early smoking is associated with peak bone mass and prevalent fractures in young, healthy men](https://asbmr.onlinelibrary.wiley.com/doi/full/10.1359/jbmr.090809) (Taes et al., 2010) [54:15]

**Study looking at the use of corticosteroids and bone health and fracture risk**: [Inhaled Corticosteroids and Bone Health](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4319192/) (Chee et al., 2014) [55:15]

**Studies assessing the relationship between proton pump inhibitors (PPIs) and fracture risk**:

- [Proton Pump Inhibitors and Fracture Risk: A Review of Current Evidence and Mechanisms Involved](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6540255/) (Thong et al., 2019) [56:45]
- Meta-analysis: [Proton pump inhibitors and risk of fractures: a meta-analysis of 11 international studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3101476/#:~:text=In%20this%20study%20level%20meta,in%20both%20men%20and%20women.) (Yu et al., 2012) [57:15]

**Episode of The Drive with Ryan Hall**: [#199 – Running, overcoming challenges, and finding success | Ryan Hall](https://peterattiamd.com/ryanhall/) | Peter Attia (peterattiamd.com) [1:03:00]

**Literature looking at BMD in athletes in various sports**: [Bone Mineral Density in Competitive Athletes](https://www.journalofexerciseandnutrition.com/index.php/JEN/article/view/10/7) (Antonio et al., 2018) [1:04:30]

**Data looking at impact of weight loss on BMD through different weight loss strategies**: [Effect of Aerobic or Resistance Exercise, or Both, on Bone Mineral Density and Bone Metabolism in Obese Older Adults While Dieting: A Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/31797417/) (Armamento-Villareal et al., 2020) [1:13:15]

**AMA episode of The Drive looking at how to interpret studies**: [#188 – AMA #30: How to Read and Understand Scientific Studies](https://peterattiamd.com/ama30/) | Peter Attia (peterattiamd.com) [1:22:45]

**Mouse study showing a certain molecule could potentially protect BMD in immobilized mice**: [Zoledronic acid prevents disuse osteopenia and augments gene expression of osteoclastic differentiation markers in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6016491/) [1:26:15]

**Episode of The Drive with Inigo San Milan discussing lactate in the context of ICU patients**: [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) | Peter Attia (peterattiamd.com) [1:28::00]

---

## People Mentioned

- [Rubens Barrichello](https://en.wikipedia.org/wiki/Rubens_Barrichello) [3:00]
- [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) [3:30]
- [Gilles Villeneuve](https://en.wikipedia.org/wiki/Gilles_Villeneuve) [3:30]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [3:45]
- [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [20:00, 1:01:30]
- [Avrum Bluming](https://estrogenmatters.com/) [49:30]
- [Carol Tavris](https://en.wikipedia.org/wiki/Carol_Tavris) [49:30]
- [Ryan Hall](https://en.wikipedia.org/wiki/Ryan_Hall_(runner)) [1:03:00]
- [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) [1:05:45]
- [Gracie brothers](https://en.wikipedia.org/wiki/Gracie_family) [1:07:00]
- [Iñigo San-Millán](https://medschool.cuanschutz.edu/deans-office/cu-med-today/profilesarchives/inigo-san-millan) [1:28:00]

---