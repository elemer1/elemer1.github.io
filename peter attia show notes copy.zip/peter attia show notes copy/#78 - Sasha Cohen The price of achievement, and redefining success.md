# #78 – Sasha Cohen: The price of achievement, and redefining success

**Source:** [https://peterattiamd.com/sashacohen/](https://peterattiamd.com/sashacohen/)

---

In this episode, Sasha Cohen, former US Olympic figure skater, discusses the most challenging things about life as an Olympian—the unfathomable pressures, enormous expectations, years of sacrifice, and your entire life’s work culminating in just a few minutes on the world stage which, once over, leads to a loss of identity resulting in many former Olympians suffering with depression. We begin by talking about everything that led up to her unforgettable moment from the 2006 Olympics, and how she handled herself so beautifully in the face of disaster. Most importantly, we talk about post-skating life when she shares many insights such as the downside of constantly striving for a moment, the hollowness of achievement, and the importance of redefining our definition of success.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sashacohen/the_Drive_public.png)

Play

#78 - Sasha Cohen: The price of achievement, and redefining success

#78 - Sasha Cohen: The price of achievement, and redefining success

1x15s30s

0:002:13:48

We discuss:

- Sasha’s mindset going into the 2006 Olympics as the favorite [6:30];
- Figure skating basics, scoring, short program vs. long program, etc. [13:40];
- Sasha’s unforgettable performance at the 2006 Olympics [18:10];
- Win, lose, or draw, why many Olympians suffer from a loss of identity [32:30];
- Dealing with the disappointment of “losing the gold” [40:30];
- The tiny window of opportunity for Olympians, and the overwhelming pressure to meet expectations [49:30];
- Sasha’s unique childhood, finding figure skating, and channeling her hyperactive personality into becoming an amazing skater [1:01:30];
- The consequences of extreme training at a young age, and trying to control the uncontrollable [1:10:00];
- What is driving extreme athletes and Olympians to be the best? [1:18:30];
- Why many former Olympians and athletes struggle with depression [1:25:00];
- Refining success—How Sasha overcame her own loss of identity [1:32:30];
- What advice would Sasha give her 15-year-old self? [1:40:45];
- Lessons we can learn from watching the rapid downfall of many former Olympians [1:45:00];
- Advice for people who are tying their identity to being “successful” or striving to be “the best” [1:56:00];
- Life lessons Sasha wants to apply to being a mother to her baby boy she is expecting [2:05:00]; and
- More.

§

## Show Notes

Before beginning this podcast episode, take a moment to watch Sasha’s long program performance at the 2006 Olympic games:

§

## Sasha’s mindset going into the 2006 Olympics as the favorite [6:30]

- Fast forwarding to age 21
- Sasha is the favorite at the 2006 Olympics
- She had a feeling this might be her last games so she was feeling the pressure
- She also felt less prepared mentally and physically that she would like
- She has some unfortunate injuries that occurred in the last few months leading up to the games
- “*These few minutes you have to fulfill a lifelong dream is just immense pressure*“
- In contrast, in the 2002 Olympics (her first games) she was just 17 she was just amazed she made the Olympics and there was no pressure to win (she got fourth place)

> “And I think something that I’ve learned a lot about myself since then is that we can’t control everything. And as athletes we think we can, that we can control and prevent any injury that might arise or any equipment problems. And, and it’s very hard to admit to yourself that you can’t control everything cause that’s what you’ve spent your whole life trying to do.”

Putting on a brave face

- Athletes can’t show weakness, says Sasha
- Because others will smell blood in the water and come for you

> “And so you’re always putting on this brave face, and it’s kind of a ‘fake it ‘til you make it’, because if you show fear you give others confidence and you undermine yourself.”

## Figure skating basics, scoring, short program vs. long program, etc. [13:40]

The short program

- usually 2 minutes and 50 seconds
- There’s three jumping passes
- there’s a footwork sequence
- A spiral sequence
- And 3 three spins

Long program

- 4 min 10 sec
- 8 jumping passes and you could do jumps in combination
- Three to four spins
- A footwork sequence and a spiral sequence as well
- More flexibility in terms of if you do a combination or you don’t do a combination
- And it’s all about trying to aggregate more and more points

Scoring:

- ~9 judges with a backup
- They take your short program and long program together to come up with your final score
- Top score among skaters wins

*Was Sasha’s strength more on the short program or the long program or how do these differ?*

- Less margin of error in short program (one mistake and you lose)
- But long program offers more opportunity to take risks (since it’s longer)
- Sasha liked short program more (more “fiery” and less pressure)
- More endurance mentally and physically in long program

> “For some people they see it as more pressure because you can’t make a mistake and in some ways it’s less pressure because it doesn’t count for as much as the long and it’s just, it’s everyone kind of getting initiated and seeing where you rank.”

## Sasha’s unforgettable performance at the 2006 Olympics [18:10]

- Coming out of the short program, Sasha was in first place, despite feeling like she didn’t do her best
- She was thrilled, she couldn’t believe it: “*I hadn’t done a clean short program in weeks.*”
- She then had a day off before her long program skate
- She actually strained her leg during her short program so she **didn’t practice at all** leading up to the long program (when is unusual)
- This added to her anxiety about feeling unprepared
- On her decision to not practice: “*You always second guess everything and in hindsight, but considering where I was and how injured I was, the time it, it did seem like the best decision because at a certain point you’ve done everything so many times that it’s how you feel physically, which really informs how you feel mentally in the moment that you step out to perform.*”

**The infamous** [**long program skate**](https://www.youtube.com/watch?v=Hcp56KtOtyY) **by Sasha in 2006**

- In the 5 minute warm up before her long program, she fell on jumps that she usually nailed
- “***It really shook me.***”
- Figure skating is a sport where you’re jumping and if you hesitate for a *millisecond*, you throw off a whole timing of a jump.

Burying the jitters

- Sasha says that you train yourself to stay in the moment over the years of competing
- At the olympics, you’re competing for 2-4 minutes on something you’ve prepared your entire life for
- The gravity of that situation can “really unravel you” if you let it

Falling on her first jump

- Sasha fell on her first jump, the [triple lutz](https://en.wikipedia.org/wiki/Lutz_jump) (the only harder jump is the [triple axel](https://en.wikipedia.org/wiki/Axel_jump))
  - Fun facts:
    - [Midori Ito](https://en.wikipedia.org/wiki/Midori_Ito) is the first woman to [land the triple axel](https://www.youtube.com/watch?v=j33BUhK1yok) at the Olympics
    - [Mirai Nagasu](https://en.wikipedia.org/wiki/Mirai_Nagasu) was the first US woman to [land the triple axel](https://www.youtube.com/watch?v=GBWLP-iDUqg) at the Olympics
    - [Elvis Stojko](https://en.wikipedia.org/wiki/Elvis_Stojko) is one of the only people to ever [land a quad jump](https://youtu.be/3uXs1SsluNY?t=110) (4.5 turns)
- She said this surprised her and she heard the “oohh” and “hush” from the crowd

⇒ Quick aside on training:

- Sasha says training it broken into segments rather than the whole 4+ min run through (which you do as well but not all the time)
- Her issue was finding the balance between doing more and resting

> “It was always this tough push-pull of ‘am I being lazy or am I being smart?’ And sometimes…something inside it was just like, ‘I’m not sure, but I have to do this again and again and again’ and then you end up injured and then you feel like an idiot because now you have to take a week off.”

*How does a skater resume the routine after falling in such a big moment?*

- Peter says this has always amazed him how they do this for 2 reasons:
  - 1) Knowing where you are physically in order to jump right back into the routine
  - 2) More impressive is the courage to be able to stand up when at that level of fall of that nature almost guarantees you can’t win
- Sasha says her coach always said, “you don’t fall, you bounce”
- You don’t have time to sulk in the implications of the fall
- But on a world stage like the olympics, it’s much more than your own disappointment
- It’s also the disappointment of the crowd, and you can hear them “groan”

> “It’s kind of being in this embarrassing catastrophic nightmare where you can’t hide. It’s like, it’s like someone’s ripped off your clothes but you can’t run off and hide. You have to hold your chin up and keep going and pretend like you’re fine.”

Nearly falling on her SECOND jump

- It was the [triple flip](https://en.wikipedia.org/wiki/Flip_jump)
- She had a severe “step out” and needed both her hands to keep her from falling
- Per Peter:
  - She has already fallen twice and her program had barely started
  - And despite that bad start it would end up being “*one of the more beautiful performances in all of women’s figure skating*”
  - He’s blown away at how she could pull that off after those devastating mistakes at the outset
- Sasha: “*I think you get very good at denial as an athlete and at blocking things out because they would be too much to take.*”

> “I saw the Olympics as this just huge looming thing like the sun, like the horizon ahead of you, but I couldn’t imagine anything beyond it. It’s the same way that we know that we one day will die but we can’t imagine that actually taking place and what’s beyond it.”

## Win, lose, or draw, why many Olympians suffer from a loss of identity [32:30]

Peter recalls a question being asked to Olympians:

*Would you die in 10 years if it meant that you could win a gold medal?*

- He said a staggering number of athletes said yes

*How would have Sasha answered that question in 2006?*

- While she’s not sure how she would have answered at the time, she does understand why some would say yes
- Being an Olympianwas everything
- It was an identity.
- Your chance to prove yourself to the world.
- Everything was riding on it.
- It was just so absolute and failing was the worst thing.
- And the sad thing is, getting second place means failing
- For years, Sasha thought that her own suffering wouldn’t have existed had she just skated better and taken the Gold medal (instead of silver)
- “*If I had just skated perfectly on that day and won [gold] then there would be nothing to resolve. There would be no searching.*”

However,

- What she found was that even athletes who did fulfill their ultimate goal of gold (e.g., Apollo Ohno and Michael Phelps) still struggle
- Why?
  - Because I think so much of what we gear our lives and performance for is **for a moment**.
  - And even if you win in that moment, that moment passes and then you still need something new to define you to prove that you’re still good enough
  - You end up constantly needing a vehicle to prove yourself

**Win, lose, or draw you lose your identity**

- That is what is so challenging for so many Olympians because you have sacrificed everything
  - you’ve been homeschooled
  - Have few friends
  - you have no balance
  - you generally don’t have many other outside interests.
  - Few friendships
- Then all of a sudden that identity is taken from you
- I was a figure skater… *But now who are you?*
- You’re kind of left on your own, somewhat isolated

–Keeping their struggles to themselves

- Olympians aren’t really sharing their struggles because being an athlete is about projecting confidence and power and that you’re fine and you’re always fine.
- You get in the habit of not portraying weakness, of not asking for help

## Dealing with the disappointment of “losing the gold” [40:30]

Peter: “*Take those first 30 seconds out of that program, I don’t think I’m alone in saying this. . .it as one of the* ***greatest programs in all of women’s figure skating****.*”

***Was Sasha proud at how she finished?***

- I was certainly proud of how I finished, she says
- During the program she had to keep her mind in check:
- “*At that moment you’re still kind of realizing like ‘there went the gold’, but you’re, you’re just trying to keep your head back because your head wants to go all these places.*”
- As an athlete, you’ve taught yourself to **suppress emotions, feelings, and doubts**, Sasha says, especially when things are still on the line and you have to perform

*On how she made it so beautiful after the bad start:*

- The music was very emotional (Romeo and Juliet from the movie)
- And so I allowed myself to really kind of get into some of the pain and the expressiveness of the music.

*After it was over*:

- “*I was relieved when I was done*…
- …*But I was also crestfallen and still trying to process everything at once.*”

*About getting the silver medal*:

![](https://peterattiamd.com/wp-content/uploads/2019/10/forbes.comSilver-medal.jpg)

**Figure 1. Sasha wins the silver medal in the 2006 Winter Olympics in Turin.** Image credit: [Forbes.com](https://www.forbes.com/sites/jimclash/2016/01/08/interview-part-4-sasha-cohen-on-michelle-kwan-torino-olympic-silver-and-her-tight-family/#1a35d4d34801)

- On the one hand, she felt lucky to medal at all
- But she also knew how much better she could have been out there
- So it felt more like she “lost the gold” than that she won the silver

> “Every time they put a microphone in my face I could get through 30 or 40 seconds before I started to cry. . .You’re kind of a porcelain doll that shattered and glued yourself to try to keep going for the next two days of the Olympics.”

**Did Sasha formally retire after 2006?**

- Didn’t formally retire in 2006 after the Olympics
- But did try some new things
  - Acting school
  - Then figure skating tours for a while (not-competitive)
- She actually came back to train in 2009-2010 season

Exploring other opportunities

- While she hadn’t retired yet, she was trying to figure out some other possible career paths
- She guest starred on [CSI NY](https://www.youtube.com/watch?v=gbm2xVuWz7U)

> “It was a wonderful diversion from this intense world of pain and disappointment.”
>
> “All Olympians go through this. You work really hard, you have tunnel vision, you spend your day between the gym, your home, and a training facility, and then all of a sudden the whole world cares about you. Everyone wants to meet the Olympian right after the Olympics, until the next games. And then just like, ‘Oh, who are you?’”

## The tiny window of opportunity for Olympians, and the overwhelming pressure to meet expectations [49:30]

Most Olympians only even make it to one games

- Very rare to see athletes get to more than one games
- And even more rare to see them compete in 3 or more (e.g., Michael Phelps)

The timing must be perfect

- Athletes, depending on the sport, sometimes “peak” at a really young age
- And they have to get lucky for the peak to line up with the timing of the Olympic games
- In figure skating, many girls peak as young as 12-15 years old
- And often times puberty will complete transform their body and throw them off their game

**Enormous expectations**

- Despite how all the stars having to align just to make the Olympics…
- Many fans don’t quite appreciate this fact and put enormous expectations on athletes
- Peter uses swimmer, Missy Franklin, as an example as someone who peaked early and wasn’t the same swimmer 4 years later yet we expected her to win everything
- Peter sad it “infuriated” him to watch people be disappointed in her when she didn’t quite look the same in 2016 vs. 2012 (rather than simply being sad *for her*)

> “There’s really no sensitivity to this person being a human being. We see athletes as resources and you need to perform, you need to meet expectations. And there’s not a lot of compassion for them as a human being just struggling on this global platform and just having their heart ripped out.”

**Why people like to see athletes fail**

Peter ponders on the fact that it seems we (society) almost enjoy watching top tier athletes fail (or show imperfections)

- “We’re so used to looking at Jerry Rice or Michael Phelps or whatever that one exception is that comes along and truly bends the arc of a sport that you forget that even the people seven rungs beneath them are still doing something that most of us can’t fathom.”
- “We get so used to seeing you guys be perfect that when you make a mistake. . .maybe there’s a part of us that like seeing it, because we know you’re not perfect and maybe there’s a sense of well you failed, therefore I’m not so mediocre in my existence.”

Sasha says we really don’t get to see what goes into being an Olympian

- We really only see the Olympian pop up out of nowhere for a couple weeks
- When you really start to see the 4 years of training
- With no glory
- Being homeschooled
- Living at a grungy training center
- It starts to humanize them to the view

**What is it like being an Olympian in the US vs. other countries?**

- It’s great to be an American Olympian relative to other countries
- Incredible to see the U S flag and the sense of comradery
- There’s this immense sense of pride representing the US
- The difference is that many other countries fund their Olympians through the government
- In the US, the U S Olympic and Paralympic committee is solely responsible for funding the athletes
- In Russia and China, for example, the government is putting a lot of money into the athletes and paying for their training
- And so they just have the resources that they have to work with are at another level.

Especially during the Soviet Union…

- It was all about ‘How do we beat the US?’ with no expenses spared
- Looking at five-year-olds and do they have the right bone structures, etc.
- Take these fifty 5-year-olds away, put them in camp and maybe one of them will make it
- We don’t care if we work them all to the bone because it’s about winning and it’s, it’s an Olympic machine.

## Sasha’s unique childhood, finding figure skating, and channeling her hyperactive personality into becoming an amazing skater [1:01:30]

- Sasha was a hyperactive kid
- She was always full of energy
- Couldn’t sit still in school
- Also wasn’t interested in traditional girl stuff (dances, dressing up, etc.)
- Diagnosed with ADHD
- Her mom did NOT want to medicate her
- Sasha discovered skating and said she has the “*feeling of gliding and freedom that I could channel all this energy into something I loved and could focus on*.”

> “It didn’t feel like a sacrifice because all I wanted to do is be on the rink and to be skating and learning new jumps. So I never really saw it as a sacrifice early on in my life. It was, it was something that gave me clarity and purpose.”

**The unique combo of power and athleticism with creative, artistic lines and flow of figuring skating**

- Figure skating is a very explosive sport
- You need raw athleticism to be successful
- But it’s unique in that it also requires a **huge artistic component**
- “you [can] take the most powerful female athlete on the planet, but if she doesn’t have the ability to create lines and flow and spin in a certain way in dance in a certain way or choreograph in a certain way, it wouldn’t be the same.”
- Figure skating it part sport, part art (next comes ballet which is all art)

*What was Sasha’s strength?*

- She said she was good at it all but was more of an emotive artistic skater
- Some girls are robots and can land jumps all day
- Sasha says it took her longer to learn jumps, didn’t come as easy
- “I excelled at the expression and the line and the flexibility”
- Sasha credits her mom for making her sit in the splits while watching TV

*How the sport is evolving*:

- To some criticism, more and more emphasis is being put on the technical aspect
- That is what racks up the points
- But it’s hard to argue that the technical stuff is easier to score than the artistic stuff
- And given the fact that young men and women are peaking early teens and then puberty is throwing off their ability, it makes it hard to allow them to mature into seasoned performers since now it’s all about the jumps

> “You can’t sustain and evolve and have the kind of skaters you had in the 90s and early two thousands like [Surya Bonaly](https://en.wikipedia.org/wiki/Surya_Bonaly), [Kurt Browning](https://en.wikipedia.org/wiki/Kurt_Browning), and [Michelle Kwan](https://en.wikipedia.org/wiki/Michelle_Kwan) where there were personalities that developed and people matured and became more like well-rounded athletes and performers because we’re now choosing to treat it just as a sport.”

## The consequences of extreme training at a young age, and trying to control the uncontrollable [1:10:00]

*When did she know she wanted figure skating to be her life?*

- Age 12, going into 7th grade she felt like school was just a waste
- By high school she was completely uninterested in the typical social stuff
- She was also tiny, looked like an elementary school kid

At age 15

- She was 4’9” and 70 lbs
- Only about 5% body fat
- Had Sasha had her period yet?
- No, not until much later
- The extreme training, dieting, and stress makes this not uncommon for young athletes

When Sasha turned 17 things changed

- Her body started to change
- She could no longer eat whatever she wanted
- It became harder and harder for her to stay at her lightest weight which makes a huge impact on her jumping and spinning ability

> “And I think that’s why you see a lot of girls kind of get sidelined when they go through puberty is because their really changes, their bones change and no matter how they try to control what they eat or how they train it, that time has passed them by.”

**Trying to control the uncontrollable**

- One of the greatest examples of the **lack of control you really have** is puberty
- Going through puberty for a female figure skater has very little control over what her body is going to turn into.

Ultimately it’s on the athlete to figure it out

- In figure skating, if you have a longer lines and you look more balletic
- and at the same time it’s easier to jump and you’re also controlling something in your life
- which are kind of all of these things that are tied into having an eating disorder.
- But then it’s like, is that what’s necessary for this sport?

**When was it the most fun to skate?**

- When I first started
- Then when I was 14 or 15 years old
- She was just beginning to get really good and get some nation attention
- There was no real pressure to be the best
- “I was still super motivated, it was all ahead of me and I was young enough that I think the pressure, the immensity and the enormity of where the level of pressure would go had not yet sunk in.”
- This is a common answer from Olympians, says Peter
- Later down the road, it becomes all about expectations

> “Before you have it, you idolize these athletes at the Olympics and it’s a dream. Just maybe one day I could get to go there, and then all of a sudden when you’re going there you’re like, ‘if I don’t win, I am the biggest failure in my life is ruined’. And so I think it’s all about framing and lenses.”

## What is driving extreme athletes and Olympians to be the best? [1:18:30]

**Training after age 17 leading to the 2006 Olympics at age 21**

- She was constantly struggling with her weight
- She had very low estrogen and low bone density so doctors put her on birth control
- That threw her body out of what and completely didn’t work for training
- It was really tough but the Olympics were two years away and she “**had to be there and I had to win because this was everything my life was for . . .so despite how difficult it was . . . quitting was, was never an option**.”

> “There’s just something inside that’s propelling you . . .but it’s not pure joy and like the love of what you’re doing that’s driving you, it’s the need to fulfill a quest.”

*Is it possible to be the best while operating from pure bliss and joy?*

*Or does there need to be some negative emotion or void being filled?*

- Peter says in many cases it’s almost “obvious” what’s driving an athlete, or what void is trying to be filled (approval of someone, proving someone wrong, etc.)
- Peter asks, *Can you win an Olympic gold purely place of bliss, pure joy and love. . .is that even possible at that level?*
  - I think you see it with kids just coming up so they might be 15 go to their first games and they’re so excited to be there and they win
  - It also happens towards the end of a career when people have had dealt with hardship and maybe it’s and they realize that this is the last games and how incredible it is and that they’re performing and they’re competing
  - It’s the most difficult when it’s clearly your peak of your career and you’re expected to perform with the best of them
  - There’s so much pressure riding on this performance and it’s no longer about your Olympic experience.
  - “I think it is complicated, but I think it’s possible. . .but there’s certain drive that doesn’t come from pure joy.”

**Takeaways from training for the Olympics**

- You realize that the great things in life take hitting your head against a wall over and over and over for years and you just **don’t give up** because giving up isn’t an option.
- In Sasha’s case, there were times leading up to the 2006 Olympics where she was not doing well and thought she wouldn’t even qualify
- But, but you don’t give up, you just keep showing up every day, and then things get better.

> “It teaches you that, that if you don’t give up, if you show up that that has a lot of weight to it.”

## Why many former Olympians and athletes struggle with depression [1:25:00]

**The pressure of expectations at the Olympics is immense**

*Is there anything in real life that compares to this feeling?*

- Certainly not, says Sasha
- “*It was like battery acid running through your chest with a thousand pounds of weight crushing you. You’re like, ‘how do I even move?*’”
- As an extreme athlete, you must have the ability to **shut down your emotions**
- “You’re a robot, you’re productive, projecting confidence.”

The **high highs** and the **low lows** of the sport and then getting used to the **evening out of real life**

- As an Olympian, you have extremely high highs, and very low lows
- The training is hard, the pressure is enormous… with lots of lonely, difficult moments (the lows)
- But performing on the big stage gives you an incredible high like no other
- When you get to real life, there is an “evening out” that takes getting used to

> “After I retired, you know, life was just nice and that was wonderful for a year. And then life just fell flat because everything had evened out. The high highs were gone, the low lows were gone. And then you’re kind of learning how to live without that paradigm.”

**Prevalence of depression in former Olympians**

Peter remembers reading that ~[80% of former Olympians suffer some form of depression](https://www.scmp.com/sport/other-sport/article/2146823/escaping-depression-michael-phelps-says-75-cent-olympians-may)

- Sasha says that would not be a surprise, and it may be even higher
- Mental health issues come with a stigma
  - So even non athletes are hesitant to talk about them
  - As an athlete, you’re taught not to admit weakness because it undermines what you’re capable of and gives your competition an opportunity

After you retire…

- Athletes (especially Olympians) **lose their identity**
- Lose their **purpose**
- Something you’ve spent a decade or two working for
- Your whole team of support
- This long term goal that’s being driving you
- All of a sudden it’s all gone
- Your **identity** as a person is gone
- In addition, you feel like you’re 10 years behind the rest of society because you’ve spent all your time on this one goal (and missing out on college and career building)

> “This rug has been pulled from underneath you. And so not only are you mourning your identity and have lost your sense of purpose, but now you see yourself as 10 years behind normal people and you don’t even know what you want to do.”

## Refining success—How Sasha overcame her own loss of identity [1:32:30]

*After retiring, the Olympian has a choice:*

Stay in the sport or move on?

- Some stay and hold on to that identity and coach or become a judge
- Others want to move on with other stuff

For those that try to move on…

- It’s like being a tadpole in the ocean (a hard transition from being the big fish in the small pond of olympians)
- you have to deal with this sense of insignificance and feeling lost and realizing the more you learn about the world, the bigger you realize it is.
- And then the more confused you are, the more options.
- “*I definitely chose the tadpole and the ocean route*”
- Sasha moved to New York and went to Columbia University

**Redefining success**

- After competing until age 21 and thinking about what’s next?
- Her first thought was ‘*What’s the next thing that seems really competitive and athletic and I can define winning?*’
- For Sasha, that answer seemed to *finance*
- But then you realize that success is what YOU define it to be
- And that actually **happiness** starts to be more important to you than what society deems “success”
- Success is fleeting and maybe success is a moment but you’re quickly replaced… so **what are you building your life around?**

There’s a value shift instead of just like this “plug and play”

- At first, Sasha’s thought was “I’m gonna take all this intensity I had in my sport and put it towards something else and be the best and just like show everyone”
- And then you realize like, **Is this mountain even worth climbing?**
- It takes a lot of time and reflection and kind of self-growth to realize *what’s worth doing…what actually is winning in life*

**What enabled Sasha to figure this out (when many others can’t)?**

Peter says Sasha is “wise beyond your years”

Peter wants to know:

*When and how did Sasha come to the realization that she no longer wanted to live her life around* ***being the best?***

- I think it’s in finding things to be hollow.
- It’s going down a path that you think, Oh, if I’m just the most successful in this, if I work my way up to the top, I’ll find identity and fulfillment and I’ll be good enough.
- And then you realize that you do it. These things look sexy from the outside. But once you’re in them, it’s really not what it appears to be.
- A lot of people do things for approval and for status in society.
- At a very young age, I got used to being **rewarded by the public for achieving**.
- So I felt that what I needed to do had to be **publicly visible** and needed to be **appreciated and to be validated**.

As you get older…

- Sasha has spent a lot of time with different Buddhist texts and in meditation and just understanding this bigger picture of life
- We get so singularly absorbed in like what’s in front of us in the moment and we think it’s the most important thing.
- The **biggest struggle** for me and something that I daily work on is:
  - W*hat do I actually want to do*?
  - versus
  - W*hat do I think other people will be impressed with*?

Both Peter and Sasha are fans of books by David Brooks:

- [The Road to Character](https://www.amazon.com/gp/product/0812983416/ref=dbs_a_def_rwt_bibl_vppi_i1) (Peter)
- [The Second Mountain](https://www.amazon.com/Second-Mountain-David-Brooks/dp/0812993268) (Sasha)

Sasha is currently exploring:

- what makes a meaningful life?
- what actually brings me joy?
- Can peel away all the layers that my upbringing through sport and society have projected onto me?
  - Sometimes you don’t really know the difference and you end up doing things that people around you do because that’s what they respect.
  - And ultimately we’re social animals and we want to be respected by others to have a sense of self worth
  - But if you can really strip all those things away, you can start to have the dialog with yourself of what you actually like
    - what have you really like something that the world doesn’t validate?
    - who’s going to win?
    - Are you going to do something for them?
    - Or you can just think for yourself?

## What advice would Sasha give her 15 year-old self? [1:40:45]

**Peter posed a thought experiment to Sasha**:

*-What advice would she give her 15 year old self?*

*-Or more poignantly, how much would you let her worry/stress about what she’s doing, even if alleviating some of that worry subjected her to the risk of not being as successful?*

Sasha:

I would go back and say…

- **Enjoy this time**

- - Enjoy being at the Olympics
  - Enjoy being on the ice and moving and having your body trained to this incredible degree
- **This is gift**: This is a very extraordinary, exceptional piece of the human experience when you can get to the top of a sport that you can represent your country

However…

- If you tell this younger girl not to stress too much because there is so much more to life…
- E.g., You’re gonna go to college and find things you love… or… The world is so much bigger than this singular focus
- Maybe she **wouldn’t stick out those really difficult times**

> “So I think if I knew more about the world in those hard times, I think it would have been much harder to stick it out. . . versus that being your only **identity** and your **whole world**.”

## Lessons we can learn from watching the rapid downfall of many former Olympians [1:45:00]

The side effect of going from Olympian to “normal” person

- Peter has seen many cases of which a top athlete retires and becomes a “normal” person
- There’s a sadness in this
- The former athlete commonly struggles to find their new identity
- Often times falling into depression or substance abuse

> “And what seems unfair to me is that the same forces that lifted him up, he was a national champion at 17 you know, the greatest that that country had ever produced, are the same forces that put the blinders on him to enable him to spend a decade of his life being the identity of a nation in a sport or the exact same forces that have abandoned him and given him nothing to cope with.” —Peter Attia

**Sasha’s take**:

- Athletes generally start young and so there’s a conditioning that sets in early which is **validation through performance and through through winning**.
- That’s how you’re defined and that’s how you’re respected and adored

> “You can be a healthy, functioning human being, or you can be the best in the world at something, but you can’t be both.”

-Sacrifices to be the best

- You have to sacrifice your emotional wellbeing, time with friends, socializing in school, these other things that would make you well rounded
- What happens in sport is you become **valued for what you do** and as soon as you stop doing it (or doing it as well as you did) **all your value is gone**.
- “And as soon as you stop winning the value just like it or it just **disintegrates so quickly**.”

**Being vs. doing—The difference between eastern and western cultures**

> “In the West, we always think that we **DO** something, that there’s a mover and a moved, a cause and an effect, that there is a God and he created everything else. And then you go into to Eastern culture and it’s symbiotic. Everything is a relationship. God is everything. And it’s about relationships. And the belief isn’t that you caused something but that you are part of something, and it’s all interrelated. It doesn’t apply to sports. But I think it really goes into the philosophies and the way that people in Eastern versus Western cultures have historically lived. And, and that really stuck with me because there’s a lot of responsibility to feel that you cause everything, that it’s all up to you. To a certain extent, it’s true in certain ways, but there’s so much that we don’t control and that we still don’t understand, and that how things are all interrelated. And I think that’s important to remember. And I think it’s helpful as an athlete to remove yourself from this cause and effect way of living to understand that you’re also a part of something.”

⇒ **Sasha is involved in an upcoming documentary called** [**Weight of Gold**](https://podiumpictures.com/weight-of-gold)

- It’s not yet released (but here is a [trailer](https://www.youtube.com/watch?v=LvaS1eN7Fdw) followed by a panel discussion in which Sasha appears)
- In the doc, the US bobsled captain [Steve Holcomb](https://en.wikipedia.org/wiki/Steven_Holcomb) is featured
- Steve committed suicide partly due the pressure of being an olympian and the loss of identity following retirement
- And the film focuses on the struggle of Olympians to highlight the importance of mental health

> “From the outside it may look like they have everything and that there’s this epitome of success, but the sense of hollowness they have on the inside, this loss of identity, because you have these really incredible type A personalities that will do anything, and sacrifice anything to achieve, and then all of a sudden their whole platform for achieving has been erased. And I think it really leaves you like a fish out of water.”

## Advice for people who are tying their identity to being “successful” or striving to be “the best” [1:56:00]

Peter points out the danger of tying your identity to…

- Achieving some type of success, or
- Trying to be “the best”

Peter asks Sasha…

***What would you say to that person that wants to be the best at something?***

- It’s fleeting. I think it’s an incredible thrill, but I think ultimately it’s complicated.
- And I think where mental health can be exasperated is when there’s a **lack of relationships**.
- We don’t realize how social we are and how much we need each other and we need friendships and family in our lives.
- Winning a gold medal, or an Oscar, are incredible accomplishments and should be celebrated
- But ultimately, those are just moments
- And moments pass by and you’re quickly replaced by the next person that wins the Oscar next or the gold medal
- You still have to step on to that next chapter and try to build those relationships and find satisfaction and fulfillment and build a life again.
- “**Be careful what you’re trading for what.**”

**Sasha’s advice for resetting your identity around things that are less fleeting**

- It takes a lot of hard work because you are letting go of a whole system of values that have defined you (in the case of an extreme athlete)
- But this applies to society as a whole
  - What we value
    - For example: It’s the young, the thin, the beautiful who we put on billboards and applaud and read about in magazines.
  - But is what society is selling actually making anyone happy?
  - We think things like,
    - when we lose 10 pounds, we’ll be happier.
    - when I’m in this relationship I’ll be happy.
- And then you start to realize that these are mirages, or false illusions

**Changing your relationship to yourself and the world**

- It’s easier to look outward than to look inward at yourself
- It’s a slow unfolding and it takes time
- It’s very difficult to let go of the only thing you’ve ever known of the way that you’re supposed to live and what everyone else applauds
- It’s much easier to just play the game the way everyone else playing the game and then hold up the trophy and everyone applauds you
- But then at the end of it, it just kind of wears off and then it’s just like “*what are you now?*”

\*Peter’s David Foster Wallace prescription\*

1. Pause this podcast right now
2. Go watch [This is Water](https://www.youtube.com/watch?v=8CrOL-ydFMI), a commencement speech by [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace)
3. Close your eyes and listen to it
4. Then do that every day for the next week
5. Then every week for the next 3 months
6. Then every month thereafter

In his speech, David talks about this idea of **worship**

- We worship things, we worship our intellect, our bodies, our wealth, whatever.
- But these things are all hollow, as Sasha pointed out
- Athletes simply figure this out quicker because the window in which you can be great is so much narrower than say the window in which you could be rich, or the window in which you can be the smartest, or the window in which you can be the fill-in-the-blank.
- Olympic athletes are literally the **most extreme version** of it because the average Olympian only makes one Olympics, which means **two weeks**
- \**Imagine being the best in the world at something where your* ***entire pinnacle is two weeks***\*

**Sasha on self identity and wellbeing**:

> “The way that we identify, the way we see ourselves, is completely responsible for our sense of wellbeing. And if you’ve set impossible standards, or you know that if you’re second best in the world, that that’s the biggest failure and disappointment you’re making the margin for feeling successful so narrow that even if you meet it, it’s only a temporary high. . . and I think that we have to think about the way we set up and define success. And is success the same thing as happiness? Because I think in sports, being successful means perhaps sacrificing and being unhappy and enduring for a very, very long time to be successful and to be gratified for moments or days. But it’s not the same thing as cultivating a sense of wellbeing, and being content, and loving your relationships, and having meaningful work, and loving what you do. That has been very much undervalued in our society.”

## Life lessons Sasha wants to apply to being a mother to her baby boy she is expecting [2:05:00]

- Sasha is pregnant with a boy
- She is very excited about this new chapter in her life

> “My whole life was so focused on myself and what I did that I think having the chance to live for someone else and to create a life for someone else is part of the arc of life and I’m so excited for all that it brings.”

On playing sports at a high level:

- Sasha says she would prefer her boy does NOT play sports at a very high level
- That she’s rather him be fulfilled in a more healthy way

Lessons Sasha will take from her own mom

- I think a sense of selflessness and commitment to the family
- Sasha’s mom showed what a privilege it is to be a mother
- At the end of anyone’s life they’ll say it’s like the time they spent with their kids and their loved ones that they remember most

> “I want to expose my child to the world, to travel, to show him how big the world is and to really just explore it. Life is this incredible adventure. And so it’s not really about becoming anything like becoming a product or becoming really good at something. It’s just having this huge life full of love and adventure.”

§

## Selected Links / Related Material

**Sasha’s long program skate in 2006 Olympics**: [Sasha Cohen 2006 Olympics LP CBC](https://www.youtube.com/watch?v=Hcp56KtOtyY) | 宋天 (youtube.com) [4:15, 7:30, 21:00]

**Only women to land a triple axel at the Olympics**: [24:00]

- *Midori Ito did it first in 1992*: [Midori Ito Conquers The Triple Axel | Impossible Moments](https://www.youtube.com/watch?v=j33BUhK1yok) | Olympic (youtube.com)
- *Mirai Nagasu was the first US skater to do it (2014)*: [US figure skater makes history, landing triple axel at Olympics](https://www.youtube.com/watch?v=GBWLP-iDUqg) | ABC News (youtube.com)

**Elvis Stojko landed one of the only quad jumps (4.5 turns) in competition**: [Elvis Stojko LP 1991 World Figure Skating Championships](https://youtu.be/3uXs1SsluNY?t=110) | Benoit Lefebvre (youtube.com) [24:30]

**Michael Phelps got 5th place in the 200 meter butterfly in the 2000 Olympics at age 15**: [Swimming at the 2000 Summer Olympics – Men’s 200 metre butterfly](https://en.wikipedia.org/wiki/Swimming_at_the_2000_Summer_Olympics_%E2%80%93_Men%27s_200_metre_butterfly) | (wikipedia.org) [35:45]

**Michael Phelps record of 18 years in the 200 meter fly was broken in in July 2019**: [Michael Phelps’ 200m fly world record shattered by 19-year-old Kristof Milak](https://www.youtube.com/watch?v=awCgeVVQ5Ls) | NBC Sports (youtube.com)  [35:45]

**A list of Michael Phelps’s current and former world records**: [Michael Phelps: World Records](https://en.wikipedia.org/wiki/Michael_Phelps#World_records) | (wikipedia.org) [36:30]

**Sasha’s appearance on CSI New York**: [Sasha Cohen performs on CSI NY “Calling All Angels”](https://www.youtube.com/watch?v=gbm2xVuWz7U) | tOfADifferentColor (youtube.com) [47:00]

**Shaun White won the 100th US gold medal**: [Shaun White wins America’s 100th Winter Olympics gold medal](https://www.usatoday.com/story/sports/olympics/2018/02/13/shaun-white-wins-americas-100th-winter-olympics-gold-medal/110399044/) | Jake Seiner (usatoday.com) [50:45]

**Novak Djokovic gets booed after having to pull out of the US Open**: [Novak Djokovic apologized and said his injury ‘hurt’ after tennis fans mercilessly booed him off the US Open court](https://www.businessinsider.com/novak-djokovic-injury-hurt-after-he-was-booed-off-court-2019-9) | Barnaby Lane (businessinsider.com) [54:15]

**Peter’s Jerry Rice poster he had as a kid**: [ORIGINAL 1995 JERRY RICE GOAT NIKE “JUST DID IT” #139 POSTER 2ND EDITION 23 X 35](https://thumbs.worthpoint.com/wpimages/images/images1/1/0216/08/1_b0937527a4e66f81e31726c75dfb87f3.jpg) | ([worthpoint.com](https://www.worthpoint.com/)) [54:45]

**A high percentage (maybe up to 80%) of retired Olympians suffer from depression**: [Escaping depression: Michael Phelps says up to 75 per cent of US Olympians may suffer mental health problems](https://www.scmp.com/sport/other-sport/article/2146823/escaping-depression-michael-phelps-says-75-cent-olympians-may) | Mathew Scott (scmp.com) [1:30:45, 1:55:45]

**Recommended books by David Brooks**: [1:39:45]

- [The Road to Character](https://www.amazon.com/gp/product/0812983416/ref=dbs_a_def_rwt_bibl_vppi_i1) (amazon.com)
- [The Second Mountain: The Quest for a Moral Life](https://www.amazon.com/gp/product/0812993268/ref=dbs_a_def_rwt_bibl_vppi_i0) (amazon.com)

**Book Sasha read that discussed the genesis of Eastern and Western thought and philosophy**: [The Art of War](https://www.amazon.com/Art-War-Sun-Tzu/dp/1599869772) | Sun Tzu (amazon.com)  [1:49:15]

**The documentary that Sasha is involved with that features Steven Holcomb’s story**: [The Weight of Gold](https://podiumpictures.com/weight-of-gold) | ([podiumpictures.com](https://podiumpictures.com/)) [1:51:30]

- *Here’s the trailer and panel discussion*: [The Weight of Gold│Mental Health & Young Americans: Breakdown or Breakthrough?](https://www.youtube.com/watch?v=LvaS1eN7Fdw) | Talkspace (youtube.com)

**The David Foster Wallace commencement speech**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) | Jamie Sullivan (youtube.com) [2:00:30]

§

## People Mentioned

- [Midori Ito](https://en.wikipedia.org/wiki/Midori_Ito) (first woman to land the triple axel in Olympics) [24:00]
- [Mirai Nagasu](https://en.wikipedia.org/wiki/Mirai_Nagasu) (first US woman to land the triple axel in Olympics) [24:00]
- [Elvis Stojko](https://en.wikipedia.org/wiki/Elvis_Stojko) ([landed a quad jump](https://www.youtube.com/watch?v=3uXs1SsluNY), great Canadian figure skater) [24:30]
- [Kurt Browning](https://en.wikipedia.org/wiki/Kurt_Browning) (great Canadian figure skater) [24:45, 1:08:15]
- [Apolo Ohno](https://en.wikipedia.org/wiki/Apolo_Ohno) [35:00, 49:30, 1:32:45, 1:53:45]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) [35:00, 49:30, 1:53:45]
- [Kristof Milak](https://en.wikipedia.org/wiki/Krist%C3%B3f_Mil%C3%A1k) (broke Phelps’s record in the 200 m fly) [35:45]
- [Shaun White](https://en.wikipedia.org/wiki/Shaun_White) [50:45, 1:53:45]
- [Missy Franklin](https://en.wikipedia.org/wiki/Missy_Franklin) (female swimmer, olympian) [51:45]
- [Novak Djokovic](https://novakdjokovic.com/) [54:15]
- [Jerry Rice](https://en.wikipedia.org/wiki/Jerry_Rice) [54:45]
- [Irina Slutskaya](https://en.wikipedia.org/wiki/Irina_Slutskaya) (Russian figure skater who was a rival of Sasha’s) [1:00:50]
- [Surya Bonaly](https://en.wikipedia.org/wiki/Surya_Bonaly) [1:08:15]
- [Michelle Kwan](https://en.wikipedia.org/wiki/Michelle_Kwan) [1:08:15]
- [Tom Dolan](https://en.wikipedia.org/wiki/Tom_Dolan) (back to back gold medals in the 400 IM in 1996 and 2000) [1:09:30]
- [Kristi Yamaguchi](https://en.wikipedia.org/wiki/Kristi_Yamaguchi) [1:16:30]
- [Brian Boitano](https://en.wikipedia.org/wiki/Brian_Boitano) [1:16:30]
- [David Brooks](https://en.wikipedia.org/wiki/David_Brooks_(commentator)) [1:39:45]
- [Confucius](https://en.wikipedia.org/wiki/Confucius) [1:49:15]
- [Aristotle](https://en.wikipedia.org/wiki/Aristotle) [1:49:15]
- [Plato](https://en.wikipedia.org/wiki/Plato) [1:49:15]
- [Steven Holcomb](https://en.wikipedia.org/wiki/Steven_Holcomb) [1:51:30]
- [Jeremy Bloom](https://en.wikipedia.org/wiki/Jeremy_Bloom) [1:51:45]
- [Brett Rapkin](https://twitter.com/brettrapkin?lang=en) (director of Weight of Gold) [1:51:45]
- [Jeret “Speedy” Peterson](https://en.wikipedia.org/wiki/Jeret_Peterson) (committed suicide, former olympian) [1:53:15]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (This is water speech) [2:00:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/11/sasha-bio-pic-500x466.png)

##### Sasha Cohen

Sasha is an American figure skater. She is the 2006 Olympic silver medalist, a three-time World Championship medalist, the 2003 Grand Prix Final Champion, and the 2006 U.S. Champion. She is known for her artistry, flexibility and body lines, and musical interpretation. As of 2019, Cohen is the last American woman to medal individually in figure skating at the Olympics. [wikipedia.org]

Twitter: [@SashaCohenNYC](https://twitter.com/SashaCohenNYC?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Instagram: [@SashaCohenNYC](https://www.instagram.com/sashacohennyc/?hl=en)

Website: [sashacohen.com](https://www.sashacohen.com/)