# The Ayrton Senna Episode (re-release): Celebrating the greatest driver in Formula 1 history and the cautionary tales of driven individuals

**Source:** [https://peterattiamd.com/ayrtonsenna/](https://peterattiamd.com/ayrtonsenna/)

---

To celebrate the life of the legendary Formula 1 driver Ayrton Senna, 25 years to the day of his tragic death, we are re-releasing this bonus episode. In this episode, Peter and med school colleague (and brilliant psychiatrist) Paul Conti reminisce on their favorite moments in Formula 1 history, their deep admiration for the late Ayrton Senna, and the remarkable careers of their favorite drivers. Paul also helps to illuminate the psychological components that made the luminary drivers great, and the cautionary lessons we can take from their incredible lives.

![The Peter Attia Drive](images/ayrtonsenna/the_Drive_public.png)

Play

The Ayrton Senna Episode (re-release): Celebrating the greatest driver in Formula 1 history and the cautionary tales of driven individuals

The Ayrton Senna Episode (re-release): Celebrating the greatest driver in Formula 1 history and the cautionary tales of driven individuals

1x15s30s

0:001:03:13

## We discuss:

- Who is Ayrton Senna? [3:47];
- How Senna’s death changed the sport [9:52];
- The 80s & 90s: a remarkable era of Formula 1 [12:57];
- Hypothesizing what caused Senna’s fatal crash [17:47];
- Comparing Stewart and Senna, their incredible bravery, and what lessons we can learn from them [23:32];
- Best documentaries on racing, and some of Senna’s best moments [31:02];
- Gilles Villeneuve, Stefan Bellof, and some of the other greats [39:17];
- Why Senna is widely acknowledged as the best of all time [46:17];
- Great rivalries and personalities [49:32];
- Rendezvous, a high-speed drive through Paris [56:52]; and
- More.

§

## Highlighted links:

The following links are some of Peter’s all-time favorites:

Articles about Ayrton Senna’s legacy:

- [Senna raised safety in Formula 1](https://www.ayrton-senna-dasilva.com/senna-raised-safety-in-formula-1/)
- [Remembering Ayrton Senna on his birthday](https://www.ayrton-senna-dasilva.com/remembering-ayrton-senna-on-his-birthday-2/)
- [The making of a Formula 1 legend](https://www.ayrton-senna-dasilva.com/the-making-of-a-formula-1-legend/)
- [Hamilton the only F1 driver to reach same level as Senna – Berger](https://www.autosport.com/f1/news/142910/hamilton-the-only-driver-on-senna-level--berger)

Qualifying lap at the 1988 Monaco Grand Prix – The best single lap in F1 history:  [Remember Senna](https://www.youtube.com/watch?v=xn8gh39SsrM)

Possibly one of the most nuanced docs (BBC): [BBC Ayrton Senna Documentary](https://www.youtube.com/watch?v=aQ6AyBPvclM)

Articles/videos about Ayrton’s tragic death at the [1994 San Marino Grand Prix](https://en.wikipedia.org/wiki/1994_San_Marino_Grand_Prix):

- [Remembering Imola 1994 (Part 1)](https://www.youtube.com/watch?v=3tVewW4xJ2g) and here’s [Part 2](https://www.youtube.com/watch?v=9ODtVMBYVpM)
- [F1: Ayrton Senna’s friend Gerhard Berger speaks for first time about the Brazilian’s death](https://www.independent.co.uk/sport/motor-racing/formula1/aryton-senna-formula-1-one-news-gerhard-berger-first-time-since-death-a8892226.html)

F1 drivers speculate on cause of Senna’s fatal crash: [Ex F1 Pilots Talk about The Cause of Ayrton Senna Fatal Crash](https://www.youtube.com/watch?v=OHDf3RNzfuo)

Pure gold!: [Punta Taco – Ayrton Senna](https://www.youtube.com/watch?v=BxH6PCG_U1Y&feature=youtu.be)

Recent articles/videos remembering Senna on the 25 anniversary of his death:

- Ranking Senna’s F1 cars: [Video: From Toleman to Williams – every Ayrton Senna F1 car ranked](https://www.autosport.com/f1/news/143088/video-every-senna-f1-car-ranked)
- [Ayrton Senna: 25 years since F1 lost its flawed, fascinating hero](https://www.theguardian.com/sport/2019/apr/29/ayrton-senna-25-years-f1-hero?CMP=Share_iOSApp_Other)
- [Ayrton Senna – His Final Hours](https://www.linkedin.com/pulse/ayrton-senna-his-final-hours-willem-toet)
- [Mark Webber reveals how Ayrton Senna’s death saved his own life](https://wwos.nine.com.au/motorsport/ayrton-senna-death-mark-webber-says-safety-improvements-saved-his-life/30a15986-a23c-4f5d-a189-2b24add7a045)
- [Who’s The Best Formula One Driver Of All Time?](https://fivethirtyeight.com/features/formula-one-racing/)
- [Senna’s ‘private kart mechanic’ Tche reveals the secret to his speed](https://www.racefans.net/2019/05/01/ayrton-senna-private-kart-mechanic-tche-reveals-secret-speed/)
- [Ayrton Senna: Top 10 moments in F1 that defined a legend](https://f1i.com/magazine/339094-ayrton-senna-top-10-defining-moments.html)

§

## Show Notes

## Ayrton Senna [3:45]

- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) is considered by many to be the greatest driver in Formula 1 history
- Tragically [died in a crash](https://en.wikipedia.org/wiki/Ayrton_Senna#Death) on May 1, 1994
- Paul and Peter both greatly admired him as a driver, and as a person
- Peter named one of his sons, Ayrton

What did Paul love about Senna?

- Not aware of anyone who has been more single-minded about achievement
- Moved the bar even higher for the definition of achievement
- Senna had exceptional physical stamina, training, controlling oneself mentally, honed reflexes, and the ability to multitask the mind and body to the very limit
- But at the same time, he was extremely humble
- He complimented his passion for driving with his intense passion for the suffering people of his home country of Brazil
- He did not broadcast this, but Senna had [big plans to help the educational system](https://www.cnn.com/2017/11/16/motorsport/ayrton-senna-foundation-sister-viviane-interview/index.html) in Brazil

What caused Senna’s downfall?

- He felt an extreme sense of responsibility to be the best for his country, and to make things better for them
- Paul believes Senna was a model for the best in us, but also a model for how we can have so many good qualities but be responsible for our own downfall
- He died, in the context of that drive, the inability to step back from the brink, his need to be better than everyone (not in an arrogant way), but in a way to feel self-worth (probably due to some trauma) that tends to isolate us, and create a feeling that there is never time to rest
- Peter: I get the sense that he felt the weight of a nation on his shoulders
- Paul: that has to be a shared responsibility . . . if you take that on yourself, you will cause your own demise

Lessons we can learn from Senna’s life

- Those blessed with ability and perseverance can cause their own downfall if they don’t recognize our limits
- Emblematic of the dangers that we can represent to ourselves and the need for compassion for ourselves
- Had Senna lived until 90, how much more could he have done for Brazil?

## How Senna’s death changed the sport [9:50]

- If you were to ask the top drivers of today ([Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton), [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel), [Daniel Ricciardo](https://en.wikipedia.org/wiki/Daniel_Ricciardo)), they will all tell you that Senna’s death is the single most important change in F1, it was the turning point in safety
- Senna, an intensely proud Brazilian, was found carrying an Austrian flag in his car during his fatal crash: Why? The day before, [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) had [died driving an F1 car](https://en.wikipedia.org/wiki/Roland_Ratzenberger#Death), and Senna, despite intense competition, had intense compassion for his peers
- This turning point caused a shift towards improved safety, a good thing, but along with trying to eliminate danger, they may have eliminated some of the limits of human ambition and bravery which is what distinguished the heroes due to the risks they were taking
- There was a time when 20-30% of drivers would be killed in a crash
- Formula 1 is an arena of human endeavor which can be tremendously inspiring, but the sport has gone so far in the direction of safety that there may never be an opportunity for another Senna without the same level of risk-taking

## The 80s & 90s: a remarkable era of Formula 1 [12:55]

- Senna’s era was remarkable due to the rivalries that existed, [Nigel Mansell](https://en.wikipedia.org/wiki/Nigel_Mansell), [Nelson Piquet](https://en.wikipedia.org/wiki/Nelson_Piquet), [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost), Senna (mid-1980s-mid-1990s)
- So much talent that someone like [Gilles Villeneuve](https://en.wikipedia.org/wiki/Gilles_Villeneuve), considered to be one of the greatest ever, did not even win a championship

What Senna could have accomplished had his career not ended tragically

- Senna won 3 championships but in Peter’s his eyes he won 4 (disqualification in the [1989 Japanese Grand Prix](https://en.wikipedia.org/wiki/1989_Japanese_Grand_Prix)), he thinks they just made a bad call (analogous to the [Hagler/Leonard fight](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler#Hagler_vs._Leonard))
- The season he died, he was driving the [Williams car](https://en.wikipedia.org/wiki/Williams_FW16), and after his death, his teammate, [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill), finished 2nd by 1 point to [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher)
- Senna was twice the driver of Hill, so had Senna not died, he would have been the 1994 world champion
- Both the 1996 champ (Damon Hill) and the 1997 champ ([Jacques Villeneuve](https://en.wikipedia.org/wiki/Jacques_Villeneuve)) were also driving the Williams car so you can assume Senna would’ve won those championships as well
- In all, Peter hypothesizes Senna could have taken 7 world championships

Hard to compare era to era

- [Juan Manuel Fangio](https://en.wikipedia.org/wiki/Juan_Manuel_Fangio), for example, won 5 world champs when barely anyone could even survive 5 seasons
- Arguably, the same feat is more impressive in the era of 1980s and 1990s, when cars were more similar to each other and the driver could make the difference
- Per Paul, the 80s and 90s were a “titanic struggle between exceptional personalities” which Paul posits is the attraction of Formula 1

Damon Hill

- He won the 1996 championship in Senna’s car (The Williams car)
- He was *the* example of an exceptional human

“We are infinitely infatuated by exceptional people, we want to understand them, we want to learn from them, we want to venerate them” —Paul

## Hypothesizing what caused Senna’s fatal crash [17:45]

- The official answer from the trial was that Senna’s tires had cooled during the first lap (which was stalled due to the need of safety vehicles to clear wreckage), so when Senna started back up, he lost traction
- [Here’s a youtube video](https://www.youtube.com/watch?v=OHDf3RNzfuo) of former F1 drivers discussing the possible cause
- [Here’s an article](https://www.skysports.com/amp/f1/news/12433/11168060/adrian-newey-reflects-on-ayrton-senna-loss-and-an-internal-struggle) with Adrian Newey, the chief designer of the Williams car when Senna was killed after crashing the FW16

Peter’s theory:

- Most likely the steering column broke before he went off the road
- Senna was known to modify his steering column
- Peter says you can see Senna violently turning the wheel with no response in the [onboard film](https://www.youtube.com/watch?v=_D6V6EK-yWw)

Paul’s theory:

- The Williams car was most the sophisticated of them all (even by today’s standards), and Paul just thinks he took the turn too fast
- When you combine that with other factors (like the cool tires) he just lost traction
- But Paul believes the underlying reason that Senna pushed it so hard was his “hubris of brilliance” and his drive to win that race at all costs in order to honor the death of the [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) (Austrian driver who had died the day before)
- Senna’s plan was to win that race and fly the Austrian flag during his victory lap which, “would have been one of the most memorable moments in the history of the sport”
- “He was so driven to win that race, and it cost him his life”
- Sid Watkins reported that Senna wasn’t himself in the paddock prior to the race that killed him, [he even tried to talk Senna into retiring](https://bleacherreport.com/articles/844103-the-great-mans-final-24-hours-what-was-the-mindset-of-senna-in-that-final-day)

## Comparing Stewart and Senna, their incredible bravery, and what lessons we can learn from them [23:30]

Both [Jackie Stewart](https://en.wikipedia.org/wiki/Jackie_Stewart) and Ayrton Senna witnessed a tragedy, but had drastically different reactions:

Jackie Stewart

- His teammate, [François Cevert](https://en.wikipedia.org/wiki/Fran%C3%A7ois_Cevert), died in qualifying for [Watkins Glen](https://en.wikipedia.org/wiki/Watkins_Glen_International) and Jackie retired after that: “it was enough, it’s over”
- Cevert was Jackie’s understudy and Jackie wanted to impart all his knowledge on him
- When Jackie started racing, there was only a 30% survival rate in the sport
- Jackie went on to help develop better safety measures in the sport
- Taking this kind of risk took an incredible amount of bravery

Ayrton Senna

- In contrast to Jackie Stewart’s reaction, Senna was compelled to push the limits even further after the death of Ratzenberger, evidence of the different character structures of Stewart and Senna
- Paul says the drive in Senna was likely the manifestation of some trauma, the feeling that he was never good enough
- Senna felt he had to “save his country . . . save the world,” which had fatal consequences
- Senna used to train by running in the heat with his uniform and helmet on until he collapsed
- In 1993, [Senna won Brazilian Grand Prix](https://www.youtube.com/watch?v=CVSgOIAOW7g) despite his [gear shifter being stuck](https://www.youtube.com/watch?v=8bf3uUdHMqo) for a significant portion of the race: his muscle cramping from the heat and difficulty of driving in a stuck gear was so bad they had to literally pull him out of the car, so much pain, he couldn’t hold up the trophy

The tenacity and bravery of a special era, and the lessons we can learn

- The drive of human performance that we could witness, the tenacity, the drive, we don’t get to witness this kind of bravery much more in sport, or really any aspects of life
- We respect it so infinitely but there is danger in identifying with this drive too much, “. . . for every person who jumps out a trench and saves somebody, how many jump out of a trench and end up dead?”
- Senna is a lesson for Paul, there were a lot of warning signs in Senna, such as the manifestations of some kind of trauma that Senna must have experienced causing the extreme need to achieve
- “Senna had a drive in him that went against rationality and survival instincts”

## Best documentaries on racing, and some of Senna’s best moments [31:00]

2 best documentaries on racing:

1. [Senna](https://www.youtube.com/watch?v=FUADzkUSDq0)
2. [1](https://www.youtube.com/watch?v=9jI1wvuf_rc)

Some of Senna’s greatest moments:

- The [Donington first lap](https://www.youtube.com/watch?v=3GOEorrE4mY) when Senna passed 3 other drivers in the rain
  - “Greatest lap in the history of Formula 1”
  - “If this lap was in a movie they would say, ‘this is too unrealistic’”
- Qualifying lap at [1988 Monaco Grand Prix](https://en.wikipedia.org/wiki/1988_Monaco_Grand_Prix)  ([MP4/4](https://www.youtube.com/watch?v=uAyT9zPQYUk))
  - He finished ahead of Prost by 1.5 seconds, “an impossible amount of time”
  - And this was against Prost, who was driving the SAME CAR
  - There is a video showing Prost’s look of disbelief when he sees Senna’s time
  - Peter says there is not any onboard film of this particular lap, but if someone can find the actual onboard lap, Peter will give them a case of [Topo Chico](https://www.topochicousa.net/) ([this article](https://www.foxsports.com.au/motorsport/formula-one/f1-mythbusting-ayrton-sennas-epic-1988-monaco-gp-pole-position-lap/news-story/4d6a7c605350e1f016018a6c5f185379) claims there were no onboard cameras used in 1988)
  - Senna says he was at the “peak of his career” at the Monaco qualifying lap
  - Senna’s qualifying lap was 1:23.998 (the fastest lap on record is 1:14.260, by [Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen): note from Peter: *it’s difficult to compare laps between years because of the year on year changes that occur in F1*)
  - [Here’s a video](https://twitter.com/McLarenF1/status/996004326714806272/video/1) (via Tweet) from McLaren, remembering Senna’s fabled lab

“The best in the world can take the car to the limit and *never* go over it”

## Gilles Villeneuve, Stefan Bellof, and some of the other greats [39:15]

- Villeneuve, a driver for Ferrari (1977-1982), was known for his talent, fearlessness, and the ability to make a car do seemingly impossible things
- [Enzo Ferrari](https://en.wikipedia.org/wiki/Enzo_Ferrari), who believed the driver [Tazio Nuvolari](https://en.wikipedia.org/wiki/Tazio_Nuvolari) was the pinnacle of greatness back in the 1930s, felt as if he had found the spirit of Nuvolari inside of Villeneuve

What is it that Paul admired about [Gilles Villeneuve](https://en.wikipedia.org/wiki/Gilles_Villeneuve)?

- Paul was a kid first learning about him and he was so impressed by: “the glory of utter mastery of something that was venerated on a worldwide scale”
- There was no one with as much natural talent (closest comparables would be guys like [Stefan Bellof](https://en.wikipedia.org/wiki/Stefan_Bellof), [Juan Manuel Fangio](https://en.wikipedia.org/wiki/Juan_Manuel_Fangio), [Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark), and Senna)
- The “utter audacity” of him going from a snowmobile racer, to a few years later driving for Ferrari (not known as a dominant car), and winning, “he won in a truck”
- Innate skill and utterly undaunted bravery
- Villeneuve had no fear, “which I think is *extremely* dangerous”

“If we’re going to respect and . . . venerate humans who have preternatural talent and are willing to take risks, then we also have to acknowledge the outcome isn’t always glorious . . . it is often simply tragic” —Paul

Villeneuve’s tragic death

- Villeneuve’s teammate, [Didier Pironi](https://en.wikipedia.org/wiki/Didier_Pironi) had a big ego, and had done some deceitful things
- For example, Pironi had passed Villeneuve at a point in the race which was against team orders
- These types of events spurred an incredible rivalry and when added to Villeneuve’s driven attitude, this ultimately proved fatal for Villeneuve
- He [died in a qualifying session](https://en.wikipedia.org/wiki/Gilles_Villeneuve#Death) when he was determined to beat Pironi’s time and possibly pushed it too hard
- Paul posits his death was caused by “his absence of fear, the anger of having been deceived, in many ways the naïveté”
- Read the [story of their rivalry](https://www.redbull.com/us-en/gilles-villeneuve-didier-pironi-rivalry)

Stefan Bellof

- [Stefan Bellof](https://en.wikipedia.org/wiki/Stefan_Bellof#Death), a man of comparable talent, drive, and fearlessness, also succumbed to a tragic death on the track
- Bellof’s record at [Nürburgring](https://en.wikipedia.org/wiki/N%C3%BCrburgring) was [just now broken](https://www.youtube.com/watch?time_continue=109&v=LAQJl3Taqm4) (stood for 35 years)
- The most daunted track, Jackie Stewart called it the “green hell”

These guys really had “no concept of self-preservation” —Paul

## Why Senna is widely acknowledged as the best of all time [46:15]

Few examples of situations where both the generation *before and after* will acknowledge someone as the greatest, but that’s what it’s like for Senna

- Fangio, on shortlist for best drivers ever, would say “lo mejor,” meaning, “the best,” when describing Senna
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton), the best driver of today, says Senna is best
- Drivers from Senna’s time, also say Senna is best

What made him the best?

- He had the combination of talent, dedication, and the desire to understand every nuance imaginable
- Wanted to understand *every* single thing about his car, the engine, the people
- He approached every detail as if it was imperatively relevant

## Great rivalries and personalities [49:30]

Prost vs Senna

- Alain Prost and Senna had a hostile relationship during their careers
- Prost was a practical man given the nickname “The Professor,” and his goal was to win as much as he can (like it’s a probabilistic game), and wanted to survive the process
- Senna, by contrast, was driven to win every practice session, qualifying round, every lap, every race, etc. They were going to clash, for sure, in deeply personal ways
- Prost would say, “the problem is that Senna thinks he can’t die . . . like he has a God-given right to win every race no matter what”
- But they ultimately had deep respect for each other
- After Prost retired, he became a commentator, and on the very day that Senna was killed, Senna made a [gracious comment over the radio transmission towards Prost](https://www.youtube.com/watch?v=W5YCdB4v6NU), which left Prost incredibly moved (a week later Prost was a pallbearer)

Mansell vs Piquet

- Nigel Mansell and [Nelson Piquet](https://en.wikipedia.org/wiki/Nelson_Piquet) were both members of the Williams team, “[Frank Williams](https://en.wikipedia.org/wiki/Frank_Williams_(Formula_One)) loved pitting people against each other”
- Paul says Nigel Mansell was “the most exciting person I ever watched drive” but he was considered the #2, first to [Mario Andretti](https://en.wikipedia.org/wiki/Mario_Andretti), and then Nelson Piquet
- Mansell was not okay with this, and Williams said, if you want to be #1, go out and prove it
- Piquet was ego-driven, and treated Mansell with denigration and condescension
- This infuriated Mansell, and drove him to be considered among the greats
- Mansell did “impossible things with aggression,” such as [famously passing Gerhard Berger in Mexico City](https://www.youtube.com/watch?v=V2g1yrGputA)
- Senna said Mansell will “go over you if he can’t go around you”

These personalities made for an unbelievable era (the 80s and 90s)

- Peter actually prefers watching old races to today’s live races (although it’s getting more exciting today as Mercedes and Ferrari are becoming very competitive)
- So much of it today is about the car, and less about the driver, versus back then you really got to see the driver’s make the difference
- Paul says the force of personality combined with incredible human potential (stamina, reflexes, cognitive ability) could lead to “seemingly impossible things”

“It gives us an insight into things we usually don’t see . . . this is like human struggle under the microscope, but it’s emblematic of all sorts of human struggle that often is inaccessible to us, because it’s in a place we can’t go . . . the quiet struggles of the uncelebrated, as much as it could be the battlefield” —Paul

## Rendezvous, a high-speed drive through Paris [56:50]

- Peter and Paul watched [Rendezvous](https://vimeo.com/34039780), a film by [Claude Lelouch](https://en.wikipedia.org/wiki/Claude_Lelouch) of a high-speed drive through the streets of Paris, over 50 times in med school
- It’s still a mystery as to who was the driver: Could it be [Jacky Ickx](https://en.wikipedia.org/wiki/Jacky_Ickx)? Could it be [Depailler](https://en.wikipedia.org/wiki/Patrick_Depailler)?
- Peter says it “had to be someone who was amazing, fearless, and know Paris like the back of their hand”
- But whoever was driving put himself and others at major risk
- Legend has it that Lelouch was arrested after the film was released
- It’s clear that Lelouch was superimposed, he wasn’t the driver, there’s no way
- Emblematic of an era, the first time cameras could be mounted in cars, and the sound is that of a Ferrari, but could have been dubbed over by a Mercedes

§

## Selected Links / Related Material

- **Senna’s fatal crash**:[Ayrton Senna’s Death](https://en.wikipedia.org/wiki/Ayrton_Senna#Death) | (wikipedia.org) [3:45]
- **Senna’s plans to help Brazilian education**: [Ayrton Senna: How F1 legend’s legacy is helping educate Brazil’s youth](https://www.cnn.com/2017/11/16/motorsport/ayrton-senna-foundation-sister-viviane-interview/index.html) | Amanda Davies & David Stokes (cnn.com) [8:15]
- **Senna planned to fly the Austrian flag**: [Roland Ratzenberger’s death](https://en.wikipedia.org/wiki/Roland_Ratzenberger#Death) | (wikipedia.org) [10:00]
- **Senna’s controversial disqualification costing him a win**: [1989 Japanese Grand Prix](https://en.wikipedia.org/wiki/1989_Japanese_Grand_Prix) | (wikipedia.org) [14:15]
- **Peter compares Senna’s disqualification to the bad call made in this famous fight**: [Hagler vs. Leonard](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler#Hagler_vs._Leonard) | (wikipedia.org) [13:45]
- **The Williams car was driven by Senna when he died**: [Williams FW16](https://en.wikipedia.org/wiki/Williams_FW16) | (wikipedia.org) [14:30]
- **Former drivers hypothesize what caused Senna’s fatal crash**: [Ex F1 Pilots Talk about The Cause of Ayrton Senna Fatal Crash](https://www.youtube.com/watch?v=OHDf3RNzfuo) | UniversalSoljrr (youtube.com) [17:45]
- **FW16 car designer discussing the fatal crash**: [Adrian Newey reflects on Ayrton Senna loss and an internal struggle](https://www.skysports.com/amp/f1/news/12433/11168060/adrian-newey-reflects-on-ayrton-senna-loss-and-an-internal-struggle) | Matt Morlidge (skysports.com) [17:45]
- **Onboard film of Senna’s fatal crash**: [Formula 1 – Ayrton Senna Crash (Car Camera Zoomed On Steering Wheel)](https://www.youtube.com/watch?v=_D6V6EK-yWw) | gubors (youtube.com) [18:00]
- **Sid Watkins final conversation with Senna before last race**: [Ayrton Senna’s Final 24 Hours: What Was His Mindset That Day?](https://bleacherreport.com/articles/844103-the-great-mans-final-24-hours-what-was-the-mindset-of-senna-in-that-final-day) | Matt Hill (bleacherreport.com) [19:30]
- **Track where Jackie Stewart’s teammate died**: [Watkins Glen International](https://en.wikipedia.org/wiki/Watkins_Glen_International) | (wikipedia.org) [23:30]
- **Senna’s remarkable victory in 1991**: [Ayrton Senna Wins The 1991 Brazilian Grand Prix](https://www.youtube.com/watch?v=CVSgOIAOW7g) | FORMULA 1 (youtube.com) [26:00]
- **Senna’s gear shift stuck in 6th gear and still wins**: F1 1991: [Ayrton Senna Wins First Brazilian Grand Prix Stuck In 6th Gear – Formula One Highlights HD](https://www.youtube.com/watch?v=8bf3uUdHMqo) | SANFRANFANAD (youtube.com) [26:00]
- **Documentary about Senna recommended by Peter**: [AYRTON SENNA STORY | Full Documentary](https://www.youtube.com/watch?v=FUADzkUSDq0) | Documentary Channel (youtube.com) [31:00]
- **The most dominant car in Formula 1 history**: [Step inside the MP4/4](https://www.youtube.com/watch?v=uAyT9zPQYUk) | McLaren (youtube.com) [31:00]
- **Documentary about Formula 1 recommended by Peter**: [1 – Life on the Limit](https://www.youtube.com/watch?v=9jI1wvuf_rc) | Yanina Ayala Herrera (youtube.com) [31:00]
- **Donington First Lap when Senna passed 3 other drivers in the rain**: [F1’s Greatest Lap? Ayrton Senna at Donington 1993](https://www.youtube.com/watch?v=3GOEorrE4mY) | FORMULA 1 (youtube.com) [31:35]
- **Qualifying lap at Monaco**: [1988 Monaco Grand Prix](https://en.wikipedia.org/wiki/1988_Monaco_Grand_Prix) | (wikipedia.org) [33:05]
- McLaren remembers Senna’s qualifying lap: “[On the anniversary of Ayrton Senna’s fabled qualifying lap at Monaco in 1988, we remember that remarkable moment](https://twitter.com/McLarenF1/status/996004326714806272/video/1).” | McLaren (@McLarenF1 on Twitter) [33:05]
- **Article explaining the lack of video of famous Monaco lap**: [F1: Mythbusting Ayrton Senna’s epic 1988 Monaco GP pole position lap](https://www.foxsports.com.au/motorsport/formula-one/f1-mythbusting-ayrton-sennas-epic-1988-monaco-gp-pole-position-lap/news-story/4d6a7c605350e1f016018a6c5f185379) | Will Dale (foxsports.com) [33:05]
- **Peter’s favorite beverage**: [Topo Chico](https://www.topochicousa.net/) | (topchicousa.net) [34:30]
- **Where Peter likes to practice driving:** [Buttonwillow Raceway Park](https://en.wikipedia.org/wiki/Buttonwillow_Raceway_Park) | (wikipedia.org) [37:30]
- **Timo Bernhard breaks Stefan Bellof’s 35-year-old record at Nürburgring**: [Timo Bernhard sets blazing lap record in Porsche 919 Hybrid Evo](https://www.youtube.com/watch?time_continue=109&v=LAQJl3Taqm4) | PCAHQ (youtube.com) [41:20]
- **Article about the rivalry of Villeneuve and Pironi**: [Find out about F1’s most tragic rivalry | James Roberts](https://www.redbull.com/us-en/gilles-villeneuve-didier-pironi-rivalry) (redbull.com) [44:00]
- **Audio of Senna’s gracious words about Prost**: [Voices from Imola: Ayrton Senna greetings Alain Prost [1994]](https://www.youtube.com/watch?v=W5YCdB4v6NU) | EveryDay Documentaries (youtube.com) [49:40]
- **Mansell famously passing Berger in Mexico City**: [Mansell vs. Berger – Mexico 1990](https://www.youtube.com/watch?v=V2g1yrGputA) | 5150UK (youtube.com) [53:15]
- **A high-speed drive through Paris**: [Rendezvous](https://vimeo.com/34039780) | Matthew Fisher (vimeo.com) [56:50]

§

## People Mentioned

- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) (greatest driver in history) [3:45, 9:50, 14:15, 17:30, 23:00, 30:15, 46:20, 49:30]
- [Sid Watkins](https://en.wikipedia.org/wiki/Sid_Watkins) (race track doctor) [8:05, 23:20]
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton) (top driver of today) [9:50]
- [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel) (top driver of today) [9:50]
- [Daniel Ricciardo](https://en.wikipedia.org/wiki/Daniel_Ricciardo) (top driver of today) [9:50]
- [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) (Senna died trying to honor his death) [10:00]
- [Nigel Mansell](https://en.wikipedia.org/wiki/Nigel_Mansell) (rivalries in the 1980s/1990s) [13:00, 53:15]
- [Nelson Piquet](https://en.wikipedia.org/wiki/Nelson_Piquet) rivalries in the 1980s/1990s) [13:00, 52:15]
- [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost) rivalries in the 1980s/1990s) [13:00, 32:00, 49:15]
- [Gilles Villeneuve](https://en.wikipedia.org/wiki/Gilles_Villeneuve) (one of Paul’s favorites) [13:25, 39:30]
- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) (1996 champ) [14:15, 16:15]
- [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) (1994 champ) [14:15]
- [Jacques Villeneuve](https://en.wikipedia.org/wiki/Jacques_Villeneuve) (1997 champ) [14:45]
- [Juan Manuel Fangio](https://en.wikipedia.org/wiki/Juan_Manuel_Fangio) (all-time great) [15:15, 39:50, 46:15]
- [Jackie Stewart](https://en.wikipedia.org/wiki/Jackie_Stewart) (3-time champ, instrumental in advancing the safety of Formula 1) [23:35]
- [François Cevert](https://en.wikipedia.org/wiki/Fran%C3%A7ois_Cevert) (teammate of Jackie Stewart who died, triggering Stewart to retire) [23:35]
- [Stefan Bellof](https://en.wikipedia.org/wiki/Stefan_Bellof) (known for setting the record at [Nürburgring](https://en.wikipedia.org/wiki/N%C3%BCrburgring) which stood for 35 years) [39:50]
- [Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark) (won 2 world championships in the 1960s) [39:50]
- [Enzo Ferrari](https://en.wikipedia.org/wiki/Enzo_Ferrari) (founder of Ferrari racing team) [42:25]
- [Tazio Nuvolari](https://en.wikipedia.org/wiki/Tazio_Nuvolari) (famous driver in the 1930s) [42:45]
- [Didier Pironi](https://en.wikipedia.org/wiki/Didier_Pironi) (rival and teammate of Bellof) [44:10]
- [Frank Williams](https://en.wikipedia.org/wiki/Frank_Williams_(Formula_One)) (founder of Williams Formula 1 team) [51:45]
- [Mario Andretti](https://en.wikipedia.org/wiki/Mario_Andretti) (driver for Williams) [53:20]
- [Gerhard Berger](https://en.wikipedia.org/wiki/Gerhard_Berger) (famously passed by Nigel Mansell in Mexico City) [53:15]
- [Claude Lelouch](https://en.wikipedia.org/wiki/Claude_Lelouch) (the filmmaker who produced [Rendezvous](https://vimeo.com/34039780)) [57:15]
- [Jacky Ickx](https://en.wikipedia.org/wiki/Jacky_Ickx) (possibly the driver in [Rendezvous](https://vimeo.com/34039780)) [58:10]
- [Patrick Depailler](https://en.wikipedia.org/wiki/Patrick_Depailler) (possibly the driver in [Rendezvous](https://vimeo.com/34039780)) [58:15]

§