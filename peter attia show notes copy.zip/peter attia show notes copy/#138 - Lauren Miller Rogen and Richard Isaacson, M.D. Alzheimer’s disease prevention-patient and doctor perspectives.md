# #138 – Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer’s disease prevention—patient and doctor perspectives

**Source:** [https://peterattiamd.com/laurenmillerrogen-richardisaacson/](https://peterattiamd.com/laurenmillerrogen-richardisaacson/)

---

##### Check out more content with neurologist, Richard Isaacson, M.D.:

- *(Oct 1, 2018)* [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](/richardisaacson/)
- *(Nov 22, 2020)* [Q&A on Alzheimer’s disease drug therapy with Dr. Richard Isaacson](/qa-with-dr-richard-isaacson-on-aducanumab-alzheimers-disease-drug-therapy/)
- *(Nov 23, 2020)* [#138 – Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer’s disease prevention—patient and doctor perspectives](/laurenmillerrogen-richardisaacson/)

Peter is joined by writer, director, actress, and founder of [HFC](https://wearehfc.org/), Lauren Miller Rogen, and previous podcast guest and director of the Alzheimer’s Prevention Clinic at Weill Cornell Medicine and New York-Presbyterian, Dr. Richard Isaacson. In this episode, Lauren tells the heartbreaking story of watching members of her family succumb to Alzheimer’s disease (AD) which motivated her to proactively address her own risk with Richard’s guidance. Richard discusses the various genetic and lifestyle factors that influence the risk of AD and uses Lauren’s unique situation to explain how he diagnoses patients and personalizes care. They go through Lauren’s protocol of preventative measures that have already produced marked results, and end with the uplifting message that one’s genetic predisposition does not seal one’s fate.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/laurenmillerrogen-richardisaacson/the_Drive_public.png)

Play

#138 - Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer's disease prevention—patient and doctor perspectives

#138 - Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer's disease prevention—patient and doctor perspectives

1x15s30s

0:002:11:39

## We discuss:

- Lauren’s deep family history of Alzheimer’s disease (3:10);
- The influence of genetics, epigenetics, and lifestyle on Alzheimer’s disease risk (13:45);
- Lauren’s mother’s disease progression and the enormous stress it causes for family members (24:30);
- The various manifestations of Alzheimer’s disease depending on the location of pathology (29:30);
- The three stages of Alzheimer’s disease (34:45);
- Richard’s deep exploration into Lauren’s family history revealing clues about a diagnosis and a roadmap to successful disease mitigation (39:15);
- How exercise reduces Alzheimer’s disease risk, and the different risk between males and females (58:00);
- Why knowing your APOE status is important, and whether certain people should be wearier of head trauma (1:08:00);
- How Richard uses genetic testing to personalize care (1:14:45);
- The “ABCs” of Alzheimer’s prevention, lifestyle interventions, and Lauren’s personal protocol for reducing her risk (1:21:45);
- Unique treatment for people with the ApoE4 variant (1:36:30);
- Richard’s mixed opinion on CBD and THC as a tool for disease prevention (1:40:00);
- Cognitive testing procedures, and how Lauren’s tests furthered her commitment to her disease prevention protocol (1:41:45);
- The relevance of sense of smell and hearing in Alzheimer’s disease risk and prevention (1:50:00);
- The emotional benefit of knowing you have control over your mental and physical health (1:57:30);
- HFC—a charitable organization founded by Lauren and Seth (2:00:15); and
- More.

§

## Show Notes

## Lauren’s deep family history of Alzheimer’s disease [3:10]

**Family history of Alzheimer’s disease**

- Her **maternal grandfather** had Alzheimer’s disease (AD), started showing symptoms in his late fifties/early sixties and was put into a nursing home when Lauren was 9 or 10
- After Lauren’s grandfather passed away, her **grandmother** began showing symptoms of AD and she also ended up in a nursing home and died in her mid 70s

**Losing her mother to Alzheimer’s disease**

- At the time of Lauren’s college graduation, she noticed her **mother** (just 52 years old) repeating stories—something that really worried Lauren
  - Within a year or two, she was losing her ability carry out her job as a teacher and function as a cognitively healthy person would
  - At this point, they brought her to a doctor and Lauren’s mother was given “as much as a diagnosis as one could get at that time”
- At this point, it was clear there was something going on in the family with AD
- Lauren was confronted with a difficult mix of emotions, including fear, anger, depression, and **denial** (Lauren said her father was in the most denial)
- In 2005, Lauren finally admitted out loud that her mom was suffering from AD

> “Who she was, was just fading away and changing right in front of her eyes.” —Lauren Miller Rogen

- After another couple of years,
  - it was clear that Lauren’s mother should not be driving or be teaching in a traditional classroom
  - She was also unable to carry out long conversations
  - This was devastating for Lauren and was a dark time for her
- **What scared her mother the most about having AD**: “*And she told me that she wasn’t scared for her. She was scared for me and my brother and my dad, because I think she got that at some point she may not know what’s happening, and that the weight would be on us*.”
- *Devastating consequences*:
  - At this point, Lauren was a young adult and just beginning to interact with her mother as a friend more so than a mom
  - Being deprived of the opportunity to develop this friendship with her mother was very difficult for Lauren
  - Lauren was intent on finding a way to help her mother, but despite her best efforts, she found nothing

> “There was nothing. And so it was a really scary, hard time where I felt like I could do nothing and that this train had left the station for my mom and that was it.” —Lauren Miller Rogen

## The influence of genetics, epigenetics, and lifestyle on Alzheimer’s disease risk [13:45]

**Richard’s perspective on Alzheimer’s disease**

- Richard sees it as an insidious disease – he “hates” it because it not only robs the person with it of who they are, but also robs the entire family
- Alzheimer’s begins in the brain about a **decade before the first symptoms of memory loss**, and this is something many doctors are still unaware of
- Onset of Alzheimer’s symptoms usually occurs in one’s seventies, but with [early-onset Alzheimer’s disease](https://en.wikipedia.org/wiki/Early-onset_Alzheimer%27s_disease), symptoms can begin in one’s forties or fifties
- While genetics is often responsible for an early onset of Alzheimer’s disease, Richard points out that there are cases when there is more to the story that can cause an earlier onset (lifestyle, head trauma, comorbidities, etc.)
  - Richard suspects this might be the case with Lauren’s family – “there’s a one plus one equals three here”

> “… could it be lifestyle? Could it be an exposure to something? Could it be head trauma? Could it be uncontrolled diabetes, high blood pressure, cholesterol? These are all things that just synergize together to potentially make a late onset Alzheimer’s case start earlier.” —Richard Isaacson

**Genetic risk factors for** [**early-onset Alzheimer’s disease**](https://en.wikipedia.org/wiki/Early-onset_Alzheimer%27s_disease)

- Genes known to cause **early-onset Alzheimer’s disease**: Variations in the genes for [presenilin-1](https://en.wikipedia.org/wiki/PSEN1), [presenilin-2](https://en.wikipedia.org/wiki/PSEN2), and [amyloid precursor protein](https://en.wikipedia.org/wiki/Amyloid_precursor_protein) gene mutation
  - These variations are quite rare (far less than 1% of people):
    - Richard has only had a few patients (out of more than 1,500) that have had one of these variations
    - Peter has never had a patient with one of them

**Genetic and epigenetic causes pushing onset of AD earlier in life**

Most people that get AD earlier in life don’t have “early-onset Alzheimer’s disease” but rather they have a “milieu of things” aka **polygenic risk** and [**epigenetics**](https://en.wikipedia.org/wiki/Epigenetics) that simply push the onset of AD earlier in life

- For example, the [apolipoprotein E](https://en.wikipedia.org/wiki/Apolipoprotein_E) (ApoE) gene variants
  - The E4 variant raises AD risk
  - In contrast, the E2 variant is protective and the E3 variant, which is most common, is neutral
- Lifestyle and behavioral characteristics
  - Diet
  - Exercise
  - Head trauma
  - Comorbidities (e.g., diabetes, high blood pressure, cholesterol)

> “Genes are not our destiny. We can absolutely win the tug of war against our genes.” —Richard Isaacson

![](https://peterattiamd.com/wp-content/uploads/2020/11/fig-1-rogen-1024x504.png)

**Figure 1. Genetic influence on early and late Alzheimer’s disease risk.** Image credit: [ncbi.nlm.nih.gov](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4421904/figure/DialoguesClinNeurosci-17-79-g003/)

**The future of Alzheimer’s disease prevention and treatment:**

- And there are usually multiple genes involved, which is why Richard believes that the future of Alzheimer’s prevention will be based on [precision medicine](https://en.wikipedia.org/wiki/Precision_medicine)
- Using these types of genetic underpinnings, understanding all the individual genes that impact a person’s risk, figuring out what they are, figuring out what their biological function is, figuring out why it puts a person down the path towards Alzheimer’s and then telling that person to do A, B, C, X, Y, and Z to get them **off the path** towards Alzheimer’s

**What is it about APOE4 that confers more risk for AD?**

- ApoE is involved in cholesterol transport
- The ApoE4 variant is also a cardiovascular risk factor
- People with the ApoE4 variant typically accumulate more [amyloid](https://en.wikipedia.org/wiki/Amyloid_beta) protein in their brains
- According to Richard, ApoE4 is understood well enough that it is not as much of a concern compared to the other contributing factors that we do not yet understand as well

## Lauren’s mother’s disease progression and the enormous stress it causes for family members [24:30]

**Lauren’s wedding**

- When Lauren was planning her wedding, her mother had just turned 60—she was still able to walk and dress herself, but she need full time care and was not always aware of where she was or even that Lauren was her daughter
- Lauren could not even have her mother around while getting ready for the wedding because she would wander off
- At the rehearsal dinner, Lauren’s mother, being uncomfortable and in an unfamiliar setting told Lauren that she just wanted to go home–This was “really hard to handle” for Lauren
- Although Lauren never had the moment with her mother she had long expected, she is grateful for the extent that her mother was able to participate and recognize
- Lauren describing the contrast of her mother’s behavior at the wedding versus the rehearsal dinner: “*But then miraculously, the day of she walked in and she called me the bride and she knew that I was the bride and that I think she knew that I was her daughter. But she knew she felt proud. She knew she felt love. And I have an amazing photo of her looking at me and holding my hand. And it’s just, she knows that there’s a connection there …*”
- In regard to her mothering recognizing her, Lauren said: “*Once that’s gone, that’s gone. But for whatever reason, the day of my actual wedding, I will say she was as there as anyone could be in her state.*”

Stress on the family

- The stress for the family caring for a family member with AD cannot be understanded
- Lauren’s father was taking the brunt of the stress as the primary caretaker
- On the plane back home from Lauren’s wedding, her mother was acting out and screaming and had an accident on the seat — her father described is as “the worst five hours of his life”

## The various manifestations of Alzheimer’s disease depending on the location of pathology [29:30]

**How the location of pathology influences disease outcome**

- The progression of Alzheimer’s is commonly represented by [Braak staging](https://en.wikipedia.org/wiki/Braak_staging), which describes how different changes in function and behavior occur as Alzheimer’s pathology spreads throughout the brain
- Although understanding of Alzheimer’s symptoms was once limited to just changes in short-term memory, it is now known that symptoms are much more diverse and related to which areas of the brain are affected by the pathology

> “*Wherever the pathology goes, those are the symptoms that manifest*.” —Richard Isaacson

- A few examples of different manifestations of Alzheimer’s disease:
  - [Dysexecutive syndrome](https://en.wikipedia.org/wiki/Dysexecutive_syndrome), which affects judgment and planning
  - [Primary age-related tauopathy](https://en.wikipedia.org/wiki/Primary_age-related_tauopathy) (PART) is more related to short-term memory
    - But this person could maintain their executive function
- Differences in manifestation are mainly dictated by which regions of the brain are affected by the disease
- For example, when someone has pathology in the back of the brain, where vision processing occurs, they may have difficulty interpreting images
- Based on this, Peter offers the analogy that **like cancer, Alzheimer’s is more than just one disease**

## The three stages of Alzheimer’s disease [34:45]

**How would Richard think about Lauren’s mom’s case based on what Lauren described?**

- Her symptoms began with little repeating of stories, and memory glitches around 52 to 54 resulting in a modified work schedule
- Six years later, she’s having trouble caring for herself, maybe not recognizing her daughter, and then having emotional behavioral psychiatric components
- That sounds like Alzheimer’s disease—progressive short-term memory loss, plus behavioral changes, plus other things
- She started in the mild cognitive impairment phase with the symptoms (stage 2 of AD)

**The three stages of Alzheimer’s disease**:

**Stage 1**: Preclinical phase where Alzheimer’s disease has started in the brain, but there are no clinically apparent symptoms

- Richard says there could be up to 46 million Americans with Alzheimer’s disease in their brain right now, but no symptoms
- This stage is by far the most important phase to focus on because that would be the time where you could intervene and try to prevent the dementia from happening

**Stage 2**: Mild cognitive impairment (MCI) due to Alzheimer’s

- There are enough memory glitches and other changes to where it’s noticeable, it’s greater than a standard deviation and a half below the norm, but the person can still take care of themselves

**Stage 3**: Dementia

- Studies suggest there’s a 12-16% per year of converting from MCI to dementia
- The only difference bt MCI and dementia is that the same symptoms are just worse and they can no longer take care of themselves

> “*Believe it or not, there are 46 million Americans with Alzheimer’s disease in their brain right now, but no symptoms.*” —Richard Isaacson

## Richard’s deep exploration into Lauren’s family history revealing clues about a diagnosis and a roadmap to successful disease mitigation [39:15]

**Lauren’s uncle’s battle with Alzheimer’s disease**

- Lauren’s mother’s brother, who was 5 years older than her mother, started showing symptoms in his mid-60s
- Knowing how destructive the disease was for her mother (who was already bedridden at this point),  Lauren sought out the best east coast physician and was recommended into Richard

**Meeting Richard becoming a patient**

- Shortly after connecting her uncle with Richard, Lauren wanted to visit the clinic and meet Richard
- During her visit, she ended up demanding to become a patient
- As Richard recounts, Lauren shot her arm out and said “*Take my blood now. Let’s do it.*”

- From there, Richard’s ultimate goal was to understand as much as possible about the family history of AD and to try to uncover all the different risk factors
- Knowing this could not only potentially help Lauren’s uncle, but just as importantly help Richard figure out the best path to prevention for Lauren (and her brother)

**Exploring family history — the “detective work” (Step 1)**

- Richard was able to see signs of decline in both of Lauren’s grandparents based on changes in their handwriting and their choice of words in Lauren’s mother’s and uncle’s high-school yearbooks, which were five years apart
- Based on seeing video of Lauren’s mother earlier in her progression, Richard sensed something more than just Alzhiemer’s was going on – perhaps dementia with [Lewy bodies](https://en.wikipedia.org/wiki/Lewy_body), as seen in Parkinson’s disease and consistent with the observed handwriting changes in the yearbooks
- Word choice can also be telling — he mentions a [study](https://psycnet.apa.org/record/2001-06652-005) in nuns whose *risk of dementia was predicted by autobiographies* they wrote in their late teens, 60 years earlier
- Coincidentally, Lauren’s great uncle was a patient of Richard’s brother (which helped with understanding family history)

> “people with the APOE4 for variant, one or two copies, have smaller brains when they’re born. So, I know we say Alzheimer’s starts 20 to 30 years before in the brain. Well, that may be because of the biomarkers of Alzheimer’s that we can detect are noticeable then. But I believe Alzheimer’s is a life course disease.”  —Richard Isaacson

*Richard’s process with patients*:

1. Investigative work (e.g., family history, signs of symptoms from various place — videos, handwriting, etc.)
2. Medical history
3. Genetic testing

> “We just try to put together lots of different pieces to the puzzle, and do as best as we can with the information we have to personalize, or individualize a person’s care.” —Richard Isaacson

**At this point in the process, the main question Richard had was**: *Despite both having two copies of the ApoE4 variant, Lauren’s mom had AD symptoms much sooner than her uncle. Why?*

- Risk of the ApoE4 variant is more pronounced in women, possibly related to menopause
- Lauren’s mother had a hysterectomy, which may have been a contributing factor due to the loss of estrogen
- Lifestyle factors:
  - She never exercised (uncle was an avid exerciser)
  - She ate a lot of sugar
  - Bad sleep habits (same with her uncle)

## How exercise reduces Alzheimer’s disease risk, and the different risk between males and females [58:00]

> “The number one thing by far is exercise and physical activity.” —Richard Isaacson

**Exercise**

- Richard points out that our understanding of exercise physiology has improved a lot since the 1980s – for example,
  - we know that the target of 10,000 steps per day is antiquated
  - and that it’s possible to have a potentially harmful amount of abdominal fat despite a normal BMI
- Richard considers [high-intensity interval training](https://en.wikipedia.org/wiki/High-intensity_interval_training) to be the most important factor in Alzheimer’s prevention
- Lauren reiterates that there was a big difference in physical activity between her mother and the rest of the family – Lauren, her brother, and her uncle were all athletes while her mother was more intellectual and preferred reading

> “*High intensity interval training is probably the only thing that can move the needle in terms of certain aspects of cognitive function in people with the APOE4 variant*.” —Richard Isaacson

**Gender**

- Richard was first inspired to better understand the greater Alzheimer’s risk among women after prodding from [Maria Shriver](https://en.wikipedia.org/wiki/Maria_Shriver)
- Peter points out that women living longer has been proposed as the reason for greater Alzheimer’s risk, but that this does not explain all of the difference

*What Richard believes to be happening in women*:

- [Perimenopause](https://www.mayoclinic.org/diseases-conditions/perimenopause/symptoms-causes/syc-20354666) is a “brain disease”
  - During perimenopause there are metabolic shifts in the brain that can predispose to acceleration of Alzheimer’s pathology
  - He also believes that this is underappreciated and can be countered with appropriate use of **estrogen replacement**
  - The disruption of sleep, the brain fog, problems with processing speed and attention, are all symptoms of perimenopause
  - Perimenopause transition is a **huge unrealized risk factor** for progression to dementia *in an Alzheimer’s susceptible woman*
  - Lauren’s mother’s hysterectomy was likely a contributing factor in her progression

> “If you want to fast forward brain aging in a woman . . .An E4/E4 woman, a surgical menopause, meaning taking out the ovaries with the uterus, wow, that could do it.” —Richard Isaacson

- Other factors contributing to risk in women:
  - Widowhood:“*widowhood is a astronomically important* [*risk factor for cognitive decline and dementia*](https://jnnp.bmj.com/content/89/3/231.abstract)”
  - Abdominal obesity: women with an enlarged waist circumference have a [39% increase in dementia risk](https://academic.oup.com/ije/advance-article/doi/10.1093/ije/dyaa099/5861491)
  - Interestingly, in men, muscle mass is a more important predictor than body fat, but we do not yet know why
  - Richard is currently doing a study involving comprehensive brain imaging in men and women between the ages of 40-65 and will hopefully be able to determine the reason for this difference between men and women

## Why knowing your APOE status is important, and whether certain people should be wearier of head trauma [1:08:00]

**The ethics of testing**

- Lauren has one copy of ApoE4 and prefers knowing – she feels empowered knowing that she is doing what she can to offset the risk
- Her test revealed that she has E3/E4 (which is less risky that E4/E4)
- Peter has been criticized by at least one primary care physician for informing people of their ApoE status
  - But the criticism comes from the thinking that there’s nothing you can do to change your course (which isn’t true)
  - A quick example, people with E4/E4 don’t absorb omega-3 fats from eating fatty fish very well, therefore they should be supplementing with omega-3 from an early age to protect the brain
- The [REVEAL study](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/trc2.12002) showed that disclosing ApoE4 status did not cause clinically significant anxiety or depression
- In 2011, Richard co-authored a [review](https://journals.lww.com/continuum/Abstract/2011/04000/Genetics_of_Dementia.12.aspx) on genetic risk factors for dementia that unfortunately did not draw much attention
  - In contrast, it is now common for papers to be exclusively focused on ApoE4

> “*Science gives us tools. I don’t want to live in the dark and not use the few tools that I’ve been given at this point. That seems way worse to me.*” —Lauren Miller Rogen on the knowing versus not knowing of one’s ApoE status

**Head trauma**

- Head trauma may be more of a concern in individuals with the ApoE4 variant, which is additional justification for testing
- Peter believes knowing the child’s ApoE status would be an important factor in choosing to play contact sports like football
- Richard agrees that playing sports like football can impose increased risk in conjunction with being an ApoE4 carrier, but also acknowledges that it is a difficult topic – “*These are really difficult conversations to have, but knowledge is power*”

## How Richard uses genetic testing to personalize care [1:14:45]

> “One day, I hope it’s soon, we’re going to know all these genes and when they get their preventative health screenings, it’s not just E4, we’re going to get a whole bunch of genes. And primary care doctors. . .are going to basically do these genetic screens on multiple genes and give people targeted personalized plans for disease risk reduction as early as possible.” —Richard Isaacson

**The polygenic nature of genetic risk factors**

- There are about 30 genes that are known to influence Alzheimer’s risk and Richard thinks are important
- This is a complicated topic because risk is influenced by the combination of gene variants
- For example, Richard considers [TOMM40](https://en.wikipedia.org/wiki/TOMM40) to be an important gene, and its influence can vary depending on ApoE4 status

Taking a step back: “*Alzheimer’s is a medical condition*.”

- Whether you’re on the lipid path, the inflammation path, or the potentially infectious path, or the head trauma path…
- There’s so many different things that can trigger brain related pathology

**Other genes Richard looks at:**

- Vascular genes like [FTO](https://en.wikipedia.org/wiki/FTO_gene) and other genes related to lipid metabolism like [PCSK9](https://en.wikipedia.org/wiki/PCSK9)
- He also pays attention to longevity genes such as those related to [FOXOs](https://en.wikipedia.org/wiki/FOX_proteins) and [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology))
- The gene for [TNF-α](https://en.wikipedia.org/wiki/Tumor_necrosis_factor), an inflammatory cytokine, is another factor that can modulate the risk associated with the ApoE4 variant
  - Lauren has a variant of the gene for TNF-α that increases her risk, and Richard and Peter have adjusted her protocol accordingly
  - Laren’s mother also had this TNF-α variant, but her uncle did not
- Peter appropriately sums this topic up by saying that “not all E4s are created equal,” similar to [lipoprotein(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) and cardiovascular risk

## The “ABCs” of Alzheimer’s prevention, lifestyle interventions, and Lauren’s personal protocol for reducing her risk [1:21:45]

**Lauren’s journey**:

- About 2 years ago (2018), Lauren really started to focus on preventing and/or delaying AD in herself
- Fortunately, her husband (Seth Rogen) is very supportive of her efforts and her has changed his habits

> “When you see what I have seen over the last 15 years, why wouldn’t I do anything I possibly can to avoid what I saw over the last 15 years? I want to do everything I possible can to not go through that myself, to not put that on my husband or my family.” —Lauren Miller Rogen

**Defining a high risk patient**:

- If their family history is notable.
- They have at least one copy of the ApoE4 gene
- Or they’re over 60
- Basically any of these traits together would put someone into Richard’s care
- And a personalized protocol would be created

**Richard’s “ABCs” of Alzheimer’s prevention**

- A is for anthropometrics, mainly body composition
- B is for blood biomarkers, primarily related to cholesterol, inflammation, metabolism, nutrition, and genetics
- C is for cognitive function
- All are assessed every 6 months — and the protocol is fine-tuned each time based on results
- Richard’s team (with contributions from Peter) published a [study](https://www.sciencedirect.com/science/article/pii/S1552526019353683) showing individualized care based on the “ABCs” to improve Alzheimer’s and cardiovascular risk factors

![](https://peterattiamd.com/wp-content/uploads/2020/11/fig-2-rogen-1024x578.jpg)

**Figure 2. Some of the biomarkers Richard measures and how they relate to lifestyle interventions.** Image credit: [sciencedirect.com](https://ars.els-cdn.com/content/image/1-s2.0-S1552526019353683-gr1_lrg.jpg)

**Lauren’s protocol**

- **Exercise**: Because of Lauren’s ApoE4 status, exercise – particularly high-intensity interval training – is emphasized in her protocol
- **Omega-3 fats (EPA and DHA)**:
  - Her E4 status make this more important—A [study](https://alzres.biomedcentral.com/articles/10.1186/s13195-016-0194-x) involving 2 g of [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) supplementation showed that less of it gets to the cerebral spinal fluid of people with the ApoE4 variant
  - Lauren takes ~2,000 mg of DHA
  - Richard aims for his patients to have an [omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/) of at least 12-14 (based on red blood cell level)
    - Here’s an at home test to measure your omega-3 index: [OmegaQuant](https://omegaquant.com/)
- **Lowering inflammation**: Because of her [TNF-α](https://en.wikipedia.org/wiki/Tumor_necrosis_factor) variant, she is on a purified form of **cocoa flavanols** and a nanoparticle version of **curcumin** (Theracurmin)
  - A [study](https://www.sciencedirect.com/science/article/pii/S1064748117305110) has shown Theracurmin to improve cognitive function and decrease amyloid accumulation in healthy adults
- **Lowering homocysteine**: Lauren takes a **B-vitamin complex** (which has B12, B6, and folic acid, etc.) to address her [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) levels
  - High homocysteine is [associated with increased brain atrophy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3192851/) resulting in impaired memory function
  - The B-complex combined with sufficient levels of Omega-3s **can slow brain shrinkage, brain atrophy, and improve memory**
- **Optimizing Vitamin D**:
  - Supplementation was also emphasized in Lauren’s protocol because her blood concentration was low (less than 20 ng/mL)
  - Richard says based on a [study in the European Journal of Nutrition](https://pubmed.ncbi.nlm.nih.gov/25293430/), people with ApoE4/4 “better have good vitamin D levels… at 50 or more”
  - Richard believes that an optimal vitamin D level is somewhere around **40-50 ng/mL**
  - *\*Tips for getting more vitamin D*:
    - Consuming supplements with fat since vitamin D is a fat soluble vitamin
    - Getting 10-15 minutes of sun exposure between 11:00 AM and 1:00 PM

*What about* ***magnesium*** *supplementation?*

- Peter is a big fan of magnesium L-threonate ([Magtein](https://magtein.com/)) because the L-threonate helps the magnesium enter the brain more easily
  - A small [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6242385/) has shown magnesium L-threonate to improve cognitive function in people with mild to moderate dementia
  - Richard has traditionally favored magnesium glycinate based on its use for headaches and it being well tolerated, but he is intrigued by magnesium L-threonate
  - Richard also believes that magnesium L-threonate may help with sleep, which he has found helpful for “stressed out type A people”

## Unique treatment for people with the ApoE4 variant [1:36:30]

**How ApoE4 influences risk and prevention**

- Richard’s team published a [review](https://link.springer.com/article/10.14283/jpad.2018.35) in 2018 specifically describing the role of ApoE4 in guiding clinical prevention
- The justification for this paper, as Richard points out, is that the influence of ApoE4 on Alzheimer’s risk is complicated, as described below
- Being an ApoE4 carrier exacerbates the negative effects of being sedentary
- Tobacco use has more of a negative effect in ApoE4 carriers
- Although the data is confusing, ApoE4 carriers should maybe be more conservative with alcohol consumption, with there potentially being benefit from completely abstaining
- Cognitive engagement may be more important for ApoE4 carriers, but the data is unclear here as well
- As already mentioned, ApoE4 carriers need higher doses of omega-3 fatty acids
- A [trial](https://clinicaltrials.gov/ct2/show/NCT03070535) is underway to determine the influence of saturated fat and a high-glycemic diet on ApoE4 carriers
- Richard is also in favor of using [medium-chain triglycerides](https://en.wikipedia.org/wiki/Medium-chain_triglyceride), but he’s more liberal with them for people WITHOUT an E4 variant — “*a tricky topic worthy of a separate discussion*”

> “*Brain imaging studies show that E4 carriers exacerbates the effect of having a sedentary lifestyle in Alzheimer’s pathology. So, someone with E4 really, really, better exercise. It’s no joke, it’s got to be really important and the intensity of the exercise is key*.” —Richard Isaacson

![](https://peterattiamd.com/wp-content/uploads/2020/11/fig-3-rogen-1024x832.png)

**Figure 3. Exercise induces greater enhancement of memory activation (red) in people who are ApoE4 carriers (High Risk).** Image credit: [ncbi.nlm.nih.gov](https://www.ncbi.nlm.nih.gov/core/lw/2.0/html/tileshop_pmc/tileshop_pmc_inline.html?title=Click%20on%20image%20to%20zoom&p=PMC3&id=2962671_nihms228284f1.jpg)

## Richard’s mixed opinion on CBD and THC as a tool for disease prevention [1:40:00]

**Why a precision medicine approach applies to CBD and THC**

- Richard is open minded to CBD and THC, but considers this a difficult topic
- He thinks the benefit is dependent on the ratio of CBD to THC
- He also thinks consuming it in edible form makes more sense than smoking it
- Evidence in regard to helping versus accelerating Alzheimer’s pathology is mixed
- Based on this Richard is “not anti-CBD,” but is “not pro” THC (he says he’s “in the middle”)
- Richard thinks the answer to CBD and THC is one rooted in precision medicine – it depends on the patient, and the situation should be objectively measured by tracking things like sleep and cognitive function

## Cognitive testing procedures, and how Lauren’s tests furthered her commitment to her disease prevention protocol [1:41:45]

**Cognitive testing in Richard’s clinic**

- Richard uses a modified form of the Alzheimer’s prevention cognitive composite (validated in [this study](https://alz-journals.onlinelibrary.wiley.com/doi/abs/10.1016/j.jalz.2014.02.002)), which is largely based on the [NIH Toolbox](https://www.nihtoolbox.org/) of cognitive assessments
- The testing he uses is sensitive enough to detect changes in brain function before symptoms occur
- Testing is not perfect because people have good days and bad days
  - For example, processing speed and attention can be negatively affected by a bad night of sleep
  - Lauren feels as if there may have been a “practice effect,” in which she became better at the tests simply by doing them, which is a concern with testing in general, but ApoE4 carriers are interestingly less susceptible to this
- But Richard says he can look for specific things that can indicate a confounder
- Richard clearly believes in the usefulness of the cognitive testing

**How testing changed Lauren’s commitment to her protocol**

- As Lauren put it, she only “half started” in the beginning, exercising and slightly improving her diet, but not doing everything she needed to
- On one of Lauren’s visits to Richard’s clinic following a stressful period in her life, she did poorly on the cognitive testing, indicating that her lifestyle at that point was pushing her in the wrong direction
- After Richard expressed serious concern, Lauren committed to putting in more effort, and it was at about this point that she also started working with Peter

*Results so far for Lauren*:

- When Lauren first saw Richard, her cognitive performance was below average, but now it is more than a [standard deviation](https://en.wikipedia.org/wiki/Standard_deviation) above average
- Despite possible confounders, Richard says unequivocally her brain is functioning better than it was before she really took her Alzheimer’s disease prevention protocol seriously

> “Your brain and biomarkers, your blood based biomarkers, you’re optimized. You’re different. Your brain is firing on more cylinders.” —Richard Isaacson on how Lauren’s brain function has changed since she implemented the Alzheimer’s disease prevention protocol

## The relevance of sense of smell and hearing in Alzheimer’s disease risk and prevention [1:50:00]

**Smell**

- Loss of smell and inability to identify certain smells were originally viewed as warning signs for Parkinson’s disease, but as Richard puts it, this can and also be “*a harbinger of Alzheimer’s disease*”
- Consistent with this, Lauren’s mother never had a good sense of smell
- Richard uses smell sensitivity as part of his testing battery, but loss of smell being a common symptom of COVID-19 (which Richard had a pretty bad case of himself) may interfere with this testing

**Hearing**

- Hearing loss is a risk factor for Alzheimer’s disease
- In the [2020 report of the Lancet Commission](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30367-6/fulltext?MvBriefArticleId=43663), hearing loss was identified as one of the strongest modifiable risk factors for dementia — one’s reaction to the study could be that “*a huge number of cases of dementia could be potentially reduced if a person gets early recognition of hearing impairment and gets it addressed*.”
- The reason why is not clearly known, but Richard speculates that it may be related to disengaging — “*You can’t hear, you’re in your own little world, you miss social cues, you have different interaction levels. I actually don’t know the answer to this, and the classic line, we need more research to truly be able to figure this out.”*
- Richard feels that screening for hearing, perhaps at a certain age, should be included in medical evaluations

## The emotional benefit of knowing you have control over your mental and physical health [1:57:30]

> “I see my blood work. I see numbers going from red to green. And that gives me a hope that I think translates into my physical being, but also into my cognitive health as well.” —Lauren Miller Rogen

While Richard has objective data that says Lauren is improving her risk factors for AD, he wants to know **how she** ***feels*** **physically, mentally, and emotionally**

Physically,

- “Physically, I feel better.”
- My overall health is better— “From a total body energy, the way I can approach a situation, I feel like I have a different type of body energy.”

Cognitively,

- “I fortunately feel like someone who is pretty in control of their cognition most of the time.”
- But she can’t say for sure she feels definitively different than before

Emotionally,

- Going back to 10 years, Lauren felt some depression around the idea that AD was inevitable
- But after working with Richard, she now feels like there’s no reason to believe you’re going to get Alzheimer’s disease, no matter your genetics
- She says that the fear has dissipated because “I have control in a way that I didn’t before”

> “Maybe that’s the greatest single benefit of all.” —Lauren Miller Rogen on the emotional benefit of taking control of your health and understanding that genetics don’t seal your fate

## HFC—a charitable organization founded by Lauren and Seth [2:00:15]

**About Hilarity for Charity**

- [Hilarity for Charity](https://wearehfc.org/) (HFC) is a charitable organization founded by Lauren and her husband Seth Rogen (a comedian)
- Lauryn says: “… *I have been so fortunate in my terrible journey. I think I’ve had the best situation of a horror show that could happen with Alzheimer’s in that, one, my family was able to afford care for my mom, and that, two, because of my relationships and the advocate that I’ve become, I have met smart people like you guys who have helped me take control of my brain health.*”
- Part of the intent of HFC is to help others have a similarly less terrible situation
- HFC is focused on Alzheimer’s disease and has two primary intentions: to help people (and their caregivers) who need help now, and to help people minimize future risk
  - HFC sends caregivers to people’s homes to give the primary caregiver a break
  - They also have a partnership with the [Rosalynn Carter Institute](https://www.rosalynncarter.org/programs/rci-reach/) for training these caregivers
- HFC also encourages young people to share their stories and start taking care of their brains
- HFC funds research, but to date they have not raised enough money to fund major studies
- When Lauren went to a support group early on in her mother’s progression, she was a 26-year-old surrounded by, for example, a guy who was 56 and upset about his mother
- Based on this experience, Lauren has made it a mission of HFC to help connect people to others who can understand their situation
- COVID-19 has slowed fundraising for HFC, but as Lauren points out, while people and organizations are diverting their donations to COVID-related efforts, as they should be, we all still have brains
  - In addition, COVID-19 is making life for caregivers more difficult
- HFC also welcomes people to have their own fundraising events on behalf of HFC
- For example, one person drove a [tuk-tuk](https://en.wikipedia.org/wiki/Auto_rickshaw) across India as a fundraiser

> “*I think overall, we’re just trying to provide people the hope that I have found over the years. We started this podcast talking about my dark devastating times and that’s not who I am anymore, and that’s not my vision about all of this anymore. And I think there is so much control that can be had that we did not have even just a few years ago. And we through HFC are just trying to teach people that they have that control too.*” —Lauren Miller Rogen

§

## Selected Links / Related Material

**The previous Drive episode featuring Richard:** [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com) [0:45]

**The Drive episodes featuring Tom Dayspring |** Peter Attia (peterattiamd.com) [4:00]

- [#20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology](https://peterattiamd.com/tomdayspring1/)
- [#21 – Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](https://peterattiamd.com/tomdayspring2/)
- [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/)
- [#23 – Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](https://peterattiamd.com/tomdayspring4/)
- [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/)
- [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology](https://peterattiamd.com/tomdayspring6/)

**A study in nuns showing autobiographies written in their late teens to be predictive of dementia risk 60 years later**: [Language decline across the life span: findings from the Nun Study](https://psycnet.apa.org/record/2001-06652-005) (Kemper et al., 2001) [49:45]

**A meta-analysis showing increased risk of dementia among widowed people**: [Marriage and risk of dementia: systemic review and meta-analysis of observational studies](https://jnnp.bmj.com/content/89/3/231.abstract) (Sommerlad et al., 2018) [1:05:45]

**Women with an enlarged waist circumference have a 39% increase in dementia risk**: [Higher risk of dementia in English older individuals who are overweight or obese](https://academic.oup.com/ije/advance-article/doi/10.1093/ije/dyaa099/5861491) (Ma et al., 2020) [1:06:15]

**The REVEAL study, which showed that disclosing ApoE4 status did not cause clinically significant depression or anxiety**: [Disclosing genetic risk for Alzheimer’s dementia to individuals with mild cognitive impairment](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/trc2.12002) (Christensen et al., 2020) [1:14:15]

**A review describing the potential benefit of omega-3 fatty acids in decreasing dementia risk potentially among ApoE4 carriers**: [The ApoE ε4 isoform: can the risk of diseases be reduced by environmental factors?](https://academic.oup.com/biomedgerontology/article/74/1/99/5129099) (Bos et al., 2019) [1:13:15]

**A review co-authored by Richard on genetic risk factors for dementia**: [Genetics of dementia](https://journals.lww.com/continuum/Abstract/2011/04000/Genetics_of_Dementia.12.aspx) (Padilla & Isaacson, 2011) [1:14:45]

**A study by Richard’s team (and with contributions from Peter) showing individualized care to improve Alzheimer’s and cardiovascular risk**: [Individualized clinical management of patients at risk for Alzheimer’s dementia](https://www.sciencedirect.com/science/article/pii/S1552526019353683) (Isaacson et al., 2019) [1:25:45]

**A study showing higher homocysteine levels to be associated with greater brain atrophy**: [Homocysteine effects on brain volumes mapped in 732 elderly individuals](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3192851/) (Rajagopalan et al., 2011) [1:29:00]

**A meta-analysis showing low vitamin D levels to be associated with lower brain volume**: [Vitamin D and brain volumetric changes: systematic review and meta-analysis](https://www.sciencedirect.com/science/article/abs/pii/S0378512214000644) (Annweiler et al., 2014) [1:30:15]

**A study showing that in Alzheimer’s patients, low vitamin D is less likely in people with the ApoE4 variant**: [Vitamin D deficiency might pose a greater risk for ApoEϵ4 non-carrier Alzheimer’s disease patients](https://link.springer.com/article/10.1007/s10072-016-2647-1) (Dursun et al., 2016) [1:30:30]

**Richard says based on a study in the European Journal of Nutrition, people with ApoE4/4 “better have good vitamin D levels… at 50 or more”**: [25-hydroxyvitamin D, APOE ɛ4 genotype and cognitive function: findings from the 1958 British birth cohort](https://pubmed.ncbi.nlm.nih.gov/25293430/) (Maddock et al., 2015) [1:30:30]

**At home test to measure your omega-3 index**: [OmegaQuant](https://omegaquant.com/) | (omegaquant.com) [1:31:30]

**A study showing less of 2 g of DHA supplementation to get into the cerebral spinal fluid of ApoE4 carriers**: [The effect of APOE genotype on the delivery of DHA to cerebral spinal fluid in Alzheimer’s diseas](https://alzres.biomedcentral.com/articles/10.1186/s13195-016-0194-x)e (Yassine et al., 2016) [1:32:30]

**A study showing Theracurmin to improve cognitive function and decrease amyloid accumulation in healthy adults**: [Memory and brain amyloid and tau effects of a bioavailable form of curcumin in non-demented adults: A double-blind, placebo-controlled 18-month tria](https://www.sciencedirect.com/science/article/pii/S1064748117305110)l (Small et al., 2018) [1:33:45]

**A study that showed magnesium L-threonate to enhance cognitive function in people with mild to moderate dementia**: [Open label trial of magnesium L-threonate in patients with dementia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6242385/) (Wroolie et al., 2017) [1:35:00]

**A review published by Richard’s team describing the role of ApoE4 in guiding Alzheimer’s prevention**: [Clinical application of APOE in Alzheimer’s prevention: A precision medicine approach](https://link.springer.com/article/10.14283/jpad.2018.35) (Berkowitz et al., 2018) [1:37:00]

**A study showing to exercise to be particularly beneficial for ApoE4 carriers**: [Interactive effects of physical activity and APOE-ϵ4 on BOLD semantic memory activation in healthy elders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2962671/) (Smith et al., 2011) [1:37:30]

**A clinical trial that is underway to determine the effects of a high-saturated-fat and high-glycemic diet on ApoE4 carriers**: [APOE genotype and diet influences on Alzheimer’s biomarkers](https://clinicaltrials.gov/ct2/show/NCT03070535) (Hanson et al.) [1:39:00]

**A study validating a composite of cognitive assessments for evaluation of preclinical Alzheimer’s disease**: [An empirically derived composite cognitive test score with improved power to track and evaluate treatments for preclinical Alzheimer’s disease](https://alz-journals.onlinelibrary.wiley.com/doi/abs/10.1016/j.jalz.2014.02.002) (Langbaum et al., 2014) [1:43:45]

**A set of cognitive tests inspired by the National Institutes of Health**: [The NIH Toolbox Cognitive Battery](https://www.healthmeasures.net/explore-measurement-systems/nih-toolbox) | (nihtoolbox.org) | [1:43:45]

**An analysis that identified hearing loss as one of the strongest modifiable risk factors for dementia**: [Dementia prevention, intervention, and care: 2020 report of the Lancet Commission](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30367-6/fulltext?MvBriefArticleId=43663) (Livingston et al., 2020) [1:54:15]

**A training program for Alzheimer’s caregivers, offered in partnership with Hilarity for Charity**: [The Rosalynn Carter Institute’s REACH program](https://www.rosalynncarter.org/programs/rci-reach/) | (rosalynncarter.org) | [2:05:15]

§

## People Mentioned

- [Tom Dayspring](https://twitter.com/Drlipid?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [4:00]
- [Seth Rogen](https://en.wikipedia.org/wiki/Seth_Rogen) (Lauren’s husband) [8:45, 24:45, 1:23:00, 1:44:45, 1:51:00; 2:05:00]
- [Stuart Isaacson](https://braincenter.org/team/stuart-isaacson-md/) (Richard’s brother, neurologist) [15:30]
- [Maria Shriver](https://en.wikipedia.org/wiki/Maria_Shriver) [41:00, 1:01:45]
- [Hussein Yassine](https://keck.usc.edu/faculty-search/hussein-yassine/) [1:32:30]
- [Gary Small](https://www.uclahealth.org/gary-small) [1:33:45]
- [Cara Berkowitz](https://www.researchgate.net/profile/Cara_Berkowitz) [1:37:15]

§