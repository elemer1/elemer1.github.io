# #01 – Tim Ferriss: depression, psychedelics, and emotional resilience

**Source:** [https://peterattiamd.com/timferriss/](https://peterattiamd.com/timferriss/)

---

I couldn’t think of a better guest to kick this thing off. Tim is not only one of my closest friends, but also is the one who most persistently encouraged me to launch a podcast.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

In this episode, Tim talks both experientially and from his own deep dive into the literature of psychedelics and mental health. Tim is shifting his focus from investing in startups to funding experiments that he hopes will establish more reliable knowledge and therapeutic options for those suffering from anxiety, depression, and addiction.

![The Peter Attia Drive](images/timferriss/the_Drive_public.png)

Play

#01 - Tim Ferriss: depression, psychedelics, and emotional resilience

#01 - Tim Ferriss: depression, psychedelics, and emotional resilience

1x15s30s

0:002:36:25

If this topic even remotely interests you, I can’t recommend [Tim’s podcast with Michael Pollan](https://tim.blog/2018/05/06/michael-pollan-how-to-change-your-mind/), author of [How to Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225/ref=sr_1_4?s=books&ie=UTF8&qid=1530096268&sr=1-4&keywords=how+to+change+your+mind), enough. (You should definitely read Pollan’s book as well.) Even if you’ve never had any exposure to psychedelics or their potential applications, I think you’ll find this subject matter really interesting, and I was very grateful for Tim to be so open and honest about his experiences.

Tim also shared his short list of acquired wisdom he returns to most reliably, which might be worth the price of admission alone.

## We discuss:

- Tim’s history of depression and his TED Talk on his close call with suicide;
- The type of thinking that triggers Tim’s downward spirals;
- Tim’s transformative experience with ayahuasca;
- How Tim’s experience and research has led him to focus on furthering the science of psychedelics and mental health;
- What some of the meditation modalities, and meditation apps, are out there, why can meditation be so hard to do, but also worthwhile to stick with;
- Why Tim made a big commitment (more than $1 million) to funding scientific research, and to psilocybin and MDMA research, in particular;
- From all the habits and tools that Tim has learned, the five things that he returns to most reliably; and
- More.

## Show Notes

What it’s like living in Austin. [01:00]

The differences between lifespan and healthspan. [08:00]

During childhood and adolescence, Tim believed he was “not designed to be happy.” [09:30]

[Tim’s TED Talk](https://www.ted.com/talks/tim_ferriss_why_you_should_define_your_fears_instead_of_your_goals) and his close call with suicide. [11:15]

Why Tim wants to focus on discussing different facets of mental health on a first-hand basis. [15:15]

What’s the type of thinking that triggers Tim’s downward spirals? [17:15]

Why Tim’s changed his focus from investing in startups to investing in mental health. [18:00]

How self-talk can be your best friend or worst enemy. [20:00]

Why Tim thinks everyone, including Type A personalities, should try meditation. [23:00]

Why men, in general, are bad at dealing with depression. [31:00]

Peter’s (newly) most-gifted book, which is related to men and depression ([I Don’t Want To Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398/ref=sr_1_1?s=books&ie=UTF8&qid=1530094462&sr=1-1&keywords=i+don%27t+want+to+talk+about+it) by Terrence Real). (Peter’s previous #1 book: [Mistakes Were Made [but not by *me*]](https://www.amazon.com/Mistakes-Were-Made-but-Not/dp/0544574788/ref=sr_1_1?s=books&ie=UTF8&qid=1530094386&sr=1-1&keywords=mistakes+were+made+but+not+by+me) by Carol Tavris and Elliot Aronson.) [32:45]

The benefits and drawbacks of self-talk. [35:00]

“The need to treat ourselves as well as we treat others. It’s women’s version of the Golden Rule.” — Gloria Steinem [37:00]

How a couple of Tim’s podcasts ([The Psychedelic Explorer’s Guide – Risks, Micro-Dosing, Ibogaine, and More](https://tim.blog/2015/03/21/james-fadiman/) and [Are Psychedelic Drugs the Next Medical Breakthrough?](https://tim.blog/2015/09/14/are-psychedelic-drugs-the-next-medical-breakthrough/) made Peter aware of the effectiveness of plants to treat patients. [38:30]

Peter’s first experience with psilocybin. [40:30]

What started Tim’s interest in psychedelics? [41:30]

Tim’s transformative experience with ayahuasca. [48:45]

How Tim’s experience and research led him to focus on furthering the science of psychedelics and mental health. [53:00]

How do you explain the ineffability of psychedelic experiences? [57:00]

What is ego dissolution, and how do you explain it? [1:00:00]

What are some of the meditation modalities, and meditation apps out there? Why can meditation be so hard to do, but worthwhile to stick with? [1:13:00]

Tim notes, “The consistent program that you follow is better than the perfect program that you quit.” [1:26:30]

Why has Tim made a big commitment (more than $1 million) to funding scientific research, and to psilocybin and MDMA research, in particular? [1:31:00]

The story of [Katharine McCormick](https://en.wikipedia.org/wiki/Katharine_McCormick) and the birth control pill, and what a small number of committed people can do to change the course of history. [1:34:30]

Why the FDA granted MDMA-assisted psychotherapy breakthrough therapy designation (which could expedite approval) for the treatment of PTSD, and how a Phase 3 clinical trial is in motion. [1:43:43]

Ibogaine and [the treatment of opiate addiction](https://www.maps.org/research/ibogaine-therapy). [1:48:30]

What is the Default Mode Network (DMN), how does it relate to mental health, and how do psychedelic compounds affect the DMN? [1:49:30]

![](https://peterattiamd.com/wp-content/uploads/2018/06/null.png)

Image credit: [Homological scaffolds of brain functional networks](https://dx.doi.org/10.1098/rsif.2014.0873) (Petri et al., 2014)

Here’s Michael Pollan explaining the DMN, and the side-by-side images in figure above, in [How To Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225/ref=sr_1_4?s=books&ie=UTF8&qid=1530096268&sr=1-4&keywords=how+to+change+your+mind) “In a 2014 paper published in the *Journal of the Royal Society Interface*, the Imperial College team demonstrated how the usual lines of communications within the brain are radically reorganized when the default mode network goes off-line and the tide of entropy is allowed to rise. Using a scanning technique called magnetoencephalography, which maps electrical activity in the brain, the authors produced a map of the brain’s internal communications during normal waking consciousness and after an injection of psilocybin (shown [above]). In its normal state, shown on the left, the brain’s various networks (here depicted lining the circle, each represented by a different color) talk mostly to themselves, with a relatively few heavily trafficked pathways among them.

“But when the brain operates under the influence of psilocybin, as shown on the right, thousands of new connections form, linking far-flung brain regions that during normal waking consciousness don’t exchange much information. In effect, traffic is rerouted from a relatively small number of interstate highways onto myriad smaller roads linking a great many more destinations. The brain appears to become less specialized and more globally interconnected, with considerably more intercourse, or “cross talk,” among its various neighborhoods.”

How MDMA, in the right setting, may help us “clean up a very messy experience that did a lot of damage,” Tim says. “To help people to heal themselves in nonverbal ways. This is really key. It’s very hard for people to talk their way out of something that they didn’t talk their way into.” [1:53:30]

Why has ibogaine gained the least traction in the US for treatment of opiate addiction? [2:00:00]

Tim’s first-hand experience with opiate addiction and overdoses. [2:06:30]

Unhappiness may be the single most important problem plaguing our civilization, and there are compounds that may be part of the solution. Is progress being made in terms of pushing through research and application? [2:13:30]

What does it take to reschedule a drug? [2:16:30]

The non-addictive potential of psychedelics. Food vs cocaine vs psilocybin. [2:18:00]

How [Solve for Happy](https://www.amazon.com/Solve-Happy-Engineer-Your-Path/dp/1501157582/ref=sr_1_1?s=books&ie=UTF8&qid=1530100769&sr=1-1&keywords=solve+for+happy+by+mo+gawdat) by Mo Gawdat has jumped into the #2 spot for most-gifted books from Peter. [2:23:50]

Peter’s most gifted or recommended books:

- [I Don’t Want To Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398/ref=sr_1_1?s=books&ie=UTF8&qid=1530270806&sr=1-1&keywords=i+don%27t+want+to+talk+about+it) by Terrence Real
- [Solve for Happy](https://www.amazon.com/Solve-Happy-Engineer-Your-Path/dp/1501157582/ref=sr_1_1?s=books&ie=UTF8&qid=1530100769&sr=1-1&keywords=solve+for+happy+by+mo+gawdat) by Mo Gawdat
- [Mistakes Were Made (but not by *me*)](https://www.amazon.com/Mistakes-Were-Made-but-Not/dp/0544574788/ref=sr_1_1?ie=UTF8&qid=1530270760&sr=8-1&keywords=mistakes+were+made+but+not+by+me+by+carol+tavris+and+elliot+aronson) by Carol Tavris and Elliot Aronson
- [Surely You’re Joking Mr. Feynman!](https://www.amazon.com/Surely-Youre-Joking-Mr-Feynman/dp/0393355624/ref=sr_1_1_sspa?ie=UTF8&qid=1530274467&sr=8-1-spons&keywords=surely+you%27re+joking+mr.+feynman&psc=1) by Richard P. Feynman and Ralph Leighton

Tim’s most gifted or recommended books:

- [Letters from a Stoic](https://www.amazon.com/Letters-Penguin-Classics-Lucius-Annaeus/dp/0140442103/ref=sr_1_2?s=books&ie=UTF8&qid=1530274641&sr=1-2&keywords=the+tao+of+seneca) by Lucius Annaeus Seneca or [The Tao of Seneca](https://www.amazon.com/Tao-Seneca-Practical-Letters-Master/dp/B01AIXEJ0U/ref=sr_1_1?s=books&ie=UTF8&qid=1530274608&sr=1-1&keywords=the+tao+of+seneca)
- [Zorba the Greek](https://www.amazon.com/Zorba-Greek-Nikos-Kazantzakis/dp/1476782814/ref=sr_1_1?s=books&ie=UTF8&qid=1530274661&sr=1-1&keywords=zorba+the+greek) by Nikos Kazantzakis
- [Stranger in a Strange Land](https://www.amazon.com/Stranger-Strange-Land-Robert-Heinlein/dp/0441790348/ref=sr_1_1?s=books&ie=UTF8&qid=1530274680&sr=1-1&keywords=stranger+in+a+strange+land) by Robert A. Heinlein
- [Surely You’re Joking Mr. Feynman!](https://www.amazon.com/Surely-Youre-Joking-Mr-Feynman/dp/0393355624/ref=sr_1_1_sspa?ie=UTF8&qid=1530274467&sr=8-1-spons&keywords=surely+you%27re+joking+mr.+feynman&psc=1) by Richard P. Feynman and Ralph Leighton

Was there anything not in Pollan’s book that Tim would have added? [2:25:00]

How Peter is very proud to be one of the “Biggest Tools” and where people can find [Egg Boxing](https://peterattiamd.com/egg-boxing/). [2:31:00]

From all the habits and tools that Tim has learned, what are the 3-5 things that he returns to most reliably? [2:33:00]

What advice would Tim give to his 20- or 30-year-old self? [2:36:00]

§

## Selected Links / Related Material

- [Why you should define your fears instead of your goals | Tim Ferriss](https://www.youtube.com/watch?v=5J6jAC6XxAI) | youtube.com
- [The 4-Hour Workweek](https://www.amazon.com/4-Hour-Workweek-Escape-Live-Anywhere/dp/0307465357/ref=sr_1_1?ie=UTF8&qid=1530270315&sr=8-1&keywords=4-hour+work+week) by Tim Ferriss
- [The 4-Hour Chef](https://www.amazon.com/4-Hour-Chef-Cooking-Learning-Anything/dp/0547884591) by Tim Ferriss
- [The 4-Hour Body](https://www.amazon.com/Hour-Body-Uncommon-Incredible-Superhuman/dp/030746363X/ref=sr_1_2?ie=UTF8&qid=1530270315&sr=8-2&keywords=4-hour+work+week) by Tim Ferriss
- [Tools of Titans](https://www.amazon.com/Tools-Titans-Billionaires-World-Class-Performers/dp/1328683788/ref=pd_bxgy_14_3?_encoding=UTF8&pd_rd_i=1328683788&pd_rd_r=50c33c3c-7b8c-11e8-84e0-534057ebf983&pd_rd_w=kPg10&pd_rd_wg=D8NQo&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=3914568618330124508&pf_rd_r=E659N5NAFY3DQ395WYWQ&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=E659N5NAFY3DQ395WYWQ) by Tim Ferriss
- [Tribe of Mentors](https://www.amazon.com/Tribe-Mentors-Short-Advice-World/dp/1328994961/ref=pd_sim_14_4?_encoding=UTF8&pd_rd_i=1328994961&pd_rd_r=50c33c3c-7b8c-11e8-84e0-534057ebf983&pd_rd_w=eS1MK&pd_rd_wg=D8NQo&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=7967298517161621930&pf_rd_r=E659N5NAFY3DQ395WYWQ&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=E659N5NAFY3DQ395WYWQ) by Tim Ferriss
- [Michael Pollan — Exploring The New Science of Psychedelics](https://tim.blog/2018/05/06/michael-pollan-how-to-change-your-mind/) | the Tim Ferriss Show
- [Mistakes Were Made (but Not by Me)](https://www.amazon.com/Mistakes-Were-Made-but-Not/dp/0544574788/ref=sr_1_1?ie=UTF8&qid=1530270760&sr=8-1&keywords=mistakes+were+made+but+not+by+me+by+carol+tavris+and+elliot+aronson) by Carol Tavris and Elliot Aronson
- [I Don’t Want To Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398/ref=sr_1_1?s=books&ie=UTF8&qid=1530270806&sr=1-1&keywords=i+don%27t+want+to+talk+about+it) by Terrence Real
- [Solve for Happy](https://www.amazon.com/Solve-Happy-Engineer-Your-Path/dp/1501157582/ref=sr_1_1?s=books&ie=UTF8&qid=1530100769&sr=1-1&keywords=solve+for+happy+by+mo+gawdat) by Mo Gawdat
- [Are Psychedelic Drugs the Next Medical Breakthrough?](https://tim.blog/2015/09/14/are-psychedelic-drugs-the-next-medical-breakthrough/) — Martin Polanco and Dan Engle on the Tim Ferriss Show
- [The Psychedelic Explorer’s Guide – Risks, Micro-Dosing, Ibogaine, and More](https://tim.blog/2015/03/21/james-fadiman/) — James Fadiman on the Tim Ferriss Show
- [This is Water by David Foster Wallace (Full Transcript and Audio)](https://fs.blog/2012/04/david-foster-wallace-this-is-water/) | fs.blog
- [How to Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225/ref=sr_1_4?s=books&ie=UTF8&qid=1530096268&sr=1-4&keywords=how+to+change+your+mind) by Michael Pollan
- [Waking Up](https://wakingup.com/) | Sam Harris meditation app
- [Awareness Meditation](https://www.wikihow.com/Do-Awareness-Meditation) | wikihow.com
- [Transcendental Meditation](https://www.tm.org/) | tm.org
- [Focused attention, open monitoring and loving kindness meditation: effects on attention, conflict monitoring, and creativity – A review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4171985/) (Lippelt et al., 2014)
- [Headspace](https://www.headspace.com/headspace-meditation-app) app | headspace.com
- [Calm](https://www.calm.com/) app | calm.com
- [Altered Traits](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384/ref=sr_1_1?ie=UTF8&qid=1530271916&sr=8-1&keywords=altered+traits) by Daniel Goleman and Richard J. Davidson
- [The Science of Meditation — A conversation with Daniel Goleman and Richard J. Davidson](#111 — The Science of Meditation) | Waking Up Podcast
- [Radical Acceptance](https://www.amazon.com/Radical-Acceptance-Embracing-Heart-Buddha/dp/0553380990/ref=sr_1_1?ie=UTF8&qid=1530272047&sr=8-1&keywords=radical+acceptance+by+tara+brach) by Tara Brach
- [The Multidisciplinary Association for Psychedelic Studies (MAPS)](https://www.maps.org/) | maps.org
- [Help Tim Ferriss Fund Research for the Treatment of Major Depression](https://www.crowdrise.com/timferriss) | crowdrise.com
- [Council on Spiritual Practices](https://csp.org/psilocybin/) | csp.org
- [Psilocybin can occasion mystical-type experiences having substantial and sustained personal meaning and spiritual significance](https://www.ncbi.nlm.nih.gov/pubmed/16826400) (Griffiths et al., 2006)
- [Mystical-type experiences occasioned by psilocybin mediate the attribution of personal meaning and spiritual significance 14 months later](https://www.ncbi.nlm.nih.gov/pubmed/18593735) (Griffiths et al., 2008)
- [Meditation leads to reduced default mode network activity beyond an active task](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4529365/) (Garrison et al., 2016)
- [The entropic brain: a theory of conscious states informed by neuroimaging research with psychedelic drugs](https://www.frontiersin.org/articles/10.3389/fnhum.2014.00020/full) (Carhart-Harris et al., 2014)
- [Psilocybin for treatment-resistant depression: fMRI-measured brain mechanisms](https://www.nature.com/articles/s41598-017-13282-7) (Carhart-Harris et al., 2017)
- [Neural correlates of the psychedelic state as determined by fMRI studies with psilocybin](https://www.pnas.org/content/109/6/2138/tab-figures-data) (Carhart-Harris et al., 2012)
- [Homological scaffolds of brain functional networks](https://dx.doi.org/10.1098/rsif.2014.0873) (Petri et al., 2014)
- [Drug Deaths in America Are Rising Faster Than Ever](https://www.nytimes.com/interactive/2017/06/05/upshot/opioid-epidemic-drug-overdose-deaths-are-rising-faster-than-ever.html) | nytimes.com
- [Why We’re Donating $5 Million to MAPS](https://www.drbronner.com/all-one-blog/2017/04/donating-5-million-maps/) | drbronner.com
- [Solve for Happy](https://www.amazon.com/Solve-Happy-Engineer-Your-Path/dp/1501157582/ref=sr_1_1?s=books&ie=UTF8&qid=1530100769&sr=1-1&keywords=solve+for+happy+by+mo+gawdat) by Mo Gawdat
- [Egg Boxing](https://peterattiamd.com/egg-boxing/) | peterattiamd.com
- [Gran Torino](https://en.wikipedia.org/wiki/Gran_Torino) | wikipedia.org
- [Back Jack Floor Chair](https://www.amazon.com/Floor-Chair-Original-BackJack-Chairs/dp/B009E8DYWK) | amazon.com
- [Jack Kornfield – Finding Freedom, Love, and Joy in the Present](https://tim.blog/2018/03/05/jack-kornfield/) | The Tim Ferriss Show
- [The Magic of Mindfulness: Complain Less, Appreciate More, and Live a Better Life](https://tim.blog/2015/11/29/magic-of-mindfulness/) | The Tim Ferriss Show
- [Podcast Gear](https://tim.blog/podcast-gear/) | The Tim Ferriss Show
- [How to Build Popular Podcasts and Blogs](https://tim.blog/2018/02/10/how-to-build-popular-podcasts-and-blogs/) | The Tim Ferriss Show
- [Topo Chico](https://www.amazon.com/Topo-Chico-Mineral-11-5oz-Bottle/dp/B076H7ZNCQ/ref=sr_1_2_sspa?ie=UTF8&qid=1530102059&sr=8-2-spons&keywords=topo-chico&psc=1) | amazon.com
- [Search Inside Yourself](https://siyli.org/) | siyli.org
- [Meditation on Loving Kindness](https://jackkornfield.com/meditation-on-lovingkindness/) | jackkornfield.com

§

## People Mentioned

- [Michael Pollan](https://twitter.com/michaelpollan)
- [Jim Loehr](https://www.tennisicoach.com/en/icoach-experts/jim%20loehr.aspx)
- [Josh Waitzkin](https://en.wikipedia.org/wiki/Joshua_Waitzkin)
- [Rick Rubin](https://twitter.com/RickRubin)
- [Chase Jarvis](https://twitter.com/chasejarvis)
- [Brené Brown](https://twitter.com/BreneBrown)
- [Tara Brach](https://twitter.com/TaraBrach)
- [Jack Kornfield](https://twitter.com/JackKornfield)
- [Terrence Real](https://www.terryreal.com/)
- [Esther Perel](https://twitter.com/EstherPerel)
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/)
- [Martin Polanco](https://twitter.com/martin_polanco7?lang=en)
- [Dan Engle](https://twitter.com/drdanengle)
- [James Fadiman](https://jamesfadiman.com/)
- [Terence McKenna](https://en.wikipedia.org/wiki/Terence_McKenna)
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace)
- [Corey McCarthy](https://twitter.com/coreymccarthyie)
- [Sam Harris](https://twitter.com/SamHarrisOrg)
- [Jeff Warren](https://jeffwarren.org/about/)
- [Dan Harris](https://twitter.com/danbharris)
- [Gabor Maté](https://twitter.com/DrMate?lang=en)
- [Katharine McCormick](https://en.wikipedia.org/wiki/Katharine_McCormick)
- [Gregory Goodwin Pincus](https://en.wikipedia.org/wiki/Gregory_Goodwin_Pincus)
- [John McPhee](https://en.wikipedia.org/wiki/John_McPhee)
- [Chade-Meng Tan](https://en.wikipedia.org/wiki/Chade-Meng_Tan)
- [Jocko Willink](https://twitter.com/jockowillink)
- [Clint Eastwood](https://en.wikipedia.org/wiki/Clint_Eastwood)

§

![](https://peterattiamd.com/wp-content/uploads/2018/06/TimFerrissShoot-186.jpg)

##### Tim Ferriss

Tim Ferriss has been listed as one of *Fast Company*‘s “Most Innovative Business People” and one of *Fortune*‘s “40 under 40.” He is an early-stage technology investor/advisor (Uber, Facebook, Shopify, Duolingo, Alibaba, and [50+ others](https://angel.co/tim)) and the author of five #1 *New York Times* and *Wall Street Journal* bestsellers, including [The 4-Hour Workweek](https://geni.us/fourhourworkweek) and [Tools of Titans: The Tactics, Routines, and Habits of Billionaires, Icons, and World-Class Performers](https://target.georiot.com/Proxy.ashx?TSID=12033&GR_URL=https%3A%2F%2Fwww.amazon.com/gp/product/1328683788/ref=as_li_qf_sp_asin_il_tl?ie=UTF8&tag=teco06-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=1328683788&linkId=7e824e99be7d16a02a481436bd5154a1). The *Observer* and other media have called Tim “the Oprah of audio” due to the influence of [The Tim Ferriss Show podcast](https://tim.blog/podcast/), which is the first business/interview podcast to exceed 200 million downloads.

Tim on Facebook: [Tim Ferriss](https://www.facebook.com/TimFerriss/)

Tim on Instagram: [@timferriss](https://www.instagram.com/timferriss/?hl=en)

Tim on Twitter: [@tferriss](https://twitter.com/tferriss)

Tim’s website: [tim.blog](https://tim.blog/)

Tim’s podcast: [tim.blog/podcast](https://tim.blog/podcast/)