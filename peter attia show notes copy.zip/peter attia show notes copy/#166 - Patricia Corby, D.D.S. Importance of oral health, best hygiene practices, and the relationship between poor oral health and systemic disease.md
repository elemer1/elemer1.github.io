# #166 – Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease

**Source:** [https://peterattiamd.com/patriciacorby/](https://peterattiamd.com/patriciacorby/)

---

Dr. Patricia Corby is Associate Professor of Oral Medicine and Associate Dean of Translational Research at Penn Dental Medicine. Her work focuses on the value of integrating dental services into other healthcare and public health settings. In this episode, Pat provides an overview of dental anatomy, the importance of oral hygiene to overall health, and the association of poor oral health and systemic diseases like cancer and diabetes. She addresses tooth decay, oral hygiene in children, the utility of dental products, and ideal oral care regimens for different populations. She also discusses issues specific to immunocompromised patients and those with chronic illnesses as well as her own research with cancer patients undergoing radiation treatment.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/MSMVpBrfTo0)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/patriciacorby/the_Drive_public.png)

Play

#166 - Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease

#166 - Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease

1x15s30s

0:002:00:37

## We discuss:

- Anatomy of teeth and the purpose of the dental pulp—a highly vascularized and innervated region of the tooth [3:00];
- Types of teeth and the different purpose they serve [14:15];
- Anatomy of the oral cavity, bacteria in the mouth, and what a healthy mouth looks like [18:10];
- Pat’s study demonstrating the importance of flossing [23:00];
- Detrimental effects of sugar and the importance of fluoride and oral hygiene [31:45];
- Oral health challenges for cancer patients and immunocompromised people [39:45];
- Pat’s current research on cancer patients undergoing radiation treatment and the oral health risks associated with human papilloma virus (HPV) [50:00];
- Periodontal disease: caries and root canals [57:30];
- The relationship between poor oral health and systemic health diseases [1:11:00];
- Potential connection between oral hygiene and COVID-19 [1:17:45];
- Dry mouth leading to oral infections and ways to prevent it [1:22:30];
- What determines the appearance of teeth, methods of teeth whitening, and whether you should remove mercury fillings [1:27:30];
- Importance of fluoride for preventing tooth decay, and dental care for children [1:32:45];
- Useful dental products: floss, electrics toothbrushes, and more [1:39:15];
- Ideal oral care regimens [1:47:30]; and
- More.

§

## Show Notes

## Anatomy of teeth and the purpose of the dental pulp—a highly vascularized and innervated region of the tooth [3:00]

- Pat likes to talk about oral health with MDs because the connection to health is important
- Peter has long wanted to discuss oral health, which is “a very underappreciated part of health” that is more than just cavities and cosmetic concerns

**Pat’s background**

- Pat grew up in Brazil
- Wanted a career involving systemic health
- specialty is in periodontics and implant dentistry
- Always wanted to do research
- Stayed in US because so many professional opportunities
- Peter mentions the anniversary of the death of [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna)
  - Pat was watching the race on TV
  - Peter says he’s never met a Brazilian person who was over 5 on that day who doesn’t remember it
  - Peter says Senna is his personal hero, and he is wearing a Senna bracelet for the occasion
- Peter did not go to the dentist for about 10 years during medical school and residency, but now he takes dental care very seriously

**Anatomy of teeth [6:15]**

- The [periodontium](https://en.wikipedia.org/wiki/Periodontium) is very complex system
- Peter points out that there’s a vascular supply quite high in the tooth even though many people might assume that the white crown is just bone
- Tooth enamel, made of minerals, is the hardest surface in the human body

![](https://peterattiamd.com/wp-content/uploads/2021/06/f1.-patcorby-1024x764.png)

**Figure 1. Individual tooth anatomy.** Image courtesy of Pat Corby.

- On the top is [enamel](https://en.wikipedia.org/wiki/Tooth_enamel) and [cementum](https://en.wikipedia.org/wiki/Cementum) (around the root), then [dentin](https://en.wikipedia.org/wiki/Dentin), then [pulp](https://en.wikipedia.org/wiki/Pulp_(tooth))
  - The enamel protects the layers underneath (hardest surface of the human body)
  - The second layer provides cushioning and is hyper sensitive
  - the heart of the tooth is the pulp, which has a lot of nerves – explains why tooth pain can be so bad
  - ligaments around the roots provide cushioning against impact

![](https://peterattiamd.com/wp-content/uploads/2021/06/f2.-patcorby-1024x814.png)

**Figure 2. Anatomy of a tooth showing cementum.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cementum)

**The role of the nervous connection and vascular supply to the tooth [10:40]**

- Tooth decay
  - Tooth decay first affects the pulp
  - If you excise the pulp, you can preserve the root

> “The way you want to think in dentistry is that … you want to preserve function.” —Pat Corby

- Try not to extract teeth because the space they hold is important
- If necessary, do a [root canal](https://en.wikipedia.org/wiki/Root_canal_treatment) or put in an artificial [crown](https://en.wikipedia.org/wiki/Crown_(dentistry))

![](https://peterattiamd.com/wp-content/uploads/2021/06/f3.-patcorby-1024x274.png)

**Figure 3. Progression of a root canal treatment.** Images courtesy of Pat Corby.

- Put implants in if you have to extract an entire tooth; not as good as a real tooth but can still hold the space and provide some function
- Can still get inflammatory periodontal disease with an implant
- Peter wonders why teeth are so highly innervated
  - Implants without nerves can still break down food
  - Our fingers are highly innervated because we need fine motor control, but why so much beneath the hard enamel?
  - Pat says it preserves blood flow and connection with the immune response to fight infection

**Function and innervation of the pulp** (*this section contains additional information provided by Pat after the podcast was recorded*)

- The [main four functions](https://www.ncbi.nlm.nih.gov/books/NBK537112/) of the pulp:
  - formation of dentin – one the most important roles, carried out by odontoblasts
  - support of dentin through nutritional support (albumin, transferrin, tenascin, and other proteoglycans)
  - innervation of the tooth
  - immune system protection of tooth: occurs through the development of new dentin, which can provide a barrier between irritants and slow the rate of carious decay
- [Two main types](https://www.ncbi.nlm.nih.gov/books/NBK537112/) of nerves are found in the pulp:
  - Sympathetic autonomic fibers to the smooth muscle cells of pulp arterioles control contractile forces that regulate blood flow
  - Afferent fibers are involved in temperature sensing and mechanical nociception

- Peter reflects that dental pain seems to serve as such an early warning indicator as a breach of a barrier
- He says, “Having been through so many miserable dental experiences, I’ve often cursed our evolutionary gods for giving us so much innervation in that tooth”

## Types of teeth and the different purpose they serve [14:15]

**Types of human teeth**

- Humans have 32 teeth with very specific functions

![](https://peterattiamd.com/wp-content/uploads/2021/06/f4.-patcorby-1024x854.png)

**Figure 4. Dental anatomy.** Image courtesy of Pat Corby.

- Incisors
  - 4 each in both the [maxillary](https://en.wikipedia.org/wiki/Maxilla) (upper) and the [mandibular](https://en.wikipedia.org/wiki/Mandible) (lower) part of the jaw
  - Used to bite and tear apart food
- Canines
  - 2 each in both upper and lower jaw
  - very strong (longer root), further tearing apart
- Premolars / bicuspids
  - 4 each in both upper and lower jaw
  - start to break down food
- Molars
  - used for chewing
  - 6 in the upper and 6 in the lower jaw

![](https://peterattiamd.com/wp-content/uploads/2021/06/f5.-patcorby.png)

**Figure 5. Close up of the position of teeth in the mouth.** Image courtesy of Pat Corby.

- The digestive process starts in the mouth
- Chewing is key because it brings the food in contact with saliva to start digestion
- Roots
  - Incisors and laterals and first premolars (the ones in front) have a single root
  - Second premolars (in back) have two
  - Molars have three or four depending on how big the tooth is
    - Much stronger and a lot of pressure
    - Peter reflects that molars would have the greatest opposition to other teeth and would need greater sensory input to sense the relative spacing and force
- The mouth is a very elaborate system
  - like a bridge, it has to be very well balanced
  - occlusion has to be precise to avoid straining the ligaments and causing inflammation
  - if don’t have good vertical occlusion, get facial pain and headaches
- Peter learned the hard way that he had 4 rather than 3 molar roots when he still had pain after root canals on the first 3 roots

## Anatomy of the oral cavity, bacteria in the mouth, and what a healthy mouth looks like [18:10]

- The oral cavity is a complex system
  - Teeth
  - Gums
  - [Gingival crevicular fluid](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6555362/) that allows for bacteria to go in and out
  - Tongue
  - And much more

![](https://peterattiamd.com/wp-content/uploads/2021/06/f6.-patcorby-1024x638.png)

**Figure 6. Anatomy of the oral cavity.** Image credit: [Quizlet](https://quizlet.com/393122434/digestive-system-mouthoral-cavity-diagram/)

- Saliva plays a protective role
  - When patients have dry mouth (perhaps due to medications, radiation treatment, or other toxic cancer treatments), the oral [microbiome](https://en.wikipedia.org/wiki/Microbiome) is altered
  - The constant washing and flushing maintain microbiome homeostasis and prevent buildup of harmful bacteria
- Oral hygiene is the key to oral health and regular bushing makes you healthier
  - There are aerobic, anaerobic, and facultative bacteria in the mouth
    - over 700 different bacteria live in symbiosis
    - they naturally coexist in the human mouth without causing disease
  - but if stop brushing your teeth, get dry mouth, etc., get changes in abundance and diversity
  - can get overgrowth of harmful bacteria and suppression of beneficial bacteria
- In a healthy mouth, ~ 30-40% of bacteria can play both aerobic and anaerobic roles and the rest are split roughly evenly between the two

## Pat’s study demonstrating the importance of flossing [23:00]

- Pat’s [study](https://pubmed.ncbi.nlm.nih.gov/18672992/) of flossing in twins
  - Two-week study of twins between the ages of 12 and 21
  - Had the same pathogens and pre-gingivitis that adults with periodontal disease have
  - These pathogens became abundant when stopped flossing
  - They are always present but only cause problems when you have a shift in the microbiome
- Utility of twin studies
  - Identical twin pairs have the same environment, age, gender, genes, etc.
  - Dizygotic (fraternal) twins have 50% of the same genes
  - In twin studies, can give twins two different treatments to compare them, or can give them same treatment to see if it’s more influenced by environment or genes
- For her study, twins came in every day for brushing (one group) or brushing plus flossing (another group)
  - Group that did not floss had gingival inflammation and bleeding
  - Had periodontal bacteria in abundance, in particular the 3 main disease-causing ones:
    - [*Porphyromonas gingivalis*](https://en.wikipedia.org/wiki/Porphyromonas_gingivalis),
    - [*Treponema denticola*](https://en.wikipedia.org/wiki/Treponema_denticola), and
    - [*Aggregatibacter actinomycetemcomitans*](https://en.wikipedia.org/wiki/Aggregatibacter)
- Most periodontal disease is inflammation caused by anaerobes that thrive in in periodontal pockets
- Periodontal disease
  - starts with inflammation around the gums
  - in healthy people, the periodontal ligament is tight
  - if stop brushing, gums get inflamed and will bleed if resume flossing
- At the initial stage of periodontal disease, it’s highly modifiable
  - but if disease continues to develop, the ligament gets inflamed and will detach from the tooth, allowing bacteria in
  - ligaments deteriorate and form a pocket
  - culminates in bone loss
- In acute periodontal disease, the gums are bleeding and inflamed but still attached to the tooth
  - in more severe disease, you see a large gap where the bone has eroded and there is a pocket
  - if you probe it, see gaps of maybe 3 to 7 mm
- Once the pocket gets inflamed with chronic periodontitis, the gums are affected
  - Gums recede, see more of teeth and eventually exposed roots
  - bacteria can colonize and get root [caries](https://en.wikipedia.org/wiki/Tooth_decay) (cavities)
  - can also get coronal caries on the top of teeth where you chew
- In bottle-fed children who have the bottle overnight, get rapid development of caries on the anterior teeth
  - One of the most common dental diseases
  - Breast milk causes less decay because all formula has sugar

## Detrimental effects of sugar and the importance of fluoride and oral hygiene [31:45]

- Harmful dental effects of sugar
  - fructose, sucrose, lactose, small complex starches are all harmful
  - most drinks have added sugar
  - cariogenic bacteria metabolize the sugar for extra energy
  - bacteria attach to the tooth secrete an extracellular matrix (biofilm)
  - when they metabolize sugar, they secrete acid which destroys the enamel of the tooth
- Peter postulates that the bacteria are metabolizing sugar anaerobically to produce lactate (and presumably hydrogen ions if the acidity of the environment is increasing)
  - Similar to the [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology)), where bacteria default to anaerobic metabolism whether oxygen is present or not
- Both glucose and fructose can be metabolized, even fructose from fruit
- Given that the twins developed periodontal disease after 2 weeks of not flossing, how did we survive before toothbrushes and flossing?
  - It was common to have dental caries 400 years ago
  - But Pat has seen people use other things to clean their teeth in developing countries: plants, sticks, etc.
  - removal of plaque is mechanical and even after brushing can get plaque back within two hours

> “[What] we’re trying to do with the brushing is just [making sure] that we don’t let that accumulate and overwhelm and develop a cavity.” —Pat Corby

- Peter points out that the form in which our ancestors consumed fructose and glucose was less concentrated and refined and thus probably less harmful to teeth
- But every time he’s had a dental problem he wonders how he would function before dentists and lidocaine
- “If you’re sitting in a cave 10,000 years ago, I don’t know that it would have been the most obvious thing that you need to remove this thin film biolayer on your teeth” – Peter Attia
- Pat says that our diets are much worse today – much higher in sugar

- Pat says that both toothbrush and toothpaste are equally important
- Toothpaste is the main source of fluoride
  - Hardens the enamel and protects against cavities, especially in children
  - Kids must get fluoride, even if have to paint it on
- Important to combine with flossing
  - Need to clean in between teeth as well as surface
- Pat is doing a trial now where they are brushing the oral mucosa to decontaminate against bacteria
  - She says oral mucosa and the tongue are neglected surfaces – most people don’t brush the tongue but need to get rid of the bacteria that accumulates there
  - “You need to clean every single surface. And just the brush itself is not going to do the job”

> “You can maintain optimal oral health just by brushing teeth, by flossing really well, and having good nutrition.” —Pat Corby

## Oral health challenges for cancer patients and immunocompromised people [39:45]

- Patient undergoing radiation treatment have mouth ulcers that make it painful to eat, drink, or brush their teeth
  - In that population, Pat’s team will clean the periodontium, cheek and oral mucosa
  - Oral hygiene programs need to be tailored to the specific needs and risks of the specific person
- Peter asks if flossing is important because of the mechanical removal of food particles between the teeth or transient irritation of the gum – would someone on an all-liquid diet still need to floss?
  - You probably should not floss if you are immunocompromised
  - Otherwise it’s mainly is to clean anaerobic bacteria in between your teeth
  - Brushing also helps with gums – massages them and helps them stay strong
  - It’s ideal to brush, then floss, then brush again to remove all bacteria
  - Also need to brush the tongue
- Different parts of the mouth have different bacteria: buccal mucosa (inside of the check), tongue, the floor of mouth, throat
- There is also the [human papilloma virus](https://en.wikipedia.org/wiki/Human_papillomavirus_infection) (HPV), which is highly associated with oropharyngeal cancer
- Patients undergoing radiation ideally would see a periodontist for a periodontal treatment every week
  - But insurance (like Medicaid and Medicare) doesn’t pay for this, even though it does pay for the oncologist, speech therapy, nutritionist, etc.
  - Pat is currently doing research to establish the benefit of oral care treatments for these patients, hoping it might become a standard of care
- Peter notes that cancer patients are at greater risk of systemic infections that start in the mouth
  - They are immunocompromised in general and also have increased susceptibility to infection from the loss of the immune barrier in the mouth
  - Pat adds they also often have dry mouth from the treatment, and some cannot produce saliva anymore
  - They get fungal infections, which “escalates a lot of local infection and inflammation in the oral cavity and affects them systemically”
- Pat is doing a study looking at saliva, inflammatory markers, and the oral microbiome before and three months after radiation treatment
  - Data Pat is collecting now shows that most of the [cytokines](https://en.wikipedia.org/wiki/Cytokine) in saliva are completely suppressed in patients who received comprehensive periodontal care (unlike those who did not receive the care)
  - Pat noted that no doctors were looking at cancer patients’ mouths even though they have “horrible oral hygiene”
  - These cancer patients are also depressed

> “They start radiation right after surgery, … they already can’t brush their teeth because sometimes they lose half of their jaw, they take their tongue. So they’re highly debilitated, so they stop brushing and they go into radiation. When they get into radiation [it’s] changing the microbiome and they develop horrible ulcers in their mouth. And then they become immunocompromised. And so it’s a whole cascade of things that happen in those patients.” —Pat Corby

## Pat’s current research on cancer patients undergoing radiation treatment and the oral health risks associated with human papilloma virus (HPV) [50:00]

**Research on cancer patients undergoing radiation**

- Pat started doing a dental cleaning on patients about to start radiation treatment and then throughout treatment
  - The radiation oncologist, [Nicholas Sanfilippo](https://weillcornell.org/nicholas-sanfilippo-md), noticed that his patients whom Pat treated did not develop mucositis
  - She did a [preliminary study](https://med.nyu.edu/center-for-innovations-in-the-advancement-of-care/sites/default/files/centerforinnovations/NYU_Langone_Nursing_Research_Booklet_6_13_17.pdf) on a small group of patients and later got a grant to do a [larger study](https://www.dental.upenn.edu/wp-content/uploads/2020/03/PD-ARMOR-Brochure_4-pages.pdf)
- Some of the dental care must be done by someone trained and some can de done by patients at home
- If someone doesn’t brush for a long period of time and plaque builds up, it can become tartar
  - Then has to be removed with a specific vibrating ultrasound
  - In a routine dental cleaning, they either scrape your teeth with very sharp instruments or they use the electronic one to disrupt and break up plaque
- Pat is doing both in a current study as well a cleaning the entire oral cavity
  - Complete cleaning takes about an hour
  - In the other group, the hygienist does a light clean or a holistic, comprehensive approach to education in order to make the study blind
  - Neither group has been developing disease
- Pat’s study is focusing specifically on patients of both sexes with head and neck cancer receiving a minimum of 50 grades of radiation to the oral cavity due to the cancer
  - In that circumstance, 90% of them will develop mucositis
  - Have both RT only and RT + chemo groups
  - 100% of patients in the RT + chemo group get mucositis
  - Mostly squamous cell head and neck cancers

**HPV (56:00)** (*this section contains additional information provided by Pat after the podcast was recorded*)

- HPV is believed to cause [70% of cancers of the oropharynx](https://www.cdc.gov/cancer/hpv/basic_info/hpv_oropharyngeal.htm) the (back of the throat, including the base of the tongue and tonsils) in the US

![](https://peterattiamd.com/wp-content/uploads/2021/06/f7.-patcorby-1024x601.png)

**Figure 7. The Oropharynx**. Image credit: [Centers for Disease Control](https://www.cdc.gov/cancer/hpv/basic_info/hpv_oropharyngeal.htm)

- It’s [unknown if HPV infection alone](https://www.cdc.gov/cancer/hpv/basic_info/hpv_oropharyngeal.htm) can cause oropharyngeal cancers or if other risk factors (such as tobacco use) must also be present
- Most (~90%) HPV-related oropharyngeal cancers are positive for a specific strain called HPV-16
- Peter finds the rising incidence of HPV-driven squamous cell carcinomas of the oropharyngeal region concerning
  - we do not have adequate screening procedures like we do for HPV-driven cancer of the pelvis in women
  - Unless you do advanced imaging like an MRI, they’re often found quite late
- Oral sex is the primary mode of transmission, and there may also be other unknown ways
  - These cancers are often the result of oral sex combined with poor oral health
  - As with other mouth infections, it’s about the balance of various microbes
  - Some, like *P. gingivalis*, allow virus to grow
- Immune system deficiency also allows viruses, bacteria, and fungi to develop into infections
- The HPV vaccine
  - The [HPV vaccine protects against](https://www.cdc.gov/cancer/hpv/basic_info/hpv_oropharyngeal.htm) the types of HPV that can cause oropharyngeal cancers
  - The CDC [currently recommends](https://www.cdc.gov/cancer/hpv/basic_info/hpv_oropharyngeal.htm) that everyone be vaccinated around age 11-12 (and through age 26 years if not already vaccinated)

## Periodontal disease: caries and root canals [57:30]

**Stages of dental disease (58:30)**

![](https://peterattiamd.com/wp-content/uploads/2021/06/f8.-patcorby-1024x534.png)

**Figure 8. Development of dental caries.** Image courtesy of Pat Corby

- The initial stage of dental decay is breaking through the enamel
  - Hasn’t reached second layer of the tooth
  - White spot lesions when decalcification has started
  - Can be reversed at this stage
  - Most we shouldn’t be touching or treating, in kids can do a fluoride varnish application
  - Used to poke it with a probe, now mostly use air to inspect so don’t break the enamel
  - Minimal discomfort because enamel caries have not reached the pulp
  - no cold or heat sensitivity
- When it reaches the dentin, it’s painful and cold sensitive
  - when bacteria start colonizing, can get constant pain
  - cold sensitivity occurs earlier in the process
  - dentin caries can be fixed without a root canal
- Once an infection reaches the pulp, a root canal is required
  - Must excise the live pulp and then clean and disinfect
  - A hot sensation is usually a sign of inflammation

**Root canal treatment**

- Peter regrets switching out a mercury filling for a white one because it started hurting and ultimately he needed a root canal
- Many times when you do a root canal, the pulp is still alive but is removed
  - Used to be a crude procedure when they would break through the roots
  - Today it’s essentially a microscopic surgery
  - Excise the pulp in an aseptic environment
  - Fill the hole with special materials
  - Preserves function

![](https://peterattiamd.com/wp-content/uploads/2021/06/f9.-patcorby-1024x566.png)

**Figure 9. Cross-section of a tooth before and after a root canal treatment.** Image credit: [American Association of Endodontists](https://www.aae.org/patients/root-canal-treatment/what-is-a-root-canal/)

- Peter says “if you’re going to have a root canal, it seems to me that you have to have this done under a microscope by an endodontist”

**Controversies around root canals [1:06:45]**

- There is no evidence that root canals cause the plethora of problems people claim they do (cancer, [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease), etc.)
  - The infection in your tooth is from microbes that were already in your body
  - They are effective if they are done microscopically and should not cause long-term issues
  - There’s a paper associating root canals with breast cancer which Peter calls a “bottom of the birdcage paper” because it did not look at a control group of women who did not have a root canal but did have cancer

> “What bothers me the most about this type of pseudoscience is when a woman gets breast cancer, it’s already upsetting enough. I think the last thing she needs to be told is, ‘This is because you had a root canal five years ago.’ That’s probably the biggest issue I take with this nonsensical science. And unfortunately, it tends to aggregate from the same group of people who tend to have other beliefs that are very unsubstantiated, such as vaccines causing autism and things like that.” —Peter Attia

## The relationship between poor oral health and systemic health diseases [1:11:00]

- Peter asks if the greatest causal relationship we have between poor oral health and poor systemic health would be with cardiovascular disease
  - Pat says there is a lot of research showing association
  - but we don’t know which comes first
- Periodontal disease has been associated low birth weight, heart problems, and [diabetes](https://en.wikipedia.org/wiki/Diabetes)
- Some markers of periodontal disease and Alzheimer’s disease are similar
- Pat says that “*It’s all based on the insult of the bacteria, causing inflammation and systemic health [problems]*.”
- We really need to do clinical trials to establish causality

**Down syndrome**

- Pat has worked with [Mony de Leon](https://directory.weill.cornell.edu/person/profile/mdl4001) and [Angela Kamer](https://dental.nyu.edu/faculty/ft/ark5.html) from NYU
- They did a [study](https://pubmed.ncbi.nlm.nih.gov/27239536/) on kids with [Down Syndrome](https://en.wikipedia.org/wiki/Down_syndrome)
  - They have motor skill and cognition issues so it’s hard to maintain good oral hygiene
  - children with Down syndrome are very susceptible to Alzheimer’s disease and cardiovascular disease and usually do not live a normal life span (die as early as their 40s or 50s)
  - but hard to tell if the increase in [amyloid-β](https://en.wikipedia.org/wiki/Amyloid_beta) in the brain is an independent process that’s being driven by the chromosomal abnormalities that are found in Down syndrome versus related to poor oral hygiene
- Peter says an interesting experiment would be a longitudinal study of two groups of peers with Down syndrome, one that are provided intensive support for oral care and one that are standard of care

**A preventative approach**

- Pat says we need to focus on “a very intense preventive approach”
- At Penn Dental, the dean ([Mark Wolff](https://www.dental.upenn.edu/faculty/mark-s-wolff/), whom Pat calls “a visionary” in his focus on prevention) prioritized the opening of the [Care Center for People with Disabilities](https://www.dental.upenn.edu/alumni/give/care-center-for-persons-with-disabilities/)
  - He and Pat are creating a program to do research on how to create effective oral hygiene programs for people with disabilities, especially cognitive and motor skills
  - It focuses on caregivers
  - But hard to know what to measure: “There is no outcome assessment that you can use for this specific population because they’re so neglected”
- Peter asks about a hypothetical experiment in subjects without cancer and who are not immunocompromised
  - Of one group receives best-in-class oral care and the other bad or mediocre care
  - Would you see a difference in inflammatory markers (including cytokines, [macrophages](https://en.wikipedia.org/wiki/Macrophage), and [monocytes](https://en.wikipedia.org/wiki/Monocyte)) across those two groups?
  - If so, that alone could explain the increase in systemic disease
    - The relationship between inflammation and cardiovascular disease is well established
    - If two people have identical lipoprotein profiles but one has inflammation, the one with inflammation will have a greater burden of disease
    - it plays a role in cancer and Alzheimer’s disease

> “To me, that’s the [Occam’s razor](https://en.wikipedia.org/wiki/Occam's_razor) approach here. Which is, poor oral health leads to poor or substandard amounts of inflammatory environment, and that’s the driver of these diseases” – Peter Attia

- Pat points out that, despite this relationship, doctors do not routinely ask their patients about oral hygiene

## Potential connection between oral hygiene and COVID-19 [1:17:45]

- COVID is transmitted by saliva / the mouth
  - Studies show that the [ACE2](https://en.wikipedia.org/wiki/Angiotensin-converting_enzyme_2) receptors (to which COVID binds to enter the body) are highly expressed in the oral cavity
  - But when a COVID patient goers into the hospital they are put in a mask in a supine position
  - Never brush their teeth or ask if they have periodontal disease
- Periodontal disease would be the “perfect reservoir” for the virus
  - COVID patients aren’t particularly congested – it goes directly from the mouth to the lungs
  - Oral hygiene should be a priority for these patients
- There aren’t any oral epidemiologists or periodontists on COVID committees
  - Experts on oral health could help us do much better prevention than masks
  - When COVID hit, dental care was not considered essential
- Pat had to suspend her trials for 3-4 months and the clinics were completely closed for almost a year
  - Procedures were suspended “and we saw really detrimental things because people couldn’t get access to care”
- Also, because of masks, people brush their teeth less and get dry mouth from breathing through a mask

## Dry mouth leading to oral infections and ways to prevent it [1:22:30]

- Can actually get [oral thrush](https://en.wikipedia.org/wiki/Oral_candidiasis) even if not immunocompromised
  - Sometimes related to a medication like [inhaled steroids](https://www.healthline.com/health/inhaled-steroids)
  - It’s also highly associated with [candida infection](https://www.cdc.gov/fungal/diseases/candidiasis/thrush/index.html)
    - Primary reason is lack of saliva (i.e., dry mouth)
  - Generally speaking, can be a result of poor oral hygiene (and certain medications) that allows [opportunistic](https://en.wikipedia.org/wiki/Opportunistic_infection) species (sometimes both virus and fungus) to grow
    - People with HIV have constant episodes of fungal infection in their mouth
- [Anticholinergics](https://en.wikipedia.org/wiki/Anticholinergic) and dry mouth
  - A class of drugs that inhibit the [parasympathetic nervous system](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system) and are used to treat digestive issues, respiratory problems, dizziness, and other conditions
  - one of the most popular classes of drugs that can cause dry mouth
  - There is an [association](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2736353) between anticholinergics and Alzheimer’s disease but we don’t have data to indicate whether it’s causal
- Interesting to speculate if the systemic effect of changes in resistance of bacteria that dry mouth causes plays a role

**Preventative measures**

- Keeping mouth lubricated with SUGAR FREE chewing gum or lozenges can be useful for people who have dry mouth
- Continual hydration is also key (sip water all day long)
- [Xylitol](https://en.wikipedia.org/wiki/Xylitol) (a sugar substitute) might be specifically be beneficial
  - Peter chews gum with xylitol in place of brushing his teeth when he is out
  - Pat has done [research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3261633/) on mother-to-child transmission of dental caries
    - Caregivers with caries tasting food and then giving it the child can affect the child’s oral health
    - Also found could prevent [vertical transmission](https://www.medicinenet.com/vertical_transmission/definition.htm) by having pregnant women chew xylitol
  - Xylitol may also prevents tooth decay because bacteria do not metabolize it
  - Peter’s favorite xylitol brand is PÜR [gum](https://www.amazon.com/PUR-Gum-Variety-440-pieces/dp/B06X188QBZ/ref=sr_1_5?dchild=1&keywords=Pure+Gum&qid=1622121412&rdc=1&sr=8-5) and [mints](https://www.amazon.com/Pur-Mints-Flavor-Variety-Pack/dp/B07FNTBM6B/ref=sr_1_3?crid=1M7AZ5TYINHNS&dchild=1&keywords=pur+mints&qid=1622121541&sprefix=Pur+min%2Caps%2C186&sr=8-3)

## What determines the appearance of teeth, methods of teeth whitening, and whether you should remove mercury fillings [1:27:30]

- What people notice most about teeth is how straight and white they are
- The color of someone’s teeth is somewhat genetically determined
- But environment plays a role as well
  - Pat’s research has shown that drinking coffee and tea had an effect
  - can modify by brushing and using whitening products
  - Peter says black tea and red wine are the worst for him
- Whitening the teeth can be detrimental if bleach excessively and cause mineral loss
  - Better to do it at the dentist rather than at home to protect the gums
  - dentists will not to do it if you have periodontal disease, but people buying over-the-counter products don’t know what they’re doing
  - doing it frequently results in constant demineralization
  - use FDA-approved products under a dentist’s supervision
- can also be preventative by minimizing the things that really discolor your teeth

*Should you remove mercury fillings?*

- There is no need to remove mercury fillings if there is no decay underneath
- The mercury in fillings is not harmful

## Importance of fluoride for preventing tooth decay, and dental care for children [1:32:45]

**Fluoride (1:32:45)**

- Want to use toothpaste with 1000-1500 parts per million (ppm) of fluoride
  - The [American Dental Association](https://www.ada.org/en) (ADA) [lists toothpaste brands](https://www.mouthhealthy.org/en/ada-seal-products/category-display?attributes=Fluoride) with fluoride to prevent decay
  - Kids under 1 swallow toothpaste so you should not use fluoride for them
- In many countries the drinking water is fluoridated, but it varies by region in the US
- Can also use drops or varnish for kids (painted on every 6 months) as well
- There are highly concentrated fluoride varnishes available (e.g., [PreviDent](https://www.colgate.com/en-us/products/prescription-only-products/pv-5000-plus-prescription-strength))
  - Pat recommends using them every night for people at high risk of caries like patients undergoing radiation treatment

**Dental care in children**

- Pat’s now-grown kids never had tooth decay
  - She would tell her kids stories about the microbiome that was going to eat their teeth so they would brush
- Night is an important time for tooth decay
  - Don’t give kids baby bottles overnight
  - when you’re sleeping, you have suppressed saliva production, creating the perfect environment for the bacteria to grow
  - critical to brush before you go to bed
- Peter asks how to handle tooth decay in children
  - Pat says you must be very careful not to traumatize them; use sedation
  - Can extract a baby tooth if causing a lot of pain
  - Can’t put a hole in the tooth and do restoration in a young child
- Can use a very concentrated type of fluoride as a temporary measure, but it turns the cheek black
  - It’s mixed with a metal that hardens when it comes into contact with the soft dentin
  - will control pain and arrest decay until the tooth falls out
  - warn the parents that the tooth will turn black but it will not affect the adult tooth

## Useful dental products: floss, electrics toothbrushes, and more [1:39:15]

- Peter asks about the cottage industry of products
  - Things like oil for pulling through the teeth and tongue scraping
  - Pat says there’s not much research, but brushing the tongue should be enough

- Dental floss

- Seem to be different types: ribbon, miniature rope, and types coated in wax
  - Pat says it’s largely a matter of patient preference
  - If your teeth are close together, may need to use a wax-coated type to protect the gums
  - Also make kinds that work well with bridges
- Pat estimates that most of her patients don’t floss every day, but it’s even more important than brushing
  - You can’t really clean the plaque that is in between your teeth
  - Anaerobic bacteria that cause systemic health problems like cardiovascular disease and diabetes are found in niches without oxygen like in between teeth and the back of the throat

- Pat likes the [Waterpik](https://www.amazon.com/Waterpik-Flosser-Electric-Countertop-Irrigator/dp/B00HFQQ0VU) but it should not be used without brushing
- Peter wonders if his toothpick habit is bad for him
  - Pat says it can stimulate the gums
  - But it cannot substitute for flossing
- Pat also likes electric toothbrushes
  - [Sonicare](https://www.amazon.com/sonicare-toothbrush/s?k=sonicare+toothbrush) and [Oral B](https://www.amazon.com/stores/Oral-B/page/995E7ED3-DC48-4870-89BF-4AB2F59E8DFB?ref_=ast_bln) are equally effective
  - Peter and Pat prefer Oral B because the vibrations are more gentle
  - Use whichever you prefer

## Ideal oral care regimens [1:47:30]

- Peter’s regimen
  - brushes his teeth in the morning only after he drinks coffee and then eats around 11
  - He uses his Oral B toothbrush for 30 seconds on top inside, 30 seconds top outside, and then same on the bottom
  - Uses his toothpick during the day
  - After dinner he flosses and then uses the Oral B again (with a xylitol-based fluoride toothpaste)
  - Does not use mouthwash or a Waterpik
  - Pat says he needs to brush after his coffee to clean his mouth from overnight
- Soft bristle toothbrushes can be better for the tongue
- You should also rinse your toothbrush after using it, and then dry it because bacteria thrive in moisture
  - Rinse in warm water
  - You can even rinse with soap (toothpaste has soap in it but taste is blocked)
- Mouthwash wipes out all your microbiome, including the good ones
  - Good to use when can’t brush, but don’t overuse so microbes won’t become resistant
  - There is not good data on whether mouthwash can cause fungal or other overgrowth
  - But it changes the microflora, so if you’re healthy you don’t want to interfere with it
- The take-home message is that prevention is key
  - The only way to prevent dental caries throughout life is chronic preventive oral care
  - Go to the dentist every 6 months for a cleaning and to ensure no cavities
  - Research shows 6 months is good for healthy people
  - If you are high risk with systemic health problems (e.g., diabetes), maybe 3 times a year instead
- Pat’s [own](https://onlinelibrary.wiley.com/doi/abs/10.1111/jcpe.12827) [research](https://pubmed.ncbi.nlm.nih.gov/26935472/) has shown that the rate of progression of periodontal disease varies
  - It’s closely tied to the body, so a systemic issue will exacerbate inflammation
  - See worse periodontal disease in patients with systemic diseases

**Oral hygiene and diabetes** (*this section contains additional information provided by Pat after the podcast was recorded*)

- Diabetics have more periodontal disease, so need more frequent cleanings
- Both [Type I](https://en.wikipedia.org/wiki/Type_1_diabetes) (T1DM) and [Type II](https://en.wikipedia.org/wiki/Type_2_diabetes) (T2DM) diabetes are associated with periodontal disease
  - Most of the studies have looked at T2DM and found a strong association
  - both types of diabetes involve increased inflammation and [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species) (ROS) in the gingiva
  - Hyperglycemia (high blood sugar), high levels of [advanced glycation end products](https://en.wikipedia.org/wiki/Advanced_glycation_end-product) **(**AGEs), and possibly hypoinsulinemia (low blood [insulin](https://en.wikipedia.org/wiki/Insulin)) or insulin resistance may all contribute
- The [largest clinical trial addressing this question](https://pubmed.ncbi.nlm.nih.gov/24346989/) did not find any effects of periodontal treatment on improving glycemic control [as measured by [glycated hemoglobin](https://en.wikipedia.org/wiki/Glycated_hemoglobin) (HbA1c)] in patients with T2DM
  - This was a surprising finding
  - the trial was stopped early because of futility
- But both diabetes and periodontal disease are preventable, so that is the key

§

## Selected Links / Related Material

**Summary of pulp function and innervation**: [Anatomy, Head and Neck, Pulp (Tooth)](https://www.ncbi.nlm.nih.gov/books/NBK537112/) *StatPearls* (Ghannam, Alameddine & Bordoni 2021) [12:15]

**Pat’s study of flossing in twins**: [Treatment outcomes of dental flossing in twins: molecular analysis of the interproximal microflora](https://pubmed.ncbi.nlm.nih.gov/18672992/) *Journal of Periodontology* (Corby et al. 2008) [22:15]

**Pat’s preliminary study on regular dental cleanings for cancer patients undergoing radiation treatment**: [Oral Care Protocol for the Management of Chemotherapy and Radiation Therapy-Induced Oral Mucositis (OMDP)](https://clinicaltrials.gov/ct2/show/NCT02608879?term=CORBY&cond=Mucositis+Oral&draw=2&rank=2) | ClinicalTrials.gov (#NCT02608879) [52:00]

**CDC statistics and information on HPV-related cancer**: [HPV and Oropharyngeal Cancer](https://www.cdc.gov/cancer/hpv/basic_info/hpv_oropharyngeal.htm) Centers for Disease Control (CDC) (cdc.gov) [56:00]

**Study of periodontal disease and Alzheimer’s in Down Syndrome patients**: [Periodontal disease’s contribution to Alzheimer’s disease progression in Down syndrome](https://pubmed.ncbi.nlm.nih.gov/27239536/) *Alzheimer’s & dementia* (Kamer … Corby … de Leon 2016) [1:13:00]

**Study showing an association between anticholinergics and Alzheimer’s disease**: [Anticholinergic Drug Exposure and the Risk of Dementia: A Nested Case-Control Study](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2736353) *JAMA Internal Medicine* (Coupland et al. 2019)  [1:24:00]

**Pat’s research on mother-child transmission of dental caries**: [On the Acquisition of Periodontopathic Bacteria by Children from Mothers: A Randomized Double-Masked Placebo-Controlled Trial in Bauru, Brazil](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3261633/) *Suom Hammaslaakarilehti* (Bretz … Corby et al. 2006) [1:26:15]

**Pat’s research on the progression of periodontal disease**: [1:55:30]

- [Patterns of periodontal disease progression based on linear mixed models of clinical attachment loss](https://onlinelibrary.wiley.com/doi/abs/10.1111/jcpe.12827) *Journal of Clinical Periodontology* (Teles … Corby et al. 2017)
- [Modelling changes in clinical attachment loss to classify periodontal disease progression](https://pubmed.ncbi.nlm.nih.gov/26935472/) *Journal of Clinical Periodontology* (Teles … Corby et al. 2016)

**Clinical trial finding that periodontal treatment did not improve HbA1c levels in patients with T2DM**: [The effect of nonsurgical periodontal therapy on hemoglobin A1c levels in persons with type 2 diabetes and chronic periodontitis: a randomized clinical trial](https://pubmed.ncbi.nlm.nih.gov/24346989/) *JAMA* (Engebretson et al. 2013) [1:57:15]

§

## People Mentioned

- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [5:00]
- [Nicholas Sanfilippo](https://weillcornell.org/nicholas-sanfilippo-md) [51:00]
- [Mony de Leon](https://directory.weill.cornell.edu/person/profile/mdl4001) [1:12:30]
- [Angela Kamer](https://dental.nyu.edu/faculty/ft/ark5.html) [1:12:30]
- [Mark Wolff](https://www.dental.upenn.edu/faculty/mark-s-wolff/) [1:14:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/06/bio-patcorby-500x500.png)

##### Patricia Corby, D.D.S., M.S.

Dr. Patricia Corby is an Associate Professor of Oral Medicine and the Associate Dean of Translational Research at the University of Pennsylvania Dental Medicine. She is also the Director of the Penn Dental Medicine Center for Clinical and Translational Research. She is an experienced researcher with over 20 years of experience designing and running high-impact clinical research projects and has served as Principal Investigator, Co-Investigator, or Consultant on a number of projects funded by the National Institutes of Health (NIH), foundations, and industry.  Dr. Corby’s work focuses on the value of integrating medical and dental services in different healthcare and public health settings to prevent systemic complications of populations with unmet oral health needs and associated chronic diseases.  After receiving her DDS and completing her residency in Periodontics and Implants in her native Brazil, she obtained her MS in Biomedical Informatics from the University of Pittsburgh School of Medicine completed a postdoctoral training in Molecular Biology and Microbial Genetics at Harvard University and the Forsyth Institute.

Professional website: https://www.dental.upenn.edu/faculty/patricia-corby/