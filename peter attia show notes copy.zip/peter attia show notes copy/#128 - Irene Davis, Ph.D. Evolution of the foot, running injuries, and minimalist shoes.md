# #128 – Irene Davis, Ph.D.: Evolution of the foot, running injuries, and minimalist shoes

**Source:** [https://peterattiamd.com/irenedavis/](https://peterattiamd.com/irenedavis/)

---

Irene Davis is the founding Director of the Spaulding National Running Center at the Harvard Medical School. In this episode, Irene describes how her research of biomechanics and clinical work with running injuries, as well as research by others, has shaped her views on maintaining body alignment and foot health. Irene discusses her argument for the role of modern footwear in running-related injuries and how minimalist footwear helps resolve the subsequent biomechanical issues.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/irenedavis/the_Drive_public.png)

Play

#128 – Irene Davis, Ph.D.: The evolution of the foot, running injuries, and minimalist shoes

#128 – Irene Davis, Ph.D.: The evolution of the foot, running injuries, and minimalist shoes

1x15s30s

0:001:53:06

## We discuss:

- Irene’s path to her Ph.D., her entry into physical therapy, and her interest in biomechanics [3:20];
- How Irene’s thinking about the use of orthotics has changed [7:15];
- The evolution of the human foot and the transition from walking to running [10:30];
- The evolution of shoes and its impact on running injuries [17:30];
- An overview of running injuries [26:00];
- Cushioned running shoes, heel striking and impact forces [29:30];
- Shin splints [33:45];
- How heel strike patterns promotes knee stress through rate of loading [35:30];
- The critical importance of exercise [42:15];
- Impact forces and injury potential [45:45];
- How shoe cushioning alters impact forces despite forefoot striking [49:00];
- An overview of minimalist shoes [52:30];
- Irene’s protocol for transitioning people out of orthotics [58:45];
- Transitioning to minimalist shoes and a forefoot strike [1:05:30];
- Foot muscle volume, minimalist shoes, and orthotics [1:07:00];
- The recognition of the importance of foot strength in podiatry [1:09:45];
- Minimalist shoes across the lifespan—from children to adults [1:12:30];
- Why learning to forefoot strike on soft surfaces is not the best approach [1:20:00];
- Knee valgus and factors related to knee injury [1:21:45];
- IT band syndrome [1:28:30];
- Physics and ground reaction forces [1:33:15];
- Irene’s approach to retraining a runner’s gait [1:36:00];
- Case study—How the transition to minimalist shoes decreased injury and improved performance [1:42:15];
- Importance of proper movement patterns and the negative influence of our modern environment [1:45:30]; and
- More.

§

## Show Notes

## Irene’s path to her Ph.D., her entry into physical therapy, and her interest in biomechanics [3:20]

The path to and focus of Irene’s Ph.D.

- She originally wanted to be in the FBI, but at the time, women weren’t allowed
- Classes in exercise science eventually led her to completing a degree in physical therapy
- Her curiosity led her to complete a master’s degree and Ph.D. in biomechanics
- She completed her Ph.D. at Penn State under [Dr. Peter Kavanaugh](https://orthop.washington.edu/faculty-profiles/peter-r-cavanagh-phd-dsc.html), who is a pioneer of running mechanics

Irene’s early work as a physical therapist

- Watching her cousin go through physical therapy after being paralyzed in a car accident inspired her to become a physical therapist herself
- She started her physical therapy career in spinal cord rehab
- After starting graduate school, she shifted to outpatient physical therapy

What shifted Irene’s interest towards biomechanics

- Quadriplegics need to move their entire body with just 25% of their muscle – they need to learn to use their bodys in atypical ways



## How Irene’s thinking about the use of orthotics has changed [7:15]

Early in Irene’s career, she was a proponent of [orthotics](https://en.wikipedia.org/wiki/Orthotics)

- She prescribed orthotics as a physical therapist
- She taught about orthotics at the University of Delaware
- She simply believed that some people had feet that were incapable of supporting themselves

Irene’s thinking began to change based on her research and when the book [Born to Run](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307279189) was published

- Her research led her to realize that people who land on their heels while running incur greater impact forces, and that footwear influences these forces
- This, plus the message in book Born to Run, made her reflect on the traditional approach of physical therapy for other areas of the body – *removing* support to encourage patients to improve their intrinsic ability
- The permanent nature of orthotics is the opposite of this approach
- *Irene says, “And it kind of brought me back to when I was a physical therapist in rehab, where we would try to take away as much support and bracing to our patients, even wheelchairs, a lower back, less lower extremity bracing so that they would use what they had. And yet my thinking in terms of feet was completely opposite. … We don’t brace anything else permanently if you have an orthopedic problem.”*

Despite the common thinking that we should be prescribing a shoe type based on an individual’s need for support, a [study done by Joe Knapik](https://www.jospt.org/doi/full/10.2519/jospt.2014.5342) on thousands of military personnel found that there was no difference in injury rate

## The evolution of the human foot and the transition from walking to running [10:30]

Anatomical changes from walking man (Australopithecus) to running man (Homo erectus)

- A study by [Dan Lieberman](https://scholar.harvard.edu/dlieberman/home) and [Dennis Bramble](https://www.biology.utah.edu/people/details.php?id=42) ([Bramble & Lieberman, 2004](https://www.nature.com/articles/nature03052)) describes human evolution in the context of endurance running
- Joint surfaces became larger to bear greater forces
- The longitudinal and medial longitudinal arches developed
- The [achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon) became longer for greater energy storage

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-1-irenedavis-1024x811.png)

**Figure 1. The longitudinal arch and bony structure of the foot.** Image credit: [oist.jp](https://www.oist.jp/news-center/press-releases/these-feet-were-made-walking)

Complexity of the foot

- The foot has 26 bones, 33 articulations, and six degrees of freedom, resulting in a complex structure
- It has four layers of arch muscle comprised of 10 muscles
- This complexity allows for a stable base of support while being able to adapt to uneven terrain and absorb shock

The “born to run” concept

- Peter recalls [Dan Lieberman](https://scholar.harvard.edu/dlieberman/home) stating during a lecture that no animal can cover as great of a distance over 24 hours as a human
- Humans have been running for 2 million years
- The ability to run greater distances was an evolutionary advantage that allowed our ancestors to chase larger animals to exhaustion

## The evolution of shoes and its impact on running injuries [17:30]

Earliest shoes

- The earliest known shoes date back to 10,000 years ago
- They were made with sage brush bark and were basically a flat surface with a strap, similar to [Huarache sandals](https://en.wikipedia.org/wiki/Huarache_(shoe))
- The primary purpose was to protect the bottom of the foot

Early running shoes

- Prior to the 1960s, running footwear was similar to what is sold as minimalist shoes today
- As running became a popular activity for the general population, people were getting injured
  - Achilles tendonitis was common — the general population were used to walking around in shoes with a slightly raised heel
  - Then when the running boom happened, the existing running shoes were flat (i.e., no heel raise)
  - At that point, new running shoes were created with a heel lift and cushioning in an attempt to counteract the injuries

Types of modern running shoes

- “Motion control” shoes have a very stiff heel counter and stiffer material in the mid sole. They may also have additional plastic reinforcement, all to prevent the foot from rolling in
- “Cushioning” shoes are for people with a high arch and little foot movement
- Running injuries did not appear in the research literature, or at least not nearly as much, until approximately when these specialized shoes appeared.

## An overview of running injuries [26:00]

- Running injuries are most commonly from the knee down, but can go all the way up to the neck
- The reason why most injuries occur from the knee down is because this is where most shock absorption occurs
  - Landing incurs a force that is 2.5 to 3 times body weight
  - At the knee, this force can be 7 times body weight
- According to [Jeff Johnson](https://www.runnersworld.com/advanced/a20792873/employee-number-one/), a former Nike employee, Nike brought in three sports podiatrists who concluded that the rise in running injuries was due to too much impact and motion, leading towards the added motion control and cushioning that is now seen in running shoes

> *“Rather than have the runners adapt to the running, they took the shoe and adapted it to the runner.”*
>
> *—Irene Davis*

## Cushioned running shoes, heel striking and impact forces [29:30]

Impact forces

- [Studies](https://www.nature.com/articles/s41598-018-35980-6?ref=pharmater.com) have shown that people create greater landing force in the [HOKA](https://www.hokaoneone.com/) shoe
- The increased cushioning gives a false sense of security that encourages a harder landing

Heel vs. forefoot striking

- A [study has shown](https://journals.lww.com/acsm-msse/Fulltext/2014/08000/Force_Deformation_Properties_of_the_Human_Heel_Pad.14.aspx) that the heel has a relatively low pain threshold that doesn’t extend far beyond the level of force generated during walking—*suggesting that we have evolved to be forefoot strikers*
- Other studies have shown that it is footwear that encouraged many of us to become heel strikers
  - [Lieberman et al., 2010](https://www.nature.com/articles/nature08723?ref=nf)
  - [Lieberman et al., 2015](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0131354)
- Most barefoot runners are forefoot strikers (even [Atlas the robot](https://en.wikipedia.org/wiki/Atlas_(robot)) [runs with a forefoot strike](https://www.youtube.com/watch?v=vjSohj-Iclc))
- Irene believes that we are adapted to be forefoot strikers and that this is why we have a long [Achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon)
- An advantage of heel striking is that it allows for a longer stride and therefore greater speed, and on softer surfaces, this might be reasonable

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-2-irene-davis-1024x583.png)

**Figure 2. Impact forces from heel striking versus forefoot striking.** Image credit: [researchgate.net](https://www.researchgate.net/publication/319104024_Common_Running_Overuse_Injuries_and_Prevention)

## Shin splints [33:45]

- One of the most common injuries that runners have when they first start running is an “overuse” injury called [shin splints](https://en.wikipedia.org/wiki/Shin_splints)
- Shin splints manifest as pain in the front of the lower leg
- The primary muscle where this occurs, the [tibialis anterior](https://en.wikipedia.org/wiki/Tibialis_anterior_muscle), is much smaller than the muscles in the back of the lower leg
- The tibialis anterior concentrically lifts the forefoot towards the knee and eccentrically controls the lowering of the forefoot towards the ground
- Because of the smaller size, the tibialis anterior is more prone to the fatigue and overuse that can result in shin splints

> “If you just look at the shape of the human lower leg, it’s designed to carry more load in the back than in the front.”
>
> —Peter Attia

## How heel strike patterns promotes knee stress through rate of loading [35:30]

- A forefoot strike allows for the calf and the motion of the foot to absorb some of the impact force and also allows the transition of force from the foot to the knee to occur **gradually**
- With a heel strike, more of the **impact force goes directly to the knee**, and the force is transferred more rapidly
- [Studies have shown](https://bjsm.bmj.com/content/50/8/450.short) higher rates of force transfer to be associated with running injuries

**Irene’s approach with patients in the clinic**:

- When people that come in with injuries will be habituated to foot orthotics and/or habituated to standard shoes
- Irene’s goal is to get the person running closer to the way we evolve to move and therefore lessening the risk for injury

> “We really try to get people back into shoes that allow their feet to do what they were adapted to do and to run in a pattern that is closer to our evolutionary legacy.” —Irene Davis

*Does Irene believe that there are certain people who just shouldn’t be running?*

- “I believe that running is an activity of daily living. People talk about running being a skill, I don’t think it is. We learn to run on our own.”
- Very few exceptions — e.g., huge leg length discrepancy that is really going to abnormally load, extreme foot deformities, etc.
- But when you look at the normal distribution of people, **most people can run**

## The critical importance of exercise [42:15]

Trailer for an interesting documentary: [The Motivation Factor](https://motivationmovie.com/)

The documentary follows a high school boot camp-style fitness program:

- In 1955, a Marine by the name of Stan LeProtti [started a program](https://www.mentalfloss.com/article/62991/1960s-high-school-gym-class-would-ruin-you) at a high school in Carmichael, California in which every kid went through a military-type boot camp
- The program was partly driven by motivation – each advancing level of fitness was associated with a different color of shorts — Everyone started out with white shorts and could then progress to different colors representing more advanced fitness levels

How the results of this program symbolize Irene’s thoughts on the innate human ability to run

- All of the kids in this program ended fit and looking like they were in the military
- Irene believes that all of these kids, who now range from approximately 55-80 years old, would still be capable of running well today.
- She believes that basic movement skill fosters proper running mechanics and that the lack of such skill is the reason why so many people today have improper running mechanics
- But you do need to be fit to run because being fit implies development of the motor control needed to run properly

> “*I think everyone who has a pretty normally intact neuromuscular system can run. But to answer your question, should that teenager who’s overweight and has been doing video games go out and run? Probably not.”*

## Impact forces and injury potential [45:45]

Based on Irene’s work with runners on a treadmill equipped with a force plate:

- Heel striking leads to a more rapid rate of vertical force development
- Forefoot striking in minimalist shoes decreases the rate of force development

## How shoe cushioning alters impact forces despite forefoot striking [49:00]

Forefoot striking in cushioned shoes has unwanted effects:

- It promotes landing with more plantar flexion (forefoot more pointed towards ground), which exposes the [Achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon) to greater stress
- It also promotes landing on the outside of the foot, which causes an increase in lateral forces. This tends to result in problems in both the Achilles and [peroneal](https://en.wikipedia.org/wiki/Peroneus_muscles) tendons

Considerations for shoe selection

- Forefoot striking should be done in minimalist shoes
- People who choose to remain heel strikers should wear cushioned shoes

## An overview of minimalist shoes [52:30]

> *“When I talk about minimal, I’m talking about a shoe you can roll up and put in your pocket.”*
>
> *—Irene Davis*

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-3-irenedavis-1024x681.png)

**Figure 3. Cushioned versus minimalist shoes.** Image credit: [vivobarefoot.com](https://www.vivobarefoot.com/uk/blog/july-2019/zero-drop-vs-zero-cushioning)

- Three brands of minimalist shoes that you can roll up and put in your pocket:
  - [Vivobarefoot](https://www.vivobarefoot.com/us)
  - [Xero](https://xeroshoes.com/)
  - [Inov-8](https://www.inov-8.com/us/)
- The [Vibram lawsuit](https://www.runnersworld.com/news/a20783252/vibram-settles-class-action-lawsuit/) turned people away from minimalist shoes, leading most companies to add more substance to their minimalist shoes
- There are now a number of “partial” minimalist shoes, as Irene calls them, which tend to have cushioning, a heel-to-toe drop, and sometimes arch support
  - Examples of shoes that fall into this category include [Nike Free](https://www.nike.com/free) and [New Balance Minimus](https://www.newbalance.com/minimus/)
  - A major problem with these shoes is that they still encourage people to heel strike, but with less cushion
  - In [one study](https://bjsm.bmj.com/content/48/16/1257.short), partial minimal shoes were associated with twice as much injuries as fully minimalist shoes
  - People who run in these shoes should learn to forefoot strike with a minimalist shoe, and if they do not want to, Irene suggests that they use fully cushioned shoes and replace them every 300-500 miles

## Irene’s protocol for transitioning people out of orthotics [58:45]

Irene’s neck brace example

- Wearing a neck brace for life will leave your neck muscles weak and unable to hold your head up
- Wearing orthotics will have as similar effect on the 10 muscles in the arch of your foot

A gradual approach, over the course of 2-3 weeks

- Irene has people initially keep their orthotics with them and gradually increase time without them – for example, the first half mile of a three-mile walk
- Once someone can regularly walk comfortably without orthotics, she has them transition to minimalist shoes
- A [study](https://insights.ovid.com/mespex/201901000/00005768-201901000-00014) led by [Sarah Ridge](https://lifesciences.byu.edu/directory/sarah-ridge) from BYU has shown simply walking in minimalist shoes to be as effective as a dedicated foot-strengthening program

## Transitioning to minimalist shoes and a forefoot strike [1:05:30]

- It’s a one to three month process, depending on age
- Focus spans to include foot, hip, and knee function
- Activities like hopping, lunging, and jumping rope are included to develop dynamic movement skill
- Only after basic movement function has been developed does treadmill training start
- Someone should be able to handle a 30-minute brisk walk with forefoot strike and minimalist shoes before starting on a treadmill. Otherwise, consequences include plantar fasciitis and metatarsal stress fracture

## Foot muscle volume, minimalist shoes, and orthotics [1:07:00]

- Irene’s team did a study ([Chen et al., 2016](https://www.sciencedirect.com/science/article/abs/pii/S0268003316300675)) showing that cross sectional volume of foot muscles is larger in people who run with minimalist shoes
- Another study has shown that people who start wearing orthotics experience a *decrease* in foot muscle volume

## The recognition of the importance of foot strength in podiatry [1:09:45]

- Recently published physical therapy guidelines for plantar fasciitis include orthotics and other approaches, but neglect to include strengthening
- In contrast, guidelines for any other part of the body do include strengthening
- Despite this, Irene’s experience is that podiatrists are becoming increasingly interested in using exercise and movement training instead of orthotics

## Minimalist shoes across the lifespan—from children to adults [1:12:30]

- Irene believes minimalist shoes are important for kids so that their feet develop properly
- Since we lose muscle power with age, and in the feet and lower extremities first, Irene also believes that transitioning to minimalist shoes is important for adults
- **Courses/programs related to training forefoot strike:** [Pose Method](https://posemethod.com/pose-method/) & [ChiRunning](https://www.chirunning.com/)

> *“It’s about getting people into shoes that let their feet do what they’re supposed to do.”*

## Why learning to forefoot strike on soft surfaces is not the best approach [1:20:00]

- Running barefoot has the benefit of maximizing sensory input from ground contact
- Running on grass barefoot is not a good idea because you may not see things that will injure your foot
- Soft surfaces in general will encourage more stiffness throughout the body
- In contrast, harder surfaces will encourage a softer landing

*Studies that have shown softer running surfaces to encourage greater leg stiffness while running***:**

- [Running in the real world: adjusting leg stiffness for different surfaces](https://royalsocietypublishing.org/doi/abs/10.1098/rspb.1998.0388)
- [Runners adjust leg stiffness for their first step on a new running surface](https://www.sciencedirect.com/science/article/abs/pii/S0021929099000780?via%3Dihub)

## Knee valgus and factors related to knee injury [1:21:45]

Injuries are multifactorial

- Poor movement pattern is not always the cause. While someone with poor movement will likely be injured more quickly, someone with good movement still has increased injury risk if their dose of movement is too high
- Poor movement can manifest as injury in different ways – for example, [knee valgus](https://posturedirect.com/how-to-fix-your-knee-valgus/) might cause knee pain, but it may instead cause hip pain

Causes of injury and knee valgus

- Irene’s running injury clinic has worked with more than 700 people
- The factors most often found in association with injury are high impact forces and poor alignment
- Knee valgus is the most common manifestation of poor alignment
- Instability of foot muscles, or the “foot core” as she calls it, is a cause of knee valgus

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-4-irene-davis-981x1024.png)

**Figure 4. Knee valgus and associated movements.** Image credit: [researchgate.net](https://www.researchgate.net/publication/319104024_Common_Running_Overuse_Injuries_and_Prevention)

## IT band syndrome [1:28:30]

- The [iliotibial band](https://en.wikipedia.org/wiki/Iliotibial_tract) (or IT band for short) connects the tensor fasciae latae to the lateral (outside) part of the [tibia](https://en.wikipedia.org/wiki/Tibia) at the knee
- Irene’s group has done both prospective and retrospective studies on people with history of IT band syndrome, and in both cases found greater inward angulation of the thigh, which stretches the IT band
- Inward rotation of the tibia was also found in these studies, which is associated with pronation (rolling in) of the foot, also stretches the IT band
- Based on the above mechanisms, IT band syndrome can originate from the hip or the foot
- Peter was able to eliminate his IT band pain through eccentric strengthening of his gluteus medius

## Physics and ground reaction forces [1:33:15]

- Ground reaction forces are an example of [Newton’s third law](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion) of physics (for every action, there is an equal and opposite reaction)
- For example, when you push against the ground, because of the massive size of earth, the ground will not move. The reaction is therefore translated into pushing yourself away from the ground rather than pushing the ground away.
- As these reaction forces are transferred through joints, the compress the joint in the process, which is how the force within the joint ends up being greater than the original amount of force being applied because of the internal moment arm in the joint and because of other stabilizing muscles contracting across the other side of the joint

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-5-irenedavis-1024x539.png)

**Figure 5. Ground reaction forces during different stages of gait.** Image credit: [mass4d.com](https://www.mass4d.com/blogs/clinicians-blog/the-effect-of-ground-reaction-forces-on-gait)

## Irene’s approach to retraining a runner’s gait [1:36:00]

> *“Mechanics is something that’s very modifiable, and for a long time people did not believe that.”*
>
> —Irene Davis

**Gait retraining in Irene’s clinic**

- Irene’s ideas of being able to retrain gait in runners was met with skepticism during the early years of her career
- It is now known that gait can be reprogrammed
- Gait retraining requires a lot of practice, however. It is not easy to retrain a movement pattern that has been engrained for decades
- Feedback is helpful, but must eventually be faded out
- In Irene’s lab, the process involves an average of two months spent working on gait, four weeks of gait training on the treadmill, and then 10 weeks of supervised incremental increases in running

The disconnect between prevention and health insurance

- The logical approach would be a proactive retraining of gait to prevent injury
- However, insurance only covers gait retraining after injury
- Because of this, 100% of the gait retraining Irene does is with people who have already been injured
- The example Peter gives to demonstrate the misguided approach taken by insurance companies here is that treating type 2 diabetes costs $7,000 to $12,000 per year compared to spending about $500 per year to prevent someone from ever getting the disease

**Evidence that gait retraining works over the long term**

One of Irene’s former postdocs did a [study](https://journals.sagepub.com/doi/abs/10.1177/0363546517736277) involving 320 novice runners:

- Half of the runners were trained on a treadmill to soften their impact (probably by inadvertently learning to forefoot strike)
- A year later, there was a 62% decrease in injuries

Similarly, a [retrospective study](https://insights.ovid.com/mespex/201207000/00005768-201207000-00017) by [Dan Lieberman](https://scholar.harvard.edu/dlieberman/home) on the Harvard track team found that forefoot strikers had half of the chronic injuries as heel strikers

## Case study—How the transition to minimalist shoes decreased injury and improved performance [1:42:15]

- A physician in a closed Christian community, inspired by the book Born to Run, resolved his own foot problems by running barefoot and in minimalist shoes
- He gradually started recommending it to members of the community’s track team who had season-ending injuries and weren’t responding to standard of care
- Eventually, 80% of the community was wearing minimalist shoes, and referrals to podiatrists decreased as use of minimalist shoes increased
- The community’s cross country team ended up completing a season with no injuries and winning their division. They were bumped up to the next division, where they also did well, possibly finishing as high as second

## Importance of proper movement patterns and the negative influence of our modern environment [1:45:30]

- Peter and Irene believe that frequent sitting and wearing of shoes present a major challenge for maintaining proper movement in today’s society
- Irene suggests that gym class in schools should be every day and should involve more demanding movement including calisthenics
- By the time kids are 12 to 17 years old, a [report from the National Adolescent and Young Adult Health Information Center](https://www.childtrends.org/wp-content/uploads/2013/10/2013-08ChronicConditions1.pdf) shows about 31% of them have at least one chronic condition
- Irene also believes that sport specificity presents similar problems and that kids should be encouraged to play multiple sports

§

## Selected Links / Related Material

**Irene’s running clinic:** [Spaulding National Running Center](https://spauldingrehab.org/research/programs-labs/spaulding-running-center) | (spauldingrehab.org) [0:50]

**The book Born to Run by Christopher McDougall:** [Born to Run: A Hidden Tribe, Superathletes, and the Greatest Race the World Has Never Seen](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307279189/ref=sr_1_1?dchild=1&keywords=born+to+run&qid=1597755442&sr=8-1) | (amazon.com) [8:15]

**Study showing that matching running shoes to foot type in military personnel had no influence on injury rate:** [Injury-reduction effectiveness of prescribing running shoes on the basis of foot arch height: Summary of military investigations](https://www.jospt.org/doi/full/10.2519/jospt.2014.5342) (Knapik et al., 2014) [9:50]

**2010 Nature paper on which Irene collaborated with Dan Lieberman**: [Foot strike patterns and collision forces in habitually barefoot versus shod runners](https://www.nature.com/articles/nature08723?ref=nf) (Lieberman et al., 2010) [10:15]

**The arches of the foot that run in the direction of heel to toe**: [Longitudinal arches of the foot](https://en.wikipedia.org/wiki/Arches_of_the_foot#Longitudinal_arches) | (wikipedia.org) [10:35]

**The tendon that attaches the calf muscles to the heel:** [Achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon) | (wikipedia.org) [10:35, 22:00, 33:40, 38:20, 49:00]

**Study by Dennis Bramble and Dan Lieberman describing human evolution in the context of endurance running:** [Endurance running and the evolution of Homo](https://www.nature.com/articles/nature03052) (Bramble & Lieberman, 2004) [11:35]

**Shoes that resemble the first shoes known to be used by man:** [Huarache sandals](https://en.wikipedia.org/wiki/Huarache_(shoe)) | (wikipedia.org) [17:55]

**The largest muscle of the calf:** [Gastrocnemius](https://en.wikipedia.org/wiki/Gastrocnemius_muscle) | (wikipedia.org) [22:30]

**An overuse injury that can be caused by running:** [Stress fracture](https://orthoinfo.aaos.org/en/diseases--conditions/stress-fractures) of the [tibia](https://en.wikipedia.org/wiki/Tibia) | (aaos.org, wikipedia.org) [26:50]

**A popular cushioned running shoe:** [HOKA](https://www.hokaoneone.com/) | (hokaoneone.com) [30:10, 47:10]

**Two studies showing higher impact forces with the HOKA shoe:** [30:10]

- [Running in highly cushioned shoes increases leg stiffness and amplifies impact loading](https://www.nature.com/articles/s41598-018-35980-6?ref=pharmater.com) (Kulmala et al., 2018)
- [Effect of shoe cushioning on landing impact forces and spatiotemporal parameters during running: results from a randomized trial including 800+ recreational runners](https://www.tandfonline.com/doi/abs/10.1080/17461391.2020.1809713) (Malisoux et al., 2020)

**Study showing that the pain threshold of the heel is nearly reached during barefoot walking:** [Force-deformation properties of the human heel pad during barefoot walking](https://journals.lww.com/acsm-msse/Fulltext/2014/08000/Force_Deformation_Properties_of_the_Human_Heel_Pad.14.aspx) (Wearing et al., 2014) [31:20]

**Two studies showing footwear to promote heel strike during running compared to barefoot runners:** [31:55]

- [Foot strike patterns and collision forces in habitually barefoot versus shod runners](https://www.nature.com/articles/nature08723?ref=nf) (Lieberman et al., 2010)
- [Variation in foot strike patterns among habitually barefoot and shod runners in Kenya](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0131354) (Lieberman et al., 2015)

**A robot that runs with forefoot strike:** [Atlas](https://en.wikipedia.org/wiki/Atlas_(robot)) | (wikipedia.org) [33:40]

**A common running injury in the front of the lower leg:** [Shin splints](https://en.wikipedia.org/wiki/Shin_splints) | (wikipedia.org) [33:40]

**The muscle in the front of the lower leg associated with shin splints:** [Tibialis anterior](https://en.wikipedia.org/wiki/Tibialis_anterior_muscle) | (wikipedia.org) [34:40]

**A meta-analysis and systematic review describing studies that have associated a greater rate of impact loading with running injuries:** [Do runners who suffer injuries have higher vertical ground reaction forces than those who remain injury-free? A systematic review and meta-analysis](https://bjsm.bmj.com/content/50/8/450.short) (van der Worp et al., 2016)  [38:00]

**A documentary on a high-school physical education program that started in the 1950s and provided students with a solid foundation of movement skill:** [The Motivation Factor](https://motivationmovie.com/) | (motivationmovie.com) [42:20]

**Movement of the forefoot about the heel and towards the ground:** [Plantar flexion](https://en.wikipedia.org/wiki/Anatomical_terms_of_motion) | (wikipedia.org) [49:00]

**Anatomical orientation:** [49:00]

- [Anterior and posterior](https://en.wikipedia.org/wiki/Anatomical_terms_of_location#Anterior_and_posterior) | (wikipedia.org)
- [Medial and lateral](https://en.wikipedia.org/wiki/Anatomical_terms_of_location#Medial_and_lateral) | (wikipedia.org)

**Tendons attaching the peroneus muscles in the lower leg to the foot:** [Peroneal muscles and tendons](https://en.wikipedia.org/wiki/Peroneus_muscles) | (wikipedia.org) [50:20]

**Three popular brands of minimalist shoes:** [Vivobarefoot](https://www.vivobarefoot.com/us), [Xero](https://xeroshoes.com/), and [Inov-8](https://www.inov-8.com/us/) | (vivobarefoot.com, xeroshoes.com, inov-8.com) [52:45]

**A lawsuit against a shoe company that decreased interest in minimalist shoes:** [Vibram lawsuit](https://www.runnersworld.com/news/a20783252/vibram-settles-class-action-lawsuit/) | (runnersworld.com) [54:10]

**Popular “partial” minimalist shoes:** [Nike Free](https://www.nike.com/free), [New Balance Minimus](https://www.newbalance.com/minimus/) | (nike.com, newbalance.com) [55:20]

**Study showing use of “partial” minimalist shoes to lead to twice as many injuries as minimalist shoes during a 12-week running program:** [Examining injury risk and pain perception in runners using minimalist footwear](https://bjsm.bmj.com/content/48/16/1257.short) (Ryan et al., 2014) [57:35]

**Structure of the foot:** [Muscles and bones of the medial and lateral longitudinal arches](https://teachmeanatomy.info/lower-limb/misc/foot-arches/) | (teachmeanatomy.info) [1:00:50]

**Study showing walking in minimalist shoes to be as effective for strengthening the foot as a dedicated strengthening program:** [Walking in minimalist shoes is effective for strengthening foot muscles](https://insights.ovid.com/mespex/201901000/00005768-201901000-00014) (Ridge et al., 2019) [1:02:55]

**Study by Irene’s group that found running in minimalist shoes to increase foot muscle volume:** [Effects of training in minimalist shoes on the intrinsic and extrinsic foot muscle volume](https://www.sciencedirect.com/science/article/abs/pii/S0268003316300675) (Chen et al., 2016) [1:08:25]

**Physical therapy clinical guidelines from the American Physical Therapy Association:** [APTA Clinical Practice Guideline Process Manual](https://www.apta.org/contentassets/ab3a561c2a5e4cb5928d2bd2da93ab7d/apta-cpg-manual.pdf) | (apta.org) [1:09:45]

**Courses/programs related to training forefoot strike:** [Pose Method](https://posemethod.com/pose-method/), [ChiRunning](https://www.chirunning.com/) | (posemethod.com, chirunning.com) [1:15:55]

**Studies that have shown softer running surfaces to encourage greater leg stiffness while running:** [1:20:50]

- [Running in the real world: adjusting leg stiffness for different surfaces](https://royalsocietypublishing.org/doi/abs/10.1098/rspb.1998.0388) (Ferris et al., 1998)
- [Runners adjust leg stiffness for their first step on a new running surface](https://www.sciencedirect.com/science/article/abs/pii/S0021929099000780?via%3Dihub) (Ferris et al., 1999)

**Inward alignment of the knees:** [Knee valgus](https://posturedirect.com/how-to-fix-your-knee-valgus/) | (posturedirect.com) [1:21:55]

**A tissue membrane in the abdominal region:** [Transversalis fascia](https://en.wikipedia.org/wiki/Transversalis_fascia) | (wikipedia.org) [1:26:45]

**Muscles of the hip involved in abduction and adduction:** [Hip abductors](https://en.wikipedia.org/wiki/Category:Hip_abductors), [Hip adductors](https://en.wikipedia.org/wiki/Adductor_muscles_of_the_hip) | (wikipedia.org) [1:27:00]

**The tendon that runs along the side of the thigh connecting the tensor fasciae latae muscle of the hip to the knee:** [The ilitibial (IT) band](https://en.wikipedia.org/wiki/Iliotibial_tract) | (wikipedia.org) [1:28:30]

**A hip muscle that helps with balance and is connected to the IT band:** [Tensor fasciae latae](https://en.wikipedia.org/wiki/Tensor_fasciae_latae_muscle) | (wikipedia.org) [1:28:30]

**Side to side rotational movements of the foot:** [Eversion/pronation and inversion/supination](https://en.wikipedia.org/wiki/File:Eversion_and_inversion.jpg) | (wikipedia.org) [1:31:10]

**A hip muscle that helps to stabilize the pelvis and maintain knee alignment:** [Gluteus medius](https://en.wikipedia.org/wiki/Gluteus_medius) | (wikipedia.org) [1:32:30]

**Basic physics, or forces acting on matter:** [Newtonian physics](https://en.wikipedia.org/wiki/Classical_mechanics) | (wikipedia.org) [1:33:20]

**Every action has an equal and opposite reaction:** [Newton’s third law of physics](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion) | (wikipedia.org) [1:34:00]

**A diagram used to depict application of forces:** [Free body diagram](https://en.wikipedia.org/wiki/Free_body_diagram) | (wikipedia.org) [1:35:20]

**The lever arm force is applied to during production of rotational force, or torque:** [Moment arm](https://en.wikipedia.org/wiki/Torque#Moment_arm_formula) | (wikipedia.org) [1:35:25]

**Study by one of Irene’s former postdocs showing that training of novice runners to lessen impact force resulted in a 62% decrease in injuries:** [Gait retraining for the reduction of injury occurrence in novice distance runners: 1-year follow-up of a randomized controlled trial](https://journals.sagepub.com/doi/abs/10.1177/0363546517736277) (Chan et al., 2017) [1:40:00]

**Study by Dan Lieberman’s group showing members of the Harvard cross-country team who were forefoot strikers had half the injuries compared to heel strikers:** [Foot strike and injury rates in endurance runners: A retrospective study](https://insights.ovid.com/mespex/201207000/00005768-201207000-00017) (Daoud et al., 2012) [1:41:30]

**A report from the National Adolescent and Young Adult Health Information Center indicating that 31% of adolescents between the ages of 12 and 17 have at least one chronic condition:** [Adolescent Health Highlight: Chronic Conditions](https://www.childtrends.org/wp-content/uploads/2013/10/2013-08ChronicConditions1.pdf) | (childtrends.org) [1:47:15]

§

## People Mentioned

- [Peter Cavanagh](https://orthop.washington.edu/faculty-profiles/peter-r-cavanagh-phd-dsc.html) [4:40]
- Joe Knapik [9:50]
- [Dan Lieberman](https://scholar.harvard.edu/dlieberman/home) [9:50, 10:35, 12:50, 13:40, 1:41:30]
- [Dennis Bramble](https://www.biology.utah.edu/people/details.php?id=42) [10:35]
- [Jeff Johnson](https://www.runnersworld.com/advanced/a20792873/employee-number-one/) [27:50]
- [Stan LeProtti](https://www.mentalfloss.com/article/62991/1960s-high-school-gym-class-would-ruin-you) [42:25]
- [Jeff Pisciotta](https://www.linkedin.com/in/jeff-pisciotta-3a045745/) [56:30]
- [Sarah Ridge](https://lifesciences.byu.edu/directory/sarah-ridge) [1:02:55]
- [Chris McDougall](https://en.wikipedia.org/wiki/Christopher_McDougall) [1:16:20]
- [Terry Laughlin](https://en.wikipedia.org/wiki/Terry_Laughlin) [1:18:35]
- [Danny Dreyer](https://www.chirunning.com/danny-dreyer/) [1:18:35]

§

![](https://peterattiamd.com/wp-content/uploads/2020/09/bio-image-irenedavis-500x500.jpeg)

##### Irene Davis, Ph.D.

Irene is a professor of physical medicine and rehabilitation at Harvard Medical School. She’s also the founding director of the Spaulding National Running Center—one of the premier centers in the United States devoted exclusively to the diagnosis, treatment and prevention of running injuries in runners of all ages and abilities. Irene holds two bachelor’s degrees, one in exercise science from the University of Massachusetts, and one in physical therapy from the University of Florida. She then went on to earn her master’s degree in biomechanics from the University of Virginia, before finally going on to get her PhD in biomechanics from Penn State.