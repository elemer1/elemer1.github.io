# #217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.

**Source:** [https://peterattiamd.com/mikejoyner/](https://peterattiamd.com/mikejoyner/)

---

Mike Joyner is a physician-researcher and one of the world’s leading experts on human performance and exercise physiology. In this episode, Mike discusses how to combat age-related declines in health and fitness levels by using various modes of exercise to improve lifespan and healthspan. Mike explains the impact of exercise on the autonomic nervous system, blood pressure, heart rate, heart rate variability, heart rate recovery, and max heart rate. He dives deep into VO2 max, including how it’s measured, what is driving it, and how to improve it. Mike provides training insights for the average person, including training volume and exercise intensity as well as simple metrics to track. Furthermore, he gives his take on the theoretical “J-curve” relationship between exercise and longevity, as well as whether possible health dangers may be associated with excessive exercise.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/mikejoyner/the_Drive_public.png)

Play

#217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.

1x15s30s

0:001:52:50

## We discuss:

- Mike’s training as an anesthesiologist and interest in exercise physiology [2:30];
- How exercise increases longevity [7:00];
- The impressive data on the benefits of exercise [9:45];
- The Centenarian Decathlon and other ways to mitigate age-related decline in strength and stability [15:00];
- The violent dropoff in strength and activity with age and how exercise preserves fitness in old age [19:00];
- Benefits of exercise on mortality and fracture risk, and the interplay of nutrition and exercise [22:00];
- How exercise benefits the autonomic nervous system and why this plays an important role in our health [26:30];
- VO2 max, heart rate recovery, heart rate variability, and other metrics of fitness positively impacted by exercise [28:30];
- Reduction in all-cause mortality with increased fitness levels and VO2 max [32:45];
- Does the relationship between exercise and longevity follow a J-curve? [40:00];
- Mitigating age-related decline in fitness by elevating your VO2 max at a young age [46:15];
- Breaking down the variables that drive VO2 max [54:30];
- Learning from elite athletes: Training regimens, aerobic efficiency, and other impressive metrics [1:00:15];
- Health benefits of light exercise for the average person [1:09:00];
- Simple training metrics to track, and Mike’s current exercise regimen [1:11:15];
- How to boost your VO2 max, and the importance of form and tempo with interval training [1:18:15];
- Training advice for the average person [1:25:15];
- Why professional athletes have longer careers than they’ve had in the past [1:27:30];
- Use of performance-enhancing drugs in professional sports [1:29:45];
- Can the miracle of exercise be put in a pill? [1:36:00];
- Mike’s current research and questions he’s most interested in answering [1:39:00];
- Use of convalescent plasma to treat COVID-19 [1:41:15];
- Parting thoughts on the current state of fitness and exercise in society [1:47:15];
- More.

§

## Show Notes

**\*Notes from intro**:

- Our guest this week is Mike Joyner
- Peter has wanted to have him on the podcast for some time as he has been reading his research for over 20 years
- Mike is a physician/ researcher
- He is a Professor and Vice Chair for Research in the Department of Anesthesiology and Perioperative Medicine at the Mayo Clinic
- He’s co-authored over 250 journal articles and he’s written numerous pieces in magazines such as *Sports Illustrated*
- He has his own website, [Human Limits](https://www.drmichaeljoyner.com/), that speaks to Mike’s interest in the physiology around human limits
- His research background is in how the nervous system regulates the vascular system and blood flow
  - How physiology is affected by: age, sex, and disease states
  - Understanding the limits of human physiology by studying elite athletes
- This episode focuses on exercise
  - How exercise helps us live longer
  - The importance of exercise as we age
  - How exercise compares to nutrition in terms of the impact it can have on health
  - We discuss its impact on the autonomic nervous system, blood pressure, heart rate, heart rate variability, heart rate recovery, and max heart rate
  - We discuss VO2 max, how it’s measured, what leads to the decline in VO2 max as we age
  - We discuss if the J curve applies to exercise and potential dangers of over-exercising
  - We talk about how one should partition their time training at high intensity and low intensity
- We also discuss performance-enhancing drugs in sports
- And if there’s ever going to be a drug that mimics the benefits of exercise

## Mike’s training as an anesthesiologist and interest in exercise physiology [2:30]

- Peter has been following Mike’s work for 25-30 years
- Growing up, endurance sports meant a lot to Peter, and has motivated him to understand the physiology better
- Before Mike went to medical school, he volunteered to be a subject in a study on lactate threshold or anaerobic threshold
  - He was 19 years old
  - This study was at the University of Arizona
- He realized then, if he wanted a career as a research physiologist, doing invasive studies, putting catheters in people, he should go to medical school
- Originally, Mike was thinking of going into cardiology or pulmonary medicine
- When he was working at the VA in Tucson on a surgery rotation and saw what was done for anesthesia, it clicked‒ this was what he wanted to do
  - It was a lot like an exercise test
  - You measure people’s breathing, blood pressure, heart rate
  - You give them drugs that affect their autonomic nervous system
  - He has pursued this vision for over 40 years now
- Peter remembers loving his anesthesia rotation, “*As a physiology geek, anesthesia and critical care for that matter, are both two remarkable specialties that are the tip of the spear of what physiology is*”
- When you think about exercise or people climbing mountains or adapting to some unusual environment, the brain stem has to do all sorts of incredible things to maintain homeostasis (or the internal environment) in a way that allows you to survive and thrive
- Mike realized, “*In anesthesia in critical care you turn those mechanisms off, and the physicians and the nurses really become the patient’s brain stem as they regulate the breathing of the patient, the blood pressure of the patient, the heart rate, and so forth*”

**What drew Mike to the Mayo Clinic?**

- He got out of medical school in the early summer of ‘87 and moved to Rochester, Minnesota  for his internship and residency at the Mayo Clinic
- He has been there ever since, for 35 years
- He grew up in Tucson, AZ
- Mike read a review article about skeletal muscle blood flow, the regulation of skeletal muscle blood flow
  - There were a lot of new ideas in the mid-80s about the regulation of skeletal muscle blood flow.
  - The world’s leading expert was a man named [John Shepherd](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3286675/)
    - Who is a very senior member of the faculty at the Mayo Clinic
    - Mike wrote him a letter, it was before email and stuff
    - John was friends with the head of the department of anesthesiology ([Alan Sessler](https://alumniassociation.mayo.edu/obituaries/alan-sessler-m-d-anes-62/)); he took the letter to him
- Mike wanted to both do his residency and spend time in the lab
- He worked with Dr. Shepard
- The department and residency program were very research friendly and that’s why he decided to go to Rochester, MN
  - He thought he would only stay for 3-4 years

## How exercise increases longevity [7:00]

**Exercise for longevity**

Peter thinks about longevity through the lens of 5 modifiable behaviors:

- i) exercise,
- ii) sleep,
- iii) nutrition,
- iv) emotional health, and all the tools around distressed tolerance, and then
- v) exogenous molecules
  - These can be manipulated to impact both your lifespan and healthspan
  - 4 are behavioral (Medications aren’t behavioral in the sense that compliance is relatively straightforward)
- **Exercise** is in a league of its own both on
  - It’s ability to extend life and reduce all-cause mortality is well documented
    - This is why Peter’s practice spends a lot of time focusing on exercise; it has the most impact
  - It’s also one of the most challenging things to get people to change their behavior around because of the significant time commitment

*If you were at a party and somebody asked, “Mike, can you explain why exercise helps you live longer?”*

- The answer is multifactorial
- 1 – The risk factors that contribute to cardiovascular disease and all-cause mortality are all influenced by exercise and physical activity
  - These would be blood pressure, diabetes, to some extent lipids and cholesterol, and also how you deal with stress
  - These are the the big 3
- There are some other new age or second wave risk factors like [endothelial](https://en.wikipedia.org/wiki/Endothelium) function
  - The lining of the blood vessels in your body that improve with exercise
- Your [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system) is influenced positively by exercise
  - People may have heard of [vagal tone](https://en.wikipedia.org/wiki/Vagal_tone) or [heart rate variability (HRV)](https://en.wikipedia.org/wiki/Heart_rate_variability); they are influenced positively by exercise

![](https://peterattiamd.com/wp-content/uploads/2022/07/f1-mikejoyner.png)

**Figure 1.  Anti-aging effects of exercise and cellular hallmarks of aging**.  Image credit: [*Rejuvenation Research* 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4340807/)

- There are 5-6 things and when you add each one, the modest increase in cholesterol [HDL], modest reduction in blood pressure, those sorts of things, when you add them up, you get X percent improvement in health span, life expectancy (or any metric you want to use)
- But when you look at the epidemiology, people who do the sorts of things you just mentioned, have a much bigger benefit than just the simple sum of the other risk factors
  - There seem to be some sort of synergy here or some sort of X factor that we don’t really understand yet

**⇒** ***Exercise improves a collection of 5 lifestyle related factors: the autonomic nervous system, blood pressure, lipids, the lining of the blood vessels, and diabetes***

## The impressive data on the benefits of exercise [9:45]

**Hazard ratios and natural experiments reported in the literature**

- Peter asks about the literature, “*The epidemiology is so overwhelming, the hazard ratios are sort of absurd. When we are used to looking at a field like nutrition and looking at the hazard ratios in nutrition, they’re very small. In fact, they’re so small and also so inconsistent that it becomes almost impossible to assign a mortality benefit (or addition) to almost anything you can eat*.”
- Mike is working on a review article and one of the interesting things he’s looking at is a “natural experiment” where you have 2 groups of people that are otherwise similar, exposed to different things
- Natural experiments are a long used tool in epidemiology
  - Economists and behavioral scientists are now using these natural experiments
- A classic natural experiment‒ the London bus conductor story led by [Jeremy Morris](https://en.wikipedia.org/wiki/Jerry_Morris) after World War II
  - They [showed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4933124/) the **physically active** conductors who were walking up and down the buses all day, **had much lower rates of cardiovascular disease (by about 50%)** than the sedentary bus drivers
- They had similar findings with telephone operators versus people who were out walking around doing things
- “*You look at that 50% [reduction in CVD], it’s incredibly consistent*” says Mike
- Studies of longshoreman, studies of Harvard alumni, there’s one in the last 10 or 15 years of 50,000 male and 25,000 female finishers of the Vasaloppet 90 kilometer cross-country ski race in Sweden where they compared them to matched controls from the Swedish record system; they showed again about a 50% reduction in cardiovascular and all-cause mortality
- There’s data from the National Cancer Institute showing the same sorts of things and showing **4-6 year increase in life expectancy among the people who got a substantial amount of physical activity** or structured exercise (either one)

**Peter’s takeaway: Natural experiments in exercise are much better in exercise than in nutrition.  Unlike nutritional epidemiology where the risk increases and risk reductions are very, very small and inconsistent, the benefits of exercise are large and consistent**.

*What are the confounders?*

- The famous natural experiment of the guys running up and down the busses, bus conductors versus drivers is a great example because it’s not amenable to a choice
- Some behaviors are easy to measure and correct for but many are not
  - Smoking is easy
  - Nutrition is harder
  - Exercise is profound

**Exercise: What a hazard ratio of 0.5 (a 50% reduction in all-cause mortality) really means**

*What’s the timeframe that’s usually looking at?  How does that translate to a five year increase in life expectancy?*”

- The relative risk of dying of heart disease in any given period of time, whether it’s a year, 5 years, 10 years, or whatever the study’s doing, is 50% lower
- But not everybody dies of cardiovascular disease (CVD)
- So you have to translate this into the years of life gained
  - Typically somewhere on the order of **3-5 years of life are gained by exercise,**
  - and **6-8 years of improved healthspan**
  - This takes smoking into account

> “*The idea is to live a long time and then die quickly with minimal disability*”‒ Mike Joyner

- Peter has always found the current medical definition of health span to not be helpful
  - The bar is pretty low, freedom from disease and disability

## The Centenarian Decathlon and other ways to mitigate age-related decline in strength and stability [15:00]

Peter prefers to use a model he calls the [**centenarian decathlon**](https://peterattiamd.com/how-to-train-for-the-centenarian-olympics/)**‒ if you go out to the last decade of your life, what are the athletic events and activities of daily living you want to be able to do?**

- Peter asks patients to cross off things they do not want to do; so they have to **opt-out** of things
  - The list is very specific
  - Walking 3 miles in 1 hour
  - Climbing 60 8-inch stairs in 1 minute
  - Carrying 20 lbs of groceries a certain distance
  - Being able to get up off the floor with just 1 hand of support
  - *This is what healthspan comes down to, not just disability but thriving*
- The initial reaction of most people is these are very easy things to do
  - Easy for a 45 year old
  - Most don’t appreciate the precipitous decline that will occur without deliberate training

**Peter’s takeaway:** *It’s for that reason that I think exercise has more potential to offset all of those things than anything else, sleep, nutrition, certainly any medication*

> “*I think, Peter, you’ve hit the nail on the head*”‒ Mike Joyner

**The decline of physical ability with age and how exercise can mitigate this**

- Mike adds, “*If you look at the decline in performance in age group, swimming, running, cycling, rowing, any sport where there’s pretty good record keeping*‒ *people can start to decline at age 30 without training. You can push that back to age 40 with training*.”
  - Training means you work out every day and relatively hard
- Something happens to people in their middle 70s, there seems to be a steeper decline
  - This seems to shift from a *cardiopulmonary limitation to a problem with skeletal muscle strength and frailty*
- 70% of 70-year olds can’t get off the floor period, not with 1 hand or 2 hands

>  “*If you look at what happens when a person in that age group falls, it’s just no fun*”‒ Mike Joyner

- What really takes people out are things like falls and the inability to do things
- Walking 3 miles in an hour takes some cardiopulmonary capacity, not a ton but some
  - Being able to go up the stairs or get off the floor takes more

**As people get into their 40s and 50s, they need to think about adding strength training or some sort of circuit training and agility training to their program**

- Mike is 63 (almost 64), one thing he does is jump rope
  - He carries it with him when he travels, because you can always jump rope even if it’s out in the parking lot of a hotel
  - *People think you’re nuts, but it’s terrific exercise*
  - Peter adds that jumping rope is great for a number of reasons
    - Foot reactivity, the lack of this can contribute to a fall
    - Cardio benefit
    - Coordination benefit
    - You don’t really pound your knees
- Another good thing you can do with your body weight is push ups, planks, and pull-ups

## The violent dropoff in strength and activity with age and how exercise preserves fitness in old age [19:00]

- Peter says, “*There’s an amazing study that demonstrates muscle mass changes, strength changes, and activity changes in men and women as they age. And it’s one of those things where you don’t actually need to understand the statistics to be able to see the figure. And it’s exactly as you describe it.*”
  - At the age of 75, the cliff is so violent you “*can’t believe what you’re watching*”
    - There are huge declines in physical activity, muscle mass, and strength
    - The figure below shows decline in muscle mass with age as well as declines in appendicular skeletal muscles (ASM) adjusted for height, weight, and BMI
    - The second figure below shows decline in grip strength as a metric for muscle strength

![](https://peterattiamd.com/wp-content/uploads/2022/07/f2-mikejoyner.png)

**Figure 2.  Decline in muscle and appendicular skeletal muscle (ASM) with age.**  Image credit: [*KIM* 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4939509/)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f3-mikejoyner.png)

**Figure 3.  Decline in grip strength with age.**  Image credit: [*Journal of Gerontology* 1990](https://pubmed.ncbi.nlm.nih.gov/2335723/)

- This begs the question, “*Is the patient losing strength because they are no longer active, or are they no longer active because they have lost strength?*”
  - Peter think’s it’s both, these 2 things feed off each other
  - He suspects the loss of strength occurs first and contributes to the loss of activity
- Mike agrees, “*You really hit into a death spiral. That’s why it becomes important to keep exercising relatively hard as you get older, at least a few days a week, to slow this decline*.”

**Examples where exercise preserves fitness in old age**

- [Studies](https://pubmed.ncbi.nlm.nih.gov/21477204/) of some Swedish cross-country skiers, men who were world and Olympic champions in the 40s and 50s
  - They remained very active and were studied in their 80s, and their fitness levels were similar to what you would see in people in very early middle age
  - You could argue there is something special about these guys to begin with for them to become champion athletes
- Classic studies from the 60s of fighter pilots sent into outer space
  - These guys were incredibly fit
  - They would go into outer space for a week and come back with terrible muscle atrophy
    - They couldn’t stand up
- In ‘66 NASA commissioned folks at the University of Texas, Southwestern Medical Center in Dallas to put 5 college-age males, 2 athletes at bedrest
  - They had tremendous reductions in their fitness over just 3 weeks of bedrest
    - Published in *Circulation* in 1968, [Response to exercise after bed rest and after training](https://pubmed.ncbi.nlm.nih.gov/5696236/)
  - Interestingly, [Ben Levine](https://profiles.utsouthwestern.edu/profile/14262/benjamin-levine.html) and his group in Dallas (along with the late [Jerry Mitchell](https://www.utsouthwestern.edu/newsroom/articles/year-2021/in-memoriam-mitchell.html)), brought these same men back 30 years later
    - Published in *Circulation* in 2001, [A 30-year follow-up of the Dallas Bedrest and Training Study: I. Effect of age on the cardiovascular response to exercise](https://pubmed.ncbi.nlm.nih.gov/11560849/)
    - These men were now in their early 50s

***Incredibly, 3 weeks of bedrest caused losses of physiological function associated with 30 years of aging***

- This small study was so instructive
- This is why it’s  so important to avoid inactive of any type
- Even low grade physical activity, such a walking a dog, gardening, taking a flight of stairs once in a while or intentionally working out is really the way to go

> “*Those lifestyle factors you mentioned… overwhelms almost everything else*”‒ Mike Joyner

## Benefits of exercise on mortality and fracture risk, and the interplay of nutrition and exercise [22:00]

**The danger of falls later in life**

- Peter’s group has been doing a lot of research internally on bone mineral density in the aging population
- The mortality of 65-year olds (and older) who suffer a fall that results in the fracture of any part of the hip or femur at 1 year can be as low as 25% or as high as 60%
  - Mike adds, “*The magic number is usually around 40, 50 [%]*”

***So you take all the 60-year olds who have a fall that breaks a hip or femur and ask, “How many of them will be alive in 12 months? The answer is half of them.”***

- The other half who live longer than a year after a fall are not back to themselves necessarily

**Studies of people who lived a long life reveal the benefits of exercise**

- [Lester Breslow](https://en.wikipedia.org/wiki/Lester_Breslow), a very famous epidemiologist, who died in his 90s, was at UCLA for many years
  - He studied people in Oakland in the late 50s to early 60s who made it to age 90
  - And the 4-5 things you talked about, he identified the people in Oakland who made it to 90
    - They were non-smokers
    - They weren’t obese
    - They remained physically active
    - They ate modestly
    - They stayed engaged in life
- The same is true in the Honolulu heart project when they [looked at](https://pubmed.ncbi.nlm.nih.gov/7091147/) a huge number of Japanese American males
  - They weren’t as focused on the small molecules, but exactly what Peter described

**Studies evaluating impact of exercise and diet on mortality**

- Mike also thinks about the [natural experiments at the Cooper Clinic](https://www.cooperinstitute.org/published-research)
  - They looked at people’s fitness levels
  - That’s not exactly the same as physical activity
  - In general, the fittest people are also the most active
  - They divided people into 3-4 groups of fitness and had them look at a healthy eating index

**⇒** *The healthy eating index in people that weren’t particularly fit did have something to do with all-cause mortality; but among the fittest people, there was very little impact of diet on the outcomes*

- A famous quote in a book about distance running called [*Once A Runner*](https://www.amazon.com/Once-Runner-John-Parker-Jr/dp/1416597883/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1654614716&sr=8-1), where somebody said, “If the furnace is hot enough, you can burn anything, even Big Macs.”
  - Now you have to take that with a grain of salt

***The take home message is about what a powerful thing exercise is***

- Peter adds, “*There’s a very common mantra that says, oh, you can’t outrun a bad diet. And I would argue, that’s probably not true. I think you can outrun a bad diet, but it’s pretty hard to do. And most people don’t understand the amount of running that’s needed to do it.*”
- There’s an incredible [study](https://academic.oup.com/ajcn/article-abstract/4/2/169/4787034) from the 50s about people who worked at a jute plant in India
  - They categorized people based on activity
    - Incredibly physically active would be those doing manual labor, hacking away on jute to make rope
    - Low activity would be office workers
  - They found as people became more and more physically active, they got lighter
    - And as people became more inactive, they got heavier
  - Interestingly, people that were in the middle rung of occupational physical activity had slightly lower caloric consumption and remained very trim
- If you read the old papers about what lumberjacks ate when they were chopping wood all day, it’s 5-6,000 calories a day
  - The old order Amish who do manual labor all day long (without tractors, etc.) they eat a lot, but very few of them are obese

***In a modern high calorie, low physical activity world, you can’t exercise your way out of a bad diet***

- If you look at athletes doing insane amounts of exercise, most of them have a hard time keeping weight on
- There’s a terrific [study](https://pubmed.ncbi.nlm.nih.gov/2744926/) about the Tour de France
  - These people are eating *ad lib*, except when they’re on the bike
  - They’re eating 6,000 calories a day and weigh about 150 lbs
  - They have a hard time keeping their weight
  - These cyclists finish in pretty bad shape

## How exercise benefits the autonomic nervous system and why this plays an important role in our health [26:30]

**How is the autonomic nervous system different from the sympathetic nervous system?  Why does this play an important role in our health?  How does exercise impact it?**

- When we think about the nervous system, normally we think about our brain, our eyes, our ears, and our senses, and also our ability to grab things, move our muscles, that sort of thing, feel pain, or feel heat or cold or sense the environment
- But your autonomic nervous system is what controls your internal environment
  - It maintains homeostasis
- So, we can increase our metabolism 10 or 20 fold with exercise, but our body temperature only rises a degree or 2
  - This happens due to the actions of the autonomic nervous system
- There are 2 branches of the [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system)
- 1 – The [sympathetic nerves](https://en.wikipedia.org/wiki/Sympathetic_nervous_system)
  - This used to be kind of categorized as fight or flight
  - You would either activate the sympathetic nerves if you needed to fight or fly/ run away.
- 2 – The [parasympathetic nerves](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system)
  - These were seen as what happened when you were asleep, when you’re digesting your food, so on and so forth
  - The most notable parasympathetic nerve is the [vagus](https://en.wikipedia.org/wiki/Vagus_nerve), it controls part of your heart rate
- But it turns out there’s kind of more of a balance in the ying and a yang between these 2 that happen all the time
- The parasympathetic nerves (the vagus nerve) controls your heart rate and makes it slower
- On the one side are nerves that can make your heart rate slower
  - They tend to lower blood pressure, and are critical for digesting food
- On the other side are nerves that increase your heart rate
  - They stimulate your blood vessels to constrict, help your muscles contract harder, and also do things like make you sweat
- By having your autonomic nervous system tuned-up a bit better, it can do a better job regulating your internal environment
  - The classic example being your blood pressure

***The key thing to remember, is that the autonomic nervous system helps you regulate the internal environment and that exercise really keeps these things tuned-up***

## VO2 max, heart rate recovery, heart rate variability, and other metrics of fitness positively impacted by exercise [28:30]

**VO****2** **max testing**

- When Peter tests his patients, he measures their blood pressure throughout
  - He looks to see where their blood pressure is during maximum exertion, percentile wise
  - Without exception, a person’s blood pressure goes up during a VO2 max test
    - For example, take somebody who’s blood pressure is 115 over 75 at the outset, they’ll easily be 160 over 95, or 100; and that’s completely normal and healthy at a max
    - Mike notes it would be higher when they’re weight lifting

**Why is it that during exercise, nothing looks good?**

- During exercise blood pressure is high, heart rate is high, heart rate variability (HRV) is low

*What is it about the recovery phase from exercise that produces a net positive effect, even though in the moment, exercise presumably is doing things that are not in our body’s best interest?*

- Mike would say exercise is in their best interest because what happens is the system shifts a little bit to meet the demands of the skeletal muscle
- You’ve got to be able to contract the muscles to exercise
  - This is consistent with the fight or flight thing
  - And so to do that, you need to send more blood flow to those muscles, and one of the ways you do that is by increasing your blood pressure (more blood pressure equals more flow)
- And the other thing you’ve got to do is increase the pumping function of your heart
  - At rest, a person’s heart is beating about 5 liters or a little over a gallon a minute
    - During moderate exercise, it can be 10 liters a minute
    - During heavy exercise, 15 or 20
    - And in elite athletes who are very trained and have very large hearts, it can be 30 or 40 liters a minute
- When you’re pumping all that blood out the blood pressure rises
  - It’s a completely normal thing to generate that large cardiac output
  - Cardiac output is heart rate times stroke volume, that’s the amount with each squeeze of the heart

***Naturally, you’re going to increase your heart rate during exercise, but then when you stop, your heart rate falls, blood pressure falls, and things look probably better than they did in somebody who is untrained and hasn’t exercised***

**What do we know about the rate of recovery, the** [**heart rate recovery (HRR)**](https://en.wikipedia.org/wiki/Heart_rate#Heart_rate_recovery)**?**

- During a maximum exercise test, a person’s heart rate is 150, 160, 180
  - Whatever their age is, and 220 minus your age is an interesting number
  - But there’s a lot of person to person variability
- What happens is how fast does your heart rate go back down to some number?
  - How fast till it goes back to baseline?
- The **faster it goes down, the better the action of your vagal nerve**
  - The vagus nerve slows down your heart rate and is also responsible mostly for your heart rate variability
  - And this nerve also suppresses funny heartbeats and is protective when it’s in good shape against arrhythmias and ventricular tachycardia, ventricular fibrillation, sudden death, all of those things

***Heart rate recovery, heart rate variability, all of those things are indirect markers of what we call vagal tone or vagal activity, and that’s a good thing***

[**Heart rate variability (HRV)**](https://en.wikipedia.org/wiki/Heart_rate_variability) **can be genetic**

- The absolute number in milliseconds between any two individuals can be quite distinct
- HRV is not nearly as modifiable as some other factors, but this depends on what sort of training people have been doing
- In general, with training most people can get a nice training bradycardia (which is vagal tone)
  - They can also go from slow heart rate recovery to faster heart rate recovery
  - They can also have more heart rate variability

***While worrying about the differences in the initial baseline is interesting and what the genetic contributions are, this is probably less important than the fact that they are modifiable***

## Reduction in all-cause mortality with increased fitness levels and VO2 max [32:45]

**How predictive is VO****2** **max of an individual’s mortality?**

- VO2 max is measured by hooking a person up to EKG electrodes and have the ride a bike or run on a treadmill
  - They would use a nose clip/ face mask/ mouthpiece to measure how much they breathe in and out
    - We know that air has 21% oxygen coming in
    - If we measure the amount of oxygen in the expired air, we can make an estimate of how much oxygen has been consumed
- What happens is when people start to exercise, they go from using about 3.5 mL per kg per minute, or maybe 250 mL or 300 mL (so 10 or 12 ounces of oxygen per minute)
- An unfit person in their 30s or 40s can typically increase that about 8 or 10 fold to say, 30 or 35 or about 3 liters a minute

> “*With training, most people can increase things at least 10-20%*”‒ Mike Joyner

- If you have some ability or train very hard, some people can almost double it

- What happens is once your VO2 max goes up, just like physical activity, it’s a measure of physical fitness; and it’s also linked to all-cause mortality
  - The fitter you are, the lower your chance of dying in the next year or 2 years, 5 years, 10 years

**METs (metabolic equivalent of task)**

- The [MET](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task) is a measure of the ratio of expended energy relative to a person’s mass
  - It allows comparison of different physical activities
- For many years, they thought that benefit from exercise plateaued at what they call about 10 or 12 METs
  - You had to be able to get 10 Mets
  - 10 METs is being able to run 1 mile in about 10 minutes, roughly, for the average person
- Henry Ford in Detroit has shown that benefits from exercise continues to rise even up to 15, 16 METs

***People that are quite fit continue to gain benefit in terms of all cause mortality***

- For cross country skiers, the people who had completed the most races and done the races the fastest had lower all cause mortality
  - They didn’t do VO2 max testing in those people
- People who had both been active for the longest period of time and probably were the fittest, also had lower all cause mortality
  - This is not compared to sedentary peers, but compared to people who’d done a few races a little bit slower

> “*Peak fitness matters”*‒ Mike Joyner

**Fitness reduces all-cause mortality and CVD**

- Peter recalls a [paper in *JAMA*](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) that is by far the most compelling description of this phenomenon
  - The figure below shows hazard ratios (HRs) for all-cause mortality of varying fitness compared to low performers

***All-cause mortality was inversely proportional to cardiorespiratory fitness***

- He would consider it one of the 10 most influential papers he’s read in terms of changing how he thinks about healthspan and lifespan
- *There are very few things in physiology where more is better*
  - Usually physiology behaves in J curves, plateaus, sigmoid curves, and things like that
- In this study people are grouped by fitness (see the figure below)
  - Bottom 25th %
  - 25-50%
  - 50-75%
  - 75-97.5%
  - The elite fitness group was the top 2.5%

![](https://peterattiamd.com/wp-content/uploads/2022/07/f4-mikejoyner.png)

**Figure 4.  Hazard ratios (HRs) for all-cause mortality compared with low performers.**  Image credit: [*JAMA Network Open* 2018](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428)

- With increased fitness, all-cause mortality just went lower and lower
- If you look at the hazard ratio the other way
  - We often think about hazard ratios in risk reduction, but if you think about the risk increase
  - Compare people in the top 2.5% VO2 max to the bottom 25%, the hazard ratio moving in that direction is 5.04
    - See group comparison in the table above for Low vs. Elite

***This means there is a 5 fold increase in all-cause mortality between the fittest 2.5% and the least fit 25%***

- Even when you look at something less extreme, compare the least fit 25% to the 3rd quartile (Low vs Above average), the hazard ratio is 2.75
  - This is right on par with the increase in mortality you would see from having end stage renal disease
  - This is greater than the hazard ratio associated with smoking

> “*Being unfit is an incredible risk factor*”‒ Mike Joyner

- People like [Frank Booth](https://biomed.missouri.edu/frank-w-booth-phd/) have argued that it should be “the risk factor”
- [Jill Barnes](https://www.adrc.wisc.edu/jill-barnes-phd-0) and Mike wrote an [editorial](https://www.mayoclinicproceedings.org/article/S0025-6196(13)00922-1/fulltext) for the Mayo Clinic Proceedings 5-10 years ago where they said if people have 12-14 MET peak exercise capacity (with the exception of cancer screening), you could probably ignore everything else
  - If you screen people for physical fitness and just did routine cancer screening, you could probably cut back on the routine cancer screening for most things [in fit individuals]
    - Except for skin cancer because fit people tend to be outside a bit more
    - The data is there to support this
- Peter would still do the cancer screening and consider aggressive lipid management and things, but agrees with Mike

> “*There’s really no intervention… that’s going to rival it [exercise]*”‒ Peter Attia

**The benefits of exercise in reducing cardiovascular disease**

- For people who pick up exercise late in life, remember that exercise is not a vaccine
- One of the most incredible studies ever done, a natural experiment
  - A man named [Clarence DeMar](https://en.wikipedia.org/wiki/Clarence_DeMar) won the Boston Marathon 7 times
  - He was born in 1888
  - He also won a medal in the ‘24 Olympics, a bronze medal in the marathon
  - He really was almost master athlete number one
  - He kept training his whole life, he was still running late in life
  - He ended up dying of stomach cancer at about age 70
  - [Paul Dudley White](https://en.wikipedia.org/wiki/Paul_Dudley_White), a famous cardiologist (we know him from something called the [Wolff-Parkinson-White Syndrome](https://en.wikipedia.org/wiki/Wolff%E2%80%93Parkinson%E2%80%93White_syndrome)) did an autopsy on DeMar
    - He saw some plaque or fatty buildup and calcium buildup in his coronary arteries, but his coronary arteries were huge, just massive
- After this, man named [Bill Haskell](https://med.stanford.edu/profiles/william-haskell#bio) at Stanford in the middle ‘90s [studied](https://www.ahajournals.org/doi/epdf/10.1161/01.CIR.87.4.1076) a bunch of people who had done ultra-marathons and they did the same thing
  - Except this time they put catheters in and injected drugs to make the blood vessels expand and they showed the blood vessels were bigger and they expanded more
- While you could still have some blockages even if you exercise, and there are people with horrible lipids who do in fact get heart disease in spite of exercise

***Exercise is not a complete vaccine, but the overall protective effect is quite large, both in terms of what it does to people’s lipids, and the fact that the blood vessels get so much bigger, and the linings of the blood vessels are healthier***

## Does the relationship between exercise and longevity follow a J-curve? [40:00]

**The literature argues there is a J curve**

- The person who doesn’t exercise has the highest risk of mortality
- Let’s look at the addition of work (exercise) in [MET (metabolic equivalent of task) hours per week](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task)
  - This is a weird metric; Peter had to use a spreadsheet to convert his training into MET hour per week so he can interpret what he does in the context of all the literature

*What is a MET?*

- 1 MET is the metabolic expenditure of sitting at rest, which corresponds to about 3.5 mL per min per kg of VO2 (oxygen ventilation)
- This ramps up as you work, summarized in the table below
  - Walking 3 miles in an hour is 4-6 METs
  - Jogging 1 mile in 10 minutes is 10 METs

![](https://peterattiamd.com/wp-content/uploads/2022/07/f5-mikejoyner.png)

**Figure 5.  MET values for different physical activities**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task)

- Let’s say you ran 6 miles in 1 hour for an energy expenditure of 10 MET-hours
  - You did 10 METs times 1 hour
  - If you did that 4x a week, this would be 40 MET hours per week of activity
- Peter is in the hundred MET-hours per week, adding up his time on the bike at so many watts, time in the weight room, time carrying his rucksack

*The literature would say Peter’s mortality risk might be higher than someone doing 40 MET hours per week*

- This suggests a J curve
  - Consider the x-axis in the graph below MET-hours per week beginning at zero and the y-axis is increasing risk of mortality
  - As a person begins to exercise their risk of mortality goes down
  - But at a certain point, more MET hours (50-75 MET hours per week depending on the study) is associated with a higher mortality risk
  - Peter’s not going to go into detail about these studies other than to say, “*We find significant fault in each of them. What do you see?*”

![](https://peterattiamd.com/wp-content/uploads/2022/07/f6-mikejoyner.png)

**Figure 6.  Hypothetical relationship between exercise and mortality risk.**  Image credit: adapted from [Wikipedia](https://en.wikipedia.org/wiki/J_curve)

- Mike notes that not all studies show an increase in mortality at higher MET hours per week
- The big [NCI study](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1001335) of 650,000 subjects doesn’t support a J curve, see the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/07/f7-mikejoyner.png)

**Figure 7.  NCI study found decreased mortality as MET-hr/wk increased.** Image credit: [*PLOS Medicine* 2012](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1001335)

- Mike likes that [cross country ski paper](https://pubmed.ncbi.nlm.nih.gov/21477204/) that he mentioned from Scandinavia
  - If somebody’s going to ski 90 kilometers and if they’re going to do it year after year and they’re going to do it fast, they have to be training a lot
- Mike doesn’t think there is good evidence for a J curve
  - Many of the studies suggesting a J curve have a small number of subjects
  - In many of these studies the number of people who are way out there (large # of METs) is very small
  - With small numbers if someone dies, gets hit by a car or something, it can make a difference
    - This is one of the problems with a study from Copenhagen or Norway

**What else happens with increased MET-hours per week?**

- The one thing that does happen is people have an apparent increase in risk of [atrial fibrillation](https://en.wikipedia.org/wiki/Atrial_fibrillation)
- One caveats is they do not have any increased risk of fatal arrhythmias
  - Atrial fibrillation is no fun, it can lead to medical problems, but it doesn’t kill you
  - [Ventricular arrhythmias](https://en.wikipedia.org/wiki/Arrhythmia#Ventricular_arrhythmia) can kill you but are not seen in any greater extent in these people who are heavy exercisers for their entire life

***The controversy is, do these people actually have more atrial fibrillation or is it just that they are exercising and notice it?***

- Mike thinks people who train for their entire life (50-70 MET hr/wk) have some increased risk of atrial fib compared to people that are super healthy otherwise
  - But their risk of atrial fibrillation is still probably lower than people who are sedentary, hypertensive, obese, diabetic, and so forth
  - Further, there are good treatments for atrial fibrillation and you continue to be protected against fatal arrhythmias

**Is there compelling evidence to suggest there is an increased risk in myocardial fibrosis in endurance athletes?**

- Data from [Ben Levine’s](https://profiles.utsouthwestern.edu/profile/14262/benjamin-levine.html) group down in Dallas show that fit young people have very flexible, compliant heart muscles
  - They show that declines with age
  - But it doesn’t decline nearly so fast in people that are either habitual exercisers or people who remain master athletes/ highly competitive

***His data show that training keeps the ventricles compliant, flexible and able to handle the increased demands and pumping demands of exercise***

- Mike thinks the fibrosis argument’s a little spurious

**Mike’s takeaway**

- Large coronary arteries in people that are habitually physically active vasodilate better
  - They probably are less likely to generate a clot
  - Theses people are also protected against fatal arrhythmias
    - There may be a subtle increased risk in atrial fibrillation
- The other thing to remember is that exercise is not an absolute vaccine
  - You can’t say that if you work out an hour day, you’re never going to have heart disease, but your risk is going to be dramatically reduced
- Peter thinks the VO2 max data discussed is another argument against a J curve
  - He asks the question, “*How is it that people in the top 2.3% of the population for VO**2* *max have the lowest mortality by a long shot, if they’re not training significantly?*”
- Peter asks his patients to be at the elite level for a decade below their actual age
  - He doesn’t see how they are going to get there doing only 40 MET hr/wk
  - You can’t achieve a VO2 max of that level, just doing a little bit of maintenance stuff here and there
  - You have to do high-intensity training
    - Mike notes that studies by people like [Bob Hickson](https://pubmed.ncbi.nlm.nih.gov/838658/) and [Wisløff ‘s group](https://bjsm.bmj.com/content/48/16/1227.long) up in Norway show that people who do some longer intervals 3-4 times a week can get a lot of bang for their buck in terms of VO2 max
    - Mike studied the effect of interval training on VO2 max in this [meta-analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182)

## Mitigating age-related decline in fitness by elevating your VO2 max at a young age [46:15]

**Peter’s logic behind his thinking that people should have a high VO****2** **max when they are young**: “*The reason you want to have a high VO**2* *max when you’re young is we want to be able to prepare for the inevitability of decline*”

**Peter’s question for Mike***: What is the most recent data on how much peak VO**2* *max declines with age in a training and non-training individual?*

- People think VO2 max declines about 10% per decade, starting in the 4th decade (so sometime in your 30s)
- A lot of that is driven by age-related decline in heart rate
- But in people that are not training, it’s because their heart can’t pump as much blood and their muscles can’t use it
- Among people who are training, they start at a higher level
  - And then if people continue to train, they probably don’t see a big decline until their late 30s or early 40s
  - This is what is seen among athletes, because there are world class endurance athletes in their early 40s
- And you can reduce the rate of decline by about half, certainly up to your 70s probably
- Not everybody keeps training hard
- If people stop training, their VO2 max falls precipitously
- [Dr. Dave Costell](https://www.bsu.edu/academics/centersandinstitutes/hpl/people/facultydirectory/emeritus/costilldavid), really one of the founders of exercise physiology in the United States, [studied](https://pubmed.ncbi.nlm.nih.gov/8847316/) a lot of elite athletes in the 60s and 70s
  - He brought them back to his lab when these guys in the 1990s, when they were in their late 40s and 50s
  - About a third of them had continued to train very hard and had minimal reduction in their VO2 max
  - A third had become joggers; they had some reduction
  - And there was a third that had just stopped doing anything, and they looked like regular sedentary people

> “*You do have to stay at it*”‒ Mike Joyner

- A group of master athletes out in the LA area were studied, same sorts of things
  - People declined and their VO2 max declined
  - But among the people who continued to train intensely in the case of the men do some strength training, their VO2 max declined at a much lower rate

**Mike’s takeaway**

- Without exercise, VO2 max declines 10% per decade
- Maintaining a high level of exercise, this decline is 5-6% per decade
- Most people who’ve been super competitive can’t keep up a high level of exercise for their entire life, so this drops off a little bit
  - But even if they drop off 10% per decade, they start at a much higher baseline
- If your VO2 max baseline is 60 versus 35 and you lose 10% per decade, you’re still going to be way, way, way ahead
  - At age 60 or 70, you’re going to have a VO2 max value higher than a 30 year old
- Peter adds this is the reason he pushes his patients so hard to have as high a VO2 max as possible when they’re in their 40s-50s
  - He’s thinking of this inevitable decline
  - He hopes to extend life by a decade
  - So you may only be expected to live to 81, but he hopes his patients will live to 91

**What do you think is the VO****2** **max above which a person will have no limit on activities when they’re in their 80s?**

- Peter doesn’t need to run a 5 minute mile in his 80s, but he wants to be able to go on a hard hike, to be able to climb 100 feet in half a mile
- A VO2 max of 14 mL/kg or 4 METs
  - 4 METs is required from an oxygen consumption perspective for people to do their activities of daily living
    - This means an occasional somewhat brisk walk for a few minutes, to be able to get around the house, to go to the supermarket and be independent, whatever that means
  - If you want to be able to run a mile in 10 minutes, that would be 35 VO2 max or 10 METs

***If someone in their 80s had a VO******2*** ***max in the 20s-lower 30s, that would be terrific***

- Peter arrived at 30-31 as a magic number for a target VO2 max
- The elite Scandinavian skiers Mike mentioned had VO2 max levels in the high 30s or low 40s, in their 80s
  - Any sort of biological gifts those men had and/or the fact that they were maximally physically active from age 13, 14 to probably 30 would account for that
- A VO2 max of 30 would be a terrific goal
- The other questions are‒
  - How many pushups do you want to be able to do?
  - How many sorts of body weight type of things do you want to be able to do?
  - What sort of agility maneuvers do you want to be able to do?
- We have to factor in orthopedic problems and that sort of thing, but again, we have good treatment for those now and our orthopedic surgeons can fix a lot of things that otherwise would’ve made it difficult for people to walk and move around
- Peter thinks about this alot for his patients
  - He things strength and stability need to be trained in parallel and as hard as they’re training from a cardio standpoint
- He does think that if you’re trying to reverse engineer ending your life with a VO2 max in the mid-20s to high-30s, “*The good news is you are never going to not be able to do something that you want to do*”
  - If you’re at the airport and the escalator is not working, you don’t care
- The question Mike thinks resonates with people is, “*Do you want to be able to play with your grandchildren?*”
- Mike notes what’s interesting in rural Minnesota, you see a few people who grew up on less mechanized farms and remained active milking cows, doing a whole lot of chores
  - It’s remarkable the muscle mass some of these men and women have
- If you look in the hilliest parts of Japan and Italy and Greece, where longevity is the highest
  - People have argued that it’s because residents have to walk up and down the hills
    - They keep their glute strength and balance; they don’t fall
    - Their more rustic lifestyle gives some de facto strength training on a daily basis

## Breaking down the variables that drive VO2 max [54:30]

**What drives VO****2** **max?**

- Broadly speaking, let’s just say there are 3 variables:
  - 1 – The gas exchange in the lungs
  - 2 – The pump efficiency
    - Stroke volume, contractility that affects the efficiency of the pump to move the blood to the capillary bed
  - 3 – The gas exchange in the muscle bed
- These are the big 3 of 4-5 steps
  - You’ve got (1) air to lung, (2) lung to blood, (3) blood from the heart to the tissues, and (4) oxygen from the blood to the tissues
- In general, oxygen uptake is **cardiac output** (how much blood you’re pumping per minute) times **arteriovenous oxygen difference** (how much oxygen you’re extracting out of the blood)
  - It turns out that if you look at all the studies and all the people, fit, unfit, trained, untrained, in general, the biggest issue is ***how much blood can you pump?***
  - *What is that heart rate times stroke volume equation?*
- When you train, you get so you can extract more oxygen from the blood
  - And if you’re at high altitude or if you’ve got problems with your lungs, then maybe the lungs don’t work as well
- But in general, you cannot extract what has not been delivered
- The key is **delivery,** and that’s **heart rate times stroke volume**
- Interestingly, some of your fittest people actually have slightly lower **peak heart rates**
  - And one of the reasons is because their stroke volume is so high

**Metrics of an elite athlete**

- One of the really interesting experiments of nature is a man called [Eskild Ebbesen](https://en.wikipedia.org/wiki/Eskild_Ebbesen), who won gold medals in 5 Olympics in rowing for Denmark
  - There is serial VO2 max data on him from the time he was 18 or 19 until his early 40s
  - His VO2 max is around 5.6 L/min, which is quite high.
  - He weighed about 70 kilos; he was a lightweight rower
  - But his peak heart rate dropped from about 190 to 150 over that period of time, which means he was able to pump the same amount of blood, but he had to do more with each beat
- Peter finds this example insane

**Peak heart rate**

- As individuals age, we think the majority of the reduction in VO2 max comes from a reduction in cardiac output
- Mikes adds that the majority is probably coming from a reduction in **peak heart rate**
  - This can be buffered to some extent if you have a nice compliant ventricle
- Peter is not quite 50 and is saddened by the reduction in his peak heart rate
- Mike adds that his was never very high to begin with
  - He’s 60 and he focuses on what his workload is
- Peter noticed a precipitous fall in his maximum heart rate when he was in his 20s
  - When he was a teenager and training obscenely hard, a heart rate of 200 was an everyday occurrence
  - By the time  he was 20-25, in medical school, his max heart rate dropped immediately to about 180
  - It became very difficult to get his heart rate over 180 which was far lower than what is predicted by 220 minus your age
- Mike was in 2 famous studies as a subject
  - One was a lactate threshold study, when he was 19
  - A few years later, he worked one summer at Washington University in St. Louis and stopped training
    - He had just finished his last year of track and field at the University of Arizona
    - He would run 10,000 meters in 3o:48
    - He liked to tell people he was good enough to get lapped by the world record holders
    - His peak heart rate was 185-188
  - Over 12 weeks of de-training, his peak heart rate went up 10 beats a minute to the high 190s
    - This would be 220 minus his age
- There’s a bunch of data on elite athletes showing that some have peak heart rates similar to 220 minus their age, but many are lower than that
  - There have been world record holders, Olympic champions that had peak heart rates in the 150s
- Peter had [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) on the [podcast](https://peterattiamd.com/lancearmstrong/) last year
  - In the heyday of his tours, they weren’t looking at their power meters when they were competing, only during training
  - On race day for the time trial, they just went off heart rate
  - Lance was winning the tours between ages 28-35 and he was holding 200 beats/min for the entire time trial (45 minutes)‒ that’s insane
- Another example is a man named [Bob Schul](https://en.wikipedia.org/wiki/Bob_Schul), an American who won the 5,000 in 1964
  - He did interval training all day and all night
  - It was incredible how he trained; his heart rate was around 154, 156
- [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun), the great miler, his heart rate was not particularly high in his 20s
- They must have incredible stroke volume; big hearts, big pumps

## Learning from elite athletes: Training regimens, aerobic efficiency, and other impressive metrics [1:00:15]

**How endurance athletes train**

- When you look at the best high output endurance athletes today, it’s one thing to talk about their peak engine performance, but it’s easy to overlook what they’re doing at the low end
- Peter had [Iñigo San-Millán](https://www.inigosanmillan.com/about-me) on the podcast twice and talked at length about [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar)
  - On episode [#201 – Deep dive back into Zone 2](https://peterattiamd.com/inigosanmillan2/)
  - See also [#85 – Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/)
  - It’s amazing to talk about how high Pogačar’s FTP (functional threshold power) is
  - It’s amazing how much power he can put out while keeping his lactate below 2 mmol
    - He’s over 4 watts/kg
- Take someone off  the street who doesn’t ride a bike but has an average fitness and ask them to hold 4 watts/kg
  - Maybe they could do it for a minute
  - Most people couldn’t do it for a minute, but Pogačar can do it for 4 hours
    - That low end aerobic efficiency is impressive
  - Peter always tries to explain to his patients, “*If your VO**2* *max represents the height or peak of your pyramid, the wider your base, the higher your peak*.”
- When Mike thinks about performance and elite athletes, he obviously thinks about their VO2 max
  - Then he starts thinking about their [lactate threshold](https://en.wikipedia.org/wiki/Lactate_threshold) which would be sort of the FTP and is related to the anaerobic threshold

**What fraction of your VO****2** **max can you perform at for minutes to hours?**

- Typically it’s about 60% in untrained, young to middle aged people
- It’s lower in people who are really untrained, just sort of sedentary
- In people that are very fit, it can be 75, 80, 85, even 90% of VO2 max
- In some older athletes, it’s close to 100
- Mike  notes that somebody like Pogačar probably has a peak work rate that they could sustain for 10 or 20 minutes of 6-7 watts per kilo
  - So the fact that they can do 4 watts per kilo forever shouldn’t surprise anybody
- Look at somebody like [Mr. Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) who’s running 4:40 miles at a pace that doesn’t really probably cause much of an increase in his blood lactate acid levels at all
  - His [metrics](https://inscyd.com/article/2019-9-26-physiologyeliudkipchoge/) have been published

**What was Kipchoge’s lactate level at the completion of a marathon at just under 2 hours?**

- Mike points out, “*At the end of the race you wouldn’t have a lot of carbohydrate on board*”
- He can run a 4:40 mile (over 12 mph) at levels it barely nudges lactate acid levels
- When Mike first started thinking about this and making models of performance, he thought that the highest number was 85% of max
  - It’s probably closer to 90% for somebody like Kipchoge
  - And when think about FTP for 1 minute, for the Kipchoge challenge, people have put treadmills at 12.5 mph
    - People get spit off the treadmill in 30 seconds (or less!)
- These people are training 2-4 hours a day
- Running is limited, the impact becomes a problem
  - They develop orthopedic issues
  - It’s really difficult for people to run more than about 120 or 130 miles a week
  - It’s difficult to do hard training for long periods of time
    - There are a few people that can do it

**How elite long distance runners train**

- If you look at what Kipchoge does, it’s almost identical, even day for day, to what [Bill Rodgers](https://en.wikipedia.org/wiki/Bill_Rodgers_(runner)) and [Frank Shorter](https://en.wikipedia.org/wiki/Frank_Shorter) did
  - He does it at altitude
  - There’s a lot of medium 8 and 10 and 12 miles runs, a couple of hard interval sessions per week, and a long run
  - That gets them to 120 miles a week, week in and week out.
- Cyclist can do more
  - They don’t have the issue of impact
  - There is also a chance to take a break here and there
  - The same is true for swimming

> “*What’s amazing is that if you look at what the elite of the elite are doing has not really change that much for 50 or 60 years*”‒ Mike Joyner

**The metrics of elite athletes haven’t improved so much as sports medicine has gotten better**

- If you look at the data on the elite of the elite from the late 60s to early 70s, it’s not like Kipchoge’s VO2 max was 90; it was high 70
- Mike thinks a lot of what’s happened in terms of at the very edge of things has been better races
- Now also, people have longer careers
  - Sports medicine is better, so if people get injured, they can recover
  - They don’t stop when they’re 25-26
- We saw this last night with [Klay Thompson](https://en.wikipedia.org/wiki/Klay_Thompson), he had two injuries at age 30
  - 40 years ago would’ve been basically career ending and he’s come back from a combination of an ACL issue and a torn achilles tendon
  - He used to just destroy people and he’s playing very well.
- Races are much better‒ they used to run the Boston marathon at noon when every so often you’d get a really hot day
- So most of the improved performance can be attributed to equipment and these sort of social factors
  - Unfortunately in the case of Mr. Armstrong, it can also be from people bending the rules

**What intensity level does Kipochoge’s train at?**

- We could pick the most extreme example and talk about Kipchoge
  - He’s running 14-20 hours per week
  - He also does a ton of other strength training and bodyweight training
- If you looked at it in terms of the lactate threshold or the equivalent of critical power on the bike, probably 60, 70% of that is fast, but not that fast
- They typically start off their group run sort of jogging and then they pick it up over time
- Also remember that he’s doing this at 7- 8,000 feet
- Mike’s understanding in reading his training program that a couple days a week he goes to a track and they run multiple 400 meters
  - Let’s say 200 meter jog, 10 times a kilometer very fast
- The total amount of time he’s running faster than race pace might just be 10 miles per week

***So he’s probably running about 60 or 70% of this stuff slower than race pace***

- Some quite slow, but most of it medium fast, but certainly not where he can’t talk to you where he’s short of breath
- Then he’s probably spending about 20% of his time he can still talk to you, but he’s pushing it a little bit
- And probably 10% of his time where he is pushing it a lot

- Peter has the same impression of elite cyclists and elite swimmers

**Elite runners in the 60s**

- In the last 20 years, it has emerged
- There is some good lab data from the 1930s and lots from the 50s and 60s
- If you look at individuals who have tremendous treadmill values, tremendous VO2 max values, who ran very fast times on dirt tracks and in muddy conditions
  - If you look at what those people were doing, they were doing all kinds of things
- [Bob Schul](https://en.wikipedia.org/wiki/Bob_Schul) was a runner in the 60s
  - His morning workout would be 40x 100 meters with a short jog in between
  - His afternoon workout might be 20x 400 meters
  - He rarely ran continuously at all except in races, and it would be a fast interval slow
- There are other people who ran up to 200 miles a week and hardly ever ran fast, again, except in races and some strides
- There were already people doing the sort of mix training described a minute ago

***What is interesting is the extent to which things have sort of converged on this 60, 70, 20, 30, 10 sort of model***

- Peter replies, “*I can understand why there is a benefit to just the mitochondrial efficiency that comes from the continuous effort that you’d miss out on if you were just doing the short bursts*”

## Health benefits of light exercise for the average person [1:09:00]

**How much training time do elite athletes spend on low-intensity exercise?**

- We know there is a health benefit to low-intensity (zone 2) exercise, but ***is there a training benefit?***
- We think about **zone 2** as where Kipochoge probably spends 60-70% of his time
  - He can still talk
- At race pace he’s in **zone 3 to zone 4**
- At **zone 4 to 5**,10% of his mileage, he’s really stretching himself

*Is Kipochoge or other athletes deliberately putting time into* ***zone 1****, which is truly a recovery pace?*

- They do that when they’re recovering between intervals
- Mike did this many years ago‒ the first mile or two can be very slow, can be just almost a walk jog and then you kind of drift into it

**Benefits of light exercise for the typical person**

- But thinking about the listeners who are just trying to improve their health, that’s where you come back to physical activity versus intentional training

***When you start looking at the health benefits of just less than brisk walking‒ they’re substantial***

- It’s purposeful, but not really brisk walking
- Parking your car farther out in the parking lot and strolling in
- Walking the dog can mean all sorts of things depending on what kind of dog you have and who’s in the neighborhood
- The data on gardening
- Most of us think about gardening as relatively light exercise
- The health benefits of light physical activity, light exercise, are substantial and there is no J curve
  - Things go up, but it’s not completely linear

> “*The biggest benefit people get health wise is in the first 10 or 15 minutes [of exercise]*”‒ Mike Joyner

- 10-15 minutes of light physical activity begins to do things in your skeletal muscle
- Then it improves your insulin sensitivity and helps you fight against diabetes
- Mike thinks just a tiny bit of additional physical activity is at least some buffer against weight gain
- There’s some improvement in your aligning in your blood vessels and probably some improvement in your autonomic function
- Is your heart going to get bigger? Are you going to get a more efficient cardiac pump‒ probably not
- But are you going to begin to be able to do more things? The answer is yes

## Simple training metrics to track, and Mike’s current exercise regimen [1:11:15]

**Should we track heart rate recovery (HRR) as we train?**

- Some people are really into tech, and Mike is a tech noodie
- Part of the reason is there wasn’t much tech around when he started
  - Digital watches were new
  - There weren’t even stop watches
- At the time, one of the big innovations was rating of perceived exertion
  - The 6-20 scale (or 1-10 scale) about how hard you’re working.
- What’s been shown is, because you can have a good day and a bad day in terms of the metrics, that they’re all sort of parallel

***Learn to read your own body via the rating of perceived exertion and/or metrics (find one you like) and then just focus on sort of big picture things***

- Mike would not get too hung up on heart rate recovery (HRR) or heart rate variability (HRV)

**Simple metrics to track**

- How much time are you training? 30, 60, 180 minutes a week?
- Are you also doing other forms of activity like taking the stairs as you mentioned?
- What sort of combination are you doing?
- How much time are you spending where you’re really short of breath?
- How much time are you spending where you’re a little bit short of breath?
- How much time is it a pleasant sort of pace?
- Mike thinks‒ that sort of information can get you as much as you need

> “*The main thing then Peter is to make sure that you have some accountability*”‒ Mike Joyner

- It can be a training partner, maybe with a device or a diary, maybe with just how far did I run today?

**Mike’s current exercise regimen**

- Running a 10 K at 30:40 is fast
- Mike once ran a 2:25 marathon
- He’s a big believer in what’s called “**hard easy”**‒ *a hard day followed by an easy day*
- What he’ll do on a hard day‒
  - 1 – **Warm-up** on a stationary bike and the rowing machine for 10 to 15 minutes
  - 2 – A **circuit** that starts with 25 squat thrusts, a minute of jumping rope, static wall sit to failure, and then some drop sets where he goes down the weight stack
    - Then drop sets with incline flies
    - Then drop sets with leg extensions
    - And drop sets with a combination of pull ups and lat pull downs and military presses
    - Then some additional stuff for his legs
    - Pushups, bar dips, and upright rows, followed by something else for his legs
    - He alternates arms and legs and works his way through this with no rest
    - Drop sets on each thing for all large major muscle masses
    - And that takes about 22 minutes for 1 circuit
  - 3 – Then he’ll get on the bike and he’ll do 8 times 3 minutes of a **ladder**
    - He starts unloaded, goes up a notch for 30 seconds, go up a notch, go up a notch, and he’ll get to maybe about 350 watts for the last 30 seconds
    - Then he’ll come back down to about 100 watts
    - It takes him 3 minutes to do this ladder up to 350 watts
    - Then he’ll bike at 100 watts for 30 seconds, move up to 150 W for 30 seconds, 200 W for 30, 250 for 30, 300 for 30, 350 for 30, then back down to 100 for 30
    - 8 repetitions of this ladder takes 1 hour
    - He does not rest between sets
- Remember Mike is doing those ladders after a heavy leg workout
  - His legs are pretty fatigued
- Mike does a hard day every other day or every 3rd day
- His **easy days** are 30-40 minutes in the morning
  - Maybe watch the first bit of [Obi-Wan Kenobi](https://en.wikipedia.org/wiki/Obi-Wan_Kenobi_(TV_series))
  - His easy days are built around watching a documentary or how many times can you watch [*The Mandalorian*](https://en.wikipedia.org/wiki/The_Mandalorian)? How many [Clint Eastwood](https://en.wikipedia.org/wiki/Clint_Eastwood) movies can you watch?
  - This started during lockdown,
  - He will do 30-40 minutes of light cycling, transitioning to rowing back and forth
  - Sometimes he does one in the morning
  - Sometimes when he comes home from work he’ll do another one
- The goal for the easy day is an old concept called **active rest**
  - He’s not trying to get a real training effect
  - He’s trying to loosen up from previous day’s workout because he’s sore
- He’ll do this for about 6 months
- And then probably when it starts getting dark again, he’ll start doing a kind of maintenance circuits, in terms of the strength
  - It may be only twice a week
  - And he’ll start doing longer rides
  - He has a Peloton; he doesn’t do any of the classes, but he’ll started doing this *hour of truth* to see how many watts he could average for an hour
    - His best during lockdown last year was an average of 316 watts for an hour

> “*Wow, that’s obscene!*”‒ Peter Attia

- Mike wants to see if he can get to 320 watts next year

**What is Mike’s VO****2** **max?**

- Back when he was quite young, it was 5.4 L/min
  - He weighed 75-80 kg
- Now he weighs about 95 kg because he’s made an effort to gain some weight
  - He thinks his max now is about 4.5 L/min

**When did Mike start running competitively?**

- He started running late; he didn’t start until his senior year of high school
- He has some natural ability
- He is 6’4” and likes to tell people, “*If I come back in the next life, I’ll be a swimmer or a rower*”
  - Because he would show up to race these tiny people
  - He’s the world’s largest, relatively good distance runner (formerly, relatively good)

**On your easy recovery day, are you just paying attention to RPE ,or are you looking at a split time on the rowing machine or a low wattage bar on the bike?**

- It’s just all [RPE (rate of perceived exertion)](https://www.triathlete.com/training/what-is-rpe/)
- It’s really just **active rest**, which is a lost concept

**Do you have a sense of your heart rate as a percentage of your max heart rate?**

- No; he doesn’t measure heart rate
- His peak heart rate is probably about 140
- He tracks RPE, he likes to suffer
- Mike notes, “*It’s unusual to be able to do intervals on your own and really push it. Not everybody can do it and that’s why you need a class or you need a coach or you need a group and so forth, but I’m lucky enough to be able to do it. So my training’s really polarized.*”

## How to boost your VO2 max, and the importance of form and tempo with interval training [1:18:15]

**Peter’s approach with patients:**

- One of the most efficient ways to improve VO2 max that Peter knows (what he tells his patients) is to use a **4 x 4 protocol**
  - 4 minutes on, 4 minutes off
  - For example, get on a bike on an incline (not very steep, maybe 6% grade)
    - He wants to stay in the saddle climbing against resistance for 4 minutes
    - He never wants the resistance to go away
    - He uses a power meter and tracks heart rate
    - He wants to keep the power as steady as he can;  invariably it dips around minute 3 and then he can recover it in the 4th minute psychologically
  - This is followed by 4 minutes of recovery
    - Literally doing nothing but rolling back to the starting line
  - Repeat

**Mike’s approach:**

- Mike agrees with Peter
- Mike tells people who want to run a faster marathon or whatever, they need to get their VO2 max up
  - These are people who are running a lot of miles
- He tells them exactly what Peter described
  - Sometimes he recommends 5 minutes of work and 3 minutes of rest
  - People who are fitter only need 2 minutes of rest

> “*Four times four is terrific*”‒ Mike Joyner

- To put this in the context of running, run at your 5 K race pace
  - Maybe the first one is a little slower
  - Then each one gets progressively faster
  - You would jog in between or if you’re not going fast, walk in between
- The classic training among elite runners is mile repeats
  - 4-5 times one mile
  - And then they jog a quarter mile or a half mile in between
- Mike has personally have seen really good runners do 4:30, 4:25, 4:20, 4:15, 4:10, 4:05
  - These were people getting ready for the Olympics

**Advice for the average person**

- Peter notes that he and Mike have trained their whole lives, so they know what going all out for 4 minutes feels like
- For the average person, the hard part is this requires a bit of coaching up front
  - You’re aiming for consistent effort for 4 minutes
  - But the suffering disproportionately occurs in the last 90 seconds

Mike’s “no bend over” rule

- When you finish the last one (#4), you do not want to be bending over
  - If you had gone a little faster, you’d want to be bending over
- What people have to recognize, both for the 4 x 4 minutes and within the 4 minutes, is a good interval workout
  - This sounds completely masochistic, it’s like putting your hand in warm water and then slowly increasing the temperature in the water to where you can barely stand it anymore and then leave it in for a while
  - And then you turn it down, let your hand cool off, and do it again

**Exploring your limits with interval training**

- One of the things Mike learned from cyclists is a terrific phrase called *manage your suffering*
  - You need to learn to manage your suffering
- The other interesting thing about this type of training is the extent to which people can have a sort of religious experience exercising
  - This sort of interval training is one way to get them
- Peter agrees, “*I think that there really is something wonderful about experiencing your limits and understanding that level of discomfort*”
- Mike adds, if you’re able to maintain your rhythm and tempo while you do it, that’s when you can have these sorts of experiences
- One of the most beautiful things ever, was to watch [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) swim the butterfly and watch his stroke
  - It wasn’t an endurance event, only a short couple of minutes
  - He was good at everything, but he was especially good at the butterfly
  - For most people, their stroke has fallen apart and they end up taking more strokes in the last 50 of a 200 meter butterfly
  - His stroke count didn’t change in the second, third, and fourth lap because he had that rhythm, that tempo
- And if you listen to the old school coaches talk about interval training, they’re constantly talking about **tempo**
  - What is your rhythm? What is your tempo?
  - And why are you doing it, why are you suffering?

***“The goal was to not lose your form and not lose your tempo***” says Mike

**Form and tempo of elite athletes**

- Peter used to watch Michael Phelps train before he broke out in the early 2000s
  - Peter was living in  Baltimore for his residency at Hopkins
  - He used to train at a place called North Baltimore Aquatic
- Michael within the swimming world was already an unbelievable prodigy because he had placed 5th in the Sydney Olympics at quite a young age, 15
- He became the youngest male to ever set a world record for the 200 fly in early ’01 at age 15
- Peter got to watch this 16 year old swimming at North Baltimore Aquatic, NBAC,
  - His signature event was the 200 fly
    - Peter would put that up there with the 200 breast and 400 IM as the 3 worst races in swimming
    - For Mike, it’s like doing an 800 intermediate hurdles on the track (that event doesn’t exist)
    - The suffering is insane
  - But the thing is, you never saw him to a 200 fly in training
  - He did lots of 75s
  - His coach, [Bob Bowman](https://en.wikipedia.org/wiki/Bob_Bowman_(coach)) was really adamant about perfect form
  - Peter recalls, Michael had an unusual rhythm, which is that he breathed on every stroke
  - Most people who swim butterfly, breathe every other stroke, you were head underwater for one stroke, head up for one, down for one
  - But no one’s form could rival his, and that’s why he was usually the last guy to hit the wall at the 50, yet would come back and just devour everybody
- Mike saw this with [Edwin Moses](https://en.wikipedia.org/wiki/Edwin_Moses), taking 13 steps between hurdles in the 400 hurdles, in the late ’70s
  - That innovation
- You see Kipchoge doing it for 2 hours, his ability to maintain this form and tempo

> “*And as you watch it… you are awed by this sense of great effort and simultaneous relaxation. It’s a real paradox*”‒ Mike Joyner

- Mikes sees this in other sports too
- When golfers get hot, how far they hit the ball‒ they are both violent and relaxed at the same time
- To watch [Steph Curry](https://en.wikipedia.org/wiki/Stephen_Curry) and [Klay Thompson](https://en.wikipedia.org/wiki/Klay_Thompson) start launching basketballs, it’s just incredible
  - The tempo, the rhythm, the form, and the effort
  - But again, just how relaxed they are

> “*It’s just wild to think about, even*”‒ Mike Joyner

## Training advice for the average person [1:25:15]

**Advice for a recreational person who’s never trained in their life**

- At this level, they don’t need to use lactate testing
- Everything is based off [**RPE (rate of perceived exertion)**](https://www.triathlete.com/training/what-is-rpe/)
  - You want 80% of their time for them to work at a level where they can talk but not enjoy it, no higher
  - This might start out as 2-3 hours per week
- After about 6 months of this kind of training, after they build up a bit of reserve, they can move to the next phase
- The next thing to add is a 4 x 4, for 4 rounds (4 on + 4 off)
  - Once a week

**Is doing 4 hard intervals once a week sufficient to boost VO****2** **max?**

- Sure, for the vast majority of people this will increase it
  - Especially if they’re doing the other stuff you’re talking about
- What Mike really likes about what Peter describes is that sometimes you have to train before you can really train
  - This is especially true when your going to do hard training

> “*Sometimes you have to train before you can really train*”‒ Mike Joyner

- Mike has seen some studies of people who are 60-70 years old, they had to do 3-6 months of pre-training before they were fit enough to train hard
- After you are able to do 4 rounds of 4 x 4, once a week, you can build up to 2x per week
- Advice from a man named [Stan James](https://medicine.uiowa.edu/alumni/content/stan-james-md) is once people start doing more than about 5 or 6 hard sessions every 2 weeks, they begin to have some sort of load management issue (orthopedics/ fatigue)
  - He’s in his 90s
  - He’s one of the pioneers of sports medicine, orthopedic surgery
  - He’s still practicing medicine but not operating anymore
  - The last time Mike checked he was alive and well out in Eugene, Oregon
  - He worked with coach [Bill Bowerman](https://en.wikipedia.org/wiki/Bill_Bowerman), the great Oregon coach, one of the founders at Nike, the waffle shoe guy
    - They got into this hard, easy thing, which is sort of what Mike does
- Mike can’t remember the last day that he didn’t do anything
  - It’s probably been years
- He estimates that he does a hard workout 120-130 times per year

> “*I never go more than a week without doing something relatively intense*”‒ Mike Joyner

## Why professional athletes have longer careers than they’ve had in the past [1:27:30]

**Do exceptional elite athletes have a finite number of exceptional performances in them?**

- People used to drift into the world rankings
- They’d last maybe 2 Olympics, 6-7 years
- They’d emerge right before one Olympics, do well, then do well in the next one, then kind of fade
- Mike thinks there are 2 things that have really changed
- 1 – Sports medicine is better
  - So if people do get injured, they can do things about it
- 2 – Sports have become so professionalized
  - People that are really, really good can now make enough money to make it worth their while to continue
  - He sees this in terms of the age of Olympians
  - It used to be very unusual to have women over age 20 in swimming
    - There was no college swimming
    - It was a lot of teenagers
- Now the age of athletes is drifting up
  - People like [Katie Ledecky](https://en.wikipedia.org/wiki/Katie_Ledecky) are having extended careers
  - Phelps went  to the Olympics in 2000, 2004, ‘08, ‘12, and ‘16

> “*That would’ve been inconceivable previously for swimmers*”‒ Mike Joyner

- Before, people hung around and maybe stayed for 1 additional Olympics
- And when they got done after college sometimes too, but eventually they had to go do get a job
- But now, among the most elite who can monetize this, people last longer
- Mike also sees this in “the major” professional sports
- Before orthopedic surgery was good and every knee surgery was an adventure, somebody like [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) would have had a shorter career
  - His career would have been over in 2009
- If you’re making $23 million, or whatever the number is, why not keep playing?
- If you look at sports like running, swimming, cycling‒ they get paid less, more of  a [journeyman](https://en.wikipedia.org/wiki/Journeyman_(sports)) group
- But if you look at the NBA, the NFL Major League Baseball, the salary scales are pretty good
  - And if people can play another couple of years, this can be millions of dollars for them
  - So they’re very motivated to do this
  - If you can be the 8th man on an NBA team and give people 15, 20 quality minutes of a game, you’re going to have a job for a long time
  - If you’re [LeBron](https://en.wikipedia.org/wiki/LeBron_James) who apparently spent some huge amount of money on training and all that other stuff, if you start thinking about spending x per year for a 40X paycheck, why not? Why stop?

## Use of performance-enhancing drugs in professional sports [1:29:45]

**What is the current status of performance-enhancing drugs in sports?**

- Cycling and swimming are the endurance sports that Peter follows
- Go back and look at the cycling data
- Peter loves how [Lance](https://en.wikipedia.org/wiki/Lance_Armstrong) talks about this
  - [Episode #178 of *The Drive*](https://peterattiamd.com/lancearmstrong/)
  - He’s very open to say that as long as there has been a [Tour de France](https://en.wikipedia.org/wiki/Tour_de_France), there has been a graying of the line, but there is a difference between the high octane cheating that was done in Lance’s era and sort of the low octane cheating that was done in [Eddy Merckx’s](https://en.wikipedia.org/wiki/Eddy_Merckx) era when they were using a little bit of [AMPH (amphetamine)](https://en.wikipedia.org/wiki/Amphetamine)
- Mike replies that testing has gotten better both in terms of frequency and the actual chemistry
- If you look at what’s called an abnormal test, it’s not like clinical medicine where it is an out-of-range test
  - There are typically many standard deviations above average for these things
  - These tests are typically designed so there’s not a lot of [false positives](https://en.wikipedia.org/wiki/False_positives_and_false_negatives)
  - So that gives people some room to microdose
    - And that’s why you have relatively few positive tests
- But occasionally people will be caught through investigations, judicial mechanisms, the police
  - Historically, many of the biggest busts have been made by the police
- Mike contends that the era of industrial strength doping is over
- People are no longer doing like the East Germans did and androgenizing females to the extent that they really look like men
- What the Russians did less than a decade ago was relatively low dose by comparison

> “*I do think that industrial strength doping has largely been stopped, prevented*”‒ Mike Joyner

- There are probably a bunch of novel compounds out there
- Small peptides that cause this to be released or that to be released, which would be very difficult to detect
  - They’d have vanishing short half-lives
  - And they would just boost your endogenous production of hormone X, Y, or Z, something like a growth hormone-releasing factor, something that caused testosterone levels to go up or suffer

***It’s a cat and mouse game, for kind of the big three‒*** [***amphetamines***](https://en.wikipedia.org/wiki/Amphetamine)***,*** [***EPO/ blood doping***](https://en.wikipedia.org/wiki/Erythropoietin)***, and*** [***anabolic steroids***](https://en.wikipedia.org/wiki/Anabolic_steroid)***/growth hormone***

- What we learned from the [BALCO situation](https://en.wikipedia.org/wiki/BALCO_scandal) is that there are all sorts of clever bathtub chemists who can make all sorts of things at home in the garage, in a very unregulated environment
- The barrier to entry for that kind of a do-it-yourself sort of stuff is quite low
  - You can buy all sorts of laboratory equipment and reagents and all sorts of things
  - So you don’t have to be a big pharma house to make interesting things

**BALCO and Patrick Arnold**

- The tragedy of [Patrick Arnold](https://en.wikipedia.org/wiki/Patrick_Arnold) is he’s a tremendous guy with a master’s degree in organic chemistry
  - He wasn’t working for one of the big pharma companies making anti-aging and sarcopenia compounds
- Peter has met Patrick a number of times
  - He spent a lot of time having a frank conversation with him about exactly how he modified these [androgens](https://en.wikipedia.org/wiki/Androgen)
- Mike remembers Patrick’s encyclopedic knowledge of everything that’s ever been synthesized in the androgen field and what it does in terms of half life and metabolism etc.
- Similarly, think of [Victor Conte Jr.](https://en.wikipedia.org/wiki/Victor_Conte), from the [Tower of Power](https://en.wikipedia.org/wiki/Tower_of_Power)‒  another [autodidact](https://en.wikipedia.org/wiki/Autodidacticism)
  - He was a junior college educated rock/jazz musician
- For both of these individuals, if you step back from the legal and ethical ramifications and ask, what do they know?
  - And try to be a little bit objective about that
  - With doping, you get into other sorts of areas
- In the cultures they were operating in, this was considered the cultural norm
- Lance was not the only person doing industrial strength doping
  - Was he doing it better than other people?
  - If there were 6 ways to doping, person X was doing 2 and you were doing 3, was Lance doing all 6?
- The other thing people have to recognize about doping in these incredibly competitive situations, with these incredibly competitive people/organizations is that there’s always going to be some sort of **arms race mentality**
  - Countries/ organizations with the mantra that our country’s better than yours because we’re winning more medals
  - You see it with training
    - If you’re in there lifting an hour a day, I’m going to go lift an hour and 10 minutes a day
  - *Where does it stop?*

**Is human growth hormone still one of the more utilized agents today for performance enhancement?**

- [Human growth hormone (HGH)](https://en.wikipedia.org/wiki/Growth_hormone) is not something that can be readily tested for
- Mike’s guess is that there’s probably some of it going on
- He thinks people have probably drifted back to more low-dose/short-acting androgens and hope for the best
- The same would be true with low dose EPO and/or related compounds
- You learn about athletes getting busted for growth hormones when person X says t hey’re sending FedEx packages to athlete Y
- So much of this has a judicial/investigatory element to it when you get to the big scandals

**Why are some sports more impacted by doping than others?**

- For example, swimming as a general rule seems less impacted than say cycling or even running, even though the demands are still pretty high
- Mike thinks this is hard to know
  - How cultures head one way or the next tribalistic behavior
  - What’s normal, what’s not normal is the key to understanding that sort of thing

## Can the miracle of exercise be put in a pill? [1:36:00]

**Can some of the benefits of exercise be captured by a pharmaceutical strategy?**

- Peter remarks, “*We started this discussion, Mike, by talking about the miracles of exercise, right? We went through all of these things that exercise is doing physiologically and how the net impact on things is so profound*‒ *on the length of your life and the quality of your life. There’s no shortage of pharma companies out there that are trying to understand*‒ *how can those benefits be put into a pill?*”
- Success in research has primarily focused on things that increase mitochondrial biosynthesis
  - This appears to work in animal models
  - Next, how do you translate it?
- Exercise makes your [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) better or makes more of them

***But [a pill] making your mitochondria better isn’t going to make your autonomic nervous system better, isn’t going to make your blood pressure better, isn’t going to necessarily make the lining of your blood vessels better, isn’t going to make your heart bigger, and so on and so forth***

- So far, these have been sort of one-trick ponies
  - They might provide some benefits for people that are wheelchair bound, quadriplegics, or people who can’t exercise for some other reason
- Mike thinks the jury is still out
- He remarks, “*I’m not particularly enthusiastic about it. I don’t think you’re ever going to get one that does any more than a little bit.*”
- Mike likes to tell people there’s already an exercise medic out there‒  the [polypill](https://en.wikipedia.org/wiki/Polypill)
  - Look at the data on people who get a combination/ one-pill-a-day of low-dose statins + low-dose blood pressure meds + 1 or 2 other components
  - It causes pretty nice reductions in risk factors in most people
  - The side effects tend to be low because it’s low-dose
- But none of this is patentable
- For people who don’t want to exercise (or can’t exercise), the better choice would be to use a polypill which would do the same things
  - A [statin](https://en.wikipedia.org/wiki/Statin) would cause their cholesterol to go down and maybe improve their endothelial function
  - A tiny bit of [Metformin](https://en.wikipedia.org/wiki/Metformin) might improve their glucose tolerance
  - A [beta blocker](https://en.wikipedia.org/wiki/Beta_blocker) might lower their heart rate

***Mike’s not advocating this, but there’s data out there suggesting that a polypill is a “legitimate” public health strategy for lifestyle diseases***

- Mike would encourage people to exercise and do the things discussed
- He also thinks polypills have been understudied

## Mike’s current research and questions he’s most interested in answering [1:39:00]

**What question is Mike the most interested in trying to answer?**

- He’s excited about a lot of things
- He has some [interesting data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5256972/) with [Sarah Baker](https://www.researchgate.net/profile/Sarah-Baker-23) on sex differences in blood pressure regulation
- He’s quite interested in human performance
  - The first thing they teach in medical school is a right-shift in the [oxygen-hemoglobin dissociation curve](https://en.wikipedia.org/wiki/Oxygen%E2%80%93hemoglobin_dissociation_curve) (see the figure below) is good for you [at altitude](https://en.wikipedia.org/wiki/Effects_of_high_altitude_on_humans)
  - Meanwhile all animals that are genetically adapted over millennia to high altitude (llamas, the birds that fly over Mount Everest, and so forth) are left-shifted

![](https://peterattiamd.com/wp-content/uploads/2022/07/f8-mikejoyner-1024x535.png)

**Figure 8. Oxygen dissociation curve showing hemoglobin of differing affinities for oxygen.**  Figure credit: [OpexStax Biology2e](https://openstax.org/books/biology-2e/pages/39-4-transport-of-gases-in-human-bodily-fluids)

- He’s been doing some really cool hypoxia [studies](https://pubmed.ncbi.nlm.nih.gov/34152867/) in people with rare left-shifted hemoglobin
  - This is a super interesting physiological question
- Hemoglobin is the red stuff in your blood
- The hemoglobin dissociation curve is a curvilinear  (S-shaped curve)
  - The idea is if you shift the curve to the right, the hemoglobin doesn’t hold onto the oxygen
  - This is great if the tissue is [hypoxic](https://en.wikipedia.org/wiki/Hypoxia_(medical)), hemoglobin will release oxygen
- The problem with a right-shifted curve is it’s harder for hemoglobin to get the oxygen of the of lung
- Animals adapted to high altitudes (such as the [bar-headed goose](https://en.wikipedia.org/wiki/Bar-headed_goose) that flies over Mount Everest without acclimation)
  - They live in the plains of Mongolia and one day just fly over Mount Everest and go to India
  - Their hemoglobin dissociation curve is left-shifted, and this allows them to pick up oxygen out of the air in their lungs at very high altitude
- Mike is studying a family of people and some other subjects that also have left-shifted hemoglobin
- There are all sorts of rare hemoglobin variants
  - They’re not like [sickle-cell](https://en.wikipedia.org/wiki/Sickle_cell_disease) or anything
- Mike notes, “*It’s interesting, Peter, to be sitting in the lab, having somebody breathe in 10% auction talking to you, these lift shifted people do that. It’s crazy. It’s just wild*.”

**What is the** [**F****i****O****2** **(fraction of inspired oxygen)**](https://en.wikipedia.org/wiki/Fraction_of_inspired_oxygen) **at the top of Mount Everest?**

- The barometric pressure is about 250
  - So 20% of 250 is roughly 50
  - Once you get it into your lungs, the arterial is in the 30s
- At 15%, which is 3000 meters, these people exercise and they do fine

## Use of convalescent plasma to treat COVID-19 [1:41:15]

- When the pandemic struck in March/April of 2020, Mike became the principal investigator of the [US Convalescent Plasma Program](https://www.uscovidplasma.org/)
  - This program that was initially designed to facilitate the compassionate use of convalescent plasma in 5,000 patients
- Antibody-rich plasma from recovered COVID patients would be given to people who had disease, and hopefully, the antibodies would help them
- The program ended up treating over 100,000 people
- They found evidence when they gave people a whole lot of antibody early in the course of disease, it made them better
- They also found some evidence that it was probably very helpful in people that were immunosuppressed

> “*That has been the gift that keeps giving*”‒ Mike Joyner

- Mike comments, “*So at age 60, 61, 62, 63, I got a new career in immunology and infectious disease*”

**People with B cell deficiency depend on antibody therapy**

- About 2-3% of the population is [B cell deficient](https://en.wikipedia.org/wiki/Humoral_immune_deficiency)
- [B cells](https://en.wikipedia.org/wiki/B_cell) are the cells in your body that make antibodies
  - [Antibodies](https://en.wikipedia.org/wiki/Antibody) help you fight the virus or respond to the vaccine
- People who are B cell deficient will continue to get COVID and other forms of infectious disease
  - Antibody therapy is essential to help those folks
- Mike just learned yesterday from [*People Magazine*](https://people.com/health/jeff-bridges-says-he-was-close-to-dying-covid-while-in-chemo/) of all places that the actor, [Jeff Bridges](https://en.wikipedia.org/wiki/Jeff_Bridges) had lymphoma and was taking drugs that depleted his B cells
  - This is typical lymphoma treatment
  - He got COVID and could not clear the virus
  - He responded to convalescent plasma

**What is the total volume of plasma you need to give a patient in that setting?**

- If you get the really high titer stuff, 200-400 mL
- Typically it’s a one time treatment; sometimes it’s helpful to give people more
- We now have people with hybrid immunity
  - People that have been both vaccinated and they’ve had a breakthrough infection, or they’ve had an infection and been vaccinated
  - The plasma in these people has a whole lot of antibodies and it’s broad-spectrum
    - It covers all the variants
    - It almost anticipates future variants because of the way our immune system works, sort of like a sloppy replicator
- [Monoclonal antibodies](https://en.wikipedia.org/wiki/Monoclonal_antibody) have been super helpful during the pandemic, but [these](https://en.wikipedia.org/wiki/Monoclonal_antibody#COVID-19) have become less effective due to escape variants
- This very high titer plasma is still available

**Mike’s current work**

- Mike is happy to be working on exercise and physiology studies again
- His work with antibody therapy has really been interesting
- Other people receiving convalescent plasma have had similar benefits to Jeff Bridges
- When Mike began medical school, the life expectancy for immunosuppressed patients was quite low
- Now patients with multiple myeloma lymphoma or leukemia live a long, long time

**How long after a person is infected and recovers from COVID are they a suitable plasma donor?**

- Within 2-3 weeks up until 3-4 months
  - Maybe even up until 6 months
  - Longer if they got boosted

**Do you only get sufficient antibodies from people who have been infected, not just boosted?**

- Initially, before vaccines were available, they only used people who recovered from infection
- Now that vaccines have been widely available for 18 months, they are able to get people who’ve had both (vaccination + recovery from infection)
  - These people are really super donors
  - They have them come back in and can get multiple units from them
  - The Mayo Clinic collects their own blood
    - They use it at Hopkins, Harvard, Einstein, and a lot of big places
- They are working with the FDA and lymphoma or leukemia societies, immune deficiency foundation, etc. to make sure convalescent serum is available for those sorts of patients
- In France, they are treating about 50 patients a week with convalescent sera
  - If you scaled this up in the US to match our larger population it would be about 300 patients a week
  - This is something Mike is interested in

> “*It’s a way for people to give back*”‒ Mike Joyner

**Are you able to find enough donors? Are enough people aware?**

- There are lots of people who have recovered from infection, and who have been vaccinated and infected
- There are always logistical issues around getting these people to the blood collection center

**Do you have to determine the blood type for plasma?**

- It should be typed in cross, and they have to be eligible to otherwise donate blood
- During the peak of plasma use (prior to the vaccines and prior to the monoclonals) around 20,000 to 40,000 units a week were being used in the country
  - There was a nice correlation between the use of convalescent plasma and a lower death rate 2 weeks later
- Mike notes that the organizational skills he learned from his coaches during his training in sports has helped him with this type of government work
  - Instead of doing a 5,000 person demonstration project he organized a treatment registry for over 100,000 patients
  - Mike explains, “*I used to joke with higher ups in the food and drug administration, they’d say, well, how did you do that? I’d say I’m a recovering physical educator. And that was always good for laughter in at least a few dark hours*.”

## Parting thoughts on the current state of fitness and exercise in society [1:47:15]

**Is Mike optimistic or pessimistic about the future of Americans based on their level of physical activity?**

- Our society needs to do something
- Upper middle class kids have access to superb coaching, to superb facilities and programs
- But we’ve got a tremendous problem with play and unstructured play
- When Mike was growing up in the ‘60s and ‘70s, they had lots of unstructured play time in parks and at school
  - A lot of these opportunities have fallen by the wayside
- When he was a kid in Tucson, the kids who were college athletes used to come back and have open gym
- There’s no open gym in the summer at the high schools in Rochester, Minnesota
  - And this is a rich community
- The advantage of an open gym was to get people off the street and have them do things
  - The police were happy to know where the kids were
  - It was great for the boys with high energy; it made their life a little easier
  - The lack of this is a real problem
- Mike thinks we’ll have incredible performances by kids who have access
- But what we’re doing in the rest of the world is problematic

> “*If I could do anything, I’d start a national open gym movement*”‒ Mike Joyner

- We have a lot of nice facilities that are only available for a limited number of times per day

**Imagine if you were czar and could say, “No matter what your lot is in life, every person has a mandatory one-hour activity per day”**

- Mike thinks about the secretaries at the Mayo Clinic
  - The Mayo Clinic has a huge, deep bunker system in the bowels of the hospital with huge hallways
  - It’s about a mile around the place
  - These folks would bring their tennis shoes and go down and walk at lunch
  - They would meet up with their pals and do 30-40 minutes a day of laps at lunchtime

***It was terrific for them. I think it was a social event for them.  I think that they solved a lot of problems too. And it actually made them way more productive.***

§

## Selected Links / Related Material

**The benefits of exercise and discussion of the natural experiment in London bus drivers and conductors**: [Exercise: the lifelong supplement for healthy ageing and slowing down the onset of frailty](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4933124/) | *The Journal of Physiology* (J Vina *et al.* 2016) | [11:00]

**The centenarian decathlon**: [How to Train for the “Centenarian Decathlon”](https://peterattiamd.com/how-to-train-for-the-centenarian-olympics/) | Peter Attia, PeterAttiaMD.com (January 18, 2022) | [15:15]

**Dallas bed rest study**: [Response to exercise after bed rest and after training](https://pubmed.ncbi.nlm.nih.gov/5696236/) | *Circulation* (B Saltin *et al.* 1968) | [21:00]

**30-year follow-up of the Dallas bed rest study**: [A 30-year follow-up of the Dallas Bedrest and Training Study: I. Effect of age on the cardiovascular response to exercise](https://pubmed.ncbi.nlm.nih.gov/11560849/) | *Circulation* (DK McGuire *et al.* 2001) | [21:15]

**Natural experiments and studies at the Cooper Clinic**: [Key Publications](https://www.cooperinstitute.org/published-research) | The Cooper Institute (2014) | [23:45]

**Muscle mass and strength declines with age**:

- [Differences among skeletal muscle mass indices derived from height-, weight-, and body mass index-adjusted models in assessing sarcopenia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4939509/) | *The Korean Journal of Internal Medicine* (KM Kim *et al.* 2016) | [19:00]
- [A cross-sectional study of loss of muscle mass corresponding to sarcopenia in healthy Chinese men and women: reference values, prevalence, and association with bone mass](https://pubmed.ncbi.nlm.nih.gov/23620096/) | *Journal of Bone and Mineral Metabolism* (Q Cheng *et al.* 2014) | [19:00]
- [The role of muscle loss in the age-related decline of grip strength: cross-sectional and longitudinal perspectives](https://pubmed.ncbi.nlm.nih.gov/2335723/) | *Journal of Gerontology*(DA Kallman *et al.* 1990) | [19:00]
- [Maximal isokinetic and isometric muscle strength of major muscle groups related to age, body mass, height, and sex in 178 healthy subjects](https://pubmed.ncbi.nlm.nih.gov/21537927/) | *European Journal of Applied Physiology* (T Harbo *et al.* 2012) | [19:00]

**Endurance cross country skiers from Scandinavia and mortality risk**: [Mortality and cardiovascular morbidity among long-term endurance male cross country skiers followed for 28-30 years](https://pubmed.ncbi.nlm.nih.gov/21477204/) | *Scandinavian Journal of Medicine and Science in Sports* (J Grimsmo *et al.* 2011) | [20:15, 35:00, 42:45]

**Study from the 50s of people who worked at a jute mill in India relating physical work and body weight**: [Relation between caloric intake, body weight, and physical work: studies in an industrial male population in West Bengal](https://academic.oup.com/ajcn/article-abstract/4/2/169/4787034) | *The American Journal of Clinical Nutrition* (J Mayer *et al.* 1956) | [25:30]

**Study of calorie consumption and energy expenditure in cyclists during the Tour de France**: [Study on food intake and energy expenditure during extreme sustained exercise: the Tour de France](https://pubmed.ncbi.nlm.nih.gov/2744926/) | *International Journal of Sports Medicine* (WH Saris *et a l.* 1989) | [26:00]

**Increased fitness results in a decrease in all cause mortality**: [Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing](https://pubmed.ncbi.nlm.nih.gov/30646252/) | *JAMA Network Open* (K Mandsager *et al.* 2018) | [34:15]

**Editorial by Jill Barnes**: [Physical Activity and Cardiovascular Risk: 10 Metabolic Equivalents or Bust](https://www.mayoclinicproceedings.org/article/S0025-6196(13)00922-1/fulltext) | *Mayo Clinic Proceedings* (JN Barnes and MJ Joyner 2013) | [37:30]

**Study of ultra-marathoners by Bill Haskell**: [Coronary artery size and dilating capacity in ultradistance runners](https://www.ahajournals.org/doi/10.1161/01.CIR.87.4.1076) | *Circulation* ( WL Haskell *et al.* 1993) | [39:30]

**Large NCI study found more leisure time physical activity associated with a longer life expectancy**: [Leisure Time Physical Activity of Moderate to Vigorous Intensity and Mortality: A Large Pooled Cohort Analysis](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1001335) | *PLOS MEDICINE* (SC Moore *et al.* 2012) | [42:30]

**Studies showing longer interval training increases VO****2** **max**:

- [Linear increase in aerobic power induced by a strenuous program of endurance exercise](https://pubmed.ncbi.nlm.nih.gov/838658/) | *Journal of Applied Physiology* (RC Hickson *et al.* 1977) | [47:00]
- [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182) | *PLOS ONE* (AP Bacon *et al.* 2013) | [47:00]
- [High-intensity interval training in patients with lifestyle-induced cardiometabolic disease: a systematic review and meta-analysis](https://bjsm.bmj.com/content/48/16/1227.long) | *British Journal of Sports Medicine* (KS Weston *et al.* 2014) | [47:00]

**Meta-analysis of the impact of interval training on VO****2** **max**: [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182) | *PLOS ONE* (AP Bacon *et al.* 2013) | [47:15]

**Dave Costell’s study of VO****2** **max in elite athletes 20 years after they retired**: [Aging among elite distance runners: a 22-yr longitudinal study](https://pubmed.ncbi.nlm.nih.gov/8847316/) | *Journal of Applied Physiology* (SW Trappe *et al.* 1985) | [49:45]

**Episode of** ***The Drive*** **with Lance Armstrong**: [#178 – Lance Armstrong: The rise, fall, and growth of a cycling legend](https://peterattiamd.com/lancearmstrong/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 4, 2021) | [59:15, 1:30:00]

**Episodes of** ***The Drive*** **with Iñigo San Millán**:

- [#85 – Iñigo San Millán, Ph.D.: Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/)  (December 23, 2019) | [1:00:30]
- [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/)  (March 28, 2022) | [1:00:30]

**Eliud Kipchoge’s metrics for running a marathon in under 2 hours**: [The likely physiology behind Ineos 1:59 project](https://inscyd.com/article/2019-9-26-physiologyeliudkipchoge/) | INSCYD (2021) | [1:02:30]

**RPE (rate of perceived exertion)**: [Training: What is RPE?](https://www.triathlete.com/training/what-is-rpe/) | Kelly O’Mara, Triathlete (July 14, 2020) | [1:17:30]

**Discussion of a polypill to mimic benefits of exercise**: [Mimicking exercise: what matters most and where to next?](https://physoc.onlinelibrary.wiley.com/doi/pdfdirect/10.1113/JP278761) | *The Journal of Physiology* (JA Hawley, MJ Joyner, DJ Green 2021) | [1:38:45]

**Sex differences in the regulation of blood pressure**: [Neurovascular control of blood pressure is influenced by aging, sex, and sex hormones](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5256972/) | *American Journal of Physiology: Regulatory, Integrative and Comparative Physiology* (SE Baker *et al.* 2016) | [1:39:15]

**Hypoxia studies in people with rare left-shifted hemoglobin**: [Impact of Pharmacologically Left Shifting the Oxygen-Hemoglobin Dissociation Curve on Arterial Blood Gases and Pulmonary Gas Exchange During Maximal Exercise in Hypoxia](https://pubmed.ncbi.nlm.nih.gov/34152867/) | *High Altitude Medicine and Biology* (GM Stewart *et al.* 2021) | [1:39:30]

**Jeff Bridges struggle with COVID**: [Jeff Bridges Says He Was ‘Pretty Close to Dying’ from COVID While in Chemo for Cancer](https://people.com/health/jeff-bridges-says-he-was-close-to-dying-covid-while-in-chemo/) | Mia McNiece, *People Magazine* (May 26, 2022) | [1:42:45]

**Review of use of Convalescent plasma to treat COVID-19**: [COVID-19 Convalescent Plasma and Clinical Trials: Understanding Conflicting Outcomes](https://journals.asm.org/doi/full/10.1128/cmr.00200-21) | *Clinical Microbiology Reviews* (D Focosi *et al.* 2022) | [1:41:00]

**Review of benefits of exercise on aging**: [Exercise Attenuates the Major Hallmarks of Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4340807/) | *Rejuvenation Research* (N Garatachea *et al.* 2015)

**Mike’s faculty webpage at the Mayo Clinic**: [Michael J. Joyner, M.D.](https://www.mayo.edu/research/faculty/joyner-michael-j-m-d/bio-00078027) | Mayo Clinic

**Mike’s website**: [Human Limits: Exploring performance and health with Michael J. Joyner, M.D.](https://www.drmichaeljoyner.com/)

§

## People Mentioned

- [John Shepherd](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3286675/) (visionary physiologists, former Professor at the Mayo Clinic) [6:15]
- [Alan Sessler](https://alumniassociation.mayo.edu/obituaries/alan-sessler-m-d-anes-62/) (chair of the Department of Anesthesiology at the Mayo Clinic from 1977 to 1988) [6:30]
- [Jeremy Morris](https://en.wikipedia.org/wiki/Jerry_Morris) (London epidemiologist) [11:00]
- [Benjamin (Ben) D. Levine](https://profiles.utsouthwestern.edu/profile/14262/benjamin-levine.html) (Distinguished Professor of Exercise Sciences, UT Southwestern Medical Center) [21:15, 44:30]
- [Jerry H. Mitchell](https://www.utsouthwestern.edu/newsroom/articles/year-2021/in-memoriam-mitchell.html) (Exercise physiologist and former director of the Harry S. Moss Heart Center at UT Southwestern Medical Center ) [21:15]
- [Lester Breslow](https://en.wikipedia.org/wiki/Lester_Breslow) (famous epidemiologist from UCLA) [23:00]
- [Frank Booth](https://biomed.missouri.edu/frank-w-booth-phd/) (Professor of Physiology and Pharmacology in the School of Medicine at the University of Missouri) [37:30]
- [Jill Barnes](https://www.adrc.wisc.edu/jill-barnes-phd-0) (Professor of Kinesiology at the University of Wisconsin) [37:30]
- [William (Bill) Haskell](https://med.stanford.edu/profiles/william-haskell#bio) (Emeritus Professor of Medicine at Stanford University Cardiovascular Institute) [39:30]
- [Ulrik Wisløff](https://www.ntnu.edu/employees/ulrik.wisloff) (Professor of Exercise Physiology at the Norwegian University of Science and Technology) [47:15]
- [David (Dave) Costell](https://www.bsu.edu/academics/centersandinstitutes/hpl/people/facultydirectory/emeritus/costilldavid) (Emeritus Professor of Exercise Science at Ball State University) [48:45]
- [Eskild Ebbesen](https://en.wikipedia.org/wiki/Eskild_Ebbesen) (Danish lightweight rower won 5 Olympic medals) [56:00]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (cycling legend) [59:15, 1:30:00, 1:33:15]
- [Bob Schul](https://en.wikipedia.org/wiki/Bob_Schul) (won an Olympic gold medal for 5,000 M) [1:00:00, 1:08:80]
- [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun) (won Olympic silver medal in 1,500 M) [1:00:15]
- [Iñigo San-Millán](https://www.inigosanmillan.com/about-me) (Professor at the University of Colorado School – Colorado Springs, expert in metabolism and exercise physiology) [1:00:30]
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) (cyclist won the Tour de France in 2020 and 2021) [1:00:30]
- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) (Kenyan long distance runner set the world record for the marathon) [1:02:45, 1:24:30]
- [Bill Rodgers](https://en.wikipedia.org/wiki/Bill_Rodgers_(runner)) (former record holder for the marathon) [1:03:45]
- [Frank Shorter](https://en.wikipedia.org/wiki/Frank_Shorter) (won an Olympic gold medal in the marathon) [1:03:45]
- [Klay Thompson](https://en.wikipedia.org/wiki/Klay_Thompson) (NBA player) [1:04:00, 1:25:00]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) (Olympic swimmer, won 28 medals) [1:22:15, 1:28:15]
- [Bob Bowman](https://en.wikipedia.org/wiki/Bob_Bowman_(coach)) (Michael Phelps coach) [1:24:00]
- [Edwin Moses](https://en.wikipedia.org/wiki/Edwin_Moses) (track and field athlete, won 2 Olympic gold medals) [1:24:30]
- [Stephen (Steph) Curry](https://en.wikipedia.org/wiki/Stephen_Curry) (one of the greatest basketball players of all time) [1:25:00]
- [Stan James](https://medicine.uiowa.edu/alumni/content/stan-james-md) (Orthopedic surgeon, pioneer in sports medicine) [1:26:30]
- [Bill Bowerman](https://en.wikipedia.org/wiki/Bill_Bowerman) (Track and field coach and co-founder of Nike) [1:26:45]
- [Katie Ledecky](https://en.wikipedia.org/wiki/Katie_Ledecky) (Olympic swimmer, won 7 gold medals) [1:29:16]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) (widely regarded as the greatest quarterback of all-time) [1:29:30]
- [LeBron James](https://en.wikipedia.org/wiki/LeBron_James) (widely regarded as one of the greatest NBA players of all-time) [1:29:30]
- [Eddy Merckx](https://en.wikipedia.org/wiki/Eddy_Merckx) (former professional cyclist, won the Tour de France 5 times) [1:29:45]
- [Patrick Arnold](https://en.wikipedia.org/wiki/Patrick_Arnold) (organic chemist, produced anabolic steroids involved in the BALCO scandal) [1:33:15]
- [Victor Conte Jr.](https://en.wikipedia.org/wiki/Victor_Conte) (Former bassist with Tower of Power) [1:34:45]
- [Sarah Baker](https://www.researchgate.net/profile/Sarah-Baker-23) (scientist at the Mayo Clinic Department of Anesthesiology, collaborator with Mike) [1:39:15]

§

![](https://peterattiamd.com/wp-content/uploads/2022/07/bio-pic-mikejoyner-500x500.jpeg)

##### Mike Joyner, M.D.

Michael J. Joyner, M.D. earned both his undergraduate and medical degrees from the University of Arizona.  He completed his internship and residency at the Mayo Clinic College of Medicine in Rochester, Minnesota, where he continues to practice anesthesiology.

Dr. Joyner is a Professor of Anesthesiology at the Mayo Clinic with a joint appointment in the Department of Physiology & Biomedical Engineering.  He has held numerous leadership positions, and is the Frank R. and Shari Caywood Professor of Anesthesiology.  He is also the Vice Chair for Research in the Department of Anesthesiology and Perioperative Medicine.

Dr. Joyner is an expert in human performance and exercise physiology.  His lab is interested in how humans respond to various forms of physical and mental stress during activities such as exercise, hypoxia, standing up and blood loss.  Dr. Joyner and his team study how the nervous system regulates blood pressure, heart rate and metabolism in response to these forms of stress. They are also interested in how blood flow to muscle and skin responds to these stressors. These responses are studied in young healthy subjects, healthy older subjects and people with conditions such as heart failure.

By studying normal physiology and how it is affected by aging, sex and disease, Dr. Joyner and his colleagues gain insight into what body systems are potential therapeutic targets for intervention. Their research also provides insight into the many complex mechanisms that operate together to keep us healthy and able to adapt to the demands of life — or fail in a way that makes us unable to adapt.

Dr. Joyner’s research has been funded by the NIH since 1993.  The Mayo Clinic name him a Distinguished Investigator in 2010.  Dr. Joyner has been a consultant to the NIH and NASA and has held leadership positions with prestigious scientific journals.

Dr. Joyner has a keen interest in how new ideas emerge, fade and then re-emerge in physiology. And he is a forceful advocate for integrative approaches in science as a powerful tool to integrate and critique data from reductionist approaches. [[Mayo Clinic](https://www.mayo.edu/research/faculty/joyner-michael-j-m-d/bio-00078027) and [DrMichaelJoyner.com](https://www.drmichaeljoyner.com/)]

Twitter: [@DrMJoyner](https://twitter.com/drmjoyner)