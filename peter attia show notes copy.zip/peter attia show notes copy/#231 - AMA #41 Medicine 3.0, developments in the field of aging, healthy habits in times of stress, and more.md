# #231 – AMA #41: Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more

**Source:** [https://peterattiamd.com/ama41/](https://peterattiamd.com/ama41/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide variety of questions, starting with a discussion on the evolution of medicine and the hopeful transition to “Medicine 3.0.” Peter recounts his unique career path and explains how he assesses risk and utilizes frameworks for decision-making. He also describes how he prioritizes his health while navigating the stresses of life, and he reviews the most exciting developments in the aging and longevity space. He finishes with some rapid-fire questions on cold plunging, strategies for lowering apoB levels, designing an exercise program for beginners, and more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #41 show notes page](https://peterattiamd.com/ama41). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The evolution of medicine and the transition to “Medicine 3.0” [3:00];
- Peter’s unorthodox career arc and what led him to this point [11:45];
- What does Peter consider to be his superpowers? [22:15];
- How Peter thinks about risk and explains it to his patients when making medical decisions [26:45];
- The advantage of using frameworks for decision-making [37:00];
- What advice would Peter give his 30-year old self? [42:15];
- Why longevity is such a hard problem to solve [42:30];
- The most impactful developments in the field of longevity and aging in the last 5 to 10 years [46:15];
- What is Peter most excited to see develop in the health and longevity space in the next few years? [51:30];
- Prioritizing healthy habits while navigating the stresses of life and time constraints [53:45];
- How Peter navigates periods of high stress [58:00];
- What fitness watch did Peter recently purchase? [1:03:45];
- Potential benefits of cold plunging [1:05:15];
- Advice for someone beginning an exercise program [1:07:30];
- Strategies and tactics to lower apoB levels [1:09:00];
- Interesting studies and books Peter has recently read [1:11:30]; and
- More.

§

The Peter Attia Drive

Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more

§

## Show Notes

§

## The evolution of medicine and the transition to “Medicine 3.0” [3:00]

**Evolution of medicine from Medicine 1.0 to 2.0 to 3.0**

**Medicine 1.0** is when we had no idea of science

- Science is a way of thinking—not a person, not an answer—science is a process
- It’s a way that we look at the natural world around us and formulate hypotheses about what explains them based on the physical principles of the universe
- We design experiments to test those hypotheses and we measure the results of those experiments against the predictions of the hypotheses
- and then we iterate and correct
- However, evolutionarily, we’re not naturally wired to do that
  - See article by Peter: [Why We’re Not Wired To Think Scientifically](https://peterattiamd.com/wired-think-scientifically-can-done/)
- Prior to the invention of this idea, nothing that existed in medicine could be tethered to science
- Any time something happened, you had to come up with an explanation
- But none of it could be linked to scientific fact or verifiable or testable hypotheses
- This is where you had all sorts of crazy ideas

**Medicine 2.0**

- Medicine started to change in the late 17th century with [Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon)
- Peter would argue that the full transition to medicine 2.0 didn’t actually take place until the advent of [germ theory](https://en.wikipedia.org/wiki/Germ_theory_of_disease) in the late 19th century
- So that’s about a 200 year period where [Joseph Lister](https://en.wikipedia.org/wiki/Joseph_Lister) all the way up to [Alexander Fleming](https://en.wikipedia.org/wiki/Alexander_Fleming) and the discovery of penicillin and antibiotics
- This was the breakthrough of medicine 2.0 which basically comes from three things:
  - 1 – the advent and acceptance of germ theory
  - 2 – the process of scientific thinking
  - 3 – The statistical machinery to enable randomized control trials (the “crown jewel of medicine 2.0”)
- But Peter believes we’ve reached a plateau with medicine 2.0: “*Medicine 2.0 has been an amazing development. I don’t want to minimize it, but I want to acknowledge [that] Medicine 2.0 has really peaked*.”
- It’s been very good at dealing with acute conditions
  - I.e., You get hit by a car, you have a life threatening infection, you suffer an MI, myocardial infarction and you want to make sure someone doesn’t die and you want to keep somebody alive as long as possible in that acute phase

> “We have reached the limits of medicine 2.0 capacity, and if longevity is something we are aspiring for, we need a new strategy.” —Peter Attia

**Medicine 3.0**

- We need a fundamental shift just like 1.0 to 2.0, we need to go from 2.0 to 3.0
- Medicine 3.0 is basically predicated on *evidence informed* as opposed to *evidence based* guidelines
- It is predicated on absurdly early preventative measures for chronic conditions (not acute conditions), which are now the dominant source of morbidity and mortality
- Medicine 3.0 has to be highly personalized
- We’re not yet in medicine 3.0, but we’re in that transition and Peter thinks we should be accelerating that

*When you think about that transition, do you have an idea of how far out you think medicine 3.0 is?*

- Too soon to say as it’s going to depend on how quickly people adopt and demand change

## Peter’s unorthodox career arc and what led him to this point [11:45];

Peter has an interesting career path with many different experiences that has shaped his thinking and brought him to where he is today with his medical practice

A lot of what Peter does your patients didn’t necessarily come from what he learned in med school or residency

So ***how did he get to where he is today?***

- When he finished high school, the only thing he was interested in was math and science
  - He wanted to follow in the footsteps of his  most influential teacher, who was himself an engineer, but then who later went on to teach math
  - The perfect fit for that was this a program that existed in Canada, where you could pick the engineering discipline and then couple it to an applied math degree
  - So he did mechanical engineering and applied math
  - The plan was always to then go and do a PhD in aerospace engineering which was really the perfect merger of mechanical engineering and mathematics through a particular discipline of math called called [Control theory](https://en.wikipedia.org/wiki/Control_theory)
- However, in his final year as he was in the process of applying to the PhD programs in aerospace, he just had a total change of heart and decided he wanted to be a doctor
  - Peter says that it was a “very bizarre change of heart” because he’d never shown any aptitude or interest in biology
  - This changed created a whole bunch of problems because he lacked the credits to apply to medical school
  - So after graduating with an engineering degree, he studied on his own for the MCAT to take it that summer graduation
  - That year he taught calculus while he took all the prerequisites for medical school (Bio 101, Psych 101, Biochemistry, etc.)
  - It was funny b/c he was taking all these freshman courses while teaching the freshman calculus (prof at night and doing labs with his students during the day)
- Eventually, he got into medical school and while in medical school with the intention of doing pediatric oncology
  - But once in clinical rotations he realizes he wants to be a surgeon instead focusing on either surgical oncology or cardiac surgery
  - Deciding between surgical oncology or cardiac surgery was a hard decision b/c he went to med school at Stanford, which is one of the powerhouses of cardiac surgery
  - But he realized that whether he’s going to do surgical oncology or cardiac surgery, all roads go through general surgery and therefore the best general surgery program at the time was at Johns Hopkins
  - Five years into that road, he has another change of heart that he doesn’t even want to do medicine (he said he was “burnt out”)

***What was the underlying reason for burnout with medicine?***

- In large part, although he didn’t know it at the time, he’s completely burnt out because of what he now perceives are the failures of medicine 2.0, which is, *we are so good at putting bandaids on bullet holes and we are so bad at fixing the underlying problem*
- Peter couldn’t resolve that internal conflict
- His wife, sensing how miserable he was, basically said either you need to fix this problem or you need to get out of medicine altogether
- Peter thought “I can’t fix this” — he had no delusions about his ability to do so, so “*I’m getting as far away from this as possible*.”

***So what’s next?***

- He thought it was too late to go back to engineering after being out of it for 10 years
- He thought about going back and doing an MBA, but he didn’t want to assume any more debt
- That’s when he discovered [McKinsey & Company](https://en.wikipedia.org/wiki/McKinsey_%26_Company), which is a consulting firm
- They sample liberally from Harvard and Stanford Business School, but they also will pluck out the odd MD, PhD and JD who they think that they can train
- So he ended up doing that and absolutely loving that experience
- He was recruited there to do was medicine/healthcare consulting, but most of what he did there was risk
- And that ability to do risk really stemmed from his background in math as well as the nature of what McKinsey as a company was being bombarded with from clients
- This was in 2006, 2007, 2008 when there was a lot happening in the risk world
- You had some credit risk things that were going on in the buildup and then of course the mortgage meltdown
- There was this enormous demand for quantitative risk tools

**Post McKinsey and renewed interest in health**

- He very reluctantly left McKinsey to join a startup energy company that was a hybrid energy biotech company that was working on a biofuel strategy based on genetic engineering
- He did that for 4 years
- But it was during this time at the energy company that he became very interested in health again
- Health at that point became a night weekend passion for him

**Peter’s re education on nutrition**

- “*That’s really when my education began. That’s when I began reading about nutrition*.” says Peter
- He really began trying to understand nutrition and then eventually lipids and then eventually cancer and metabolic health
- That learning process ultimately it led to him starting to work with clients
- At this point, it was more of a consulting side business where he would review all of patients’ medical information and make recommendations to their doctors
  - Peter says that that business was not very satisfying because he really couldn’t make changes based on that type of recommendation strategy

**A new medical practice**

- Peter had never let his medical license lapse
- So by about 2013, he excitedly came back to doing medicine in a totally different capacity and in a capacity that has zero resemblance to what he did in the past
- To do this new practice, he effectively required a whole new training program
- To understand lipids, he had to basically seek out lipid experts
- He met [Tom Dayspring](https://peterattiamd.com/tomdayspring6/) in 2011 and by 2013, he probably knew more about lipids than had he trained in internal medicine and even done a lipid fellowship
- He luckily had unfettered access to guys like Tom, [Ron Krauss](https://peterattiamd.com/ronkrauss/), [Allan Sniderman](https://peterattiamd.com/allansniderman/), and [Tara Dall](https://taradall.com/) as mentors
- The same was true once he wanted to learn about hormones, nutrition, exercise and all these other things

> “Basically my superpower is to figure out who the smartest people are and just extract as much information as possible.” —Peter Attia

**Eating Academy blog**

- During the time he was interested in nutrition, doing those marathon swims, and more – Peter started sending emails to just friends with his insights
- Those emails eventually turned into version 1 of his online blog, which was called Eating Academy
- Circa 2010, I just basically start an email list to friends who are asking, hey, can you share these insights with us?
- Ultimately, that old blog turned into the new website (peterattiamd.com) where Peter and [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) wrote together
- That lasted for a few months until they realized the time intensity was too much
- Then it was eventually transitioned in July 2018 to the [podcast](https://peterattiamd.com/podcast/) which leads us to today

## What does Peter consider to be his superpowers? [22:15]

**A question Peter likes to ask people is: “*****What’s your superpower? What’s your kryptonite?*****”**

**Nick turns the question around on to him**:

1 – Peter says he doesn’t have any pride when it comes to acknowledging what he doesn’t know and finding someone who knows more

- Peter has a knack for sniffing out people who are really good at something
- He has the power of approaching them in a way that makes them really receptive to share their knowledge with him

2 – The other “superpower” is his high capacity to integrate information across disparate areas

- Peter enjoys knowing a lot about a lot and can accept not knowing the most about anything
- Peter likes to learn from people who truly know more than anyone on a topic — “Their subject matter depth is so insanely deep that they are among the best in the very world”.
- Peter is trying to get within 90% of the knowledge of those type of people across as many areas as possible
- This “superpower” fits nicely into the concept of The Drive Podcast – which is bringing in experts and gleaning as much from them as possible

*Peter’s knowledge goal:*

- A lot of people’s knowledge is a “mile wide and inch deep”—that’s the person who’s incredibly superficial knowledge, but about everything
- Then you’ve got the “inch wide mile deep”—those are the best in the world
- Peter’s goal is to be “half a mile wide and half a mile deep”

Nick says another “superpower” of Peter is his ability to **think in “frameworks” and to assess risk**

- Nick says that Peter has “*a natural curiosity, with that curiosity has to come from a place of no ego where you might have gone into having a question, thinking one thing, and you have to completely revert*.”
- Peter credits his time at McKinsey for this
- Peter really was hooked by McKinsey’s relentless rigor of thought and stressing of the importance of structured thinking

## How Peter thinks about risk and explains it to his patients when making medical decisions [26:45]

- Risk mitigation is very important
- Discussed on the [podcast with Allan Sniderman](https://peterattiamd.com/allansniderman/)) – there’s a big difference between 10 year risk and 30 year risk
- While a 40 year old might have a low 10 year risk, he could have a significant 30 year risk
- This has implications if longevity is the goal

*Real life examples of how Peter talks through risk*

- While Peter may take some risks professionally with his career, he says deep down he’s always calculating risk
- For instance, he was invited to do heli-skiing recently and he knew immediately his answer was “no”
- That’s because the risk of doing it is much higher (injury, death) to Peter than the risk of not doing it (missing out on an amazing experience)
- For Peter’s skill level, that’s a “very asymmetric risk equation” says Peter
- Conversely, there are things Peter does, like driving race cars, that many people think is insanely risky
- But with his understanding of how to drive a race car, his understanding of the true risk doing that in certain settings is such that he believes the risk is exceedingly low
- Now that might not be true for another person
- But a big part of driving for Peter is knowing where his limits are and driving within his limits, and if he exceeds his limits, only doing so in an area where exceeding the limit has a low consequence
- The race car example is analogous to how he thinks about everything, including medicine
- Where is it that, if he makes a mistake, are the consequences very low versus the consequences being enormous?
- And it’s in that understanding of where the risks are symmetric and where the risks are asymmetric.

***Nick asked Peter to talk through it in a way that someone who’s listening to this can apply it to their own health journey…***

Common example: Brand new patient, 60 years old

- Family history is incomplete meaning clear blind spots
- But one thing we know is his older brother did have a stroke in his 60s
- Patient has had one calcium score in his life, circa 2018, and it was super lower with a score of 4
- This means DOES have calcification in his coronary arteries, but as a then 56 year old to have a calcium score of four is still pretty low risk
- Lipids are really high
- LDL cholesterol, non HDL cholesterol, and apoB are all concordant at the 90th percentile
- The patient’s previous doctor determined (most from the CAC score) that this isn’t really high enough risk
  - The doctor erroneously determined his lipids are high but not too high
  - In other words the doctor didn’t actually understand how high his lipids were (he’s actually at the 90th percentile)
    - (Peter actually carries with him a reference card which shows both [Framingham](https://www.lipidcenter.com/pdf/Framingham.pdf) and [MESA](https://twitter.com/Drlipid/status/1579111715379085313/photo/1) percentile rankings for every lipoprotein)
  - Peter finds it amazing that this patient has never been offered lipid lowering medications
  - The other reason that the doctor didn’t offer him any lipid lowering medications is he is otherwise quite a healthy guy
    - He’s lean, he’s not overweight, he doesn’t have a lot of the hallmarks of metabolic ill health
  - The patient and the doctor agreed that nothing was really warranted here
- Peter then proceeded to spend the next hour with his clinical team explaining to the patient that that’s the wrong conclusion
  - Peter told him “if you want to do nothing about your lipids, that’s fine, but I want to make sure you’re doing it through the lens of understanding causality”
  - That means you have to understand that **apoB is the causative agent in atherosclerosis**
    - (And along with hypertension and smoking is one of the three largest drivers of this condition)
  - He’s got this sky high apoB, and there’s already evidence of damage to his coronary arteries
  - He’s not somehow genetically immune to this, which it does appear that there are some people who are
- Then the question becomes, ***what’s the bigger risk?  Leaving this untreated or treating it?***
  - There are risks to both — everything has a risk
  - Doing nothing has a risk, and doing something has a risk
  - We have to quantify them both to the best of our ability to be able to paint a pretty good picture for him about what doing nothing has a risk of, which is in the next 10 years, your risk of an event is X
  - He’s now old enough that his 10 year event risk is actually more than 5%
  - He technically should be treated even by medicine 2.0 standards
- Peter explained to him the risks of each scenario starting with the question of *Is it a reversible or irreversible problem?*
  - When you do nothing here, you suffer an MI, you can die — That’s an irreversible outcome.
  - Most people who believe lipid lowering meds are dangerous are overstating the risks, says Peter
    - But we will acknowledge that there’s a 5% chance of intractable muscle soreness
    - Let’s also acknowledge that there’s a 1% chance of type 2 diabetes
  - But these things are totally reversible
    - Muscle soreness comes on within weeks and vanishes within weeks when you stop the drug
    - Type 2 diabetes doesn’t come on like a step function, it comes on slowly
    - And if you know what to monitor, you can keep an eye on it —
      - for instance, some patients on statins will have glucose homeostasis breakdown
      - And in that case Peter will change the statin or we stop the statin
  - In other words, **the asymmetry on the other side is so different**
- This gets back to make a mistake in an area where it’s easy to fix the mistake
  - Don’t make a mistake in an area where you can’t fix the mistake
  - This is how you talk about risk and apply it to medicine

## The advantage of using frameworks for decision-making [37:00]

Peter says his framework thinking was developed from working at McKinsey & Company — “*I suspect this came out of the intensity of having to learn so much new content over and over and over again, and realizing that I couldn’t do it without a scaffolding*.”

- Peter learned to quickly create a scaffolding for every problem so that he could anchor new information to it
- And he still does this today

A common example: A patient will tell Peter he is considering supplement X and asks Peter his thoughts

- You could think of this as for any exogenous molecule, so supplement drug hormone.
- Peter sends the patient an eight question framework and tells them to go through it and then let’s discuss
  - What is the objective? The more clearly you can define your objective, the more clearly you can assess if this is the right tool for accomplishing that objective
  - Is there a biomarker? How do you plan to customize, track, and adjust your treatment over time? If there is no biomarker to monitor as a measure of effectiveness, it doesn’t mean you shouldn’t take the supplement or medication; it just means you may need to be more intentional about monitoring results in other ways.
  - Does the risk outweigh the reward? Everyone has a different tolerance for risk. Some questions to consider when weighing risk vs. reward: Is the mechanism of action well understood? How many patient-years of use exist? What are the short- and long-term risks of taking the medication? What are the risks of not taking the medication?
- 9 times out of 10, they answer the question for themselves
- In other words, when they go through the exercise, they come away going, “okay, I think I know the best answer here”
- A really good framework basically should allow the user to come up with the answer on their own.

> “A good framework teaches you how to fish, it doesn’t hand you the fish.” —Peter Attia

\*\*\*

[Jerky Boys](https://www.youtube.com/watch?v=f1RPDbcOfqY)

[Frank Rizzo IS BACK!](https://www.youtube.com/watch?v=mIuA3QkvnFU)

## What advice would Peter give his 30-year old self? [42:15]

***If you have a time machine, you can go back to your 30 year old self, you can give health advice, what would you say?***

Peter says this is challenging because there’s a high likelihood that he wouldn’t have listened so the advice would fall on deaf ears

- He thinks perhaps he’d look himself in the eyes and just say…
  - “It’s going to be okay, it’s going to work out”
  - “You don’t know what you’re in store for. There’s going to be moments where you think it’s awful, but it’s all going to work out, just put your head down and do it.”
- Alternatively, he might say, “Look, dude, get some mental health help.”

“*If I thought he would’ve listened, I would offer more advice, he wouldn’t have listened, so I don’t think it’s worth it*.”

## Why longevity is such a hard problem to solve [42:30]

Peter has said before that longevity is a really hard problem to solve

*What does he mean by that?*

- Biology is just more complicated than physical sciences
- Biological sciences versus physical chemistry, organic chemistry, physics, it’s just messier in general and the systems are noisier.
- It’s harder to study
- It’s harder to control
- It’s harder to make causal inference

“*I’m not aware of a system for which it’s harder to make a causal inference than studying the impact of relatively simple inputs on, for example, the human body.*”

**Simple example**: Think about the simplest things that we can’t really understand what the long term effect is of drinking three coca-colas a day

- We can speculate what it is based on some short term data, based on some mechanistic data, based on some animal data, however, you can’t tell someone for certain that if they drink a gallon of Coke a day they’re going to get cancer, heart disease, or diabetes
- But we can’t tell you that with any certainty

Think about it… *What is a gallon of Coca-Cola?*

- It’s literally nothing more than fructose and glucose, the simplest molecules in organic chemistry.
- But what they do when they get into your body, over a long enough period of time is not really known
- If we can’t do that, how the heck are we going to figure out all the nuances of how to dose exercise, how to dose nutrients, how to dose every medication?

All of these other things that we think about into a system that is so noisy and so chaotic and has so many degenerative changes that are occurring?

- Mitochondrial function is going down
- Nutrient sensing function is going down
- We don’t even really understand why they’re happening
- That’s basically why “longevity” is a harder problem than any other problem

> “This problem is so hard, it will forever keep me interested.” —Peter Attia

## The most impactful developments in the field of longevity and aging in the last 5 to 10 years [46:15]

If you really limit this question to pure [geroscience](https://en.wikipedia.org/wiki/GeroScience), Peter reluctantly says the answer might be some of the insights we have around epigenetic modifications

- Peter “hates to say it” because he thinks that it gets so much hype and it’s nowhere near as relevant on a practical level as people make it out to be
- On a scientific level, it’s quite interesting

**PCSK9 inhibitor**

- Peter thinks that if we just used PCSK9 inhibitors correctly, we would make atherosclerosis the 10th leading cause of death as opposed to the #1 cause of death
- Atherosclerosis is the number one cause of death and the gap between atherosclerosis and cancer is even bigger worldwide than it is in the US
- “*If we simply took this tool that exists, PCSK9 inhibitors, which have no side effects and obliterate apoB, and we started injecting them into people when they were 30 and taking everybody’s apoB when they were 30 down to 30 or 40 or 50 milligrams per deciliter, I would argue that ASCVD would be the 10th leading cause of death as opposed to the leading cause of death*”
- Of course, we still need to make sure we control people’s blood pressure and ensure that they don’t smoke, but we’re already doing those things
- PCSK9 inhibitors are an amazing tool and why we’re not using them more is another entire topic of discussion

**GLP-1 agonists and related drugs**

- Peter thinks GLP-1 agonist and related drugs have the potential to revolutionize obesity (and things that come with obesity ranging from orthopedic to the metabolic)

**Back to PCSK9 inhibitors**: *What’s the quick version of why we’re not using PCSK9s more?*

The primary issue is something Peter can’t understand, which is, *Why it is with cigarettes and blood pressure we have no difficulty treating causative agents and yet with apoB we don’t?*

- When a person smokes, we don’t wait until their 10 year risk of heart disease or lung cancer is 5% to tell them not to smoke
  - Why? Because we understand causality
- Similarly if a 30 year old goes into the doctor and their blood pressure’s 140/90, will the doctor try to treat that right away whether with lifestyle or medication
  - And if a year from now your blood pressure is still 145/95, you’re definitely going on medication to lower your blood pressure at the age of 30
- Any doctor who didn’t do those two things would be guilty of malpractice

Yet, for some reason, when a 30 year old shows up with extremely high apoB or their LDL cholesterol, very few doctors would treat that

- That suggests a failure of the medical system — “*Arguably one of the biggest failures of the medical system*.”
  - Because it means we are failing to treat causative agents and we are instead, from the standpoint of lipids, relying on a risk calculator
- And it’s true, there’s no 30 year old who could have high enough lipids to cross a 5% threshold in the next decade, yet they have the causative agent sitting right there
- Until that issue is addressed, all the other stuff about cost becomes irrelevant
- Because you don’t need a PCSK9 inhibitor to do this. You could do this with statins
- The thing is that statins come with all the stigma associated with the 5% of people who get side effects, and probably another 10-15% of people who have placebo with nocebo side effects as well

## What is Peter most excited to see develop in the health and longevity space in the next few years? [51:30]

***What areas are you most excited to see develop in the next five to 10 years? Does anything jump out?***

There are some pretty amazing drugs that we don’t understand why they work fully

- [Canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin#:~:text=Canagliflozin%2C%20sold%20under%20the%20brand,together%20with%20exercise%20and%20diet.) (an SGLT-2 inhibitor)
  - This ia a drug that really just controls blood sugar, yet seems to have all of these profound effects on kidney health, heart health, and longevity ([ITP study](https://insight.jci.org/articles/view/140019))
  - Understanding why that works would be great
- The study of **metabolomics** ([podcast episode #216](https://peterattiamd.com/joshrabinowitz/)) is another example of something we know works, but we have no clue how they work
- We know **exercise** works, but we have no idea really why it’s working so potently
- And as a result, we don’t really have ways to tweak the system and make it better

Something in the future that’s really interesting: *Could we create molecules to augment the benefits of things that we know work by doubling down on certain pathways?*

***Peter’s issue with putting too much stock into this type of stuff…***

- Peter’s problem with getting too much into this is that a lot of people, his patients included, tend to get distracted by that type of thinking
- That becomes very attractive and it comes at the expense of doing something today
- “*One of the challenges in longevity is being focused enough on what we can do today with no other development or scientific breakthrough that is incredibly powerful to impact the length and quality of our lives while at the same time maintaining enough interest and optimism around the technologies that we hope will foster that*.”
- “*Those two states can coexist, but usually people just want to be exclusively in one camp.*”

## Prioritizing healthy habits while navigating the stresses of life and time constraints [53:45]

***How do people make changes towards longevity while at the same time enjoy life?***

***How do people, say, choose exercise vs. sleep when both are important but only really have time to focus on one or the other?***

Peter would divide his answer into two categories:

- One is there’s a season in your life for many different things and those seasons will change
- There’s that idea, which is you’ll have periods of high stress, periods of low time, periods of low stress lots of time
- One is, what’s your strategy for the ebbing and flowing of life?

Now that’s a little bit distinct from the second point raise, which is, *what’s your strategy for straddling the balance between short-term pleasure and long-term pain?*

- Starting with the latter (short term pleasure)…
- It’s pretty clear that
  - i) many things that in the short term that are very pleasurable will cost you dearly in the long term, and
  - ii) that many things that in the short term are uncomfortable and unpleasant, in the long term will yield huge dividends
  - At the risk of stating the obvious, neither extreme makes sense

In other words, if Peter were to say to Nick, “I’ve got this intervention, where you need to sit in a dark room for 23 and a half hours a day, cross-legged, not eating, not seeing another human being, just chanting, but you will live to 200”… Would you do it?

- Nobody in their right mind would do that
- The short term pain there is so great it is not worth any long term gain

Conversely if Peter were to say, “You can have the greatest month of your life, you won’t need to sleep, we’re going to give you enough cocaine to keep you awake for 30 straight days. You can eat whatever you want. You can have whatever hedonic pleasure you want and in 30 days you will drop dead.” … Would you do that?

- It’s hard to imagine many people would say yes

Intrinsically we deep down understand that there has to be a place that you live somewhere on that continuum

- But many people do not spend enough time thinking about it
- When Peter looks at a person who’s averaging 5 or 6 alcoholic beverages every single day, in the short term they can convince themselves that they just happen to love alcohol and they really love to pair the perfect wine with the perfect dinner
- Peter would push back and say, “I don’t think that’s true. I don’t think you are discounting enough what that’s going to do to you in the long run. . .I bet that you could get just as much pleasure from two drinks a day if you still feel the need to drink that much as you do from five or six drinks a day.”
- So Peter just tries to handle these on a case by case basis with people when he trying to identify what their jugular issue is

For instance:

- Is it too little sleep? Is it too much alcohol? Is it too little exercise? Is it too much food? What’s the issue that is their short term source of pleasure?
- Then he tries to understand: what is the long term consequence of that to the best of our abilities and how can we help the person understand that trade off?

## How Peter navigates periods of high stress [58:00]

**Ebbs and flows of life:**

- Life ebbs and flows and there are times when you can go all out and there are times that you can’t
- And knowing **when** is really important

Quick story: There was this surgeon named Rich Alexander that Peter really loved operating with

- When you were doing really, really complicated cases with him, he would always just say “fast on the straight away, slow on the curves, fast on the straight away, slow on the curves.”
- He wanted you to be as fast as possible **when the stakes were really low**
- But when you were dissecting the portal triad, for example, you were going really slow, because the **stakes were really high**

***Peter uses a personal example of how he’s trying to finish his book…***

- The last few months have been really tough trying to finish the book (multiple projects, seeing patients, etc.)
- And also the next 12 months have a lot more going on than he would like

*So how does Peter navigate that?*

- Peter knows that his stress levels are being amplified which means one of my five buckets is out of equilibrium (buckets being: Nutrition, sleep, exercise, stress and emotional health, and medications or supplements like drugs, exogenous molecules)
- So the book thing is this externality that is disrupting one of those buckets
- So now Peter has to think about “how do I compensate for them on the other four?”
- And he has a clear pattern for this
  - First, he acknowledges that that one bucket’s going to suck
  - Note that Peter knows his stress is elevated as he is checking his blood pressure twice a day and it’s running 5 to 10 points higher than normal (despite his breathing exercises and other stress reducing routines)
  - That tells Peter that there is all the more reason to really pay attention to exercise and sleep
  - Then the one area where he’s letting much more go with nutrition — “I’m just being way less dogmatic about nutrition”
    - “*I’ve made a concession, I’ve made a concession very deliberately, but I’ve also made sure that three areas are as good as they can be*.”
  - For sleep, he uses pharmacology and sauna
    - He will take trazodone and try to couple that sauna before bed — “*I’ve never had better sleep in my life*”
  - He also ensures he’s really focusing on keeping up with exercise

So in summary, Peter says his “control” over his stress and nutrition might be lower than normal (like a 7 out of 10), but he dials in on his sleep and exercise

- Peter says, “*I live with that and know that I don’t want to do any more damage than is necessary. I’m in damage control mode and not profound growth mode*.”

***How often are you reevaluating those buckets? Is that a daily thing, a weekly thing, a monthly thing?***

- They move at different cycles, says Peter
- Pharmacologic supplement stuff probably gets evaluated every time he does blood work
- He also just does certain things are based on feeling
- For example, he might notice he is carrying so much more tension in his neck, postsurgery, and he’s become really thoughtful about using a muscle relaxant called [Baclofen](https://www.mayoclinic.org/drugs-supplements/baclofen-oral-route/description/drg-20067995#:~:text=Baclofen%20is%20used%20to%20help,certain%20injuries%20to%20the%20spine.)
  - It’s a great muscle relaxer without the horrible side effects of benzos or really potent muscle relaxants
  - Peter says he will take Baclofen periodically and it completely takes away an early rising tightness in his traps, for example, that used to turn into really horrible aches
  - He might combine that with tissue work, movement work, and “*you can immediately put this little thing out when it’s a tiny ember as opposed to letting it become a big flame*”

*Frequency of evaluation*:

- With nutrition and exercise, Peter’s evaluating those every day
- With sleep, he’s also looking at that every day
- With stress and mental health, he’s evaluating at least weekly

**Of those five buckets, you’ve talked a lot recently about how exercise is the most important drug we have for longevity…**

*Are you much more apprehensive to turn down exercise compared to those others or is it truly one of those you just have to reevaluate all five all the time?*

- Peter does think exercise is the most potent, but of course one also has to know thyself as they say
- For Peter personally, it’s so strong on his physical health AND his mental health that he would just never turn it down
  - “*To turn down exercise would imply there’s been a cataclysmic system failure*”
- It might be that for some people however, in a time of crisis it’s easier for them to back off on exercise
- The point is that if one is to ratchet down exercise, they should then try to ratchet up some measure of control in the other areas
  - Maybe that person needs to be more diligent about what they eat during that period of time to compensate for the lack of control they’re going to exert over that other area.

## What fitness watch did Peter recently purchase? [1:03:45]

Peter recently [posted](https://twitter.com/PeterAttiaMD/status/1513194722080219144?s=20&t=o6aB_DaGQFe_0P0ltXoM6w) on Twitter that he was looking for a fitness watch. ***What did you choose and are you happy with that decision?***

- Peter’s objective was to find one that would be really accurate on heart rate, but without wearing a chest strap or armband
- He started with the most expensive one that they had, and it turned out to not be very accurate for heart rate
- So he returned it, got another one, and it was equally inaccurate on heart rate.
- At that point he realized he’s not going to be able to read heart rate accurately off his wrist
- So he just ended up getting the cheapest one he could find, which is called the [Coros Pace 2](https://www.coros.com/pace2) for around $200
  - Peter says, “*It’s equally crappy at reading heart rate off the wrist, but it works just fine off my armband. I guess I’m happy I chose that because I finally accepted that if I want to know my heart rate, I can’t do it off my wrist*”

*What is Peter using the watch for?*

- Mainly for rucking
- He doesn’t want to carry his phone with him, but he wants to know things like:
  - How far he goes
  - how much elevation
  - His speed is
  - And his heart rate (even if not completely accurate)

## Potential benefits of cold plunging [1:05:15]

In a weekly email, Peter [wrote](https://peterattiamd.com/is-cold-exposure-therapy-beneficial/) about why he doesn’t think cold exposure really helps in terms of metabolic health and brown adipose tissue

However, *are there other benefits that you think it could help with?*

- Peter says he does not believe that the time that we spend in a cold plunge has any bearing on metabolic health or bat activation or anything like that

But it could be beneficial for a couple of things:

- 1 – It reduces muscle soreness
- 2 – It is a great way to go back and forth in sauna to help with sleep
  - Peter will typically do a short sauna for 15 minutes, then a cold plunge, then a long sauna, then a cold plunge
  - “*Getting that body temperature really, really cold right before I go to bed facilitates pretty awesome sleep*.”

**Figure 1.** Peter and Layne Norton enjoying a cold plunge. Source: [@PeterAttiaMD](https://www.instagram.com/p/Ch20P-gj3jV/)

## Advice for someone beginning an exercise program [1:07:30]

The hypothetical person:

- Someone that is generally healthy but have never seriously prioritized fitness before until now
- Let’s say they know their metrics like their VO2 max, bone density, biomarkers, and they are average in the same cohort
- This person is willing to invest 60 minutes a day for 5 days a week

*What’s the best advice you would give them as they begin to think about what their training plans are and starting to get involved in exercise?*

At five one-hour sessions a week, Peter suggests the following:

- Two of those five workouts should be strength training
- Two and a half of those should be zone 2
- And half of one workout should be VO2 max (zone 5)

Other thoughts from Peter:

- Starting with 5 workouts per week of one hour is a good starting place
- After a year (or less) of doing that that, you’ll start to see benefits and you’re going to have developed the habits around spending that time exercising
- Peter would rather someone start at that time commitment than, say, start exercising 15 hours a week

## Strategies and tactics to lower apoB levels [1:09:00]

***What are the best ways to lower someone’s apoB?***

First of all, there are four things that are driving up apoB:

- Absorption
- Cholesterol synthesis
- LDL clearance
- Triglyceride burden

**Nutrition** is one way to lower apoB – two ways to do that:

- One is through lowering triglycerides
  - Triglycerides can clearly be impacted by nutrition
  - So if someone has very, very high triglycerides, nutrition can impact that and ultimately apoB
- Secondly, saturated fat intake impacts apoB both directly and indirectly
  - It plays a role in cholesterol synthesis and also saturated fat impairs LDL clearance
- So reducing saturated fat and reducing triglycerides, which usually comes by reducing intake and reducing carbohydrates specifically (carbs are really sensitive to trigs)

**Pharmacology** is where you can have the greatest impact on apoB and there are multiple classes of those drugs

- HMG-CoA reductase inhibitors (statins) inhibit cholesterol synthesis, which results in the liver upregulating LDL receptors
- [Ezetimibe](https://www.webmd.com/drugs/2/drug-64335/ezetimibe-oral/details) which inhibits cholesterol reabsorption and also upregulates LDL receptors
- [Bempedoic acid](https://medlineplus.gov/druginfo/meds/a620020.html), which inhibits cholesterol synthesis in the liver specifically and upregulates LDL clearance (though it’s far weaker than statins, more in line with ezetimibe)
- PCSK9 inhibitors directly target the protein that itself targets the LDL receptor
  - So by blocking this protein, you increase the residence time (the life) of the LDL receptor
  - That’s very potent — That’s at least, if not more, potent than the single highest dose of any statin
- [Vascepa](https://www.webmd.com/drugs/2/drug-162888/vascepa-oral/details), which is high dose EPA, works by mechanisms we don’t fully understand, but seems to really only work in people with very high triglycerides

> “I think most people aren’t going to be able to reach my personal targets of apoB without pharmacologic intervention.” —Peter Attia

⇒ Check out a recent special episode of The Drive on this topic: [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/)

## Interesting studies and books Peter has recently read [1:11:30]

***Has Peter read any good scientific papers or books lately?***

Peter read a pretty good scientific [paper](https://www.sciencedirect.com/science/article/abs/pii/S0735109722052603?via%3Dihub) that was in the Journal of the American College of Cardiology

- It was looking at a veteran population to look at cardio respiratory fitness with all-cause mortality
- It was a huge study with “*just unbelievable confirmation of what every study before it has showed*”

**Books**

1 – [From Strength to Strength](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur Brooks

- Peter had [Arthur Brooks](https://twitter.com/arthurbrooks) on the podcast recently ([#226](https://peterattiamd.com/arthurbrooks/))

2 – [Four Thousand Weeks: Time Management for Mortals](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/0374159122) by Oliver Burkeman

3 – [Die With Zero: Getting All You Can from Your Money and Your Life](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1667499196&sr=1-1) by Bill Perkins

Peter says these are “*three books that I can’t stop thinking about in terms of how they pertain to living a good life*”

§

## Selected Links / Related Material

**Peter’s article explaining we humans aren’t naturally able to think scientifically**: [Why We’re Not Wired To Think Scientifically](https://peterattiamd.com/wired-think-scientifically-can-done/) | Peter Attia (peterattiamd.com) [5:45]

**Episode of The Drive with Allan Sniderman when they discussed risk**: [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) |  Peter Attia (peterattiamd.com) [27:00]

**The data on the reference card which Peter carries with him showing both the Framingham and MESA percentile rankings for every lipoprotein**: [32:15]

- [Framingham](https://www.lipidcenter.com/pdf/Framingham.pdf) | (lipidcenter.com)
- [MESA](https://twitter.com/Drlipid/status/1579111715379085313/photo/1) | (twitter.com/Drlipid)

**The Jerky Boys video**: [Frank Rizzo IS BACK!](https://www.youtube.com/watch?v=mIuA3QkvnFU) | Comedy Dynamics (youtube.com) [41:15]

**The interventions testing program study on Canagliflozin**: [Canagliflozin extends life span in genetically heterogeneous male but not female mice](https://insight.jci.org/articles/view/140019) (Miller et al., 2020) [51:45]

**Episode of The Drive on metabolomics**: [#216 – Metabolomics, NAD+, and cancer metabolism | Josh Rabinowitz, M.D., Ph.D.](https://peterattiamd.com/joshrabinowitz/) | Peter Attia (peterattiamd.com) [52:00]

**Fitness watch Peter recently purchased**: [Coros Pace 2](https://www.coros.com/pace2) | (coros.com) [1:04:15]

**Instagram post of Peter and Layne Norton in a cold plunge**: [@peterattiamd](https://www.instagram.com/p/Ch20P-gj3jV/) | (instagram.com) [1:05:15]

**Peter’s weekly email explaining why he doesn’t think cold exposure really helps in terms of metabolic health and brown adipose tissue**: [Is cold exposure beneficial for metabolic health?](https://peterattiamd.com/is-cold-exposure-therapy-beneficial/) | Peter Attia (peterattiamd.com) [1:05:30]

**Interesting paper Peter read recently about cardio respiratory fitness and all cause mortality**: [Cardiorespiratory Fitness and Mortality Risk Across the Spectra of Age, Race, and Sex](https://www.sciencedirect.com/science/article/abs/pii/S0735109722052603?via%3Dihub) (Kokkinos et al., 2022) [1:11:30]

**Books Peter has been reading lately**: [1:12:00]

- [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur Brooks | (amazon.com)
  - Peter had Arthur Brooks on the podcast: [#226 ‒ The science of happiness | Arthur Brooks, Ph.D.](https://peterattiamd.com/arthurbrooks/)) | Peter Attia (peterattiamd.com
- [Four Thousand Weeks: Time Management for Mortals](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/0374159122) by Oliver Burkeman | (amazon.com)
- [Die With Zero: Getting All You Can from Your Money and Your Life](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1667499196&sr=1-1) by Bill Perkins | (amazon.com)

§

## People Mentioned

- [Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon) [6:45]
- [Joseph Lister](https://en.wikipedia.org/wiki/Joseph_Lister) [7:00]
- [Alexander Fleming](https://en.wikipedia.org/wiki/Alexander_Fleming) [7:00]
- [Tom Dayspring](https://peterattiamd.com/tomdayspring6/) [19:45]
- [Ron Krauss](https://peterattiamd.com/ronkrauss/) [20:00]
- [Allan Sniderman](https://peterattiamd.com/allansniderman/) [20:00, 27:00]
- [Tara Dall](https://taradall.com/) [20:00]
- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [21:30, 1:07:30]
- [Layne Norton](https://twitter.com/BioLayne) [1:21:15]
- [Arthur Brooks](https://twitter.com/arthurbrooks) [1:12:00]

§