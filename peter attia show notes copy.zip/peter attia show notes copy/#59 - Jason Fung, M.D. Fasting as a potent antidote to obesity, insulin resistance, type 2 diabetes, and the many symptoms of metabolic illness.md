# #59 – Jason Fung, M.D.: Fasting as a potent antidote to obesity, insulin resistance, type 2 diabetes, and the many symptoms of metabolic illness

**Source:** [https://peterattiamd.com/jasonfung/](https://peterattiamd.com/jasonfung/)

---

In this episode, Jason Fung, nephrologist and best-selling author, shares his experiences utilizing an individualized approach to fasting to successfully treat thousands of overweight, metabolically ill, and diabetic patients, and why being a doctor who specializes in kidney disease gives him a unique insight into early indications of metabolic disease. We also have a great discussion on insulin resistance where Jason makes the case that we should actually think of *hyperinsulinemia* as the underlying problem. We also discuss the difference between time-restricted feeding, intermittent fasting, and dietary restriction (e.g., low-carb) and how they can be used to attack the root cause of T2D, metabolic syndrome, and obesity. We also have a fascinating discussion about the limitations of evidence-based medicine which leads to a conversation where we compare and contrast the scientific disciplines of medicine and biology to theoretical physics.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jasonfung/the_Drive_public.png)

Play

#59 - Jason Fung, M.D.: Fasting as a potent antidote to obesity, insulin resistance, type 2 diabetes, and the many symptoms of metabolic illness

#59 - Jason Fung, M.D.: Fasting as a potent antidote to obesity, insulin resistance, type 2 diabetes, and the many symptoms of metabolic illness

1x15s30s

0:002:42:06

## We discuss:

- Comparing scientific disciplines: Medicine and biology versus physics [7:25];
- The limitations of evidence-based medicine [12:30];
- Early signs of metabolic disease: How specializing kidney disease gives Jason a unique insight into early indications of illness [20:50]
- Insulin resistance, hyperinsulinemia, and the overflow paradigm [29:30];
- Why the common treatments for type 2 diabetes seem to make things worse [42:30];
- How hyperinsulinemia (not insulin resistance) drives metabolic syndrome [53:15];
- Insulin and weight gain, and using fasting to empty the cells of glucose [59:30];
- The two step process of developing type 2 diabetes and how they are both manifestations of hyperinsulinemia [1:03:15];
- NAFLD and hyperinsulinemia: A vicious cycle [1:08:30];
- Are the features and symptoms of diabetes actually protective? [1:12:15];
- Is obesity causing insulin resistance or is it the other way around? [1:17:30];
- What role does inflammation play in obesity? [1:21:45];
- CVD and cancer: Diseases of too much growth? [1:27:30];
- How to reduce proliferation with rapamycin, nutrition, exercise, fasting, and manipulating hormones [1:32:45];
- Getting patients to fast: How Jason and Peter utilize fasting in their practice, and how their approach differs [1:40:15];
- Comparing bariatric surgery to fasting as a treatment for type 2 diabetes [1:48:00];
- Why people think that fasting is bad for you [1:55:15];
- Time-restricted feeding and intermittent fasting: Defining terms, and how Jason applies them in his practice [1:58:30];
- A fasting case study: A diabetic patient with a non-healing foot ulcer [2:04:00];
- Keys to a successful fast [2:12:45];
- Muscle loss during fasting, and why Jason isn’t worried  [2:24:45];
- Will fasting help a healthy person live longer? [2:31:30];
- Does fasting cause gallstones? [2:38:45]; and
- More.

§

## Show Notes

## Comparing scientific disciplines: Medicine and biology versus physics [7:25]

**What makes Jason’s perspective unique**

- Peter says what distinguishes Jason from others who like to speak about the benefits (and risks) of fasting is that Jason is on the front lines treating patients
- Jason agrees, and adds that he’s only interested in what works ⇒ “*You can talk all you want about this and that, but if it doesn’t change management, then it doesn’t interest me particularly*.”

Physics

- Jason loves the approach to scientific progress in the realm of physics
- He really looks up to [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (as does Peter), [Einstein](https://en.wikipedia.org/wiki/Albert_Einstein), and [Niels Bohr](https://en.wikipedia.org/wiki/Niels_Bohr)
- “*The way they do science is so much better than we do in medicine.*”
- In physics, if the theory doesn’t agree with experimental evidence, you have to throw out the theory
- In medicine, bad theories tend to go round and round and round because they make sense, but nobody’s actually put them to the test
- In the case of insulin resistance… “*the way we think about insulin resistance is sort of totally wrong and that’s why we have the sort of mess that we have*”

Biology vs. physics

- Peter: “I’m generally suspect of people who have very, very strong points of view on things in biology or medicine who no longer interact with patients. Doesn’t mean that they’re wrong, but I’m generally suspect because of that.”
- Biology is harder than physics…. it’s just a lot messier
- Peter: “Every time I think I’ve really got it figured out, I’ll always meet a patient who proves me wrong.”

What Jason appreciates most about physics

- Many great theories (e.g., Newton)
- But then inevitably there are anomalies ⇒ “*Anomalies are what drives sort of science forward because you have to come up with a better theory that explains the anomalies*”
- Then you come up with a better theory which may have wild predictions but it could supplant the existing theory (i.e. [Niels Bohr](https://en.wikipedia.org/wiki/Niels_Bohr)’s [quantum theory](https://en.wikipedia.org/wiki/Old_quantum_theory) supplanted Einstein)
- This doesn’t happen in medicine, says Jason… instead we have a super laborious process of ***evidence-based medicine***

## The limitations of evidence-based medicine [12:30]

Jason explains his frustrations…

- In medicine, we have a super laborious process
- We need evidence in order to move things forward
- Whereas physics moves at “light speed” because it doesn’t demand the sort of evidence base
- Evidence-based medicine is not a search for truth… **it’s a search for consensus**
- This approach makes things move glacially

⇒ For example, fasting…

- Five years ago, fasting was the dumbest thing you could do
- But Jason treated hundreds and hundreds of patients, and the “results were amazing”
- He still got major criticism:
  - “*Where’s the evidence?!*”
  - “*There’s no evidence, clearly this is bad!*”

> “*That’s where everything just sort of bogs down.* ***You can’t make intuitive leaps forward****. That always bothers me a lot*.”

**Theorists vs. experimentalists**

- In physics, you can generally divide the field into the **experimentalists** and the **theorists**
- That’s what I think allows the step-function changes in our understanding, says Peter
- Einstein’s advances were theoretical, for example, and the experimental evidence to support these things came after
- And many times the big steps forward come on the basis of theoretical propositions
- “We don’t really have that medicine and biology. We don’t have experimentalists and theorists.”

**Where evidence-based medicine works**

⇒ Best example of evidence-based medicine working: **infectious disease**

- The treatment most infections is remarkable (e.g., HIV)
  - Infections are quite acute, very easy and binary to measure progression
  - The interventions are simple (i.e., take this medication/don’t take this medication)
  - You get the answer if it’s working really quickly (looking at T-cell count or amelioration)

⇒ The problem is that **most things in medicine are much more complicated** than this

“I think evidence-*informed* medicine is probably a better way to think about it.” says Peter

**The risk of doing nothing**

- People are very quick to say, for instance, “*Well, you don’t have the evidence to support fasting for a patient with Type II Diabetes*.”
- But… *what’s the risk of NOT doing something*?
- \*You must compare the risk of doing something (much more on the forefront of people’s minds) with the risk of NOT doing something (which people often forget to consider)\*

⇒ For example, people with Type 2 diabetes

- Risk of NOT doing anything:
  - Continue to get treated with more and more insulin to control blood glucose
  - It’s a virtual certainty that they will eventually have to go on dialysis
  - So the risk of doing nothing is **huge** compared to the risk of an intervention like fasting

## Early signs of metabolic disease: How specializing kidney disease gives Jason a unique insight into early indications of illness [20:50]

[Nephrology](https://en.wikipedia.org/wiki/Nephrology) is a specialty of medicine that concerns itself with the kidneys: the study of normal kidney function and kidney disease, the preservation of kidney health, and the treatment of kidney disease, from diet and medication to renal replacement therapy (dialysis and kidney transplantation) [wikipedia.org]

**Why did Jason choose nephrology?**

- He was drawn to internal medicine because generally it attracts people who “*sort of like to think about things and try to solve puzzles*”
- And within nephrology, a subdivision of internal medicine, all you can do is think about things “because that’s all we could do”
- Example, with kidney disease, there are two general treatments:
  - 1 Prednisone
  - 2 Dialysis
- “*The last time we had a drug that actually slowed down progression of kidney disease was the* [*ACE inhibitors*](https://en.wikipedia.org/wiki/ACE_inhibitor) *in the 80s*.”
- More recently, we have the [SGLT2 inhibitors](https://en.wikipedia.org/wiki/SGLT2_inhibitor) for diabetic kidney disease
- “*Before that, it’s like nothing. There wasn’t a lot to do, but there’s a lot to think about. That’s sort of what I liked about.*”

**Peter is impressed with 2 things about the kidney:**

*First, how intelligent it is*

- There was a very clever design in evolution
- The kidney pulls out everything and then dumps out the bad, and keeps what is good… because the probability that the good things are going to change is low, but the probability that you’ll see new bad things is high
- **Sock drawer analogy**: It would be tempting to think that the kidney would operate like it’s going in your sock drawer to pull out just the right sock, but it doesn’t, it pulls out all of the socks and puts back the right ones.

*Secondly, how small the kidney compared to how much it does*

- A very high fraction of our circulating blood volume passes through the kidney (about 20%)
- This is part of the reason that the kidney is such an **early warning indicator of disease** either through high blood pressure or high glucose

**The kidney as an early warning indicator of high blood pressure and high glucose**

- The eyes are generally the first place you can see disease
- Second place is probably the kidneys by looking at urine (which is formed in the kidney)
- About 20% of the entire blood circulation of the body passes through the kidney… and most of it passes through the [glomerulus](https://en.wikipedia.org/wiki/Glomerulus_(kidney)) (“the functional unit of the kidney”)
- The glomerulus, which you have about a million of these glomeruli in the body, are basically a big bag of blood vessels
- *If you have diseases of the blood vessel* (heart disease and kidney disease are blood vessel diseases that generally show up later in life) … there are so many blood vessels in the kidney that can be affected and **give you an early warning of worse disease to come**

*How we see disease in the urine*

- To look for signs of diabetes or high blood pressure, you measure the urine for what’s called the [albumin to creatinine ratio](https://www.ncbi.nlm.nih.gov/pubmed/10333950)
- When you start to get increased [urinary albumin](https://en.wikipedia.org/wiki/Microalbuminuria) excretion, that means there is damage to the vascular system
- In contrast, looking at the liver…
  - It’s got a big vascular system, just like the kidney
  - But **you can’t measure anything** whereas the urine you can actually directly measure it

**Correlation to heart disease**

Increased urine albumin excretion has a *very, very strong correlation to heart disease*

- Not because having albumin in the urine is so bad, but it tells you that there’s something bad going on in the blood vessels of the kidney
- Which therefore tells you something bad is going on in the blood vessels of the body

In Peter’s practice…

- He’s started to pay much closer attention to cystatin C, creatinine, along with microalbumin because he has begun to realize that the kidney, which often gets neglected, is one of the most important organs in terms of longevity

*⇒ If you are in your 40s…*

- And you already have a glomerular filtration rate at 80% of what would be predicted, you have to fast forward a little bit and say, “Well, what’s that going to look like when you’re 80?”
- The net implication for Peter has been a much greater focus on blood pressure, even just slightly elevated blood pressure
- Many physicians (until recently) probably just weren’t thinking of as a significant enough problem
- *“There are a staggering amount of people walking around who on the surface, just based on the creatinine look pretty normal, but a slightly deeper look says, ‘No, actually, they’re not normal. They are compromised. It won’t be clinically relevant for 30 or 40 years, but that is going to be relevant.’”*

**There are no symptoms of kidney disease**

- The thing is that **there are no symptoms**
- [IgA Nephritis](https://en.wikipedia.org/wiki/IgA_nephropathy) is the most common primary kidney disease in the world
- But the patient will not know it
- “They will have lost 95% of their kidney function by the time I see them just because they never knew they had a problem because they never checked it.”
- Fortunately, it’s so easy check in the urine, it’s non-invasive, and anybody can do it

## Insulin resistance, hyperinsulinemia, and the overflow paradigm [29:30]

**Explaining insulin resistance to a layperson**

- To start, Jason says the way he was taught insulin resistance in med school was wrong because it was only in terms of glucose

⇒ The wrong way to think about it…

- Insulin is a hormone, and when insulin goes up, it allows glucose (through the GLUT4 receptor) to go from the blood into the cells
- In the case of normal levels of insulin (unlike type 1 diabetes), and glucose can’t make it into the cells, we call it “insulin resistance”
- *So if insulin is around, why can’t the glucose go into the cell?* ⇒ It must be because of insulin resistance

⇒ This is the **lock and key paradigm**

- Insulin is a hormone. It acts on the insulin receptor, which is on the cell surface.
- The insulin receptor is like a gate ⇒ There’s a door with a lock ⇒ Insulin is like the key so it opens the door ⇒ Therefore, the glucose can go from the blood into the cell for energy
- When you look at insulin and insulin receptors and see there is nothing wrong with them, the common thinking is that *there must be something that’s gumming up the system*
- And the gumming of the system is stopping the glucose from getting into the cell and so now the cell is facing an internal starvation
- This *internal starvation* is why we give insulin to move the glucose into the cell
- Jason says this thinking is *almost completely incorrect*

**The central paradox of insulin resistance**

- Insulin has many, many different functions, and *only one of which is letting glucose into the cell*
- And in many ways the body appears *extremely sensitive* to insulin in a person who has so-called insulin resistance

Examples…

⇒ *In the liver…*

- Insulin is responsible for [de novo lipogenesis](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/)
- If there’s too much glucose after the glycogen is full, it’s going to turn it into triglycerides, or fat
- So, de novo lipogenesis is working fine *even in the face of insulin resistance and type 2 diabetes*

> “So, how can it be that you have a liver cell which can’t let in the glucose (so it’s resistant to the insulin) yet the other effect of insulin (de novo lipogenesis) is not only working fine, it’s actually going over time?”

⇒ *What about the mitogenic effects of insulin?*

- Insulin is a growth factor
- So for example, with gestational age babies, we say that a woman has insulin resistance, yet insulin is actually doing what it’s supposed to do…. *stimulating a lot of growth*

*⇒ Testosterone*

- Insulin has an effect on testosterone and PCOS
- And again, it’s not just working fine, it’s working at a super high level

> “In the liver, you have this central paradox where in the same tissue, to the same levels of insulin, you have both resistance and super sensitivity. That’s not really possible.”

*⇒ Obesity…*

- A very common phenotype of insulin resistance is obesity (i.e., the accumulation of fat in a fat cell)
- For a fat cell to get larger, it needs to incorporate triglyceride
- To incorporate triglyceride requires insulin
- So, on the one hand, this patient is insulin resistant… but looking the fat cell, it appears to be quite well insensitive to insulin

**Hyperinsulinemia**

- The problem is not insulin resistance per se, the problem is *hyperinsulinemia*
- Using insulin to push more and more glucose into the cells is a problem because the cell is already too full in a person with insulin resistance/T2D

⇒ The suitcase analogy

- You are packing a suitcase
- Your wife tells you to put more shirts in, so you do
- But after she keeps asking you to put shirts in, you finally say “no”
- Possible reasons you say “no”
- The suitcase won’t open anymore so you can’t add shirts
- It’s too full to add more
- You simply decided to stop listening to her
- But whether you are fully willing to add shirts, or if you are defiant to her request, the outcome looks the exact same… *excess shirts outside the suitcase*

⇒ In the case that you’re being stubborn and simply not listening to your wife…

- When we treat type 2 diabetes with big doses of exogenous insulin, we are essentially ramming the excess shirts (glucose) into the suitcase (cell)

⇒ But if it’s an **overflow paradigm**, the *implication is completely different*…

- Because the solution is to get rid of some of the stuff that’s in your suitcase
- Putting more in is not the solution
- The solution is to empty that cell of glucose… that’s the *whole solution*
- But that is a totally different paradigm than what we’ve been taught… we use [sulfonylureas](https://en.wikipedia.org/wiki/Sulfonylurea) and exogenous insulin trying to shove more glucose into this already filled cell

**High insulin environment**

Increasing insulin to deal with the excess glucose because of so-called “insulin resistance” actually supercharges the other effects of insulin on the body

- It triggers the making of testosterone
- You get [PCOS](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome)
- The growth effects of insulin which has huge implications for cancer
- Example, breast cancer and colon cancer
  - Very insulin sensitive
  - Much higher rates in type 2 diabetes and obesity
  - So, you’re getting the cancer-causing effects of the insulin, but yet you’re saying people are insulin resistant
- So it makes sense that you have continued de novo lipogenesis even in the face of this so-called resistance, because you actually have too much insulin

## Why the common treatments for type 2 diabetes seem to make things worse [42:30]

The majority of drugs to treat T2D aren’t actually aimed at decreasing glucose, it’s more about increasing insulin, such as…

- Sulfonylureas
- Exogenous insulin
- DPP-4 inhibitors

Continuing the suitcase analogy…

- These drugs are similar to your wife screaming at you to put more shirts in
- At first, you can do it, but as you keep doing that, the problem just keeps getting worse and worse
- At first it’s a little full, and then it’s a lot too full

*Progressively worse*

- If you watch a patient with T2D diabetes, you can see his condition just get progressively worse over time even when on these medications
- The treatment was completely incorrect
- We kept putting more shirts in when we should’ve been taking shirts out
- We kept putting more glucose into the liver, which is what insulin does, instead of taking all that glucose out of the liver

*Why tight control of glucose with insulin doesn’t work long term*

- Trials like [ACCORD](https://www.nejm.org/doi/full/10.1056/NEJMoa0802743), [ADVANCE](https://www.nejm.org/doi/full/10.1056/NEJMoa0802987), and [VADT](https://www.nejm.org/doi/full/10.1056/NEJMoa0808431) all failed because they were working on this incorrect paradigm of insulin resistance (lock and key paradigm)
- [Macrovascular vs. microvascular disease](https://clinical.diabetesjournals.org/content/26/2/77)
  - When diabetes trials are using glycemia as their end point (meaning how low can you get the hemoglobin A1c/how “tightly” can you control the glucose) the patients will see benefits in *microvascular problems*
  - But the opposite is not true
  - By taking someone’s average glucose from 200 down to 150, that would be considered a huge win in a diabetes trial (and that benefit might show up in their kidneys)
  - But if you had to double the amount of insulin you gave them to do that, it turns out that at the macrovascular level (e.g., heart and brain) they don’t get any better, **they get worse**
    - This indicates that hyperinsulinemia itself is problematic

See [Peter’s discussion with Jake Kushner](https://peterattiamd.com/jakekushner/) for more

**It’s about** ***whole-body*** **glucose, not just blood glucose**

- It’s not the blood glucose per se, it’s the *whole-body* glucose, says Jason
- *If you take the glucose that’s in the blood and simply shove it into the liver, have you done anything good for this patient?* ⇒ The answer is no, because you’re just covering up the problem
- It’s the whole-body glucose moving the glucose from one compartment of the body, which is the blood, to another compartment, which is the liver

[*SGLT2 inhibitors*](https://en.wikipedia.org/wiki/SGLT2_inhibitor)

- The SGLT2s are a new class of drug which blocks the receptor on the kidneys where you’re actually absorbing the glucose, and you actually pee out the sugar
  - You do get some side effects: Urine infections, yeast infections, and for some reason, you get ketoacidosis, too

If you look at the trials, they’re actually quite consistent that you get a [huge protective effects against kidney disease](https://care.diabetesjournals.org/content/diacare/39/Supplement_2/S165.full.pdf)…

- Reduce the risk of kidney disease by about 25%
- And reduce the risk of heart disease
- Never seen before in any class of antidiabetic drug
- The reason it’s working is because it’s getting rid of the glucose as opposed to simply moving it around…“*We’re emptying out that suitcase*”
- The amount of lowering of blood sugar was super unimpressive in all of these trials
- Every single one of these trials shows organ protection with almost no benefit to your blood sugar (A1c would only drop 0.3 or 0.4)
- It was terrible for the blood sugar, but the *end points were incredible*
  - *Why? ⇒* You’re actually treating the underlying problem of too much **whole-body glucose** as opposed to too much glucose in the blood (two totally different problems)

## How hyperinsulinemia (not insulin resistance) drives metabolic syndrome [53:15]

Exercise

- Peter points out that exercise increases a reservoir for glucose uptake, the muscle
- The more one exercises, the more he/she could put away glucose into a muscle as glycogen

*⇒ What magnitude of benefit does exercise have on T2D*?

- There is a benefit, for sure
- But it is much less efficient than attacking the diet
- The liver is really the key to type 2 diabetes, and you can’t exercise the liver

**Metabolic syndrome and insulin**

Metabolic syndrome which is a constellation of five things:

1. Increased blood glucose
2. Abdominal obesity
3. High triglycerides
4. Low HDL
5. High blood pressure

*How does hyperinsulinemia play a role in metabolic syndrome?*

- The liver is now busy exporting out tons and tons of the fat
- The liver has too much glucose because of too much insulin so the liver is jam-packed
- It wants to get rid of all this extra fat so it’s putting out tons of triglycerides (you get [hypertriglyceridemia](https://en.wikipedia.org/wiki/Hypertriglyceridemia))
- And as triglycerides go up, *HDL goes down*
- As you’re exporting out all of this fat, this fat goes into all kinds of places where it’s not supposed to go (the pancreas, the omentum fat, etc.) and you get *abdominal obesity*
- And it’s **not because of dietary fat**, because dietary fat *doesn’t go into the liver*
- Dietary fat goes into the chylomicrons, which goes into the blood vessels, which is taken out by the adipocytes
- The belly fat is because the liver is pouring out all this new fat that gets taken up in all the organs around it
- Insulin also has an effect on blood pressure because insulin causes reabsorption of sodium at the site of the [proximal tubule](https://en.wikipedia.org/wiki/Proximal_tubule)
- The whole syndrome is not a syndrome of insulin resistance… **It’s a syndrome of hyperinsulinemia**

*If the problem is hyperinsulinemia, then the solution is completely obvious*

- Insulin is high… so *we need to lower it*
- It’s no different than if your thyroid is too high, you want to lower it
- In T2D, we know that insulin levels are high… *so why did we think it would get better by giving more insulin? ⇒*  **We totally misunderstand the problem**

*Easier to treat “hypo” and “hyper”*

- With hormones, it tends to be easier to treat a case of too little (hypo) and too much (hypo) of a particular hormone

  ⇒ Example, it’s much easier to treat low cortisol than to get a super stressed person with high cortisol to bring it down (there’s no pill to lower cortisol)

- With **type 1 diabetes**, just give more insulin
- But with T2D, which is too much insulin, there was no drug (now there is SGLT2)… and we would give more insulin (“it’s so ridiculous”)

## Insulin and weight gain, and using fasting to empty the cells of glucose [59:30]

- Studies (like the [DCCT](https://www.ncbi.nlm.nih.gov/pubmed/8366922)) show that insulin causes weight gain
- People gained weight and eventually became hyperinsulinemic
- Even T1D patients became hyperinsulinemic…
- You start out taking 15 units a day when you’re a kid
- And then by the time you’re 45, you’re taking like 60 units a day
- Why? You developed insulin resistance, and yet you had no insulin in your body in the first place 20 years ago
- We thought that giving more insulin was good, but we didn’t realize that, hey, too much insulin is just as bad as too little insulin (or worse in this case)

*The negative feedback loop*

- We actually know a lot about how this sort of overflow paradigm works, biochemically
- It’s called the [TCA cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle)

> “We worked out the whole biochemistry of how this overflow paradigm is supposed to work. We actually teach high school students that, ‘Hey, if you’re feeding in way too much of [insulin] into the TCA cycle, there’s a negative feedback loop.’”

- ATP is going to block glycolysis which is going to block that glucose so you don’t overload the system
- So now glucose can’t go in anymore
- In other words, hyperinsulinemia, which is actually too much glucose, too much insulin, is going to feed back and not let the glucose into the cell which is why the glucose stays outside (in the blood), and you have this so-called insulin resistance
- But the **key is to empty out the cell of glucose**
- *And how are you going to do that?* ⇒ Low carbohydrate diets and intermittent fasting, says Jason

**Fasting to empty the cells of glucose**

> “There is no more potent way to lower insulin than to fast.” —Peter Attia

- Many people spend time arguing about whether low-fat or low-carb diets work best to lower insulin… but they seem to forget the infinitely more potent tool: *eating nothing at all*
- By eating nothing you are going to force your body to start using another fuel, and **the first place it’s going to pull it out of is this fatty liver** (which, by the way, is causing a ton of cirrhosis and T2D because it’s actually part of the same problem)

## The two step process of developing type 2 diabetes and how they are both manifestations of hyperinsulinemia [1:03:15]

**The two-step process of developing type 2 diabetes**

- First is insulin resistance (or said a better way: hyperinsulinemia)
- Next, Pancreas atrophies after spending so much effort to produce more and more insulin and it finally fails ([beta-cell failure](https://www.ncbi.nlm.nih.gov/pubmed/18777097))
- After the beta-cell failure is when the blood glucose go way up
- Process takes about 10 years
- So the **rising insulin resistance is met with hyperinsulinemia, which keeps the blood glucose normal, and it keeps it normal for a long time at the expense of hyperinsulinemia**.

The current mainstream thinking is that insulin resistance, and beta-cell failure are totally separate

- But that doesn’t make sense, says Jason
- First of all, virtually all type two diabetics are reversible

⇒ Example, bariatric surgery

- About 80-90% of those type two diabetics that have the surgery will get off all their meds and reverse their type two diabetes
- So the beta cell hasn’t “failed”
- The [youngest person ever to develop type two diabetes was a three year old girl](https://www.theguardian.com/society/2015/sep/16/type-2-diabetes-three-year-old-girl-obesity) ⇒ Did her pancreas completely fail already??
- The only thing is that you only see beta-cell failure in this case of insulin resistance, and never anywhere else (One goes with the other all the time and exclusively with each other)

These observations fit the *overflow paradigm*

- It explains the paradox very easily, because what happens is…
  - You’re filling up your liver with all this glucose
  - You get hyperinsulinemia
  - Now you’ve got too much glucose in your liver so your liver starts making fat and pumping it out
  - The pancreas then starts to accumulate fat that was pushed out by the liver (i.e., fatty pancreas)
  - So your pancreas has not failed, your pancreas is just **clogged with fat**
  - All type 2 diabetes people have big fatty pancreases

⇒ [Type 2 Diabetes: Etiology and Reversibility](https://www.medscape.com/viewarticle/781719_7) by Roy Taylor

- Showed that when you get them to fast they showed that the type 2 diabetes was reversible because you simply unclog the fat
- In other words…

- The fatty liver is responsible for the insulin resistance (hyperinsulinemia)
- And the fatty pancreas is responsible for the beta failure
- So they’re both manifestations of the same thing
- They’re both **manifestations of hyperinsulinemia**
- “*That explains why it’s not two defects of type 2 diabetes, it’s actually a single defect and why it’s a reversible problem.*”

**A better hypothesis**

- This hypothesis fits the anomalies so much better than everything else
- Look at fructose for example,
  - W*hy is fructose so bad if it doesn’t have any glycemic effect/insulin effect*?
    - Well, it causes fatty liver because all that fructose goes into the liver and it’s turned into fat through de novo lipogenesis
- It explains everything about how this disease of type 2 diabetes more than just hyperinsulinemia, or insulin resistance, it explains how that all kind of comes about

> “We have a theory now which now fits the facts so much better than the old ‘lock and key’ model and therefore you have to adopt it and say ‘what are the treatments that come out of this that are going to be more effective?’”

## NAFLD and hyperinsulinemia: A vicious cycle [1:08:30]

Peter asks Jason about the **arrow of causality** between NAFLD and hyperinsulinemia

⇒ A very common patient presentation is the following:

- Hyperinsulinemia, with or without normal glucose levels
- Hemoglobin A1c is often completely normal
- Their ALT is high, much higher than we would like to see, though not so high that people would get alarmed by it
- And if you could get an ultrasound of the liver and you would almost assuredly see the accumulation of fat
- And a treatment plan for that patient will resolve the NAFLD, normalize the ALT, and reduce hyperinsulinemia
- But Peter has never been able to disentangle if the high level of insulin is really pushing the fat accumulation in the liver or the other way around

*⇒ So does the NAFLD drive hyperinsulinemia or is it the other way around?*

- I think it does both, say Jason

⇒ [2009 study by Peter Havel comparing glucose to fructose](https://www.ncbi.nlm.nih.gov/pubmed/19381015)

- They took two groups of people
  - One group they gave sort of Kool-Aid that was sweetened with glucose
  - Another group they gave Kool-Aid sweetened with fructose
- They found was that when you gave a lot of fructose, people got type 2 diabetes measured by an oral glucose tolerance test
- The fructose, which is metabolized in the liver, is causing fat accumulation specifically in the liver, and that is going to cause hyperinsulinemia, because the liver is full of all this excess fat, now you’re trying to shove all this glucose into this fatty liver cell and the liver is like, “no, I can’t take anymore so I’m going to be resistant to this”
- And as the liver gets resistant, the blood glucose goes up and then the body starts to have to make more insulin to control that situation
- So, it seems like the **arrow of causation goes both ways**

> “It’s sort of a vicious cycle. Each is making the other worse, so you have to take care of the problem. So when you take care of one, you sort of take care of both.”

## Are the features and symptoms of diabetes actually protective? [1:12:15]

Jason says the following are not actually detrimental, they’re actually **protective**

- Obesity
- Insulin resistance
- Fatty pancreas

**For example, let’s take obesity…**

- Suppose you live in a house on a street
- Every day, insulin comes by and knocks on the door and gives you a little bit of glucose
- You say thank you and you use it for energy and everything’s great
- Then one day, insulin comes by and instead of giving you a little cup of glucose, it gives you a big barrel of glucose
- It’s sort of too much but you take it because you’re supposed to… but eventually your house fills up with all this glucose

*⇒ So what are you going to do?*

- You’re going to stop taking that glucose (so that’s insulin resistance)
- It’s protecting itself from the effects of too much glucose
- With fatty liver ⇒ it’s protecting itself from too much glucose
- Insulin, however, is still thinking “*I’ve got to get rid of this glucose. I can’t have it hanging around, I’m going to lose my job.*”
- So more and more insulin comes to your house and starts battering down the door and just shoving in all this glucose
- The insulin is overcoming the protective response (insulin resistance)

*⇒ So then what do you do?*

- Well, you start to take some of these barrels of glucose and you try and **give it to your friends and your family** (this is what the liver does)
- It’s got way too much fat sitting around so it takes this fat and shovels it out the door as [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein)
- It goes into other organs
  - The [omentum](https://en.wikipedia.org/wiki/Greater_omentum) ⇒ That’s how you get *abdominal obesity* that you see
  - The pancreas ⇒ fatty pancreas

*⇒ Fatty pancreas*

- Your pancreas makes a lot of insulin, makes a lot of insulin, makes a lot of insulin up onto a certain point until it’s all clogged up and it can’t make the insulin
- *So what happens?* … You start to pee out all this sugar… you get polyuria, polydipsia, glycosuria, your body is actually trying to protect itself by peeing out all this sugar

> “We think of all these responses, obesity, insulin resistance, and the beta cell failure, as pathologic, but they’re actually protective. . .Your body is actually trying to protect yourself against the root cause of the problem which is too much insulin, too much glucose.”

SGLT2s

- They are effective because they attack the root cause

Treatment with insulin

- When you actually give people *more insulin*, you actually keep all that glucose inside
- And guess what? They gain weight

***Extremely lean and severely insulin resistant?***

⇒ Paper: [Lipodystrophy: Pathophysiology and Advances in Treatment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3150735/)

⇒ New York Times article: [Skinny and 119 Pounds, but With the Health Hallmarks of Obesity](https://www.nytimes.com/2016/07/26/health/skinny-fat.html)

People with [lipodystrophy](https://en.wikipedia.org/wiki/Lipodystrophy) have no fat yet they have the “worst insulin resistance you’ve ever seen”

Peter’s take:

“This sort of explains that paradigm which is if you are truly insulin resistant, and you at least buy the argument that that’s a global term, meaning one cell is insulin resistant they all are, well then, yes, you should be the leanest individual on the face of the earth because your adipose tissue does not have the ability to integrate or assimilate the signal that says, ‘one, bring triglyceride in, and two, halt the process of lipolysis.’ . . .

. . .The problem is not insulin resistance per se, it’s actually hyperinsulinemia so what your body is doing is taking all this fat and sort of storing it away so it doesn’t cause a problem. These people with the lipodystrophy, they couldn’t store the fat so what happens is the fat stored up in their liver and they had the highest insulin resistance you’ve ever measured, because it’s really a protective mechanism. The fat is trying to suck away all this glucose so that it doesn’t cause a problem.”.

*Obesity as a protective mechanism*

This is why obesity itself is actually a protective mechanism against hyperinsulinemia, against too much sugar.

The ultimate problem is too much glucose and too much insulin.

Then the next step is okay, so now insulin is way too much.

Insulin has got all his cousins out battering down your door, throwing in all this stuff and you can’t take it anymore.

## Is obesity causing insulin resistance or is it the other way around? [1:17:30]

**Which is driving which?**

- “I think it’s more likely that **hyperinsulinemia is driving the obesity** rather than the other way around.”

[1993 insulin study](https://care.diabetesjournals.org/content/16/1/21)

- Took people who were type 2 diabetic
- They gave them a lot of insulin, so from time zero to six months, they went from zero units of insulin to like 100 units of insulin.
- Their blood sugars were great
- *What happened?* … Well, they **gained like 20 pounds** and if you look at the number of calories they were eating per day, it actually had dropped by about 200 or 300 calories per day
- The only difference was the **hyperinsulinemia**

> “The arrow of causality is very easy to establish going from hyperinsulinemia to obesity, and forgetting all the mechanism.”

⇒ [Study showing liposuction didn’t improve insulin resistance or risk factors for CVD](https://www.nejm.org/doi/full/10.1056/NEJMoa033179)

- Liposuction doesn’t reverse insulin resistance
- However, that procedure doesn’t remove *visceral fat* which might be the fat that is causing the major problems

## What role does inflammation play in obesity? [1:21:45]

The other thing that seems to go hand in hand with hyperinsulinemia in patients is they also tend to be quite inflamed (measured via C-reactive protein, fibrinogen, interleukins, cardiac specific forms of inflammation, etc.)

Jason’s take:

- Anti-inflammatory medicine doesn’t seem to help people lose weight consistently
  - Such as NSAIDs, Prednisone, etc.
- So, there might be a kernel of truth in that, **but it doesn’t really make a lot of sense**
- Also, in the case of a bad infection causing inflammation to rise up… **People don’t gain a bunch of weight**

> “I don’t deny that there’s a lot of important inflammatory mediators and stuff, but it’s just not so simple that you can say more inflammation causes weight gain, less inflammation causes weight loss.”

**Peter’s observation with his patients**

- Patients that come to him needing to lose weight
- A hyperinsulinemic patient with **no inflammation** tend to respond quite well to carbohydrate restriction and exercise
- A hyperinsulinemic patient coupled **with inflammation** tend to NOT respond well to carbohydrate restriction and exercise and need fasting to move the needle

*⇒ Does that suggest that inflammation can have a negative synergy with hyperinsulinemia?*

- I think that there probably is something to that, says Jason
- But ultimately, Jason says that the role of inflammation is a little too “messy” to try to figure out there’s so many different mediators, such as TNF, IL-2, endotoxins, etc.)
- In fact, [Prednisone](https://en.wikipedia.org/wiki/Prednisone), which is used to suppress the immune system and decrease inflammation, actually tends to make people gain weight until they finish their course of the medication, and the weight comes back down

Other hormones, for example, are more obviously causal in terms of obesity

- We know that cortisol for example has a huge impact on body fatness.
- Sex hormones have to play a role somewhere in there as well because there are women who develop gestational diabetes and their insulin, their diets, they don’t change. The difference is they got pregnant and that’s a difference in sex hormones.
- Looking at girls and boys at puberty for example…
- The difference between girls and boys is testosterone versus estrogen
- Yet girls who go through puberty have way more fat than boys (who get more muscle)

> “So we know that there are other hormones that clearly have an impact, so it’s not just about insulin, but it’s about cortisol, it’s about sex hormones, and I think inflammation probably comes in there somewhere, but what to do about it and it’s a lot messier…too many moving parts.”

## CVD and cancer: Diseases of too much growth? [1:27:30]

The two top killers in America are:

- Cardiovascular disease (CVD)
- Cancer

⇒ Jason says that they’re both **diseases of too much growth**

- Growth in adults is generally bad
- Once you reach adult size, your liver doesn’t grow, your kidney doesn’t grow, you shouldn’t be growing
- Obesity, fatty liver, these are diseases of excess growth

Alzheimer’s disease

- If you have all this excess protein in your brain that’s blocking your signals, that’s Alzheimer’s disease

CVD

- In the blood vessels, we know that there’s excessive growth
- It’s not a matter of fat or cholesterol clogging your arteries like a pipe… those are a response to injury
- It’s a response to injury, but you get excess proliferation of certain things (e.g., smooth muscle cells)

> “To me, it’s just a disease of **too much growth** that’s eventually building and closing off that artery.”

Cancer

- Insulin is a growth factor
- Every single time that you have a nutrient sensor, like insulin, like mTOR, like AMPK… it increases growth  (It goes through the same pathway… through PI3K and then MAPK and Akt)
- One of the big problems with “insulin all the time” is that you’re telling your body to grow all the time when it really shouldn’t be growing all the time
- To decrease growth you must influence insulin and mTOR
- mTOR
  - Very sensitive to dietary protein
  - If there’s a lot of protein, you turn on all these cell proliferation signals.
  - When you have very little protein, you get [autophagy](https://en.wikipedia.org/wiki/Autophagy)
- Being obese, for example, it doesn’t give you cancer, but it certainly increases your risk of breast and colon cancer by a whole lot
- There’s a very strong relationship between type 2 diabetes and breast cancer for example (due to the hyperinsulinemia)

> “To me, those are all diseases of excessive growth and therefore you have to start looking at growth pathways . . . and all of these times that you can decrease nutrient sensors, that is decrease mTOR, decrease insulin, increase AMPK, you’re getting good effects for longevity.”

## How to reduce proliferation with rapamycin, nutrition, exercise, fasting, and manipulating hormones [1:32:45]

**Rapamycin has antiproliferative properties**

- Every chronic disease is some amount of hyperproliferation/hyper-growth
- “You have a drug here that in the most elegant way, in the least toxic way, in the most specific way, targets one of the most important regulators of growth (mTOR).”

**The role of hormones in fat and muscle growth**

*Why do bodybuilders use insulin?*

- Testosterone is anabolic but **insulin is even more anabolic**

⇒ Testosterone

- Anabolic to muscle
- Catabolic to fat

⇒ Insulin

- Anabolic to both muscle AND fat

⇒ Cortisol

- “The worst of both worlds.”
- Catabolic to muscle
- Anabolic to fat

*How can you manipulate these hormones to the desired outcome?*

- Nutrition is one tool
- Exercise is another
- And the use of hormones themselves (in cases where there’s deficiencies) being another tool

> “The things that we care most about avoiding, if you really look closely, involve some measure of hyperproliferation and growth.” —Peter Attia

Papers Peter mentioned:

- The 2006 theoretical paper: [In pursuit of the longevity dividend: what should we be doing to prepare for the unprecedented aging of humanity?](https://go.galegroup.com/ps/anonymous?id=GALE%7CA143579030&sid=googleScholar&v=2.1&it=r&linkaccess=abs&issn=08903670&p=AONE&sw=w)
- 2009 rapamycin trial: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)

**Treating the diseases of today vs. 50 years ago**

⇒ Infectious disease vs. chronic disease

- Today, we are treatly mostly chronic disease
- Go back 50 to 100 years, we were treating a lot of infectious diseases (i.e., Hepatitis virus, pneumonias, diarrheas, etc.)
- We developed all these great drugs, antibiotics, antivirals, etc.
- Huge parallel between antibiotic resistance and insulin resistance
  - Today we see antibiotic resistance which is caused by too much antibiotics and we try and treat it by using even more antibiotics to overcome that resistance (“which is the dumbest thing you could do”)
  - In insulin, we have insulin resistance, we treat it with more insulin, which is what caused it in the first place, and then things get worse

⇒ The paradigm of medicine did not change

- So we shifted from treating infectious diseases to chronic diseases **but we never changed our paradigm of medicine**
- As a doctor, I give you a pill, an antibiotic, and you get better
- Then people came in with diseases like diabetes and obesity and the related diseases of too much growth (cardiovascular disease and cancer) and we basically said “let me give you a pill”
  - That’s totally the wrong thing because you don’t have a pill to decrease proliferation

⇒ Side note: Rapamycin might be the first “pill” we can give to treat hyperproliferation however, it’s limited to just one pathway (mTOR)

**The 3 nutrient sensing pathways**

⇒ The three pathways are

  1) Insulin

  2) mTOR

  3) AMPK

⇒ How they respond to different things:

- Insulin responds to dietary carbohydrates and dietary proteins
- mTOR responds mostly to dietary protein
- AMPK actually measures the ATP, the AMPA, ATP ratio … so it actually doesn’t care what you eat, it just cares about the cellular energy availability

⇒ Different time scales

- Insulin goes up and down within minutes and it’s gone within hours
- mTOR is sort of up and down between 18 and 30 hours
- AMPK is sort of days to weeks

“*So you have such a sophisticated system because you have three nutrient sensors that are giving you different information based on your diet and also based on your timescale.*”

**Fasting**

Where as rapamycin only affects one pathway (mTOR), intermittent fasting does the following…

- Decreases your insulin
- Decreases your mTOR, and
- Increases your AMPK
- All three things that you need to do in order to **decrease proliferation** so it’s the “*best bang for your buck*”

> “Fasting every so often has incredible benefits because you’re going to be able to affect those diseases of excessive growth.”

## Getting patients to fast: How Jason and Peter utilize fasting in their practice, and how their approach differs [1:40:15]

**For Peter’s patients**: Before starting on longer fasts, he first starts his patients with the two easiest ways to help the patients escape the gravitational pull of eating pure garbage:

- 1) Time-restricted feeding
  - you don’t restrict what a person eats, or how much they eat, you just restrict when they eat
  - Example is the 16:8 protocol, a 16 hours fasting time with an 8 hour eating window
- 2) Dietary restriction
  - No restriction on when you eat. No restriction on how much you eat. You just can’t eat these foods
  - Example, carb-restriction
- Depending on how well those 2 approaches work, Peter may begin to encourage patients to incorporate longer fasting

**At Jason’s practice**:

- He focuses heavily on the fasting from the start
- Jason believes we spend way too much time talking about what to eat instead of when to eat
- We’ve been told to eat small meals throughout the day but Jason says no science backs up this idea and that someone essentially made it up and it stuck

Fasting is easier for patients

- When Jason decided to focus in on diet/nutrition with patients, he found that getting the patients to  change the frequency of eating as opposed to what they’re actually eating, was much easier
- He saw so many patients at such a quick pace he needed something that he could efficiently and effectively explain within 10 minutes
- When his patients started seeing really good results, he knew he was on to something

Jason wrote [case report that was published in BMJ Case Reports](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6194375/)

- Three patients who had T2D for 20+ years using big doses on insulin
- Put on a 24 hours of fasting three times a week (one-meal a day)
- They got **off all their insulin** between 5 and 18 days
- “*It was ridiculous how quickly they responded*”
- They went from 20 years of diabetes to non diabetic, and have maintained it for the last six years

## Comparing bariatric surgery to fasting as a treatment for type 2 diabetes [1:48:00]

[Roux-en-Y gastric bypass](https://en.wikipedia.org/wiki/Gastric_bypass_surgery#Variations)

- A surgical procedure where the part of the bowel that comes out of the stomach, which is called the jejunum and is the first part after the duodenum
- You cut a piece and then reattach it as a piece of a Y, and then bring it up such that you are basically bypassing not just significant parts of the volume of this stomach as a reservoir, but also the initial part of the duodenum and the jejunum

⇒ Observation:

- Within about 10 days…
  - They haven’t lost a meaningful amount of weight
  - But all of a sudden, they don’t need insulin anymore, and very quickly, their diabetes resolves
- The question remains…
  - How much of that reversal was due to:
    - internal architecture?
    - Was there something problematic about the duodenum of that patient?
    - How much of that is due to the change in the nutrition of the patient? ⇒ because a patient who undergoes a gastric bypass has to make significant changes in their nutrition
    - How much of that is due to the perioperative period of **caloric restriction**?

⇒ What does Jason think?

- He says you could probably get exactly the same results if you simply **didn’t feed them for 14 days**
- In the cases that Jason has done this, the diabetes completely resolves

**The overflow paradigm explains this**

- These 14 days fasts can reverse T2D because…
- It is dropping insulin levels very low
- After the first 24 hours, glycogen runs out
- Your body is then going to have to metabolize fat for energy
- The first place it’s going to start pulling fat out of is going to be the **internal organs**

⇒ Fatty liver decrease

- The liver is going to be the first to lose fat
- As this big fatty liver goes down, just like emptying your suitcase, the insulin resistance starts to melt away

⇒ Pancreatic function

- Pancreatic fat starts to go down because your liver is not pumping out fat and dumping it in your pancreas
- So you’re unclogging the pancreas, and you’re producing enough natural insulin that you don’t get the hyperglycemia anymore
- Your glucose isn’t that high because now you’re at a stage where insulin production is going to go up

**Visceral fat loss BEFORE subcutaneous fat loss**

- Clinically, you see that before you lose the weight (all a lot of subcutaneous fat) … you’re getting rid of the [visceral fat](https://en.wikipedia.org/wiki/Abdominal_obesity) (the fat around the organs)
  - The insulin resistance is fatty liver
  - The beta cell failure is fatty pancreas
- You’re getting rid of that first, and that’s why that diabetes goes away so quickly before you see significant weight loss

⇒ “Medical bariatric”

- Jason refers to fasting as “medical bariatric”
- “*You get all the benefits of bariatric surgery without doing any surgery, because you can get almost everything the same.*”

**More about bariatric surgery**

- Bariatric surgery is “easier” for patients
- It also has benefits such as
  - Bypassing the duodenum (and there’s [some evidence the duodenum can be altered to improved T2D](https://care.diabetesjournals.org/content/39/12/2254) so bypassing it may be a reason for improvement via bariatric surgery)
  - They food they eat doesn’t get absorbed as much as they get less net calories from the same food

## Why people think that fasting is bad for you [1:55:15]

**We are being told we shouldn’t fast**

- Jason says that everyone CAN fast
- But the reason most people don’t fast is *not because they can’t do it*… it’s because **people are telling them they shouldn’t fast**

⇒ Example, recent publication suggested [skipping breakfast increases risk for cardiac mortality](https://www.ncbi.nlm.nih.gov/pubmed/31023424)

- Nutritional epidemiology studies are so dangerous, says Jason
- Results from a study like there are a correlation, not causation
- This particular study was likely affected by [healthy user bias](https://en.wikipedia.org/wiki/Healthy_user_bias) (i.e., the people who skip breakfast are likely unhealthy people in a number of ways because they are the type of person who would skip breakfast in the face of so many experts telling them not to)

*⇒ The diet soda example:*

“My issue with these studies similar to yours I suppose in that there’s a non-healthy user bias to a lot of these. The more obvious examples are the studies that suggest that diet sodas are worse for you than sodas, but of course, it misses a very obvious or clear thing that might be missing, which is who are the patients who are going to disproportionately consume diet sodas? Certainly, a subset of them might be people who are more health conscious and say, ‘Well, if I want a soda, I’d rather it be diet than not,’ but it’s more often that people who are being told, ‘Look, you can’t have a regular soda’, and so therefore you’re selecting for less healthy patients.” —Peter

## Time-restricted feeding and intermittent fasting: Defining terms, and how Jason applies them in his practice [1:58:30]

**Time-restricted feeding (TFR)**

*A 16 hour fast with an 8 hour feeding window (16:8) is a common TFR protocol… does Jason think there are clinical benefits from a 16:8 fasting protocol?*

- Yes, we see people get better
- However, they can see *even better* results with a change to the type of food eaten during that window
- Jason says going back to the 1970s, people were averaging about 14 hours of “fasting” before their dinner and their breakfast
- Nowadays, our daily “eating window” is much larger (about [15 hours per day](https://www.ncbi.nlm.nih.gov/pubmed/?term=28264001%5BPMID%5D) per research by [Satchin Panda](https://www.salk.edu/scientist/satchidananda-panda/))
- So simply going back to the 16 hours of fasting “brings us back to baseline” and can be a major improvement for people

*Why? ⇒* It’s **more practical** than counting carbs (or calories)

- Jason believes 16:8 fasting is more effective at weight loss than dietary restriction or calorie restriction largely because it is simply more practical/“easier”/less effort
- It’s so much easier to tell people,
  - “Between 12 and eight is your eating window. Everything else, don’t eat,”
  - …compared to…
  - “Look at everything that you eat in the day. Try and calculate how many carbs it is, and add it up so that you have some arbitrary less than, less than 120, less than 50, less than 20, whatever.”

*Peter’s experience with patients using TRF*

- He’s seen mixed results on 16:8
- Some patients who have really significant improvement
- Other patients experience no improvement whatsoever
- Generally, the tighter his patient squeeze the window (18:6, 22:2), the more benefits they see

**Intermittent fasting (more than 24 hours)**

- Peter says he sees the most benefit for patients who implement “intermittent fasting”
- Time-restricted feeding is fasting up to 24 hours
- Intermittent fasting is when intermittently (periodically) fast for more than 24 hours
  - And fasting can be a complete reduction of calories or it can be a hypo-caloric fast
    - Hypo-caloric means you can consume somewhere between 20% and 40% of your normal caloric requirement for a period of time (three to seven days) and then you repeat that cycle

*What type of protocols does Jason use for intermittent fasting with patients?*

Jason will individualize the fasting plan by taking the following things into account:

**1** How severe is their condition?

- Severe type two diabetic on a huge amount of insulin, we’re going to give a more stringent schedule than somebody who’s just prediabetic and wants to prevent it from getting into diabetes

**2** How old are they?

- It can be more risky for older people so may not be as aggressive
- That said, they have a patient in her 80s who did a 61 day fast
  - But generally they don’t recommend something that long, this particular lady just felt so good on it she didn’t want to stop

**3** How willing are they to do it?

- Some people are just not willing to fast as aggressively as Jason recommends

## A fasting case study: A diabetic patient with a non-healing foot ulcer [2:04:00]

Summary of the case

- Jason had a 40 year old patient with a non-healing diabetic foot ulcer for a year
- Jason told him, “You know, your problem is not your foot. Your problem is your diabetes, because the reason you have this foot ulcer is because of diabetes.”
- Jason immediately started him on a full week of fasting followed by a 36 hour fast 3 times per week
- His foot healed up in 3 weeks

*How did Jason manage this guy through this first week?*

- Peter points out: This is someone who was a “completely obligate glycogen consumer” and so he’s going to be in a “world of hurt” when his body runs out of glycogen
- Jason says that he just tells them up front, “This is gonna suck… you’re going to be hungry”
- In other words, as long as you warn people ahead of time, they can get through it
- And the other benefit is that after they realize that can do a full week, getting them to do a 24 or 36 hour fast is no big deal
- And to be clear, the only reason Jason started this aggressive is because of the urgency of the situation
- In a less severe case (i.e., a 40 year old with an A1c of 6.0), Jason would start them out slower and gradually move them up

**Every patient is different**

- You can’t apply a stock plan to everyone
- People respond differently
- Yet many “experts” try to say it’s this way or you are wrong…

> “I find that the people who are super dogmatic are the people who never see patients.”

## Keys to a successful fast [2:12:45]

*What percentage of Jason’s patients are willing to do a water-only fast for at least a period of three days?*

- Probably less than 50% (at least right off the bat)
- Just the other day, Jason was seeing a patient:
  - He is developing proteinuria
  - He was going into renal failure
  - Jason told him he needs to fast
  - His response was… “My endocrinologist says I can’t fast. No Way.”

*What percentage of people will do any fast at all?*

- **Fifty percent of people won’t fast for any period of time** at all, “*not even five hours*” says Jason
- People was so ingrained to think we have to constantly eat (example was the public’s reaction to the [CNBC story describing Jack Dorsey’s use of fasting](https://www.cnbc.com/2019/04/08/twitter-and-square-ceo-jack-dorsey-on-his-personal-wellness-habits.html))
- And only **about 20% of people will do a longer fast**

Physical vs. psychological

- “It’s not the physical side that actually gets them. It’s always the psychological side. The physical stuff is super easy to deal with. It’s the psychological part that’s really hard. . . That’s where we focus a lot of our attention, working on the psychological, how to set your environment up for success and coming up with different strategies for success and creating a supportive community that’s going to help your success.”

Supportive environment is key

- How, for example, do Muslims regularly fast? … It’s because the environment is supportive
- In the US, it is the opposite, people are telling you it’s dangerous
- Jason says that he is trying to create a community of people who are accepting of fasting and that was the impetus for writing the [books he wrote](https://www.amazon.com/Dr.-Jason-Fung/e/B01BT8K6FK%3Fref=dbs_a_mng_rwt_scns_share)

**Keys to overcoming the difficulty of fasting**

1 **Supportive environment**

- A family and environment that that supports you is essential
- If people are telling you to stop and that you’re crazy, you won’t get through it

2 **Setting expectations regarding symptoms**

- Telling the patient what to expect doesn’t relieve the symptoms but it makes “dealing with it a lot better”
- Potential symptoms include:
  - It may be hard to sleep
  - Headaches
  - Cramps
  - Diarrhea (or constipation)
  - Hunger

3 **Making sure they understand it is temporary pain for powerful results**

- Jason’s patient with the foot ulcer has a recent A1C of 5.9 which is not even pre-diabetic within a couple of months (which is a bit longer than somebody else who responds quick or is in a less severe situation)

*Why patients warning them ahead of time helps because…*

- They know what to do to relieve the symptoms (in cases you can do something i.e. headaches)
- They trust the doctor because the doctor told them something would happen and it did

**Peter’s tip for help with sleep**:

- Take [phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine) with the fast in the evening
- It calms down the adrenal glands

⇒ Example, an oral over-the-counter GABA

- Unfortunately, it’s becoming harder to get *centrally-penetrating* [GABA](https://en.wikipedia.org/wiki/Gamma-Aminobutyric_acid) over the counter, but even just *peripheral GABA* will take down some of that sympathetic tone

**Managing electrolytes**

*“The number of times that I’ve actually had to intervene or tell somebody to stop a fast because of electrolytes is zero.”*

*⇒ Sodium*

- You can get some people who do get a bit sodium depleted
- But if you’re otherwise healthy, your kidneys should never get to that state
- There are people from the [INTERSALT study](https://www.ncbi.nlm.nih.gov/pubmed/9022559) that actually barely eat any salt at all and still survive fine presumably because your body should be able to reabsorb all the sodium it needs

*⇒ Magnesium*

- A bit more difficult because a lot of type two diabetics are depleted of magnesium to start
- Often recommend magnesium supplements especially if a patient is experiencing a lot of the cramps

*⇒ For dizziness*

- Jason will recommend some bone broth (which is technically not a fast) but it’s got calories and amino acids that will help

*\*A long fast isn’t the only answer\**

- Jason tells his patients that if they feel really bad to just stop
- They can always regroup and start up again the next day
- Or you can switch strategies such as switching to a shorter fast, more frequently, or even move to a ketogenic diet
- “*There’s all kinds of things that we can do without doing a long fast.*”

**Managing hunger**

- Feeling hunger is normal, just make sure you aren’t *extraordinarily lethargic*

⇒ Important note from Peter:

- Even seasoned fasters still get hungry
- Personally for Peter, he feels quite hungry at some point in the day, every day
- But… it’s never a feeling of hunger that is more profound than a regular day feeling “really hungry”
- The seventh day of a fast is not a more profound hunger
- It’s the **anticipation of the hunger** that becomes problematic

> “For there is nothing either good or bad, but thinking makes it so.” —William Shakespeare in Hamlet Act 2, scene 2, 239–251

## Muscle loss during fasting, and why Jason isn’t worried  [2:24:45]

***Does Jason do anything specific to minimize muscle loss when his patients are fasting?***

- Nothing specifically, says Jason
- But he’s generally treating a very sick population (i.e., not bodybuilders) who urgently need to lose weight and correct things

*No excess skin after radical weight loss*

- One of the things that’s very unusual about fasting for weight loss as opposed to weight loss for other things is that **we don’t see the excess, flabby skin problems**
- Why?
  - Skin is made of protein and connective tissue
  - When you do the intermittent fasting, you go through a period where you have [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis) and you’re breaking down protein

*Skin flaps from calorie restriction*

- With massive weight loss from chronic calorie restriction, you are much more likely to see the large flaps of excess skin left over
- But your body should get rid of it… *so why doesn’t your body get rid of it?*
- It’s because you never went through this period of gluconeogenesis, where you actually are breaking down protein

***Protein loss or muscle loss?***

- Jason says that the protein loss is often confused and called muscle loss
- It makes no sense that the body should store food energy as glycogen and body fat, but the minute you need to use it, you start burning muscle

*⇒ Analogy*: “It’s like storing firewood for the winter. Then, as soon as you need to use it, you chop up your sofa and throw it in the fire. . . I don’t think our bodies are that stupid.”

**Gluconeogenesis**

- There’s a period, which is fairly limited, during the fast thing where you have gluconeogenesis
- Then you can see fat oxidation goes way up
- Here’s a [1969 study by George Cahill](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/575355)

⇒ [Paper by Frank Nuttall](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890841/)

- He tried to estimate how much excess protein
- He found that somebody who is overweight has 20 to 50% more protein than a regular person
- That excess protein is in the form of skin, muscle, connective tissue, blood vessels
- “*There’s all kinds of extra protein that goes along with being overweight and that all needs to go.*”

*Jason summarizes why is not worried about muscle loss:*

“I’ve treated a few thousands of patients with type two diabetes. . .how many patients have I had to stop because I was worried about muscle loss? That would be zero in six years. . . People rag on me all the time about this. It’s like, ‘Oh what about this? What about this?’ Okay, how many thousands of patients have you done this for? Try it on several thousand patients. Then come back to me and tell me if muscle loss is the most important thing for this 65-year-old, 300-pound man on 150 units of insulin.”

## Will fasting help a healthy person live longer? [2:31:30]

**Can a heathy person (meaning non-obese, insulin-sensitive, non hyperinsulinemic person) benefit from periodic fasting in terms of reducing the odds of chronic disease down the line?**

- “Absolutely, yes.”
- If you use fasting to drop your insulin levels every so often, you’re going to lower your chance of getting diseases of hyperinsulinemia (heart disease, stroke, cancer, Alzheimer’s disease, type two diabetes, obesity)

**What about something like quarterly prolonged fasting (5+ days) to increase longevity?**

- Jason says if you take the perspective of evidence-based medicine, you might say that there is no evidence it can improve longevity/ward off chronic disease
- However… what is the risk/reward ratio?
  - In terms of risk, Jason says it’s “just about zero”
  - In terms of reward, it could be potentially massive
- So the real question is… *why wouldn’t you do it?*

⇒ For example, let’s say you have rheumatoid arthritis

- If the [Valter Longo’s FMD](https://prolonfmd.com/fasting-mimicking-diet/?gclid=Cj0KCQjw9JzoBRDjARIsAGcdIDV4dpPV43VZ00Up_X0-S6dbLHbsi1KDbRcvDlHpMEE7cOkwSxCl2bMaAo3bEALw_wcB) says it can help “reset” your immune system and improve your autoimmune disease… *why wouldn’t you try it?*
- “*We know what prednisone does to people, so why wouldn’t I do seven days of fasting? The risk of that is zero. Say I don’t get any benefit from that, then I don’t have to do it ever again. What happens if things get a lot better? I’ve just treated my own disease. The reward can be so high, but you don’t have to guess that, you can just do it.*”

## Does fasting cause gallstones? [2:38:45]

*There is “*[*weak epidemiology*](https://ajph.aphapublications.org/doi/pdf/10.2105/AJPH.81.7.880)*” suggesting that skipping breakfast will increase your risk of* [*gallstones*](https://en.wikipedia.org/wiki/Gallstone)*, how often are you seeing that in your practice?*

- A lot of people have gallstones, say Jason, “*but I don’t see an* ***increased*** *risk*”

*Gallstones and the low fat diet*

- The problem is that people who follow a low fat diet seem to run into issues
- Your gallbladder uses bile to emulsify fats
- Therefore when there’s not fat in your diet the bile just sits around with all this stuff and you get sludge
- Then, you start eating a higher fat diet and you are then squeezing it out and you’re getting stones

> “I don’t see it clinically as a problem. I think what caused a lot of the problems was probably the lower fat diet because you’re simply not getting the flow. The intrahepatic flow. . . we think we’re so much smarter than our body, which has survived for millions of years. We’re going to eat zero fat and just have all this sludge just sit in the gallbladder because you never took it out. How does that make sense? To me, it makes no sense.”

§

## Selected Links / Related Material

**Jason’s books**: [4:50]

- [The Obesity Code: Unlocking the Secrets of Weight Loss](https://www.amazon.com/gp/product/1771641258/ref=dbs_a_def_rwt_bibl_vppi_i0)
- [The Diabetes Code: Prevent and Reverse Type 2 Diabetes Naturally](https://www.amazon.com/Diabetes-Code-Prevent-Reverse-Naturally/dp/1771642653)
- [The Complete Guide to Fasting: Heal Your Body Through Intermittent, Alternate-Day, and Extended Fasting](https://www.amazon.com/Complete-Guide-Fasting-Intermittent-Alternate-Day/dp/1628600012)
- [The Longevity Solution: Rediscovering Centuries-Old Secrets to a Healthy, Long Life](https://www.amazon.com/gp/product/1628603798/ref=dbs_a_def_rwt_bibl_vppi_i3)

**Jason is the co-founder of this website and dieting program**: [Intensive Dietary Management Program](https://idmprogram.com/) | (idmprogram.com) [4:50]

**Richard Feynman lecture where he explains the scientific method**: [10:30]

- *Shortened version*: [The Scientific Method-Richard Feynman](https://www.youtube.com/watch?v=OL6-x0modwY) | Sképseis (youtube.com)
- *Full version*: [Richard Feynman on Scientific Method (1964)](https://www.youtube.com/watch?v=0KmimDq4cSU) | Soccer Man (youtube.com)

**American Diabetes Association came out with new guidelines approving low carbohydrate diets as useful and as having the most evidence behind it**: [Low Carb Diet in 2019 American Diabetes Association Standards of Care](https://www.lchf-rd.com/2018/12/18/low-carb-diet-in-2019-american-diabetes-association-standards-of-care/) | JOY KIDDIE, MSC, RD (lchf-rd.com) [19:30]

**Trials that “failed because they were working on this incorrect paradigm of insulin resistance, the ‘lock and key’ paradigm”**: [46:00]

- ACCORD: [Effects of Intensive Glucose Lowering in Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa0802743) (Action to Control Cardiovascular Risk in Diabetes Study Group et al., 2008)
- ADVANCE: [Intensive Blood Glucose Control and Vascular Outcomes in Patients with Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa0802987) (The ADVANCE Collaborative Group et al., 2008)
- VADT (Veterans Affairs Diabetes Trial): [Glucose Control and Vascular Complications in Veterans with Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa0808431) (Duckworth et al., 2009)

**Peter’s discussion with Jake Kushner about how controlling glucose with increasing insulin may decrease microvascular disease but it increases macrovascular disease**: [#41 – Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights](https://peterattiamd.com/jakekushner/) | Peter Attia (peterattiamd.com) [46:45]

**SGLT2 inhibitors showing protective effects against kidney disease and cardiovascular events**: [SGLT2 Inhibitors and the Diabetic Kidney](https://care.diabetesjournals.org/content/diacare/39/Supplement_2/S165.full.pdf) (Fioretto et al., 2016) [50:45]

**The DCCT study showing insulin causes weight gain**: [The effect of intensive treatment of diabetes on the development and progression of long-term complications in insulin-dependent diabetes mellitus.](https://www.ncbi.nlm.nih.gov/pubmed/8366922) (Diabetes Control and Complications Trial Research Group et al., 1993) [59:30]

**3 year old develops type 2 diabetes, youngest person ever**: [Three-year-old girl diagnosed with type 2 diabetes](https://www.theguardian.com/society/2015/sep/16/type-2-diabetes-three-year-old-girl-obesity) | Sarah Boseley (theguardian.com) [1:05:00]

**The Twin Cycle Hypothesis by Roy Taylor**: [Type 2 Diabetes: Etiology and Reversibility](https://www.medscape.com/viewarticle/781719_7) | Roy Taylor (medscape.com) [1:06:00]

**2009 study by Peter Havel comparing glucose to fructose**: [Consuming fructose-sweetened, not glucose-sweetened, beverages increases visceral adiposity and lipids and decreases insulin sensitivity in overweight/obese humans.](https://www.ncbi.nlm.nih.gov/pubmed/19381015) (Stanhope et al., 2009) [1:10:45]

**The study looking at people who are extremely lean with severe insulin resistance ( lipodystrophy)**: [Lipodystrophy: Pathophysiology and Advances in Treatment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3150735/) (Fiorenza et al., 2012)

**New York Times article about lipodystrophy**: [Skinny and 119 Pounds, but With the Health Hallmarks of Obesity](https://www.nytimes.com/2016/07/26/health/skinny-fat.html) | Gina Kolata (nytimes.com) [1:14:00]

**Experiment from the 90s that suggested insulin caused weight gain even when eating 200-300 calories less**: [Intensive Conventional Insulin Therapy for Type II Diabetes: Metabolic effects during a 6-mo outpatient trial](https://care.diabetesjournals.org/content/16/1/21) (Henry et al., 1993) [1:19:00]

**Sam Klein study showing liposuction does not improve insulin resistance**: [Absence of an Effect of Liposuction on Insulin Action and Risk Factors for Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa033179) (Klein et al., 2004) [1:19:00]

**2006 paper theorizing that rapamycin would be a great longevity drug**: [In pursuit of the longevity dividend: what should we be doing to prepare for the unprecedented aging of humanity?](https://go.galegroup.com/ps/anonymous?id=GALE%7CA143579030&sid=googleScholar&v=2.1&it=r&linkaccess=abs&issn=08903670&p=AONE&sw=w) (Olshansky et al., 2006) [1:32:45]

**The first trial demonstrating the immense power of rapamycin to promote longevity**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009) [1:33:15]

**Jason’s case report about three patients with T2D that used fasting to reverse their diabetes**: [Therapeutic use of intermittent fasting for people with type 2 diabetes as an alternative to insulin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6194375/) (Furmli et al., 2018) [1:47:00]

**Altering the morphology of the duodenum may improve type two diabetes**: [Endoscopic Duodenal Mucosal Resurfacing for the Treatment of Type 2 Diabetes: 6-Month Interim Analysis From the First-in-Human Proof-of-Concept Study](https://care.diabetesjournals.org/content/39/12/2254) (Rajagopalan et al., 2016) [1:53:15]

**Recent study that suggested that people who skipped breakfast had a higher cardiac mortality**: [Association of Skipping Breakfast With Cardiovascular and All-Cause Mortality.](https://www.ncbi.nlm.nih.gov/pubmed/31023424) (Rong et al., 2019) [1:56:45]

**Satchin Panda’s work suggesting people eating window is about 15 hours per day**: [A camera-phone based study reveals erratic eating pattern and disrupted daily eating-fasting cycle among adults in India.](https://www.ncbi.nlm.nih.gov/pubmed/?term=28264001%5BPMID%5D) (Gupta et al., 2017) [1:59:45]

[**Chris Gardner**](https://med.stanford.edu/profiles/christopher-gardner)**‘s study comparing a low-fat vs. a low-carb diet**: [Effect of Low-Fat vs Low-Carbohydrate Diet on 12-Month Weight Loss in Overweight Adults and the Association With Genotype Pattern or Insulin Secretion](https://jamanetwork.com/journals/jama/fullarticle/2673150) (Gardner et al., 2018) [2:09:00]

**The CNBC story on Jack Dorsey’s use of fasting that sparked controversy**: [Billionaire Jack Dorsey’s 11 ‘wellness’ habits: From no food all weekend to ice baths](https://www.cnbc.com/2019/04/08/twitter-and-square-ceo-jack-dorsey-on-his-personal-wellness-habits.html) | Catherine Clifford (cnbc.com) [2:13:30]

**The five-year mortality following a diabetes related foot amputation**: [The impact of foot ulceration and amputation on mortality in diabetic patients. I: From ulceration to death, a systematic review.](https://www.ncbi.nlm.nih.gov/pubmed/25601358) (Jupiter et al., 2016)  [2:16:15]

**The INTERSALT Study showing that people barely consuming sodium did just fine while fasting**: [The INTERSALT Study: background, methods, findings, and implications.](https://www.ncbi.nlm.nih.gov/pubmed/9022559) (Stamler J., 1997) [2:21:15]

**A case study on Jason’s blog of a patient who lost over 100 pounds**: [#IDMsuccess Story: Life changes at 50](https://idmprogram.com/idmsuccess-story-life-changes-at-50/) | (idmprogram.com) [2:25:30]

**George Cahill starvation studies looking at gluconeogenesis**: [Blood Glucose and Gluconeogenesis in Fasting Man](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/575355) (Felig et al., 1969) [2:27:45]

**Cahill’s insulin infusion, noted in**: [Chapter 26 of Cerebral Metabolism and Neural Function: Alternate Fuel Utilization by Brain](https://coconutketones.com/wp-content/uploads/2016/10/CahillGF_CerebMetabolism.pdf) (Cahill and Aoki, 1980) [2:28:30]

**Insulin infusion experiment**: Metabolic effects of insulin, glucagon, and glucose in man: Clinical application (Aoki and Cahill, In Endocrinology, edited by DeGroot et al., p. 1843, New York: Grune and Stratten, 1979) [2:28:30]

**Two studies that took normal weight subjects and fasted them and infused them with insulin**: [2:28:30]

- *Cahill’s insulin infusion, noted in*: [Chapter 26 of Cerebral Metabolism and Neural Function: Alternate Fuel Utilization by Brain](https://coconutketones.com/wp-content/uploads/2016/10/CahillGF_CerebMetabolism.pdf) (Cahill and Aoki, 1980)
- *Insulin infusion experiment*: Metabolic effects of insulin, glucagon, and glucose in man: Clinical application (Aoki and Cahill, In Endocrinology, edited by DeGroot et al., p. 1843, New York: Grune and Stratten, 1979)

**Study that estimated excess protein in somebody who is overweight ranging to be 20 to 50% more protein than a regular person**: [Body Mass Index, Obesity, BMI, and Health: A Critical Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890841/) (Frank Q. Nuttall, 2015) [2:29:30]

**Valter Longo’s Fasting-mimicking diet is a type of intermittent fasting**: [Fasting-Mimicking Diet](https://prolonfmd.com/fasting-mimicking-diet/) | (prolonfmd.com) [2:34:00]

**Weak epidemiology suggesting that skipping breakfast will increase your risk of gallstones**: [A Prospective Study of Hospitalization with Gallstone Disease Among Women: Role of Dietary Factors, Fasting Period, and Dieting](https://ajph.aphapublications.org/doi/pdf/10.2105/AJPH.81.7.880) (Sichieri et al., 1991) [2:38:45]

§

## People Mentioned

- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (physics, someone both Peter and Jason admired) [8:45]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) (debated Niels Bohr over quantum mechanics) [8:45, 15:00]
- [Niels Bohr](https://en.wikipedia.org/wiki/Niels_Bohr) (debated Einstein over quantum mechanics) [8:45]
- [Isaac Newton](https://en.wikipedia.org/wiki/Isaac_Newton) (famous physicist) [11:45]
- [Joseph Kraft](https://www.diabetes-epidemic.com/about-the-author.html) (realized you could see insulin resistance coming by observing insulin rather than blood glucose) [1:04:15, 1:09:00]
- [Roy Taylor](https://www.newcastle-hospitals.org.uk/staff-profiles/14178.aspx) (reversibility of type 2 diabetes) [1:06:30, 1:51:15]
- [Naji Torbay](https://www.weightcareclinic.com/) (mentor of Peter, endocrinologist who got Peter to think of hyperinsulinemia as an endocrine condition) [1:09:00]
- [Peter Havel](https://nutrition.ucdavis.edu/people/peter-havel) (studies comparing glucose to fructose) [1:10:45]
- [Sam Klein](https://gns.wustl.edu/about/faculty/samuel-klein-md/) (obesity research) [1:21:00]
- [Satchin Panda](https://www.salk.edu/scientist/satchidananda-panda/) has done all these studies about how long people actually eat [1:59:45]
- [Guns N’ Roses](https://en.wikipedia.org/wiki/Guns_N%27_Roses) [2:06:45]
- [Chris Gardner](https://med.stanford.edu/profiles/christopher-gardner) (low fat vs. low carb study) [2:09:00]
- [Jack Dorsey](https://en.wikipedia.org/wiki/Jack_Dorsey) (big controversy after it came out that he does fasting) [2:13:30]
- [William Shakespeare](https://en.wikipedia.org/wiki/William_Shakespeare) (“nothing is either good or bad, but thinking simply makes it so”) [2:24:30]
- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (gluconeogenesis) [2:27:45]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (diabetes researcher, starvation studies, gluconeogenesis) [2:27:45]
- [Frank Nuttall](https://www.sharecare.com/doctor/dr-frank-q-nuttall) (excess protein study in obese people) [2:29:30]
- [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) ([Fasting-Mimicking Diet](https://en.wikipedia.org/wiki/Valter_Longo#Fasting_mimicking_diet)) [2:34:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/06/jason-fung-bio-image-500x500.jpeg)

##### Jason Fung, M.D.

Dr. Jason Fung is a Canadian nephrologist who one of the most significant clinical practices that utilizes fasting for treatment of metabolic disease in Toronto, Canada.

He has written multiple [best-selling books](https://www.amazon.com/Dr.-Jason-Fung/e/B01BT8K6FK%3Fref=dbs_a_mng_rwt_scns_share) and he co-founded the [Intensive Dietary Management program](https://idmprogram.com/).

Dr. Fung graduated from the University of Toronto and completed his residency at the University of California, Los Angeles.