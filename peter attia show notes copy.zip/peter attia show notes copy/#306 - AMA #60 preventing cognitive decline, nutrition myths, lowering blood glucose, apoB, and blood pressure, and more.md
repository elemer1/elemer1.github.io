# #306 – AMA #60: preventing cognitive decline, nutrition myths, lowering blood glucose, apoB, and blood pressure, and more

**Source:** [https://peterattiamd.com/ama60/](https://peterattiamd.com/ama60/)

---

In this “Ask Me Anything” (AMA) episode, Peter provides insights on a broad range of important topics. He delves into the prevention of cognitive decline, the link between cardiovascular disease and Alzheimer’s disease, and methods to lower blood glucose, insulin, and apoB. He also addresses nutrition-related queries, exploring the impact of dietary habits on weight loss and longevity, how a person can identify the best diet for themselves, and common nutrition myths. Additional discussions include optimal blood pressure, daily step goals, the benefits of standing versus sitting desks, and much more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #60 show notes page](https://peterattiamd.com/ama60). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of topics and episode format [1:40];
- Preventing cognitive decline [5:00];
- How to lower blood glucose and insulin [13:30];
- The relationship between lipids, CVD, and Alzheimer’s disease, and whether statins can increase the risk of neurodegenerative disorders and AD [23:15];
- Reducing apoB levels through exercise and diet [31:45];
- Pharmacological options for lowering apoB [38:00];
- How nutrition impacts longevity via metabolic health, muscle mass, BMD and more [40:15];
- How can someone determine the best diet for themselves? [43:45];
- Nutrition myth: All weight loss is good [46:45];
- Nutrition myth: Metabolic rates are dramatically different among individuals based on genetics [49:00];
- Nutrition myth: Losing weight after a brief period of overeating is impossible [53:45];
- Nutrition myth: GLP-1 agonists are a replacement for a healthy lifestyle [57:45];
- Nutrition myth: There is a single best diet for weight loss [1:03:00];
- Nutrition oversimplification: All calories are created equal [1:05:45];
- Daily step goals [1:06:45];
- The benefits of standing versus sitting throughout the day [1:10:45];
- How to identify the most impactful and easiest-to-implement ways to improve your health [1:12:30];
- The critical importance of emotional health [1:14:30];
- Why supplements should be considered as supportive aids rather than primary solutions in one’s strategy to improve longevity [1:18:00];
- Strategies for reducing high blood pressure [1:20:45];
- Peter’s biggest frustrations with “mainstream health advice” [1:28:00];
- Peter’s chaotic, yet cherished, morning routine [1:31:00]; and
- More.

§

The Peter Attia Drive

Preventing cognitive decline, nutrition myths, lowering blood glucose, apoB, and blood pressure, and more

§

## Show Notes

§

## Overview of topics and episode format [1:40]

- Today’s AMA will be in a rapid-fire Q&A style, different from the usual deep dives.
- Previous rapid-fire AMAs have been well-received.
- This format allows covering a variety of topics and questions more broadly.
- Answers will be more conversational, similar to how Peter would speak to a patient.
- Topics include:
  - Preventing cognitive decline
  - Various nutrition questions
  - Relationship between cardiovascular disease and Alzheimer’s disease
  - Weight loss and longevity
  - Fasting
  - Blood pressure
  - Step requirements
  - And more.
- Peter has recently shifted his in-person presentations from a lecture format to a Q&A format and has found it a better style for the listeners
- He believes a well-moderated Q&A is generally more engaging for the audience.

## Preventing cognitive decline [5:00]

***If someone came to Peter and said, “What’s the best thing I can do? How can I prevent cognitive decline in my life,” what would Peter say to them?***

- Well, there is a “playbook” of modifiable behaviors that one can do to reduce your risk of dementia and prevent cognitive decline
- That said, genetics does play a role in cognitive decline (e.g., APOE4 gene and probably others we’re not yet aware of)
- Outside of that, *what can you do with respect to your behavior to reduce the risk*?
- The overlap between reducing the risk of a disease known as dementia is virtually identical to the steps you take to reduce the risk of cognitive decline
- *Are there differences*? Sure there are
- If you’re talking about patients in whom we’re trying to reduce the risk of dementia, and for example, we see serum markers of low amounts of amyloid accumulation, we may actually turn to pharmaceutical agents that reduce the amount of amyloid there
- So that’s something that wouldn’t be in the playbook.

**Let’s now talk about cognitive decline in the NON-pathologic sense**

**Three most important things**:

*Exercise*

- Exercise is the most powerful in terms of magnitude, effect size, and the preservation of cognitive function
- Both strength training and cardio are essential — it’s not an either/or situation

⇒ See [AMA #46](https://peterattiamd.com/ama46/) all about brain health

*Metabolic health*

- The brain, this tiny organ, is roughly 2% of your body weight and yet approximately 20% of your metabolic demand
  - if you think about that enormous asymmetry, it tells you that anything that plays a role in fuel partitioning and energetics is going to have an outsized impact on your brain
- And all of that points towards having remarkable fuel partitioning, being very insulin sensitive and being very metabolically flexible
- If you dispose of glucose very efficiently, you are by definition very metabolically flexible, which means you are able to access as substrate both fatty acid and glucose for ATP production
- the most obvious example of this is if you look at people at the far end of the spectrum in terms of metabolic inflexibility, we see that in the disease state of type two diabetes and in people with type two diabetes, the increase in the risk for Alzheimer’s disease, depending on where you look, could be anywhere from 40 to even 100%
- “*And the good news is those go hand in hand. Exercise is one of the most important tools to increase metabolic flexibility*.” says Peter

*Sleep*

- The epidemiology would suggest that if an individual is not sleeping in appropriate length or stages, their increase in Alzheimer’s disease specifically, but probably in other forms of dementia, also goes up
  - See: [The connection between sleep and Alzheimer’s disease](https://peterattiamd.com/the-connection-between-sleep-and-alzheimers-disease/)
- Sleep is not a passive thing, it’s an active form of recovery for the brain

**Cognitive activities**

- So after those three things, the next most important thing is what you actually do with your brain and body
- Engage in complex activities that combine brain and body (e.g., dancing, learning new skills).
- More beneficial than simpler mental exercises like crossword puzzles.
- Practical examples:
  - Peter’s father, at almost 87 years old, still works daily, which keeps his brain active and sharp.
  - Peter likes driving (like his F1 simulator) because driving is one of those things that involves so many senses, so your eyes, your ears, and your proprioceptive vestibular system

*Peter on “retirement” from work*

> “We should think about retiring as a time when we don’t work for money anymore. But I really think it’s probably important that people are working throughout their entire lives, meaning they’re working on something that is keeping their brain challenged.” —Peter Attia

**Supplements**

- Supplements exist but are less impactful compared to exercise, metabolic health, and sleep.
- The mentioned lifestyle factors have a significantly much larger effect on preventing cognitive decline.

## How to lower blood glucose and insulin [13:30]

***If someone gets blood work and they see that their glucose and/or insulin is high, what should they do about it?***

- First thing is you have to be mindful of how you’re looking for it — “there’s high and there’s HIGH”
- For instance, say the fasting blood glucose of 103
  - Well, it’s hard to know what to make of that.
  - Is that high?
    - Yeah, that’s technically higher.
    - If you haven’t eaten in 10 hours and you woke up and your blood glucose is 103, that is higher than you would expect
    - But there are other reasons for it that might not suggest pathology
  - So that’s why you should also be looking at an insulin
    - If you see a low insulin level, say four or five, coupled to that glucose, Peter would want more data before he jumped to a diagnosis
- This is where he’d look at a later in the day fasting glucose
  - If the person is willing to fast later, then you would want to see if it is still high or whether it has come down
  - Peter is an example of this situation
    - If you draw Peter’s blood first thing in the morning, he will always have a slightly elevated glucose (high 90s, low 100s) but his insulin is going to be very low
    - However, if Peter continues to fast until mid-morning, his glucose is going to be 70
    - So there’s something about the morning for Peter… could be the dawn effect or it could be genetic
    - This is not that uncommon

**Now let’s assume though we’re talking about a situation where the person truly has problems with high glucose**

- This is a person who through CGM or other tests like an oral glucose tolerance test reveals they have too high a level of glucose, and even when challenged with glucose, you don’t dispose of it well or efficiently
- Or if they do dispose of it efficiently, they require too much insulin to do it
- Too much insulin to dispose of glucose is the “canary in the coal mine that comes long before you see excursions of glucose that are too high”
- The first thing you’re looking for is elevations of postprandial insulin, even in the presence of normal glucose
- And that may precede elevated levels of glucose, which is putting you on a path towards type two diabetes by years

What we have to do is fix the problem by looking at four big things that drive it:

- **1) Exercise**:
  - Focus on Muscle Insulin Sensitivity: Muscles dispose of most glucose, around 80%, making them the largest glucose storage depot.
  - Role of the Liver: The liver also stores glucose but has a much smaller capacity, roughly 20% compared to muscles.
  - Importance of Exercise: Exercise is the most effective way to increase muscle insulin sensitivity.
  - Insulin Dependent and Independent Pathways: Insulin gets into muscles through both pathways, with insulin-independent uptake occurring especially after exercise.
  - Impact of Aerobic Exercise: Aerobic exercise, particularly zone two efforts, helps muscles absorb glucose without generating more from the liver.
  - Glucose Management in Type 1 Diabetes: Exercise helps manage blood glucose levels effectively, even in those with type 1 diabetes who have insufficient insulin.

- **2) Nutrition/carb restriction**:
  - Carbohydrate restriction is essential for controlling glucose levels
  - That said, although overall caloric restriction can also improve glycemic control.
  - But, it’s important to note that simply restricting carbs won’t be effective especially in the context of excess calories
    - Example: Increasing from 3000 to 3500 calories on a ketogenic diet will not effectively lower blood glucose
- **3) Sleep**:
  - Poor sleep significantly affects glycemic control
  - Peter personally has seen his blood glucose levels raising by 10-15 mg/dL following a really poor night of sleep
- **4) Hypercortisolemia/Stress Management**:
  - Persistent elevations in cortisol increase hepatic glucose output, which of course increases circulating glucose levels
  - “*The hard part is that’s the hardest thing to control. It’s the hardest behavior to mitigate*.”

> “*For many of our patients, once we’ve gone through box one, box two, and box three, which by the way almost always fix it, and if they don’t fix it completely, they render it completely manageable. You can still sometimes see persistent elevations of glucose on account of box four.*” —Peter Attia

**Pharmacologic Strategies**:

- Multiple classes of drugs can lower glucose, mainly used for type 2 diabetes.

Efficacious drugs include:

- SGLT2 Inhibitors: Moderately potent, slight risk of genital infections due to glucose urination.
- GLP-1 Agonists: Most potent, but expensive and reduce appetite significantly, potentially affecting parasympathetic and sympathetic outputs.
- Metformin: Considered first-line, with transient GI side effects, but potential concern over impairing aerobic function due to mitochondrial inhibition.
- **Usage Caution**: Pharmacological interventions should be secondary to addressing the top four lifestyle factors (exercise, nutrition, sleep, stress) for managing glucose levels.

The most efficacious drugs today would be:

- SGLT2 inhibitors
  - [AMA #53](https://peterattiamd.com/ama53/)
- GLP-1 agonists
  - [AMA #29](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)
  - [AMA #45](https://peterattiamd.com/ama45/) (pros and cons)
- Metformin
  - [Episode #204 with Nir Barzilai](https://peterattiamd.com/nirbarzilai2/)
  - [AMA #35](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/)

## The relationship between lipids, CVD, and Alzheimer’s disease, and whether statins can increase the risk of neurodegenerative disorders and AD [23:15]

**We see a lot of questions on the relationship between lipids, cardiovascular disease, and Alzheimer’s disease.**

**Additionally, some people are worried that statins can increase the risk of neurodegenerative disorders.** (see [AMA #46](https://peterattiamd.com/ama46/) which addresses this concern)

***So what do we know? How would you talk to someone on the relationship between lipids and AD?***

Let’s start with a start with the high level discussion:

- Statins, which are the most ubiquitous drugs used for lowering lipids, work by inhibiting HMG-CoA reductase, reducing cholesterol synthesis primarily in the liver, which upregulates LDL receptors and lowers LDL and ApoB levels in the blood.
- This mechanism has been shown to effectively reduce cardiovascular disease across various populations.
- Epidemiological data suggest that lower cholesterol, blood pressure, smoking, and diabetes risks are beneficial for both heart and brain health, reducing dementia risk.
- However, no primary studies have directly examined the impact of statins on dementia risk.
- Secondary analyses indicate that statins either have no effect or reduce dementia risk, with a recent [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34871380/) showing a 20% reduction in all-cause dementia and a 32% reduction in Alzheimer’s disease among statin users

“So I would take that as a pretty good sign that statins, certainly at the population level, are brain healthy.” —Peter Attia

⇒ See [AMA #46](https://peterattiamd.com/ama46/)

Peter mentioned the upcoming STAREE study (An RCT on statins with dementia as the primary outcome is currently in progress – STAREE using atorvastatin vs placebo–expected 2025) potentially providing more definitive answers

Peter brings up a small caveat:

- There are a subset of patients that if they really need aggressive lipid lowering, and if in years past we would’ve used aggressive statins, we will always turn to another tool
- These are patients who are at some elevated risk for dementia, so that can either be family history or genetic history
- If they happen to be very low synthesizers of cholesterol, which we can measure using something called desmosterol—the penultimate molecule in the cholesterol synthesis, one of the two cholesterol synthesis pathways, and it’s also particularly sensitive for brain cholesterol
- If we have patients who are low synthesizers, low desmosterol, and at high risk for dementia, we’ll simply not use a statin, because again, you don’t need to
- We have enough other drugs so we can still be as aggressive as we want to if we need to be for cardiovascular health without having to subject them to at least kind of a theoretical risk that still may be, may not be related to statins

## Reducing apoB levels through exercise and diet [31:45]

**If a person is relatively healthy (not undermuscled, not overnourished) but they have high apoB…** *How much can that person lower my APOB through just exercise and diet versus going the pharmacological route?*

⇒ Just a few episodes about apoB: [#229](https://peterattiamd.com/understanding-cardiovascular-disease/), [#238](https://peterattiamd.com/ama43/), [#276](https://peterattiamd.com/peter-faq/)

\*\*\*

- LDL and APOB concentrations are highly genetically determined
- With that said, let’s ask the question, *how can we through lifestyle modify it?*
  - The most effective way to do it is if you are a person who is very insulin resistant, you are going to have by far the biggest benefit in fixing your underlying metabolic disease, and you could have easily a 20 to 25% reduction in APOB through that mechanism

Let’s go through what impacts APOB concentration… APOB concentration is going to be dependent on:

- 1) How much cholesterol you synthesize (highly genetic) and how much cholesterol you reabsorb
  - Because that cholesterol that you synthesize eventually makes its way back to the liver, primarily through LDL, it gets secreted in bile, it gets reabsorbed in the GI tract, and it gets put back in the pool
  - Those are very regulated processes and they can both be manipulated pharmacologically
  - But those are factor on and factor two that determine LDL concentration or LDL cholesterol concentration, APOB concentration
  - Why? Because those two largely determine the circulating pool of cholesterol in your body and cholesterol is the dominant “cargo” in the APOB particle.
- 2) Triglyceride concentration
  - Your triglyceride concentration determines the other cargo—so it’s cholesterol, ester and triglycerides that are the main cargoes that lipoproteins traffic in
  - And so, anything that lowers your triglycerides is going to lower APOB, and you will have by far a bigger effect on your APOB targeting triglyceride than cholesterol, because behaviors have a greater effect there (with one exception which will be addressed shortly)
  - So if you show up and your triglycerides are 187 milligrams per deciliter and your APOB is elevated, let’s get that trig down to 60 milligrams per deciliter and we’ll see a 25% reduction in your APOB
  - With patients that have very high trigs, Peter doesn’t go to pharmacology until we lower the trigs
    - The reason for that is when you lower the trig from 187 to 67, you’re getting so many other benefits besides the APOB reduction and we want those benefits no matter what

*What about exercise?*

- What effect does exercise have on this? ⇒ The answer is virtually none
- If you look at studies that look at LDL cholesterol, because they’re not looking at APOB reduction with exercise, we’re talking about a couple of milligrams per deciliter.
- So even though these studies might find statistically significant findings, they’re not clinically relevant.
- If your LDL cholesterol is 120 milligrams per deciliter, taking it to 116 milligrams per deciliter is absolutely of no clinical bearing.
- If we’re going to really want to get into primordial prevention, you’re going to want that LDL cholesterol at 50 milligrams per deciliter and you’re not going to get there with exercise

*Other forms of nutrition besides the broad improvement in metabolic health*:

- This is where dietary fats play a role
- Now, under normal circumstances, people eating relatively normal diets, you don’t move the needle as much as you think
- You will reduce LDL cholesterol and APOB by substituting—even isocalorically—saturated fat for monounsaturated fat and polyunsaturated fat
  - We’re talking about 7 or 8 milligrams per deciliter with a 5% change in fat composition
  - That said, Peter would argue that’s not very statistically significant.
- So if you want to move LDL cholesterol or APOB significantly with dietary changes, you have to do something much more draconian
- If a person goes into a complete state of fat reduction, so they’re getting 10-15% of total k cals from fat, they will absolutely have a more significant effect on LDL and they can achieve near physiologic levels of LDL.
  - Peter has never and will never recommend that approach
  - Peter thinks the health consequences of that are so far outweighed by the benefits that you get from a cardiovascular standpoint that there is simply no upside to doing that
- Conversely, when you look at people who go on very high saturated fat diets, they can easily resemble folks who have familial hypercholesterolemia, meaning LDL cholesterol levels in excess of 190 milligrams per deciliter
  - In those individuals, simply reducing saturated fat will have a profound impact
  - So that’s basically the net net of how one really manipulates LDL cholesterol
  - And when we see people that show up looking like they have FH, the first question we ask is, “What are you eating?”
    - And if they say, “Oh, I’m on a ketogenic diet and I eat coconut oil out of a jar, and I drink MCT in my coffee 15 times a day.”
    - We’re like, “Great, we’re going to assume you don’t have FH and let’s fix your diet.”

## Pharmacological options for lowering apoB [38:00]

Effectiveness of lifestyle changes:

- The ability to lower LDL and APOB through lifestyle alone depends on individual risk factors and baseline levels.
- Some patients can maintain an APOB of 50-60 mg/dL with diet and exercise alone, especially if they have no current signs of cardiovascular disease, such as a calcium score of 0.
- For these patients, further pharmacological intervention may not be necessary, and they can continue with their current lifestyle modifications.

Need for pharmacological intervention:

- For individuals with naturally higher APOB levels (e.g., 80-100 mg/dL) and signs of cardiovascular disease (e.g., elevated calcium score), lifestyle changes alone may not be sufficient.
- For example, Peter mentions his own case, where his natural APOB levels are between 80-100 mg/dL, and he had a calcium score of 6 at age 35.
- To significantly reduce the risk of cardiovascular disease, he aims to lower his APOB to the 30-40 mg/dL range, which requires pharmacotherapy.

Calcium Score Testing:

- The decision to perform a calcium score test should be based on how the results will impact subsequent decisions.
- It’s crucial to have a clear plan for how to act on the test results: if the result is X, do Y; if the result is A, do B.
- Tests should not be conducted if the outcomes won’t alter the treatment strategy or if the responses to different results would be the same.
- The approach to calcium score testing is highly individualized, tailored to each patient’s situation and the potential changes in management based on the results.

⇒ See [AMA #5](https://peterattiamd.com/ama05/) and [AMA #34](https://peterattiamd.com/ama34/) for more about calcium scores

## How nutrition impacts longevity via metabolic health, muscle mass, BMD and more [40:15]

See [episode #222](https://peterattiamd.com/mattkaeberlein3/) with Matt Kaeberlein on how nutrition impacts longevity

\*\*\*

***What is the impact of nutrition on longevity?***

Role in metabolic health:

- Nutrition plays a crucial role in metabolic health, significantly impacting chronic diseases.
- The primary focus is on energy consumption relative to energy expenditure, determining energy balance.
- Total calorie intake is more critical than the type of calories consumed, although diet quality matters.
- A balanced diet with appropriate calorie intake is generally better than over-consuming even the healthiest foods
  - In real life, that may be a false example, because it probably is difficult to really overeat food that isn’t highly processed and over-engineered
- Overeating is more likely with highly processed, low-nutrient, and highly palatable foods, leading to poor metabolic health.

> “*Metabolic health, first and foremost, is the goal of nutrition.*” —Peter Attia

Muscle mass and bone mineral density (BMD):

- Beyond metabolic health, nutrition is vital for maintaining muscle mass and bone mineral density, essential for quality of life as we age.
- Sarcopenia (muscle loss) and osteopenia (bone loss) are significant concerns in older age.
- Proper nutrition, especially adequate protein intake, is crucial for preventing anabolic resistance and maintaining muscle and bone health.
- Many people enter old age already protein deficient due to under-consumption in middle age, highlighting the importance of early nutritional interventions.

## How can someone determine the best diet for themselves? [43:45]

**Determining the Best Diet for an Individual**

*Evolution of perspective*:

- Peter’s approach to determining the best diet has evolved over the past decade.
- Initially, he focused on a biochemical perspective, emphasizing the diet that produces the best results based on carbohydrate, fat, and protein ratios, and specific biomarkers.
- Today, Peter emphasizes the importance of adherence to a diet rather than its theoretical efficacy
- The best diet is one that an individual can consistently follow, even if it’s not the “perfect” diet
- He values a diet that scores 7 out of 10 in efficacy but can be maintained consistently over one that scores 10 out of 10 but is unsustainable

*Personal and empirical determination*:

- There’s no single test or set of tests to determine the best diet for an individual; it must be determined empirically
  - Peter recently [wrote a piece](https://peterattiamd.com/dna-diets-for-weight-loss/) on people that are trying to use genetic inference to make personalized diets
- Genetic inference might help in the future, but it’s not currently reliable.

*Practical approach*:

- Peter used to laugh when people said the phrase “the best diet is the one you can stick to” but he realizes his mistake now
- Peter prioritizes finding a sustainable diet for patients, even if it’s not the optimal biochemical choice, as long as it leads to consistent adherence and satisfactory results

## Nutrition myth: All weight loss is good [46:45]

**Focus on fat loss, not just weight loss**:

- Not all weight loss is beneficial; the goal should be fat loss, not muscle loss
- Muscle loss is generally undesirable except in very specific cases, like a retired professional bodybuilder

*Monitoring with DEXA scans*:

- DEXA scans are crucial for monitoring the loss of fat versus lean mass in patients who need to reduce their overall weight
- Peter stresses the importance of maintaining muscle mass through adequate protein consumption and exercise during weight loss

Use of GLP-1 and GIP agonists:

- These drugs can be used to aid in weight loss but should be carefully monitored with DEXA scans.
- If patients cannot maintain muscle mass while on these drugs, the treatment is discontinued to prevent undesirable outcomes.

*Importance of muscle maintenance*:

- Maintaining muscle mass is critical for overall health and longevity
- The DEXA scan provides a more comprehensive picture of body composition than a simple scale measurement, highlighting the importance of differentiating between fat loss and muscle loss.

⇒ For more on DEXA scans and body composition, check out [AMA #40](https://peterattiamd.com/ama40/) and [AMA #44](https://peterattiamd.com/ama44/)

## Nutrition myth: Metabolic rates are dramatically different among individuals based on genetics [49:00]

- A common myth is that metabolic rates are dramatically different and genetically determined
- Data suggests that energy expenditure is influenced by basal metabolic rate and factors like deliberate and non-deliberate movement

Role of lean mass:

- Basal metabolic rate is largely dependent on the proportion of lean mass versus fat mass.
- Lean mass requires more energy to maintain, leading to higher energy expenditure in individuals with more lean mass

Personal experience:

- Peter reflects on his teenage years, noting his extremely high energy intake and low body fat due to high levels of physical activity
- As an adult, despite having more lean mass and a likely higher basal metabolic rate, his overall energy expenditure is lower due to reduced physical activity

**Aging and metabolic rate**:

- Aging impacts body composition, which in turn affects energy expenditure and metabolic rate
- Factors like menopause can influence body composition, but overall, lean mass is a key driver of metabolic rate
- Body composition, more than genetic differences, drives variations in energy expenditure and what people consider their metabolic rate
- Effective management of body composition is crucial for maintaining a healthy metabolic rate

## Nutrition myth: Losing weight after a brief period of overeating is impossible [53:45]

Recovering baseline weight:

- A common myth is that it’s difficult to return to your baseline weight after deviating from a rigorous program.
- Example: Losing 10 pounds, gaining 5 pounds back during indulgent periods like Thanksgiving does not mean all progress is lost
- Returning to the program can help quickly shed the regained weight

Set Point Theory:

- Set point theory is often viewed unfavorably, suggesting difficulty in moving away from a long-term weight
- This theory may be somewhat true but it also applies in the opposite direction; gaining weight beyond the set point is equally challenging to maintain
- Consistency and returning to healthy habits are crucial for maintaining desired weight

- Focus on overall habits throughout the year rather than short-term indulgences
- Indulging occasionally, such as between Christmas and New Year’s, is less impactful than maintaining healthy habits the rest of the year

Personal anecdotes:

- Peter shares his love for sweets and the discovery of new treats like [chocolate-drizzled popcorn](https://www.instagram.com/peterattiamd/reel/C1U0XbQOH7m/)
- Despite having a sweet tooth, Attia emphasizes the importance of moderation and returning to healthy eating habits

⇒ Peter is very fascinated by the neuroscience of taste which was briefly spoken about on the [podcast with Stephan Guyenet](https://peterattiamd.com/stephanguyenet/)

## Nutrition myth: GLP-1 agonists are a replacement for a healthy lifestyle [57:45]

**Myth: nutrition and exercise are obsolete with GLP-1 agonists**

*GLP-1 Agonists and weight loss*:

- GLP-1 agonists, especially when combined with GIP like tirzepatide, offer unprecedented appetite suppression with a favorable safety profile
- Historically, similar appetite suppressants had significant side effects, often leading to their market withdrawal
- Despite the effectiveness of GLP-1 agonists in reducing fat mass, they do not build muscle mass or improve fitness, leaving gaps in overall health improvement.

*Limitations of weight as a health metric*:

- Weight alone is a poor proxy for health; total fat mass, especially subcutaneous fat, is also not ideal
- These drugs help reduce visceral fat and improve insulin sensitivity but don’t address all health aspects

**Misconceptions about replacing lifestyle changes**:

- There’s a dangerous myth that GLP-1 agonists can replace the need for sleep, exercise, and nutrition
- While GLP-1 agonists are beneficial, they should complement, not replace, a healthy lifestyle

*Impact on the fitness industry*:

- The rise of GLP-1 agonists has significantly impacted companies focused on weight loss, like WeightWatchers, as people opt for medication over lifestyle changes
- This shift has redirected wealth from lifestyle businesses to drug companies, highlighting a potential mistake in abandoning exercise and nutrition

*Future of GLP-1 Agonists*:

- The popularity and potential of GLP-1 agonists suggest they will continue to grow in influence
- It’s crucial to balance medication use with lifestyle habits for holistic health benefits

*⇒ Check out the previous episodes all about GLP-1 agonists*:

- Initial episode with Bob Kaplan: [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)
- Follow up episode: [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/)

## Nutrition myth: There is a single best diet for weight loss [1:03:00]

**No such thing as a universal best diet**:

- There isn’t a single best diet for weight loss, even from an efficacy standpoint
- Different diets can be effective for weight maintenance depending on individual adherence and needs

**Principles of an effective diet**:

- The best diet for weight loss and maintenance should provide sufficient satiation without leading to overconsumption
- Key characteristics include:
  - More real, unprocessed food than processed food
  - Higher protein intake
  - Higher fiber intake

*Variety of diets*:

- Many different diets can adhere to these principles, such as low carb, low fat, Mediterranean, vegan, or carnivore diets
- Effectiveness depends more on the quality of the food within the diet rather than the diet’s name

Examples:

- A ketogenic diet can be effective if it includes plenty of protein, fiber, and real food
- Conversely, a ketogenic diet heavy in packaged, processed foods and artificial sweeteners may not be effective
- The focus should be on what the diet contains rather than its label
- Prioritizing real food, protein, and fiber across various diet types can lead to better weight management outcomes

## Nutrition oversimplification: All calories are created equal [1:05:45]

Oversimplification:

- The idea that all calories are created equal is an oversimplification
- This concept is neither completely true nor completely false

Future discussion:

- Peter plans to discuss this topic in-depth with [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin), a researcher at the NIH, in a future podcast
- Kevin Hall has extensive experience studying the role of calories in energy balance
- Different types of calories can have different effects on the body
- The discussion will explore the nuances and complexities of calorie intake and its impact on energy balance and overall health

## Daily step goals [1:06:45]

**Peter’s general perspective on step goals**:

- The idea of a minimum step requirement per day varies depending on the individual
- Peter personally does not track step count because he exercises daily, and step count is not a significant factor in his overall fitness
- If his schedule allowed, he would gladly aim for 10,000 steps daily
- Most of his steps, especially during rucking, are not tracked as he doesn’t always carry his phone
- For example, during a long ruck, he can achieve around 37,000 steps, covering 16 to 17 miles in about five hours

Patient recommendations:

- For patients with low fitness levels, a prescribed daily step goal, such as 10,000 steps, is beneficial
- Starting with walking 10,000 steps at a pace of 3 miles per hour can serve as a foundation before moving to more strenuous activities

High volume walking:

- On hunting trips, he notices the highest step volumes, easily reaching over 20,000 steps per day
- The idea of a million-step challenge in a month is intriguing but time-consuming, requiring significant dedication and potentially a treadmill desk

Key consideration: Step count should be viewed in the context of an individual’s overall movement and fitness regimen

## The benefits of standing versus sitting throughout the day [1:10:45]

**Peter’s general view**:

- He believes there are benefits of standing over sitting throughout the day
- “*sitting is to lower back pain what bourbon is to alcoholism*” -Peter is not sure who this quote is attributed to but he likes it
- Sitting in a squatted position is very beneficial, but just sort of sitting there in a chair is not a great position to be in for a prolonged period
- Despite the benefits, Peter’s current work setup involves more sitting due to frequent Zoom meetings
- He anticipates changes in his setup with the new podcast studio, allowing for more standing time

Recommendations:

- For those with setups that facilitate standing, he recommends **prioritizing standing and regular exercise over just focusing on step counts**
- Peter acknowledges the growing popularity of treadmill desks and is considering one

## How to identify the most impactful and easiest-to-implement ways to improve your health [1:12:30]

**General approach**:

- The most important, easiest to access, easiest to implement, and highest impact health improvement varies per individual
- Start with the action requiring the least effort that yields the most significant result – and the reasoning here is twofold:
  - 1) Whatever’s going to give you the most benefit, especially if it’s done at the least effort you should do it just from a pure health perspective
  - 2) For building habits and confidence
    - The first change should also build confidence and create a foundation for further health improvements
    - For many, this might be improving sleep as it’s often the area where people can see the most immediate benefits

> “*You will feel the most improvement when you [make the easiest change] and you will have more confidence to take control over another aspect of your health*.” —Peter Attia

Example:

- Peter shared a story of someone who used a continuous glucose monitor (CGM) after reading his book, realized their glucose spikes, made dietary changes, and experienced better energy levels and exercise capacity
- The initial improvement in one area (nutrition in this case) enabled them to address other health aspects more effectively

## The critical importance of emotional health [1:14:30]

**Self-evidence and loneliness**:

- Emotional health is often sacrificed but is crucial since we are always with our thoughts and emotions
- At the end of the day, it’s just us with our minds, so if we’re unhappy, it questions the point of existence

Happiness and relationships:

- True happiness involves deep satisfaction from connections with others, not just material success or health.
- Imagining a life with everything except human connection illustrates the importance of relationships for happiness.

⇒ For more, check out the [episode with Arthur Brooks](https://peterattiamd.com/Arthurbrooks/)

Impact on life satisfaction:

- Poor self-relationship leads to poor relationships with others, resulting in deep dissatisfaction in life
- Emotional health is essential to counter the potential depression that can come with aging

Aging and emotional health:

- As physical and cognitive abilities decline with age, maintaining emotional health can bring joy and satisfaction
- Emotional well-being doesn’t have to decline with age and can be a source of strength and happiness despite other losses

Thought experiment:

- First, imagine you can have everything you desire in worldly terms, all the success, all the money, all the health
- Now, imagine you’re going to be the only person on the planet
- Robots will take care of everything else, and you will exist as the sole member of the species and you can’t communicate with anybody and you can’t have any relationships with anybody
- H*ow happy are you going to be*?
  - The answer? ⇒ “It’s actually the definition of hell on earth.”

> “We do crave relationships, we do crave intimacy, and you can’t have those things if your relationship with yourself is poor. If your relationship with yourself is poor, your relationship with others is going to be poor.” —Peter Attia

## Why supplements should be considered as supportive aids rather than primary solutions in one’s strategy to improve longevity [1:18:00]

Role of supplements:

- Supplements are considered a subset of exogenous molecules, along with pharmacological molecules and hormones
- They are the **least** important compared to exercise, nutrition, sleep, and emotional health
- Emphasizing supplements over fundamental health practices like exercise, nutrition, and sleep is seen as misprioritization
- The focus should be on optimizing these primary areas before considering supplements

Adjunct use:

- Supplements should be viewed as adjuncts, meaning they support but do not replace primary health practices
- Examples include:
  - Magnesium for sleep and muscle cramps ([AMA #54](https://peterattiamd.com/ama54/))
  - EPA and DHA (see [episode #83](https://peterattiamd.com/billharris/) with Bill Harris and [AMA #46](https://peterattiamd.com/ama46/))
  - Various forms of theracurmin ([AMA #46](https://peterattiamd.com/ama46/))
- It’s crucial to maintain realistic expectations and not overly rely on supplements for significant health improvements

## Strategies for reducing high blood pressure [1:20:45]

⇒ See [AMA #48](https://peterattiamd.com/ama48/) all about blood pressure

\*\*\*

**Importance of blood pressure**:

- Managing blood pressure is crucial for reducing risks associated with cardiovascular disease and Alzheimer’s disease (similar to managing apoB levels)
- Lower blood pressure correlates with better heart and brain health

Pharmacological management:

- Modern medicine offers a wide range of effective drugs to manage blood pressure with minimal side effects
- Unlike in the past, virtually all patients can now manage their blood pressure pharmacologically

Lifestyle interventions:

- Fortunately, blood pressure is highly responsive to lifestyle changes
  - This is the contrast with apoB levels which are very difficult to manage with lifestyle interventions outside of extreme measures that come with too many other problems
- Key interventions include 1) weight loss 2) exercise, and 3) sodium restriction (but other interventions exist as well)

1—Weight Loss:

- A rule of thumb is that for every kilogram of weight loss, there is a corresponding 1 mm Hg reduction in systolic blood pressure
- That means if a person’s walking around at 130 over 85, which is clearly hypertension, before you would put them on blood pressure medication, especially if they’re overweight, of course you would say, “Look, let’s see what happens if you lose 10 kilos.”
- You’re going to get the blood pressure improvement and you’re going to get so many other benefits that come with it
- Peter is not keen on putting a patient on medication if they’re not at an ideal weight

2—Exercise:

- Aerobic exercise can significantly [reduce systolic blood pressure](https://www.ahajournals.org/doi/10.1161/JAHA.112.004473?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) by 7-8 mm Hg with just 75 minutes per week
  - “*That is a profound improvement, and the more that exercise goes up, the more you’re going to see that*.” says Peter
- Strength training has less long-term impact on blood pressure
- NOTE: With intense cardio training, your blood pressure is also rising while you’re doing it. Remember, we’re never talking about the effect of blood pressure during exercise. We’re talking about it after.

3—Sodium restriction:

- The impact of sodium restriction on blood pressure is mixed in the literature and it seems to be highly individual
- Why is the literature mixed? ⇒  It probably comes down to two things:
- 1 There are genetic susceptibilities to sodium—actual genes that regulate a person’s sensitivity to sodium
- Individuals with genetic sodium sensitivity may benefit more from sodium restriction.
- 2 Insulin resistance
- In an insulin resistant person, I.E. a person with maybe more of the features you would see in metabolic syndrome, you’re going to see more sensitivity to sodium
- if a person is hypertensive but metabolically healthy, and we see this all the time, by the way, remember, hypertension is also quite genetic, that’s not a person I’m going to try sodium restriction in
- When I see a person who has all the hallmarks of insulin resistance, they not only have the glycemic markers, but their uric acid is high, their homocysteine is high, that’s a person that may indeed benefit from sodium restriction if they’re consuming excessive amounts of sodium

“*I do not think sodium restriction to an extreme is beneficial across the board, and I wouldn’t push sodium restriction down into the* ***sub 2 grams per day category***”

- But if a person is deemed sodium sensitive and they’re consuming 4 or 5 grams of sodium per day, then reducing it a little bit becomes a viable option

4—Alcohol consumption:

- Reducing alcohol intake to less than two drinks a day [can lower systolic blood pressure](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8101846/) by about 4 mm Hg in men and 3 mm Hg in women
- This reduction is a small part of the broader health benefits of reducing alcohol consumption

5—Stress management:

- Chronic stress is a significant factor in hypertension but it is challenging to control
- Strategies include exercise, reduced alcohol intake, better sleep, and overall lifestyle management

Comprehensive approach:

- A combination of these lifestyle interventions, when optimized, can significantly improve blood pressure management.
- For those still unable to achieve target levels (120/80 mm Hg), pharmacological options are available to complement lifestyle changes

⇒ The entire set of drugs for blood pressure management and how we should think about the use of those drugs in different were covered in [AMA #48](https://peterattiamd.com/ama48/)

## Peter’s biggest frustrations with “mainstream health advice” [1:28:00]

After a time-restricted feeding and cardiovascular disease study, which made huge waves, Peter wrote a weekly email pointing out how it wasn’t quite necessarily what was being reported: [Does time-restricted eating increase the risk of cardiovascular death?](https://peterattiamd.com/time-restricted-eating-and-ascvd/)

\*\*\*

***When you look at the “mainstream health advice,” what are some of your biggest frustrations around that?***

*Scientific illiteracy*:

- The media and many podcasters often lack a solid understanding of scientific principles, leading to misleading information and sensationalism
- There is a reward system that prioritizes being first to report over accuracy, often presenting non-peer-reviewed data without proper context or analysis
- In the past, data presented [like this](https://newsroom.heart.org/news/8-hour-time-restricted-eating-linked-to-a-91-higher-risk-of-cardiovascular-death) undergo thorough peer review before being published and discussed in the media
- Today, the media bypasses these steps, leading to premature and often incorrect conclusions being shared with the public
- “*Even if you put aside the fact that the media hasn’t peer reviewed it—meaning it’s not peer reviewed, and they’re not the peer reviewers—the media, as evidenced by virtually every response to that piece, is too scientifically illiterate to evaluate even the data as they are presented*.”
- And as such, the media present spurious data, they present data without context, and they are incapable of doing the type of analysis that Peter’s team were able to do or that many others could have done

> “*By far my biggest gripe is the never ending barrage of incorrect analyses, spurious reporting, sensationalized reporting, noise generating headlines that have created a cacophony of noise and chaos for the average consumer who’s just trying to get a handle on what to do*.” —Peter Attia

\*Recommended Resources:

- Check out the [Studying Studies AMA #30](https://peterattiamd.com/ama30/) and the [podcast with David Allison](https://peterattiamd.com/davidallison/) that break down scientific studies and nutrition in detail
- Future discussions with experts like [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) aim to provide more in-depth and accurate health information

## Peter’s chaotic, yet cherished, morning routine [1:31:00]

Peter [shared](https://www.instagram.com/peterattiamd/reel/C1CXrhCuVbk/?hl=en) his morning routine on instagram

\*\*\*

***What is your morning routine if anyone wants to emulate that in their life?***

- Peter suggests watching the [video](https://www.instagram.com/peterattiamd/reel/C1CXrhCuVbk/?hl=en) as way to really get a sense
- Peter’s youngest son is obsessed with football, wearing a jersey and holding a football every minute of the day, including indoors
- They’ve had discussions about not throwing the football at people unexpectedly, but accidents still happen, including hitting his wife and potential damage to valuables
- Adapting to the situation, Peter and Jill have accepted playing football in the house and created a “passing lane” to minimize damage
- His son also gets upset about school rules, like not being able to wear cleats
- Adding to the morning chaos, Peter’s Aussie Shepherd dog has been “strategically” placing hard chewed bone toys where Peter steps on them every morning

*Humor and reflection*:

- Peter humorously describes his mornings as anything but peaceful, filled with stepping on toys and dealing with his son’s football antics
- Despite the chaos, Peter and his wife cherish these moments, realizing they only have a few years left with their children at home
- Peter emphasizes the importance of appreciating time with young children, as he anticipates the sadness of an empty nest

> “*I think any parent should take a moment, sometimes it’s harder to do this than others, but I think just saying, ‘Hey, you only have a very limited amount of time with these little people, so make the most of it.’*” —Peter Attia

§

## Selected Links / Related Material

**AMA episode of The Drive all about brain health**: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) | Peter Attia (peterattiamd.com) [7:00]

**Epidemiology that would suggest that if an individual is not sleeping in appropriate length or stages, there is an increase in risk of Alzheimer’s disease & other forms of dementia**: [The connection between sleep and Alzheimer’s disease](https://peterattiamd.com/the-connection-between-sleep-and-alzheimers-disease/) | Peter Attia (peterattiamd.com) [9:45]

**The most efficacious drugs today for reducing blood glucose**: [21:30]

- SGLT2 inhibitors: [#279 – AMA #53: Metabolic health & pharmacologic interventions: SGLT-2 inhibitors, metformin, GLP-1 agonists, and the impact of statins](https://peterattiamd.com/ama53/)
- GLP-1 agonists:
  - [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)
  - [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/)
- Metformin
  - [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/)
  - [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/)

**AMA episode of The Drive that addresses the concern that statins could increase the risk of neurodegenerative disorders**: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) | Peter Attia (peterattiamd.com) [23:45]

**A recent meta-analysis showing a 20% reduction in all-cause dementia and a 32% reduction in Alzheimer’s disease among statin users**: [Statin use and risk of dementia or Alzheimer’s disease: a systematic review and meta-analysis of observational studies](https://pubmed.ncbi.nlm.nih.gov/34871380/) (Olmastroni et al., 2022) [27:45]

**Episodes of The Drive that discuss apoB**: [31:45]

- [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/)
- [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/)
- [#276 ‒ Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more](https://peterattiamd.com/peter-faq/)

**Episode of The Drive with Matt Kaeberlein on how nutrition impacts longevity**: [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/mattkaeberlein3/) | Peter Attia (peterattiamd.com) [40:15]

**Peter’s article on people that are trying to use genetic inference to make personalized diets**: [“DNA diets” are still a long way off from offering an easier route to weight loss](https://peterattiamd.com/dna-diets-for-weight-loss/) | Peter Attia (peterattiamd.com) [45:00]

**Peter shares his discovery of new treats like chocolate-drizzled popcorn on instagram**: [@peterattiamd](https://www.instagram.com/peterattiamd/reel/C1U0XbQOH7m/) | (instagram.com) [55:30]

**Episode of The Drive with Stephan Guyenet that touched on the neuroscience of taste**: [#212 – The neuroscience of obesity | Stephan Guyenet, Ph.D.](https://peterattiamd.com/stephanguyenet/) | Peter Attia (peterattiamd.com) [57:00]

**Episodes of The Drive that featured GLP-1 agonists**: [1:01:30]

- Initial episode with Bob Kaplan: [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)
- Follow up episode: [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/)

**Episode of The Drive about happiness with Arthur Brooks**: [#226 ‒ The science of happiness | Arthur Brooks, Ph.D.](https://peterattiamd.com/Arthurbrooks/) | Peter Attia (peterattiamd.com) [1:15:00]

**AMA episode of The Drive all about magnesium**: [#282 – AMA #54: Magnesium: risks of deficiency, how to correct it, supplement options, potential cognitive and sleep benefits, and more](https://peterattiamd.com/ama54/) | Peter Attia (peterattiamd.com) [1:19:00]

**Episodes of The Drive that discuss EPA and DHA**: [1:19:00]

- [#83 – Bill Harris, Ph.D.: Omega-3 fatty acids](https://peterattiamd.com/billharris/)
- [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/)

**Episode of The Drive that talks about the supplement, theracurmin**: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) | [1:19:00]

**AMA episode of The Drive all about blood pressure**: [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/) | Peter Attia (peterattiamd.com) [1:21:00]

**Aerobic exercise can significantly reduce systolic blood pressure by 7-8 mm Hg with just 75 minutes per week**: [Exercise Training for Blood Pressure: A Systematic Review and Meta‐analysis](https://www.ahajournals.org/doi/10.1161/JAHA.112.004473?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) (Cornelissen and Smart, 2023) [1:25:00]

**Reducing alcohol intake to less than two drinks a day can lower systolic blood pressure by about 4 mm Hg in men and 3 mm Hg in women**: [Alcohol Consumption and Hypertension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8101846/) (Cushman, 2001) [1:27:45]

**Peter’s weekly email about the media’s sensationalization of studies**: [Does time-restricted eating increase the risk of cardiovascular death?](https://peterattiamd.com/time-restricted-eating-and-ascvd/) | Peter Attia (peterattiamd.com) [1:28:00]

- The media report: [8-hour time-restricted eating linked to a 91% higher risk of cardiovascular death](https://newsroom.heart.org/news/8-hour-time-restricted-eating-linked-to-a-91-higher-risk-of-cardiovascular-death) | (newsroom.heart.org) [1:28:00]

**Episodes of The Drive that discuss how to read and understand scientific literature**: [1:30:00]

- Studying studies: [#188 – AMA #30: How to Read and Understand Scientific Studies](https://peterattiamd.com/ama30/) | Peter Attia (peterattiamd.com)
- Nutrition: [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) | Peter Attia (peterattiamd.com)

**Peter shared his morning routine on instagram**: [@peterattiamd](https://www.instagram.com/peterattiamd/reel/C1CXrhCuVbk/?hl=en) | (instagram.com) [1:31:00]

§

## People Mentioned

- [Arianna Huffington](https://en.wikipedia.org/wiki/Arianna_Huffington) [9:00]
- [Matthew Walker](https://en.wikipedia.org/wiki/Matthew_Walker_(scientist)) [9:00]
- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) [1:06:00]
- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) [1:30:00]

§