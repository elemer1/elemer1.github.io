# #352 ‒ Female fertility: optimizing reproductive health, diagnosing and treating infertility and PCOS, and understanding the IVF process | Paula Amato, M.D.

**Source:** [https://peterattiamd.com/paulaamato/](https://peterattiamd.com/paulaamato/)

---

This is part two of a two-part mini-series on fertility and reproductive health. Paula Amato is a leading expert in female reproductive health and infertility, widely recognized for her contributions to advancing fertility treatment and research. In this episode, which follows last week’s conversation on male fertility, Paula explores the biology of female fertility, including how hormonal changes regulate the menstrual cycle and ovulation, what those patterns reveal about fertility potential, and why both partners should be evaluated early in infertility workups. She discusses the role of the fallopian tubes, the causes of miscarriage, the impact of age and lifestyle on fertility, and treatment options for conditions like PCOS—including the emerging use of GLP-1 agonists. The episode also covers the evolution of IVF, advances in pre-implantation genetic testing, egg freezing, and the promise and limitations of next-generation reproductive technologies.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/paulaamato/the_Drive_public.png)

Play

#352 ‒ Female fertility: optimizing reproductive health, diagnosing and treating infertility and PCOS, and understanding the IVF process | Paula Amato, M.D.

#352 ‒ Female fertility: optimizing reproductive health, diagnosing and treating infertility and PCOS, and understanding the IVF process | Paula Amato, M.D.

1x15s30s

0:002:23:28

## We discuss:

- The finite nature of a woman’s egg reserve, how it changes over time, and the basic process of ovulation and fertilization [3:00];
- How hormones influence egg selection, and how and why chromosomal errors lead to most miscarriages [5:30];
- The full journey of conception—from hormonal cues triggering ovulation to fertilization, embryo development, implantation, and early pregnancy risks [16:30];
- How infertility is defined and diagnosed, and the broader trends contributing to rising infertility rates [25:15];
- Fallopian tube damage: how STDs and scarring impact fertility and raise ectopic pregnancy risk [31:30];
- Unexplained infertility: how doctors evaluate ovulation and cycles—and why more research on women’s health is needed [41:00];
- The defining symptoms of polycystic ovary syndrome (PCOS), its hormonal characteristics, and its relationship with insulin resistance [44:00];
- Managing PCOS without pregnancy: cycle regulation, androgen suppression, and insulin resistance treatment [46:00];
- The treatment approach for women with PCOS who are trying to conceive: GLP-1 use, ovulation induction, and timing protocols [49:45];
- Barriers to getting informed fertility care for PCOS: limited provider knowledge and access, insurance gaps, and next steps when ovulation treatments don’t lead to pregnancy [55:45];
- Fertility treatment for women with unexplained infertility, risk of multiple pregnancies with superovulation, and more [1:03:00];
- Intrauterine insemination (IUI): process, success rates, and when in vitro fertilization (IVF) becomes the better option [1:07:00];
- The history of in vitro fertilization (IVF), and how access and acceptance have evolved over time [1:16:45];
- The step-by-step process of IVF [1:19:30];
- The IVF lab process: egg retrieval, fertilization, embryo culture, and freezing [1:26:30];
- Genetic testing and embryo selection in IVF: aneuploidy screening, polygenic traits, and ethical concerns [1:41:15];
- Embryo transfer in IVF: timing, uterine preparation, and implantation support [1:47:30];
- Egg donation in IVF: indications, donor guidelines, and other considerations [1:50:45];
- How to choose the right IVF clinic [1:54:45];
- Innovations in fertility on the horizon, advice about freezing eggs, and more [2:02:00];
- Optimizing fertility through lifestyle: diet, stress management, sleep, exercise, and supplementation [2:07:45];
- Promising areas of fertility research [2:15:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Paula Amato is a Professor of OB/GYN at Oregon Health & Science University and a leading expert in reproductive endocrinology and infertility
- She’s been on the forefront of research in clinical practice of IVF, fertility preservation, and reproductive aging
- In this episode, we continue our two-part series on infertility
  - Last week, we [covered](https://peterattiamd.com/paulturek/) the male side of this with [Dr. Paul Turek](https://alphasperm.com/pages/paul-turek)
  - This week, we’re talking more about female infertility with Paula

In this episode, we discuss

- The biology of female fertility
  - How hormonal shifts drive the menstrual cycle and regulate ovulation, and what those patterns reveal about fertility potential
- How infertility is defined
- Where to begin a work-up, and why both partners should be evaluated early
- The role of the fallopian tube in natural conception, and how infections and/or structural issues can lead to infertility or atopic pregnancy
- The reality of miscarriage, and why most early losses are due to chromosomal abnormalities (not anything the patient is doing wrong)
- Increasing impact of age, lifestyle, and environmental factors on fertility
  - Especially as more people delay childbearing
- Causes and treatment options for polycystic ovarian syndrome (PCOS)
- The emergence of GLP-1 agonists in PCOS, and what we know (and don’t know) yet about their impact on fertility and pregnancy safety
- The nuances of diagnosing and treating unexplained infertility
- How age and ovarian reserve shape clinical decisions
- The evolution of IVF, from early methods to today’s technology
  - Including the use of preimplantation genetic testing
- Considerations around egg freezing ‒ how timing, age, and egg quantity influence outcomes and decision making
- Promise and limitations of next-gen reproductive technologies
  - Such as mitochondrial replacement and many other things

## The finite nature of a woman’s egg reserve, how it changes over time, and the basic process of ovulation and fertilization [3:00]

- The physiology in women is different from men, but no less complex, and there are some pretty unique things about it
- Sperm seem to be an infinite resource, men are constantly generating billions of these
- The opposite is true for women

**Women have a limited number of eggs**

- When an embryo or fetus develops, the gonad differentiates into either a testes or an ovary
- The main difference is that sperm is produced throughout a man’s lifetime, whereas women are born with a finite number of eggs

**⇒** The most eggs you’ll ever have is when you’re in your mom’s womb as a fetus, and by the time you’re born, there’s about 2 million or so eggs, and by the time you start menstruating, you’re down to maybe 400,000

***A 5-fold reduction in the number of eggs occurs from birth to age 12-14, and most eggs in ovaries undergo a process called*** [***atresia***](https://en.wikipedia.org/wiki/Atresia#Follicular_atresia) ***(they die)***

- Once a girl goes through puberty, every month (if she’s not on hormonal contraception) one of those eggs grows
  - Actually, probably a group of eggs every month starts to grow, but then one takes over and is released from the ovary and usually finds its way into the [fallopian tubes](https://en.wikipedia.org/wiki/Fallopian_tube)
  - That’s the tube connecting the ovary and the uterus
  - Normally if there’s not sperm around, the egg just reabsorbs and there’s no pregnancy;  the lining of the uterus sheds, and a girl or woman has a period every month
    - If there’s sperm around, there’s a chance that that egg might fertilize, and that fertilization usually happens in the fallopian tube
    - Then that now zygote or embryo travels down the tube into the uterus and some of the time implants into the the lining of the uterus and establishes a pregnancy

## How hormones influence egg selection, and how and why chromosomal errors lead to most miscarriages [5:30]

**The cycle of what’s happening in a woman of prime reproductive age (age 20) and the role hormones are playing**

- One of the things that has always fascinated Peter is the selection
- With males, we don’t think about that problem
  - The selection tends to be more metabolic or stochastic
  - The sperm that makes it isn’t really predetermined
- At day 0, a woman begins her [menstrual cycle](https://en.wikipedia.org/wiki/Menstrual_cycle), and she’s about 14 days from ovulation
- We start to see the interplay of [luteinizing hormone (LH)](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [follicle-stimulating hormone (FSH)](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone), particularly FSH
  - [The figure below shows how hormone levels change throughout the menstrual cycle]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f1-paulaamato-1024x677.png)

**Figure 1. Hormone levels during the menstrual cycle**. Image credit: OpenStax Anatomy & Physiology [Figure 27.15](https://openstax.org/books/anatomy-and-physiology/pages/27-2-anatomy-and-physiology-of-the-female-reproductive-system)

*Walk through what’s happening in that period of time that ultimately leads to one and only one egg being the chosen one*

- It’s a little random in women as well
- It’s true that the pituitary hormones (FSH and LH) are what drives growth of what we call the follicles
  - The eggs are inside the follicles
- Usually a cohort of eggs start to grow
  - The follicles start to get bigger and the cells surrounding the egg start to divide

Peter asks, “*What do they look like prior to all of that happening? These are cells that only have 50% of the genetic material. They’ve already undergone meiosis.*”

- Yes, they’re [arrested](https://en.wikipedia.org/wiki/Oogenesis#Meiosis_II) in [meiosis](https://en.wikipedia.org/wiki/Meiosis), and meiosis is not completed until they ovulate (and then in some cases are fertilized)
  - We have an arrested cell that has one of each of the mother’s chromosomes
    - Including one X chromosome by definition (one of her two sex chromosomes)

*Is this egg still in its “young” phenotype?*

- In other words, if the woman is 20-years-old and all of the cells in her body are functionally 20 years old, is this egg prior to ovulation still basically an infant cell?
- As far as we know, although there’s some data recently to suggest that perhaps the cells surrounding the egg are metabolically active and maybe aging
- Certainly we do know that the quality of the eggs decreases as women get older
  - That affects how the eggs and the chromosomes ultimately divide
  - That’s part of the reason it’s harder to get pregnant as you get older
  - Even though you’re ovulating, you may be releasing an egg every month, but that egg could be abnormal, and if it’s abnormal, it likely won’t fertilize
  - And if it’s abnormal, you don’t want it to fertilize and establish your pregnancy

***But you’re right, they’re pretty much arrested in time, certainly before puberty, and then every month a few start to develop***

- We don’t really know how that one egg is selected
- Definitely hormonal factors play a role, but it’s somewhat random
- One grows and then eventually is released

**Thinking about natural selection**

- Peter doesn’t want to anthropomorphize this too much, but one would assume that natural selection runs strong, and if a woman, by the time she begins her fertility stage of life has 400,000 eggs (on average), she only has a finite number of shots on goal (let’s just say 12 per year)
- If you look at **peak reproductive age (maybe 20-years-old)**, that’s a tiny sliver of 400,000
- You would have to assume that there is some selection that’s happening to pick the best few hundred of those 400,000

*Is there any evidence that some selection is happening?*

- Only in the ones that usually result in pregnancy; these are chromosomally normal
- Most of the embryos are chromosomally abnormal, and that’s because most of the eggs are chromosomally abnormal
- So, there is selection in that sense

***Most of the time, only the chromosomally normal embryos are the ones that implant and continue to develop***

Peter asks, “*And when you say chromosomally normal, are you referring to the egg or the zygote?*”

- They zygote

**⇒** Most of the abnormalities in chromosomes that happen in a zygote are believed to be related to maternal age

*Does that mean we think that the abnormality occurred way before ovulation, or when do we think that that occurred?*

- We think it occurred in the stage of meiosis that happens as the egg is developing that month
  - That ripening phase

**Explain how that ripening phase happens**

*If you were to sample eggs from a five-year-old girl (nowhere near reproductive age), is every one of those in a state of frozen meiosis?*

*How many things have to happen before it is ready to undergo full meiosis?*

*How do you go from that frozen meiotic state to an aneuploidic state? (and please explain these terms)*

- It’s a little bit of a black box because we can’t see exactly what’s happening
- The way we understand it is that the cells start off (including egg cells) as having 2 copies of each chromosome, but eventually has to become 1 copy in order to combine with a sperm (that also has 1 copy of each chromosome)
- During that process, there has to be disjunction of each of the pairs of chromosomes
  - There are 23 pairs of chromosomes (including X and Y, the sex chromosomes)

**⇒** It’s during that disjunction phase [of meiosis] when we think most of the errors happen [[aneuploidy](https://en.wikipedia.org/wiki/Aneuploidy)]

- Because if they don’t divide evenly (like 23 and 23), you’re going to get an extra one [chromosome, in one cell] and you’re going to be missing one [chromosome, in another cell]
- Then when it combines with sperm that also has a haploid set of chromosomes, there’s going to be an abnormal number [of chromosomes, called aneuploidy], and that affects development

Peter asks, “*That completion only occurs during the 14 days leading to ovulation?*”

- Ovulation and then fertilization; yes

***For Peter, that that explains why there must be either something going on with the egg or maybe the metabolic milieu around the egg from those cells that is changing the probability of success for that division of genetic material***

- Even though the eggs are “frozen in time”

**⇒** As a woman ages, the probability of successful division goes down

**Peter’s friend has a son with Down’s Syndrome**

- He’s probably 20 now
- This story occurred roughly 20 years ago
- When he was born, he was their third child
- They didn’t know about his condition until he was born
  - They hadn’t done amniocentesis or anything like that
- They were dealing with this right in the aftermath of their son’s birth
- The doctor, the GYN came in and Peter’s friend said he’d never forget this: the guy looked straight at his wife and said, “*Look, it’s important for you to understand that this is your fault.*”
  - The friend wanted to jump across the table and kill this guy
- But then what he realized is what the doctor was actually saying was this is the result of the egg releasing 2 copies of chromosome 21
- He came to appreciate what the doctor was trying to do there albeit in a completely clumsy way
- It always struck Peter as a great lesson in bad bedside manner

***The point here being is while*** [***trisomy 21***](https://en.wikipedia.org/wiki/Down_syndrome) ***is a very common form of aneuploidy, it’s also not lethal; there are many*** [***lethal forms of aneuploidy***](https://en.wikipedia.org/wiki/Aneuploidy#Types)

- Depending on the chromosomal abnormality, some only develop to a certain point and then stop developing
  - Some are compatible with live birth, but usually have some abnormalities

**If you were to look at all miscarriages that occur inside the first trimester, would you be able to hazard a guess as to what percentage of all miscarriages inside of 13 weeks are likely the result of aneuploidy?**

- Definitely the majority of them
- Probably close to 90% of them

Peter adds, “*Maybe someone listening to this who’s experienced miscarriages early in a pregnancy can take some solace in understanding that that was the body’s way of correcting something that was inevitable sooner rather than later.*”

- Miscarriages are very common, and aneuploidy is the most common cause
- Although there are other causes
- Usually we don’t do a whole lot of testing if it’s just 1 miscarriage because that’s very common
  - We just assume fetus or embryo was abnormal

**⇒** If a woman has 2 miscarriages in a row, that warrants some additional testing (regardless of her age)

*So if a 40-year-old woman had successive miscarriages, you wouldn’t just chalk it up to, well, she’s 40, of course these are aneuploidic eggs?*

- That’s the most likely explanation, but you don’t want to miss some other treatable cause
  - Because you have limited time

> “*One of the lessons here, hopefully for people listening is: if a couple miscarriages, they shouldn’t feel that they’ve done something wrong*.”‒ Peter Attia

- The woman shouldn’t beat herself up thinking:
  - Did I have one too many cups of coffee
  - Am I under too much stress
- There’s a 90% chance this was a bad split [bad separation of chromosomes in meiosis]

## The full journey of conception—from hormonal cues triggering ovulation to fertilization, embryo development, implantation, and early pregnancy risks [16:30]

**Day 0 ‒ a woman begins her period**

- We’re just getting ready to embark on her next fertility cycle
- The pituitary gland is secreting [luteinizing hormone](https://en.wikipedia.org/wiki/Luteinizing_hormone) and *follicle-stimulating hormone* [the figure below shows how hormone levels change throughout the menstrual cycle]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f2-paulaamato-1024x677.png)

**Figure 2. Hormone levels during the menstrual cycle**. Image credit: OpenStax Anatomy & Physiology [Figure 27.15](https://openstax.org/books/anatomy-and-physiology/pages/27-2-anatomy-and-physiology-of-the-female-reproductive-system)

*Walk me through what is happening in the next 14 days that leads to that ovulation*

- A group of eggs or follicles are starting to grow, and one gets selected
  - It’s random; we don’t understand why
  - This happens in the follicle, and a follicle is a fluid-filled, cyst-like structure that surrounds each egg
- That follicle continues to grow
- Hormonally, those cells surrounding the eggs are producing estrogen
- That [estrogen](https://en.wikipedia.org/wiki/Estrogen) is acting on the uterine lining to build up the lining to potentially support a pregnancy
- Then what happens just before ovulation is there’s a surge in a hormone called LH (luteinizing hormone), and that’s what we think triggers ovulation or release of an egg
- So, all that has to happen before an egg is released
- The egg busts out of the ovary, and finds its way to the tube
  - [the ovaries and fallopian tubes are shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f3-paulaamato-1024x626.png)

**Figure 3. Anatomy of the female reproductive system**. Image credit: [CDC](https://www.cdc.gov/cancer/nbccedp/cc_basic.htm) on [Wikipedia](https://en.wikipedia.org/wiki/Female_reproductive_system)

**Movement of the egg from the ovary through the fallopian tube**

*How energetically demanding is that?*

- We learned last week [talking with Paul Turek](https://peterattiamd.com/paulturek/) that the ATP requirement for those sperm to travel all that distance is unbelievable

*How passive versus active is the movement of that egg? How metabolically demanding is it?*

- Paula doesn’t know that we understand it completely
- You would imagine that energy is required for that to happen
- It’s not just sort of a diffusion down the fallopian tube
- Prostaglandins and calcium are involved; all kinds of things have to happen for that process to occur

*Give people a sense of  how long a* [*fallopian tube*](https://en.wikipedia.org/wiki/Fallopian_tube) *is*

- Probably 5-10 cm
- Peter thinks everyone’s probably used to seeing the image of ovaries being these little eggs and fallopian tubes having these little fingers that hug up on the eggs [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f4-paulaamato.png)

**Figure 4. Steps in egg movement from ovary through the fallopian tube to implantation in the uterus**. Image credit: [Britannica](https://www.britannica.com/science/ovary-animal-and-human)

*What is actually in between that space? How does the egg get from an ovary into a fallopian tube? Is there an actual connection there?*

- There is actually
- They’re not stuck together, but they’re kind of in close proximity so that those fimbriae (or finger-like projections) kind of sweep up the egg once it’s released from the ovary
- Otherwise, the ovaries and the tubes are in direct contact with the [peritoneum](https://en.wikipedia.org/wiki/Peritoneum)
- The pictures always show the tubes out here and the eggs out here, but they’re actually, everything’s closer together in the pelvis

**The egg is now in the fallopian tube. How long does it take to get through the length of the fallopian tube into the uterus?**

- About 5-6 days
- It’s a completely different experience from the sperm which are racing at breakneck speed and cover that distance in seconds

*What regulates the speed with which the egg travels through the fallopian tube and how does that impact fertility?*

*Is there a scenario whereby it happens too quickly and things don’t work?*

- Paula doesn’t know about too quickly
- There are hair-like projections in the tubes ([cilia](https://en.wikipedia.org/wiki/Cilium)) that help with motility of the egg down the fallopian tube into the uterus

***Potential abnormalities have to do with scarring in the tubes: if the tubes are blocked and then it interferes with the egg encountering the sperm***

Peter asks, “*What leads to that?*”

- A number of different things

***Infection probably most commonly, but also scarring from previous surgery potentially, or a condition called*** [***endometriosis***](https://en.wikipedia.org/wiki/Endometriosis)

**Assuming a woman’s cycle is predictable and normal and would just say day 14 is ovulation, that is the day that the egg leaves the ovary, or that is the day that the egg reaches a certain place within the fallopian tube?**

- That is the day the egg is released from the ovary

**⇒** The egg usually encounters sperm in the fallopian tube, and there’s where fertilization usually happens

- Then it takes a few more days for the embryo now (or pre-embryo) to travel down the rest of the tube into the uterus and hopefully implant (if it’s normal)

**How many sperm is the egg encountering at the time of fertilization?**

Peter recalls this is, “*One of the most interesting things here that is worth repeating, even though we talked about it last week (in case anybody missed it)*”

- Millions

*Why is it that only one perm out of millions (or even less than that) gets to transmit its genetic material into that egg?*

***Once an egg is fertilized, there’s a chemical reaction that happens that prevents any other sperm from fertilizing the egg***

- Because that would be bad ‒ you only want 1 sperm and 1 egg to combine
- There’s like an electrical force field that immediately activates around the egg
  - Peter finds this so fascinating and brilliant

**What is the relative size of an egg to a sperm?**

- The egg is much bigger than other sperm
- Paula doesn’t know exactly in microns how big it is
  - [an [egg](https://images.nigms.nih.gov/pages/DetailPage.aspx?imageid2=1339) is 150 microns in diameter and the average [length of a sperm](https://pmc.ncbi.nlm.nih.gov/articles/PMC3739080/#:~:text=median%20values%20L%204.4%20%CE%BCm) is 4.4 microns]
- It’s shocking how disparate they are in size
  - Peter’s analogy: you have this massive egg (that’s like the sun) and this tiny little sperm (which is like the earth) colliding with it

**How long from the impact of sperm and egg until you have that single-cell zygote that actually has a lined-up pair of chromosomes?**

- Within a few hours

**What is the process that occurs for cell division when that zygote goes from 1 to 2 to 4 to 8 cells?**

*How long does that take?*

*At what point does it implant into the uterus?*

- Most of what we know actually about this is from [in vitro fertilization (IVF)](https://en.wikipedia.org/wiki/In_vitro_fertilisation), because we can actually see that happening in the Petri dish
- Usually with IVF, an egg is fertilized with sperm
- By the next day we can see if it’s fertilized and we know if it’s fertilized because it has what we call 2 **pronuclei** ‒ DNA from the sperm and DNA from the egg
- Then over the course of the next couple of days, it divides into maybe 6-8 cells

***About 3 days after fertilization, the fertilized egg is about 6-8 cells, and then by 5-6 days it’s about 60-80 cells and that’s the stage where it implants in the uterus***

**When does it cease to become a zygote?**

*Remind us of the terminology, we have* [*zygotes*](https://en.wikipedia.org/wiki/Zygote) *and* [*blastomeres*](https://en.wikipedia.org/wiki/Blastomere) *(*[*blastocyst*](https://en.wikipedia.org/wiki/Blastocyst)*)*

- A zygote is a single cell that’s fertilized (an egg and sperm combined)
- Then it starts to divide and we call it a pre-embryo
- By 2 weeks we call it an embryo
- But in IVF, we call it an embryo even in the first few days

**Assuming that we have chromosomal alignment, it’s two weeks out. So, we have a two-week-old embryo that is implanted. What is the greatest risk that is faced by that embryo to coming to fruition as a fetus? (going all the way into the third trimester)**

*In other words, we’ve taken the biggest risk off the table (which is aneuploidy). What are the other risks it faces once a pregnancy is established?*

- If it’s a normal embryo, chances are pretty good that it continues to term

Let’s define normal

- Normal at the macro level means chromosomally normal
- There are other genes that play a role in embryo development (those are less understood)
- You could have a chromosomally normal embryo that fails to develop for other reasons
- There could be uterine factors that also play a role
  - An embryo may implant, but if there’s some structural abnormality, for example, in the uterus, maybe that pregnancy can’t continue and may result in a miscarriage

## How infertility is defined and diagnosed, and the broader trends contributing to rising infertility rates [25:15]

**What are the questions you have to render the diagnosis of infertility?**

*Meaning we need some intervention, versus you just need to make a few adjustments in something and I’m not willing to put the label of infertility on?*

- Begin with a full medical history of both partners (if it’s a couple),
  - That includes medical history, reproductive history, psychosocial history, sexual history, lifestyle factors (all those things are important)

**⇒** The medical definition of infertility is trying for about a year ‒ unprotected intercourse for about a year without success

***We start our testing after a year in women who are less than 35, and after 6 months if a woman is older than 35***

- Even though it may take longer to get pregnant if you’re older, if there’s something wrong you want to know about it sooner rather than later

Questions on the female side

- Are her menstrual cycles regular?
- Is she tracking ovulation?
- Does it look like she’s ovulating?

Questions on the male side

- We ask about sexual function
- Have they had a semen analysis?
  - If not, we usually order one because we’re interested in the sperm concentration, the motility of the sperm, the shape of the sperm, those types of things

Peter adds, “*One of the things I was very surprised by in the podcast that we did last week on male fertility was how infrequently men are getting evaluated and how many missed opportunities; in other words, how much wasted time is being generated because infertility is being assumed to be the responsibility of the female. (Responsibility might be the wrong word.)*”

**⇒** When you look at the data, about a third of the time infertility is due to a female factor, a third of the time it’s a male factor, and another third of the time it’s some combination of male and female factors

***Definitely one of the first things that we do is a semen analysis on the male partner***

Peter asks, “*Do you guys do that yourselves?*”

- We do, at the fertility clinic, yes
- If there is an abnormality, we usually refer that male partner to a reproductive urologist for further evaluation

Paula explains, “*These days it’s recommended actually that men, even if they’re not trying to get pregnant, sometimes assess their semen analysis, and because it can be a marker of other health problems, just like a woman’s menstrual cycle can be a marker of other health problems*.”

> “*I should qualify that one-year timeframe, if you have some reason to believe that you have a fertility problem, I wouldn’t necessarily wait a whole year and then go see a provider.*”‒ Paula Amato

When to see somebody sooner

- If your cycles are irregular
- If you think you might have [polycystic ovary syndrome](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome) or something

**Is it possible to say anything about fertility rates changing over the past 50 years?**

- There is some data that seems to suggest that infertility rates are increasing over the last several years
- It’s pretty common

**⇒** The lifetime risk of infertility for each person is about 1 in 6 (that’s close to 20%)

- The last few years in the United States seems to be kind of a plateau of the prevalence

Peter asks, “*If a woman gets pregnant in her 20s, but then in her 30s meets the criteria for infertility, would she be considered one of those 1 in 6?*”

- Yes (lifetime prevalence)

*The reasons for the increase in infertility prevalence are not super well understood*

- 1 – Part of the reason is delayed childbearing
- You could make infertility 100% if every woman decides to have a baby when she’s 70
- Women are waiting longer to start their families , and that’s definitely contributing to increased rates of infertility
  - Women are spending time to pursue education, career, etc.; maybe they haven’t found the right partner
- 2 – There’s some data that show that sperm counts are decreasing globally, and that might be playing a role
  - It’s a little controversial
- 3 – There might be a slight increase risk of sexually transmitted diseases
- All of those things are probably factors

**Is there an analysis that’s tried to get at this by normalizing to female age?**

- It seems to Peter that instead of looking at lifetime prevalence of infertility, you could look at infertility for women in narrow buckets of age, and that might provide a better sense of whether there’s a true infertility issue
- It’s definitely been looked at by age
- Paula doesn’t know the data off top of her head if it’s been looked at by age over time
- But definitely your chance of infertility is higher if you’re 40 compared to if you’re 20 or even 30

Peter asks, “*Do we know if a 30-year-old woman today has a higher rate of infertility than a 30-year-old woman 50 years ago?*”

- Paula thinks so but doesn’t know the data off the top of her head
- Peter points out that if the answer is yes, that may not answer all of their questions
  - Because infertility still could be explained by decreasing sperm count, by increasing paternal age
  - This would be a very difficult analysis to do
- There are environmental factors as well
  - Our exposures are different now than they were 50 years ago

## Fallopian tube damage: how STDs and scarring impact fertility and raise ectopic pregnancy risk [31:30]

**How do STDs and which STDs play a role in fertility?**

- The ones most well-understood are probably [gonorrhea](https://en.wikipedia.org/wiki/Gonorrhea) and [chlamydia](https://en.wikipedia.org/wiki/Chlamydia), which are very common sexually transmitted diseases

***On the female side, those particular infections can ascend to the fallopian tubes and cause scarring in the fallopian tubes (which interferes with the egg and the sperm meeting) and can lead to infertility***

Peter asks, “*Is that something that happens if it is left untreated or is that something that’s easy to address with antibiotics if caught early?*”

- If it’s caught early, then it’s usually treatable with antibiotics
  - There are some issues with antibiotic resistance, especially with gonorrhea
- But if it’s late stage or it’s unrecognized or untreated, then it’s more likely to ascend to the fallopian tubes where it usually causes fertility problems

**How prevalent is gonorrhea today in the US?**

- It’s pretty common but Paula doesn’t know the exact numbers
  - [The [CDC](https://www.cdc.gov/sti-statistics/data-vis/table-gc-agesex.html) reports 179.5 cases per 100,000 in 2023 (in the US)]
- It’s more common in certain populations
- Some of it is lack of awareness and education about safe sex practices, maybe less testing as well
  - We especially saw that during the pandemic

*How does it present?*

- Symptoms in women: pelvic pain, fever, vaginal discharge

*Is it equally transmissible from male to female and female to male?*

- It’s more transmissible from male to female

*If a male has it, does he know he has it?*

- Not always

**Does** [**HSV**](https://en.wikipedia.org/wiki/Herpes_simplex_virus_2) **factor into fertility at all?**

- Not as much

**How does chlamydia presents and how it impacts fertility**

- The same as gonorrhea
- Pelvic pain and fever
- Usually they both present together

*Does it have the same pathology where it ascends the fallopian tubes and scars the tubes?*

- Yes

**Worst case scenario: a woman undergoes a severe infection with gonorrhea &/or chlamydia, is not treated in time, and has completely scarred fallopian tubes.**

*Is it still likely that she could get pregnant through IVF? Are the eggs and uterus still preserved enough?*

- Yes
- It doesn’t usually affect the uterus or the eggs or the ovaries
- Now, she may not know that she has blocked tubes until she starts trying because you wouldn’t necessarily feel different if your tubes were blocked
- Paula talked earlier about what testing we might do in addition to a semen analysis and getting a menstrual history ‒ we usually do an x-ray test

**⇒** It’s called a [hysterosalpingogram](https://en.wikipedia.org/wiki/Hysterosalpingography) (or HSG for short), and it’s done specifically to evaluate whether or not the tubes are open

Peter asks, “*Are you just injecting contrast? I assume you do this externally, you go into the cervix, you just inject dye and take an x-ray?*”

- Exactly

*What does a normal fallopian tube look like on that test?*

- This test is usually done in a radiology facility by radiologists (although some gynecologists do this test)
- The dye fills up the uterus so you can also see the uterus, and then the tubes are kind of like these wire-like
  - The dye is filling up the tubes and then spilling out the tubes, so you can see that process
- The diameter of a normal fallopian tube in that setting is less than a centimeter
  - That’s the whole tube
  - The actual opening is millimeters
  - Paula doesn’t know exactly, but you can see it on an x-ray
- The ovaries are not visualized because of the finger-like projection
- So the dye is actually spilling dye into the peritoneum at this point

Peter asks, “*Based on that visual inspection, a trained radiologist and GYN can say, ‘That is smooth, that looks great,’ versus ‘that is jagged and/or obstructed.’*”

- Right

**If it’s obstructed, every month when an egg comes out, it’s not getting past that point. Does it just atrophy and get reabsorbed?**

- Yes

*Would that cause pain?*

- No

Peter points out, “*We didn’t talk about this earlier (we took it for granted): This is happening with two separate sides.*”

- Yes
- Peter finds it mind-boggling that one is being selected, and the one that’s happening on one side, somehow that signal is making it to the other side to say, “*You can’t do it this month*.”

*How does that happen?*

- We don’t know
- We have an idea: something to do with the receptors on the eggs and particular hormonal milieu
- Maybe there’s some nerve that plays a role
- We have no idea actually, but it is on average 50% from one side and 50% from the other side
  - And it’s not necessarily alternating, but it’s on average
- It’s mind-boggling (and fascinating) that these things are physically half a foot apart and some signal is transmitted in this woman’s body
  - And we don’t understand it
- Or whatever that egg that’s being selected somehow develops the appropriate receptors or whatever, that only it can respond to the hormones
- It’s not necessarily signaling to the other ones, but something is happening to that one that’s being selected, that’s making it the so-called “dominant follicle” for that cycle
- Peter supposes a more likely and plausible scenario is that something stochastically triggers one and only one to develop a high enough receptor concentration for FSH or LH (or something), so that it’s the only one that develops the radar

Paula points out, “*When we do in vitro fertilization, we’re giving much higher doses of FSH and multiple eggs are growing. So, you can overcome this process and get multiple eggs to grow, but we don’t totally understand physiologically what makes just one grow each month.*”

**Let’s say you do the analysis, and I assume if there’s scarring on one side but not the other, would you intervene, or would you just say, “*****No, we’re just going to take twice as long for one to get through?*****”**

- There’s still a chance to get pregnant
- Although whatever process caused the scarring in the one tube probably affected the other tube as well
- Just because it’s open doesn’t mean that it’s functioning normally
- You can give it a few months of trying

**The other issue you have to worry about is** [**ectopic pregnancy**](https://en.wikipedia.org/wiki/Ectopic_pregnancy)

- If that tube is not normal, if fertilization happens, that embryo can implant in the tube, and that’s kind of a very dangerous situation because, obviously, the tube can’t accommodate a pregnancy
- Usually that causes pain and if it goes unrecognized, it’s a surgical emergency

Peter asks, “*How many weeks of gestation is a woman when she’s showing up in the ER complaining of abdominal pain?*”

- 6-8 weeks of pregnancy (2 months)

**⇒** Remember we time pregnancy from 2 weeks before ovulation, so by the time she recognizes she’s pregnant, she’s already a month pregnant

- So, in the next month is probably the most common time where those ectopic pregnancies present

**When a woman has an ectopic pregnancy, can that fallopian tube be salvaged?**

- Sometimes, if you recognize it early, it can be treated either medically or surgically, and that tube can be salvaged
- If you recognize it late and the tube ruptures, then oftentimes, the treatment is to just remove the tube, especially if it’s not functioning normally

*When you remove the fallopian tube in that situation, are you leaving the ovary?*

- Yes
- Peter points out that you want to keep her endocrine system intact

*What’s happening to the eggs that come out of that tube?*

- They just get released into the peritoneum (the abdomen)

Peter asks, “*So do you tell that woman, ‘Your fertility rate just went down by 50%’?*”

- Yeah
- She can still get pregnant if she has the other tube intact, but most of the time, if the egg ovulates from the right, it’s going to try and go down the right side
- Although there have been cases where you can ovulate from the right ovary, and it can travel down

**What other risks for ectopic pregnancy besides former STDs that lead to scarring in the tube?**

- The most common are:
  - Previous surgery ‒ pelvic surgery, in particular (like ruptured appendix)
  - [Endometriosis](https://en.wikipedia.org/wiki/Endometriosis) can cause scarring of the tubes

**Is there any genetic component to this if your mom had an ectopic pregnancy?**

- Not that we know of

## Unexplained infertility: how doctors evaluate ovulation and cycles—and why more research on women’s health is needed [41:00]

**Back to our hypothetical case**

- A woman comes in, and let’s just assume, for the sake of simplicity, the workup on her male partner shows that his sperm are fine
- The radiograph shows that she has normal fallopian tubes (at least to the eye)

*What’s the next step in the workup?*

- We want to assess her cycles and ovulation

**⇒** If she’s ovulating regularly, then we call that unexplained infertility

Peter asks, “*And how do you know that she is? Is that determined by the fact that she has a regular period? Does that alone tell you that?*”

- Usually
- It would be unusual to have regular periods and not be ovulating, but it could happen

**How stringent is your definition for a regular period? It’s not 28 days, necessarily**

- It could be anywhere from 21 to 35 days or so
- The duration of the period is not as important as how frequently the period is happening

Peter asks, “*Even if it was 21 days, but it was always 21 days, that’s better than it’s 24, 28, 31.*”

- Some variation is normal
- Sometimes patients think their periods are irregular: sometimes they’re 26 days, sometimes they’re 32
  - Paula considers that normal
  - It’s not usually always 28 days or always 21 days

**⇒** Irregular would be you’re skipping months or maybe you’re getting a period every 3 or 4 months

**What’s happening when periods are irregular?**

- There are a number of different causes
- Probably the most common is something called [polycystic ovary syndrome (PCOS)](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome)
- It’s a very common hormonal condition
- We don’t know exactly what causes it

> “*I feel like I’m saying that a lot about women’s health. We don’t know exactly what causes it because we’re not investing enough in women’s research*.”‒ Paula Amato

**Why do we not have more research on women’s health?**

- Peter recalls this lack of research on women’s health came up on a recent podcast on HRT [[episode #348](https://peterattiamd.com/rachelrubin/)]
- One of Peter’s big rallying cries is, “*How pathetic it is that we’ve not done enough research*.”

***Paula thinks it’s for political reasons, gender inequality, all kinds of reasons like that***

Peter asks, “*Do we have a sense objectively that there is a difference in this type of research?i”*

- *Or do we think it’s just that, well, maybe there’s equal amounts of funding, but the innate problems associated with the female reproductive system (or female health, in general) are so much more complicated that at equal funding levels, we’re going to be far behind in our understanding?*
- Paula thinks it’s the former
- Funding for women’s health research is about 10% of the overall NIH budget (it’s very small)
- If you look at reproductive health, it’s even smaller
- So it’s a huge issue

## The defining symptoms of polycystic ovary syndrome (PCOS), its hormonal characteristics, and its relationship with insulin resistance [44:00]

**Polycystic ovarian syndrome (PCOS)**

- It’s super common: 6-8% of women have [PCOS](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome)
- Most common symptoms:
  - Irregular periods
  - High [androgen](https://en.wikipedia.org/wiki/Androgen) levels – that can present with acne or excess hair growth
    - We call that [hirsutism](https://en.wikipedia.org/wiki/Hirsutism)
    - The androgens are [testosterone](https://en.wikipedia.org/wiki/Testosterone), [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone), and [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone); but typically elevated testosterone from the ovaries
  - Obesity or being overweight
- We don’t know if the elevated levels of testosterone produced by the ovaries is the cause or effect

***But elevated testosterone levels are definitely seen in almost all women with PCOS***

**Why is PCOS also highly associated with insulin resistance?**

- We don’t know, but we think androgens play a role
- We think there might be some genetic factors that play a role

***We have recognized in the last several decades that most women with PCOS also happen to be insulin-resistant***

- But we don’t know the direction of causality
- We know that not everybody who’s insulin-resistant has PCOS
- Of course, not all diabetics are insulin-resistant

Peter asks, “*Are some women with PCOS not insulin-resistant?*”

- Probably, on some level they are, but they’re able to compensate
- Certainly, it’s more likely if they tend to be overweight
- It’s definitely multifactorial
- Paula’s guess: it’s like we’re treating PCOS now more like other complex diseases like obesity or hypertension, etc.
  - There’s lots of things going on
- Peter’s take on what she just said, “*If there is any causality between them, it’s more likely that the PCOS is driving the insulin resistance than the other way around, given the number of women that are insulin resistant who do not have PCOS.*”
  - Paula agrees this is probably true

## Managing PCOS without pregnancy: cycle regulation, androgen suppression, and insulin resistance treatment [46:00]

**What do we need to do to treat PCOS?**

***It depends on the goal of the patient***

- 1 – If they’re trying to get pregnant, there’s one set of treatments
- 2 – If they’re not trying to get pregnant, but they have PCOS, then we usually focus on their cycles
  - Because it’s generally not a good idea to go too long in between cycles because what can happen is the lining of the uterus can overgrow
  - If it overgrows too much, it can become what we call [hyperplastic](https://en.wikipedia.org/wiki/Hyperplasia)  (2orst-case scenario cancer)
    - You definitely don’t want that
    - It’s important to be shedding that lining or to be on hormonal suppression so that that doesn’t happen
- 3 – If the goal is to treat the hyperandrogenic symptoms like the acne and the hirsutism: hormonal treatments usually effective for that
  - We usually start with birth control pills
  - Birth control pills, very effective for most symptoms of PCOS
    - It’ll regulate the cycles, decrease androgen levels, help with hirsutism, acne, etc.
    - A [birth control pill](https://en.wikipedia.org/wiki/Oral_contraceptive_pill) is a high dose of a synthetic estrogen and progestin that’s given 21 days and then paused for a week
    - Meaning you take it every day, but the last week is a placebo

**Is the reason that birth control pills helps with the hyperandrogenism because it raises** [**sex hormone binding globulins**](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) **so much that it mops up all the excess testosterone?**

- Yes, that’s part of the reason
  - Paula is impressed by Peter’s endocrinology knowledge
- And by the way, you can take it that way Peter described (where you have a bleed every month) but you don’t have to
  - Many people take it continuously these days, so you don’t have a period at all

Peter asks, “*Doesn’t that address the issue that you were talking about, or does the synthetic estrogen… the synthetic progestin offset the hyperplasia, and then you don’t care?*”

- Right

**⇒** When you take the combination of estrogen and progestin, usually the lining becomes quite thin

*There are 2 mechanisms of action**[of hormonal birth control pills]*

- 1 – When you’re taking those high doses of estrogen and progesterone, it’s suppressing the pituitary hormones (namely the LH and FSH), but the LH is what drives the testosterone production in the ovary
- 2 – The estrogen component of the pill will increase the sex hormone binding globulin, so you have less free testosterone around [and also less estrogen]
- That will help with those symptoms we talked about

**Treatment for a woman with PCOS who doesn’t want to get pregnant, just reduce the androgen impact and protect her uterus**

- A constant oral contraceptive is a great strategy
- There are others
- She could use a [progestin IUD](https://en.wikipedia.org/wiki/Hormonal_intrauterine_device) (that’s a hormonally active IUR)
  - There are a number of different ones
  - We’re just taking progesterone every few months that usually will help protect the lining, but probably won’t decrease the androgen levels

*How often do you place women who have PCOS with insulin resistance on* [*metformin*](https://en.wikipedia.org/wiki/Metformin)*?*

*Do you find that or any of the other diabetic agents to be particularly useful?*

- Occasionally
- That’s an important point because women who have PCOS are insulin resistant, which predispose them to diabetes

**Does insulin resistance and** [**type 2 diabetes**](https://en.wikipedia.org/wiki/Type_2_diabetes) **independently impair fertility? (All things being equal absent PCOS)**

- Yeah, in some cases
- There’s some data that shows that metabolic diseases or chronic diseases can impact fertility

***Mechanisms are unclear, but probably related to both ovulation, dysfunction, and also endometrial receptivity***

## The treatment approach for women with PCOS who are trying to conceive: GLP-1 use, ovulation induction, and timing protocols [49:45]

*What is the playbook for treating a woman with PCOS who is also trying to conceive?*

**⇒** Paula counsels women with PCOS (especially if they’re overweight or obese) that weight loss helps with all the symptoms of PCOS (so healthy diet, lifestyle, etc.)

**How much of a role are** [**GLP-1 agonists**](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) **playing in this now? How much more success are you having with treating PCOS that way?**

- Increasingly
- They’re very successful for weightloss
- There’ve been some studies on PCOS patients specifically ‒ very effective
- They work really well, just like they work in people with diabetes or people with obesity without diabetes

**⇒** The problem is you can’t get pregnant while you’re taking them, and the current recommendation is to stop for at least 2 months

*Why?*

***We don’t have any data on whether they’re safe [during pregnancy]***

- Peter adds, “*That’s an important message for anybody listening.*”
- You can be on it pre-pregnancy, just the recommendation is to stop for at least 2 months
- Having said that, you may have read about **Ozempic babies**: people getting pregnant on GLP-1
  - There have been lots of them
  - There is a registry, and so far, to Paula’s knowledge, there haven’t been [any] reported birth defects and that type of thing
    - But obviously, we’re talking about a small number
  - Presumably these are women who have taken either [semaglutide](https://en.wikipedia.org/wiki/Semaglutide), [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide), and presumably they get pregnant, either intentionally or not
  - That’s a very interesting [registry](https://wegovypregnancyregistry.com/) to follow
  - They usually stop taking the GLP-1 agonist once they find out they’re pregnant, so we don’t know what happens if you continue

**Peter’s takeaway**: a woman who’s got PCOS is going to be first counseled to make these changes that effectively help her lose weight and increase her metabolic health

**Let’s say she is somewhat successful but still unable to address the concern [ovulation for pregnancy]**

- Luckily there are very good ovulation-inducing medications available
- What Paula typically recommends for someone with PCOS to help them ovulate more regularly is [letrozole](https://en.wikipedia.org/wiki/Letrozole) (brand name [Femara](https://www.rxlist.com/femara-drug.htm))
  - It’s just a medication you take for 5 days in your cycle, and then we can usually assess ovulation with the ultrasound
  - This is a category of medication called [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor), which blocks the [conversion](https://en.wikipedia.org/wiki/Aromatase_inhibitor#Mechanism_of_action) of testosterone to estrogen
  - ***That lower estrogen somehow triggers the pituitary to increase secretion of FSH and LH, and that stimulates the ovary to get one of those follicles to grow***

*Is the reason you use something like an aromatase inhibitor as opposed to clomiphene or hCG is just that it’s a smaller nudge, and you’re starting out with it?*

- No, we used to use [Clomid](https://en.wikipedia.org/wiki/Clomifene#) first line for PCOS, but then there was a [study](https://pubmed.ncbi.nlm.nih.gov/25006718/) that came out several years ago comparing the two and showing that pregnancy rates were a little bit higher with letrozole

***Clomid’s perfectly good as well, but Letrozole is better for [treating infertility in women with] PCOS***

- Peter finds that counterintuitive
  - If you think about it, when you take an aromatase inhibitor, you’re going to lower estrogen, but he guesses it depends on the dose
  - He’s thinking of [anastrozole](https://en.wikipedia.org/wiki/Anastrozole) (which he’s more familiar with than [letrozole](https://en.wikipedia.org/wiki/Letrozole))
  - He supposed if you took a milligram of anastrozole every day for 5 days, you would drive estrogen down
  - But he didn’t think that that reduction in estrogen would lead to a high enough amount of [gonadotropin-releasing hormone](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone), which is, effectively, what has to be happening
    - It has to be going up to drive the secretion of LH and FSH
    - [Peter explains more about these hormones in [episode #256](https://peterattiamd.com/endocrinesystem/)]
  - He would think that giving 50 to 100 milligrams of Clomid would have a much bigger impact on that
- Paula explains that it also works, but the [randomized control trial](https://pubmed.ncbi.nlm.nih.gov/25006718/) (head-to-head comparison) showed the pregnancy rates were better for some reason with letrozole compared to Clomid

*Does it matter when, in her cycle, she takes the Letrozole?*

- Usually, it’s recommended from day 3-5 with the first day of full bleeding (we call that day 1)

Peter asks, “*What if the whole point of this is she’s not having her period? How do you then time it?*”

- We induce a period (not a real period), but we induce a withdrawal bleed by giving progesterone and then by withdrawing the progesterone
  - 5-10 mg of [medroxyprogesterone acetate (MPH)](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate) or you can give 200 mg of [micronized progesterone](https://en.wikipedia.org/wiki/Progesterone_(medication)) for about 7-10 days

Peter asks, “*Do you have a preference for MPA versus micronized?*”

- No, not really, because it’s such a short course

**Peter’s takeaway**

- You give the full dose of endometrial progesterone for 5 days
- The second you take it off, it’s the withdrawal of progesterone that causes the lining to shed
  - And then we call that day 1 [of the menstrual cycle]
- Then on day 3-7, we go ahead and start ripening the follicle with the aromatase inhibitor (for 5 days)

**Paula explains the next step in treatment**

- We usually do an ultrasound around day 12-ish
- You could see one of those follicles starting to grow
- Not all patients will respond so sometimes we have to increase the dose or sometimes we have to try a different medication
  - But most patients with PCOS will respond to that medication

## Barriers to getting informed fertility care for PCOS: limited provider knowledge and access, insurance gaps, and next steps when ovulation treatments don’t lead to pregnancy [55:45]

**Would you say that every single woman out there with PCOS who wants to get pregnant has access to a doctor that understands what you just described and can do that for her?**

*Or do you worry that too many women are being shunted to IVF too soon without an attempt at something like this?*

> “*I definitely think there’re probably not enough people who totally understand management of PCOS, especially in the context of fertility treatment*.”‒ Paula Amato

- Even in the context of non-infertility treatment, often, what Paula hears from patients is: they had irregular period, and somebody told them to start go on the birth control pill but they never told them why
  - ***They didn’t even know they had PCOS***
  - It happens to be the correct treatment
  - But they’ve gone years now not understanding that they have PCOS and the implications of that (metabolic implications, etc.) ‒ that’s a problem
  - ***Once they want to become pregnant, very few general gynecologists are set up to be able to treat patients with either Clomid or letrozole***
    - It’s not like a fertility clinic with reproductive endocrinologists because Paula’s clinic is set up to do monitoring 7 days a week

***Not everybody has access to a fertility specialist; it’s very dependent on where you live; it’s a little bit better now with telehealth***

**Do you have to do the sonogram when you’re doing this?**

- You don’t have to, but you want to know whether the woman’s responding, meaning that she’s actually ovulating
- There are other ways to assess that, if she gets a period at the right time that she probably ovulated or if she gets pregnant
- Or you can check a progesterone level in the [luteal phase](https://en.wikipedia.org/wiki/Menstrual_cycle) (the second half of the cycle), and if it’s elevated, she probably ovulated
- Paula just happens to use ultrasound (it’s easier)

**How much of what you are describing is covered with typical health insurance?**

- It depends where you live ‒ the United States is very state-dependent
  - Some states have infertility insurance mandates where your employer’s insurance policy has to provide infertility, diagnostic, and treatment
  - But in many states, infertility is not covered
  - Or they might just cover the testing portion but then not cover the treatment portion (that’s a huge problem)
- Paula is in Oregon [[Spring Fertility](https://springfertility.com/)]
- Oregon doesn’t have an infertility insurance mandate yet
  - There’s a bill in this regular session now

> “*Infertility is a disease like every other disease, and we think it shouldn’t matter where you live. You should have access to the appropriate treatment.*”‒ Paula Amato

- In Oregon, coverage depends on your employer and whether they provide that particular insurance coverage

**If a person has health insurance that does not cover reproductive care, how much would be the out-of-pocket cost of what you just described?**

- Letrozole and Clomid are just oral medications (cheap drugs)
- When you add monitoring, that could be another $300
- If you do intrauterine insemination (which she hasn’t talked about yet), that’s a few hundred dollars a month
- For some people, that would be a lot
- But that’s inexpensive compared to IVF

**Peter’s takeaway**: we would go through 3 consecutive cycles of this before moving on to IVF

**Ways this infertility treatment can fail**

- 1 – We did an ultrasound, but we didn’t see an egg
- This means the patient is not responding to follicle stimulation
- 2 – We got ovulation but didn’t get fertilization
- Peter assumes in parallel you’re doing the male workup
  - Nothing would be a greater crime than going to all of that trouble and you didn’t figure out that the sperm was the problem

*Let’s assume the sperm is not the problem, and we see ovulation. Would you be more inclined to continue that treatment for another 3-6 months?*

- Yes
- This is someone who hasn’t been ovulating, and they haven’t tried for a year
  - They haven’t met the criteria for infertility

**⇒** There’s nothing magic about 3 months, but that’s at least a check-in point to assess if we continue to do this or move on to something else

***If it’s a young person and this is the first time they’re ovulating in their life, then yeah, we give them more time on a less invasive, less expensive treatment***

**Back to the first case, the patient has tried this 3x but is not ovulating**

*What’s the next step?*

- Assuming we’ve tried higher doses and different medication (like Clomid or whatever) and she’s still not responding
- Then we typically move on to a class of medication called [gonadotropins](https://en.wikipedia.org/wiki/Gonadotropin) or essentially [FSH (follicle-stimulating hormone same hormone)](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)

Peter asks, “*Not* [*LH*](https://en.wikipedia.org/wiki/Luteinizing_hormone)*. You don’t give* [*hCG*](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) *directly?*”

- It’s a little bit of a combination
- We do eventually give hCG to trigger ovulation
- We could either use those medications with either: timed intercourse, intrauterine insemination, or IVF
  - That middle option with timed-intercourse and [intrauterine insemination (IUI)](https://en.wikipedia.org/wiki/Artificial_insemination#Intrauterine) has kind of fallen out of favor a little bit because those medications are very expensive and require a lot of monitoring
  - So, we usually skip that and go directly to [IVF](https://en.wikipedia.org/wiki/In_vitro_fertilisation)

**⇒** Success rate with IUI or time intercourse is much lower than IVF

**If you are going to use FSH and LH, give me a sense of cost. What dose are you using of hCG?**

- If the plan is just timed-intercourse, intrauterine insemination (IUI), we use maybe 1-3 ampules of FSH (75 units)
- The whole cycle, if you include the monitoring, the IUI, etc., could cost $3,000-4,000

**⇒** After a few cycles of timed-intercourse or IUI, it’s almost the same cost as an IVF cycle

**The advantage of IVF**

- You can freeze embryos
- So if you want to have 2 or 3 kids, you might as well just do IVF and bank those embryos because, otherwise, you’re going to have to do the same thing all over again for your second kid or your third kid

**Has intrauterine insemination fallen out of favor?**

- No
- IUI is still very common
- Rachel has been talking specifically about a patient with PCOS who is not ovulating

## Fertility treatment for women with unexplained infertility, risk of multiple pregnancies with superovulation, and more [1:03:00]

**Otherwise, if you have a patient who is ovulating, her tubes are open, and maybe has unexplained infertility**

- We still use the [medication](https://en.wikipedia.org/wiki/Controlled_ovarian_hyperstimulation#Hyperstimulation_medications) to help them super ovulate
- Normally, you just make 1 egg

**⇒** When someone is already ovulating, the goal of the fertility medications is to get them to release more than one egg

***With more eggs around, there is a higher chance that one of them is going to be normal and one is going to be fertilized***

**What does the graph look like of the number of eggs versus probability of twins, triplets, etc.?**

- That’s one of the downsides
- The risk of multiples with the oral medications like [Clomid](https://en.wikipedia.org/wiki/Clomifene) or [letrozole](https://en.wikipedia.org/wiki/Letrozole) is about 5-8%
- It’s not super high, but it’s definitely higher than if the patient were to conceive without medication
- That is something we counsel them about

**Common first-line treatment**

- A common first-line treatment is to use oral medication with IUI, even in the context of normal sperm, although it’s more important if there’s a male component
- And then, if that didn’t work in 3 cycles, then move on to IVF

**With the injectables, what is the risk of multiple pregnancies?**

- Much higher, 25-35%

*How many eggs are typically released?*

- It depends on the dose of the medications
- When we’re doing **IVF**, we want a lot of eggs: 10 to 15 eggs
- But if we’re doing **IUI**, it could be 3-5 eggs
- It depends on the dose and depends on the age of the patient, etc.

Paula explains, “*What’s fallen out of favor is injectables with IUI. We don’t do that very much.*”

**Back in the day, every time you were in the grocery store and you saw the cover of the** ***National Enquirer*****, and there was like, “*****This woman just had 47 babies*****.” What the hell was going on in those eras?**

- In the early days of fertility treatment, when people just had access to injectables and IUI, most of the multiple pregnancies were not from IVF but from injectables and IUI
- The [famous octuplets](https://en.wikipedia.org/wiki/Suleman_octuplets) case was an IVF case
- In the early days of IVF (when IVF was not very successful), we had to transfer many embryos to get decent pregnancy rates, and some of the time, more than one would take
- So, the pregnancy rates were the multiple pregnancy rates
- In that situation, they would’ve transferred 8, and all 8 took
  - More than the recommenced number were transferred
- Also one embryo can split into two
- Now there are very strict [guidelines](https://www.asrm.org/practice-guidance/practice-committee-documents/guidance-on-the-limits-to-the-number-of-embryos-to-transfer-a---committee-opinion-2021/) from the American Society for Reproductive Medicine, which is our professional organization, that almost always we’re transferring just one embryo these days

Peter asks, “*Unless a couple says, ‘I’d actually like to have twins,’?”*

- We discourage that
- Because twins are riskier for the babies and for the mom
  - Not riskier in an IVF setting; just riskier in general

**Do IVF twins pose any more risk to either fetus or mom than naturally conceived twins?**

- Yes, there is some data that would suggest that IVF pregnancies have a higher risk of complication than spontaneous pregnancies
- We don’t know exactly why
  - If it’s the IVF
  - If it’s the fact that people who need IVF have underlying conditions that may predispose them to some of these complications
- Overwhelmingly, data is reassuring that [IVF] pregnancies do fine, the babies fine

**⇒** We definitely know that twins, whether you’re conceived them spontaneously or with IVF, the risk of almost every pregnancy complication is going to be higher

*Complications*

- This is the risk of [preeclampsia](https://en.wikipedia.org/wiki/Pre-eclampsia), [HELLP syndrome](https://en.wikipedia.org/wiki/HELLP_syndrome), blood clot, hypertension, hemorrhage, need for a C-section, premature delivery
- All of those risks are increased with twins

***We don’t intentionally like to produce twins, although it happens sometimes***

## Intrauterine insemination (IUI): process, success rates, and when in vitro fertilization (IVF) becomes the better option [1:07:00]

**Do you want to say a little more about IUI?**

Peter adds, “*I don’t know what it is about when people say turkey baster it makes me cringe. That is just such a gross image to me… Just so that people know what we mean by intrauterine insemination, just to be clear, you are not using a turkey baster?*”

- Definitely not

*Explain how IUI is done*

- You an oral set of hormones so that the woman doesn’t have a massive proliferation of follicles
- For the male, do you want fresh semen, or do you care if it’s frozen?
  - They have the same rate of success
  - Single women and female same-sex couples would be using donor insemination

The indications for IUI

- Single women,
- Same-sex couples
- A couple with unexplained infertility
  - Where you just can’t find a reason and want to optimize their chances
- If there’s a male factor such as lower sperm count or lower motility

Details of IUI

- The female partner would typically take fertility medication to increase the number of eggs [released]
- She would track her ovulation
- When she’s ovulating, she would come to the clinic
- The male partner would come to the clinic and produce a sperm sample
- We process the sperm (which is basically collect the best sperm in a small volume), and then place that sperm directly into the uterus through the cervix

Peter asks,  “*The problem that you’re able to overcome on the sperm side would be number and motility?*”

- Yes
- Or morphology or any abnormality in the semen analysis as long as it’s not very severe

**ICI stands for intracytoplasmic sperm injection**

- We actually take a sperm and inject it directly into an egg
- For a **severe male factor,** that would be the recommended treatment

**⇒** If the sperm’s a little bit low, but it’s not too bad, then we would try a few cycles of IUI first

**When in the woman’s cycle, how many days before she ovulates do you want to inject those sperm into the mouth of the uterus?**

- Essentially on the day she is ovulating

*Peter’s reaction*

- He finds this interesting because one of the things he took away from the [discussion with Paul Turek](https://peterattiamd.com/paulturek/) last week was was that if you look at the probability distribution curve of when a pregnancy occurs, the ejaculate enters the uterus prior to ovulation
  - Around 80% of pregnancies occur when the sperm are there prior to ovulation
  - If you waited until ovulation to have sex, that accounts for only about 20% of conceptions
- Paula agrees that the sperm can hang around  for 2-3 days or so whereas the lifespan of the ovulated egg is much shorter

Peter asks, “*Based on that, wouldn’t it make sense to put the sperm in prior to ovulation, or is it just too risky to try and anticipate when that is?*”

- If it’s a straight couple, we’ll tell them to also have intercourse every couple of days around the time of ovulation
- The pregnancy rates in early studies show that probably the highest pregnancy rate occurs if you do the insemination on the day that you think the patient is ovulating

*Do you determine the day of ovulation with ultrasound?*

- Usually LH monitoring
  - Remember LH goes up just before ovulation
- The patient will monitor her urine LH, and we also do ultrasound to look at the size of the follicles
- We sometimes trigger ovulation with hCG, which kind of simulates the woman’s own LH surge
  - 5,000 units of hCG (half a vial): it’s a lot (probably more than physiologic)
  - The purpose is to cause release of the egg
- We time the insemination to happen when we think the ovulation is happening

**Peter’s out-of-the-box thinking scenario**

*Do you ever get the male to bank a ton of sperm and perform IUI on 4 consecutive days before forcing ovulation?*

- You could do that, or the couple could just have sex
- Peter points out that this introduces another variable regarding the quality of the semen
  - If he’s having sex every day, he’s not having a chance to fully rebuild the supply
  - What if his motility is anything other than perfect?
- In the other case, what if we’re dealing with a same-sex couple or a single mom?

***Paula recalls*** [***studies***](https://pubmed.ncbi.nlm.nih.gov/31410635/) ***looking at 2 IUIs compared to 1, specifically in same-sex couples or single women and they show no difference [in rate of pregnancy, see the figure reproduced below]***

![](https://peterattiamd.com/wp-content/uploads/2025/06/f5-paulaamato.png)

**Figure 5. Pregnancy rate resulting from single or double IUI**. Image credit: [*Journal of Assisted Reproduction and Genetics* 2019](https://pubmed.ncbi.nlm.nih.gov/31410635/)

- Remember, if you’re paying out of pocket for all of these things, it has to be worth it

**Peter’s takeaway**: at some point the cost is going to approach the cost of IVF

- Paula points out, “*Is it worth another $400? Five days, now your cost of your IUI cycle’s all of a sudden $2,000. Yeah. So those are practical considerations.*”

**If you look at all of the uses of IUI, what is the success rate?**

**⇒** The pregnancy success rate really depends on the age of the female partner

- If it’s a young woman in her **20s**, the success rate might approach the success rate for natural conception: 20-25% per cycle
- If it’s a woman **over 35**, it might be 10-15%
- If it’s a woman **over 40**, it might only be 1-5% per cycle

> “*It’s all about the quality of the egg. So even though an egg is released, maybe two eggs are released, if those eggs aren’t normal, they’re not going to fertilize and implant.*”‒ Paula Amato

- We’ve covered a lot of fertility treatments

**Peter’s takeaway**: it seems that the likelihood that a woman who’s undergone some of the things we’ve discussed that still ends up going down to the IVF pathway, is reasonably high

- Paula points out that the majority of people don’t need IVF
  - It depends on the age of the female and what the problem is

**For all women under age 35 who present with defined infertility, walk through the success rate of pregnancy by modality**

*How many are successful with just an oral treatment, absent IUI?*

- This depends on what the cause of the infertility is
  - Is it unexplained or is it PCOS, for example?

*Unexplained infertility as defined by no pregnancy after more than a year of sex*

***Probably less than 50% will get pregnant with IUI and will have to move on to IVF***

- Unexplained means either it’s bad luck or more likely there’s something going on and we just can’t figure it out
- Almost always in those cases, IVF is going to give you a higher chance of success
- For PCOS, their problem was they just weren’t ovulating, so probably 80% of those people will get pregnant with just ovulation induction and IUI, because you’re solving the problem
  - Hormonal therapy is addressing the problem
- If it’s a very severe male factor, probably IUI is not going to work
  - It really depends on the etiology of the infertility

**Age 35-45: what percent of women with unexplained infertility will get pregnant absent an IVF strategy?**

*These women don’t have PCOS and let’s assume that it’s not a male issue*

- It depends on how long you do it for

**⇒** Most of the time we’re only doing it for 3 cycles because it’s not cost-effective to do it for longer

***In this age group, probably the majority of women will likely need IVF if they are not successful after 3 months of IUI***

- Theoretically, if you continue doing IUI, a lot of those people will eventually get pregnant

*After 3 months of IUI, what percentage are going to be pregnant?*

- Probably under 50%, Paula doesn’t know the exact number
- It could be a third, potentially
- The success rate in that group is something like 10-15%

## The history of in vitro fertilization (IVF), and how access and acceptance have evolved over time [1:16:45]

- The first successful IVF baby was born in 1978
  - Referred to as a test tube baby, which is kind of weird because it was a Petri dish, not a test tube
- We’ve come a long way since then

**Do you know how that was done back in 1978?**

- There’s a recent docudrama about the first IVF success called [*Joy*](https://en.wikipedia.org/wiki/Joy_(2024_film))
- The baby’s name was Louise Joy Brown
- They tried for many, many years before they had the first success
- These were 2 doctors
- Peter wonders what kind of [IRB](https://en.wikipedia.org/wiki/Institutional_review_board) approval there was?
  - How much controversy was there around this?
- There was a lot of controversy; this was seen as very freaky (playing God)
- This was done at the time, primarily for women with blocked tubes
- Paula can’t remember the exact details of the couple, but thinks they had tubal disease
- IVF works great for tubal disease because of course, you’re bypassing the tubes altogether
- This was done in the UK (Britain)
- The first cases were one with laparoscopic surgery under general anesthesia to retrieve the eggs
- Then they were combining the eggs with the sperm in a Petri dish
- Maybe they were transferring the embryo maybe back into the tube in those days, or maybe through the cervix
- But yes, a lot has changed over the last 45 years or so

**Despite that success in 1978, what did it look like for the next 10 years, from 1978 to 1988? How prevalent was IVF?**

*When did it get to the point where anybody who could afford it could access it?*

- Much more recently
- The first IVF baby in the US was born a few years later (maybe 1981) in Virginia
- It took probably many decades for it to become commonplace throughout the world
- Now, in most countries you can access IVF
  - Not everybody can access IVF, in some countries more than others
- In medicine, 45 years, that’s a relatively recent development
- It’s been only in the last maybe 20, 30 years that it’s become standard

## The step-by-step process of IVF [1:19:30]

**Walk through how IVF works**

- Typically, we do a bunch of screening tests on both partners
  - That includes some blood tests, a semen analysis, an ultrasound to get some assessment of the woman’s egg number

**⇒** It takes about 2-3 months to complete a cycle of IVF

Peter asks, “*When you say egg number, are you determining that through an AMH or through a physical examination of the ovaries?*”

- Both
- We do an ultrasound, and we can count the number of follicles
  - They’re a few millimeters
  - You can see that on the ultrasound and that gives you some sense about how many eggs that particular patient will produce with ovarian simulation

**Explain what AMH is and how it works**

- [AMH (Anti-Müllerian hormone)](https://en.wikipedia.org/wiki/Anti-M%C3%BCllerian_hormone#In_vitro_fertilization) is secreted by the cells that surround the egg
- It tends to correlate with egg number
- It doesn’t tell you anything about fertility or pregnancy rates or anything like that
  - Age is still the most important factor in that sense
- It gives you an idea on if you have a normal number of eggs for your age

Peter asks, “*Two women have the same number of eggs, if one woman has high quality eggs, the other woman does not, they could still have the same AMH level on a blood test.*”

- Right, if they’re different ages, their success rates can be different

**⇒** A normal AMH would be about 2 pg/dL; <1 pg/dL is considered low

*What’s the difference in AMH between a 16-year-old girl who is at the peak of her fertility versus a 30-year-old woman who is still fertile but has lost a step?*

- It’s a very narrow range
- An AMH >2 is normal for reproductive age
- It can be too high; for example, patients with PCOS have very high levels

***An AMH >2 indicates a good number of eggs and <1 indicates a low number of eggs***

- You’re not looking at it like you look at a [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone) or something
- The assay is also very variable ‒ it depends on where you have it done
- It just gives you an idea of, “*Is the egg number average for your person’s age? More than average, less than average?*”

*Knowing the AMH level helps*

- Helps determine what dose of medication to use during IVF
- Helps give an expectation to the patient an expectation
  - You’re probably going to make 5-10 eggs, maybe not 15-20

**A typical IVF cycle**

- When a woman is ready to start an IVF cycle, everything usually starts with her period, depending on the age again
- Usually, the patient starts on a couple of weeks of birth control pills
  - What that does is kind of suppresses the ovaries because we want all the eggs to kind of grow at the same rate
- Then she stops taking the pill, and starts the gonadotropins (which are the FSH and a little bit of LH, injections)
  - You’re on those for about 8-12 days
  - Every few days while on those medications, you have to come into the clinic for ultrasound monitoring and blood levels of estradiol are checked
  - We can monitor how many follicles are growing, how big they are, etc.
  - Usually these medications are pretty well tolerated

*What dose of LH and FSH is she injecting relative to what she would normally make? Is it 2x?*

- Much higher
- It depends on the age
- Higher doses are used for women who are older
- Maybe 5x

*Symptoms from injection of FSH and LH*

- Most common: bloating as the ovaries get a little more enlarged
- There’s a small risk of something called [ovarian hyperstimulation syndrome](https://en.wikipedia.org/wiki/Ovarian_hyperstimulation_syndrome), when the ovaries get a little bit too stimulated, but that’s exceedingly rare
  - If there’s signs this is happening, we can always back down on the dose
- Sometimes patient doesn’t make as many eggs as we were hoping so sometimes we have to increase the dose or change the protocol, but usually we guess pretty right

*Once the follicles are a certain size, that’s how we know the eggs are mature*

- Because of course, we can’t see the eggs on the ultrasound, you can only see the follicles that contain the eggs
- Then the patient gets [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin), which is another medication which kind of simulates her own LH surge
  - The purpose of that medication, it causes the final maturation of the eggs
  - That medication is very time sensitive
- We time the egg retrieval to happen just before the woman ovulates

Peter asks, “*To be clear, were you only giving her FSH before, or were you giving her LH as well?*”

- A little bit of LH, but mostly FSH
- We use LH versus hCG just to stimulate the physiologic cycle
  - Peter didn’t realize the body appreciated a difference between them
- They’re very similar and hCG is used, but the body doesn’t have hCG until the patient is pregnant
  - hCG works well as a substitute for LH

*Is there a synthetic LH out there as a drug?*

- Yeah
- It comes as a combination drug with FSH

**How do you prevent her from ovulating while you are giving her FSH and LH and she is ripening multiple polygons? How are you preventing an ovulation?**

- There’s another medication that we give, it’s called the [GnRH antagonist](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone_antagonist#Fertility_treatment)
  - It basically blocks the LH surge from happening until we cause it
- When you’re giving her FSH, the LH that’s attached to it is very, very low
- Blocking the [GnRH](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone_receptor) (with the antagonist) will prevent ovulation
- Peter is surprised that giving her so much FSH with a little bit of LH isn’t enough to suppress the GnRH
  - But clearly it’s not, or you wouldn’t be having to give her that

**Peter’s takeaway**:

- When you give her a GnRH antagonist, that basically puts a block between her hypothalamus and her pituitary
- Then you control the switch, and the switch is the megadose of hCG (which is an LH analog)

## The IVF lab process: egg retrieval, fertilization, embryo culture, and freezing [1:26:30]

**Do you harvest the follicles in the fallopian tube?**

- In the ovaries

**⇒** The egg retrieval happens 2 days after that hCG trigger (36 hours specifically)

- A woman comes into the surgery center (or a clinic with an anesthesiologist present) in the morning, 2 days after receiving hCG
- She’s administered general anesthesia ([propofol](https://en.wikipedia.org/wiki/Propofol))
  - It’s like a colonoscopy or dental extraction or something
- The procedure is all done vaginally using the ultrasound
- A needle is guided by the ultrasound that goes through the vagina into the ovaries
  - We don’t harvest trans-abdominally
  - You don’t have a straighter shot going through the abdomen, and there’s a lot of stuff between the abdomen and the ovary (like the bowel)
  - It’s much easier to go through the vagina (they’re sitting right there)
  - The ovaries are sitting right on top of the vagina, to the side of the uterus ‒ you  just stick a needle on either side and you can get an ovary
  - You’re not even going through the cervix
- This strikes Peter as a very delicate, complicated procedure
  - It’s a relatively minor type of surgery

Peter asks, “*How much do you have to dilate the vagina? What I’m thinking about is, how do you get your hand in there to guide the needle?*”

- You don’t have to get your hand in there
- It’s just the ultrasound probe and there’s a needle guide alongside it
- It’s a long needle, so your hand is not in the vagina
  - A 16-gauge needle
- You’re doing this under ultrasound guidance so you can see exactly
- You’re looking where you’re going with the ultrasound and you’re using the needle to puncture the ovary, get into the follicles
- The needle is attached to a vacuum suction, and so the fluid and the follicles collected goes through the needle and into the test tube
- Then that test tube is handed off to the embryologist, and they look under the microscope and try and isolate the egg

Peter asks, “*I’m just so full of dumb questions here today, Paula. How do you prevent yourself from sucking out 300 non-follicle eggs and ultimately destroy her long-term fertility risks?*”

- You only go into the large follicles, which are really the only ones you can see on ultrasound
- There’s gazillion of eggs in there, but you can’t even see them

***You’re just going into the follicles and you’re not running the risk of sucking up those eggs***

**⇒** On average, we get 10-15 follicles and each follicle is about 1.5-2 cm

- An unstimulated ovary is 5-6 cm (about the size of a plum), and when it’s stimulated it’s about the size of a grapefruit
- So you have really good resolution of where the follicles are
- You’re not running the risk of sucking everything out of the ovary
- We’re just getting fluid and the follicles , we’re not touching the tissue of the ovary

Peter asks, “*It’s only a 16-gauge needle. Does that mean you’re puncturing the follicle?*”

- Yes, the fluid of each follicle gets punctured before it enters the needle
  - They’re done one at a time
- A 16-gauge needle is only 1 mm across

Paula explains, “*You suck out all the fluid and you don’t have to take it out each time, you can go from follicle to follicle to follicle. You just have to go in typically twice, once on the right and once on the left.*”

- It’s easier to just watch a video of it [see below] and then you get the idea

**Video of egg retrieval for IVF** (Credit: [Dr. Paulien Moyaert](https://youtu.be/NUaH5mFBi2A?si=2crACQ6mIR05Qh59)):

**Video of ultrasound view of egg retrieval for IVF** (Credit: [Advanced Fertility Center of Chicago](https://youtu.be/sbu4la4bzjc?si=_DcG3IQXCPICXvTD)):

*Risks of egg retrieval*

- Peter is just thinking of all the things that could go wrong and how the needle could get gunked up with tissue
- Paula agrees, that could happen

***There’s always a small risk of bleeding, small risk of infection, small risk of injury in other organs***

- You do this on both sides, because you’re stimulating both sides

*How long does that procedure typically take?*

- Half an hour
- And you’ve got the embryologist next to you checking the eggs under the microscope
  - Basically, they tell us they got eggs
  - We don’t know if they’re mature yet; we know nothing about them yet

**Bottom line**: The retrieval is just aspirating all the follicles, trying to get as many eggs as possible

**Next step**: after we get the eggs, they go to the lab and the rest of the process happens there

**Let’s assume that the woman is doing this not to just freeze her eggs, but because she wants to get pregnant**

*What happens next?*

- The discussion of how many eggs to fertilize and freeze happens before harvesting the eggs
- Typically, we’re fertilizing all of them

**Tell me the time course now and how you move from retrieval to fertilization**

- The eggs are sitting in the Petri dish in the lab in a proprietary medium
  - Commercial companies make the medium, but the exact components of it are not entirely known
  - Different companies have different mediums
  - It’s meant to emulate the fluid in the fallopian tubes where fertilization would normally happen
  - There’s not that many companies making this type of media to choose from
    - Peter thinks this would be a huge area of innovation in the field, but it’s not really
    - In the early days of IVF, the medium might have been a problem, but nowadays, they’ve got it down
- The embryologist transfers the egg to the media and a few hours later, the eggs are inseminated
- With [conventional IVF](https://en.wikipedia.org/wiki/In_vitro_fertilisation#Co-incubation): a bunch of sperm are added and fertilization happens by itself
- With [ICSI (intracytoplasmic sperm injection)](https://en.wikipedia.org/wiki/Intracytoplasmic_sperm_injection): the embryologist takes a single sperm and injects it into each egg

**⇒** Anytime there’s a male factor [of infertility], we tend to do ICSI

- A lot of times it’s done even when there isn’t a male factor, because fertilization rate is a little bit higher with ICSI compared to IVF
- In very few cases, you don’t get fertilization
- So you don’t want to find out, oh, by the way, sperm can’t fertilize your egg, that’s the whole problem all along
- Because then you have to throw away the eggs

**Peter’s takeaway**: for a couple listening to us now, this is something they need to be talking with their fertility doc, which is, “*Hey, do you do ICSI out of the gate no matter what?*”

- Yeah, it’s a little controversial because it adds cost ($1,000-2,000)

**⇒** To be clear, the data shows that ICSI and IVF have similar success rates for [infertility due to] non-male factors

- But we do it a lot of times anyway because a very small percentage of cases have zero fertilization
  - That’s catastrophic because you’ve now lost those eggs too
- But technically, if you just look at the data, success rates should be the same
  - Exceeding conventional IVF if there is a non-male factor
  - But a lot of times there’s sperm factor, so we’re doing ICSI anyway

**What are the types of manipulations that are needed to foster the right environment?**

*This is done by the embryologist not the fertility doctor*

- The fertilized eggs are in media, in an incubator at body temperature, then all the micro-manipulations happen
- First, they strip the eggs, which means they remove the cells around the eggs
- Then a few hours later, they’re injecting the sperm into each egg
- Then the media these days may or may not get changed over the 5 or 6 days that we culture the embryos
  - We’re trying to not have to take the embryos out of the incubator if we don’t have to
- By the next day, usually we look at the eggs under the microscope to see if they’re fertilized
  - Usually about 70% of the eggs will be fertilized
  - Let’s say we get 10 eggs, you can expect maybe 7 of them will be fertilized, and now there’s 7 embryos
- We discard the unfertilized eggs, continue to culture the embryos in the Petri dish

**At this point, are all of the embryos in one dish or are you separating them?**

- They’re in one droplet of oil, and there might be more than one droplet in each dish

**How are embryologists trained?**

- There’s no clear pathway
- Most train through an apprenticeship
- You might start working in an fertility clinic and do some basic lab prep work initially
- Most of them have some sort of undergraduate science background, but you don’t have to

***You gain experience in the lab, and then eventually you become a junior embryologist; so it’s like a mentorship program***

Peter asks, “*How many years would it take if I started tomorrow working as a lab tech who was doing nothing but cleaning Petri dishes, how many years would it take for me to be the head embryologist in your lab?*”

- It might take 4-5 years
- There’s some formal schools with online programs, some with in-person components

Peter adds, “*Not to take anything away from what you do, but you could have the best fertility doctor, if they don’t have a good embryologist, you’re not going to have great success rates.*”

- Paula agrees, “*The lab is almost more important than what we do because there’s just more variability.*”
  - But luckily, at least the United States, the labs are pretty good
- Peter used to work in a lab and he can think of 100 ways it could get screwed up, contaminated, jostled (all these things that can go wrong)
- The lab is super important

***Most of the success rate is probably more related to what happens in the lab than anything the physician does***

**How many days is the embryo grown in culture (in the laboratory)?**

- 5-6 days
- It depends on if we’re doing a fresh transfer or freezing the embryos
- We do both
- These days, most of the time, we’re freezing

Peter asks, “*Because you’re doing genetic screening?*”

- Right
- After culturing the embryos in the Petri dish for 5-6 days, we look at the ones that have made it to that stage
  - We call that the **blastulation rate**

**⇒** Usually only half of the fertilized eggs make it to this stage

- If we started with seven, now maybe there is 3 or 4

**⇒** Most of the ones that didn’t make it are chromosomally abnormal

- You’re doing this in women who tend to be a bit older
  - Presumably, if you did this exact thing in 18-year-old girls, you’d have a much higher success rate
  - The blastulation rate (the ones that make it to day 5 or 6) is a lower percentage the older a woman is, because a higher proportion of those embryos are just going to be abnormal
- The embryos that make it to day 5 or 6 are more likely to be normal, but not necessarily normal
- We can also do genetic testing on those embryos, which involves biopsying them
  - We take a few cells from the embryo and freeze the embryos

**How many cells do you have at day 5?**

- Altogether you might have like 60 to 80 cells

**⇒** You can take 5-6 cells from the perimeter of the trophoblast (not the embryo directly, but the cells surrounding the embryo) for genetic testing

- You do that for each and every embryo, and then you freeze each embryo

**Tell me what the freezing process is like**

- The freezing process used these days is called [vitrification](https://en.wikipedia.org/wiki/Vitrification#Vitrification_in_cryopreservation)
  - It’s a special kind of freezing that doesn’t result in ice crystals
- A machine rapidly lowers the temperature
  - It’s like a liquid nitrogen dump
  - As opposed to the old days when we did slow freezing
- The embryo becomes a glass-like state without crystals, and the survival rate is really high
- Then they are stored in [liquid nitrogen](https://en.wikipedia.org/wiki/Liquid_nitrogen)
  - It’s not like your freezer at home

**How long does it typically take to get the genetic results?**

- A week or two

## Genetic testing and embryo selection in IVF: aneuploidy screening, polygenic traits, and ethical concerns [1:41:15]

**What depth of genetic testing is being done here?**

*Are you doing whole genome sequence or are you just looking at a handful of* [*SNPs*](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) *that are pre-identified as the ones that matter?*

- This has evolved over time
- It’s **still very controversial** because there’s always a risk of harming the embryos
  - You’re only looking at a few cells, so is it really representative of the embryo?
- We do it a lot, and the data definitely shows that if you transfer a normal embryo, it has a very high chance of implanting

**The issue recently has been**: are we discarding embryos that are maybe normal because we think they’re abnormal based on the genetic testing, but the genetic testing is flawed?

- The chromosomal analysis is trivial ‒ it’s really easy to identify [aneuploidy](https://en.wikipedia.org/wiki/Aneuploidy)

***Most of the time we’re using something called next-generation sequencing, which is very high-level sequencing, but it’s not whole genome sequencing (it’s targeted sequencing)***

**⇒** You’re looking mostly at chromosomal abnormalities, unless you know that the couple is a carrier for some genetic mutation that you also want to screen for

*Let’s say both of the parents are carriers for* [*cystic fibrosis (CF)*](https://en.wikipedia.org/wiki/Cystic_fibrosis)*, and so there’s a 1 in 4 chance that you’re going to get 2 copies of CF*

- Then you’re looking directly for the [CF genes](https://medlineplus.gov/genetics/condition/cystic-fibrosis/#causes)
- You would use the same approach for [beta-thalassemia](https://en.wikipedia.org/wiki/Beta_thalassemia), [sickle cell](https://en.wikipedia.org/wiki/Sickle_cell_disease) (there’s a whole bunch of them)

**⇒** Most people doing IVF will get carrier screening to see if they’re carriers for any genetic mutations

- Most of those people would say, “*I’m going to do IVF because I don’t want to take the chance.*”

**What about people who say, “*****We’re each*** [***APOE 3/4***](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) ***and we would really not like to select a 4/4.*****”?**

*Are you able to do that, and when does that start to cross an ethical line?*

- It’s a little more controversial when you’re talking about non-deterministic adult consequence genes with variable penetrance
- You may or may not get Alzheimer’s disease (or whatever it is)

***It’s a little more controversial, but we’re going in that direction***

- In the near future, we’re probably going towards whole genome sequencing where we can even pick up mutations that happen [de novo](https://en.wikipedia.org/wiki/De_novo_mutation) [in the embryo]
  - You might not be a carrier, but a mutation might just happen randomly, and so you could pick up some disease that way
- We often know ahead of time if the patient is a carrier of
  - [BRCA mutations](https://en.wikipedia.org/wiki/BRCA_mutation)
  - [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)#) [variations that increase risk of] cardiovascular disease
  - There’s a whole bunch of things

**People are starting to talk about polygenic screening of embryos**

- It’s a little more controversial because the science isn’t quite settled yet
- It’s one thing if you’re already doing IVF and we have these embryos here and we’re just going to add another layer of testing
  - Like which one of these embryos is at higher risk for diabetes or hypertension?
- That’s a whole different story if you’re saying, “*Oh, you should do IVF because we want to get the embryo with the lowest risk of these diseases*.”

***We’re not quite there, this is very controversial, it’s expensive, and there are ethical issues***

- There’s a question of is it a form of possible eugenics and that type of thing?

> “*Aneuploid testing, testing for chromosomal abnormalities is pretty routine, pretty standard.*”‒ Paula Amato

**There was a day when people weren’t doing any genetic testing and the embryo selection was just based on morphology**

- This was back in the days where we had to transfer more than one embryo because we didn’t know
  - You could look at 2 embryos and they could look both normal, but one of them is chromosomally abnormal and one’s not, and you can’t really tell
  - So we had to transfer more embryos to get decent pregnancy rates

**Current success rate of implantation**

- Now with genetic testing, because we know that a chromosomally normal embryo has a pretty high chance of implanting, [the success of implantation is] not 100%, maybe 70, 75%
- For some reason, that’s not the whole story because even chromosomally normal embryos sometimes don’t implant

***The success rate of implantation for a chromosomally normal embryo is 70-75%***

**What’s the concordance between a chromosomally genetically normal embryo and good morphology?**

- There’s good correlation
- We use both

*If there’s discordance there, which one are you relying on, or are you discarding unless you have concordance that’s positive for both?*

- In reality, the ones that have poor morphology aren’t even frozen or biopsied ‒ they’re discarded
  - They’re selected out
- There might be a little bit of difference in morphology between the ones that you’ve actually decided to freeze and biopsy and keep
- Presumably you have the genetic testing on all of them
- You would preferentially transfer the ones that are chromosomally normal, even if the morphology grade is a little bit lower

Peter asks, “*Let’s just say you harvested 15, you fertilized 10, 7 had good morphology, 6 came back genetically good. Those would be reasonable numbers?*”

- Yeah
- Maybe 5 (6 out of 7 is high)

**Peter’s takeaway**: you can implant one third of what you harvested, and each of those has a 70-75% success rate

**Would you only implant one at a time?**

- Yes
- If you implant 2, then you have a 50% chance of twins (which is high)
  - We can’t take that risk
  - Patients usually get to make that decision (we believe in patient autonomy)
  - You’re going to make the case for implanting 1 because you want a healthy baby and healthy mom

## Embryo transfer in IVF: timing, uterine preparation, and implantation support [1:47:30]

**How does that process work?**

- That process is much less complicated, but equally important
- Usually it’s timed ‒ it has to happen at a certain time in the cycle
  - We either use the woman’s natural cycle to time it when implantation would normally occur (which is the second half of the cycle)
  - Or we use what we call a controlled program cycle, where we basically give the woman the hormones and then time the transfer to happen at a specific time
- The actual process is kind of like a pap smear
  - It doesn’t require any anesthesia or anything
- We do it under ultrasound guidance, using abdominal ultrasound
- We thaw one of the embryos, draw it up in a little catheter with a syringe on the end
- Place the speculum in the vagina, and then just pass the catheter through the cervix
  - And we’re looking on the ultrasound for the placement

*Where are you implanting it?*

- 1.5-2 cm from the top of the uterus, a few centimeters through the cervix

*How do you make sure it doesn’t come out?*

- You can’t, but it usually doesn’t
- It’s more like peanut butter in there
- It’s not like you can stand up and it comes out; it stays in there

*What is the total volume you’re injecting?*

- 50 μL (really small)

**What does the inside of a uterus look like at that stage?**

*How thick is the lining?*

- It’s about 7-10 mm

*Is this technically 14 days past her period [day 1], or are you doing it artificially more into the* [*luteal phase*](https://en.wikipedia.org/wiki/Menstrual_cycle#Luteal_phase)*?*

- It’s roughly 7-10 days or so after ovulation
- The lining is thickened already
  - That’s one of the things we check with ultrasound before we do the transfer (to make sure the lining is thick)

*What does the lining actually look like? Is it tentacle fingers?*

- On the ultrasound, the 2 walls of the uterus are opposing each other
  - It’s not like you can see the cavity
  - It’s a potential space, not a real space
- On the ultrasound, the lining has a different echo density than the wall itself
- So we can measure thickness, and the combined thickness of the 2 opposing walls has to be at least 7 mm or so

Peter asks, “*And if you get in there and do the ultrasound and it’s not, are you going to come back and try to do it another day, and have you lost that egg because it’s been thawed or can you keep that egg in the medium now?*”

- We essentially assess the lining a week before we do the transfer
- So we would not thaw the embryo unless we were sure of the lining
  - Once it’s thawed, you don’t want to refreeze it

**Peter’s takeaway**: once you put the embryo in there, closer to the top of the uterus, it’s largely being held in place by the opposition of the wall

**Are you done, or are you still doing ongoing hormone therapy?**

- Sometimes we give supplemental progesterone
  - That’s another hormone that helps maintain the pregnancy
- And then usually 12-14 days later, the patient has her first pregnancy test (hopefully she’s pregnant)
- We usually follow the pregnancy for the first few weeks
- Then she transfers to an OB midway

> “*I’ve been doing it for 30 plus years, and I still find it fascinating*.”‒ Paula Amato

## Egg donation in IVF: indications, donor guidelines, and other considerations [1:50:45]

**How often does a woman go through all of this and for whatever reason you can’t get enough eggs, or the eggs you get are not chromosomally normal, and her next alternative is an egg donor?**

- Unfortunately, more often than we would like
- Again, it depends on the age of the patient
- Sometimes patients do multiple cycles, maybe they don’t have any normal embryos, or maybe even the normal embryos we transfer don’t take
  - A number of different things can happen

**⇒** The most common reason someone would need an egg donor is usually maternal age

- Someone who’s older and has tried to get pregnant with their own eggs, and it hasn’t worked for whatever reason
  - Now she’s looking at egg donation as an option

***Egg donation works really well ‒ the age of the uterus doesn’t seem to matter as much***

- Usually, **egg donors** are young women in their 20s, early 30s sometimes
  - They produce multiple eggs

**⇒** The success rate with a donor egg is quite high: about 70, 75%, whereas for women over 40, using their own eggs, success rate might be 10-20% (per cycle)

Peter reacts, “*Wow! 10-20% for a 40-year-old woman… I did not realize it was that low.*”

- Yeah; untested embryos, or they may not get any normal embryos

**How many times can a young woman be an egg donor before you worry about…**

*Is there anything you worry about if you’re counseling these women? (assuming the same women are coming to you as egg donors)*

- Sometimes people do it multiple times, sometimes they just do it once
- They’re essentially undergoing the IVF process themselves, or at least the first half of it
- There’s the **risks** we talked about: ovarian hyperstimulation (which is rare), risks associated with the retrieval, anesthesia

*Is there anything that restricts her ability to get pregnant later in life?*

- No
- Barring any major complications, it does not seem to impact future fertility

**What is the typical fee that’s collected by an egg donor?**

- Usually between $5,000-10,000, depending on where you live
- That’s a real incentive to do that
- A 2-week period

*How many times a year could a woman donate eggs if she wanted to?*

- The guideline is up to 6 times a lifetime
  - That’s a little bit arbitrary, but the professional society has decided that’s a good number of times
- Most people don’t do it that many times; they might just do it once or twice

**What do you discuss with women who undergo egg donation about the appropriateness of timing in explaining to the children that they have a different genetic mother?**

- Before anybody donate eggs, we always have them meet with one of our mental health therapists, just as a psychoeducational visit to go over these types of questions and best practices around what to tell the child, when to tell the child

***The general rule is tell them early and tell them often. You basically want to normalize the thing.***

- You definitely want to be the ones to tell them, and you don’t want them to find out by some other means
  - Like somebody contacts them on 23andMe or something like that

Peter asks, “*And early means what? Telling them before they understand reproduction? What are you telling them?*”

- That’s a little outside of Paula’s area of expertise
- Young could be 4 or 6 years of age
  - It might depend on the child and how mature they are, etc.
- There’s different ways to introduce the concept
- Obviously, if it’s a same-sex couple or if it’s a single person, it might happen earlier as opposed to a straight couple

## How to choose the right IVF clinic [1:54:45]

**If someone is listening to this and they’re trying to figure out how to select a good IVF clinic, what are the things they should be looking for?**

- Peter would assume it’s like any other field of medicine: not all doctors and not all clinics are created equal
  - Just because you see a lot of advertising, it doesn’t tell you anything
  - In other words, you’re going to have to become a very, very intelligent consumer
- For most people, this will be the single most expensive out-of-pocket healthcare expense they have
- It might be one of the most consequential as well
- When someone asks Peter about this, he goes down the rabbit hole of like, “*Here’s 100 questions I would ask.*”
  - It usually begins with, “*Tell me your success rate individually.*” (he doesn’t care about the national success rate)

*Paula’s advice*

- These days, it’s a little easier with the internet and there’s [suggested questions](https://springfertility.com/wp-content/uploads/2021/11/Spring-Fertility-Questions-to-Ask-at-Your-Initial-Consult.pdf) you can look at online
- It’s true, there is some variability amongst clinics, although there’s a lot of consolidation happening in the field as well
- So a lot of the practices are becoming common to most clinics
- Some of the questions are practical, like **location** ‒ which clinics are close to where you live?
  - You have to go in every few days, so most people can’t be going to another state
  - You have to go in and get these ultrasounds
- In most major cities, you have multiple options
- She agrees that Peter is right about **individual clinic success rates**, although technically it’s hard to use those to compare them to each other because you don’t necessarily know the population
  - So how do you normalize it?
- This is one of the few fields of medicine where clinic-specific success rates are publicly available from the [CDC](https://www.cdc.gov/art/success-rates/index.html) (until recently)
  - There is a law that was passed in the ’90s that says you have to report every IVF cycle and the success rate
  - Because of that, the CDC tracks this
  - Although all the people that work in that department were fired recently; so you don’t know what’s going to happen with that
- There is also our professional organization called the Society of Assisted Reproductive Technology, and its website ([SART.org](http://sart.org)) lists most of the clinics in the US
  - They have to report their success rates and it’s published every year

Paula would send people to the [SART website](https://www.sartcorsonline.com/members/Search) first: look at the clinics in your area, look at the success rates, keeping in mind that populations might be different in different clinics

- Look for a clinic that does a sufficient volume
  - You have to do at least 100 cycles (ideally more)
  - [sample data is shown in the figure below; the # of total cycles is listed under the title]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f6-paulaamato-1024x194.png)

**Figure 6. Sample Clinic Summary Report for 2022**. Image credit: [SART 2025](https://sartcorsonline.com/Csr/PublicSnapshotReport?ClinicPKID=2035&reportingYear=2022&fromDisclaimer=true)

**How many doctors work in your clinic?**

- We have about 6 doctors [Paula works at [Spring Fertility](https://springfertility.com/portland/) in Portland, OR]

**How many total cycles do you guys do a year?**

- We do 600-800 retrievals a year
- There’s a lot of variability: some clinics that do thousands, some that do 50
- Volume would be one factor that Paula thinks is important

**How many embryologists do you have?**

- About 9 embryologists
- There’s a shortage of embryologists nationwide and reproductive endocrinologists, because the demand for IVF is going up

Paula adds, “*I would definitely look at the clinic’s success rates, look at the volume.*”

- The other thing with the internet especially, you can look at **patient reviews**, word of mouth
  - Got to take those with a grain of salt, right?
  - They tend to be negative selecting
  - Not everybody who has a great experience is necessarily going to post it on Reddit, but everyone who has a bad one does

**You can also interview your doctor**

*What are questions you should be asking of the doctor that are independent of the objective metrics we just discussed?*

- Ask about their philosophy about protocols, about things like add- ons, like genetic testing
- Are you a clinic where everybody is encouraged to do genetic testing?
  - That’s not necessarily the clinic Paula would choose
  - Instead, she talks to the patient about the pros and cons and lets the patient decide
  - She does a lot of genetic testing, so it’s not like she is  against it or anything
- Get a sense of the vibe of the clinic: are they just interested in money?
  - Not that doctors ever think like that, but you know what she means

***Sometimes it takes having a consultation with one or more clinics to see where you feel more comfortable***

- Paula is a little bit biased towards some academic centers, just because their missions includes education and research, etc., but there’s several very excellent private clinics as well

**How much of a delta is there in cost within the same city? Or do prices tend to converge within a given geography?**

- Within a given geography, they’re pretty similar (it’s not cheap)

*What is the fully-loaded cost today?*

- An IVF cycle is probably around $20,000 per cycle
  - That includes genetic testing per cycle

*How does that compare to 20 years ago?*

- Like most things, prices have gone up
- It should go up just based on the cost of labor that goes into all these things, and there’s innovations
- Even though the price of genetic testing is coming down

Paula explains, “*You think as volume goes up, eventually prices go down, but that hasn’t quite happened. As new things get added, then it just tends to become more expensive*.”

**Are most people still paying out of pocket? Is this covered by insurance?**

- It  depends on where you live
- There are now 24 states that offer some kind of fertility coverage and about 15 of them include IVF
- Most places though, you are paying out of pocket if your employer doesn’t happen to offer infertility insurance coverage

**What would be some red flags if you’re going through this process?**

- Communication with the clinic
  - A lot of your experience is going to be communicating with nurses and coordinators just setting up appointments
  - You want to get a sense of what that is like, because that could be stressful if it’s not smooth
  - Sometimes it’s not smooth (Paula includes her clinic in this): there’ve been some things we try and do, like texting and apps and things, to make the communication easier, and it doesn’t always work the way it’s supposed to
- You want to get time with your doctor
  - In some clinics, you hardly ever see the doctor and you see maybe the ultrasonographer
  - Not that that’s bad, but some patients prefer to have more frequent interaction with their actual provider

**Peter’s takeaway**: there’s a sweet spot in volume; it’s probably an inverted U-shape, where if they’re too low, they don’t have the reps, and if they’re too high, it’s a bit of a sweatshop and a factory (you want in the middle there)

## Innovations in fertility on the horizon, advice about freezing eggs, and more [2:02:00]

**What’s on the horizon medically for extending fertility?**

*There’s a* [*study*](https://www.nyp.org/advances-womenshealth/pilot-study-evaluates-weekly-pill-to-slow-ovarian-aging-delay-menopause) *going on at Columbia looking at the use of rapamycin to extend fertility in women*

*What is the question that is being asked, and how is it being asked in this study?*

- There is a lot of interest in extending fertility
- Up until 100 years ago, women were basically dying at 50, the average age of menopause

> “*It’s kind of a recent phenomenon that we’re actually living a third of our lives post-menopause.*”‒ Paula Amato

- Fertility starts to decline way before you go through menopause
- Now, of course, **egg freezing** (which we haven’t talked about yet), is one of the ways you can extend fertility, and it works pretty well as long as you’re young when you freeze your eggs
  - Again, it’s a relatively recent phenomenon
  - You’re not usually covered by insurance and it’s expensive, etc.
    - You’re paying basically half the IVF cycle to harvest, and then you’re paying to freeze
  - So it’s not the answer

Peter asks, “*What is the cost of freezing [eggs]?*”

- $10,000 for the cycle, and then about $1,000 a year for storage

**What do you recommend for a woman who is 20-years-old who wants to focus on her career and then have kids, who asks, “*****When should I freeze by?*****” Are you going to say, “*****Do it now*****”?**

- No
- Paula wouldn’t recommend all women in their 20s freeze their eggs, because most of those eggs will never be used
  - You’d be doing it for nothing because most of those women will probably not need IVF and will get pregnant spontaneously

***We think the sweet-spot is early to mid-30s (that’s where it makes the most sense)***

- Because you’re about to get to the probability cliff where fertility starts to really decline
- If you think you might want to have kids but you’re not in a place in your life where you think that’s going to happen in the next few years, then freezing your eggs when you’re in your early to mid-30s is probably the time where it’s most cost-effective
  - Very high likelihood that you will use them, if not for the first kid, maybe for the second kid
  - And it might be worth spending $10,000 and $1,000 a year

**Do you freeze every egg you retrieve?**

- Only the mature ones

**Expectations for a typical 30-year-old**

- You’re probably going to get 10-15 eggs per cycle (on average)

*How many cycles do you recommend a 30-year-old do?*

- There are some [calculators online](https://springfertility.com/eggcalc/)
- The younger you are, the fewer eggs you need because more of them are going to be normal
- For someone age 30, 10-20 [eggs] would give you a decent chance of success
  - There’s never any guarantees
  - But studies show that even if people use those eggs and they’re not successful, the fact that they did something proactively, there’s some psychological benefit in doing that
- As you get closer to 40, you might need 20-40 or 50
  - Which is not practical for most people because you can’t do that many cycles
  - And it’s expensive and there’s risks involved

> “*I think egg freezing is a great option for women.*”‒ Paula Amato

- Paula also thinks as a society we should try and make it easier for women to have kids during their peak reproductive years (in their 20s and 30s)
  - A whole different question

**Back to rapamycin**

*How is this* [*study*](https://www.nyp.org/advances-womenshealth/pilot-study-evaluates-weekly-pill-to-slow-ovarian-aging-delay-menopause) *testing this?*

- [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is used in other anti-aging type contexts
- There’s some [animal data](https://pubmed.ncbi.nlm.nih.gov/29330421/) that shows that maybe rapamycin might extend fertility
- Remember the egg cell death that we talked about earlier?
- By preventing that to some degree, so that the eggs last longer and you’re fertile for more years
- The data is mixed in animal models
- The study at Columbia is actually trying to test it in humans
- Paula believes this study is a few months long where they’re giving a relatively low dose of rapamycin
  - [the study will use a dose of [5 mg per week](https://www.nyp.org/advances-womenshealth/pilot-study-evaluates-weekly-pill-to-slow-ovarian-aging-delay-menopause#:~:text=The%20VIBRANT%20trial%20is%20a%20pilot%20study%20that%20will%20evaluate%20a%205%2Dmg%20per%20week%20dose) for 3 months with a 9 month follow-up]
- Their outcome marker is the hormone [AMH](https://en.wikipedia.org/wiki/Anti-M%C3%BCllerian_hormone)
- It’s a relatively inexpensive study
- They’re not invasively looking at follicles
- What you have to believe then is, in just a period of a few months, you could pick up a signal of more or less AMH reduction
- And even if you can, what does that mean really?
- Peter thinks if the study is positive, it’s interesting
  - If it’s negative, it probably doesn’t tell us much; it’s only 3 months
- Paula agrees, to really do the study, you need long term (a few years)
  - You need pregnancy outcomes or at least age of menopause
  - That would take a long time and you’d have to take it for many years, probably
- Peter agrees, that’s going to be a really difficult question to answer in humans

*The problem is the animal data is not consistent*

- Some studies show maybe rapamycin is helpful
- Other studies show that it might actually be harmful because of the way it is immunosuppressive and things

***Certainly for any listeners trying to conceive, Paula would not recommend rapamycin***

- But yes, she is curious about the data coming out of Columbia and other studies

## Optimizing fertility through lifestyle: diet, stress management, sleep, exercise, and supplementation [2:07:45]

**What would be the most common things you would be saying to a woman who is otherwise experiencing idiopathic infertility (for lack of a better word)?**

- We already addressed PCOS and the metabolic stuff
- We hear things all the time about stress and sleep
- Paula thinks all of those things, lifestyle factors are important
  - They’re rarely the sole cause of infertility, but they can certainly exacerbate infertility as well as any other disease

> “*The lifestyle factors that promote health are generally the same lifestyle factors that promote fertility.*”‒ Paula Amato

- A healthy diet is important

**What is a healthy diet as it pertains to fertility?**

*Is it different? Does a woman who’s getting ready to conceive, does she need more fat in her diet, for example?*

- The data on diet is not great for anything, especially not fertility
- There’s very little evidence that there’s a particular diet that’s good for fertility that’s different from what’s good in general

***For most of patients, Paula recommends a Mediterranean diet***

- That diet is palatable to most people and has a fair amount of evidence that it’s reasonably healthy
- That’s a lot of fruit and vegetables, whole grains, protein (mostly from fish) and olive oil
- It’s not that different from what she would recommend for anybody

**What supplements do you recommend?**

- Peter loves frameworks
  - Maybe one framework is are there supplements that correct legitimate deficiencies like vitamin D or B vitamins, where we could make a case that supplementing with these things happen?
- Peter is talking beyond just the prenatal vitamins that are obvious and necessary
  - We’ll leave that to the side because it’s so self-evident

*Peter is asking about supplements that are more grab-bag mystery supplements where you’re not actually correcting some obvious deficiency, but we think it might increase fertility*

- The data around supplements is even less robust than the data around diet

Yes, you can make a case for correcting deficiencies

- A lot of reproductive-age women, are iron deficient, for example, and they might need to be on iron supplements
- You mentioned prenatal vitamins
- Obviously, folic acid is important for anybody trying to get pregnant
- People who live in Portland, Oregon (where Paula is) tend to be vitamin D deficient
  - She usually recommends vitamin D for people

Other supplements specifically for fertility

- The ones she most commonly hears about are things like [CoQ10](https://en.wikipedia.org/wiki/Coenzyme_Q10) or [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone) is another one
- There’s some data that it might be helpful (again, it’s not very robust)
- DHEA increases endogenous testosterone production and improves egg quality
  - Who knows how it works
  - The data isn’t great
  - Might improve libido – Paula thinks people have studied that and it doesn’t work so well
  - It’s a weak androgen
  - The data is not there and probably will never be there because their symptoms aren’t there to do those studies
- It probably doesn’t hurt, though, so Paula is relatively supportive if the patient wants to take CoQ10

Peter asks, “*Do you think it’s just psychological, where if they take it and they feel that they’re doing something better, it reduces their stress around it? Because for me, I can’t help but think that stress has such a negative impact on fertility.*”

- Oh, for sure
- It’s so difficult to quantify stress (like many aspects of health) ‒  we don’t have a biomarker
- Even measuring [cortisol](https://en.wikipedia.org/wiki/Cortisol) doesn’t actually tell you anything about the experience of stress

***There are so many negative health outcomes that result from stress, and therefore, anything that a person can do to improve their stress, helps***

- If taking supplements helps with that, she’s all for it
- Peter is not advocating that we should go crazy on it with no evidence, but he wonders if any of the efficacy of those things is mediated through that reduction of stress
- Paula agrees: as long as it’s not harmful, that’s great

**⇒** When we say the data isn’t there, that doesn’t mean that it doesn’t work; it just means that nobody has shown one way or another whether it works

- It’s not helpful to tell a patient, “*You need to be less stressed out.*”

***Finding a way to cope with stress is really what we’re talking about, and it can be different for different people***

- For some people it could be exercise, it could be meditation, it could be mindfulness, social support
- Whatever it is, it’s an important step

***Sleep, diet, and exercise are important for fertility***

**Do we know anything about too much exercise for women who are trying to conceive?**

- We certainly hear stories about college athletes and women who are doing a lot are actually having difficulty even maintaining a regular menstrual cycle
- What are some clues that a woman’s exercise might actually be too much and that might be impacting her fertility?

***Extreme exercise can be associated with fertility issues, but for most patients, exercise is beneficial***

*Extreme would be*

- If it causes any change in a person’s [menstrual] cycle
- For some extreme athletes, sometimes their periods will stop altogether
- There’s a condition called [RED-S (relative energy deficiency in sport)](https://en.wikipedia.org/wiki/Relative_energy_deficiency_in_sport)
  - Basically the body’s very smart, if it thinks there’s not enough energy around to support a pregnancy (because we’re expending it all on this exercise), it’s just going to shut the whole thing down
  - The patient stops menstruating
  - So obviously, they’re going to have difficulty getting pregnant if they’re not menstruating, it means they’re not ovulating
  - It has other implications for things like bone health because the ovary, in addition to making eggs, also makes estrogen, and estrogen is super important for bone health
  - [the figure below summarizes the symptoms of RED-S]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f7-paulaamato.png)

**Figure 7. Symptoms of RED-S**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Relative_energy_deficiency_in_sport)

**Paula recommends women keep track of their menstrual cycle**

- She talked about semen analysis being a marker of other health outcomes
- Your periods are also a marker
- Of course, if you’re on [hormonal contraception](https://en.wikipedia.org/wiki/Combined_hormonal_contraception), you might not know what your natural cycle is doing

**⇒** Red flags: if your cycles are irregular or if you’re not having them at all, or if they’re super painful or they’re super heavy

- And sometimes you don’t know what’s super painful or super heavy because nobody talks about anything
  - Thankfully this generation of young women is talking more and there’s the interne

***Don’t wait until you’re ready to try to get pregnant to figure that out; there may be something important you need to know way ahead of time***

**We’ve already talked about obesity, but on the other side of that, is there a certain body fat level beneath which fertility is also impacted?**

- There’s not a cutoff, but certainly being overweight or obese can impact fertility and being severely underweight
- For the underweight people, this is a similar mechanism, if your brain thinks there’s just not enough, it’s usually going to manifest through [amenorrhea](https://en.wikipedia.org/wiki/Amenorrhea)

**Summary of factors that affect fertility**

- Disrupted sleep could affect ovulation and fertility
- Stress
- All the things Peter mentioned in his book [[*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=2TC711USCGSV6&dib=eyJ2IjoiMSJ9.P2oZuRwhOizmZb9mpYCQtECUAcvg5rlEd8KVys71cK995QWrBVd90W-dZA4NMMgS8MSZtfA_JyTg2mK8C3BgF6G3nVqje3abCz2y3drJbbavncfG57OFcnu5wMVC_TUPjRmyd_Jgmw2PhB2fSQD5BvbfHrSOs-cpxsA3MXSaCuZ9U5uM8OIbuBbNwmhAaWgcQQaFw1OlvGiC4ep6gdBaNKaAN6ci_4C4JARk0b7LDBA.IyNaZjNV_ob6e9nkrWhsrXR5O402Dm6B7ttuAT5mgWc&dib_tag=se&keywords=outlive&qid=1746817978&sprefix=outlive%2Caps%2C100&sr=8-1)] are all the same things that are important for fertility

## Promising areas of fertility research [2:15:45]

**What do you think is the most promising area of research?**

*If we’re sitting here in 10 years and we’re talking about this and we’re looking back at the last decade, what do you imagine you will be most excited about from an innovation perspective?*

- There’s always innovations happening
- **Genetic testing** will continue to evolve as we learn more about genetics, and that’ll play a bigger role
- **Automation in the lab**: a lot of the steps we talked about earlier are literally an embryologists sitting at the microscope doing these things
  - But now, there’s some companies developing these lab-on-a-chip concepts (microfluidics) where you put in the egg, put in the sperm, an embryo comes out at the other end
  - The whole process is becoming automated, and it could potentially improve access

Peter asks, “*Do you see this as more of a cost reduction or more of a success improvement?*”

- Maybe both
- It could potentially reduce error
- Usually, the cost of things tends to go up anytime there’s an innovation, before it comes down
- Maybe ultimately, it’ll come down

**Another exciting area is in vitro maturation**

- That’s where the eggs are maturing in the Petri dish instead of in a woman’s body
- Potentially in the future, a woman wouldn’t have to take all these injections, and you could just take the immature eggs, put them in the Petri dish, and then give the Petri dish the medications, if you will
- That work is in very early stages, not quite as successful as conventional IVF yet

Peter asks, “*I assume because it’s difficult to harvest un-mature follicles?*”

- Partly
- And even that maturation process, we haven’t quite gotten it down like it happens in the body

**A real game changer would be something like in vitro gametogenesis**

- This is making eggs and sperm potentially from skin cells
- So even if you run out of eggs, if we could take a skin biopsy and reprogram that cell to make an egg
- We are in the very early stages of that
- It’s been done in mice
- Paula thinks we’re probably 10-20 years away

*What’s the obstacle?*

- The whole process of reprogramming skin cells is very complicated and not easy
  - Taking a skin cell back to a stem cell, and then the stem cell to the egg
  - Both of those steps are hard to do
- There are a couple of companies that are trying
- Paula does research in this area, you essentially take the nucleus from a skin cell and put it into an egg
  - Just replacing the genetic material so you don’t have to reprogram the skin cell

Peter asks, “*Is it easy to separate the chromosomes?*”

- No, it’s very complicated for meiosis to happen efficiently and equally
- We’re probably 10, 20 years away
- But that would be an alternative way to get to that
- But then you need donor eggs, and so that has its own limitations
  - It’s not like donor eggs are easy to come by either
  - But it does help the older woman who is able to make follicles, but they’re just [aneuploidic](https://en.wikipedia.org/wiki/Aneuploidy)

**Another thing we’re working on is something called mitochondrial replacement therapy**

- It’s a similar concept
- You have an older woman, she undergoes IVF
- You have a donor that undergoes IVF, but you take the nucleus out of the older egg and you put it in a younger egg
- So essentially, the cytoplasm is from the young egg (including the mitochondria)
  - [all the mitochondria in an embryo comes from the egg]
- We think other aspects of aging are acquired mutations in the mitochondria

***So if you have young cytoplasm, young mitochondria ‒ maybe that nucleus will do better in that young egg***

- Unfortunately, we can’t do that in the United States legally, but we’re doing trials in other countries

**Peter’s parting thoughts [2:20:00]**

- This is a remarkable field
- It’s still amazing how well this works
  - If you think about it, it’s very brute force; it’s very mechanical
    - He doesn’t mean this in a disparaging way at all
- When you think about the timescale of this as a field, it’s having an enormous impact that is relatively recent
- It seems that early intervention is better

**Important takeaway**: Paula’s point about women who have any sort of irregularity in their cycle, if they’re in their teens or 20s, if for no other reason beyond just the discomfort of it at the moment, getting this looked at now is a great way to get ahead of an infertility problem 10 years hence

- While we don’t have a high listenership of 18-year-old girls, there are parents who are listening and this message might make its way to potential future patients
- It’s also comforting to hear just how high the probability of success is in the modern era, today
- It sounds like we’re converging on quality, whereas Peter would imagine this was a field that was a bit like the Wild West 20 years ago
  - Where you had a bunch of low-quality practitioners
  - He’s guessing today, with consolidation of groups, we’re seeing less and less of that and more standardization
- Peter is blown away at the concept of the embryologist and what’s required to do that
  - That we don’t have a more formal training path, especially given that you said that we have a shortage of such people
  - That seems like an incredibly rewarding career for somebody

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Paul Turek**: [#351 ‒ Male fertility: optimizing reproductive health, diagnosing and treating infertility, and navigating testosterone replacement therapy | Paul Turek, M.D.](https://peterattiamd.com/paulturek/) (June 2, 2025) | [1:30, 17:45]

**Episode of** ***The Drive*** **on HRT**: [#348 ‒ Women’s sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.](https://peterattiamd.com/rachelrubin/) (May 12, 2025) | [43:00]

**Letrozole is better than Clomid for treating infertility in women with PCOS**: [Letrozole versus clomiphene for infertility in the polycystic ovary syndrome](https://pubmed.ncbi.nlm.nih.gov/25006718/) | *NEJM* (R Legro et al. 2014) | [53:15]

**Fertility clinic where Paula sees patients**: [Spring Fertility](https://springfertility.com/) (2025) | [58:15, 1:58:00]

**American Society for Reproductive Medicine guidelines for the number of embryos that can be transferred during IVF**: [Guidance on the limits to the number of embryos to transfer: a committee opinion](https://www.asrm.org/practice-guidance/practice-committee-documents/guidance-on-the-limits-to-the-number-of-embryos-to-transfer-a---committee-opinion-2021/) | *ASRM* (2021) | [1:05:30]

**Double IUI has the same success rate as single IUI**: [Double intrauterine insemination (IUI) of no benefit over single IUI among lesbian and single women seeking to conceive](https://pubmed.ncbi.nlm.nih.gov/31410635/) | *Journal of Assisted Reproduction and Genetics* (B Monseur et al. 2019) | [1:12:30]

**Questions to ask on your first visit to a fertility doctor**: [Questions to ask at Your Initial Consult](https://springfertility.com/wp-content/uploads/2021/11/Spring-Fertility-Questions-to-Ask-at-Your-Initial-Consult.pdf) | Spring Fertility (2021) | [1:56:00]

**Fertility clinic success rates**: [ART Success Rates](https://www.cdc.gov/art/success-rates/index.html) | CDC (2025) | [1:56:45]

**SART data on IVF clinic success rates**: [#StartWithSART Find and IVF Clinic](https://www.sartcorsonline.com/members/Search) | Society for Assisted Reproductive Technology (2025) | [1:57:15]

**Study evaluating the potential for rapamycin to delay menopause**: [Pilot Study Evaluates Weekly Pill to Slow Ovarian Aging, Delay Menopause](https://www.nyp.org/advances-womenshealth/pilot-study-evaluates-weekly-pill-to-slow-ovarian-aging-delay-menopause) | NewYork-Presbyterian Advances in Women’s Health (2025) | [2:02:00, 2:05:30]

**Online calculator for egg freezing**: [Egg Freezing Outcome Estimator](https://springfertility.com/eggcalc/) | Spring Fertility (2025) | [2:04:30]

**Animal data suggesting that rapamycin may extend the reproductive lifespan**: [Premature recruitment of oocyte pool and increased mTOR activity in Fmr1 knockout mice and reversal of phenotype with rapamycin](https://pubmed.ncbi.nlm.nih.gov/29330421/) | *Science Reports* (E Mok-Lin et al. 2018) | [2:05:45]

---

## People Mentioned

- [Paul Turek](https://alphasperm.com/pages/paul-turek)
- [Rachel Rubin](https://www.rachelrubinmd.com/drrubin)

---

![](https://peterattiamd.com/wp-content/uploads/2025/06/bio-paulaamato-600x600.png)

##### Paula Amato, M.D.

Paula Amato, earned her Medical Degree and completed her residency in obstetrics and gynecology at the University of Toronto. She did a fellowship in reproductive endocrinology and infertility at the University of California-San Diego. Dr. Amato is a physician scientist. She is Professor of Obstetrics and Gynecology and Division Head of Reproductive Endocrinology and Infertility at [Oregon Health & Science University](https://www.ohsu.edu/people/paula-amato-md). She sees patients at [Spring Fertility](https://springfertility.com/team/dr-paula-amato/) in Portland, Oregon.  She served as president of the American Society for Reproductive Medicine from 2023-2024.

Dr. Amato specializes in caring for patients with infertility, polycystic ovary syndrome, and menopausal issues. Her research focuses on innovative assisted reproductive technologies for the treatment of infertility and ovarian aging. Dr. Amato is an expert in the science of reproductive endocrinology and infertility. [[Spring Fertility](https://springfertility.com/team/dr-paula-amato/)]

LinkedIn: [Paula Amato](https://www.linkedin.com/in/paula-amato-07150614/)

X: [@PaolaAmato](https://x.com/paolaamato)