# #280 ‒ Cultivating happiness, emotional self-management, and more | Arthur Brooks Ph.D.

**Source:** [https://peterattiamd.com/arthurbrooks2/](https://peterattiamd.com/arthurbrooks2/)

---

Arthur Brooks is a social scientist, professor at Harvard University, columnist for The Atlantic, and bestselling author. In this episode, Arthur returns to the podcast to discuss his new book, [Build the Life You Want](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2). He delves into the nuanced concept of happiness, differentiating between momentary feelings and overall wellbeing. He explains the importance of understanding one’s personality pattern with respect to positive and negative emotions in order to better self-manage emotions. He delves into the three key elements of happiness, offering practical strategies for enhancing those specific domains through methods such as metacognition, transcendent experiences, discipline, minimizing self-focus while directing attention outward, and more. Through personal examples, Arthur demonstrates that one can actively track well-being levels and take intentional steps to cultivate happiness and enhance overall well-being.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/arthurbrooks2/the_Drive_public.png)

Play

#280 ‒ Cultivating happiness, emotional self-management, and more | Arthur Brooks Ph.D.

#280 ‒ Cultivating happiness, emotional self-management, and more | Arthur Brooks Ph.D.

1x15s30s

0:002:00:42

## We discuss:

- Happiness vs. happy feelings, and how happiness and unhappiness can coexist [4:30];
- The six fundamental emotions [8:00];
- The evolution and heritability of happiness, and the four personality patterns with respect to positive and negative emotions [17:30];
- Navigating relationships: the power of complementarity over compatibility [23:30];
- The importance of self-managing your mental habits [25:30];
- Enjoyment: one of the three macronutrients of happiness [32:00];
- Satisfaction: one of the three macronutrients of happiness [43:45];
- The reverse bucket list, metacognition, and other techniques to protect yourself from your limbic system [51:00];
- Meaning: one of the three macronutrients of happiness [57:30];
- The four quarters of your life and how that relates to the meaning of your life [1:05:00];
- Putting metacognition into practice [1:09:00];
- What might explain the societal downdrift in happiness over the last few decades? [1:17:00];
- Taking charge of your happiness: discipline, transcendent experiences, and other deliberate actions for happiness [1:30:30];
- Tracking happiness: biomarkers and micronutrients behind the macronutrients of happiness [1:42:00];
- The value in minimizing the self and looking outward [1:49:45];
- How Arthur surprised himself with his ability to improve his happiness [1:54:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Our returning guest this week is Arthur Brooks, originally on the podcast in October 2022 [[episode #226](https://peterattiamd.com/arthurbrooks/)]
- Peter wanted to have Arthur back on the podcast to talk about his new book on happiness called [*Build the Life You Want*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2)
- Arthur is a [Harvard Professor](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664), a Ph.D. social scientist, and a columnist at [*The Atlantic*](https://www.theatlantic.com/projects/how-build-life/), and also the best-selling author of [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - This is one of the handful of books Peter keeps in multiple copies to share with anyone who come over to the house and doesn’t have a copy
- Arthur’s work specializes in using the highest levels of science and philosophy to provide people with actionable strategies to live their best lives
- In this conversation we focus on the idea of happiness
  - That sounds like a very vague concept
  - And if you’re anything like Peter was a few years ago, you would reject the idea that this was something that could be studied
- We speak about the difference between happiness, happy feeling, unhappiness, the evolution and heritability of happiness, and the different types of emotions we have
- Peter thinks Arthur has a really helpful way to think about this
- One of the most important things Peter has noticed himself observing since reading this [book](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2) and talking with Arthur is, “*In the moment, my emotions may not necessarily reflect my overall state of happiness, and I shouldn’t confuse in the moment feelings of uneasiness (or even negatively valenced emotions) with the overall picture of what Arthur calls, ‘The macronutrients of happiness.*’”
- We speak a lot about the positive and negative affect schedule (PANAS) and a test you can take to help understand your predisposition to types of happiness and to your compatibility with others
- We then focus on what Arthur calls, “*The macronutrients of happiness*”
  - Enjoyment, satisfaction, and meaning
    - While all of these words are familiar, in this context, they have a specific set of parameters
    - It’s worth understanding them because it’s what Peter keeps coming back to as he examines his own life
- We talk about the importance of metacognition and transcendence in our happiness and the idea of me-self versus I-self
- We end the conversation looking at potential biomarkers and what a dashboard for happiness might look like
  - Not blood-based biomarkers
  - The term biomarkers is used loosely to refer to other questions that one might ask themselves to get a sense of their overall happiness just as we may look at our own blood-based biomarkers to get a sense of our overall health
- The deeper Peter gets into this world of longevity, the more and more convinced he is of the importance of a topic like happiness
- As he wrote about in [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=1MA1P4X1UMXAK&keywords=outlive&qid=1698768779&sprefix=outlive%2Caps%2C97&sr=8-1), there really is no clear reason to want to live longer if you are unhappy
- For that reason, Peter finds himself especially drawn to this kind of work
- Peter considers himself to be constantly on a journey to understand this in himself and to understand how he can help his patients with this

## Happiness vs. happy feelings, and how happiness and unhappiness can coexist [4:30]

the interplay of positive and negative emotions between happiness and unhappiness

- Peter congratulates Arthur on his new book and adds, “*This is not your first, second or third rodeo, but I’m sure each time, it’s a little bit of a what’s the world going to think?*”
- Arthur thinks writing a book is like having a child, “*A book is something where as you bring it into the world you go through…*” [stages]
  - He remembers [Elisabeth Kübler-Ross](https://en.wikipedia.org/wiki/Elisabeth_K%C3%BCbler-Ross), the Swiss psychiatrist who wrote that famous [book](https://www.amazon.com/Death-Dying-Doctors-Nurses-Families/dp/1476775540/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1698246510&sr=8-1) about death and dying
  - You have to go through five stages
  - Most of that research has been questioned since then, but it’s pretty interesting
- When writing a book, you go through bargaining and denial and rage, and finally there’s acceptance but you’re still nervous for sure

**What’s the difference between happiness and happy feelings? Are they the same thing?**

- They’re not the same thing, and this is a really important misconception
- Most of us live in the era of feelings
- Arthur adds, “*If you’d talk to my parents or, god knows, my grandparents about feelings, they would scratch their head. What are you talking about?*”
- You’re talking about your emotions all the time
- [Ephemera](https://en.wikipedia.org/wiki/Ephemera) feeling seems so counterproductive
- Our grandparents were right: feelings are not happiness any more than the smell of the turkey is your Thanksgiving dinner
- Feelings are *evidence* of happiness, and that’s incredibly good news

***A lot of people think that happiness is a feeling. It’s quite incorrect.***

- There are many better technical definitions of happiness, but they produce a lot of feelings
  - They’re associated with a lot of emotions, which is [limbic system](https://en.wikipedia.org/wiki/Limbic_system) activity (a part of the brain)
    - A 40-million year evolutionary process that developed the limbic system to create emotions
    - That signals information and is what emotions come from

> “*If you mistake these feelings for the underlying phenomenon of happiness, you’re going to be chasing it all over the place. You’ll be chasing ghosts, how I slept last night, what I ate for breakfast, if my spouse yelled at me this morning.*”‒ Arthur Brooks

- If you mistake the feelings of happiness for the underlying phenomenon of happiness, you wind up being managed as opposed to having any prayer of managing your own happiness

***That’s the first thing to keep in mind: it’s not feelings***

- Peter reflects, “*It’s hard to differentiate though… you have to remind yourself when you’re in the throes of what I just referred to as negatively valenced feelings, that this is not a statement of my overall state of happiness.*”

**What’s the relationship between unhappiness and happiness? Are they polar images? How do they coexist?**

- If you go back to the ancient philosophers, there was the idea that happiness and unhappiness exists on a spectrum
  - So unhappiness would be the lack of happiness
- We know a lot better now given the explosion of neuroscience and the way that emotions are produced that in fact, you can be happy and unhappy
  - Or have happy and unhappy feelings in parallel
- For example, the average person spends about 40% of their time with predominantly positive feelings
  - It sits in a neutral idle of positivity
  - Most people do, not everybody
- About 16 or 17% of the time, the average person has predominantly negative feelings, something is going on
  - That’s more intense
  - And part of the reason is because negative emotions get your attention and they’re supposed to
    - Evolution favors negative emotions
    - Positive emotions are nice to have, but negative emotions, pay attention because that could cost you your life

## The six fundamental emotions [8:00]

**What are some of the most powerful negative emotions that would drive action?**

*If you think about his evolutionarily, and not even going back to millions of years ago but just going back hundreds of thousands of years ago to the origin of our species as homo sapiens*

- There are basically **six fundamental emotions** or basic emotions
  - These are the building blocks of all emotional life that are produced by the limbic system of the brain, four negative and two positive
- The **four negative emotions** are sadness, anger, fear and disgust
  - All four of those have a very strong evolutionary basis
- **Fear and anger** have to do with threat
  - They involve the [amygdala](https://en.wikipedia.org/wiki/Amygdala) of the brain
  - When a car is about to run you over and you’re a pedestrian in a crosswalk, that crosses your visual cortex and is recorded in the occipital lobe of your brain as an enormous predator
    - That signals to your amygdala to send the signal through the hypothalamus of your brain to your pituitary glands (which signals your adrenal glands above your kidneys) to spit out stress hormones
    - That happens in 74 milliseconds
    - By that time, you’re sweating, your heart is pumping, you’ve jumped out of the way and you’ve flipped off the driver, a combination of fear and anger in response to the enormous predator
    - Three seconds later, your prefrontal cortex catches up and you say, “*I shouldn’t have flipped him off. That’s not my values*,” or whatever it happens to be
  - So that’s your limbic system keeping you alive (that’s fear and anger)
- **Disgust** involves the [insular cortex](https://en.wikipedia.org/wiki/Insular_cortex) of the brain, also part of the limbic system
  - That’s when you pull something out of the back of your fridge you forgot about a few weeks ago, and you hold it and you’re like, “*Oh.*”
    - That signals don’t eat it
    - And so anything that might carry a pathogen signals that basic negative emotion of disgust to you
  - Now, it can be misattributed to people, and that’s what demagogic politicians always do
    - That’s what the media does to us
    - It tries to reprogram the insula of the limbic system of the brain so that when somebody disagrees with you politically, you look at them like a cockroach
    - That’s what demagogic leaders and dictators have done for time immemorial so that people will undertake barbaric acts against people in their own countries, at least of war, etc.
- Last but not least is **sadness**, and sadness has also evolved
- Sadness is what you feel largely in the [dorsal anterior cingulate cortex](https://en.wikipedia.org/wiki/Anterior_cingulate_cortex) of the brain, another part of the limbic system, that’s mental pain usually when you’re either socially excluded or you’re separated from a loved one
  - Now that’s something that’s evolved because you don’t want to be separated from your tribe
  - You don’t want to walk the frozen tundra and die alone
- But what happens, for example, in grief?
  - Grief is unremediated sadness
  - And the reason is because your brain is saying make this separation go away, and you can’t because the other person is permanently gone
  - And so the grief is just this pulsating activity in the dorsal anterior cingulate cortex of the brain saying “I must be reunited with that person but I can’t be”
  - In many cases it takes a lot of time for the dorsal anterior cingulate cortex to stop registering that sadness, that pain
- Peter adds, “*The sadness we feel when a person dies, which would be the ultimate form of separation, is a more extreme version of, say, a social isolation that you might feel, like what a kid feels if they go to sit at the cafeteria table and all the other kids get up and walk away.”*

**There are interesting studies that look at how grief registers in the brain**

- The brain is thrifty and the neuroscience of this is super interesting
- When you stub your toe, there’s actually two processes going
  - There’s sensory pain and affective pain
  - 1 – Sensory pain means you can feel it in the nerve endings and it’s very unpleasant
  - 2 – Affective pain is I hate this
  - And you feel both in physical pain
- The affective component involves the same part of the brain, the dorsal anterior cingulate cortex, when you have something that emotionally bothers you, when you’re being excluded
- We know that because there’s these interesting [studies](https://pubmed.ncbi.nlm.nih.gov/14551436/) in an fMRI machine, they’re looking at the part of the brain that’s illuminated
  - They’re being subjected to being rejected by somebody else, and they can see the part of the brain that’s actually illuminated

***Does the brain treat all pain the same?***

- Peter loves going into cold plunges (he does it almost every day), and it’s insanely uncomfortable
- He adds, “*There’s not a day that I step into that 42-degree ice bath with jets shooting water around me that I’m like, ‘This doesn’t hurt,’ but it doesn’t come with the ‘I hate this’ because I’m choosing to do it and I think there’s value in it.*”

*Does the brain treat that differently? How would we think of that as an emotion?*

- This is a controlled aversive emotion under your own power
- Another example is if you go to a haunted house on Halloween and get scared
  - You’re controlling the fear
- If you’re on a really radical amusement park ride, it’s the same thing
- You’re subjecting yourself to a little bit of the stress hormones and the experience of the aversive emotion, but since it’s under your own control, you actually use it in a way that you enjoy
- For example, people who do extreme sports, this is the same thing that they do
  - They like to feel a little bit in danger
  - One of Arthur’s kids is somebody who likes this ‒ he likes to expose himself to things that actually hurt, as long as he’s under control

**Is there any evidence that other species do this?**

- No
- This is a uniquely human phenomenon
- For example, there’s also no evidence that you can train any other species to appreciate spicy food, to ingest capsaicin
- This is a really higher order phenomenon where we have aversive emotions
- Other animals have aversive emotions, but we actually can dominate them through a process called [metacognition](https://en.wikipedia.org/wiki/Metacognition) where we experience the emotions not just in the limbic system of the brain but in the prefrontal cortex
  - This is the human difference is where this comes around
- For example, if the dog wants the cookie, it eats the cookie
  - Dogs are limbic creatures

**Limbic reaction versus making it metacognitive**

- Little kids are limbic, and when Arthur’s kids were little, they’d be screaming over something, there’s a piece of rice on their chair (whatever thing that bums them out), and you’re like, “*Use your words.*”
  - What you’re telling them to do is to experience the emotion in the prefrontal cortex of the brain where they can decide how to react
  - They can think about what their own emotions are
    - And when you’re doing that, then you can get in the cold plunge and say, “*It hurts so good*.”
    - That’s what metacognition brings to you
- Also, with metacognition you can say something like, “*I’m really sad about this. What am I learning?*”
  - That’s how you can be a far more evolved human being by becoming more and more metacognitive, using the techniques for doing so, which is a lot about what Arthur’s writing about these days

**What are the two positive emotions?**

- While pretty much all neuroscientist agree on the four negative emotions, they don’t all agree on the two positive
- The two that pretty much everybody agrees on are joy and interest
- Some people believe that surprise is a positive basic emotion
- **Joy** is obvious ‒ ordinarily, it’s when you’re reunited with somebody that you love or something good happens pursuant to struggle
  - The joy you get after you work really hard for something and you get it, that’s a basic positive emotion
  - It’s an evolved reward so that you work hard to find some berries on a bush and you get your caloric needs met for the day
  - That’s actually stimulating a part of the brain called the [ventral striatum](https://en.wikipedia.org/wiki/Striatum#Structure), which is your reward system, and, boom, that feels good; I want to do it again; do it again
- **Interest** is different: interest is you get intense pleasure
- For example, people are listening to *The Drive* (which Arthur does)
  - Why? Because he learns something from it
  - Why does he care? It’s not like it’s going to dramatically change his salary trajectory or his professional success if he does or doesn’t listen to the show
  - He wants to learn because learning is intensely pleasurable
- That’s really a fascinating phenomenon because that’s how people evolve and make progress, and it makes sense that that would be an evolutionary phenomenon
  - We would favor learning so that people can get ahead and feed themselves and find new sources of food and find new mates and all the things that they do
  - And the way that that’s adapted to the current environment is they listen to this show
- It seems to Peter that both joy and interest could be found in creatures other than us
- Learning would be a testable hypothesis, presumably with a maze or something like that
  - Whether the learning is positively valenced
  - You can teach a worm things
    - We just don’t know whether it’s a positive balanced experience because they don’t have the kind of brain that will give you emotions as we understand them
- Peter wonders if optogenetics would provide insight into that one day when you could get cellular level resolution of different parts of the brain
  - He’s thinking about [Karl Deisseroth’s](https://profiles.stanford.edu/karl-deisseroth) work [discussed in [episode #191](https://peterattiamd.com/karldeisseroth/)]

**We know that dogs have rudimentary emotions**

- They can mimic human emotions really well
- But it’s almost certainly a limbic phenomenon that looks metacognitive more than anything else
- And one of the things that we do is we selectively breed dogs so that their emotional state more clearly mimics our own
  - We like that
  - They make better companions
  - They do something they’re not supposed to do and they look guilty
    - They don’t feel guilty; that’s certainly an illusion
- Peter has a new puppy and can really relate to this
- There are certain ways that they are quite similar to us
  - For example, there’s a lot of research that suggests that they have serotonin balance issues, and if you give a dog a [selective serotonin re-uptake inhibitor (SSRI)](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor), it will actually have some of the same effects it can have on people
    - You can give your dog Prozac and your dog will be less depressed or at least have fewer depressive symptoms in some cases
    - So there are ways that they are similar to us for sure

## The evolution and heritability of happiness, and the four personality patterns with respect to positive and negative emotions [17:30]

**When you think about the arc of evolution, a purely Darwinian approach to our existence would be evolutionary fitness. Where does happiness fit into that?**

- This is a question that Arthur has thought about for a long, long time
- A lot of people assume that evolution would favor happiness, and the reason is basically this:
  - Evolution gives me a bunch of desires: desires for calories and interesting things and sexual partners
  - There’s certain things that I want, and one of the things that I want is those things, but also I want to be a happy person
  - So therefore evolution must favor happiness
- But that’s wrong, there’s no indication that mother nature cares about your happiness
  - She cares really about two things: survival and gene propagation
    - Mother nature wants you to survive and pass on your genes
- Does being happy help that?
  - Maybe and maybe not
- We find that [dark triad](https://en.wikipedia.org/wiki/Dark_triad) personalities, [malignant narcissists](https://en.wikipedia.org/wiki/Malignant_narcissism), they tend to be way unhappier than normal, and they’re extremely sexually attractive to the opposite sex
  - What’s up with that?
  - People are finding terrible mates that make them miserable, and they have extremely high levels of success in mating markets, and that militates against the idea that happiness would be evolved

***Arthur has become persuaded that happiness is the divine path versus the animal path, and it’s many times you need to stand up to mother nature’s imperatives so that you can be happy***

**What can we learn about the genetics of happiness?**

- The baseline levels of mood balance (which is not the same thing as happiness) is the extent to which you feel positive and negative emotions over the course of the day
  - This varies a lot between individuals.
  - There are four personality patterns with respect to positive and negative emotions over the course of your day, and they have to do with the intensity and the frequency of negative and positive emotions
    - There are four equal sized groups

![](https://peterattiamd.com/wp-content/uploads/2023/11/f1-PANAS-arthurbrooks2-1024x955.png)

**Figure 1. Four quadrants of the Positive and Negative Affect Schedule (PANAS).** Source: [arthurbrooks.com](https://arthurbrooks.com/hubfs/PANAS%20Lesson%20Plan-1.pdf)

- 1 – **Mad Scientist**: There are people who have extremely intense positive emotions and extremely intense negative emotions
  - Now, it doesn’t have to be extreme
    - In Arthur’s case, it is
  - It has to be above average to be in a quadrant called the **mad scientist** quadrant, and that’s a quarter of the population
  - They’re above average positive intensity and mood and above average negative
- 2 – **Cheerleaders**: There are some (and this is the one that everybody wants to be) who have above average positive and below average negative in intensity
  - These are the **cheerleaders**
  - That’s a quarter of the population
- 3 – **Poets**: There’s a quarter of the population that’s above average negative and below average positive
  - Those are the **poets**
  - These people are really interesting from a neuroscientific perspective
- 4 – **Judges**: There’s the low-low, people who are low affect people, people who have low intensity positive, low intensity negative
  - It doesn’t mean they’re not unhappy or happy
  - It means the intensity of their feelings puts them in that bottom quadrant
  - Those are the **judges**
  - Those are the unflappable people with enormously good judgment who don’t get freaked out about anything
  - That’s a quarter of the population
- You can take a quiz on [Arthur’s website](https://arthurbrooks.com/build) [scroll down to “Are you a cheerleader, poet, mad scientist, or judge”] to find out which category you’re in
  - They don’t keep the data
  - It’s just so people can know who they are to manage themselves

> “*A large part of who you are is genetic based on what we know about the basis of happiness”*‒ Arthur Brooks

**When we talk about the heritability of happiness, is it with respect to exactly that phenomenon as opposed to the definition of happiness that will get to (that you write about)?**

- Not exactly because we haven’t looked at identical twin studies with respect to those four quadrants
- The four quadrant testing is the positive affect, negative affect series, the [PANAS series](https://en.wikipedia.org/wiki/Positive_and_Negative_Affect_Schedule), which is very well scientifically validated, but we haven’t actually compared the identical twin data on nature versus nurture and personality with those data
- What the identical twin studies do is they look at the extent to which your mood balance, your self-evaluated general happiness scores are related to your parents and grandparents and the heritability
- In those studies is that they take identical twins that were separated at birth, adopted to separate families, and then they were reunited as adults and given personality tests
  - This was not a social science experiment cooked up by guys like me at Harvard
  - It happened naturally
  - They find that between 44-52% of your baseline self-evaluated wellbeing is evolved
    - Your mother literally made you unhappy
- Peter puts this in context, “*Obesity is probably 60% heritable. Height is much higher, one of the highest, probably 80-90% heritable*.”
  - Alcoholism is 50%
  - Autism, probably 80%
  - Depression, probably 60-70%

***Peter’s takeaway is your genes are not your destiny when it comes to happiness***

- Arthur clarifies, “*They play a role… you need to know your genetic proclivity because then you can manage it.*”
- He talks to a lot of people who both parents and all four grandparents drink too much
  - They’re not doomed to alcoholism because ***once you know your tendency, you manage your habits***
    - That’s where life really gets interesting
- This is the reason we need to manage our health so that we know where we are, what our tendencies are
  - There’s some people who have such incredibly good health, they need to go to the gym half as much as Arthur does, a quarter as much
    - They can eat all kinds of more junk than he can
- Arthur explains, **“*****Once I know what my tendencies are, then I know where to compensate on the basis of my habits, and that’s where knowledge about what you’ve inherited is true power.*****”**
- Peter guesses he’s a mad scientist and so is Arthur
  - Arthur agrees, “*I’m the maddest of the mad. I’m at the 95th percentile in positive and the 90th percentile in negative.*”
- Arthur asks Peter, “*It’s hard to be married to you, right?*”
  - Peter’s wife would say it’s impossible
  - Arthur’s wife reminded him as recently as yesterday that it’s not a walk in the park being married to him

## Navigating relationships: the power of complementarity over compatibility [23:30]

***What do we know about compatibility of those types in friendships and partnerships?***

- One of the biggest mistakes a lot of young people make is they are told that to find a good romantic partnership, you have to find maximum compatibility
  - That’s wrong

***You need a minimum baseline of compatibility, on top of which, you need complementarity***

- Back in the day, the matchmaker in your village would find somebody, same religion, they live in the same place
  - They’re both a match on physical attractiveness
- Now, let’s find one completing the other
  - This is one of the reasons that introverts and extroverts make very good marriage partners, typically
  - Two extroverts can be a real problem, at daggers drawn
    - They’re competing with each other all the time
  - Two introverts, typically there’s not enough conversation, not enough human connection
    - They’ll be isolated too much
    - What we find is they’ll drift apart
- When it comes to these personality profiles with respect to affect, you need to find somebody who completes you, but you have to appreciate differences
- So mad scientists do really well with judges because judges mellow them out
- Two mad scientists: it’s craziness, it’s a hurricane all the time because what will happen is you’ll get into a vortex of getting more and more spun up and then going all the way back down again
  - You can be an accelerant to each other, and that can be really a big problem

***So look for somebody different than you***

- The problem with dating is the platforms that people use
- You don’t meet somebody in a restaurant anymore
- Young people aren’t going to church very much
- So where do you meet? Online
  - And they curate their profiles to find somebody who’s like a sibling, which is (as Arthur’s adult kids remind him) not hot
- What’s “hot” is complementarity, is the adventure of somebody different than you, somebody that you’re discovering something
- You love somebody because of their differences, not despite their differences, and you can find a lot of that, and it’s especially productive when we come to these personality profiles

## The importance of self-managing your mental habits [25:30]

**What do you do with your knowledge base?**

*As a mad scientist, what are the tools you use to regulate your emotions and keep the balance more on the positive versus negative valence?*

- The reason Arthur has done this research is because he needs it, “*This is me-search.*”
- If you’re a mad scientist and you don’t self-manage, you’re going to be all over the place
  - You’re going to be a big mess
  - You’re going to have difficult relationships
  - A lot of the time, you’re going to be miserable, and it’s avoidable
- It’s actually unconstructive not to self-manage
- But self-management is not one weird trick as they like to say on the internet
  - There’s no hacks
- It’s really all about **mental habits**
- It starts with knowledge of the science
- It goes into specific practices, and then a lot of it has to do with teaching other people
- As you know, the best way for you to live better is to teach other people how to live better
- If you want to be healthy, start a health podcast or something and make sure you’ve got good science on your side

*When it comes to being a “mad scientist”…*

- The mad scientist profile that’s hard to manage otherwise, and the mistake that people get into is they try to stay on the positive side
- With bipolar disorder, we find that the biggest problem that they have is staying on their meds because they like the manic and they don’t like the depression, but they can’t time it
  - And by the way, Arthur is not saying that every mad scientist has bipolar disorder
  - He’s just saying that they tend to have mania
  - There’s a hypomanic edge, as [John Gartner](https://johngartner.com/) talks about, and that’s what most mad scientists have, a little bit of this
    - That’s why they tend to make pretty good entrepreneurs (like Peter), but they fall prey to a lot of mood issues that are pretty avoidable
- You actually have to stabilize your mood so that you’re not seeking the highs and trying to avoid the lows
- At the pro level of self-management in the mad scientist category is to not seek the highs because the highs don’t help you that much
- What you actually need to be is a full person, not riding the wave of your emotions
- You need to manage your emotions and never let them manage you

**That gets into the whole topic of metacognition**

- That is to experience your emotions in your prefrontal cortex as opposed to living according to your limbic system
  - Never be managed by your limbic system
    - Your limbic system is nothing more than the factory for your emotions
    - And if you’re basically taking raw factory materials and trying to live according to them as opposed to assembling them, making them into a set of experiences, learning from them, growing from them, you’re not fully alive
    - You’re subject to a crazy machine all the time
- A lot of what Arthur writes about is actually **how do you experience emotions more fully in the prefrontal cortex of your brain?**
  - What are the techniques for doing so?
  - And when you’re doing that, what is the repertoire of reactions and responses that you can bring to a highly volatile emotional state?

**Are there any folks where, for example, the poet (the great artists), where you actually push them to be more in that limbic system or is it the same for everyone because the poet is the one who’s disproportionately down?**

- There’s interesting research that doesn’t use the same [PANAS test](https://en.wikipedia.org/wiki/Positive_and_Negative_Affect_Schedule), but it’s pretty provocative nonetheless
- The people who have a tendency toward depression (not bipolar), they tend to be more creative, they’re ruminators, and they also tend to be romantics
  - This follows a pattern
  - You’ve met people like this that have this pattern of romantic, creative, depressive, poetic people
- Neuroscience research suggests that there’s a part of the brain that’s especially active for these people: it’s called the [ventrolateral prefrontal cortex](https://en.wikipedia.org/wiki/Ventrolateral_prefrontal_cortex), and this is the part of the brain that you use a lot when you’re ruminating on something, which depressive people do as they think about the thing
  - This is also what’s going on when you’re in love with somebody
    - You can’t stop thinking
    - You’re ruminating on another person
  - This is the same thing that’s going on when you’re working on a business plan or writing a symphony or actually writing a poem
- That’s what they’re really good at, but also what they’re really bad at
- They can’t stop thinking about things which is good for them and really bad for them
  - Their strength is their weakness

***This is the same thing across all the profiles: your strength is your weakness, your weakness is your strength. Learn to manage it: wire to the strengths, remediate the weaknesses, and complete yourself.***

- Arthur encourages everybody to be more metacognitive
  - So that if you’re a poet, you can be really, really poetic but it won’t ruin your life

**Do we think that the most extreme form of greatness that we’ve seen, the most genius type of phenomenon that we’ve seen as a species, always comes from extremes in these categories?**

- It’s almost certainly not true
- It’s sort of the caricature of what we think to be true
- And part of the reason is because those are the spectacular cases
  - You see somebody who’s unbelievably good at something and who’s weird, you focus on their weirdness
- There are tons of people who are extremely accomplished and not that weird
  - You don’t have to be weird
- It’s the thing where it’s like, I guess to be a great entrepreneur, you have to be the person that [Walter Isaacson](https://liberalarts.tulane.edu/departments/history/people/walter-isaacson) wants to write a biography about
  - If Walter Isaacson is writing your biography, get help
- There are tons of people, very successful entrepreneurs, artists, athletes, just people who excel, who have decent relationships, who are able to self moderate, and who don’t abuse drugs and alcohol
  - Now, a lot of them do, and part of the reason is because they have certain personality characteristics that go relatively unremediated
- And we have people who are highly limbic
  - They tend to be successful in spite of their messy mental hygiene, not because of their messy mental hygiene
- It’s even better if you’ve got some of these characteristics and you’re really creative and really hardworking and really driven and you manage it; that’s even better

## Enjoyment: one of the three macronutrients of happiness [32:00]

> “*Happiness is not a feeling. Feelings are evidence of happiness.*” —Arthur Brooks

- Arthur wrote about this in [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- Happiness is not a feeling (we’ve established that)
- Feelings are evidence of happiness

**Indirect ways to figure out how happy someone is**

- Arthur could ask your wife, “*How happy is Peter?*” when Peter’s not there and he would probably get some very accurate information
- There’s some tests, they’re not very good, but you could answer a series of targeted questions when you’re under fMRI
- But really the best way to do it, the most cost-effective and efficient way to do that is for you to anonymously answer a bunch of questions that are like this
  - Imagine all the people you know were the happiest person you’ve ever met, really happy, is 10, and the most miserable SOB you’ve ever met is a 1
  - All things considered at this period of your life, not this moment, this period of your life, all things considered, thinking of those people, what’s your number?
    - That turns out to be incredibly accurate
  - You’ve got to have a large sample because some people answer it in a wonky way
  - And it has to be anonymous because if you answer this in front of your wife, you’ll probably lie
    - People don’t tell the truth in front of their spouses necessarily, in front of their friends, because they give answers that people want to hear

**Based on these data, you find that the happiest people, they have three macronutrients in balance and abundance**

- Peter asks, “*Are those responses* [*normally distributed*](https://en.wikipedia.org/wiki/Normal_distribution)*?*”
  - Yes they are, but the mean is not 5, it’s more like 7.5
    - So there’s a bias toward the top part of the scale
    - Normally happy is about 7-8
- Most people over the course of their adult lives (early 20s to early 50s), they’re between 7-9
- Most of the executives that Arthur works with one-on-one who are 3’s, they’re depressed
  - They’re actually suffering from clinical issues
  - They’re behind the line of scrimmage
- There’s nobody who’s like, “*Yeah, I’m pretty normal. I’m probably at the 40th percentile. That probably makes me a three and a half*.”
- 40th percentile is probably a 5
  - They would like to be better, and they feel like they’re not as good as they should be
    - Despite the fact that in the scale that looks like the middle of the scale, but it’s not the middle
- The people who are in the upper end (8-9) and like Arthur’s wife (9.5), they tend to be really healthy, and healthy means they have balance and abundance across what Arthur often refers to as the “happiness macronutrients”
  - It’s very easy in this audience because everybody knows it’s protein, carbohydrates, and fat, and the best diets are those that have all of them in balance and abundance
    - You have to get your macros
    - You’re not going to have 100% protein

***The three happiness macronutrients are i) enjoyment, ii) satisfaction, and iii) meaning***

- By the way, none of those is straightforward any more than protein, carbohydrates, and fat is straightforward
- You have to have strategies to understand why they’re so hard to attain and what you need to do
  - Exercises to make sure that you can be better and more skillful at attaining each one

**Enjoyment**

- Enjoyment seems straightforward ‒ “I want to enjoy my life, get a lot of pleasure” – but that’s wrong
  - Pleasure is limbic
  - Enjoyment involves the prefrontal cortex
  - Enjoyment is a much more complex phenomenon than pleasure
  - Pleasure is a signal from the limbic system that says this thing that you’re doing will help you survive usually through caloric needs or passed on your genes through something like sex, nothing more
    - It’s just like any positive emotion, it sends a signal saying, “*Do more of this.*”
    - That’s not the secret of happiness
    - That’s incredibly evanescent; it’s extremely temporary
    - And if you pursue pleasure, what you’ll be doing is you’ll be engaging systems in your brain
    - The dopamine system, for example, which is the anticipation of reward, the reward being pleasure
    - You’ll hit the lever, get the cookie; hit the lever, get the cookie
    - It will never last, and you’ll become an addict

> “*Pleasure seeking, I mean, the hippie phenomenon, the hippie motto of ‘if it feels good, do it’ is life ruining advice*.”‒ Arthur Brooks

- If you only did what feels good, you’d never go into an ice bath
  - You wouldn’t stay married

***What you need for enjoyment: the source of pleasure, people, and memory***

- That’s where you’re engaging your prefrontal cortex
- So Anheuser-Busch *never* runs ads for beer of a dude alone in his apartment pounding a 12 pack
  - They never do that, right?
  - A lot of people use the product that way
  - Why don’t they show that?
  - Because that’s the pursuit of pleasure and that’s dangerous; that’s bad for you
- Use of methamphetamine is bad for you
- What we’re incredibly good at using science today is to take things that give a little bit of pleasure evolutionarily and supercharge them
  - Natural endorphins that you get that will block pain under normal circumstances, we can supercharge them in a lab and make fentanyl and 100,000 people died last year

***That pursuit of that pleasure is utterly ruinous***

- We look at a random series of events, and when it’s random, we get payoffs a little bit
  - We’ll seek those events, and that gives us a little bit of pleasure
  - We turn that into slot machines in Vegas, and then you’re sitting there at 4:00 AM by yourself
    - Really, really bad for you

***That’s the problem: seeking pleasure alone, not making memories, will make you miserable***

- Usually if something gives you pleasure and you’re doing it alone, you’re usually doing it wrong
  - Pornography is a problem
    - It uses the sexual function in a way that leads to addiction and huge problems in people’s lives
    - It’s contraindicated
    - It’s not good for especially young people to use that, but that’s the same thing as fentanyl in this way

***Okay, so what do you do? You make sure you’re with people, especially the people you love, and you’re making memories***

- That’s why Anheuser-Busch’s ads have two dudes or 10 dudes or a family cracking open a Bud and drinking it and laughing
  - Because in the ad they want you to associate the beer with happiness, which is *enjoyment* is the central factor, *not the pleasure* that the little bit of alcohol will bring you, and that’s what we need to do (that’s the strategy)
- Peter and his team are working on a very in-depth newsletter on the conflicting data on alcohol (specifically around wine)
  - Why is it that at a biochemical level and certainly looking at the Mendelian randomizations, alcohol is toxic at any dose and it’s a monotonically increasing function, so there’s no amount of alcohol that is healthy
  - Yet the epidemiology is pretty significantly in favor of modest drinking over abstinence
  - And once you even strip out all of the obvious confounders that would lead to that, you’re left with the phenomenon you describe, which is if you dig into the data really deeply, it’s the *Mediterranean drinking pattern* that seems to be associated with some benefits at low doses
    - People and memory, not the alcohol per se
    - The food and the wine and the people combo that seems to be beneficial, not the vodka and Red Bull in the dorm issue
    - Even though it’s the same molecule, it’s a very different experience
- Processed sugar is the same thing: you find the people who eat candy one to three times a month on average live a year longer than people who abstain completely from candy
  - Candy’s terrible for you: it rots your teeth, it leads a metabolic syndrome
  - Eating candy one to three times a day is very different than eating it one to three times a month
- And so the whole point is you do something that you enjoy
  - It’s something that gives you a little bit of pleasure, which something really sweet does because of our evolution
  - Something that gives you a little bit of euphoria, like alcohol, it makes you feel good
  - But you do it with people and you make a memory
    - Unless all your friends are drunks, which is bad

***You can use a little bit of poison in a productive way, but it has to be about enjoyment, never about pleasure per se***

- Arthur wishes he had this information when he was in his twenties (not 59)
  - It would have saved him a lot of grief
  - All that time he wasted with drinking, with unproductive activity
  - And the way he missed opportunities to love and be loved and to have a happier life

> “*This is really, really news that people can use*”‒ Arthur Brooks

- Peter adds, “*This is probably one of the stronger arguments against evolution being in favor of happiness. It’s clear that evolution is in favor of pleasure. Pleasure might be one of the most potent fuels that drives the engine of evolution, at least when it comes to reproduction, but certainly other aspects of evolution as well.*”
- But **enjoyment** is a higher order process and Peter guesses it would not necessarily have the same evolutionary drive, although he supposes being with people obviously also has a strong evolutionary bent if for no other reason than we couldn’t have survived alone even through the industrialization of agriculture
- Arthur explains, “***The problem is the maladaptation that comes with technological progress is that you can strip off the component of enjoyment that is pleasure and then supercharge it in the lab. That’s the problem***.”
  - The internet makes it possible to do that
  - Chemistry makes it easy to do that
  - There are all kinds of ways that we strip out that component of enjoyment, so it’s no longer part of the evolved societies that would’ve been more traditional
- Peter asks about the person listening who loves to smoke and says, “*Guys, I enjoy smoking, I really enjoy it*,” is this really pleasure (if you’re doing it by yourself)?
  - That’s right
  - Arthur’s wife smokes two times a year when she’s with her sister in Barcelona
    - She loves her sister
    - Her sister smokes only after meals, only with people maybe once or twice a day (which by the way is too much)
    - Suffice it to say that any amount of tobacco and any amount of smoke in your lungs is not good for you
    - His wife is not a smoker
  - Arthur used to be a smoker, but now he doesn’t touch it
    - Not even twice a year
    - He doesn’t want that monkey on his back
    - He so thoroughly stripped the pleasure from tobacco off from the enjoyment of communally smoking that he can’t handle it anymore
    - Part of that is his mad scientist
- Enjoyment is complicated, and that’s why the knowledge is so critically important
  - That’s why happiness is serious business

## Satisfaction: one of the three macronutrients of happiness [43:45]

***What is satisfaction?***

- Satisfaction is the joy after struggle
  - If students cheat to get an A on an exam, there’s no satisfaction
  - But if they actually struggle for it and they study for it, they get a ton of satisfaction when they get an A, because that’s how we’re wired

***Again, this comes back to the evolutionary psychology, even biology, is that you go looking hard for something and you get it, you want that to be reinforced as a good thing to do***

- That’s why Mother Nature really wants that to happen, and that’s why we have that evolutionary imperative

**Here’s this little twist that Mother Nature throws into it**

- If you knew that that satisfaction (that joy) wasn’t going to last, you’d think twice before going through the struggle
  - You’d think twice about the cost benefit analysis
  - If you said to yourself, “*I like that watch. It’s a nice watch,*” I don’t know what kind of watch that is
    - That’s a Seamaster or something, right?
    - It says GMT; it’s a nice watch
  - But if you’d thought to yourself, “*It’s a pretty expensive watch. I’m going to really, really like it for a week,*” you’d think twice about it
  - This is a trivial example, but there’s all kinds of things that we do
    - That relationship, that conquest, that business plan, that fill in the blanks
    - “*I’m not going to enjoy it for very long*.”

***Mother Nature shields you from that truth; you have to have it wear off quickly because you wouldn’t be ready for the next thing***

- If you’re a caveman and you’re looking for calories and you find berries on a bush after a long hike, that’s incredibly satisfying
  - That gives you a bunch of joy
  - But if you sat there enjoying them for the next week, you’d be a saber-toothed tiger’s dinner

***You have to be ready for the next set of emotions. That’s homeostasis. You go back to the baseline, physical baseline, emotional baseline (you always go back)***

> “*But if you realize that, you won’t make the effort in the first place.*”‒ Arthur Brooks

- So Mother Nature tantalizes you with the joy that’s going to come after the struggle and then veils the knowledge that you’re not going to enjoy it forever
- For example, people actually think, “*If I move to California, I’m going to be happy for the rest of my life because of the sunshine.*”
  - Arthur has the data: it’s a few months
  - The taxes are forever
- Arthur sees this constantly with people
  - His students think they’re going to be happier at 38 than 28, which is generally not true
    - Generally your happiness is lower at 38 than it is at 28, and lower at 48 than it was at 38
    - The reason they get it exactly upside down, is because they think that they’re going to get things they want and they’re going to be satisfied forever with them
    - When they get married, they’ll be permanently happier

**Have you been able to quantify the length of satisfaction, the duration of satisfaction when they get admitted to Harvard Business School (before they matriculate)?**

- Oh yeah
- There are interesting studies that ask this question, when you get a bonus at your job, when do you enjoy it the most?
  - When it hits your check or the day you find out?
  - It’s a question that answers itself
  - You go home because your boss says, “*You’re the linchpin in this company. What a great job you’re doing, 40% bonus*.”
  - You don’t have the dollars, but you go home and open a bottle of champagne with your spouse
    - You earned it; it’s great
  - Three weeks later, it shows up in your check and you’re like, “*Huh, yeah. Yeah, good. Good. I can do something with that.*”
  - But that’s not where the real satisfaction happens because of the **homeostasis**
  - Now, the fact that that surprises you leads to deeply **suboptimal behavior**
    - If you keep getting surprised again and again and again and again, the satisfaction doesn’t last
    - Natural conclusion is that you just needed more; it just wasn’t enough
    - So go get more and more and more, and this leads to this chase, what we call it in Arthur’s business the “**hedonic treadmill**”
- Hedonic means feelings, and the treadmill is you’re running, running, running, running to keep, maintain, and to get more of certain feelings, and you never figure out that you’re on a treadmill and not making progress
- The homeostasis is that you catch up immediately
  - You get ahead by two inches and immediately it starts running you backwards
  - Unless you keep running, running, running, running, then you’re going to be going the wrong direction, and that’s terrifying and terrible

***So people not figuring out Mother Nature’s cruel little hoax, they wind up on the hedonic treadmill of more, more, more, more, more, have more***

**Why are we fooled by this?**

- We’re born to be fools when it comes to this satisfaction problem

**Peter’s takeaway** ‒ “*This is actually one of the macronutrients where it seems that evolution is fully engaged. Clearly, evolution favors pleasure over enjoyment, but evolution is all for satisfaction… and all for fooling you into believing this is the one that’s going to be the eternal satisfaction*.”

- Arthur agrees, “*That’s the animal path.*”
- But there is a glitch in that matrix that we can exploit if we’re willing to stand up to our natural impulses
- This is where every philosophical and religious tradition comes in
- According to the First Noble Truth of Buddhism, life is **suffering**
  - That doesn’t mean life has to be suffering
  - It means life is naturally suffering

***What the Buddhists are saying is that left to your devices, you’re going to suffer***

- And the word for suffering in that First Noble Truth of Buddhism is mistranslated
  - The word in Sanskrit is dukkha, and dukkha actually means dissatisfaction
  - The First Noble Truth of Buddhism is that life is unsatisfying because of the hedonic treadmill, because of homeostasis
- And how do you get beyond that?
  - You recognize that the reason for your dissatisfaction ‒ this is the second truth
- The Second Noble truth is **attachment**
- The Third Noble Truth is that you need to **detach**
- And the Fourth Noble Truth is the [**Eightfold Path**](https://en.wikipedia.org/wiki/Noble_Eightfold_Path), which is entirely contrary to nature
  - The Eightfold Path is not natural, and that’s why it’s hard
- Here’s the way to think about it:
  - Mother Nature says satisfaction will come and stay if you have more, more, more
  - What’s your life strategy? More. More money. More power. More pleasure. More admiration. More Instagram followers. More.
  - Actually the right mode, a model that better satisfies, that gives you more satisfaction that lasts is: **haves divided by wants**
    - All the things you have divided by all the things that you want
    - And this is basically kind of what the Eightfold Path of Buddhism comes into (this is a baby version)
    - Arthur apologizes to the Buddhists who are listening to us
  - The **Eightfold Path** says you don’t need to have more strategy, you need to want less strategy ‒ you need to want less

***We need to manage our wants in this life, and in so doing, then satisfaction hangs around***

- That’s what the Dalai Lama always says, “*You shouldn’t have what you want, you should want what you have*,” really which is another way of talking about this

## The reverse bucket list, metacognition, and other techniques to protect yourself from your limbic system [51:00]

**There are all kinds of techniques, of visualizations to do this**

- Because Arthur has an arts background: he was a professional musician for many years and his mother was a painter
  - We have a tendency to think of our lives that we’re building, especially the hustlers, the go-getters, the strivers who listen to you
  - That your life is like a beautiful painting and you’re the artist with a brush, and that canvas is your life, and you’re putting the brushstrokes on the canvas
- The problem is by the time you’re 45 and you’re a striver, that canvas is full
  - Arthur defies people that add another brushstroke
- You need to use the metaphor that your life is actually a sculpture, that you’re **chipping away**, that you are in there, but there’s too much stuff stuck to you
  - You need less, less, less
  - You want less, strip away the detritus, get out the chisel
    - Because this has to be practical
- Here’s the exercise Arthur gives his students: the way for them to be successful is through the visualization and manifestation that comes from having a **bucket list**
  - On your birthday you list all your ambitions and all your desires and your cravings, and you imagine yourself getting all these things (this is the visualization)
    - That’s a good way to blow up the denominator of your satisfaction equation and feel like a complete loser
  - You need a **reverse bucket list** where you make a list of all of your worldly attachments and you cross them out
    - Not that you won’t get them, but that now they’re not limbic
    - Now they’re in your prefrontal cortex
    - Now that you can actually manage those cravings in an entirely different way
  - And this absolutely works
  - Arthur does this on his birthday every year now

**Using the “reverse bucket list” technique**:

- For example, on his last birthday, Arthur thought, “*What are my attachments that are holding me down?*”
  - He realized it was a lot of political opinions
- [Thích Nhất Hạnh](https://plumvillage.org/about/thich-nhat-hanh/biography) (the Vietnamese Buddhist monk who started the Plum Village Community of Western Buddhists) said that the greatest source of misery and attachment for most people is their opinions

***We’re so attached to our opinions; it’s like we’re hoarding our gold***

- And if you get between me and my opinions, you’re stupid and evil
- Arthur thought to himself, “*My political opinions are too strong. I’m too attached to them*.”
- So he wrote down about half of his political opinions
  - He still has them, but he crossed them out which negated their importance, their moral importance in his life
- He need fewer opinions because what it really comes down to is he needs more friends
- Now he’s way lighter, way freer

**How does the exercise of acknowledging the opinions and crossing them out, how does that translate?**

- For instance, we sit here today on the heels of a tragedy that took place very recently, a terrorist attack, and it’s a very dividing event politically
- Even though Peter is not a political person, he doesn’t talk about his political views publicly, he has very strong views
  - And as a result of that, he’s prone to be very judgemental of those who hold opposing views
  - There are certain views where he is all about nuance, and there’s some views where it is black and white

*How would that exercise help in this situation?*

- This gets back to metacognition
- **Metacognition** is not being limbic, but rather experiencing emotions and emotional phenomena in the prefrontal cortex of the brain, where you can make conscious executive decisions
  - It’s letting your CEO do it as opposed to the kids do it
- And so what you do is when you have a strong volatile political opinion (which is not just terrorism is bad)
  - It’s that anybody who disagrees with me about this particular situation is a moron, that’s what goes on the list

***What you do is you cross that out, not because you don’t think that, but because you’re willing to consider that***

- You’re willing to let your CEO think about that as opposed to axiomatically assuming that
- It’s no longer a limbic opinion where you see something on TV and you get a sense of revulsion, where your insular cortex engages because you have a sense of disgust on the contrary
- Peter asks, “*Do you think that that’s a better strategy than my strategy, which is to tune all of that out, is to basically say, ‘I’m going to do something that feels cowardly,’ which is I’m not going to engage in any of this by reading any of it, by watching any of it, by participating? I’m going to focus on what I do best. I’m going to do my job and not become a spectator.*”
- There’s a lot to that because you should specialize in what you can do well
  - You should focus on the things you can control as opposed to the things that you can’t
  - These are two different phenomenon
- Peter points out, “*You could argue my strategy is a dangerous strategy from a societal perspective because then if everybody took that approach, nobody would do anything.*”
  - Arthur agrees
  - You wouldn’t have any collective action, and everybody would be ignorant for sure

**What you’re trying to do is protect yourself from your limbic system when you block out information**

- This is basically: I don’t like the news, so I’m going to cancel the newspaper
- You shouldn’t be afraid of information, and that’s all your limbic system is delivering to is information
- You should learn how to use information
- Ideally, what you do is metacognitively you process the information and make decisions on how to use the information
  - Sometimes that’s not efficient
  - Sometimes that’s suboptimal because you don’t have time to do it

**Arthur has found that he uses a combination of the two techniques**

- He was president of a [think tank](https://en.wikipedia.org/wiki/American_Enterprise_Institute) in Washington, DC for almost 11 years
  - He was so aware all the time of what everything everybody was saying and doing; he knew what was going on
    - He knew if there was going to be a budget resolution
    - He could tell you what was going on with a farm bill, the whole deal
- Now he knows a lot less, and the reason is he rations his access to news
  - He reads a total of 15-30 minutes of news per day all at once
- He needs more bandwidth for his work, and he doesn’t  want it to intrude on his work
  - But he’s not afraid of his limbic system
- He’s not afraid of what this information will actually do to him because he’s working metacognitively to make sure that when he does have this information, he can process it in executive ways as opposed to childlike ways
  - It’s no longer “ghosts in the machine”
- Arthur has a repertoire of ways he can deal with it
  - He can choose his reactions to his emotions
  - He can use substitute emotions
  - He can act as if he had different emotions, and he can disregard his emotions
  - But all of that is on purpose, and those are the fruits of metacognition

## Meaning: one of the three macronutrients of happiness [57:30]

**The third macronutrient (a sense of purpose, meaning) extends far beyond “work”**

- Arthur explains, “*Meaning is the most important because it’s the protein. You’ll die.*”
  - You can vary the carbs and fat a lot, but you can’t mess with protein too much
  - It’s a basic building block and you’re in big, big trouble when you become protein deprived, because there’s no other way to get it
  - It’s not like your carbs are going to transform into proteins
- And everybody knows when they don’t have a sense of meaning because their life is empty
- They’re the most miserable when they don’t have a sense of meaning, but nobody knows exactly what it is

***Philosophers and psychologists define meaning as a combination of three things: coherence, purpose, and significance***

- 1 – **Coherence** is things happen for a reason
  - That’s the first part of meaning
  - You believe that things happen for a particular reason
  - That doesn’t mean your way is the right way and it might be randomness
- Arthur’s father was a Ph.D. biostatistician, also very religious, and he used to say that the greatest miracle in the world was randomness
  - That God built the universe with randomness and regular distributions of events
  - He thought that miracles were extreme tale events in random distributions, and God loved randomness
- In other words, there’s lots and lots of different ways to understand why things are coherent
- 2 – The second is **purpose**, which is direction
  - Your life has direction
- There’s a word called the [rhumb line](https://en.wikipedia.org/wiki/Rhumb_line), and it means the end point toward which your voyage is tending
  - You’re not going to get there and you’re going to vary from it, but you have to have a north star (something you’re navigating to)
- 3 – The last is **significance**: it would matter if you weren’t alive

**These are worth thinking about in detail in our lives**

- Arthur has a diagnostic test to see if somebody has a meaning crisis; it’s a two question exam
  - And if somebody doesn’t have real answers…
  - Everybody’s got PC answers, answers you give your mom or whatever
- The reason this is useful is these are the two questions to go looking for answers to in your life

> “*This is your vision quest is to find the answers to these by reading, by experiencing, by meditating, by spending time by yourself, by praying, by asking people’s advice, by therapy (I don’t know, do your thing).*”‒ Arthur Brooks

- 1 – Question number one is, why are you alive?
  - You got to have an answer, your answer, a real answer
- 2 – Question number two is, for what are you willing to die today?
- You flunk this quiz by saying, “*I don’t know*.”
- The adventure actually begins after you flunk the quiz because it’s like, “*I’m going to figure that out. I’m going to go find those answers. I’m going to read. I’m going to consider. I’m going to do all the things that you do metacognitively to find the answers to these questions.*”
- Peter thinks there are probably a lot of people who cannot answer #1, who can answer #1; or who can answer #1, but can’t answer #2
  - I’m alive because of some biological process, etc.
  - But #2 is I don’t know what I’m willing to die for
- Arthur clarifies, “*Are you asking #1 through the lens of biology?*”
- Peter thinks it depends on how  you answer it and what actually give you meaning
  - A spiritual person or a religious person would have a divine response to the first question
  - An atheist would respond to the first question in terms of biology
    - Arthur thinks they would really understand
    - That biological answer could give you a tremendous sense of meaning and a sense of place in the universe
- Peter adds, “*Although it’s interesting because as someone who leans far more towards the agnostic atheist side, I spend most of my time coming to grips with mortality, which is a very difficult thing to come to grips with.*”
  - Which is question #2
  - He comes to grips with that by addressing Arthur’s third point around sense of purpose, which is his insignificance
    - In other words, it’s only through accepting his complete and utter insignificance that he can have some semblance of peace with my finitude and my eventual and relatively quick demise
- Arthur agrees, “*This is one of the reasons that* ***transcendence*** *is one of the happiness practices*”
  - The practice of transcendence, whether it’s secular or religious transcendence is really important because it makes you small
    - You stand in awe of a sunset
    - You stand in awe of seeing somebody committing an unbelievably selfless act

***Transcendence makes you actually feel smaller, which gives you peace through a sense of perspective***

- One of the people who works in Arthur’s area, [Dacher Keltner](https://psychology.berkeley.edu/people/dacher-keltner) at UC Berkeley, has a book called [*Awe*](https://www.amazon.com/Awe-Science-Everyday-Wonder-Transform/dp/1984879685/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) that talks about the neurocognitive processes involved when you’re experiencing awe, and why it gives you such deep peace
  - And it’s really all about what you’re talking about: you got to get small
  - If you can find ways to get small, you’re going to be a lot better off, for sure

**How do we reconcile that with the need to have significance through your sense of purpose?**

- The key is at the same time you realize that you matter, but at the same time, it’s okay that the universe will be just fine if you die
- They seem like conflicting phenomenon, but they’re actually weirdly compatible
  - It matters that I exist here, and things will be just fine if I don’t
- You think about this when you get married for the first time
  - You say, “*You love me, and if I’m gone, you’ll be okay.”*
- It’s this sense of peace, that balance between those two things turns out to be the trick
- Peter reacts, “*I’ve never been able to find that.*”
  - Arthur hasn’t found it either for sure, but he thinks practice makes perfect
- The way to think about this and the way to find the answers to the questions is really interesting

**Arthur has worked on this with his kids**

- He has adult kids
- His 23-year-old (Carlos), he’s a piece of work; like Peter, he’s human performance machine
  - He’s a scout sniper in the US Marine Corps
  - 204, 4% body fat, 6’5”
- Carlos didn’t have the answers to that because many young adults don’t
- But he found the answers to that as he did something that was truly difficult
  - Going through marine basic training and then infantry training battalion, and then doing the Indoc to become an operator in the Marines, in the scout sniper platoon
    - That stuff’s no joke, it’s hard
- If you ask him the question now, why are you alive? He’d simply say, “*Because God made me to serve.*”
  - That is both the how and the why of question #1
- Question #2: for what are you willing to die?
  - Very simple: for his faith, his family, his fellow Marines, and for the United States of America and our allies
- These are very solid answers
  - These are not the right answers for somebody listening, or you, or me necessarily, but they are answers that he actually believes, and that’s what gives him his sense of meaning

***Finding what we really do think about those things; what really is persuasive to us is a philosophical, and for some, a theological journey really worth taking***

## The four quarters of your life and how that relates to the meaning of your life [1:05:00]

- It’s definitely something Peter has spent much more time thinking about in the past year than any time before
- Arthur explains that people usually think about this around age 50
- In ancient [Vedic](https://en.wikipedia.org/wiki/Vedas) physics, the theory of the four quarters of life, we think about kid and adult and all that
  - Last time Arthur and Peter talked they touched on this when they were talking about Arthur’s last book [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) [[episode #226](https://peterattiamd.com/arthurbrooks/)]
- According to this ancient Hindu thinking, you’ve got **(1) Brahmacharya**, which is your student phase, the first quarter of your life
  - 2 – The second quarter of your life is called **Gṛhastha**, which is the householder phase where you’re hustling and you’re starting your family and your work
  - 3 – The third quarter, going in from the second to the third is the second adolescence, into something called **Vanaprastha**, which means these two Sanskrit words, “*To retire into the forest.*”
    - And it’s supposed to happen around age 50
    - What happens is that certain things fade, and other things become more salient to you
    - More transcendental things start to become more important to you
- Part of this change around age 50 has to do with the change in your brain, change in your strengths, the change in your crystallized intelligence
  - These are real phenomena that neuroscientists have identified, and social psychologists as well
- But as a spiritual matter it means, “*What is my retirement into the forest?*”
  - What does that actually mean?
  - Certain things are more important to me than they used to be
  - These are important questions, not because you’re going to die, but because you just want to know
- A lot of people wind up coming back to the faith of their youth when this happens, a lot of people will develop a meditation practice
- Some people will find that they will get deeply, deeply into fitness in ways they hadn’t before, and doing things that are super hard for them, that challenge them as human beings
- Some people will change careers, do something that they’ve always wanted to do, but something that has more artistic significance, more creative significance than it had before.
- All of that is this Vanaprastha
- 4 – And the whole point of that is to get to the fourth quarter, which is called **Sannyasa**, and that’s enlightenment
  - To sit at the feet of the guru and to bask in the glow of the master is kind of how the Hindus will talk about it
  - But you got to do the work to get there

***You got to ask the questions and be on the quest, and that’s your third quarter around age 50***

**Do you think that each of these quarters don’t necessarily reflect equal chunks of time on the calendar, but do you think that they require an emphasis on different elements of those three macronutrients of happiness?**

- Arthur does
- This is mixing neuroscience plus social psychology plus Vedic wisdom, and Arthur adds, “*This is where no man has gone before*.”
- Arthur has asked this to some of his teachers
  - He goes to India every year and studies with various gurus and spiritual teachers, which is outside of his tradition
    - He’s a Catholic, but it makes him a better Catholic, and it makes him a better social scientist too
  - He asked his teacher in Palakkad (which is in southern India), a Tamil guy named Nochur Venkataraman, about precisely these sets of questions
- He said that people pass through these phases depending on how adroit they are spiritually at different periods of time
- But you have to do all the learning from each one
  - You need to be a student, you need to develop your life
  - Then you need to retire into the forest and contemplate these questions such that you can get to the ultimate destination, which is this period of enlightenment in your life
  - And in so doing, you need to develop these different parts of your life
- You can’t do this without the love that you share with other people, which is inherently enjoyable
- You can’t do this without achieving certain things and understanding that your life requires a certain amount of satisfaction, and that has achievement, that has earned success involved in it
- And of course, you can’t do that without understanding what meaning is to you, and what the meaning of your life really is

## Putting metacognition into practice [1:09:00]

**Four techniques associated with metacognition**

- This is an artificial distinction between them
- What you’re trying to do is get space
- When your grandmother said, “*You’re angry, count to 10,*” the research suggests, by the way, count to 30 when you’re angry

***And while you’re counting to 30, envision the consequences of what you’re thinking of doing, and then you’ll be fully metacognitive; then you will be processing the information in the prefrontal cortex of your brain***

- So that was really good advice from grandma
- To put a finer point on it: what you want is space between your limbic system and your premotor cortex
  - You want space so that your executive brain can experience emotions and deal with them appropriately

***If you don’t give it space, you’ll be reactive, and your limbic system will manage you***

- That’s the problem that a lot of people have in life
  - It’s like, I’m sad, I cry, I’m angry, I yell, I’m happy, I laugh, whatever it happens to be
  - That’s no way to live
  - Then the kids are in charge of the family budget (big problem, big problem)
  - That kind of spontaneity comes at an enormous cost

**How do you put space in it**

- Therapy is a good way for some people
  - It’s not Arthur’s thing
  - People can learn about their emotions this way
  - [Cognitive behavioral therapy (CBT)](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy) is super useful for a lot of people
- Meditation can do that; because most meditation techniques that will require that you analyze yourself at a certain remove
  - For example: Peter’s feeling sad right now; how interesting that Peter is feeling sad
    - It’s just information; just analyzing information; being a scientist about yourself
- Prayer is really good for this
  - Why? Because you’re bringing in a higher power to help you manage these things, and in so doing, you’re experiencing them very consciously in the executive, the bumper of tissue right behind your forehead
    - That’s where you want it to reside
- Some people do this through intensive exposure to nature, walking before dawn for an hour without devices
- Some people will do this indirectly by, I don’t know, studying the fugues of Johann Sebastian Bach and learning how to analyze them

***Whatever it happens to be, one way or the other, you don’t want the limbic system in charge***

**Just to be clear, you feel this can be done without a mindfulness-based meditation practice?**

- Peter points out that such a practice is a potent exercise to distance self from thought
- Arthur replies, “*Exactly right*”
- For example, one of the most effective ways to do this that has nothing to do with meditation at all is **journaling**
- A lot of people suffer from anxiety
  - **Anxiety** is basically unfocused fear; it’s a bombardment of stress hormones having to do with the fact that there’s a pervasive sense of doom that’s undefined
    - Undefined fear, unfocused fear
- There are a lot of ways you can treat anxiety: you can take pharmaceuticals, benzodiazepines that will mute the stress response etc.

***But the whole point of metacognition and journaling, when it comes to anxiety, is that you force your prefrontal cortex to take over by writing down the five things you’re most afraid of right now***

- It’s like, “*I’m freaking out, man. I’m freaking out. My heart is fluttering, I’ve got the butterflies in my stomach. I can’t sleep, or I wake up too early, I don’t know what’s going on. It’s like I’m feeling like I’m under threat*.”
- Okay, get out the pad and paper
  - #1 What am I actually afraid of ;#2 What am I actually afraid of?
- It’s not perfect, but this as a strategic technique will work miracles in your life if you consistently **journal about your emotions**
  - And then by the way, throw it away afterward because you don’t want everybody in your family to find it, because who knows?
    - Maybe you’re thinking forbidden thoughts or have forbidden fears
- **Anxiety** is a maladapted kind of fear
  - “*I’m doomed*,” is not the way cavemen were supposed to feel fear
- Fear is so that you can run away from a tiger
  - Fear is supposed to be extremely episodic
  - Our forebearers were mostly hanging out all day, and then occasionally something bad would happen and they’d have to run really fast and climb a tree, and that’s what fear is for
- For our forebearers, it was 99% fellowship, hanging out with your friends/ tribe, and 1% extreme panic
- Some anthropologists think that the quality of life has dramatically fallen in the modern era
- One of the components of modern life is this generalized anxiety where we’re processings outside stimuli as minor threats
  - So we get a little drip of cortisol into our system constantly, constantly, constantly, and it’s really unfocused

***So focus it, write down the five things, and they suddenly will feel a lot less threatening, and they’ll be more bounded, and they’ll be determined in a way where you can actually deal with them and start getting some solutions as opposed to just feeling afraid***

- That’s an example of non-mindful meditation, metacognition, as simple as a pad and paper

**What about this idea of journaling positive experiences as kind of a database?**

- Arthur likes doing that, but what he likes doing better is journaling negative experiences and learning from them
- Peter asks, “*Does that mean learning from them, or finding meaning in them, or are those the same thing?*“

**Here’s a way to journal negative experiences that can really, really change life a lot**

- Arthur asks his students to keep a failure and disappointment journal
  - When you’re 28, there’s one thing after another: she broke up with me, or she didn’t return my text, or that professor gave me a C on an exam, or the job market isn’t turning out the way I wanted it to
    - There’s something bugging you in a big way
- Every time, write it down, even if it’s stupid, write it down
  - Then leave two blank lines under under each entry
  - The first one you come back to after 30 days, set an alarm on your phone
    - Come back to it and you have to write, what did I learn about this thing in the last 30 days?
  - After six months, you get another alarm that says, go back to it and write down something good that happened as a result of that
- Now if we don’t do that, we won’t remember and we won’t grow on the basis of this
- For example, you’re at work and your boss says, “*Time for your performance evaluation*.”
  - And you’ve been killing it; you’re working hard, doing a good job
  - And your boss is like, “You’re a B around here,” and you’re crushed
  - So you write it down in your journal: I thought I was an A+, turns out my boss thinks I’m a B-
  - Your natural tendency is to say, “*I’m going to go out and drink with my friends and complain about my boss with my partner, and then make the discomfort go away. I want it to go away, make it go away.*”
    - That’s wrong
    - Write it down, 30 days you come back and you say to yourself, “*What did I learn?*”
    - You learned you weren’t as good a fit for this job as you thought
    - Also, you thought you were going to be bummed out about this for the rest of your life, and actually you were bummed out about it for like three days

***You learn from it because you write down the thing that you learned, and now it’s permanent, because you’ve committed it to your executive center***

- Six months later you come back and say, “*Given the fact that I wasn’t as good a fit as I thought, I went on the job market and I found a job for which I am a better fit, and I’m a lot happier*.”
- When you start doing this consistently, you’ll start looking forward to writing down things in your failure journal
  - This is alchemy, practically
  - You’ve converted the negative into the positive

> “*There’s no good or bad emotions, there’s only information.*”‒ Arthur Brooks

- You’ve treated the emotional information the way you’re supposed to: you’re learning from the data
- Arthur likes that a lot better than, “*I saw fluffy clouds today, and I’m really grateful for that*.”
  - Gratitude lists are great, but failure lists, that’s powerful, that’s actually even better for life

## What might explain the societal downdrift in happiness over the last few decades? [1:17:00]

**The difference between optimism and hope**

- People use these terms interchangeably
- There’s so much empathy and compassion, but they’re not the same
- In his class, Arthur always has a distinction between two things that seem the same
  - See what the distinction will do for our lives if we understand them
  - Optimism and hope are a classic case

***Optimism is nothing more than a sunny prediction***

- Everything’s going to be alright
  - Maybe yes, maybe not

***Hope is: no matter what happens, something can be done and I can do something about it***

- Hope is empowering
- You can be a very pessimistic but very hopeful person
- You can be an optimist who’s hopeless
  - I think things are going to be okay, thank God, because there’s nothing I can do
- Hope actually is tied to happiness, optimism generally is not
- You might be an optimist because you’re a happy person, but the optimism itself doesn’t make you happier

**What is the opposite of hope?**

- Despair is hopelessness: there’s nothing I can do (nothing can be done)
- That’s almost never true

**What is the root of that feeling or belief system?**

- Despair usually is an extreme form of disempowerment
- People get it from childhood trauma
- Some research suggests that the way that people are brought up can make them inherently hopeless
- But people actually can get into kind of a hopeless stance, and part of it is self-definition
- For example, we have a real tendency in our culture to want people to live on the basis of victimhood and grievance
  - A person’s identity will be, “*I’m a victim*,” and their identity will be grievance against the people who have power over them .
- Arthur gets it, there are people who have power over us, and there’s legitimate grievance, and people are victims

***But to identify as a victim is the recipe for hopelessness and despair***

**Why is that becoming more prevalent, or does it just seem that way?**

- It goes in waves
- What happens is we have an identity culture at this point
- One of the things that you typically find with especially-manipulative leaders is they will tell people that they can be virtuous on the basis of victimhood
  - That victimhood is inherently virtuous
  - Literally in the social science literature is called virtuous victimhood
  - And it’s incredibly disempowering for the followers
  - It’s incredibly manipulative and malignant on the part of leaders who are actually doing this
- And we’re in a period in our culture of polarization and hatred and contempt, where there’s a lot of that going around
- Peter thinks both sides have agency in this, just different flavors of it, and Arthur agrees
- You look at the most **manipulative leaders** and they have the characteristic (almost always) of what we call the [dark triad](https://en.wikipedia.org/wiki/Dark_triad) of personality
  - Which is a combination of [narcissism](https://en.wikipedia.org/wiki/Narcissism), [machiavellianism](https://en.wikipedia.org/wiki/Machiavellianism_(psychology)), and [psychopathy](https://en.wikipedia.org/wiki/Psychopathy)
  - That happens in 7% of the population, according to [Scott Barry Kaufman](https://scottbarrykaufman.com/), who has done the best work on the dark triad
- The trait psychopathy doesn’t mean you’re an ax murderer, it means you’re way less remorseful about your negative actions than people in the population
- If you’re narcissistic, machiavellianism and have trait psychopathy, you’re a dark triad
  - You’re most likely going to want to disempower people, create a movement of people who are relatively disempowered, because you want to manipulate people

**Do we see that more concentrated in politics?**

- Yes, right now in particular
- Politics is where we reward dark triads, and we’re rewarding dark triads on both sides of the political spectrum right now
- So it’s a war of dark triads, and their followers are being systematically disempowered into a climate of virtuous victimhood
- What’s the source of my virtue? The fact that I’m getting screwed is the source of my virtue

***Agree or disagree that that’s a hell of a way to run a country, but for sure this is why happiness in in decline***

**Where do we think we are on the long arc of happiness?**

- Peter is less optimistic that our ancestors were happy
- He thinks it’s hard for us to relate what they went through
- He has the feeling that most people would much prefer to be alive today than to have been alive 100 years ago, let alone 1,000 years ago, 10,000 years ago or 100,000 years ago
- On the one hand we all have this amazing good luck
  - There’s 8 billion people on the planet, 100 billion have already died
  - In the last 250,000 years 100 billion people have died
  - So how lucky are we that we were born right now?
- Arthur adds, “*Or you could say, it should be a lot better if I were born 200 years from now, perhaps. Who knows?*”
- There’s a sense of dread
- Peter thinks there is probably objective data on our happiness today relative to 10 years ago, 20 years ago, 30 years ago?

**If you go back to immediately following World War II, what has been the trajectory of happiness?**

- We have imperfect data on that
- We have really good data going back to the 1970s
  - That’s really when the [National Opinion Research Center](https://en.wikipedia.org/wiki/NORC_at_the_University_of_Chicago) started, through the general social survey, which is University of Chicago data, and this is the best data available
    - We can really trust it
    - That started to ask people about their self-evaluation of their life
- And you don’t want to look at it between countries because those comparisons are nonsense
  - Denmark is happier than Mexico ‒ it’s meaningless because they define happiness differently and they have different cultural beliefs
  - They also have different languages
    - In German happiness is luck
    - In middle English, the word for luck was hap, from which we actually get happiness
    - Whereas felicity, the idea of felicitousness in the romance languages has a completely different sense to it of what that means
    - Plus, for example, in Denmark, happiness is a lot about contentedness
    - There’s a word in Danish “[hygge](https://en.wikipedia.org/wiki/Hygge)”, which means the cozy conviviality in the presence of friends on a comfy couch (it’s like a paragraph)
    - Arthur doesn’t want hygge, he wants adventure; which is why his grandparents left Denmark and came to the United States, to start a farm
- You can look at the same group of people over time (that’s pretty legit), and what you find is that it was from the 1970s through the 1980s, happiness was pretty constant and pretty decent in the United States
  - And then it started to fall
- Peter finds this interesting because you could argue that the 70s was a pretty depressing time in the US
  - The 80s, maybe less so
- But Arthur is saying that happiness in the US was pretty consistent from the 70s-80s
- Around 1989/1990, happiness starts to decline

**There’s two phenomenon going on: there’s weather and climate for happiness**

- The climate is these little declines, one percentage point here in the percentage of people who say they’re very happy
  - A little increase in the percentage of people saying they’re not happy about their lives
  - Usually these are the three groups:, not too happy, somewhat happy, very happy
    - They’re just kind of closing in on each other a little bit
- Then there’s storms, there’s weather; and the big ones were around 2008

**What happened in the 90s? What led to the climate drift of the 90s?**

***In the 90s, the four habits of the happiest people all went into decline: faith, family, friendship, and work that serves other people***

- The attitudes we have toward our work all changed in the 1990s and the 2000s
- There was a secular decline in the number of people that were practicing faith
- A secular decline in the formation of families: getting married and having families
- A secular decline in the number of people who know you well
  - There was more and more loneliness and fewer intimate friendships that people had
- [Vivek Murthy](https://www.vivekmurthy.com/) (our surgeon general) has written a whole [book on loneliness](https://www.amazon.com/Together-Connection-Performance-Greater-Happiness/dp/0062913298/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1698431024&sr=8-1), and there’s a lot of speculation
- The UCLA data on loneliness, people using those data are always asking what it is

***Probably it has to do with the fact that people are more and more likely to move away from their families, and technological changes have made it so that we don’t have to be in person as much as we have been in the past***

**Was that even true in the early 90s?**

- Yea
- It was certainly true by the mid 1990s as Arthur was writing a lot of emails then

**Advantages of in-person experiences**

- We’re evolved to link to each other and experience intense pleasure when [oxytocin](https://en.wikipedia.org/wiki/Oxytocin) is produced endogenously in the brain from eye contact and touch
- So if we’re actually communicating with each other, not getting eye contact and touch, we’re going to get less of it
- That’s what happened where people say, I have fewer people who know me well
  - There’s more isolation in our communities that’s been happening
  - Or it’s been just drift
  - And people have fewer and fewer healthy ideas about their work
    - Such as, “*My work really serves other people*,” and we see this over the decades

**Why has that changed? Where has that changed?**

- Peter asks, “*Is that basically the change from a largely manufacturing sector to finance information technology?*”
- Arthur doesn’t know the answer
- He’s a real enthusiast for the free enterprise system
  - And his friends who are not, would blame the free enterprise system for making us into these incredible efficiency machines in the way that we do our work
    - Work is just less humane and less human

**Are we less tethered to a product?**

- That’s for sure, and we’re less tethered to a workplace too
- For example, Arthur’s dad worked for the same university for his whole career
  - 40 years teaching the same university, day in and day out
  - He didn’t like it a lot of times, complained about the dean, all the things that college professors do, but he knew his colleagues and he had students over to the house
- In contrast, Arthur has changed universities a bunch of times

**Why don’t we stay at one career?**

- Our culture tells us we need to move when it’s time to get a better deal
- We don’t lay down roots professionally, and that’s why we have less of a sense of bondedness in the workplace
  - Less of a sense that we have relationships that we’re serving in the workplace
  - And it’s not just efficiently producing a product
- Unhealthy changes in recent decades:
  - People have worse attitudes toward their work
  - They’re less likely to have close friends
  - They are less likely to form and cultivate families
  - And they’re less likely to practice faith
- Arthur summarizes, “*The climate changes. Then we get these bad storms*.”

**How big an impact was 9-11 on the American psyche?**

- Not that bad
- On the contrary, it was momentarily a blip, and then the [esprit de corps](https://en.wikipedia.org/wiki/Morale) that came about actually lifted happiness
  - That’s what often happens
  - No doubt, that would’ve been World War II if we had data then
- A big national threats that bring us together and raise our happiness
  - It’s not reliable data, but it suggests that during wartime, clinical depression falls by 75%
    - You can’t rely on the data because it is not a treatment and control experiment where half of the population got a war and the other half didn’t
  - This is longitudinal data and we’re doing the best that we can, but it is almost certainly the case that a collective threat brings us together, and that does not hurt our happiness

**What hurt our happiness occurred around 2008**

- Originally we all thought it was because of the financial crisis (that certainly didn’t help)
- It was the advent of social media
  - 2008 was when everybody adopted social media

***Social media has been catastrophic for American happiness, especially among young people, among young women***

- Data from [Jonathan Haidt](https://jonathanhaidt.com/) (at NYU, who Arthur has worked with for a long time) and [Jean Twenge](https://www.jeantwenge.com/) (who teaches at San Diego State University) show that this was just inflecting when different platforms [emerged], which lowered happiness in different ways
  - Twitter creates more hatred and contempt in our culture
  - Instagram creates social comparison, which is the thief of joy
  - TikTok, when you see ordinary people doing fun things, it makes you feel lonely
  - That was 2008

> “*They’re unhappiness machines. Obviously you can use them in a way that doesn’t denigrate your happiness, but most people don’t*.”‒ Arthur Brooks

**Then political contempt and polarization in the 2016 era**

- 1 in 6 Americans stops talking to a family member because of politics after the 2016 election, that’s the second storm

**The third storm was the coronavirus, when everybody went home, and nobody came back**

- Remote work, death for happiness
- 7% of the population actually gets happier because they’re introverts
  - Those are the cats, the rest of us are dogs
- It’s terrible that something pulled us apart like that and then we didn’t get back together
- At Arthur’s university, it’s like tumbleweeds going down the hall
  - He goes in at 3:00 in the afternoon to his office, and the lights are off because of the motion sensor
- People didn’t go back to work, and the result of that is we don’t congregate
- There’s still fear in some places
  - It’s not as bad as it was, but there are permanent changes
- Ordinarily you’ll see twice as many people say they’re very happy as not happy, but today that has flipped
  - Twice as many people today say they’re not happy, as very happy

***There’s a secular decline with periodic storms, periodic downdrafts in happiness***

## Taking charge of your happiness: discipline, transcendent experiences, and other deliberate actions for happiness [1:30:30]

- Thinking about some of those things, based on Peter’s personal experience, he would agree that social media usually does not produce a positive feeling (it’s usually negative)
- But if we’re going to put on our “metacognitive hats” and self-manage…
- And if we think of ourselves as capable of self-managing through difficulty—as opposed to moving to India and becoming a monk—and we still want to coexist in this world…

**…*****Then what are the steps we want to take to minimize the damage of these things and at the same time, sort of try to find this semblance of happiness?***

- The goal of Arthur’s work is greater happiness not perfect happiness (that’s not the goal, nor is it desirable)
- People say, “*I want to be happy*,” but they don’t because pure happiness would mean the eradication of your negative feelings and you’d be dead
  - You wouldn’t learn and grow
  - We got get back to the same problem with satisfaction

***Happiness is not a destination, it’s a direction, and we all want to get happier***

- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) calls it “happier-ness” ‒ that’s the goal
- To do that, you need information, and that’s why Arthur teaches you about the science of happiness
  - It’s a super interesting body of knowledge
  - Arthur writes about it every week

**Arthur’s advice** ***‒ Do the work to change your habits, and then you need to share it with other people so it becomes permanent in your consciousness***

- Arthur is dedicated to making an entire generation of happiness aficionados and teachers
  - He wants a movement of people who say, “*My hobby is learning about happiness. And in my job, I’m a happiness teacher.*”
  - And to do that, you have to know the facts on this

**There are certain things you need to protect yourself from and certain things you need to do**

- You need aversion and you need approach
- 1 – You need to take seriously your spiritual life

*For the non-religious person*

- Peter acknowledges that most people listening are not religious
- Many people would be confused by Arthur as scientist and serious intellectual guy describing himself as having a very strong religious faith
  - Yet he doesn’t have a difficult time reconciling science and faith
- Arthur explains, “*Faith and reason have to coexist in the same way that understanding a Picasso painting and understanding Picasso the man are utterly reconcilable but not the same thing. The painter and the painting are not in conflict with each other. They’re both important things to understand.*”
- Peter points out, “*There there are many religious people who take a very literal view of, say, the Bible and would say, ‘Well, the earth is 6,000 years old or whatever.’*”
  - They need to study more science
  - They are taking things too literally
  - They’re not understanding that there’s an intellectual bifurcation between the concept of the creation, the myth of how that actually creation takes place (which is the literalness that you’re talking about) and then the evidence (the awe-inspiring evidence of the creation itself)
- One of the reasons Arthur is religious is because of science
  - Every time he learns something new, he’s like, “*Thank you. What a wonderful gift*.”
    - It doesn’t also freak him out that he might be wrong about the science
    - It also doesn’t freak him out that he might be wrong about the religion
- Some people view those with religious views as more fortunate
  - Peter thinks this makes it easier to process death if you believe there is a life after death
  - Arthur agrees, “*There’s meaning in a different dimension*.”
  - Whereas, if you only think of it in terms of biochemistry, death is a blank screen
- Death is a “what question” and in the spiritual dimension, death becomes a “why question”
  - Arthur explains, “*Those are different interrogatives that have different philosophical and emotional content*.”
- There is this area in-between of spirituality (which is not religion), and this is the closest Peter gets to religion
  - Around the idea of finding enormous pleasure in nature
    - That’s why Peter lives in the middle of nowhere and has to be outside every day; it’s so beautiful
- Arthur explains, “*That’s a* ***transcendent experience****, and that’s really what we’re talking about.*”
- A lot of people get transcendence from nature

**What does a person do who lives in a very busy urban center, where they’re surrounded by a wall of concrete all day, every day?**

- If that turns out to be destructive to your transcendence, that’s a reason to move
  - For some people, not everybody
- Some people get their transcendence from other dimensions of life
  - Maybe they’re traditionally religious
  - Maybe they’re serious meditators
  - Maybe they become completely awestruck from music or human genius

***This really gets back to transcending your littleness, transcending that and that transcendent experience. What it does is it gives you the same benefit as a religious journey (the same happiness benefit).***

**Peter’s takeaway ‒**

- We need to talk about something much broader than religion in the formal sense
- Awe can be the religious belief or an obsession or appreciation of great music or art
  - Or meditation can be the place you tap transcendence
- Arthur points out, “*It’s also very convenient to not invent your own physics on this*“
  - The Catholic Church is really, really good for him
  - It’s one of the things not what he feels, it’s what he’s decided to do

***This is an important thing to understand about transcendence: you don’t feel transcendence all the time; you decide to experience transcendence and put yourself in the circumstances to experience awe***

- For example, Peter may go outside and there’s a lot on his mind
  - He has a very busy, and hectic, and stressful life, and he doesn’t feel it every single day
- Arthur goes to a mass every day, but  he doesn’t feel it every day
  - He wakes up an atheist a lot

**Why do you go to mass every day?**

- It’s part of the protocol for living the life he wants to live
- He gets up at 4:45, works out for an hour (body), goes to mass (soul), then to work
  - That’s when his creativity is the highest
  - Notice that he’s optimizing his dopamine
    - This gives him the creativity and focus for three hours that he needs to write
  - He also wants to optimize both body and soul at the very beginning of the day so he’s centered on the things that really matter to him, notwithstanding how he feels

***It’s the discipline of the will that in and of itself is so important***

- He doesn’t want to do it a lot of days, but that’s not the point

**Do you think that there is a deficit of that as well of that idea?**

*The difference between a feeling and the discipline of the will (or commitment)*

- For example, Arthur alluded to **marriage** earlier
  - Anyone who’s married for many years will acknowledge that so much of the almost perverse joy of marriage is that you make a lot of sacrifices for another person and you find yourself putting someone else ahead of yourself
    - That’s a very hard thing to do
    - Peter adds, “*I’m just so hardwired to be such a selfish guy that it’s really a wonderful practice to do something where I know, ‘I’m going to make my wife’s coffee today, because she would do the same for me.’*”
- Arthur thinks Peter has discovered (and not enough people have) that **love is not a feeling**
  - Happiness is not a feeling either
  - Love is a commitment
- [Martin Luther King](https://en.wikipedia.org/wiki/Martin_Luther_King_Jr.), gave this very beautiful sermon on the most transgressive passage in the Christian Bible, which is Matthew 5:44, love your enemies
  - And he says, “*Jesus says, ‘Today I give you a new teaching. You have heard that you should hate your enemies and love your friends. I tell you, love your enemies and pray for those who persecute you.*’”
  - He says, “*Jesus doesn’t say to like your enemies, because that’s a sentimental thing.* ***To like is to feel, to love is to decide.***”
    - This is what’s going on between you and your wife
    - The satisfaction, the disciplining of your own will comes from the decision to love her
    - That’s the magic in marriage
    - That’s the magic in friendship
    - That’s the magic that you can have in a relationship with your kids
- Arthur adds that if it’s all about your feelings, he’d be divorced
  - His wife would bail on him because he’s a pain to be around
    - She decides every day to love him
- [Thomas Aquinas](https://en.wikipedia.org/wiki/Thomas_Aquinas) based on [Aristotle](https://en.wikipedia.org/wiki/Aristotle), and Aristotle talked really compellingly about love and friendship
  - Aquinas in 1265, writes the Summa Theologica’s magisterial contribution to philosophy
    - He reintroduced Aristotle to the West
    - Everybody was a platonist to Aquinas
  - He defined love as to will the good of the other as other
    - When you’re making your wife that cup of coffee, not withstanding your feelings, you’re willing her good for her, not you

**That discipline of the will to love another person like that, that decision to do so is completely transformative**

- That’s transcendent to the day-to-day experience
- The **animal path** is, “*Well, I’m not going to make coffee. I don’t feel like it*.”
- The **divine path** is to love her, is to will her good as her
  - That’s the human distinction
  - That’s organized life

**Peter’s takeaway** ‒ “*It really seems that that’s almost a theme here of happiness, that happiness is much more about deliberate decision-making, deliberate choices, as opposed to reactive feelings, which that’s obviously the extent to which we’ve discussed it. I think I like this thing that Oprah said, not happiness, but happier-ness.*”

- The thing that Arthur liked the most about what Oprah said was, “*Let’s write a book*… *Let’s spread this idea to a bunch of other people*.”
- Arthur has been listening to *The Drive* for a long time, and this is the salient theme, “*Take charge. Don’t leave your health up to what feels good right now… You’re the boss. The startup is you… You’re the CEO. Treat it as such. The CEO doesn’t do what feels good all the time. The CEO does what’s right, notwithstanding her or his feelings.*”

***That’s the secret of happiness, treating your life like a startup… and you’re not going to do it by doing what feels good in the moment***

- When Peter talks about health span, Arthur talks about happy span
- You’re not going to discipline the will sufficiently to be able to make the decisions that lead you on this divine path that can give you this thing that you actually see
  - It’s not perfect, but you can learn and grow and have progress throughout the journey

## Tracking happiness: biomarkers and micronutrients behind the macronutrients of happiness [1:42:00]

**How do you think about the biomarkers of happiness?**

- In Peter’s work, there are so many biomarkers
  - It’s one of the things that makes his job relatively straightforward
  - Blood-based biomarkers
  - Biomarkers of performance: VO2 max, strength
  - Body composition
- Arthur has thought about this so much and he’s had dozens of entrepreneurs want to engineer the idea and app-ize it
- In the class at Harvard, you have to be able to turn it into some sort of a product, and the way that you would do that is by having a relatively complicated but measurable phenomenon that you could look at and get better at
  - That’s a proxy marker for the underlying construct, which is happiness
- Here’s the fundamental problem with that: it’s a different species of challenge

**There’s two types of problems in human life: complex problems and complicated problems**

- Discussed in their earlier podcast, [episode #226](https://peterattiamd.com/arthurbrooks/) at [1:33:30]
- The **complicated problems** are really, really tricky and take a lot of computational horsepower and learning, but once you solve them, you can replicate the solution with effortless ease forever
  - You can do the same with biomarkers
- The **complex problems** are incredibly easy to understand, but impossible to solve
  - There are too many permutations of what can actually happen
- For example, Peter likes Formula 1 racing, and so Arthur is going to take a bunch of Unix machines and wire them together, and with 250,000 lines of code, he’s going to simulate every F1 race for the rest of the year
  - This is idiotic. Why? Because F1 is complex
    - That’s why it’s interesting and you want to watch it
    - That’s why it’s so exciting to watch a Formula 1 race, because it’s complex
    - Winning is the simplest thing in the world: you cross the finish line before the other guys
    - But a million different things can happen, and that’s the fun of it

> “*All of life’s joys are complex problems. Most of the solutions that we get from technology and science are complicated solutions*.”‒ Arthur Brooks

***The biggest problems that we have right now has to do with the fact that we want to solve our complex problems (like love) with complicated solutions (like Instagram)***

- A complicated solution to a complex problem will always leave you cold and make you worse off
- For example, if Arthur said, “*I’m going to get rid of all the Formula 1 races because it’s dangerous, and I’m going to have nothing more than computer simulations of it*.”
  - That’s dumb
- That is key for us to understand, and that’s the reason he can’t app-ize this

***Happiness is a complex and adaptive human phenomenon, and you can only get it by living it, and working on it, and making progress, and failing, just like your marriage***

- Peter acknowledges, “*In that sense, at least I get feedback in my marriage, because when I screw up and I apologize, I see that my wife forgives me. When I make a mistake, I feel the lenience and the love. When I need the help, the help is there. So, indirectly, I’m getting really good feedback.*”
- Conversely, if a person was to take an honest assessment of their marriage, and realize, “*We’re two ships passing and we don’t fight, but we don’t have anything in common,*” if they were thoughtful enough, they’d recognize things are not well
  - So they’d have a barometer there

**Do you think that using others as a mirror is the best way to get the true barometer of happiness?**

*Or, do we rely on our own internal assessment?*

- We wind up with our own internal assessment, but it’s not good enough to have that be one single metric of, “*How happy am I?*”
- We have identified **three metrics of happiness** so far today in the conversation:
  - 1 – Levels of enjoyment
  - 2 – Satisfaction
  - 3 – Meaning
- We can know whether or not we have those things on the basis of the science that we’ve talked about and the ways that we can get better at and practice it

***The techniques for getting more of those things are faith, family, friends, and satisfying work***

- Arthur breaks it down even further
- He doesn’t try to make it complicated, it’s still complex

**Arthur keeps a spreadsheet that lists the** ***micronutrients*** **behind the macronutrients of his happiness**

- He tracks dozens of dimensions, and he’s rating himself
- He weighs those things according to his experience of how they feed into the macronutrients
- He has scores on those dimensions and he wants to make progress every year
- He rates himself twice a year: on his birthday and half birthday
- His half birthday is coming up (November 21st) and he’s going to fill out his spreadsheet and say, “*I’m not on pace to get the progress that I had in my strategic plan for my happiness for next May… What are the things I need to actually touch up?*”
- Arthur is doing a curve fit to the complex problem he’s trying to solve with a little bit of a complicated solution
- He gives all those dimensions to his students and says, “*Look, do the reading. Do the work. I’ve read 10,000 articles about this, so you don’t have to.*”
- He tries to break it down a little bit, so that he can have a multidimensional problem

***One of the things that we know with complex problems is the more multidimensional you make it, the more likely you are to get better solutions***

- The worst thing that you can do is like, “*How do I feel today?*”
  - You’re not going to make progress under those circumstances

**What are some of the micronutrients that go into this for you?**

- Warmth of my marriage
- The relationship with my kids
- How well things are going with respect to the value I’m trying to create with my career
- Stability of friendships
- The degree to which Arthur feels like he’s properly philanthropic
- The interest he’s taking in his professional life
- The closeness he has with certain intimates in his life
- The extent to which he’s avoiding or finding conflict in his work relationships
- All these things go into Arthur’s spreadsheet, because he knows that they really matter across these three dimensions, the extent to which he’s enjoying my life over the course of each day
- He does these particular ratings, and then he puts them together with a weighted sum across them
  - He’s  messed with a weighted sum and experimented with it until it seems about right with respect to what he’s experiencing

**You make it a multidimensional problem**

- There’s a huge body of social science (imperfect linear models) where you take big problems and make them into a bunch of little tiny problems, and that curve fits to the complex thing you’re trying to solve
- Peter notes that by evaluating this twice a year, you aren’t dependent on the technical noise of the day or the week

***You’re trying to answer these questions through the lens of the last half of the year***

- Arthur adds, “*If I’m having a big conflict with my wife on my birthday, I don’t do it that day… because I don’t want the noise.*”
  - And if something really great happens to him, he doesn’t answer it that day either, because he doesn’t want his neurochemistry to be affecting it unduly
- He’s been doing it for 25 years, and he’s pretty cold in calculating
- Peter thinks it would be a reasonable app to start with
- Arthur agrees that it could be, but it’s very different from biomarkers, because he doesn’t actually know what you would look at
  - What are the biomarkers?
- Arthur has a list of things to measure that serves as a proxy for a dashboard of your happiness health, but it’s imperfect

**Any plans to share that, to make that something others can use besides your students?**

- Arthur admits, “*I should do that*”
- He’d be very interested in experimenting on that (maybe with Peter’s clients) to see to what extent that could be a useful tool

## The value in minimizing the self and looking outward [1:49:45]

**The idea of less self**

*Take away the mirrors*

- Peter finds this to be a very interesting discussion
- Some people will literally minimize the view of themself in a mirror, and then of course Arthur talks about broader versions of that, such as social media and things like that

*Do you think everybody would benefit from this?*

- [William James](https://en.wikipedia.org/wiki/William_James) talked about the I-self versus the me-self (you must have both)
- When you’re looking in the mirror, you’re two people: you’re the looker and the lookie
- And you need both, because you need to be able to look to understand what’s going on around you, but you need to have a reflection of yourself to understand who you are
- I need to see, but I need to be seen by me so I can understand my context, so I can understand my place in the world
- You’ll get run over by a car if you don’t have the I-self
- Or you’ll have somebody kill you because you’ve offended them repeatedly because you don’t understand the me-self is the way that this works out

**The problem in our society is it’s all me-self, no I-self**

- Most people are not observing the world very much at all
- They’re being observed and they’re observing themselves
- They’re trying to be observed, and they’re observing themselves

*Social media is a classic case of this*

- Checking your notifications is nothing more than a me-self obsession, “*What are they saying about me? What impact am I having on other people?*”
- Why we do it: we’re evolved to want to understand where we are in the hierarchy
  - Social comparison, even envy, are evolved phenomena, because it helps keep us alive and make progress

***It’s misery when it takes over and when technology supercharges our ability to be in the me-self state***

- There are moments when you can be really confused about the I-self and the me-self
- One time Arthur was really thinking deeply about something and was obsessed
  - He was in the car with his daughter, and he filled up the car with the gas, took off from the gas station, lost in thought
  - About a block later, he hears this weird ding, ding, ding, ding
  - He thought, “*What’s going on? Somebody dragging a muffler*,” and he’s looking for somebody dragging a muffler
  - Then he notices that cars are honking and pointing at him
  - He stopped the car, and it turns out he hadn’t pulled the gas hose out of the car
    - The hose pulled out of the pump and was dragging it down the road
    - He went back to the gas station and found out how expensive it is to replace part of a gas pump (pretty bad)

***The whole point was he was the I-self and the me-sell all at once, and it was this weird disequilibrating experience***

**One of the ways to get much happier is to be more in the I-self and less than in me-self state is to minimize the reflection, is to think a lot less of what other people are thinking and to observe yourself a lot less**

*Different ways to do that*

- In his book [[*Build the Life You Want*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2)], Arthur talks about this guy he works with pretty closely: a fitness influencer and fitness model
  - If you’re seeing your lower abs and you’re an adult, that means you’re never eating anything you like (ever), and you’re not getting enough enjoyment for your life, right?
  - He was miserable for 10 years
  - He didn’t eat what he liked; he always had headaches; he didn’t feel good
  - He didn’t have normal relationships
  - And so, he decided he had to make a change in his life
  - He literally got rid of every mirror in his apartment and showered in the dark for a year, so he couldn’t see his own abs, and his life completely changed
    - Just on the basis of getting rid of those mirrors

**When people are miserable in Arthur’s classes, he says**

- 1 – Take the notifications off your social media (turn them off)
- 2 – Don’t look at your mentions (under any circumstances), don’t pay attention to that
- 3 – Literally start getting rid of some of your mirrors, your literal mirrors
- And what you’ll do is you’ll get into more of a state of looking outward

***The more you look outward, the happier you’ll be***

- The better off your life will be, when you’re walking around going, “*Man, that’s amazing.*”
  - You know what’s not amazing? Me.

## How Arthur surprised himself with his ability to improve his happiness [1:54:00]

**What surprised you the most when you set out to write this [**[***Build the Life You Want***](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2)***]*****?**

- Peter points out that Arthur is writing a book on a topic that he’s studied for decades and written column after column weekly in [*The Atlantic*](https://www.theatlantic.com/projects/how-build-life/)
  - He’s written other books that touch on similar themes

*Peter has to believe that there’s something Arthur believes today that he absolutely didn’t before*

- Arthur has changed his opinion about a lot of different things

> “*The science has gotten clearer and my knowledge has gotten deeper.*”‒ Arthur Brooks

- Arthur wrote his first book about happiness in 2008 [[*Gross National Happiness*](https://www.amazon.com/Gross-National-Happiness-Arthur-Brooks/dp/0465002781/ref=sr_1_8?crid=2D2AUC9SPNWTF&keywords=arthur+brooks+books&qid=1698764137&sprefix=arthur+brooks+books%2Caps%2C91&sr=8-8)]
  - But it was like a book on astronomy
  - It was observing happiness from a distance
    - Who are the happy people, who are the unhappy people?

**Arthur realized, “*****It never really occurred to me that with the science, I could change my own life, that I’m not a fundamentally happy person*****.”**

- Mad scientists struggle because negative affect: it gets your attention so much more strongly than positive affect does
  - If you’re high positive and high negative, you’re going to feel on balance, pretty negative a lot
- For years, Arthur always thought, “*Happiness is a really interesting thing, but it’s not my lot.”*
- *Then, when he came back and started the new happiness projects, writing his* [*column*](https://www.theatlantic.com/projects/how-build-life/) *and the books he’s written in the past couple of years, he said, ‘All right, let’s see if that’s true. I can’t move the stars as an astronomer, but maybe I can use the social science and the neuroscience in ways where I can with the knowledge, change my habits and get happier.’*”
  - He doubted it and thought he couldn’t
  - But he actually did; he changed his life
- He’s usually 8-9 weeks out on his column in the Atlantic, because he’s trying the things that he’s suggesting
  - He’s a lab rat, and he knows Peter does this too
    - You’re not going to suggest something to your clients that you don’t feel comfortable with
  - Even as a human being, this is what he’s doing too
- And he’s taking constant updates
  - He takes the tests with his students on positive and negative affect and life satisfaction

**Arthur’s wellbeing has risen by 60% in the past four years**

- He explains, “*It was a pretty low base. It was a bad denominator. But it’s been dramatic, and I didn’t actually trust, I didn’t actually believe, but it’s actually true, and anybody can do this.*”
- Peter thinks this is a great message because Arthur hasn’t wrapped his identity up in being the happiest guy
  - He’s not faking it
- Peter explains when people see him eat a donut, they’re like “*What?*” and he tells them, “*Hey, read the* [*book*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=1MA1P4X1UMXAK&keywords=outlive&qid=1698768779&sprefix=outlive%2Caps%2C97&sr=8-1)*, man*.”
  - He didn’t say, “*Don’t eat a donut*.”
  - Don’t eat 10 a day

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Arthur Brooks**: [#226 ‒ The science of happiness | Arthur Brooks, Ph.D.](https://peterattiamd.com/arthurbrooks/) (October 10, 2022) | [1:00, 1:05:15]

**Arthur’s new book on happiness**: [Build the Life You Want: The Art and Science of Getting Happier](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2) by Arthur Brooks and Oprah Winfrey (2023) | [1:15, 1:52:30, 1:53:45]

**Arthur’s column on happiness**: [How To Build A Happy Life](https://www.theatlantic.com/projects/how-build-life/) | Arthur Brooks, *The Atlantic* (2023) | [1:15, 1:54:00]

**Arthur’s previous book**: [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur C. Brooks (2022) | [1:15, 32:00, 1:05:30]

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=1MA1P4X1UMXAK&keywords=outlive&qid=1698768779&sprefix=outlive%2Caps%2C97&sr=8-1) by Peter Attia and Bill Gifford (2023) | [4:00, 1:56:45]

**fMRI study of the pain of rejection**: [Does rejection hurt? An FMRI study of social exclusion](https://pubmed.ncbi.nlm.nih.gov/14551436/) | *Science* (N Eisenberger, M Lieberman, and K Williams 2003) | [11:45]

**Quiz to determine your personality pattern with respect to positive and negative emotions**: [Be Happier. Build the life you want](https://arthurbrooks.com/build) [scroll down to “Are you a cheerleader, poet, mad scientist, or judge?”] | Arthur Brooks (2023) | [20:45]

**Arthur’s first book on happiness**: [Gross National Happiness: Why Happiness Matters for America–and How We Can Get More of It by](https://www.amazon.com/Gross-National-Happiness-Arthur-Brooks/dp/0465002781/ref=sr_1_8?crid=2D2AUC9SPNWTF&keywords=arthur+brooks+books&qid=1698764137&sprefix=arthur+brooks+books%2Caps%2C91&sr=8-8) Arthur Brooks (2008) | [1:54:30]

§

## People Mentioned

- [Elisabeth Kübler-Ross](https://en.wikipedia.org/wiki/Elisabeth_K%C3%BCbler-Ross) (Swiss psychiatrist and author of [*On Death and Dying*](https://www.amazon.com/Death-Dying-Doctors-Nurses-Families/dp/1476775540/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1698246510&sr=8-1)) [5:00]
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) (expert in optogenetics, Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford University) [16:30]
- [John Gartner](https://johngartner.com/) (Psychologist and author of *The Hypomanic Edge*) [27:30]
- [Walter Isaacson](https://liberalarts.tulane.edu/departments/history/people/walter-isaacson) (Professor of American History and Values at Tulane University and biographer) [31:15]
- [Thích Nhất Hạnh](https://plumvillage.org/about/thich-nhat-hanh/biography) (the Vietnamese Buddhist monk who started the Plum Village Community of Western Buddhists, 1926-2022) [52:45]
- [Dacher Keltner](https://psychology.berkeley.edu/people/dacher-keltner) (Professor of Psychology at UC Berkeley and author of [*Awe*](https://www.amazon.com/Awe-Science-Everyday-Wonder-Transform/dp/1984879685/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)) [1:02:30]
- [Scott Barry Kaufman](https://scottbarrykaufman.com/) (Cognitive scientist, podcaster, and author) [1:19:45]
- [Vivek Murthy](https://www.vivekmurthy.com/) (Physician, 19th and 21st Surgeon General of the US, and author of [*Together*](https://www.amazon.com/Together-Connection-Performance-Greater-Happiness/dp/0062913298/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1698431024&sr=8-1)) [1:24:45]
- [Jonathan Haidt](https://jonathanhaidt.com/) (social psychologist, Professor of Ethical Leadership at New York University, and author) [1:28:30]
- [Jean Twenge](https://www.jeantwenge.com/) (Professor of Psychology at San Diego State University and author) [1:28:30]
- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) (talk show host, author, and media proprietor) [1:31:45, 1:40:45]
- [Martin Luther King Jr.](https://en.wikipedia.org/wiki/Martin_Luther_King_Jr.) (Civil rights leader and political philosopher, 1929-1968) [1:38:45]
- [Thomas Aquinas](https://en.wikipedia.org/wiki/Thomas_Aquinas) (Philosopher and theologian, 1225-1274) [1:39:30]
- [Aristotle](https://en.wikipedia.org/wiki/Aristotle) (Ancient Greek philosopher, 384-322 BC) [1:39:30]
- [William James](https://en.wikipedia.org/wiki/William_James) (Philosopher and psychologist, 1842-1910) [1:50:15]

§

![](https://peterattiamd.com/wp-content/uploads/2022/10/bio-image-arthurbrooks.jpg)

##### Arthur Brooks, Ph.D.

Arthur C. Brooks is the Parker Gilbert Montgomery Professor of the Practice of Public and Nonprofit Leadership at the Harvard Kennedy School, and Professor of Management Practice at the Harvard Business School, where he teaches courses on leadership and happiness. He is also a columnist at The Atlantic, where he writes the popular “How to Build a Life” column. Brooks is the author of 13 books, including the 2023 #1 New York Times bestseller [*Build the Life You Want: The Art and Science of Getting Happier*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_1?hvadid=658443648904&hvdev=c&hvlocphy=9019562&hvnetw=g&hvqmt=e&hvrand=6184079167641394292&hvtargid=kwd-420263501740&hydadcr=14840_13352664&keywords=build+the+life+you+want&qid=1701098044&sr=8-1) with co-author Oprah Winfrey,  and the 2022 #1 *New York Times* bestseller [*From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X). He speaks to audiences all around the world about human happiness and works to raise well-being within private companies, universities, public agencies, and community organizations.

Instagram: [arthurcbrooks](https://www.instagram.com/arthurcbrooks/?hl=en)

Website: [arthurbrooks.com](https://arthurbrooks.com/)

X (formerly twitter): [@arthurbrooks](https://twitter.com/arthurbrooks)