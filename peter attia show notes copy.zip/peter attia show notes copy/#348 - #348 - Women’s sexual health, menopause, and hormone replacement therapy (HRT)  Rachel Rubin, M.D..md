# #348 ‒ Women’s sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.

**Source:** [https://peterattiamd.com/rachelrubin/](https://peterattiamd.com/rachelrubin/)

---

Rachel Rubin is a board-certified urologist and one of the nation’s foremost experts in sexual health. In this episode, she shares her deep expertise on the often-overlooked topic of women’s sexual health, exploring why this area remains so neglected in traditional medicine and highlighting the critical differences in how men and women experience hormonal decline with age. Rachel explains the physiology of the menstrual cycle, the complex hormonal shifts of perimenopause, and the wide-reaching health risks associated with menopause, including osteoporosis, cardiovascular disease, dementia, and recurrent urinary tract infections. She also breaks down the controversy surrounding hormone replacement therapy (HRT), particularly the damaging legacy of the Women’s Health Initiative study, and provides guidance on the safe and personalized use of estrogen, progesterone, and testosterone in women. With particular emphasis on local vaginal hormone therapy—a safe, effective, and underused treatment—Rachel offers insights that have the potential to transform quality of life for countless women.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/rachelrubin/the_Drive_public.png)

Play

#348 ‒ Women's sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.

#348 ‒ Women's sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.

1x15s30s

0:002:13:28

## We discuss:

- Rachel’s training in urology and passion for sexual medicine and women’s health [3:00];
- Hormonal changes during ovulation, perimenopause, and menopause: why they occur and how they impact women’s health and quality of life [5:30];
- Why women have such varied responses to the sharp drop in progesterone during the luteal phase and after menopause, and the differing responses to progesterone supplementation [14:45];
- The physical and cognitive health risks for postmenopausal women who are not on hormone therapy [17:45];
- The history of hormone replacement therapy (HRT), and how misinterpretation of the Women’s Health Initiative study led to abandonment of HRT [20:15];
- The medical system’s failure to train doctors in hormone therapy after the WHI study and its lasting impact on menopause care [29:30];
- The underappreciated role of testosterone in women’s sexual health, and the systemic and regulatory barriers preventing its broader use in female healthcare [35:00];
- The bias against HRT—how institutional resistance is preventing meaningful progress in women’s health [46:30];
- How the medical system’s neglect of menopause care has opened the door for unregulated and potentially harmful hormone clinics to take advantage of underserved women [53:30];
- The HRT playbook for women part 1: progesterone [57:15];
- The HRT playbook for women part 2: estradiol [1:05:00];
- Oral formulated estrogen for systemic administration: risks and benefits [1:13:15];
- Topical and vaginal estrogen delivery options: benefits and limitations, and how to personalize treatment for each patient [1:17:15];
- How to navigate hormone lab testing without getting misled [1:24:15];
- The wide-ranging symptoms of menopause—joint pain, brain fog, mood issues, and more [1:31:45];
- The evolution of medical terminology and the underrecognized importance of local estrogen therapy for urinary and vaginal health in menopausal women [1:37:45];
- The benefits of vaginal estrogen (or DHEA) for preventing UTIs, improving sexual health, and more [1:41:00];
- The use of DHEA and testosterone in treating hormone-sensitive genital tissues, and an explanation of what often causes women pain [1:50:15];
- Is it too late to start HRT after menopause? [1:56:15];
- Should women stop hormone therapy after 10 years? [1:58:15];
- How to manage hormone therapy in women with BRCA mutations, DCIS (ductal carcinoma in situ), or a history of breast cancer [2:00:00];
- How women can identify good menopause care providers and avoid harmful hormone therapy practices, and why menopause medicine is critical for both women and men [2:06:00]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Rachel Rubin is a board-certified urologist and one of the nation’s leading experts in sexual health
- She is among a select group of physicians with fellowship training in sexual health for both men and women, bringing a rare and deeply informed perspective to her clinical work
- The conversation today focuses on women’s sexual health

**We discuss**

- Why sexual medicine (particularly for women) remains so neglected in traditional healthcare
- The critical difference in how men and women experience hormone decline with age
- The physiology of the menstrual cycle, including the role of estrogen, progesterone,  FSH, and LH
- Why perimenopause is characterized by extreme hormone fluctuations
- The risks of menopause beyond just symptoms like hot flashes
  - Including risk of osteoporosis, cardiovascular disease, dementia, and recurrent UTIs
- The longstanding controversy around HRT
- How a single study (the Women’s Health Initiative study) led to decades of fear-based medicine and entire generation of women deprived of the benefits of HRT
  - By Peter’s calculation >20 million women
- How to use estrogen, progesterone, and testosterone for women
  - Including dosing, delivery, method (such as oral, transdermal, vaginal)
  - Why personalized care is essential
- The overlooked role of testosterone in women’s health
  - Both before and after menopause
- The benefits of local, vaginal hormonal therapy
  - A safe, inexpensive, and underutilized treatment that prevents urinary tract infections, improves sexual function, and dramatically enhances quality of life in post-menopausal women
- This is a podcast in which Peter learned a lot, even though he likes to think he knows quite a lot about this already
- Rachel’s expertise here is second to none, and Peter was feverishly taking notes throughout
- Peter can’t wait to implement many of the things he learned in his clinical practice

## Rachel’s training in urology and passion for sexual medicine and women’s health [3:00]

**Help us understand how your training in urology led you to what you’re doing today**

- When we think of urology, we think about prostates, kidneys, bladders
- But what you forget is that urologists are ultimately the quality of life doctors
- We deal with urination problems and we deal with sexual medicine

> “*No one cares about erections and orgasm and libido quite the way that a urologist cares… it’s not a gender thing*.”‒ Rachel Rubin

- We’re not penis doctors only: we are board certified to take care of everybody’s genital and urinary tracts
- Unfortunately, society has led us to know a lot more about the men’s sexual health and men’s genitals than female genitals
- Rachel trained in urology because she was interested in women’s health, but she was also interested in sexual health, sexual medicine
- She didn’t like delivering babies, didn’t like OB/GYN
- What she loves about urology is that she can see everybody and she can really dive deep on quality of life issues
  - The magic of urology is also that you really get to know your patients
  - It’s not like when you did surgery, you take out someone’s appendix and you never see them again
    - Maybe you do one post-op visit
- Urologists have deep relationships, we’re both surgeons but we actually care about the medical side of these quality of life issues
- As she was going through medical school, she really realized that talking about sexual health and quality of life issues was fun for her
  - It’s just been a joy
- She’s been working to further the field of urology to make us better at taking care of women
- Rachel does a lot of educating and teaching to her colleagues about how we really need to care about the whole, everybody

## Hormonal changes during ovulation, perimenopause, and menopause: why they occur and how they impact women’s health and quality of life [5:30]

- Peter wants to talk about it from a female standpoint today because there’s a dearth of great information out there and an abundance of garbage information out there
- He appreciates Rache’s breadth of knowledge that covers both sexes, but he wants to talk about women specifically

**Menopause: an obvious difference between men and women from an endocrine perspective**

- Menopause is a sudden and abrupt loss of sex hormones
- That is in contrast to the way men’s sex hormones decline over time a little more slowly
- Listeners of this podcast are highly erudite
  - [menopause is discussed in episodes [#42](https://peterattiamd.com/caroltavris-avrumbluming/), [#253](https://peterattiamd.com/joannmanson/), [#256](https://peterattiamd.com/endocrinesystem/), [#259](https://peterattiamd.com/sharonparish/), and others]

*Give a quick overview of what is happening to women in menopause*

- Rachel got an interesting email last week that said, “*Dr. Rubin, my wife is seeing your practice. Her libido is now like an F1 Formula One race car. And I’m like a 1988 Honda Civic. What can you do for me?*”
- Rachel’s **gas tank analogy**: as men age, sometimes we see a decrease in their gas tank
  - Men are  feeling low, they’re feeling down, they’ve got erectile dysfunction, low libido

***Whereas women at age 52, their gas tank is empty ‒ this is a castration event***

- We don’t have many castration events in men’s health

> “*Menopause is sort of a, your gas tank is officially empty. There’s not much in the tank*.”‒ Rachel Rubin

**Perimenopause is this time where it’s very erratic**

- The gas tank is over full, and then it goes to empty really quickly without warning
- This analogy is helpful when we’re talking to women about the reason you don’t feel like yourself is because there’s just no gas in the tank

**⇒** We see the ovaries are no longer producing estrogen, progesterone, and testosterone the way that they were during your reproductive years

- Peter loves that analogy ‒ it absolutely replicates what he sees clinically
  - In perimenopause, sometimes he measures a women’s labs every 3 months and will see periods where [estradiol](https://en.wikipedia.org/wiki/Estradiol) is through the room, [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) and [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) are low; then, 3 months later it’ completely flipped
- Rachel compares the changing hormones levels to the stock market
  - It goes up, it goes down
  - And it’s not even just checking it every 3 months; if you check it every 10 days, you’re going to see a fluctuation
- Rachel is obsessed with looking at the [menstrual cycle](https://en.wikipedia.org/wiki/Menstrual_cycle), obsessed with talking about numbers here because it is so fascinating and we are not taught to think this way
- For example, when you’re in your ‘healthy reproductive years’ (and by the way, nobody is the book)
  - You talk a lot about continuous glucose monitors
  - She would love continuous sex hormone monitors
    - Although she know there’s be a lot of unintended consequences and bad things that would come of it

**Hormonal changes during the menstrual cycle**

- When a woman has her period (and is bleeding), at day 1 [estradiol](https://en.wikipedia.org/wiki/Estradiol) is not zero, it’s probably 40-50 pg/mL
  - The units are different for testosterone, which is measured in ng/dL
  - [the unit for measuring testosterone is 10,000x larger than the unit for measuring estradiol]
- Let’s say 50 pg/mL is her low, then she ovulates in mid-cycle and estradiol is about 150ish (maybe 200, 300)
- During pregnancy the level of estradiol is 3000 pg/mL or higher (it’s very high)

**⇒** If you are in your normal reproductive cycle, you go from 50 to 150 pg/mL estradiol

- Back to the **gas tank analogy**: you’re at a quarter tank at 50 and you go to three quarters tank at 150, then down to a quarter tank
- You can drive wherever you want to go during that time

*What happens in perimenopause*

***It is this chaos and erratic fluctuation where your body is just wanting more hormone than it has***

- Your brain, your FSH is telling your eggs to do more than they can
- Sometimes they overshoot, and now you are overflowing gas
  - Rachel had a lady recently whose day 1 estrogen was 200 and her day 10 estrogen was 900
  - You see wild fluctuations in perimenopause

**⇒** For anyone listening who wants a more nuanced view of this, see the overview Peter made of the ovulatory cycle a couple years ago where he draws a graph of estrogen, progesterone, FSH, and LH [[episode #256](https://peterattiamd.com/endocrinesystem/)]

- Rachel adds, “*That video is so fantastic… if you ask most OB/GYNs to draw the menstrual cycle, many of them wouldn’t be able to do so.*”
- It’s incredibly complicated and confusing
- We think our doctors know everything, and unfortunately they don’t

[Video above from [episode #256](https://peterattiamd.com/endocrinesystem/)]

**Explain the role of FSH and LH on the brain**

- When you have your period, the lining of your uterus is shedding and your estrogen is at its all time low
- Peter adds the obvious statement: most of the time when a woman ovulates, she does not get pregnant
- In this non-pregnancy state, you’re shedding the lining, your estrogen’s about 50, let’s say, to make it easy
- Now it’s starting to go up, up, up, up, up and you’re developing this follicle (this egg is developing)
- [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) is sort of your brain’s marker of, “*It’s time to ovulate.*”
  - So that’s when you pee on a stick and you’re trying to check if you’re ovulating ‒ it’s checking your LH levels
- You’re going to see this increase in LH
- Again, everyone’s a little bit different, but it happens kind of mid-cycle day 10 to 14
  - Remember, Rachel is a urologist not gynecologist
- You get this LH surge, the egg pops out, and it is the shell of the egg that creates the [progesterone](https://en.wikipedia.org/wiki/Progesterone) surge
- So you actually don’t make any progesterone really in that first half of your cycle, and then after ovulation, we call the second half the luteal phase, which just means that’s when progesterone is around
- And so you get this surge of progesterone when there is no fertilization, that shell of the egg evaporates, and then you lose your progesterone
- And it is that withdrawal of progesterone that causes the uterine lining to shed

![](https://peterattiamd.com/wp-content/uploads/2025/05/f1-rachelrubin-1024x663.png)

**Figure 1. Hormone changes that occur during the menstrual cycle**. Image credit: [episode #256](https://peterattiamd.com/endocrinesystem/)

What is confusing for people

- Through that time, your progesterone goes from very, very low to after you ovulate very, very high, and it’s that cycle every month
- Now estrogen again goes from 50 to 150 back down to 50
  - That’s what the book says
  - But Rachel’s patients are not all on the book, so she’s super interested in this
- Rachel cares about how people are feeling
- During her conversation with people, there’s the book answer, the Instagram answer, and her answer is somewhere in the middle
- The numbers are helpful for people to see
  - When you’re pregnant, your estrogen is 3000
  - When you’re regularly ovulating, it’s 50 to 150
  - In perimenopause, it could be a 1000 and down to zero in 2 seconds flat

**Why is it that in perimenopause, the fluctuations in estradiol level are so dramatic?**

- It has to do with the fact that you have a limited number of eggs
- You’re sort of getting to that end of your bucket of eggs that you’re born with
  - That’s again controversial on the internet
- Your body is really trying to do what it has always done, and it’s just having trouble
  - It’s having trouble recruiting the egg, ovulating
  - You don’t ovulate every time, sometimes you ovulate twice (push out two eggs in this perimenopause cycle)
- So we can sometimes see really high elevations, which can come with symptoms

**⇒** That’s the challenge of perimenopause is sometimes you have symptoms because you’re too low, sometimes you have symptoms because you’re too high, and sometimes it’s that fluctuation

- Back to the **car analogy**: you’re driving a 100 mph on the highway and you go to empty gas tank immediately
  - That is not good for a car
  - That is inflammation, that is irritation, that is a lot of perimenopause symptoms
- Peter extends the analogy, “*Part of the reason why a woman during this period of time can experience these enormous surges of estradiol is if you think that there’s, say a kink in the gas line and you really, really want to squeeze the lever to get as much gasoline as you can in the car, sometimes you overshoot and just you get a whole bunch extra in there because there’s volatility in the follicle release.*”

## Why women have such varied responses to the sharp drop in progesterone during the luteal phase and after menopause, and the differing responses to progesterone supplementation [14:45]

- Women have varying degrees of sensitivity to the dramatic reduction in [progesterone](https://en.wikipedia.org/wiki/Progesterone) that they experience in the last quarter of the cycle once the lining sheds
- They talked about how during the luteal phase, progesterone levels are rising
  - We’re building up the endometrial lining in preparation for pregnancy
  - Most of the time, pregnancy is not going to happen
- When the uterine lining sheds, progesterone crashes, and this is what’s referred to as [PMS](https://en.wikipedia.org/wiki/Premenstrual_syndrome)
  - Some women are somewhat unfazed by that and for other women, that’s a big deal

**Is the varying degrees of sensitivity to progesterone about the central receptors of progesterone?**

- This is an important question that Raches sees clinically all the time
- If you give somebody, say, micronized progesterone or synthetic progestin (in birth control), you will see a wide variety of reactions to these different medications
- Rachel would say it has to probably do with the [GABA receptor](https://en.wikipedia.org/wiki/GABA_receptor) and the [metabolites of progesterone](https://en.wikipedia.org/wiki/Progesterone#Metabolism) and how the receptors in the brain use these molecules

> “*I think we just don’t know enough. I tell my patients all the time, I wish… Oh my gosh, we have so much work to do in women’s health. We have so much research we need done*.”‒ Rachel Rubin

- This is why Rachel comes on this platform: she needs smart people to be listening to this, to ask the research questions and to do this research because clinically we see this all the time
- Rachel will put up that menstrual cycle with her patients and say, “*When do you start to have symptoms? Are you having symptoms when your estrogen is falling? Are you having symptoms when your progesterone is falling?*”
- And can we hack this system to help you feel better?
- And how are you going to respond to it?

*Response of women to micronized progesterone fall into 1 of 3 buckets*

- 1 – A third of the patients love it and guzzle it like it’s candy, and they’re the happiest people in the world, helps their sleep, reduces anxiety (it’s absolutely life changing)
- 2 – A third of patients don’t really notice it, it doesn’t bother them (if you tell them they need it to protect their uterus they’ll take it)
- 3 – A third of patients are very sensitive
  - Within that, a third are extremely sensitive meaning they have horrible reactions
    - It makes them too sleepy, it makes them feel bloated, they don’t like it

Rachel adds, “*As a clinician and an interested researcher, I don’t know exactly enough to be able to spot who those people are ahead of time.*”

**Peter’s takeaway on perimenopause** ‒

- The one consistent thing that’s happening is inconsistency
  - At some point you’ll get to a place where the consistency returns
- The new norm is you don’t make estrogen, you don’t make progesterone
- The signal from your pituitary FSH and LH begin monotonically rising, rising, rising
- If you were to do the blood work of a woman in her 60s who had never been placed on HRT, you would see a very high FSH, a very high LH (usually above the labs’ cutoff for measurements) and then estradiol and progesterone are non-existent

## The physical and cognitive health risks for postmenopausal women who are not on hormone therapy [17:45]

- Peter wants to talk about that woman that he just described: in her 60s [in menopause], who is now 10 years out of any hormones

**What are the risks to her physical health, mental health, emotional health, cognitive health, the whole picture of her health everything?**

*What is she worse off for at that period of time?*

- That’s a really important question in the sense of
  - What is the risk of taking hormone therapy in that patient
  - What is the risk of *not taking* hormone therapy in that patient
- It’s super interesting because we love talking about the risks of medication, but we don’t spend a lot of time talking about the risks of *not taking* medication
- If we think about that woman as she gets older, she certainly will have the microbiome and genital and urinary changes of not having hormones

> “*As a urologist, this is actually one of the couple of things that will kill her*.”‒ Rachel Rubin

**⇒** As you lose hormones in the genitals (which are very hormone sensitive, the bladder is very hormone sensitive), you change the microbiome, you decrease the acidity of the tissue, the bad bacteria grow, your risk of [urinary tract infections (UTIs)](https://en.wikipedia.org/wiki/Urinary_tract_infection) increase drastically

***She may get recurrent urinary tract infections or pelvic pain, she may develop osteoporosis, and there’s also the risk of dementia and Alzheimer’s***

- The risk of not taking hormone therapy when you get a hip fracture is going back to the life that you lived is very challenging or you die
- The risk of dementia and [Alzheimer’s](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) is much higher in women, and we don’t have good data about whether hormones are actually protective, how they’re protective, or when to start them
- We also know that [heart disease](https://peterattiamd.com/category/risks/heart-disease-prevention/) is the number one killer of women, and we know that things get worse as you get older

Rachel explains, “*I think there are significant risks to that person. And from the mental health perspective, I think there’s no question that we see worsening*.”

- Perimenopause, from what she understands of the data, is actually worse on mental health and can actually level out a little bit once there’s less erratic hormones
- But again, an empty gas tank is still an empty gas tank ‒ and so we see a lot of challenges in this time period

Peter points out, “*We talked about obviously the risk of dementia. We talked about the risk of osteoporosis, cardiovascular disease, colon cancer, all of these are risks that are pretty clearly going up in the absence of hormones.*”

## The history of hormone replacement therapy (HRT), and the misinterpretation of the Women’s Health Initiative study leading to abandonment of HRT [20:15]

**Talk about the history of HRT**

- It was largely normal practice in the 1960s
- Initially it was just replacing estrogen and they figured within a few years that if you only gave a woman estrogen, you increase the risk of endometrial cancer
  - Because the endometrial lining continued to get bigger and bigger until you eventually developed [hyperplasia](https://en.wikipedia.org/wiki/Hyperplasia) (which presumably became [metaplasia](https://en.wikipedia.org/wiki/Metaplasia) and ultimately cancer)

**⇒** If you oppose the estrogen with progesterone, you keep the endometrial lining in check, and this largely became the standard of care through the 1980s and into the 1990s

- Epidemiologic observations showed that women who took hormones did significantly better
- People who listen to this podcast are well aware of how critical Peter is of epidemiology
  - It’s certainly very easy to make the case that in the 1980s, women who were taking hormones had a healthy user bias
    - They probably had better access to healthcare
    - They were probably doing many more things to improve the quality of their health
- The NIH did something that made a lot of sense, they said, “*Look, we can’t rely on this epidemiology. We need to do a randomized control trial.*”
- They did it through something called the [Women’s Health Initiative (WHI)](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative), which had 2 components
  - A nutritional component that was asking a question about low-fat diets
  - A component that was looking at the HRT

*Talk about how the study was designed, some of the potential pitfalls of it, and ultimately how the results of that have been misunderstood and misinterpreted for so long*

- This is a big deal
  - This story could be made into a Hollywood biopic mega drama
- A billion dollars of our resources went into doing this study, and there are many things that we learned that were helpful and useful and this huge set of data that we’re still using today to extrapolate information from

***A lot of good that came from it, but there was a lot of misinformation and just really bad marketing (or really effective marketing you could argue)***

**What is so wild, is that before the WHI study was published, they did a press conference**

- Have you ever seen the NIH do a press conference that [Matt Lauer](https://en.wikipedia.org/wiki/Matt_Lauer) talked about or that made it on [Good Morning America](https://en.wikipedia.org/wiki/Good_Morning_America)?
- Rachel remembers she was in medical school at the time
- They said, “*We had to stop the study early. It is increasing the risk of breast cancer and increasing the risk of blood clots and cardiovascular disease, and we have to stop the study*.”
- There’s different statistics out there, but people will say about 40% (maybe) of women were on hormone therapy at the time ‒ overnight it crashed to nothing
  - You’re talking billions of dollars of an industry that went to nothing
- The people who are prescribing the hormone therapy were like, “*This doesn’t make any sense. I’ve been doing this for 20 years, 30 years. I don’t have a clinic full of people who are dying of blood clots or heart attacks or who get breast cancer. This is not my clinic, whose clinic is this?*”
- Then they published the [paper](https://pubmed.ncbi.nlm.nih.gov/12117397/)

***They misinterpreted the data so drastically and scared everybody with so much fear that you actually have an entire generation that has forgotten how to prescribe hormone therapy***

> “*This is the nightmare that we’re living in today, because now we realize that the data was misinterpreted.*”‒ Rachel Rubin

- The [form of HRT studied by the] WHI was one medication, one dose (that’s it)
  - It was a sort of birth control pill style kind of hormone therapy
  - A synthetic estrogen and progestin
- It was not the the FDA-approved products that we use today like estradiol and progesterone (they’re different medications)
  - We can talk about the marketing term bioidentical
- And so you’re talking one medication, one dose, and we’re still practicing fear-based medicine 30 years later

Rachel adds, “*We don’t practice any other medicine like this… We evolve, we learn new things.*”

**Let’s talk about the good outcomes of HRT**

- When you took estrogen and progestin (or estrogen alone), you had a decreased risk of **colon cancer**
  - You had significant decreased risk of **fracture**
  - Decrease of **diabetes**
- This is in the hormones we don’t even really prescribe anymore
- We saw a decrease in overall **mortality**
  - A decrease in cancer specific mortality
- And then when you looked at the cardiovascular data over time, there was actually no difference
  - And again, Rachel is a urologist, not a heart expert

***It wasn’t so scary***

**Fear and risk associated with HRT**

- As you get older, we know birth control pills can cause **blood clots**
  - So we do worry about giving a birth control pill to grandma because you can increase blood clots
  - That’s true; Rachel agrees with that
- When it comes to **breast cancer**, the most fascinating data that didn’t make the press conference: women who are on the estrogen alone (so they didn’t have a uterus, they didn’t need the progestin therapy) had a decreased risk of getting and dying from **breast cancer**
  - And it didn’t make the news
  - Even in that study that put the box labeling on all the products, it’s not true
- When you looked at the estrogen + progestin groups, there was a fear that there was an increased risk of incidence but *not mortality* from breast cancer
  - When you look at that data, there is questioning of the fact that the placebo group actually was more protected by breast cancer because many of them had been on hormones in the past
  - When you use a correct placebo group, the lines actually go together

Rachel adds, “*You’re more of a statistics nerd than I am. But the reality is there was no difference.*”

***And so we scared an entire generation of people away from hormones because of a bad misinterpretation of statistics***

- Peter jokes that his blood pressure is up right now; he’s probably 180/120
- He thinks this is a remarkably succinct summation of the WHI
- He has friends and patients who to this day are paranoid about hormones, so he wants to offer another opportunity for them to understand what’s going on

**Peter’s summary**

- The WHI had 2 parallel arms
  - 1 – Women without a uterus were just randomized to either the synthetic or equine-based estrogen versus a placebo
  - 2 – Women with a uterus got [MPA](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate) (a synthetic progesterone) and the estrogen
- The one finding that got all of the attention was that in the women with a uterus group, if you got the synthetic progestin and estrogen, you had an increase in your incidence of breast cancer
  - It turned out it didn’t actually lead to any change in mortality from breast cancer, but there was an increase in the incidence
  - The number is really scary if it’s given in *relative terms*: it was a 24% increase in the incidence
    - Incidence for the listener, meaning getting breast cancer
    - You had a 24% higher chance of getting breast cancer if you took the 2 hormones
    - On the surface that sounds devastating, but we always need to think in terms of *absolute risk*

**⇒** Relative risk doesn’t mean that much if you don’t understand absolute risk

- If Peter said, “*Rachel, I have a treatment for you that is going to fix a hundred problems, but it increases your risk by 100% of getting hit by an astroid.”* Would you take the medicine or not?
- Well, you’d have to know what your base level risk of getting hit by an asteroid is
  - And given that it’s almost zero, doubling it doesn’t mean anything

**⇒** The absolute risk increase for these women was 0.1%

- To put that in less technical terms, it meant even if you believe the results of that study
  - And Rachel has offered a great explanation for why the actual results should be questioned

***Even if you take the results at face value, for every 1000 women who were put on HRT, an additional 1 got breast cancer, though she didn’t die from it at any increased rate to the women who didn’t get the hormone***

> “*This is the greatest injustice imposed by the modern medical system in our lifetime.*”‒ Peter Attia

- Rachel agrees this is a disaster

## The medical system’s failure to train doctors in hormone therapy after the WHI study and its lasting impact on menopause care [29:30]

- Just yesterday, Rachel got back from teaching at the largest internal medicine conference (the [ACP, American College of Physicians](https://www.acponline.org/))
  - More than 20,000 internal medicine physicians
- She was asked to give a course on female sexual dysfunction, and it was wonderful
- She talked a lot about menopause
  - There was no other menopause content at this course
  - There was no course on how to prescribe [HRT]
    - Given everything Peter has done, her colleagues and herself have done to bring it into just popularity
- Patients are coming in asking questions [about HRT], and there wasn’t even a course to learn
  - She can’t say that’s true for GLP-1s or any of these lipid lowering agents
- The problem is you now have a brain drain
  - Because the doctors who prescribed hormone therapy either retired or died, and there was no one they taught ahead of them
- Rachel was very lucky; she had very good mentorship and an incredible experience

***We are now trying to make up for lost time to train people how to write prescriptions [for HRT]***

- So it’s not enough to say, “*Hey, the WHI was misinterpreted and we’ve done a bad thing for women*.”
- People don’t know how to do this and it’s a huge problem
- This is half the population; this is not niche medicine

Rachel explains, “*The fact that menopause medicine is the tiniest little room of subset of gynecology, (which it should not be under gynecology). This is whole body medicine, and yet nobody seems to care.*”

- Peter finds this interesting because he’s taken for granted that he got lucky and had amazing mentors
  - They taught hom how to do this stuff
- But it’s also the nature of his personality to be endless curious and show up in somebody’s clinic for 2 weeks and do this
- Peter has tended to focus on the lost generation of women
- 2 years ago, he had his analysts estimate excess mortality resulting from the number of women who were deprived of HRT because of the WHI
  - Mortality through hip fractures, cardiovascular disease, the entire list
  - The number of lives that were lost, the amount of disability that was incurred
    - Even if you don’t die from a hip fracture, 50% of survivors never regain the same level of function
  - And Peter didn’t even know how to quantify all of the sexual side effects and vasomotor side effects that women unnecessarily endured
    - He didn’t try to quantify them
  - The loss of life and disability incurred was the thing he focused on
  - [in [episode #253](https://peterattiamd.com/joannmanson/#:~:text=By%20Peter%E2%80%99s%20calculation%20it%E2%80%99s%20a%2015x%20reduction%20in%20mortality), Peter estimates HRT results in a 15x reduction in mortality]
    - [This is in women who begin HRT in the transition from perimenopause to menopause and stay on it for 30 years]
- It’s personal to someone Peter’s age because his mother and mother-in-law are in that category
  - They’re the ones that got absolutely screwed by this system
- Peter points out that Rachel is highlighting something equally catastrophic with potentially a greater impact, which is we failed to train a generation of doctors to do anything about it
- And if that’s not reversed, the problem doesn’t get much better

***The data is very clear on this: less than 6% of internal medicine, OB/GYN, or family practice doctors get even an hour of menopause education in their training***

- Peter doesn’t remember learning anything about menopause in medical school
- He did learn that hormones are bad
- Rachel points out: you are taught hormones are dangerous or the bodybuilders take the hormones, the snake oil salesman take the hormones
- We don’t talk about this in real medicine
- Everyone says, “*It’s not my industry. It’s not my thing*.”
- At this internal medicine conference yesterday and all the internal medicine doctors were saying, “*But this isn’t my field. I don’t feel comfortable*.”
- An endocrinologist was standing there saying, “*I don’t feel comfortable doing this*.”
- Rachel said, “*You’re a hormone doctor. That is what you do*.”

**The need for change in the medical field regarding HRT**

- It is so embarrassing
- Rachel has been asked to speak at multiple academic centers to teach on hormone therapy, and every time she’s like, is this real life?

> “*I am a urologist teaching hormone doctors about how to prescribe hormone therapy, and it is real life, and this is why I’m so loud about it, because we have to change this*.”‒ Rachel Rubin

- We need the ICU doctors and the pulmonologists and the heart doctors and all the doctors to know that menopause affects their organs, colon cancer
- Why aren’t GI doctors talking to women that estrogen prevents colon cancer?
- Why are we checking DEXAs at 65?
- Why are rheumatologists not prescribing hormone therapy?
- Because Rachel does a lot of teaching about how to prescribe hormone therapy, she found out recently: ***psychiatrists tell her that their malpractice insurance will not cover them if they prescribe hormone therapy***
  - Her response was, “*Wait a minute. You prescribe postpartum depression drugs, which are progestin based. You do reproductive psychiatry, which means birth control is a part of what you do. And you’re being told you’re not allowed to prescribe hormone therapy when hormone therapy is one of the greatest antidepressants in the history of medicine.*”
  - It is insanity; we’re living in a nightmare

## The underappreciated role of testosterone in women’s sexual health, and the systemic and regulatory barriers preventing its broader use in female health care [35:00]

**Testosterone is important for men’s health and women’s health**

- We’ve talked about 2 hormones a lot [estrogen and progesterone], but there is a third hormone that we haven’t yet talked about that is very linked to these 2 hormones: [testosterone](https://en.wikipedia.org/wiki/Testosterone)
- This doesn’t get enough attention in women

**Before we get into how one should think about replacing hormones, can you talk about the relationship of testosterone to women’s sexual health?**

*What is happening to testosterone levels during this transition from peri to menopause?*

- Rachel is very passionate about this topic
- She loves prescribing testosterone for men’s sexual health
- When we prescribe testosterone for men, remember their gas tank doesn’t get empty, it gets low
  - We are doing off-label testosterone therapy in men unless they have [Klinefelter](https://en.wikipedia.org/wiki/Klinefelter_syndrome) or some significant medical problem
  - And it’s very understood; it’s talked about
- Just 3 weeks ago, the [FDA removed the labeling on testosterone therapy](https://jamanetwork.com/journals/jama/fullarticle/2832503) saying it no longer is a cardiovascular disease risk
  - That’s great news

**⇒** The thing about women and testosterone is, it’s actually not a menopause thing ‒ testosterone is an age-related decline

- In your 30s, you’re starting to drop your testosterone

Rachel clarifies, “*I don’t know who decided that men get testosterone and women have estrogen. We both have both of the hormones*.”

- Peter makes the point: we measure testosterone in ng/dL and we measure estradiol in pg/mL [a unit that is 10,000x smaller]

**⇒** If you normalize those to the same level, women are shocked to learn that they have 10x the amount of testosterone in their body that they do estradiol at peak estradiol

> “*When you put everything in the same unit… Both of us are testosterone- driven beings.*”‒ Rachel Rubin

- We don’t teach this to OB/GYNs
  - Very few know about the role of testosterone in women’s health
- We love to gaslight women and say, well, if you have your period, your hormones are normal
  - Drives Rachel insane
  - Women are told this all day, every day, “*You can’t possibly have a hormone problem because you’re getting your period regularly.*”
- And the reality is that’s not true
- That curve, that curve we were just talking about, testosterone is nowhere on that curve

**⇒** We know there’s a peak of testosterone around ovulation

- That is nature’s way of saying, let’s make a baby

***We know that your libido goes up around ovulation because your testosterone goes up, and there’s an age-related decline in testosterone***

**Another big problem is we give women birth control pills all the time**

- How does birth control work?
- Birth control is high-dose hormone therapy
- We love hormone therapy and birth control, but as soon as you become menopause, everybody’s afraid of hormone therapy
- It makes no sense
- Rachel would argue the hormone therapy we’re talking about in the WHI, that is more synthetic, that has side effects

***Birth control turns off your ovaries and it adds back a final estradiol and a synthetic progestin; it doesn’t add back testosterone***

- To be honest, we are botching testosterone for women along the life cycle

**But if you take someone who’s never been on birth control, their testosterone starts to drop in their 30s, what are they complaining about?**

- It’s not just a libido thing
- We know there are testosterone receptors all throughout the genitals and the urinary tract

**⇒** *Women with low testosterone have an increased risk of:*

- UTIs
- Pain with intercourse or pelvic pain conditions
- Some studies indicate potentially depression and anxiety can increase
  - Testosterone effects on the brain

***We have global consensus (and we don’t agree on too much as a globe) that testosterone in women works for low libido***

- And specifically the data is on postmenopausal women
- But there is data in perimenopause and much smaller studies before that
- The consensus is testosterone works, but everyone has emotions about testosterone

Rachel adds, “*I didn’t think testosterone was a feeling, but apparently it is a feeling for people because people hate talking about it.*”

- And again, nobody taught you how to prescribe it, and there’s no FDA-approved product for women
  - Except in Australia where it’s approved by their governing body
- And so you have a lost art of knowing how to give people back testosterone when they are symptomatic
- Peter thinks this is an area where women sometimes are also a bit concerned about what happens if they take testosterone because testosterone understandably conjures up images of all sorts of things from large muscles, big mustaches, lots of other things

**How do you talk to women about the risks of testosterone therapy?**

- The most common side effect Peter sees in women is acne
- He’s never seen any of the really dramatic side effects, but he does tell women, “*Look, there’s a decent chance if you were shaving your legs every five days, you’re going to be shaving them every three days… If you were kind of susceptible to acne growing up, you might get a little bit more of it and we’ll have to back off*.”
- Rachel is grateful for celebrities because just in the news in the past few weeks, [Halle Berry](https://en.wikipedia.org/wiki/Halle_Berry) says she’s on testosterone
  - [Kate Winslet](https://en.wikipedia.org/wiki/Kate_Winslet) says she’s on testosterone therapy
  - They look pretty amazing and they don’t look androgenized at all

***Rachel has more patients who never start testosterone therapy because of the fear of side effects than actually stop testosterone therapy because of the side effects***

- When we talk about side effects, Rachel tells them, “*Think about a horny teenager. They have these great libidos, but they have some oily skin, acne, but that’s when you get really high with your doses.*”
- We really don’t see it clinically

**⇒** Rachel uses FDA-approved testosterone for men, at one-tenth the dose

- She has women rub it on their leg because if they do get hair on their leg, people are used to having hair on their leg, and so they shave it, they wax it, they laser it, whatever it is that they do with leg hair
- She doesn’t have that many patients stop for acne, oily skin
  - There’s that fear when you get really high in the dose
- She’s not a pellet promoter or user because you get super physiologic levels and she can’t take it out
  - If you get a pellet put in, and if you have deepening voice or clitoromegaly, hair issues, these are the challenges with some of these super physiologic levels
- But when we’re using reasonably dosed topicals, we really see magic happen
- When Rachel gets estrogen and progesterone right for her patients, it is by adding that third piece, that testosterone [that women feel like themselves again]
  - Because your ovary probably does more than 3 things

Rachel explains, “*When we add that testosterone piece, it’s wild. All the patients come back and they say to me, ‘Wow, I feel like me again.’ It’s wild. That’s the piece.*”

- These women didn’t realize how badly they felt
  - They tell her, “*Wow. I didn’t realize how badly I felt. Wow, that was the missing piece*.”
  - She hears it over and over and over again
- Rachel can’t not want that for all women
  - She can’t not want to give them that as an option on the menu

**Do you prefer to rely on the topical version of testosterone, which would be like an** [**AndroGel**](https://www.rxlist.com/androgel-162-drug.htm)**-type product and just dose it at a much smaller dose?**

- Yeah, that’s typically how we do it and how our guidelines look at it
- At the ISSWSH (the International Society for the Study of Women’s Sexual Health, a fabulous organization) you can find any doctor to help you with menopause and sexual health by going to their [website](https://app.v1.statusplus.net/membership/provider/index?society=isswsh)
- They came out with a really lovely [how-to practice guideline](https://pubmed.ncbi.nlm.nih.gov/33814355/) that they took from the global consensus
- They recommend using that FDA-approved testosterone for men and using it at appropriate doses for females
- Rachel likes [testim](https://www.rxlist.com/testim-drug.htm), which is the 1% generic testosterone gel
  - It’s a 5 mL tube of gel
  - Male patients would use the whole tube of gel, rub it on their chest every day
    - Rachel has very few men who do that, by the way; injections, orals, those are much better
  - She tells her female use a blob or 0.5 mL (they can put it in a syringe if they want to dose out that 0.5 mL)
    - They take a blob and rub it on their calf every day
    - The whole tube should last about a week or 10 days
    - It’s not an exact precision science, but the patients can figure this out
- In Rachel’s experience, testosterone takes a while to kick in (for both women and men)
  - She has colleagues who disagree with her on this
  - She would love to know Peter’s experience

She tells patients, “*You need to do this regularly, and I think it’s going to be 3, 4, even 5 months before you’re going to really wake up and say, ‘Wow, this is working. Oh my gosh, someone just walked across the street and I did a cartoon style head turn where my eyes popped out of my head. Oh my gosh, I initiated sex. Wow, that orgasm was easier to have.’”*

- These are the things that patients notice
- She also gets patients telling her that their stress incontinence is slightly improved
  - Why? Because the urethra has testosterone receptors in it
  - We know that for all genders
- Peter definitely agrees that is true for some people
- He has also seen people who within weeks report feeling better
- The only way you could understand this is through blinding
  - We just don’t know how significant the placebo effect is, and therefore it’s hard for him to know within his observation

**What has your experience been with Natesto?**

- [Natesto](https://www.rxlist.com/natesto-drug.htm) is an FDA-approved nasal formulation
  - It’s a nasal gel
  - Peter has had women use it vaginally, nasally
- Rachel reports that it’s gotten harder and harder to find these days
- She has been interested in it
- It turns out that nobody likes to squirt things in their nose (it’s a challenge)
- Any of these topical testosterone formulations, a lot of them have alcohol in them, so Rachel doesn’t recommend putting them on your genitals directly
  - But she does think it needs to be studied
- It’s challenging finding the formulation of testosterone that is low enough from the male side, to use for women at an appropriate dose
  - We have lots of formulations for men

**Why isn’t a female formulation of testosterone being made?**

Rachel jokes, “*Buckle up, buttercup.*”

- We had a billion dollars that was put into it
- A 5-year study that was done at the FDA and it showed it was safe and it was effective
- The [TLDR](https://en.wikipedia.org/wiki/Wikipedia:Too_long;_didn%27t_read) on testosterone is: it’s not that serious
- The FDA came back and they said, “*Oh, women have breast tissue, so we’re going to need 5 more years of data and another billion dollar study*.”
- And every company was like, “*I’m out*.”
- The benchmark was different for men: 6 months

***The FDA just keeps moving the goal post***

## The bias against HRT—how institutional resistance is preventing meaningful progress in women’s health [46:30]

- Rachel mentioned the labeling on testosterone being removed
- The [TRAVERSE study](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025) showed that testosterone doesn’t worsen cardiovascular disease
- The box labeling on estrogen products, which says that estrogen causes stroke, blood clots, heart attacks, probable dementia
- We just got done saying that that study didn’t show that
- So why is that box labeling still there?
- We’re killing women by trying to protect them

**Why do you think this is happening?**

*If you try to ‘steel man’ the case for the other side, where are they in their thinking on this?*

- Medicine has a humility problem
- They don’t like to say, “*I don’t know… Hey, we didn’t know what we didn’t know back then. We’re learning and we’re adjusting*.”
  - They don’t like to evolve in their thinking
- For some reason, women’s health comes with so much bias
- The amount of money that goes into women’s health research is worse than it was 10 years ago

Peter reacts, “*This is paternalistic… I hate to put sociology on top of this*.”

- Peter has spoken with one of the PIs from the [WHI](https://en.wikipedia.org/wiki/Women's_Health_Initiative) and thinks she is by far the most honest broker of that group
  - [[episode #253](https://peterattiamd.com/joannmanson/)]
  - He doesn’t have good things to say about that group
  - He can’t ‘steel man’ their case

Rachel wonders, “*How is this real life?*”

- For example, she met with someone high up at the FDA
  - It was a room full of perimenopausal women
- We presented our case about vaginal hormones
  - Which is basically microdosing hormones, and they prevent UTIs by more than half
  - When you use vaginal hormones, you treat the genitourinary syndrome of menopause
- We said to them, “*Your labeling, this should not have the same labeling of all estrogen products. You should remove the labeling*.”
- And they said, “*Well, we’re really going to need industry to come at us to remove the labeling*.”
- Why do you need industry to remove the box?
- We no longer have industry in this field in any significant way because the [WHI](https://en.wikipedia.org/wiki/Women's_Health_Initiative) destroyed that industry

***So we have a huge problem where you actually don’t have any money [going] towards women’s health***

**The state of research on women’s health in biotech**

- Rachel thinks Pfizer completely fired their women’s health division saying, “*Yeah, we’re going to look at allergy now*.”
- Rachel did a study once on pelvic pain
- We were looking at botulinum toxin and pelvic pain, and she was on the call where they said, “*Oh, we have a new CEO now and women’s health is no longer a priority*.”

***We do have a paternalistic problem ‒ it’s true, and unfortunately it’s not getting any better***

**Comparing research on men’s health to research on women’s health**

- Peter usually does not subscribe to theories like that
- He usually finds himself thinking there are alternative explanations
- But it gets hard to dismiss an argument as follows
  - If the tables were turned, and the WHI was really the MHI (the Men’s Health Initiative), and it produced equally idiotic results, would we be in the same place we are today, or would men have said, “*Oh hell no?*”

Rachel asks, “*The* [*TRAVERSE trial*](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025)*, right?*”

- There were 2 bad studies that were done, horrible studies that made no sense, that showed testosterone had some dangers
- The FDA threw that box labeling on
- Within minutes, they created the TRAVERSE trial
  - It got done in 5 years
  - Within minutes when it was finished and it got published in the *New England Journal of Medicine*, the box was removed

Peter adds, “*And by the way, the TRAVERSE trial’s not even a great trial. I’ve been so critical of the TRAVERSE trial.*”

- [read more in this [newsletter](https://peterattiamd.com/traverse-trial-and-trt-in-men/)]
- Peter thinks you could have come to the same conclusion of the TRAVERSE trial if you knew how to read all of the data before it
- He doesn’t think the TRAVERSE trial added much
- Rachel agrees
- To conclude that testosterone causes fractures makes no sense
  - We know that’s not true
  - We know testosterone helps bone mineral density
- You can make the same arguments of how you look at these studies, how these studies are designed, the flaws of them
- You’re going to do a study for 5 years
- Why are you giving people gels?
- Is that the right thing?
- Why do we care what the people of the Women’s Health Initiative said 20 years ago?
- Why is that even news and why can’t it die?

Rachel explains, “*Because you don’t have enough people like you standing up, you don’t have the internal medicine doctor standing up and saying, ‘This is wrong,’ because they’re not teaching it*.”

- You don’t have the OB-GYN saying this is wrong because they’re delivering babies and women are dying in childbirth

> “*Women’s health, menopause health in particular, is important to nobody. When it’s nobody’s problem, nobody takes ownership of it*.”‒ Rachel Rubin

- Peter believes this is going to changes
- A great quote said, “*Funeral by funeral, science makes progress.*”
  - That’s not a great explanation for what’s about to happen temporally because it’s going to be a while before everybody who held that belief in their soul is no longer around
  - But it does give him hope that a new generation of women will come along and take ownership over their health

**Peter has seen a change in 10 years**

- 10 years ago when he was prescribing hormones to women, you cannot believe the fights he would have with their other doctors
  - They were scolding him like, “*How dare you?*”
  - It came with an arrogance, a lack of willingness to even look at the data, which Peter found ironic
  - This arrogance of I’m going to scold you, but I know nothing, and I’m not actually willing to have a discussion with you
  - Peter was like, “*Great. Turn to figure two in the JAMA paper and let’s look at this and look at the appendix and look at the supplemental data. Are you seeing the same thing I’m seeing? Can we at least agree on the facts?*”
  - Rachel replies, “*No, we can’t*.”

**Rachel does sexual medicine, so she looks at the whole patient (everything)**

- She would never say to them, “*Hey, you have to stop this beta blocker right now because it’s causing your erectile dysfunction*.”
  - Even though the beta blocker may be worsening his erectile dysfunction
  - She would never say, “*Stop this medicine. It’s hurting you.*”
- She would talk to their doctor

***There’s something about hormones that doctors who know nothing feel very confident in saying, “You can’t be on this. You must stop this.”***

- Without even having the curiosity of wondering if the person who prescribed it actually knew what they were talking about
- It’s is everywhere; we see this all the time

## How the medical system’s neglect of menopause care has opened the door for unregulated and potentially harmful hormone clinics to take advantage of underserved women [53:30]

- Unfortunately the nature of everything just discussed has created a fringe movement
- Peter has seen a lot of doc-on-a-box hormone practices that are putting women at risk
  - They are doing bad things to women in the name of doing good
  - Peter doesn’t believe that these are inherently bad individuals, they’re ill-informed
  - They’re just not that bright, and maybe some of them are just actually charlatans and they’re seeing an enormous opportunity here

Peter shares, “*As a general rule, I tell patients, be very, very suspicious of a doctor that is selling you hormones. Be incredibly suspicious of any physician who has their own compounding pharmacy within the practice and is giving you compounded formulations and also making money on it.*”

**Talk a little bit about the fringe side of this world**

- People care about their pain points; people want to feel better
- There’s a whole supplement aisle at CVS that makes all these wildish claims that we’re going to help you with everything
- And the reality is
- Rachel just got done saying your gynecologist and your internal medicine doctors are going to, in that 10-minute visit, tell you that you don’t need this; this is not going to help you
- And so enter the fringe people, the snake oil salesmen, the people who are doing wildly inappropriate things

***That doesn’t mean the hormones themselves are bad, it just means we have a marketing problem here***

- If we are not doing it and helping people, they hear their friend did it, they hear their neighbor did it, and they say, “*I want what she’s having.*”

> “*This is why we call ourselves the Menoposse*. *This is why we teach so loudly is because we’re trying to bring it back into evidence-based medicine and say you can actually do this quite reasonably.*”‒ Rachel Rubin

**⇒** In fact, there are many FDA-approved products that work much better, that are more regulated, that are totally safe

- They should be covered by your insurance
- The problem is, it’s too quiet
  - No one is giving people answers
  - No one’s even looking at the questions
- So then the fringe people take over and are unfortunately doing very inappropriate things
- [This is a problem in] men’s health too
  - As a urologist, we see shot clinics and all these wild [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma) clinics and testosterone pellet clinics and compounded pellets and all of these things because Rachel’s colleagues are not doing enough to take care of men’s sexual health

***These clinics exist to prey on those patients who deeply want to connect and get their answers, which is why Rachel and her colleagues are even loud about it for everybody***

- Peter finds the number of online testosterone clinics mind-boggling, and a lot of them are prescribing second tier drugs

Rachel points out, “*The people who need it are not being offered it, and the people who don’t need it are abusing it. And that is true for hormones for everybody.*”

**Numbers of women on HRT**

- Rachel talked about this at the last menopause meeting

**⇒** Less than 4% of women are on hormone therapy right now

- 4% of women who would theoretically be required
- That’s worse than Peter would have guessed
- It’s worse than it was 10 years ago
- Rachel did the same calculations as Peter when she was in the Uber on the way over
  - There’s something like 84 million women over the age of 40
  - Divide, 84 million by 3,000 (it’s a big number [28,000])
  - We can’t see patient panels of 27,000 people
    - [this number is a small % of 84 million]

*We need people to step up. Who should be writing estrogen prescriptions?*

***Peter and Rachel both agree that every doctor who sees a woman of that age should be prescribing HRT***

- Who actually does? Nobody.

## The HRT playbook for women part 1: progesterone [57:15]

- Peter is not saying he does it right, because he doesn’t think there’s a right way to do it
- He mostly wants to hear how Rachel does it because he bets she’s way better at it

**⇒** [Progesterone](https://www.rxlist.com/prometrium-drug.htm) is the easiest of the lot

- If a woman has a uterus, you have to protect that endometrial lining
- So even if she’s in the camp of women who don’t notice being on progesterone, you have to be on progesterone
  - We’ll come back to IUDs and progesterone coated devices and things like that.
- Let’s just talk about the way you get progesterone

**Is there any reason when giving oral progesterone to use anything other than micronized, FDA-approved progesterone orally?**

- What’s lovely is we need a toolbox because not everybody responds to the same thing
- Rachel loves [micronized progesterone](https://www.rxlist.com/prometrium-drug.htm); it’s a fabulous product
- It’s is her go-to first line
- Sometimes we need to put it vaginally instead of orally to help with some of those sedating side effects
  - You can avoid going to the brain if you put it vaginally

**⇒** Rachel typically starts with 100 mg oral progesterone (depending on the dose of estrogen)

- Some people say if you’re going higher with  your estrogen, you may need to do 200 mg of progesterone (the data’s not very clear)
- You can dose it every single day (typically 100 mg every day)
- A lot of data show you can do it cyclically: 200 mg for 12-14 days out of the month
- Both are fine

***Many patients say they feel better doing 100 mg progesterone every day because it can help with sleep and anxiety reduction***

**Do we believe that 100 systemically is sufficient to oppose estrogen?**

- There’s not enough data and we need more
- If patients bleed, it’s a nice tell that maybe they need more progesterone

**⇒** If you take it with fat or you take it with something to eat, it absorbs better because progesterone is not absorbed very well

- This is why we always had synthetic progestins in the first place
- We’re still learning the capabilities of micronized progesterone

***But according to most menopause specialists out there, they typically will use 100 mg every day, or 200 mg 12-14 days of the month***

- The only thing Peter does differently is he starts women at 50 to 100 mg and will generally take them to 200 mg if tolerated
  - If not, he keeps them at 100
- He finds that women who are in that ⅓ to ½ group who are very positively selected towards progesterone, they feel fantastic at 200
  - The most notable improvement is sleep
  - Rachel agrees

> “*Most women are just over the moon with how well they sleep.*”‒ Peter Attia

- Hair gets thicker, mood improves

**Let’s talk about the other subset of women [who don’t tolerate progesterone], and this is a real subset**

- In Peter’s patient population about 10-20% for whom if you bring progesterone in the room, something goes wrong, their mood really changes
  - In some cases become depressive
  - More commonly what they tell me is, and I’m quoting them, this is not Peter saying it, “*I become a raging bitch. I’m worried I might kill my husband.*”
  - So for those women, he thinks progesterone is a bad idea, and then he uses a [progesterone-coated IUD](https://en.wikipedia.org/wiki/Hormonal_intrauterine_device)

*Are you doing that or are you using a suppository at that point?*

- You can do either
- You can say, “*Hey, try taking this vaginally and see if that goes away. See if you’re no longer feeling anger or bloated or have irritability*.”
  - And so vaginally can be an option
- Rachel loves progesterone-coated IUDs ‒ they’re great in perimenopause
- Why? Because people think that you just lightly dance into menopause
  - It is like bloody murder hell scene ‒ it can be terrible
  - You can bleed the whole month
  - You can bleed heavy
  - You can bleed when you’re least expecting it
- The IUD is very nice because it will stop bleeding
- And so you throw an estrogen patch on and some testosterone, and that’s a really great perimenopause plan
- And you get birth control, which is very important
- You can add micronized progesterone to the patient who gets good sleep, even if they have an IUD, that doesn’t add danger (Rachel loves that)

*There’s another synthetic progestin you can use as well*

- Rachel has seen people do things like [Slynd](https://www.rxlist.com/slynd-drug.htm) (which is a progestin-only birth control pill); add a patch and testosterone to that as well
- Synthetic progestins sometimes can have mood side effects as well, so they’re not completely benign for all people

Rachel asks, “*Have you heard of* [*Duavee*](https://www.rxlist.com/duavee-drug.htm)*?*”

- It’s an oral estrogen, but it also has what’s called [bazedoxifene](https://en.wikipedia.org/wiki/Bazedoxifene#), which protects the uterus but is not a progesterone-based medicine
  - Rachel wishes they were separate; she wishes we could just give bazedoxifene, alone so that you don’t have to use oral estrogen if you don’t have to (any pharmaceutical reps listening?)
- Oral estrogen is not evil

**⇒** Rachel is a sex doctor and we know that transdermal estrogen is a little better for sexual function

- That’s why she’s a big fan of transdermal products
- Rachel has had patients do that who really don’t tolerate progesterone, and then you can just use estrogen only

Peter asks, “*Are you referring women who are on what potentially might be a low dose of progesterone to their GYN for endometrial ultrasounds on some regular interval just to look for hyperplasia or anything like that?*”

- We really don’t like to look for things
- The nice thing about endometrial cancer, from what Rachel understands, is it bleeds (again, she’s putting her urology hat on, she is not a gynecologist)
- Now, if you bleed and you just started a new hormone therapy, it’s probably okay
- Rachel likes to know if there’s any structural things going on
  - Do you have a polyp?
  - Do you have a fibroid?
  - Is your lining super thick?
- If you’re in perimenopause, you still should be bleeding
- So it’s that challenge
- Rachel doesn’t go looking for things that aren’t bleeding because she doesn’t necessarily want to find thing

***At this point, there’s not necessarily a reason for routine surveillance***

- Because if your lining is, say, 6 millimeters and you’re not bleeding, are you really going to put that woman through a biopsy and through a hysteroscopy?
  - And those have significant pain and problems that go with that as well

**Anything else you want to say about progesterone?**

*Do you start it concomitantly with the estrogen? Do you like to start one before the other?*

- Rachel likes to start one before the other in general because she likes people to know what’s doing what (Peter agrees)
- When someone comes to see you and says, “*Give it all to me*;” it’s always a disaster every time
- Rachel likes to stack it
- And again, you’re not going to cause endometrial cancer in 3 months of using just estrogen
  - You’re talking about something that takes years and years and years to develop, and even that data is not that clear cut
- She will often start with the estrogen
- Sometimes she’ll start with progesterone if sleep is the major issue
- But she finds the vasomotor symptoms, it’s such a big deal to get rid of those, so often starts with estrogen and then slowly adds in the other hormones
- Peter is really happy to hear he’s following her playbook already
  - He almost always starts with estradiol and we muck around for a while till we get it right
    - Because that’s the hardest to get right (in his opinion/experience)
  - Then we fiddle with progesterone and then testosterone if they’re not already on it
- But some women are coming into perimenopause already on testosterone

## The HRT playbook for women part 2: estradiol [1:05:00]

- There are 3 estrogens: [estradiol (E2)](https://en.wikipedia.org/wiki/Estradiol), [estrone (E1)](https://en.wikipedia.org/wiki/Estrone), and [estriol (E3)](https://en.wikipedia.org/wiki/Estriol)
- The FDA only has a battery of approved products around the second estrogen [E2], which is the dominant estrogen
- There’s no FDA-approved product for estrone, and there’s no FDA-approved product for estriol, but there are plenty of compounded opportunities around that

***The most common of them is referred to as*** [***Bi-Est***](https://www.uspharmacist.com/article/biest-80-20-cream) ***(Bi-Estrogen), which is an 80/20 mix of estriol and estradiol***

**What is your take on why that product (Bi-Est) exists?**

*Do you view that as a reaction to the WHI? How do you think about it?*

- Rachel agrees that what happened is the Women’s Health Initiative happened and hormone therapy all went into the underground (to the alley)
- One of the ways that these back alley doctors did it was saying, “*Oh, we’re using the safer version. We’re using this compound and we’re going to make it 80/20, and we’re going to use the more safe option.*”
- By the way, Rachel hasn’t seen that data and there is no data on Bi-Est in large trials that’s going to tell you what it does
- They just decided to use it
- Rachel doesn’t actually blame those people if they had no alternative
  - If she were in the middle of the desert and was having horrible symptoms and had the options of nothing or a Bi-Est cream, she’d probably slather the Bi-Est cream on
- Rachel doesn’t prescribe Bi-Est cream because she hasn’t needed to
- If she has a patient who is using it, they come to her and they’re feeling great and have no problems
  - She’ll say, “*Well, do you want to save some money? We could change you to a different formulation.*”
  - Sometimes if they’re having symptoms, she’ll check their levels and find their estradiol level is essentially zero (<5)
  - Then she’ll tell them, “*Listen, I think you’re just using fancy lotion. I think you’re paying a lot of money to put nice lotion on you, and I don’t know that it’s protecting your bones.*”

***If you are using this to protect your bones or to stop your hot flashes or to help with your sexual health, maybe we use the formulations that are a little bit better studied and that we know are absorbing in your body because we can prove it***

- We have FDA-approved options, and they’re covered by insurance most of the time

Peter doesn’t use Bi-Est at all

- He has used it occasionally in the past (10 years ago), largely in women who were terrified of HRT
- There’s no human data that support what Peter is about to assert
- He says this because one can look at a whole bunch of biochemical charts and tables and talk themselves into anything being true
- There are biochemical arguments to be made that estrone, and in particular, one of the metabolites of estrone (he thinks it’s [4-Hydroxyestrone](https://en.wikipedia.org/wiki/4-Hydroxyestrone)), is the estrogen that is driving **breast cancer**
  - So in an estrogen-sensitive breast cancer, given that you have so many estrogens, is it more likely that one is responsible than another?
  - The answer is, oh, some of the data suggests it’s 4-Hydroxyestrone
- Estriol has no biochemical path to even get there
  - In other words, there are no series of enzymes that can convert estriol into 4-Hydroxyestrone
- Of course, there are pathways that will turn estriol weakly into estradiol, so maybe you get a little bit more

***This is a long-winded way of saying there’s no reason at all from an evidence perspective to use Bi-Est***

- Peter doesn’t use it
- He used it one in a woman who had breast cancer and was adamant that she needed hormones
  - Symptomatically, she seemed to need it and he felt it was reasonable to compromise
  - For what it’s worth, she got insanely better on the Bi-Est
  - How much of that was from the estriol? How much of that was from the estradiol?
    - He has no idea

**When Rachel teaches physicians how to use HRT**

- She’s holding their hands, saying, “*You can do this. You can write these prescriptions.*”
- And one of the things that I just keep coming back to is the sentence, “*What are you afraid of?*”
  - When someone asks, “*Well, can I do it in this patient?*” or “*Can I use this product?*”

> “*In menopause medicine, the reason we’re all struggling is we’re not yet at an algorithm, or a playbook, as you say, that it’s a one-size-fits-all*.”‒ Rachel Rubin

- What’s so sexy about this field is we actually have to use our brains, we have to talk to people, we have to get to know what’s bothering them, and we have to do the right tools for them
  - Which may be different in each person
  - Because you have to also understand what are your patients afraid of? (because that is the only thing that  matters)
- We take risks all the time
  - Rachel took a risk taking a car to get here
  - If you ever drink alcohol, you are taking a risk
  - We all take these calculated risks, and we all have different calculations.
- Rachel loves to push people
  - If a patient comes in on Bi-Est, are you afraid you’re going to hurt this patient?
  - She doesn’t think it’s going to hurt them necessarily, but she doesn’t know what’s in that compound
    - If the top of that bottle is the same as the bottom of that bottle
  - She doesn’t know if it’s good for her bones
  - She doesn’t know if it’s absorbing in the way it should be
- She does have studies on FDA-approved estradiol
- Then it becomes, “*What am I afraid of with the patients?*”
- What are you afraid of about the Estradiol?
  - Are you afraid of cancer?
  - Because you know in the Women’s Health Initiative, people who used estrogen had a decreased risk of getting and dying from breast cancer
  - Rachel points out, “*Our patients don’t know this*.”

**Peter thinks this is one of the biggest limitations of how he talks about Medicine 2.0, which is, very few people are conditioned to ask the question, “*****What is the risk of not acting?*****”**

- We have a reasonable idea of what is the risk of doing X? What is the risk of doing Y?
- Although, in this particular example, we seem to get that patently wrong
- What’s the risk of not doing something is very significant

**All the different ways a woman can get estradiol through an approved, tested, chemically sound means**

*A little bit of nomenclature*

**Systemic estrogen**: hormones for your whole body

- When we’re talking about hormone therapy it can be called hormone replacement therapy (HRT) or menopause hormone therapy (MHT) or simply hormone therapy
- That’s estrogen for your hot flashes, for your bone protection, for your skin, hair, and nails

**Local vaginal hormones**

- That’s a whole other topic that Rachel hopes they talk about later because it’s her favorite one
- Local vaginal hormones are used to treat the genitourinary symptoms of menopause

**⇒** Those are safe for every human on earth, including your 99-year-old mother-in-law in the nursing whom, who could potentially die of a urinary tract infection

- These are the 2 separate areas

**Options for systemic estrogen**

- The big ones in the toolbox: patches, gels, rings (which go vaginally), oral estradiol
- There are injections of [estradiol valerate](https://www.rxlist.com/delestrogen-drug.htm#description) or [estradiol cypionate](https://www.rxlist.com/depo-estradiol-drug.htm)
  - That’s the old-school way that Rachel uses sometimes
- Each one has pros and cons
- It’s nice to have the toolbox, because not every product works for every patient

***The key is is getting it right for that patient, because you need something that they’re going to do, and that they’re going to do it for a long time; these are not things that you just do for a weekend***

## Oral formulated estrogen for systemic administration: risks and benefits [1:13:15]

**Oral formulated estrogen**

- Peter doesn’t use it much; he used to use it a bit more than he does now
  - Sometimes he would use it for women whom they were struggling to get the right dose on something else and he just needed something to get them through the weekend (while they readjust their cream, patch, or whatever)
- Rachel doesn’t use oral estradiol much, but that’s not to say that it isn’t useful
- It is very useful, and it’s underused
- For example, people are used to taking birth control pills, they like pills

***For a healthy person with no major risk factors or cardiovascular issues, taking an oral estrogen really is not going to increase their level of blood clots, or heart attacks, or anything like that at any significant worrisome level***

**⇒** The risk of a blood clot is less than the risk when taking a birth control pill

- Given the ubiquity with which women are on birth control pills, it shouldn’t scare you
- We tend to blow it out of proportion

*What is your patient selection criteria on that? When is the risk a little too high?*

**⇒** Rachel tends to always start with [transdermal estrogen](https://www.rxlist.com/esclim-drug.htm) ‒ this is her sex doctor hat

- Because we learned from a study called the [KEEPS trial](https://pubmed.ncbi.nlm.nih.gov/25069991/) where they looked at oral estrogen versus transdermal estrogen
  - They found there is a slight increase in blood clots with oral estrogen, but sexual function is better with transdermal estrogen
  - And that’s because of what happens to [sex hormone-binding globulin (SHBG)](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)
- When you take oral estrogen, it goes through the liver
  - We talk a lot about [first-pass metabolism](https://en.wikipedia.org/wiki/First_pass_effect)
  - Lots of things go through the liver when you take medications
  - In this one, in particular, it can pump out more clotting proteins

***If you’re at any risk of blood clots, just like birth control pills, if you’re a smoker, if you are overweight, if you have a genetic predisposition to blood clots, we’re not going to use an oral hormone product***

This is an area where Rachel would love to see research

- She was speaking at a [Harvard testosterone course](https://hmstestosteronecourse.com/) with [Abe Morgentaler](https://connects.catalyst.harvard.edu/Profiles/display/Person/87781) and [Mohit Khera](https://drmohitkhera.com/about/); she was speaking about women’s testosterone use
  - [Mohit was the guest on [episode #260](https://peterattiamd.com/mohitkhera/)]
- And the speaker who was there to talk about transgender hormone therapy talked about **sublingual estrogen**
  - Rachel ran to the microphone and said, “*What are you talking about? I’ve never heard of sublingual estrogen. There’s no product. What are you saying?*”
  - He says, “*Oh, you just take an oral estrogen tablet, and you put it under your tongue like a Tic Tac and you let is dissolve, and it doesn’t go through the liver, and it works fabulously to increase blood levels*.”
  - Rachel thought that sounded amazing

 Peter asks, “*And it doesn’t drive up* [*SHBG*](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) *presumably?*”

- Presumably, because it doesn’t go through the liver, which actually if you think about it logically
- If you take a high dose estrogen ring, and you put it in a vagina, same thing
  - You absorb estrogen vaginally
  - What’s the difference there? A sublingual estradiol
- Rachel thinks it’s fascinating
- She doesn’t have many patients on it
- She would love to see data look in that direction because it’s cheap
- And you can get away with a lower dose
- She doesn’t have patients on this and hasn’t seen any studies on this
- This guy was using it for transgender hormone therapy at a much higher dose
  - Probably 1 or 2 mg [BID](https://revive.gardp.org/resource/dosing-bid-tid/?cf=encyclopaedia)
- If she were playing with it, she would be nervous and probably do 0.5 twice a day and check the levels (this is not what she does in her clinic)

## Topical and vaginal estrogen delivery options: benefits and limitations, and how to personalize treatment for each patient [1:17:15]

**What are the challenges of using creams, and patches?**

*How do they limit women’s activity levels?*

- Rachel used to have this whole talk she would give women about what she thought was the best way to maximize the absorption of the cream, and what she wanted them to do before they put it on
  - She wanted them to have a shower, and she wanted them to exfoliate their inner thigh
  - This whole routine was probably so elaborate that it decreased compliance
- It’s true for men and testosterone, we often find that they don’t absorb well through the skin
  - Unfortunately, we don’t know who those people are
  - In some people, they absorb beautifully ‒ they get these beautiful levels and they feel great

Rachel always tells patients, “*Here’s the menu… We have to tinker to get it right for you, because you’re not like anybody.”*

**Twice-weekly patches [transdermal estrogen]**

- Rachel finds that patients like them better

Pros:

- What’s nice about patches is you have a wide variety of doses that you can play around with
- When she starts patients on hormones, she typically chooses a medium to medium-low version
  - Because if you go too high, initially, they get breast tenderness, and they get really annoyed with you, and then you have to backtrack
  - So, she always titrates up a little bit as we need to

Cons:

- For some people, they don’t stick well
- For some people, they don’t absorb well
- Some people feel that they drop off
- If you chance it twice a week, some people feel they’re getting a little lower
- Peter notices that women who use the sauna, who are very athletic and exercising like crazy, physical adherence is a problem
- Some people are allergic to the adhesives.
- Some people love patches

Rachel explains, “*Again, you have to have a menu. If you’re going to a doctor, and they give you one type of hormone therapy, and that’s the only type, please run. They need to know the menu, because it’s not a one-size-fits-all*.”

**Estrogen gels**

- There are a number of different gels
- The brand name [Divigel](https://www.rxlist.com/divigel-drug.htm) goes on your thigh
- There’s [Estrogel](https://www.rxlist.com/estrogel-drug.htm), which goes on your arm
- There’s [Evamist](https://www.rxlist.com/evamist-drug.htm), which is an aerosolized spray that goes on your arm

Pros:

- Gels can be really nice, because it’s dosing every day

Cons:

- The challenge is sometimes they take a little bit to dry
  - So, if you’re a busy person and you want to rub something on, and you want to run out
- Not everybody wants to do something every day
- You have to get it into their routine, and sometimes you got to work up to it
- Sometimes Rachel’s patients will use patches, but when the summertime hits and it’s hot and muggy, they’ll switch to the ring, or they’ll switch to a gel

**Vaginal estrogen rings**

*What’s the case for not just using the ring all the time?*

- Rachel loves the ring
- There are 2 types of ring
  - 2 FDA-approved rings
  - This is important because sometimes your pharmacist messes this up

Pros:

- A ring, just like a birth control ring, you set it and forget it
  - You put it in the vagina
  - In the vagina does not feel it like a tampon, you don’t feel it, and it just stays in for 3 months at a time
  - You push it up against the cervix and it settles in and finds a place
- By the way, if you have penetrative sex, most people don’t take it out, they don’t feel it
- Nobody’s bothered by this thing
- 1 – There is a [Femring](https://www.rxlist.com/femring-drug.htm), which is a high dose ring, and it comes in two doses, 0.05 and 0.1 [mg per day, a systemic estrogen dose]

**⇒** Remember, if you have a uterus, you need progesterone to protect the uterus

- 2 – There’s an [Estring](https://www.rxlist.com/estring-drug.htm), which is a 2 mg localized estrogen ring [7.5 mcg per day, 2 mg total reservoir, not a systemic dose]
  - You do not need progesterone, if you have a uterus, because it’s just treating the genital urinary syndrome of menopause
  - So, it’s *not* treating your hot flashes, it’s not protecting your bones, it’s not going to help your night sweats, but it’s going to prevent [UTIs](https://en.wikipedia.org/wiki/Urinary_tract_infection)

**⇒** It’s important that you know the difference, because the pharmacist sometimes won’t, and he’ll give you the wrong ring, which could be catastrophic, if they think they have a systemic ring, but they have a local ring

- They look a little different
- The systemic ring is a high dose and the local one is a low dose
- You change them at the same frequency, every 3 months
- Now there’s a company right now studying a product that’s a one-month ring that has both estrogen and progesterone in it, which is very interesting
  - Rachel is not at all affiliated with it
  - She’s curious to see where the research goes with that

Cons:

- Rachel loves the ring, but there are women who you show them the ring and they want nothing to do with it
- Women who have used rings for birth control love the idea

*What Rachel’s patients say about the ring:* it literally stops working that last month

- Everyone is a little different, but she has patients whose hot flashes come back in the last month on the ring

Peter asks, “*Why not just swap it every 2 months?*”

- It’s expensive, and a lot of times insurance doesn’t cover the ring
  - It’s about $180 cash price when you use an online pharmacy called [Transition](https://patients.transitionrx.com/home)
- Sometimes patients will slap a patch on, or a gel at the time to overlap
- They’ll change it early, or they’ll add a different therapy, or they’ll stop using the ring altogether

*This is where checking levels is actually helpful*

- It’s perfect for 2 months
- Again, there’s the book answer, the Instagram answer, and the Dr. Rubin answer
- Peter is sure there are a couple of his patients that would volunteer to do this where we do twice a week levels for 3 months while they’re on a ring, and just watch the curve
- Rachel explains, “*You have a 0.1 ring in, and you should expect estrogen levels of 60, 70, something like that.*”
  - You’ll see an estrogen level of 13 ‒ this is not working
    - The patient will complain of hot flashes, night sweats, their symptoms will come back

***Rachel sees a lot of ring issues with dosing for hot flashes, night sweats***

- Another problem is if you have any kind of [prolapse](https://en.wikipedia.org/wiki/Prolapse), the ring can fall out during bowel movements (other things like that)
  - If there’s not enough space in there
  - That can get expensive
- Rachel had an ultramarathon runner who loves her ring message her, “*I feel awful. Something’s not right. I don’t feel like myself again.*”
  - They checked her level and her estrogen was undetectable
  - When she went to change the ring, she couldn’t find it
  - She probably had a bowel movement, it fell out, she didn’t notice it, and then her levels dropped
- It’s where the detective work helps you figure out what’s going on with your patients

***The ring is not perfect for everybody, but Rachel loves the ring. If you’re in perimenopause and you get your progesterone from an IUD, a systemic estrogen ring, you put a little topical testosterone on every morning, it’s really a set it and forget it.***

- It’s very low maintenance and relatively inexpensive

## How to navigate hormone lab testing without getting misled [1:24:15]

- There are 2 things Peter wants to talk about on the lab front
- He is really fastidious about using [LC/MS](https://en.wikipedia.org/wiki/Liquid_chromatography%E2%80%93mass_spectrometry) for estradiol [[Quest example](https://testdirectory.questdiagnostics.com/test/test-detail/30289/estradiol-ultrasensitive-lcms?cc=MASTER)]
  - He does not want to use the [ELISA](https://en.wikipedia.org/wiki/ELISA)-based assay at all [[Quest example](https://testdirectory.questdiagnostics.com/test/test-detail/4021/estradiol?cc=MASTER)]

**Are you pretty meticulous about that, or do you find that you’re just happy checking any Estradiol?**

- Rachel gets the sensitive estradiol [LC/MS]
- That’s what Peter gets for everybody, and the same with testosterone

**⇒** *PSA for both physicians and patients*: if you do not use the LC/MS assay (which is very sensitive, the liquid chromatography assay), the results can be truly meaningless

- The reason is that the ELISA-based assays are so susceptible to interference from other molecules, and there are some really known obvious supplements that completely obscure the findings
  - For example: biotin, which is in a lot of things, will render a non-LC/MS test irrelevant
  - There are other things that we are not fully aware of

***It is worth splurging and paying the extra maybe it’s $5, or $10 (would be the cash price difference on that test), but absolutely make sure when testosterone and estradiol are being measured, you actually have to go through the hoops and make sure you’re ordering the LC/MS test***

**Controversy about hormone therapy**

Rachel points out, “*There’s a lot of disagreements when it comes to hormone therapy, how to properly do hormone therapy, how to check for hormone therapy.*”

- And for anyone who is going to say mean things about her on the internet from this podcast, she truly believes that most of us agree on 98% of this

> “*Truly, we want women feeling better. Most of us believe the data that hormones, the benefits outweigh the risk*.”‒ Rachel Rubin

- There’s 2% disagreement
- Part of it is in the what we don’t know yet
  - The unknown and the curiosity
- Lab testing is one of those issues

Rachel explains, “*The book says never check labs. If your doctor checks labs, they are really doing something wrong. You should only care about symptoms.*”

- Then you have the fringe that are doing all saliva-based testing, every minute check labs, do all these expensive labs, which Rachel does not agree with

***Like Peter, Rachel’s curiosity with labs is fascinating***

- When you can capture these perimenopausal fluctuations, and show the patient, “*The reason you feel so terrible is because your estrogen was 1000 and now it’s zero and that hurts.*”
- Does she need numbers to know that’s what’s happening?
- It actually helps patients quite a lot for them to look at this and see the data
- Peter doesn’t buy into the idea that you need to be spending an inordinate amount of money on esoteric, non-validated labs

**⇒** All you need to do is go to Labcorp, go to Quest, you can go to any CLIA-approved lab that knows how to the assay correctly

***Peter tells patients that the symptoms are the most important things, but the numbers help direct his thinking***

- This is how he manages thyroid [hormones]; this is how he manages sex hormones

**How Peter thinks about advice given on social media**

- There’s a caricature of the Dunning-Kruger curve that Peter finds so helpful [shown below]
  - For the folks who aren’t familiar, on the X-axis, you have experience, and on the Y-axis, you have confidence
  - In the character version of the representation of this curve, you, initially, have a huge spike, which then falls into a valley, and then a slow rise
  - The huge spike is referred to as the peak of Mount Stupid, followed by the valley of despair, and the slope of enlightenment

![](https://peterattiamd.com/wp-content/uploads/2025/05/f2-rachelrubin-1024x586.png)

**Figure 2. The Dunning-Kruger Curve**. Image credit: [Facebook](https://www.facebook.com/drgarth/posts/you-have-probably-heard-of-the-dunning-kruger-effect-it-is-a-type-of-cognitive-b/1210643660425020/)

Peter explains, “*It’s important for people to understand that when you are on Instagram, and YouTube, disproportionately, you are seeing people at the peak of Mount Stupid, which is to say they have very low experience, insanely high confidence.*”

- Peter makes up an example
  - These are the ones telling you that TSH must be between 0.4 and 1.9, and if it is any bit above 1.9, you have hypothyroidism, and you need to be on Armor Thyroid, or Nature-throid, or whatever
  - And none of that is correct

> “*You just have to take care of enough patients for enough years to get humbled enough to know that whatever you think you know with rigidity is probably wrong*.”‒ Peter Attia

**Rachel agrees about the importance of humility in medicine**

- She is famous and her patients love her because she spends a lot of her day saying, “*We don’t actually know. This is a data-free zone. Here’s what I think. Here’s how we’re going to use logic. Here’s the tools in our toolbox.*”
- There is that ability to really know the data so well to truly understand there’s a lot we need to figure out

***That’s why Rachel has a research group, and that’s why they’re trying to answer these questions, because we have more questions than we have answers***

- But she also needs to get her patients feeling as good as possible, and it’s addicting

**Peter’s approach with patients**

- We focus relentlessly on the symptoms
- We care what the estradiol level is
- We also think the [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) is a very helpful marker
  - If a woman’s FSH is 78, and her estradiol is 40, Peter is inclined to believe she needs more estrogen, especially, if she’s saying, “*I think I feel a bit better. I’m just not sure*.”

**⇒** But nothing tells him he’s given her too much estrogen more than her saying her breasts hurt

- And that’s the advantage of doing it with these short-term estrogens, because he can pull it back really quickly
- Peter would consider himself a minimalist essentialist on labs, but not an absolutist in either direction
  - Rachel loves that ‒ it’s reasonable and logical

**This is why it’s confusing for patients on social media**

- People think they hear they need to use an estrogen gel, but they use a patch
  - Should they switch?
- Again, it’s not serious; there is a menu
- It’s good to get educated and learn about all the different options so you can see what’s right for you

***Expecting that one doctor will give you all the answer is not going to happen***

## The wide-ranging symptoms of menopause—joint pain, brain fog, mood issues, and more [1:31:45]

- The reality is doctors don’t even know the symptoms of menopause
- Patients don’t even know the symptoms of menopause
- The person who was doing Rachel’s makeup this morning, she’s like, “*I just feel awful. I feel like an old person. I’m not sleeping. I’m not fun anymore. I can’t drink. Joints are achy*.”
  - Rachel said, “*Welcome to you need hormone therapy*.”
- Rachel is always teaching, no matter who she is with

**⇒** You have hormone receptors throughout your whole body, it is a whole body experience

- There’s hot flashes and night sweats
- By the way, hot flashes are not just a nuisance
  - That is probably a neurologic [vasculogenic](https://www.merriam-webster.com/medical/vasculogenic) event
- The worse is your risk of cardiovascular issues, and things like that
- Joint pain is a huge one
  - Rachel never thought as a urologist, she would treat so much joint pain
  - Her patients come in all the time and say , “*Oh my God. I don’t get out of bed feeling old. I don’t feel creaky. My joints recover again after I exercise*.”
- Again, empty gas tank
- Inflammation
- Hormones are nature’s joint fluid, almost like brake fluid (back to the car analogy)
- Your eyes need lubrication, your eyes need wax, your vagina needs lubrication, your joints actually need lubrication
- Think of horny teenager ‒ you’ve got oils, oily skin
- Hormones create these oils, vaginal lubrication, oil for your skin
- There are androgen receptors in your eyeballs, in these [meibomian glands](https://en.wikipedia.org/wiki/Meibomian_gland)
- Rachel thinks of hormones like fluid, and when the hormones go too high or too low, it dries everything out
- You get joint pain, you get [frozen shoulder](https://en.wikipedia.org/wiki/Adhesive_capsulitis_of_the_shoulder), you get [plantar fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis)
- Rachel’s colleague [Vonda Write](https://www.surgeon.drvondawright.com/about) recently [published](https://pubmed.ncbi.nlm.nih.gov/39077777/) on the musculoskeletal syndrome of menopause

![](https://peterattiamd.com/wp-content/uploads/2025/05/f3-rachelrubin-1024x360.png)

**Figure 3. Musculoskeletal syndrome of menopause**. Image credit: [*Climacteric* 2024](https://pubmed.ncbi.nlm.nih.gov/39077777/)

**⇒** The musculoskeletal syndrome of menopause is the idea that so many women in their 40s and 50s, everything starts to break down because the gas tank is empty and inflammation increases

**Rachel’s summary of menopause symptoms**

- Musculoskeletal symptoms
- Sleep issues
- Mood issues
- Bleeding changes
- Low libido
- Orgasm and arousal problems
- Pain with sex increases like crazy
- Irritability is very common
- Depression
- Brain fog
  - All women start going to doctors in thor 40s and they say, “*Oh, it’s probably hormonal,*” but they’re not giving them the solution
  - They’re just telling them it’s not cancer
  - The neurologist will rule out cognitive decline

**Your brain is filled with estrogen receptors**

- [Lisa Mosconi](https://www.lisamosconi.com/about-me) is a neuroscience researcher from Cornell, and when she wanted to assay for estradiol receptors in the brain she found that there was no assay available
- So, she gets Maria Shriver to give her a giant amount of money, and she develops an assay
- She just [published](https://pubmed.ncbi.nlm.nih.gov/38902275/) in *Nature*
- What would you expect?
- Your body is efficient; it’s not going to do things it doesn’t need to do
- The hypothesis was that as [you get later and later past] menopause, the estrogen receptors in your brain are going to downregulate
  - Why have receptors around when there’s no estrogen to feed the brain?
- What did she find?
- The exact opposite: an increase in estrogen receptor density the older you get (age 65 was the oldest she measured), and it correlates to brain fog and all these symptoms

Peter explains his reading of that, “*Estrogen is so important in the brain that it has to upregulate the receptors as the estrogen level goes down and down and down and down*.”

- It’s a lot like the way the brain is treated with glucose
  - If you are fasting, muscles will within days become completely insulin-resistant
  - It’s their way of preserving every molecule of glucose the liver spits out for the brain
  - So you look like you have diabetes in an effort to save glucose for the brain
- Peter thinks this is what’s happening with estrogen
- Rachel makes the argument that weight gain in menopause is evolutionary, so that you make more estrone (or whatever) that goes to the brain
  - Because the brain wants every morsel that it can get

***This idea that hormones matter for the brain is very important***

- Think of a receptor
- As perimenopause is happening, the receptors are full, now they’re empty, then they’re full, now they’re empty, now they’re half-full, now they’re empty

Rachel adds, “*This is why we see* [*ADHD*](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder) *pop up in perimenopause… because your brain is having a panic attack, because it’s just trying to figure out some stability here*.”

- This is why in empty gas tanks, in menopause (where you’re totally empty), the brain fog gets better: the volatility of hormone is less

> “*All I’m saying is just add some estrogen to just keep the receptors happy*.”‒ Rachel Rubin

## The evolution of medical terminology and the underrecognized importance of local estrogen therapy for urinary and vaginal health in menopausal women [1:37:45]

**Urinary symptoms of menopause**

- Both urinary incontinence and the higher prevalence of UTIs
- We used to call this problem the “senile vagina”
- Then it got changed to “vulva vaginal atrophy” or “[atrophic vaginitis](https://en.wikipedia.org/wiki/Atrophic_vaginitis)”
  - This described the observation that as you get older, the vagina atrophies; it shrivels up; it shrinks up

Rachel jokes, “*If a penis shriveled up at age 52, we’d probably have a vaccine sponsored by Pfizer. They created Viagra, they would create this vaccine.*”

- This is the thing, we just called it vulva vaginal atrophy, and we recommend moisturizers or lubricants if you have a little vaginal dryness or pain with sex
- If you’re really bothered, then there’s this thing called vaginal estrogen we could give you

Rachel explains the crazy part of this, “*It’s not just a little vaginal dryness. The vagina and the bladder need hormones.*”

- Babies don’t have hormones, and that’s why you see it’s red, it’s irritated
  - Diaper cream was invented, because it looked so painful
  - They pee their diapers all the time

***The genitals morph and change with hormones***

- Puberty happens, and you have a change of the genitourinary system

**What happens is as you lose hormones, it goes in reverse**

- It changes the [microbiome](https://en.wikipedia.org/wiki/Human_microbiome)
- The hormones keep the tissue acidic; it grows the healthy [*Lactobacilli*](https://en.wikipedia.org/wiki/Lactobacillus#Vaginal_tract)
- The vagina is supposed to be acidic, it’s supposed to be able to fight infection

***Without proper hormones, you lose that ability to fight infection***

*Symptoms include*

- Urinary frequency
- Urinary urgency
- Vaginal dryness
- Increase in leakage
- Increase in urgent continence
- Recurrent urinary tract infections (UTIs)
  - UTIs can and do kill people

![](https://peterattiamd.com/wp-content/uploads/2025/05/f4-rachelrubin-1024x552.png)

**Figure 4. Genitourinary syndrome of menopause symptoms and signs**. Image credit: [GSM Guidelines 2025](https://www.auanet.org/guidelines-and-quality/guidelines/genitourinary-syndrome-of-menopause#x21972)**⇒** We have known since the ‘90s that you can reduce the risk of urinary tract infections by well over 50% with estriol ([*NEJM*](https://pubmed.ncbi.nlm.nih.gov/8350884/))

![](https://peterattiamd.com/wp-content/uploads/2025/05/f5-rachelrubin.png)

**Figure 5. Kaplan-Meier analysis showing the cumulative proportions of women remaining free of urinary tract infections in the estriol (vaginal cream) and placebo groups (P<0.001 by the Log-Rank Test)**. Image credit: [*NEJM* 1993](https://pubmed.ncbi.nlm.nih.gov/8350884/)

- We have known this all along
- Peter was not aware of this

Peter asks, “*And yet, there is no FDA-approved estriol formulation despite that fact?*”

- Correct
- Rachel thinks it’s available in Europe

**The name of vulva vaginal atrophy was changed in 2014**

- It was a bad name because it doesn’t describe what’s really happening to people

***They changed the name to genitourinary syndrome of menopause (GSM)***

- Now there was one urologist, Rachel’s mentor was in the room, and they almost didn’t put the word urinary in it, and he fought and he yelled, and he screamed
  - This is the power of one person to be able to change the whole world, and they listened and put the word urinary in it

***Rachel is so glad they included the word urinary because urinary problems are the things that kill people***

- People are dying of urinary tract infections

## The benefits of vaginal estrogen (or DHEA) for preventing UTIs, improving sexual health, and more [1:41:00]

- A large amount of money goes to Medicare expenditures when it comes to urinary tract infections

**⇒** Rachel [published](https://pubmed.ncbi.nlm.nih.gov/38154005/) last year that if Medicare patients used vaginal estrogen, we would save Medicare between $6 billion and $22 billion a year (Billion!)

[***Vaginal estrogen***](https://www.rxlist.com/estrace-vaginal-cream-drug.htm) ***is safe for everybody, and it’s only*** [***$13 a tube***](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/)

- Peter knows there are people in the Medicare system who are going to be interested to understand that

- When you do a low dose, local vaginal estrogen, or DHEA product, you can reduce your risk of urinary tract infections by more than half
- They are safe to use
  - If you’ve had a history of blood clots, breast cancer, whatever medical problem, Rachel can tell you that it’s safe

**⇒** It will not only help with lubrication, help with pain with sex, help with urinary frequency, urgency, leakage

***Local vaginal estrogen (or DHEA product) will reduce your risk of urinary tract infections by more than half***

- It’s inexpensive and covered by your insurance
- If everybody in Medicare eligibility used vaginal estrogen, we would save Medicare between $6-22 billion a year
  - That’s a conservative estimate because how many patients are getting urinary tract infections, they’re going to their doctor for cultures, they’re in the ICU with sepsis
  - This is a huge economic morbid and mortality problem that we are dealing with, and no one cares

**Why isn’t this a mainstream treatment?**

Peter adds that he always tries to come up with the steel man and say, “*Is it that they don’t care, or is it that they’re unaware, or is it that they feel that it just needs to fall on the shoulders of somebody other than themselves?*”

- Rachel thinks we have a marketing problem
- Peter pushes back and doesn’t agree: he feels like there is nothing more talked about right now
  - Look at what [Halle Berry](https://en.wikipedia.org/wiki/Halle_Berry) is doing, look what [Oprah](https://en.wikipedia.org/wiki/Oprah_Winfrey) is doing, look what [Gwyneth](https://en.wikipedia.org/wiki/Gwyneth_Paltrow) is doing…
  - There are so many very powerful, very influential women that are talking about this, is this not in the zeitgeist right now?
- Rachel agrees that it’s getting better, but these people don’t write the prescriptions

***Not enough physicians are talking about this, and they don’t care***

- It’s not over the counter
- If you can’t get the prescription, or if you don’t go to your doctor saying that you need it
- Rachel posted an [Instagram reel](https://www.instagram.com/reel/DH6XhjQgU2h/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==) about a patient who said, my friend went to her doctor, said she was having pain with sex, asked for vaginal estrogen, and her gynecologist said, and I quote, “*You need to think of other ways to change your relationship from now on, it’s not in the cards for you*.”
- What does that mean? You can’t have sex anymore?
- Correct
- And the fact is, it’s not about sex, it’s about urinary tract infections

Peter responds, “*Wait a minute, wait a minute. This is impossible for me to fathom… Any idea how old this woman is?*”

- In her 60s

*Do you think this gynecologist doesn’t know about estrogen?*

- Honestly, Rachel doesn’t know anymore
- It’s incredible

**Vigara came out in 1998**

- Viagra changed the world, billions of dollars
- [Viagra](https://en.wikipedia.org/wiki/Sildenafil) is a [PD5 inhibitor](https://en.wikipedia.org/wiki/Sildenafil#Mechanism_of_action): it relaxes smooth muscles of the penis, increased blood flow, gives you a rigid erection
  - It helps with arousal for men
- If you take it microdose, low doses, it can also help with [BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia) or urinary problems

Rachel adds, “*We love Viagra, we love* [*Cialis*](http://v)*, wish it was in the water. We should study it in women.*”

- Peter did, in medical school

Rachel argues, “*We’ve had Viagra for women long before we’ve had Viagra for men, and we’ve known about it since the 1970s. And Viagra for women is vaginal hormones.*”

**The importance of vaginal hormones for sexual health**

- What do vaginal hormones do?
- They relax the tissue, they increase arousal, they increase lubrication, they increase orgasm, they help with urinary symptoms
- They do everything Viagra does, and they prevent urinary tract infections
  - Viagra doesn’t do that

***So, you’re talking about better than Viagra, it’s inexpensive…***

- Now, it didn’t use to be
  - When Rachel got out of training, a tube of [Estrace](https://www.rxlist.com/estrace-vaginal-cream-drug.htm) was $500
- Now, it’s not expensive, a tube of estrogen is [$13](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/)
  - Because of people like [Mark Cuban](https://en.wikipedia.org/wiki/Mark_Cuban) and [GoodRx](https://www.goodrx.com/estrace)
    - [more recently, Mark co-founded [Cost Plus Drugs](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/)]
  - Rachel has [talked](https://www.instagram.com/p/Cx_ITnPA0Ve/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==) to Mark Cuban, and he knows more about vaginal estrogen than 90% of doctors

Peter asks, “*And you’re saying that the reason that this price has come down is, I know Mark is a very hardliner against the* [*PBMs*](https://en.wikipedia.org/wiki/Pharmacy_benefit_management)*, did Mark basically take a sledgehammer to that?*”

- Yeah, they changed the game
- It’s incredible
- He understands the nuances of why vaginal estrogen is so important
- Rachel can’t get doctors to do that

> “*We have a marketing problem. We have a product that is better than Viagra for women, it’s been around longer than Viagra, it’s inexpensive, what are we missing? It’s marketing.*” Rachel Rubin

- We’re not telling the patients, we’re not telling the doctors,
- And we have a box labeling, that says, this product causes stroke, heart attacks, blood clots, probable dementia, breast cancer, and needs to be taken with progesterone
  - Not one of those statements is true
- So, we went to the FDA and said, you got to remove the box, you’re killing people
  - And the FDA said, nah, we’re going to leave the box on
  - This is a nightmare

**Rachel shares a story about her mother**

- Her mother just died in November
- She spent 6 months in the IUC in Houston, TX
  - Nobody should be in an ICU for 6 months
  - It was an absolutely gut-wrenching, horrible time for Rachel
- Her mother had been on vaginal estrogen because Rachel wanted her to prevent UTIs (she’s a 70-year-old woman)
- She gets into the hospital, has a transplant, has a catheter, and isn’t doing well, is on [ECMO](https://en.wikipedia.org/wiki/Extracorporeal_membrane_oxygenation), and is very sick for a very long time
- And Rachel said to the doctors, “*I know this isn’t the most important thing in the world, but I’d like to restart her vaginal hormones because having a catheter, being in an ICU, and being immunocompromised, my mother’s risks of a urinary tract infection are incredibly high, and a urinary tract infection is going to kill this woman, so I would like to restart her vaginal estrogen.*”
- And because menopause medicine is a tiny little field, in a tiny little corner, they looked at her like she was an insane person
- They said, “*What do you mean? Your mother’s very sick right now.*”
- Rachel said, “*I know my mother’s very sick right now, and this is one thing I can control.*”
  - She sort of did a, ‘do you know who I am?’
  - Because Rachel on the guidelines committee for GSM, for the American Urologic Association [the [GSM guidelines](https://www.auanet.org/guidelines-and-quality/guidelines/genitourinary-syndrome-of-menopause) were just updated]
- So for the transplant team, she had to write up a whole s-bar of here’s why it’s important, here’s the research, here’s all the literature, here’s the citations
- And they said, “*But it’ll increase her risk of blood clots*.”
- Rachel replied, “*No, it won’t, vaginal hormones don’t increase your risk of blood clots*.”
  - It’s like [hydrocortisone cream](https://en.wikipedia.org/wiki/Topical_hydrocortisone) compared to [Solumedrol](https://en.wikipedia.org/wiki/Methylprednisolone), those are very different things
- Then, they went to the ICU team, and they said, “N*o, we can’t give this to her, it’ll increase her risk of blood clots*.”
  - Rachel had to convince them
- She finally got them to write the prescription
  - She had to teach them how to write the prescription
- Then, the pharmacy wouldn’t dispense it
  - Why?
  - It increases the risk of blood clots. It says so right on the box
- So she had to call and yell
- Rachel is trying to run her practice in Washington, D.C.
- Her brother and father are trying to advocate with her because they know this is important, they also follow her on social media
- Finally, the pharmacy dispenses the tube of [Estrace](https://www.rxlist.com/estrace-vaginal-cream-drug.htm)
- There’s no applicator, the nurses don’t know how to give it
- Rachel had to show them and teach them how to dispense it
- Her mother ultimately passed, not from a UTI, thank goodness

Rachel explains, “*I had to do all this being one of the leading educators on this topic, what does everybody else do? And guess what? The teams changed every week. We had to do this every week, and to teach them why this was important, and how to do this.*”

***Vaginal hormones should not be gynecology, it should not be a small subset of menopause medicine***

- We could save Medicare between $6 and $22 billion a year if people understood this
- If the box labeling weren’t on there
- It is so personal at this point, and yet it is horrible
- Peter is very sorry to hear that story, both at the personal level but at the meta level of what is implied

**If a woman is on a high enough systemic dose of estradiol, does she also need, later in life, local estrogen?**

- Maybe even not later in life

***We find that systemic hormones are not often enough to help with the genital and urinary symptoms***

Most doctors don’t know this

- Again, what are you afraid of?
  - You’re not adding any systemic risk, it doesn’t increase…
  - If your estrogen level is 70 on your patch, and you add a vaginal estrogen, her estrogen level is going to stay 70, you’re not going to get that systemic absorption, but you are going to reduce your UTI rate significantly

Peter asks, “*Has that study been done? That would be a super interesting study.*”

- Think of how easy it would be to do a study
  - Take a group of women that were all at systemic target of estradiol, and you randomized them to a placebo vaginal cream versus an estradiol vaginal cream
  - You could follow these women for a year
  - If they were in a susceptible enough population, and you would get a very clear answer as to whether or not you’re getting additional UTI protection
- And if the answer to that is yes, just imagine the implications there
  - At that point, it becomes malpractice

## The use of DHEA and testosterone in treating hormone-sensitive genital tissues, and an explanation of what often causes women pain [1:50:15]

- Rachel just [published](https://pubmed.ncbi.nlm.nih.gov/39774900/) a study showing DHEA does the same thing, it reduces the risk of UTIs by more than half
  - [[prasteron](https://en.wikipedia.org/wiki/Prasterone) is also known as DHEA]

**What is DHEA doing?**

- They’ve looked a lot at oral DHEA and the data is all over the place
  - Because your adrenals are pumping out a lot of DHEA (adrenal production of testosterone)

**⇒** When you put DHEA vaginally, the idea is that your vaginal enzymes convert it into both estrogen and androgens, and what’s so fascinating is we know that the vagina, the vulvar vestibule, the clitoris, the bladder have androgen receptors

- So using just estrogen in this tissue may be missing the whole point
  - We do have patients that benefit from having an androgen in the tissue as well
- The only FDA-approved product we have is [Intrarosa](https://www.rxlist.com/menopause_and_perimenopause_slideshow/article.htm), which is vaginal DHEA
- Now, it’s often hard to get for patients

***If Rachel could get it for everybody, she would, it’s fabulous because the tissue needs androgens. The data’s very good.***

- There’s some data that shows it helps with urgency
- Rachel just [published](https://pubmed.ncbi.nlm.nih.gov/39774900/) in the *Menopause* Journal that it decreased risk of UTIs by more than half
- Rachel uses it frequently
- What’s nice about the product, it’s a nightly product, it’s DHEA in palm oil, so it’s very moisturizing, very lubricating
- Rachel’s my mentor, [Irwin Goldstein](https://www.sdsm.info/meet-dr-goldstein) published that actually, it also helps the tissue called the vulvar vestibule

**Details of female anatomy**

Rachel asks, “*Do you know what the vulvar vestibule is?*”

- Rachel is obsessed with homologs

Examples of homologs in male and female anatomy

- The head of the penis and the head of the clitoris are homologs
- The homolog of the scrotal skin is the labia majora
- The clitoris and the penis both have a prepuce or a hood to it
- There’s a line that goes down a penis, that goes down the penis and the scrotum called the [median raphe](https://en.wikipedia.org/wiki/Penile_raphe) and the homolog is the labia minora
  - It’s skin, it’s ectoderm
  - If you take the median raphe and you split it, that’s your labia minora, which is very hormone sensitive

Rachel is trending on TikTok because she talks about the labia minora shrinking and disappearing in menopause, and the internet has broken because of i**t**

- The [labia minora](https://en.wikipedia.org/wiki/Labia_minora) is very hormone sensitive tissue that we do not study and we know almost nothing about
- It resorbs in menopause
- Inside the labia minora
  - If we cut into the median raphe, in a man (and we do this when we put in penile implants, or we do urethral surgeries), we get to the male urethra

Rachel explains, “*So, Peter, your outside of your cheek is skin, the inside of your cheek is different tissue. One’s more sensitive, one’s thicker. So the skin of the median raphe is very different than the skin of the tube of your urethra. You agree?*”

- If you split open the labia minora, you get to the urethra, and that is the [vulvar vestibule](https://en.wikipedia.org/wiki/Vulval_vestibule)
- The tissue that surrounds the urethra in a woman, that goes all the way around
  - It is made up of endoderm

***We think of the cervix as a transition point, but the most important transition point that affects sexual health in a woman is when you go from ectoderm of the labia minora to endoderm of the vulvar vestibule, and then past the hymen is mesoderm (it’s fascinating anatomy)***

Why is this important?

- It’s so important, because if you push with a Q-tip on the labia minora, they’ll have no pain
- If you push them on their [vulvar vestibule](https://en.wikipedia.org/wiki/Vulval_vestibule), they’ll say, that’s my UTI, that’s my interstitial cystitis, that’s the pain that I have with sex
  - It is rich in hormone receptors
- This is why 50% of women go off their endocrine therapy for breast cancer because they have urinary symptoms, pelvic pain symptoms, and it is all sourced in a body part that no one taught you in medical school
- Rachel did that on purpose because she knew Peter wouldn’t know it, because no one has taught how to examine it
  - They put a speculum in, and they bypass it completely, and they are missing the problem

***Back to the DHEA: this tissue has estrogen and testosterone receptors in it, so sometimes estrogen is not enough to help this vulvar vestibule tissue***

- There is [1 paper](https://pubmed.ncbi.nlm.nih.gov/33488333/) to suggest that DHEA is enough
- And this is the one time Rachel will compound a product for a woman
  - Otherwise she uses FDA-approved products at her practice
  - She will compound the amount of estrogen in an estrogen vaginal topical ream (0.01%) and will use a topical testosterone (0.1%, different than the 1% she talked about for libido)
    - She typically uses a VersaBase of a methyl cellulose base
    - There’s no DHEA in it

***Women rub it topically on this vulvar vestibule and you cure pain with sex, you help these UTI symptoms, interstitial cystitis goes away in so many patients, it’s miraculous***

Rachel adds, “*If you have a patient who’s on vaginal estrogen, systemic estrogen, systemic testosterone, and they say, Peter, I still have pain with sex, it still kind of hurts, it’s always the vestibule.*”

## Is it too late to start HRT after menopause? [1:56:15]

A hypothetical patient asks Rachel, “*I buy your argument that hormones are safe, but I am now 56 years old, I finished menopause at 49, isn’t it too late to do anything about it?*”

**There is an idea in menopause called the timing hypothesis (or the window)**

*The question of the timing hypothesis is what are you afraid of? What are we worried about?*

- We’re worried about blood clots… We don’t want to hurt people
- We’re worried about cancer
- We’re worried about heart disease

*But the question is, does the hormone therapy that we use apply to the data that we have?*

- Rachel would argue it doesn’t
- There is a level of we don’t know what we don’t know

**⇒** Even the timing hypothesis, using [prempro](https://www.rxlist.com/prempro-drug.htm), which was the medicine used in the WHI, is under question

- [Susan Davis](https://research.monash.edu/en/persons/susan-davis) from Australia just wrote a [big paper](https://pubmed.ncbi.nlm.nih.gov/39419045/), questioning the **timing hypothesis**
  - She argues that when you look at the data really closely, it doesn’t really hold muster
  - ***We shouldn’t really be forcing people to say, you cannot start hormone therapy after 60***

**This is where shared decision making comes into play ‒ what we are treating**

- Do you care about your bones?
- Do you care about your sexual health?
- Do you care about your mental health?
- And do you want to see if hormone therapy helps with these things?

**⇒** Hormone therapy is indicated for 3 reasons: vasomotor symptoms, hot flashes, night sweats, prevention of osteoporosis

- To Rachel, this last one is a green light, so anyone should be offered hormone therapy because who wouldn’t want to prevent [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis)?
- Who wouldn’t want to prevent the genital and urinary syndrome of menopause

***Anybody of any age (even perimenopause and premenopause), vaginal estrogen or DHEA, is safe, and really helpful to prevent UTIs, and should be used absolutely everywhere throughout life***

## Should women stop hormone therapy after 10 years? [1:58:15]

**If you were lucky enough to catch a woman through perimenopause, and you got her on hormones by the age of 49, now she’s 69, do you have to stop HRT?**

- Peter asks this question about the hedging strategy, which says not only to use as little as possible for as short a duration as possible, but you also need to stop after 10 years

***Definitely not***

**⇒** There is no data to suggest stopping it; in fact, stopping it, all of your bone gains go away

- They all go away quickly

Peter explains, “*That was the argument put forth to me with one of the authors of the WHI, who is by far the most willing to concede that mistakes were made. Which was, okay, yes, I will concede that the estradiol is doing amazing things for the woman’s bones, but remember, they’re going to go away when you stop the hormones, as though that was a necessary thing to do*.”

***Rachel’s advice is to keep on them***

- Again, this idea of, ‘if it’s not broke, don’t fix it’
- By taking a woman off of hormone therapy, you actually potentially could be disrupting any plaques that are there, you could be causing [vasospasm](https://en.wikipedia.org/wiki/Vasospasm)…
  - There are all these things that could happen, we really don’t want to take women off their hormone therapy unless there is a reason to
- The only reason Rachel sees [to stop HRT] is if a woman has an active cancer that you are going to target hormones as a target for your treatment of cancer
  - That’s not to say the hormones cause the cancer
  - But all body parts have hormone receptors, and we have used hormones as a target for our breast cancer therapies and some other cancer therapies

## How to manage hormone therapy in women with BRCA mutations, DCIS, or a history of breast cancer [2:00:00]

**How do we manage hormones in women who are at risk of breast cancer (from a familial standpoint), who have been diagnosed with DCIS?**

*Also in women who actually have breast cancer, or have a history of treated breast cancer?*

- [DCIS](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ) is not cancer, but increases the risk of cancer
- First, Rachel takes a long time at her clinic to get to know patients
- They really try to dive into the data, and see: What do we know? What do we not know?

Rachel always tells people, “*You can’t take hormone therapy because Rachel Rubin tells you to take hormone therapy, you have to do your own research, figure out what you’re interested in*.”

Rachel has a lot of colleagues who are talking about this

- Peter had [Avrum Bluming](https://www.researchgate.net/profile/Avrum-Bluming) on the podcast [[episode #42](https://peterattiamd.com/caroltavris-avrumbluming/)], and he has a great book called [*Estrogen Matters*](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Lengthen/dp/0316578908/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.qu5_jgKs5LWKALqIfd0QsQ.VdBBKRmbbwzkZXiz_C1GCpVaLon1MjOeVJ7AzZrm4MQ)
  - He’s an oncologist who’s questioning a lot of this research
- [Corinne Menn](https://www.drmenn.com/about.html), who is a gynecologist who had breast cancer, as a young person (in her 20s), and now takes hormone therapy
  - She talks a lot about hormone therapy, and teaches [courses](https://www.drmenn.com/courses.html) on hormone therapy and breast cancer

Rachel’s philosophy and thoughts on 3 types of patients

- Rachel is always learning
- She doesn’t like fear
- She doesn’t like telling women they can’t do things with their body
- She likes understanding: What are we afraid of?
- 1 – When it comes to the [BRCA patients](https://en.wikipedia.org/wiki/BRCA_mutation), if you do surgical menopause on someone, and they don’t have cancer, and you do not give them back hormone therapy, ***you are trading one problem for another***
  - You may give them extra life from a breast cancer perspective, but you are shortening their life from a bone health and a cardiovascular disease perspective, that is very clear
- 2 – The other problem is the [DCIS](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ), if you are not going to give someone endocrine therapy of any kind, and they’re done
  - They have surgery, they’re done, ***there is no reason why they can’t take hormone therapy***
- 3 – For the patient who has **active breast cancer**, there is a lot of emerging questioning in this patient population
  - Again, the question is: If you’re allowed to get pregnant, are you allowed to take hormone therapy?
  - And that’s really the pushback that we give some people
  - There is a lot of data that we need here, but we need to be asking these questions

**Recent data calls into question the risks attributed to hormone therapy**

- Rachel is a urologist, when she came out of her training, [the prevailing thought] was testosterone fuels prostate cancer
- Now, 10 years later, if you have prostate cancer, sure, we can give you testosterone, no problem
- If you have metastatic disease, we target testosterone, so we’re going to use castration level androgen blockers
- But that doesn’t mean if you have localized disease that you can’t have testosterone therapy
- We think of testosterone and prostate cancer as a [saturation model concept](https://www.medicinacomplementar.com.br/biblioteca/pdfs/Cancer/ca-3171.pdf), and Rachel actually thinks we need to be using that model, potentially when it comes to breast cancer

> “*We need to… have more logic and understanding and less fear. It’s marketing*.”‒ Rachel Rubin

- All prostate cancer is testosterone sensitive prostate cancer, but we don’t cut off testicles for the fear that an abnormal cell will happen in a prostate
  - [Rachel’s blog post, [*Does Testosterone Cause Cancer?*](https://www.rachelrubinmd.com/post/does-testosterone-cause-cancer)]
- A lot of breast cancer is estrogen receptive [positive] breast cancer, not all of it, right?
  - But some of it is, that doesn’t mean estrogen causes cancer

Peter responds, “*It’s insanely helpful. And of course, it echoes exactly what* [*Ted Schaeffer*](https://www.tedschaeffermd.com/) *said when we spoke about this after discussing the* [*TRAVERSE trial*.](https://pubmed.ncbi.nlm.nih.gov/37326322/)”

- [[episode #310](https://peterattiamd.com/tedschaeffer3/)]

**What Peter found most telling from his conversation with Ted**

- Ted explained that if he has a man who has a Gleason 3+3 (which means he has prostate cancer) and he follows him, and if it becomes a 3+4, he’s going to have to remove his prostate and put him on TRT if he needed it
- His argument was exactly Rachel’s argument on the pregnancy side ‒ the reason we would happily give him TRT
  - Let’s assume the man is replete with testosterone, would we castrate him during that period of observation? Of course not
  - So why wouldn’t he not give him testosterone if he needs it, even though has actually has prostate cancer

**Rachel argues this is where that patriarchal divide happens**

- We are willing to take those risks and focus on quality of life when it comes to men’s health
- We castrate women with the mere thought that they may develop an abnormal cell in their body, and completely ignore their quality of life, and all of those things that go with it

***Women are more than breast tissue, they are so much more than their cancer risk, and we have to understand and actually have these reasonable conversations with women***

> “*Your oncologist is not in charge of you, they give you advice*.”‒ Rachel Rubin

Y**our doctors are like a pit crew… Let’s go back to our car model**

- You have a pit crew, but you get to decide who’s on your pit crew, and who fits into your pit crew
- But it can’t be just one doctor
- You may need someone to talk about your sexual health
- You may need someone to talk about your menopause hormones
- You may need a bone doctor
- You may need a heart doctor
- You need to collect your pit crew, but when one doctor says, no, you can’t do this with your body
  - Rachel doesn’t like that terminology
  - She doesn’t think it’s fair anymore

**When you give women information about how their bodies work, they make great decisions for themselves**

- They can look at the menu and say, listen, I’m most worried about [Alzheimer’s](https://en.wikipedia.org/wiki/Alzheimer%27s_disease), and I’ve looked at the data and this is what I choose to do
- Or hey, I’m more worried about [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis)
  - Listen, my grandma had broke a bunch of ribs, she had Alzheimer’s and osteoporosis, and my grandpa hugged her and she broke a bunch of ribs, that’s not how I want to age
- So, what do I care about?
  - I don’t want to get osteoporosis, I don’t want to get dementia, and I’ve seen all the literature, hormone therapy sounds pretty good to me
  - And that’s really the key
- There’s a lot of people on social media, maybe negative about hormone therapy, but if you look, they are on hormone therapy themselves, they will say they have an estrogen patch on

**Are there people on social media saying they’re anti-HRT but they use HRT?**

*What’s their argument?*

- This idea that we are overselling HRT, that not every woman needs HRT

> “*I’m not suggesting every woman needs HRT. But I want every woman to be offered the menu*.”‒ Rachel Rubin

- Rachel wants women to know what the [HRT options] are
  - Just like she wants people to know how to exercise and lift weights and eat healthy
  - Here’s the menu, if you choose to smoke and drink and do drugs, that is your choice, but she wants you to know that the menu exists

## How women can identify good menopause care providers, avoid harmful hormone therapy practices, and why menopause medicine is critical for both women and men [2:06:00]

**What do women need to be aware of?**

- Not every woman can see Rachel
- Not every woman has access to a doctor who has the breadth of knowledge that a select few do in this space

*How can women find practitioners near them, and what exploitative practices do they need to be mindful of so they’re not duped into either dangerous therapies or overly extractive therapies?*

- There’s danger on both sides
  - There’s danger going to the doctor for 10 minutes, and saying, oh, that’s not safe, you don’t want to do this
  - And there’s dangers of going to the very expensive pellet clinic, that is going to overdose you and charge you lots and lots of money
- Rachel likes being somewhere in the middle, and getting a few opinions here
  - This is where opinions can be a bunch of people on Instagram, don’t just follow one person, follow a bunch of people
- If you like books, there’s tons of books now on menopause

**Some of Rachel’s favorite books and documentaries on menopause**

- [Mary Claire Haver](https://maryclairewellness.com/provider/dr-mary-claire-haver/) has the most popular book called [*The New Menopause*](https://www.amazon.com/New-Menopause-Navigating-Through-Hormonal/dp/059379625X/ref=sr_1_1?crid=2DE9AE3H1E31L&dib=eyJ2IjoiMSJ9.eUOWa_TN0sXbFLm_ms-bN-BpNzAoaMx6G1TjuQWVuemGGS_3zQZbYzsS0mGYjkUl34h3DXtdy8tYdfTK-ymf-fMtBAc-MPAbolLhOxAcwoJonJG8_2TfhgKRMz8ffQ1V0AaXKPx0xmX2yno2PxxCxu2egh5cL9HNrhSGXZKn9wvVReH9hc70f-qAPZsXtas4JUVgP2spmN6zQfIa7VNNj413BaSW3Tv5Y7hNlVoFsBE.cfAhEOcjlCveryYBjG7IQmuqyKViK-ThqV0aNkiOP5E&dib_tag=se&keywords=The+New+Menopause&qid=1745853499&s=books&sprefix=the+new+menopause%2Cstripbooks%2C194&sr=1-1)
- [Heather Hirsch](https://heatherhirschmd.com/about/) has a great book called [*Unlock Your Menopause Type*](https://www.amazon.com/Unlock-Your-Menopause-Type-Personalized/dp/1250850827/ref=sr_1_1?crid=EOI9TKRPDPHP&dib=eyJ2IjoiMSJ9.6p1awFrEoAJyxLfsQWuh3XPqOLwEDNXy4GjG3LuKN95zA1xeUVe-LcnAyoJa2YYkUIOfBBa5flDdZ6aXh6EQR5wzK52lvzPjCqlHylmhwkBaQJO8z1VXljIEHhOiiVJTSoKp7u4q2PEkpCGCTJlItSCPn8eZrhozrPDsYN2Dz-9aXhrEb2IhQK480mQ-FMBkny7bgJiUvEczd5UPfzgJh1SAz_aDI4ZSKd5uoFFKrt0.7aNecC6_XOHHrdvgtOzRWBO_X8G7uUf9Cdy7Omy6fts&dib_tag=se&keywords=heather+hirsch&qid=1745853847&s=books&sprefix=heather+hirsch%2Cstripbooks%2C90&sr=1-1)
- A journalist ([Jancee Dunn](https://www.janceedunn.net/biography)) wrote a great book on perimenopause: [*Hot and Bothered*](https://www.amazon.com/dp/0593542568/?bestFormat=true&k=hot%20and%20bothered%20jancee%20dunn&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_15&crid=5DMI8S9ZIV88&sprefix=hot%20and%20bothere)
- [Tamsen Fadal](https://www.tamsenfadal.com/about) just wrote a book about menopause [[*How to Menopause*](https://www.amazon.com/How-Menopause-Charge-Health-Reclaim/dp/0306833549/ref=sr_1_1?crid=2YBPXM4AEZVD5&dib=eyJ2IjoiMSJ9.c-jIRpwDGfQ879X2PmLRAx9cFyujz5uSTUqqiCmZ-S0QRhBbNL7zHD4p0TdmrkWYDwTlL-rts9BMkSBaKrUFXFIWllQrORlvGA31CF6w-wZVIy4ADZ-J4aeTI_58QnV4b4cvtLeQ0Z-DPUrrtlFLO8SN-X6awPha5ZiAq7ACLz740hZqBFqq05C6MXIDmEophoyk6HwHB7-MQm87M4T93LvLjHUMmbWKE7QaypLCjRM.4CnIjukORxSFdzKafhyIaOpfMREHSgbp0q11h_s4NmE&dib_tag=se&keywords=Tamsen+Fadal&qid=1745854495&s=books&sprefix=tamsen+fadal%2Cstripbooks%2C82&sr=1-1)]; she’s also a reporter
- [Estrogen Matter](http://k)s is a really great book
- There’s one called[*The Menopause Manifesto*](https://www.amazon.com/Menopause-Manifesto-Health-Facts-Feminism/dp/0806540664/ref=sr_1_1?crid=63O8J6HXQETN&dib=eyJ2IjoiMSJ9.dCViR-qv8Yq2l2i-ASs1DFK2e--4FEQQtK7iWcXYb6kRzXbfShA6Jyw6CwOWHR6fQ8aQlcYWhlYZRyRB_KDsF8b9PanmsnLfsktBQgsLZC9LoDrHFH4C_AsMfgCb5EqckQd78Yq38q6w-lQpHIrBnGUALHoBI95MPZhGjpE8aezRZTq6V2aa-G7mc86k3P2Sql49AxeK7ckQ8j7YzK2j-fUX5cSVeRJLRQkRyo_oIQQ.uANdKjUTSP8JxYEZByRHuR0ZPzmSxHLx5WWOShV8pZo&dib_tag=se&keywords=The+Menopause+Manifesto&qid=1745854842&s=books&sprefix=the+menopause+manifesto%2Cstripbooks%2C97&sr=1-1)
- There’s also great podcasts out there
- Oprah just did a [special](https://abc.com/news/6f72d548-a74c-4985-9dda-ce39b170cde5/category/1138628)
- There’s [documentaries on PBS](https://www.pbs.org/show/the-m-factor-shredding-the-silence-on-menopause/) now
- Menopause is having a movement
- You can’t have this excuse anymore, of, “*Oh, my doctor doesn’t do this,*”
- Go find a different doctor
- There are telemedicine companies

***The Menopause Society*** [***website***](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx) ***and the Women’s Sexual Health Society (ISSWSH)*** [***website***](https://app.v1.statusplus.net/membership/provider/index?society=isswsh) ***are great places to find a provider***

- Again, you have to advocate for yourself because no one will do that other than you

> “*I think the more you educate yourself, the more you can find the right people in your pit crew, who are going to fill that gas tank, and get you to where you want to go.*”‒ Rachel Rubin

**Do you feel that there are too many women that are still getting their hormone therapy in the dark alley with highly sus individuals?**

*And if so, what would be a clue that you’re in that camp?*

- This is a problem
- When your doctor says no, you can’t have anything, that’s suspect

Red flags

- If your doctor says, you can only have this really expensive product that has to be inserted into your butt 4x a year, and you have to pay me thousands of dollars, that’s extremely suspect
- If they say you have to pay lots of money for this special compounded product, that’s safer and more effective, that’s a red flag
- If you have to give very expensive saliva testing labs, and they’re making you pay a lot of money, very suspect
- Again, that doesn’t mean you can’t do it, if it’s working for you, and you’re happy, you have body autonomy, you do what you want, but know that there’s red flags there
- Rachel has a big problem with the pellet industry
  - There is an FDA-approved [pellet](https://www.rxlist.com/testopel-drug.htm) for men
  - If pellet companies cared about women, do the studies, go through the FDA, and show it’s safe
  - It’s a billion dollar industry

**Rachel’s beef with the FDA**

- Take that that box labeling off estrogen products, especially vaginal estrogen

**Everyone takes advantage of women**

- All the supplement companies, they take advantage by promising these things to women, but they don’t do the work of science
- What Rachel asks is, just do the work

**Peter thinks this was a fantastic discussion**

- A really nuanced and deep discussion about an important topic
- This is a topic that really impacts almost 100% of the population
  - We just talked about 50% of the population
  - The other 50% of the population would be hard-pressed to say that they don’t care about at least one person in that other group

**Rachel’s parting thoughts on longevity and the importance of today’s conversation**

- Rachel is also a men’s health doctor

She lectures her urology colleagues, “*You talk about longevity, and here are the things you can do for longevity, I think you’re missing one point. And that is that men who are divorced, single, or widowed, have horrible health outcomes. Horrible.*”

- Whether you look at mental health, prostate cancer, cancer outcomes, horrible

**⇒** Men who are divorced die sooner

***If you want longevity, if you want to keep living, you have to keep people partnered***

- When do people get divorced?
  - Between 40 and 60
  - That is the age of perimenopause and menopause

***Menopause is killing men, it is killing men because it changes their marriages, and it leads to divorce, which leads to death***

- If men’s health doctors, if doctors truly cared about keeping men alive, they would do menopause medicine because that is one of the most important ways to keep men alive
- Rachel can’t thank Peter enough for this platform because it is everybody’s problem

---

## Selected Links / Related Material

**Episodes of** ***The Drive*** **that discuss menopause**: [6:15]

- [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) (February 25, 2019)
- [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.](https://peterattiamd.com/joannmanson/) (May 8, 2023)
- [#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones | Peter Attia, M.D.](https://peterattiamd.com/endocrinesystem/) (May 29, 2023)
- [#259 – Women’s sexual health: Why it matters, what can go wrong, and how to fix it | Sharon Parish, M.D.](https://peterattiamd.com/sharonparish/) (June 19, 2023)

**Peter explains the ovulatory cycle**: [#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones](https://peterattiamd.com/endocrinesystem/) | Peter Attia, M.D. (May 29, 2023) | [10:15]

**Women’s Health Initiative, initial results**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women: Principal Results From the Women’s Health Initiative Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/12117397/) | *JAMA* (J Rossouw et al. 2002) | [23:30]

**Change in FDA labeling of testosterone**: [FDA Updates Testosterone Labeling for Blood Pressure and Cardiovascular Risks](https://jamanetwork.com/journals/jama/fullarticle/2832503) | *JAMA Medical News in Brief* (S Anderer, 2025) | [36:00]

**ISSWSH providers for menopause and sexual health**: [Find a provider](https://app.v1.statusplus.net/membership/provider/index?society=isswsh) | ISSWH (2025) | [42:45, 2:08:00]

**ISSWSH guidelines on use of testosterone for postmenopausal women**:  [42:45]

- [News](https://www.isswsh.org/news/402-clinical-practice-guideline-for-the-use-of-systemic-testosterone-for-hsdd-published) | ISSWSH (2021)
- [International Society for the Study of Women’s Sexual Health Clinical Practice Guideline for the Use of Systemic Testosterone for Hypoactive Sexual Desire Disorder in Women](https://pubmed.ncbi.nlm.nih.gov/33814355/) | *Journal of Sexual Medicine*(S Parish et al. 2021)
- [International Society for the Study of Women’s Sexual Health Clinical Practice Guideline for the Use of Systemic Testosterone for Hypoactive Sexual Desire Disorder in Women](https://pubmed.ncbi.nlm.nih.gov/33797277/) | *International Journal of Women’s Health* (S Parish et al. 2021)
- [International Society for the Study of Women’s Sexual Health Clinical Practice Guideline for the Use of Systemic Testosterone for Hypoactive Sexual Desire Disorder in Women](https://pubmed.ncbi.nlm.nih.gov/33792440/) | *Climacteric* (S Parish et al. 2021)

**TRAVERSE trial**: [Cardiovascular Safety of Testosterone-Replacement Therapy](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025) | *NEJM* (A Lincoff et al. 2023) | [46:30, 50:00, 2:03:00]

**Peter’s newsletter about the TRAVERSE trial**: [Is testosterone replacement therapy both safe and effective in men with higher cardiovascular risk factors?](https://peterattiamd.com/traverse-trial-and-trt-in-men/) | PeterAttiaMD.com (S Lipman, K Birkenbach, P Attia 2023) | [50:15]

**KEEPS trial**: [Arterial imaging outcomes and cardiovascular risk factors in recently menopausal women: a randomized trial](https://pubmed.ncbi.nlm.nih.gov/25069991/) | *Annals of Internal Medicine* (S Harman et al. 2014) | [1:14:45]

**Harvard testosterone course**: [Testosterone Therapy and Sexual Dysfunction](https://hmstestosteronecourse.com/) (2025) | [1:15:30]

**Episode of** ***The Drive*** **with Mohit Khera**: [#260 ‒ Men’s Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.](https://peterattiamd.com/mohitkhera/) (June 26, 2023) | [1:15:30]

**The musculoskeletal syndrome of menopause**: [The musculoskeletal syndrome of menopause](https://pubmed.ncbi.nlm.nih.gov/39077777/) | *Climacteric* (V Wright et al 2024) | [1:33:45]

**Estradiol receptors in the brain change during menopause**: [In vivo brain estrogen receptor density by neuroendocrine aging and relationships with cognition and symptomatology](https://pubmed.ncbi.nlm.nih.gov/38902275/) | *Scientific Reports* (L Mosconi et al 2024) | [1:35:30]

**Estriol reduces risk of UTI in postmenopausal women**: [A controlled trial of intravaginal estriol in postmenopausal women with recurrent urinary tract infections](https://pubmed.ncbi.nlm.nih.gov/8350884/) | *NEJM* (R Raz, W Stamm 1993) | [1:40:15]

**Billions could be saved by using vaginal estrogen to prevent UTIs**: [A Cost Savings Analysis of Topical Estrogen Therapy in Urinary Tract Infection Prevention Among Postmenopausal Women](https://pubmed.ncbi.nlm.nih.gov/38154005/) | *Urology Practice* (C Goldman Houston et al. 2024) | [1:41:15]

**Vaginal DHEA decreases risk of UTIs by more than half**: [Prevalence of urinary tract infections in women with vulvovaginal atrophy and the impact of vaginal prasterone on the rate of urinary tract infections](https://pubmed.ncbi.nlm.nih.gov/39774900/) | *Menopause* (R Rubin et al. 2025) | [1:45:15]

**Benefits of DHEA for treating GSM**: [Vaginal dehydroepiandrosterone compared to other methods of treating vaginal and vulvar atrophy associated with menopause](https://pubmed.ncbi.nlm.nih.gov/33488333/) | *Przeglad Menopauzalny (Menopause Review)* (W Pieta, R Smolarczyk 2020) | [1:55:00]

**Questioning timing hypothesis, limitations of when to start HRT**: [Is it time to revisit the recommendations for initiation of menopausal hormone therapy?](https://pubmed.ncbi.nlm.nih.gov/39419045/) | *Lancet Diabetes & Endocrinology* (S Taylor, S Davis 2025) | [1:57:15]

**Episode of** ***The Drive*** **with Avrum Bluming**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) (February 25, 2019) | [2:00:45]

**Avrum Bluming’s book**: [Estrogen Matters](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Lengthen/dp/0316578908/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.qu5_jgKs5LWKALqIfd0QsQ.VdBBKRmbbwzkZXiz_C1GCpVaLon1MjOeVJ7AzZrm4MQ) by A Bluming and C Davis (2024) | [2:01:00]

**Corinne Menn’s courses (CME)**: [Breast Cancer Survivors & HRT Course](https://www.drmenn.com/courses.html) (2025) | [2:01:15]

**Episode of** ***The Drive*** **with Ted Schaeffer discussing the TRAVERSE trial**: [#310 – The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer3/) (July 22, 2024) | [2:03:00]

**Some of Rachel’s favorite books on menopause**: [2:07:00]

- [The New Menopause: Navigating Your Path Through Hormonal Change with Purpose, Power, and Facts](https://www.amazon.com/New-Menopause-Navigating-Through-Hormonal/dp/059379625X/ref=sr_1_1?crid=2DE9AE3H1E31L&dib=eyJ2IjoiMSJ9.eUOWa_TN0sXbFLm_ms-bN-BpNzAoaMx6G1TjuQWVuemGGS_3zQZbYzsS0mGYjkUl34h3DXtdy8tYdfTK-ymf-fMtBAc-MPAbolLhOxAcwoJonJG8_2TfhgKRMz8ffQ1V0AaXKPx0xmX2yno2PxxCxu2egh5cL9HNrhSGXZKn9wvVReH9hc70f-qAPZsXtas4JUVgP2spmN6zQfIa7VNNj413BaSW3Tv5Y7hNlVoFsBE.cfAhEOcjlCveryYBjG7IQmuqyKViK-ThqV0aNkiOP5E&dib_tag=se&keywords=The+New+Menopause&qid=1745853499&s=books&sprefix=the+new+menopause%2Cstripbooks%2C194&sr=1-1) by Mary Claire Haver (2024)
- [Unlock Your Menopause Type: Personalized Treatments, the Last Word on Hormones, and Remedies that Work](https://www.amazon.com/Unlock-Your-Menopause-Type-Personalized/dp/1250850827/ref=sr_1_1?crid=EOI9TKRPDPHP&dib=eyJ2IjoiMSJ9.6p1awFrEoAJyxLfsQWuh3XPqOLwEDNXy4GjG3LuKN95zA1xeUVe-LcnAyoJa2YYkUIOfBBa5flDdZ6aXh6EQR5wzK52lvzPjCqlHylmhwkBaQJO8z1VXljIEHhOiiVJTSoKp7u4q2PEkpCGCTJlItSCPn8eZrhozrPDsYN2Dz-9aXhrEb2IhQK480mQ-FMBkny7bgJiUvEczd5UPfzgJh1SAz_aDI4ZSKd5uoFFKrt0.7aNecC6_XOHHrdvgtOzRWBO_X8G7uUf9Cdy7Omy6fts&dib_tag=se&keywords=heather+hirsch&qid=1745853847&s=books&sprefix=heather+hirsch%2Cstripbooks%2C90&sr=1-1) by Heather Hirsch, Stacey Colino (2023)
- [Hot and Bothered: What No One Tells You About Menopause and How to Feel Like Yourself Again](https://www.amazon.com/dp/0593542568/?bestFormat=true&k=hot%20and%20bothered%20jancee%20dunn&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_15&crid=5DMI8S9ZIV88&sprefix=hot%20and%20bothere) by Jancee Dunn (2023)
- [How to Menopause: Take Charge of Your Health, Reclaim Your Life, and Feel Even Better than Before](https://www.amazon.com/How-Menopause-Charge-Health-Reclaim/dp/0306833549/ref=sr_1_1?crid=2YBPXM4AEZVD5&dib=eyJ2IjoiMSJ9.c-jIRpwDGfQ879X2PmLRAx9cFyujz5uSTUqqiCmZ-S0QRhBbNL7zHD4p0TdmrkWYDwTlL-rts9BMkSBaKrUFXFIWllQrORlvGA31CF6w-wZVIy4ADZ-J4aeTI_58QnV4b4cvtLeQ0Z-DPUrrtlFLO8SN-X6awPha5ZiAq7ACLz740hZqBFqq05C6MXIDmEophoyk6HwHB7-MQm87M4T93LvLjHUMmbWKE7QaypLCjRM.4CnIjukORxSFdzKafhyIaOpfMREHSgbp0q11h_s4NmE&dib_tag=se&keywords=Tamsen+Fadal&qid=1745854495&s=books&sprefix=tamsen+fadal%2Cstripbooks%2C82&sr=1-1) by Tamsen Fadal (Author), Lisa Mosconi PhD (Foreword) (2025)
- [Estrogen Matters](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Lengthen/dp/0316578908/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.qu5_jgKs5LWKALqIfd0QsQ.VdBBKRmbbwzkZXiz_C1GCpVaLon1MjOeVJ7AzZrm4MQ) by A Bluming and C Davis (2024)
- [The Menopause Manifesto: Own Your Health with Facts and Feminism](https://www.amazon.com/Menopause-Manifesto-Health-Facts-Feminism/dp/0806540664/ref=sr_1_1?crid=63O8J6HXQETN&dib=eyJ2IjoiMSJ9.dCViR-qv8Yq2l2i-ASs1DFK2e--4FEQQtK7iWcXYb6kRzXbfShA6Jyw6CwOWHR6fQ8aQlcYWhlYZRyRB_KDsF8b9PanmsnLfsktBQgsLZC9LoDrHFH4C_AsMfgCb5EqckQd78Yq38q6w-lQpHIrBnGUALHoBI95MPZhGjpE8aezRZTq6V2aa-G7mc86k3P2Sql49AxeK7ckQ8j7YzK2j-fUX5cSVeRJLRQkRyo_oIQQ.uANdKjUTSP8JxYEZByRHuR0ZPzmSxHLx5WWOShV8pZo&dib_tag=se&keywords=The+Menopause+Manifesto&qid=1745854842&s=books&sprefix=the+menopause+manifesto%2Cstripbooks%2C97&sr=1-1) by Jen Gunter (2021)

**Oprah special on menopause**: [An Oprah Winfrey Special: The Menopause Revolution](https://abc.com/news/6f72d548-a74c-4985-9dda-ce39b170cde5/category/1138628) | ABC (2025) | [2:07:30]

**PBS documentary on menopause**: [The [M] Factor: Shredding the Silence on Menopause](https://www.pbs.org/show/the-m-factor-shredding-the-silence-on-menopause/) | PBS (2025) | [2:07:30]

**How to find a practitioner**: [2:07:45]

- [Find a Menopause Practitioner](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx) | The Menopause Society (2025)
- [Find a provider](https://app.v1.statusplus.net/membership/provider/index?society=isswsh) | ISSWH (2025)

**2025 Guidelines for genitourinary syndrome of menopause**: [Genitourinary Syndrome of Menopause: AUA/SUFU/AUGS Guideline (2025)](https://www.auanet.org/guidelines-and-quality/guidelines/genitourinary-syndrome-of-menopause) | *American Urological Association* (M Kaufman et al. 2025)

---

## People Mentioned

- [Abraham Morgentaler](https://connects.catalyst.harvard.edu/Profiles/display/Person/87781) (Associate Professor of Surgery (Urology) at Beth Israel Deaconess Medical Center and Harvard Medical School in Boston, course director for [Testosterone Therapy and Sexual Dysfunction](https://hmstestosteronecourse.com/) at Harvard Medical School, and Founder of [T4L Education](https://t4leducation.com/)) [1:15:30]
- [Mohit Khera](https://drmohitkhera.com/about/) (Professor of Urology and the F. Brantley Scott Chair in Urology at Baylor College of Medicine, the Director of the Laboratory for Andrology Research at the McNair Medical Institute, and the Medical Director of the Executive Health Program at Baylor) [1:15:30]
- [Vonda Write](https://www.surgeon.drvondawright.com/about) (Double-boarded, fellowship-trained orthopedic surgeon and internationally recognized authority on active aging and mobility; expert in musculoskeletal aging) [1:33:45]
- [Lisa Mosconi](https://www.lisamosconi.com/about-me) (Associate Professor of Neuroscience in Neurology and Radiology and director of the Alzheimer’s Prevention Program at Weill Cornell Medicine) [1:35:00]
- [Mark Cuban](https://en.wikipedia.org/wiki/Mark_Cuban) (American businessman and television personality who launched [Cost Plus Drugs](https://www.costplusdrugs.com/) with the aim of lowering generic drug prices in the US) [1:45:15]
- [Irwin Goldstein](https://www.sdsm.info/meet-dr-goldstein) (Director of San Diego Sexual Medicine, Clinical Professor of Urology at UCSD, founder of the field of sexual medicine, Rachel’s mentor) [1:51:45]
- [Susan Davis](https://research.monash.edu/en/persons/susan-davis) (Professor of Chronic Disease & Ageing at Monash University, Australia, Head of the Monash University Women’sHealth Research Program) [1:57:15]
- [Avrum Bluming](https://www.researchgate.net/profile/Avrum-Bluming) (Emeritus Professor of Medicine, University of Southern California, author of [*Estrogen Matters*](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Lengthen/dp/0316578908/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.qu5_jgKs5LWKALqIfd0QsQ.VdBBKRmbbwzkZXiz_C1GCpVaLon1MjOeVJ7AzZrm4MQ)) [2:00:45]
- [Corinne Menn](https://www.drmenn.com/about.html) (OBGYN and Menopause Society Certified Practitioner, 20 year survivor of breast cancer, and educator) [2:010:00]
- [Ted Schaeffer](https://www.tedschaeffermd.com/) (Chair of the Department of Urology at Feinberg School of Medicine, Urologist in Chief at Northwestern Memorial Hospital, Director of the Polsky Urologic Cancer Institute and Program Director of the Genitourinary Oncology Program at the Robert H. Lurie Comprehensive Cancer Center of Northwestern University) [2:03:00]
- [Mary Claire Haver](https://maryclairewellness.com/provider/dr-mary-claire-haver/) (OBGYN, Menopause Society Certified Practitioner, author of [*The New Menopause*](https://www.amazon.com/New-Menopause-Navigating-Through-Hormonal/dp/059379625X/ref=sr_1_1?crid=2DE9AE3H1E31L&dib=eyJ2IjoiMSJ9.eUOWa_TN0sXbFLm_ms-bN-BpNzAoaMx6G1TjuQWVuemGGS_3zQZbYzsS0mGYjkUl34h3DXtdy8tYdfTK-ymf-fMtBAc-MPAbolLhOxAcwoJonJG8_2TfhgKRMz8ffQ1V0AaXKPx0xmX2yno2PxxCxu2egh5cL9HNrhSGXZKn9wvVReH9hc70f-qAPZsXtas4JUVgP2spmN6zQfIa7VNNj413BaSW3Tv5Y7hNlVoFsBE.cfAhEOcjlCveryYBjG7IQmuqyKViK-ThqV0aNkiOP5E&dib_tag=se&keywords=The+New+Menopause&qid=1745853499&s=books&sprefix=the+new+menopause%2Cstripbooks%2C194&sr=1-1)) [2:07:00]
- [Heather Hirsch](https://heatherhirschmd.com/about/) (OBGYN, founder of the Menopause & Midlife clinic at the Brigham and Women’s Hospital and also served on the faculty at Harvard Medical School, currently a private telemedicine practitioner) [2:07:00]
- [Jancee Dunn](https://www.janceedunn.net/biography) (Well columnist for the *New York Times* and author of [*Hot and Bothered*](https://www.amazon.com/dp/0593542568/?bestFormat=true&k=hot%20and%20bothered%20jancee%20dunn&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_15&crid=5DMI8S9ZIV88&sprefix=hot%20and%20bothere)) [2:04:07]
- [Tamsen Fadal](https://www.tamsenfadal.com/about) (Journalist, author) [2:07:15]

---

![](https://peterattiamd.com/wp-content/uploads/2025/05/DrRubinHead.avif)

##### Rachel Rubin, M.D.

Rachel Rubin earned a BS in Biopsychology and Biomedical Engineering from Tufts University. She continued at Tufts, earning her medical degree. She then completed an internship in general surgery at Medstar Georgetown University Hospital. She did her residency in urology at Georgetown University. After this, she completed a fellowship in sexual medicine and prosthetic urology in San Diego with Dr. Irwin Goldstein. Dr. Rubin is one of only a handful of physicians with fellowship training in sexual medicine for all genders.

Dr. Rubin is a board-certified urologist and sexual medicine specialist who works as a clinician, researcher, and educator. She was the former education chair and current Director-at-Large for the International Society for the study of Women’s Sexual Health (ISSWSH). She serves as associate editor for the Journal of Sexual Medicine Review and the Video Journal of Sexual Medicine. Dr. Rubin launched her own [practice](https://www.rachelrubinmd.com/ourdoctors) in 2022 so she could provide patient-centered care with a multidisciplinary approach, working closely with physical therapists, sex therapists, and other medical and behavioral health providers. She is passionate about providing comprehensive care to her patients and sees her role as a coordinator of care for her patients to help them achieve their sexual health goals and improve their quality of life. She also is passionate about educating her patients, hoping to empower them to take control of their own health and advocate for better care. Further, Dr. Rubin works hard to educate other providers to ensure that they are armed with the tools to provide evidence-based, compassionate care to their patients. [[Rachel Rubin, MD](https://www.rachelrubinmd.com/drrubin)]

Instagram: [@drrachelrubin](https://www.instagram.com/drrachelrubin/?hl=en)

Website: [rachelrubinmd.com](http://rachelrubinmd.com)

X: [@drrachelrubin](https://x.com/drrachelrubin?lang=en)

YouTube channel: [@DrRachelRubin](https://www.youtube.com/c/DrRachelRubin)