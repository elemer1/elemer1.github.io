# #147 – Hussein Yassine, M.D.: Deep dive into the “Alzheimer’s gene” (APOE), brain health, and omega-3s

**Source:** [https://peterattiamd.com/husseinyassine/](https://peterattiamd.com/husseinyassine/)

---

Hussein Yassine is a physician and researcher who studies brain lipid utilization in the context of finding preventative measures for cognitive impairment, specifically Alzheimer’s disease (AD). In my conversation with Hussein, we begin with a fundamental coursework in brain biology—including its architecture and energy systems. We go on to discuss what these systems look like when something goes wrong and cognitive decline ensues. We talk about the evolutionary origins of the ApoE genotype, with specific attention to the ApoE4 allele and its association with AD. We spend time discussing ApoE4 implications for the brain’s fuel utilization, notably omega-3 fatty acids: EPA and DHA. We briefly pivot to the implications of recent omega-3 trials for cardiovascular disease and return to what we currently understand about EPA/DHA and brain health; we contemplate potential dietary interventions across the lifespan to preserve and prolong cognitive function.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/husseinyassine/the_Drive_public.png)

Play

#147 - Hussein Yassine, M.D.: Deep dive into the "Alzheimer's gene" (APOE), brain health, and omega-3s

#147 - Hussein Yassine, M.D.: Deep dive into the "Alzheimer's gene" (APOE), brain health, and omega-3s

1x15s30s

0:002:06:19

## We discuss:

- Hussein’s Background and introduction to brain composition (3:00);
- The blood-brain barrier and brain filtration (8:00);
- Lipids and brain function (13:00);
- How the brain utilizes energy (18:00);
- Apolipoprotein E (ApoE) structure and function in the periphery (27:30);
- ApoE function in the brain (38:15);
- Evolutionary origins of ApoE isoforms (43:45);
- ApoE4 variant and Alzheimer’s Disease (AD) risk (53:30);
- Dietary fuel preference with the ApoE4 allele (1:03:00);
- The role of omega-3 fatty acids in the brain (1:13:30);
- Comparing findings from the REDUCE-IT and STRENGTH trial (1:21:45)
- The relationship between dietary omega-3 intake and brain health (1:34:15);
- Preventing cognitive decline: A critical window for DHA in ApoE4 carriers? (1:42:30);
- Hussein’s ongoing research and recommendations for E4 carriers (1:54:00); and
- More.

§

## Show Notes

## Hussein’s Background and introduction to brain composition [3:00]

- Hussein grew up in Beirut, Lebanon and went to medical school there and moved to the U.S. to do residency training and his fellowship
- Did a fellowship in endocrinology
- Comes from a family with heart disease and diabetes so decided to subspecialize in lipid disorders
- He studied blood lipids for 2-3 before moving to brain lipids

**The brain is composed of 3 main types of cells**

- The brain is a unique compartment that is mostly lipid
- Contains a large amount of lipids—from sterols to different forms of fatty acids
- [Neurons](https://en.wikipedia.org/wiki/Neuron) which are responsible for firing and forming synapses; the regulate how the brain functions
- Helper cells (i.e., [glia](https://en.wikipedia.org/wiki/Glia) and [microglia](https://en.wikipedia.org/wiki/Microglia)) help neurons function in the brain
  - [glial cells](https://en.wikipedia.org/wiki/Glia#:~:text=Glia%2C%20also%20called%20glial%20cells,support%20and%20protection%20for%20neurons.) are the immune cells responsible for clean up
  - [Microglial cells](https://en.wikipedia.org/wiki/Microglia) are cleanup specialists and have been linked to neurodegenerative diseases
- [astrocytes](https://en.wikipedia.org/wiki/Astrocyte#:~:text=Astrocytes%20are%20a%20sub%2Dtype,million%20synapses%20at%20a%20time.) repair and supply nutrients; regulate energy storage production

## The blood-brain barrier and brain filtration [8:00]

**The brain is surrounded by the blood-brain barrier**

- separates the blood vessels and the blood inside the blood vessels from the brain
- designed to protect the brain and to maintain a stable environment
- composed of:
  - [endothelial cells](https://en.wikipedia.org/wiki/Endothelium) called capillary cells that have a lining of tight junctions
  - [Pericytes](https://en.wikipedia.org/wiki/Pericyte) surround those endothelial cells and support the maintenance of the barrier
  - [mural cells](https://en.wikipedia.org/wiki/Mural_cell#:~:text=Mural%20cells%20are%20the%20vascular,for%20vascular%20development%20and%20stability.), or wall cells, make up the matrix surrounding pericytes and capillary cells

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig.1-hussein.png)

**Figure 1.** Schematic representation of the blood–brain barrier. (A) Scheme of the neurovascular unit that constitutes the BBB and (B) the main routes of the crossing of molecules to the CNS are represented [[source](https://www.researchgate.net/figure/Schematic-representation-of-the-blood-brain-barrier-Notes-A-Scheme-of-the_fig1_281486047)]

**Cerebral spinal fluid (CSF) os the “sewage system” of the brain**

- Allows drainage from the brain cells, from the interstitial fluid
- Fluid surrounding brain cells that we call the **interstitial fluid**
- By products of brain cells—protein aggregates for examples, which build up in diseases like Alzheimer’s disease (AD) are cleared by the CSF
- The [choroid plexus](https://en.wikipedia.org/wiki/Choroid_plexus#:~:text=The%20choroid%20plexus%20or%20plica,the%20regions%20of%20choroid%20plexus.) pumps water-like fluid into the CSF. This motion of fluid through the brain washes it
  - Interferes with blood circulation to clear out metabolic waste from the CSF into the blood for excretion

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig.-2-hussein-527x1024.png)

**Figure 2.** The CSF activity is critical for maintaining the sewage system of the brain and the choroid plexus shuttles the waste products into the blood from the brain for excretion [[source](https://www.mdpi.com/1422-0067/21/18/6457)]

- Illness makes it difficult to clear CSF
  - People can be born with malformations that obstruct the flow of CSF, and they develop conditions, where some of these compartments within the brain expand and enlarge
  - Shunts can help drain fluid from the brain and into the abdomen
- The brain is a bloodless organ

## Lipids and brain function [13:00]

- The reason the brain is so lipid-laden relative to other organs is because it is an electrical system that requires lipids
- Cells of the brain require lipid and cholesterol

**The brain is functionally different**

- An electrical system that constantly fires
- The brain’s function is signal transduction
  - Maintaining electric potential and conduction compared to another cell type like a [cardiac myocyte](https://en.wikipedia.org/wiki/Cardiac_muscle_cell) of heart muscle that is mechanical
    - A mechanical cell that has to pump all the time, to be able to maintain a certain pressure and blood flow
    - Requires strong cytoskeletal elements, such as actin or myosin but less lipids
- Requires “electricity” that moves within the neuronal map; requires lipids
  - For the neuron its [myelin](https://en.wikipedia.org/wiki/Myelin)
  - For the synapse it’s the [synaptosome](https://en.wikipedia.org/wiki/Synaptosome#:~:text=A%20synaptosome%20is%20an%20isolated,differential%20and%20density%20gradient%20centrifugation.), the synapse body that needs to conduct and depolarize—changing electric potential across the membrane
- Lipids facilitate moving [glutamate](https://en.wikipedia.org/wiki/Glutamic_acid), or glutamine, inside of the cell
- Weighs about 2% of our body weight but is responsible for about 20% of our energy consumption

## How the brain utilizes energy [18:00]

The way the brain utilizes energy represents a knowledge gap in the field; The brain does the following:

1) Regulates glucose content but is not dependent on insulin signalling

- The rest of the body regulates transporter via insulin that acts with [GLUT4](https://en.wikipedia.org/wiki/GLUT4#:~:text=GLUT4%20is%20the%20insulin%2Dregulated,cloned%20and%20mapped%20in%201989.) which
  - allows an insulin-dependent mechanism to enter glucose into pumping muscles or adipocytes
  - You can induce GLUT4 expression by exercising or by the changes in body weight
  - It responds to the external environment
- In contrast, the blood-brain barrier uses [GLUT1](https://en.wikipedia.org/wiki/GLUT1) predominantly, which is regulated by the peripheral glucose concentration
  - Not controlled by what you eat
  - Can be regulated to protect the brain:
    - Type 2 diabetes, where there is systemic hyperglycemia, the brain protects itself by reducing GLUT1 expression at the blood-brain barrier
    - During a prolonged fast and the system is hypoglycemic, the brain upregulates GLUT1 at the blood-brain barrier to extract glucose from circulation
    - In normal physiologic states it does not fluctuate very much
    - In illness in which there is destruction of GLUT1 transporters—like  leakage or destruction of the blood-brain barrier—the brain now struggles to capture glucose from the system and has to respond to glucose shortage

2) Prefers glucose instead of fat

- Compared to muscles that have lots of options for fuel (e.g., glucose, fatty acids, lactate)
- There are no fat depots or storage sites
- Prefers fat to integrate into the myelin sheath or the synaptosome to regulate membrane fluidity, to help with depolarization

3) When glucose is not available, the brain extracts ketone bodies produced by fatty acid oxidation in the peripheral system

- When the brain goes through energy crises it can extract energy (ATP) from fat. But there is a price tag called [oxidative stress](https://en.wikipedia.org/wiki/Oxidative_stress)
- Brain cells (e.g., neurons, glial, astrocytes) have partitioned roles with different fuel preferences
  - Neuron prefers lactate over glucose
  - Astrocytes take p glucose and produce lactate, “donating” the lactate to the neuron
- When glycogen is depleted, the brain extracts ketone bodies through the blood-brain barrier to maintain its firing

## Apolipoprotein E (ApoE) structure and function in the periphery [27:30]

**ApoE and ApoC3 are the conductors of the peripheral circulation system**

- If we consider the lipoproteins in the peripheral circulation system to be like an orchestra, the ApoE and ApoC3 regulate the speed at which things are happening; they are the conductors of the orchestra
- Whereas ApoB is largely associated with LDL particles as well as VLDL and LDL; and APOA1 is associated with the HDL family of particles…ApoE and ApoC3 are interchangeable
  - They play different roles and can decide whether a lipoprotein is going to stay in circulation (ApoC3) or get cleared (ApoE)

**ApoE has many roles in the circulatory system**

- Imagine you drink a milkshake
  - The fat from the milk is packaged in chylomicrons which are known to cary ApoB48
  - In the beginning there would be more ApoC3 which would keep the lipoprotein from getting lipolyzed
  - The ApoC3 blocks lipoprotein lipase
  - When the lipoprotein gets to be a certain size, the HDL will donate the ApoE to get taken up in the liver
  - When the particle gets smaller, the ApoC3 will fall off and the ApoE will get reassembled such that the VLDL particle gets cleared
  - In metabolic syndrome, there is an inefficient process because ApoE and ApoC3 are not as mobile — ApoC3-enriched small density LDL particles are not cleared
- ApoE has an affinity for the LDL receptor in the liver but it is higher for [LRP1](https://en.wikipedia.org/wiki/LRP1) which is kind of LDL receptor

**ApoE structure**

- ApoE is a bit more complicated than the rest of the lipoproteins because it can take many shapes and forms and infinities can change based on lipid binding
- It has two arms: the N-terminus binds to the receptor and the C-terminus is embedded inside the lipid core of the lipoprotein particle
- The mutation of ApoE4 which substitutes the cystine with the arginine changes how ApoE folds and unfolds

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-3-hussein-1024x285.png)

**Figure 3.**The structure of APOE isoforms. APOE is a soluble secreted protein, with N-terminal and C-terminal domains linked by a central hinge region. The N-terminal domain contains the receptor binding domain (indicated in green), and the C-terminal domain contains the lipid binding region (indicated in orange). [[source](https://www.researchgate.net/figure/The-structure-of-APOE-isoforms-APOE-is-a-soluble-secreted-protein-with-N-terminal-and_fig1_331023115)]

**ApoE concentration**

- Cannot make an ApoE assessment by measuring concentration; it is too dynamic in function and does not correlate to a given concentration
- ApoC3 at extremes can be predictable to understand residual risk and metabolic disease
- In comparison…
  - We can measure plasma ApoB and ApoA in circulation
  - ApoB is predictably linked to  LPa, VLDL, IDL, and LDL concentrations—it is used as a surrogate for LDL concentration; with a 1:1 correlation
  - We use APoA1 concentration as a surrogate for HDL concentration; estimated as a 1:1 or 1:4 concentration

## ApoE function in the brain [38:15]

- In the brain there are no LDL, VLDL, HDL but there are Apo lipoprotein particles
- ApoE in the brain is not facilitating clearance of lipids or the rate by which lipolysis is happening
- Its role in the brain is largely supporting the astrocytes
- For astrocytes to support neurons they need to efficiently crosstalk, facilitated by ApoE diverse functions

**ApoE functions differently for different cell types**

- With glial cells can regulate the exchange of lipids and thus, inflammation
- With astrocytes can take out cholesterol and give it to the neuron

- ApoE increases after damage
  - In Hussein’s rat model [study](https://www.researchgate.net/publication/11168217_Treatment_of_the_chronic_inflammation_in_peripheral_target_tissue_improves_the_crushed_nerve_recovery_in_the_rat_Histopathological_assessment_of_the_nerve_recovery) the nerve was severed
  - ApoE was released at very high rates to make sure repair would occur
  - Structural flexibility to transport lipids allows it to regulate what receptors and transporters the cell can actually express

**A fundamental difference between ApoE and ApoB**

- ApoB is taken up by a liver cell and degraded in the lysosome; this allows for drugs like statins and PCSK9i
- ApoE escapes degradation: once it is taken up by a liver cell or an astrocyte or a neuron, it is recycled
- Hussein’s [research](https://www.annualreviews.org/doi/full/10.1146/annurev.nutr.19.1.141) suggests that ApoE4 moves across the blood-brain barrier via LRP1 from the plasma to the brain

**ApoE time in circulation**

- The protein confers different properties depending on the lipoprotein
- If it’s in lipid-free form, it can be rapidly excreted or disappear from circulation
- Bound to HDL it hangs around longer
- Bound to VLDL it takes less time because clearance rates are faster than hDL

## Evolutionary origins of ApoE isoforms [43:45]

> **“Nothing in Biology Makes Sense except in the Light of Evolution” – Theodosius Dobzhansky**

**ApoE protein exists in different forms**

- Originally (thousands of years ago) there was only the ApoE4—a single isoform
- It is has a very important inflammatory function
- Capable of turning immune cells, glial cells, into an acute inflammatory state by changing a cell’s lipid content

**ApoE4 inflammatory regulation conferred an evolutionary advantage**

- The ancestral variant has a greater capacity to aggregate
- When it starts to aggregate inside the microglia, it creates an acute inflammatory response that makes it more efficient in immune response
- ApoE4 women had a better chance of giving childbirth and protection from peripheral sepsis, compared to non-E4 women in the slums of Brazil or in certain areas in Africa
- [Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5349792/) show that those who had E4 allele may have had better luck surviving, not only parasitic infections in certain countries like Nigeria but also tend to have better outcome with hemophilia
- With E4 the brain is better equipped to to deal with bacterial infection

 **Environmental changes lead to other variants**

- Lifespan has increased so in older age, there is more E4 aggregate — an issue that did not occur when people died younger
- E3 variant showed up about 50,000 years ago and E2 variant showed up about 10,000 years ago
- Mass movement out of the African continent came with changes in diet
  - From meat to more plants
  - From higher-fat to higher-carbohydrate
  - Allowed ApoE3 and E2 to be more successful
- In contrast, ApoE4 thrives on a lipid-providing environment

**ApoE4 renders lipids the preferred fuel source**

- ApoE4 makes GLUT1 transport less successful
- The hypothesis is that ancestral diets that were high in fat favored ApoE4 but when it switched to plant-based, the effect of ApoE4 on GLUT1 transport fell out of favor
- ApoE3 and ApoE2 favors higher glucose utilization and is therefore more adaptive for a plant-based diet

## ApoE4 variant and Alzheimer’s Disease (AD) risk [53:30]

- ApoE4 became a predictor of AD in the late 1980’s
- [Allen Roses](https://www.nytimes.com/2016/10/06/science/allen-roses-who-upset-common-wisdom-on-cause-of-alzheimers-dies-at-73.html) at Duke genetically profiled a large number of common ApoE variants of people dying with, and without AD
- Published a [case series](https://scholar.google.com/scholar_lookup?journal=Science+(80-.)&title=Gene+dose+of+apolipoprotein+E+type+4+allele+and+the+risk+of+Alzheimer%E2%80%99s+Disease+in+Late+Onset+Families&author=EH+Corder&author=AM+Saunders&author=WJ+Strittmatter&author=DE+Schmechel&author=PC+Gaskell&volume=261&publication_year=1993&pages=921-923&) that identified patients with AD had higher ApoE4 compared to non-AD
- [Amyloid cascade hypothesis](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) was the prevailing hypothesis at the time—amyloid plaques would form and subsequent tangles
- A larger longitudinal [study](https://www.pnas.org/content/90/5/1977.short) followed people progressing through disease and confirmed that ApoE4 increases chances of getting AD vs non-E4 carriers

**ApoE4 risk for disease pathogenesis**

- Two copies of ApoE4 increases AD 12-fold
- One copy of E4 will increase AD chance between 2- to 4-fold
- [ApoE genotypes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3162068/) 43 means that someone carries one copy of E4 and 24 is protective
  - ApoE2 is thought to be protective against getting AD
  - Sometimes genotype 24 carries behave as E4 and some as E2—depends on how well proteins are expressed inside of cells

**Not all ApoE4 carriers have the same risk of AD**

- Varies by ethnicity
  - In [Nigerians](https://www.ncbi.nlm.nih.gov/books/NBK25535/), there is lower risk compared to Japanese or Americans
  - Hispanic, Latino, LatinX populations carrying E4 does not produce the same AD pathogenesis
- Variations has to do with the ApoE gene locus
  - It is part of a [haplotype](https://en.wikipedia.org/wiki/Haplotype)—a group of genes that are inherited together
  - ApoE4 is found on chromosome 19 and has 20-30 different gene variants that are co-inherited with ApoE4
  - [Linkage equilibrium](https://en.wikipedia.org/wiki/Linkage_disequilibrium) differs between ethnicities
  - Different version of other genes get introduced with ApoE expression
  - Suggests that ApoE4 by itself is not sufficient for disease but depends on the environment and other genes

 **Gene-gene and gene-environment interactions and AD**

- [Study](https://www.medrxiv.org/content/10.1101/19011015v1) showed that ApoE4 by itself may not substantially increase the risk of AD
  - Diabetic carriers had an increased AD risk compared to diabetics without E4 or E4 carriers without diabetes
  - By itself, AD with E4 was barely increased above AD risk for non-E4 carriers

## Dietary fuel preference with the ApoE4 allele [1:03:00]

**ApoE4 carrier risk for AD is based on an age model**

- Carriers only start to have problems at a certain age, but only some of them

- - There is a subset of those who are aging and getting disease

- Husein is [studying](https://pubmed.ncbi.nlm.nih.gov/32587511/) how ApoE4 interacts with the diet and how that interaction can change disease process

**E4 carriers are less capable of regulating fuel modulation mechanisms including GLUT1**

- E4 makes GLUT1 less successful at the blood-brain barrier
- GLUT1 is regulated by the peripheral glucose concentration such that when it is low the brain takes priority
- When glucose is high in the periphery, GLUT1 is less active to protect the brain
- E4 carriers are more susceptible to disease because the brain fuel source gets interrupted
- Other [studies](https://jamanetwork.com/journals/jamaneurology/article-abstract/2538230) also show that ApoE4 also effects omega-3 fatty acid transport to the brain

**ApoE4 transmits risk of disease through an energy crisis**

- The ability to regenerate and sustain a certain energy production status decreases with age
- This strains the brain and diet may make a difference
- Certain diets can accelerate aging or create a form of stress that can be the second hit to carriers—accelerate aging brain that is disease
- Diet interaction is contingent on aging and a second or third hit, or stressor

**E4 allele implication in type 2 diabetes**

- ApoE4 could be a factor for why certain person may get type 2 diabetes
- ApoE4 by itself creates a system with aging that makes an individual insulin-resistant
- ApoE4 interacting with this phenotype is probably more complicated than A1C for average blood glucose and the genotype in a large population

**Hypotheses that link ApoE4 with disease and aging**

- Hypotheses are not mutually exclusive but likely work synergistically to compound a problem
  - Neuronal energy starvation: the energy hypothesis refers to E4 hindering fuel transport across the blood-brain barrier
  - Overly active immune response predisposes inflammation: refers to E4 carrier being predisposed to neuroinflammation
  - Leaky blood-brain barrier loss of integrity: component refers to the blood-brain barrier allowing toxins to get into the brain and shrink cells—[investigated](https://pubmed.ncbi.nlm.nih.gov/30643288/) by a research group at USC

## The role of omega-3 fatty acids in the brain [1:13:30]

**The brain is largely composed of polyunsaturated fatty acids (PUFA)**

- Some [studies](https://pubmed.ncbi.nlm.nih.gov/20329590/) report that 40%-50% of the brain is composed of PUFA
- docosahexaenoic acid ([DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid)), eicosapentaenoic acid ([EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid)), alpha-linoleic acid ([ALA](https://en.wikipedia.org/wiki/Alpha-Linolenic_acid)) are omega-3; arachidonic acid ([AA](https://en.wikipedia.org/wiki/Arachidonic_acid)) is an omega-6
- PUFAs in neuronal membrane facilitate neuronal firing and allows conduction and the brain to work efficiently
- DHA is the main building block and most common in the brain
- EPA is less abundant but may comport more anti-inflammatory properties compared to DHA
- There is limited interconversion between DHA/EPA although EPA can become DHA and visa versa

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-4-hussein-1024x771.png)

**Figure 4.** The anti-inflammatory effects of omega-3 PUFAs are attributed to (1) prevention of the conversion of arachidonic acid into prostaglandins and leukotrienes or (2) its ability to function as an alternative substrate to produce less potent mediators. (3) Resolvins, protectins, and maresins, distinct anti-inflammatory and pro-resolving lipid mediators derived from omega-3 PUFAs. [[source](https://www.sciencedirect.com/science/article/pii/S0914508715002300)]

**Omega-3 fatty acids come from the diet**

- The human body cannot make DHA/EPA from scratch
- ALA precursor is converted by a group of desaturases into DHA and EPA
- Widely believed this conversion remains in the range of 0.5% to 5% at most

**Dietary consumption limitations in the U.S. and disease predisposition**

- The U.S. is poor in DHA/EPA
- DHA averages 100mg/day
- Standard diet may not provide enough omega-3’s to the brain
- It is likely that this contributes to disease pathogenesis
- But supplementation effectiveness is not clear
  - A range of supplement trial results
  - Supplements range in type, quality, forms so trials are not all like-for-like
- Supplementation can come in various forms but it has to be marine
  - Can be produced by microalgae (triglyceride (TG)-based)
  - Refined from fish oils (ethyl esters or resiterfied TG-based)
  - Krill oils (phospholipid-based)
- Omega-3 deficiency may be at a higher increased risk of disease; a deficiency state that predisposes a person to disease

## Comparing findings from the REDUCE-IT and STRENGTH trial [1:21:45]

- High-dose EPA in the context of cardiovascular disease contrasts cardiovascular disease and AD dementia
  - Cardiovascular disease has a well-described and well-understood process:
    - Plaques form and rupture => An adverse event occurs
  - AD dementia is chronic and slowly progresses over years or decades
    - Manifests in the loss of function of daily activities, cognitive deficits

**The impetus for the** [**REDUCE-IT**](https://www.nejm.org/doi/full/10.1056/nejmoa1812792) **trial**

- Japanese [studies](https://pubmed.ncbi.nlm.nih.gov/24267237/) from a decade ago suggested that EPA:AA ratio was associated with less cardiovascular disease (CVD) in certain regions in Japan
- Trials that used EPA supplementation were positive but not conclusive; used around 2g of EPA but trends were not strong enough to make official recommendations
- Led to concerted U.S. efforts to answer if high-dose EPA translated to decrease CVD death
- The REDUCE-IT trial (2019) was a large multicenter trial that administered 4g of EPA to people with diabetes, high triglycerides as EPA is known to lower triglycerides (TGs)

**REDUCE-IT trial outcome**

- compared to the placebo arm, those who were given 4g of EPA/day did substantially better=less CVD events
- The flaw: used mineral oil placebo
- Mineral oil increased CVD events
  - Whereas other oils are larger percent n-6—corn oil (61% LA); safflower oil (77% LA); canola oil (21% LA)
  - [Mineral oil](https://en.wikipedia.org/wiki/Mineral_oil) can take various forms like mixes of crude oil (i.e., petroleum)
  - Was not considered from a health perspective but rather what was economic and available

[**STRENGTH trial**](https://jamanetwork.com/journals/jama/article-abstract/2773120) **vs REDUCE-IT trial outcome comparison and implications**

- STRENGTH trial (2020) compared 4g/day of omega-3 supplement (carboxylic acid ([CA](https://en.wikipedia.org/wiki/Omega-3_carboxylic_acids)))to corn oil placebo in addition to statin therapy
- The drug is an EPA/DHA ratio of: DHA at 15-25 % and a concentration of EPA at 50-60%.
- Patients taking statins at high CVD risk did not show significant different CVD event with the addition of omega-3 FA

**Potential reasons for the outcome differences:**

- Mineral oil “placebo” was not neutral to elicit a large disparity between EPA and placebo administration
- Was the dose of EPA in the STRENGTH trial — a mix of EPA and a smaller amount of DHA—not enough to confer a similar benefit?
- Does an EPA/DHA ratio, used in the STRENGTH trial, not confer the same benefit?
- Was the length of study (4 year) not enough time to decrease CVD event outcome in a high-risk, sick cohort?

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-5-hussein-1024x827.png)

**Figure 5.** Strength trial vs Reduce-It trial comparison of cohort baseline characteristics. Fatty Acid Research Institute (FARI)

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-6-hussein-1024x573.png)

**Figure 6.** STRENGTH trial vs REDUCE-IT  trial comparison of CVD events by intervention. Fatty Acid Research Institute (FARI)

**The difference between a drug and a supplement**

- A drug produces a cascade effect
- Consider the prevailing hypothesis for how statins work:
  - Inhibits [HMG-CoA reductase](https://en.wikipedia.org/wiki/HMG-CoA_reductase) (the rate-controlling enzyme in the pathway that produces cholesterol)
  - Increase the expression of LDL receptor in the liver
  - Deplete cholesterol circulating by LDL or VLDL particles for excretion
  - LDL cholesterol decreases as small density LDL cholesterol particles => lower risk for atherosclerosis
  - This cascade effect is decreased CVD event outcome
- By contrast, there is not a good understanding of how high-dose EPA works, were it to be used as a pharmaceutically prescribed drug
- One possibility is that EPA has anti-inflammatory effects
- Plausible that EPA results in less plaque—not due to reduction of TGs but by reducing inflammation

## The relationship between dietary omega-3 intake and brain health [1:34:15]

**The prevailing understanding that EPA and DHA is critical for brain function**

- DHA deficiency in mouse animal model results in microcephaly

- National Institute of Health ([NIH](https://www.nih.gov/)) landmark [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5572498/) in mouse model showed that pregnant mice deprived of DHA had offspring with neurons that did not make enough synapse

- Signified that DHA deficiency is detrimental to brain function
- Human [studies](https://academic.oup.com/ajcn/article/99/3/734S/4577501) show that PUFA-deficient lactating milk is associated with poorer academic outcomes

- Led to the FDA recommendation of DHA and AA enriched infant formula

- However, it is not clear the age range, or critical window, in which DHA deficiency comports the most substantial impact
- Moreover, the relationship between aging and deficiency status is not evident
  - The brain develops rapidly from birth to 6 years,  at which point it is almost fully developed
  - The brain starts to accumulate proteins and there is less exchange with plasma
  - The rapid accretion of lipids is important for babies and young children to get exposed to enough omega-3s
  - Omega-3 lipids slows between 6yo to 12yo or 13yo, after which pools of lipids are relatively stable
  - Stability is important so that the brain has a constant environment

- Smaller [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4175558/) suggest ramifications later on if omega-3 deficient at an early age. Such as: subtle cognitive impairments, anxiety disorders, mood disorders, depression, but other studies don’t find these associations

- The role of omega-3 in the diet between 6yo-60yo is more difficult to understand

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-7-hussein.jpg)

**Figure 7.** Critical neural development window as it pertains to alterations in essential fatty acid (blue box) and iron (red boxes) metabolism during early human brain development.[[source](https://media.springernature.com/lw685/springer-static/image/art%3A10.1203%2F01.PDR.0000160542.69840.0F/MediaObjects/41390_2005_Article_BFpr2005138_Fig1_HTML.jpg)]

**The half-life of lipids in the brain vs other compartments in the body**

- It takes 3-6 weeks for the dose of DHA to reach plateau, or saturation kinetics, after being given a maximum dose of DHA or EPA
- This is determined by the half-life of transporter proteins of the lipids: HDL as the major phospholipid carrier
- The amount of time the DHA remains in neuronal membranes is substantially longer than that for DHA on the surface of a phospholipid, or on HDL, or with an albumin carrier and blood
- Brain lipids should not substantially fluctuate, in order to keep a stable environment
- The implications are that studies that investigate what happens to those who consume enough omega-3s vs those who don’t would have to be 5-10 years=resource and effectiveness problem (e.g., Can people follow a prescription consistently for that amount of time?)

## Preventing cognitive decline: A critical window for DHA in ApoE4 carriers? [1:42:30]

**Hussein’s lab investigates diet and age profile intersection to evaluate cognitive outcomes**

- The younger E4 brain (30’s) utilizes omega-3s as fuel substrate
- One of the [studies](https://pubmed.ncbi.nlm.nih.gov/28335828/) took younger ApoE4 carriers and injected them with labeled DHA into plasma to estimate how much DHA gets past the blood-brain barrier into the brain using PET scan
  - Reported that  ApoE4 carriers had greater uptake of DHA in the brain compared to non carriers
  - Younger, cognitively normal E4 carriers better utilized DHA from blood to maintain cognitive function
- Epidemiology study from [Netherlands](https://scholar.google.com/scholar_lookup?journal=Ann+Neurol&title=Dietary+fat+intake+and+the+risk+of+incident+dementia+in+the+Rotterdam+study&author=S+Kalmijn&author=LJ+Launer&author=A+Ott&author=JCM+Witteman&author=A+Hofman&volume=42&publication_year=1997&pages=776-782&pmid=9392577&) reported E4 carriers who consumed a good amount of fatty fish combined with leafy vegetables had less disease at 60yo than those who did not

**Hussein’s research focuses primarily on DHA and brain function**

- The roles of EPA and DHA in the brain are different
  - DHA is the main omega-3 that makes the building blocks of synapses in the brain
  - EPA behaves as an anti-inflammatory signaling molecule
- EPA is a primary focus in the context of vascular disease like atherosclerotic strokes
- DHA is a primary focus for investigating the synapse and what it requires to form neurotransmission

**ApoE4 carriers across a lifespan have change in the ability to utilize fats as fuel**

- At a certain age (i.e., 55yo-70yo)  the ability of the ApoE4 brain to capture FAs from blood gets compromised
- This happens around the same time that the GLUT1 receptors are compromised, when the blood-brain barrier itself starts to get compromised
- When the blood-brain barrier starts disintegrating, neither GLUT1 or omega-3 transporters are working well
- A randomized clinical [trial](https://pubmed.ncbi.nlm.nih.gov/21045096/) evaluated patients with mild Alzheimer’s disease given 2g/d of DHA versus placebo over a 15mo period
  - Population age between 65yo-80yo
  - Reported no effect on cognitive impairment (CI); a negative trial
  - E4 carriers had no response and non-carriers appeared to improve on the primary outcome of CI
  - E4 carriers were less responsive to DHA than non-E4 carriers

**There seems to be a** **critical window** **for an E4 carrier to integrate and assimilate DHA—before the blood-brain barrier fails in FAs transport and GLUT1**

- Active large clinical trial called [PREVENT-E4](https://clinicaltrials.gov/ct2/show/NCT03613844) addresses how older E4 carriers assimilate supplemental DHA
  - Had to decide on age profile:
    - if younger E4 carriers are chosen, they could longitudinally demonstrate prevention but could result in a futility study with low compliance
    - Older E4 carriers 55yo-70yo would cognitively decline with time but it may be too late for successful intervention
  - Study designed decided on 55yo-70yo cohort to see if 2g/day DHA could prevent cognitive decline
  - Ongoing recruitment in Los Angeles to end in 2023 and publish in 2024-2025
- It is difficult to impossible to effectively do a study that puts 35yo on DHA for their lifetime to see a hard outcome, that is a meaningful reduction in AD later in life

**The “critical window” question cannot be neatly effectuated by clinical trial**

- Hussein believes that identifying a biomarker would be most promising
  - For example LDL cholesterol as a target to lower for CVD prevention
  - Generally speaking, it is agreed that lowering LDL cholesterol is associated with lower atherosclerosis disease

**Hussein has hopes for a biomarker that can be targeted**

- He hopes for a biomarker in 35yo-40yo that can be targeted to protect against AD dementia and cognitive decline in the following decades
- What is the cost-benefit of:
  - Doing nothing?
  - Taking a given amount of DHA through diet or supplement?

## Hussein’s ongoing research and recommendations for E4 carriers [1:54:00]

> “When we talk about modifying ApoE4 risk, we often are referring to modifying the vascular effects of Apo E4. So not only will you get cardiovascular benefit, but you will also get a brain benefit because the blood vessels in Alzheimer’s disease have as much of a role as the actual neurons and astrocytes and so forth.” — Hussein Yassine, M.D.

**Hussein’s upcoming publications on older E4 carrier fuel utilization**

- In an older E4 brain, once dementia starts there is a failure to utilize glucose as a  source of energy and [phospholipase enzymes](https://en.wikipedia.org/wiki/Phospholipase) that facilitate cellular auto-digestion are upregulated
- The enzyme is activated in the E4 brain to possibly extract FAs for its own neuronal myelin to produce ATP
- [Phospholipase A2 enzyme](https://en.wikipedia.org/wiki/Phospholipase_A2) (PLA2) control omega-3 and omega-6 FA utilization in the brain
  - Calcium-dependent enzyme of phospholipase A2
  - Strongly upregulated in AD disease brains who also carry the E4 genotype vs non-AD brains with carry E4 genotype
- The analysis accessed [RUSH](https://rushu.libguides.com/rusharchives/RUMC) AD disease research archive and [identified](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3439198/) PLA2 enzymes that is hyperactive in E4 brains
  - ApoE4 brain activates these enzymes which take away FAs from the phospholipid membrane and degrades the Fas for ATP
  - The effect is neuronal inflammation and oxidative stress
  - Not the same patterns in non E4 carriers with AD dementia
- Has implications for recommendations to younger E4 carriers vs older E4 carriers

**Once E4 carriers have disease there is likely less benefit from ketone supplementation compared to non-carriers**

- The **largest** [**studies**](https://jamanetwork.com/journals/jamaneurology/article-abstract/2538230) to date do not demonstrate beneficial response to supplementation once E4 carriers have disease
- The degenerating blood brain barrier compromising the transport of ketone bodies, the same way it has compromised glucose and omega-3 FAs
- Dietary interventions at this stage may not be very effective
- Highlights the importance of getting the right intervention before you get to that stage

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-8-hussein-1024x733.png)

**Figure 8.** Interaction of omega-3, apoE4, disease stage in cognitive outcomes [[source](https://jamanetwork.com/journals/jamaneurology/article-abstract/2538230)]

**Hussein does not recommend omega-3 supplementation due to lack of evidence**

- He can recommend that people have at least 1 serving of fatty fish per week
- Epidemiology [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4772061/) suggest that E4 carriers who consume 1 serving of fatty fish per week *may* be providing enough omega-3s to the brain to help mitigate disease longer-term
- The best advice Hussein can give is to maintain adequate omega-3 consumption from fatty fish and not supplements and to control blood pressure and exercise throughout the lifespan

**Exercise may help mitigate cognitive decline**

- PET imaging [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3583203/) reports that E4 carriers who exercise have less amyloid plaque buildup compared to E4 carriers who did not exercise
- Multiple factors including high level of education and hypertension control protected E4 carriers from dementia vs E4 carriers who had less education and worst blood pressure control

§

## Selected Links / Related Material

**Hussein’s rat model study where the nerve was severed to observe ApoE increases after damage**: [Treatment of the chronic inflammation in peripheral target tissue improves the crushed nerve recovery in the rat: Histopathological assessment of the nerve recovery](https://www.researchgate.net/publication/11168217_Treatment_of_the_chronic_inflammation_in_peripheral_target_tissue_improves_the_crushed_nerve_recovery_in_the_rat_Histopathological_assessment_of_the_nerve_recovery) (Kato et al., 2002) [39:30]

**ApoE4 moves across the blood-brain barrier via LRP1 from the plasma to the brain**: [THE MAMMALIAN LOW-DENSITY LIPOPROTEIN RECEPTOR FAMILY](https://www.annualreviews.org/doi/full/10.1146/annurev.nutr.19.1.141) (Hussain et al., 1999) [42:15]

**Studies show that those who had E4 allele may have had better luck surviving not only parasitic infections in certain countries like Nigeria, but also tend to have better outcome with hemophilia**: [Apolipoprotein E4 is associated with improved cognitive function in Amazonian forager-horticulturalists with a high parasite burden](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5349792/) (Trumble et al., 2017) [46:45]

**A case series that identified patients with AD had higher ApoE4 compared to non-AD**: [Gene dose of apolipoprotein E type 4 allele and the risk of Alzheimer’s disease in late onset families](https://science.sciencemag.org/content/261/5123/921.abstract) (Corder et al., 1993) [53:45]

**Large longitudinal study confirmed that ApoE4 increases chances of getting AD vs non-E4 carriers**: [Apolipoprotein E: high-avidity binding to beta-amyloid and increased frequency of type 4 allele in late-onset familial Alzheimer disease.](https://www.pnas.org/content/90/5/1977.short) (Strittmatter et al., 1993) [53:45]

**Nigerians have a lower risk of dementia compared to Japanese or Americans**: [Critical Perspectives on Racial and Ethnic Differences in Health in Late Life.: Ethnic Differences in Dementia and Alzheimer’s Disease](https://www.ncbi.nlm.nih.gov/books/NBK25535/) (Manly and Mayeux, 2004) [58:00]

**Study showing that ApoE4 by itself may not substantially increase the risk of AD**: [Exceptionally low likelihood of Alzheimer’s dementia in APOE2 homozygotes](https://www.medrxiv.org/content/10.1101/19011015v1) (Reiman et al., 2019) [59:30]

**Husein is studying how ApoE4 interacts with the diet and how that interaction can change disease process**: [APOE Alleles and Diet in Brain Aging and Alzheimer’s Disease](https://pubmed.ncbi.nlm.nih.gov/32587511/) (Yassine and Finch, 2020) [1:07:30]

**Study showing that ApoE4 also effects omega-3 fatty acid transport to the brain**: [Association of Serum Docosahexaenoic Acid With Cerebral Amyloidosis](https://jamanetwork.com/journals/jamaneurology/article-abstract/2538230) (Yassine et al., 2016) [1:09:45]

**Research out of USC showing that loss of integrity in the blood-brain barrier (leaky blood-brain barrier) allows toxins to get into the brain and shrink cells**: [Blood-brain barrier breakdown is an early biomarker of human cognitive dysfunction](https://pubmed.ncbi.nlm.nih.gov/30643288/) (Nation et al., 2019) [1:12:30]

**Some studies report that 40%-50% of the brain is composed of PUFA**: [Essential fatty acids and human brain](https://pubmed.ncbi.nlm.nih.gov/20329590/) (Chang et al., 2019) [1:14:00]

**The REDUCE-IT trial**: [Cardiovascular Risk Reduction with Icosapent Ethyl for Hypertriglyceridemia](https://www.nejm.org/doi/full/10.1056/nejmoa1812792) (Bhatt et al., 2019) [1:21:45]

**Japanese studies from a decade ago suggested that EPA:AA ratio was associated with less cardiovascular disease (CVD) in certain regions in Japan**: [Association between ratio of serum eicosapentaenoic acid to arachidonic acid and risk of cardiovascular disease: the Hisayama Study](https://pubmed.ncbi.nlm.nih.gov/24267237/) (Ninomiya et al., 2013) [1:22:30]

**The STRENGTH trial**: [Effect of High-Dose Omega-3 Fatty Acids vs Corn Oil on Major Adverse Cardiovascular Events in Patients at High Cardiovascular Risk: The STRENGTH Randomized Clinical Trial](https://jamanetwork.com/journals/jama/article-abstract/2773120) (Nicholls et al., 2020) [1:29:00]

[**NIH**](https://www.nih.gov/) **studies in mouse model showed that pregnant mice deprived of DHA had offspring with neurons that did not make enough synapse**: [Perinatal Brain Docosahexaenoic Acid Concentration Has a Lasting Impact on Cognition in Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5572498/) (Lozada et al., 2017) [1:35:00]

**Human studies show that PUFA-deficient lactating milk is associated with poorer academic outcomes**: [Impact of maternal diet on human milk composition and neurological development of infants](https://academic.oup.com/ajcn/article/99/3/734S/4577501) (Sheila M Innis, 2014) [1:36:00]

**Smaller studies suggest ramifications later on if omega-3 deficient at an early age**: [Omega-3 Fatty Acid and Nutrient Deficits in Adverse Neurodevelopment and Childhood Behaviors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4175558/) (Hibbeln and Gow, 2015) [1:38:15]

**Study that took younger ApoE4 carriers and injected them with labeled DHA into plasma to estimate how much DHA gets past the blood-brain barrier**: [DHA brain uptake and APOE4 status: a PET study with [1- 11 C]-DHA](https://pubmed.ncbi.nlm.nih.gov/28335828/) (Yassine et al., 2017) [1:39:45]

**Epidemiology study from Netherlands reported E4 carriers who consumed a good amount of fatty fish combined with leafy vegetables had less disease at 60yo than those who did not**: [Dietary fat intake and the risk of incident dementia in the Rotterdam study](https://onlinelibrary.wiley.com/doi/abs/10.1002/ana.410420514) (Kalmijn et al., 2004) [1:45:30]

**Randomized clinical trial that evaluated patients with mild Alzheimer’s disease given 2g/d of DHA versus placebo over a 15mo period**: [Docosahexaenoic acid supplementation and cognitive decline in Alzheimer disease: a randomized trial](https://pubmed.ncbi.nlm.nih.gov/21045096/) (Quinn et al., 2010) [1:45:45]

**Active large clinical trial called PREVENT-E4 addressing how older E4 carriers assimilate supplemental DHA**: [DHA Brain Delivery Trial (PreventE4)](https://clinicaltrials.gov/ct2/show/NCT03613844) | (clinicaltrials.gov) [1:48:00]

**The RUSH AD disease research archive**: [Rush University Medical Center Archives: Rush Records (1969-present) [RUMC and Rush University]](https://rushu.libguides.com/rusharchives/RUMC) | (rushu.libguides.com) [1:56:00]

**Analysis of the RUSH archive identified PLA2 enzymes that is hyperactive in E4 brains**: [Overview and Findings from the Rush Memory and Aging Project](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3439198/) (Bennett et al., 2013) [1:56:00]

**The largest studies to date do not demonstrate beneficial response to supplementation once E4 carriers have disease**: [Association of Serum Docosahexaenoic Acid With Cerebral Amyloidosis](https://jamanetwork.com/journals/jamaneurology/article-abstract/2538230) (Yassine et al., 2016) [1:57:00]

**Epidemiology studies suggest that E4 carriers who consume 1 serving of fatty fish per week** ***may*** **be providing enough omega-3s to the brain to help mitigate disease longer-term**: [Docosahexaenoic Acid and Cognition throughout the Lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4772061/) (Weiser et al., 2016) [1:59:39]

**PET imaging study reports exercise may help mitigate cognitive decline for E4 carriers**: [Exercise engagement as a moderator of APOE effects on amyloid deposition](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3583203/) (Head et al., 2013) [2:00:30]

§

## People Mentioned

- [Joseph Goldstein](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2740366/) (discoverer of the low density lipoprotein (LDL)) [40:45]
- [Allen Roses](https://www.nytimes.com/2016/10/06/science/allen-roses-who-upset-common-wisdom-on-cause-of-alzheimers-dies-at-73.html) (profiled a large number of common ApoE variants of people dying with, and without AD) [53:30]
- [Joe Quinn](https://www.researchgate.net/profile/Joseph_Quinn) (author of 2010 *JAMA* paper that evaluated patients with mild Alzheimer’s disease given 2g/d of DHA versus placebo over a 15mo period) [1:45:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/02/bio-image-hussein.jpeg)

##### Hussein Yassine, M.D.

Hussein is a physician and researcher who is an Associate in the Department of Medicine, Keck School of Medicine of USC. His lab studies how changes in lipid metabolism and nutrition affect cognition and the risk of developing Alzheimer’s disease, paying specific attention to how the APOE4 allele affects lipid metabolism and response to diet. He directs the Roybal Alzheimer’s disease Research program focused on understanding how obesity, diabetes, and vascular risk factors in Los Angeles’s Latinx population affect cognition and Alzheimer’s disease risk. He also runs the Lipid Clinic at Roybal Healthcare Center in East LA, providing care for a large population of complex lipid and diabetes disorders that are referred from all LA county clinics.