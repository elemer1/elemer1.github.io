# #173 – AMA #26: Continuous glucose monitors, zone 2 training, and a framework for interventions

**Source:** [https://peterattiamd.com/ama26/](https://peterattiamd.com/ama26/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob answer numerous follow-up questions to recently discussed deep-dive topics such as the use of continuous glucose monitors and getting the most from zone 2 exercise. They also discuss the incredible feats of cyclists in the Tour de France through the lens of the amazing performance physiology required from these athletes. Additionally, Peter ties the conversation together by sharing his foundational framework when considering different interventions, even in the absence of data from a randomized controlled trial.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #26 show notes page](https://peterattiamd.com/ama26/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Peter’s foundational framework when considering different interventions [1:30];
- Applying Peter’s framework to the idea of using a CGM [8:00];
- Why certain fruits have a bigger impact on glucose, and the limitations of a CGM can tell you [16:00];
- Importance of paying attention to insulin, and the prospects of a continuous monitor for insulin levels [20:00];
- How exercise impacts glucose and peak glucose numbers to stay under [24:15];
- Impact of anxiety on stress on glucose, and why it’s important to calibrate your CGM [26:30];
- The five main tools for managing blood glucose numbers [33:45];
- Benefits of moving or exercising after a meal, and where ingested carbohydrates get can be stored [37:15];
- How to make decisions about an action or intervention in the absence of data from a rigorous, randomized controlled trial [40:30];
- The incredible athletic feats of Tour de France cyclists [48:30];
- Different modalities for doing zone 2 exercise: running, rowing, cycling, and more [1:00:15];
- Proxies for knowing your in zone 2 short of using a lactate monitor [1:07:30];
- Monitoring lactate for zone 2 exercise [1:10:00]; and
- More.

§

The Peter Attia Drive

Continuous glucose monitors, zone 2 training, and a framework for interventions

§

## Show Notes

§

## Peter’s foundational framework when considering different interventions [1:30]

**Intro to the AMA discussion**:

- Taking follow-up questions on CGM based on:
- The previous [AMA #24](https://peterattiamd.com/ama24/)
- And the Sunday email: [Are continuous glucose monitors a waste of time for people without diabetes?](https://peterattiamd.com/are-continuous-glucose-monitors-a-waste-of-time-for-people-without-diabetes/) Which mentioned the [JAMA perspective](https://jamanetwork.com/journals/jama/article-abstract/2780027) on the topic
- Also taking some questions on zone 2 training and exercise (see [AMA #19](https://peterattiamd.com/ama19/))

**Peter’s framework for different interventions as foundation for how you think about CGM and their use in different populations**

- Peter’s framework for interventions helps in laying the foundation for how one should think about CGM and their use in different populations
- The framework really pertains to anything that comes across Peter’s plate

*⇒ Example, when looking critically at the data around meditation (which asks a series of questions)*

**-First question** is what is the risk of harm from doing this thing?

- If you do X, how high is the probability of harm?

**-Second question** is obviously the contrapositive of that. If you do X, what is the probability of benefit?

- Mirrored in the way the FDA organizes drug trials
  - After you get through the preclinical data, the animal work, after the IND has been filed, your first trial in humans, which is called the phase one trial, is looking at harm
  - a small trial with dose escalation that is only trying to understand if as you escalate the dose, do you see an increase in side effects?
    - Very occasionally, you see some benefits in a phase one trial. And if you do, that’s interesting, but you generally can’t take it to the bank because the study is so small and generally it’s quite homogeneous
  - That’s when you move on to phase two studies, which are geared towards efficacy, i.e., is this thing doing good?
    - if the phase two trial is positive, you move to a much larger trial called the phase three trial, which really doubles down on efficacy
    - But the real point here is you’re raising the bar, so to speak, for what you’re demanding of this.
    - Again, what’s the risk of harm, what’s the probability of benefit are two obvious questions

**-Third question**, what’s the opportunity cost of this intervention?

- Let’s use an example, Peter came across a device that would put you in a trance
  - there was this device that you would listen to and it would supposedly put you in a trance and the company that was proposing this thing had all sorts of theoretical benefits from using it (you are less likely to get breast cancer, all of these other things)
  - Was there any harm in this device? As far as I could tell, no
  - Was there any benefit of this device? Certainly not to the extent that they made claims
    - That said, I had tried the device because a friend of mine bought it for me. I have to admit, it was the most relaxing thing I’d ever done (virtually every time I tried it, I fell asleep)
  - But there were opportunity costs
    - First, it was pretty expensive
    - More importantly, there was a time cost
      - It was two 20-minute sessions a day, much along the lines of like transcendental meditation, which is similar, but has much better data
      - Well, there’s a problem because for most people who are super busy, 40 minutes a day for very questionable benefit didn’t make a lot of sense if it came at the expense of other things that undoubtedly had benefits such as could that be 40 minutes a day of actual meditation
      - 40 additional minutes a day of sleep
      - 40 minutes a day of exercise? All things that I would point to as having far greater evidence in favor of.
      - any time you’re thinking about doing something, you want to go through that
      - especially important questions to be asking when the answer is not readily apparent from RCTs that have generally already answered one and two

\*Remember, The easiest RCTs to do are the ones that are based on pharmacology

- They’re generally addressing questions one and two, but they’re not really addressing question three
- And that’s because there really isn’t much of an opportunity cost to taking a pill outside of the economic cost (the time cost of it is relatively low)
- When it comes to RCTs that are more intervention based such as exercise, yes, you want to be able to think about the **time cost**

## Applying Peter’s framework to the idea of using a CGM [8:00]

**The framework applied to CGM in non-diabetics**

- As you look to something like CGM in the case of non-diabetics, this framework is very helpful
- At this time, we don’t have great RCTs to point to that say in people who are not yet diabetic, there is a benefit to using CGM

-First ask the question, *What is the risk of harm?*

- when we talk about CGM specifically, the risk of harm is very low (but now zero)
  - Example, the most obvious thing that comes to my mind is anxiety that it can stoke. It can create obsession in someone
  - For instance, we have some patients who have a history of eating disorders. These are patients I would not in any way, shape or form advocate the use of CGM

-Secondly, *Is there any chance of it doing good?*

- First potential benefit could be insight-based good, which is teaching you what your carbohydrate tolerance is
- Second potential benefit is behavior modification, which is effectively a strapped on version of the Hawthorne effect
  - When you’re wearing a CGM, you’re basically utilizing a tool that is monitoring you. There is no shortage of data to support the idea that when people are asked to monitor food intake, they make changes in the right direction.
  - How you create accountability for patients. You say, “Look, we’re going to check in once a day and I just want you to tell me what you ate”
    - even if you provide no other instruction, just need you to tell me what you ate,” that level of accountability immediately changes a person’s behavior

-Third question, *what is the* ***opportunity cost?***

- The biggest opportunity cost is the economic cost
  - If you are not diabetic, you are not going to have your insurance company cover one of these devices
  - There are really three companies that make CGMs in the clinical grade
    - [Medtronic](https://www.medtronicdiabetes.com/products/guardian-connect-continuous-glucose-monitoring-system)
    - [Abbott](https://www.abbott.com/corpnewsroom/strategy-and-strength/freestyle-libre-2-next-gen-is-here.html)
    - [Dexcom](https://www.dexcom.com/g6-cgm-system)
  - Then there are lots of companies that help with plugging in those CGMs into their apps to help users with their goals, be it weight loss or otherwise, such as…
    - [Levels](https://www.levelshealth.com/)
    - [Supersapiens](https://www.supersapiens.com/en-EN/?us=yes)
  - But these devices are not cheap
    - daily cost of CGM is about $10 per day
      - That’s a huge expense assuming you need it every minute of every day. I don’t think you do. I think you can gain a lot of insight using these things periodically. I don’t think this is something you need to be tethered to every minute of every day
      - There are some people like me who enjoy that

> “I continue to find insights that just provide value and more than anything else, it’s really the behavioral tool.” —Peter Attia on using a CGM

**Peter discussed this in Sunday email**: [Are continuous glucose monitors a waste of time for people without diabetes?](https://peterattiamd.com/are-continuous-glucose-monitors-a-waste-of-time-for-people-without-diabetes/)

- Peter tells patients that everybody deserves a three-month trial of CGM
- At first, 90% of this is going to be insight into how certain food and habits affect blood sugar
- Only 10% of it is going to be changing your behavior through this Hawthorne effect
- By the end of that 90 days, that’s going to flip to 90% behavioral tool and 10% insights
- Directionally, within about three months, you will start to see what grapes do vs. grapefruit, or what happens when you eat carbs after a workout vs. right before bed

## Why certain fruits have a bigger impact on glucose, and the limitations of a CGM can tell you [16:00]

Question from subscriber: *My glucose spikes when I eat some fruits, but not others. Do you know why this happens? Does it mean that I should avoid fruits that spike my glucose?*

- Not all fruits are created equal
- The fruits that we consume are not the same as the fruits our ancestors would have eaten
- Certain fruits are going to be better than others
- Are there nutrients in that that are beneficial?
  - Yes, but you can get them elsewhere
  - Berries are a good option as an example of a fruit that have a far lower impact on glycemic response.
- Helpful to use CGM to tailor your intake of not just fruits and vegetables, but basically all carbohydrates

**Important**: Don’t overinterpret what CGM is valuable for

- CGM is not a substitute for other metrics of health
- **Example**: [Bill Gifford](https://www.linkedin.com/in/bill-gifford-125868b/) recently [wrote a story](https://www.menshealth.com/health/a35541222/cgm-continual-glucose-monitor-levels-supersapiens/) for Men’s Health
  - He wrote an article about CGM and in preparation for that article, he’s been wearing all sorts of different CGMs
  - He explained how eating this thing or that is really raising his glucose… until he realized that I could cheat the system by eating this other thing that was crappy for me as long as it didn’t raise his glucose as much.
- H*ow do we reconcile that*?
  - CGM is a tool for understanding carbohydrate tolerance
  - It does not provide you an insight into how well you metabolize different fatty acids
  - It’s not a valuable tool to help you understand how much visceral fat you have.
  - It doesn’t provide you immediate insight into nitrogen balance and how much protein you need.
  - We need different tools tools for those things

For instance,

- Peter has some patients who can eat a diet where all of their fat intake, 50% of it is saturated fat
- might be consuming 50% of their calories from fat of which 50% are saturated. So 25% of their calories are coming from saturated fat, and they have no dyslipidemia
- other patients who if put on a diet like that have dyslipidemia
- That’s where we need to do advanced lipid testing
- when you do that, you start to realize why, “Oh, hey, the guy who’s apo B goes through the roof also tends to hyper-absorb steroids and hyper-synthesize sterols when in the presence of high amounts of saturated fat
- Check out the [Tom Dayspring episodes](https://peterattiamd.com/?s=tom+dayspring) for a lengthy discussion about that

**Another glib example**: “*If you only use body weight as your metric of health, you could easily be lulled into thinking smoking is good for you because most smokers lose weight*.”

> “*You have to be careful that you are not looking at one metric and fixating on that one metric alone, but instead you’re using that metric and assimilating it with all the metrics that we have available*.” —Peter Attia

## Importance of paying attention to insulin, and the prospects of a continuous monitor for insulin levels [20:00]

**How close are we to having a device track insulin in real time?**

- insulin is certainly the most interesting analyte if it could be measured continuously
- That would be at least—if not more important—than glucose, especially for non-diabetics
- For diabetics, you could make the case that really glucose is what matters
- In the non-diabetic population, you would actually want to measure insulin continuously

⇒ Spoken about this at length in the [episode with Gerald Shulman](https://peterattiamd.com/geraldshulman/)

**Hyperinsulinemia**

> “*Hyperinsulinemia is the canary in the coal mine*.” —Peter Attia

- Hyperinsulinemia is what tells you you have peripheral insulin resistance, which is obviously long proceeding the dysregulated glucose levels that we’re picking up
- When we measure glucose, we’re really measuring something that is way downstream of a problem that matters
- Unfortunately, measuring insulin continuously seems to not be something that is in our future…it would be technically very difficult to do.

*What about point of care, even like a finger prick?*

- There’s at least one company that I know of that is offering point of care device for insulin measurements—some of their data looks interesting to Peter
- They claim to be able to measure insulin and C-peptide on a finger stick of blood
- The point is: There’s a big leap between being able to measure something in blood at a point of care
- To go from taking a tube of blood and doing a radio immune assay to measure insulin to being able to take a drop of whole blood and measure insulin…that’s an enormous step forward
- Well, it’s an even bigger leap to be able to then measure that analyte and interstitial fluid. And that’s what would be necessary if you wanted to do continuous monitoring of something because obviously a CGM is not sampling in your blood, it’s sampling in your interstitial.

**Importance of OGTTs (oral glucose tolerance tests)**

When you look into most studies on diabetes…

- Generally they have three buckets: i) where they have normal glucose tolerance, ii) impaired glucose tolerance, and then iii) type 2 diabetic
- If you’re going along the spectrum from normal to diabetic, there’s probably a state where you’re going from normal glucose tolerance to impaired glucose tolerance
- But in between those two states your insulin may be going up and up and up, and that would be an early indicator that you’re on the road to impaired glucose tolerance and diabetes
- That’s why we do OGTTs with frequent glucose and insulin sampling in every one of our patients non-negotiable
- it’s exactly the progression you have to monitor
- It’s very clear what you see
- When you go from a perfectly normal person, the first thing that deviates is elevations of postprandial insulin
- That person will still have normal glucose, both fasting and postprandially, and normal fasting insulin
- But the real canary in the coal mine is the ***elevation of postprandial insulin***
- That will remain hidden for a long period of time before it translates to even an elevation of fasting insulin
  - Then you’ll see an elevation of postprandial glucose
  - Then you’ll see an elevation of fasting glucose
- When we think about metabolic syndrome
  - If you have three of these five things, you get the red flag
  - one of those things is an elevation of fasting glucose
  - But that’s a decade down the road from when all these other things start to take place

## How exercise impacts glucose and peak glucose numbers to stay under [24:15]

**Question from subscriber**: *It looks like my glucose spikes during exercise, particularly high-intensity exercise. Is this something that you see? Is it something that I should be concerned about? Do you know why it happens?”*

- Yes, definitely it’s something that you see, but it is definitely not something you need to worry about

*Why is a huge spike in glucose happening when you exercise?*

- Due to hepatic glucose output primarily
- Assuming you’re not mainlining glucose during the high-intensity exercise…what’s happening is the liver is making glucose and that’s in response to cortisol, glucagon, a whole bunch of other hormonal signals
- What typically happens is there’s a bit of a mismatch between how much glucose is made and how much is actually needed
- It’s way better for the body to err on the side of overdoing it than underdoing it. Underdoing it is catastrophic, it’s fatal. Overdoing it, you don’t really pay a price for it.
- the highest glucose Peter’s ever seen on his CGM mid-workout is in the 160s

**An arbitrary cutoff**

- In Peter’s practice, they don’t want to see glucose spike above 140 in terms of **postprandial spike**
- That’s a very aggressive metric and it’s absolutely arbitrary
- “*But again, in a non-diabetic through five years of empirical work with patients, we’re very confident that that’s a number that a person can achieve without much restriction*”
- They can still be eating plenty of carbohydrates provided they’re insulin sensitive enough
- And that’s going to drive that average glucose to our goal, which is to be below 100, which is going to put them at an A1C imputed of less than 5%, which puts us in the best category

> “In summary, do not be alarmed by glucose levels that rise during intense exercise and obviously don’t confuse that for the glucose spike you see post-Haagen-Dazs.” —Peter Attia

## Impact of anxiety on stress on glucose, and why it’s important to calibrate your CGM [26:30]

**Question from subscriber**: “*This week has been my first week wearing the* [*G6 CGM*](https://www.dexcom.com/g6-cgm-system)*. I’m a non-diabetic, but want to understand my glucose trends better and reduce variability. I was giving a presentation today about 4:00 PM and more than three hours after eating or drinking. And about 50 minutes into the presentation, my alert went off as my glucose hit 160 milligrams per deciliter.*

*I have moderate to high anxiety with presenting, but was taken aback by the impact and immediacy of that stress response to my glucose level.*

*Can you share any insights on this and perhaps what that means for people with even low to moderate anxiety if they’re regularly put into stressful situations at work or at home? It seems like this group of people may struggle more with reducing glucose variability?*”

Episodes discussing this topic include [#54 with Keven Sayer](https://peterattiamd.com/kevinsayer/)

- “That’s pretty unusual, but not unheard of” says Peter
- You could easily get into the 160s from the physiologic stress of exercise
- If someone does have enough anxiety over presenting, it’s not surprising that someone who doesn’t like public speaking or gets nervous around it would experience that
- This gets into the question of, “Is it making it worse by monitoring it?”
- “This might sound like a cop-out, but I would say don’t have the device on when you’re public speaking” — just turn the app off and you could even make it such that you don’t even see the data in retrospect. There’s ways to manipulate the app so you don’t even see those data.
- The data suggests that less glucose variability is better than more
- The good news is much more of that is impacted by nutrition and exercise than by stress
- Stress plays a role in hyperglycemia in a subset of people, but Peter would put that as third on the list of where you’re going to have your greatest impact, which is going to be nutrition and exercise
- Peter would put stress and sleep at about the same level

**Tools for coping with anxiety**

- Instead, what Peter might do is try to maybe use that feedback as a way to look at other tools for coping with anxiety
- For example
  - Have found propranolol, which is a type of beta blocker, to be very helpful in coping with that type of situational anxiety
- There are lots of ways to utilize that information to your advantage and use glucose as a tool of biofeedback to maybe demonstrate when you’re able to manage that a little bit better.

*CGM can be a blessing and a curse*

- Almost like the blessing and curse of having such a powerful tool that monitors your glucose 24/7
- From a research perspective, it’s amazing
- But also a CGM can be anxiety inducing if it’s watching you 24/7
- For instance, there’s an alarm for a higher glucose and a lower glucose (note: you can change the limits)
  - The one that’s set in stone is the lower limit because obviously the FDA has to ensure it protects diabetics from the catastrophic outcome which is the hypoglycemic incident
  - But, if you lay on the device while you’re sleeping, it is going to drive glucose down —
    - The reason for that is anything that accelerates local glycolysis will drive down glucose.
    - If the thing is on your arm and you lay on that arm while you’re sleeping and really compress it, it actually increases glycolysis locally at that site. And so glucose will go down
    - Most of the hypo alarms at night bc of this

***Calibrating your CGM***

- You’ve got to make sure you’re calibrating these things
- Peter is partial to Dexcom because it can be calibrated — it’s really important to be able to calibrate your CGM because it makes them way more accurate
- The reason is when you’re not a diabetic, you’re holding it to a higher standard
- “If it’s off by 10 milligrams per deciliter in me (peter), that’s an enormous deviation given the tight control I’m after”
- If you’re a person who’s got a hemoglobin A1C of 8%, the difference between a glucose of 200 and 210 doesn’t matter as much and the Dexcom G6 does not need to be calibrated at that level.
- For example, the person who was giving the presentation and their glucose spiked to 160… Peter would want to make sure that person had, in fact, calibrated the meter
- In the first 24 to 48 hours, the sensors can be a little bit off — and a lot of that has to do with the trauma of the insertion which alters the glucose kinetics locally
- Make sure you’re calibrating it at a time when you believe your glucose is at a steady level — don’t calibrate it right after a meal or a workout, for example

## The five main tools for managing blood glucose numbers [33:45]

**Five tools that you can use to manipulate glucose:**

1. Nutrition
2. Exercise
3. Management of stress (mostly, but not all, about cortisol)
4. Sleep
5. Medications/supplements

**Start with the most powerful leavers** — *nutrition, sleep, and exercise*

- Everyone’s going to be starting from a different place
- You can use the CGM to push the boundaries a little bit to tell you what is your carbohydrate tolerance
- A given person can have two totally different carbohydrate tolerances depending on their activity levels
- Peter uses a personal example,
  - When I was cycling a lot, which is the last thing that I did quasi seriously, I was easily consuming 600 grams of carbohydrates a day and no issues maintaining normal glucose homeostasis
  - that’s 2,400 calories of carbs a day
  - If I were to consume 2,400 calories of carbohydrates a day, I don’t suspect my glucose would look nearly as good as it did then. And that’s because I used to be exercising nearly 28 hours a week and now I’m exercising maybe 10 hours a week
- Again, you’re just going to basically tweak these interventions based on your starting point and your aspiration

**Sleep**

- Sleep cannot be overlooked
- The data for poor sleep and insulin resistance are actually quite strong (see [Matthew Walker episode](https://peterattiamd.com/matthewwalker3/))
- Even short-term bouts of sleep deprivation, like two weeks of four hours of sleep per night result in about a [50% reduction in glucose disposal](https://pubmed.ncbi.nlm.nih.gov/10543671/) which would result in hyperglycemia
- Sleep deprivation is particularly insidious because it affects other things downstream like you motivation to exercise, your willpower to not eat crappy food, stress/anxiety levels, etc.

## Benefits of moving or exercising after a meal, and where ingested carbohydrates get can be stored [37:15]

**Why exercise post meal?**

- When we talk about glucose disposal, we’re primarily talking about muscle glucose disposal
- But there are two other places the glucose goes
- the liver and fat cells (both directly and indirectly through de novo lipogenesis)
- But the biggest sink (especially in the short timeframe after a meal) is the muscle which can be opened up by exercise and resistance training

*Peter tells the personal story of going to some super famous donut shop…*

- Afterwards, he just doubled up on his zone 2 mostly in an effort of curiosity, “Look, that was a staggering dose of sugar and glucose and starch. I’m really curious as to what a double dose of zone 2 would do today.”
- I was actually really surprised at how little my glucose spiked
- I don’t think it went above like the 120s and I also didn’t have a rebound
- A lot of times you can do something that transiently keeps glucose under control, but then it rebounds later
- But the fact that it was early in the day, you tend to see more of that rebound effect later in the day, the muscles, all things equal tend to get a little bit more insulin resistant later in the day

*CGM insights:* All things equal tend to get a little bit more insulin resistant later in the day *—* That’s another example of how I think CGM is a tool that has given me a lot more insight in how to eat more carbohydrates and I’ve yet to meet a carb I don’t like.

**Peter’s typical zone 2 dosage**: About four 45-minute sessions a week.

## How to make decisions about an action or intervention in the absence of data from a rigorous, randomized controlled trial [40:30]

**How to make decisions about an action or intervention in the absence of data from a rigorous, randomized controlled trial**

Regarding CGM…

- “The first thing I would say is it’s probably a question of time”
- Might be the case that at some point we will have great RCTs that look at the use of CGM in non-diabetics
- It’s also quite the case that we won’t, or that we will have them and they will have negative effects
- Why?
- if you don’t ask the right question over the right period of time, you’re not going to get the right answer
- Is it likely that in normal, healthy people use of CGM over the course of, I don’t know, a year is going to yield a material benefit on their health over that year?
- Not necessarily
- The benefits may need to be integrated over decades.
- In other words, they might not need to use CGM for decades, but the effects of tight glycemic control over lousy glycamic control may need to be demonstrated over decades

⇒ The epidemiologic data was discussed at length in the [AMA #24](https://peterattiamd.com/ama24/)

- The epidemiologic data for lower glucose, less variability and fewer spikes were not based on RCTs, these were based on epidemiology that were very suggestive
- Everything we’re saying about CGM is, of course, not based on an RCT, but instead is based on a proxy to that.
- If you believe that CGM is a tool to help you achieve that, then by proxy, it should be better.

***Many examples of beneficial things that do NOT have RCT data****:*

*smoking and cancer*

- The most obvious and glib of these is cigarette smoking and lung cancer
- We don’t have RCTs that tell us that cigarette smoking is the cause of lung cancer. We have a lot of non-RCT data, a lot of proxy data that make that abundantly clear

*The benefits of HRT in perimenopausal women and postmenopausal women*

- the epidemiology here was very much in favor of HRT
- But the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative), which was the [RCT that was published](https://jamanetwork.com/journals/jama/fullarticle/195120) and suggested it was harmful
- But a much clearer examination of the RCT has brought most observers around to the other side, which is, “No, actually, HRT is beneficial despite the fact that the RCT said it was not.”
- ⇒ See [episode of The Drive](https://peterattiamd.com/caroltavris-avrumbluming/) that disputes much of the “findings” from the WHI

*The benefit of EPO in cycling*

- not aware of any RCT that demonstrates the benefit of EPO in cycling
- I’m not aware of an RCT that took a group of cyclists and put half of them on EPO and half of them on a placebo and measured performance
- And yet is there anybody who knows anything about EPO and cycling that wouldn’t say that there is an enormous benefit to EPO and cycling, absent the RCT?

*PCSK9 inhibitors*

- The two main trials that were used for the approval of PCSK9 inhibitors were the [FOURIER trial](https://www.ncbi.nlm.nih.gov/pubmed/28304224) and the [ODYSSEY trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1801174)
  - The FOURIER trial is the one that led to the approval of Repatha
  - The ODYSSEY trial is the one that led to the approval of Praluent
- These were both studies that were done in patients who were statinized
- One of the trials, you had a group of patients that were maximally statinized
  - They came in with an average LDL cholesterol  in the vicinity of 70 milligrams per deciliter
- ODYSSEY trial, they were on statins, but they weren’t quite as low in LDLc
- The addition of a PCSK9 in these trials led to significant benefits in terms of all cause mortality, cardiac mortality, adverse MACE, et cetera
- To my knowledge, there has not been a study that has demonstrated the benefit of PCSK9 inhibitors in isolation
- Yet clinically, anybody who takes care of complicated lipid patients that are on monotherapy PCSK9 can tell you there’s a case to be made to use it in certain situations
- Can I point to a trial that tells you that that’s beneficial? I can’t.
- But by proxy, when I weigh it against the alternative, which is a patient who is intolerant of statins, a patient who is intolerant of ezetimibe, and a patient who achieves no benefit from fenofibrate or any of the other lipid lowering modalities, if my alternative is I’m going to do nothing or I’m going to give them a PCSK9 inhibitor in isolation, it’s a no-brainer
- And how confident am I that it’s going to benefit them?
  - I’m actually very confident
  - because by proxy, I understand the mechanism of action and I understand that ultimately this is lowering apo B in a manner that is safe

*Another example: Boxing training*

- When Peter was a teenager, he would train for boxing six hours a day, six days a week from about the ages of 13 to 19
- Do you think that that benefited me physically?
- Yes, but, “I’m pretty sure there’s no RCT out there that tested adolescent boys doing boxing to demonstrate the health benefits of it”
- But if you just think about all of the work I had to do to be able to box how much training went into it, hitting the heavy bag, hitting the double end bag, hitting the speed bag, hitting the focus mitts, bobbing and weaving on the rope, all of the jumping rope, all of that stuff
- Anybody who says that that wasn’t beneficial to me would be crazy
- But again, there’s no RCT that demonstrates it.
- Do you need the RCT? I don’t think you do. I think what you can instead rely on is the proxy
- All of those things that I did raised my heart rate, transiently raised my blood pressure
- In the long run, lowered systemic vascular resistance, improved glucose disposal, improved insulin sensitivity
- By proxy, you could say training for boxing is beneficial without necessarily having the RCT to demonstrate it.

## The incredible athletic feats of Tour de France cyclists [48:30]

**The Tour de France** – Jun 26, 2021 – Jul 18, 2021

- One of the craziest stages is the double climb of [Mont Ventoux](https://en.wikipedia.org/wiki/Mont_Ventoux)
- If you took like the adult fittest version of Peter, his all-out pace for 1 kilometer is what the Tour guys would hold for about 20 kilometers, just to put that in perspective

*How much of an accomplishment is the Tour de France if your average biker tried it?*

- [How Long Can You Hold World Hour Record Pace?](https://www.youtube.com/watch?v=JVO5ILQfx0Y) | Non Cyclist Vs Amateur Vs Pro
- [How Fast Do Pros Cycle Uphill?](https://www.youtube.com/watch?v=Rvt9CaR4_7k) | Beginner VS Amateur VS Pro: Hill Climb Edition

**Cycling categories**:

In cycling, you have category—

- Amatuer
  - cat 1 (best amateur level)
  - cat 2
  - cat 3
  - cat 4
  - cat 5 (worst amateur level)
- Next comes the domestic pro
- Then you have a European pro
- Then you have someone who makes a top team like the teams that would actually go to the Tour de France
  - A Tour team would consist of 10 guys, all being the highest level of rider
  - But only 1 member of the 10 person team would be considered a GC contender
  - the race is won in the mountains and in the time trials. On the flat stages is not where that race is won
  - The real delta in watts per kilos that makes the difference is… *what can they squeeze out on those climbs?*

**In the** [**EPO era**](https://en.wikipedia.org/wiki/Doping_at_the_Tour_de_France#:~:text=to%20work%20before%3F-,1990s%3A%20The%20era%20of%20EPO,revealed%20in%202006%20and%202007.), [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) was 7 to 7.1 watts per kilo at his functional threshold power

- So for 30 to 60 minutes, Lance could hold 7 to 7.1 watts per kilo.
- If you’d like to see what this is like… get on a bike that has a power meter, take your body weight in kilos, multiply it by 7 and ask yourself how long can you hold that
- The answer for most people is measured in **seconds**, period.

**In the non-EPO era**…you’re going to see about a 10% reduction in power

- That means that a functional threshold power will be 6.3, 6.4 watts per kilos
- (Note: there has never really been a time when cycling hasn’t been fully, fully clean, but blood doping—EPO—is largely out of cycling now)
- Peter says, “*I couldn’t hold six watts per kilo now for more than a minute”*
- Lance’s exact numbers when off EPO was 450 watts, on EPO 500 watts was his FTP, meaning the power he could hold for an hour.
- An average fit person would not be able to hold 200 watts for an hour

[**Alpe d’Huez**](https://en.wikipedia.org/wiki/Alpe_d%27Huez) **at the Tour de France**

- In his best shape, Peter estimates it would take him a little over an hour to get up Alpe d’Huez
- When you go to ride Alpe d’Huez as a recreational cyclist and there’s a place where you put your time at the top, it’s generally considered above and below an hour
- You’re basically just doing maximum watts for an hour
- Records at Alpe d’Huez:
- Marco Pantani has the record at 37:35 in 1997 (EPO era)
- Lance Armstrong was 1 second off the record (37:36) in 2004 (EPO era)
- Today without EPO, I would bet these guys are still going up in like 40, 41, 42 minutes.
- FYI – the difference between a 1 hour climb vs. a climb in 40 minutes is an **eternity**
- Peter thinks it would take the avg fit person 1:45 to go up Alpe d’Huez

**What would it take the avg. person to finish the Tour de France?**

Just finishing it would be a Herculean achievement, says Peter

If you could do it in twice the time that it took those cyclists, that would be amazing

> “But I cannot, for the life of me, believe that there is an athletic event that is more demanding than the Tour de France.” —Peter Attia

**Iñigo San Milan and his colleague George Brooks published a** [**2018 paper**](https://www.ncbi.nlm.nih.gov/pubmed/28623613) **that looked at Zone 2 efficiency and lactate**:

- They were looking at lactate accumulation and they had elite athletes and they were at something like 300 watts and their blood lactate was pretty much like at 2
- Most mere mortals we’re looking at like 100 or 150 watts for the same lactate level
- “If I set up my [Wahoo Kickr](https://www.wahoofitness.com/devices/bike-trainers) at 300 watts to do my zone two training, that would be a short session.” says Bob

> “*You take every one of those [Tour d France] guys without a single bit of assistance and they are still uniformly genetically gifted beyond anything you’ll appreciate. They train harder than anything anyone could ever appreciate. Their tolerance for pain is like nothing most people can relate to. . .go and look at their faces when they’re climbing, when they’re in that real push on those mountain stages. And that’s an extraordinary amount of discomfort*.” —Peter Attia

⇒ Check out [The Secret Race: Inside the Hidden World of the Tour de France](https://www.amazon.com/Secret-Race-Inside-Hidden-France/dp/034553042X) by Tyler Hamilton

## Different modalities for doing zone 2 exercise: running, rowing, cycling, and more [1:00:15]

**Question from subscriber**: “*I’ve considered stationary bike rowing machine, walk/run treadmill, or outside, maybe even barefoot. Any advantage to the “whole body” aspect of rowing versus the leg predominant other choices?*”

- Peter comments, “You’re going to notice differences in your zone 2 performance based on the medium that you do as a function of your efficiency.”

**Running**: Someone who has been a lifelong runner will probably have an easier time hopping on a treadmill or even going outside and running and staying in zone 2 as a runner

**Stationary bike**: Peter does almost all of his zone 2 on a stationary bike (a road bike that sits on his [Wahoo kickr](https://www.wahoofitness.com/devices/smart-bike/kickr-bike?utm_id=go_cmp-11606786093_adg-116067098071_ad-500164600495_aud-973522991190:kwd-672483359177_dev-c_ext-_prd-_mca-_sig-CjwKCAjw3_KIBhA2EiwAaAAlimLBUfBGc6sMQB1ffOeZ5Ymn664cnS5kWRmoAmpUbXcwFGCH7gHdxRoCqzEQAvD_BwE&utm_source=google&gclid=CjwKCAjw3_KIBhA2EiwAaAAlimLBUfBGc6sMQB1ffOeZ5Ymn664cnS5kWRmoAmpUbXcwFGCH7gHdxRoCqzEQAvD_BwE)) because “that’s my comfort zone”

- “*It’s very comfortable for me to sit on a bike and I can put all of my energy into the activity at hand*.”

**Rowing**: Rowing is a great whole body exercise

- You could argue there’s probably no better whole body exercise than rowing
- the drawback of rowing for zone 2 is if you aren’t a really good rower, you’re going to struggle because your form is going to fail before you get the real metabolic benefits
- Personally, Peter likes rowing, :but my form is not good enough that I could do 45 minutes of zone 2 on a rowing machine”
- He likes rowing in shorter bursts for high-intensity training
- But for people like [Beth Lewis](https://peterattiamd.com/bethlewis), she can do zone 2 on a rowing machine as she’s an exceptional rower (see [episode of The Drive with Beth](https://peterattiamd.com/bethlewis))

**Comparing indoor versus outdoor for zone 2 exercise**

- There are advantages to being indoor because you just control the environment much more
- Treadmill is great for the ability to toggle speed and incline with perfect control
- For zone 2, the name of the game is trying to really keep it in that zone for as long as possible
- People that’ll say, “Hey, I went out and ran today and my app told me I spent 30 minutes in zone 2.” And it’s like, “Well, that’s not the same because if you’re going up and down and up and down and up and down, yes, the area under the curve is 30 minutes, but that’s not the same as spending 30 straight minutes in it.”
- For this type of mitochondrial training, you want to stay in zone 2 the whole time
- There’s absolutely benefits to the up and down training, but for this type of mitochondrial functionality, we want to make it a little bit more prescriptive
- If you didn’t put the incline on it, if you’re going flat, is it possible to jog in zone two for people?
- *Could Peter really dial in zone 2 while running?* Yeah, maybe. But again, I’m not that efficient a runner anymore. I don’t run. I haven’t run as a consistent form of exercise probably since 2016

> “Zone two is a metabolic state. It’s not determined by speed. It’s determined by which energy system you’re requiring and what the equilibrium is.” —Peter Attia

## Proxies for knowing your in zone 2 short of using a lactate monitor [1:07:30]

**Question from subscriber**: “*I listened to the recent* [*AMA on zone 2*](https://peterattiamd.com/ama19/)*, then went and listened again to* [*Phil Maffetone*](https://peterattiamd.com/philmaffetone/) *and the episode on zone 2. How should I think about these two things? Are they the same? If I’m exercising at 180 minus age, i.e., MAF. . . is that more or less zone two, or are they talking about different things?*“

**Phil’s** [**MAF method**](https://philmaffetone.com/method/) **is basically a heuristic for zone 2**

- MAF stands for maximum aerobic function
- [​​MAF 180 Formula](https://philmaffetone.com/180-formula/)
  - A person is going to be at their maximum aerobic output—meaning they’re going to be maximally fat oxidizing—at an approximate heart rate of 180 minus their age, plus or minus a few modifications
  - You begin with 180 minus your age and individualize it to your health and fitness needs
    - E.g., If you’re 50 years old, the MAF starting point would be a heart rate of 130, but it could be as high as 140 or as low as 120 depending on how you tweak it
    - That’s a pretty good proxy for zone 2

**Zone 2**

- Zone 2 is just a much more technical definition because it is basically saying it is the point at which you reach that threshold beyond which you will accumulate lactate
- And that happens at about 2.0 millimole
- It’s a much more onerous way to metabolically dial in to exactly what’s happening versus using a proxy for that, which is heart rate.

*Other proxies for zone 2*:

- RPE, relative perceived exertion
- Using heart rate
  - Simplest is 180 minus your age
  - Better is if you know what your true maximum heart rate (not your predicted) — start out at 78% of that value and adjust it based on RPE titrating to just the point at which you will want to open your mouth
  - In other words, we’ll say, “Okay, nasal breathe and get to the point where you just need to open your mouth

## Monitoring lactate for zone 2 exercise [1:10:00]

**Subscriber question**: “*What’s the best way to determine the boundary of zone two for the weekend warrior? Should one buy a device to measure lactate, is there one you recommend?*”

- Another great heuristic: the “talk test”
  - You could talk if you wanted to while doing zone 2 but you would like it
  - if you’re in zone 1 you could talk all day
  - But going from zone 2 into zone 3 is where it just becomes uncomfortable enough to talk

**Lactate devices**

- Peter uses the [Lactate Plus by Nova](https://novabiomedical.com/lactate-plus/index.php)
  - It’s pretty expensive (about 300 bucks)
  - Strips are even more expensive — about $2 per strip
- “I think it is worth having one of these devices to do some spot checks. You don’t have to do it every day.”
- Peter says, “I’m triangulating between power and heart rate and lactate and other factors like meals”
- For example, I will have a totally different lactate response if I eat or don’t eat prior to zone 2
  - Carbohydrate rich meals will drive up lactate. No meal or carbohydrate poor meal, no effect on lactate

§

## Selected Links / Related Material

**Previous AMA about glucose and CGM**: [#165 – AMA #24: Deep dive into blood glucose: why it matters, important metrics to track, and superior insights from a CGM](https://peterattiamd.com/ama24/) | Peter Attia  (peterattiamd.com) [1:45]

**The Sunday email about CGM for non-diabetics**: [Are continuous glucose monitors a waste of time for people without diabetes?](https://peterattiamd.com/are-continuous-glucose-monitors-a-waste-of-time-for-people-without-diabetes/) | Peter Attia (peterattiamd.com) [1:45]

**The JAMA paper that was mentioned in Peter’s email above**: [Start-ups Tout Continuous Glucose Monitoring for People Without Diabetes](https://jamanetwork.com/journals/jama/article-abstract/2780027) (Mary Chris Jaklevic, 2021) [1:45]

**Previous AMA discussion on zone 2 training**: [#145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/) | Peter Attia  (peterattiamd.com) [1:45, 1:07:30]

**Three companies that make CGMs in the clinical grade**: [11:15]

- [Medtronic](https://www.medtronicdiabetes.com/products/guardian-connect-continuous-glucose-monitoring-system)
- [Abbott](https://www.abbott.com/corpnewsroom/strategy-and-strength/freestyle-libre-2-next-gen-is-here.html)
- [Dexcom](https://www.dexcom.com/g6-cgm-system)

**Companies that help with plugging in those CGMs into their apps to help users with their goals, be it weight loss or otherwise**: [11:30]

- [Levels](https://www.levelshealth.com/)
- [Supersapiens](https://www.supersapiens.com/en-EN/?us=yes)

**Sunday newsletter article explaining CGM and how it’s 90% “insight” and 10% behavioral at first then after a few months, the situation flips**: [Are continuous glucose monitors a waste of time for people without diabetes?](https://peterattiamd.com/are-continuous-glucose-monitors-a-waste-of-time-for-people-without-diabetes/) | Peter Attia (peterattiamd.com) [13:15]

**Bill Gifford wrote a story for Men’s Health about CGM**: [You CGM, Right, Bro?](https://www.menshealth.com/health/a35541222/cgm-continual-glucose-monitor-levels-supersapiens/) | BILL GIFFORD, *March 1, 2021* (menshealth.com) [17:15]

**The Tom Dayspring episodes for a lengthy discussion about dyslipidemia**: [Tom Daysping episodes](https://peterattiamd.com/?s=tom+dayspring) | (peterattiamd.com) [19:15]

**Episode of the drive discussing insulin and the prospects of a continuous monitor for insulin**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia  (peterattiamd.com) [20:30]

**Episode of The Drive discussing CGM with the CEO of Dexcom**: [#54 – Kevin Sayer, CEO of Dexcom: Continuous glucose monitors – impact of food, sleep, and stress on glucose, the unmatched power of CGM to drive behavioral change, and the exciting future of CGM](https://peterattiamd.com/kevinsayer/) | Peter Attia  (peterattiamd.com) [26:45]

**Episode of The Drive talking about poor sleep and insulin resistance**: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Peter Attia  (peterattiamd.com) [35:45]

**Just two weeks of four hours of sleep per night result in about a 50% reduction in glucose disposal**: [Impact of sleep debt on metabolic and endocrine function](https://pubmed.ncbi.nlm.nih.gov/10543671/) (Spiegel et al., 1999) [33:45]

**AMA episode discussing the epidemiologic data of the effects of tight glycemic control over lousy glycemic control**: [#165 – AMA #24: Deep dive into blood glucose: why it matters, important metrics to track, and superior insights from a CGM](https://peterattiamd.com/ama24/) | Peter Attia  (peterattiamd.com) [42:00]

**Data on HRT for women**: [42:45]

- [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) | (wikipedia.org)
- **The RCT that was published on the WHI cohort suggested HRT was harmful**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women](https://jamanetwork.com/journals/jama/fullarticle/195120) (Writing Group for the Women’s Health Initiative Investigators, 2002)
- **Episode of The Drive that disputes much of the “findings” from the WHI:** [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia  (peterattiamd.com) [42:45]

**The two main trials that were used for the approval of PCSK9 inhibitors**: [44:15]

- [FOURIER trial](https://www.ncbi.nlm.nih.gov/pubmed/28304224)
- [ODYSSEY trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1801174)

***How much of an accomplishment is the Tour de France if your average biker tried it?*** [48:30]

- [How Long Can You Hold World Hour Record Pace? | Non Cyclist Vs Amateur Vs Pro](https://www.youtube.com/watch?v=JVO5ILQfx0Y) | ​​Global Cycling Network (youtube.com)
- [How Fast Do Pros Cycle Uphill? | Beginner VS Amateur VS Pro: Hill Climb Edition](https://www.youtube.com/watch?v=Rvt9CaR4_7k) | Global Cycling Network (youtube.com)

**Iñigo San Milan and his colleague George Brooks published a 2018 paper that looked at Zone 2 efficiency and lactate**: [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://www.ncbi.nlm.nih.gov/pubmed/28623613) (San Milan and Brooks, 2018) [58:30]

**Bike attachment Bob and Peter use**: [Wahoo Kickr](https://www.wahoofitness.com/devices/bike-trainers) | (wahoofitness.com) [59:00]

**Book about the pain it takes to do the Tour de France**: [The Secret Race: Inside the Hidden World of the Tour de France](https://www.amazon.com/Secret-Race-Inside-Hidden-France/dp/034553042X) by Tyler Hamilton | (amazon.com) [59:45]

**Episode of The Drive with Beth Lewis that discusses rowing**: [#131 – Beth Lewis: The Art of Stability: Learning about pain, mitigating injury, and moving better through life](https://peterattiamd.com/bethlewis/) | Peter Attia  (peterattiamd.com) [1:02:30]

**App that Bob uses for cycling**: [The Sufferfest](https://thesufferfest.com/) [1:06:15]

**Episode of The Drive with Phil Maffetone where they discuss his methods of training which are similar to zone 2 training**: [#144 – Phil Maffetone: Optimizing health and performance through maximal aerobic function](https://peterattiamd.com/philmaffetone/) | Peter Attia  (peterattiamd.com) [1:07:30]

- Phil’s [MAF method](https://philmaffetone.com/method/)
- [MAF 180 Formula](https://philmaffetone.com/180-formula/)

**Lactate meter that Peter prefers**: [Lactate Plus by Nova](https://novabiomedical.com/lactate-plus/index.php) | (novabiomedical.com) [1:11:00]

§

## People Mentioned

- [Bill Gifford](https://www.linkedin.com/in/bill-gifford-125868b/) [17:15]
- [Tom Dayspring](https://twitter.com/Drlipid?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [19:15]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/) [20:30]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) [52:30]
- [Marco Pantani](https://en.wikipedia.org/wiki/Marco_Pantani) [55:45]
- [Iñigo San Millán](https://twitter.com/doctorinigo?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [58:30]
- [George Brooks](https://ib.berkeley.edu/people/faculty/brooksg) [58:30]
- [Tyler Hamilton](https://en.wikipedia.org/wiki/Tyler_Hamilton) [59:45]
- [Beth Lewis](https://www.instagram.com/bethlewisfit/?hl=en) [1:02:30]
- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) [1:04:30]
- [Phil Maffetone](https://philmaffetone.com/about/) [1:07:30]

§