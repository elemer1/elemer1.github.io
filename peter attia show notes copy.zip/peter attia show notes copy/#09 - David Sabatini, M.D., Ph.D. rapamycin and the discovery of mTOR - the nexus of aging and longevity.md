# #09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?

**Source:** [https://peterattiamd.com/davidsabatini/](https://peterattiamd.com/davidsabatini/)

---

In this episode, my good friend David Sabatini delves into his extensive work with the mechanistic target of rapamycin—better known as mTOR—and rapamycin. The compound rapamycin is the only known pharmacological agent to extend lifespan all the way from yeast to mammals—across a billion years of evolution. David, a professor of biology and a member of the Whitehead Institute at MIT, shares his remarkable journey and discovery of mTOR in mammalian cells and its central role in nutrient sensing and longevity. Fasting, rapamycin, mTOR, autophagy, gedankenexperiments: having this conversation with David is like being the proverbial kid in the world’s greatest candy store.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)=

![The Peter Attia Drive](images/davidsabatini/the_Drive_public.png)

Play

#09 - David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?

#09 - David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?

1x15s30s

0:001:11:22

## We discuss:

- mTOR and David’s student years [4:30];
- Rapamycin and the discovery of mTOR [8:15];
- The connection between rapamycin, mTOR, and longevity [30:30];
- mTOR as the cell’s general contractor [34:45];
- The effect of glucose, insulin, and amino acids on mTORC1 [42:50];
- Methionine sensing and restriction [49:45];
- An intermittent approach to rapamycin [54:30];
- Rapamycin’s effects on cancer, cardiovascular disease, and neurodegeneration [57:00];
- Gedankenexperiment: couch potatoes on rapamycin vs perfectly behaved humans [1:03:15];
- David’s dream experiment with no resource constraints [1:07:00]; and
- More.

§

## Show Notes

### mTOR and David’s student years [4:30]

- How David discovered mTOR as a student
- Why David finds himself a little bit strange from an academic point of view
- David’s experience with Solomon Snyder during his MD-PhD program at Johns Hopkins
- What is a “small molecule” like rapamycin, and how do we define it?
- The most influential scientific discussion David ever had
- David says doing your own project as a student is a key foundation for becoming a scientist

### Rapamycin and the discovery of mTOR [8:15]

- David’s introduction to rapamycin, by way of [FK506](https://en.wikipedia.org/wiki/Tacrolimus)
- In Snyder’s lab, they were studying modulation of calcineurin in the brain, and excitotoxicity in the brain, using FK506, and they were using rapamycin as a control drug
- How a letter from Sol Snyder to Suren Sehgal resulted in getting millions of dollars (in hindsight) of rapamycin for free
- How RAFT1 and FRAP1 became mTOR
- How a fax from a journalist tipped David off that [Stuart Schreiber](https://en.wikipedia.org/wiki/Stuart_Schreiber) discovered mTOR at about the same time
- What is gene cloning?
- David was one of the first at the lab to clone [cDNA](https://en.wikipedia.org/wiki/Complementary_DNA)
- David’s [paper on the discovery of RAFT1](https://www.ncbi.nlm.nih.gov/pubmed/7518356/) (now known as mTOR) was published in Cell in 1994
- Silver staining: “A very sensitive way of seeing a protein”
- How did David know he was looking at mTOR when he discovered it?
- Collaborating with Paul Tempst and using microbiology tricks to clone MTOR
- The amazing Paul Tempst: protein sequencer (and predictor)
- Making the transition to running a lab
- Detergent: a key inflection point in David’s career
- David says he continued to work on mTOR when he started his own lab, “largely because I didn’t know anything else”
- David remembers some people being critical of him working on ‘that silly molecule’ (rapamycin)

### The connection between rapamycin, mTOR, and longevity [30:30]

- David tried to look at rapamycin in worms, but it turns out that rapamycin doesn’t get into worms
- But there was an important paper in worms, where there was a mutant in C.*elegans* version of mTOR that had longevity effects (unrelated to daf-2)
- Interestingly, David, says, in the screens they gave the daf mutants, one of the daf mutants, in retrospect, in which the gene was never identified, [turns out to be “raptor” (daf-15)](https://www.ncbi.nlm.nih.gov/pubmed/15253933/): *raptor* stands for **r**egulatory-**a**ssociated **p**rotein of m**TOR**
- Why is it that the inhibition of mTOR (specifically, mTORC1) can extend life?
  - David says we don’t know the answer to that question yet
  - One way to address this question is by eliminating things that mTORC1 does, and see if you still get the lifespan effects
  - If you do this, and look at the many different processes, David would probably vote for [autophagy](https://www.ketonutrition.org/blog/2018/8/5/autophagy-your-cellular-upgrade) as the most important thing that mTORC1 regulates (‘it’s a simple answer, but clearly not the whole answer’)
  - Naïvely, this may be the process that rejuvenates the cell (throwing out the old, and making the new), though this has not been proven

### mTOR as the cell’s general contractor [34:45]

- David’s answer to the question of why mTOR modulation has longevity effects while many other pathways don’t? David uses an analogy of rejuvenating a building to the rejuvenation processes of mTOR
  - You can’t just get a plumber, or an electrician, or a painter, or a carpenter to rejuvenate a building
  - The building has many different features, of which all of them have aged
  - What you really need is a general contractor, who is then going to bring in all of the necessary people to work on the subsystems
  - An old building typically has lots of things wrong with it: electrical, windows, plumbing, and so on
  - To some extent, mTOR is like the general contractor for the cell
  - David doesn’t know of any other pathway that does as many things as mTOR
  - mTOR has a finger in every major process in the cell
  - ‘Another way to think about the question of why mTOR can have an impact on lifespan is, what’s the simplest way to manipulate a cell, so that lots of things are changed? And the answer to that is the modulation of mTOR’
  - ‘All the other pathways: maybe some will regulate transcription, maybe some will do translations, some are going to change the shape of the cell, but if you have to do all those things, plus more: the only way of doing it with a single hit, is to go after mTOR’
  - To impact that state of a cell, to rejuvenate it, to slow aging, you can’t just do one thing, or a handful of things, you probably need 100 things: probably the only way you can do all of those things with one button, is to go after mTOR
- Rapamycin started as an immunosuppressant
  - Mannick paper (the Novartis work) that showed the first beneficial modulation of the immune system in humans
- Why wouldn’t complete inhibition of mTORC1 be a good thing?
  - Because mTORC1 is probably required for the growth of any normal cell
- mTORC2 inhibition and glucose homeostasis
- Rapamycin doesn’t fully inhibit mTORC1
- Autophagy is relatively weakly modulated by rapamycin
- Why is that? Our view is that the way to accomplish that is, not to go after mTORC1 itself, but to go after its upstream regulators
- The big benefit, in David’s view, in doing that, is that you should be able to have something that modulates all mTORC1 substrates, and you can also start to get tissue specificity

### The effect of glucose, insulin, and amino acids on mTORC1 [42:50]

- Insulin and glucose seem to activate mTORC1
- With the growth of a cell, muscle cell, for example, you want the global signal (insulin) that you’re in a fed state, and you want the local signal (e.g., amino acids, glucose) that you have the building blocks in order to grow
- Leucine is more important in the context of strength training
- The key function of mTOR is to turn off
- Why do we need to sense two different amino acids — leucine and arginine — and why did evolution select these two?

### Methionine sensing and restriction [49:45]

- Sabatini’s group [found a methionine sensor](https://www.ncbi.nlm.nih.gov/pubmed/29123071) (SAMTOR, or **S**–**a**denosyl**m**ethionine sensor upstream of m**TOR**C1) for the mTORC1 pathway
- Methionine restriction could be beneficial for longevity if low IGF-1 is beneficial
- ‘There’s extensive literature on methionine restriction having quite beneficial effects on glucose homeostasis and is actually quite reasonable to see lifespan extension effects as good as caloric restriction’
- People supplement with a variant of SAM (**S**–**A**denosyl **M**ethionine): [SAMe](https://www.mayoclinic.org/drugs-supplements-same/art-20364924) (**S**–**A**denosyl-L-**Me**thionine)
- David thinks methionine is probably the most interesting of the amino acids because if you fast an animal, methionine drops the most (in mice)
- SAM is used for methylation reactions
- SAM is the 2nd most common (ATP is most common) cofactor in enzymes
- With fasting, methionine and SAM plummet
- David is working on generating animal models asking whether the sensor we have is involved in the effects of methionine restriction (e.g., knock out the sensor, do methionine restriction, and see if the animal doesn’t have the same benefits of methionine restriction, which means this sensor, and by extension mTORC1, are the key mediators of methionine restriction)

### An intermittent approach to rapamycin [54:30]

- What is the best dose of rapamycin for efficacy and side effects for longevity?
- Intermittent dosing creates autophagy intermittently
- Let the system rebuild
- Removing autophagy is toxic, as is too much autophagy
- Cycling anabolism/catabolism might be the single most important thing to do

### Rapamycin’s effects on cancer, cardiovascular disease, and neurodegeneration [57:00]

- When we think about the life-extending properties of rapamycin, do we believe that it is a result of delaying the clinical onset of disease and/or delay the demise of the animal once it has the disease?
- What do we know about rapamycin and mTOR in the brain?
- We know autophagy is really important for the brain
- Like in all tissues, mTORC1 is a bit of a double-edged sword

### Gedankenexperiment: couch potatoes on rapamycin vs perfectly behaved humans [1:03:15]

- SAD (Standard American Diet) controls, rapamycin intervention, and perfectly behaved humans
- Who lives longer, and/or better: rapamycin intervention, or humans that live “perfectly” as we understand it?

### David’s dream experiment with no resource constraints [1:07:00]

- Signal transduction: David would love to have a description of what all the different tissues are doing over time
- What are all the different tissues doing in different contexts?
- A complete description of what these systems are doing, over time, across many tissues, under many different states

§

§

## Selected Links / Related Material

- **STEM-Talk interview with David Sabatini**: [Episode 70: David Sabatini on the discovery of mTOR and its role in disease, longevity & healthspan](https://www.ihmc.us/stemtalk/episode-70/) | ihmc (ihmc.us/stemtalks)
- **Podcast discussing mTOR/rapamycin with David, Peter, and Nav Chandel**: [The Tim Ferriss Show: My Life Extension Pilgrimage to Easter Island](https://tim.blog/2016/10/20/my-life-extension-pilgrimage-to-easter-island/) | Tim Ferriss (tim.blog) [2:45]
- **David’s paper about the discovery of RAFT1, now known as mTOR**: [RAFT1: a mammalian protein that binds to FKBP12 in a rapamycin-dependent fashion and is homologous to yeast TORs](https://www.ncbi.nlm.nih.gov/pubmed/7518356/) (Sabatini et al., 1994) [12:00]
- **Stuart Schreiber’s paper also discovering mTOR about the same time as David**: [A mammalian protein targeted by G1-arresting rapamycin-receptor complex](https://www.ncbi.nlm.nih.gov/pubmed/8008069/) (Brown et al., 1994) [12:00]
- **Mutations in daf-15 (raptor) extend lifespan in worms**: [The TOR pathway interacts with the insulin signaling pathway to regulate C. elegans larval development, metabolism and life span](https://www.ncbi.nlm.nih.gov/pubmed/15253933) (Jia et al., 2004) [31:00]
- **Paper revealing how inhibition of mTOR could extend lifespan**: [Genetics: Influence of TOR kinase on lifespan in C. elegans](https://www.nature.com/articles/426620a) (Vellai et al., 2003) [31:00]
- **Paper revealing how inhibition of mTOR could extend lifespan**: [mTOR is a key modulator of ageing and age-related disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3687363/) (Johnson, Rabinovitch, and Kaeberlein, 2013) [31:00]
- **Dom D’Agostino’s blog post on autophagy**: [Autophagy – Your Cellular Upgrade](https://www.ketonutrition.org/blog/2018/8/5/autophagy-your-cellular-upgrade) | Keto Nutrition (ketonutrition.org) [34:00]
- **Paper showing first beneficial modulation of the immune system in humans**: [mTOR inhibition improves immune function in the elderly](https://stm.sciencemag.org/content/6/268/268ra179.short) (Mannick et al., 2014) [38:00]
- **A recent paper by Mannick’s group showing enhanced immune function and reduced infections with mTORC1 inhibition**: [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://www.ncbi.nlm.nih.gov/pubmed/29997249) (Mannick et al., 2018)
- **Paper that looked at leucine sensing for the MTORC1 pathway**: [Sestrin2 is a leucine sensor for the mTORC1 pathway](https://www.ncbi.nlm.nih.gov/pubmed/26449471) (Wolfson et al., 2015) [45:15]
- **Paper that looked at arginine sensing for the mTORC1 pathway**: [The CASTOR Proteins Are Arginine Sensors for the mTORC1 Pathway](https://www.ncbi.nlm.nih.gov/pubmed/26972053) (Chantranupong et al., 2016) [45:15]
- **Methionine sensing for the mTORC1 pathway**: [SAMTOR is an S-adenosylmethionine sensor for the mTORC1 pathway](https://www.ncbi.nlm.nih.gov/pubmed/29123071) (Gu et al., 2017) [49:45]
- **Paper on methionine restriction**: [Methionine restriction and lifespan control](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5008916/) (Lee et al., 2016) [50:00]
- **Genetic papers in flies that suggest that some of the methionine restriction go through the TOR pathway in flies**: [Methionine restriction extends lifespan of Drosophila melanogaster under conditions of low amino-acid status](https://www.ncbi.nlm.nih.gov/pubmed/24710037/) (Lee et al., 2014) [50:30]
- **Antidepressant supplement backed by “quite convincing data”**: [SAMe](https://www.webmd.com/vitamins/ai/ingredientmono-786/same) | (webmd.com) [50:45]
- **Nobel Prize to Ohsumi for work on autophagy**: [Nobel Prize goes to Japanese scientist for work on key cellular recycling process](https://www.statnews.com/2016/10/03/nobel-prize-medicine/) | Sharon Begley ([statnews.com](https://www.statnews.com/)) [1:00:00]
- **Cell paper discussing Ohsumi’s Nobel-winning work**: [Autophagy Captures the Nobel Prize](https://www.cell.com/cell/fulltext/S0092-8674(16)31595-1?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867416315951%3Fshowall%3Dtrue) (Tooze and Dikic, 2016) [1:00:00]
- **Paper explaining mTOR signaling**: [mTOR signaling at a glance](https://jcs.biologists.org/content/122/20/3589) (Laplante and Sabatini, 2009)
- **Paper reviewing advances in their understanding of mTOR**: [mTOR Signaling in Growth, Metabolism, and Disease](https://www.ncbi.nlm.nih.gov/pubmed/28283069) (Saxton and Sabatini, 2017)
- **Paper by Sabatini discussing his career**: [Twenty-five years of mTOR: Uncovering the link from nutrients to growth](https://www.pnas.org/content/114/45/11818) (Sabatini, 2017)

§

§

## People Mentioned

- [Nav Chandel](https://www.chandellab.com/people) (expert on metabolism, on [Tim Ferriss podcast](https://tim.blog/2016/10/20/my-life-extension-pilgrimage-to-easter-island/) episode with Peter and David) [2:45]
- [Matt Kaeberlein](https://twitter.com/mkaeberlein?lang=en) (upcoming podcast guest on [The Drive](https://peterattiamd.com/podcast/), [The Dog Aging Project](https://dogagingproject.com/)) [3:45]
- [Solomon Snyder](https://en.wikipedia.org/wiki/Solomon_H._Snyder) (David joined his lab during his M.D., Ph.D. at Johns Hopkins) [5:45]
- [Suren Sehgal](https://ns1.imtech.res.in/drugpedia/index.php/Surendra_Nath_Sehgal) (discoverer of rapamycin) [9:00]
- [Stuart Schreiber](https://en.wikipedia.org/wiki/Stuart_Schreiber) (identified mTOR at the same time as David while at Harvard) [11:15]
- [Paul Tempst](https://www.mskcc.org/research-areas/labs/members/paul-tempst) (helped David with protein sequencing) [15:30, 19:15]
- [Michael Hall](https://en.wikipedia.org/wiki/Michael_N._Hall) (yeast protein sequencing) [18:30]
- [Dos Sarbassov](https://faculty.mdanderson.org/profiles/dos_sarbassov.html) (David’s postdoc made a key detergent discovery leading to mTOR) [27:00]
- [Bobby Saxton](https://twitter.com/RSaxtonPhD) (worked with David at Whitehead and explained to Peter why inhibition of mTORC1 leads to inhibition of mTORC2) [39:15]
- [Noboru Mizushima](https://www.novusbio.com/faculty/noboru-mizushima) (pioneering work with autophagy) [59:45]
- [Yoshinori Ohsumi](https://en.wikipedia.org/wiki/Yoshinori_Ohsumi) (Nobel Prize for autophagy work) [1:00:00]
- [Bernardo Sabatini](https://twitter.com/blsabatini?lang=en) (neuroscientist, David’s brother) [1:02:45]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/08/David-Sabatini-1024-512-twitter-e1535452606833-300x300.jpeg)

##### David Sabatini, M.D., Ph.D.

David M Sabatini is an American scientist and Professor of Biology at the Massachusetts Institute of Technology as well as a member of the Whitehead Institute for Biomedical Research. He has been an investigator of the Howard Hughes Medical Institute since 2008 and was elected to the National Academy of Sciences in 2016. He is known for his important contributions in the areas of cell signaling and cancer metabolism, most notably the discovery and study of mTOR, a protein kinase that is an important regulator of cell and organismal growth that is deregulated in cancer, diabetes, as well as the aging process. [[wikipedia.org](https://en.wikipedia.org/wiki/David_M._Sabatini)]