# #13 – Brett Kotlus, M.D.: How to look younger while we live longer

**Source:** [https://peterattiamd.com/brettkotlus/](https://peterattiamd.com/brettkotlus/)

---

This episode explores the question of how we can maintain a naturally youthful look as we get older. Brett — a New York City oculofacial plastic surgeon who specializes in both non-surgical and surgical cosmetic and reconstructive procedures of the eyes and face — shares some remarkably practical advice on everything from the most extensive procedural options, down to the simple steps one can do themselves, starting today, that can make a tremendous impact. Brett also discusses how to pick a provider you trust while you’re sorting through the ever-growing list of facial treatments and cosmetic procedures.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/brettkotlus/the_Drive_public.png)

Play

#13 - Brett Kotlus, M.D.: How to look younger while you live longer

#13 - Brett Kotlus, M.D.: How to look younger while you live longer

1x15s30s

0:001:48:42

## We discuss:

- History of medical training that led to Brett’s current interests [5:00];
- What changes occur that make skin look older over time? [8:00];
- How to avoid the “unnatural” look associated with cosmetic surgery [17:00];
- Facial augmentation, fixing eye-bags, and picking the right provider [22:15];
- Common botox mistakes, and how to do it right [37:30];
- Protect and rejuvenate your skin with these 3 main tools [46:30];
- Latest trends in cosmetic industry, botox, cryolipolysis, the various forms of facials, and PRP [1:05:00];
- Importance of picking a provider you trust, rather than a device you want [1:31:30];
- Future of the cosmetic field [1:33:00]; and
- More.

§

## Show Notes

## History of medical training that led to Brett’s current interests [5:00]

- Trained both in general oculoplastic surgery and general plastic surgery
- Eye and facial plastic surgeon specializing in cosmetic and reconstruction of the face, with a particular interest in the region around the eyes

## What changes occur that make skin look older over time? [8:00]

- Loss of bone
- Reduction in facial fat, muscles and ligaments
- Sun exposure causing [solar elastosis](https://en.wikipedia.org/wiki/Actinic_elastosis) and brown spots
- Facial skin changes more dramatically than elsewhere
- Gravity constantly pulling down creates wear and tear
- Genetic factors can influence how our skin ages and looks (darker skin tends to age better)

## How to avoid the “unnatural” look associated with cosmetic surgery [17:00]

- Brett advises, don’t try to look more than 7-10 years younger than your current age
- Listen to a trusted advisor who will tell you when you’ve gone far enough
- Don’t try to enlarge something beyond its natural dimensions, keep natural contours and features
- “There’s no amount of money that will make you look ‘naturally’ 30 years younger than where you are”

**Facial augmentation, fixing eye-bags, and picking the right provider [22:15]**

- Lip fillers ([hyaluronic acid](https://www.plasticsurgery.org/cosmetic-procedures/dermal-fillers/types)) are becoming more common, for “good and bad” reasons, Brett says
- Is a facelift permanent? Generally harder to fix than “fillers” which are enzymes that can be reversed and taken out
- Brett has a [very interesting technique](https://drkotlus.com/dark-circles-and-eye-bags/) for fixing eye bags with [hyaluronic gel](https://www.plasticsurgery.org/cosmetic-procedures/dermal-fillers/types) fillers
  - Peter has sent many patients to Brett for this procedure
  - Looks amazing, minimally invasive
  - This is Brett’s niche at his practice

**When selecting a provider:**

- A good provider will understand how your face works together and how augmenting one area, in particular, might affect others
- First look up what organizations certify people (For eye fillers, look at the [oculoplastic organization](https://en.wikipedia.org/wiki/Oculoplastics))
- Read references and referrals
- Look at before and after photos
- Ask the nurses who work in the hospital who the best doctor is
- Interview 3-4 doctors
  - Do you connect with them? On the same page?
  - Ask how many procedures they have done
  - Ask what complications that doctor has had and how he or she dealt with them
- Tip: don’t gloss over complications, figure out the likelihood and the necessary steps that will be taken in the case of a complication

## Common botox mistakes, and how to do it right [37:30]

- Classic mistake is injecting botox directly into wrinkles on the forehead and “going after the horizontal forehead lines”
- Peter had an unpleasant experience with botox in forehead
- A better approach to botox:
  - Inject the corrugator and procerus muscles (just at the top of the nose, that you use to furrow your brows)
  - Light sprinkle in the forehead
  - It lasts 4 months, repeat, and over time the forehead lines will soften
  - Ideally, you do botox *before* permanent etch lines appear

## Protect and rejuvenate your skin with these 3 main tools [46:30]

**Protecting your skin from the sun [47:00]**

**Difference between UV rays, A vs. B**

- Different wavelengths of ultraviolet light
- Both UVA and UVB rays can cause cancer
- UVB (not UVA) is responsible for turning your skin red

**Ways to classify and rate different sunscreens**

- SPF rating (for UVB rays)
  - A way of rating the protection from UVB rays
  - An SPF of 15, for example, is saying that it will take you 15 times longer to turn red versus wearing no sunscreen
  - “Over (SPF) 30, you don’t get that much more benefit”
- Protection from UVA rays
  - NB: SPF rating does NOT apply to UVA rays
  - To protect from UVA you must use “broad spectrum” sunscreen
- Organic (chemical) versus inorganic (physical) sunscreens
  - Organic, in some cases, have negative side effects such as hormonal disruptive effects so Brett advises against these
  - Inorganic, which uses zinc and/or titanium as a reflective agent, is better and safer in Brett’s opinion

**Characteristics of the ideal sunscreen**

- SPF 30
- Broad Spectrum
- Inorganic (i.e., physical, not chemical)

**How and where to apply sunscreen properly**

- Reapply every 2 hours
- Focus on the face, hands, and chest as they are most exposed to the sun

**Trusted Sunscreen brands**

- [EltaMD](https://eltamd.com/product/uv-physicalbroad-spectrum-spf-41/)
- [MD Solar Science](https://mdsolarsciences.com/collections/all/products/mineral-creme-spf-50?variant=3353122241)
- [Replenix](https://topixpharm.com/product/sheer-physical-sunscreen-spf-50/)
- [SkinCeuticals](https://www.skinceuticals.com/skin-care/category/sunscreens)

**Retinoic acid for skin protection and maintenance [56:30]**

**Retinoic acid**

- A form of vitamin A that is proven for both anti-aging (i.e., wrinkles) as well as for acne
- Acts like a hormone working at the DNA level, affecting transcription of particular genes
- Promoting collagen synthesis
- Increasing turnover of skin cells
- “One of the top 3 things I would recommend for everyone to be using if they are interested in having a skin care regimen that is effective”

**Where to get topical retinoic acid?**

- [Tretinoin](https://en.wikipedia.org/wiki/Tretinoin), prescribed by the doctor, more potent, but has more side effects (i.e., dry skin)
- [Retinol](https://en.wikipedia.org/wiki/Retinol), over-the-counter, many brands, including: [PeterThomasRoth](https://www.peterthomasroth.com/product/retinol-fusion-pm/retinol-fusion-pm-night-serum/1501321/each), [Topix](https://topixpharm.com/product/all-trans-retinol-smoothing-serum/), [The Ordinary](https://theordinary.com/product/rdn-advanced-retinoid-2pct-30ml)

**How to use it**

- Start with over-the-counter retinol to avoid getting dry skin
- You can try doing it daily, but if you are getting dry skin, try the following:
  - Every 2nd or 3rd day
  - “Pulse” treatment, put it on, and 10 minutes later, wash it off
- Apply at night before bed because sun exposure renders retinol ineffective
- If you can tolerate this without side effects, you may consider a prescription

**Tip: Don’t forget to apply it to your eyelids**

“Someone who’s been using retinol from their 20s-on always looks better”

**Use vitamin C to reverse sun damage [1:00:45]**

- Topical [vitamin C](https://en.wikipedia.org/wiki/Vitamin_C) helps to *reverse* sun damage (unclear as to whether it helps to *prevent* against sun damage)
- [L ascorbic acid](https://www.skintrends.com/skincare/face/product-faqs/ingredients/vitamin-c/l-ascorbic-acid.html) is the form of vitamin C thought to be the most effective
- Brett recommends the vitamin C *serums*
- Apply vitamin C serum in the morning
- You can apply sunscreen on top of the vitamin C once the serum dries

*What percentage of the benefit is someone getting, in terms of an anti-aging regimen, by taking these 3 (sunscreen, retinol, vitamin C) steps?*

“It will go a long way…using these powerful basics, I’ve seen amazing changes”

## Latest trends in the cosmetic industry, botox, cryolipolysis, the various forms of facials, and PRP [1:05:00]

**Latest in botox [1:05:00]**

Many non-cosmetic indications: Bladder spasms, vocal cord spasm, [torticollis](https://en.wikipedia.org/wiki/Torticollis), migraines, [hyperhidrosis](https://en.wikipedia.org/wiki/Hyperhidrosis), etc.

For cosmetic purposes:

- There is a progression of the approach to using smaller amounts, spread over a larger area, and utilizing an expert understanding of how the face muscles work together
- Can now turn around a resting frown face, reduce a gummy smile, make eyelids rest differently so your eyes appear more open, and more
- But be careful, as many non-experienced doctors start to move into the cosmetic world and may not have the expertise necessary for high-quality work

**Tip: look for truly personalized care**

**Non-surgical fat reduction with cryolipolysis [1:10:00]**

[Cryolipolysis](https://en.wikipedia.org/wiki/Cryolipolysis), “cool sculpting,” is a procedure that suctions your fat and freezes it at a certain temperature in order to cause apoptosis of those cells

- Is it effective? “Yes, it’s effective”
- Other devices that also do this, the “Sculpture”… these are not “operator dependent” because you just turn them on and they do the job
- There is a heat and cold device for fat suction, which is more effective?
- “Both effective…the two main leaders in the industry give you about 20% of subcutaneous fat reduction”
- Where on the body? “Anywhere you can pinch fat” such as flanks, necks, etc., but not visceral fat

**Beware: there are a lot of copycats that aren’t FDA approved**

**Facial rejuvenation treatments: Chemical peels, lasers, energy devices, PRP [1:12:00]**

Chemical Peels

- Peter got a chemical peel and was amazed at 3 things:
  - how quick and easy the procedure was
  - how red he was for 5 days and the need for Aquaphor
  - how many sunspots vanished
- Peels work by burning away the outer layer of skin (why you look red) and they go at different depths depending on how many layers of chemical applied, type of chemical, and the strength
- Risks: Can get a burn and a scar if not careful
- Types of peels: phenol (more risk, more benefit), TCA peels, glycolic, etc.
- Brett does not favor one type peel over the others…“Depends on skin type…very specific treatment plan”
- A very operator-dependent procedure, be sure to choose the right provider
- What questions to ask when choosing a provider?
  - How many peels have you done?
  - Can you show me examples?
  - Is this safe for my skin-type?
  - What are the risks?
- Peter gets a quick consultation

**Lasers [1:14:45]**

- Similar to peels except that most lasers today are [fractional](https://en.wikipedia.org/wiki/Photorejuvenation), which means they aren’t taking off all the skin (like a peel would), but instead are taking a more targeted approach
- Most common lasers for resurfacing are Erbium and CO2
- Different levels within those, different energy settings, certain people are not candidates
- There are safe and low-grade lasers like [Clear and Brilliant](https://www.clearandbrilliant.com/) where there doesn’t have to be a doctor performing the procedure, can be a nurse
- When considering a laser treatment, Brett advises to rely heavily on the provider’s advice
- Need a consultation based on skin type
- Are lasers painful? “Usually no, but depends on your pain tolerance…but more powerful lasers could require some type of local anesthetic”

**Energy devices [1:16:15]**

- Designed for facial tightening rather than fixing the skin surface, the idea is that heat is stimulating collagen synthesis, causing contraction and tightening
- Types include: [Thermage](https://www.thermage.com/) using radio frequency, [Ultherapy](https://www.ultherapy.com/?gclid=Cj0KCQjwiJncBRC1ARIsAOvG-a60clxO-zPm_BC0NA2CgxiUoGE9GTO-W-0Z3BrV8BD2aT8rkf831UwaAlzvEALw_wcB) which is a focused ultrasound, plasma devices, and more
- “For the most part I’m underwhelmed with these technologies” —Brett

**Platelet-rich Plasma (PRP) [1:17:30]**

- PRP, which is a process of drawing an individual’s blood, spinning it to separate the platelet-rich plasma from the rest of the components of blood, and then injecting the concentrated PRP back into the patient for a number of indications
- PRP, in some circles, is touted as a cure-all (e.g., joint pain, smooth your skin, replace your hair, heal wounds, enhance erections), but Brett advises that “you have to be a little bit skeptical…the literature doesn’t support it very strongly”
- For facial rejuvenation, there is a procedure called the Vampire Facial which is marketed for wrinkles, acne scarring, hyperpigmentation, anti-aging
  - Taking PRP and using [microneedling](https://en.wikipedia.org/wiki/Collagen_induction_therapy) to inject it into the face
  - Pretty low-risk procedure
  - $800-$1,200
  - “I’m not a major proponent of this procedure…I don’t think it is well proven”
  - Looking at the before and after pictures, “It’s very hard to find good results that are not the result of differences in lighting”

**Other devices, FDA approval, financial motivation to create the next best thing [1:28:30]**

- It’s important to note that there is a financial incentive in the industry to create the next best device
- An FDA approved device or procedure doesn’t mean it’s effective, it just means it’s relatively safe
- A good doctor will be selective and turn down patients if they aren’t an ideal candidate
- “We have to step back and ask ourselves, w*ho are we serving ourselves or our patients?*” —Brett
- Peter says someone once told him, “Your reputation as a surgeon is going to be much more about the patients you choose not to operate than the patients you choose to operate on”

## Importance of picking a provider you trust, rather than a device you want [01:31:30]

- Many doctors own a lot of the same devices, but you have to ask yourself how they are using it and are they being selective?
- A good doctor wouldn’t do a procedure to you unless they would be willing to do it to themselves or a family member
- Is the doctor giving you the solution that they have? Or are they giving you the solution that you need (even if that means sending you elsewhere)?
- Good filtering questions:
  - What are the types of procedures you typically don’t do and you refer out?
  - What is *your* solution? And are there other solutions that are out there that you can discuss?

## Future of the cosmetic field [1:33:00]

- Fat grafting with nanofat
- Utilizing stem cells
- Brett using nanofat as a stem cell, “our fat is a rich source of stem cells”
- Fibroblast Growth Factor (FGF) for facial volumization “seems to hold some promise”
- Customization at the genetic level
  - How is your skin type going to respond to this laser?
  - What energy is best for you based on your genetics?
- 3D “bioprinting”
  - Able to bring ears, organs, blood vessels, skin, custom implants, and more
  - Brett already uses 3D printing to make custom surgical instruments
  - There is still a big regulatory obstacle to get 3D printing of a living cell inside a surgical room
  - “It’s mind-blowing, and it’s exciting, and it’s frustrating, because I want the next step, but it takes money, time, and people that are interested”

§

§

## Selected Links / Related Material

### Skin care products

Top priority:

- **Trusted sunscreen brands**: [EltaMD](https://eltamd.com/product/uv-physicalbroad-spectrum-spf-41/), [MD Solar Science](https://mdsolarsciences.com/collections/all/products/mineral-creme-spf-50?variant=3353122241), [Replenix](https://topixpharm.com/product/sheer-physical-sunscreen-spf-50/), [SkinCeuticals](https://www.skinceuticals.com/skin-care/category/sunscreens) (56:00)
- **Brush-on powder sunscreen, great for on-the-go**: [Colorescience](https://www.colorescience.com/products/sunforgettable-total-protection-brush-on-sunscreen-shield-spf-50) | ([colorescience.com](https://www.colorescience.com/)) [56:00]
- **Retinol, non-prescription options**: [PeterThomasRoth](https://www.peterthomasroth.com/product/retinol-fusion-pm/retinol-fusion-pm-night-serum/1501321/each), [Topix](https://topixpharm.com/product/all-trans-retinol-smoothing-serum/), [The Ordinary](https://theordinary.com/product/rdn-advanced-retinoid-2pct-30ml) (56:30)
- **Vitamin C, skin antioxidants**: [Kiehls](https://www.kiehls.com/skincare/healthy-skin-essentials/powerful-strength-line-reducing-concentrate/595.html), [Skinceuticals](https://www.skinceuticals.com/skin-care/serums/vitamin-c-serum), [BKMD](https://bkmdlab.com/products/overnight-antioxidant-capsules), [NIOD](https://niod.com/product/ethylated-l-ascorbic-acid-30pct-network-30ml) (1:00:45)

May also want to consider:

- **This has different sized particles of Hyaluronic acid and supporting peptides that boost your skin’s water content and your intrinsic production of hyaluronic acid**: [Deciem Multi-molecular Hyaluronic Acid Serum](https://niod.com/product/multi-molecular-hyaluronic-complex-30ml) | (niod.com)
- **This is Dr. Kotlus’s product that tightens the lower eyelids and flattens eye bags before an event and lasts about 6 hours**: [Tensate Instant Eye Lift Serum](https://bkmdlab.com/products/tensate-instant-eye-lift-serum) | (bkmdlab.com)
- **This is a huge Korean-beauty sensation called Hanacure mask that tightens your face like it’s shrink wrapped**: [Multi-Action Treatment Mask](https://www.hanacure.com/products/the-all-in-one-facial-starter) | (hanacure.com)
- **Dr. Kotlus has a product similar to the Hanacure mask that will last for several uses and eliminates the multiple steps**: [Extra Firming Gel Mask](https://bkmdlab.com/products/extra-firming-gel-mask) | (bkmdlab.com)
- **Night moisturizer that Dr. Kotlus described as “amazing”**: [Night Moisturizer with Vitamin A](https://www.avyaskincare.com/products/night-moisturizer) | ([avyaskincare.com](https://www.avyaskincare.com/))
- **DIY facial exfoliant 2 x per week (You don’t always need to buy skin products, says Dr. Kotlus)**: [DIY sugar scrub](https://www.google.com/search?client=safari&rls=en&q=DIY+sugar+scrub&ie=UTF-8&oe=UTF-8) | ([google.com](https://www.google.com/))
- **Odorless brand of moisturizer with SPF that Peter likes**: [CeraVe](https://www.cerave.com/) (cerave.com)

### Other helpful product-related resources:

- **Great resource to find out which products have toxicity risks**: [SKINDEEP Database](https://www.ewg.org/skindeep) | ([ewg.org](https://www.ewg.org/))
- **FDA page that lists dermal fillers that have approval**: [Dermal Fillers Approved by the Center for Devices and Radiological Health](https://www.fda.gov/MedicalDevices/ProductsandMedicalProcedures/CosmeticDevices/WrinkleFillers/ucm227749.htm) | ([fda.gov](https://www.fda.gov/))

### Other selected links / related material

- **Brett’s unique approach to fixing eye bag**: [ARE EYE BAGS GETTING IN THE WAY OF HOW YOU WANT TO BE SEEN?](https://drkotlus.com/dark-circles-and-eye-bags/) | (drkotlus.com) [22:15]
- **Study looking at benefit and risks of sunlight**: [Sunlight, UV-radiation, vitamin D and skin cancer: how much sunlight do we need?](https://www.ncbi.nlm.nih.gov/pubmed/18348443) (Holick, 2008) | (47:00)
- **Trending non-surgical fat reducing technique**: [CoolSculpting](https://www.coolsculpting.com/what-is-coolsculpting/) | (coolsculpting.com) [1:10:00]
- **Safe and low-grade laser**: [Clear and Brilliant](https://www.clearandbrilliant.com/) | (clearandbrilliant.com) [1:15:00]
- **Ball bearings scene in [Fletch](https://en.wikipedia.org/wiki/Fletch_(film))**: [It’s All Ball Bearings](https://www.youtube.com/watch?v=pbWWxGmbS9s) | Ditto Greetings (youtube.com) [1:34:15]
- **Brett mentions enjoying Peter on the Joe Rogan Experience episode**: [Joe Rogan Experience #1108 – Peter Attia](https://www.youtube.com/watch?v=gP1NA5f4LfE) | PowerfulJRE (youtube.com) [1:40:15]
- **Experiment where they grew the ear on the mouse’s back**: [Vicante Mouse](https://en.wikipedia.org/wiki/Vacanti_mouse) | (wikipedia.org) [1:41:15]
- **Peter’s Instagram post Brett refers to as, “Einstein’s theory of longevity”**: [Longevity in a nutshell](https://www.instagram.com/p/BijxwKsltJ3/?utm_source=ig_web_button_share_sheet) | [@peterattiamd](https://www.instagram.com/peterattiamd/) (instagram.com) [1:45:00]
- **Brett’s video highlighting the approach of his practice**: [It Starts with Your Eyes](https://drkotlus.com/) | (drkotlus.com) [1:53:00]

**Additional References:**

- [Newer Understanding of Specific Anatomic Targets in the Aging Face as Applied to Injectables: Aging Changes in the Craniofacial Skeleton and Facial Ligaments](https://www.ncbi.nlm.nih.gov/pubmed/26441110) (Wong et al., 2015)
- [Newer Understanding of Specific Anatomic Targets in the Aging Face as Applied to Injectables: Superficial and Deep Facial Fat Compartments–An Evolving Target for Site-Specific Facial Augmentation](https://www.ncbi.nlm.nih.gov/pubmed/26441111) (Ramanadham SR et al., 2015)
- [A three-dimensional construct of the aging eyebrow: the illusion of volume loss](https://www.ncbi.nlm.nih.gov/pubmed/22231412) (Papageorgiou et al., 2012)

§

## People Mentioned

- [Nicole Kidman](https://twitter.com/NicoleKidman?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:05:45]
- [Chevy Chase](https://en.wikipedia.org/wiki/Chevy_Chase) (in Fletch, [ball bearings scene](https://www.youtube.com/watch?v=pbWWxGmbS9s)) [1:34:20]
- [Joe Rogan](https://twitter.com/joerogan?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:40:15]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/09/brett-kotlus-website-pic-e1535823242595-500x500.png)

##### Brett Kotlus, M.D.

Dr. Kotlus received a Master’s degree in Genetics from the Pennsylvania State University and his medical degree from the Sackler School of Medicine. After completing his residency at the North Shore-Long Island Jewish Health System of the Albert Einstein College of Medicine, he completed two accredited fellowships in Oculofacial Plastic Surgery and General Cosmetic Surgery in Tucson, Arizona. He subsequently served as Assistant Clinical Professor at the University of Arizona. Before moving his practice to NYC in 2014, Dr. Kotlus provided surgical and non-surgical aesthetic services for 8 years in the Midwest at one of the country’s most successful cosmetic surgery offices. [https://drkotlus.com/about/]

Brett on Facebook: [Brett Kotlus, M.D.](https://www.facebook.com/drkotlus/)

Brett on Instagram: [@drkotlus](https://www.instagram.com/drkotlus/?hl=en)

Brett on Twitter: [@brettkotlus](https://twitter.com/brettkotlus?lang=en)

Brett’s website: [Brett Kotlus MD](https://drkotlus.com/)