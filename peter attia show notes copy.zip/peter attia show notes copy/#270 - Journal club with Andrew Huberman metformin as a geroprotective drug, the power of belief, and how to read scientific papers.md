# #270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers

**Source:** [https://peterattiamd.com/andrewhuberman2/](https://peterattiamd.com/andrewhuberman2/)

---

Andrew Huberman, Professor of Neurobiology at Stanford University and host of the [Huberman Lab podcast](https://hubermanlab.com/), joins us in a special journal club episode. Peter and Andrew each present a recent paper that sparked their interests, delving into the findings, dissecting their significance, discussing potential confounders and limitations, and exploring remaining questions. Importantly, they share their methodologies for comprehending research studies, providing valuable insights for listeners to navigate this process independently. Peter presents an epidemiological study reevaluating a noteworthy metformin result that intrigued the anti-aging community, leading to discussions on metformin’s geroprotective potential (or lack thereof) and the current lack of aging biomarkers. Andrew introduces a paper examining how our beliefs about the medications we take influence their biological effects, distinguishing the “belief effect” from a placebo effect and highlighting its exciting implications for the future.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/andrewhuberman2/the_Drive_public.png)

Play

#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers

#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers

1x15s30s

0:002:16:58

## We discuss:

- The motivation behind this “journal club” conversation [2:45];
- Why Peter chose a paper on metformin, how metformin works, and why it generated excitement as a longevity-enhancing agent [9:00];
- Defining insulin resistance and its underlying causes [16:15];
- Metformin as a first-line treatment for type 2 diabetes, and Peter’s evolving interest in metformin as a geroprotective drug [22:00];
- Defining the term “geroprotection” [24:45];
- The 2014 study that got the anti-aging community interested in metformin [26:00];
- Peter presents the 2022 paper that repeats the analytical approach from the 2014 Bannister study [33:15];
- Greater mortality in the metformin group: how results differed between the 2022 paper by Keys and the 2014 Banner paper [40:00];
- Understanding statistical significance, statistical power, sample size, and why epidemiology uses enormous cohorts [51:45];
- Interpreting the hazard ratios from the 2022 metformin study, and the notable takeaways from the study [56:45];
- Drugs that may extend lifespan, why Peter stopped taking metformin, and a discussion of caloric restriction [1:08:45];
- Current thoughts on the use of metformin for longevity [1:21:00];
- Could there be any longevity benefit to short periods of caloric restriction? [1:22:45];
- Peter and Andrew’s process for reading scientific papers [1:26:45];
- The biological effects of belief, and how “belief effects” differ from placebo effects [1:32:30];
- The neurobiology of nicotine: a precursor conversation before delving into the paper Andrew chose [1:39:45];
- Andrew presents a paper that demonstrates the impact of belief [1:45:30];
- Analyzing the fascinating results of the Perl paper [1:54:30];
- Exciting implications of the findings about “belief” reported by Perl and colleagues [2:03:15]; and
- More.

§

## Show Notes

\***Notes from intro**:

- This is a special episode of the drive
  - It’s a dual episode with Andrew Huberman that will be released both on the *Huberman Lab* podcast and *The Drive*
- In the episode Peter and Andrew have a journal club where they each present and talk through a paper they have found interesting in the previous couple of months
- The hope is this will help people understand not only the results of these specific papers, but it will also give people an idea about how to read and interpret a paper
- Peter’s paper looks at a [study](https://pubmed.ncbi.nlm.nih.gov/36287641/) on [metformin](https://en.wikipedia.org/wiki/Metformin) by Keys et al.
  - This looked back at the 2014 study by Bannister et al. that initially got everyone really interested in metformin as a possible geroprotective molecule
- Through looking at this paper we discuss metformin as a possible geroprotective drug
- We also have a general discussion of geroprotection and the current lack of biomarkers of aging
- Andrew’s paper [addressed](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2) how our beliefs of the drug we take impacts the effect they have on us on a biological level
  - Not looking at placebo effects but actual belief effects and what this could mean going forward
- Andrew is an [associate professor of neurobiology at the Stanford University School of Medicine](https://med.stanford.edu/profiles/andrew-huberman#bio) and the host of the very popular [*Huberman Lab* podcast](https://hubermanlab.com/)
  - He’s also a former podcast guest on [episode #249](https://peterattiamd.com/andrewhuberman/)

## The motivation behind this “journal club” conversation [2:45]

**Overview of today’s conversation**:

- This is something Peter and Andrew have been wanting to do for a while and it’s something they do all the time
  - Peruse the literature and find papers they are excited about
- This episode will focus on talking about papers we find exciting in real time, for the first time, in podcast format
- The goal is to give people some sense of why they’re so excited about these papers
  - We feel people should know about these findings
- It’s also an opportunity for people to learn  how to dissect information and think about the papers they hear about in the news
  - To start thinking like scientists and clinicians
  - To get a better sense of what it looks like to pick though a paper: the good, the bad, the ugly
- Papers might be downloaded from PubMed
- Peter used to run a journal club inside his practice
  - Once a month a person would pick a paper and we would go through it in a formal journal club presentation
  - We’ve gotten away from it for the last year just because we’ve been a little stretched thin
  - Peter thinks it’s something we need to resume because it’s a great way to learn and it’s a skill
- People probably ask Andrew all the time, “*What are the dos and don’ts of interpreting scientific papers?*”

**Is it enough to just read the abstract?**

- No

*The “How to” is tougher*

- The two papers chosen today illustrate two opposite ends of the spectrum
- Andrew is going to talk about something and get into the technical nature of the assays, the limitations, etc.
- Peter is going to talk about a very straightforward, simple epidemiologic paper, that he thinks has important significance
  - Originally he had gone down the rabbit hole on a much more nuanced paper at ATP binding cassettes in cholesterol absorption
  - Ultimately, he thought this paper might be more interesting to a broader audience

**Peter had a dream about Andrew last night**

- In this dream, Andrew was obsessed with making a certain drink that was like his elixir
  - It had all of these crazy ingredients in it, tons of supplements
  - When Peter woke up, he was trying hard to remember them
- One thing it had in it was dew
  - Andrew had to collect a certain amount of dew off the leaves every morning to put into this drink
- The best part: Andrew had a thermos of this stuff that had to be with him everywhere
  - All of his clothes had to be tailored with a special pocket that he could put the thermos into so that he was never without this special drink
- Andrew replies, “*Well, it’s not that far from reality, I’m a big fan of* [*yerba mate*](https://en.wikipedia.org/wiki/Yerba_mate)*. I’m drinking it right now in fact.*”
  - It comes in many forms, usually loose-leaf
  - Andrew’s dad is Argentine, that’s where he picked it up
  - It heavily caffeinated
  - Don’t drink the smoked versions, those are potentially carcinogenic
- This thing about carrying the thermos close to the body, if you are ever in Uruguay or if you ever spot grown men in a restaurant anywhere in the world, carrying a thermos with them to their meals and hugging it close, chances are they’re Uruguayan and they’re drinking yerba mate
  - They drink it, usually, after their meals, it’s supposed to be good for your digestion
- Andrew suggests they talk about dreams some other time
  - Recently, he has been doing some dream exploration and he’s had some absolutely transformative dreams for the first time in his life
- One dream allowed Andrew to feel something he’s never felt before and it catalyzed a large number of important decisions in a way that no other experience has ever impacted him
  - It was drug free

**Was there a lot of work you had to do to prepare for that dream to take place?**

- Oh yes, at least 18 months of intensive analysis type work with a very skilled psychiatrist
- But Andrew wasn’t trying to seed the dream
- He was just at a sticking point with a certain process in his life
- While he was taking a walk, he realized his brain (his subconscious) was going to keep working on this
- Then two nights later, he traveled to a meeting in Aspen and had the most profound dream ever
  - He was able to sense something and feel something he’s always wanted to feel
  - It was so real within the dream
- He woke up, knew it was a dream, and realized this is what people close to him that he respects have been talking about
- He was able to feel it and therefore can access this now in his waking life
  - It was transformative

## Why Peter chose a paper on metformin, how metformin works, and why it generated excitement as a longevity-enhancing agent [9:00]

- The paper we’re going to talk about is pretty straightforward: [Reassessing the evidence of a survival advantage in Type 2 diabetes treated with metformin compared with controls without diabetes: a retrospective cohort study](https://pubmed.ncbi.nlm.nih.gov/36287641/)
  - By Matthew Thomas Keys and colleagues; published last fall
  - Also the subject of a recent [newsletter](https://peterattiamd.com/a-recent-metformin-study-casts-doubts-on-longevity-indications/)

**Why is this paper important?**

- In 2014 (almost 10 years ago), Bannister published a [paper](https://pubmed.ncbi.nlm.nih.gov/25041462/) that got the world very excited about [metformin](https://en.wikipedia.org/wiki/Metformin)
  - Many people have heard the concept of this paper
  - In many ways it’s the paper that has led to the excitement around the potential for geroprotection with Metformin
- Metformin is a drug that has been used for many years (40-50+ years) as a first-line agent for patients with [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)
  - The brand name is Glucophage, but it’s a generic drug today

**The mechanism by which Metformin works is debated hotly, but what I think is not debated is the immediate thing that Metformin does**

- Metformin inhibits complex I of the mitochondria
- To take a step back, everybody thinks of mitochondria as the cellular engine for making [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate)
- The most efficient way that we make ATP is through [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)
  - Where we take either fatty acid pieces or a breakdown product of glucose (once it’s partially metabolized to pyruvate)
  - We put that into an [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain), and we basically trade chemical energy for electrons that can then be used to make phosphates onto ADP
- Think of everything you do: eating is taking the chemical energy in food, taking the energy that’s in those bonds, making electrical energy in the mitochondria, those electrons pump a gradient that allows you to make ATP
- To give a sense of how primal and important this is, if you block that process completely, you die
  - [Cyanide](https://en.wikipedia.org/wiki/Cyanide) is something that is incredibly toxic, even at the smallest doses
  - Cyanide is a complete blocker of this process and if my memory serves me correctly, I think it blocks [complex IV of the mitochondria](https://en.wikipedia.org/wiki/Cytochrome_c_oxidase)
- Andrew knows a lot about toxins that impact the nervous system, but he doesn’t know a lot about poisons
- He adds, “*If ever you want to have some fun, we can talk about all the dangerous stuff that animals make and insects make and how they kill you.*”
  - [Tetrodotoxin](https://en.wikipedia.org/wiki/Tetrodotoxin) and all these things that block sodium channels
  - [Alpha-latrotoxin](https://en.wikipedia.org/wiki/Latrotoxin)
  - Andrew really geeks out on this stuff because it allows him to talk about neuroscience, animals, and scary stuff
- Cyanide is a very potent inhibitor of the electron transport chain, and it will kill you instantly
- Metformin works at the first of those complexes [[complex I](https://en.wikipedia.org/wiki/Respiratory_complex_I) of the electron transport chain]
  - There are four of those electron transport chain complexes (shown in the figure below)
  - Metformin does not completely inhibit complex I, it’s just a weak blocker of that

![](https://peterattiamd.com/wp-content/uploads/2023/09/f1-andrewhuberman2.png)

**Figure 1. Components of the electron transport chain**. Image credit: [ScienceFacts.net](https://www.sciencefacts.net/electron-transport-chain.html)

- The net effect of metformin blocking complex I: it changes the ratio of [adenosine monophosphate](https://en.wikipedia.org/wiki/Adenosine_monophosphate) to [adenosine diphosphate](https://en.wikipedia.org/wiki/Adenosine_diphosphate) [AMP:ADP]
- What’s less clear is, “*Why does that have a benefit in diabetics?*”
- It unambiguously reduces the amount of glucose that the liver puts out
- Hepatic glucose output is one of the fundamental problems that’s happening in type 2 diabetes
  - We talked about this in [AMA #20](https://peterattiamd.com/ama20/)
- Peter and Andrew are sitting here with normal blood sugar, about 5 g of glucose in total circulation
- Think about how quickly the brain will go through that, within minutes.
- The only thing that keeps us alive is our liver’s ability to titrate out glucose
- And if the liver puts out too much (for example, if the glucose level was consistently two teaspoons, ~10 g) you would have type 2 diabetes
- So the difference between being metabolically healthy and having profound type 2 diabetes is one teaspoon of glucose in your bloodstream

***The ability of the liver to tamp down on high glucose output is important, and metformin seems to do that***

Andrew asks, “*Is it fair to provide this overly simplified summary of the biochemistry, which is that when we eat, the food is broken down, but the breaking of bonds creates energy that then our cells can use in the form of ATP, and the mitochondria are central to that process, and that metformin is partially short-circuiting the energy production process. And so even though we are eating, when we have metformin in our system, presumably there is going to be less net glucose.*”

- “Sort of”, replies Peter
- It’s not depriving you of ultimately storing that energy
- What it’s doing is changing the way the body partitions fuel
- It’s not depriving you of the calories that are in glucose, that was [Olestra](https://en.wikipedia.org/wiki/Olestra)
  - Remember Olestra from the ‘90s?
  - It was a fat that was not easily digested, sort of analogous to plant fiber
  - It was being put into potato chips, and the idea was that people would simply excrete it
    - People got a lot of stomach aches and anal seepage
    - When you have that much fat malabsorption, you start to have accidents ant that did away with that product

## Defining insulin resistance and its underlying causes [16:15]

- Metformin is considered a perfect first-line agent for people with type 2 diabetes
- With type 2 diabetes, the primary insult probably occurs in the muscles and it is [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance)
- [Insulin](https://en.wikipedia.org/wiki/Insulin) is a peptide; it binds to a receptor on a cell
- Let’s just talk about it through the lens of the **muscle** because the muscle is responsible for most glucose disposal, it gets glucose out of the circulation
- High glucose is toxic, we have to put it away and we want to put most of it into our muscles, that’s where we store 75% to 80% of it

**Insulin signaling is needed to allow glucose to enter the cell**

- When insulin binds to the [insulin receptor](https://en.wikipedia.org/wiki/Insulin_receptor) now glucose can freely flow in
  - The insulin receptor will trigger tyrosine kinase inside the cell (just ignore all that), but a chemical reaction takes place inside the cell that leads to a phosphorylation
    - So ATP donates a phosphate group
  - And a transporter (just think of like a little tunnel, like a little straw) goes up through the level of the cell, and now glucose can freely flow in
- Things that move against gradients need pumps to move them
  - Things that move with gradients don’t
- Glucose is moving with its gradient into the cell
  - It doesn’t need active transport, but it does need the transporter
    - There is so much more glucose outside the cell than inside
  - Getting the transporter (the straw) to the cell surface requires energy, and that’s the job of insulin
- Andrew didn’t know this
  - He knows [active](https://en.wikipedia.org/wiki/Active_transport) and [passive transport](https://en.wikipedia.org/wiki/Passive_transport) as it relates to neurotransmitter and ion flow, but he had never heard that when insulin binds to a cell that literally a little straw is placed into the membrane of the cell
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) at Yale did the best work elucidating this
  - Discussed in [episode #140](https://peterattiamd.com/geraldshulman/)
- As the intramuscular fat increases, that signal gets interrupted
  - And by intramuscular Peter means intracellular fat, [triacyl](https://en.wikipedia.org/wiki/Triglyceride) and diacylglycerides accumulate in a muscle cell
- And all of a sudden (Peter makes these numbers up to illustrate what happens) if you used to need two units of insulin to trigger the little transporter, now you need three and then you need four, and then you need five

**The definition of insulin resistance:** you need more and more insulin to get the glucose transporter to the cell surface

***The early mark of insulin resistance (the canary in the coal mine) is not an increase in glucose, it’s an increase in insulin***

- This is normal glycemia with hyperinsulinemia
  - Especially postprandial, meaning after you eat
- Hyperinsulinemia, is the thing that tells you, “*Hey, you’re 5-10 years away from this being a real problem.*”

**Type 2 diabetes**

- Fast-forward many steps down the line, someone with type 2 diabetes has long passed that system [of hyperinsulinemia with normal glucose levels]
- Now, not only are they insulin resistant, where they just need a boatload of insulin to get glucose out of the circulation
  - Insulin is made by the pancreas
  - But now that system’s not even working well and now they’re not getting glucose into the cell
  - So now their glucose level is elevated
    - Even though it’s continually being chewed up and used up, because the brain alone would account for most of that glucose disposal
  - The liver is now becoming insulin resistant as well, and now the liver isn’t able to regulate how much glucose to put into circulation and it’s overdoing it

***So now you have too much glucose being pumped into the circulation by the liver and you have the muscles that can’t dispose of it***

- It’s a vicious, brutal cascade because the same problem of fat accumulating in the muscle is now starting to happen in the pancreas
- And now, the relatively few cells in the pancreas that make insulin (called [beta cells](https://en.wikipedia.org/wiki/Beta_cell)), are undergoing inflammation due to the fat accumulation within the pancreas itself
  - So now the thing that you need to make more insulin is less effective at making insulin
- Ultimately, way, way, way down the line, a person with type 2 diabetes might actually even require insulin exogenously

**Could you share with us a few of the causes of type two diabetes? Of insulin resistance?**

- Andrew adds, “*It sounds like one is accumulating too much fat.*”
- 1 – Energy imbalance would be an enormous one
- 2 – Inactivity or insufficient activity is probably the single most important
- When Gerald Schulman was running clinical trials at Yale, they would recruit undergrads to study and do these very detailed mechanistic studies where they would require tissue biopsies
  - Biopsy somebody’s quadriceps and look at what’s happening in the muscle
- Peter remembers him telling him about this when he interviewed him on the [podcast](https://peterattiamd.com/geraldshulman/)
  - Schulman said, “*The most important criteria of the people we interviewed was that they had to be inactive*.”
  - These people were still lean
  - He couldn’t have active people in these studies

> “*Exercising is one of the most important things you’re going to do to ward off insulin resistance.*”‒ Peter Attia

- 3 – Sleep deprivation has a profound impact on insulin resistance
  - There are some very elegant mechanistic [studies](https://pubmed.ncbi.nlm.nih.gov/10543671/) where you only let people sleep for 4 hours a week and you’ll rescue their glucose disposal by about half
  - Discussed in [episode #49](https://peterattiamd.com/matthewwalker3/)
  - ***You’re basically inducing profound insulin resistance in just a week of sleep deprivation***
- Hypercortisolemia is another factor
- Energy imbalance is an obvious factor
  - So when you’re accumulating excess energy, when you’re getting fatter, if you start spilling that fat outside of the subcutaneous fat cells into the muscle, into the liver, into the pancreas
- All of those things are exacerbating it

## Metformin as a first-line treatment for type 2 diabetes, and Peter’s evolving interest in metformin as a geroprotective drug [22:00]

- Every drug you give a person with type 2 diabetes is trying to address part of this chain
- Some of the drugs tell you to make more insulin, that’s one of the strategy
  - For example drugs like [sulfonylureas](https://en.wikipedia.org/wiki/Sulfonylurea)
- Other drugs, like insulin, just give you more of the insulin
- Metformin tackles the problem elsewhere ‒ it tamps down glucose by addressing the hepatic glucose output channel
- [GLP-1 agonists](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist) are another drug, it increases insulin sensitivity, initially causing you to also make more insulin
  - [Ozempic](https://en.wikipedia.org/wiki/Semaglutide) is the brand name of one of these drugs

*Is it true that* [*berberine*](https://en.wikipedia.org/wiki/Berberine) *is more or less the poor man’s metformin?*

- Yes
- It’s from tree bark and just happens to have the same properties of metformin of reducing [mTOR](https://en.wikipedia.org/wiki/MTOR) and reducing blood glucose
- Metformin was discovered in a lilac plant in France
- You need a prescription for metformin, but you don’t need a prescription for berberine
- Andrew had a couple great experiences with berberine and a couple of bad experiences too (we’ll talk more about it later)

**Peter’s personal experience with metformin [23:15]**

- In 2011, Peter became very interested in metformin personally, and after reading about it, obsessing over it, he decided to take it
- He remembers exactly when he started taking it in May of 2011
  - He was on a trip with a bunch of buddies
  - They went to the Berkshire Hathaway shareholder meeting, which is the Buffett shareholder meeting (it was kind of like a fun thing to do)
  - He remembers being so sick the whole time because he didn’t titrate up the dose of metformin
    - He went straight to 2 g a day, which is kind of like the full dose
- Andrew asks, “*Is that characteristic of your approach to things?*”
  - Yes
- Peter remembers they went to Dairy Queen, but he couldn’t have ice cream because he was so nauseous
  - He couldn’t keep anything down
- Andrew thinks, “*If you’ve got metformin in your system, you’re going to buffer glucose. You could have four ice cream cones and probably feel fine.*”
- So clearly metformin has this side effect initially, which is a little bit of appetite suppression

**There were a lot of reasons Peter was interested in metformin at the time**

- He wasn’t thinking true geroprotection (that term wasn’t in his vernacular at the time)
- He thought it would help him **buffer glucose** better
- This was his first foray into self experimentation

## Defining the term “geroprotection” [24:45]

- Gero from geriatric meaning old
- Protection meaning to protect from aging
- When we talk about a drug like [metformin](https://en.wikipedia.org/wiki/Metformin) or [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) or even [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) or [NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside), the idea is we’re talking about them as geroprotective to signal that they are drugs that are not targeting a specific disease of aging
  - [AMA #35](https://peterattiamd.com/ama35/) discusses these drugs in more detail
  - [AMA #45](https://peterattiamd.com/ama45/) discusses metformin as a geroprotective drug, starting at [1:11:30]
- For example, a [PCSK9 inhibitor](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target) is sort of geroprotective, but it’s targeting one specific pathway, which is cardiovascular disease and dyslipidemia.

***Whereas the idea is a geroprotective agent would target hallmarks of aging***

- There are **9 hallmarks of aging** (but Peter’s never been able to get them all straight):
  - Decreased autophagy and proteomic instability [and loss of [proteostasis](https://www.sciencedirect.com/topics/medicine-and-dentistry/protein-homeostasis)]
  - Increased senescence
  - Decreased nutrient sensing or defective nutrient sensing
  - Genomic instability
  - Methylation and epigenetic changes
  - Mitochondrial dysfunction
  - Telomere attrition
  - Stem cell exhaustion
  - Altered intracellular communications
  - Discussed in [AMA #45](https://peterattiamd.com/ama45/) [after 1:11:30]
- So a geroprotective agent would target those deep down biological hallmarks of aging

## The 2014 study that got the anti-aging community interested in metformin [26:00]

**The 2014** [**paper**](https://pubmed.ncbi.nlm.nih.gov/25041462/) **by Bannister**

- What Bannister and colleagues did was they took a registry from the UK and they got a set of patients who were only on metformin, with type 2 diabetes
  - These were people who had just progressed to diabetes
  - They were not put on any other drug, just metformin
- And then they found, from the same registry, a group of matched controls
  - This is a standard way that epidemiologic studies are done because you don’t have the luxury of doing the randomization
  - So you’re trying to **account for all the biases** that could exist by saying, “*We’re going to take people who look just like that person with diabetes. So can we match them for age, sex, socioeconomic status, blood pressure, BMI, everything we can? And then let’s look at what happened to them over time.*”
- Now again, this is all happening in the future, so you’re looking into the past
  - It’s retrospective in that sense
- The table of what Bannister did is important background (shown below)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f2-andrewhuberman2.png)

**Figure 2.** Image credit: [*Diabetes, Obesity & Metabolism* 2014](https://pubmed.ncbi.nlm.nih.gov/25041462/)

- They did something that Peter didn’t notice at the time (or maybe he did and he forgot), but he noticed it five years ago when he went back and looked at this paper
  - They did something called *informative censoring*
- The way the study worked is if you were put on metformin, they were going to follow you
  - If you’re not on metformin, they were going to follow you
  - They were going to track the number of deaths from any cause that occurred
    - This is called **all-cause mortality (or ACM)**, and it’s really the gold standard in a study of this nature or even a clinical trial
    - You want to know how many people are dying from anything because we’re trying to prevent or delay death of all causes
- **Informative censoring** says, “*If a person who’s on metformin deviates from that inclusion criteria, we will not count them in the final assessment.*”
  - What are the ways that can happen?
    - 1 – The person can be lost to follow-up
    - 2 – They can stop taking their metformin
    - 3 – More commonly, that can progress to needing a more significant drug
  - So all of these patients were excluded from the study
- In Peter’s opinion, “*This is a* ***significant limitation of this study*** *because what you’re basically doing is saying, ‘We’re only going to consider the patients who were on metformin, stayed on metformin and never progressed through it. And we’re going to compare those to people who were not having type 2 diabetes.’*”
  - An **analogy** here would be, imagine we’re going to do a study of two groups that we think are almost identical
    - One of them are smokers and the other are identical in every way, but they’re not smokers
    - And we’re going to follow them to see which ones get lung cancer
    - But every time somebody dies in the smoking group, we stop counting them
    - When you get to the end, you’re going to have a less significant view of the health status of that group

***With that caveat, the Bannister study found a very interesting result: the crude death rate in the group of people with type 2 diabetes who were on metformin was 14.4 deaths per 1000 patients (including the censoring) [see the previous figure]***

- One of the challenges of epidemiology is the match gets complicated
  - You have to normalize death rate for the amount of time you study the people
  - So everything is normalized to 1000 person years
- The control group had 15.2 deaths per 1000 patients
  - This was a startling result
- This difference of a year and a half doesn’t seem that striking to Andrew (he later remarks that his math was wrong about the year and a half)
  - Of course, a difference of a year and a half in lifespan is remarkable
- Peter explains that type 2 diabetes will shorten your life by six years (on average)
- Bannister’s result is the actuarial difference between having type 2 diabetes and not, but you’re right, this is not a huge difference
  - It’s only a difference of a little less than 1 year of life per 1000 patient years studied

***The point here is you would expect the people in the metformin group to have a far worse outcome (worse crude death rate), and the fact that it was statistically significant in the other direction***

- It turned, out on what’s called a [Cox proportional hazard](https://en.wikipedia.org/wiki/Proportional_hazards_model) (which is where you actually model the difference in lifespan), ***the people who took metformin and had diabetes had a 15% relative reduction in all cause death over 2.8 years*** (which was the median duration of follow-up, compared to the non-diabetics)
  - That’s a big deal
  - And there’s no clear explanation for it unless you believe that metformin is doing something beyond helping you lower blood glucose
- The difference in blood glucose between people in these two groups was still in favor of the non-diabetics
- At the time Peter believed this was a very good suggestion that metformin was doing other things
  - He was in the camp of metformin being a geroprotective agent (today he is undecided about this)

**What other things could metformin be doing?**

- Other than lowering blood glucose
- Metformin is a weak inhibitor of mTOR
- Metformin reduces inflammation
- Metformin potentially tamps down on senescent cells and their secretory products
- There are lots of things metformin could be doing that are off target, and it might be that those things are conferring the advantage
- Fast-forward until a year ago, and Peter thinks most people took the Bannister study as the best evidence we have for the benefits of metformin
- Peter is asked as much as he is asked any question, “*Should I be on metformin?*”

## Peter presents the 2022 paper that repeats the analytical approach from the 2014 Bannister study  [33:15]

**Insulin causes the glucose transporter to move to the cell surface**

- Andrew appreciates the background and is still dazzled by how insulin triggers insertion of the straw
  - Peter explains the straw is just a little transporter [for glucose]
  - Andrew is fascinated by how quickly, efficiently, and specifically biology can create these little protein complexes that do something really important
    - An on-demand creation of a portal
  - “*These are cells engineering their own machinery in real time in response to chemical signals.*”
- Peter asks if action potential works the same way but in reverse
  - You need the ATP gradient to restore the gradient, but one the action potential fires, it’s passive outside
- Andrew explains, “*What Peter is referring to is the way that neurons become electrically active is by the flow of ions from the outside of the cell to the inside of the cell. And we have both active conductances (meaning they’re triggered by changes in the gradients via changes in electrical potential) and then there are passive gradients (where things can just flow back and forth until there’s a balance equal inside and outside the cell).*”
- What’s different is that there’s some movement of a lot of stuff inside of neurons when neurotransmitters like dopamine bind to its receptor
  - It’s like a bucket brigade that gets kicked off internally
  - But it’s not often that you hear about receptors getting inserted into cells very quickly
    - Normally you  have to go through a process of transcribing genes and making sure that specific proteins are made which are slow things that take place over the course of many hours or days

***What’s amazing is this glucose transporter moves to the cell surface in minutes***

**The 2022 study by Keys and Colleagues redid the entire Bannister analysis**

- Interest in this topic is through the roof, and this is likely the motivation for their study
- There is a clinical trial called the [TAME Trial (Targeting Aging with Metformin)](https://peterattiamd.com/tame-metformin-anti-aging-trial-nir-barzilai/) getting underway soon
  - [Nir Barzilai](https://www.einsteinmed.edu/faculty/experts/484/nir-barzilai/) is probably the senior PI on that
  - The Bannister study (along with some other studies of lesser significance) was motivation for the TAME trial
- The [Keys study](https://pubmed.ncbi.nlm.nih.gov/36287641/) used a different cohort of people
  - The [Bannister study](https://pubmed.ncbi.nlm.nih.gov/25041462/) used roughly 95,000 subjects from a UK biobank [90,000 with type 2 diabetes and 90,00 matched subjects without diabetes]
  - Here they used a larger sample, about half a million people sampled from a Danish health registry
  - And the Keys study did something elegant: they created two groups to study
    - 1 – A standard replication of what Banister did (people with diabetes matched to those without)
    - 2 – Discordant twins (same sex twins where one had diabetes and one didn’t)
- The **use of twins** was elegant because you have a degree of genetic similarity and you have similar environmental factors during childhood that might allow you to see if there’s any sort of difference in signal

**So now turning this back into a little bit of a journal club: virtually any clinical paper you’re going to read, table one (below) is the characteristics of the people in the study**

![](https://peterattiamd.com/wp-content/uploads/2023/09/f3-andrewhuberman2.png)

**Figure 3. Baseline characteristics of matched cohorts of metformin initiators and those without diabetes**. Image credit: [*International Journal of Epidemiology* 2022](https://pubmed.ncbi.nlm.nih.gov/36287641/)

- You always want to look at **table one**: the baseline characteristics of the subjects in the study
- Usually the **first figure** in a paper shows the study design
  - It’s usually a flow chart that says: these are the inclusion criteria, these are all the people that got excluded, this is how we randomized, etc.
- You can see in the table above there are four columns
  - The first two are singletons ‒ these are people who are not related
  - The second two are twins who are matched
  - You can see the numbers
- Remember Peter said they sampled about 500,000 people
  - [The results section states, “*Our source populations comprised 445,662 singletons from a 5% random sample of the Danish population alive in or born since 1968 and all 151,091 individual twins recorded in the population-based DTR*.”]
- In the table above you can see who they studied and their characteristics:
  - 7,842 singletons on metformin and the same number, they pulled out matched without diabetes
  - 976 twins on metformin with diabetes, and then by definition, 976 co-twins without diabetes
    - What was their age upon entry?
    - How many were men?
    - What was the year of indexing when we got them?
    - What medications were they on?
    - What was their highest level of education, marital status, etc.?
- Peter calls out one thing that cannot really be matched in a study like this that is a very **important limitation**: medication

***Notice how pretty much everything else is perfectly matched until you get to the medication list (it’s all over the place; they’re nowhere near matched)***

- For example, if you look at the singletons and the fraction of people with type 2 diabetes that are on lipid lowering medication: it’s 45.6% versus 15.4% in the matched controls without diabetes
  - That’s a 3x difference
- For antiplatelet therapy: it’s 30% versus 14%
- Antihypertensive therapy: 63% versus 31%

***People who have one health issue and are taking metformin are likely to have other health issues***

- Peter notes, “*Again, a fundamental flaw of epidemiology. You can never remove all the confounders.*”
- Andrew replies, “*This is why I became an experimental scientist so that we could control variables.*”
- Without random assignment, you cannot control every variable
- You’ll see in a moment when we get into the analysis, they go through three levels of corrections, but they can never correct this medication one

## Greater mortality in the metformin group: how results differed between the 2022 paper by Keys and the 2014 Banner paper [40:00]

The two big things that were done in this experiment or in this survey or study to differentiate it from Banister was:

- 1 – Looking at twins
- 2 – They did a sensitivity analysis with and without informative censoring
  - One of the other things they wanted to know was: *Does it really matter if we don’t count the metformin patients who progress?*

**The table (below) walks you through the crude mortality rate in each of the groups:**

![](https://peterattiamd.com/wp-content/uploads/2023/09/f4-andrewhuberman2.png)

**Figure 4**. Image credit: [*International Journal of Epidemiology* 2022](https://pubmed.ncbi.nlm.nih.gov/36287641/)

- Peter points out the most important row in Table 2: crude per 1000 person-years (mortality) [highlighted above]
  - Recall previously in the Bannister study, those were in the ballpark of about 15
  - Here in the singletons who were nondiabetic, it was 16.86

***Explaining what is meant by “1000 person years”***

- Andrew explains, it’s normalizing to who is going to live a thousand years, but because no one is expecting that, you’re pooling people until you hit 1000
  - So some people are going to live to 76 years, 52 years, 91 years
  - It becomes like a normalized division
  - You’re asking: if there were 1000 person years available to live, how likely is it that this person would live another 15?
- Peter explains we always need some way of normalizing
  - For example, when we talk about the mortality from a disease like cancer, we report mortality per 100,000 persons (this is a mortality rate)
    - The reason we can do it that way is we’re looking at how many people died in a calendar year, and we divide it by the number of people in that age group
- Tangent: that’s why we can say the highest mortality [rate] is in people age 90+; even though the absolute number of deaths is small, there’s not many people in that age group
  - The majority of deaths in absolute terms probably occurs in the seventh decade
  - But as you go up, because the denominator is shrinking [# people in an age group], you have to normalize it
    - So we just normalize it to the number of people
- In this study it is done in a slightly more complicated way because we don’t follow these people for their whole lives
  - We’re only following them for a period of observation (roughly three years)

***So to say something like, “We have a crude death rate of 5 deaths per 1000 person years,” one way to think about that is if you had 1000 people and you followed them for 1 year, you’d expect 5 to die***

- If you had 500 people and you followed them for 2 years, you expect 5 to die
- If you have 1000 people and you follow them for 1 year, you expect 5 to die
- Those would all be considered equivalent mortalities

Peter finds that when you get into the weeds of epidemiology, its way more complicated than following the basics of experimental stuff where you push it all into one bin and say: we’re going to take this number of people, exclude this group, randomize, and see what happens

- Andrew remarks, “*That’s like the paper we’ll talk about next.*”

They don’t show it in this paper (it’s only in the text), but when you adjust for age, the crude death rate of the people on metformin who are singletons versus twins are almost identical

- This is a very important thing to check
- In the table they look different because it’s 24.93 for the [singleton] metformin group and 21.68 for the twin group that’s on metformin
  - When you adjust for age it goes from 24.93 to 24.7
- The other thing to notice in table 2 are the parenthesis offering the 95% [confidence interval (CI)](https://en.wikipedia.org/wiki/Confidence_interval)
  - For example, take the number, 24.93 the crude death rate of how many people are dying who take metformin, what it’s telling you is we’re 95% confident that the actual number is between 23.23-26.64
  - If a **95% confidence interval** does not cross the number zero, it’s statistically significant

**Things that jump out from this paper**

*First, there’s clearly a difference between the people who have diabetes and the people who don’t*

- This study is a little complicated because it’s basically two studies in one
- For the singletons you’re comparing 24.93 to 16.86
- This difference remains after age adjustment
  - The twin group is 24.73 compared to 12.94
- Andrew asks, “*So 16.86 people die, and some people probably think how can 0.86 of a person die?*”
  - Peter says, “*Yeah, just call it 17 versus 25*.”
  - 17 deaths per 1000 versus 25 deaths, and the 25 are the folks that took metformin
  - To the naive listener that means that metformin kills you faster or you’re more likely to die
    - But you have to remember that these people have a major health issue that the other group does not have

**The Kaplan-Meier curve is a mortality curve**

- [Kaplan-Meier curves](https://en.wikipedia.org/wiki/Kaplan%E2%80%93Meier_estimator) show up in all sorts of studies ‒ any study that is looking at death
  - This can be prospective randomized, this can be retrospective

![](https://peterattiamd.com/wp-content/uploads/2023/09/f5-andrewhuberman2.png)

**Figure 5.** Image credit: [*International Journal of Epidemiology* 2022](https://pubmed.ncbi.nlm.nih.gov/36287641/)

- This is a cumulative mortality curve
  - When the X-axis is always time, on the Y-axis is always cumulative survival
  - It’s a curve that always goes from zero to one (or 100%), and it’s always decreasing monotonically, meaning it can only go down or stay flat; it can never go back up
- Andrew summarizes, “*You’re starting at alive and you’re looking at how many people die for every year that passes.*”
- In figure 5 (shown above) the panel on the left is matched singletons and on the right are the discordant twins
  - You have two lines: those that were on metformin with type 2 diabetes and their matched controls
    - The matched controls are the darker lines
    - The people with type 2 diabetes on metformin are the lighter line
  - You’ll also notice they’ve got shading around each line (Peter likes the way they’ve done that)
    - The shading is just showing you a 95% confidence interval
- Andrew adds that in both of these graphs, the downward trending line from the control (the non-diabetic not taking metformin) is *above* the line corresponding to the diabetics who are taking metformin
  - Put crudely, the people who are taking metformin that have diabetes are dying at a faster rate for every single year examined
  - And the two lines do not overlap, except at the beginning when everyone’s alive
  - Analogy: it’s like a foot race where basically the people with metformin and diabetes are falling behind and dying as they fall
- Peter points out about Kaplan-Meier curves: it’s not uncommon in treatments to see these lines cross
  - They don’t have to
  - It’s not a requirement that they never cross
  - It’s only a requirement that they’re monotonically decreasing or staying flat
- Peter has seen cancer treatment drugs where they have two drugs going head-to-head in a cancer treatment and one starts out looking really, really bad, but then all of a sudden it kind of flattens while the other one goes bad, and then it actually crosses and goes underneath
  - But that’s not the case here

***The people with diabetes taking metformin in both the match singletons and the discordant twins are dropping much faster and they always stay below***

- The shading on the lines shows the 95% confidence interval
  - It’s basically putting [error bars](https://en.wikipedia.org/wiki/Error_bar) along this
  - For those unfamiliar with statistics, an analogy to understand error bars:
    - If you were going to measure the heights of a room full of 10th graders, there’s going to be a range
    - You’ll have the very tall kid and the very shorter kid, and you’ll have the short kid and the medium kid
    - There’s going to be an average (a mean), and then there’ll be standard deviations and standard errors
- These confidence intervals give a sense of how much range
  - Some people die early, some people die late within a given year, they’re going to be different ages
  - So these error bars can account for a lot of different forms of variability
  - Here you’re talking about the variability in how many people die in each group
- It’s also a mathematical model that’s smoothing it out because it’s running for the full 8 years even though they’re only following people for a median of 3-4 years
  - They’re using a complicated [Cox proportional hazard](https://en.wikipedia.org/wiki/Proportional_hazards_model), which generates hazard ratios
  - Any model has some error in it

***When you look at figure 5 above, we don’t know exactly where the line is, but we know it’s in that shaded area***

- **If those shaded areas overlapped**, you couldn’t really know for sure that one is different from the other

## Understanding statistical significance, statistical power, sample size, and why epidemiology uses enormous cohorts [51:45]

**A common myth**

- When a lot of people look at a graph and see these error bars, they will think that if the error bars overlap, it’s not a significant difference, but if the error bars don’t overlap (meaning there’s enough separation), then that’s a real and meaningful difference
  - That’s not always the case
  - It depends a lot on the form of the experiment
  - Andrew often sees some of the more robust Twitter battles over how people are reading graphs
- It’s important to remember that you run the statistics (hopefully the correct statistics) for the sample, but determining significance your confidence in that increases as the p-value decreases

***The gold standard for significance are p-values less than 0.05***

- [Significance](https://en.wikipedia.org/wiki/Statistical_significance) means whether or not the result could be due to something other than chance
- But when you’re talking about data like these, which are repeated measures over time, people are dropping out literally over time, you’re saying they’ve modeled it to make predictions as to what would happen
  - ***We’re not necessarily looking at raw data points here***
  - The raw data was in the previous table, now that has been run through this Cox model and smoothed out
- The other thing you always want to understand is just because something doesn’t achieve statistical significance, the only way you can say it’s not significant is you have to know what it was [powered](https://en.wikipedia.org/wiki/Power_of_a_test) to detect
- **Statistical power** is a very important concept that probably doesn’t get discussed enough
  - Before you do an experiment, you have to have an expectation of what you believe the difference is between the groups, and ***you have to determine the number of samples you will need to assess whether or not that difference is there or not***
- You have to use something called a [power table](https://peterattiamd.com/studying-studies-part-v-power-and-significance/)
  - If you’re comparing treatment A to treatment B and you think A will have a 50% response and B will have a 65% response, you go to the power table and look for a 15% difference; you want to be 90% sure, and it tells you how many people (or animals) you would need in this study
  - You’re going to need 147 in each group, and if you fail to find significance, you can comfortably say there is no statistical difference at least up to that 15%
  - There may be a difference at 10%, but you weren’t powered to look at 10%
- Another more more generally about statistics: ***the way to reduce variability in a data set is to increase sample size***
  - For example, if you walked into a 10th grade class to measure height and the first three kids you happen to see all play on the volleyball team together, the sample size is small and is likely a skewed representation (taller than average)
- When you hear about a study from the UK Biobank or from half a million Danish citizens, those are enormous sample sizes
  - So even though this is not an experimental study (it’s an epidemiological observational study), there’s tremendous power by way of the enormous number of subjects in the study

***Using an enormous number of subjects is the way that epidemiology will make up for its deficit (it can never compensate for inherent biases)***

- You could never do a randomized assignment study on half a million people
- Epidemiology could survey people over the course of their lives and have the biggest sample size possible because this is relatively cheap
- The cost of doing an experiment where you have tens of thousands of people is prohibitive
  - For example, the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) was a billion dollar study

> “*This is the balancing act between epidemiology and randomized prospective experiments… They both offer something, but you just have to know the blind spots of each one*.”‒ Peter Attia

## Interpreting the hazard ratios from the 2022 metformin study, and the notable takeaways from the study [56:45]

**The table below is the most important table in here**

- This lays out the final results in terms of the [hazard ratio (HR)](https://en.wikipedia.org/wiki/Hazard_ratio) (shown below)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f6-andrewhuberman2.png)

**Figure 6.** Image credit: [*International Journal of Epidemiology* 2022](https://pubmed.ncbi.nlm.nih.gov/36287641/)

**Hazard ratios are important to understand**

- If a hazard ratio is greater than 1, you subtract and that tells you the **relative harm**
  - For example, if the hazard ratio is 1.5, there is a 50% *increase* in risk
- Recall on the Bannister paper, the hazard ratio was 0.85
  - That means it’s a 15% risk *reduction* in relative risk

***You can see in table 4 that all the hazard ratios are positive***

- There’s a lot of information packed here: singletons, twins, different ways of comparing (unadjusted, etc.)
- If you look at the singletons with and without metformin and make no adjustments, the hazard ratio is 1.48
  - This means that people on metformin had a 48% greater chance of dying in any given year than their non-diabetic counterpart
- Andrew points out that we don’t have a group that’s taking metformin who doesn’t have diabetes, and we don’t have a group who had diabetes and is taking metformin plus something else
  - We’re only dealing with these constrained populations
- There is another arm of the study that Peter is not getting into because this adds more complexity
  - They have another group that’s got diabetes and takes metformin and sulfonylureas, and those people die even more

***This again speaks to the point, the more you need the medications, they’re never able to erase the effect of diabetes***

- Andrew wonders if these drugs might be possible accelerating death due to diabetes
  - We could never know that from this because we would need to see diabetics who don’t take metformin (who take nothing), and Peter would bet that they would do even worse

***Peter’s intuition is that metformin is helping but not nearly as much as we thought before***

**This study makes another set of adjustments**

- In the **unadjusted model**, they only matched for age and gender (that’s pretty crude)
- In the **partially adjusted model**, they adjust for medications (cardiovascular, psychiatric, pulmonary, dementia meds) and marital status
  - The hazard ratio drops from 1.48 to 1.32
  - You still have a 32% greater chance of dying in any given year
- What if we adjust for the highest level of education along with any of the other covariants?
  - It ends up at 1.33 or a 33% chance increase in death
    - No real change from the prior adjustment
- Looking at the **twins**, you could argue is a slightly purer study because you at least have one genetic and environmental thing that you’ve attached
  - The unadjusted model is brutal, a hazard ratio of 2.15, that’s 115% greater chance of dying than the non-diabetic co-twin
  - Think about this: these are twins who in theory are the same in every way except one has diabetes and one doesn’t
  - When you make the first adjustment of all the meds and marital status, you bring it down to a 70% increase in risk
  - When you throw in education, it goes up to 80%

**They did the analysis with and without censoring (which Peter thinks is really cool)**

- Censoring is when you stop counting the metformin people who have died
- In the singleton group, when you un-adjust it, there is a 48% chance of increased all-cause mortality if you don’t censor
  - If you censor them, it comes down to 1.39

***This is a very important finding, it did not undo the benefits we saw in the Bannister study (a 15% reduction in mortality when censored); when Keys sensored, it got better (but not that much), it went from 48% to 39%***

- In the twins, it went from 115% down to only 97%
- In some ways, this presents an enigma because it’s not entirely clear why Bannister found such a different response

**Another technical detail of the Keys paper, they did something called a nested case-control**

- [Nested case-controls](https://en.wikipedia.org/wiki/Nested_case%E2%80%93control_study) are another elegant way to do case-control studies
  - You sample by year and sort of normalize
  - You don’t count all the cases at the end, you count them one by one
- It’s not worth getting into because it doesn’t change the answer

***The point here is the Keys paper makes it undeniably clear that in that population, there was no advantage offered by metformin that undid the disadvantage of having type 2 diabetes***

- This does not mean that metformin wasn’t helping them because we don’t know what these people would’ve been like without metformin
  - It could be that this bought them a 50% reduction in relative mortality to where they’d been
- But what it says is, in a way, this is what you would’ve expected 10 years ago before the Banister paper came out
- It’s saying what is the likelihood that sick people who are on a lot of medication are going to die compared to not sick people who aren’t on a lot of medication
  - It’s not quite that simple
  - There are ways to try and isolate the contribution of metformin because they’re on a bunch of other meds (done in other figures)
  - They can  never attach the results specifically to metformin
  - With the partial adjustment, they’re going drug by drug all the way through (yes/ no for each drug) and then comparing those groups
    - No differences jumped out that can be purely explained by these other variables

> “*This is a great opportunity to talk about why no matter how slick you are, no matter how slick your model is, you can’t control for everything.*”‒ Peter Attia

- There’s a reason that virtually every study that compares meat eaters to non-meat eaters finds an advantage amongst the non-meat eaters
  - Be it lifespan or disease incidence
  - It might be tempting to say eating meat is bad until you realize that it takes a lot of work to not eat meat
    - That’s a very significant decision
  - And that person probably has a very high conviction about the benefit of that to their health, and it is probably the case that they are making other changes with respect to their health that are a little more difficult to measure
  - There’s a million other problems Peter picked up with that, but this is just a silly example

***The point is it’s very difficult to quantify some of the intangible differences, and even a study that goes to great lengths (as this one does epidemiologically) to make these corrections, one can never make the corrections***

**Peter’s takeaway‒** “*This makes much more sense to me than the Bannister paper, which never really made sense to me*.”

- Peter was first critical of the Bannister paper in 2018, about four years after it came out
  - That’s about the time he stopped taking metformin, though he stopped taking it for a different reason (we’ll come back to this)
  - He thought the censoring was a little fishy
  - He thought they weren’t looking at a trug group of real type 2 diabetics
- Even the Keys paper doesn’t tell us that metformin wouldn’t be beneficial, because it could be that those people, if they were on nothing (as their matched cohorts were on nothing), they would’ve been dying at a hazard ratio of 3, and this brought it down to 1.5, in which case you would say, there is some geroprotection putting the brakes on this process
- Absent a randomized control trial, we will never know the answer
  - There has not been a randomized control trial on metformin when it comes to a hard outcome
- There has been in the [Interventions Testing Program (ITP)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp), which is a kind of gold standard for animal studies
  - It’s a NIH funded program that’s run out of three labs
  - The ITP was the first study that really put rapamycin on the map in 2009 ‒  it demonstrated that even when rapamycin was given very, very late in life (60 month old mice), it still afforded them 15% lifespan extension (hard to do this in humans)
- When the ITP studied metformin, it did not succeed

## Drugs that may extend lifespan, why Peter stopped taking metformin, and a discussion of caloric restriction [1:08:45]

**The Interventions Testing Program (ITP)**

- There have not been many drugs that have worked in the [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp); the ITP is very rigorous
  - They don’t use an inbred strain of mice
  - It is done concurrently in three labs with very large sample sizing
- When something works in the ITP it’s pretty exciting
  - [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus) has been studied several times and it’s always worked
  - Another one we should talk about some other time is [17-alpha-estradiol](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol)
    - It works in male mice and produces comparable effects to rapamycin
    - It doesn’t make it in female mice, but this is alpha and not beta
    - 17-alpha-estradiol is not the [beta-estradiol](https://en.wikipedia.org/wiki/Estradiol), which is the estradiol that is bioavailable in all of us
- Andrew notes the importance of estrogen for libido, brain function, tissue health
  - And Peter adds bone health and body composition
- This idea of crushing estrogen and raising testosterone is silly (leave raising testosterone out of it), but many pharmacologic approaches to raising testosterone also raise estrogen
  - Unless people are getting hyperestrogenic effects like [gynecomastia](https://en.wikipedia.org/wiki/Gynecomastia) or other tissues, pushing down on estrogen is the exact wrong direction to go
- [Canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin), an [SGLT-2 inhibitor](https://en.wikipedia.org/wiki/SGLT2_inhibitor), is also very successful in the ITP

**Peter stopped taking metformin 5 years ago**

- The initial nausea went away after a few week or maybe a month
- Once Peter got really into lactate testing, he noticed how high is lactate was at rest
- In a healthy person, a resting fasted lactate should be below 1.0 (somewhere between 0.3-0.6 mmol), and only when you start to exercise should lactate go up
- In 2018 when Peter started blood testing lactate for zone 2 training, his finger prick before he started exercising showed a blood lactate around 1.6 mmol
  - What you might expect after you ran up a flight of stairs
- This caused Peter to start doing a little digging and he realized if you have a weak mitochondrial toxin, you’re going to shunt more glucose into pyruvate and more pyruvate into lactate
  - He was anaerobic
- Andrews asks, “*Could you feel it?*”

**Andrew took** [**berberine**](https://en.wikipedia.org/wiki/Berberine) **during a period somewhere between 2012-2015**

- He’s a big fan of the [Tim Ferris](https://tim.blog/about/) [slow carbohydrate diet](https://tim.blog/wp-content/uploads/2019/07/tim_ferriss_the-4-hour-chef_one_pager_slow_carb_diet.pdf), because he likes to eat meat and vegetables and starches
  - He found that it worked very quickly
  - It got him lean, he could exercise, he could think and sleep
- Andrew eats to enjoy himself but also to have mental energy
- The slow carbohydrate diet is in [*The 4-Hour Body*](https://www.amazon.com/Uncommon-Fat-Loss-Incredible-Becoming-Superhuman/dp/0091939526/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1692039451&sr=8-1), and this was a very good plan for him
  - Easy to follow
  - You drop some things like bread; you don’t drink calories
  - One day a week you have a “cheat day” and anything goes
  - The only modification Andrew made was the day after the cheat day, he wouldn’t eat (he’d fast)
  - He had profound gastric distress after the cheat day, so the last thing he wanted to do is eat any food
- Andrew read that berberine (the poor man’s metformin) could buffer blood glucose
  - In some ways it made him feel less sick when ingesting all those calories and spiking of his blood sugar and insulin (from ice cream etc.)
  - If he took berberine then ate 12 donuts, he felt much better (as if he ate 1 donut)
- Andrew thinks he was taking a couple hundred mg
- One thing Andrew noticed when taking berberine was that if he did not ingest a profound number of carbohydrates very soon afterwards, he got brutal headaches
  - He thinks he was [hypoglycemic](https://en.wikipedia.org/wiki/Hypoglycemia) (didn’t measure it)
  - He realized berberine was putting him in this lower blood sugar state, and that allowed him to eat these cheat foods
- When Andrew cycled off the 4-hour diet (he doesn’t follow a low-carb diet anymore), when he didn’t do those cheat days, he didn’t have any reason to take the berberine
  - And he feared he wasn’t ingesting enough carbohydrates to justify trying to buffer his blood glucose
  - His blood glucose tends to be very low

Peter asks, “*Did you ever try* [*acarbose*](https://en.wikipedia.org/wiki/Acarbose)*?*”

- It’s another glucose disposal agent but it works more in the gut and prevents glucose absorption
- Acarbose is another one of those drugs that actually found a survival benefit in the ITP, and it was a very interesting finding because the thesis for testing it
  - The ITP is a very clever system, anybody can nominate a candidate to be tested, and then the panel over there reviews it and they decide if they will study it
  - Peter thinks [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) nominated acarbose to be studied
  - The rationale was it would be a caloric restriction mimetic because you would literally just fail to absorb, I don’t know, make up some number, 15 to 20% of your carbohydrates would not be absorbed, and therefore the mice would effectively be calorically restricted
  - The mice lived longer on acarbose but they didn’t weigh any less
    - So they lived longer but not through calorie restriction
  - The speculation is they lived longer because they had lower glucose and lower insulin

Andrew mentions interesting ideas that some forms of **dementia** might be [type 3 diabetes (diabetes of the brain)](https://en.wikipedia.org/wiki/Type_3_diabetes)

- So things like berberine, metformin, lowering blood glucose, ketogenic diets, etc. might be beneficial there
- Andrew adds, “*It seems that we know the following things for sure: One, you don’t want insulin too high nor too low. You don’t want blood glucose too high nor too low. If the buffering systems for that are disrupted, clearly regular exercise is the best way to keep that system in check.*”

**In the absence of exercise, is there any glucose disposal agent that you take on a regular basis because you have confidence in it?**

- This is what they’re talking about with metformin, berberine, and acarbose
- Peter replies, “*The only one that I take is an* [*SGLT-2 inhibitor*](https://en.wikipedia.org/wiki/SGLT2_inhibitor)*.*”
  - This is a class of drug used by people with type 2 diabetes
  - Mechanistic studies of this drug, coupled with its results in the ITP, coupled with the human trial results that show profound benefit in non-diabetics taking it even for heart failure, Peter thinks there’s something very special about that drug
  - Actually, that was another paper he was thinking about presenting this time (maybe we’ll do that the next time)

**Andrew asks, “*****Do you believe in caloric restriction as a way to extend life or are you more of the do the right behaviors (as covered in your*** [***book***](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1692110535&sr=8-1)***)?*****”**

- Peter thinks you can uncouple a little bit the buffering of blood glucose from the caloric deficit
- You can probably be in a reasonable energy balance and buffer glucose with good sleep hygiene, lots of exercise, and just thoughtful eating without having to go into a calorie deficit
- It’s not entirely clear if profound caloric restriction would offer a survival advantage to humans, even if it were tolerable to most (which it’s not)
  - There are not many people willing to sign up for that
- The question is: Do you need to be fasting all the time?
  - Do you need to be doing all of these other things
- Answer: Outside of using them as tools to manage energy balance, it’s not clear
- Energy balance probably plays a greater role in glucose homeostasis, from a nutrition standpoint, than the individual constituents of the meal
  - Exceptions where this is not true: imagine a scenario where a person could be in a negative energy balance eating Twix bars all day and drinking Big Gulps, but that’s also not very sustainable
    - Because if by definition if you’re in negative energy balance consuming that much crap, it’s going to destroy you
    - You’re going to feel miserable ‒ you’ll be starving and not satiated
    - You’ll end up having to go into caloric excess
- For a person to be generally satiated in an energy balance, they’re probably eating about the right stuff
- Peter doesn’t think that specific macros matter as much as he used to think
- Andrew is a believer in getting most of his nutrients from unprocessed or minimally processed sources
  - It allows him to eat foods he likes and more of them

## Current thoughts on the use of metformin for longevity [1:21:00]

**Andrew’s takeaway**

- This is an amazing paper for the simple reason that it provides a wonderful tutorial of the benefits and drawbacks of this type of work
- It’s also wonderful because we hear a lot about metformin, rapamycin, and these anti-aging approaches
- And he was not aware that there was any study of such a large population of people

**Peter’s takeaway**

- The geroprotective benefits of metformin remain to be seen
- The TAME study should answer this question definitively
  - TAME will take a group of non-diabetics and randomizing them to placebo versus metformin and studying for specific disease outcomes
- If the TAME study ends up demonstrating that there is a geroprotective benefit of metformin, Peter will reconsider everything
- We just have to all walk around with an appropriate degree of humility around what we know and what we don’t know
- Right now, the epidemiology, the animal data, Peter’s own personal experience with its impact on lactate production and exercise performance (which appears to be attenuated by metformin), he doesn’t think of it as a great tool for the person who is insulin sensitive and exercising a lot
  - The impact of metformin on hypertrophy and strength (which appears to be attenuated) is a whole other rabbit hole we could go down another time
  - Peter still prescribes metformin to patients all the time if they’re insulin resistant

## Could there be any longevity benefit to short periods of caloric restriction? [1:22:45]

- For instance, eating one meal a day where you’re in a slight caloric deficit of 500-1000 calories, for a couple of days
  - And then going back to the way you were eating before that restriction
    - Periodically restricting once every couple of weeks or a once a month fast for a day or two?
  - Andrew asks, “*Is there any benefit to it in terms of cellular health? Can you reset the system?*”
    - Does this affect the clearing of [senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence) or [autophagy](https://en.wikipedia.org/wiki/Autophagy)?

***Peter thinks the short answer is no, for two reasons:***

- 1 – He doesn’t think that duration would be sufficient
- 2 – Even if you went with a longer period of restriction, muscle mass is lost and it’s very difficult to gain that back
- Peter used to do 7 days of water only per quarter, and 3 days per month
  - It would be a 3 day fast, 3 day fast, 7 day fast
    - Just imagine doing that all year, rotating
  - Peter did this for many years and has no idea if that provided a benefit
  - He had profound misery for a few days
  - Discussed in [AMA #44](https://peterattiamd.com/ama44/)
- Peter’s thoughts for fasting is that there’s got to be a resetting of the system here
  - It must be sufficiently long enough to trigger all of those systems

**The bigger problem with geroscience is we don’t have biomarkers around true metrics of aging**

- Peter hopes the field of epigenetics comes to the rescue n this
- We’re good at using molecules or interventions for which we have biomarkers
- For example, when you lift weights, you can look at how much weight you’re lifting and you can look at your DEXA scan and see how much muscle mass your generating (those are biomarkers)
  - Those are giving you outputs that say my input is good *or* my input needs to be modified
- When you take metformin, when you take rapamycin, when you fast, we don’t have a biomarker that gives us any insight into whether or not we’re moving in the right direction or if we’re taking enough
- Peter adds, “*So often I get asked what’s the single most important topic you would want to see more research dollars put to in terms of this space? And it’s unquestionably this [biomarkers].*”
  - Without biomarkers we’re not going to get great answers because you can’t do most of the experiments Peter and Andrew would dream up

## Peter and Andrew’s process for reading scientific papers [1:26:45]

- Notice that Peter said he read the paper several times
  - Unlike a newspaper article or an Instagram post, with a paper you’re not necessarily going to get it the first time
- Andrew thinks spending some time with papers, reading it and then reading it again a little bit later or one thing at a time

**Andrew’s process for reading scientific papers**

- Unless it’s an area that Andrew knows very, very well (where he can skip to some things before reading it the whole way through), his process is always the same
- When he was a professor at UC San Diego, he taught a course called Neural Circuits in Health and Disease and they would do this (parse papers)
  - He would ask students what he called “***The*** ***four questions***” (he writes this down when going through the paper)
- 1 – **What question are they asking:** What’s the general question? What’s the specific question?
- 2 – **What was the approach:** How did they test that question? (sometimes that can be very detailed)
  - It’s not so important for most people that they understand every method, but it is worthwhile that if you encounter a method like PCR or chromatography or FMRI, that you at least look up on the internet what its purpose is (that will help a lot)
- 3 – **What did they find?**
  - You can usually figure out what they believe they found by reading the figure headers
- 4 – **What is the conclusion of the study?**
  - This is the key question that would really distinguish the high performing students from the others
  - ***You have to go back at the end and ask whether or not the major conclusions drawn in the paper, are really substantiated by what they found and what they did (and that involves some thinking)***
- Andrew points out that this isn’t something that anyone can do straight off the bat
  - It’s a skill that you develop over time
  - Different papers require different formats

> “*Those four questions really form the cornerstone of… how to read a paper.*”‒ Andrew Huberman

- Andrew will read the title, abstract, then skip to the figures and see how much he can digest without reading the text
  - Then he goes back and reads the text
- In fairness, great journals (like Science, Nature, and Cell Press) oftentimes will pack so much information into each figure and it’s coded with no definition of the acronyms that almost always Andrew is into the introduction and results within a couple of minutes wondering what the hell an acronym is
  - It’s just wild how much nomenclature there really is
- The Chair of Ophthalmology at Stanford ([Dr. Jeffrey Goldberg](https://profiles.stanford.edu/jeffrey-goldberg)) who was a guest on The [Huberman Lab podcast](https://hubermanlab.com/dr-jeffrey-goldberg-how-to-improve-your-eye-health-and-offset-vision-loss/) recently off-camera told us that if you look at the total number of words and terms that a physician leaving medical school owns in their mind and their vocabulary, it’s the equivalent of two additional full languages of fluency beyond their native language
- Andrew remarks to Peter, “*So you’re trilingual at least… Do you speak a language other than English?*”
  - Poorly
- Peter agrees, this is a great format to read scientific papers

***No one is expected to be able to parse these papers the first time through without substantial training***

**Peter’s process for reading scientific papers**

- Peter has a different approach when he is familiar with the subject matter versus when he is not
- If it’s **a subject he knows really well**, he can basically glean everything he needs to know from the figures
  - Sometimes he’ll do a quick skim on methods
  - He doesn’t need to read the discussion, intro, or anything else
- If it’s **something he knows less about**, he tries to start with the figures
  - This usually ends up generating more questions
  - Typically he will go back and read the methods
- A lot of papers these days have supplemental information that is not attached to the paper, and you’ll be amazed at how much stuff gets put into the **supplemental section**
  - The reason for that is that journals are very specific on the format and length of a paper
  - So a lot of the times when you’re submitting something, like if you want to put any additional information in there, it can’t go in the main article, it has to go in the supplemental figure
- Even for the paper Peter went through, there were a couple of the numbers he spouted off that came out of the supplemental paper
  - For example, when they did the sensitivity analysis on the censoring versus non-censoring, that was in the supplemental figure

## The biological effects of belief, and how “belief effects” differ from placebo effects [1:32:30]

**The paper Andrew chose**

- The [paper](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2) Andrew chose for this journal club episode is “a very different sort of paper; it’s an experimental paper where there’s a manipulation”
- Andrew loves this paper, and he doesn’t often say that about papers
- A couple of caveats: the paper is not published yet
  - He was able to get this paper because it’s on [BioRxiv](https://www.biorxiv.org/)
  - There is a strong possibility that the final version of this paper is going to look different
- There has been a new trend over the last 5-6 years of people posting papers they’ve submitted to journal for peer review online so that people can look at them prior to those papers being peer reviewed
- There are a couple of thing that make Andrew confident in the data that they’re going to talk about
  - First of all, the group that published this paper is really playing in their wheelhouse
  - They publish a lot of really nice papers in this area
- [Xiaosi Gu](https://labs.icahn.mssm.edu/gulab/) (Andrew is going to mispronounce her name) who’s at the Icahn School of Medicine in Mount Sinai, runs a laboratory studying addiction in humans
- The first author of the paper is [Ofer Perl](https://labs.icahn.mssm.edu/gulab/)

> “*This paper is wild. And I’ll just give you a couple of the takeaways first as a bit of a hook to hopefully entice people into listening further because this is an important paper*.”‒ Andrew Huberman

**One of Andrew’s takeaways** ‒ This paper basically addresses how our beliefs about the drugs we take impacts how they affect us at a real level, not just at a subjective level, but at a biological level

**Background for this paper and how “belief effects” are different than placebo effects**

- A former guest on the *Huberman Lab* podcast, [Dr. Alia Crum](https://hubermanlab.com/dr-alia-crum-science-of-mindsets-for-health-performance/) talked about **belief effects**
- Belief effects are different than [placebo effects](https://en.wikipedia.org/wiki/Placebo#Effects)
  - Placebo effects are really just category effects
  - For example, if you are given a pill (molecule X5952) and it’s going to make your memory better, and then you are given a memory test
    - The people taking X5952 perform better than people in the control group who are taking a placebo
    - It’s binary, you’re either in the drug group or the placebo group, and you’re either told your getting drug or placebo
  - Another example, a lore in high school that kids would do this mean thing ‒ get some kid at a party to drink alcohol-free beer and once the kid started acting drunk they’d say, “*Gotcha. It doesn’t even have alcohol in it.*”
    - A mean joke but it speaks to the placebo effect
  - There’s also a social context effect
- Placebo effects are real
- Belief effects are different
  - They are not A or B (placebo or non-placebo)
  - Belief effects have a lot of knowledge to enrich one’s belief about a certain something that can shift their psychology and physiology one way or the other
- One of the best examples of these belief effects comes from Ali Crum’s lab in the psychology department at Stanford
  - If people are put into a group where they watch a brief video, just a few minutes of video about how stress really limits our performance, let’s say at archery or at mathematics or at music or at public speaking, and then you test them in any of those domains or other domains, in a stressful circumstance, they perform less well
  - We know they perform less well because by virtue of a heightened stress response
    - You can measure: heart rate, stroke volume of the heart, peripheral blood flow which goes down when people are stressed, narrowing of vision, etc.
  - You take a different group of people and randomly assign them to another group where now they’re being told that stress enhances performance, it mobilizes resources, it narrows your vision such that you can perform tasks better
    - And their performance increases above a control group that receives just useless information, or at least useless as it relates to the task
  - So in both cases the groups are being told the truth, stress can be depleting or it can enhance performance, but this is different than placebo because now it’s scaling according to the amount and the type of information that they’re getting
- Peter asks, “*Can you give me a sense of magnitude of benefit or detriment that one could experience in a situation like the one you just described?*”
- Andrew puts a rough percentage on it: stress makes the 10-30% worse at performance than the control group, and enhancement by stress is approximately an equivalent improvement
  - They’re in opposite directions
- In another [experiment](https://pubmed.ncbi.nlm.nih.gov/21574706/) that Ali’s lab did (and others) gives people a milkshake
  - You tell them it’s a high calorie milkshake, it has a lot of nutrients, and then you measure ghrelin secretion in the blood
    - [Ghrelin](https://en.wikipedia.org/wiki/Ghrelin) is a marker of hunger that increases the longer it’s been since you’ve eaten
  - And what you notice is that it suppresses ghrelin to a great degree and for a long period of time
  - You give another group a shake, you tell them it’s a low calorie shake, that it’s got some nutrients in it, but that it doesn’t have much fat, not much sugar, etc.
  - They drink the shake and get less ghrelin suppression (it’s the same shake)
  - Satiety lines up with that also in that study
- A third [example](https://pubmed.ncbi.nlm.nih.gov/17425538/) took hotel workers, they gave them a short tutorial (or not informing them) that moving around during the day and vacuuming and doing all that kind of thing helps lower your BMI, which is great for your health
  - You incentivize them and then you let them out into the wild of their everyday job
  - You measure their activity levels
    - The two groups don’t differ
    - They’re doing roughly the same task, leaning down, cleaning out trash cans, etc.
  - The group that was informed about the health benefits of exercise lost 12% more weight compared to the other group
    - But there was no difference in actual movement
  - This study was sparked by Ali’s graduate advisor saying, “*What if all the effects of exercise are placebo?*” (which no one believes)
  - This anecdote speaks to how really smart people think ‒ they sit back and they go, yeah, exercise obviously has benefits but what if a lot of the benefits are that you tell yourself it’s good for you and the brain can actually activate these mechanisms in the body?
    - And why wouldn’t that be the case because the nervous system extends through both?

## The neurobiology of nicotine: a precursor conversation before delving into the paper Andrew chose [1:39:45]

*This* [*study*](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2) *is about belief effects (not placebo effects)*

**The effects of nicotine**

- To make a long story short, we know that [nicotine](https://en.wikipedia.org/wiki/Nicotine) does improve cognitive performance (vaped, smoked, dipped or snuffed or these little ZYN pouches or taken in capsule form)
  - Andrew is not suggesting people run out and start doing any of those things
  - He did a whole [episode on nicotine](https://hubermanlab.com/nicotines-effects-on-the-brain-and-body-and-how-to-quit-smoking-or-vaping/)
  - The delivery device often will kill you some other way or is bad for you
- It causes vasoconstriction, which is also not good for certain people, but nicotine is cognitive enhancing
  - Why? Well, you have a couple of sites in the brain, namely in the [basal forebrain](https://en.wikipedia.org/wiki/Basal_forebrain), [nucleus basalis](https://en.wikipedia.org/wiki/Nucleus_basalis) (in the back of the brain), structures like [locus coeruleus](https://en.wikipedia.org/wiki/Locus_coeruleus), but also this what’s called the [pedunculopontine nucleus](https://en.wikipedia.org/wiki/Pedunculopontine_nucleus) (which is this nucleus in the pons, in the back of the brain in the [brainstem](https://en.wikipedia.org/wiki/Brainstem)) that sends those little axon wires into the [thalamus](https://en.wikipedia.org/wiki/Thalamus)
  - The thalamus is a gateway for sensory information (visual and auditory information), and it has [nicotinic receptors](https://en.wikipedia.org/wiki/Nicotinic_acetylcholine_receptor)

***When the pedunculopontine nucleus releases nicotine or when you ingest nicotine, what it does is it increases the signal to noise of information coming in through your senses; so the fidelity of the signal that gets up to your cortex (which is your conscious perception of those senses) is increased***

**How much endogenous nicotine do we produce?**

- It’s going to be [acetylcholine](https://en.wikipedia.org/wiki/Acetylcholine) binding to nicotinic receptors (we’re not making nicotine)
- This is a nicotinic acetylcholine receptor, of which there are at least seven (and probably 14) subtypes
  - They’re called nicotinic receptors in an annoying way, in the same way that cannabinoid receptors are called cannabinoid receptors
    - But then everyone thinks those receptors are there because we’re supposed to smoke pot, or those receptors are there because we’re supposed to ingest nicotine
  - The receptor is named after the drug

**The important thing to know**

- Is whether or not it’s basal forebrain or pedunculopontine nucleus or locus coeruleus, that is involved in the brain
  - Because we’re not talking about muscle where acetylcholine does something else via nicotine receptors
- In general in the brain, nicotine tends to be a **signal-to-noise enhancer**
  - For the non-engineering types out there, signal-to-noise: Just imagine I’m talking right now and there’s a lot of static in the background, there are two ways for you to be able to hear me more clearly
    - We can reduce the static
    - Or I can increase the fidelity (the volume and the clarity of what I’m saying), and that’s really what acetylcholine does
  - That’s why, when people smoke a cigarette, they get that boost of nicotine and they just feel clear (it really works)

**The other thing that happens is the thalamus sends information to a couple of places**

- First of all, it sends information to the reward centers of the brain, the [mesolimbic reward pathway](https://en.wikipedia.org/wiki/Mesolimbic_pathway) that releases [dopamine](https://en.wikipedia.org/wiki/Dopamine)
  - Typically when nicotine is increased in our system, dopamine goes up, and that’s one of the reasons why nicotine is reinforcing
  - We just like it; we seek it out
  - They’ve done beautiful experiments with honeybees even, where you put nicotine on certain plants, or it comes from certain plants, and they’ll forage there more (you get them kind of buzzed. Bad pun.)
- There’s also an output from the thalamus to the [ventromedial prefrontal cortex](https://en.wikipedia.org/wiki/Ventromedial_prefrontal_cortex) (which is an area of the forebrain that really allows us to limit our focus and our attention for the sake of learning)
  - It allows us to pay attention
  - Andrew talked about this in his podcast on [stimulants](https://hubermanlab.com/adderall-stimulants-and-modafinil-for-adhd-short-and-long-term-effects/), typically ADHD drugs like [Adderall](https://en.wikipedia.org/wiki/Adderall), [Vyvanse](https://en.wikipedia.org/wiki/Lisdexamfetamine), [Ritalin](https://en.wikipedia.org/wiki/Methylphenidate), [methamphetamine](https://en.wikipedia.org/wiki/Methamphetamine)

**It’s counterintuitive that a stimulant would be a treatment for someone with difficulty focusing**

- In young kids who have difficulty focusing, if you give them something they love, they’re like a laser
  - And the reason is that ventromedial prefrontal cortex circuit engages when the kid is interested and engaged
- But kids with [ADD/ADHD](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder) tend to have a hard time engaging their mind for other types of tasks, and other types of tasks are important for getting through life
- It turns out that giving those stimulant drugs, in many cases, can enhance the function of that circuit and it can strengthen so that, ideally, the kids don’t need the drugs in the long run
  - Although, that’s not often the way that it plays out
- There’s now a big battle out there: “*Is ADHD real? Is it not real?*”
  - Of course it’s real
  - Does every kid need ADHD meds? No
  - Are there other things like nutrition, more playtime outside, etc. that can help improve their symptoms without drugs? Yes.
  - Is the combination of all those things together known to be most beneficial? Yes
  - Are the dosages given too high and generally should be titrated down? Maybe
    - Some kids need a lot; some kids need a little (Andrew probably just gained and lost a few enemies there)

***The point is that: these circuits are hardwired circuits***

**Doesn’t nicotine potentially have a calming effect as well?**

*That seems a bit counterintuitive to the focusing one. Is it a dose effect, timing effect? How does that work?*

- It’s a dosing effect
- The interesting thing about nicotine is that it can enhance focus in the brain, but in the periphery, it actually provides some muscle relaxation
- It’s kind of the perfect drug if you think about it
- Andrew was reflecting on this, how when we were growing up, people would smoke on the plane (they had a smoking section on the plane)
  - People smoked all the time, and now hardly anyone smokes for all the obvious reasons
  - But it provides that really ideal balance between being alert but being mellow and relaxed in the body
    - Hence, it’s reinforcing properties

## Andrew presents a paper that demonstrates the impact of belief [1:45:30]

**What is remarkable about this** [**study**](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2)

- They had experienced smokers come into the laboratory, gave them a vape pen
  - Typically, there’s a washout before they come in (a couple of days), so they’re not smoking for a bit so they can clear their system of nicotine (they’re probably miserable)
- They measure carbon monoxide and they’re measuring nicotine in the blood
- Then they have them vape with either a low, medium, or high dose of nicotine
  - The dosages don’t really matter because tolerance varies, etc.
- And then, they are putting them into a [functional magnetic resonance imaging (fMRI)](https://en.wikipedia.org/wiki/Functional_magnetic_resonance_imaging) machine, where they can look at blood flow (the [hemodynamic](https://en.wikipedia.org/wiki/Hemodynamics) response)
  - It’s the ratio of the oxygenated to deoxygenated blood
  - Blood will flow to neurons that are active to give it oxygen, and then it’s deoxygenated, and then there’s a change in what’s called the [BOLD signal](https://en.wikipedia.org/wiki/Functional_magnetic_resonance_imaging#BOLD_hemodynamic_response)

**More about fMRI**

- In fMRI, when you see these hotspots in the brain, it’s really just looking at blood flow
- And then, there’s some interesting physics around… (Andrew admits he will probably get this wrong)
  - Do you remember the [right-hand rule](https://www.khanacademy.org/test-prep/mcat/physical-processes/magnetism-mcat/a/using-the-right-hand-rule)?
  - [Hold out your right hand with the fingers curled and the thumb up, when the electric current moves in the direction that your fingers are curling, a magnetic field is introduced in the direction of your thumb]
- What you do is when you put a person’s head in this big magnet and then you pulse the magnet, what happens is the oxygenated/deoxygenated blood interacts with the magnetic field differently, and that difference in signal can be detected
  - And you can see that in the form of activated brain areas
- MRI all works by proton detection
  - So presumably there’s a difference in the proton signal when you have high oxygen versus low oxygen concentration
- What they’ll do is they’ll pulse with the magnet (this is definitely getting beyond Andrew’s expertise) and that the spin orientation of the protons is going to relax back at a different rate as well
  - So by relaxing at a different rate, you can also get not just resting state activation like, “*Oh, look at a banana. What areas of the brain light up?*” But you can look at connectivity between areas and how one area is driving the activity of another area
- fMRI is a very powerful technique

**Peter asks, “*****How fine is the resolution?… What are the blind spots of the technique?*****”**

- You can get down to subcentimeter (but not millimeter)
  - They always talk about in in this paper as [voxels](https://en.wikipedia.org/wiki/Voxel), which are these low cubic pixel things
- There are a number of little **confounds** that maybe we won’t go into now that have been basically worked out over the last 10 years by doing the following:
  - You can’t just give somebody a stimulus compared to nothing
  - It was discovered, for instance, that when someone would move their right hand they would see an area in motor cortex lighting up
    - Because when you’re in the MRI, you’re leaning back and you can move your right hand a bit
  - But what they noticed was that the area corresponding to the left hand was also lighting up
  - So what you really have to do is, you have to look at resting state
    - How much are they lighting up just at rest?
    - And subtract that out

***You’ll always see “resting state” versus “activation state”***

- Peter recalls a funny [study](http://prefrontal.org/files/posters/Bennett-Salmon-2009.pdf) done as a spoof maybe a decade ago that put a dead salmon into an MRI machine, they did an fRMI and demonstrated some interesting signal
  - He wrote about it in this [newsletter](https://peterattiamd.com/what-a-dead-salmon-can-teach-us-about-how-we-use-machines/)

**The design of this** [**study**](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2)

- They put people into the scanner, and then they give them essentially a task that’s known to engage the **thalamus reward centers** and the **ventromedial prefrontal cortex**
  - It’s a very simple game
  - You let people watch a market (or you could say the price of peas, it doesn’t really matter)
    - It goes up, it goes down, and they’re looking at a squiggle line
  - Then, it stops and then they have the option, but they have to pick one option
    - They’re either going to invest a certain number of the hundred units that you’ve given them, or they can short it (they can try and make money on the prediction it’s going to go down)
  - Depending on whether or not they get the prediction right (or wrong), they get more points (or they lose points), and they’re going to be rewarded in real money at the end of the experiment
    - This is going to engage this type of circuitry
- Now, remember, these groups were given a vape pen prior to this, where they vaped what they were told is either a low, medium or high dose of nicotine, and then they do this task

**What question are they asking?**

- The goal is *not* to get them to perform better on the task
- The goal is to engage the specific brain areas that are relevant to this kind of **error- and-reward type circuits**, and we know that this task does that
  - So, that includes the thalamus
  - That includes the mesolimbic reward pathway and dopamine
  - It includes the ventromedial prefrontal cortex

**How did they test that question?**

- They measure nicotine in the blood
  - They are measuring very carefully how much people vaped
  - One of the nice things about the vape pen for the sake of experiment (not recommending people vape) is they can measure how much nicotine is left in the vape pen before and after
  - They can measure how long they inhaled; how long they held it in
    - There’s a lot that you can do that’s harder to do with a cigarette
- They measured people’s belief as to whether or not they got low, medium, or high amounts of nicotine
- They were told: This is a “low amount,” a “medium amount,” or a “high amount,” and then they looked at brain area activation during this task
  - ***But they were all given the same amount (this is the sneak)***
  - The subject are unaware that they all got the same amount of relatively low nicotine-containing vape pen
- They measured nicotine from their bloodstream, and they all had fairly low levels

**What they found was very straightforward**

***People’s subjective feeling of being on the drug matches what they were told***

- So if they were told, “*Hey, this is a high amount of nicotine,*” yeah, it feels like a high amount of nicotine
  - these are experienced smokers
  - That’s the **placebo effect**
- If you look at the activation of the thalamus in the exact regions where you would predict acetylcholine transmission to impact the function of the thalamus, these are areas involved in **attention**
  - These include areas like what’s called the [centromedian nucleus](https://en.wikipedia.org/wiki/Centromedian_nucleus), the [ventral posterior nucleus](https://en.wikipedia.org/wiki/Ventral_posterior_nucleus) (the names really don’t matter)
- It scales with what they thought they got in the vape pen, meaning:
  - If you were told that you got a low amount of nicotine, you got a little bit of activation in these areas
  - If you were told that you got a medium amount of nicotine, and that’s what you vaped, then you had medium amounts or moderate amounts of activation
  - And if you were told you got high amounts of nicotine, you got a high degree of activation
- The performance on the task scales with it somewhat

***Keep in mind that everyone got the exact same amount of nicotine, so here the belief effect isn’t just changing what one subjectively experiences; it actually is changing the way the brain responds to belief (which Andrew finds absolutely wild)***

## Analyzing the fascinating results of the Perl paper [1:54:30]

**A couple of things could have confounded this**

- It could have been that if you believe you got a lot of nicotine, you’re just faster or you’re reading the lines better or your **response time** to hit the button is quicker
  - If you’re told you have a drug that’s going to improve reaction time (which you may believe about nicotine), you may be quicker on the trigger (more activation)
- They rule that out by looking at rates of pressing and there was no difference
- Further, in the sensory areas of the brain that would represent that kind of difference, they don’t see any difference
- The other thing that is very clear is that the **connection between the thalamus and the ventromedial prefrontal cortex**, that pathway scales in the most beautiful way, such that people that were told they had smoked a low or vaped a low amount of nicotine got a subtle activation of that pathway
  - People that were told that they got a moderate amount of nicotine got a more robust activation of that pathway
  - And the people that were told that they got a high amount of nicotine in the vape pen saw a very robust activation of the thalamus to this ventro-prefrontal cortical pathway
  - Now, of course, this is all happening under the hood of the skull, simply on the basis of what they were told and what they believe
- Technically the fMRI is showing the activation of those two areas, and that’s how you can infer the strength of that connection
- There’s a separate method called [diffuser tensor imaging](https://en.wikipedia.org/wiki/Diffusion_MRI), which Andrew thinks was developed out of the group in Minnesota
  - Minnesota has a very robust group in terms of neuroimaging, that can measure activation and fiber pathways
  - This is not that, but you can look at the timing of activation of a known monosynaptic pathway

**What the figures tell us**

- Andrew likes to read the titles of the figures
- Figure 7 shown below (aka “fig.2” from the study) — the belief about nicotine strength induced a dose-dependent response in the thalamus (shown below)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f7-andrewhuberman2.png)

**Figure 7.** Image credit: [preprint 2023](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2)

- **Panel e** shows the belief rating as a function of the estimate in thalamus activation
  - It’s a mess when you look at all the dots at once, but if you separate it out by high, medium, and low, and you run the statistics, what you find is that there’s a gradual but legitimate increase from low to medium to high
  - In other words, if you are told, “*This is a high dose of nicotine*,” your brain will react as if it’s a high dose of nicotine
- Now, what they didn’t do was give people zero nicotine (that’s a **control that is missing**)

> “*What I find just outrageous and outrageously interesting about this study is simply that what we are told about the dose of a drug changes the way that our physiology responds to the dose of the drug*.”‒ Andrew Huberman

**In Andrew’s understanding, this is the first study to ever look at dose-dependence of belief effects**

- Why would that be important?
- Well, for almost every study of drugs, you look at a dose-dependent curve
  - You look at zero, low dose, medium dose, high dose
- Here, they clearly are seeing a dose-dependent response simply to the understanding of what they expect the drug ought to do
  - In other words, you can bypass pharmacology somewhat
- In Figure 7 above (aka “Fig. 2-b” in the study)  there are four bars corresponding to the group that was told they got the: (1) low dose, (2) medium dose, (3) high dose, and (4) healthy controls
  - The healthy controls were non-smokers who were just put in the machine

**This is measuring parameter estimate. Is that referring to their ability to play the trading game?**

- The parameter estimate is a measure of the level of activation
- So, what they’re doing is they’re just saying, “*If we just look at the thalamus, what is the level of activation?*”

**Peter’s takeaway** ‒ this suggests that the only statistical difference was between the low and the high, and nobody else is statistically different

- Andrew agrees

**But that’s not the whole story**

- In Figure 8 below (aka “Fig.4-b” from the paper), when you look at the output from the thalamus to the ventromedial prefrontal cortex, the parameter estimates is the degree of activation between the thalamus and the ventromedial prefrontal cortex
  - That’s called the **instructed belief**
  - You can see that there’s a low, medium, and high scatter of dots for each, and that each one of those is significant

![](https://peterattiamd.com/wp-content/uploads/2023/09/f8-andrewhuberman2.png)

**Figure 8.** Image credit: [preprint 2023](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2)

- Peter points out, “*Isn’t it interesting that the thalamus, which is… more proximate to the nicotine acetylcholine receptor… you have a lower difference of signal strength, and somehow that got amplified as it made its way forward in the brain.*”
  - He asks Andrew if this is surprising
- It is, and it surprised the authors as well

**It’s important to match the author’s conclusions against what they actually found**

- This is what this discussion is doing
- The interpretation that they give is that it doesn’t take much nicotinic receptor occupancy in the thalamus to activate this pathway
- But they too were surprised that they could not detect a raw difference in the activation of the thalamus
- But in terms of its output to the prefrontal cortex, that’s when the difference showed up
  - Because figure 8 (*“Fig 4” part b in the paper*) is more convincing that figure 7 above (“*Fig. 2” in the paper*)
  - If you read the fine print in Figure 7 above (*“Fig. 2-e” from the paper*), r=0.27 (the [correlation coefficient](https://en.wikipedia.org/wiki/Correlation_coefficient)), and this is weak

**Peter’s takeaway** ‒

- The thalamus is like, “*Eh, there might be a signal.*”
- There could be a huge signal here but we’re underpowered (this goes back to the earlier discussion)

**How many subjects were in this?**

- Peter thinks you wouldn’t have a lot of subjects in this experiment
- Andrew agrees
  - This speaks to the general challenge of doing this kind of work
  - It’s hard to get a lot of people in and through the scanner
    - It’s expensive
- The methods [state 20 smokers and 33 healthy controls were used]
- If you do this with a thousand people, it could all be statistically significant
- The paper talks about this, “*Based on this, we estimated that an N of 20 in each belief condition (N of sample size), the final sample would provide 90% power to detect an effect of this magnitude at an alpha of 0.5 in a two-tailed test.*”
  - This refers to the power of analysis
  - At 90% confidence, to get an alpha of 0.05, which means we’ll want to be 95% confident, we need 60 people (20 per group)
- But if the difference is smaller than what they expected, they’ll miss out on some of the significance, which looks like they’re missing between the medium and high group
- Andrew agrees and was surprised that they did not see a difference between the medium and the high group, but they did in the output of the thalamus
- He was also surprised that they didn’t see a difference in Figure 9 below (*“Fig.3” from the paper*)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f9-andrewhuberman2.png)

**Figure 9.** Image credit: [preprint 2023](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2)

- Figure 9 (aka “Fig. 3” in paper): their belief about nicotine strength did not modulate the reward response, the dopamine response
  - Measured with fMRI
- Figure 9-b (aka “Fig.3-b” in the paper) shows that there’s no difference between these different groups in terms of the amount of activation in these reward pathways if people got a low, medium, or high amount of nicotine

## Exciting implications of the findings about “belief” reported by Perl and colleagues [2:03:15]

**Andrew believes that finding could be leveraged**

- For instance, if somebody were **trying to quit nicotine**, and they were going to do that by progressively reducing the amount of nicotine that they were taking, but you told them that it was the same amount from one day to the next, you could whittle it down presumably to a low amount before taking it to zero
- And if they believed it to be a greater amount, then it might actually not disrupt their reward pathways, meaning presumably they’d feel rewarded by whatever nicotine they were bringing in

**Peter asks, “*****What would be your prediction if this experiment were repeated, but it was done exactly the same way with non-smokers?*****”**

- That’s interesting
- You asked about potential sources of artifact problems with fMRI
- One of the challenges that they note in this study was you have to stay very still in the machine, but the subjects were constantly coughing because they’re smokers
  - Andrew started chuckling at that one: they’re smokers, they’re coughing, they can’t stay still, it’s a movement artifact
- So presumably the data would be higher fidelity [from non-smokers]
  - For people that are naive to nicotine, even a small amount of nicotine is likely to get this pathway activated to such a great degree
    - Sort of like the first-time effect of pretty much any drug
- Peter wonders if non-smokers would be more or less susceptible to the belief system
- Andrew agrees that this is a good question
  - Non-smokers have no prior experience to compare it to with respect to the obviously beneficial effects of nicotine that the smokers are well used to

**Andrew thinks this paper is very cool because they’re starting to explore dose dependence of belief and that has all sorts of implications**

- This is not the be-all-end-all, perfect experiment
- Use your imagination, whether or not we’re talking about a drug, or a behavioral intervention or a vaccine (not any one specific vaccine, but vaccines generally), psychoactive drugs, illicit drugs, antidepressants, all sorts of drugs, metformin, etc.

***What we believe about the effects of a drug presumably, in addition to what we believe about how much we’re taking and what those effects ought to be, clearly are impacting at least the way that our brain reacts to those drugs***

- Peter agrees this is very interesting
- When you consider how many drugs that have peripheral effects, or peripheral outputs, begin with central issues
- Peter thinks the the [GLP-1 agonists](https://peterattiamd.com/ama45/) ([Ozempic, generic name semaglutide](https://en.wikipedia.org/wiki/Semaglutide)) are such a great example of this
  - No one fully understands exactly how they’re working, but it’s hard to argue that the GLP-1 agonists are having a central impact
    - It’s doing something in the brain that is leading to a reduction of appetite
  - Andrew thinks the mouse data point to different areas of the hypothalamus that are related to satiety (that’s a possibility)
    - Peter agrees, there’s no quicker way to make a mouse overeat or undereat than by lesioning its hypothalamus (depending on where you do it)

**The bigger question: what do you need to believe in order for that to be the case?**

- Andrew asks, “*Have they done placebo trials… where people get something and they’re told…*”
- Yes, those drugs have all been tested via placebo, and the placebo groups don’t do anywhere near as well
  - That’s how we know that there’s activity of the drug
- But again, that’s a little bit different than being told you are absolutely getting it, right?
  - Because in the [RCTs](https://en.wikipedia.org/wiki/Randomized_controlled_trial), you’re just told: “*You might be getting it; you might not be getting it*.”
    - So it’s not quite the same as this experiment
- The experiment in this [paper](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2) is one level up, where you’re being told, “*You’re absolutely getting it. You’re just getting different doses of it.*”

**Andrew takes this to the ADHD realm**

- Let’s say a kid has been on ADHD meds for a while, and the parents or the physician decide they want to cut back on the dosage
- But if they were to tell the kid it’s the same dosage they’ve always been taking and it’s had a certain positive effect for them
  - According to the results at least in this paper (which are not definitive but are interesting), the lower dose may be as effective simply on the basis of belief

***This is the part that makes it so cool: it’s not a kid tricking themselves or the parents tricking the kid, so much as the brain activation is corresponding to the belief***

**Because it’s done in the brain, it gets to these abstract, nearly mystical, but not quite mystical, aspects of belief effects, which is that:**

- Your brain is a prediction-making machine
- It’s a data interpretation machine
- But it’s clear that one of the more important pieces of data are your beliefs about how these things impact you
  - So it’s not that this bypasses physiology
  - People aren’t deluding themselves
  - The thalamus is behaving as if it’s a high dose, when it’s the same dose as the low-dose group
- Peter thinks of the implication for **blood pressure** (for example)
  - We don’t really understand essential hypertension (the majority of people walking around with high blood pressure) ‒ the etiology is unclear
  - Lots of people are being treated
  - How do we know that the belief system about it can’t be changed?

[**Alia Crum**](https://profiles.stanford.edu/alia-crum) **is onto some other really cool stuff**

- For instance, just to highlight where these belief effects are starting to show up, if you tell a group that the side effects of a drug that they’re taking are evidence that the drug really works for the purpose that they’re taking it, they report more relief from the primary symptoms that they’re trying to target
  - Even though those side effects are kind of annoying, people report the experience as less awful
  - So, our belief about what side effects are can really impact how quickly a drug works and how compatible we feel that drug is with our entire life
- Andrew suggests that maybe we call side effects something else
  - You don’t want to lie to people
  - But you also don’t want to send them in the opposite direction, which is reading the list of side effects of a drug and then developing all of those side effects (the [nocebo effect](https://en.wikipedia.org/wiki/Nocebo))
    - And then maybe later coming to the understanding that some of those were raised through belief effects
- Peter agrees, this is tough because how do you know which is a side effect and which is a belief effect
  - There are some people who are really impacted by the list of possible side effects and it makes it very difficult for them to take any sort of pharmacologic agent
    - Because they can’t help but incur every possible side effect

**Andrew asks, “*****Isn’t it true that medical students often will start developing the symptoms of the different diseases that they’re learning about?*****”**

- Peter does think that in medical school, you start to **think of the zebras more than the horses** all the time
  - What he’s referring to: you see hoof prints and you should think of horses, but medical students only think of the zebras
  - There are certain conditions that you spend so much time thinking about that you have a very **warped sense of their prevalence**
    - In medical school, there’s a condition they never stop talking about called [sarcoidosis](https://en.wikipedia.org/wiki/Sarcoidosis), but peter has only seen three cases in his life (it’s not that common)
    - [Situs inversus](https://en.wikipedia.org/wiki/Situs_inversus) is another example: embryologically people have a reversed rotation and everything in their body is flipped
    - Their heart is on the right side, their liver is on the left side, their appendix is on the left side
    - Peter has never seen a case of situs inversus
    - As a medical student, if you were told someone had left-sided, lower quadrant pain (to which the answer is almost assuredly they have diverticulitis) you’d think, “They could have appendicitis in the context of situs inversus.” [although that possibility is rare]

> “*I don’t know about our listeners, but for me, this is among the things that I just delight in, and even more so because you’re the one across the table from me teaching me about these incredible findings.*”‒ Andrew Huberman

§

## Selected Links / Related Material

**Andrew’s podcast**: [Huberman La](https://hubermanlab.com/)b (2023) | [2:30]

**Previous episode of** ***The Drive*** **with Andrew Huberman**: [#249 ‒ How the brain works, Andrew’s fascinating backstory, improving scientific literacy, and more](https://peterattiamd.com/andrewhuberman/) | Andrew Huberman, Ph.D. (April 3, 2023) | [2:30]

**\*\*\*Paper Peter chose to discuss (Keys 2022)**: [Reassessing the evidence of a survival advantage in Type 2 diabetes treated with metformin compared with controls without diabetes: a retrospective cohort study](https://pubmed.ncbi.nlm.nih.gov/36287641/) | *International Journal of Epidemiology* (M Keys et al. 2022) | [9:15]

**Newsletter about the Keys paper:** [A recent metformin study casts doubts on longevity indications](https://peterattiamd.com/a-recent-metformin-study-casts-doubts-on-longevity-indications/) | Kathryn Birkenbach, Peter Attia, PeterAttiaMD.com (March 11, 2023) | [9:15]

**Bannister’s 2014 paper about metformin**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls](https://pubmed.ncbi.nlm.nih.gov/25041462/) | *Diabetes, Obesity & Metabolism* (C Bannister et al. 2014) | [9:45, 26:15, 32:45, 57:30, 1:07:00]

**Previous episode of** ***The Drive*** **discussing problems happening with type 2 diabetes**: [#149 – AMA #20: Simplifying the complexities of insulin resistance: how it’s measured, how it manifests in the muscle and liver, and what we can do about it](https://peterattiamd.com/ama20/) (February 15, 2021) | [13:30]

**Previous episode of** ***The Drive*** **with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) (December 7, 2020) **|** [20:30]

**Previous episode of** ***The Drive*** **discussing the impact of sleep deprivation on insulin resistance**: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) (April 15, 2019) | [21:15]

**Episode of** ***The Drive*** **discussing geroprotective drugs**: [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) (May 16, 2022) | [25:00]

**Previous episode of** ***The Drive*** **discussing metformin as a geroprotective drug and the 9 hallmarks of aging**: [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/) | beginning at [1:11:30] | PeterAttiaMD.com (March 13, 2023) | [25:00]

**Discussion of the TAME trial**: [About TAME: A Metformin Anti-Aging Clinical Trial with Nir Barzilai, M.D.](https://peterattiamd.com/tame-metformin-anti-aging-trial-nir-barzilai/) | PeterAttiaMD.com (May 13, 2022) | [35:30]

**Episode of** ***The Drive*** **discussing Peter’s experience with fasting**: [#242 – AMA #44: Peter’s historical changes in body composition with his evolving dietary, fasting, and training protocols](https://peterattiamd.com/ama44/) | PeterAttiaMD.com (February 12, 2023) |  [1:24:00]

**Episode of the** ***Huberman Lab*** **with Dr. Jeffrey Goldberg**: [Dr. Jeffrey Goldberg: How to Improve Your Eye Health & Offset Vision Loss](https://hubermanlab.com/dr-jeffrey-goldberg-how-to-improve-your-eye-health-and-offset-vision-loss/) | HubermanLab.com (June 26, 2023) | [1:30:30]

**Episode of the** ***Huberman Lab*** **with Dr. Alia Crum**: [Dr. Alia Crum: Science of Mindsets for Health & Performance](https://hubermanlab.com/dr-alia-crum-science-of-mindsets-for-health-performance/) | HubermanLab.com (January 24, 2022) | [1:33:30]

**\*\*\*Paper Andrew chose to discuss (Perl preprint)**: [A thalamic circuit represents dose-like responses induced by nicotine-related beliefs in human smokers](https://www.biorxiv.org/content/10.1101/2022.07.15.500226v2) | Preprint (O Perl et al 2023) | [1:40:00]

**Episode of the** ***Huberman Lab*** **about nicotine**: [Nicotine’s Effects on the Brain & Body & How to Quit Smoking or Vaping](https://hubermanlab.com/nicotines-effects-on-the-brain-and-body-and-how-to-quit-smoking-or-vaping/) | HubermanLab.com (September 19, 2022) | [1:40:15]

**Episode of the** ***Huberman Lab*** **about stimulants**: [Adderall, Stimulants & Modafinil for ADHD: Short- & Long-Term Effects](https://hubermanlab.com/adderall-stimulants-and-modafinil-for-adhd-short-and-long-term-effects/) | HubermanLab.com (May 29, 2023) | [1:43:15]

**fMRI of a dead salmon**: [Neural correlates of interspecies perspective taking in the post-mortem Atlantic Salmon: An argument for multiple comparisons correction](http://prefrontal.org/files/posters/Bennett-Salmon-2009.pdf) | Poster (C Bennett et al. 2009) | [1:49:30]

**Newsletter about fMRI of a dead salmon**: [What a dead salmon can teach us about how we use machines](https://peterattiamd.com/what-a-dead-salmon-can-teach-us-about-how-we-use-machines/) | Peter Attia, PeterAttiaMD.com (December 25, 2021) | [1:49:30]

§

## People Mentioned

- [Christian Bannister](https://uk.linkedin.com/in/bannisterca) (Director of Computational Statistics at Cardiff University) [9:30]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) (Professor of Medicine and Cellular & Molecular Physiology at Yale, expert in type 2 diabetes) [20:30]
- [Nir Barzilai](https://www.einsteinmed.edu/faculty/experts/484/nir-barzilai/) (Director of the Institute for Aging Research and Professor of Medicine at Albert Einstein College of Medicine) [35:45]
- [Tim Ferris](https://tim.blog/about/) (author and podcaster) [1:12:30]
- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) (Dean and Provost Professor at the Indiana University School of Public Health-Bloomington, obesity expert) [1:16:00]
- [Jeffrey Goldberg](https://profiles.stanford.edu/jeffrey-goldberg) (Chair of Ophthalmology at Stanford) | [1:30:30]
- [Xiaosi Gu](https://labs.icahn.mssm.edu/gulab/) (Director, Center for Computational Psychiatry and Associate Professor, Psychiatry & Neuroscience at the Icahn School of Medicine at Mount Sinai) [1:33:45]
- [Alia Crum](https://profiles.stanford.edu/alia-crum) (Associate Professor of Psychology at Stanford University, expert in the placebo effect) [1:34:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/04/bio-pic-andrewhuberman-500x500.jpeg)

##### Andrew Huberman, Ph.D.

Andrew Huberman earned his Bachelor’s degree from the University of California, Santa Barbara. He went on to earn a Master’s degree in Neurobiology and Behavior from the University of California, Berkeley, and a PhD in Neuroscience from the University of California, Davis. He completed his postdoctoral training at Stanford University.

Dr. Huberman is currently an Associate Professor of Neurobiology and an Associate Professor (by courtesy) of Psychiatry and Behavioral Sciences at Stanford University. His laboratory studies neural regeneration with the goal of developing treatments to prevent and reverse vision loss. They also study neuroplasticity and circuits for anxiety and visually-driven autonomic arousal.

In 2021 Andrew started the [*Huberman Lab* podcast](https://hubermanlab.com/) where he discusses neuroscience and the connections between the brain, our organs, our perceptions, our behaviors, and our health. This has become one of the top-10 podcasts on Apple Podcasts and Spotify. [[Stanford](https://med.stanford.edu/profiles/andrew-huberman#bio)]

Twitter: [@hubermanlab](https://twitter.com/hubermanlab?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Instagram: [@hubermanlab](https://www.instagram.com/hubermanlab/?hl=en)