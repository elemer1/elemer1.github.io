# #200 – AMA #33: Hydration—electrolytes, supplements, sports drinks, performance effects, and more

**Source:** [https://peterattiamd.com/ama33/](https://peterattiamd.com/ama33/)

---

In this “Ask Me Anything” (AMA) episode, Peter discusses all things related to hydration, starting with how water is distributed in the body and the important concept of tonicity. He explains the difference between dehydration and volume depletion and their respective health consequences and implications. He describes the different conditions which affect our daily water needs, as well as the signs of dehydration and how it can affect performance. Next, he discusses all the ways in which we can rehydrate and when it makes sense to add electrolytes, glucose—or a combination of both—to rehydration fluids. Additionally, Peter gives his take on the plethora of sports drinks on the market and which ones stand out from the rest. Finally, he concludes with some key takeaways related to hydration.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #33 show notes page](https://peterattiamd.com/ama33). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

***Note from Peter:** This podcast was recorded in early January 2022. At that time, I had no involvement with any company producing any of the hydration products that are discussed here. However, since recording this podcast, I’ve continued down the rabbit hole of getting deeper into this subject. I’ve become particularly enamored with one of the companies that I mention in this AMA and I am now a small investor in that company, which is LMNT. You can find [a list of all my disclosures here](/about/).*

## We discuss:

- Peter’s incident leading to a renewed interest in hydration [3:15];
- Water in the human body: percentage, location, and implications [6:00];
- Defining tonicity—isotonic, hypotonic, and hypertonic [11:45];
- Defining dehydration and volume depletion [19:00];
- The health consequences of dehydration and volume depletion [21:45];
- How do we actually lose water? [25:30];
- How much water do we need every day? [28:00];
- Signs of dehydration during exercise and how it can affect performance [32:45];
- Is it possible to be overhydrated? [43:15];
- Electrolytes: benefits and when to include them in rehydration fluids [47:00];
- Glucose: benefits and when to include it in rehydration fluids 51:15];
- The ability of glucose to improve absorption of sodium [58:45];
- The type of carbohydrates in drinks than actually impact performance [1:02:00];
- Sodium during workouts: is there an optimal ratio of carbohydrate to sodium? [1:05:00];
- Pros and cons of sports drinks and which ones stand out [1:09:15];
- How much hydration comes from the food we eat? [1:14:30];
- Is there a downside to drinking electrolytes throughout the day even without exercise? [1:15:15];
- Key takeaways related to hydration [1:18:15]; and
- More.

§

The Peter Attia Drive

Hydration—electrolytes, supplements, sports drinks, performance effects, and more

§

## Show Notes

§

## Peter’s incident leading to a renewed interest in hydration [3:15]

Peter recently lost consciousness and fell and [hit his head](https://www.instagram.com/p/CWOFMZfgCF_/) on a table

- He attributes this incident to him being profoundly dehydrated
- He had recently given three units of blood a few days before the fall
- Two days later he took an overnight flight (which can cause dehydration)
- On Friday morning he completely lost consciousness and face-planted into a table

![](https://peterattiamd.com/wp-content/uploads/2022/03/f1-ama33-756x1024.png)

**Figure 1.** Damage from the face plant. [[instagram.com/peterattiamd](https://www.instagram.com/p/CWOFMZfgCF_/)]

That got him thinking about:

- *How can I mitigate this sort of thing from happening again?*

- *What does it say overall about my hydration status?*

- *Is that partly what may contribute to why I sometimes feel lightheaded in the mornings?*

## Water in the human body: percentage, location, and implications [6:00]

*What does it mean that ~60% of our body is water? Where is this water located?*

- Water inside the cell is called Intracellular fluid (ICF): accounts for about two-thirds of water in the body [67%]
- Water outside the cell is called Extracellular fluid (ECF): about one third of the body’s water [33%]
  - About 25% of ECF is in blood/vasculature, which is therefore only about 8% of all water in the body — this is the plasma
    - Anytime you spin blood or see blood spun the tube, it’s red — after you spin it, it gets very dark at the bottom (predominantly, what you’re seeing is the platelets and the red blood cells which dominate everything else). And then you see a clearish yellow fraction, depending on how much lipids are in there (That’s the plasma, which is effectively the water).
  - About 60% of the ECF is Interstitial fluid  which is therefore only about 20% of all water in the body
    - This is the space that is between cells, but not in plasma, and it’s underappreciated for what it does
    - When you have a cold or you’re really, really sick, some people notice they actually might gain weight.
    - And then they might notice that if they’re really paying attention in the days after they’re starting to get better, not only are they losing weight again, but they’re peeing like crazy — That’s because of the expansion of that interstitial space.
    - When we’re sick, our blood vessels become very leaky — That’s where we have all the white blood cells and immune in cells do something called extravasate from the vascular system so that they can go and reach the tissues.
    - But that leaking is what leads to this swelling.
    - Extreme example: Somebody in the ICU may look very puffed up
  - The remainder of ECF is transcellular fluid (includes digestive tract fluid, cerebrospinal fluid, and other fluid filling epithelium-lined spaces) [roughly 5% of all water in body]

**\*Summary of water content and location**:

- About 67% of your total body water is inside cells.
- About 20% is in the interstitium (the area that exists between everything which can really expand when you’re sick)
- About 8% is in the vascular system.
- And about 5% is basically everything else, including CSF and things like that.

***Does this change based on body composition?***

- It will change based on body comp.
- Muscle is far higher in water content than fat.
- Fat tissue is about 10% water by weight.
- We refer to that as being “anhydrous,” without water.
- Muscle is probably 75% water.
- Take two individuals—One of them is 12% body fat. The other is 35% body fat.
  - There’s absolutely going to be a difference in how much water that person is carrying. The more muscular person has a higher amount of their body weight made up in water.

## Defining tonicity—isotonic, hypotonic, and hypertonic [11:45]

**What is tonicity?**

- Tonicity is essentially a measure of how the concentration of one solution compares to the concentration of another solution
- The way we think about this in human physiology is all relative to the concentration of a cell, because the cell is the dominant source of water
- Red blood cells are the easiest way to see this — i.e., *If you put a bunch of red blood cells into another fluid, how would the water move between those two?*

![](https://peterattiamd.com/wp-content/uploads/2022/03/f2-ama33-1024x564.png)

**Figure 2.** Effect of different solutions on red blood cells. [[wikipedia.org](https://en.wikipedia.org/wiki/Tonicity)]

What you’re looking at above are a bunch of red blood cells in a solution where the surrounding solution has a different concentration of solutes in it relative to the red blood cell

- **Isotonic** – This would be if you put those red blood cells into a solution that has the same tonicity as them
  - There’s a total balance between how much fluid goes from the outside solution to the cells and how much goes from the cells to the outside solution
  - The red blood cells don’t really change in shape at all
- **Hypertonic** – if you put the red blood cells into a very concentrate solution we would call that hypertonic
  - you would have a net flow of water from the red blood cells into that solution
  - *Why?* ⇒ Because just like water, always rolls downhill. Water always moves in the direction of the concentration gradient
  - There’s a natural equilibrium that’s always trying to happen where water is trying to equate the concentration across the permeable membrane of the cell.
  - In a hypertonic solution, the cells would shrivel up as they lose water into the more concentrated surrounding solution.
- **Hypotonic** – The opposite of hypertonic
  - If you put water into a hypotonic solution, there’s going to be an influx of water into the cells and they’ll eventually swell, swell, swell until they actually would rupture

NOTE: The tonicity of pure water is essentially zero

- if you just infused water into somebody’s vascular system, you would rupture all the cells in their body
- When we give IV fluids, we have to give them relatively close to isotonic solutions. They don’t have to be always isotonic
- They can be a little hypertonic in the case of head injuries, as you’re trying to reduce the swelling in their brains, or as you’re trying to suck fluid out.
- you can also give slightly hypotonic solutions if a person already has too many electrolytes on board. They have their sodium levels are getting too high and things like that
- But as a general rule, you’re starting from the baseline of giving an isotonic solution, which is 0.9% sodium chloride. And then you can adjust up or down with how much sodium chloride is in there and also how much other minerals, ions are in there along with things like glucose, which contribute to tonicity as well.

*What are some of the most important solutes for determining the tonicity of blood? Are there certain things that are more important than others?*

- There’s kind of like the 80/20 rule here, which is what contributes to the lion’s share of tonicity within the human physiologic system?
- The lion’s share of this is contributed by sodium and it’s counterion chloride
- Sodium chloride (salt) is what accounts for about 85% of the tonicity of the extracellular space.
- The other things that contribute to it are glucose and blood urea nitrogen
  - If you’ve ever had a blood test done, you’ve probably noticed one of the things that shows up on your chemistry panel says BUN (it’s always pronounced by its initials, BUN)
  - that’s the amount of nitrogen coming from the urea, which is part of the waste product of the urea cycle, which is how we get rid of excess protein
- The general formula which gets you very close to estimate a person’s plasma osmolality: Plasma osmolality = 2[Na+] + (Glucose / 18) + (Blood Urea Nitrogen / 2.8)
  - So it’s 2x the sodium concentration (it’s basically like saying the sodium and you double it up because sodium is always attached to chloride) **plus** the glucose concentration in milligrams per deciliter divided by 18 (and that’s correcting for the molar weight) **plus** the blood urea nitrogen concentration (similar units) divided by 2.8 (which again is a correction for the molecular weight) and that gives you something between about **275 and 295 milliosmoles per kilogram**
- The way I think about this is usually milliequivalents per liter or molarity, which is millimoles per liter (But again, for these nondissociable solutes, those are all equivalent)
  - For a non-dissociable solute, osmolarity (mOsm/L) = normality (mEq/L) = molarity (mmol/L).
    - So, osmolarity, normality, which is milliequivalents per liter or molarity, millimoles per liter are all equivalent
  - Peter will probably refer to them as milliequivalents per liter going forward, but he might refer to it as molarity

Above is complicated, so the thing you want to really remember is that **an isotonic solution to human plasma is going to be in the ballpark of about 280 milliequivalents per liter or millimoles per liter**

- And this will become important as we start to think about rehydration and where we need to be in relation to that

## Defining dehydration and volume depletion [19:00]

Many use the word dehydration and volume depletion interchangeably, but they’re technically not the same

**Dehydration** is a loss of water only, but without an appreciable loss of sodium or any other osmole

- By definition, if you are dehydrated, your tonicity should be going up — If you only lose water, but your osmoles don’t change. You’re concentrating them more.
- Since most of the water in the human body is present in ICF, pure water loss primarily affects intracellular volume and rarely has a major impact on circulatory volume

**Volume depletion**, which I think more accurately would be called hypovolemia, is a reduction of extracellular volume, but it also requires a loss of sodium as well

- Remember, sodium is the dominant osmole
- A normal extracellular sodium concentration is somewhere between 140 and 145 milliequivalent
- Sodium is the predominant determinant of our tonicity or the osmolality.

**Summary**:

- The point here is dehydration is just a loss of water
- Volume depletion is a loss of water along with electrolytes

*Clinically, where does this show up?*

- We see that volume depletion is often associated with a decrease in blood volume.
  - if you’re losing blood, you’re kind of losing wholesale volume water plus electrolyte
- But it doesn’t have to be that extreme, for example, if you’re just sweating like crazy—sweat is hypotonic so you’re disproportionately losing water to electrolytes
- When you’re sweating profusely, you’re in an area where it’s very hot and very dry, you’re losing a ton of water through that means you’re probably going to err more on the side of dehydration than volume depletion

## The health consequences of dehydration and volume depletion [21:45]

**In the hospital/intensive care unit**:

- - In the hospital, it’s a much bigger concern and the sicker the patient is in the hospital, the more of a concern it is
  - When someone is in the intensive care unit this is a huge priority to be monitoring their hydration status and their volume status
  - You would have catheters sitting inside the major veins in their body, like their vena cava and things like that where you would actually have a pressure transducer that tells you what their central venous pressure is.
  - Patients in the ICU often have catheters into their bladder
    - The reason we use urine output as such a sensitive indicator of volume status is that the kidney is one of the most sensitive organs to the volume in your body.
    - Your kidney weighs in the order of 2% of your body weight, maybe less, yet with each time that your heart pumps, about 20% of your blood flows through the renal system
    - So, this is a system that if anything changes in blood volume is the first place it shows up
    - And so, when a patient’s urine output goes down, that’s usually a very early sign that something is not right with their circulating volume

- *Ultimately, what can you see?*

- - Obviously, you can see kidney injury, you can see any sort of hypoxic injury. Meaning, injury that results from low oxygenation
  - If part of the reason for that is low blood volume, you’ll see cognitive impairment, dizziness, headaches, lightheadedness

**In the real world, outside the hospital…**

- urine output is a very good indication of your hydration status
- contrary to popular belief, the color of your urine is not always a great indicator
- It’s not always the case that your urine when you’re dehydrated becomes very dark
- ​​urine color is not particularly helpful

## How do we actually lose water? [25:30]

**Ways we lose water**

- **Urine** –
  - The most common way that water leaves our system is through urine
  - The kidneys are doing the lion’s share of the filtration and therefore the excretion of water
- **Sweat** –
  - We also lose it through our skin with sweat
  - It depends highly on the environment you’re in and your activity level, but you can lose a ton of water through that surface
- **Respiratory surface** –
  - One that most people don’t appreciate is through the respiratory surface
  - This becomes really important under two conditions when you’re very active and when the temperature and humidity are extreme
  - If you took a person’s lungs out of their body and unpacked every one of the little alveolar air sacks, it would cover a tennis court
  - The purpose of that is to facilitate gas exchange
  - But remember, if you think back to your biochem 101, *what is the final common pathway of metabolism?* ⇒ It’s carbon dioxide and water
  - So, we’re constantly exhaling CO2 and water vapor. And the hotter it is and the drier it is, the more we’re losing through that channel.
  - This is why an airplane can contribute to dehydration – you’re breathing in air that is exceedingly dry

*Other things that exacerbate hydration status*:

- Natural diuretics like **caffeine** and **alcohol**
- Alcohol inhibits something called antidiuretic hormone vasopressin
  - It’s just making you pee more than you need to pee, meaning it’s just more volume than you would excrete for that equivalent amount of water

## How much water do we need every day? [28:00]

- Basic guideline lines are not very helpful
  - If you look at sort of the nameplate guidelines, it says most adults who are relatively sedentary require two to three liters of water per day
  - Most of that comes from liquids, but some of that comes from food
  - Women, because they’re smaller, on average probably require a little bit less so it might say one and a half to two liters per day.
- The important thing is you’re able to titrate that to both your activity level and your environment, the ambient temperature, the humidity, etc.
- Then, of course, what are some other factors that could contribute to this?
  - How are you dressed in that environment?
  - And then being more active is going to require a much higher fluid amount

![](https://peterattiamd.com/wp-content/uploads/2022/03/f3-ama33-1024x750.png)

**Figure 3.** Water needs estimated from sweat loss predictions due to changes in physical activity and air temperature. [[Sawka, M. et al, 2005](https://www.researchgate.net/publication/7715558_Human_Water_Needs)]

*Looking at the figure above…*

- On your horizontal axis is just showing you temperature in two units (Celsius on the bottom and Fahrenheit on the top)
- You can see at the left end of that spectrum, so you’re sitting indoors, it’s air conditioned, which is to say it’s 20 degrees Celsius and call it 68 degrees Fahrenheit
- And you can see there’s not a huge difference between the fluid demands of a sedentary person versus an active person
- Even very active versus sedentary is a difference of about two liters per day
- It would say, “Hey, this sedentary person requires two liters under these conditions. The very active person is probably four and a half, maybe five.”

*But look what happens when the temperature goes up*:

- All of them, of course, increased their requirement, but the more active you are, the more of a hockey stick that is
- There’s probably not too many people that are out there being very active at 40 degrees Celsius or 104 Fahrenheit, but go just one notch down to 35 and 95 and, yeah, that’s an easy thing to do.
- NOTE – This was probably done at reasonable levels of humidity (like 50%, 60% humidity)
- Would be interesting to look at this at 30% or 40% humidity (which is actually probably more comfortable, because it’s not as humid as 70% or 80% humidity) but you’re going to see that water demand go up even more.

**How much water vs. salt do we lose when we sweat? Water and salt content of sweat.**

- Sweat is hypotonic — If you taste your sweat, it is salty
- The sodium concentration of sweat is going to be somewhere between 20 and 60 milliequivalents per liter, or millimole per liter
- Remember what Peter said earlier in the plasma, the sodium concentration is like 140 to 150 millimole — We’re talking about one fifth to maybe one third of the sodium concentration of your plasma is what’s coming out in sweat
- That variability is going to be a function of hydration status
  - The more hydrated you are, the lower that concentration is going to be
  - But no matter how salty your sweat tastes, it’s still a hypotonic solution, therefore, it’s depleting you a volume more than it’s depleting you of osmoles

## Signs of dehydration during exercise and how it can affect performance [32:45]

**Effect of dehydration on the heart**

- The heart works like a pump
- It has a pretty important characteristic, which is called *preload*
- Every time the heart is about to beat, it starts in a pumped position and then it contracts, and that’s called the ejection fraction – i.e., *how much blood does it eject with each contraction*?
- The heart is a muscle that likes to have some stretch in it before it contracts so it’s stronger when it has preload in it
- All things equal, if the heart has X amount of volume versus 1.2X amount of volume in it, it’s going to squeeze harder with that larger amount
- It also turns out that you can stretch it too much and then congestive heart failure where the heart gets totally stretched out – it then reverts to being weak and it’s pumped
- But from the standpoint of performance, you want more volume in the heart to increase what’s called contractility (and preload is a huge driver of contractility)
- As your *plasma volume goes down*, as you become either dehydrated or volume depleted, your preload goes down, therefore your contractility goes down

*What we see and how it affects performance*

- One of the first things we see in an individual who is dehydrated while they’re trying to perform is their heart rate has to go up
- And because contractility and heart rate are what produce cardiac output
- Two things that matter when it comes to athletic performance from a cardiorespiratory standpoint:
  - First is cardiac output – e.g., How much volume of blood can the heart circulate per minute?
    - We measure cardiac output in liters per minute
  - The second is at the tissue level — i.e., how much oxygen can be utilized?
  - So it’s cardiac output and VO2 (utilization of oxygen)
- The hydration thing isn’t real impacting VO2, unless you actually get into blood loss, then it is affecting it
- But where it’s really affecting it is on the cardiac output side, meaning it’s decreasing contractility because of preload and it’s driving up heart rate.
- Again, the first thing that you’re going to see in an athlete who’s dehydrated is a higher heart rate than they should have
  - For instance, the day after Peter gave blood, he did his zone 2 ride right before getting on the plane and his heart rate was 10 beats higher and his power was 20 watts lower
    - This tells Peter he was suffering at both ends — i) volume depletion and ii) he has lost a lot of red blood cells (meaning he was impaired on the VO2 side as well)

**Dehydration/volume depletion/glucose/electrolytes and heart rate**

- A higher heart rate than normal is one clue that dehydration might be going on
- But it’s important to note that other things can also impact heart rate:
  - Catecholamines, how much circulating epinephrine, norepinephrine, you have stress hormones
  - Recovery, just overall physiologic recovery will impact heart rate.
- Volume depletion is a big part of this
- All things equal and you’re running 5-10 beats per minute higher under the exact same conditions, one thing that should be on your mind is what is my hydration status relative to normal
- All of that is one component

*Glucose and electrolytes*

- There’s a totally separate component here which is if you are dehydrated, if you are not replacing volume, you’re likely not replacing glucose.
- Glucose is the most important thing we need to be replenishing while we’re exercising along with electrolytes because glucose is the substrate for ATP substrate
- If you’re dehydrated because you’re not taking it enough volume, you’re likely not taking in enough glucose either
- Even if you’re taking big glucose gels or something like that without sufficient water, you’re probably not facilitating the absorption of it.
- It gets a little bit murky as to how to assess performance because some of that performance reduction could also be sort of on the glycolytic side

**How dehydrated do people need to be to really see a hit in performance?**

- We can view this effect by looking at [data](https://physoc.onlinelibrary.wiley.com/doi/full/10.14814/phy2.12483) from cyclists in time trials
- First, it’s important to note that the higher the level you’re trying to perform, the more susceptible you’re going to be
  - By the time a person is losing 4% or 5% of their body mass in water loss, they’re pretty much hosed
  - At this point, they’re losing alertness, they’re cramping. They’re incredibly fatigued, they’re dizzy, they’re probably hyperthermic
- What’s more relevant is what’s happening to people when they lose even 1% to 2% of their mass under those conditions
  - you’re going to see basically everything go in the wrong direction
  - if you look at the studies where they’re taking dehydrated versus hydrated athletes and pushing them hard for a 90 minute time trial…
  - you’re looking at a heart rate difference of 15 beats per minute
  - core body temperature difference of a full degree celsius, if not slightly more
  - a difference in relative perceived exertion of about 15%.
  - going to take 15% longer to complete a given time trial
  - they’re going to have of easily 5% to 10% reduction in power output
- If you think about what the implications are for people competing in real world high level athletics, it’s clearly a very big deal.
- For instance, you see [F1 drivers](https://en.wikipedia.org/wiki/Formula_One) losing two to three kilograms during a 90 minute to two hour race and that is purely from water loss
  - Recently, [F1 driver Sergio Perez has a malfunction in his water supply](https://www.formula1.com/en/latest/article.i-was-completely-gone-says-perez-after-lack-of-drinking-water-put-him-in.2TZgY6EH7EGtEbStjqax1f.html#:~:text=Sergio%20Perez%20said%20a%20malfunction,to%20the%20podium%20in%20Texas.) which had a major impact on his while racing

## Is it possible to be overhydrated? [43:15]

**Overhydration**

- It’s possible to over hydrate, but it mostly happens in a hospital setting when you give somebody too much hypotonic IV fluid, can eventually really reduce the concentration of sodium significantly that you run into a condition called [hyponatremia](https://en.wikipedia.org/wiki/Hyponatremia)
- The normal sodium concentration in the plasma is about 140 to 150 milliequivalents
- If it gets kind of into the low 130s, that gets pretty dangerous
- We would call 125 to 135 would be moderate hyponatremia and that can result in dizziness, bloating, fatigue, nausea
- If it gets into the 120 to 125 range, the patients will start to be confused, they can vomit, they can even become [dyspneic](https://en.wikipedia.org/wiki/Shortness_of_breath) (meaning short of breath)
- If it gets below 120, if sodium concentration gets below 120, the person can have seizures ultimately going into a coma and the ultimate cause of death here is [cerebral edema](https://en.wikipedia.org/wiki/Cerebral_edema)

***When can overhydration happen during exercise?***

- When people are exercising in typically high heat, which is requiring them to drink a lot and they’re doing so over a long period of time
- A few times a year, you might hear about a story of somebody who died from hyponatremia during a marathon or an iron man
  - It’s usually someone who is out there exercising three, four, five hours. It’s usually under a pretty high heat condition, so they are a lot of water
  - when they’re sweating, they’re also losing sodium, but they are replacing it with probably just water altogether
  - So, they’re taking in all of this water. They’re not absorbing all of it, but they’re still absorbing a decent amount of it. And they’re constantly diluting, diluting, diluting their plasma
  - The heat isn’t necessary to get hyponatremia. It exacerbates the need for you to drink and that’s when you can really get into trouble
- If you’re exercising for an hour, water is fine.
- But if you’re exercising a lot more than that, start thinking about the **importance of bringing in the sodium that you’re going to need to offset the risk of hyponatremia**

## Electrolytes: benefits and when to include them in rehydration fluids [47:00]

**Peter’s personal fluid consumption**

- Regular water mostly
- Bubbly water
- Occasionally a diet soda (diet Sprite being his favorite)
- It’s pretty unusual for him to drink liquid that has any form of calorie or electrolyte in it, because his days of long activity/exercise are over
- In his long endurance exercise back in the day, he was more disproportionately focused on the caloric side (glucose) of what was coming in as opposed to the electrolyte

**Electrolytes in our fluid**

- Today, there are no shortage of products/sports mixes
- Dividing these into two categories:
  - 1 – from an electrolyte standpoint
  - 2 – From a carbohydrate standpoint
- Those are the big variables you have to play with for both the replacement of the electrolyte and the carbohydrate, but also to impact the tonicity of the solution you’re drinking
- In terms of electrolytes, sodium the most obvious component there because that’s the thing that we are dominantly losing
  - Most of our intracellular tonicity is determined by the extracellular concentration, the plasma concentration of sodium
  - If we say that, that’s about 140 to 150 milliequivalents, we’re sweating out, call it 20 to 50, 20 to 40 of that. You always want to be thinking about replacing sodium
  - Everything else is kind of a rounding error
- There are two other electrolytes that are commonly added to mixes: 1) Magnesium and 2) Potassium
- Peter says magnesium should be replaced outside of exercise
  - Peter is a big fan of slow mag because it doesn’t upset the GI system, it’s fully absorbed, but absorbed slowly, and he wants to get his magnesium outside of my exercise
- Potassium is something that shows up in sports drinks and it certainly is an important electrolyte
  - First problem with potassium is you can’t give potassium as freely as you can give sodium
  - And you don’t really want to, because most potassium sits inside the cell whereas most sodium sits outside the cell. So, the one we want to be replacing is sodium.
  - Secondly, if you get potassium wrong, it can be deadly
    - Now, this is hard to do outside of the hospital
    - It’s unfortunately very easy to kill somebody by giving them too much potassium. And walking into a grocery store and buying a little potassium supplement is much harder because they’re so deliberately tuned down to have very low potassium in them
- When you look at what determines the electrolyte content of sports mixes, you’re going to see it’s virtually all sodium and then some of them will have magnesium and potassium

## Glucose: benefits and when to include it in rehydration fluids [51:15]

**Do you need glucose in your water?**

- Short answer: It depends on the duration of your activity
- For relatively short duration activity, you really don’t need glucose as you should have sufficient muscle glycogen and liver glycogen to meet all your needs
- Peter says for him, any activity up to about two hours at pretty decent exertion, he will not need glucose
- In the extreme example, if he were trying to break the world record in a marathon, he would absolutely need glucose under those conditions
- But if he’s lifting weights pretty hard for two hours, he would likely need 700 milliliters to a liter of fluid
  - If there’s glucose in it, that’s fine, but it’s not as necessary is having the electrolytes
- Today, if Peter is doing zone 2 for an hour, he’s either doing plain water or water + electrolytes, but no glucose
- Note, drink mixes usually taste better with glucose, and that usually leads to more water consumption if it’s tasty
  - Be careful of this, because tasty glucose drinks can start to creep into our sedentary lifestyle which is not good

> “That’s where I think you really have to be careful about drawing a hard line on drinking glucose when you’re not exercising. It really isn’t a good idea.” —Peter Attia

- If you feel that you need a more isotonic solution—because remember water is the most hypotonic solution there is
- SO if you feel like you need to really increase volume, not just water, then you’re better off just drinking, in my opinion, an electrolyte solution that’s free of glucose.

**One other point to make**:

- when you’re exercising, there is a benefit to having glucose in there, in addition to the electrolytes, because they facilitate the absorption of each other faster
- that’s where there is truth to some of the marketing claims you see where adding glucose at the right amount to an electrolyte drink will speed up the absorption
- Today, we have very good data, and the data is that a glucose containing solution of about 5% to 6% is the sweet spot
  - Anything that has a higher concentration than that is basically going to be a little bit too rich
  - And in fact, it’s going to start to become hypertonic
- Isotonic is going to be about that 5% to 6% range

***The mistake that a lot of people make…***

- Many people err on the side of too much glucose
- You see people out there for a 5k fun run, and they’ve got two gels that they’re squirting in their mouth and they’re drinking a Gatorade — that’s just way too much
- First of all, Gatorade and Powerade alone is about an 8% solution so they are already slightly higher than isotonic
- Then when you go and add two goos to it, you’ve basically created the most hypertonic solution imaginable — you’ve taken it from 8% to probably 20%.
- The reality is, you don’t even need those calories to run a 5k
- You should just be drinking your volume with electrolytes

## The ability of glucose to improve absorption of sodium [58:45]

**One benefit possibly of glucose is it makes it easier to absorb sodium**

![](https://peterattiamd.com/wp-content/uploads/2022/03/f4-ama33-775x1024.png)

**Figure 4.** Transmembrane cotransport of sodium and glucose. [Figure from Human Physiology. An Integrated Approach, 6th ed.]

- You’re looking here at kind of a cross section of a cell, but the top of the page there is where you have glucose and sodium and they’re in the lumen, which means they’re kind of still outside the body
  - Technically, they’re in the body, but they haven’t been absorbed into the vascular system yet.
- The concentration of glucose there is low relative to the concentration of glucose in the body
  - To get glucose in, it has to move up its gradient
- Conversely, sodium concentration is higher there than it is on the inside of the cell
  - Sodium concentration, intracellularly, is very low, just as potassium concentration outside of the cell is very low
- So, it turns out that there is this very nice synergy energetically by bringing glucose in and coupling it to bringing sodium in
- When you move sodium and glucose across their gradients, which are opposite, one is up, one is down, you facilitate that better
- it turns out that two sodium ions moving with one glucose molecule is a very efficient way to do this
- That movement of sodium into the cells also draws water into the epithelial cell, which then moves water into the extracellular fluid as sodium is then pumped into the extracellular system via that sodium, potassium pump at the bottom of the picture, what we call the basolateral cell.
- For these reasons, sports drinks should really be hypotonic to maybe almost isotonic
- And they should probably contain both glucose and sodium if you’re trying to maximize the amount of water that’s going to be absorbed and also, of course, provide some amount of glucose
- All of this is to say that sports drinks should probably be hypo to isotonic solutions, containing glucose and sodium
- Soft drinks and things like that are obviously very hypertonic. And paradoxically, they can exacerbate dehydration in the long run, because they get this gradient wrong
- So, fluid moves in the wrong direction. It triggers what’s called water secretion. Water going from the inside of the body back into the lumen.

## The type of carbohydrates in drinks than actually impact performance [1:02:00]

***Do the various types of carbohydrates in drink mixes matter?***

- Definitely, especially through the lens of performance
- There were days when people thought it should just be pure glucose
- Alternatively, there were sports drinks that were made with pure fructose
  - You could have isocaloric mixture of all fructose versus all glucose, and they would behave very differently
  - Why? ⇒ The fructose one would be a lot sweeter
  - But the fructose one would actually result in a lot of gastric distress, even at isocaloric levels relative to glucose. There was just more difficulties absorbing it and emptying from the gut.
- Then you also look at other types of glucose that are complex such as [maltodextrin](https://en.wikipedia.org/wiki/Maltodextrin)
  - Maltodextrin, common in sports drinks, is just a huge oligomer made up of glucose
  - it’s effectively like glycogen and it’s easier to get more glucose in through maltodextrin because it does exit the stomach a little bit slower

*Maltodextrin plus fructose*

- Today, the sports drink space is trending towards maltodextrin + fructose mixes
- They’ve just empirically tested a bunch of different ratios out.
- So, fructose to maltodextrin of 0.5:1, 0.8:1, 1.25:1 where you have more fructose than maltodextrin.
- Empirically, a ratio of fructose of 0.8:1 resulted in the best sprint power, the best carbohydrate oxidation rates, and the best oxidation efficiencies comparatively [[O’Brien et al., 2013](https://www.researchgate.net/publication/255958218_Fructose-Maltodextrin_Ratio_Governs_Exogenous_and_Other_CHO_Oxidation_and_Performance)]
- What you’re looking at now is solutions that are slightly less sweet than sugar. Because again, fructose to maltodextrin of 1:1 or 1.2:1 would be where you would sort of think of like a high fructose corn syrup
- This is just all empirically optimized to find the best absorption, the easiest absorption and the highest utilization and oxidation of the maltodextrin

## Sodium during workouts: is there an optimal ratio of carbohydrate to sodium? [1:05:00]

***How much sodium intake is ideal?***

- When you’re sweating, you’re losing 20-60 millimole per liter, which is about a third to a fifth of what’s going on in your blood
- So you do need to be replacing sodium
- Ideally, you want a hypotonic solution given that you are losing a hypotonic solution
- Now, the question becomes: *how do you figure out how to mix these two?*
- We’ve just established that mixing glucose with sodium increases the absorption of both along with water
- We’ve established that you need sodium because you’re losing it,
- Obviously, we need glucose for long enough activity amount, but *how much?*

An interesting [study](https://www.sciencedirect.com/science/article/abs/pii/S0022347685806612) looked at this:

![](https://peterattiamd.com/wp-content/uploads/2022/03/f5-ama33-966x1024.png)

**Figure 5.** Absorption and secretion of water and sodium as function of glucose/sodium ratio of perfusing solutions. [[Lifshitz and Wapnir, 1985](https://www.sciencedirect.com/science/article/abs/pii/S0022347685806612)]

- The lines are drawn on top of the data points
- On the Y axis, you’re looking at absorption or secretion of water through the kidney
- Anything below the X axis means water is actually being lost from the body secreted out to the kidneys. It will exit the body as urine.
- Anything above the line, above the X axis is the opposite — that water is being absorbed
- We want to be in the **absorbed** camp

Then the next question is, *do these absorptions or secretions vary as a function of the glucose to sodium concentration?*

- On the X axis, what they’ve done is they have in increased the glucose to sodium concentration
- At the far end of it, it’s 0.0 where the X axis meets the Y axis (assume it’s a solution of just sodium and no glucose)
- But as you add glucose and you start to increase the concentration of glucose over sodium—initially you have an uptick in water absorption before it starts to come down
- Sodium absorption just starts going down as you’re diluting it with glucose.

The question is: *where does water absorption maximize?*

- The conclusion of this study was that at a ratio of about 2.0 you see the maximal water absorption (The dotted line represents water absorption and it peaks when the sure of glucose  to sodium is about 2.0)
- But a ratio of 2.0 can be different things:
  - It could be glucose concentration of 200, sodium concentration of 100
  - What turns out to be the right number?
    - it turns out because now we want to abide by another principle, which is we want to be just under isotonic
    - so it turns out that about 110 to 120 millimole of glucose and about 60 millimole of sodium gets us there
    - Because again, there’s other osmoles in the solution here, so you’re also having the chloride as well.
    - they also looked at potassium chloride that had a little bit of bicarb in there. So, I wouldn’t be wed to the 110 versus 60
- The point is look for a glucose to sodium ratio of about 2:1 is going to maximize your water absorption
  - From a commercial standpoint, the product that Peter has seen that comes closest to that is [Liquid IV](https://www.liquid-iv.com/)

## Pros and cons of sports drinks and which ones stand out [1:09:15]

**A note about taste**

- Unfortunately, people tend to gravitate towards ones that taste best
- Peter has experimented with a ton in recent months and says he can’t stand half of them for how they taste – and this leads to him just not drinking much during a workout
- *“​​Doesn’t really matter if it’s the perfect drink if you can’t drink it*.” says Peter

**What Peter doesn’t like…**

- Peter does not like anything about the Gatorade/Powerade type drinks (except for maybe the taste)
- First off, they are hypertonic – the fact that they have close to 400 milliosmoles just tells me that this is not a winning solution
- It tastes good. You’ll drink a bunch of it, but it’s kind of in the long run, more dehydrating
- And for many people, it can upset their gut
- In the end though, that much carbohydrate is just not necessary

**Better options…**

- [LMNT](https://drinklmnt.com/)
- [Nuun](https://nuunlife.com/)
- [Liquid IV](https://www.liquid-iv.com/)
- It’s probably the case that Liquid IV results in the greatest amount of water absorption because it’s pairing and coupling glucose to sodium
- It’s also providing you with glucose—so if you’re doing something where you **need** the glucose, then that’s probably the one to turn to.
- Conversely, if you just need hydration…Even though it may not be as good in terms of rapid absorption as Liquid IV, Peter thinks LMNT and Nuun probably offer you something better in that you’re still getting the electrolytes, but you’re not necessarily getting the excess glucose that you might not need

> “I always prefer to get my glucose through food for all the reasons that we’ve talked about from a metabolic perspective.” —Peter Attia

*Dental issues with Gatorade/Powerade*

- if you talk to any dentist, they will tell you people that sit around drinking sports drinks all day have horrible teeth
- There’s something very destructive to your mouth when you’re just sitting there sipping on a Gatorade all day

## How much hydration comes from the food we eat? [1:14:30]

*How much water do we get throughout a day through eating food?*

- It depends on the food
- The more fat you’re eating, the less water you’re getting
- The more anhydrous the food, the less water you’re getting
- general rule of thumb, you probably get 20% to 30% of your water intake through food though.

## Is there a downside to drinking electrolytes throughout the day even without exercise? [1:15:15]

***If someone doesn’t exercise on a given day, are there repercussions to drinking fluids with added electrolytes? Is it beneficial because it’s helping with the electrolyte hydration for the next day?***

- Fluids with electrolytes only (e.g., no glucose) are much better than something with glucose (e.g., Liquid IV)

*What about coconut water?*

- “I*t might be actually that coconut water is actually a pretty decent sports drink under the right conditions, but I do think the sugar concentration is pretty high and I’d probably err on the side of some of the other ones that have been more scientifically put together*.”

*Hot yoga and sauna hydration*

- Rehydrating with an electrolyte solution would be beneficial after hot yoga or sauna since you sweat so much

*CGM data from sports drinks*

- Nuun and LMNT don’t seem to have any bearing on blood glucose
- Liquid IV certainly does — It might be a 4% solution, so it’s half out of Gatorade. You’ll see a bump in glucose, for sure if you’re not exercising while you take it.

## Key takeaways related to hydration [1:18:15]

**Summary/Takeaways**

1 – Tonicity

- Always think about the difference between what’s hypotonic, what’s isotonic, what’s hypertonic
- I.e., How is what I’m drinking concentrated relative to that which I’m trying to replace?

2 – Sodium dictates your hydration status

- Think about sodium being the most important solute in determining the hydration status in water
- Sodium dictates your hydration status and where your body water is distributed
- Most of the time when people talk about dehydration, what they’re really talking about is volume depletion which involves not just a loss of water, but a loss of sodium
- If you’re thinking about how to replace that in a setting where you’re not eating (fasting) and therefore you’re not getting sodium that way, you want to have some sodium in the solution that you’re drinking.

3 – A good rehydration strategy requires some replacement of water salt in the proportions that they’ve been lost

- This generally means hypotonic solutions
- If you’re losing about a third to a fifth of the amount of sodium in your perspiration that you have inside your plasma
- Replacement water by itself can just be leading to more urine production — Your kidneys are getting it, but they’re secreting it, not absorbing it.
- In really severe situations can actually lead to hyponatremia, rare but potentially fatal.

4 – Carbohydrates are an important component of rehydration for long, challenging endurance sports drinks because you’re losing glycogen, and because it also facilitates water absorption through that co-transporter of glucose and sodium

- You definitely want to avoid hypertonic solutions such as soft drinks or even highly concentrated drinks
- Gatorade is just a lousy solution here, because it’s hypertonic as well. All they do is trigger intestinal secretion of water and they can ultimately paradoxically result in dehydration.
- The effect sugar in liquid drinks has on the liver is terrible especially when people are consuming these things outside of exercise (see [Rick Johnson episode](https://peterattiamd.com/rickjohnson2/))

5 – Find your strategy

- Just tinker with this stuff, you’ve got to figure out how it works for you
- For the Liquid IV, LMNT, Nuun, and other mixes… mixing them according to the directions that they provide is smart as they’ve generally done a lot of work on this and they sort of know the optimal plays
- For Peter personally, he actually dilutes the mixes just slightly to remove some of the flavor since he actually prefers the taste of water when exercising
- If using glucose in your fluids, look for the 2:1 glucose to sodium concentration

> “Anytime I’m not drinking [plain] water, there’s really a purpose that I’m trying to serve in terms of glucose and/or electrolyte replacement and improving hydration status and water absorption.” —Peter Attia

§

## Selected Links / Related Material

**Peter’s Instagram post about his face plant**: [@peterattiamd](https://www.instagram.com/p/CWOFMZfgCF_/) [4:45]

**Famous commencement speech by David Foster Wallace**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI&t=251s) | Lynn Skittle (youtube.com [11:30]

**Bruce Lee’s “Be like water” quote**: [Bruce Lee’s “Be Like Water” Quote Explained](https://screenrant.com/bruce-lee-be-like-water-quote-meaning-explained/#:~:text=Bruce%20Lee%20said%20to%20%22empty,Be%20water%2C%20my%20friend%22.) | (screenrant.com) [11:30]

**Time trial study in cyclists looking at the impact of dehydration on performance**: [The effect of dehydration on muscle metabolism and time trial performance during prolonged cycling in males](https://physoc.onlinelibrary.wiley.com/doi/full/10.14814/phy2.12483) (Logan-Sprenger et al., 2015) [39:00]

**Netflix documentary about Formula 1**: [Formula 1: Drive to Survive](https://www.netflix.com/title/80204890) | (netflix.com) [40:30]

**Sergio Pérez water malfunction in his F1 race showing effects of dehydration**: [‘I was completely gone’ says Perez after lack of drinking water put him in ‘surviving mode’ in US GP](https://www.formula1.com/en/latest/article.i-was-completely-gone-says-perez-after-lack-of-drinking-water-put-him-in.2TZgY6EH7EGtEbStjqax1f.html#:~:text=Sergio%20Perez%20said%20a%20malfunction,to%20the%20podium%20in%20Texas.) | (formula1.com) [41:30]

**Crossover study that found an ideal ratio fructose to maltodextrin in drink mixes to be 0.8:1**: [Fructose–Maltodextrin Ratio Governs Exogenous and Other CHO Oxidation and Performance](https://www.researchgate.net/publication/255958218_Fructose-Maltodextrin_Ratio_Governs_Exogenous_and_Other_CHO_Oxidation_and_Performance) (O’Brien et al., 2013) [1:03:45]

**Study looking at absorption and secretion of water and sodium as function of glucose/sodium ratio of perfusing solutions**: [Oral hydration solutions: Experimental optimization of water and sodium absorption](https://www.sciencedirect.com/science/article/abs/pii/S0022347685806612) (Lifshitz and Wapnir, 1985) [1:05:45]

**Sports drink mixes Peter prefers with electrolytes**: [1:11:30]

- *With glucose + electrolytes*: [Liquid IV](https://www.liquid-iv.com/)
- *Just electrolytes (no glucose)*:
  - [LMNT](https://drinklmnt.com/)
  - [Nuun](https://nuunlife.com/)

§

## People Mentioned

- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [11:15]
- [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) [11:30]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [11:30]
- [Sergio Pérez](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez) [41:30]
- [Layne Norton](https://twitter.com/BioLayne?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [42:30]
- [Floyd Mayweather](https://en.wikipedia.org/wiki/Floyd_Mayweather_Jr.) [58:00]
- [Manny Pacquiao](https://en.wikipedia.org/wiki/Manny_Pacquiao) [58:00]
- [Rick Johnson](https://peterattiamd.com/rickjohnson2/) [1:20:30]

§