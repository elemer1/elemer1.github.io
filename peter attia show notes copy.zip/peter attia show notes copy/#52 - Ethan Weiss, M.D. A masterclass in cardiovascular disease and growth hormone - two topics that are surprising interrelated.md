# #52 – Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone – two topics that are surprising interrelated

**Source:** [https://peterattiamd.com/ethanweiss/](https://peterattiamd.com/ethanweiss/)

---

In this episode, Ethan Weiss, Hopkins trained preventative cardiologist at UCSF, discusses two topics that on the surface may seem unrelated which is cardiovascular disease, and the role of growth hormone and IGF in disease. Ethan provides a masterclass in everything from acute coronary syndrome to all of the complex nuances around stent placement, as well as how calcium scores and results from CT angiograms shape his treatment of patients. He also shares how his idea to study the sex differences in blood clotting as it relates to coronary disease lead him to pursue the field of endocrinology, and specifically what he found with respect to the effect of growth hormone and IGF on the liver, the brain, and overall human longevity.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ethanweiss/the_Drive_public.png)

Play

#52 - Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone - two topics that are surprising interrelated

#52 - Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone - two topics that are surprising interrelated

1x15s30s

0:002:54:11

## We discuss:

- Mutual love for hockey [7:15];
- Ethan’s background and interest in cardiology [13:15];
- Clinical definitions of a heart attack, clotting, and plaque: What causes the acute event? [24:15];
- Defining coronary disease and myocardial infarction: The evolving nomenclature [32:00];
- What happens when someone comes to the ER with a STEMI (ST elevation myocardial infarction)? [47:15];
- Stents [54:45];
- Treatment protocol for both acute and chronic coronary artery disease: History, controversy, and important distinctions [1:06:30];
- Using stents to treat stable angina: What we learned from the COURAGE AND ORBITA trials [1:15:30];
- The “art” of longevity: The challenge of preventative medicine and understanding risk [1:31:45];
- Understanding CAC scores, and CT angiogram results [1:40:15];
- How sex differences in clotting and heart disease got Ethan interested in growth hormone and IGF [2:01:00];
- Impact of growth hormone on the liver [2:07:00];
- Growth hormone and insulin sensitivity [2:18:00];
- The role of GH and IGF on chronic disease and cancer [2:23:30];
- Will taking growth hormone promote longevity? [2:32:30];
- GH and IGF as a treatment for early stage dementia? [2:34:30];
- What happens to IGF while fasting and what about fasting improves longevity? [2:35:15];
- The importance of becoming scientifically literate and making science more exciting for future generations [2:38:30];
- Ethan’s new company: Keyto [2:43:45]; and
- More.

§

## Show Notes

## Mutual love for hockey [7:15]

- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) (Ethan owns a signed [Edmonton Oilers](https://en.wikipedia.org/wiki/Edmonton_Oilers) jersey)
- [Chicago Blackhawks](https://en.wikipedia.org/wiki/Chicago_Blackhawks) (first game Ethan ever attended in 1979 with his father)
- [Washington Capitals](https://en.wikipedia.org/wiki/Washington_Capitals) (Ethan’s favorite team)
- [New York Islanders](https://en.wikipedia.org/wiki/New_York_Islanders) (beat the Oilers for the [Stanley Cup in 1983](https://en.wikipedia.org/wiki/1983_Stanley_Cup_Finals))
- When Peter was 10-years old he asked for cash for his birthday so he could by a Gretzky jersey (he went with a [Oilers home jersey](https://www.authenticoilerstore.com/UFiles/nhl/images/oilers_194.jpg))
- [Toronto Maple Leafs](https://en.wikipedia.org/wiki/Toronto_Maple_Leafs) (Peter’s hometown team that he never really loved)
- [Mark Messier](https://en.wikipedia.org/wiki/Mark_Messier) (Former Edmonton Oiler that Peter got to have dinner with recently)
- [Northlands Coliseum](https://en.wikipedia.org/wiki/Northlands_Coliseum) (former home of the Oilers)

## Ethan’s background and interest in cardiology [13:15]

- Ethan “grew up in the hospital”
- Ethan’s [father](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0000061/james-weiss) is a cardiologist at Johns Hopkins
- Ethan eventually went on to complete med school and residency on Johns Hopkins
- Now a cardiologist at UCSF since 1998

Did he always want to do medicine?

- No, actually was uninterested in science until happenstance
- Went to Vassar to study music but fell for science after taking a class that piqued his interests

Med school at Johns Hopkins

- Surrounded by incredibly smart people
- One of the only non “hard science” students
- Hopkins was an intensely challenging environment but his fellow classmates were really supportive
- Classmates: David Sabatini, Dave Brett, Andy Cameron
- “Going to med school at Hopkins in that era was like playing for the Yankees.”
- Peter and Ethan both fondly recall “Sunday School” and being critiqued by famous surgeon John Cameron
- Hopkins in the 1990s was some of the hardest times
  - you’d stay up all night taking care of patients
  - basically did nothing but sleep or be in the hospital
  - A lot of active HIV disease at the time which is basically ICU level care and only people there were you and 2 other residents
- “*You look back on it and you think, ‘I don’t know how I survived it,’ but in retrospect it was really fun*.”

How did he pick cardiology?

- His intention was to avoid it as to not follow his father exactly
- But he became extremely fascinated when a series of patients in their late 30s, early 40s, who had myocardial infarction (heart attack) yet they were relatively **absent any obvious risk factors**
- Decided he wanted to study the pathogenesis of unstable antigen (or MI) in young people without risk factors
- Worked in the lab of [Pascal Goldschmidt](https://en.wikipedia.org/wiki/Pascal_J._Goldschmidt) and it was that experience which was a “*career defining for me, that drove my clinical interest*”

## Clinical definitions of a heart attack, clotting, and plaque: What causes the acute event? [24:15]

- 99% of heart attacks in this country happen because of a ruptured atherosclerotic plaque
- Many people mistakenly believe that a heart attack occurs because their “pipes” get narrower and narrower until in closes
- In recent history there was a debate about whether a clot in the artery was primary or secondary to a heart attack…  *Was it there before or after the person died*?
- The work of [Michael Davies in the late 1970s and early 1980s](https://www.ncbi.nlm.nih.gov/pmc/?term=(Davies+MJ%5BAuthor%5D)+AND+(%221975%22%5BPublication+Date%5D+%3A+%221989%22%5BPublication+Date%5D)) proved the idea that [plaque rupturing was actually causal](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC481773/)
- In the 1980s they began aspirating out a clot using a suction catheter in people who came to the ER with a heart attack, and they got immediately better
- It was the first demonstration that this clot event was the primary cause of most heart attacks

**Michael Davies [paper](https://heart.bmj.com/content/heartjnl/82/3/265.full.pdf)**

- autopsy of somebody who presents with a heart attack and died
- By looking at the histology, you can tell how many times the plaque has actually ruptured (much like you’d look at the rings to figure out the age of a tree)
- On average these people in that first series had had **seven plaque ruptures** in their culprit artery before they died

![](https://peterattiamd.com/wp-content/uploads/2019/05/starys-book-cover-897x1024.png)

**Figure 1. Book cover Herbert Stary’s Atlas of Atherosclerosis Progression and Regression showing plaque rupture “rings”.** Image credit: [amazon.com](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538?ie=UTF8&ref_=asap_bc)

*What is it about plaque that causes the heart attack?*

- The contents of atherosclerotic plaque: rich with lipids and inflammatory cells
- But the thing that causes the heart attack is the [**macrophages**](https://en.wikipedia.org/wiki/Macrophage)
- White blood cells which carry around this protein called [tissue factor](https://en.wikipedia.org/wiki/Tissue_factor)
- Which is basically the instigator/trigger for the clotting cascade
- Tissue factor is a wound healing signal ⇒ If you cut yourself, we have tissue factor underneath the epithelium, so when the blood sees tissue factor, there’s a biochemical reaction that results in a blood clot
- Epoxy analogy: “*It’s sort of an epoxy. You know those epoxies that come in two separate tubes? Taken alone they’re not sticky, but when the tube combines them, it becomes like rock solid glue. The macrophage exposes the tissue factor. Now, the blood passing through becomes the other tube of the epoxy, and boom, you get this acute brick.*”

[**ISIS-2 paper**](https://www.ncbi.nlm.nih.gov/pubmed/9563981) **in 1998**

- Compared aspirin and streptokinase versus aspirin alone in patients who presented with heart attack
- Streptokinase is what’s called a thrombolytic ⇒ it’s a natural substance that we make that dissolves clots (anticoagulant)
- Clotting is a balance between pro forces and anti-forces
- You get a cut, your body clots the blood at the site of injury to keep you from bleeding out
- But it has to be very specific, otherwise you will clot everywhere and die
- Example,
  - If you knock out procoagulants in a fetal mouse, they will die right after being born
  - If you knock out anticoagulants, they will die in the womb

## Defining coronary disease and myocardial infarction: The evolving nomenclature [32:00]

A heart attack/myocardial infarction (MI) was defined by a constellation of things:

- Chest pain (elephant sitting on chest)
- Radiating pain into left arm, neck, etc.
- Nausea
- Changes in the electrocardiogram
- Presence of biomarkers
  - Creatine kinase (CK) = an enzyme that’s leaked out of the sides of the muscle cell when there’s damage to it
  - You can find CK in the blood after someone runs a marathon
  - The “MB fraction” is a type of CK more specific to the cardiac muscle

**Electrocardiogram (EKG)**

*What does an EKG look like?*

- Every time the heart beats there’s a signature that can be measured electronically when you put leads on the chest
- [P wave](https://en.wikipedia.org/wiki/P_wave_(electrocardiography)) = little wave that symbolizes when the atrium is doing its contraction
- [QRS spike](https://en.wikipedia.org/wiki/QRS_complex) = This is a big signal due to the ventricular contraction
- [T wave](https://en.wikipedia.org/wiki/T_wave) = another little wave showing ventricular repolarization
- Then it repeats

![](https://peterattiamd.com/wp-content/uploads/2019/05/ECG-1024x1010.png)

**Figure 2. Electrocardiogram.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Electrocardiography)

*History of the treatment of MI*

- Used to be, literally put somebody in bed
- Then with advent of beta blockers… basically forced “pharmacological bed rest”
- Then aspirin
- Then streptokinase (clot dissolving medicine)
- Then inserting [balloons](https://en.wikipedia.org/wiki/Balloon_catheter)
- And then came stents

*What are the signs in an EKG that someone is having/has had a heart attack?*

- As a med student in the 90s, MI was defined by the presence or absence of the [Q waves](https://en.wikipedia.org/wiki/QRS_complex#Q)
- You’d put 12 leads on chest, arms and legs to create a three dimensional picture of the heart

⇒ Q-wave MI

- If after somebody had a heart attack they developed a Q wave in certain leads that would signal a Q-wave myocardial infarction (transmural cell death ⇒ occurring across the entire wall of an organ or blood vessel)

⇒ Non-Q wave heart attack

- Presented with the same clinical picture (chest pain, biomarkers like CK and myoglobin)
- But they didn’t have this Q-wave, so they were called non-Q wave myocardial infarction.

**Unstable angina and stable angina**

Unstable angina

- An unstable angina was thought to be the same pathophysiology (ruptured plaque)
- But it was thought to be an incomplete cessation of blood (clot was a full blockage… still a little bit of a blood flow getting through)
- Back then (in the 90s) if you had chest pain and the EKG changes, but you didn’t have the biomarkers… you were said to have *unstable angina*

Stable angina

- There is a lesion that would narrow an artery, but you’d only get chest pain when you increase demand (demand ischemia)
- This blockage that’s would be 75-80% of the diameter of the artery
- Example,
  - You go out and you do something that caused you to increase your demand (walk a flight of stairs)
  - You need to build deliver more oxygen to the tissue but you can’t do that
  - The way coronaries work physiologically is that they augment blood flow by dilating (That’s why people are told to take [nitroglycerin](https://en.wikipedia.org/wiki/Nitroglycerin) if they’re having chest pain)
  - Once you stop the physical exercise (or you take nitroglycerin), the symptoms go away

*Peter summarizes unstable vs. stable:*

“It’s not just that in the unstable case, you may have some actual plaque rupture. It’s this idea that in the stable case, it’s the inability to dilate the target lesion and the plausible steal of blood. . .There hasn’t been a new injury, but under a certain period of stress, you’re able to basically see this area that otherwise can’t function fully.”

**The challenge of predicting risk**

- Stable angina doesn’t typically kill people, but it is the thing that we spend the lion’s share of our time thinking about and talking about in treating
- What kills you is the acute thing
- Most western adults will have coronary disease by the time they get to be 50 (looking at a CT, there will be plaque)
- But it’s unlikely that the amount of plaque is obstructing blood flow either significantly at rest or with exertion in a 50 year old
- Over time, however, as that plaque gets bigger, it’ll start to become apparent to me that when I’m walking, increasing my demand, I’m not able to deliver oxygen, so I’ll become symptomatic
- The point at which we say most **people become symptomatic is when the percent diameter stenosis or blockage is about 70%.**
- We have focused on this 70% number because it’s what we can measure clinically… *but there’s nothing to suggest that there’s a magic in that number that would put somebody at a greater risk, as opposed to somebody who had 50%*
- The work of Michael Davies, much of the fatal plaque rupture events happened in arteries [**that had only 30 or 40%**](https://www.ncbi.nlm.nih.gov/pubmed/6709008)

*The paradox of stable angina*

- People can have 90% inclusions and be highly symptomatic, but just incredibly stable
- The more the stenosis increases, the more likely it tells you that the downstream musculature has found some other way to acquire oxygen
- So someone who’s walking around the 95% stenosis is very likely to suffer death *in the case of that plaque rupturing*
- But the fact that it hasn’t ruptured yet makes it seem unlikely it will rupture in the future

*Are we much better at predicting heart attack risk today than 20 years ago?*

- “I don’t think so.”

**How the nomenclature has evolved to today [44:00]**

“*The nomenclature evolved over the past 15 or 20 years [because of] the advent of interventional cardiology.*”

ST elevation

- It takes days to see a Q wave, but in the acute setting, there’s a defining feature that seems to predict whether there was a complete loss of blood flow ⇒ called [ST elevation](https://en.wikipedia.org/wiki/ST_elevation)
- [ST segment](https://en.wikipedia.org/wiki/ST_segment) is a flat line that connects the end of the S wave to the beginning of the T wave
- If the ST segment gets increased above a couple of millimeters in more than one lead… then that signals a complete blockage of an artery (this is known at STEMI)

![](https://peterattiamd.com/wp-content/uploads/2019/05/ST-elevation.png)

**Figure 3. Elevation of the ST segment, between the S wave and the T wave. This segment is elevated above the baseline, when is should be isoelectric.** Image credit: [nataliescasebook.com](https://www.nataliescasebook.com/tag/s-t-elevation)

In the case of a STEMI ⇒ If you show up with ST elevation and a clinical picture that looks like MI, you end up going to a cath lab within an hour, and you get that artery opened up

What is the overlap between ST elevation and Q-wave?

- The way to think about it as the Q wave, and the ST elevation MI are probably the same
- It’s just you’re seeing a later manifestation of the Q wave
- The non-Q wave MI is probably now what we call non-ST elevation MI (known as non ST elevation acute coronary syndrome)

Acute coronary syndrome (ACS) is the entire collection:

- ST elevation ACS (STEMIs)
- non-ST elevation ACS (non-STEMIs)
- Very simply defined by the presence or absence of ST elevation
- Turns out that people who don’t have ST elevation often have other ST segment abnormalities (most commonly ST segments are actually depressed)

## What happens when someone comes to the ER with a STEMI (ST elevation myocardial infarction)? [47:15]

Someone shows up at the ER with a STEMI

- Immediately goes to [cath lab](https://en.wikipedia.org/wiki/Cath_lab) for a [balloon](https://en.wikipedia.org/wiki/Balloon_catheter) or [stent](https://en.wikipedia.org/wiki/Stent)
- They also get [heparin](https://en.wikipedia.org/wiki/Heparin), aspirin, [clopidogrel](https://en.wikipedia.org/wiki/Clopidogrel)

Do you check enzymes (blood biomarkers) anymore before cath lab?

- No
- “[Time is myocardium](https://www.holy-cross.com/tags/time-myocardium)” ⇒  the longer the heart deprived of oxygen, the less chance it’s gonna actually recover
- There’s been a push to speed things up

How much time has this saved?

- 30+ minutes, Peter estimates
- Every hospital now in this country is measuring their what’s called “door-to-balloon time”
- Like every quality metric, there are trade offs (people taken to the cath lab who probably don’t belong there, maybe some DNR-DNI or have metastatic cancer)
- Overall this is better than it used to be… the most important thing is get somebody up there

What actually happens in a cath lab?

- In the old days… almost everybody had basically a needle put into the femoral artery (the major offshoot of the aorta, feeds your leg oxygen, inserted at the crease of the groin)

⇒ Modified Seldinger Technique

- Catheter goes into the artery and can go all the way up around the arch of aorta and back down to the base of the heart where the coronary ostia are (we have a left and right coronary ostium)
- Has a one-way valve which allows you to put things in (like contrast dye for x-rays)

Balloons to open up artery

- You can wrap a balloon around the tip of the catheter and then use a syringe to blow up that balloon to crush open the blockage or clot to reestablish blood flow
- This is a bit of a mechanical and “crude” technique
- Like a beaver’s dam being shoveled downstream
- And what happens if all the blockage get caught somewhere else downstream?

What about chemicals to dissolve the clot?

- We have ways to inject something (e.g. [TPA](https://en.wikipedia.org/wiki/Tissue_plasminogen_activator)) that can break apart the “epoxy”
- But they aren’t that effective… why?
- The drugs are imprecise and hard to only use locally
- You’re increasing the risk of dislodging of blood clots somewhere else that might be really important (i.e. an injury in your head made blood clot somewhere in your subdural area, or something in your GI tract protecting you from bleeding out)
- This is dangerous and the reason that [primary angioplasty](https://en.wikipedia.org/wiki/Percutaneous_coronary_intervention) became standard of care in the US

## Stents [54:45]

![](https://peterattiamd.com/wp-content/uploads/2019/05/stent-1024x704.png)

**Figure 4. Stent before inflation (right) and after inflation (left).** Image credit: [pakistantoday.com](https://www.pakistantoday.com.pk/2019/01/11/health-dpt-finalises-new-rates-for-cardiac-stents/)

![](https://peterattiamd.com/wp-content/uploads/2019/05/coronary-artery-stent-872x1024.png)

**Figure 5. Process of inserting and expanding a stent to open up a coronary artery.** Image credit: [summitmedicalgroup.com](https://www.summitmedicalgroup.com/library/adult_health/car_coronary_artery_stents/)

The early days of stents

- Stents (little metal scaffolds) were developed back in the 1990s as a means of treating stable angina
- Using just the balloon, 40-60% of people would show up with “restenosis”
- So they put the stent around the balloon and that would keep the artery from closing back up
- Stents completely cured the physical recoil problem
- But they left behind an injury problem ⇒ The act of blowing up the stent injures the vessel wall creating scar tissue causing In-Stent Restenosis (ISR)

Drug-eluting stents

- Early 2000s, drug eluting stents came about
- [Andy Marks](https://www.markslab.columbia.edu/marks_bio.html#) played a big role
- Cells are making scar tissue in response to the vessel injury
- Rapamycin (and other mTOR inhibitors) were known to be antiproliferative drugs so you could paint it onto the stent so it could be there locally and not cause systemic toxicity
- That mostly got rid of that problem of In-Stent Restenosis

*The biggest problem with stents* ⇒ When stents first started getting used in coronaries, one of the biggest problems was within a period of a few weeks, a non-trivial amount of people would come back with what effectively was a STEMI because **the stent would clot off** (subacute stent thrombosis)

[Paper in the 1996 issue of NEJM](https://www.nejm.org/doi/full/10.1056/NEJM199604253341702)

- A trial that demonstrated that you could do stenting of coronary arteries safely with the addition of this drug called ticlopidine (Ticlid) which renders the platelet a little bit less sticky
- So if you gave people Ticlin at the time they got their stent, the chance of the stent clotting off went to almost zero
- Eventually, that drug had some toxicity and was replaced with the drug that’s used in most cases still today called [Clopidogrel](https://en.wikipedia.org/wiki/Clopidogrel) (Plavix)
- In other words, you’d show up with a stable problem that’s chronic and through the intervention you’d end up having an acute fatal complication
- Mostly that problem got solved with [Plavix](https://en.wikipedia.org/wiki/Clopidogrel)

Fast forward to drug-eluting stents…

- We’ve solved the restenosis problem, but people are showing up now at three months, six months, nine months, with “late stent thrombosis”
- Having again, the same life-threatening, STEMI-like experience
- In the process of inhibiting the muscle cells and other cells that make the scar tissue, *we’re also inhibiting in the endothelial cells*
- And the endothelial cells are what prevent the blood clotting
- With a bare metal stent, the body will re-endothelialize the inside of the stent within three weeks or four weeks but now that is prevented from happening
- Before drug-eluting stents, the standard of care was to take Plavix for one month and you’re done

Today’s standard of care

- Newest generation drug-eluting stents have the right mixture and cocktail of drug on them
- They’re really easy to deliver and cause less injury
- Plavix is taken for 6 months
- What you’re doing is you’re buying bleeding risk by inhibiting this risk of stent thrombosis
- **Stent thrombosis is the worst. You don’t want, you can’t have that.**

> “If you’re going to an island and you can only bring one thing with you . . . all that matters is your Plavix. You got to take it every day.”

## Treatment protocol for both acute and chronic coronary artery disease: History, controversy, and important distinctions [1:06:30]

> “This is one of the most controversial, least understood areas of medicine.” —Ethan Weiss on the protocol for treating stable angina

*Someone presents with stable angina with a 60-70% occlusion, what should the doctor do?*

In the 1980s…

- That patient gets a prescription for nitroglycerin and beta blocker
- Beta blocker helped reduce the demand (governor on a car)
- Nitroglycerin, as we described, it helps relax the blood vessels
- A couple of not great tools in the 1980s
- Eventually get bypass because there was no other option for what we now call revascularization

Mid 1990s…

- Stents became viable and you could give somebody a really durable response without needing to take the medicines

Bypass surgery

- The only bypass surgery available at the time was the [LIMA-to-LAD CABG](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1964611/)
- LIMA stands for Left Internal Mammary Artery
- When you open up the sternum, you have these arteries on the inside of the sternum
- The left and right version of these turn out to be the most important conduits that you can use to bypass
- You attach it distally (past the lesion) to bypass the lesion
- This worked in a subset of people
- So the thought way…if this bypass worked, shouldn’t clearing the pipes (like a roto rooter) work as well? (i.e. angioplasty)

*How Ethan treats these cases*:

- Ethan discusses 2 things with patients
  - 1) How do I feel? (Presence or absence of symptoms)
  - 2) Is this gonna impact how long I live?
- “Those are the two variables we think about every day in cardiology.”
- Most of the time when we’re talking about treating stable angina, **we’re talking about treating symptoms**

*If it doesn’t affect mortality, should we care?*

- Peter wants to make a point that treating symptoms is important even if there is no impact on mortality: “I find a heavy dose of people who think if it doesn’t impact all cause mortality, it’s never worth talking about. I suspect these people have never taken care of patients.”
- Many of these people can’t…
  - Walk up your stairs
  - Can’t garden
  - Hike with your wife
  - Skiing with your children
  - Can’t have sex

> “Even if there’s an intervention that doesn’t extend life by one day, if it improves the quality of life, it should still be on the table.”

**IMPORTANT reminder regarding the treatment protocol [1:12:!5]**

**STEMI patients**

- In the case of STEMI…
- “I don’t think this point cannot be emphasized too many times. If you show up in the hospital, or in the emergency room, with the ST elevation MI (STEMI), that ST segment has increased above baseline, and you’re having a heart attack. You are going straight to the cath lab.”
- Important and controversial statement

**Non-STEMI**

- If you show up with a non-STEMI (chest pain, biomarkers like troponin in your blood, but an EKG that is NOT ST elevation)… that puts you into a different category
- Most people are managed either:
  - Medically (a bunch of medicines)
  - Or they go down a path of interventional cardiology

*Complicated non-STEMI vs. uncomplicated non-STEMI*

⇒ Complicated non-STEMI

- means you have one of the following (in addition to other symptoms like chest pain and enzymes)…
  - Hemodynamic instability (meaning your blood pressure is very low)
  - Heart failure
  - Fluid in your lungs
  - Chest pain that go away with medicines
  - Ongoing concern with EKG changes
  - Or you just don’t feel right
- That patient **also can go to the cath lab**
- But it isn’t an “emergency” unless there’s hemodynamic instability

⇒ Uncomplicated non-STEMI

- The blood pressure is fine, no evidence of congestive heart failure, etc.
- Those patients can be managed either noninvasively with medicines, or invasively (stents) after deliberation
- There was a period of time where most of those people went into the intervention arm (and got a stent)
- I think in the past few years, there have been questions about the value of that

**RECAP**

- STEMI means immediately go to cath lab, no debate, clear mortality benefit (If you have no access to a cath lab, then TPA is the best you can do)
- In the non-STEMI situation, if you’re hemodynamically unstable, again, same thing…. opening the artery saves lives, no debate
- If you’re non-STEMI and hemodynamically stable, things start to become a little bit more gray.
- Then with stable angina, there’s a huge amount of gray area regarding mortality benefit, big debate

## Using stents to treat stable angina: What we learned from the COURAGE AND ORBITA trials [1:15:30]

Quick plug for Peter’s favorite app for looking up journal articles: [Journal Club](https://itunes.apple.com/us/app/journal-club-medicine/id512153051?mt=8)

[**COURAGE trial in 2007**](https://www.nejm.org/doi/full/10.1056/NEJMoa070829)

- **Question it was looking to answer**: *Is there any additional benefit outside of symptom relief that you get from putting a stent in an artery in somebody with a blocked artery and stable angina*?
- *In other words…* is there a benefit in terms of reducing the risk of heart attack (or some other hard outcome like death) in patients when you randomly assign them in a non-blinded manner to be treated with maximum medicines, or with stents?
- **Result**: It was negative. There was no difference between the two arms.
- “That was a big hit in an industry where it was pretty much the Wild West at that point in terms of the number of stents people were getting.”
- “This definitely was a big result in cardiology, particularly in interventional cardiology. It was not met without criticism, as you can imagine.”

[**ORBITA trial**](https://www.ncbi.nlm.nih.gov/pubmed/29103656)

- **Question**: *Are stents actually even reducing symptoms?*
- \*The key differentiator of this trial was blinded, which meant there were [sham procedures](https://en.wikipedia.org/wiki/Sham_surgery) done
- *The setup*: People with a known blockage were randomly assigned to get either optimized medical therapy or stent. But it was blinded so everyone got a catheter put in but wouldn’t know whether or not a stent was inserted.
- *Criticisms*: It was a small sample size

*⇒ Peter’s quick rant about power and significance*:

“From a size perspective, the issue comes down to power. I think this is the biggest challenge of trial design. People talk a lot about significance, which is what the P value tells you, but people don’t talk a lot about power, which is beta. The idea here is, you have to have some sense, a priori, of how much of a difference you will see to design your trial because you have to know how many people to put in it. Because if the trial comes out and there is a statistically-significant difference, which is usually defined the P value less than 0.05, meaning there is a less than 5% chance that the difference you have observed is due to chance, then power becomes irrelevant. It’s just that power becomes so important when the opposite happens, when you don’t see a difference.

It’s your ability to say, ‘We don’t see a difference, and we believe that a difference is not there,’ versus, ‘We don’t see a difference, but we didn’t have enough people to look at it.’ For example, if I was gonna design a trial with me and Ethan, just as the two of us, it’s quite likely that I would never find a statistically-significant distinction. But that doesn’t mean that the metric I’m looking at doesn’t exist, it’s just with two people in a trial the probability that I’m going to find it is incredibly low unless the difference is egregious. I’ve always found this to be the biggest challenge of clinical trials is that you have to have some sense of your expected outcome to select beta to power the study appropriately.”

- **Result of the study**: They did not see a difference in symptom (i.e. it didn’t help, on average)
- *How is was presented to the public (i.e. NY TImes and Wall Street Journal)*: Stents not only do they not reduce your risk of having a heart attack or die, they don’t even reduce your symptoms.
- “It created a firestorm of conversation.”
- *Timing of this report*: This was during the day that doctors would do stress testing and as soon as they would see a 70% blockage they would put in a stent (George W. Bush has a stent for stable angina around this time)
- **Takeaway from the trial (Ethan’s perspective)**: While stents may or may not be useful in some circumstances at reducing your symptoms, it’s very unlikely that, in stable angina, they’re gonna do anything else (such as change mortality risk). But either way, it’s our job to try to manage you as best we can with medicines before we go down that path, because there are going to be consequences that putting a stent in you. If medications are working, or making your feel miserable, we’re gonna keep that stenting procedure in our back pocket.

**The changing nature of scientific knowledge [1:29:30]**

- An unfortunate nature of science is that what is “known” today could be different tomorrow
- “All facts have a half-life”, says Peter
- While it may be frustrating, Peter says it is “in some ways, that’s the single most exciting thing about science. It would be boring if all of the natural universe and its laws were known and this was just a game of memorizing all those facts.
- Sometimes results are just “wrong”, says Ethan: “Even a P-value of 0.05 means … there’s a 5% chance that the result happened by chance.

> “We have to stay humble. I love it when I’m wrong. There have been a few examples this year I’ve been wrong, brutally wrong, and it brings me joy. I love it when something defies my expectation.”

## The “art” of longevity: The challenge of preventative medicine and understanding risk [1:31:45]

> “What we’re missing, and I hope we can eventually refine it and make it better, is a good way to predict disease risk and these chronic diseases.”

The decision on how aggressively to treat someone

- Ethan says deciding how aggressively to treat someone as a cardiologist is one of the things he struggles with most
- Some people get “overmanaged” and simply “turning off” all the many arms of treatment allows the patient to get better
- Ethan struggles to figure out where he wants to be on that spectrum
- We do not yet have the tools to says your risk for this chronic disease is X,Y, or Z therefore we should do this, this or this

Peter agrees, and says that this is a very nuanced discussion (i.e. can’t be discussed on Twitter)

- “As my patient sitting in front of me, I don’t know how aggressive to be or not to be. **You’re not asking the question** ***on average***. Yet, what tool are you given to guide you? You are given a tool called a clinical trial, which is, by its very nature, *all about averages*. Therein lies the mismatch of what I have described as medicine 2.0.”

Limited nature of clinical trials

- Clinical trials give us great information on averages
- The larger and more robust the trial, generally, the more heterogeneous the data
- You’ve asked a question that comes down to judgment ⇒ You know what it means to be aggressive, and you know what it means to be conservative, and you know what the corners of that box look like
- Yet a doctor could have two people in front of him that superficially looks similar, but actually one of them is probably going to have a better outcome if I behave aggressively, and the other one might have a better outcome if I behaved conservatively ⇒ the challenge to figure out which one is which

> “If you’re a hammer and everything’s a nail, even if you’re acting as hammer and nail in accordance with clinical trials, I suspect you were still acting in a very blunt manner.”

The challenges of preventative medicine

- In terms of prevention, Ethan says, “*there’s not gonna be a clinical trial to answer a lot of the questions that I have about how to manage my patients*.”
- Prevention is not really amenable to medicine 2.0 b/c the clinical trial is… average outcome, short duration, simple intervention, easy-to-measure outcome
- *Evidence-based medicine versus evidence-informed medicine* ⇒ the latter just makes much more sense because these decisions that you have to make virtually every day and virtually nothing that you do can you point to the ORBITA or COURAGE equivalent
- Preventative medicine really is an art and a science (or as Peter says in the reverse order, there’s an art and science to longevity because it’s really an art that’s informed by science)

## Understanding CAC scores, and CT angiogram results [1:40:15]

**Physiologic test**

- This would be like a stress test, a treadmill test, to see whether you have symptoms, determine whether there’s ischemia (Meaning there’s a difference in the supply and demand of oxygen)
- You can use EKG or you can use an echo, or you can use what’s called nuclear, which is basically a radio-labeled potassium analog that lights up living cells (hat’s been the standard of care in this field for 40 years)

**Anatomic tests**

- In the past 20 years or so, people have started to explore whether there’s a role for anatomy
- One anatomic test is an [angiogram](https://en.wikipedia.org/wiki/Angiography)
- You can take somebody to the cath lab and you can put a catheter up there and inject some dye into the artery to look for blockages
- You wouldn’t use that as a screening test (even though patients often ask for one just to see if they have any)

⇒ When is an angiogram test appropriate to do?

- It’s for people in the “intermediate risk” category
- If you’re low risk, for the most part, there’s not gonna be much benefit to adding one of these tests (asymptomatic people)
- If you’re high risk, you probably fall into a different category as well

⇒ What do the results of an angiogram mean?

- The results are about answering one question, which is “how aggressive should we be with our medical therapy?”
- It informs us about whether or not statins or PCSK9 inhibitors are appropriate, for example

**Coronary artery calcium score (CAC)**

- First developed by [Arthur Agatston](https://en.wikipedia.org/wiki/Arthur_Agatston) ⇒ He determined that there was a linear relationship between the amount of plaque that you have and the degree of calcium that you have in your arteries
- With that knowledge he developed a quantitative measurement called the [coronary artery calcium scan](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) or score (CAC)
- It is a low-dose radiation screening test that looks for calcium
- The scan tells you how much calcium you have as well as on a percentile basis based on your age and sex

*What does it mean if it shows nothing? Meaning your score is zero?*

- When you look at the stages of lesions, calcification is a very late process
- It’s basically the repair of damage
- *If you have a calcium score of zero, does it mean you have perfect coronary arteries*? **You can’t conclude that.**
- All about the context ⇒ In a 25-year-old with a calcium score of zero, *it’s meaningless*
- Conversely, when a 90-year-old shows up and has a calcium score of zero, it’s quite informative (their risk of having a heart attack is not zero but it’s below 1%)
- *Remember*: the **biggest risk factor for having a heart attack is your age** so it supersedes all the other known risk factors that we use everyday (lipids, blood pressure, diabetes)

*Why is age the greatest risk factor?*

- It’s an area under the curve issue, an exposure question
- In atherosclerosis, this AUC shows a monotonic progression in an individual (just as we see progression of polyp to cancer in the colon)
- So the older you are, the more interesting it is to have a zero calcium score (“[*Bayes’ theorem*](https://en.wikipedia.org/wiki/Bayes%27_theorem) *at its finest*”…you are acquiring more and more information as somebody goes on)
- A 35 year old has a zero CAC score? Tells us very little about his future risk
- A 35 year old with a non-zero number?

*What is most interesting about the CAC score*?

- It’s a two by two and there’s only two quadrants that are interesting and informative
- Young people (45 or 50) who already has calcification
- Older people (70+) who has zero calcification
- “*If you’re in the other two quadrants I don’t think I’ve learned anything.*” says Peter

Case studies:

- Peter’s patient
  - 49 years old
  - Calcium score of 4500 (off the charts high)
  - Bad family history: Father and brother both has heart attacks in their 40s
  - Shockingly, no elevated [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a))
  - Lipid profile also not that bad
  - [ApoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) is in the 70th percentile
  - These are the toughest and “scariest” patients, says Peter, “*they’re at the 70th or 80th percentile of risk by lipids and by other metrics, but by story, and now by calcium and other tests, they’re at the 99th percentile in terms of risk.*”
  - “*There’s clearly something going on and I don’t even know what it is.*”
- Ethan’s patient

- Early 50s
- Has a very tight proximal left main (The so-called widow maker)
- His lipid test came back normal
- He had no obvious risk factors and then we got his LP(a) back and it was high
- On the one hand, Ethan felt relieved because he understood what was going on
- On the other hand, we still don’t really have a direct therapy to offer
- Side note: [Sam Tsimikas](https://twitter.com/lpa_doc?lang=en) is developing ASO drugs to will hopefully lower Lp(a)

For more on Lp(a), check out this [deep dive episode of The Drive](https://peterattiamd.com/lpa/)

**Final thoughts on the usefulness of the calcium score**:

⇒ “I’ve always found it very difficult to interpret the data on this because they tend to report it without clearly specifying the age cohort. So for example, everybody loves to quote a study that would say a zero calcium score means your 10-year risk is 1.9% or something to that effect, but you can’t actually say that without knowing the age of the cohort, because a zero calcium score in a group of 30-year-olds probably has a 10-year risk of less than 1%, a zero calcium score in a cohort of 70-year-olds would clearly be 5 to 10% still. So that’s another thing that I just find very sloppy, but I don’t have these discussions too much in social media because I find it so frustrating, but it’s you just don’t have the time to explain that nuance to folks.”

⇒ Ethan suggests using the MESA ([Multi-Ethnic Study of Atherosclerosis](https://www.mesa-nhlbi.org/)) [calculator](https://www.mesa-nhlbi.org/MESACHDRisk/MesaRiskScore/RiskScore.aspx) for determining 10-year risk… “it has the traditional risk factors and then you can add in the calcium score if you have it.”

> “But again, it comes back to this being way more art than science. This is at this point in primary prevention, this is still very much art and not science and probably will be for our lifetime so we’ll have to get used to that.”

**CT angiogram (CTA) [1:51:00]**

- The CTA provides anatomic detail (like the angiogram) as well as the detail of the wall of the artery to look for soft plaque that hasn’t reached the point of calcification (That said, if someone already has a lot of calcification you can’t do it)
- In other words, you can see the formation of plaque inside the endothelium before it starts to narrow the lumen

![](https://peterattiamd.com/wp-content/uploads/2016/06/Coronary_angiography_of_a_STEMI_patient_showing_partial_occlusion_of_left_circumflex_coronary_artery.jpg)

**Figure 6. CT angiogram of a STEMI patient showing partial occlusion of left circumflex coronary artery.** Image by [Todt et al., 2012](https://bmccardiovascdisord.biomedcentral.com/articles/10.1186/1471-2261-12-9#MOESM2)is licensed under [CC by 2.0](https://creativecommons.org/licenses/by/2.0/)

*What is the value of that information and how does it change our management*?

- It adds great benefit on the negative and on the positive (depending on the age)
- HOWEVER a patient with a zero calcium score whose CTA is pristine it’s still not a guarantee of no risk but it makes you feel a bit more comfortable that your level of aggression can be lower

*Radiation exposure*?

- So then what’s the cost? So other than the theoretical cost of the radiation which is probably something and the-
- CT angiograms are 2 millisieverts of radiation
- The NRC limits people or suggests an upper limit of 50 millisieverts for a year
- Peter says, we want our patients to be below 20 millisieverts for a year
- Living at sea level exposes you to maybe 1 millisievert over the course of a year
- Living in Denver probably exposes you to 4 or 5 millisieverts for a year
- An x-ray is only 1 millisievert

Monetary cost

- It’s probably $2000 to $2500 so it’s a quite expensive study relative to the CT, the calcium score,
- Certain places, however, (Stanford) is doing CT angiograms for only $100

*What is the risk of doing a CTA?*

- Ethan’s perspective is that the risk is zero with the right patient and the right doctor
- The wrong patient and the wrong doctor it could be high.

⇒ Example,

- The anxious patient who simply can’t live with the knowledge that something is “growing” inside of them (meaning, the plaque)
- Analogy would be someone with prostate cancer wanting to cut it out even though there are lots of ways to effective ways to treat prostate cancer that seldom involve cutting the tumor out
- So there are patients who just can’t sleep they think… “I’m going to die from a heart attack” and no matter what I say, I can’t dissuade them of that
- “*So this is sort of why I’m not gonna widely do this in everybody, but in certain people it’s spectacular.*”

HeartFlow

- [HeartFlow](https://www.heartflow.com/) is a company that is layering on an analysis to the CT angiogram
- It’s based on the idea that you can use physics to measure the percent narrowing of an artery by measuring the velocity across the lesion (like your finger on the end of a garden hose increases the velocity of the water that comes out)
- You can measure pressure before and after the artery blockage and then infer how severe the blockage is

⇒ Earlier tools for measuring pressure

- The technique of measuring pressure was first developed invasively in people who were going into the cath lab
  - One of them was this intravascular ultrasound, IVUS
  - Another one was this fractional flow reserve (FFR), which is a way of measuring pressure and basically inferring the degree of blockage

⇒ More about FFR

- FFR is the calculation of P2, which is the pressure beyond the occlusion over P1
- There are two big trials that looked at the use of invasive fractional flow reserve: FAME 1 and FAME 2
- *The take home from those studies*:
  - If you had an FFR that was less than 0.8… if you then put a stent in that artery people did better
  - It suggested that this could be a useful tool to help stratify who should be getting stents and who shouldn’t be getting stents
- FFR in practice:
  - It’s invasive (needing a catheter) so you have to be having an angiogram to do it
  - So somebody came up with this idea that you could do the same thing using just a noninvasive CT scan and you could basically measure the velocity and infer the pressure using [Boyle’s law](https://en.wikipedia.org/wiki/Boyle%27s_law)
- HeartFlow is now selling the software as an add-on package to the CTA and they’ll give you what’s called a CTFFR (which is their calculated FFR)

*How has HeartFlow changed your practice?*

- Not so much, says Peter and Ethan
- Whereas the anatomy whether there’s plaque there (CTA) does help guide you about how aggressive to be with your medical therapy, it’s not clear to me that we’re learning anything from adding the HeartFlow on
- We have the information from these two other big trials (COURAGE & ORBITA) that tell us that this is probably not gonna be a huge game changer because … *what information is it adding and how are we gonna react to it*?
- Their pitch from a business standpoint is that it saves unnecessary catheterizations

*But what value will it bring to a patient*?

“I can’t think of a big value today, unless you had somebody who you were gonna send to the cath lab and you thought this would help sort of make you feel comfortable by not doing [sending them].”

## How sex differences in clotting and heart disease got Ethan interested in growth hormone and IGF [2:01:00]

See this article for more about how Ethan’s started researching growth hormone: [Faculty Spotlight: Ethan Weiss, MD](https://ucsfhealthcardiology.ucsf.edu/facstaff/spotlight/weiss)

Interest in blood clotting leading to growth hormone

- Ethan started out interested in the biology of blood clotting
- He began investigating the difference between the male and female clotting system
- It appears that evolution may have been able to optimize the system for the two sexes differently
- Peter says that is a “very interesting idea” and relates it to CVD:
  - Women tend to get CVD later in life that men
  - “*Men would in theory evolve to heal from a wound much quicker, even at greater cost down the line (i.e. earlier heart disease) because of their role in a hunter gatherer society, whereas the woman must evolve to protect the offspring much more and you could see how that would be a lower immune response, a lower inflammatory response, a lower prothrombotic response*.”
- And in rat models…it looked like there was a pretty significant difference in the rate of clotting between male and female mice

*Is it the sex-hormones?*

- Ethan looked at sex hormones like estrogen, estrogen receptor, etc. but that didn’t turn out to be the difference maker

*What about the liver?*

- Turns out that mammals have this remarkable sexually dimorphic liver
- If you take the liver out of a mammal, there’s a set of genes that are expressed dramatically different
- There is a tremendous signature difference between the genes that are turned on in the liver of females and males
- And *where are clotting factors made?* **The liver**.

Growth hormone

- What regulates the dimorphism of liver gene expression in mammals? ⇒ It turns out it’s not sex hormones, it is **growth hormone secretion**
  - Confirmed in a [1984 Cell paper](https://www.ncbi.nlm.nih.gov/pubmed/6323022)

Differences in growth hormone

- Males have longer intervals between the pulses of GH
- Females are more continuous so they have very short intervals
- The AUC, however, is the same
- In rodents, you can inject GH in a particular way that can completely reverse the gene expression in the liver to make the liver more masculine (in a female) or more feminine (in a male)

## Impact of growth hormone on the liver [2:07:00]

“If a man and a woman are both receiving the same dose and same dosing pattern of exogenous growth hormone you would **evaporate that difference of gene expression in the liver** because you would have *suppressed the pituitary secretion.”*

Ethan began investigating the role of GH in blood clotting

⇒ [Knocking out JAK2 in the liver](https://www.ncbi.nlm.nih.gov/pubmed/21364286)

- Knocking out different components of the growth hormone signaling pathway in a mouse
- Started with a protein called JAK2, (a signal transducer of growth hormone)
- That signal is transduced because growth hormone receptor itself is a type one cytokine receptor (It doesn’t have any intrinsic tyrosine kinase activity so it has to partner with this other non-receptor tyrosine kinase, JAK2, to transduce the signal)
- After knocking out JAK2 in the liver in hepatocytes and the liver basically turned into adipose tissue (in other words, they created [NAFLD](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease))
- Summary: Taking GH away from the liver increases fat in the liver by 25x

Relationship between growth hormone and IGF-1

- [Knocking out GH signaling in the liver will then therefore shut off *circulating* IGF-1 to zero](https://www.ncbi.nlm.nih.gov/pubmed/21527499) (because 95% of it comes from the liver)
- Circulating IGF-1 is the plasma biosensor for growth hormones
- Growth hormones half life is extremely short which means evolution created a system to measure growth hormone levels not by measuring growth hormone itself,  **but by measuring IGF-1**
- So when IGF-1 levels fall, the hypothalamus and pituitary sense that and then they turn on growth hormone
- “*Goodness gracious. I love when nature is so smart.*” says Peter
- The vast majority of the role of circulating IGF-1 is as a plasma biosensor for growth hormone, so it regulates growth hormone secretion

*What happens if you knocked out IGF-1?*

- You get this huge increase in GH secretion, you basically get [acromegaly](https://en.wikipedia.org/wiki/Acromegaly) but you get *selective growth hormone resistance in the hepatocytes*
- GH is one of two hormones that’s both catabolic and anabolic ⇒  it’s a way to mobilize fat from adipose tissue stores (catabolic) and helps muscles grow (anabolic)
  - Testosterone being the other where you can be anabolic to muscle, catabolic to fat
  - Insulin is anabolic to both muscle and fat
  - Cortisol, by contrast, is the reverse ⇒ catabolic to muscle, anabolic to fat
- If you give an animal growth hormone (or if you have a patient who has a tumor that secretes growth hormone) a disease called acromegaly like [Andre the Giant](https://en.wikipedia.org/wiki/Andr%C3%A9_the_Giant)
- We reasoned that what was happening was the growth hormone was turning on lipolysis and mobilizing all this fat and that that fat was getting taken up by the liver

*What about knocking out receptors in the entire body (instead of just the liver)?*

- When you you knock out the JAK2 (or STAT5) pathway in the whole animal, it had a one to twofold increase in lipid in their liver, very modest, hardly noticeable
- Whereas if you knock out the receptor selectively just in hepatocytes, you get this 20 to 25-fold increase
- That told us it’s not just about having high growth hormone levels, *it’s about high growth hormone levels and those growth hormone levels acting on the periphery*, so there must be some other factor that is important here

*What is the other important factor?*

- There’s a molecule called CD36 (aka fatty acid translocase)
- It was increased by 20-fold in these animals where we knocked out JAK2 in the liver
- Could be facilitating uptake of fat in the liver?

⇒ Follow up experiments [knocked out CD36 just in hepatocytes and showed that you could improve things](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4733118/)

- We put together this model where growth hormone secretion is disinhibited at the level of the hypothalamus-pituitary
- You get an increase in activity in peripheral tissues
- It’s then mobilizing all this fat and then that fat is being taken up sort of preferentially by the upregulation of this molecule, CD36
- Then if you block both JAK2 and CD36, you pretty much normalize the fat uptake by the liver (It wasn’t 100%, but it was near normalized)

**Ethan’s experiment**: [**Blocking JAK2 in adipocytes and the liver**](https://www.ncbi.nlm.nih.gov/pubmed/29203511)

- We said, “Since we’re presuming that this must be a product of lipolysis, what happens if we block this pathway in adipocytes?”
- So we went and made an animal where we knocked out JAK2 in adipocytes selectively
- Then we crossed the two together and asked, *can you reduce the amount of lipid in the liver by knocking out both at the same time?*
- “And we did.

⇒ Fascinating finding from that study…

- The mice where we had knocked out JAK2 in just the adipocytes had the most profound insulin sensitivity (We actually killed our mice because they died from hypoglycemia)
- We gave them the same amount of insulin that you’d give a normal mouse and they bottomed out and we couldn’t rescue them
- This was mostly glucose being disposed into the muscle?
- No
- Turns out, the defect is almost entirely in turning off endogenous glucose production from the liver
- Which is really not an insulin sensitivity issue at all, it just masquerades as profound insulin sensitivity but you basically clamp the portal vein (metaphorically) and you kill an organism if you stop hepatic glucose output
- The animals died within 30 minutes

## Growth hormone and insulin sensitivity [2:18:00]

- Those findings have sent Ethan on a path to trying to understand how growth hormone regulates insulin sensitivity or insulin glucose homeostasis and how that happens through the adipocyte
- This lead Ethan to the work of [Bernardo Houssay](https://en.wikipedia.org/wiki/Bernardo_Houssay), an Argentinian physician-scientist who [won the Nobel Prize](https://www.nobelprize.org/prizes/medicine/1947/houssay/biographical/) which he shared with the Coris of the [Cori cycle](https://en.wikipedia.org/wiki/Cori_cycle)
- He defined the diabetogenic nature of growth hormone so he did these experiments that basically got left behind because no one really paid attention to any of this stuff for a long time

[The incredible work of Bernardo Houssay](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4728695/)

- He took the pituitary out of an animal and then gave it insulin
- Found that the animal was more susceptible to the toxic effects of insulin, so they bottomed their blood sugar out.
- He then did the opposite experiment where he lopped out the pancreas and then saw that if you got rid of the pituitary gland that they were less susceptible to the hyperglycemia (that they basically had improved diabetes)
- **The takeaway message**: Remove GH and you’re going to appear insulin sensitive, but in reality, much more hypoglycemic. Take away GH in the absence of the pancreas, and you actually tolerate hyperglycemia better.

⇒ After these findings (in the 1960s), type 2 diabetes patients were getting their pituitary glands removed

- Very effective treatment
- But there was significant morbidity due to the difficulty of the surgery
- Afterwards they’d have to replace all of the thyroid and sex hormone and ACTH (the cortisol related stuff) ⇒ yet it still turned out to be better off all things considered in how well it managed their diabetes

The ultimate killer experiment [happened in 1984](https://www.nejm.org/doi/full/10.1056/NEJM198403293101302?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub=pubmed).

- Took patients with type one diabetes who had an insulin pump (i.e. getting a fixed dose of insulin)
- They were then given injections of growth hormone
- Insulin levels would go straight up and stay high until they stopped the GH injections and it comes back down
- Three out of the seven people in this one study got profoundly hypoglycemic when they stopped the growth hormone
- And in that 1983 New England Journal paper, they actually talked about growth hormone secretion being as much the cause of brittle type two diabetes as as the effect

⇒ *How is this regulated at a cellular level*?

- Growth hormone “coevolved” basically from insulin
- It’s not that surprising, says Ethan… IGF-1 is basically the target molecule of GH
- Growth hormones kind of retained a lot of the sort of metabolic effects of insulin
- And insulin has retained a lot of the growth promoting effects that used to be with growth hormone when they were all one molecule

**The point is**…

> “GH and insulin act in concert and from our experiments it looks like that’s happening in the adipocyte and that basically growth hormones acting as a brake on insulin signaling and that’s controlling metabolism in the whole body at a distance.”

## The role of GH and IGF on chronic disease and cancer [2:23:30]

IGF binding proteins (IGFBP)

- Controversy around this idea of IGF and its association with mortality (much  conflicting information)
- People with GH receptor mutations leading to low IGF and they seem to live longer (or at least get less cancer)
- But then they also seem to get a bunch of other diseases that are kind of odd
- But when you look at all cause mortality, it seems to nader at the ~60th percentile for everything

![](https://peterattiamd.com/wp-content/uploads/2019/01/u-shape-IGF-1024x748.png)

**Figure 7. Predicted HR for the association between IGF-I and all-cause mortality.** Image credit: [Meta-analysis and dose-response metaregression: circulating insulin-like growth factor I (IGF-I) and mortality (Burgers et al., 2011)](https://academic.oup.com/jcem/article/96/9/2912/2834729) [Burgers et al., 2011]

- But when you look by disease, certain diseases seem to get better with higher IGF (Alzheimer’s disease  and CVD)
- But others get worse, such as cancer which starts to go up

![](https://peterattiamd.com/wp-content/uploads/2019/01/A-1024x750.png)

**Figure 8. Relationship between serum IGF-1 levels and risk of (A) all-cause mortality (B) cancer mortality and (C) cardiovascular disease (CVD) mortality.** Image credit: [Both Low and High Serum IGF-I Levels Associate with Cancer Mortality in Older Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4258605/) (Svensson et al., 2012)

*How does all of that make sense in terms of what you’re learning at this level?*

- Two camps of people
  - One side believes that GH is the elixir that will promote longevity
  - The other side believes that too much GH signaling will negatively impact longevity
- *Not debatable*: Excess GH signaling, at least at the levels that you see with transgenic animals or people with [acromegaly](https://en.wikipedia.org/wiki/Acromegaly), is one of the most potent ways to die

⇒ On the flip side: [Laron syndrome](https://ghr.nlm.nih.gov/condition/laron-syndrome)

- People with Laron syndrome no growth hormone in their body
- Decrease in their risk of metabolic diseases and type 2 diabetes (despite an increase in body fat)
- They also never get cancer

⇒ In a mouse model of Laron syndrome…

- [Andrzej Bartke](https://www.siumed.edu/im/faculty/andrzej-bartke.html) and [John Kopchick](https://en.wikipedia.org/wiki/John_Kopchick) were able to [engineer a mouse to live 1,819 days](https://news.bbc.co.uk/2/hi/uk_news/england/cambridgeshire/3079834.stm) (207 human years) by removing GH from the mouse for their entire life
- It’s the longest lived mouse in history (earned them the $5 million [Methuselah prize](https://en.wikipedia.org/wiki/Methuselah_Foundation#Methuselah_Mouse_Prize) in 2003)
- Mice were short and fat, but their cognitive health is unknown (wasn’t studied)
- They are extraordinarily insulin sensitive, and the insulin sensitivity is conferred by the absence of the signaling pathway in the adipose tissue, which is acting at a distance, mostly on the liver

![](https://peterattiamd.com/wp-content/uploads/2019/05/laron-mouse.png)

**Figure 9. An image of a wild-type (WT) mouse, a giant bovine growth hormone (bGH) transgenic mouse, a dwarf GH receptor antagonist (GHA) transgenic mouse and a dwarf growth hormone receptor (GHR) -/- mouse in the same genetic background is shown (C57BL/6 J). These mice represent normal, elevated, decreased and absent levels of GH action, respectively.** Image credit: [e-enm.org](https://e-enm.org/ViewImage.php?Type=F&aid=593897&id=F1&afn=2008_ENM_26_4_285&fn=enm-26-285-g001_2008ENM)

*What do you think confers the protection to the Laron’s patients?*

- Ethan’s best guess is an improvement in insulin sensitivity, and a decrease in circulating insulin and decrease in IGF-1
- They just don’t get cancer

⇒ About the relationship between hyperinsulinemia and high glucose, Peter says:

“People need to understand the difference between managing glucose and managing insulin. If you manage glucose levels, if you keep glucose levels in the ideal range, by any means, you control microvascular disease. You’re less likely to go blind and less likely to have kidney failure and have an amputation. But if you do that with a strategy of high insulin, you trade it for macrovascular disease, atherosclerosis, coronary artery disease throughout the body. . .suggesting that even high insulin by itself can be problematic.”

- These Laron patients are walking around with very low insulin, which you could see would protect them at the *macrovascular* level

The insulin paradox: Peter struggles with the idea that Laron patients…

- Extremely insulin sensitive
- Normal glucose levels
- So, their microvascular disease is decreased
- Additionally, IGF is “pro tumor” so they aren’t getting cancer
- The confusing part: IGF and GH important are seemingly important in the brain so how are they avoiding neurological problems?
- Ethan says that he’s never at the brain (and not many other researchers have done it either) so he does not know
  - “*If you’re just asking about the things that I can measure, so metabolic disease, cardiovascular disease, cancer and lifespan. It seems like everything aligned towards too much GH being bad and less GH being better, but I can’t tell you about the neuro stuff. It could be the opposite there for sure*.”

*Why don’t Laron patients don’t have a survival advantage?*

- Despite the fact that Laron patients get a phase shift and delay the onset of cardiovascular disease, neurodegenerative disease, and cancer, they still don’t have a survival advantage… *why?*
- Example: 300 people in Ecuador with Laron
  - not one single case of cancer or diabetes over 30 years compared to ~15% in their age matched relatives
  - However, they were depressed and had an increased risk of alcoholism because they were basically ostracized for their physical appearance
  - Also had higher incidence accidental death (you have to die of something) …
  - But if accidental death increased, you should still show a survival advantage
  - But the truth is that epidemiology just makes this very difficult to untangle and understand

> “We’re never going to have a human longevity lifespan study that you or I will see the results of. And we just have to understand that.”

Insulin and cardiovascular disease

- Ethan is in the camp that believe that lipids are fundamental drivers of cardiovascular disease, of atherosclerotic disease and events.
- However, good evidence that insulin actually does play a role and that fasting insulin is an independent risk factor for cardiovascular disease
- See this [paper by James O’Keefe](https://www.ncbi.nlm.nih.gov/pubmed/29225902)

## Will taking growth hormone promote longevity? [2:32:30]

Peter is often asked by patients…*Should I be on growth hormone?*

- Peter’s general answer is no as he’s not convinced by any data that growth hormone will promote longevity
- But on the flip side, he has softened my tone in recent years
- He used to reject it on first principles because it made no sense because, if nothing else, the cancer risk
- But Peter finds it fascinating that we don’t see any trial of evidence that all these athletes who take GH are suffering the negative consequences which means it’s “*probably not as big as I would have guessed and or it takes a lot longer to show up than I would’ve guessed*”

What does Ethan tell his patients?

- If you’re optimizing for longevity, it’s hard to tell a story that that’s going to help you live longer
- Now if you’re optimizing for feeling better (increase my lean muscle mass, decrease body fat)
- And you’re willing to accept that we have no evidence that it’s going to increase your lifespan (it may more likely even decrease it) but you like how it makes you feel and look then it’s something we can consider

## GH and IGF as a treatment for early stage dementia? [2:34:30]

IGF/GH as a treatment for early stage dementia?

- Peter wants to see more investigation into whether increasing IGF improves cognition
- **Ideal clinical trial**: If we take our high risk dementia patients (or patients already in the earliest stages of cognitive impairment) and treat the subset of those patients who are at the bottom quartile of IGF levels, will GH provide benefit?

## What happens to IGF while fasting and what about fasting improves longevity?  [2:35:15]

What happens to Peter’s IGF-1 when he does a fast?

- They plummet, he says, but your scale/context matters…
- When on a strict keto diet for 3+ years, Peter’s IGF levels were in the 40th or 50th percentile for his age (not really surprising when you consider that a ketogenic diet minimizes insulin)
- When not on a ketogenic diet, his IGF is in the 70th percentile (which is about 200)
- On day 6 or 7 of a complete water, only fast, IGF will be in the 80-90 which is more than two standard deviations below the mean
- What he finds most interesting is **how long it takes to rebound and it takes about six weeks to come back to normal**

Measuring GH during a fast?

- It’s not very plausible because it is too pulsatile
- Ethan says, “it might be so high that you would be able to see something”
- “it’s very interesting to see how much you can manipulate GH nutritionally”

Understanding the role of GH in the fasting-feeding transition

- GH goes up while fasting, but IGF-1 levels go down
- So you get this selective GH resistance in the liver … the question is whether you’re getting GH resistance in other tissues as well… so the questions then become:

- What is GH activity in adipocytes? Is it actually maintained?
- So are you basically trying to mobilize fat as a way of avoiding starvation?
- Is it basically you’re trying to direct GH to act only on the periphery and not on the liver?

What about fasting is improving longevity?

- By the way, if you believe that periodic fasting improves longevity (Valter Longo does), it also begs the question, *is the benefit conferred by the reduction in IGF or the transient rise in GH*?
- “I never even really considered that the benefit could be conferred from the GH rise, although that seems less likely… who knows though… if biology teaches us anything it’s to stop acting like we know what we’re talking about.”

## The importance of becoming scientifically literate and making science more exciting for future generations [2:38:30]

> “An inability to understand science makes you a victim for the rest of your life.” —Peter Attia on his concerns about the “retreat” from science in early education

- Peter’s big concern with early education is the “retreat from science” (especially in the case of females)
- It’s not that he wants everyone to become a scientist, but that an inability to understand science can result in you being overrun with propaganda and nonsense
- Concerning fact about the makeup of the Senate: less than 1% of the lawmakers of this country are trained scientifically

Ethan’s take:

⇒ First… he Believes scientists need to do a better job of “communicating what we do in an interesting and exciting way to people without dumbing it down” (he commends Peter for The Drive as a great example of that)

- Ethan highly recommends videos from [iBiology.org](https://www.ibiology.org/) started by [Ron Vale](https://www.ibiology.org/ibiology-team/ron-vale-president-chairman-of-the-board/)
- Ethan recently appeared on one with [David Sabatini in a series about mTOR](https://www.ibiology.org/cell-biology/mtor-regulation/)

⇒ Secondly, there’s a trend of becoming hyper specialized earlier and earlier in life

- The problem with this is that…
  - 1) People who get into science at a young age get burned out and don’t like it by the time they get to be a fellow or a resident or attending
  - 2) People who don’t get into science until later such as mid-college (like Ethan) find it way too much of an obstacle to get in now in 2019 (compared to 1991)

Project to help MD students learn science:

- Ethan is working on something (it’s early so he can’t say much yet)
- Working on ways to help MD only medical students and beyond get exposed to real intensive multi-year experiences in the lab
- It will help increase the scientific literacy so MDs will be able to speak both these languages (traditional MD training has almost no scientific training)

## Ethan’s new company: Keyto [2:43:45]

Keyto

- Ethan started a company called [Keyto](https://getkeyto.com/) which created a portable breath analyzer for [acetone](https://en.wikipedia.org/wiki/Acetone)
- Ethan believes that [behavioral science](https://en.wikipedia.org/wiki/Behavioural_sciences) is the most interesting part of the obesity story
- So this sensor is ultimately all about solving the question: ***How do we use technology to help people change their behavior?***

Lack of good tools and information

- Most people use the body weight scale to track their weight loss
- But the scale is an incredibly lagging indicator (you could have entire gallon of ice cream tonight at 11 PM and step on the scale tomorrow and you may not have any difference in your weight)
- So it’s relatively useless on a day to day level, and by the time you actually get information it’s not actionable
- Peter also points out that water weight (especially in women still experiencing a menstrual cycle) can fluctuate wildly in a single day

The ketogenic diet for weight loss

- The one unique fact about the keto diet that’s different from all the other diets is it allows you to follow a biomarker which acts as a guide to help your own adherence and help reinforce some of these behaviors
- Current ways of testing your ketone level (blood or breath or urine) has all kinds of issues and imperfection
- But a good sensor (like Keyto) that people could carry around with them, and be accurate enough, could actually help guide behavioral changes

![](https://peterattiamd.com/wp-content/uploads/2019/05/keyto-device-1024x965.png)

**Figure 10. Keyto Breath Sensor.** Image credit: [getkeyto.com](https://getkeyto.com/)

§

## Selected Links / Related Material

**Company that both Ethan and Peter sit on the board**: [Virta Health](https://virtahealth.com) | (virtahealth.com)  [4:15, 2:28:00, 2:44:30]

**Ethan’s company that makes a breath sensor for measure ketones (acetone)**: [Keyto](https://getkeyto.com/) | (getkeyto.com) [6:30, 2:43:45]

**Peter’s podcast with Ted Schaffer where the reminisce about “Sunday School” from med school**: [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) | Peter Attia (peterattiamd.com) [19:45]

**Work of Michael Davies proving plaque rupturing was actually causal**: [Plaque fissuring–the cause of acute myocardial infarction, sudden ischaemic death, and crescendo angina.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC481773/) (Davies et al., 1985) [26:00]

**Davies describing multiple plaque ruptures upon autopsy among people with MI deaths**: [Mechanisms of progression in native coronary artery disease: role of healed plaque disruption](https://heart.bmj.com/content/heartjnl/82/3/265.full.pdf) (Davies, 1999) [26:45]

**Book which had a cover showing the “rings” of arterial lesions from plaque ruptures**: [Atlas of Atherosclerosis Progression and Regression (Encyclopedia of Visual Medicine Series)](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538?ie=UTF8&ref_=asap_bc) by Herbert Stary | (amazon.com) [27:30]

**Comparison of aspirin and streptokinase versus aspirin alone in patients who presented with heart attack**: [ISIS-2: 10 year survival among patients with suspected acute myocardial infarction in randomised comparison of intravenous streptokinase, oral aspirin, both, or neither](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC28530/) (Baigent et al., 1998) [29:15]

**Many fatal plaque rupture events happen in arteries that had only 30 or 40% blockage**: [Thrombosis and acute coronary-artery lesions in sudden cardiac ischemic death.](https://www.ncbi.nlm.nih.gov/pubmed/6709008) (Davies et al., 1984) [41:45]

**Work by Eugene Braunwald and TIMI Group in treating a STEMI**: [TIMI Study Group](https://www.timi.org/index.php?page=publications) | (timi.org) [44:45]

**Primary angioplasty trials**: [49:30]

- [A Prospective Randomized Clinical Trial of Intracoronary Streptokinase versus Coronary Angioplasty for Acute Myocardial Infarction](https://www.nejm.org/doi/full/10.1056/NEJM198603273141303) (O’Neill et al., 1986)
- [A Randomized Trial of Immediate versus Delayed Elective Angioplasty after Intravenous Tissue Plasminogen Activator in Acute Myocardial Infarction](https://www.nejm.org/doi/full/10.1056/NEJM198709033171001?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub=pubmed) (Topol et al., 1987)

**Companies that make stents**: [58:45]

- [Medtronic](https://www.medtronic.com/us-en/index.html)
- [Boston Scientific](https://bostonscientific.com/)
- [Abbott](https://www.abbott.com/)

**Ethan’s paper published in April 1996 issue of NEJM**: [A Polymorphism of a Platelet Glycoprotein Receptor as an Inherited Risk Factor for Coronary Thrombosis](https://www.nejm.org/doi/10.1056/NEJM199604253341703) (Weiss et al., 1996) [1:00:30]

**Trial that demonstrated that you could do stenting safely with the addition of the drug called ticlopidine (Ticlid)**: [A Randomized Comparison of Antiplatelet and Anticoagulant Therapy after the Placement of Coronary-Artery Stents](https://www.nejm.org/doi/full/10.1056/NEJM199604253341702) (Schömig et al., 1996) [1:00:30]

**The COURAGE trial**: [Optimal Medical Therapy with or without PCI for Stable Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa070829) (Boden et al., 2007) [1:15:30]

**App for finding trials and papers recommended by Peter**: [Journal Club](https://itunes.apple.com/us/app/journal-club-medicine/id512153051?mt=8) | (itunes.com) [1:16:45]

**The ORBITA trial**: [Percutaneous coronary intervention in stable angina (ORBITA): a double-blind, randomised controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/29103656) (Al-Lamee et al., 2018) [1:21:15]

**Episode of The Drive Richard Isaacson about Alzheimer’s disease and ApoE**: [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com)[1:48:15]

**10-year CHD risk calculator on MESA website**: [MESA 10-Year CHD Risk with Coronary Artery Calcification](https://www.mesa-nhlbi.org/MESACHDRisk/MesaRiskScore/RiskScore.aspx) | (mesa-nhlbi.org) [11:30] [1:50:30]

**MESA – One of the two largest cohorts to study atherosclerosis**: [Multi-Ethnic Study of Atherosclerosis](https://en.wikipedia.org/wiki/Multi-Ethnic_Study_of_Atherosclerosis) | (wikipedia.org) [1:50:30]

**Framingham – One of the two largest cohorts to study atherosclerosis**: [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study) | (wikipedia.org) [1:50:30]

**Company that built software to measure the percent narrowing of an artery by measuring the velocity across the lesion**: [HeartFlow](https://www.heartflow.com/) | (heartflow.com) [1:56:15]

**Two big trials that looked at the use of invasive fractional flow reserve**: [1:58:00]

- FAME: [Fractional flow reserve versus angiography for guiding percutaneous coronary intervention.](https://www.ncbi.nlm.nih.gov/pubmed/19144937/) (Tonino et al., 2009)
- FAME-2: [Fractional flow reserve-guided PCI versus medical therapy in stable coronary disease.](https://www.ncbi.nlm.nih.gov/pubmed/22924638/) (De Bruyne et al., 2012)

**Cell paper finding that growth hormone drives the sexual dimorphism of liver gene expression in mammals**: [Secretory rhythm of growth hormone regulates sexual differentiation of mouse liver.](https://www.ncbi.nlm.nih.gov/pubmed/6323022) (Norstedt et al., 1984) [2:05:30]

**Peter’s podcast episode with Nir Barzilai where they briefly discussed growth hormone and longevity**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [2:07:15]

**Ethan’s experiment knocking out JAK2 in mice**: [Abrogation of growth hormone secretion rescues fatty liver in mice with hepatocyte-specific deletion of JAK2.](https://www.ncbi.nlm.nih.gov/pubmed/21364286) (Sos et al., 2011) [2:07:45]

**Knocking out growth hormone signaling in hepatocytes shuts off circulating IGF-1**: [Liver-derived IGF-I contributes to GH-dependent increases in lean mass and bone mineral density in mice with comparable levels of circulating GH.](https://www.ncbi.nlm.nih.gov/pubmed/21527499) (Nordstrom et al., 2011) [2:11:00]

**Knocking out CD36 in the liver improves fatty liver and insulin sensitivity**: [Hepatocyte-Specific Disruption of CD36 Attenuates Fatty Liver and Improves Insulin Sensitivity in HFD-Fed Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4733118/) (Wilson et al., 2016) [2:14:30]

**Blocking JAK2 in adipocytes**: Adipocyte JAK2 mediates growth hormone-induced hepatic insulin resistance. (Corbit et al., 2017) [2:15:30]

**Blocking JAK2 in adipocytes and the liver**: [Adipocyte JAK2 Regulates Hepatic Insulin Sensitivity Independently of Body Composition, Liver Lipid Content, and Hepatic Insulin Signaling.](https://www.ncbi.nlm.nih.gov/pubmed/29203511) (Corbit et al., 2018) [2:15:30]

**Bernardo Houssay wins the Nobel Prize**: [Bernardo Houssay Biographical](https://www.nobelprize.org/prizes/medicine/1947/houssay/biographical/) | (nobelprize.org) [2:18:15]

**The work of Bernardo Houssay with the pituitary gland and insulin which lead to his Nobel Prize**: [Bernardo Houssay (1887-1971): Endocrine physiologist and Nobel laureate](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4728695/) (Yon Tan et al., 2016) [2:19:15]

**Growth hormone and insulin in diabetes**: [Importance of Raised Growth Hormone Levels in Mediating the Metabolic Derangements of Diabetes](https://www.nejm.org/doi/full/10.1056/NEJM198403293101302?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub=pubmed) (Press et al., 1984) [2:20:45]

**Andrzej Bartke and John Kopchick engineered the longest living lab mouse by knocking out growth hormone**: [Battle for ‘old mouse’ prize](https://news.bbc.co.uk/2/hi/uk_news/england/cambridgeshire/3079834.stm) | Valerie Sprague (news.bbc.co.uk) [2:26:00]

**Paper by James O’Keefe suggesting insulin in an independent marker for CVD**: [Postprandial insulin assay as the earliest biomarker for diagnosing pre-diabetes, type 2 diabetes and increased cardiovascular risk.](https://www.ncbi.nlm.nih.gov/pubmed/29225902) (DiNicolantonio et al., 2017) [2:32:15]

**Ron Vale’s iBiology video series about mTOR with David Sabatini and Ethan Weiss**: [mTOR and the Regulation of Growth](https://www.ibiology.org/cell-biology/mtor-regulation/) | ([ibiology.org](https://www.ibiology.org/)) [2:41:00]

§

## People Mentioned

- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) (famous NHL player admired by Ethan and Peter, Ethan has a signed jersey)  [8:00]
- [Mark Messier](https://en.wikipedia.org/wiki/Mark_Messier) (former NHL player and teammate of Gretzky who Peter got to have lunch with recently) [12:15]
- [Jari Kurri](https://en.wikipedia.org/wiki/Jari_Kurri) (former NHL player) [12:15]
- [Paul Coffey](https://en.wikipedia.org/wiki/Paul_Coffey) (former NHL player) [12:15]
- [Kevin Lowe](https://en.wikipedia.org/wiki/Kevin_Lowe) (former NHL player) [12:15]
- [Grant Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr)  (former NHL player) [12:15]
- [James Lloyd Weiss](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0000061/james-weiss) (Ethan’s dad, cardiologist at Johns Hopkins) [13:15]
- [Julius Axelrod](https://en.wikipedia.org/wiki/Julius_Axelrod) (Ethan’s dad worked in his lab [13:45]
- [David Sabatini](https://twitter.com/DMSabatini?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (classmate at Johns Hopkins) [17:30, 2:01:15, 2:41:00, 2:43:15]
- Dave Brett (classmate at Johns Hopkins) [17:30]
- [Andy Cameron](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0010274/andrew-cameron) (classmate at Johns Hopkins, son of John Cameron) [17:30]
- [John Cameron](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0001321/john-cameron) (famous surgeon at Johns Hopkins) [18:15]
- [Charles Yeo](https://hospitals.jefferson.edu/find-a-doctor/y/yeo-charles-j.html) (surgeon from Johns Hopkins) [19:00]
- [Kurt Campbell](https://mdmercy.com/centers-of-excellence/cancer/treatments-we-offer/surgical-oncology/our-doctors/kurtis-campbell-md) (chief resident at Johns Hopkins when Ethan was there) [19:00]
- [Ted Schaffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261) (expert on Alzheimer’s, guest on [The Drive](https://peterattiamd.com/tedschaeffer/)) [19:45]
- [Pascal Goldschmidt](https://en.wikipedia.org/wiki/Pascal_J._Goldschmidt) (Ethan worked in his lab) [23:30]
- [Michael Davies](https://bmi.ku.dk/english/Staff/?pure=en/persons/426515) (proved heart attacks were caused by ruptured atherosclerotic plaque) [25:45, 41:45]
- [Eugene Braunwald](https://en.wikipedia.org/wiki/Eugene_Braunwald) (ST elevation, TIMI Group) [44:45, 47:45]
- [Andrew Marks](https://www.markslab.columbia.edu/marks_bio.html#) (drug eluting stents, mTOR) [57:30]
- [Darrel Francis](https://twitter.com/profdfrancis?lang=en) (PI of the ORBITA trial) [15:45, 1:21:30]]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) (got a stent for his stable angina) [1:27:15]
- [Arthur Agatston](https://en.wikipedia.org/wiki/Arthur_Agatston) (Agatston score for calcium) [1:42:30]
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman) (age as the greatest risk factor for atherosclerosis) [1:45:30]
- [Richard Isaacson](https://weillcornell.org/risaacson) (expert on Alzheimer’s disease, guest on [The Drive](https://peterattiamd.com/richardisaacson/)) [1:48:15]
- [Sam Tsimikas](https://twitter.com/lpa_doc?lang=en) (developing ASO drugs to will hopefully lower Lp(a)) [1:49:30]
- [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) [2:01:15]
- [Shaun Coughlin](https://cancer.ucsf.edu/people/profiles/coughlin_shaun.3549) (biology of blood clotting) [2:02:00]
- [Richard Palmiter](https://www.hhmi.org/scientists/richard-d-palmiter) (Cell paper finding GH to be reason for sexual difference in liver gene expression) [2:05:30]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) (guest on The Drive where they discussed GH and longevity) [2:07:15]
- [Andre the Giant](https://en.wikipedia.org/wiki/Andr%C3%A9_the_Giant) (gigantism/acromegaly) [2:13:15]
- [Bernardo Houssay](https://en.wikipedia.org/wiki/Bernardo_Houssay) (Argentinian physician scientist, who won the Nobel Prize) [2:18:00]
- [Andrzej Bartke](https://www.siumed.edu/im/faculty/andrzej-bartke.html) (engineered longest living lab mouse by knocking out GH) [2:26:00]
- [John Kopchick](https://en.wikipedia.org/wiki/John_Kopchick) (engineered longest living lab mouse by knocking out GH) [2:26:00]
- [James O’Keefe](https://en.wikipedia.org/wiki/James_O%27Keefe_(cardiologist)) (published a paper on insulin as a biomarker for diabetes) [2:32:15]
- [Barry Bonds](https://en.wikipedia.org/wiki/Barry_Bonds) (GH and steriods) [2:33:15]
- [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) (fasting) [2:37:45]
- [Ron Vale](https://www.ibiology.org/ibiology-team/ron-vale-president-chairman-of-the-board/) (iBiology.org) [2:41:00]
- [Ned Segal](https://twitter.com/nedsegal) (CFO of Twitter, friends with Ethan) [2:51:15]
- [Jack Dorsey](https://twitter.com/jack) (CEO of Twitter) [2:51:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/05/bio-image-1.jpg)

##### Ethan Weiss, M.D.

Dr. Ethan Weiss is a cardiologist specializing in general cardiology. His special interests include preventive cardiology, genetics of coronary disease, risk assessment, and heart disease in the young.

In his research, Dr. Weiss uses genetic models to better understand the mechanism of metabolic disorders such as obesity, fatty liver disease, and diabetes. He also studies the blood clotting system and has interest in identifying novel ways to safely block clots associated with diseases such as heart attack and stroke without causing an increase in bleeding.

M.D., 1996 – School of Medicine, Johns Hopkins University

Clinical Fellowship, – School of Medicine – Cardiology, University of California, San Francisco

**Follow Ethan on Twitter:** [**@ethanjweiss**](https://twitter.com/ethanjweiss?lang=en)