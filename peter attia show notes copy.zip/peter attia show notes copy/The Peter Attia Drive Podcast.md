# The Peter Attia Drive Podcast

**Source:** [https://peterattiamd.com/podcast/](https://peterattiamd.com/podcast/)

---

![The Peter Attia Drive podcast artwork](https://peterattiamd.com/wp-content/uploads/2025/08/the-Drive_public.png)

# The Peter Attia Drive Podcast

4.9 • 4.1k

4.7 • 6.6k

*The Peter Attia Drive* is a deep-dive podcast that explores the science and art of living the longest and healthiest life possible. With over 100 million downloads, *The Peter Attia Drive* investigates everything from exercise and nutritional biochemistry to cardiovascular health, cancer, cognitive health, mental and emotional well-being, and beyond. Each episode brings listeners closer to the cutting edge of what it means to thrive.

Hosted by Dr. Peter Attia—a Stanford, Johns Hopkins, and NIH-trained physician renowned for his expertise in longevity and life optimization.

- 100+ million episodes downloaded
- A focus on maximizing longevity
- Deep dive into physical, cognitive, and emotional health
- Topics include exercise, nutritional biochemistry,  cardiovascular disease, Alzheimer’s disease, cancer,  and much more

##### AVAILABLE on your favorite platforms

## Popular Episodes

[![](https://peterattiamd.com/wp-content/uploads/2024/07/Longevity-101-737x1024.jpg)](https://peterattiamd.com/longevity101/)

Ep. #311

### [Longevity 101](https://peterattiamd.com/longevity101/)

Podcast Episode

[![](https://peterattiamd.com/wp-content/uploads/2023/09/Metabolic-health-1-737x1024.jpg)](https://peterattiamd.com/ama51/)

Ep. #271 (AMA #51)

### [Understanding and improving your metabolic health](https://peterattiamd.com/ama51/)

AMA

[![](https://peterattiamd.com/wp-content/uploads/2023/07/Centenarian-decathlon-737x1024.jpg)](https://peterattiamd.com/training-for-the-centenarian-decathlon/)

Ep. #261

### [Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength](https://peterattiamd.com/training-for-the-centenarian-decathlon/)

Podcast Episode

[![](https://peterattiamd.com/wp-content/uploads/2022/10/CVD-737x1024.jpg)](https://peterattiamd.com/understanding-cardiovascular-disease/)

Ep. #229

### [Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/)

Podcast Episode

[![](https://peterattiamd.com/wp-content/uploads/2023/10/Special-episode-737x1024.jpg)](https://peterattiamd.com/peter-faq/)

Ep. #276

### [Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more](https://peterattiamd.com/peter-faq/)

Podcast Episode

[![](https://peterattiamd.com/wp-content/uploads/2023/04/AMA-46-Brain-health-737x1024.jpg)](https://peterattiamd.com/ama46/)

Ep. #251 (AMA #46)

### [Optimizing brain health: Alzheimer's disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/)

AMA

[![](https://peterattiamd.com/wp-content/uploads/2019/12/85-Zone-2-737x1024.jpg)](https://peterattiamd.com/inigosanmillan/)

Ep. #85

### [Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/)

Guest Episode

[![](https://peterattiamd.com/wp-content/uploads/2023/06/AMA-59-Blood-pressure-1-737x1024.jpg)](https://peterattiamd.com/ama48/)

Ep. #258 (AMA #48)

### [Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/)

AMA

[![](https://peterattiamd.com/wp-content/uploads/2019/04/47-Sleep-737x1024.jpg)](https://peterattiamd.com/matthewwalker1/)

Ep. #47

### [Part I of III: Dangers of poor sleep, Alzheimer's risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)

Guest Episode

[![](https://peterattiamd.com/wp-content/uploads/2024/05/AMA-59-Inflammation-1-737x1024.jpg)](https://peterattiamd.com/ama59/)

Ep. #301 (AMA #59)

### [Inflammation: its impact on aging and disease risk, and how to identify, prevent, and reduce it](https://peterattiamd.com/ama59/)

AMA

[![](https://peterattiamd.com/wp-content/uploads/2024/04/Verical-images-for-site-737x1024.jpg)](https://peterattiamd.com/courtneyconley/)

Ep. #296

### [Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more](https://peterattiamd.com/courtneyconley/)

Guest Episode

# Get Premium Access  to Exclusive Content

**Membership Includes:**

- Exclusive Ask Me Anything episodes
- Best in class podcast Show Notes
- Premium Articles on longevity
- Full access to *The Peter Attia Drive Shorts* podcast
- Podcast Summary episodes

## Monthly

$19 / month

Billed monthly.

[SIGN UP](/subscribe#subscribe)

## Annual

$149 / year

Billed annually.

[SIGN UP](/subscribe#subscribe)

## Recent Episodes

[![](https://peterattiamd.com/wp-content/uploads/2026/01/January2026_AMA79_PodcastImage-756x600.jpg)](https://peterattiamd.com/ama79/)

AMA

### [A guide to cardiorespiratory training at any fitness level to improve healthspan, lifespan, and long-term independence](https://peterattiamd.com/ama79/)

Ep. #379 (AMA #79)

[![](https://peterattiamd.com/wp-content/uploads/2026/01/January2025_AbbieSmithRyan_PodcastImage-756x600.jpg)](https://peterattiamd.com/abbiesmithryan/)

Guest Episode

### [Women’s health and performance: how training, nutrition, and hormones interact across life stages](https://peterattiamd.com/abbiesmithryan/)

Ep. #378 with Abbie Smith-Ryan, Ph.D.

[![](https://peterattiamd.com/wp-content/uploads/2025/12/December2025_BestofBrooks_PodcastImage-756x600.jpg)](https://peterattiamd.com/bestofbrooks/)

Guest Episode

### [Special episode: Understanding true happiness and the tools to cultivate a meaningful life—insights from past interviews with Arthur Brooks](https://peterattiamd.com/bestofbrooks/)

Ep. #377 with Arthur Brooks, Ph.D.

[![](https://peterattiamd.com/wp-content/uploads/2025/12/December2025_AMA78_PodcastImage-756x600.jpg)](https://peterattiamd.com/ama78/)

AMA

### [Longevity interventions, exercise, diagnostic screening, and managing high apoB, hypertension, metabolic health, and more](https://peterattiamd.com/ama78/)

Ep. #376 (AMA #78)

[![](https://peterattiamd.com/wp-content/uploads/2025/12/December2025_DomDAgostino_PodcastImage-756x600.jpg)](https://peterattiamd.com/domdagostino2/)

Guest Episode

### [The ketogenic diet, ketosis, and hyperbaric oxygen: metabolic therapies for weight loss, cognitive enhancement, cancer, Alzheimer’s disease, brain injuries, and more](https://peterattiamd.com/domdagostino2/)

Ep. #375 with Dominic D’Agostino, Ph.D.

[![](https://peterattiamd.com/wp-content/uploads/2025/11/November2025_CaroleHooven_PodcastImage-756x600.jpg)](https://peterattiamd.com/carolehooven/)

Guest Episode

### [The evolutionary biology of testosterone: how it shapes male development and sex-based behavioral differences](https://peterattiamd.com/carolehooven/)

Ep. #374 with Carole Hooven, Ph.D.

[![](https://peterattiamd.com/wp-content/uploads/2025/11/November2025_AntonioBianco_PodcastImage-756x600.jpg)](https://peterattiamd.com/antoniobianco/)

Guest Episode

### [Thyroid function and hypothyroidism: why current diagnosis and treatment fall short for many, and how new approaches are transforming care](https://peterattiamd.com/antoniobianco/)

Ep. #373 with Antonio Bianco, M.D., Ph.D.

[![](https://peterattiamd.com/wp-content/uploads/2025/11/November2025_AMA77_PodcastImage86-756x600.jpg)](https://peterattiamd.com/ama77/)

AMA

### [Dietary fiber and health outcomes: real benefits, overhyped claims, and practical applications](https://peterattiamd.com/ama77/)

Ep. #372 (AMA #77)