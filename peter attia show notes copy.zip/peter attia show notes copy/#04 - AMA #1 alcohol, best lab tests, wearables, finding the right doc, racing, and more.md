# #04 – AMA #1: alcohol, best lab tests, wearables, finding the right doc, racing, and more

**Source:** [https://peterattiamd.com/ama01/](https://peterattiamd.com/ama01/)

---

In the first “Ask Me Anything” episode, I answer a wide range of questions from podcast listeners and the Twittersphere. [Bob Kaplan](https://twitter.com/bobkaplan), my head analyst, playing the role of [Mike Wallace](https://en.wikipedia.org/wiki/Mike_Wallace), asks, and follows up on, the hard-hitting questions submitted via Twitter.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ama01/the_Drive_public.png)

Play

#04 - AMA #1: alcohol, best lab tests, wearables, finding the right doc, racing, and more

#04 - AMA #1: alcohol, best lab tests, wearables, finding the right doc, racing, and more

1x15s30s

0:002:13:51

## We discuss:

- What are my thoughts on alcohol consumption and health? [4:00]
- What are the best lab tests to request from your PCP, and what are the best markers for longevity? [14:00]
- What are the best wearables and why, and why do I use a continuous glucose monitor? [35:00]
- How does one select the right physician as a patient? [47:00]
- Why do I race cars and what’s the hardest thing to learn as a new driver? [54:30]
- What is my current exercise regimen and what are my thoughts on exercise for improving lifespan and healthspan? [1:20:15]
- What is my strategy for learning something deeply? [1:33:00]
- What is my process for forming my beliefs? [1:53:30]
- What does my diet look like these days? [1:57:45]
- And more.

---

## Show Notes

## Alcohol Consumption [4:00]

Peter is not convinced that there is a single benefit to ethanol in the human body.

However, he does wonder if there is a net benefit of alcohol if it lowers your stress.

What is the effect of ethanol on the body?

- Alcohol is a toxin\*: the dose makes the poison;
- There is a probability distribution that drives the impact of a toxin on the population.\*

\* See: [Is sugar toxic?](https://peterattiamd.com/is-sugar-toxic/) by Peter Attia for more on what toxicity means in this context.

Generally speaking, alcohol has two effects:

- Brain effect of alcohol: we drink it for this: the buzz;
- Liver effect of alcohol: similar to fructose.

##### **Alanine aminotransferase, or [ALT](https://www.mayomedicallaboratories.com/test-catalog/Clinical+and+Interpretive/8362), is the best proxy to see hepatic harm.**

- Peter considers < 20 normal, whereas [the reference range](https://www.mayomedicallaboratories.com/test-catalog/Clinical+and+Interpretive/8362) includes 7-55 U/L;
- A question Peter always asks: *Does my patient have fatty liver right now? If so, is it more in response to ethanol, or is it more in response to fructose?*
- Figure out how much harm is coming, purely from a hepatic sense or alcohol, and make sure we’re drawing a line well below that.

##### **The most important question might be: why am I consuming alcohol?**

- *Am I drinking just for the sake of drinking?*
- *Am I trying to soothe some other issue?*
- *Does my drinking lead to a behavior that I’m otherwise not happy about it?*
- *For example, does alcohol loosen the reins on what I eat?*

##### **Peter’s rule of thumb on alcohol: [9:00]**

- “As a general rule, I don’t drink. If I’m going to drink, it’s going to be good alcohol”;
- What are Peter’s favorites?
  - Wine: [Clio;](https://www.totalwine.com/wine/red-wine/red-blend/clio-jumilla/p/16572750)
  - Tequila: [Clase Azul Reposado;](https://www.claseazul.com/clase-azul-reposado)
  - Beer: censored.

##### **Why do we think alcohol is potentially healthy and associated with longevity?**

- The French Paradox;
- Resveratrol;
- Bad science.

Alcohol and its impact on sleep. [13:00]

§

## Best Lab Tests [14:00]

##### **Peter’s top five lab tests:**

1. Lp(a)-P (or Lp[a] mass is a reasonable approximation).
2. *APOE* genotype.
3. LDL-P (or ApoB).
4. OGTT with insulin measurements.
5. ALT.

Honorable mentions: Hcy, hs-CRP, oxLDL, and oxPL, fibrinogen, Lp-PLA2, ADMA and SDMA are also really helpful to know. Estradiol (E2) as well. Knowing your family history can also tell you something about risk.

#####

##### **Lp(a)**

There’s a future episode dedicated to this topic.

#####

##### ***APOE* genotype**

The three major *APOE* alleles are:

- ApoE2 (ε2);
- ApoE3 (ε3);
- ApoE4 (ε4).

You inherit two copies, one from each parent, so you will effectively fall into the bucket of one of six combinations:

- ε2/ε2;
- ε3/ε3;
- ε4/ε4;
- ε2/ε3;
- ε2/ε4;
- ε3/ε4.

---

**Table 1. Estimated percentages (frequency) of the U.S. population with the six possible *APOE* pairs ([Raber et al., 2004](https://www.ncbi.nlm.nih.gov/pubmed/15172743)) and odds ratio for developing Alzheimer’s disease according to apolipoprotein E (*APOE*) genotype in Caucasians: clinic/autopsy studies ([Farrer et al., 1997](https://www.ncbi.nlm.nih.gov/pubmed/9343467)).** Adjusted for age and study. Odds ratio for *APOE* genotype derived assuming a reference odds ratio of 1 for *APOE* ε3/ε3 genotype.

![](https://peterattiamd.com/wp-content/uploads/2018/07/apoe-frequency-and-risk-1024x303.png)

---

- While a number of people argue there’s nothing you can do with this information, Peter argues that Alzheimer’s disease is preventable—you can reduce the risk for the disease—and genotyping gives us greater insight into this risk;

---

![](https://peterattiamd.com/wp-content/uploads/2018/07/ad-fig1-kaplan-attia-palenchar-300x247.png)

**Figure 1. Modalities of Alzheimer’s disease (AD) prevention.** Systemic interventions (in orange, on left) should be the foundation of any AD prevention program and are aimed at correcting an unhealthy baseline. Targeted interventions (in blue, on right) can be used for patients with specific indications. [[Schelke et al., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5907312/)]

---

- Peter co-authored a [paper on Alzheimer’s prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5907312/) this year ([Schelke et al., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5907312/)) that discussed the mechanisms of risk reduction in Alzheimer’s disease.

##### **LDL-P (or ApoB)**

Peter explains the similarities and differences between LDL-P and ApoB, and notes that this number is dynamic, and is affected by four things:

1. The amount of cholesterol you synthesize.
2. The amount of cholesterol (or sterol) that you reabsorb.
3. The amount of triglycerides (TGs) you have to carry around.
4. Your clearance of the particles (which is primarily driven by the LDLR on the liver).

#####

##### **The four lipoproteins to know, in approx order of importance:**

1. Lp(a).
2. LDL-P.
3. Small LDL-P (typically < 20 nanometers).
4. VLDL remnant (we can’t directly measure this).

#####

##### **Remnant cholesterol**

The poor man’s proxy for VLDL remnant: [remnant cholesterol](https://en.wikipedia.org/wiki/Remnant_cholesterol), from a standard lipid panel. Intermediate density lipoproteins (IDLs) are also referred to as VLDL remnants.

---

![](https://peterattiamd.com/wp-content/uploads/2018/07/null-2.png)

**Figure 2. Remnant cholesterol.** Image credit: Dave Feldman. [Cholesterolcode.com](https://cholesterolcode.com/remnant-cholesterol-what-every-low-carber-should-know/).

---

Remnant cholesterol = Total cholesterol – HDL-C – LDL-C.

Especially helpful if the LDL-C is measured directly. But, LDL-C is typically estimated using the [Friedewald equation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4226221/), obviating the need for an ultracentrifuge.

- LDL = Total cholesterol – HDL-C – VLDL-C;
- Friedewald equation: LDL-C ≈ Total cholesterol – HDL-C – TG/5.\*

\* Friedewald substituted TG/5 in for VLDL-C (or remnant cholesterol).

Therefore, VLDL-C is estimated by dividing TG by 5. Getting a direct LDL-C measurement and then subtracting HDL-C and LDL-C from total cholesterol is a better The above is a better proxy for VLDL remnant than TG / 5.

Peter likes to see this number less than 15 mg/dL.

An example:

John Smith

- Total cholesterol: 204 mg/dL;
- LDL-C (direct): 116 mg/dL;
- HDL-C: 76 mg/dL;
- TG: 89 mg/dL.

Remnant cholesterol:

- = Total cholesterol – HDL-C – LDL-C;
- = 204 – 76 – 116;
- = 12 mg/dL.\*

\* If LDL-C was calculated using the Friedewald equation (and the non-LDL-C lab test results were the same):

- LDL-C ≈ Total cholesterol – HDL-C – TG/5;
- ≈ 204 – 76 – 11;
- ≈ 204 – 76 – 11;
- ≈ 117;
- 11 mg/dL represents the estimated remnant cholesterol (54 / 5 = 10.8).

#####

##### **Oral Glucose Tolerance Test (OGTT)\***

##### \* An OGTT that measures insulin as well as glucose:

- Measure fasting insulin and glucose;
- Then take 75 grams of glucola (Peter now prefers 100 grams of glucose in the form of food (rice or potatoes) for this test);
- Measure insulin and glucose at 1-hour;
- Measure insulin and glucose at 2-hours.
- For glucose, [normal results are](https://medlineplus.gov/ency/article/003466.htm):
  - Fasting: 60-100 mg/dL (Peter likes to see < 90);
  - 1 hour: < 200 (Peter likes to see < 120-130 [depending on the amount of muscle mass one has];
  - 2 hours: < 140 (Peter likes to see < 100);
  - You can be within these ranges and still have hyperinsulinemia, especially postprandially.
- For insulin, [reference ranges are](https://emedicine.medscape.com/article/2089224-overview?pa=l5g6Y9cYDccHohrBPIVdz0zUN7ZiZH1%2FOnYFKTtz2q9v5Ultl15XSsqFFYrY6QMr56MI7dGTgNawPfsOtJla9Q%3D%3D):
  - Fasting: < 25 mIU/L (Peter likes to see < 6);
  - 1 hour: 18-276 (Peter likes to see this < 30);
  - 2 hours: 16-166 (Peter likes to see this < 20).

“If you’re not seeing the insulin, you’re not knowing the answer,” Peter says. If you’ve failed an OGTT on glucose levels, then you’ve *really* failed.

##### **Peter shares an example of an OGTT patient:**

- His fasting insulin and glucose look good;
- At one hour his glucose is 114, but his insulin is 56;
- At 2 hours, he’s fine, below 100 glucose, and his insulin is below 20;
- The implication, even with just one flaw on his record (1-hour insulin of 56): that’s diabetes *in situ*, according to Joseph Kraft;
- That’s postprandial hyperinsulinemia, which is a harbinger to insulin resistance.

With an OGTT on a ketogenic diet (KD), Peter has seen elevated glucose and insulin in a number of individuals after being challenged. Low fasting insulin and glucose, but sky high insulin and glucose when challenged.

#####

##### **ALT**

Peter likes to see ALT lower than 20 and pretty much ignores the current [reference ranges](https://www.mayomedicallaboratories.com/test-catalog/Clinical+and+Interpretive/8362) (7-55 U/I for males, 7-45 U/I for females):

- We’ve seen such a big shift upward in ALT at a population level, coincident with a rampant increase in fatty liver disease;
- The labs basically show you +/- 1-2 standard deviations of the population average. The references are showing you what’s average, they’re not showing you what’s optimal;
- Up to 42 ALT is considered normal on the lab test, but if Peter sees a patient with a 38, he’s highly alarmed;
- By 2025, the NAFLD => NASH => cirrhosis will be the leading indication for a liver transplant in the US. In 2000, less than 1% of liver transplants were due to NAFLD.

Peter also mentions that estradiol (E2) levels in men are rising. Peter’s seen two upward shifts in the reference range, at the same lab, over eight years. Men are becoming more and more estrogenized. Another topic for another time.

§

## Tests for Longevity [27:15]

- *APOE* genotype;
- Lp(a) (inverse relationship) (there is some data to suggest that elevated Lp[a] can be found in some centenarians).

Peter takes a reverse engineering approach to longevity. He’s looking at three things in blood, disease-wise:

1. *What is this person’s risk for atherosclerotic disease (heart disease or stroke)?*
2. *Risk for cancer?*
3. *Risk for neurodegenerative disease?*

##### **Risk for atherosclerotic disease (heart disease or stroke)**

Cardiovascular disease is primarily driven by three things:

1. Lipoproteins (Lp[a], LDL-P, small LDL-P, VLDL remnant).
2. Inflammation (nonspecific: fibrinogen, hs-CRP; specific: oxLDL, Lp-PLA2, oxPL).
3. Endothelial dysfunction (insulin, Hcy, ADMA, and SDMA).

You can see a lot of signs of cardiovascular disease in blood.

- The younger you are, the more your blood tells Peter about your risk of cardiovascular disease;
- The older the patient gets, the more Peter relies on CT angiograms;
- Calcium score can be somewhat helpful in a younger patient, but it can be misleading at times;
  - A recent paper looked at calcium score and found that 50% of patients that had events, had them at a site that had noncalcified lesions ([Korosoglou et al., 2018](https://www.ncbi.nlm.nih.gov/pubmed/29759509));
- James O’Keefe just authored a paper that looked at added sugars, cardiovascular health, insulin resistance, and hyperinsulinemia ([DiNicolantonio and O’Keefe, 2018](https://openheart.bmj.com/content/4/2/e000729)).

#####

##### **Risk for cancer**

- Blood biopsies appear to be on the horizon, but currently, there’s not much blood insight;
- Cancer comes down to inflammation, metabolic health, and minimizing hyperinsulinemia, so there is overlap with tests looking at these components;
- A few outliers may be [*BRCA* mutations](https://en.wikipedia.org/wiki/BRCA_mutation) or [Lynch](https://ghr.nlm.nih.gov/condition/lynch-syndrome), where genetic testing yields some insight;
- IGF might be able to provide some insight, but it’s controversial;
- [Listen to the podcast with Rhonda Patrick](https://peterattiamd.com/rhondapatrick/), Ph.D. for more on this.

#####

##### **Risk for neurodegenerative disease**

- For Alzheimer’s disease (AD), what’s good for the heart is good for the brain;
- Also, looking at *APOE* can tell you about risk.
- *TOMM40* SNPs, and [variable-length polymorphisms](https://www.ncbi.nlm.nih.gov/pubmed/20029386), may tell us something about risk

##### **There are a few components to AD:**

1. Vascular component.
2. Metabolic component.
3. Toxin component (we have the least insight into this).

§

## Wearables [35:00]

- The difference between Peter’s fasting glucose of 90 vs. 105 is much more a function of his cortisol level than anything to do with insulin sensitivity, which he learned in part through using a [continuous glucose monitor](https://www.dexcom.com/g6-cgm-system) (CGM);
- The [Oura ring](https://ouraring.com/) is another wearable that’s sticky for Peter, which tracks sleep and HRV, among other things.

##### **Peter’s wearable criteria:**

1. What you’re measuring matters.
2. What you’re measuring differs from day to day in ways that are not intuitive or linear.
3. What you’re measuring you can actually measure accurately.
4. You can report the data in a timeframe that is relevant to learn (or act on).
5. You can provide corrective, actionable feedback, if necessary.

§

## Selecting a Great Doctor [47:00]

##### **Peter’s four pillars (the Quadruple-As?) for finding a good physician:**

1. Availability: how much access do you have to your MD?
2. Affability: you should be able to get along with your doctor, and they need to bring you along, and listen ([in one study](https://www.ncbi.nlm.nih.gov/pubmed/11456245), patients were interrupted every 12 seconds during a visit).
3. Ability: the single-most important thing.
4. Advocacy: the physician who is connected and can get you through the storm.
   1. So much of what we learned in medical school is irrelevant by the time we’re practicing;
   2. The lag between when something becomes a finding and when it becomes mainstream or obvious enough that everyone’s doing it, that lag is about 12-20 years;
   3. So it is important that physicians stay informed of the latest literature.

##### **Questions to ask your doctor, and things to determine:**

- How busy are you clinically?
- How much time do you spend reading literature?
- Try to figure out his or her curiosity and passion for learning. “If you’re not learning quite a bit as a doctor, you’re probably not practicing great medicine,” Peter says.

§

## Racing [54:30]

##### **What was the hardest thing for you to learn when you were becoming a driver?**

#####

##### **The elements, and tactics, of driving:**

1. Throttle.
2. Brake.
3. Steering.
4. Shifting.

You have four contact points (tires). Everything else is in service of those things.

##### **There are four things that determine how fast you’re going to go:**

1. Tires.
2. Engine.
3. Chassis.
4. Driver.

##### **What does the driver control?**

- Vision, and the line a driver takes;
- There is an optimal line to go around a racecourse;
- Understeer and oversteer;
  - Understeer is a relatively easy problem to correct and see;
  - ##### **Learning to correct an oversteer is the greatest learning curve;**
  - You don’t see it, you feel it;
  - While correcting it is well-understood, it’s not intuitive.

§

## Thoughts on Senna [1:02:45]

§

## Thoughts on [iRacing](https://www.iracing.com/) [1:09:15]

##### **How does iRacing improve your real-world racing skills, and could you do more official races or races with fans? Also, favorite car?**

- Favorite open wheel car: Pro Mazda;
- Favorite closed wheel cars: Ferrari 448 GTE and RUF 911;
- Daily driver? Used to be the E92 M3;
- The need for speed: Top Gun is getting a sequel: [Top Gun: Maverick](https://en.wikipedia.org/wiki/Top_Gun:_Maverick)

§

## Exercise [1:15:00]

##### **Knowing what you do now, how would your preparation for those long open water swims have changed? Still as many hours in the water prior to a big event? Would your feeding strategy be any different?**

#####

##### **Four stages of competence:**

1. Unconsciously incompetent.
2. Consciously incompetent.
3. Consciously competent.
4. Unconsciously competent.

##### **How Peter used to fuel his open water swims:**

- [Hammer Perpetuem](https://www.hammernutrition.com/products/perpetuem/)…high carb fuel;
- Maxum ([maltodextrin](https://en.wikipedia.org/wiki/Maltodextrin)) spiked [Cytomax](https://www.cytomax.com/),

##### **Peter would be a fat-adapted athlete today as an open water swimmer:**

- Lowering his [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient) (RQ);
- He’d fuel with;
  - [Generation UCAN](https://shop.generationucan.com/?gclid=EAIaIQobChMIo_vB6uaK3AIVDZ6fCh2k1gBcEAAYASAAEgI6ivD_BwE)
  - [Biosteel](https://www.biosteel.com/en-ca/products/high-performance-sports-mix/11440)

Peter also discusses how you feed an open water swimmer (and Tour de France cyclists).

§

## Peter’s Exercise Regimen [1:20:15]

- Lift weights M/W/F;
- Some metabolic conditioning mixed in;
- T/Th/Sa/Su riding a bike, with either the [Peloton](https://www.onepeloton.com/bike?gclid=EAIaIQobChMI_KiH5eiK3AIVysDICh0GSwpLEAAYASAAEgKbhPD_BwE), or [wahoo KICKR](https://www.wahoofitness.com/devices/bike-trainers) ([TrainerRoad](https://www.trainerroad.com/) is his preferred software);
- Regular movement prep: flexibility, mobility, and movement correction for injury prevention
- Peter doesn’t train, he exercises;
- Peter expands on lifting weights your entire life as something you should never stop doing;
- Exercise to improve lifespan vs healthspan;
- Exercise likely improves lifespan by reducing the risk of atherosclerotic disease, cancer, and neurodegenerative disease;
- Exercise can provide cognitive benefits (e.g., BDNF);
- Any exercise that helps you dispose of glucose more efficiently is beneficial;
- More muscle creates a bigger glucose sink, which is probably going to improve things from an energetic and metabolic perspective;
- Are there benefits on the cardio system that goes beyond that? Probably, yes;
- Exercise has an even greater impact on healthspan: improving your quality of life.
- It becomes harder to maintain muscle mass as you get older and is probably the single most important factor in whether you become frail into old age or not;
- Rule #1 in lifting weights: don’t get hurt;
- Hex bar deadlift is an example of an exercise Peter does often and accepts the tradeoff of any benefits that a straight-bar deadlift may provide for the reduced risk of injury from a hex Bar deadlift;
- Peter only presses with dumbbells;
- All overhead shoulder work is stability work;
- Everything that works the shoulders is done below the shoulders;
- How you minimize how quickly you’re going to decline is very important.

§

## More on Wearables [1:28:50]

##### **The CGMs out there:**

- Dexcom ([Peter uses the G6](https://www.dexcom.com/g6-cgm-system))
- [Libre](https://www.freestylelibre.us/)
- [Medtronic](https://www.medtronicdiabetes.com/treatments/continuous-glucose-monitoring)

Peter also wears an Oura ring.

§

## Thinking About Thinking / Learning About Learning [1:33:00]

##### **What is your strategy for learning something deeply? How does your learning process work?**

#####

##### **General strategies and tactics:**

- Read a lot of papers;
- Watch a lot of lectures;
- Your learning often comes from doing: patients teach Peter a lot;
- Seek out mentors, teachers, and researchers you admire;
- Know how to pick and choose your teacher and/or mentor;
- Understand how you best learn;
- Look at the most recent review articles;
- Watch lectures given by the researchers to a broader audience;
- Understand the origins and history of the topic;
- Learn from people who understand the topic deeply;
- Learn to teach to understand ([the Feynman technique](https://fs.blog/2012/04/learn-anything-faster-with-the-feynman-technique/));
- “If I had more time, I would have written a shorter letter,” [attributed to Mark Twain](https://quoteinvestigator.com/2012/04/28/shorter-letter/)

##### **More specific strategies and tactics:**

- Peter starts with the most recent review article on a topic;
- Peter never starts with the primary literature because it’s too narrow and he wants a larger overview;
- For example, for Lp(a), he would go into PubMed and search “Lp(a) review”;
- Try to figure out who the luminaries are on the topic: in this example of Lp(a), [Sam Tsimikas](https://twitter.com/Lpa_Doc) sticks out;
- Then read the last three review articles by the individual(s);
- Start by looking at, and understanding, the figures in those papers;
- First, go 80/20: Try to squeeze out an 80% understanding of the topic;
- Then, go 20/80: contact the people who can get you closer to 100% on the topic.

##### **In your life to date, what did you waste the most time doing, and what do you wish you’d done with that time, instead?**

It sounds trite, and like the serenity prayer:

- Not accepting the things that couldn’t be changed;
- Not putting more focus on changing the things that could be changed;
- Not spending more time in the present with the people that matter;
- While these may be regrets, they also taught Peter that doing the opposite is what he wants to do instead.

#####

##### **What impact did your upbringing have on your insane career path/constant drive?**

##### **I’d like to know what your process is for forming your beliefs. There seem to be a lot of narratives/absolutes that people get stuck on in the nutrition world and really miss the “it depends” part that you seem to have. [1:50:30]**

- [All facts have a half-life](https://fs.blog/2012/12/the-half-life-of-facts/);
- Feynman [talked about](https://www.amazon.com/Pleasure-Finding-Things-Out-Richard/dp/0465023959) how all we do in science is increase the probability that we believe something is true. “A scientist is never certain. We all know that. We know that all our statements are approximate statements with different degrees of certainty; that when a statement is made, the question is not whether it is true or false but rather how likely it is to be true or false.” — Richard P. Feynman;
- We don’t necessarily have to be right, we want to know the most;
- If we think: how can we know the most, rather than how can we be right the most, it takes a little bit of the edge;
- Peter references [a scene from Charlie Wilson’s War;](https://www.youtube.com/watch?v=B2L1-TgfKb4)
- “[The first principle is that you must not fool yourself—and you are the easiest person to fool](https://calteches.library.caltech.edu/51/2/CargoCult.htm).” — Richard P. Feynman;
- “[Science is the belief in the ignorance of experts](https://www.fotuva.org/feynman/what_is_science.html).” — Richard P. Feynman;
- “[If it disagrees with experiment, it’s wrong](https://www.youtube.com/watch?v=OL6-x0modwY).” — Richard P. Feynman.

§

## Peter’s Diet [1:57:45]

##### **Why did you decide to discontinue your ketogenic diet? What differences in your health and performance have you noticed since?****What does your diet look like these days?**

- Peter wanted more flexibility in his diet and left nutritional ketosis, mostly because he was missing his homemade curry stir fry ([mentioned here](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/)), which helped kick him out of the land of ketosis;
- Peter had about the best response someone can have on a ketogenic diet;
- Everything got better: performance (eventually both aerobic and anaerobic), mental clarity, biomarkers, and resilience;
- Peter had a hard time telling his daughter why he didn’t eat certain foods;
- Peter does time-restricted feeding (TRF), but doesn’t necessarily restrict carbohydrates (he does restrict Wheat Thins and We-Thins);
- Peter occasionally does prolonged fasts;
- Peter was in nutritional ketosis for about three years straight (and [wrote about his experience on his site](https://peterattiamd.com/category/ketosis/))
- [Peter’s fancy coffee](https://peterattiamd.com/wired-think-scientifically-can-done/);
- [The Peter Kaufman shake](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/);
- [Big ass salad;](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/)
- Peter rotates between lamb, beef, and other meats for dinner.

§

## Potential Future Topics [2:08:15]

##### **Statins**

- When to use, why do you use, which ones to use?
- Side effects?
- Unintended consequences?
- Probabilistic medicine and RAROC.

See [the podcast with Ron Krauss, M.D.](https://peterattiamd.com/ronkrauss/), for more on statins.

#####

##### **Smart drugs & supplements**

- Drugs & supps for cognition;
- Drugs & supps for performance.

#####

##### **Heat and cold therapy**

- Sauna;
- Hyperthermia;
- Cold therapy.

See the [podcast with Rhonda Patrick, Ph.D.](https://peterattiamd.com/rhondapatrick/), for more on heat and cold therapy.

#####

##### **HRT**

- Testosterone & HRT in men;
- Estrogen & HRT in women.

#####

##### **Autophagy**

- What is it?
- Can we quantify it?
- What can we do about it?

§

§

## Selected Links / Related Material

- **The dose makes the poison**: [Is sugar toxic?](https://peterattiamd.com/is-sugar-toxic/) | Peter Attia (peterattiamd.com) [4:45]
- **Frequency of *APOE*** alleles: [ApoE genotype accounts for the vast majority of AD risk and AD pathology](https://www.ncbi.nlm.nih.gov/pubmed/15172743) (Raber et al., 2004)
- ***APOE* genotype and Alzheimer’s risk**: [Effects of age, sex, and ethnicity on the association between apolipoprotein E genotype and Alzheimer disease: A meta-analysis](https://www.ncbi.nlm.nih.gov/pubmed/9343467) (Farrer et al., 1997)
- **Peter, Bob, and [Dan](https://loop.frontiersin.org/people/509094/overview) co-authored a paper with Richard Isaacson and his colleagues on Alzheimer’s prevention**: [Mechanisms of Risk Reduction in the Clinical Practice of Alzheimer’s Disease Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5907312/) (Schelke et al., 2018) [16:00]
- **VLDL remnants are also referred to as IDLs**: [Endocrinology: Adult and Pediatric (Seventh Edition)](https://www.sciencedirect.com/science/book/9780323189071) (Freeman and Walford, 2016) [19:30]
- **Friedewald equation**: [Comparison of a Novel Method vs the Friedewald Equation for Estimating Low-Density Lipoprotein Cholesterol Levels From the Standard Lipid Profile](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4226221/) (Martin et al., 2014) [19:30]
- **Friedewald equation**: [Low-carbohydrate diets increase LDL: debunking the myth](https://proteinpower.com/drmike/2009/06/22/low-carbohydrate-diets-increase-ldl-debunking-the-myth/) | Michael Eades (proteinpower.com) [19:30]
- **Remnant cholesterol calculation**: [Remnant Cholesterol – What Every Low Carber Should Know](https://cholesterolcode.com/remnant-cholesterol-what-every-low-carber-should-know/) | Dave Feldman (cholesterolcode.com) [19:30]
- **Diabetes *in situ***: [Detection of Diabetes Mellitus *In Situ*](https://academic.oup.com/labmed/article-abstract/6/2/10/2641019?redirectedFrom=fulltext) (Occult Diabetes) (Kraft, 1975) [23:15]
- **Calcium scores**: [The coronary calcium paradox: Yet another step towards the differentiation between stable and rupture-prone coronary plaques?](https://www.ncbi.nlm.nih.gov/pubmed/29759509) (Korosoglou et al., 2018) [29:00]
- **Insulin resistance and hyperinsulinemia**: [Added sugars drive coronary heart disease via insulin resistance and hyperinsulinaemia: a new paradigm](https://openheart.bmj.com/content/4/2/e000729) (DiNicolantonio and O’Keefe, 2018) [30:00]
- **Lp(a) in centenarians**: [Elevated lipoprotein(a) levels and small apo(a) isoforms are compatible with longevity: evidence from a large population of French centenarians](https://www.ncbi.nlm.nih.gov/pubmed/9543111) (Thillet et al., 1998)
- **Lp(a) in centenarians**: [Lipoproteins, vascular-related genetic factors, and human longevity](https://www.ncbi.nlm.nih.gov/pubmed?Db=pubmed&Cmd=ShowDetailView&TermToSearch=17990970&ordinalpos=2&itool=EntrezSystem2.PEntrez.Pubmed.Pubmed_ResultsPanel.Pubmed_RVDocSum) (Panza et al., 2007)
- ***TOMM40***:A TOMM40 variable-length polymorphism predicts the age of late-onset Alzheimer’s disease (Roses et al., 2010) [44:30]
- **Caffeine metabolism**: [For Coffee Drinkers, the Buzz May Be in Your Genes](https://well.blogs.nytimes.com/2016/07/12/for-coffee-drinkers-the-buzz-may-be-in-your-genes/) | Anahad O’Connor (nytimes.com) [44:30]
- **Your doctor needs to liste**n: [Speaking and interruptions during primary care office visits](https://www.ncbi.nlm.nih.gov/pubmed/11456245) (Rhoades et al., 2010) [47:00]
- [*Senna* documentary](https://en.wikipedia.org/wiki/Senna_(film)) | wikipedia.org [1:05:00]
- [Senna Foundation](https://www.ayrtonsenna.com.br/en/) | [1:05:00]
- **Peter’s favorite YouTube clip (Chris Harris drifting)**: [Drift Hero – Chris Harris Porsche 911 GT3 RS Montage](https://www.youtube.com/watch?v=k2LpPGFUzbw&t=27s) | youtube.com [1:01:40]
- **Peter’s favorite YouTube clips**: [F1’s Greatest Lap? Ayrton Senna at Donington 1993](https://www.youtube.com/watch?v=3GOEorrE4mY) | youtube.com [1:03:00]
- **Peter’s favorite YouTube clips**: [Ayrton Senna Qualifying Lap Monaco](https://www.youtube.com/watch?v=wQgP9nugt5I) | youtube.com [1:03:00]
- **Peter’s favorite YouTube clips**: [Ayrton Senna’s Heel-and-toe](https://www.youtube.com/watch?v=8By2AEsGAhU&t=76s) | youtube.com
- **Favorite open wheel cars**: [Pro Mazda](https://www.iracing.com/cars/star-mazda/) | iracing.com [1:12:20]
- **Favorite closed wheel cars**: [Ferrari 488 GTE](https://www.iracing.com/cars/ferrari-488-gte/) | iracing.com [1:13:00]
- **Favorite closed wheel cars**: [Porsche Ruf Rt 12 R](https://www.iracing.com/cars/ruf-rt-12-r/) | iracing.com [1:13:00]
- **Daily driver**: [BMW E92 M3](https://en.wikipedia.org/wiki/BMW_M3#E92_M3_GTS) | wikipedia.org
- **The need for speed**: [Top Gun](https://en.wikipedia.org/wiki/Top_Gun) | wikipedia.org [1:14:20]
- [Top Gun: Maverick](https://en.wikipedia.org/wiki/Top_Gun:_Maverick) | wikipedia.org [1:14:20]
- **Feeding Tour de France riders**: [What is in a Tour de France rider’s musette?](https://roadcyclinguk.com/racing/features-racing/tour-de-france-riders-musette/) | Oliver Gill (roadcyclinguk.com) [1:19:45]
- **Feeding Tour de France riders**: [The secret life of a soigneur](https://www.cyclingweekly.com/news/racing/secret-life-soigneur-230187) | Sophie Hurcom (cyclingweekly.com) [1:19:45]
- **Learn to teach to understand**: [The Feynman Technique: The Best Way to Learn Anything](https://fs.blog/2012/04/learn-anything-faster-with-the-feynman-technique/) | Farnam Street (fs.blog) [1:40:00]
- **Feynman on uncertainty**: [The Pleasure of Finding Things Out: The Best Short Works of Richard P. Feynman](https://www.amazon.com/Pleasure-Finding-Things-Out-Richard/dp/0465023959) by Richard P. Feynman [1:50:00]
- **Being right the most vs. knowing the most**: [How to Live a Longer, Higher Quality Life, with Peter Attia, M.D.](https://investorfieldguide.com/attia/) | Invest Like the Best podcast (investorfieldguide.com) [1:53:00]
- **Charlie Wilson’s war scene**: [Classic Charlie Wilson’s War/Zen Master](https://www.youtube.com/watch?v=B2L1-TgfKb4) | youtube.com [1:53:15]
- **The first principle**: [Cargo Cult Science](https://calteches.library.caltech.edu/51/2/CargoCult.htm) by Richard P. Feynman [1:55:45]
- **The belief in the ignorance of experts**: [What is Science?](https://www.fotuva.org/feynman/what_is_science.html) by Richard P. Feynman [1:55:45]
- **If it disagrees with experiment**: [Richard Feynman – Scientific Method](https://www.youtube.com/watch?v=OL6-x0modwY) | youtube.com [1:55:45]
- **Curry stir fry, the Peter Kaufman shake, and the big ass salad**: [What I actually eat, part III (circa Q1 2014)](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/) | Peter Attia (peterattiamd.com) [1:58:00]
- **Peter’s fancy coffee (see reference #1 in the article)**: [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/) | Peter Attia (peterattiamd.com) [1:58:00]
- **Statins**: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | The Drive podcast (peterattiamd.com) [2:10:00]
- **Heat and cold therapy**: [Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more (EP.02)](https://peterattiamd.com/rhondapatrick/) | The Drive podcast (peterattiamd.com) [2:10:00]

§

§

## People Mentioned

- [David Sinclair](https://twitter.com/davidasinclair?lang=en) (and resveratrol) [11:30]
- [Joseph Kraft](https://academic.oup.com/labmed/article-abstract/6/2/10/2641019?redirectedFrom=fulltext) (on insulin measurements) [23:40]
- [Rob Lustig](https://twitter.com/RobertLustigMD?lang=en) (on ALT) [24:45]
- [James O’Keefe](https://twitter.com/DRJamesOKeefe?lang=en) (on cardiovascular health and T1 diabetes) [30:00]
- [Richard Isaacson](https://weillcornell.org/risaacson) (on AD prevention) [31:50]
- [Ayrton Senna](https://www.ayrtonsenna.com.br/en/) (racing driver) [1:02:45]
- [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) (racing driver) [1:04:25]
- [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost) (racing driver) [1:06:00]
- [Nigel Mansell](https://en.wikipedia.org/wiki/Nigel_Mansell) (racing driver) [1:06:00]
- [Nelson Piquet](https://en.wikipedia.org/wiki/Nelson_Piquet) (racing driver) [1:06:00]
- [Lewis Hamilton](https://twitter.com/LewisHamilton?lang=en) (racing driver) [1:06:00]
- [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel) (racing driver) [1:06:00]
- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) (racing driver) [1:08:00]
- [Tom Dayspring](https://twitter.com/drlipid?lang=en) (Peter learns lipidology from) [1:34:00]
- [Ron Krauss](https://peterattiamd.com/ronkrauss/) (Peter learns lipidology from) [1:34:00]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) (Peter learns lipidology from) [1:34:00]
- [Jamie Underberg](https://twitter.com/lipiddoc?lang=en) (Peter learns lipidology from) [1:34:00]
- [Tara Dall](https://www.taradall.com/) (Peter learns lipidology from) [1:34:00]
- [Siddhartha Mukherjee](https://twitter.com/DrSidMukherjee) (author of [Emperor of All Maladies](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916)) [1:42:30]
- [Sam Tsimikas](https://twitter.com/Lpa_Doc) (on his understanding of Lp[a]) [1:43:40]
- [Patrick O’Shaughnessy](https://twitter.com/patrick_oshag) (had Peter on his podcast) [1:53:00]
- [Steve Phinney](https://blog.virtahealth.com/author/stephenphinney/) (on ketosis) [1:59:45]
- [Peter Kaufman](https://www.generationucan.com/directors_4.html) (of the infamous shake) [2:02:00]
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) (future guest on depression) [2:09:30]
- [Rhonda Patrick](https://peterattiamd.com/rhondapatrick/) (past guest on heat and cold therapy) [2:09:45]
- [Dom D’Agostino](https://twitter.com/DominicDAgosti2?lang=en) (future guest on ketosis) [2:10:00]
- [Ron Krauss](https://peterattiamd.com/ronkrauss/) (on statins) [2:10:00]
- [David Sabatini](https://twitter.com/DMSabatini?lang=en) (future guest on rapamycin, mTOR, and autophagy) [2:10:00]
- [Greg Wyant](https://sabatinilab.wi.mit.edu/membersDS.html) (on autophagy) [2:10:00]
- [Monther Abu-Remaileh](https://twitter.com/abu_remaileh) (on autophagy) [2:10:00]
- [Mark Bell](https://twitter.com/MarkSmellyBell) (future guest on exercise) [2:10:00]
- [Chris Bell](https://twitter.com/BigStrongFast) (future guest on exercise) [2:10:00]

#### **\* If you have any questions for the next AMA (#2), please submit them to the comments section of this post. \***

§