# #255 ‒ Latest therapeutics in CVD, APOE’s role in Alzheimer’s disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.

**Source:** [https://peterattiamd.com/johnkastelein/](https://peterattiamd.com/johnkastelein/)

---

John Kastelein is a renowned expert in lipoprotein metabolism and atherosclerotic cardiovascular disease (ASCVD) research. In this discussion, John delves deep into familial hypercholesterolemia (FH), a genetic disorder characterized by high levels of LDL cholesterol in the blood that increases the risk of developing heart disease. He covers its definition, genetic underpinnings, and clinical identification. He then explores the therapeutic options available for the prevention and treatment of cardiovascular disease, including the captivating history of CETP inhibitors. He explains the past shortcomings of previous CETP inhibitors before underscoring the compelling potential of the latest iterations, not only for cardiovascular disease but also for conditions like Alzheimer’s disease and type 2 diabetes. Moreover, he unveils the intricate role of APOE, shedding light on why the APOE4 isoform codes for a protein that significantly increases the risk of Alzheimer’s disease and cardiovascular disease. Concluding the discussion, John shares a profound sense of optimism, envisioning the possibility of targeted therapeutic interventions for high-risk patients in the near future.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/johnkastelein/the_Drive_public.png)

Play

#255 ‒ Latest therapeutics in CVD, APOE's role in Alzheimer's disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.

#255 ‒ Latest therapeutics in CVD, APOE's role in Alzheimer's disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.

1x15s30s

0:002:04:18

## We discuss:

- Familial hypercholesterolemia (FH): a genetic condition [4:30];
- Differentiating between phenotype and genotype when it comes to FH [9:45];
- The pathophysiology related to mutations of FH [15:30];
- Clinical presentations, physical manifestations, and diagnosis of FH [22:00];
- Criteria used to make a formal diagnosis of FH [30:15];
- Why a small fraction of people with FH do not develop premature ASCVD [34:15];
- Treatment and prevention for those with FH [39:45];
- Addressing the assertion by some that elevated LDL is not casual in cardiovascular disease [52:45];
- The history of CETP inhibitors and the role of the CETP protein [55:45];
- The thrifty gene hypothesis and why genes underlying FH may have been preserved [1:09:00];
- The compelling potential of the latest CETP inhibitor (obicetrapib) [1:13:00];
- Promising results from phase 3 trials exploring obicetrapib [1:27:45];
- Why the APOE4 allele increases the risk of Alzheimer’s disease, and the connection to blood lipids [1:41:30];
- The role of APOE in cardiovascular disease [1:51:45];
- Takeaways and looking ahead [1:57:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- John Kastelein is a genetic researcher and clinician scientist known for his work in the field of familial hypercholesterolemia and the development of lipid modulating drugs
- He is currently a Professor of Genetic Medicine at the University of Amsterdam where he leads the Department of Vascular Medicine
- John has been the main driving force behind the development of a treatment for homozygous [familial hypercholesterolemia](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia), a severe form of FH
  - Some of you may be listening to this saying, “*What the heck are you talking about?*”
  - Well, it’s important to understand that FH or familial hypercholesterolemia is the second most common form of hereditary heart disease right after elevated [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a))
  - And you know from probably listening to previous versions of this podcast that elevated Lp(a) is staggeringly prevalent in the population and by extension, therefore, so too is various forms of FH
- While we use FH as an important place to start this discussion and understand therapeutic options, the subject matter that we cover here is applicable to anybody who’s interested in minimizing their risk of cardiovascular disease
- John has also led several clinical trials including the pivotal ODYSSEY LONG TERM and ODYSSEY OUTCOMES studies, which helped to establish the safety and efficacy of PCSK9 inhibitors in the treatment of FH and other forms of hypercholesterolemia
- We start the discussion by focusing on familial hypercholesterolemia
  - We talk about what it is, how you define it, how you can be aware if you have this, what the genetics are that underpin it, what we do with kids that have this, etc.
- We then talk about the history of CETP inhibitors, which is indeed a sordid history
  - These have been a class of completely unsuccessful drugs that have resulted in much hype and fanfare without any tangible results
  - However, John makes a pretty compelling case for the most recent version of these drugs to be not only a potential game changer for cardiovascular disease, but perhaps even more interestingly for Alzheimer’s disease and type 2 diabetes
- The final topic of discussion is that in the role of [*APOE*](https://en.wikipedia.org/wiki/Apolipoprotein_E)
  - Traditionally when you hear Peter talk about *APOE*, he’s talking about the gene APOE and its three isoforms: *APOE 2, APOE 3, APOE 4*
    - It’s important to understand that those genes code for a protein that goes by the same name apoE, although it is not fully capitalized, and that’s how you know the difference when you’re reading it
  - We talk about what this protein does
  - We talk about why someone with the *APOE4* gene is at much greater risk of Alzheimer’s disease and cardiovascular disease
    - Even though the [isoform](https://en.wikipedia.org/wiki/Protein_isoform) of apoE is only 1 [amino acid](https://en.wikipedia.org/wiki/Amino_acid) different from the one encoded by *APOE3*
- This ties nicely into the discussion of how this most recent CETP inhibitor might work
- Peter is left with a sense of profound optimism that sometime in the next five years, we may indeed have therapeutic molecules that we can use specifically for high-risk patients such as those with *APOE4*
- This discussion surprised and delighted Peter much more than he expected
- Even though it’s a technical topic, it is something that is going to be of great interest to anybody who cares about heart health and brain health

## Familial hypercholesterolemia (FH): a genetic condition [4:30]

- This podcast came across Peter’s radar courtesy of one of his mentors, [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876)
- Cardiovascular disease is the leading cause of death globally, and Peter doesn’t think you can state the stats enough
  - Last time he looked, 19 million people died in the world due to [ASCVD](https://en.wikipedia.org/wiki/Coronary_artery_disease)
  - The second place killer was cancer with around 12-13 million deaths (not even close)
- For this reason, Peter thinks we need to take every opportunity to educate people about this

**The genetic condition familial hypercholesterolemia (FH)**

- This is probably more prevalent that people realize
- Thousands of people listening to this podcast are probably affected by it
- John was the first in the Netherlands who had a large scale organization to find people with [FH](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia)
- John trained in Vancouver
- He was a Visiting Professor in Vancouver by [Michael Hayden](https://medgen.med.ubc.ca/michael-hayden/)
- John had his Canadian exam
- He worked in a lipid clinic in Vancouver in a time when there were hardly no lipid clinics in Europe
- When he got back to Europe and started the lipid clinic in Amsterdam, about 60% of all of his referrals were FH
  - He wondered why this was so
- Holland is about the size of Rhode Island and it has 18 million people, but these people have not really moved in the past
  - So there are large provinces with consanguinity, though not as much as with the French Canadians or the South Africans
- He got a huge 30 million euro grant from the Dutch government to actively find people with FH
- At the time, there was severe anterior MIs ([myocardial infarction](https://en.wikipedia.org/wiki/Myocardial_infarction)) in men between the ages of 20-30
  - John can almost remember all of them
  - These were people who were fit and didn’t know they had an LDL of 300 mg/dL from birth onwards
  - They would be playing tennis and get a massive anterior MI
  - In those days there was not much stenting yet, and you could only do vague, superficial things
- FH is a true [autosomal dominant disease](https://en.wikipedia.org/wiki/Dominance_(genetics)), meaning it’s not [sex-linked](https://en.wikipedia.org/wiki/Sex_linkage)
  - You only need to get the gene from one parent
- It’s almost 100% [penetrant meaning that if you have a robust mutation in one of the genes that cause FH, you’re almost certain to get the phenotype](https://en.wikipedia.org/wiki/Penetrance)
  - And that phenotype starts very early
- His clinic in Amsterdam is the largest pediatric lipid clinic in the world
  - They have seen over 2,000 children with heterozygous FH
- This disease starts very early in life
  - It becomes symptomatic in the teenage years in the sense that the cholesterol that is elevated in the circulation starts depositing on the tendons, especially the [extensor tendons](https://en.wikipedia.org/wiki/Extensor_expansion) on the dorsum of the hand and in the [achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon)
  - Then you start very slowly seeing the arcus in the eye, and sometimes the deposits of cholesterol on the eyelids, the [xanthelasma](https://en.wikipedia.org/wiki/Xanthelasma) (shown below)

***Cholesterol deposition in the tendons and eye/ eyelids are the two first physical manifestations of FH***

![](https://peterattiamd.com/wp-content/uploads/2023/05/f1a-johnkastelein.png)

**Figure 1a. Xanthelasma palpebrarum, deposits of cholesterol.** Image credit: Wikipedia, [FH](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia) and [xanthelasma](https://en.wikipedia.org/wiki/Xanthelasma)

![](https://peterattiamd.com/wp-content/uploads/2023/05/f1b-johnkastelein.png)

**Figure 1b. Xanthelasma palpebrarum, deposits of cholesterol.** Image credit: Wikipedia, [FH](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia) and [xanthelasma](https://en.wikipedia.org/wiki/Xanthelasma)

- Often the first really serious manifestation of FH is [angina](https://en.wikipedia.org/wiki/Angina) or heart attack

> “*One of the things that is so dangerous about this disorder is that the plaque that you get in FH is a soft plaque*”‒ John Kastelein

- FH patients develop dangerous soft plaque
  - It’s a cholesterol-rich large plaque that is often proximal in the arteries
  - If a plaque like this bursts, you either have an occlusion of your entire [LAD](https://en.wikipedia.org/wiki/Left_anterior_descending_artery) or you have a mainstem occlusion which kills you right on the spot
    - Peter adds these are referred to as “the widow maker”

## Differentiating between phenotype and genotype when it comes to FH [9:45]

**Differentiate when you use the word phenotype and genotype. Explain how one defines the phenotype of FH**

- The patient’s family history of premature coronary disease comes first
- Second, these people have elevated LDL cholesterol without any other abnormality
  - HDL is normal, triglycerides are normal, but LDL is elevated
- You also need to find elevated LDL in [first-degree relatives](https://en.wikipedia.org/wiki/First-degree_relative) (children, parents, or siblings)
  - With that LDL, you can construct a family tree where you know who is affected and who is not
- Unfortunately, there’s overlap between unaffected family members and affected family members in LDL cholesterol, and that is why John decided a long time ago to go for the mutation (the genotype)
  - Because either you carry the mutation or you do not, there is no overlap
- This is a bit of an issue because unlike for example, Lp(a) where the phenotype is unambiguous [elevated Lp(a)], the genotype is also very clear
  - There’s a one-to-one mapping ‒ the *LPA* gene codes for Lp(a)
- With FH there is a very heterogeneous genetic set of causes
  - Peter read there may be over 3,500 different mutations that could cause FH and produce this phenotype

**Are we using an LDL-C cutoff of 190 mg/dL?**

- Yes, this is the number used for referrals
- The initial patients John saw all had LDLs of 300 or more

**Genotype of FH [12:15]**

- When you start determining a [genotype](https://en.wikipedia.org/wiki/Genotype), you have to be absolutely sure that your diagnosis is correct, because if your diagnosis is not correct and you don’t find a mutation, it’s meaningless
- John used the children as a diagnostic linchpin because if a child has high cholesterol, there’s almost no other cause for elevated LDL cholesterol in a child than FH
  - With the exception of primary [hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism)
- Peter wants to make sure people understand there are a lot of people walking around with an LDL cholesterol of 200 mg/dL
  - But they might have triglycerides of 300 mg/dL
  - They might have type 2 diabetes
  - They might have untreated thyroid disease
  - They might have untreated renal disease
- There are lots of other diseases for which a side effect is elevated LDL cholesterol, and John had to rule those out
  - This is why he started in children; these diseases are far less likely in children
- In the thousands of kids John has seen, only a handful had a secondary course for elevated LDL
  - The vast majority all had a genetic course
- When they had a cohort of 220 children where there was three generations of a family with elevated LDL and there was no doubt that they had FH, then they started sequencing to find a mutation
  - John published this in [*JAMA*](https://jamanetwork.com/journals/jama/fullarticle/199118) and in [*Lancet*](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(00)03587-X/fulltext)
- They used next generation sequencing to sequence everything ([exons](https://en.wikipedia.org/wiki/Exon) and [introns](https://en.wikipedia.org/wiki/Intron)) and mutations explained 95% of the cases of FH
  - This is a very different number from the literature where the cause of FH for adults can be found in 50-60% of patients, and there is no explanation for the other 40%
  - For 5% of these kids (11 kids) they never found the mutation responsible for their high LDL, and they really tried
    - This tells John that there are more genes/ mutations they don’t know about yet
- The clinical diagnosis of FH is not that good yet in adults, but it’s very good in children (where 95% have an identifiable mutation)
- Of the 95% of children where the genetic cause of FH was identified, mutations occurred in:
  - 95% the [LDL receptor](https://en.wikipedia.org/wiki/LDL_receptor)
  - 4.5% [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)
  - 0.5% [PCSK9](https://en.wikipedia.org/wiki/PCSK9) gain of function mutations
- In the Netherlands, the vast majority of FH is caused by mutations in the LDL receptor
  - In the U.S. maybe 70-80% of cases are due to LDL receptor variants

## The pathophysiology related to mutations of FH [15:30]

**When we say a mutation in LDL receptor or mutation in apoB or gain a function in the PCSK9 protein, explain briefly what each of those means and why would each of those translate to 3x normal levels of LDL cholesterol**

- Every LDL particle has one apoB protein kind of cringled around it, almost like a snake (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/05/f2-johnkastelein.png)

**Figure 2. The structure of LDL contains one apolipoprotein B (shown in dark blue)**. Image credit: [*World Journal of Cardiovascular Diseases* 2017](https://www.scirp.org/journal/paperinformation.aspx?paperid=79174)

- One area of that protein is sticking out of the LDL sphere, and that is a binding domain that is around amino acid 3,500
- Then there is a receptor for that particle sticking out from your liver cell (your hepatocyte), and these two bind normally.
- The LDL receptor grabs the LDL particle, and then the whole complex is internalized into the lysosome/ endosome where it’s basically dealt with (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/05/f3-johnkastelein.png)

**Figure 3. LDL binding to the LDL receptor in the liver and endocytosis**. Image credit: [*Journal of Thrombosis and Thrombolysis* 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5010583/)

- Next to the LDL receptor on the hepatocyte surface sits another protein called [PCSK9](https://en.wikipedia.org/wiki/PCSK9), and that protein degrades the LDL receptor (illustrated in the figure below)
- This helps achieve a balance, you can’t have an overactive LDL receptor because then you would clear every LDL particle from your circulation
  - The PCSK9 protein that degrades the LDL receptor gives that balance

![](https://peterattiamd.com/wp-content/uploads/2023/05/f4-johnkastelein.png)

**Figure 4. PCSK9 targets LDLR for degradation not recycling**. Image credit: [*Journal of Thrombosis and Thrombolysis* 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5010583/)

**Mutations responsible for FH**

- 1 – If there is a mutation in the binding domain of **apoB**, then you have something called FH or [familial defective apoB](https://www.ahajournals.org/doi/full/10.1161/01.ATV.17.2.348#:~:text=Familial%20defective%20apolipoprotein%20B%2D100%20(FDB)%20is%20a%20frequently,of%20LDL%20in%20the%20plasma.)
- 2 – If you have a mutation in the **LDL receptor**, you can’t bind the apoB
- 3 – If you have a **very active PCSK9** and you basically degrade all your LDL receptors, the end result is the same ‒ there’s not enough LDL receptors for the LDL particles
- All three of these things converge at the surface of your liver cell, and problems with any always lead to elevated LDL cholesterol
  - And that leads to all the downstream things previously discussed

***Mutations that reduce LDL binding to the LDL receptor result in more LDL in circulation***

**Peter’s analogy to visualize apoB, the LDL receptor, and PCSK9**

- Peter pictures an LDL particle with apoB wrapped around it as a baseball, and the LDL receptor is a baseball mitt sticking out from the liver
  - The PCSK9 protein is something that smacks the mit and closes it
- One form of mutations change the shape of the baseball mitt so it can’t catch the ball (or catches it poorly)
- Another mutation changes the shape of the ball so the ball doesn’t fit in in the baseball mitt
- The final mutation is one that makes too many of the things that swat the baseball mitts
- John adds, “*If you make the diagnosis right in a child with elevated LDL cholesterol, you’ve excluded the rest… you know this is FH*”
  - Their father, grandpa, one sibling all have high cholesterol
  - When you do a mutation screen, you can find a mutation in 95% of cases
- The vast majority of mutations are in the LDL receptor
  - Next is apoB, and then comes PCSK9
  - In the Netherlands, gain of function mutations in PCSK9 are very rare (0.5%)
- Another mutation Peter has seen even in his small practice is loss of function of the ATP-binding cassette G5/ G8
  - The effect of loss-of-function mutations in [ABCG5](https://en.wikipedia.org/wiki/ABCG5)/ [ABCG8](https://en.wikipedia.org/wiki/ABCG8) is illustrated in the figure below
  - These mutations disrupt the excretion of cholesterol in feces via the bile

![](https://peterattiamd.com/wp-content/uploads/2023/05/f5-johnkastelein.png)

**Figure 5.** Image credit: [*Advances in Experimental Medicine and Biology* 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8118135/)

- These patients have levels of [sitosterol](https://en.wikipedia.org/wiki/Beta-Sitosterol) and [campesterol](https://en.wikipedia.org/wiki/Campesterol) that are more than a log-fold higher than the 95th percentile, and this changes management because [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe) becomes the first line therapy
- Peter asks if John would agree that in these people, this is the mutation driving high LDL in these patients
  - John completely agrees

***Mutations in these three genes (outlined earlier) are very prevalent in the general population (1 in 250), and this makes FH by far the most frequent autosomal dominant disorder in men***

**High levels of plant sterols sitosterol and campesterol**

- The Koreans and others have looked in children with high cholesterol at [sitosterol](https://en.wikipedia.org/wiki/Beta-Sitosterol) and [campesterol](https://en.wikipedia.org/wiki/Campesterol) levels
  - They should be 12 for sitosterol and 14 for campesterol
  - In children with a level of around 35 (who have increased plant sterols in circulation), they found mutations in [ABCG5/G8](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8118135/)
    - This is called phytosterolemia
    - It used to be thought that the prevalence of this was 1 in a million
    - Now we think the prevalence is 10x more frequent (1 in 150,000 or so)
- What was not appreciated is that if you are [heterozygous](https://en.wikipedia.org/wiki/Zygosity#Heterozygous) for  a loss-of-function mutation in ABCG5/G8 (have 1 copy of), you have increased sitosterol and campesterol levels
  - It’s not rare

## Clinical presentations, physical manifestations, and diagnosis of FH [22:00]

**Clinical presentation**

- Peter notes that the physical signs go beyond the obvious (atherosclerosis)
- Earlier John mentioned tendon xanthomas and cholesterol deposits elsewhere in the body

**Do we have a sense as to why cholesterol tends to accumulate in particular areas, for example, in extensor tendons over flexor tendons?**

- The theory is it’s linked to movement, and there is a preponderance of [macrophages](https://en.wikipedia.org/wiki/Macrophage) and [monocytes](https://en.wikipedia.org/wiki/Monocyte) around tendons that are used very, very frequently
  - Monocytes/ macrophages are capable of storing LDL cholesterol, and when there are enough of them, you can physically see it and feel it
- The two most frequent places where you’ll find these deposits are the extensor tendon of your hands, which you use the whole day, and of course your achilles tendon
- John has seen [xanthomata](https://en.wikipedia.org/wiki/Xanthoma) also in the [patella](https://en.wikipedia.org/wiki/Patella) (shown in the figure below), in that tendon, actually on the [tibia](https://en.wikipedia.org/wiki/Tibia)

![](https://peterattiamd.com/wp-content/uploads/2023/05/f6-johnkastelein.png)

**Figure 6. Xanthoma on the patella.** Image credit: Wikipedia

- He’s seen xanthoma under a wedding ring; he’s seen them everywhere
- The deposits on the eyes are probably also linked to movement because you’re blinking your eye the entire day
- Cholesterol can be deposited in the cornea (not lens), which is called an [arcus cornealis](https://en.wikipedia.org/wiki/Arcus_senilis)
  - People don’t really know why that is
- John once made a FH diagnosis on a KLM airplane
  - There was a stewardess who wanted to give him a drink and she had very blue eyes, these Dutch blue eyes, and he looked in her eye and saw a ring
  - He advised her to have her cholesterol checked, and she proved to have FH

**Do you require the clinical manifestations for the diagnosis?**

- If you have a 50-year-old person who has had elevated LDL-C (>200 mg/dL) for as long as they’ve had blood tests
  - Their father also had elevated cholesterol and died of heart disease at age 78 (not prematurely)
  - This patient has no evidence of xanthomas, no arcus, nothing at all, no physical sign whatsoever
  - Their CT angiogram show their coronary arteries are clean
- Absent a genetic test, do you say phenotypically that he meets the criteria for FH?
  - Assume you’re ruled out every other medical thing (hypothyroidism, kidney disease, insulin resistance)
- John points out, “*There are people for some reason that have very elevated LDL cholesterol, it is genetic, it is dominant, but it doesn’t lead to the physical stigmata.*”

***You don’t need the physical stigmata to make the diagnosis***

- However, in this scenario John hasn’t seen a normal CT angio (in a 50-year-old)

***To have a normal*** [***CT angio***](https://en.wikipedia.org/wiki/Computed_tomography_angiography) ***when your LDL is 200-300 mg/dL is really rare***

**There is a** [**Gaussian distribution**](https://en.wikipedia.org/wiki/Normal_distribution) **for heterozygous FH**

- There is an overlap between homozygous FH and the end of the distribution of heterozygous FH
  - John and [Evan Stein](https://www.cardiometabolichealth.org/faculty/evan-stein/) have published about this ([homozygous FH](https://www.sciencedirect.com/science/article/pii/S0735109717380038?via%3Dihub) and [heterozygous FH](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.116.025158))

***You can never use LDL alone as a 100% certain marker of being normal because you could have heterozygous FH or homozygous FH;*** ***this is a syndrome diagnosis***

- You need family history, arcus, etc.

> “*What’s also very important is what you said in the beginning that this is a unique LDL disease*”‒ John Kastelein

- This is a unique LDL disease, and the moment there is elevated triglycerides or low HDL, you immediately have to think about something entirely different
  - Especially in an individual that is not obese or diabetic

**Explain the difference between heterogeneous FH and homogeneous FH**

- John notes that the terminology is difficult
- He remembers Peter’s discussion of polygenic hypercholesterolemia with [Dan Rader](https://www.med.upenn.edu/pcpm/daniel-j-rader-md.html) [in [episode #240](https://peterattiamd.com/danrader/)], and it is sometimes so severe that it looks a lot like heterozygous FH
- Some people way if you’ve had those genes from birth onwards and you have high LDL cholesterol from a young age, the risk of severe polygenic hypercholesterolemia is the same as for heterozygous FH
- But John finds that difficult because in patients with premature [MI](https://en.wikipedia.org/wiki/Myocardial_infarction), there is a huge enrichment for heterozygous FH (the homogenous heterozygous FH)

***Heterogeneous FH or polygenic hypercholesterolemia (whatever you want to call it) is still a less severe clinical picture***

- John has never seen people with polygenic FH get heart attacks in their 20s or 30s
- He has a humongous database of 25,000 heterozygous FH patients (studies listed under selected links at the end)
- Patients with monogenic FH (especially those with severe  mutations in the LDL receptor gene such as a [stop codon](https://en.wikipedia.org/wiki/Stop_codon) where they don’t make any protein at all have the most severe form of inherited hypercholesterolemia
- But polygenic or heterogenous FH is much more common that the monogenic form of heterozygous FH

## Criteria used to make a formal diagnosis of FH [30:15]

**Can you formally state the Dutch lipid clinic criteria?**

- Peter thinks this might be the most rigorous
- There is the Simon Broome criteria, the WHO criteria, and the Dutch Lipid Clinic criteria  [[reviewed in 2019](https://www.ahajournals.org/doi/10.1161/JAHA.119.013225) and summarized in the figure below]
- [Peter Lansberg](https://www.researchgate.net/profile/Peter-Lansberg) (on of John’s coworkers) put together the Dutch Lipid Clinic criteria
  - These criteria was externally and internally validated with mutations and huge numbers
  - Every time you do a comparison between the Dutch and the rest, the Dutch are winning in terms of their power to predict FH

*FH scoring criteria:*

- If you have a first degree relative with known premature coronary disease, you have a score of one
- If you have a first degree relative with high LDL, you get one
- Then if you have children or you have these xanthomata, you get two
- The list is long, and what is interesting is that if you have a mutation, you get a score of eight

***A diagnosis of definite FH requires a score above eight***

- The diagnosis options are: definite FH, probable FH, possible FH, and unlikely FH
  - This is great because you can divide your patient population into these categories, and it has a therapeutic consequence
- If someone has definite FH, they are treated from the age of six
  - They are at risk in their 20s
  - Peter comments, “*I think a lot of people, especially if you don’t really understand the pathophysiology of lipid metabolism, would think that’s absolutely insane. Now, I obviously share your view, which is absolutely not insane*.”
  - Treatment is the only way that person is going to live a long life
- In the pediatric lipid clinic, John has seen children between the ages of 5 to 10 come in with their mother (in her 30s) and the husband was deceased
  - She came in with three children and one child had a total cholesterol of 400, the middle child had normal cholesterol, and the youngest child had a cholesterol of 300
  - That mother really wants these two children to be treated
  - They both inherited the genes that killed her husband at 30, and his first heart attack was his last

## Why a small fraction of people with FH do not develop premature ASCVD [34:15]

**What is your best guess about the fraction of people with FH who do not go on to develop premature ASCVD? And what would be some plausible explanations for that?**

- Based on John’s long-term follow-up of that large Dutch cohort, only about 5% of people escape all disease symptoms
  - That includes coronary artery, calcium scoring, CT angios, xanthelasma, arcus, anything
  - They seem completely immune to the elevated LDL cholesterol
  - The vast majority of these people are women
- In Holland, mutation screening is free (the government pays for it), so everyone who comes to his clinic is tested
- Knowing the mutation provides some explanations
- Often these women had very high HDL cholesterol, so perhaps she had an efficient [reverse cholesterol transport](https://en.wikipedia.org/wiki/Reverse_cholesterol_transport) system
  - In other words, they have something protective
- John has desperately tried to understand these 5% (genetically and otherwise), and no one on the planet has ever found a good biological reason as to why some people are resistant to [high levels of] LDL cholesterol
  - FH is too rare to have enough monozygotic twins to make any conclusions
- Peter adds that the HDL story is far more complicated than the LDL story
  - Based on his discussion with [Dan Rader](https://www.med.upenn.edu/pcpm/daniel-j-rader-md.html) ([episode #240](https://peterattiamd.com/danrader/))
  - We don’t know when we measure an elevated HDL cholesterol, if it is a biomarker of something good that is happening or if it’s a bad thing
  - One idea is that people with elevated HDL-C have very dysfunctional HDLs
- John adds, “*Those are people with* [*SR-BI*](https://en.wikipedia.org/wiki/SCARB1) *mutations*”
- John [published](https://www.nejm.org/doi/full/10.1056/NEJMoa0907687) on one family in New England that had very high HDL and premature coronary disease
- But in this instance he is describing a nice thin elderly grandmother who’s very active, jumping up and down, doesn’t smoke, and her high HDL is definitely not a sign of something dysfunctional

## Treatment and prevention for those with FH [39:45]

**Are there any differences in how we treat people by sex, by age and by level of disease at time of diagnosis?**

- Peter would call it **primary prevention** when treatment is given before there is a discernible sign of disease, and **secondary prevention** if you have signs of disease, a calcium score of five, or abnormalities on a CTA
  - [Episode #247](https://peterattiamd.com/ethanweiss2/) discussed [coronary artery calcium scores (CAC)](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) and [CTA (CT angiography)](https://en.wikipedia.org/wiki/Computed_tomography_angiography)

***John agrees, primary prevention is rare***

- Peter adds that secondary prevention could occur if you have a zero calcium score but there’s soft plaque inside the artery ‒  this is ASCVD that can be documented by the naked eye

**Walk us through primary versus secondary prevention, men versus women, children versus adults**

- A child comes to the clinic at age six
- At six years old, this is the the first time a child understands what they eat, and in heterozygous FH, it is very important to start with a very healthy lifestyle early on
  - They are given extensive training on anti-smoking, healthy diet choices, sports/ physical exercise
- This counseling does *not* detract from the fact that they will start with a [statin](https://en.wikipedia.org/wiki/Statin) at age six

**Can you give some insight or color around what type of dietary advice you are recommending, saturated fat restriction?**

- It’s anecdotal to say that people with FH are more sensitive to saturated fat in the diet
- All of these lifestyle measures are not going to cure FH, they are just supportive
  - This is very different from the general population
- Heterozygous FH is driven by the LDL and how long a patient is exposed to that LDL
- So, the earlier we can intervene, the better

***It’s pretty clear that if you start intervening early in LDL, you probably add 15 to 20 years to life versus doing nothing on the medication front***

**Start treating the child with a statin**

- John used to have a preference for pravastatin because it was kind of seen as the mildest
- Also, they did a [two-year randomized trial of Pravastatin](https://jamanetwork.com/journals/jama/fullarticle/199118) versus placebo where they showed there was regression of carotid IMT (intima-media thickness of the carotid arteries) in kids between the ages of 8-18
  - They could stop the progression of athero
  - This was back in 2004
- Now there are guidelines for the American College of Pediatrics, and European guidelines, and statin treatment begins somewhere between ages 6 and 8
- There’s not much of a preference anymore for a certain statin
  - Some people prefer Rosuvastatin because you can dose it at 2.5 mg to start with, which is a tiny pill for a kid
  - And then you add ezetimibe because you don’t go to goals like you do in adults, but you try at least to have an LDL below 130
    - It’s very interesting because there’s no intervention evidence for this at all like an adult
- [Results](https://academic.oup.com/ehjcvp/article/9/2/138/6697756#394544844) just came out that show even LDLs below 20 are better than below 55 are better than below 70
  - We don’t have those data for kids
- Peter is surprised to hear that he has such a modest goal of 130 given that kids without FH have LDL cholesterol levels of 20-30
  - John is fighting conservatism
  - He personally doesn’t agree with the 130
  - There are pediatricians who treat kids more aggressively

> “*The healthy LDL is for your endothelium and is much lower than 130*”‒ John Kastelein

- Peter’s point is this is ironic because we have the natural experiment right in front of us
  - Kids are born with an LDL cholesterol of 10 mg/dL, and it starts going up as they go through puberty, but during the most important period of brain development the level of cholesterol is virtually undetectable
  - John agrees, your brain grows by far the fastest in the first year of life and you basically have no LDL left to go anywhere

**Has the thinking changed with PCSK9 inhibitors?**

- You could make the argument that statins are impairing cholesterol synthesis and maybe in a developing child that could be problematic, but a PCSK9 inhibitor has no bearing on cholesterol synthesis

*Do PCSK9 inhibitors simply amplify LDL clearance?*

- John agrees, but he has changed his thinking
- There are some preclinical indications that in the embryonic stage, PCSK9 has a role in brain development
  - Preclinical indications are pretty useless in John’s opinion
- There are some Mendelian randomization studies that pick up an increased signal for Alzheimer’s disease with low PCSK9, but all the trials have never shown any effect on cognition
- But these arguments are all used by people who are more conservative
- John and others have done all the trials because they have so many kids with heterozygous FH with [evolocumab](https://en.wikipedia.org/wiki/Evolocumab), simvastatin plus ezetimibe, all the statins alone ([pravastatin](https://en.wikipedia.org/wiki/Pravastatin), [rosuvastatin](https://en.wikipedia.org/wiki/Rosuvastatin), [simvastatin](https://en.wikipedia.org/wiki/Simvastatin)), [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe), [PCSK9 monoclonals](https://en.wikipedia.org/wiki/PCSK9#Monoclonal_antibodies), and kids are *not* statin intolerant
  - He doesn’t see kids developing myalgia and statin-related muscle symptoms
    - Peter notes that 5% of adults experience this
  - Kids don’t read the inserts in medication
- John published a [10-year follow-up](https://jamanetwork.com/journals/jama/fullarticle/1902218) on these kids (at age 18-28) and compared them with a generation above their age [[20-year follow-up](https://www.nejm.org/doi/full/10.1056/NEJMoa1816454) published in 2019]
  - None of these kids got a heart attack, angina, or anything
  - The generation above them who didn’t get any treatment (because statins weren’t available) had rampant early coronary disease and mortality

***Although it’s not a real randomized controlled clinical trial, this observational data shows that treating from an early age protects these kids against premature death and premature coronary artery disease***

**Contrast this treatment with that of a middle-aged adult who shows up either with or without disease. How aggressive do you go there?**

- John goes as aggressive as the guidelines tell us to go for non-FH patients
- Kids are transferred from the pediatric lipid clinic to the adult lipid clinic when they’re 18, and they are immediately started on [PCSK9 monoclonals](https://en.wikipedia.org/wiki/PCSK9#Monoclonal_antibodies) and pretty soon with [inclisiran](https://en.wikipedia.org/wiki/Inclisiran) and [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe)

> “*We really strive for the lowest LDL possible for that individual*”‒ John Kastelein

- For those with homozygous FH, he treats with a high dose statin, ezetimibe, [evolocumab](https://en.wikipedia.org/wiki/Evolocumab), and [evinacumab](https://en.wikipedia.org/wiki/Evinacumab) (the Regeneron [ANGPTL3](https://en.wikipedia.org/wiki/ANGPTL3) monoclonal antibody)
  - These four things constitute the state of the art therapy for homozygous FH
  - It gets a lot of patients to relatively normal LDL levels, which is a miracle for homozygous FH
- In heterozygous FH, there are about 10% of patients that even with triple therapy, we can’t get them to a reasonable LDL
  - We call these now **severe heterozygous FH**, and they probably have more than one mutation, but that we officially don’t know that
  - They can’t get below 100 or 120
  - This is linked to the starting LDL, when you start at 300, you have a statin that takes of 45%, another drug takes off 15-20%; it’s not that easy to get below 100

**Is apheresis even a viable option?**

- Peter wonders if it’s easy to pull out
  - He knows this works for Lp(a)

*Does it work for the majority of the apoB bearing lipoproteins?*

- It does
- John is involved with an apheresis center in Amsterdam because they’ve sometimes diagnosed homozygous FH in kids six months old that had a very severe homozygous FH
  - And they had to LDL apheresis these kids
- For these patients, [evinacumab](https://en.wikipedia.org/wiki/Evinacumab) is the golden rescue
  - It’s still only used in adults, but John hopes they will be able to use that quadruple therapy rapidly in kids also because it obviates the need for apheresis in many instances

**How frequently is evinacumab dosed?**

- It’s intravenous [dosing](https://www.rxlist.com/evkeeza-drug.htm'), “*I think once a week*”
- But they are working on a subcutaneous formulation

## Addressing the assertion by some that elevated LDL is not casual in cardiovascular disease [52:45]

- Peter notes, “*There is a small but vocal cadre of people out there who kind of refuse to believe that LDL is causally related to ASCVD or another sub variant of this group who believe that it’s only causally related to ASCVD in the context of metabolic illness. But if you’re metabolically healthy, then LDL is not problematic*.”

**Based on your knowledge and experience with FH, which spans the spectrum of metabolically healthy to unhealthy people, how likely do you think that is?**

- John replies, “*These patients that you mentioned before are always used as the stick to beat people like me because they say if LDL is truly causal, it’s impossible that some people don’t get heart disease while having FH*.”
- He tries to explain that most genetic diseases are modified by other environmental and genetic factors
- There is a website (cholesterolcritics.org) of a strange bunch of people that absolutely don’t want to accept that LDL cholesterol is bad
- In John’s experience, in his entire career working hundred hour weeks for years to find people with FH [this is not true]
  - He assembled the largest cohort on the planet of people with heterozygous FH
  - He’s seen the families, and these stories are all heartbreaking
- So John doesn’t listen to these people anymore

***It is so simple because these people have one thing, one a mutation in a single gene that doesn’t do anything else than raise LDL cholesterol, and they drop dead when they’re like 25***

- Peter adds that the Mendelian randomization also makes that clear because it doesn’t just include FH (see studies listed in the selected links section)
- Peter’s response to people when they point out that there are some people with high LDL cholesterol or high apoB who don’t have coronary artery disease is that there are also people who smoke their whole lives and don’t get lung cancer
  - By the way, there are people who never smoke who do get lung cancer
  - Neither of those facts remotely diminishes the causal case for smoking and lung cancer
  - John agrees, smoking is a very good example
- John adds, “*The FH argument was always the scientific argument of proving that LDL cholesterol, it’s elevated, sits at the core of atherogenesis*”
- When it became clear that there were a few people among these FH families who could actually live without a problem, critics used that as an argument

## The history of CETP inhibitors and the role of the CETP protein [55:45]

- CETP inhibitors are a class of drugs that Peter discussed at length with [Dan Rader](https://www.med.upenn.edu/pcpm/daniel-j-rader-md.html) [in [episode #240](https://peterattiamd.com/danrader/)]
- The latest ones are the first that appear to have a shot at working

**Explain what CETP is and the sordid past of CETP inhibitors as a prologue to where the field is now**

- This is one of the best examples of how big pharma can make big mistakes
- The [CETP](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein) protein was discovered by [Phil Barter](https://www.sydney.edu.au/medicine-health/about/our-people/academic-staff/philip-barter.html) (the Australian that’s now retired)
  - He actually discovered it in rabbits
  - And why did he look in rabbits?
  - Because if you give a rabbit egg yolk (or cholesterol), that rabbit gets atherosclerosis
  - If you do the same diet to a mouse or to a rat or a hamster for that matter, they don’t get atherosclerosis

***It was extremely interesting what made a rabbit different from other rodents, and that is a rabbit has CETP***

- So all strategies to lower CETP were tested in that New Zealand white rabbit, like [siRNA](https://en.wikipedia.org/wiki/Small_interfering_RNA), gene therapy, small molecules, antibodies against CETP

***In all instances, you could cure the athero with lowering of CETP activity***

- At the same time, it became obvious that in Japan there are many people with a mutation in CETP, so they have very low CETP
  - The first report said, these people live longer than we do and they’re free of coronary disease
  - So then loss of function of CETP became a longevity gene, and many people still consider it this
    - Because if you don’t have it, you live longer, you have less Alzheimer’s disease, you have less diabetes, and in general, you are simply more healthy
- Peter notes this is sort of like PCSK9 and its loss of function is also a longevity gene
- John explains, you don’t need PCSK9
- The theory is that we all went through an **evolutionary funnel** about 10,000 years ago during the last ice age
  - There were very few humans alive, especially in the north, and they went through the evolutionary funnel where everything was directed to being thrifty
  - People who could absorb the last calorie out of a mammoth were favored
  - We now think that those genes that we selected during that evolutionary funnel are now bad for us
    - Like we don’t need PCSK9
    - We don’t need CETP
    - We probably also don’t need [ANGPTL3](https://en.wikipedia.org/wiki/ANGPTL3)
  - All of these genes were meant to conserve energy and to conserve cholesterol
- What [CETP](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein) does is a very simple th        ing, it grabs a [cholesterol ester](https://en.wikipedia.org/wiki/Cholesteryl_ester) molecule from an [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein) particle
  - CETP sits on the HDL particle like a little cap
  - It’s a curved protein that sits on top of a sphere and it has an opening and it sucks a cholesterol molecule out of HDL
  - Then that particle collides with an LDL particle, and there’s a little tunnel and it spits the cholesterol ester molecule straight into LDL
  - ***So the consequence of that is that HDL cholesterol goes down and LDL cholesterol goes up***
    - Which in the days of very active LDL receptor activity was a great idea because then all the cholesterol went back to the liver
    - A cholesterol molecule is very expensive to make; it costs 27 ATP
    - In a nasty environment like the ice age, you want to conserve that molecule, and the best way of conserving a cholesterol is by sending it back to the liver
    - And then the liver can decide what to do with it, put it in VLDL or in bile, or it can do a lot of things with it
- But in a situation where our LDL receptors are not that active anymore, adding cholesterol to LDL is not a very good idea
- All the [Mendelian randomization studies](https://www.ahajournals.org/doi/10.1161/CIRCGEN.117.002034) have shown that people with high activity of CETP have more heart disease, more heart failure, more kidney disease, more diabetes, more Alzheimer, etc.
- When Pfizer’s atorvastatin patent was going to expire within a few years, they made a CETP inhibitor called [torcetrapib](https://en.wikipedia.org/wiki/Torcetrapib)
  - John was involved in all these large trials; he was on the steering committee of the [Evacetrapib](https://en.wikipedia.org/wiki/Evacetrapib) trial, on all of these trials except the [REVEAL trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1706444) (that was done by Oxford)
- Pfizer did a [phase 2](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_II) trial, and after four weeks, blood pressure went up a little bit, and then comes the big pharma mistake
  - They said, “*Why do we care about a little blood pressure increase if HDL goes up by 70%?*”
  - The mistake was they didn’t understand why the blood pressure went up and they moved the drug into [phase 3](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_III)
    - If you don’t understand a side effect in phase two, you don’t move a drug into phase three until you’ve understood it
    - But this was John’s fault too because he was on the executive committee of the outcome trial with [torcetrapib](https://en.wikipedia.org/wiki/Torcetrapib), and they all thought this was going to be the next fantastic wave of drugs in cardiovascular disease
    - But that drug killed more people than it saved
- Peter was so optimistic based on the HDL cholesterol increase achieved by this drug, and he remembers his surprise in September of 2006 when it was announced that the trial was being halted
  - Even though it was clear this trial was kind of a stupid land grab from an IP perspective on the part of Pfizer
- The drug turned out to be an enormous failure
- Everybody was fired except the basic scientists who got the assignment to understand what happened
- It was interesting because they took the drug and they infused it into a rat
  - Now a rat does not have CETP, but the blood pressure went up in 10 minutes
  - So that told everyone that this is a drug that has an off-target effect
  - Fortunately it has nothing to do with CETP
  - But the drug actually raced straight into your adrenals where it promoted aldosterone production, cortisol production, it raced into your endothelial cells where it promoted [Endothelin 1](https://en.wikipedia.org/wiki/Endothelin_1), which is like an [angiotensin II](https://en.wikipedia.org/wiki/Angiotensin_II_receptor) (a terrible vasoconstrictor)
  - And all of that led to water and sodium retention, low potassium, high blood pressure
  - And you don’t want a drug like that in a secondary prevention patient
  - “*So that was the most unfortunate beginning of a new story in our field ‒ the wrong drug*”
- Peter adds, “*This was not too long after another epic failure… the drug* [*Vioxx*](https://en.wikipedia.org/wiki/Rofecoxib)”
  - He argues this drug shouldn’t have been removed, and instead more work should have been done to determine who susceptible individuals were
    - There was a subset of patients in whom Vioxx slightly raised blood pressure and led to a small increase in events
  - It was a truly remarkable [COX-2 inhibitor](https://en.wikipedia.org/wiki/COX-2_inhibitor) that makes [Celebrex](https://en.wikipedia.org/wiki/Celecoxib) look like drinking water in terms of its impotence
  - But the arrogance of the biotec company and their refusal to act in a timely manner resulted in just the loss of a drug that Peter thinks we would be better off having
  - Big pharma, “*Often they are their own worst enemies*”
- John is now a drug developer himself with [Michael Davidson](https://www.uchicagomedicine.org/find-a-physician/physician/michael-h-davidson), and the idea that we would push a drug in phase three while not understanding a side effect in phase two is just incomprehensible
- What’s interesting is not many people realize that after Pfizer came Roche or Merck with the drug [dalcetrapib](https://en.wikipedia.org/wiki/Dalcetrapib)
  - This drug only raised HDL
  - It was a very weak CETP inhibitor
  - It raised HDL by about 30% and there was no effect on the [Kaplan Meier curve](https://en.wikipedia.org/wiki/Kaplan%E2%80%93Meier_estimator) in the cardiovascular outcomes trial whatsoever

***What people didn’t realize, that drug was the end of the HDL hypothesis***

- HDL cholesterol was raised by 35% but there was no effect on LDL, no effect on apoB, no effect on non-HDL
  - And that did *not* translate into one less heart attack or stroke
- Peter recalls two Mendelian randomizations, one looking at [genes that raised HDL cholesterol](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(12)60312-2/fulltext) and one looking at [genes that lowered HDL cholesterol](https://pubmed.ncbi.nlm.nih.gov/22090275/)
  - Neither were found to be causally linked to ASCVD

> “*So when I hear people tell me that their high HDL cholesterol is protecting them from coronary artery disease in the presence of high LDL cholesterol, I have to restrain myself.*”‒ Peter Attia

- John explains that was is interesting in those days is we didn’t understand that you need to lower LDL cholesterol with a CETP inhibitor to see an effect on ASCVD
- [Dalcetrapib](https://en.wikipedia.org/wiki/Dalcetrapib) was the third drug in clinical trials, and at this time people weren’t sure if they had to power an outcome trial on the basis of the HDL cholesterol increase or the LDL
  - Oxford did a 30,000 patient [trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1706444), which is still the largest cardiovascular outcome trial ever
  - But they overestimated the LDL lowering
  - The drug only lowered LDL by 17%
  - The baseline LDL in their trial was 60 mg/dL
  - So the absolute LDL was 11 mg/dL, and that predicted a 9% reduction in [MACE](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events)
    - Which was exactly what they got

***That trial validated that CETP inhibition only lowers heart attacks by virtue of its LDL lowering***

- It answers to the same law as statins, ezetimibe, and PCSK9 monoclonals
- After this, John and Michael understood that what they needed to find was a CETP inhibitor that didn’t have the off-target effect of [torcetrapib](https://en.wikipedia.org/wiki/Torcetrapib), that was way more potent than [dalcetrapib](https://en.wikipedia.org/wiki/Dalcetrapib), and lowered LDL robustly so they could repeat the [anacetrapib](https://en.wikipedia.org/wiki/Anacetrapib) trial, but then with a much bigger effect size
  - And they found that drug at Mitsubishi ([obicetrapib](https://www.nature.com/articles/s41591-022-01936-7))

## The thrifty gene hypothesis and why genes underlying FH may have been preserved [1:09:00]

**Back to John’s evolutionary explanation of CETP, PCSK9, and ANGPTL3**

- Peter finds this to be the most lucid evolutionary explanation for our species wide transition to the preservation of apoB
- Peter has never heard it explained this way, and it makes so much more sense than any other kind of teleological or evolutionary explanation
- John adds, “*It’s called the “****thrifty gene hypothesis,”*** *and it’s more often used to explain, for example, that people in Asia get type 2 diabetes at a much lower BMI than we Caucasians, because they’ve gone through much more famine. When the rice failed, huge famine in the far east.*”
- Peter knew it takes 27 ATP to make a molecule of cholesterol, but the never made the additional leap to think about how expensive that is
  - And up until 150 years ago, we were in an environment that was so resource constrained
  - So we spent hundreds of millions of years in an environment where preservation of resources was the second priority only after reproduction
  - It makes sense that we would be so effective at LDL clearance, and therefore we would want to be in the business of shuttling as much cholesterol from HDL into LDL via [RCT](https://en.wikipedia.org/wiki/Reverse_cholesterol_transport) because we knew it was going to a good place, back to the liver
    - It would be circulated as bile, we would ultimately recirculate that pool
    - We could make more hormones, we could digest more food stuff
  - “*It all makes sense*”
- Only now, there is not such a premium on the ATP required for cholesterol synthesis, and we’ve got more than enough cholesterol to spare
- Now that gene that we worked for millions of years to preserve is “*biting us in the ass*”
  - Just like the same genes are around adiposity and insulin resistance

**A very interesting additional piece of evidence**

- If you make a mouse look like a human heterozygous FH and you infect that mouse with bacteria and compare the [results](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507194/) of infection with bacteria in the non-FH mouse, the FH mouse has better resistance to bacterial infection
- The theory is that FH in 1860 was not the severe disease it is right now
  - John has seen that in his [pedigrees](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC31037/)

***Maybe there is so much FH because in the ice age, having high LDL might have been an advantage as a protection against bacterial infection***

- These two things converge

**Peter thinks about how amazing that in in terms of a parallel to** ***APOE4***

- This is the exact same story as [*APOE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms), which basically was the only apoE isoform we had until, about 200,000 years ago, and it offered remarkable protection against infections
- It’s only today with our longer life (and all the insults that come with a longer life) that *APOE4* is such a predisposing factor to both cardiovascular and neurodegenerative disease
- Peter adds, “*That was an amazing explanation of the story. That was actually also, I think, a fantastic prologue for those who missed the discussion with* [*Dan Rader*](https://peterattiamd.com/danrader/).”

## The compelling potential of the latest CETP inhibitor (obicetrapib) [1:13:00]

**Recap where we are with obicetrapib**

- John begins, “*I am still a scientist and I don’t want to sound like a salesman, but we were lucky finding this drug in Mitsubishi*”
- John is a consultant to many biotech companies, and sometimes companies ask him to look at the pipeline and see if there’s anything good or bad in it
- He was invited by Mitsubishi to look at a number of things, and he saw the phase 1 data on this compound that was still called TA-8995
  - At 1 mg, that drug lowered LDL by 27%
    - Now remember, dalcetrapib was used at 600 mg and it didn’t do anything on LDL
    - So I thought, “*Holy moly, this drug is very potent*”
  - Then he looked at the CETP inhibition at 10 mg, which is a dose he is using now, and there was a 97% inhibition of CETP

***It is a surprisingly potent CETP inhibitor, and that translates into an LDL lowering of about 50% on top of high-intensity statins and an HDL increase of 165%***

- He knows that the HDL cholesterol increase is not going to do anything for heart attacks and strokes
- He and Michael are not only working on this drug to develop it, they’re also scientists who want to understand all the genetic and epidemiology and Mendelian randomization data
- They’ve gone far beyond heart disease with this drug
- They are looking at Alzheimer’s disease, age-related macular degeneration, septicemia, and diabetes
- Because if you really inhibit CETP, you not only stop the transfer of cholesterol from HDL to LDL, but you completely change lipoprotein metabolism and you force the liver to produce more [apoA-I](https://en.wikipedia.org/wiki/Apolipoprotein_AI)
  - They agree on the fact that apoA-I is a fantastic molecule, because it is the molecule that [ABCA1](https://en.wikipedia.org/wiki/ABCA1) (the cholesterol pump on the cell membrane) recognizes and actually exports cholesterol to
- Secondly, we also know that if you produce lots of apoA-I, you produce lots of **prebeta-HDL** particles (small HDL particles), and these particles suck cholesterol out of peripheral tissues
  - In endothelial cells and macrophages, that’s probably good
  - What’s much more interesting is that they suck cholesterol out of the [beta islet cells](https://en.wikipedia.org/wiki/Beta_cell) in your pancreas, and if you’re a type 2 diabetic, more and more of these cells die until the point that you become insulin independent
    - That is because of the lipotoxicity of that cell
    - That cell takes cholesterol and can’t export it, the sterols are oxidized and they become pro-inflammatory, toxic
    - The cells go into [apoptosis](https://en.wikipedia.org/wiki/Apoptosis) and they die
- Now this is proven for all four CETP inhibitors
  - In all of the trials, there was less diabetes in the treatment arm than in the placebo arm
  - John published this in his recent [meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9729761/)

**Explain the difference between homotypic exchange and heterotypic exchange**

*Do you think that all of the CETP inhibitors resulted in more heterotypic exchange between the apoBs and the apoA-Is?*

- 1 – You stop the transfer of a cholesterol molecule going from HDL to LDL, and that will make HDL higher and LDL lower
  - Stable isotope turnover studies and have shown the reason for the lower LDL is that they are swept up by the liver
  - So these LDLs actually get 50% lower, which is a huge drop, because the liver upregulates their LDL receptors
- 2 – At the same time, these large HDLs take apoE on board
  - And apoE is also a ligand for the LDL receptor
  - The large HDL particles are also cleared by the liver, and the liver does that because it produces large amounts of apoA-I, which kind of disturbs the balance
- 3 – So there is a new equilibrium between removal of lipoproteins by the liver and production of small HDL particles
  - But that only happens if you almost completely knock out CETP
  - You have to really inhibit CETP by about 90%, which is very close to the homozygous patients in Japan
    - They also have half LDL and about a triple HDL, and every other thing that I just described
- For John and [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876) and people that really know lipids, this is extremely interesting because it is complex

**Connection between CETP and septicemia**

- There are two groups in the world, one in [Vancouver](https://pubmed.ncbi.nlm.nih.gov/33228395/) and one in [Leiden](https://pubmed.ncbi.nlm.nih.gov/32033866/), that have shown that if you are born with a loss of function variant in CETP, you are much better protected against [septicemia](https://en.wikipedia.org/wiki/Sepsis)
  - Not a little bit, but a big mortality effect
  - Of course they want to test this drug in septicemia

**Is there any evidence that untreated FH patients have a lower mortality from septicemia?**

- Most of this work has been done pre-clinically, and it’s not great science, but there are some indications

*So it’s not as straightforward as, if you have high peripheral cholesterol, you have more precursors to make corticosteroids and therefore support immune function in the time of sepsis?*

- It’s way more complicated
- Most likely, it has to do with the scavenging function of lipoproteins
- If you’re CETP is low when you get septicemia, your HDL stays high
- It’s very likely that the HDL particle functions as a sink for endotoxins and everything else
  - So having high HDL during septicemia is a very good thing
- In the ICU, Peter has witnessed the opposite where a drop in HDL cholesterol is a poor prognostic indicator
- John adds that you are protected against that drop in HDL if your CETP activity is low, because it’s like having a CETP inhibitor on board which stops removing cholesterol from HDL

**Connection between CETP and diabetes**

- The Roche drug only raises HDL, it doesn’t lower LDL
- It’s protective effect against diabetes can only be connected biologically to HDL
- It is now thought that if you raise HDL with CETP inhibition, you protect the pancreas against apoptosis (summarized in the figure below)
- The effect is about 16-20% in the new-onset type 2 diabetes between placebo and active treatment arm
  - It’s almost as big as the negative effect of statins on diabetes, which at the highest dose is 15% or so

![](https://peterattiamd.com/wp-content/uploads/2023/05/f7-johnkastelein.png)

**Figure 7. Mechanisms linking HDL-C and diabetes whereby low HDL-C contributes to diabetes.** Image credit: [*European Heart Journal Cardiovascular Pharmacotherapy* 2022](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9729761/)

**Is obicetrapib the first CETP inhibitor that impacts both heterotypic and homotypic exchange?**

- [Heterotypic exchange is swapping cholesterol between different lipoproteins, between apoB particles (LDL) and apoA-I particles (HDL)]
- [Homotypic exchange is swapping cholesterol among the same type of lipoprotein, swapping cholesterol among apoB particles *or* among apoA-I particles]
- This is hard to say because there is not much work done with the older CETP inhibitors
- [Dan Rader](https://www.med.upenn.edu/pcpm/daniel-j-rader-md.html) has done a huge amount of work with the Merck [anacetrapib](https://en.wikipedia.org/wiki/Anacetrapib)
  - He has shown that HDL particles from anacetrapib-treated patients have more cholesterol influx from macrophages
  - He has shown that [SR-BI](https://en.wikipedia.org/wiki/SCARB1) is upregulated in the liver by CETP inhibition with that drug
- Not much work has been done with the other drugs
- There is a track record of 4-5 consecutive failures of CETP inhibitors, and if you were a Wall Street analyst, you’d have a really hard time getting excited based on how many times you’ve been burned
- But coming at this through the lens of science…

**Obicetrapib clinical trials**

- John completed phase 1 (no toxicities) and [phase 2 clinical trial of obicetrapib](https://pubmed.ncbi.nlm.nih.gov/35953719/)
- There have been four phase 2 trials and now this drug is in phase 3 [[phases of a clinical trial](https://en.wikipedia.org/wiki/Clinical_trial#Phases)]
- John has started the outcome trial at the same time as the lipid trials
- They need to show robust LDL lowering (non-HDL lowering), robust apoB lowering, and and they also need to show safety
- There should be no effect on blood pressure, good safety, good tolerability
- It’s a tiny 10 mg pill
- This drug is well tolerated, and they haven’t seen any **side effects i**n phase 2
- It **lowers LDL by half,** which makes it just as potent as the injectables, but in a 10 mg pill
  - John was amazed when he first saw these LDL results
- At then end of the day (in the future), they need to show outcomes in a cardiovascular outcomes trial
- Peter observes, “*If this pans out to be as good in large phase three studies as it has been in phase 2, the only thing that would stand in the way of this displacing every statin on the planet is cost. Because you’d have equal or better lipid lowering efficacy, and instead of having a small increase in the risk of type 2 diabetes, you would be patently reducing that risk.*”
- And it’s very cheap to make; it’s not an injectable monoclonal antibody
  - It’s public knowledge that it costs $36 per year to make this drug, and that will allow them to price it reasonably and ethically
- This is something John and Michael have always wanted, a drug that lowers LDL and apoB that you can use on top of a statin or in a fixed dose combination with ezetimibe
  - The vast majority of his clinic in Amsterdam have pill boxes; they are afraid of a needed, and they want an extra pill to get their LDL done

## Promising results from phase 3 trials exploring obicetrapib [1:27:45]

- BROADWAY is 2,400 ASCVD, high-risk patients, looking at secondary prevention for one year in people who are on a maximally tolerated lipid lowering therapy
  - It’s placebo controlled, two to one randomization

**Is 52 weeks with 2,400 patients enough to see a difference in MACE?**

- It’s not powered for [MACE,](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events) and in every phase three trial, whether you’ve alirocumab, evilocumab, inclisiran, or even bempedoic acid, they are adjudicating events
  - They expect about 120 events in its entirety, and they hope to see a trend
  - They are not allowed to do statistics; the FDA does not allow it
  - This is just descriptive
  - Just like the [inclisiran trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9825807/), they had about a 30% difference in events, and that gives you an indication that it’s moving in the right direction

**Other trials**

- BROOKLYN is a very small trial in 300 patients with heterozygous FH
- PREVAIL is the big one with 9×000 patients with existing ASCVD; it’s also secondary prevention
  - They’ve entered a lot of risk enhancing factors into this trial because they understand that the higher the risk, the easier it is to show a benefit
  - They strive for a baseline LDL of around 100 because then if you lower LDL by 50%, your absolute difference is 50 mg/dL and this translates to a 27% MACE reduction
    - Which of course they can’t do, because there will be people off drug, there will be people who are going to take a PCSK9 monoclonal
    - But at least they are very sure that it’s going to be more than 20% MACE reduction

**Aside from not having coronary artery disease, what are the exclusions for Prevail?**

- If your LDL is below 55 milligram per deciliter
- They adapted Prevail to the New American College of Cardiology guidelines
- One of the things Peter has talked about previously on the podcast [[episode #210](https://peterattiamd.com/benoitarsenault/)] is how skeptical he was when FOURIER and ODYSSEY were launched
  - Not because he didn’t believe PCSK9 inhibitors would work
  - He thought they were going to be a home run, he thought they would be incredibly safe (both ended up being true)
  - But he thought the trial would fail because of the patients
  - This was also secondary prevention, very similar patient population to PREVAIL
  - The patients were heavily drugged to a LDL cholesterol of 70 mg/dL then randomizing them to PCSK9 inhibitor versus placebo
  - Peter thought they wouldn’t be able to do the study long enough to see a difference, but this was completely wrong
  - That study was halted at around 3.2 years

**Do you worry about that risk?**

- The patients are so heavily medicated, you will exclude them if they are down to 55 mg/dL, but there will be a lot of people at 70 mg/dL
- John has already randomized a very robust number and expect to be ready before the end of the year with 9,000 patients, and the baseline LDL is exactly where they want it (around 100 mg/dL)
  - They have promoted the inclusion of high LDL patients into the trial
- John points out another big mistake of the FOURIER trial, “*it was not 3.2, but it was 2.3 years*”
  - Peter got the numbers mixed up
  - 2.3 years was too short
- John is going to have at least a 2.5 year follow-up
  - He think the median follow-up will be 3-4 years, and that’s long enough to see the full effect of lipid lowering
- PREVAIL is being run in Canada, North America, South Africa, Europe, Eastern Europe, and Western Europe

**No side effects were observed with obicetrapib, and Lp(a) was cut in half [1:33:30]**

*Did any other side-effects show up in phase 2?*

- Peter notes that they are not seeing the typical statin-related side effects of insulin resistance or muscle soreness
- John replies, “*Zero. I hate to sound like a salesman*”
- Phase 2 results were published in [*Nature Medicine*](https://www.nature.com/articles/s41591-022-01936-7)
- They are submitting their results from ROSE2, which is the fixed dose combination with ezetimibe, to another very good journal
- Currently, they have not identified a single side-effect related to study drug
  - This will change as the numbers get bigger
  - This was also true for the Lilly CETP inhibitor, the Rhodes CETP inhibitor, and the Merck CETP inhibitor
    - None of these three had side effects
    - There were 60,000 patients in outcome trials

*If you discount the Pfizer misery, the rest of the CETP inhibitors were very safe*

- Peter notes from a side effect profile, we’re moving into a world of drugs that don’t have side effects
  - Bempedoic acid, ezetimibe, potentially obicetrapib, and PCSK9 inhibitors
  - Only statins have side effects, although in relatively fewer people than is generally perceived
- There are books out there like [*The Cholesterol Myth*](https://www.amazon.com/Cholesterol-Myth-Truth-About-Know/dp/0615918263/ref=sr_1_5?crid=ASDPQWBIBPSJ&keywords=the+cholesterol+myth&qid=1683304622&sprefix=the+cholesterol+myth%2Caps%2C142&sr=8-5) and [*Statins are Toxic*](https://www.amazon.com/Statins-Toxic-Side-Effects-Scientific/dp/1781483906/ref=sr_1_1?crid=F5BFSM2CMDWK&keywords=statins+toxic&qid=1683304686&s=books&sprefix=statins+toxic%2Cstripbooks%2C83&sr=1-1), and it’s interesting because in people that really need it (people with severe heterozygous FH), you see a lot less statin intolerance than in people in primary prevention that just have it as a lifestyle drug
  - There is a large psychological component to all of this

**Do you see any benefit on Lp(a) reduction?**

- 56%, in the [*Nature Medicine* paper](https://www.nature.com/articles/s41591-022-01936-7)
- More than with a PCSK9 inhibitor
- Dan Rader did a [stable isotope study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5567403/) with anacetrapib and found out that this CETP inhibitor inhibited the synthesis of Lp(a)
- John has no idea how this is possible because he cannot connect an intracellular synthesis of a protein to a drug that sits on a HDL particle in circulation
  - There must be a link that we still don’t understand
- John is going to do a stabile isotope study with Dan for apoB-containing lipoproteins and they’re going to look at Lp(a)
- In his ROSE trial (published in [*Nature Medicine*](https://www.nature.com/articles/s41591-022-01936-7)), Lp(a) went down by 56% with the 10 mg dose and 43% with the 5 mg dose
- Other CETP inhibitors lower Lp(a) by about 20%, but they are only about one third as efficacious

> “*It feels like the Lp(a) lowering is in conjunction with LDL-lowering, but… I can’t explain this.*”‒ John Kastelein

- Peter finds this amazing and explains, “*If we know that there are a few thousand people that are listening to this who have FH or some trait, there’s tens of thousands listening who have elevated Lp(a).*”
  - Elevated Lp(a) is the most common genetic finding that leads to premature ASCVD

***As impressive as a 50% reduction is, we don’t yet know if that’s clinically enough to reduce outcomes***

- Peter thinks it remains to be seen if the ASO inhibitors will be the lifeline there (TBD)

**Longevity**

- Peter wants to remind the audience of the [Mendelian randomization](https://www.ahajournals.org/doi/10.1161/CIRCGENETICS.114.000748) observation that CETP activity is largely genetic, and ***people with hypofunctioning CETP tend to live a very long life***
  - They have less heart disease, less Alzheimer’s disease, less diabetes, less heart failure, and less renal disease
- We can now add hypofunctioning CETP the the list of longevity genes
  - Other longevity genes: [*APOE2*](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms), [*FoxO*](https://en.wikipedia.org/wiki/FOX_proteins), hypofunctioning [apoC-III](https://en.wikipedia.org/wiki/Apolipoprotein_C-III), hypofunctioning PCSK9
- The Mendelian randomization, it makes it very clear that for every 1 mg/mL decrease in a genetically determined CETP concentration, we’re going to see:
  - About a 0.1 mmol/L reduction in LDL-C, and about the same reduction in triglyceride
  - 2+ nmol/L reduction in Lp(a), which is enormous
  - 0.2- 0.25 mmol/L increase in HDL cholesterol, etc.
  - But one of the things Peter  never realized was you’re also seeing a reduction in blood pressure about 0.2 mmHg, which doesn’t sound like much until you realize that this is just normalized to 1 𝜇g/mL
  - 0.1 mmol/mol change in [hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin)

**CETP inhibitors are potent anti-hypertensive agents as well. What explains this?**

- John replies, “*There’s absolutely no explanation for that.*”
- The data on blood pressure was already known in the day of torcetrapib [the first [CETP inhibitor](https://en.wikipedia.org/wiki/CETP_inhibitor)]
- CETP is made by [Kupffer cells](https://en.wikipedia.org/wiki/Kupffer_cell) in the liver; it gets synthesized and excreted
- CETP sits on the back of an HDL particle
  - 1 in 10 HDL particles have a CETP protein on their backs, and the half like of an HDL particle is about a week

***CETP is a very simple protein; it sits in your circulation or on an HDL and does what it need to do and John has no idea how it can have anything to do with blood pressure***

- He does not know the relation with brain lipid metabolism
- More is known today than two years ago, and we are making great strides in understanding how loss of CETP function influences brain cholesterol metabolism

## Why the APOE4 allele increases the risk of Alzheimer’s disease, and the connection to blood lipids [1:41:30]

- The vast majority of patients with late-onset, sporadic Alzheimer’s disease have an apoE4 molecule on board
  - Their genotype is either *E4/ E4, E3/ E4, or E2/ E4*
  - If you have *E4/ E4*, your risk of Alzheimer’s disease is 16x higher than those who have *E3/ E3*
  - The genotype *E3/ E4* has a risk that is 4.5x higher
- We are beginning to understand why carrying an *APOE4* allele is so back for the brain

***apoE4 is an insufficient molecule to get cholesterol out of cells in the brain that have too much, or bring cholesterol to cells in the brain that have too little***

- apoE4 fails on both accounts; it’s not a good acceptor of cholesterol, and it’s a bad bringer of cholesterol
- If you are *E4* and you have cholesterol abnormalities that accumulate over your life, you get **sterol accumulation in neurons**
- When sterols are in a cell for too long, they become oxidized
  - Like anything else exposed to oxygen, we rust

***Oxidized sterols are what kills cells; it gives a pro-inflammatory signal; it drives cells into apoptosis***

- Oxidized sterols are the worst thing you can have
- An oxidized sterol is not much of a problem if you have a functioning particle in your brain that searches sterols of of the cells and converts them to [24S-hydroxycholesterol](https://en.wikipedia.org/wiki/24S-Hydroxycholesterol), gets it to the blood-brain barrier, to your liver, into bile, and it’s gone
- The brain normally needs a lot of cholesterol for [myelination](https://en.wikipedia.org/wiki/Myelin), building [synapses](https://en.wikipedia.org/wiki/Synapse), building these sprouts
  - But at the same time, if they have too much, then they want to get rid of it fast
  - It’s all wrong in an *APOE4* carrier
- There is only one protein that can help here, [apoA-I](https://en.wikipedia.org/wiki/Apolipoprotein_AI)
  - apoA-I can take over all the functions of apoE4
  - You get apoA-I in the brain by raising it substantially in circulation
  - apoA-I is small enough to get through the blood-brain barrier, and there is very likely a receptor that pushes it through brain cells

***CETP inhibitors raise apoA-I the most by far***

- Large HDLs acquire apoE because as they get larger, they lose apoA-I
  - John thinks he has preclinical evidence for this, and is doing a trail in humans where they taps CSF to look at apoA-I to see if your apoA-I concentration goes up in circulation if it gets into the brain

***Once apoA-I gets into your brain, it takes over the function of the dysfunctional apoE4***

- The **nomenclature** makes this complicated, when the gene and the protein have the exact same name (summarized in the table below)
  - At least with Lp(a) there is the *LPA* gene and Lp(a) lipoprotein
  - Gene names are in all capital letters and italicized

![](https://peterattiamd.com/wp-content/uploads/2023/05/f8-johnkastelein.png)

**Figure 8. Nomenclature of genes and proteins discussed**.

- - The [*APOE* gene](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) has three isoforms [2, 3, and 4], and there are six different possible combinations
  - But here we’re talking about what the apoE protein does
  - The protein transcribed from the *APOE4* isoform is only one [correction: two] [amino acids](https://en.wikipedia.org/wiki/Amino_acid) different from the wildtype isoform

- *APOE3* (the wild type allele) has a cysteine at positions 112 and 158 while *APOE4* has arginines at these positions; all other amino acids are identical

- - ***These two amino acid differences change the three-dimensional conformation of the protein completely and makes it a lousy cholesterol acceptor and transporter***
- If you carry *E4*, there is a long list of things that go wrong in your brain
  - It’s pro-inflammatory
  - Insufficient lipoprotein metabolism
  - It’s no longer a [chaperone](https://en.wikipedia.org/wiki/Chaperone_(protein)) for beta-amyloid
- Chris Hemsworth is a Hollywood actor who knows he is an *APOE4* carrier; he’s an athlete
  - He disclosed this during the *Limitless* series [discussed in [episode #234](https://peterattiamd.com/chrishemsworth/)]
  - Peter thinks it was really valuable that Hemsworth discussed this; it brought a lot of awareness to this

> “*It is very valuable for someone like Chris to know that he has a APOE4 because the earlier you take steps to prevent the exacerbating risk factors, the better your odds.*”‒ Peter Attia

- Peter always opens this discussion by explaining the **risk factors** [having an *APOE4* allele increases the risk of Alzheimer’s disease]:
  - Data suggests it’s a little less than 16 and 4-fold
  - It may be closer to 10-fold and 2-fold, but there’s no question, it’s high risk but it’s not deterministic
  - It’s far less [penetrant](https://en.wikipedia.org/wiki/Penetrance) than FH
    - There are lots of people walking around with *APOE4* that are not getting Alzheimer’s disease, and a third of people with Alzheimer’s disease don’t have *APOE4*
    - So everything they’re talking about is fair game to everybody
- Peter didn’t realize apoA-I could cross the blood-brain barrier, therefore if you have a therapy that raises apoA-I, you can potentially offset the damage of a defective apoE

**Do you have any sense about the magnitude of apoA-I that crosses the blood-brain barrier?**

- Peter adds that those with the [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology)) *KL-VS* variant seem to have almost complete protection from their *APOE4* gene [[*Neurology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6550504/)]
- John recalls one large [Mendelian randomization study](https://pubmed.ncbi.nlm.nih.gov/16096813/) where low CETP protects an *APOE4* carrier from Alzheimer’s disease
- To the question of, “*Can we have an effect size?*” John is doing a “proof of concept” trial where he looks at 50 biomarkers in CSF
  - He hopes apoA-I goes up in the brain, and as a consequence of that, cell are going to normally synthesize cholesterol
  - Levels of [desmosterol](https://en.wikipedia.org/wiki/Desmosterol) and [lathosterol](https://en.wikipedia.org/wiki/Lathosterol) should go up if cholesterol synthesis is normalized
  - At the same time, [24S-hydroxycholesterol](https://en.wikipedia.org/wiki/24S-Hydroxycholesterol) should also go up because cells are getting rid of cholesterol in a normal fashion
  - And the inflammation biomarker should go down because apoA-I basically substitutes for this dysfunctional apoE4
- In order to understand the effect size, they need to be able to make a story where they say dysfunctional apoE4 was replaced by apoA-I and:
  - Normal cholesterol synthesis is on again
  - Normal cholesterol removal is on again
  - Inflammation goes down
- This proof of concept trials only is six months, so there won’t be much in Alzheimer’s biomarkers, but if they can show that they improved lipoprotein metabolism in the brain, it is a first step into a fascinating journey

**Will you be measuring desmosterol and lathosterol in any of these trials or in all of them?**

- No, but in the Alzheimer’s trial he will, it’s a fourth trial (*not* PREVAIL)
- The Alzheimer’s trial has no name because it’s in a single large Alzheimer’s center in Amsterdam
  - Patients basically have mild cognitive impairment with a diagnosis of Alzheimer’s
  - Patients will get obicetrapib, they will serially measure both blood and CSF by spinal taps

*In the PREVAIL trial, will you be looking at lathosterol and desmosterol levels?*

- They will have a lot of spare tubes so that is something they could look at
  - They have quite a wishlist of things they want to look at

## The role of APOE in cardiovascular disease [1:51:45]

**What can we say about atherosclerosis and APOE?**

- *APOE4* might have been wonderful during the ice age, but now it’s bad
  - Because it’s associated with higher LDL
  - It’s associated with a more proinflammatory state
  - It’s associated with more heart disease

**How apoE4 leads to higher LDL**

- [apoE](https://en.wikipedia.org/wiki/Apolipoprotein_E) is found on [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein), VLDL remnants, [chylomicron remnants](https://en.wikipedia.org/wiki/Chylomicron#Chylomicron_remnant), and [IDL](https://en.wikipedia.org/wiki/Intermediate-density_lipoprotein)
- apoE4 is a better ligand for the LDL receptor than apoE3/ E2
- As a result, the chylomicron remnants, VLDL, and ILDL race to your liver and will down-regulate the LDL receptor
  - This allows LDL to go up
- Peter adds, “*Make sure folks understand that, because that’s a bit counterintuitive, right? This is a little bit of a paradox.*”
- apoE is not found on LDL; instead it is on all remnants and VLDL
  - These are taken in by the LDL receptors in the liver, and result in downregulation of the LDL receptor
- With less LDL receptors to get rid of LDL, blood levels of LDL go up

> “*But there’s much more to E4 than just a little lipoprotein metabolism*”‒ John Kastelein

- Carrying the *APOE4* allele is associated with things you down want in the brain such as a chronic proinflammatory state
  - People like [Paul Ridker](https://prevmed.bwh.harvard.edu/paul-m-ridker-md-mph/) has spent their life’s work on this

**Does the association with** ***APOE4*** **in terms of risk vanish once you normalize for apoB, or is there still residual risk based on these other factors such as inflammation that exist and persist once you’ve normalized for** ***APOE3*** **versus** ***APOE4*** **in the context of the same LDL-C/ apoB?**

- John refers to [Alan Snyderman’s](https://www.cardiomuhc.ca/allan-sniderman) work that says once you control for apoB, everything falls away
  - It’s the number of LDL particles
  - apoB is what really drives all our statistics in cardiovascular disease
  - Alan Snyderman was on the podcast in [episode #185](https://peterattiamd.com/allansniderman/)
- For example, the data on [bempedoic acid](https://en.wikipedia.org/wiki/Bempedoic_acid) ([reviewed in 2022](https://bmjopen.bmj.com/content/12/2/e048893.long)) was on the line of absolute LDL lowering versus [MACE](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events) reduction [no MACE reduction even though LDL decreased]
- John asks, “*So where is the room or the space for the* [*CRP*](https://en.wikipedia.org/wiki/C-reactive_protein) *lowering effect if you’re on the line?*”
- John admires Alan Snyderman; he has been stoic in his emphasis on apoB for so long, and finally he is getting vindication where most people agree that non-HDL and apoB are a better prognostic marker and measure of therapy than LDL-C
- Personally, John thinks apoE4 has some properties that you cannot completely knock out with apoB lowering
- Peter thinks Alan’s view and John’s view may not be completely at odds,and John agrees
  - It could be that those other effects are small enough that on a clinical level you would need really large sample sizes and lifetime exposure metrics to see the difference
  - It’s also possible that there are other amplifying features
    - For example, if you take two healthy people (one *E4* and one *E3*) with the same apoB, their risk is similar
    - But if you take two unhealthy people with [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)/ [NAFLD](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease)/ profound insulin resistance (one *E4* and one *E3*) with the same apoB, it could be that those other factors create more of a gap between those people on a [Kaplan Meyer curve](https://en.wikipedia.org/wiki/Kaplan%E2%80%93Meier_estimator)

## Takeaways and looking ahead [1:57:00]

 **Peter’s takeaway**‒ “*I’m trying hard not to be excited… When you’re once bitten, twice shy, and I’ve been a very vocal critic of these trials, meaning the last 15 years of CETP inhibitors, and I would say that perhaps I’ve been too harsh and I’ve been mostly a critic of the HDL hypothesis, and I’ve relied on the CETP story along with the Mendelian randomization as my rationale for that.*”

- With a better understanding of CETP and that the hypofunctioning variant is a longevity gene (maybe more than the hypofunctioning PCSK9), Peter realizes he has been too down on CETP inhibitors and he is very hopeful about obicetrapib
- John has made the same kind of turnaround in his head
- He was a strong believer in the HDL hypothesis until the ROSE trial, then he had to turn away from HDL back to LDL and apoB
  - He had to understand the blood pressure effect
  - Understand the mistakes in the trials
  - Try to find a drug that didn’t have all that baggage
- John’s first [*NEJM* paper](https://www.nejm.org/doi/full/10.1056/NEJM199801083380203) looked at CETP activity in a coronary angiography trial
  - In those days, they only had coronary angiography with pravastatin
  - They found if you had high CETP activity, you had the worst progression of coronary disease in that two year trial

“*That taught me that CETP was bad, and since that day, I’d wanted to find an inhibitor that was something that I could work with.*”‒ John Kastelein

**Looking forward**

- Peter finds this story beautiful and hopes John can write a clinical philosophical paper about how the field has lost its way in this drug based on the wrong biomarker
  - We’re using HDL-C as a biomarker because we didn’t have a better biomarker for CETP inhibition
- The initial insight in the biology was correct, but by having the wrong biomarker and failing to understand the mechanism of that 15 years, billions of dollars were wasted, and lives were lost
  - It’s a sobering story
- John looks forward and emphasizes, “*What we want nowadays is strong Mendelian randomization evidence. We want lots of phase 1 and phase 2 trials to show that there are no bizarre side effects, and then you gently go into a phase 3 [trial]*”
  - Phase 2 trials are no longer done when you see a blood pressure effect, and this is a good thing
- John will have data on Alzheimer’s disease in the summer and is really thrilled to understand what’s happening in the brain

§

## Selected Links / Related Material

**Cohort of children with FH**:

- [Efficacy and Safety of Statin Therapy in Children With Familial Hypercholesterolemia: A Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/199118) | *JAMA* (A Wiegman et al. 2004) | [13:45]
- [Review of first 5 years of screening for familial hypercholesterolaemia in the Netherlands](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(00)03587-X/fulltext) | *The Lancet* (M Umans-Eckenhausen et al. 2001) | [13:45]

**Previous episode of** ***The Drive*** **with Dan Radar**: [#240 ‒ The confusion around HDL and its link to cardiovascular disease | Dan Rader, M.D.](https://peterattiamd.com/danrader/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 30, 2023) | [28:15, 38:15, 55:45, 1:13:00]

**Database of 25,000 FH patients**:

- [Review of first 5 years of screening for familial hypercholesterolaemia in the Netherlands](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(00)03587-X/fulltext) | *The Lancet* (M Umans-Eckenhausen et al. 2001) | [29:15]
- [Cardiovascular risk in relation to functionality of sequence variants in the gene coding for the low-density lipoprotein receptor: a study among 29,365 individuals tested for 64 specific low-density lipoprotein-receptor sequence variants](https://pubmed.ncbi.nlm.nih.gov/22390909/) | *European Heart Journal* (R Huijgen et al. 2012) | [29:15]
- [Selection of individuals for genetic testing for familial hypercholesterolaemia: development and external validation of a prediction model for the presence of a mutation causing familial hypercholesterolaemia](https://pubmed.ncbi.nlm.nih.gov/27044878/) | *European Heart Journal* (J Besseling et al. 2017) | [29:15]

**Diagnostic criteria for FH**: [Diagnosis and Treatment of Heterozygous Familial Hypercholesterolemia](https://www.ahajournals.org/doi/10.1161/JAHA.119.013225) | *Journal of the American Heart Association* (M McGowan et al. 2019) | [30:30]

**Mutation in SR-BI and premature coronary disease**: [Genetic Variant of the Scavenger Receptor BI in Humans](https://www.nejm.org/doi/full/10.1056/NEJMoa0907687) | *NEJM* (M Vergeer et al. 2011) | [39:00]

**Pravastatin treatment of children with FH reverses carotid atherosclerosis**: [Efficacy and Safety of Statin Therapy in Children With Familial Hypercholesterolemia: A Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/199118) | *JAMA* (A Weigman et al. 2004) | [43:15]

**Very low LDL cholesterol levels associated with lower cardiac events**: [Safety and efficacy of very low LDL-cholesterol intensive lowering: a meta-analysis and meta-regression of randomized trials](https://academic.oup.com/ehjcvp/article/9/2/138/6697756#394544844) | *European Heart Journal* (G Patti et al. 2023) | [44:15]

**10-year follow-up of children with FH treated with statins**: [Ten-Year Follow-up After Initiation of Statin Therapy in Children With Familial Hypercholesterolemia](https://jamanetwork.com/journals/jama/fullarticle/1902218) | *JAMA* (D Meeike Kusters et al. 2014) | [48:15]

**20-year follow-up of children with FH treated with statins**: [20-Year Follow-up of Statins in Children with Familial Hypercholesterolemia](https://www.nejm.org/doi/full/10.1056/NEJMoa1816454) | *New England Journal of Medicine* (I Luirink et al. 2019) | [48:15]

**Mendelian randomization establishes the causal role of LDL in ASCVD**:

- [Effect of Long-Term Exposure to Lower Low-Density Lipoprotein Cholesterol Beginning Early in Life on the Risk of Coronary Heart Disease: A Mendelian Randomization Analysis](https://www.sciencedirect.com/science/article/pii/S0735109712047730?via%3Dihub) | *Journal of the American College of Cardiology* (B Ference et al. 2012) | [54:45]
- [Evaluating the relationship between circulating lipoprotein lipids and apolipoproteins with risk of coronary heart disease: A multivariable Mendelian randomisation analysis](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1003062#sec025) | *PLOS Medicine* (T Richardson et al. 2020) | [54:45]

**Mendelian randomization shows that people with high CETP activity have more heart disease**:

- [CETP (Cholesteryl Ester Transfer Protein) Concentration: A Genome-Wide Association Study Followed by Mendelian Randomization on Coronary Artery Disease](https://www.ahajournals.org/doi/10.1161/CIRCGEN.117.002034) | *Circulation* (L Blauw et al. 2018) | [1:00:30, 1:38:00]
- [Circulating Cholesteryl Ester Transfer Protein and Coronary Heart Disease: Mendelian Randomization Meta-Analysis](https://www.ahajournals.org/doi/10.1161/CIRCGENETICS.114.000748) | *Circulation* (W Niu & Y Qi 2015) | [1:00:30, 1:38:00]

**Mendelian randomization finds that genes that raise HDL cholesterol are not associated with lower risk of CVD**: [Plasma HDL cholesterol and risk of myocardial infarction: a mendelian randomisation study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(12)60312-2/fulltext) | *The Lancet* (B Voight et al. 2012) | [1:06:15]

**Mendelian randomization finds that genes that lower HDL cholesterol are not associated with increased CVD**: [LCAT, HDL cholesterol and ischemic cardiovascular disease: a Mendelian randomization study of HDL cholesterol in 54,500 individuals](https://pubmed.ncbi.nlm.nih.gov/22090275/) | *Journal of Clinical Endocrinology and Metabolism* (C Haase et al. 2012) | [1:06:15]

**Mouse model of FH are more resistant to bacterial infection**: [Low-density lipoprotein receptor-deficient mice are protected against lethal endotoxemia and severe gram-negative infections](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507194/) | *The Journal of Clinical Investigation* (M Netea et al. 1996) | [1:11:30]

**Pedigrees suggest FH did not result in lower mortality before 1915**: [Mortality over two centuries in large pedigree with familial hypercholesterolaemia: family tree mortality study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC31037/) | *BMJ* (E Sijbrands et al. 2001) | [1:11:45]

**CETP inhibitors reduce risk of diabetes, meta-analysis**: [The effect of CETP inhibitors on new-onset diabetes: a systematic review and meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9729761/) | *European Heart Journal Cardiovascular Pharmacotherapy* (K Dangas, A Navar, & J Kastelein 2022) | [1:16:45]

**ROSE trial, phase 2 trial of obicetrapib**: [Lipid lowering effects of the CETP inhibitor obicetrapib in combination with high-intensity statins: a randomized phase 2 trial](https://www.nature.com/articles/s41591-022-01936-7) | *Nature Medicine* (S Nicholls et al. 2022) | [1:24:45, 1:33:45, 1:35:45]

**Previous episode of** ***The Drive*** **discussing the FOURIER and ODYSSEY trials**: [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/)  (June 13, 2022) | [1:31:00]

**CETP inhibitors lower production of Lp(a)**: [CETP (Cholesteryl Ester Transfer Protein) Inhibition With Anacetrapib Decreases Production of Lipoprotein(a) in Mildly Hypercholesterolemic Subjects](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5567403/) | *Arteriosclerosis, Thrombosis, and Vascular Biology* (T Thomas et al. 2017) | [1:35:45]

**Previous episode of** ***The Drive*** **with Chris Hemsworth**: [#234 ‒ Chris Hemsworth on Limitless, longevity, and happiness](https://peterattiamd.com/chrishemsworth/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 12, 2022) | [1:47:99]

**Mendelian randomization shows loss of function of CETP protective in** ***APOE4*** **carriers**: [Cholesteryl ester transfer protein (CETP) polymorphism modifies the Alzheimer’s disease risk associated with APOE epsilon4 allele](https://pubmed.ncbi.nlm.nih.gov/16096813/) | *Journal of Neurology* (E Rodriguez et al. 2006) | [1:49:00]

§

## People Mentioned

- [Thomas (Tom) Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876) (MD, FACP, FNLA, lipidologist) [4:45, 1:19:00]
- [Michael Hayden](https://medgen.med.ubc.ca/michael-hayden/) (Professor of Medicine at The University of British Columbia, genetic disease expert) [6:15]
- [Evan Stein](https://www.cardiometabolichealth.org/faculty/evan-stein/) (Faculty of the Cardiometabolic Health Congress) [27:00]
- [Dan Rader](https://www.med.upenn.edu/pcpm/daniel-j-rader-md.html) (Professor of Molecular Medicine at the Perelman School of Medicine at the University of Pennsylvania and expert in HDL) [28:15, 38:15, 55:45, 1:13:00, 1:23:15, 1:35:45]
- [Peter Lansberg](https://www.researchgate.net/profile/Peter-Lansberg) (lipidologist in the Department of Vascular Medicine at the Academic Medical Center in Amsterdam, the Netherlands)
- [Philip Barter](https://www.sydney.edu.au/medicine-health/about/our-people/academic-staff/philip-barter.html) (Professor of Medicine at the University of Sydney Heart Research Institute) [56:30]
- [Michael Davidson](https://www.uchicagomedicine.org/find-a-physician/physician/michael-h-davidson) (Clinical Professor of Medicine and Director of the Lipid Clinic at the University of Chicago, Pritzker School of Medicine)  [1:05:15]
- [Paul Ridker](https://prevmed.bwh.harvard.edu/paul-m-ridker-md-mph/) (Professor of Medicine at Harvard Medical School and Director of the Center for Cardiovascular Disease Prevention at Brigham and Women’s Hospital) [1:54:15]
- [Alan Snyderman](https://www.cardiomuhc.ca/allan-sniderman) (Professor of Cardiology and Medicine at McGill University and Director of the Mike Rosenbloom Laboratory for Cardiovascular Research at Royal Victoria Hospital in Montreal) [1:54:45]

§

![](https://peterattiamd.com/wp-content/uploads/2023/05/bio-johnkastelein-500x500.png)

##### John Kastelein, M.D., Ph.D.

John Kastelein earned his doctorate in medicine (with honors) from the University of Amsterdam. He trained in internal medicine at the Academic Medical Center of the University of Amsterdam. He completed his training in lipidology and molecular biology at the University of British Columbia in Vancouver.

Dr. Kastelein is a Professor of ACS – Atherosclerosis & Ischemic Syndromes, ACS – Pulmonary Hypertension & Thrombosis, and Vascular Medicine at [Amsterdam University Medical Centers](https://www.amsterdamumc.org/en/research/researchers/john-j.-p.-kastelein.htm) where he held the Strategic Chair of Genetics of Cardiovascular disease. His research focuses on pathogenesis of atherosclerosis, lipoprotein metabolism, and treatment treatment to lower cardiovascular risk.  Dr. Kastelein has published over 800 research papers in peer-reviewed journals, including *Nature Genetics, Lancet, New England Journal of Medicine, JAMA,* and *Circulation*. He has a [discipline H-index of 159](https://research.com/u/john-jp-kastelein).

Dr. Kastelein founded the Lipid Research Clinic in 1989, which is currently serving as a tertiary referral center for over 5000 patients each year. Dr. Kastelein has served as President of the Dutch Atherosclerosis Society (DAS) and chair of the National Scientific Committee on Familial Hypercholesterolemia (EHC). He also is a member of the Royal Dutch Society for Medicine & Physics, the Council for Basic Science of the American Heart Association, the European Atherosclerosis Society, and a Fellow of the European Society of Cardiology. He is a board member of the International Task Force for CHD Prevention and served on the Executive Board of the International Atherosclerosis Society (IAS). Additionally, Dr. Kastelein has served on a number of executive and steering committees of large cardiovascular intervention studies, including the SPIRE, ORION, GLAGOV, REALIZE, IDEAL, TNT, CAPTIVATE, ENHANCE, ILLUMINATE, JUPITER, and RADIANCE. In 2010 he was awarded the prestigious Dutch Heart Association prize of 1 million euros. He was the 2014 recipient of the [Anitschkow Prize](https://eas-society.org/society-affairs-and-governance/grants-awards-prizes/anitschkow-prize/) by the European Atherosclerosis Society.

Dr. Kastelein is the founder and CSO of NewAmsterdam Pharma, a company developing the CETP inhibitor Obicetrapib. He is also a key advisor to a number of biotech and pharmaceutical companies, and is a member of the steering committees of numerous lipid-lowering and cardiovascular intervention trials. [[NewAmsterdam Pharma](https://www.newamsterdampharma.com/aboutus#clinical-advisory-board)]

Twitter: [@JohnKastelein](https://twitter.com/JohnKastelein)