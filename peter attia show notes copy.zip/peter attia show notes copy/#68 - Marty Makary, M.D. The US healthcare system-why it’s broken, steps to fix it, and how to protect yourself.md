# #68 – Marty Makary, M.D.: The US healthcare system—why it’s broken, steps to fix it, and how to protect yourself

**Source:** [https://peterattiamd.com/martymakary/](https://peterattiamd.com/martymakary/)

---

##### Check out more content from Marty Makary, M.D.:

- *(Aug 26, 2019)* [#68 – The US healthcare system — why it’s broken, steps to fix it, and how to protect yourself](/martymakary/)
- *(Jan 3, 2022)* [#189 – COVID Part 1: Current state of affairs, Omicron, and a search for the end game](/covid-19-current-state-omicron/)
- *(Jan 24, 2022)* [#192 – COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more](/covid-part2/)

In this episode, Marty Makary, Johns Hopkins surgeon and NYT bestselling author, discusses his new book, [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=sr_1_1?keywords=the+price+we+pay&qid=1557713767&s=books&sr=1-1), and his ambitious attempt to fix the broken U.S. healthcare system through educating the public, changing the lexicon, encouraging radical transparency in pricing, and more. We go in detail into the main drivers of inflated health care costs, the money games being played making it hard to understand, and the unfortunate system structure that has resulted in one in five Americans finding themselves in medical debt collections which can ruin the lives of people and families seeking basic medical care. Marty also shares some very practical advice and tips if you find yourself a victim of predatory pricing and stuck with an outrageous medical bill. In the end, despite the current state of the system, Marty discusses the many exciting trends gaining traction in healthcare and why he is very optimistic and hopeful about the future.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/martymakary/the_Drive_public.png)

Play

#68 - Marty Makary, M.D.: The US healthcare system—why it's broken, steps to fix it, and how to protect yourself

#68 - Marty Makary, M.D.: The US healthcare system—why it's broken, steps to fix it, and how to protect yourself

1x15s30s

0:002:49:57

§

\*This episode of The Drive centers around the content of Marty’s new book, [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=sr_1_1?keywords=the+price+we+pay&qid=1557713767&s=books&sr=1-1), which is set to release September 10, 2019. If you’d like to dive deeper into this topic, Marty’s new book will be a great resource.\*

§


We discuss:

- The science of delivering healthcare, how we need to do better as a system, and why no single person or entity fully to blame [10:15];
- The stories that prompted Marty to write his first book (Unaccountable) [19:15];
- The Surgery Checklist [26:15];
- The problem is with the system (not any one person or entity) and the misaligned interests of all the parties involved [28:15];
- Patients crave honesty and transparency, and the story of Peter’s back surgery gone wrong [33:00];
- Today’s med students and young doctors have less tolerance for predatory pricing and healthcare industry BS [44:30];
- Funny stories about John Cameron (legendary surgeon at Johns Hopkins) [48:00];
- How doctors are trained to internalize traumatic experiences which can result in a misunderstood form of “burnout” [57:40];
- The beat down of med students with traditional medical education and some exciting innovations to medical education [1:07:00];
- Exciting trends in healthcare and an optimistic view of the future [1:11:30];
- The Price We Pay (Marty’s new book), an attempt to illuminate the blackbox that is the US healthcare system [1:21:00];
- Why it’s not always in the best interest of the insurance company to negotiate the best price [1:28:30];
- Who is actually paying for medical costs, and Marty’s frustration with the healthcare lexicon [1:32:00];
- Pros and cons of a single payer system [1:37:00];
- How to fight outrageous medical bills and predatory pricing (and make a dent in the wasteful healthcare spending for the country) [1:49:30];
- Disrupting the healthcare industry with private healthcare facilities with market demanded transparency [2:05:45];
- The people hurt the worst by the current US healthcare system, the sad breast cancer statistic, and the importance of knowing that medical bills are negotiable [2:09:30];
- The healthcare industry bubble [2:14:00];
- Increased costs from unnecessary tests and procedures [2:16:30];
- Malpractice concerns due to the litigious culture in America: What influence does it have on unnecessary testing, healthcare costs,  and overall quality of treatment [2:22:00];
- Drug pricing, price gouging, middle-men money games, kickbacks, and other drivers of healthcare costs [2:27:45];
- How can we possibly fix the healthcare system? [2:34:30];
- Helpful resources [2:46:15]; and
- More.

§

## Show Notes

## The science of delivering healthcare, how we need to do better as a system, and why no single person or entity fully to blame [10:15]

**Marty’s first book**: [Unaccountable: What Hospitals Won’t Tell You and How Transparency Can Revolutionize Health Care](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198383)

\*This has been made into a popular show on Fox called [The Resident](https://www.fox.com/the-resident/)

*What prompted you to write Unaccountable?*

- “Unaccountable to me was an opportunity to … engage the general public in a way that both brings honor to medicine and at the same time warns people that it’s important to get a second opinion. It’s important to ask certain questions.”

The science of delivering healthcare

- During med school, Marty realized that there was a whole science around the actual delivery of medical care (patient safety, avoiding mistakes, etc.)
- Marty says discussion on policy is detached from the real world inside the trauma center (for example)

**A system problem**

- Marty tells a story about a broken elevator in a hospital
  - A person walked into the open doors and fell to his death
  - For some reason, they still didn’t put up a barrier
  - Shortly after that, *another* person fell again (but did not die)
- Other examples include
  - Broken elevator button to the emergency helicopter pad
  - Person at the x-ray counter refusing to give you x-rays because of some policy they made up
- These stories and others prompted Marty to realize **we have a system problem**
- “It made me think about systems, hospital systems, redesigning the delivery of care. And I think all of those questions naturally open up the question of how can we do better, how do we not harm people?”

**We need to change the** [**lexicon**](https://en.wikipedia.org/wiki/Lexicon) **in medicine**

*Doctors can’t take all the blame*

- Marty says that doctors (understandably) get defensive when they hear the term “medical mistake”
- Doctors work their tail off to get through school and then to get blamed for “mistakes” that in many cases are more of a systems issue
- Marty says it’s important we change the lexicon
  - Instead of “medical mistake”
  - We should say “medical care gone wrong” which is a more of a patient term

*The lexicon in medicine*

- When you say “health care costs” it sounds nebulous
- But the price of health care has gotten out of control

- Medicine has a way of creating its own lexicon to “sterilize” everything (i.e., “preventable adverse event” to describe a death that didn’t need to happen)

> “So one of the things I’ve tried to do, at least with the platform that I’ve been given for my surgical career at Hopkins is say, “How can we change lexicon? How can we look at the systems and the delivery of care? How can we make sure somebody’s in charge of the overall ship?”

**The less absurd errors are far more scary**

- The open elevator shaft story is egregious but far less common
- Peter says the scarier part is the less absurd errors that happen even at the best of institutions
- In residency at Hopkins, Peter remembers the weight of the responsibility he was given when he was very inexperienced
- And at the same time he has the “complete trust” and “absolute faith” of patients
- Marty tells a story about how he stuck a patient over 20 times trying to get an IV in because he was afraid of his chief resident walking in and saying “Why doesn’t this patient have a central line?”
- But that’s how med school is… you have to learn over time and by making mistakes

## The stories that prompted Marty to write his first book (Unaccountable) [19:15]

Marty was seeing “mind-boggling” things he was seeing as a med student and resident

- Spend a million dollars rescuing a patient only to go out and have them repeat that behavior that brought them in
- Or a new medication finally gets invented in the pharma world and brought to the bedside but docs just didn’t feel like giving it or weren’t aware of it

> “The implementation science of medicine is more challenging than the discovery science…so I thought, ‘This is where the opportunity is.’”

**A story from Marty’s residency that stood out**

- A woman had cancer
- The CAT scan was clear about what type of cancer it was
- Doctors insisted that she have this invasive biopsy in order to figure out what the cancer type was
- But the woman DID NOT want the surgery ⇒ “*I just want to go home and sort of live the last few weeks, months of my life in peace.*“
- Yet the team of docs remained insistent that they do the surgery despite the patient’s feelings

> “And I’m just looking at this train that just will not stop and listen to patients, and I’m thinking, ‘How did we get to this point where we just do stuff on people who don’t want things done?’”

   \*Marty says that in the show, The Resident, they did a “beautiful depiction” of this particular case

**The booming healthcare industry**

- In researching the cost crisis for his new book [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=sr_1_1?keywords=the+price+we+pay&qid=1557713767&s=books&sr=1-1), Marty says that healthcare is now the number one industry in the US
- As of January 2018, [it’s the number one business in the US](https://www.theatlantic.com/business/archive/2018/01/health-care-america-jobs/550079/)
- Entire cities have been transformed (e.g., Pittsburgh)

> “We’ve created this train that sometimes doesn’t listen to patients.”

## The Surgery Checklist [26:15]

- Working with [Peter Pronovost](https://en.wikipedia.org/wiki/Peter_Pronovost), Marty published the [Surgery Checklist](https://www.ncbi.nlm.nih.gov/pubmed/16776390)
- Later, Marty and Pronovost worked with the WHO which adapted him list into the [WHO Surgical Safety Checklist](https://en.wikipedia.org/wiki/WHO_Surgical_Safety_Checklist)

\*Peter Pronovost gave Peter Attia this book by Joseph Campbell: [The Hero with a Thousand Faces](https://www.amazon.com/Thousand-Faces-Collected-Joseph-Campbell/dp/1577315936) (This book helped him make his decision about leaving medicine)

## The problem is with the system (not any one person or entity) and the misaligned interests of all the parties involved [28:15]

Marty’s intentions when writing his first book ⇒ [Unaccountable](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198383)

- He wanted to highlight the problems we have as a system, not to blame any one person or entity
- Rather than highlight the human errors, he wanted the message to be: “We’re all human beings. We’re going to make human mistakes. Let’s not blame the human being. Let’s talk about how we minimize those mistakes, how we create safety nets when they do occur, and how we talk openly and honestly about them.”
- That said, there are certain people who probably should not be doing surgery (maybe 10% of residents)
- One time Marty pointed about some egregious errors a resident was making in the operating room by one particular person
- It was an entirely avoidable issue, and it was a “skill issue”
- When Marty told another doctor about it, the other doc’s response was “that’s too bad”
- This had Marty thinking, “Is that how we help each other? Is that how we police ourselves?” There’s got to be a better system.”

> “Hospitals are profiting from the individuals, not that they want anything bad to happen, but they’re just not financially aligned to really intervene. . .I realized we’ve got to educate patients on second opinions. We’ve got to educate patients on the questions to ask, and I try to be very honest about the issue.”

*Marty not thrilled about the title*

- Marty said one problem with the book is that the publishers made him title it “Unaccountable”
- Most doctors that contacted Marty were grateful and encouraging
- But 10% of doctors that gave him negative feedback, but Marty suspects that most of those doctors didn’t read the book…instead they probably just reacted to the title

*The media sensationalization*

- The media sensationalizes the topic of patient safety
- As a patient safety researcher, it’s hard to state the facts and then trust the media is fair and balanced (they’re all in the ratings business)

> “To be very honest, I’m thankful that I’m no longer a researcher in patient safety, and my entire research effort has moved on to the cost crisis in healthcare because during that era, a 10 year era when we were doing a lot of research on patient safety, working on The Surgical Checklist, the media was sensationalizing the subject a lot.”

## Patients crave honesty and transparency, and the story of Peter’s back surgery gone wrong [33:00]

**The gag rule**

- In medicine, there is an unwritten rule called the “gag rule”
- When there is a bad outcome (i.e., someone dies on the operating table), if there is \*any chance\* that a lawsuit could be involved, doctors are not allowed to speak to the family of the patient
- This is not only unfair to the family, but it’s also traumatic for the doctor

> “Even if somebody made a mistake, it’s remarkable how patients are forgiving. They just want honesty.”

**Peter’s back surgery gone wrong**

- In med school, Peter has a debilitating back issue that required emergency surgery
- The surgery operated on the wrong side and actually made the situation worse
- At follow ups, the surgeon refused to acknowledge anything was wrong
- He actually called Peter a “pussy”

“This guy was a horrible human being who happened to do this, but what amazed me was the **complete and utter lack of honesty**.”

**People crave honesty and transparency**

- When things go wrong, hospitals have risk managers who push a deny and defend mentality when things go wrong, cut off all communication, to mitigate their legal risk
- But in medicine people want honesty, they’re forgiving and they want to understand what happened
- In fact, lawsuits tend to come from a lack of communication after a medical mistake more so than from the severity of the mistake

*NY Times article*: [To Be Sued Less, Doctors Should Consider Talking to Patients More](https://www.nytimes.com/2015/06/02/upshot/to-be-sued-less-doctors-should-talk-to-patients-more.html)

Communication (or lack thereof) is a bigger driver of lawsuits rather than the actual events

- [Apologies and Medical Error](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2628492/)
- [Communication gaffes: a root cause of malpractice claims](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1201002/)

> “The studies show that satisfaction of the patient is the bigger driver rather than the actual events. So if the patient is extremely satisfied, the risk of a lawsuit is low and that’s why I tell docs when something goes wrong, reach out to the patient immediately and disclose.”

**Doctors have need to talk and to avoid internalizing everything**

- Marty compares what doctors go through in a trauma bay or ER room to a milder version of some of the horrors that soldiers witness in war and by internalizing these experiences it can turn them into “robots” and have a negative impact on their lives (see movies [Hurt Locker](https://en.wikipedia.org/wiki/The_Hurt_Locker) and [American Sniper](https://en.wikipedia.org/wiki/American_Sniper))

> “We’re human beings. Things are going to happen. Let’s talk about how to prevent it. How do you feel about this? We’ve got to talk through, because I’ll tell you when we internalize, it’s bad for our bedside skills. We turn into robots.”

## Today’s med students and young doctors have less tolerance for predatory pricing and healthcare industry BS [44:30]

“When they see stuff in the hospital, they call it out, “Wait, whoa, this lady didn’t want a biopsy. Why are we doing the biopsy? Whoa, Whoa, wait a minute.”

[Restoring Medicine](https://www.restoringmedicine.org/) ⇒ organization started by Marty’s students to advocate for more honest and fair pricing

## Funny stories about John Cameron (legendary surgeon at Johns Hopkins) [48:00]

The hierarchy in medicine:

>Attending

->Fellow

–>Chief resident

—>Mid-level resident

—->Junior resident

—–>Intern

——>Sub intern (med student final year)

——->Third year med student

**“Pimping” with** [**John Cameron**](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0001321/john-cameron)

*What is “pimping”?*

- It’s the Socratic method of teaching
- It’s just a method of posing questions and explaining things, but the students perceive this as a do or die interview
- The teacher is actually more interested in someone’s communication skills, honesty, affability than whether they know every fact and stat
- John Cameron would do this to students inside the operating room

Sunday School with John Cameron

- Peter reminisces about “Sunday School” with John Cameron (see [Peter’s discussion with Ted Schaeffer](https://peterattiamd.com/tedschaeffer/) starting at 44:15)
- \*A former student actually wrote about [Sunday School](https://www.surgjournal.com/article/S0039-6060(00)87250-5/fulltext) with John Cameron

*Funny story from Peter*

- Inside the operating room, John Cameron was once questioning a wanna be neurosurgeon
- Peter said that this young girl was a “space cadet” and you just knew deep down she didn’t have what it took to be a neurosurgeon
- Cameron was quizzing her no the history of surgery and she was failing miserably
- He finally pinned her down on a question about who created neurosurgery (if you’re at Hopkins, you KNOW this answer==> Harvey Cushing)
- But the poor girl answered with “Ben Carson?”
- This answer caused Dr. Camerson to “lose it”
- Peter couldn’t wait to get out of the OR because it was so uncomfortable (and he couldn’t wait to tell somebody)

## How doctors are trained to internalize traumatic experiences which can result in a misunderstood form of “burnout” [57:40]

Doctors, nurses, and healthcare providers who are involved in seeing bad outcomes can easily develop a form of PTSD

- Peter tells a story from the trauma bay at Hopkins and witnessing fatalities from gun shot wounds (and in one case seeing a pic of the victim’s 3 yr old daughter in his wallet)
- These experiences can be traumatic but “you have about 10 seconds to get your stuff together and get onto the next one”
- Peter believes that these experiences (and the inability/lack of time to talk about it) contribute to what many refer to as “physician burnout”
- It’s emotionally exhausting to allow yourself to dwell on the horror, and the pain of the families, and so doctors end up internalizing al this
- Any human being in that situation “will naturally turn into a robot”

Many docs (especially [Zubin Damania](https://en.wikipedia.org/wiki/Zubin_Damania)) take major issue with the term “burnout”: ZdoggMD says [it’s not burnout, it’s “moral injury”](https://www.youtube.com/watch?v=L_1PNZdHq6Q)

## The beat down of med students with traditional medical education and some exciting innovations to medical education [1:07:00]

**The beat down of bright, young med students**

- 90% of people will say they want to go into medicine to become a missionary doctor or to help the poor or underserved in some capacity

> “We take people when they come in with these very altruistic goals in life…fast forward 8 or 10 years later and they’re like different people…we beat them down, we make them memorize and regurgitate the Krebs cycle 18 times, even though no one’s ever needed to know the intermediary of the Krebs cycle on the fly in the hospital. This entire medical education is just so absurd.”

\*Innovating education at [Sidney Kimmel Medical College](https://www.jefferson.edu/university/skmc.html) (Thomas Jefferson University)

- They recruit people based on [empathy and compassion](https://www.jefferson.edu/university/skmc/research/research-medical-education/jefferson-scale-of-empathy.html) and self-awareness
- In med school
  - They are going to teach you the standard vocabulary
  - But also going to teach you the life skills that you need to know:
    - How to communicate
    - How to find knowledge when you don’t know it
    - How to be honest and be able to say, “I don’t know”

Traditional medical education…

- In med school, we beat them down with memorizing terms, regurgitation, like running on a treadmill
- In residency… don’t ask questions and internalize all this crap that you’re going to see (much of which “isn’t right”)
- As an example, forcing students to learn opthamology when they are planning to be a urologist
- They are run so ragged, Marty says, “*They feel humiliated, belittled, subjected to all this beating and we wonder why they feel entitled, and we wonder why they’re doing stuff they know they shouldn’t be doing. We wonder why a doctor in a primary care clinic is giving out antibiotics too frequently.*”

## Exciting trends in healthcare and an optimistic view of the future [1:11:30]

High percentage of doctor’s feel overwhelmed

- Marty says it’s hard to find a doctor who’s practicing office based high volume medicine who’s not burn out
- Their schedule is so packed and they are churning through patients every 15 minutes
- And we have a population that seems to be getting sicker and the volume of people needing healthcare is only increasing
- Peter asks, *What is the solution to this? How is there enough time in the day to have enough doctors to take care of these folks?*

Exciting trends and potential solutions ⇒ “*One thing I wanted to do [when writing The Price We Pay] is balance every problem with a solution or exciting disruptor because right now I am so optimistic and up on the future of healthcare. So many cool things are happening.*”

**Globally capitated primary care clinics**

*What does capitation mean?*

- Basically there’s no billing going on
- Globally capitated means that the clinic is getting paid a lump sum amount of money so they don’t have to worry about billing for every little thing
- They can spend as much time as they want with patients because they are **evaluated by the outcomes of those patients long-term**

There’s an exciting one in Florida called [ChenMed](https://www.chenmed.com/)

- They have made a deal with insurance and employers where they get a lump sum for the entire journey of care of the beneficiaries/population/employees
- ChenMed will then assume that downstream risk
- “*It creates this incredible alignment of incentives long-term to do what’s in the best interest of the patient.*”

**Other examples**:

[Kaiser Permanente](https://healthy.kaiserpermanente.org/)

Smaller clinics that Marty is a “big fan” of:

- [Oak Street Health](https://www.oakstreethealth.com/)
- [Iora Health](https://www.iorahealth.com/)
- [Magenta Health](https://magenta-health.com/)

[**Self-insured healthcare**](https://en.wikipedia.org/wiki/Self-insurance) **by large companies**

- Apple (hypothetical example) is an example of a company who could easily “self-fund” or “self-insure”
- At the point of **500 employees or more**, the vast majority of businesses in the United States have recently moved to self-funding
  - Because at that point, it becomes cheaper than traditional insurance

[Stop loss insurance](https://en.wikipedia.org/wiki/Stop-loss_insurance) for smaller companies

- There’s 21 stop loss insurance companies in the US, they sell across state lines, it’s very competitive
- It works beautifully and businesses are saying, “Look, we’ll assume the first $100,000 of risk.”
- A lot of businesses can afford that risk, especially if they’re saving money on the front end.

> “This is the future of healthcare and what’s happening pretty soon and the reason I’m so excited about healthcare is that primary care doctors are saying, “Let me help you, let me move in. I want to be the doc for your company. I want to go over the occupational hazards on the factory assembly line. I want to talk about prevention and doing stuff immediately so that patients don’t need to go to the emergency room. They can come to me for urgent care then I’ll sort of figure out.” And the utilization is down. The costs are down because if there’s one story of a modern American medicine, it’s that price gouging has become an accepted way of doing business in certain pockets of healthcare. And as a business you’re very vulnerable.”

## The Price We Pay (Marty’s new book), an attempt to illuminate the blackbox that is the US healthcare system [1:21:00]

- After leaving medicine, Peter spent two years in credit risk learning about the mortgage-backed security crisis
- At the end of the two years, he said he understood about 95% of how it all worked
- The book (and film), [The Big Short](https://en.wikipedia.org/wiki/The_Big_Short), did a great job explaining it to where someone could understand it up to about 70%
- By contrast, Peter says that if you gave him another 3 years devoted to understanding the US healthcare system, he “wouldn’t be able to do it”
- It is just too convoluted to understand

**The Price We Pay**

![](https://peterattiamd.com/wp-content/uploads/2019/08/The-Price-We-Pay_3d-683x1024.png)**Figure 1. Book cover for The Price We Pay by Martin Makary.**

- Marty hopes that [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=sr_1_1?keywords=the+price+we+pay&qid=1557713767&s=books&sr=1-1) will do for the healthcare crisis what [The Big Short](https://en.wikipedia.org/wiki/The_Big_Short) did for the mortgage crisis
- Marty hopes his book will explain things in a way that are understandable, relatable, and that touch on every area of healthcare

⇒ *To understand the healthcare situation, we must first have an understanding of*:

- Pricing failures
- The overtreatment crisis that we’ve created
- Middlemen and administrative waste

[**Pharmacy benefit managers**](https://en.wikipedia.org/wiki/Pharmacy_benefit_management) (example of a middle man)

⇒ \*Girl Scout cookie analogy\*

- Girl scout leader comes to your business and says, “You should provide cookies to all your employees as a benefit”
- The business owner says “Great, I like the idea of all my employees having Girl Scout cookies.”
- The girl scouts sell the cookies to the employees for $5 per box (as a copay)
- The girl scout then charges the company $50 per box
- You would think the employer would say “wait a minute, you are gouging me on price”
- \*HOWEVER… in the healthcare world, **employers cannot understand** the names of the drugs and the generic substitutes and the biosimilars and the bioequivalents and the different dosing schedules and the different frequencies
  - A 1,000 employee company will get a report with 4,000 medications that you paid for as a self-funded or self-insured business
  - Unlike cookies where it’s easy to understand market value, the employer has no clue what market value is
- Furthermore, the brokers/PBMs are playing “money games”
  - When the employer pushes back on the cost, they will say “You’re getting a great discount.”
  - In reality, they are setting the price at whatever they want and then “discounting” it to make seem like a great deal

**\*Recommendation**: Considering using [GoodRx](https://www.goodrx.com/) for prescriptions\*

- Oftentimes, you can pick up medications for a cheaper price that even your copay through GoodRx
- Download the [GoodRx app](https://www.goodrx.com/mobile) for your mobile device

## Why it’s not always in the best interest of the insurance company to negotiate the best price [1:28:30]

A story recently came out about an [insurance executive who got charged $70,000 for a hip replacement](https://www.npr.org/sections/health-shots/2018/05/25/613685732/why-your-health-insurer-doesnt-care-about-your-big-bills)

- The “sticker” price was about $29,000
- The $70,000 price tag was actually the “negotiated” rate between the hospital and his insurance company
- The question is… who in the world negotiate that price??
- Well, the truth is that it **may not always be in the financial interest of the insurance company to negotiate the best rate**

*⇒ Why??*

- The [Affordable Care Act](https://en.wikipedia.org/wiki/Patient_Protection_and_Affordable_Care_Act) revised the [medical loss ratio](https://en.wikipedia.org/wiki/Loss_ratio) (MLR) to say that insurance companies could only make a 20% profit and that 80% of the money had to be paid out as claims payouts
- So if you can only make 20% of the premiums as profit, how do you make more profit the next year?
  - You would want to drive up revenue as high as possible bc you can only take 20% of the gross
  - You also want more payouts so you can justify increasing premiums the next year

## Who is actually paying for medical costs, and Marty’s frustration with the healthcare lexicon [1:32:00]

Marty says, “one of my biggest frustrations is the lexicon or the language that we all use [around medical bills and insurance].”

- The phrase “My insurance company paid that amount” is commonly used
  - Well, in fact, YOU paid that amount in your insurance premiums
- The phrase, “my employer paid the rest.”
  - Well, that’s actually from the same pool of money towards wages and benefits that you would otherwise get a raise from
- And the phrase, “Oh, the government paid.”
  - We’re paying like a 7.5% Medicare excise tax on your end (double that if self-employed)

**Shocking (and sad) stats**

- [Healthcare is now about 18% of GDP](https://www.cms.gov/Research-Statistics-Data-and-Systems/Statistics-Trends-and-Reports/NationalHealthExpendData/index.html)
- In Massachusetts, **43% of tax dollars** go towards healthcare
- Health related costs are the leading cause of personal bankruptcy
- [One in five Americans are in debt collections](https://www.norc.org/NewsEventsPublications/PressReleases/Pages/new-kaisernew-york-times-survey-finds-one-in-five-working-age-americans-with-health-insurance-report-problems-paying.aspx)

**Hospitals taking people to court**

There’s a [court in Virginia](https://www.npr.org/sections/health-shots/2019/06/25/735385283/hospitals-earn-little-from-suing-for-unpaid-bills-for-patients-it-can-be-ruinous) that will take you to court within months and garnish your wages (if you fail to pay medical bills)

- And if you have no wages they will take it directly from your savings account
- This is a *not-for-profit* hospital
- Mostly, these are poor people who work and have health insurance who have done nothing wrong
- They’ve showed up to work. They work hard. I’ve met several of them who are single moms.

Hospital in New Mexico in a town of 28,000 people

- The hospital has sued HALF the population
- The court employees say that 95% of what we deal with is the hospital suing people (10 or 20 lawsuits in a day)

> “People are getting hammered out there. And what we’re saying and what I’m trying to use this incredible platform that God’s given me as a surgeon at Johns Hopkins is to say this is not our heritage. This is not our profession. We have this incredible public trust. We need to stand up for our patients.”

## Pros and cons of a single payer system [1:37:00]

Single-payer healthcare systems (i.e., Canada and UK):

- They are not perfect (or even ideal) systems, however, they do have some good things going for them:
  - It is budget-driven, whereas US is a demand-driven system
  - And a single payer always owns the risk for life.

In the US…

- Demand determines money spent ⇒  and demand set by *patient and provider*
- Portability of risk ⇒ the average tenure of a person with a particular payer (Aetna, United, etc.) is less than 4 years
- The payer knows they only have that person for a few years so they don’t have long term incentive to keep that person healthy
- Example, if someone gets T2D, that person will be expensive in 20 years,  BUT… over the next 3 years they won’t cost the payer that much… so there is no incentive to do anything about
- Finally, we don’t have universal coverage
  - “Why is someone who makes $ 28,000 a year and has health insurance ever getting a bill for $4,000? What’s the morality behind that?”

Marty:

> “It’s just there’s no real reward financially to accompany the goodwill that we all have that we want what’s best for patients. . .that’s what I love about these, what I call globally capitated primary care, that have lives for the long haul and they’re doing incredible things. And if you’re a business, sign up with **Iora, ChenMed, Oak Street**, one of these globally capitated primary care, or get some of these local primary care practices are pulling together and saying, “We want to go to the local business and we want to work with them.”

**Insurance brokers**

- Just like the mortgage crisis and the financial collapse of 2008, people just don’t understand what’s happening and the money games going on

⇒ So for example,

- if a business gets a higher insurance premium rate for next year, they’ll tell their broker, “This is crazy. 11% increase in one year??”
- The broker will say “Well, the costs of drugs and the cost of …” BUT… the reality is that **it is more about the intermediaries and money games being played**
- Insurance brokers  get paid a giant kickback from the insurance company or the pharmacy benefit manager for sticking an employer with one of their plans
- In other words, companies aren’t always given the best options
- Switching to an “independent” broker can sometimes save a business half a million dollars immediately

> “And businesses all over America are getting ripped off right now in their health insurance and on their pharmacy benefit management plans.”

*⇒ Would a single-payer system solve this problem?*

- Yes, it would
- And per Marty’s research, it would save 15% right off the top of the US Healthcare costs

However… Marty says **Medicare for All has major problems**

- Over time historically, governments have shown 100% of the time, **they cannot resist the temptation to make across the board cutbacks on healthcare**
- Over time you’re left with dilapidated systems
  - E.g., parts of the UK or other countries where their spending on healthcare is just so weak that when the doctors, like in England, went on strike, the government’s kind of like, “Well, you guys are civil servants, suck it up.”

## How to fight outrageous medical bills and predatory pricing (and make a dent in the wasteful healthcare spending for the country) [1:49:30]

We must cut back on the waste

- Some estimates say that as much as *50% of our healthcare spending is wasted*
- Example, Marty says a woman was once billed $1,200 for checking into the ER even though she left before she got any treatment

> “I like the idea of cutting out the waste. But I think if we can do it through free market competition, then it’s much better for the long term.”

In his book, The Price We Pay, Marty is attempting to **educate the public**

- “We can educate employers, everyday Americans, how to buy drugs, how to buy health insurance, how to ask the questions, get second opinions, challenge their bills, and recognize that when you get one of these massive bills, you’re not legally obligated to pay it.”

**No legal contract**

- Marty has pro bono lawyers making the legal case and they are overloaded with unlimited cases
- The argument in court is that there’s no legal contract
- Analogy: It’s like someone cuts your hair and then charges you $900 after the fact… there’s no legal contract

An egregious real life example:

- African doctor whose son needed an endoscopy
- The procedure requires a fee for the gastroenterologist, hospital, anesthesiologist
- Turns out… all the fees related to the procedure were “inside the network” of the patient’s insurance EXCEPT for the anesthesiologist (for no reasons that this patient could ever understand)

*⇒ What is the legal obligation of that patient and how can that patient fight it?*

- Marty has been making the argument that there is no legal contract
- In addition, even if something was signed prior to the procedure, you could easily make the argument that it was signed under duress which negates the contract (i.e., if someone comes in with a burst appendix and is in excruciating pain)

EMTALA law

- Hospitals are required by law ([EMTALA](https://en.wikipedia.org/wiki/Emergency_Medical_Treatment_and_Active_Labor_Act)) to take care of anyone with an urgent or emergent condition
- There’s no credit card needed, or checking of SS#, none of that is required

\***TIP to avoid predatory pricing**\*

- If you feel that there’s a legal document that you have to sign your home and your financial life away in order to get stitches and you’re concerned about predatory billing, you sign in that little signature box the words, “DID NOT READ”
- Nobody is going to read what you sign in there and then when the collectors call and the judge says you have to provide your routing number and your account number or we’re going to garnish your wages, you say there’s **no legal contract**

> “We’re trying to empower people in the United States to say we need a competent and fair pricing system.”

**How people can fight massive hospital bills created by hospital pricing schemes**

- The hospitals have learned to show inflated prices so they can give big discounts and still make a killing
- “People are getting hammered with surprise bills right now. Hammered.”

*Why are bills so hard to understand?*

- A simple doctor visit often produces a super complicated bill that makes no sense
- Marty once took a hospital bill to a hospital CEO
- The bill was for $5,000 for a simple 45 minute
- The hospital CEO could not even explain how it was that high

**⇒** Example of how the hospitals inflate prices

- Hospital sets an arbitrary sticker price, say $5,000
- They then tell the insurance company (or employer), we normally charge $5,000 but we will give you a special discount and change $500 to make them feel like they are getting a great deal
- Sounds great right?
- But the reality is, if you could arbitrarily set a sticker price you could discount it 99% and still make a killing
- And by the way, different companies get different discounts to add to the confusion
- In addition to these secret discounts, *both parties are sworn to secrecy* that this discount cannot be made public and **that kills the competition**

*What is the legal recourse for someone stuck with an outrageous bill?*

- You should argue in court/or with the collections agency  that they need to provide the legal contract
- You are entitled to see the contract or agreement that obligates you to pay
- \*The only time you’re being technically presented with a contract for price is at the provider’s level, and we’re basically saying it’s very easy to render that contract null and void.\*

**⇒ Another thing you can do**: If it’s really egregious, contact your state’s attorney and contact your local news network

- [Sarah Kliff](https://twitter.com/sarahkliff?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) with the NY Times and [Elisabeth Rosenthal](https://twitter.com/rosenthalhealth?lang=en) at Kaiser Health News each have sections where you can send in your bills

**Quarter million dollar helicopter rides**

> “You just nailed the number one story of the modern American healthcare system. Entities, organizations, doctors, hospitals, ambulances, helicopters have figured out if you bill outside of insurance, you can just gouge and some people will pay it. And if you just send it to collections and harass and send them 50 bills, some people just pay it. And the reality is God’s been good to you and I. If we got a $5,000 bill, we’d find a way just to pay. It might be annoying, but we’ll find it. But half of America has less than $300 in savings. People are getting hammered.”

## Disrupting the healthcare industry with private healthcare facilities with market demanded transparency [2:05:45]

> “This is the future. It’s exciting, it’s disruptive, it’s why I’m so up on medicine right now.”

[Keith Smith](https://surgerycenterok.com/specialist/keith-smith-m-d/), a doctor in OKC, is [disrupting healthcare in Oklahoma](https://www.theconservativepundit.net/meet-the-pundits/g-keith-smith-md/)

- He told Marty, “This is total BS. I don’t understand how a doctor can take an oath, treat a patient, and ruin their life financially. It’s against everything I’ve ever considered sacred about this heritage of medicine.”
- He now offers one bundled price for every service at his medical center (you don’t get a bill for the epidural separate and from the anesthesiologist fee, etc.
- “They got their act together and hospitals need to get their act together instead the finger pointing, ‘Oh well that’s the lab. The lab is billing you separately.’”
- The insurance companies and hospitals hate Keith and hope he fails
- But he’s doing well and people with fly from all over to go see him because they know they get an honest price

⇒ Marty’s [study evaluating price transparency medical centers](https://www.ncbi.nlm.nih.gov/pubmed/29712614)

- They evaluated the price transparency medical centers in the United States before and after they decided to go full, honest pricing.
- And they all do incredibly well… their business goes up, their satisfaction goes up

\*The future is **private healthcare**, but with *market demanded transparency\**

- It’s very appealing to wipe out all the money games overnight with a single payer system…
- But if you look academically at every government that has done it, they cannot resist the temptation to just skim, cut, skim, cut year after year, 10 or 20 years

## The people hurt the worst by the current US healthcare system, the sad breast cancer statistic, and the importance of knowing that medical bills are negotiable [2:09:30]

- There’s no question that the quality of care we have the potential to deliver is exceptional under the right circumstances
- But we have a cost crisis, and we have an access crisis
- The two subsets of people who are therefore going to be crushed in the US healthcare system are…
  - People who cannot afford access at all, and
  - People who can’t afford egregious costs when levied upon them
- If you’re not in those two camps, you’re going to be okay.
- But we might be at a tipping point where it’s become so egregious if it’s true that one in five people are getting collections through healthcare

**Breast cancer and debt collections**

- A recent study just came out at ASCO, [half of women with stage four breast cancer in the United States are being harassed by medical debt collectors](https://www.medscape.com/viewarticle/903202)

*How do medical debt collectors feel about what they have to do for a living*?

- Well, some of them hate their life.
- I would say for the most part, they are glad to be in a position where for the most part, if you object, fight your bill, they’re going to just knock off 20, 50% right off the top.

\*Another tip for people out there\* ⇒ **Medical bills are negotiable!**

- The business model (of hospitals for example) relies on some people just saying, “Oh screw it, I’ll pay.”
- Some hospitals (Duke) even employ more “revenue cycle” and “revenue enhancement” people than they have beds in the hospital

## The healthcare industry bubble [2:14:00]

If you fix the healthcare system, how many people are going to lose a job?

- A lot, Healthcare is an enormous industry. It employs tens of millions of people.

Just like the subprime mortgage crisis…

“Healthcare is a gigantic bubble right now and the parallels to the financial crisis are striking. At some point, if you think about it, we are spending money we don’t have on products that we don’t even need sometimes. The PBM world, medical services that are unnecessary, the enormous middle layers, and doctors quite honestly are very suspicious of what’s happening. They don’t understand. I mean, I didn’t understand until I started touring and going to these conferences and and saying, ‘I’m sick of this. I’m a professor of health policy. I don’t feel like I have a handle on the entire healthcare system.’”

- If it weren’t for all the money games being played, there are many jobs in the healthcare industry that wouldn’t need to exist
- If we had honest and fair pricing in America, we wouldn’t need this gigantic negotiating of discounts and markups, the markup discount game I call it.

**The importance of changing the lexicon**

Marty emplores people to change the language they use the “honest lexicon” and “patient centered terms”

- Instead of preventable adverse event say medical care gone wrong
- Instead of saying costs says prices
- Instead big medical bills says predatory billing practices

## Increased costs from unnecessary tests and procedures [2:16:30]

*When doctors are asked privately, what percentage of tests that physicians ordered do they deem unnecessary?*

- 21% was the average according to Marty’s [survey of over 2,000 doctors](https://www.ncbi.nlm.nih.gov/pubmed/28877170)

One of the most egregious examples is the use of [stents](https://en.wikipedia.org/wiki/Stent) in interventional cardiology

- There are cases where a stent will absolutely save a patient’s life (i.e., somebody is having an ST elevated wave MI and they’re hemodynamically unstable)
- But then there’s a whole body of literature that makes it also pretty clear that there are a whole bunch of people that don’t seem to get any better with stents
- Yet doctors are getting paid by the stent
- But it doesn’t mean that all the doctors doing this are bad people
- Yes there may be some nefarious actors who are literally just shaking down the system and they know that they’re going to get 1000 bucks for every stent they put in… and they will put five stents in this guy today, even though he probably needs zero

See [Peter’s talk with Ethan Weiss](https://peterattiamd.com/ethanweiss/) for more on stents

But Peter’s impression is that the **majority of unnecessary care** comes from…

1 Lack of time to educate themselves and the patients

- Docs that don’t have the time to deal with figuring out exactly what the right thing to do is, and the cost of me giving in and giving someone an antibiotic when I’m pretty sure they have a viral infection that’s going to go away in three days. The cost of me trying to educate the patient on that and explain antibiotic resistance, it’s just too high. I’ve only got 15 minutes. I’ll just give them the Goddamn Z Pack.

2 Avoidance of a lawsuit

- The second subset of that (the worst one) is the doc who thinks “I’m not going to be the guy that gets sued because I didn’t order the head CT on the person with a headache, even though I know that this person stopped drinking coffee two days ago and they went from three cups of coffee a day to nothing and they’re coming in here with the worst headache of their life and I’m pretty 99.999% sure it’s caffeine withdrawal, but I’m not going to let this person walk out of this ER without a head CT because if God forbid it’s a tumor or an aneurysm, I’m going to get sued. So everyone gets a head CT.

## Malpractice concerns due to the litigious culture in America: What influence does it have on unnecessary testing, healthcare costs,  and overall quality of treatment [2:22:00]

- Because of the litigious culture in America… many doctors are “over ordering” unnecessary test to “cover the bases”
- But at the same time, many docs are avoiding caring for a particular patient (especially a complex case of surgery)
- Those two things seems to actually balance out the costs
- In other words, malpractice/lawsuit concerns are not a big driver of the high healthcare costs
- It’s less than three tenths of 1% of the overall healthcare costs crisis

> “It’s vivid and we’re proximate to it as doctors. And to be honest with you, like you say, healthcare is a lot of things that we don’t understand. And here’s one thing we see and we understand and it just seems wrong, and that’s why it’s disproportionately dominating the discussion of healthcare costs.”

## Drug pricing, price gouging, middle-men money games, kickbacks, and other drivers of healthcare costs [2:27:45]

*Recapping some of the drivers of wasteful healthcare spend…*

- Bogus discounts and “middlemen” account for about 15%
- 21% of healthcare and services are unnecessary according to this survey of 2,000 doctors that Marty did at Johns Hopkins
- People are coming up with the stats that roughly half of our healthcare spend can be chopped off and we can still deliver high quality healthcare, and better patient outcomes, says Marty

Drug pricing

- When pharma companies develop drugs, they are budgeting the profit down the road into the drug development price
- Problem is with drug pricing is there are so many moving parts
- Some of these drugs do miracles and save lives (great example being  immune based medications like [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab))
- The problem lies in that there are a few bad actors engaged in the business of price gouging

**Price gouging**

**1** Companies with drug patents that are not giving the information to the generic companies

- By not disclosing info like they should it’s like having a patent for a few more years (FDA is cracking down on this)

**2** PBM (middle men) money games

- The smoke bomb in the PBM world is the **rebates**
- Rebates are when the PBMs (or any middle layer players) say to the Pharma companies,
  - “*If you want to be in our catalog, our formularies that we make available to our employees and on the benefits programs we manage or the hospitals that we supply, if we’re a group purchasing organization or GPO, pay us a million bucks to be in the catalog*.”
- *Well, what does the Pharma Company do*? ⇒ They pay the million bucks and they build it into the price of the drug
- These types of games are what cause things like saline bags to be in shortage and price spike

**3** Bulk “discounts”

1. Providers of saline, for example, will negotiate with the hospital/employer to be the “exclusive provider” of saline and will give them a “bulk discount”
2. The reality is the provider set the price high purposefully so they can sell a big discount

> *“I call it a rich man’s game. It’s very profitable for everybody. . .****except for the patient****.”*

**4** Hospitals getting kickbacks

- Even hospitals are getting kickbacks in healthcare
- Marty says it’s time to ban kickbacks

⇒ *What is allowing kickbacks?*

- It’s a policy issue ⇒ In 1987, the [Safe harbor](https://en.wikipedia.org/wiki/Safe_harbor_(law)) law was passed to give PBMs and GPOs, or it gave PBMs and GPOs exclusivity, so the Sherman Antitrust Act does not apply to this supply chain

## How can we possibly fix the healthcare system? [2:34:30]

**Peter describes the biggest problem as the following**:

- Many people at the individual level are getting screwed by our Healthcare system
- But it seems like it’s happening to individuals and we are not pushing back as a collective
- And it’s very easy for a massive industry to deal with one off attacks

> “The biggest single problem here. . .It’s not a structural problem within the system. There are relatively straightforward ideas that can be tested and iterated on. The problem is, how do you create the inertia for change when the people who have to force change at the individual level have less to gain than the collective entity does to lose?”

**Marty says there are exciting things happening**

- Young people, millennials, doctors, senior physicians who understand the money games are beginning to stand up and organize in a grassroots way
- Marty says that this is the heritage of the medical profession: “*This is who we are as doctors. We’re advocates for our patients. That’s who we are. It’s in our blood.*”
- Examples:
  - [Dr. Albert Sabin](https://en.wikipedia.org/wiki/Albert_Sabin) invented the polio vaccine and forfeited an estimated 8 billion dollars when he gave it away for free rather than patent it
  - [Dr. Benjamin Rush](https://en.wikipedia.org/wiki/Benjamin_Rush), one of the five physician signers of the Declaration of Independence, treated shunned patients with schizophrenia who were impoverished
    - [President Adams](https://en.wikipedia.org/wiki/John_Adams) said, “Benjamin Franklin and Dr. Benjamin Rush both had great contributions to mankind, but Benjamin Rush had more and they were greater,”

> “We have this incredible heritage of being patient advocates. If we can channel 1% of the energy we spend on lobbying for higher doctor pay in Washington DC into being the champions of fair and honest, transparent pricing, we’re going to see this incredible public trust come back.”

**Physicians need to be the catalysts of change**:

- Physicians aren’t the reason that this system is broken
- But now the onus is on them to play a role in catalyzing reform
- Because by association (whether we like it or not), we’re now a part of the problem

**Hospital code of conduct**:

- Hospital executives are very understanding when you present them with examples of egregious bills harming people’s lives, says Marty

\*Marty’s students have created a [Hospital Code of Ethics](https://www.restoringmedicine.org/code-of-ethics) on restoringmedicine.org

- Provide one honest, transparent bill that’s not jacked up for discounts.
- Never sue a patient that’s low income and came in for basic medical care.
- When billing a patient directly, use the medicare allowable amounts

**How everyday folks can help**:

Get involved in your local hospital and ask them questions:

- How do you manage patients who can’t pay if their deductible is high and they get a bill or they’re uninsured?
- How do you bill?
- What’s your average markup? Is it 1.5 is it 2.5 is it 23 (like Marty found in some of our research)
- What is your average markup defined as?
- How much do you charge above the Medicare allowable amount?

*Basic steps to affecting change in your city*:

1. Reach out to your local courthouse
2. Find out if they’re suing the socks off of the town (like we’ve seen in [20% of hospitals in the state of Virginia](https://www.globalresearch.ca/prevalence-characteristics-virginia-hospitals-suing-patients-garnishing-wages-unpaid-medical-bills/5682089))
3. Then reach out to your hospital board members and ask them, engage them on the subject

**Other good news**:

- [President Trump](https://en.wikipedia.org/wiki/Donald_Trump) and the Trump administration ([Seema Verma](https://en.wikipedia.org/wiki/Seema_Verma), [Alex Azar](https://en.wikipedia.org/wiki/Alex_Azar), [Kellyanne Conway](https://en.wikipedia.org/wiki/Kellyanne_Conway)) helped push through an [executive order on price transparency in health care](https://www.npr.org/sections/health-shots/2019/06/24/735432387/trump-administration-pushes-to-make-health-care-pricing-more-transparent) that aims to lower rising health care costs by showing prices to patients (starting Jan 1, 2020)
- The American people are prioritizing this problem as the number one problem in America (probably the number one issue in the election)

## Helpful resources [2:46:15]

- [Health Rosetta](https://healthrosetta.org/)
  - Place to find an independent versus a kickback broker
  - Started by Dave Chase to create a brand of sort of the free trade brokers that have agreed to a basic code of conduct and transparency
- [Restoring Medicine](https://www.restoringmedicine.org/)
  - Started by Marty’s students
  - Can point people in the direction of all of the things Marty is discussing
- [MartyMD.com](https://www.martymd.com/)
  - provide some resources for folks that are interested in learning more about this
- [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=sr_1_1?keywords=the+price+we+pay&qid=1557713767&s=books&sr=1-1)
  - Marty’s book being released in September 2019

![](https://peterattiamd.com/wp-content/uploads/2019/08/Screen-Shot-2019-08-16-at-9.28.21-AM-1024x693.png)

**Figure 2. Comparing the cost of hospital services compared to other common societal goods.** Image credit: [restoringmedicine.org](https://www.restoringmedicine.org/)

§

## Selected Links / Related Material

**Marty is the Surgical Director of this program:** [Islet Transplant Center at John Hopkins](https://www.hopkinsmedicine.org/transplant/programs/auto_islet/index.html) | (hopkinsmedicine.org) [4:00]

**Working with** [**Peter Pronovost**](https://en.wikipedia.org/wiki/Peter_Pronovost)**, Marty published this surgical checklist which is now used around the country**: [The Surgical Checklist](https://www.ncbi.nlm.nih.gov/pubmed/16776390) (Makary et al., 2006) [4:50, 26:15, 33:00]

**Marty’s books**:

- [Unaccountable: What Hospitals Won’t Tell You and How Transparency Can Revolutionize Health Care](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198383) (amazon.com) [5:20, 10:20,
- [The Price We Pay: What Broke American Health Care–and How to Fix It](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110) (amazon.com) [5:30, 47:00, 1:07:30, 1:14:45, 2:13:00, 2:43:15

**Television show on Fox based on Marty’s work**: [The Resident (TV Series)](https://en.wikipedia.org/wiki/The_Resident_(TV_series)) | (wikipedia.org) [5:30, 10:30, 23:45]

**Where Marty did his residency**: [District of Columbia General Hospital](https://en.wikipedia.org/wiki/District_of_Columbia_General_Hospital) | (wikipedia.org) [12:00]

**Healthcare is the number one industry in the US**: [Health Care Just Became the U.S.’s Largest Employer](https://www.theatlantic.com/business/archive/2018/01/health-care-america-jobs/550079/) | Derek Thompson (theatlantic.com) [22:45]

**The book that Peter Provonost gave Peter Attia that helped him with his decision to leave medicine**: [The Hero with a Thousand Faces](https://www.amazon.com/Thousand-Faces-Collected-Joseph-Campbell/dp/1577315936) by Joseph Campbell (amazon.com) [27:00]

**Patients sue doctors when things go bad because of a lack of honesty and transparency**: [To Be Sued Less, Doctors Should Consider Talking to Patients More](https://www.nytimes.com/2015/06/02/upshot/to-be-sued-less-doctors-should-talk-to-patients-more.html) | Aaron E. Carroll (nytimes.com) [39:15]

**Studies show that the lack of honest communication is the bigger driver rather of lawsuits than the actual events**: [40:45]

- [Apologies and Medical Error](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2628492/) (Jennifer K. Robbennolt, 2009)
- [Communication gaffes: a root cause of malpractice claims](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1201002/) (Huntington et al., 2003)

**Movies that depicted the internalization of trauma (and possibly PTSD) seen on the battlefield and this inability to react to things that now seem petty**: [43:15]

- [Hurt Locker](https://en.wikipedia.org/wiki/The_Hurt_Locker)
- [American Sniper](https://en.wikipedia.org/wiki/American_Sniper)

**Organization started by Marty’s students to advocate for more honest and fair pricing**: [Restoring Medicine](https://www.restoringmedicine.org/) | (restoringmedicine.org) [46:40, 1:51:45, 2:41:00]

**Peter’s discussion with Ted Schaeffer where they talked about “Sunday School” with John Cameron (*****starting at 44:15*****)**: [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) | Peter Attia (peterattiamd.com) [51:00]

**Sunday School with Dr. John Camerson**: [Sunday School](https://www.surgjournal.com/article/S0039-6060(00)87250-5/fulltext) (Michael G. Sarr, 2000) [51:00]

**Physiological nervous system response to increased intracranial pressure named after Harvey Cushing**: [Cushing reflex](https://en.wikipedia.org/wiki/Cushing_reflex) | (wikipedia.org) [53:15]

**A device that revolutionized surgery which cuts and simultaneously cauterizes invented in part by Harvey Cushing**: [“Bovie”](https://en.wikipedia.org/wiki/Electrosurgery) | (wikipedia.org) [53:30]

**Video by Zubin Damania about physician burnout being more about “moral injury”**:: [It’s Not Burnout, It’s Moral Injury | AMA 15](https://www.youtube.com/watch?v=L_1PNZdHq6Q) | ZDoggMD (youtube.com)  [1:01:15]

**Medical school that is innovating their education to include empathy and compassion**: [Sidney Kimmel Medical College](https://www.jefferson.edu/university/skmc.html) | (jefferson.edu) [1:07:30]

**Capitated primary care clinics that Marty highly recommends**: [1:16:00]

- *There’s an exciting one in Florida called*: [ChenMed](https://www.chenmed.com/)
- *Smaller clinics that Marty is a “big fan of”*:
  - [Oak Street Health](https://www.oakstreethealth.com/)
  - [Iora Health](https://www.iorahealth.com/)
  - [Magenta Health](https://magenta-health.com/)

**Massive scale capitation care clinic that Peter mentions**: [Kaiser Permanente](https://healthy.kaiserpermanente.org/) (kaiserpermanente.org) [1:17:15]

**The book/movie called The Big Short that reveals the mortgage industry crisis which Marty compares to his book Price We Pay but for the healthcare industry**: [1:21:50, 1:51:15]

- *Book*: [The Big Short: Inside the Doomsday Machine](https://www.amazon.com/Big-Short-Inside-Doomsday-Machine/dp/0393338827) by Michael Lewis | (amazon.com)
- *Movie*: [The Big Short (film)](https://en.wikipedia.org/wiki/The_Big_Short_(film)) | (wikipedia.org)

**Recommendation for where to get prescription medication**: [1:28:00]

- Website: [GoodRx](https://www.goodrx.com/)
- Mobile app: [GoodRx app](https://www.goodrx.com/mobile)

**Case where an insurance executive got charged $70,000 for a hip replacement**: [Why Your Health Insurer Doesn’t Care About Your Big Bills](https://www.npr.org/sections/health-shots/2018/05/25/613685732/why-your-health-insurer-doesnt-care-about-your-big-bills) | Marshall Allen (npr.org) [1:29:45]

**Reports showing healthcare costs are not almost 18% of GDP**: [National Health Expenditure Data](https://www.cms.gov/Research-Statistics-Data-and-Systems/Statistics-Trends-and-Reports/NationalHealthExpendData/index.html) | (cms.gov) [1:33:00]

**One in five Americans has medical debt in collections**: [New Kaiser/New York Times Survey Finds One in Five Working-Age Americans With Health Insurance Report Problems Paying Medical Bills](https://www.norc.org/NewsEventsPublications/PressReleases/Pages/new-kaisernew-york-times-survey-finds-one-in-five-working-age-americans-with-health-insurance-report-problems-paying.aspx) | (norc.org) [1:34:00]

**NPR story about Virginia courts suing it’s patients**: [When Hospitals Sue For Unpaid Bills, It Can Be ‘Ruinous’ For Patients](https://npr.org/sections/health-shots/2019/06/25/735385283/hospitals-earn-little-from-suing-for-unpaid-bills-for-patients-it-can-be-ruinous) | Selena Simmons-Duffin (npr.org) [1:34:15]

**Virginia hospitals suing people and garnishing their wages**: [Prevalence and Characteristics of Virginia Hospitals Suing Patients and Garnishing Wages for Unpaid Medical Bills](https://www.globalresearch.ca/prevalence-characteristics-virginia-hospitals-suing-patients-garnishing-wages-unpaid-medical-bills/5682089) (Bruhn et al., 2019) [1:34:15, 2:42:15]

**GM just signed a big contract with Henry Ford Health System, a direct employer contract**: [Henry Ford Health System Launches “Direct to Employer” Healthcare Contract with General Motors](https://www.henryford.com/news/2018/08/direct-to-employer-announcement) | (henryford.com) [1:42:30]

**The law that requires hospitals to care for anyone with an urgent condition**: [EMTALA](https://en.wikipedia.org/wiki/Emergency_Medical_Treatment_and_Active_Labor_Act) | (wikipedia.org) [1:55:00]

**Marty’s study showing that price transparency medical centers do very well from a business perspective**:  [The Impact of Price Transparency for Surgical Services.](https://www.ncbi.nlm.nih.gov/pubmed/29712614) (Mehta et al., 2018) [2:07:45]

**Half of women with stage four breast cancer in the United States are being harassed by medical debt collectors**: [Breast Cancer Wariness: Half Pursued by Debt Collectors](https://www.medscape.com/viewarticle/903202) | Nick Mulcahy (medscape.com) [2:11:15]

**21% of treatment is unnecessary according to over 2,000 doctors in Marty’s survey**: [Overtreatment in the United States.](https://www.ncbi.nlm.nih.gov/pubmed/28877170) (Lyu et al., 2017) [2:16:30, 2:28:00]

**A really exciting and “unbelievable” cancer immunotherapy drug**: [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab) | (wikipedia.org) [2:30:15]

**1987 law that was passed to give PBMs and GPOs exclusivity so the Sherman Antitrust Act does not apply to this supply chain**: [Safe harbor (law)](https://en.wikipedia.org/wiki/Safe_harbor_(law)) | (wikipedia.org) [2:33:45]

**President Trump signed an executive order on price transparency in health care**: [Trump Administration Pushes To Make Health Care Pricing More Transparent](https://www.npr.org/sections/health-shots/2019/06/24/735432387/trump-administration-pushes-to-make-health-care-pricing-more-transparent) | TAMARA KEITH and SELENA SIMMONS-DUFFIN (npr.org) [2:41:45]

**LA Times reporter, Noam Levey writes about Americans are making different choices at the supermarket, cutting their vacations, FICA scores are getting destroyed, etc. because of inflated medical bills**: [Health insurance deductibles soar, leaving Americans with unaffordable bills](https://www.latimes.com/politics/la-na-pol-health-insurance-medical-bills-20190502-story.html) | Noam Levey (latimes.com) [2:45:00]

**Most helpful resources**: [2:46:15]

- Find an independent insurance broker here: [Health Rosetta](https://healthrosetta.org/)
- *Site started by Marty’s students*: [Restoring Medicine](https://www.restoringmedicine.org/)
- *Marty’s website with more resources*: [MartyMD.com](https://www.martymd.com/)

§

## People Mentioned

- [Jorge Salazar](https://med.uth.edu/pediatricsurgery/faculty/jorge-d-salazar-md/) (mutual friend from med school) [9:30]
- [Ted Schaeffer](https://dr-schaeffer.com/) (Sunday School, former guest on The Drive) [9:30, 51:00]
- [Lucian Leape](https://www.hsph.harvard.edu/news/features/lucian-leape-patient-safety-champion-honored-at-retirement-symposium/) (patient safety) [11:00]
- [David Bates](https://en.wikipedia.org/wiki/David_W._Bates) (patient safety) [11:00]
- [John Cameron](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0001321/john-cameron) (legendary surgeon at Johns Hopkins) [13:45, 45:00, 48:00]
- [Steve Rosenberg](https://ccr.cancer.gov/Surgery-Branch/steven-a-rosenberg) [13:45]
- [Charlie Yeo](https://hospitals.jefferson.edu/find-a-doctor/y/yeo-charles-j.html) (person Peter admired at Hopkins) [16:15, 49:00]
- [Keith Lillemoe](https://www.massgeneral.org/doctors/doctor.aspx?id=18955#) (person Peter admired at Hopkins) [16:15]
- [William Stewart Halsted](https://en.wikipedia.org/wiki/William_Stewart_Halsted) creates this program in the late 1800s [16:30]
- [Adel Makary](https://www.vitals.com/doctors/Dr_Adel_Makary.html) (hematologist, Marty’s father) [19:30, 2:37:45]
- Janet Romanelli (wonderful person to work with at Hopkins, Peter’s mother-in-law) [24:00]
- [Peter Pronovost](https://en.wikipedia.org/wiki/Peter_Pronovost) (helped Marty deeleop the surgery checklist) [26:15]
- [Joseph Campbell](https://en.wikipedia.org/wiki/Joseph_Campbell) (wrote book that helped Peter) [27:00]
- [William Osler](https://en.wikipedia.org/wiki/William_Osler) (one of the four founding professors of Johns Hopkins Hospital) [53:00, 2:22:00]
- [Harvey Cushing](https://en.wikipedia.org/wiki/Harvey_Cushing) (created neurosurgery) [53:00]
- [Ben Carson](https://en.wikipedia.org/wiki/Ben_Carson) (NOT the inventor of neurosurgery)[54:15]
- [Zubin “Zdogg” Damania](https://zdoggmd.com/about-z/) (it’s “Moral Injury” not “physician burnout”) [27:15]
- [Chris Sonnenday](https://www.uofmhealth.org/profile/1426/christopher-john-sonnenday-md) (exception of someone who maintained his humanity, now running the transplant program at the University of Michigan) [1:10:15]
- [Sarah Kliff](https://twitter.com/sarahkliff?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (reporter who publishes cases of predatory pricing)  [2:03:30]
- [Elisabeth Rosenthal](https://twitter.com/rosenthalhealth?lang=en) (Kaiser Health News, reporter who publishes cases of predatory pricing) [2:03:30]
- [Keith Smith](https://surgerycenterok.com/specialist/keith-smith-m-d/) (a doctor in OKC, is [disrupting healthcare in Oklahoma](https://www.theconservativepundit.net/meet-the-pundits/g-keith-smith-md/)) [2:05:45, 2:39:15]
- [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) [2:07:30]
- [Scott Gottlieb](https://en.wikipedia.org/wiki/Scott_Gottlieb) (head of the FDA) [2:30:45]
- Jill Attia (one of the best nurses at Hopkins per Marty, Peter’s wife) [2:32:00]
- [Albert Sabin](https://en.wikipedia.org/wiki/Albert_Sabin) (invented the polio vaccine) [2:36:20]
- [Benjamin Rush](https://en.wikipedia.org/wiki/Benjamin_Rush) (one of the five physician signers of the Declaration of Independence, treated shunned patients with schizophrenia who were impoverished) [2:37:00]
- [President John Adams](https://en.wikipedia.org/wiki/John_Adams) [2:37:40]
- [Benjamin Franklin](https://en.wikipedia.org/wiki/Benjamin_Franklin) [2:37:40]
- [President Trump](https://en.wikipedia.org/wiki/Donald_Trump) (signed [executive order on price transparency in health care](https://www.npr.org/sections/health-shots/2019/06/24/735432387/trump-administration-pushes-to-make-health-care-pricing-more-transparent))
- [Seema Verma](https://en.wikipedia.org/wiki/Seema_Verma) (Trump administration, helped push through executive order on price transparency in health care) [2:41:45]
- [Alex Azar](https://en.wikipedia.org/wiki/Alex_Azar) (Trump administration, helped push through executive order on price transparency in health care) [2:41:45]
- [Kellyanne Conway](https://en.wikipedia.org/wiki/Kellyanne_Conway) (Trump administration, helped push through executive order on price transparency in health care) [2:41:45]
- [Noam Levey](https://twitter.com/NoamLevey?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (LA Times reporter who wrote about inflated medical bills ruining the lives of American families) [2:45:00]
- [Dave Chase](https://healthrosetta.org/people/dave-chase/) (Health Rosetta) [2:46:15]

§

![](https://peterattiamd.com/wp-content/uploads/2019/08/Makary_doctor-coat-500x500.jpg)

##### Martin Makary M.D., M.P.H.

*New York Times* bestselling author

Johns Hopkins surgeon and Professor of Health Policy

[Dr. Makary](https://en.wikipedia.org/wiki/Marty_Makary) is the NYT bestselling author of [*The Price We Pay*](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=sr_1_1?keywords=the+price+we+pay&qid=1557713767&s=books&sr=1-1), a new book that breaks down the high cost of health care and shows how people can get a better deal on their health care. The book has been described as “a must-read for every American and business leader” by Steve Forbes and a “deep dive into the real issues driving up the price of health care” by Dr. Don Berwick. Makary is a frequent medical commentator on NBC and FOX News and a leading voice for physicians, writing for the *Wall Street Journal* and *USA Today*.

Dr. Makary has been elected to the National Academy of Medicine and named one of America’s 20 most influential people in health care by *Health Leaders* magazine. His current research focuses on the appropriateness of medical care, drug prices, and the impact of the health care cost crisis on low-income populations. Dr. Makary was the lead author the Surgical Checklist and later served in leadership with Atul Gawande on the World Health Organization Surgery Checklist project. Makary has published more than 250 scientific articles, including articles on health care transparency, vulnerable populations, and guidelines for prescribing opioids. As a gastrointestinal surgeon, he is also an advocate for healthy food and lifestyle medicine.

His last book, *Unaccountable*, was adapted for television into the hit medical series *The Resident*. His newest book, The Price We Pay, tells the stories of health care’s disruptive innovators and the new movement to restore medicine to its mission.