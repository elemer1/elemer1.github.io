# #29 – Apolo Anton Ohno: 8-time Olympic medalist – extreme training, discipline, pursuing perfection, and responding to adversity

**Source:** [https://peterattiamd.com/apoloohno/](https://peterattiamd.com/apoloohno/)

---

In this episode, 8-time Olympic medalist, Apolo Ohno, discusses the lessons he’s learned from his remarkable career in speed skating and the extreme physical and mental training — and determination — required to reach greatness.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/apoloohno/the_Drive_public.png)

Play

#29 - Apolo Anton Ohno: 8-time Olympic medalist – extreme training, discipline, pursuing perfection, and responding to adversity

#29 - Apolo Anton Ohno: 8-time Olympic medalist – extreme training, discipline, pursuing perfection, and responding to adversity

1x15s30s

0:003:38:09

## We discuss:

- Apolo’s childhood with his single dad, early success in sports, and falling in love with skating [7:30];
- The differences between inline and ice skating, and short- & long-track speed-skating, and the evolution of the clap skate [21:00];
- The mental game and the physical game: intense training and mindset [29:30];
- Apolo’s early success in short-track that led to an amazing opportunity and his reluctance to go for it [40:15];
- Early days at Lake Placid, first experience on the world stage, and a little self-sabotage [56:45];
- Tough love parenting, making a commitment, training like Rocky, and developing the mindset of a fighter [1:17:30];
- 2002 Olympics, winning his first medal, and rising above the sport [1:32:45];
- Apolo’s evolving training and body composition throughout his Olympic career [2:05:15];
- Going into the Lion’s Den to learn from Korean skaters and making a radical and risky change that led to his most successful Olympic games [2:12:45];
- Apolo’s tumultuous relationship with South Korea, from hatred to respect to admiration [2:29:00];
- Applying lessons learned through training, adjusting to life after skating, and the struggles many athletes face transitioning to retirement [2:46:30];
- The final years of Apolo’s career: intense focus, crazy training, mental fortitude, and resiliency [2:57:30];
- Officially retiring and contemplating a comeback [3:16:15];
- Where does Apolo want to be in 10 years? [3:22:45];
- The pursuit of perfection and flow states [3:29:30];
- Where you can follow Apolo [3:35:00]; and
- More.

§

## Show Notes

## Apolo’s childhood with his single dad, early success in sports, and falling in love with skating [7:30]

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-7.jpeg)

**Figure 1. Apolo with his father showing off his 8 medals**. Image credit: [Freedom of Excess](https://freedom-of-excess.blogspot.com/2013/06/to-dads.html)

- His father was born in Japan, came to US at age 17, spoke zero English
- He has never met his mother, parents split up right after when he was born
- Apolo’s own genealogy is a bit of a mystery
- Dad drilled into him that you can always work hard and get better, no matter how good you are you should strive for perfection
- Apolo starting swimming at age 8 and broke a state record in the 50 m backstroke at age 12
- Started training in speed skating at 14
- Fell in love with speed skating and decided that is what he wanted to do after seeing a live competition in Vancouver:
- “This is the most incredible sport ever seen in my life. It doesn’t make sense how these human beings can be leaning over these impossible angles on a blade that’s one millimeter thick and they’re wearing outfits that resemble Superman without the cape.”
- Peter has noticed a common thread amongst professional in that they enjoy the process of mastery and the practice that comes with it
- Did Apolo enjoy practice? Not early on (age 14-17), but eventually did

## The differences between inline and ice skating, and short- & long-track speed-skating, and the evolution of the clap skate [21:00]

- Inline skating is on wheels (rollerblades), predominately outdoor but some indoor tracks now
- Ice skating is, of course, on ice in a skating on a 17-18 inch blade

Short track vs long track

- [Short track](https://en.wikipedia.org/wiki/Short_track_speed_skating), more recently invented, is a form of speed skating in which multiple skaters (4-6) skate around an oval track of 111.12 meters where the skaters are passing and battling
- [Long track](https://en.wikipedia.org/wiki/Long_track_speed_skating) has been around much longer, skate around a 400 meter oval and it’s you against the clock, in your own lane

Evolution of the ice skate

- [Clap skates](https://en.wikipedia.org/wiki/Clap_skate) started to make it into the sport 1995-97
- Evolved into a clap skate “so you get like a five to 15 percent additional advantage every single time you push”
- Totally different technique in how you skate and when the clap skate came out, many competitors fell out of the sport because they weren’t able to make the adjustment

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-30.png)

**Figure 2. The clap skat****e**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Clap_skate)

Note: speed skaters no longer use the clap skate, back to a traditional non-hinging blade

## The mental game and the physical game: intense training and mindset [29:30]

[Eric Heiden](https://en.wikipedia.org/wiki/Eric_Heiden)

- US long-track skater who won an unprecedented 5 gold medals in the 1980 Olympics in each of the long skate events
- He is an example of an extreme athlete with his training and mindset
- Unique ability to tolerate pain, threshold and lactate acid
- Used to train like Rocky

Heiden also became a pro cycler

- Peter says Heiden actually has the time record up a famous hill in the Bay Area called [Old La Honda](https://graphics.stanford.edu/~lucasp/grade/oldlahonda.html) that Peter used to ride during med school
- Here’s a [quick video of Heiden riding Old La Honda](https://www.youtube.com/watch?v=0Oj8k_YHcYg)
- Here’s a [forum discussion](https://weightweenies.starbike.com/forum/viewtopic.php?t=112799) of Eric’s record

The mental game

- Apolo always loved the mental game and tried to implement that into his training
- Looked up to [Lance Armstrong](https://twitter.com/lancearmstrong?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) and Eric Heiden and tried to emulate their mental approach
- “Lance [was] superhuman, not only for [his] accomplishments but the way that [he] mentally attacked pain and training because that’s where you win your actual wars, in the training, and that’s when you get to the competition.”

Intense physical training

- Not uncommon for a group of 100 athletes in a training program to start out and then get whittled down to 12 after the other 88 were broken or simply unable to keep up due to genetics
- Apolo says he would skate for 4-6 hours daily
- And then follow that up with some crazy, risky training like lateral one-leg jumps up stairs
- Check out this TIME video showcasing some of Apolo’s crazy training: [How They Train: Speed Skating | TIME](https://www.youtube.com/watch?v=xdKiY92WE40)

> “I loved to do stuff that people thought was completely obscene and crazy. And for me I would say 80 percent of my career all my races were won before I got to the start line. The other competitors were racing for second [because] they just they just knew that I was like just completely off my rocker. I was not in the same headspace as them.”

## Apolo’s early success in short-track that led to an amazing opportunity and his reluctance to go for it [40:15]

Emergence of short-track speed skating

- Speed skating was a demonstration sport in the [1988 Calgary Winter Olympics](https://en.wikipedia.org/wiki/1988_Winter_Olympics)
- 1992 was the first Olympics to have it officially as an Olympic sport
- US not a big player, no real funding for athletes
- Short track differs quite drastically from long track
  - Long track is a 400 meter loop with a max of 2 skaters staying in their own lanes and racing against the clock
  - Short track includes 5-8 racers competing in a group on an oval ice track with a length of 111.12 meters (364.6 ft), the rink itself is the same size as an Olympic-sized figure skating rink and an international-sized ice hockey rink

A very technical sport

- Skaters have all the control over their equipment
- If equipment (skates and blades specifically) are not completely dialed in you are at a severe disadvantage, very technical
- Blades are offset to the left side (because you’re always going left and always leaning left in the turns)
- Not actually digging in the ice, mostly gliding on the water on top of ice

Apolo emerges as a very talented youngster

- From 12-14 was winning all the races “west of Toronto”
- Knew he didn’t want to be a swimmer anymore
- Eventually was recruited by a [junior development program in Lake Placid, NY](https://www.teamusa.org/about-the-usoc/olympic-training-centers/lpotc/about) (Home of the [1980 Winter games](https://en.wikipedia.org/wiki/1980_Winter_Olympics) where Heiden won 5 gold medals, and the [Miracle on Ice](https://www.youtube.com/watch?v=qYscemhnf88) occurred)
- The program means you move to NY, go to school there, and train, supposed to be at least 15 but asked him to come early at 14
- He lived in Seattle at the time (summer of 1996)
- Apolo didn’t want to go, just a naive kid who wanted to hang out with his friends and didn’t realize the opportunity in front of him
- Apolo’s father thought that this singular-focus sport could really help Apolo, a mischievous kid, put his high energy and tendency to get into trouble to good use

Apolo’s brief run-away from home

- Dad drops Apolo off at airport for his flight to Lake Placid
- Instead of boarding the flight, Apolo calls a friend to come pick him up and he proceeds to live with friends for the next 11 days
- Program calls Apolo’s dad and says where is your son?
- Dad finds Apolo and this time flies with him to Lake Placid and hand-delivers him to Coach [Patrick Wentland](https://www.teamusa.org/US-Speedskating/About/Hall-of-Fame-Content/Skaters/Patrick-Wentland)

## Early days at Lake Placid, first experience on the world stage, and a little self-sabotage [56:45]

Early days at Lake Placid

- Hated it at first, awkward, didn’t fit in, athletes from all over the country
- Only training he’d done before was with his dad who used to wake him early mornings to skate and used this approach to instill mental strength
- Apolo, whose nickname was Chunky as a kid, had the highest body comp of the group in Lake Placid and this embarrassed him
- He barely missed the cut to make the junior team (got 3rd place) which ticked him off as this was the first team he has ever not made in his life
- It was a moment when he began to realize the limits of his natural talent, “That was a time where if I wanted to make significant changes I had to really concentrate both technically and also on the physiology of training to be a short track athlete.”

Preparing for his first experience on the world stage

- In preparation for the 1997 World Team trials to make the 1997 World Team, Apolo began putting in extra work in the weight room
- He saw massive gains with relatively little effort and ended up winning the trials and qualifying for the World Team
- At age 14, he was competing against grown men, placed 19th at the 1997 [Speed Skating World Cup](https://en.wikipedia.org/wiki/ISU_Short_Track_Speed_Skating_World_Cup), and after witnessing the style and attitudes of the foreign teams (Korea, China) came away with the impression that the US was way behind the times in terms of the training and skating strategy

Self-sabotage

- With the approaching Olympic trials, Apolo fell back into old habits in Seattle, stopped training, ate crappy food, and lost interest in putting in the effort
- Apolo still doesn’t fully understand why but theorizes that it has something to do with how easy things were for him with all his talent that he was looking for the minimum amount of work he could put in and still achieve success
- Young, immature, and naive about how far talent could take you, “There’s a thousand guys in line who have half the talent that would do ten times more work just to be a fraction of what you could possibly become.”

Olympic Trials in 1997 to make the 1998 Olympics

- Apolo was just “going through the motions” in his training
- Barely made the cut for a chance just to *compete* in the Olympic trials
- At the Olympic Trials, he didn’t get anywhere close to qualifying for the Olympics
- Had a defeated and defiant attitude

## Tough love parenting, making a commitment, training like Rocky, and developing the mindset of a fighter [1:17:30]

A cabin on the beach

- Seeing a pivotal moment approaching, Apolo’s father literally dropped Apolo off at a cabin on [Moclips Beach](https://en.wikipedia.org/wiki/Moclips,_Washington) ([Iron Springs Resort](https://ironspringsresort.com/)) all by himself (at age 15!) and told him he couldn’t leave until he decided what he wanted to do
- After about nine days of contemplation and soul searching, Apolo made the decision to commit to speed skating

Training and tasting victory

- Over the next few months he trained in solitude in his father’s basement, didn’t talk to anyone, just trained and studied
- When he got back to the [training center in Colorado Springs](https://www.teamusa.org/about-the-usoc/olympic-training-centers/csotc/about), he was by far the best skater in the national team program
- In 1998, won a gold medal in the 1,000 meter at the Speed Skating World Cup against reigning Olympic champ [Kim Dong-sung](https://en.wikipedia.org/wiki/Kim_Dong-sung) and also great talent, [Fabio Carta](https://en.wikipedia.org/wiki/Fabio_Carta) (this event has very little meaning especially when it falls in the same year as a Winter Olympics)
- “I came out of nowhere and that became my first taste of winning on the world circuit”

The mental component of sports

> “The mental component of the sport was always to me the most fascinating and the most underutilized in every aspect.”

- Early on he started working with a young sport psychologist ([David Creswell](https://www.cmu.edu/dietrich/psychology/people/core-training-faculty/creswell-david.html)) and together they worked on
  - Meditation and breathing exercises
  - Positive self-talk
  - Manifesting what you want through visualization
- Apolo looked up to boxers and was a fan of the Rocky mentality
- He would train until he puked for no other reason than to try to develop the mental toughness and fortitude

> “I thought that was the only way that I could beat the Koreans. . .I didn’t skate as beautifully as they did.”

## 2002 Olympics, winning his first medal, and rising above the sport [1:32:45]

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-31.png)

**Figure 3. Apolo on SI cover prior to the 2002 Winter Olympics.** Image credit: [sicovers.com](https://www.sicovers.com/content/images/thumbs/0002287_the-2002-winter-olympics-apolo-anton-ohno.jpeg)

Was Apolo nervous for the [2002 Olympics](https://en.wikipedia.org/wiki/2002_Winter_Olympics)? “Not at all. I was ready.”

- He held the best time trial of ~1:23:45 in the 1000 meter, nobody else breaking 1:25:00
- Similar to Lance Armstrong, Apolo had low lactate levels which can be an advantage

Lactate test Apolo would perform:

- 6 sets of 1000 meter sprints, 2 min rest in between sets
- Prick you each time to generate your lactate performance curve
- Maintained his lap time and speed, lactate stayed steady and low (says around 9, and others were at 20)

Story about his first Olympic medal (and a must-watch [satire video](https://www.youtube.com/watch?v=5fFnSRKUBFU))

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-32.png)

**Figure 4. Final lap in 1000 meter short track at the 2002 Winter Olympics where Apolo wins Silver for his first Olympic medal**. Image Credit: [The Salt Lake Tribune](https://archive.sltrib.com/article.php?id=53415448&itype=CMSID)

- [1000 meter short track race at the 2002 Olympic games in Salt Lake City](https://en.wikipedia.org/wiki/Short_track_speed_skating_at_the_2002_Winter_Olympics_%E2%80%93_Men%27s_1000_metres)
- Apolo was the favorite but there were 3 other competitors who would be a big challenge to him, 1) [Mathieu Turcotte](https://en.wikipedia.org/wiki/Mathieu_Turcotte) from Canada 2) [Li Jiajun](https://en.wikipedia.org/wiki/Li_Jiajun) from China 3) [Ahn Hyun-soo](https://en.wikipedia.org/wiki/Viktor_An) (Harry Potter looking Korean skater)
- And then there was [Steven Bradbury](https://en.wikipedia.org/wiki/Steven_Bradbury) from Australia who was only in the race due to disqualifications
- Apolo had the lead during the final lap
- But on the last turn there was a big crash that took down everyone but Bradbury, who skated from half a lap behind to win the first gold medal in the history of Olympic games for Australia
- Apolo scrambled across the finish line to win Silver
- *Rocky metaphor*: Peter compares Apolo’s scramble to the finish line to win to when [Rocky Balboa and Apollo Creed both knock each other down](https://youtu.be/Ctl9I6O5OkI?t=400) and Rocky is the only one to get up

**Must-see, hilarious video of the race: [Ozzy Man Reviews: Greatest Olympic Win Ever](https://www.youtube.com/watch?v=5fFnSRKUBFU)**

How the rest of the 2002 games went for Apolo

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-33.png)

**Figure 5. Apolo wins the first Olympic gold medal in US history in speed skating in 2002**. Image Credit: [Team USA (YouTube)](https://www.youtube.com/watch?v=1Z-obyjzj5g)

- Apolo wins his first Gold medal: [Won a gold in the 1500 meters](https://www.youtube.com/watch?v=1Z-obyjzj5g), but only due to a controversial disqualification for blocking by South Korean [Kim Dong-sung](https://en.wikipedia.org/wiki/Kim_Dong-sung) (launching a fascinating and tumultuous relationship between Apolo and South Korea, more about this at 2:28:30)
- Another crash in the relay prevented him from another probable gold medal
- “But short track to me is very much like life very much like life right. You can do everything right and for whatever reason something out of your control gets thrown your way and you have to take it as such and learn from it and come back stronger and better.”

Rising above the sport

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-41.png)

**Figure 6. Apolo Ohno Wheaties Box**. Image credit: [aloha\_pineapple | Flickr](https://www.flickr.com/photos/aloha_pineapple/119030574/)

- As is rarely the case, Apolo says less than 1%, he was a featured athlete which allowed him to earn a living through commercials and media tours
- Most medal-winning athletes have to get “regular jobs” while training in between Olympic games
- What made Apolo appealing?
- Peter and Apolo theorize that his story was just interesting and inspiring in a way
- Americans love to win, but they love a story of overcoming hardship even more, and the way Apolo finished that first race for silver was a perfect fit to his fascinating life story

> “Obviously I want to win. I want to bring home bring home the color gold because that is what we signify with being successful. But at the end the day, I wanted the representation of who I was on the ice at that period of time to reflect what we would be proud of. And that would make my father proud. And I knew if I had that happen that I could be proud and that our country would be proud.”

## Apolo’s evolving training and body composition throughout his Olympic career [2:05:15]

You would expect an athlete going from age 19 to 23 to 27 would put on muscle and gain weight, but Apolo actually continually got leaner and leaner (while maintaining strength)

2002

- Training was about power, ballistics, strength, and speed
- 165 lbs
- Exceptional ability was to recover quickly
- Leg press 1,500 lbs
- 350 for 12 reps (max of about 500)
- Vertical was 36 inches
- Peter says “I’m convinced by the way the single leg vertical is probably the best predictor of speed.”

2006

- 155 lbs
- Could still leg press the same weight
- Significantly leaner
- 2006 games he won a gold in the 500 meter and a bronze in the relay

2010

- 143 lbs
- Leg press nearly 2,000 lbs
- Less ballistic power
- Stopped doing Olympic lifts
- Did a lot of weighted plyometrics
- Spent much of the time purposefully atrophying his upper body

> “In speed skating there’s seven parts to one push . . . that you have to drill and you had to make it automatic and normal. And you’re never on just one plane of balance on that piece of blade. You’re on the heel, now you’re in the middle, now you are back towards a heel and then you finish on the ball or towards the toe. And it’s different depending on the speed . . . and the track pattern. There’s so many elements that are always changing.”

## Going into the Lion’s Den to learn from Korean skaters and making a radical and risky change that led to his most successful Olympic games [2:12:45]

In 2007, Apolo realized that to stay competitive he had to go into the “Lion’s Den” (as his father put it) and train with the best skaters in the world, the South Koreans

**Check out this great [NBC segment](https://www.nbcsports.com/video/inside-lions-den-south-korea-apolo-ohno) where Apolo describes how this time in South Korea changed his life**

Apolo lived and trained in South Korea in 2007, during his time there he was struck by the following characteristics of the skaters:

- Commitment to perfection in their technique and preparation
- Efficiency in which they move on the ice which made their physical strength less important
- Uniformity of the team who all seemed to skate the same

How they had so many great athletes

- Giant pool of skaters
- Extreme discipline from a young age
- Bodies seemed to be genetically built for speed skating

Apolo realized he needed to make big changes to stay competitive

> “If I take the same strategy of success from 2006 into 2010, I won’t make the semi-final.”

- His dominance in the sport was waning
- South Koreans were getting better and better
- The sport was evolving and he needs to evolve with it
- *“What was important during training the elements that made you a fast speed skater all changed. . .My goal was to show up as a different type of an athlete that they would never prepare for. I want to change my natural gait and rhythm.”*

*Rocky metaphor*: Peter compares how Apolo totally changed his approach leading up to his final Olympics to how Rocky prepared for his [rematch with Clubber Lang](https://www.youtube.com/watch?v=o4VyvcySBuE)

Changing his training and preparation from 2007-2010

- Hired a live-in strength and conditioning coach
- Became obsessively focused with losing weight, especially upper body weight/muscle that wasn’t necessary to have
- It was a struggle, loved food, and not much weight to lose
- Need to get lighter and faster so he worked on his gait: wanted to go from power and slow to quick and nimble and had to retrain his gait to a quicker cadence
- Had sticky notes around his house constantly reminding him of his goal
- He was constantly questioning his decision => he was doing the opposite of what he did in the past which made him successful
- Results were not good at first, other skaters were doing better than him, and the chatter was that he was sticking around for one too many Olympics, but in the end it worked out

> “I was driven a lot by my pure fear that the guys on the other side of the world were better, more prepared, younger, more talented, and genetically-gifted. . .and the only way I knew was just to be tougher mentally and to be able to withstand a pain threshold that they wouldn’t even dare step into”

## Apolo’s tumultuous relationship with South Korea, from hatred to respect to admiration [2:29:00]

- After the 2002 games where [he won gold only because the Korean skater was disqualified](https://www.youtube.com/watch?v=1Z-obyjzj5g), Apolo was hated across the country of South Korea
- Apolo felt hurt emotionally because he loved the culture, and felt the hatred was unwarranted
- Anti-American sentiment was at its peak, and Apolo was a bit of a scapegoat
- They even had Apolo’s face on toilet paper

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-42.png)

**Figure 7. Actual toilet paper from South Korea**.

In 2004, Apolo and team USA returned to compete in South Korea

- After staying away from S. Korea for 2 years due to the threat of violence against Apolo, the US team returns to compete in 2004
- Security and police everywhere
- South Korea considered this their “rematch” to prove that Apolo winning gold in 2002 was just a fluke
- Apolo was focused on *earning their respect* as opposed to beating them
- Despite having severe food poisoning, he won the competition, and more importantly, he won the respect of the South Korean citizens
- The same fans that were booing him when he got there were cheering for him when he was leaving

The perfect short-track body composition

- Pelvis tilted forward
- Rounded lower back
- Shorter torso
- Long legs
- Thinner frame naturally
- Minimal upper body weight
- Strong lower body
- Peter said, that is like a cyclist
- Strength to weight ratio
- South Koreans seemed to have this naturally
- Apolo did not have this naturally, nor did the way he skated feel natural, had to force it and only after years of training was it automatic

## Applying lessons learned through training, adjusting to life after skating, and the struggles many athletes face transitioning to retirement [2:46:30]

Using the lessons he learned from being an Olympian

> “The traits and attributes that I developed as a short-track athlete . . . are beneficial attributes to apply towards specific parts of life”

- **Overcoming new challenges**: He can always reflect back on the challenges he overcame as an athlete to remind himself what he is capable of accomplishing with the right mental attitude
- **Mental fortitude**: “I’ve done things physiologically I never thought was possible, I broke through barriers mentally that I think were really powerful”
- **Ability to focus on long term goals**: He says he still has the ability to maintain a hyper-focus on things he wants to improve or accomplish, but says he is much less rigid, “I’m a much softer as a person now. . .I was so rigid in every element you can imagine and tight with my time. . . it made me probably unpleasant to be around”

The struggle many athletes face after retirement

- First, many can’t seem to apply their greatness in sport to their next chapter in life
- Secondly, many feel like they’ve lost their sense of purpose and belonging
- Did Apolo struggle with the transition?
- “It was incredibly difficult”

The struggle of former Olympians

- Just dedicated the last 4,8, 12+ years towards learning a skill that doesn’t translate to real life
- No real work experience for your resume
- The lack of a clear goal and structure is hard because it’s all you’ve known for years
- “It gets dark” when their sense of purpose and belonging go away

## The final years of Apolo’s career: intense focus, crazy training, mental fortitude, and resiliency [2:57:30]

[2009 Speed Skating World Cup](https://en.wikipedia.org/wiki/2009%E2%80%9310_ISU_Short_Track_Speed_Skating_World_Cup) in Beijing

- Didn’t perform well, maybe got 5th
- First time he didn’t get on the podium
- Negative thoughts flowed in: *Is this it for me? Can I keep up?*
- Psychologically damaging event
- Noticed that other racers stopped respecting him during competitions
- South Korean coaches had studied him for years and knew exactly his every move

Did you think about just retiring?

- No, didn’t want to give up
- Listened to his 3 confidants
  - Dad (realist who was focused on developing a plan)
  - [Ian Baranski Beck](https://twitter.com/olympussports?lang=en) (best friend who kept it real and told the blunt truth)
  - [John Schaeffer](https://en.wikipedia.org/wiki/John_Schaeffer) (strength and conditioning coach who was a pure optimist)

Never show all your cards in speed skating

- “So people didn’t really know what was going on internally. They just thought that I was like this stoic, never show pain, incredibly focused, super hungry, quiet kind of crazy guy. . .with an insatiable appetite for pain and training every day. . .and that’s what I want people to believe.”
- Reality was he didn’t much confidence at this point that he could compete at a high level any more
- But realized that all that matters was the one day coming up, nothing in the past matters, would keep his medals in his sock drawer bc just wanted to look forward

Intense focus and crazy training

- After his suboptimal performance at the world championship in 2009, he checked himself into the Colorado Springs training center and just trained in solitude
- What was his plan? Improve cadence >> Lower body weight >> Maintain strength >> Get in the best aerobic shape in his life
  - Long bike rides
  - Inline skates
  - Running
  - Treadmill
  - Stairmaster

Training on the [Manitou Incline](https://en.wikipedia.org/wiki/Manitou_Incline) in Colorado Springs

- He said he “lived there” multiple times per week
- Would train in a 40 lb weighted vest
- Fastest time: 17:36
- Average time for athletes: 22:00

![](https://peterattiamd.com/wp-content/uploads/2018/11/Looking_down_the_Manitou_Springs_Incline_from_Barr_Trail_Bailout.jpg)

**Figure 8. Manitou Incline**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Manitou_Incline#/media/File:Looking_down_the_Manitou_Springs_Incline_from_Barr_Trail_Bailout.jpg)

This training was not ideal for a speed skater

- “I was doing everything wrong”
- I should have been doing short interval training instead of 3-hour bike rides
- How much of this training was for your brain versus your body? “90-95%”
- “But what did I gain a mental perspective and a honed focus and a resiliency. And I think the feeling that I was reinventing myself was really important to me psychologically”

What is it like going into your last Olympics?

- More appreciative
- Could be more present
- Could feel like you are a part of the world coming together
- He felt successful before the races started
  - He hit is cadence and weight goals
  - His opponents didn’t even recognize him
  - He ended up winning 3 medals and finishing his career with 8 medals

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-47.png)

**Figure 9. Apolo celebrates after winning his eighth Olympic medal**. Image credit: [UPI](https://www.upi.com/Apolo-Anton-Ohno-Americans-can-learn-from-Olympic-culture/2131516242626/)

By end of 2010 games, who were your main sponsors?

- Alaska Airlines
- Omega
- Subway
- Coca-Cola

## Officially retiring and contemplating a comeback [3:16:15]

- Officially retired in 2012, but internally he knew in 2009
- He never wanted to be the guy that tried to come out of retirement but watching [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) in 2012 really made him consider it

Peter’s favorite Phelps moment:

- When he [dominated in the 2nd swimmer position of the 4 x 100 freestyle relay](https://www.youtube.com/watch?v=-XI_XeoIFnI) immediately following his “abysmal” performance in his signature event (400 IM) which should have broken him
- Apolo says he needs to be angry and taste defeat
- When you are winning for so long it gets hard to push yourself and you need to remember what it feels like to lose to reinvigorate yourself
- Same reason why Apolo would throw in some self-sabotage here and there

Returning to the cabin at Iron Springs Resort

- Needed to make a final decision about coming out of retirement
- Decided not to do it, to stay on his path as an entrepreneur and trying to learn and explore and grow as a human
- Very happy with his decision

## Where does Apolo want to be in 10 years? [3:22:45]

- Healthy, first and foremost
- Increased relationships with family and friends
- Business-wise, involved in many different projects and ideas
- Winning in business is good but mostly about learning
- Trying to self-reflect and understand what is really important
- Wants to give back to the youth: Apolo wants to help kids understand the importance of sports and the amazing life lessons of commitment, dedication, discipline that you can learn

> “I think [these lessons] are difficult to teach if you don’t have the physical component associated with them”

## The pursuit of perfection and flow states [3:29:30]

What was the closet Apolo got to feeling like he had a perfect race?

- One race, [won gold in the 500 meters in Torino, Italy in 2006](https://www.nbcsports.com/video/2006-olympics-apolo-ohno-narrowly-wins-gold-torino)
- Wasn’t fastest, but had a strategy and executed it flawlessly and won wire-to-wire

Flow state

- Apolo says some of his favorite moments were when he entered a [flow state](https://en.wikipedia.org/wiki/Flow_(psychology))
- “Felt like Neo from the Matrix”
- Flow is an addictive feeling even for non-athletes, doctors, writer, singer, etc.
- Peter says race car driving gets you into flow => Your fastest laps never feel that fast, feels effortless, addictive
- Apolo on finding flow:

> “I’m convinced that you have to care enough about the outcome for you to get in that state. There has to be some form of consequence, maybe not physical or immediate danger, but psychologically to impact you to almost force yourself into that realm.”

## Where you can follow Apolo [3:35:00]

- Twitter: [@ApoloOhno](https://twitter.com/ApoloOhno)
- Instagram: [@ApoloOhno](https://www.instagram.com/apoloohno/?hl=en)
- His book, [Zero Regrets](https://www.amazon.com/Zero-Regrets-Greater-Than-Yesterday/dp/1451609078), written immediately following his last Olympic games
- Website: [ApoloOhno.com](https://www.apoloohno.com/)

§

## Selected Links / Related Material

## Must-See Video Links:

- **Video of Apolo’s training doing single-leg lateral jumps**: [How They Train: Speed Skating | TIME](https://www.youtube.com/watch?v=xdKiY92WE40) | TIME ([youtube.com](https://www.youtube.com/)) [37:30]
- **Must-see, hilarious video of Apolo’s first Olympic medal race**: [Ozzy Man Reviews: Greatest Olympic Win Ever](https://www.youtube.com/watch?v=5fFnSRKUBFU) | Ozzy Man Reviews ([youtube.com](https://www.youtube.com/)) [1:37:15]
- **Video of Apolo’s controversial win for his gold medal**: [2002 Winter Olympics–ST Men’s 1500m](https://www.youtube.com/watch?v=1Z-obyjzj5g) | KatsD10 ([youtube.com](https://www.youtube.com/)) [1:50:00, 2:29:00]
- **NBC segment where Apolo describes how training in South Korea changed his life**: [Ohno shares experience in Lion’s Den, South Korea](https://www.nbcsports.com/video/inside-lions-den-south-korea-apolo-ohno) | ([nbcsports.com](https://www.nbcsports.com/)) [2:12:45]
- **Apolo’s closest thing to a perfect race**: [Ohno narrowly wins gold in Torino](https://www.nbcsports.com/video/2006-olympics-apolo-ohno-narrowly-wins-gold-torino) | ([nbcsports.com](https://www.nbcsports.com/)) [3:30:00]

## Full list of references

- **Apolo’s website**: [ApoloOhno.com](https://www.apoloohno.com/)
- **Apolo wins Dancing with the Stars**: [Apolo Anton Ohno](https://dancingwiththestars.fandom.com/wiki/Apolo_Anton_Ohno) | ([wikia.com](https://www.wikia.com/fandom)) [1:10]
- **Apolo couldn’t get info on his heritage even with the help of NBC TV show**: [Who Do You Think You Are?](https://en.wikipedia.org/wiki/Who_Do_You_Think_You_Are%3F_(U.S._TV_series)) [13:45]
- **Description of famous climb called Old La Honda**: [Old La Honda (East side), Portola Valley](https://graphics.stanford.edu/~lucasp/grade/oldlahonda.html) | ([stanford.edu](https://www.stanford.edu/)) [31:30]
- **Video of Eric Heiden riding up Old La Honda**: [Eric Heiden Old La Honda Record 14:10](https://www.youtube.com/watch?v=0Oj8k_YHcYg) | jsoltren ([youtube.com](https://www.youtube.com/)) [31:30]
- **A forum discussion about Heiden’s record at Old La Honda**: [Old La Honda](https://weightweenies.starbike.com/forum/viewtopic.php?t=112799) | ([starbike.com](https://www.starbike.com/)) [31:30]
- **Video of Apolo’s training doing single-leg lateral jumps**: [How They Train: Speed Skating | TIME](https://www.youtube.com/watch?v=xdKiY92WE40) | TIME ([youtube.com](https://www.youtube.com/)) [37:30]
- **Junior Olympic training center in Lake Placid**: [Lake Placid Olympic Training Center](https://www.teamusa.org/about-the-usoc/olympic-training-centers/lpotc/about) | ([teamusa.org](https://www.teamusa.org/)) [49:00]
- **“Miracle on Ice” where USA hockey upset the Russians happened in 1980 at Lake Placid**: [Final Minute of the “Miracle on Ice”](https://www.youtube.com/watch?v=qYscemhnf88) | Ryan G (youtube.com) [49:00]
- **Michael Phelps becomes youngest male to set a world record**: [2001 World championships](https://en.wikipedia.org/wiki/Michael_Phelps#2001_World_championships) | ([wikipedia.org](https://www.wikipedia.org/)) [51:30]
- **Where Apolo trained once he turned 15**: [Colorado Springs Olympic Training Center](https://www.teamusa.org/about-the-usoc/olympic-training-centers/csotc/about) | ([teamusa.org](https://www.teamusa.org/)) [1:11:00]
- **The cabin where Apolo was dropped off by his father at age 15 to make a decision**: [Iron Springs Resort](https://ironspringsresort.com/) | ([ironspringsresort.com](https://ironspringsresort.com/)) [1:18:00]
- **Must-see, hilarious video of Apolo’s first Olympic medal race**: [Ozzy Man Reviews: Greatest Olympic Win Ever](https://www.youtube.com/watch?v=5fFnSRKUBFU) | Ozzy Man Reviews ([youtube.com](https://www.youtube.com/)) [1:37:15]
- **Peter compares Apolo’s scramble to the finish line to win to when Rocky Balboa and Apollo Creed both knock each other down in Rocky II and Rocky is the only one to get up**: [Rocky II – Rocky Balboa Vs Apollo Creed (Rematch) [HQ]](https://youtu.be/Ctl9I6O5OkI?t=400) | RockyBalboaOfficial ([youtube.com](https://www.youtube.com/)) [1:46:00]
- **Video of Apolo’s controversial win for his gold medal**: [2002 Winter Olympics–ST Men’s 1500m](https://www.youtube.com/watch?v=1Z-obyjzj5g) | KatsD10 ([youtube.com](https://www.youtube.com/)) [1:50:00, 2:29:00]
- **NBC segment where Apolo describes how training in South Korea changed his life**: [Ohno shares experience in Lion’s Den, South Korea](https://www.nbcsports.com/video/inside-lions-den-south-korea-apolo-ohno) | ([nbcsports.com](https://www.nbcsports.com/)) [2:12:45]
- **Another Rocky metaphor comparing how Apolo totally changed his approach leading up to his final Olympics to how Rocky prepared for his rematch with Clubber Lang**: [Rocky III Rocky Balboa Vs Clubber Lang 2nd Fight](https://www.youtube.com/watch?v=o4VyvcySBuE) | Wonder Land ([youtube.com](https://www.youtube.com/)) [2:20:15]
- **Famous hiking trail in Colorado Springs where Apolo trained intensely in preparation for his final Olympics**: [Manitou Incline](https://en.wikipedia.org/wiki/Manitou_Incline) | ([wikipedia.org](https://www.wikipedia.org/)) [3:07:00]
- **Peter’s favorite Michael Phelps moment**: [France Win Gold In 4x100m Freestyle Relay Final | London 2012 Olympics](https://www.youtube.com/watch?v=-XI_XeoIFnI) | Olympic (youtube.com) [3:18:00]
- **Apolo’s closest thing to a perfect race**: [Ohno narrowly wins gold in Torino](https://www.nbcsports.com/video/2006-olympics-apolo-ohno-narrowly-wins-gold-torino) | ([nbcsports.com](https://www.nbcsports.com/)) [3:30:00]
- **Apolo Ohno’s book**: [Zero Regrets](https://www.amazon.com/Zero-Regrets-Greater-Than-Yesterday/dp/1451609078) by Apolo Ohno | ([amazon.com](https://www.amazon.com/)) [3:35:00]

§

## People Mentioned

- [Rocky Balboa](https://en.wikipedia.org/wiki/Rocky_Balboa) (many parallels between Rocky and Apolo’s life) [3:30]
- [Bob Kaplan](https://twitter.com/bobkaplan) (Attia Medical analyst, show notes contributor) [5:00]
- [Travis Denson](https://twitter.com/tden185) (Attia Medical analyst, show notes contributor) [5:00]
- [Eric Heiden](https://en.wikipedia.org/wiki/Eric_Heiden) (won 5 golds in single Olympics) [29:45, 49:00, 53:00, 1:46:45]
- [Katie Ledecky](https://en.wikipedia.org/wiki/Katie_Ledecky) (won 200, 400 and 800 in single Olympics) [30:00]
- [Steve Prefontaine](https://en.wikipedia.org/wiki/Steve_Prefontaine) (held many outdoor track records) [30:30]
- [Lance Armstrong](https://twitter.com/lancearmstrong?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (someone Apolo admired) [34:45, 37:30, 1:34:30, 2:45:15]
- [Dianne Holum](https://en.wikipedia.org/wiki/Dianne_Holum) (unconventional and obscene training methods) [35:30]
- [Tonya Harding](https://en.wikipedia.org/wiki/Tonya_Harding) [48:00]
- [Nancy Kerrigan](https://en.wikipedia.org/wiki/Nancy_Kerrigan) [48:00]
- [Patrick Wentland](https://www.teamusa.org/US-Speedskating/About/Hall-of-Fame-Content/Skaters/Patrick-Wentland) (Apolo’s first real speed skating coach) [49:15, 56:30]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) (most accomplished swimmer in Olympic history) [51:30, 1:04:00, 1:14:00, 2:16:30, 2:45:15, 3:09:45, 3:16:30, 3:18:30]
- [Bonnie Blair](https://en.wikipedia.org/wiki/Bonnie_Blair) (top female speed skater) [53:00]
- [Marc Gagnon](https://en.wikipedia.org/wiki/Marc_Gagnon) (Canadian speed skater warned Apolo that he waits too long to make his move) [1:15:00]
- [Jocko Willink](https://twitter.com/jockowillink?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Navy SEAL) [1:20:00]
- [Kim Dong-sung](https://en.wikipedia.org/wiki/Kim_Dong-sung) (skater who was DQ giving Apolo his first gold medal) [1:26:15, 1:52:30]
- [Fabio Carta](https://en.wikipedia.org/wiki/Fabio_Carta) (Italian short track skater)[1:26:15]
- [David Creswell](https://www.cmu.edu/dietrich/psychology/people/core-training-faculty/creswell-david.html) (Apolo’s sports psychologist) [1:27:00]
- [Mathieu Turcotte](https://en.wikipedia.org/wiki/Mathieu_Turcotte) (skater in the 2002 race where they all crash and Apolo gets his first medal) [1:39:15]
- [Li Jiajun](https://en.wikipedia.org/wiki/Li_Jiajun) (skater in the 2002 race where they all crash and Apolo gets his first medal) [1:39:15]
- [Ahn Hyun-soo](https://en.wikipedia.org/wiki/Viktor_An) (skater in the 2002 race where they all crash and Apolo gets his first medal) [1:39:15]
- [Steven Bradbury](https://en.wikipedia.org/wiki/Steven_Bradbury) (skater who won gold in the 2002 race where they all crash and Apolo gets his first medal) [1:39:15]
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) (“[Everyone has a plan until they get hit](https://www.barrypopik.com/index.php/new_york_city/entry/everyone_has_a_plan_until_theyve_been_hit_boxing_adage)”) [1:39:45]
- [Matt Targett](https://twitter.com/matthewtargett?lang=en) (Olympic swimmer, Peter’s friend) [1:49:15]
- [Dr. Randy Wilber](https://www1.udel.edu/ICECP/facultystaff/faculty_wilber.html) (Sports Physiologist at the U.S. Olympic Training Center) [2:06:00]
- [Dan Jansen](https://en.wikipedia.org/wiki/Dan_Jansen) (advice for retiring athletes) [2:55:30]
- [Michelle Kwan](https://twitter.com/michellewkwan?lang=en) (advice for retiring athletes) [2:55:30]
- [Ian Baranski Beck](https://twitter.com/olympussports?lang=en) (best friend who kept it real and told the blunt truth) [3:02:15]
- [John Schaeffer](https://en.wikipedia.org/wiki/John_Schaeffer) (strength and conditioning coach who was a pure optimist) [3:02:15]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (speaks Japanese) [3:28:00]
- [Neo from The Matrix](https://en.wikipedia.org/wiki/Neo_(The_Matrix)) (how Apolo feels when in his flow state on the ice) [3:31:45]

§

![](https://peterattiamd.com/wp-content/uploads/2018/11/apolo-ohno-2x1-500x500.jpeg)

##### Apolo Anton Ohno

Apolo Anton Ohno is a retired American short track speed skating competitor and an eight-time medalist (two gold, two silver, four bronze) in the Winter Olympics.

Raised by his father, Ohno began training full-time in 1996. He has been the face of short track in the United States since winning his medals at the 2002 Winter Olympics. At the age of 14, he became the youngest U.S. national champion in 1997 and was the reigning champion from 2001–2009, winning the title a total of 12 times. In December 1999, he became the youngest skater to win a World Cup event title, and became the first American to win a World Cup overall title in 2001, which he won again in 2003 and 2005. He won his first overall World Championship title at the 2008 championships.

Ohno’s accolades and accomplishments include being the United States Olympic Committee’s Male Athlete of the Month in October 2003 and March 2008, the U.S. Speed skating’s Athlete of the Year for 2003, and was a 2002, 2003 and 2006 finalist for the Sullivan Award, which recognizes the best amateur athlete in the United States. Since gaining recognition through his sport, Ohno has worked as a motivational speaker, philanthropist, started a nutritional supplement business called 8 Zone, and in 2007, competed on and won the reality TV show Dancing with the Stars. Ohno later became host of a revival of Minute to Win It on Game Show Network and served as a commentator for NBC’s coverage of the 2014 Winter Games in Sochi and the 2018 Winter Games in Pyeongchang. [[Wikipedia](https://en.wikipedia.org/wiki/Apolo_Ohno)]

Website: [ApoloOhno.com](https://www.apoloohno.com/)

Apolo on Instagram: [@ApoloOhno](https://www.instagram.com/apoloohno/?hl=en)

Apolo on Twitter: [@ApoloOhno](https://twitter.com/ApoloOhno?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)