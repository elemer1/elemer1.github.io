# #89 – AMA #11: All things fasting

**Source:** [https://peterattiamd.com/ama11/](https://peterattiamd.com/ama11/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of fasting-specific questions from subscribers. Peter starts by defining the various fasting protocols, details his own personal fasting regimen, explains his revised plan for 2020, and provides a ton of value to anyone interested in fasting. Once again, Bob Kaplan, Peter’s head of research, will be asking the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #11 show notes page](https://peterattiamd.com/ama11/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Defining the various fasting protocols [1:00];
- Why Peter plans to switch to a 3-day fast once per month in 2020 [11:00];
- How Peter uses his CGM to gain insights into the depth of fast [13:15];
- Peter’s supplement protocol during fasting, and why he eats a ketogenic diet leading up to a prolonged fast [17:00];
- Peter’s exercise regimen during a fast [23:30];
- Peter’s hunger levels during a typical 7-day fast [26:45];
- Fasting observations—Core body temperature and thyroid hormone [30:30];
- Fasting observations—Glucose, BHB, and hunger levels [33:15];
- Peter’s sleep protocol during a fast [40:15];
- Does Peter observe any differences between men and women in their ability to fast? [47:00];
- How Peter prefers to break a long fast [50:15];
- Importance of community support while fasting, and is there a perfect fasting protocol? [52:00]; and
- More.

§

The Peter Attia Drive

All things fasting

§

## Show Notes

## Defining the various fasting protocols [1:00]

**The overnight fast**

- The standard fast that almost by definition everybody does between dinner and breakfast
- *Example*: Finish dinner at 7pm, eat breakfast at 7am the next morning = 12 hour overnight fast

**Time restricted feeding (TRF)**

- The idea where you increase that window from just an overnight fast into a slightly longer window
- To put the overnight fast example used above into time-restricted feeding nomenclature, you would call it a 12/12 (meaning 12 hours of fasting followed by a 12-hour window)
- You can extend that and you can say a 14/10 window or a 16/8 window or an 18/6 window
- The first number refers to the period of time that has **no nutrient exposure** and then followed by the window in time in which one would **be able to consume food** (typically ad libitum aka without restriction)

**Alternate day fasting (ADF)**

- Generally speaking, ADF means that every other day you do *something* other than eating ad libitum
- *Most strict ADF* = Consume nothing everything other day (this would be challenging to maintain over the long haul)
- *More common versions of ADF* = every other day you have a **hypocaloric** day
  - *Example*, 1,000 calories on the “fasting” day and then eat ad libitum (or they’re normal calories amount) on the non-fasting day
  - Could also refer to this as “*alternate day calorie restriction*” instead of ADF

**Intermittent fasting (IF)**

- This term has become popular with the public
- But many people mistake IF with TRF… in other words they say intermittent fasting but what they really mean is time-restricted feeding
- Peter describes IF as undergoing a fast (of at least 24 hours) at some frequency
- *Example*, once every month (or every quarter, or every six months, etc.) you would go an extended period of time (>24 hours) without consuming calories

**5:2 hypocaloric fast**

- This is another popular variation of “fasting”
- Five days out of the seven-day week you’re eating normally
- But two days out of the seven-day week (but not successive days), you are typically eating a hypocaloric diet of 400 to 600 calories

**Fasting Mimicking Diet (FMD)**

- The [FMD](https://l-nutra.com/pages/fasting-mimicking-diet) is a trademarked protocol coined by a company called [L-Nutra](https://l-nutra.com/) which sells a prepackaged five-day “fast” and it’s based on the work of [Valter Longo](https://valterlongo.com/)
  - This product is ~900 to 1000 calories on the first day and  ~700 to 750 calories for days two through five
- To be clear, the Fasting Mimicking Diet is a brand (like Kleenex is to tissues)
- “*But there are an infinite number of ways that one can do a reduced-calorie fast that approximates some of the metabolic benefits of fasting.*”

**Prolonged fasting/multiple-day fasting**

–*Clarification from Peter*:

- You can do prolonged “fasting” via a reduced-calorie “fast” (e.g., the 5 days Fast-Mimicking Diet)
- In Peter’s practice, he will sometimes prescribe anywhere from three to seven days typically at about 500 to 700 calories a day (with a customized macronutrient profile)

–*A true fast is water only (plus minerals)*:

- A “true” prolonged fast would be nothing but water (but also includes tea and some minerals with zero calories) for a period of time (typically three to seven days at a time)
- Bubbly water is okay as well, Peter goes through [Topo Chico](https://www.topochicousa.net/) at “*geometric rate*” when fasting

–*Is coffee and/or tea okay?*

- There is probably some difference in the nature of the fast if you include coffee or tea, but probably not as much of an issue as “purists” make it out to be
- With patients who are pretty caffeine dependent, Peter recommends NOT giving up their coffee because fasting can be hard enough without dealing with caffeine withdrawals
- Eliminating coffee during a fast might improve the “gut rest” you get from a true fast
- But some observers have suggested that [coffee actually enhances autophagy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4111762/) late enough in the fast (though Peter is skeptical about that)

## Why Peter plans to switch to a 3-day fast once per month in 2020 [11:00]

**What type of fasting does Peter most commonly do?**

- He’s tried every protocol mentioned above over time
- For the past couple years, he’s been doing a [7-day water-only fast once per quarter](https://peterattiamd.com/ama02/)

**Plans for 2020**

- For 2020, Peter plans to switch to a **3-day water-only fast once per month**
- No real scientific insight telling him that’s what he should be doing
- More so he just wants to try something different
- The main difference is that with 3 days per month…
- There will be a more consistent exposure to fasting
- But at the same time, he may not be going as “deep” into the physiologic effects of fasting

*-Why 3 days?*

- Peter’s intuition is that **3 days is probably the minimum amount of time needed** to hit some of the important physiologic benchmarks such as…
  - Glycogen depletion which leads to…
  - Inhibition of mTOR
  - Activation of AMPK
  - A significant reduction of glucose and insulin that triggers [autophagy](https://en.wikipedia.org/wiki/Autophagy) and the inhibition of [senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence)

> “Truthfully, in humans, we don’t necessarily know exactly what the dose curve looks like for duration of fasting to physiologic output of desired consequence.”

## How Peter uses his CGM to gain insights into the depth of fast [13:15]

-Peter relies heavily on his [CGM](https://peterattiamd.com/kevinsayer/) to give him insights during his fast

-But not just looking at what his glucose levels are

-He looking for thinking like, “what’s the behavior of my glucose at night?”

—When in a **fed state**…

- His nighttime glucose can actually be quite erratic
- And he tends to run the highest glucose at night
- Peter observes more glucose excursion from the liver in the evening

—When in a **fasted state**…

- That erratic nature of glucose tends to vanish by the end of 48 hours (and certainly by the third day of only consuming water)
- He basically has a flat line of glucose
- And it’s a very low number, typically in the 60s
- The only thing that can make it budge is **exercise**
  - After lifting weights, Peter sees a transient rise in glucose of ~20 milligrams per deciliter or about one millimolar
  - Then it’ll sort of slowly come down

–*Significance of the new glucose equilibrium*:

- Peter’s intuition is that there’s something relevant that’s happening when we reach a new equilibrium of glycogen
- And that new equilibrium takes about 3 days to get to
- Peter estimates that this new baseline glucose level after 3 days is about 80% of the way to the “floor” of glucose which you might get to after about 10 days

⇒ [George Cahill’s 40-day starvation experiment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf)

- Subjects were fasted for 40 days on water-only
- After a month+, they maintained the blood glucose of about three millimolar which would be in the high 50s
- How is that possible?
  - You’re body is breaking down triglycerides into free fatty acids which are then used to make the ketones
  - The backbone of that free fatty acid is [glycerol](https://en.wikipedia.org/wiki/Glycerol) which then becomes gluconeogenic substrate
  - In other words, the liver takes that backbone of glycerol (three carbons) and it makes glucose
  - So even though you’re not eating, you’re still able to make glucose in the liver and the brain is still dependent on glucose even in a fasted state
- But Cahill’s data suggested even a month into a fast, **as much as 40-50% of the energy going to the brain of those subjects was still coming from glucose,** with the remainder coming from beta-hydroxybutyrate

**The takeaway**: *When fasting, Peter is using the observations of i) a* ***reduction of glucose*** *and ii) a* ***lack of volatility of glucose*** *as a proxy for something physiologically interesting that’s probably happening in concert.*

## Peter’s supplement protocol during fasting, and why he eats a ketogenic diet leading up to a prolonged fast [17:00]

![](https://peterattiamd.com/wp-content/uploads/2020/01/topo-chico-meal-prep-ama11-1024x962.png)

**Figure 1. Peter’s “meal prep” getting ready for a week of fasting.** Image credit: [@peterattiamd](https://www.instagram.com/peterattiamd/)

**Leading up to his 7-day water-only fasts…**

- Peter usually eats a ketogenic diet the week prior as a way to ease the transition into using BHB for energy
- “*If you could enter a fast with, say, one millimolar of beta-hydroxybutyrate floating around, your body has already done some of the very ‘heavy lifting’ in transitioning you to a more fat-adapted state which is obviously the essential state of fasting.*”

**Supplement protocol**

–*Magnesium*

- When NOT fasting, Peter’s magnesium protocol consists of:
  - A supplement called magnesium oxide (a “poorly absorbed, rapid-transit version of magnesium”), and…
  - L-threonate, which isn’t a magnesium, but it’s packaged with magnesium and it transports magnesium to the brain
- When fasting…
  - Peter’s changes out the magnesium oxide with a slow absorbing version of magnesium
  - And he also continues to take [magnesium L-threonate](https://www.cancer.gov/publications/dictionaries/cancer-drug/def/magnesium-l-threonate)

–*Methylated B vitamin complex*

- Peter takes this all the time (i.e., even when not fasting)
- It actually may not be that relevant during a fast but he is just pointing out that he doesn’t STOP taking it during a fast

–*He does NOT take rapamycin or metformin during a fast*

- He doesn’t take rapamycin during a fast because “I’m getting very potent mTOR inhibition during a fast.”
- And with metformin, he stopped taking it altogether recently so obviously not taking it during a fast

–*Sodium*

- On the three-day fast Peter recently did, he did NOT supplement any sodium at all and felt great (i.e., not lightheaded)
- On the seven-day fasts, he’s historically required two additional grams of sodium which he takes in the form of bouillon

—*Why is sodium important during a fast?*

- Bouillon is an important part of the toolkit for people because until your body really adapts to fasting and ketosis, the kidney gets pretty inefficient with sodium because it need to use sodium as an exchange to maintain potassium levels
- The body really need potassium inside **and outside** of a cell
- But the potassium outside of the cell is *really critical*
- Typical levels might be about four milliequivalents, but if that number gets down to three you are in trouble
- So the body will fight like hell for that extra milliequivalent of potassium and it will do so at the expense of sodium often and/or magnesium.
- So that’s why supplementing those things becomes an optimal way for your body to preserve potassium, and it’s much safer to supplement magnesium and sodium than to supplement potassium.

*–Why can’t we just supplement with potassium?*

- Potassium is one of those things where you want to let the body do its thing and just give it the right amount of food and let it extract potassium from nature.
- A high amount of potassium could kill a person
- Whereas in magnesium, you could overshoot by 10X and you wouldn’t hurt somebody.

> “I find most over-the-counter, commercial supplements of potassium to be silly because they don’t even contain enough potassium to move the needle. That’s because you shouldn’t really use potassium to move the needle. You should use sodium and magnesium to make that happen.”

**Supplements for sleep**: (discussed in more detail starting at 42:00)

- [Magnesium L-threonate](https://www.cancer.gov/publications/dictionaries/cancer-drug/def/magnesium-l-threonate) (already mentioned above) is a great sleep promotor
- [Doc Parsley’s Sleep Remedy](https://store.docparsley.com/products/sleep-remedy) – a full dose, which is three capsules about 30-45 min before bed
- [Jarrow Formulas PS-100](https://www.jarrow.com/product/150/PS)
  - this supplement is called [phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine)
  - Peter will take 3 capsules about 30 to 45 minutes before bed
- On rare occasions… 25 mg (half a pill) of a medication called [trazodone](https://en.wikipedia.org/wiki/Trazodone)

## Peter’s exercise regimen during a fast [23:30]

> “One of the important things during fasting is the preservation of lean mass. It’s pretty easy for the body to undergo some atrophy during a fast, and If we’d like to minimize that it’s [through strength training].”

**Minimizing atrophy**

- During a fast, the body’s lean mass can undergo some atrophy
- The best way to combat that is by strength training (about 30-60 minutes ideally)

**Peter’s regimen**

- He attempts to get in at least 60 minutes of strength training per day during a fast
- 60 minutes of strength training every day during a fast gives enough of signal to the muscle to minimize (or avoid atrophy)
- You’re not going to grow muscle mass during a fast
- In Peter’s experience, strength training is actually more tolerable than cardio training during a fast
- That said, there is an adaptation that takes place … *for example*:
- A couple of years ago I found even low end aerobic to be quite painful during long fasts. No longer is that the case. Now a zone 2 workout during a long fast feels great. But **anaerobic** stuff is certainly miserable. (e.g., Tabata or a set of brutal med ball slams [EMOM](https://www.acefitness.org/education-and-resources/lifestyle/blog/6535/emom-workout)s)

***\*Tip****: Give yourself some extra rest between sets. Surprisingly, you don’t really lose much strength during a fast, but you’re going to need a little bit more time to replenish between sets because there still is a glycolytic cost of those exercises.*

–*More detail about his workouts…*

- His workouts always include some exercises that are
  - i) Hip-hinging
  - ii) Pulling, and
  - iii) Pushing
- With hip-hinging, it’s things like deadlifts, deficit lunges, walking lunges.
  - \*REMEMBER: The devil’s in the details…anybody can hip hinge…*but can you hip hinge properly?*
- *The differences between his fasted and non-fasted workouts*: When fasted, doing his same regular exercises but, just taking a little bit more time between sets, and probably a little less likely to stack exercises.
- A*nother observation about fasted workouts*:
  - 1) He finds workouts more enjoyable because he puts less pressure on himself to nail every rep and set (i.e., not so regimented)
  - 2) Counterintuitively, it actually alleviates a lot of the hunger to be exercising… “*It actually is quite appetite suppressing.*”

## Peter’s hunger levels during a typical 7-day fast [26:45]

*When doing 7-day fasts*…

- He always does last meal Saturday, first meal Saturday
  - Which means Sunday through Friday are fully-fasted days and Saturdays are half days basically
  - Early dinner on Saturday as the last meal
- Sunday, first full fasted day
  - Wakes up, works out, then goes to the airport to travel
  - All feels pretty normal to that point
- Middle of the day on Monday (second fully-fasted day)…
  - It really starts to kick in that I’m fasting and he feels really hungry
  - It’s not quite 48 hours
- Midday hunger is common
  - From day 2 to day 5 of the fast, Peter says he feels pretty hungry between 12pm-5pm
  - Why midday?
    - Part of that is just our circadian rhythm
    - Part of that is habit
    - Part of that is just boredom
- Evenings feel very normal for Peter
  - “*I tend to get over this hump by about 6 p.m.*”
  - From 6 p.m. until bedtime, he doesn’t feel any different from how he normally feels
- By day 6…
  - He starts to lose all sense of hunger (medical terms for this is anorexia)
  - Case studies show people have this same complete loss of hunger generally between 7 and 14 days into a fast

## Fasting observations—Core body temperature and thyroid hormone [30:30]

**Peter feels cold a lot more**

-During a fast, it’s normal to feel a greater perception of being cold

- This is because your core body temperature falls
- And there’s [evidence](https://www.ncbi.nlm.nih.gov/pubmed/18225975) that by **day 3** we’re seeing [T3](https://en.wikipedia.org/wiki/Triiodothyronine) go way down, and [reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) go way up

⇒ In this [review](https://www.ncbi.nlm.nih.gov/pubmed/18225975), for example, they cite a group of investigators that [looked at healthy men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC154448/pdf/JCI0317490.pdf) and then [looked at healthy women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1482518/), and found the following numbers with a 72-hour fast (+ placebo)

-Men

- Baseline T3: 69.1 ng/dl
- 72h T3: 51.7
- Baseline rT3: 15.3
- 72h rT3: 20.2

-Women

- Baseline fT3: 2.98 pg/ml
- 72h fT3: 1.66
- Baseline rT3: 16.9 ng/dl
- 72h rT3: 33.5

***So, what’s going on here?***

- Your thyroid gland produces a hormone called T4
- T4 is inactive so the body has to convert it into either…
  - The active hormone which is T3; or
  - The anti-active hormone which is called reverse T3
- The amount of T3 and reverse T3 in the body is very important at regulating metabolism, body temperature, and all thyroid-related things
- In an environment where food is scarce, the body absolutely wants to slow down your metabolism.
- The greatest tool it has for doing that is by making more reverse T3 via an up-regulation a type of deiodinase enzyme that makes it
- And it will do so at the expense of making the active T3

-For Peter personally…

- He measures thyroid function during towards the end of his fasts and he’s “blown away” at the deterioration of thyroid function
- So not only has that slowed his metabolic rate down but, as a result of that, he is much more sensitive to cold

*-Does this do long-term damage to the thyroid?*

- Usually a week after re-feeding, Peter’s thyroid function is completely back to normal
- And after years of fasting, he’s seen no long-term signs of concern

> “The thyroid is a very resilient organ. . .that seems to understand when it needs to be activating you one way versus another.”

## Fasting observations—Glucose, BHB, and hunger levels [33:15]

**Correlation between BHB, glucose, and cortisol levels**

- BHB levels and glucose levels tend to be highly **inversely correlated**
- So when glucose comes down quickly, BHB will rise quickly
- In cases were Peter’s glucose stays “stubbornly” high, BHB levels take longer to come up
- W*hat might cause glucose levels to stay up*?
  - For Peter, when glucose levels are stubbornly high (i.e., high 80s/low 90s) it’s generally due to [cortisol](https://en.wikipedia.org/wiki/Cortisol) (aka stress)

-By the end of a **7-day fast**, Peter’s typically at:

- 5-6 millimolar for BHB
- 3-3.5 millimolar for glucose

-In a recent 3 day fast…

- During the last 36 hours, he was above three millimolar in BHB
- And by the end of the 3 days he was at 3.9 millimolar (pretty typical for him)

-In some cases, however, his BHB don’t get as high…

- He’s had fasts where even 6 or 7 days in, his ketones were still in the 2-3 millimolar range
- “*There’s something physiologically not working well and you’re sort of stuck in that no man’s land where you don’t have quite enough ketones to provide all your energy needs, but you’re also not replenishing your glucose levels enough. So you’re stuck vacillating between those two states. That’s not the most pleasant place to be.*”
- Possible explanations for this:
  - Cortisol can impair ketone production
    - If you’re overly stressed
    - If you’re a little sick
    - Basically anything that upregulates adrenal output can impair you from making ketones
  - One time, Peter was chewing a lot of gum sweetened with xylitol, which didn’t raise glucose at all, but it clearly impair ketone production

**How is hunger (or lack thereof) related to BHB and glucose levels?**

-Peter says his hunger is almost completely abated around day 6 or 7

-This lines up with his ketone levels being in the 5-6 millimolar range

–*Does Peter think that the* ***5-6 millimolar range*** *is the moment when hunger levels dissipate altogether?*

- “I don’t think I know yet.” says Peter
- But certainly it would make sense that the more ketones present the more available fuel that could be used
- But there are still times when your ketones are **3-3.5 millimolar** and you don’t feel hungry at all
  - But that could be a function of time of day, etc.

**In Cahill’s famous starvation** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf)

![](https://peterattiamd.com/wp-content/uploads/2020/01/cahill-study-figure-ama11-1024x848.png)

**Figure 2. Circulating concentrations of β-Hydroxybutyric, glucose, free fatty acids and acetoacetate in obese but otherwise normal man fasting for 40 days.** Image credit: ([Cahill and Veech, 2003](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf))

*The subjects in this study showed the following*:

- Glucose keeps dropping and then after a few days basically flatlines
- The ketones/BHB is continually increasing for the first three weeks
- The peak at ~6 millimoles after 30 days and doesn’t go up much more over the final 10 days
- At 10 days, subjects were at 4-4.5 mM
  - Peter is surprised their ketone levels weren’t higher than this after 10 days

*-Compared to Peter…*

- The ketone levels of subjects don’t rise as quickly as Peter who is at ~5 mM of ketones after a week or less
- Peter is surprised at how long it took Cahill’s subject to reach their BHB levels
- Peter says this MAY be because of the advancement of technology in measure ketones
- Peter says it’s hard to believe ketone levels would plateau after 40 days
- The other thing to keep in mind is the more time you spend in ketosis, the better the body gets at using the ketones. So that also kind of keeps the levels of ketones in the blood from going up continuously and linearly

*-What about people who fast going from a ketotic state vs. those who don’t?*

- People who fast who spend a lot of time in ketosis probably have a different experience than people who fast coming out of a non-ketotic fed state.
- Peter wishes he would have done an extended fast sometime during 2011-2014 when he was in ketosis
  - I would love to know what it would have been like to have done a seven-day fast in that environment when my body was really revved up and used to using ketones.
  - Is it possible all my levels would have been lower because I would have been using my ketones so much more efficiently?
  - Or is it possible they would have been much higher because the machinery to make them would have been so much more revved up?

⇒ See [Peter’s interview of Dom D’Agostino](https://peterattiamd.com/domdagostino/) where he explains the relative amounts of acetyl acetone, beta-hydroxybutyrate, and acetone production consumption during the fasted periods

## Peter’s sleep protocol during a fast [40:15]

**Sleep can be tricky during fasting**

-Peter says that he has experienced…

- Some of the “greatest nights of sleep of my entire life” while fasting
- And also some of the “most miserable nights of sleep in my entire life” while fasting

-When Peter does struggle with sleep…

- It’s rarely that he’s too hungry to fall asleep (although some people experience this)
- For Peter it’s **usually** that he has a hard time *staying* asleep (e.g., waking up super early and not being able to fall back asleep)

**Peter’s sleep regimen and wind-down routine**

-First of all, he “doubles down” on all my usual sleep hygiene stuff

- A big one is light removal
  - Blue light blocking glasses.
  - Not using electronics, if possible, but if so he’s putting blue light filters on them
- He uses the [OOLER Sleep System by chiliPAD](https://www.chilitechnology.com/products/ooler-sleep-system?variant=28215717232714&gclid=CjwKCAiAx_DwBRAfEiwA3vwZYut8wm-csZv574eNo4IRLKnUNlYux_SQJdtxvhXuyt8dPB7spQP8JBoC-SAQAvD_BwE)
  - He runs this machine a little warmer when fasting since core body temp is lower
- Lowering the air temperature of the room (65 in summer, 69 in winter)
- He’s being thoughtful about bedtime and wake up time
- Uses his Alaska bear eye mask to be as dark as possible

**Supplements for sleep**:

- Magnesium L-threonate is a great sleep promotor
- [Doc Parsley’s Sleep Remedy](https://store.docparsley.com/products/sleep-remedy)
  - Low dose of melatonin plus 5-HTP plus four or five other things
  - Peter takes a full dose (3 capsules) about 30-45 min before bed
- [Jarrow Formulas PS-100](https://www.jarrow.com/product/150/PS)
  - This supplement is called [phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine)
  - Peter will take 3 capsules about 30 to 45 minutes before bed
  - This is helpful because it can “*silence the adrenal glands a little bit which do tend to kick into overdrive when you’re fasting*.”
- [Trazodone](https://en.wikipedia.org/wiki/Trazodone)
  - On rare occasions… 25 mg (half a pill) of a medication called [trazodone](https://en.wikipedia.org/wiki/Trazodone)
  - Only uses in a pinch
  - It’s a fantastic sleep aid that has no stage erosion on sleep like you’d get with a benzo or Ambien

\*A note on Ambien and benzos:

- [Ambien](https://en.wikipedia.org/wiki/Zolpidem) is such a crappy drug, says Peter, because it more or less knocks you unconscious rather than puts you into proper sleep and there is erosion in your sleep stages
- A “benzo” ([benzodiazepine](https://en.wikipedia.org/wiki/Benzodiazepine)) would be better than Ambien, but still not great
- So when Peter really needs something extra, he will use trazodone instead of those 2 options

⇒  See Peter’s [interview of Matt Walker (Part 2)](https://peterattiamd.com/matthewwalker2/) for more on the dangers of sleeping pills

## Does Peter observe any differences between men and women in their ability to fast? [47:00]

**Does Peter observe any differences between men and women in their experience with fasting?**

- Peter has historically noticed that men tend to find fasting a little bit easier
- But his opinion on that might be changing since his sample size may not be big enough to make that generalization
- In fact, he is seeing more and more women go through fasting without a hitch

-Recently, Peter’s 60+ year old mother-in-law joined Peter on a 3-day fast over the holidays pretty much on a whim having never done it before

- She ended up having a great experience
- She slept great without taking any supplements
- She observed how much of her eating is mindless (found herself walking to the kitchen out of boredom rather than hunger)

NOTE: If a woman is trying to get pregnant, fasting’s a pretty bad strategy because it would likely send a signal that would probably interfere with ovulation and some of the other things that are important to prepare a woman to get pregnant.

Both men and women have struggles…

- Some men and women both really struggle to make that bridge to water-only fasting and they’ve struggled a lot with reduced-calorie fasting

If there is a difference between men and women…

- Women struggle more to do **time-restricted feeding** than men in Peter’s observation
- *For example*,
  - every guy Peter has given a 16 to 18 hour fasting protocol has been able to do it
  - But some of the women get the shakes and just feel like they need to be eating constantly
  - And these are usually very tiny, petite, slight women
- “*Maybe there’s just something going on with their metabolism that is unique to them and less about their gender.*”

## How Peter prefers to break a long fast [50:15]

- Make the first meal a pretty small meal
- Peter likes to have some cooked vegetables (it’s a bit hard with all of the insoluble fiber in raw veggies)
- Combined with a small amount of protein (e.g., steak)
- If the volume is too big, you might get the hiccups given your stomach has shrunk
- Peter once broke his fast with a couple glasses of win as an “experiment”
- “It definitely hit me harder than it normally would…prompted me to think twice about that before I do it again.”

## Importance of community support while fasting, and is there a perfect fasting protocol? [52:00]

**Uncertainty with protocols**

“*If anything is clear to a listener here it’s just how much uncertainty there is with these protocols, and how even though there’s lots of people out there claiming that their protocol is the only protocol or the best protocol, it would be hard with a straight face to say something like that with so much uncertainty and so few tools to truly evaluate this in humans when it comes to hard outcomes.*”

**Importance of community and support while fasting**

- Peter has personally felt the benefits of doing a fast with others
  - Whether in person like with his mother-in-law
  - Or via social media, he’s noticed that when he [shares on Instagram](https://www.instagram.com/p/B7D1Ju7gBqf/), he always finds that some followers of his are doing it along with him

*-Where to find community support*:

- [Zero app](https://www.zerofasting.com/) is creating a fasting community as well
- Follow [Peter’s instagram](https://instagram.com/peterattiamd) for live updates on his fasting

§

## Selected Links / Related Material

**The branded Fasting-Mimicking-Diet (FMD) based on Valter Longo’s work**: [L-Nutra](https://l-nutra.com/) | (l-nutra.com) [7:00]

**Some evidence that coffee may enhance autophagy**: [Coffee induces autophagy in vivo](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4111762/) (Federico Pietrocola et al., 2014) [10:00]

**The particular brand of bubbly water that Peter fancies**: [Topo Chico](https://www.topochicousa.net/) | (topochicousa.com) [10:45]

**Peter’s fasting protocol of seven days of water-only fasting sandwiched between a week of eating keto on either side**: [#11 – AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting](https://peterattiamd.com/ama02/) | Peter Attia (peterattiamd.com) [11:15]

**George Cahill’s 40-day fasting experiment**: [Ketoacids? Good medicine?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf) (Cahill and Veech, 2003) [15:15, 36:30]

**Review showing evidence that by day 3 we’re seeing T3 go way down, and reverse T3 go way up**: [Fasting-induced changes in the hypothalamus-pituitary-thyroid axis.](https://www.ncbi.nlm.nih.gov/pubmed/18225975) (Boelen et al., 2008) [30:30]

- *Papers cited by the review (in men)*: [The role of falling leptin levels in the neuroendocrine and metabolic adaptation to short-term starvation in healthy men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC154448/pdf/JCI0317490.pdf) (Chan et al., 2003)
- *Papers cited by the review (in women)*: [Differential regulation of metabolic, neuroendocrine, and immune function by leptin in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1482518/) (Chan et al., 2006)

**Peter’s interview Dom D’Agostino where Dom explains the relative amounts of acetyl acetone, beta-hydroxybutyrate, and acetone production consumption during the fasted periods**: [#05 – Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](https://peterattiamd.com/domdagostino/) | Peter Attia (peterattiamd.com) [40:00]

**The type of magnesium that Peter takes during a fast which acts as a great sleep promotor**: [Magnesium L-threonate](https://www.cancer.gov/publications/dictionaries/cancer-drug/def/magnesium-l-threonate) | (cancer.gov) [42:15]

**The sleep supplement Peter takes during a fast**: [Doc Parsley’s Sleep Remedy](https://store.docparsley.com/products/sleep-remedy) | (docparsley.com) [42:20]

**Brand of phosphatidylserine Peter takes for help with sleep during a fast**: [Jarrow Formulas PS-100](https://www.jarrow.com/product/150/PS) | (jarrow.com) [43:15]

**The prescription drug Peter uses for help with sleep during a fast only on rare occasions**: [Trazodone](https://en.wikipedia.org/wiki/Trazodone) | (wikipedia.org) [44:00]

**The bed cooling system Peter uses**: [OOLER Sleep System by chiliPAD](https://www.chilitechnology.com/products/ooler-sleep-system?variant=28215717232714&gclid=CjwKCAiAx_DwBRAfEiwA3vwZYut8wm-csZv574eNo4IRLKnUNlYux_SQJdtxvhXuyt8dPB7spQP8JBoC-SAQAvD_BwE) | (chilitechnology.com) [46:00]

**Phone app for fasting help and community**: [Zero](https://www.zerofasting.com/) | (zerofasting.com) [54:00]

§

## People Mentioned

- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) [15:15]
- [Dom D’Agostino](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [39:45]

§