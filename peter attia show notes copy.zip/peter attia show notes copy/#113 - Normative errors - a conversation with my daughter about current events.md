# #113: Normative errors — a conversation with my daughter about current events

**Source:** [https://peterattiamd.com/normative-errors/](https://peterattiamd.com/normative-errors/)

---

In this episode, I sit down with my daughter to discuss the brutal death of George Floyd, and the aftermath we are watching unfold. Though I have no expertise in race relations, law enforcement, or police brutality, I do have some knowledge in the training of physicians, and it is that training of doctors that I've been thinking about lately as it may offer one small insight into this crisis. In this very short discussion, we speak about three types of errors in medicine (and medical training), how to distinguish between the two variants that are acceptable, and the one that is unacceptable. My question, ultimately, is if such a framework can be applied to law enforcement?

**Duration:** 22:07

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

---

*Note: This is a short, special episode without the typical detailed show notes format.*
