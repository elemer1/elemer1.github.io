# #74 – Jason Fried: Optimizing efficiency and work-life balance

**Source:** [https://peterattiamd.com/jasonfried/](https://peterattiamd.com/jasonfried/)

---

##### Check out more content with Jason Fried:

- *(October 7, 2019)* [Jason Fried: Optimizing efficiency and work-life balance](/jasonfried/)
- *(February 17, 2020)* [AMA with Jason Fried: Work-life balance, avoiding burnout, defining success, company culture, and more](/jasonfriedama/)

In this episode, Jason Fried, co-founder of [Basecamp](https://basecamp.com/), shares his beliefs around achieving business success in a modern world which tends to disproportionately focus on the massive success stories (the outliers). Jason gives his honest take on companies like WeWork, Uber, and Lyft that may give off the appearance of wild success but may instead provide an example of the dangers of perverse incentives. We get into Jason’s backstory, and how his affinity for optimizing efficiency and production in the workplace culminated with the creation of Basecamp, his very successful web-based project management software business. Perhaps most importantly, we get really deep into all aspects of work-life balance and what it really means to “work hard” (Stay tuned for an AMA-style deep dive into the topic of work-life balance with Jason in the near future). In addition, Jason provides many more valuable nuggets including thoughts on some common mistakes made by businesses today, the value of giving employees autonomy, how to take the right types of risks, why he doesn’t set any goals, and much, much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jasonfried/the_Drive_public.png)

Play

#74 – Jason Fried: Optimizing efficiency and work-life balance

#74 – Jason Fried: Optimizing efficiency and work-life balance

1x15s30s

0:002:24:35

## We discuss:

- Jason’s background and his early entrepreneurial spirit [9:45];
- Views on completing higher education and the notion of hard work [24:00];
- Beliefs around success in business [35:00];
- WeWork, Uber, and Lyft: Poor business practices and the dangers of perverse incentives [41:30];
- Jason’s early career: his redesign approach and personal motivation [56:00];
- The genesis of Basecamp [1:10:00];
- Why Jason does not set goals but instead focuses on a vision [1:12:15];
- Workplace motivation and hiring practice [1:20:30];
- The importance of luck and not overworking [1:32:00];
- A framework to work less and optimize for workplace autonomy [1:38:00];
- The importance of saying ‘no’ more often (and tips for doing so) [1:55:00];
- A shared passion for watches [2:03:30];
- Guarding against the perils of phone addiction [2:08:45];
- Jason’s views on email and chat for communication [2:15:00] and;
- More.

§

## Show Notes

> ## Jason’s background and his early entrepreneurial spirit [9:45]

- Grew up in Deerfield, Illinois and began working when he was 13 or 14 years old
- Got interested in computers when he saw a microsoft black and white flight simulator

![](https://peterattiamd.com/wp-content/uploads/2019/10/00_screenshot.png)

**Figure 1. Microsoft black and white flight simulator.** Image credit: [microsoft corp archives](https://archive.org/details/mac_Flight_Simulato102)

- Jason got his first Mac Plus computer and began to make software because he wanted a tool to organize his music collection
  - Had a lot of music cassettes, cds, which he would loan out to friends and never got back
  - To track his collection he started using [FileMaker Pro](https://en.wikipedia.org/wiki/FileMaker_Pro)
  - Built his own interface design to track his collection, which he called AudioFile

> “I had always had an interest in interface design, for some reason, design, and so I learned how to make an interface. I built this thing which I eventually called Audio File, which was a way to keep track of the music collection that you had, and all the tracks that were on the CDs or the tapes, and who you loaned it out to and when. They would send you a reminder to get it back, and the whole thing” – Jason Fried

- Jason realized for the first time that he could make something he wanted, others might want it too, and be willing to pay for it
  - He uploaded AudioFile to AOL and shared his interface on the open web (shareware)
  - In text file he solicited $20 contribution if the user liked his product
  - Later received $20 in the mail

*Jason’s early entrepreneurial spirit*

- He would buy things and flip them at a higher price
  - With money saved up from selling shoes and tennis rackets he would buy things to flip
  - Had interest in military gear and ordered army supply and camping from a catalog called the Sportsman’s Guide
  - Ordered by cash on delivery and then create his own catalog of the gear that he ordered
  - Sold to his friends at a premium (not for the money but because it was fun)
- Getting in slight trouble for unrelated behavior ended his resale business
- Parents did not put many authoritative  limitations on him; were very supportive
  - An only child, his parents gave him a lot of latitude which he appreciated and feels it was valuable
  - Allowed him to figure things out for himself and be independent
  - Once he pushed a ‘bit too far’, he altered his behavior

## Views on completing higher education and the notion of ‘hard’ work [24:00]

> “I actually felt like school was interfering with my education. I felt like I was learning so much more from doing business and finding clients, and delivering work, and getting paid or not getting paid, and understanding what it’s like to work with people in the world, that school began to feel faker and faker to me, because everything was very abstract.” – Jason Fried

- Studied finance at the University of Arizona
- He found that he was ready to be done with school a couple of years in, when he had started doing website design
- He preferred learning in the real-world context, rather than via ‘abstract’ classroom lesson material

In the business field, it doesn’t matter if someone finish school or not…

- What matters are the experiences that the individual finds interesting and being motivated by what he/she is involved with
- Steve Jobs, for example, went to a liberal arts college and got involved in courses that influenced his interest and tastes for design

Timing matters …

- Facebook exists because Mark Zuckerberg went to college (whether or not he finished)
- Even for the famous entrepreneurs that did not finish college, school was important

> “…we tend to focus on the exceptions. It’s like those are the exceptions and the exceptional people. A lot of this has to do with luck, and timing, and and also skill, and talent, and observation, and opportunity, and all these things, but I think we put a lot of weight into things that probably have very little to do with it, in fact.” – Jason Fried

The mythology around ‘hard’ work …

- Jason does not think that the entrepreneurial success stories should be attributed to them working ‘harder’ than others
- He disagrees with the notion of hard work applied to an office environment
- Hard work, rather, is manual labor (e.g. picking strawberries in a field or roofing in the heat)

We are wired for pattern recognition such that …

- We look for patterns in success stories in order to determine: *what made them successful?*
- We put weight on things that have little to do with the ultimate success of these individuals
- Rather, Jason says to focus on what they got from their experience rather than the fact that they dropped out of school

⇛ Peter wrote a [blog post](https://peterattiamd.com/wired-think-scientifically-can-done/) about how we (as humans) are **not wired to think scientifically** but instead, we are hardwired to follow (exemplified by created patterns to follow-suit of successful ‘idols’)

- We look for the patterns that correlate with our own stories, creating confirmation biases
- We end up missing interesting details when we function with patterns
- People follow the wrong patterns (for example a startup following the actions of a large company like Apple)

## Beliefs around success in business [35:00]

**1 | Business success is mostly about luck and timing**

- Jason believes that we under-appreciate how much luck is involved in success stories (instead emphasizing talent and skill)
- Competitive and economic pressures have to do with timing (e.g. Dropbox)

> “I think that most of this stuff is actually luck and timing. There’s clearly talent and skill involved, too, but sometimes things just happen at the right time.” – Jason Fried

- If a [business] success cannot be replicated at a later time, it likely had a lot to do with luck and timing
- A couple of years ago, Jason would not have credited luck for his success in business…
- In fact, her remembers answering a question about luck with “*I don’t believe in luck.*”
  - Jason says he’s ashamed of that answer but that was his thinking at the time
  - “*Now I realize that that’s probably not true at all. In fact, if I had to start the business again right now, pretty good chance I wouldn’t. I wouldn’t be able to do it at all.*”

Luck and timing are multidimensional …

- The entrepreneurs (idea) timing
- Market timing
- Competitors timing
- Public appetite timing

… all of which have an element of luck involved

**2 | Business only gets harder**

- People underestimate how difficult it is to have employees
- Basecamp is harder today than 20 years ago…
- There are more competitors, employees
- There is an assumption that working hard ‘now’ means they don’t have to work hard ‘later’
- People become accustomed to working long hours that are not necessary

**3 | If lightning strikes, keep that lightning in a bottle**

- He is not a serial entrepreneur
- Believes in developing the ‘stroke of luck’ instead of trying to recreate it again
- He says he would not be able to have a ‘hit’ like Basecamp again
- The way to make a career is to stay in business, not to exit and reenter back into business (he doesn’t want to take the company public because of the pressure a public company brings with it)

> “I’m not ashamed to say I don’t think I could do this again. Well, I’m totally comfortable with that. A lot of entrepreneurs feel like they need to prove something to someone or themselves that they can do it over and over and over. That’s just not me. So I think putting that idea out there is a good alternative, because a lot of people think that by starting a business, selling it five years in, doing other ones, selling it five years in is like the way to make a career. I think the way to make a career is to sustain business, not to get out of business.” – Jason Fried

## WeWork, Uber, and Lyft: Poor business practices and the dangers of perverse incentives [41:30]

Business is not that difficult if people don’t make it so hard on themselves

- Unreasonable expectations of growth and owing too much money is self-destructive
- Companies grow too fast, raise money from the outside, put unnecessary expectations on themselves

> “They are forced into a growth track where they have to grow and they have to produce returns. They have to then hire people because they have money in the bank from the investor, because that’s where you spend money; on people, basically, and marketing. Then you get ahead of yourself, and you’re over your skis, and now you’re screwed, you’re in trouble. So now you have to keep fueling the growth, and raising more money.” – Jason Fried

Making money is a skill: if you want to get good at it, you must practice

- If you keep borrowing money to fund operation, when can a business practice making money?
- Uber and Lyft are textbook terrible businesses that has incurred massive losses
  - There are many issues with the business like their pricing model and ethics
  - Businesses like Uber are pushed by growth and public perception, but they are terrible businesses (similar to WeWork)
- People look at these businesses as a point of comparison, failing to realize that the likes of Apple, Microsoft, Amazon are *the exceptions*

⇒  The Amazon example

- It is the exception: most companies cannot be Amazon
- Amazon Web Services (AWS) is an outsourced cloud and a large part of the Amazon business

Jason is more interested in small businesses that have to show profit…

- Although he respects their user experience, Jason believes that Amazon puts undue pressure on smaller business and (unhealthily) dominates the market
- Most companies have to generate more money than they spend and they have to pay employees
- Rather than idolize large scale companies like WeWork, Lyft, Uber, smaller companies/the public should critically evaluate the economics and the unrealistic timelines of certain business outlooks (e.g. autonomous vehicles)

==> For more on perverse company incentives in the pharmaceutical industry (Ranbaxy) check out: [previous episode of the Drive with Katherine Eban](https://peterattiamd.com/katherineeban/)

## Jason’s early career: his redesign approach and personal motivation [56:00]

- Good timing for website design: became commercially viable for companies to have websites (Mosaic was a big step forward along with the Netscape IPO)
  - Jason contacted companies and suggested that he improve the  webdesign
  - He ended up getting a job in San Diego when he graduated from college with Keith Cruickshank
- He soon realized he didn’t want to work for someone else
  - He discovered that he is driven by the work content and didn’t want to invest his time in visions he didn’t believe in
  - He quit and started doing independent, freelance website design
  - Focused his efforts on redesign, rather than creating a website from scratch
  - Sometimes he would send a free mockup to potential clients in order to visualize the improvement he proposed making

> “I felt like I had the ability to take something that someone had and elevate it, basically, in a way where they’d be like, ‘I want that version of the thing that I have.’” – Jason Fried

Reimagining a web design: *‘This is what I would do if I could’…*

- Created something called The Better Project at Basecamp
- The team redesigned FedEx’s website out of frustration with the interface

> “And so, sometimes you have to create your own clients. That’s what I did, too, and got that word out there. And then word spread.” – Jason Fried

Jason is a believer in risk but never puts himself at risk …

- Apple, for example, took a huge bet on the Mac computer
- The company was hemorrhaging cash when Jobs returned to the company
- With every business decision, Jason weighs the odds
- With his co-founder David, he considers what the worst outcome could be and determines whether or not it is worth it

> “Risk is like taking a shot that if it doesn’t work, no big deal and we do that all the time at Basecamp. But what I will not do is bet the company on something. Maybe I would figure out that I’ve done that, looking back, if something didn’t work. But I would not knowingly go into something and go, ‘This has to work. We’re going all in on this or else it’s over.’” – Jason Fried

⇒ For more on differentiating outcome from process, check out a [previous episode of The Drive with Annie Duke](https://peterattiamd.com/annieduke/)

> “I don’t need to hit the grand slam. I want to keep doing this. I found my dream job, which is running my own business. Why would I want to put that at risk?” – Jason Fried

Although external recognition no longer interests Jason, it was something he sought at the beginning of his career…

- Submitted website design to an award site but got harsh feedback
- He didn’t agree with the feedback he received
- Realized that individual opinion is just that: subjective
- Not receiving the award motivated him to be better (rather than vengeful)

Jason identified his strength: structuring a web interface such that a user easily understood what the company was selling

- Many companies have a difficult time clearly explaining what they are selling
- Jason focused on excelling at his strength rather than where he was weaker (e.g. sophisticated site design)

> “I didn’t have the desire to flex outside of that. Let me just get good at what I’m good at. Why do I need to get good at everything? Let me get good at that. So, I kept doing that, got really quite good at it.” – Jason Fried

## The genesis of Basecamp [1:10:00]

- Hired a second person (Matt Linderman) when he won an account with Getty Images for its Getty One service (an aggregated site of stock photo libraries)
- As the company – originally called 37signals – got more accounts, they needed a better work management system
  - Basecamp was the work management system built to respond to the company’s internal needs
  - It was a product for which there was external demand

> “So, we built Basecamp. Like when I built my audio product, we built Basecamp for ourselves for our own specific needs. Didn’t even realize it was going to be a product, but then we used it with our clients and they said, ‘Hey, what is this thing you’re using? We have projects, too. Can we use this thing to manage?’” – Jason Fried

- With the product need identified, the concept was developed and refined
- Basecamp – the work management software – was launched February 5th 2004
  - Within 15 months, it was making more money than the website design services
  - Company transitioned solely to software development
- Jason’s partner David developed the software’s backend with Jason developing the front-end user interface

## Why Jason does not set goals but instead focuses on a vision [1:12:15]

> “Maybe it’s the number of goals I don’t like. Maybe it’s the milestone goals I don’t like. But directionally, I definitely want to go in specific directions.” – Jason Fried

- Jason does not take a goal-driven approach
  - The Basecamp software development was not planned
  - Instead, he reacted to a perceived market demand

He believes people should do what motivates them and goals don’t motivate him because …

1. They set him up to feel disappointed
2. If the goal is achieved then a new one is set (the bar is continually moved forward) and the ‘goal post’ is arbitrary

- Rather than setting out to achieve a quantitative  goal, he focuses on more experiential metrics like personal enjoyment
  - A goal is more fixed, or binary
  - A vision is directional but does not have to measure up against a set expectation or measure

## Workplace motivation and hiring practice [1:20:30]

> “You can hire the best in the world, but if the environment is crap, you’re not going to get the best work out of those people and they’re going to leave.” – Jason Fried

- Basecamp culture focuses on creating a motivational environment around individual contribution rather than business goals
- He believes compensation tied to performance is an issue

Jason’s unique hiring practices …

- Spends weeks writing job ads that accurately and specifically detail job role
- Includes salaries in the job description (no end negotiations)
  - Believes that the place to spend money is on the people he hires
  - Basecamp pays their employees within the top 10% of industry rates based on San Francisco salaries (industry leading in salaries)
  - He does not expect nor demand the candidate to negotiate for their salary
- The candidate’s  writing ability is very important: it is the first ‘filter’ of the hiring process

> “If you cannot write well, if you submit a cover letter and it’s bad, you’re out. I don’t care if you’re the best scientist in the world, you’re out, because you have to be able to communicate with us and the rest of the company, it’s primarily written, and you have to be able to express yourself that way.” – Jason Fried

Although Jason has authored five books, he says writing was not always his strength …

- His interest in writing fueled his motivation to become a better writer
- He values succinct expression: it is much harder to produce a shorter work than it is a longer piece of writing
  - His book contract said 40,000 words but he handed in 20,000
  - His publisher was focused on word count, claiming that thick books sell better (rather than content-driven)
  - The book was extended in length with pictures

## The importance of luck and not overworking [1:32:00]

> “So, people ask me all the time how to start a business. I don’t know. I haven’t done it for 20 years. I’m the wrong person to talk to about how to start a business. Advice has a shelf life, and it expires pretty quickly. You’re much better off talking to somebody who just started a business six months ago, than me…Reflecting on that, you kind of realize like, ‘Well, a lot of this has to do with when we started it, and what was going on at the time.’” – Jason Fried

- Recognizing the importance of luck in his own success came with reflection
- Came to the conclusion that he would not be able to replicate his success and thus a large part had to do with luck

Understanding that he could put in less work time less time within a week came at a distinct moment…

- Realized that for a given written proposal, all people want to know is how much it will cost
- So he began writing shorter proposals
- Figuring out the essence of something is a habit and a skill incorporated in the Basecamp ethos
- Within Basecamp, the company culture emphasizes the communicating the “essence” – referring to the given concept as the “epicenter”

> “We call it the epicenter of whatever it is that we’re doing. What are we doing? So you think of like, if I was to open a hotdog stand on the street, it’d still be a hot dog stand if I didn’t have ketchup and mustard and onions and pickles and relish, even the bun. I could just sell the hot dog. If it was a hot dog, it would be a hot dog stand still. If I didn’t have the hot dog, it wouldn’t be a hot dog stand. All those other things wouldn’t matter then…So the epicenter is the hot dog itself” – Jason Fried

## A framework to work less and optimize for workplace autonomy [1:38:00]

- The software industry as a whole has a problem with producing products with too many features
  - The antithesis of working with the “essence” or “epicenter” of a concept
  - Becomes a competition for the most features – as if more is better
  - For Jason, it is more interesting to reduce something to “must haves”
  - Requires a high level execution
  - Allows you to work less, which Jason takes a lot of pride in

> “I think there’s a lot of macho boasting in our industry of people who work long hours and get no sleep. It’s like, ‘I got four hours of sleep last night.”’ – Jason Fried

- The issue is protecting time in the workplace to do the work, rather than the amount of work to do
- Jason believes that protected blocks of time are necessary to do creative, productive work
- It doesn’t have to be crazy at work (also the title of one of [Jason’s books](https://www.amazon.com/Doesnt-Have-Be-Crazy-Work/dp/0062874780))
- Employees need to be given time to themselves without having calendars blocked with meetings
- How Basecamp employees coordinate without a lot of meetings:
  - They work independently
  - Every team is autonomous and under their own control
  - There are no dependencies
  - Every project has a six week or shorter lifespan
  - Deliveries are launched as they are developed and are small enough that they don’t depend on other things in the pipeline
- **An ideal framework**: three person team with a six week feature timeline
  - A team of (maximum) three people deliver on a  given ‘calendar’ (six week) feature cycle
  - A team is typically two programmers and one designer
- The number three is important:
  - A small team that can be self-managed; a “wedge”
  - Once a fourth person is added, there are “sides” … it becomes more complicated
- The basecamp organization is very flat:
- There is a lateral communication of what each team is working on rather than a hierarchical, reporting structure

> “…these things are self-reporting and we’re all paying attention to the work itself as it’s going. So there’s no moments when there’s big presentations. There’s no presentations. It’s like, work is happening. We’re paying attention to the work itself. Everyone’s writing up what they’re working on every single day, and people just know what’s going on.” – Jason Fried

- The framework Jason uses in his company is applicable in the context of other businesses and industries
- He recently published a [web-based book called Shape Up](https://basecamp.com/shapeup), explaining the framework

> “A lot of people, I think, think that their work is so mission critical. It’s not. You can work this way. You can slow things down a little bit, you can break things into smaller bits, and you can apply a few people, and apply pressure to a problem with just a few people over a short period of time, and solve that.” – Jason Fried

- Jason recognizes there are trade-offs made but he would rather get the feature produced; he would rather produce and deploy the product
- Short project lifespan also preserves the motivating company culture
- There is nothing more demoralizing than a never-ending project
- If the project isn’t going anywhere after six-weeks, they can pull the ‘circuit-breaker’ – abandoning the project; ‘pulling the plug’
- Not many companies operate in this way (yet)
- Corporate culture changes come from the top down
- But Jason encourages employees initiate a change for themselves

> “So if you don’t like being interrupted by other people all the time, you can interrupt other people less, or fewer times. Whatever you have in front of you that you can modify and you can change, begin to change that for yourself. You’re not going to change the whole company. But hopefully you can influence some other people, and they might be willing to make some more changes. And you can kind of bring that up the chain. But I’m not under any illusion here that someone’s going to read this book, or read some other books we’ve written, and the company’s going to change.” – Jason Fried

## The importance of saying ‘no’ more often (and tips for doing so) [1:55:00]

> “I often regret saying yes, I’ve realized, to things far out in the future. One of the reasons why is because yes is really easy to say. Yes requires no work.” – Jason Fried

- Saying ‘yes’ means saying ‘no’ to many other potentials
- Saying ‘no’ to one thing leaves other options available

Jason prefers flexibility and options …

- Saying ‘no’, kindly but often allows for this
- Also once reason why he has kept Basecamp privately held
- There are trade-offs to not attending; saying ‘no’
  - There are people he will not meet at events
  - But the ‘power of no’ allows for a lot of potentialities

Tips for saying ‘no’ …

- Appreciate the invitation but be honest about the demands of engaging, or saying ‘yes’
- People understand and appreciate the honesty

## A shared passion for watches [2:03:30]

- Jason’s dad used to buy watches on eBay
- Old [Elgin](https://www.chrono24.com/elgin/index.htm) tank watches from the 20’s
- Watch design is a great example of how many ways there are to design something
- First watch he got was a [Seiko Data 2000](https://www.vintagecomputer.net/browse_thread.cfm?id=725)  – a digital watch with a keyboard
- His tastes have changed over time and his rotating watch collection reflects that
- You can look back on watches (which continue to circulate as collectable objects) as a literal demarcation of (taste) change with time
- Got involved with blog, e-commerce site, and watch co-creator: Hodinkee
  - He followed vintage watch dealer [Eric Wind](https://www.windvintage.com/about)  who used to be involved with the company
  - Peter is an investor in the company

## Guarding against the perils of phone addiction [2:08:45]

- Jason would get  [Hodinkee](https://www.hodinkee.com/) alerts on his phone but had to turn them off during the day
- Believes that phones are highly addictive: the modern-day cigarette
- People suffer more with phones than from cigarettes
- Businesses facilitate and perpetuate society’s phone addiction

> “the business models surrounding many of these things on phones are all about engagement, and engagement is an addictive behavior. And so these companies basically are designed to addict you to their services and prompt you the right amounts of time per day. and reward you for engagement and whatnot. And they build these terrible addictive behaviors.” – Jason Fried

- Jason emphasizes the corporate responsibility to initiate behavioral change
- It is irresponsible to continue with business models that create, prey on, and reward addictive behaviors
- As long as the business model (financially) supports it … the business actions will continue as is…

> “Like you can’t see things changing unless the business model changes. There’s lots of talk about like companies need to be more responsible, and designers need to be even more responsible, and programmers shouldn’t be building software like this.” – Jason Fried

- Jason had a period of opting out of Instagram
- Felt as though his relationship with the media platform was unhealthy
- Deletes the app from his phone
- He is not opposed to social media…
- He uses  Twitter
- But Instagram is more comparative and supports an exhibitionist/voyeur dynamic for the user and external ‘world’

## Jason’s views on email and chat for communication [2:15:00]

> “Chat rooms are basically all day meetings with an unknown set of participants and many, many different topics all at once. And they’re basically virtual open offices and they’re running 24/7 and they’re terrible.” – Jason Fried

- Within organizations, Jason believes that chat message is worse than email
  - There is an expectation for immediate response
  - The format discourages taking time for consideration and writing out complete thoughts
  - The ‘tempo’ of an electronic environment may do more harm than good…
  - Rather than contemplative, chat message interfaces support a rushed mentality with little to no mental downtime

§

## Selected Links / Related Material

**Jason’s web-based product management service:** [Basecamp](https://basecamp.com/about) | (basecamp.com)

**Software Jason used**: [Filemaker Pro](https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwj_kt2csIHlAhUStsgKHQnbAm0YABAAGgJxdQ&ohost=www.google.com&cid=CAESQOD2SVzdbJEsd7GL7hiKhST90YoEPzSZ7dOGgmRE8KjHPxuOBJZ3kkR57Fdn6sCVAw0BuHZOV2NOBw0HGMu7zJE&sig=AOD64_1mDhe_bj7bv_u2gbmw8H23NfzLfA&q=&ved=2ahUKEwjX_dGcsIHlAhVvUt8KHd5SDcEQ0Qx6BAgREAE&adurl=) [11:30]

**An outdoor supply magazine Jason ordered from**: [Sportsman’s Guide](https://www.sportsmansguide.com/) | (filemaker.com) [16:45]

**Jason sold tennis rackets on commission in his first job**: [Yamaha Secret 10](https://tt.tennis-warehouse.com/index.php?threads/yamaha-secret-10.21981/) | (tennis-warehouse.com) [17:30]

**Jason studied finance at**: [The University of Arizona](https://www.arizona.edu/) | (arizona.edu) [24:30]

**Icon of successful business**: [Amazon Inc](https://www.amazon.com/)  | (wikipedia.org) [28:15]

**Peter’s post about how humans are not wired to think scientifically**:  [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/) | Peter Attia (peterattiamd.com) [30:30]

**A large-scale successful company**: [Apple Inc](https://en.wikipedia.org/wiki/Apple_Inc.). | (wikipedia.org) [34:15]

**A successful startup**: [Dropbox](https://en.wikipedia.org/wiki/Dropbox_(service)) | (wikipedia.org) [34:15]

**An example of a large company with perverse incentives that perpetuates unrealistic expectations**: [Uber](https://en.wikipedia.org/wiki/Uber) | (wikipedia.org) [55:45]

**An example of a large company with perverse incentives that perpetuates unrealistic expectations**: [Lyft](https://en.wikipedia.org/wiki/Lyft)| (wikipedia.org) [55:45]

**An example of a large company with perverse incentives that perpetuates unrealistic expectations**: [WeWork](https://en.wikipedia.org/wiki/WeWork) | (wikipedia.org) [55:45]

**Awarding software and website design**: [High Five Awards](https://highfive.com/awards) | (highfiveawards.com) [56:15]

**Website creator**: [Mosaic](https://mosaicvisuals.com/) | (mosaicvisualscom) [56:15]

**Web Browser**: [Netscape](https://en.wikipedia.org/wiki/Netscape) | (wikipedia.org) [56:15]

**A company Basecaamp did a mock redesign for as part of The Better Project**: [FedEx](https://en.wikipedia.org/wiki/FedEx) | (wikipedia.org) [1:01:30]

**For more on differentiating outcome from process check out a previous episode of The Drive with Annie Duke**: [#60 – Annie Duke, decision strategist: Poker as a model system for life—how to improve decision making, use frameworks for learning, and apply ‘backcasting’ to boost your odds for future success](https://peterattiamd.com/annieduke/) | (peterattiamd.com)  [1:04:00]

**Jason won an account with**: [Getty Images](https://www.gettyimages.com/) | (GettyImages.com) [1:10:15]

**On perverse company incentives in the pharmaceutical industry (Ranbaxy):** check out a [previous episode of the Drive with Katherine Eban](https://peterattiamd.com/katherineeban/) | (peterattiamd.com)  [1:20:30]

**Jason has published four books** **along with a fifth web-based published framework manual** [1:40:30]:

- [It Doesn’t Have to Be Crazy at Work](https://www.amazon.com/Doesnt-Have-Be-Crazy-Work-ebook/dp/B079WV79TK/ref=rtpb_1/130-0245629-5910000?_encoding=UTF8&pd_rd_i=B079WV79TK&pd_rd_r=d6d4135a-6ae6-4358-8848-e3436a128e49&pd_rd_w=cpvCm&pd_rd_wg=8n1nM&pf_rd_p=7775a5bd-b826-4387-ab97-911f28a0f0db&pf_rd_r=EQ21FTGY64YS8GB8AP6J&psc=1&refRID=EQ21FTGY64YS8GB8AP6J)  | (amazon.com)
- [ReWork](https://www.amazon.com/Rework-Jason-Fried-ebook/dp/B002MUAJ2A/ref=rtpb_1/130-0245629-5910000?_encoding=UTF8&pd_rd_i=B002MUAJ2A&pd_rd_r=0afb11b1-79dc-420c-aac4-d4795b4f7c5e&pd_rd_w=ygp8N&pd_rd_wg=Jrb3E&pf_rd_p=7775a5bd-b826-4387-ab97-911f28a0f0db&pf_rd_r=26NAG1NAQA3E0K60A5FJ&psc=1&refRID=26NAG1NAQA3E0K60A5FJ)  | (amazon.com)
- [Remote: Office Not Required](https://www.amazon.com/Remote-Office-Required-Jason-Fried-ebook/dp/B00C0ALZ0W/ref=rtpb_2/130-0245629-5910000?_encoding=UTF8&pd_rd_i=B00C0ALZ0W&pd_rd_r=d6d4135a-6ae6-4358-8848-e3436a128e49&pd_rd_w=cpvCm&pd_rd_wg=8n1nM&pf_rd_p=7775a5bd-b826-4387-ab97-911f28a0f0db&pf_rd_r=EQ21FTGY64YS8GB8AP6J&psc=1&refRID=EQ21FTGY64YS8GB8AP6J) | (amazon.com)
- [Getting Real: The Smarter, Faster, Easier Way to Build a Successful Web Application](https://www.amazon.com/gp/product/0578012812/ref=dbs_a_def_rwt_bibl_vppi_i3) | (amazon.com)
- [Shape Up: Stop Running in Circles and Ship Work That Matters](https://basecamp.com/shapeup) | (basecamp.com/shapeup)

**Jason’s father bought old watches from the 20’s**: [Elgin](https://www.chrono24.com/elgin/index.htm)  | (chrono24.com) [2:03:45]

**One of Jason’s first watches**: [Seiko Data 2000](https://www.vintagecomputer.net/browse_thread.cfm?id=725)  | (vintagecomputer.net) [2:04:15]

**Watch e-commerce site**: [Hodinkee](https://www.hodinkee.com/)  | (hodinkee.com) [2:07:00]

§

## People Mentioned

- [Mark Zuckerberg](https://en.wikipedia.org/wiki/Mark_Zuckerberg) (credited with creating Facebook) | (wikipedia.org) [25:30]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) (Principal founder of Microsoft) | (wikipedia.org) [25:30]
- [Steve Jobs](https://en.wikipedia.org/wiki/Steve_Jobs) (Apple Co-Founder)| (wikipedia.org)  [25:30]
- [Paul Allen](https://en.wikipedia.org/wiki/Paul_Allen) (Co-Founder of Microsoft)| (wikipedia.org) [28:15]
- [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) (Founder of Amazon Inc)| (wikipedia.org) [28:15]
- [David Heinemeier Hansson](https://en.wikipedia.org/wiki/David_Heinemeier_Hansson) (Basecamp Co-founder)| (wikipedia.org) [1:05:45]
- [John McFee](https://tim.blog/2014/12/11/john-mcphee/) (Princeton Professor in reference by Tim Ferris for succinct writing)  | (tim.blog) [1:28:45]
- [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett) (successful businessman investor; CEO of Berkshire Hathaway)  | (wikipedia.org) [1:59:45]
- [Eric Wind](https://www.windvintage.com/about) (watch collector who Peter and Jason know; formerly involved with Hodinkee) | (windvintage.com) [2:07:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/10/bio-jason-fried.jpg)

##### Jason Fried

Jason is the co-founder and CEO of [Basecamp](https://basecamp.com/), a project management software business, committed to building the best web-based products and tools with the least number of unnecessary features. He’s also the co-author of several books, Getting Real, Rework, Remote, and It Doesn’t Have To Be Crazy At Work.

Twitter: [@jasonfried](https://twitter.com/jasonfried)

Jason’s [books](https://www.amazon.com/Jason-Fried/e/B002MQ13PQ)