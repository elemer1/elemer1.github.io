# #294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu

**Source:** [https://peterattiamd.com/olavaleksanderbu/](https://peterattiamd.com/olavaleksanderbu/)

---

Olav Aleksander Bu is an internationally renowned sports scientist acclaimed for his coaching prowess with elite athletes spanning a diverse range of sports disciplines. In this episode, Olav delves deep into the intricacies of VO2 max and its profound impact on performance. They explore the relationship between VO2 max and ATP production, energy efficiency, and power, as well as the impact of low-intensity training on VO2 max. The conversation extends to Olav’s experiences pushing the boundaries with high-performance athletes and the data driven interventions he uses to improve performance. They also dissect the role of lactate threshold, discuss other important metrics to track, and explore the exciting possibility of utilizing a portable VO2 testing device as a practical alternative to traditional lab-based assessments.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/olavaleksanderbu/the_Drive_public.png)

Play

#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu

#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu

1x15s30s

0:002:33:43

## We discuss:

- Olav’s background, expertise in exercise physiology, coaching experience, and interest in the extremes of human capability [4:15];
- The processes of energy conversion within the human body and its implications for performance [9:30];
- Improving movement efficiency, and the importance of mindfulness in training to optimize performance [20:00];
- The relationship between VO2 max, power output, and endurance performance in different sporting contexts [34:45];
- How VO2 max is measured in the lab, and why it’s a crucial predictor of both lifespan and quality of life [44:45];
- Absolute vs relative VO2 max, the significance of functional threshold power in cycling, and the importance of longer duration tests for accurate assessments [54:00];
- Portable VO2 testing devices as a practical alternative to lab-based tests [1:05:15];
- The complexities of measuring ventilation and its impact on performance metrics like VO2 max and heart rate [1:15:45];
- Training interventions to increase VO2 max, and factors that impact performance outcomes [1:23:30];
- The respiratory exchange ratio (RER) and endurance sports, and how factors such as diet composition and exercise intensity influence RER values and performance [1:32:45];
- Science-guided training for versatile athletes: maximizing VO2 max, power, torque, and cadence in cycling, and the importance of incorporating diverse stimuli to enhance performance [1:41:00];
- Physiological limitations on VO2 max [2:02:15];
- The different energy systems used during work, and other things to monitor like VCO2 and heart rate [2:06:00];
- Lactate threshold and other metrics to guide your training [2:10:30];
- Analysis of a lactate power curve: exploring lactate dynamics in endurance training and performance [2:23:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Olav Aleksander Bu is an endurance coach, exercise scientist, engineer, and physiologist
- He is the head of performance for Norway Triathlon and is best known for coaching 2 of the world’s best triathletes: [Kristian Blummenfelt](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) and [Gustav Iden](https://en.wikipedia.org/wiki/Gustav_Iden)
- He also coaches the Norwegian olympic sailing team and consults for multiple world tour cycling and elite track and field teams
- In this episode we were only able to cover a fraction of what Peter hoped to cover
  - As we ended up going so deep on VO2 max and performance
  - It’s safe to say, this will be the first of several interviews with Olav
- In this interview, we look at the relationship between VO2 max and ATP production, efficiency, energy, and power
- We speak about the quality of low intensity training as it relates to VO2 max
  - How weight impacts VO2 max
  - Absolute versus relative VO2 max values
    - Why we maybe ought to pay a little more attention to the absolute numbers than just the relative (as Peter has typically done)
  - Different ways to test for VO2 max
  - Different ways to train to improve your VO2 max
  - Olav’s work with his athletes
- We also have a deep discussion around the role of lactate testing and its role in performance
- To put this into context, if you’re listening to this podcast, you’ve heard Peter go on and on about the importance of VO2 max
  - To really have the masterclass in VO2 max alone here is really worth the “price of admission”
  - We get into so many other nuances around different terms people have heard and sometimes confused
    - What’s the difference between lactate threshold 1 (LT1), lactate threshold 2 (LT2), and zone 2?
    - How are these actually measured?
- Even if you think you have no interest in doing the kind of deep testing that Olav does (or even the stuff that Peter does on himself), you’re still going to learn a lot about the physiology of this stuff
- During the course of this discussion, Peter learned about the [VO2 Master](https://vo2master.com/)
  - This is a portable VO2 max unit that Olav uses extensively with his athletes
  - Peter has heard of these types of devices in the past (not specifically this one), and it’s always with a bit of skepticism that he assumes these things can’t be that accurate
  - But during the course of the podcast and after Olav and Peter talked about this and Peter’s curiosity was peaked so much that he got one of these devices
    - Peter has been blown away by this device, and he considers it the single best investment he’s made in tracking
    - The accuracy is staggering
    - It’s remarkable that he can put this thing on, and go outside and do a workout on his bike (or on his stairmaster) and test his VO2 max on his own
  - This is one of the many nuggets that came out of this podcast

## Olav’s background, expertise in exercise physiology, coaching experience, and interest in the extremes of human capability [4:15]

- What we are about to discuss today fascinates Peter to no end, but more than that, Olav is someone who brings a level of expertise that is so high that it really allows Peter to engage at a level of curiosity that he rarely gets to

**Tell people who you are, what you do, and the types of athletes that you work with**

- Olav grew up on a farm on the west coast of Norway
- He had to participate in a lot of work at a farm when he was a kid against his will
  - He saw neighbors and others playing and he would would very much like to do that as well
  - A long time ago, he started to really appreciate all the hardship
- As a kid, he developed a very keen interest for technology and was extremely curious
  - He liked to really pick things apart and understand how things were put together
  - Fascinated about everything from the universe and rockets and so on
  - Living at the farm, he got the possibility to pick apart a lot of machineries and things to see how they worked
- Being with animals on the farm, he has a strong connection with animals
- As he started to grow older, he became very interested in things that were extreme
- Extreme sports is something that resonates a lot with him
  - There is probably no extreme sport that he hasn’t participated in on an okay level
- He earned a degree in electro techniques and went on to engineering
- He was not cut out for working 8-4
- He was more interested in entrepreneurship
  - He liked to build things in a new way, new things, solve things that nobody has solved before

***Extreme things fascinate him***

**An event happened in 2011**

- This was after he started his second company
- We had used a helicopter to get into the mountains
- Half of his family died on this trip, and it made a shift in his life
- He got even more into sports
- He began to combine the field of exercise physiology and his strength in technology, and he began research
- A lot of research happens in a laboratory setting where you are taking out components and looking at how it reacts, but rarely are we able to transform that back into humans in a way that makes the same difference
- He began to use technology to study elite athletes in the setting where they normally exercised, and he used that to continue to drive performance
- Today, 3 of his athletes hold records in triathlon: short course, long course Olympic medal, World Championship medal, short course, the Ironman World Championship, 70.3 and full distance from Kona and St. George last year
  - [Kristian Blummenfelt](https://en.wikipedia.org/wiki/Kristian_Blummenfelt), [Gustav Iden](https://en.wikipedia.org/wiki/Gustav_Iden), and Ken Jenina
- Olav always learns from them because he’s very curious about how they feel and how they perceive things
  - While there’s a lot we can measure with data, there’s still a lot of things we can’t measure
  - You need that context
- Today he’s building a company and scaling these companies using AI
  - The company called [Entalpi](https://www.entalpi.com/) uses large numerical models, large language models
- He likes physics ‒  [enthalpy](https://en.wikipedia.org/wiki/Enthalpy) and [thermodynamics](https://en.wikipedia.org/wiki/Thermodynamics) are fundamental laws that humans can’t escape
- On the other side of things, Olav works to coach coaches at the highest levels
  - Olympic level, world level

## The processes of energy conversion within the human body and its implications for performance [9:30]

- Peter remarks that the triathlete is a remarkable athlete in several levels
  - He/she must be very good in 3 disciplines that are related, but quite distinct
  - Different body types: if you look at the world’s best swimmers, the world’s best cyclists, and the world’s best runners, they actually have quite different physiology, depending on the distances they race and certainly different methods of training
  - The triathlete therefore has to be really respected because they have to be almost world-class in each of those things to be world-class in their sport and their physiology as a result of that is remarkable
- There are so many things that we’re going to talk about today, including temperature management, energy expenditure, energy consumption
- Peter wants to make sure that the listener is able to follow where we go
  - We’re going to get into some really serious weeds
  - We’re going to talk about [MCT transporters](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) for [shuttling lactate](https://en.wikipedia.org/wiki/Lactate_shuttle_hypothesis) out of cells and all of those things [in a future episode]
- As Peter and Olav are sitting here right now having a discussion, and their bodies are converting chemical energy into electrical energy, back into chemical energy
  - It requires the substrates of oxygen and hydrocarbons to do that

**Can you explain in a little bit of detail exactly what that process looks like for us right now as we’re sitting here under obviously a very low physiologic demand?**

- There’s a beautiful [metabolic map](https://biochemical-pathways.com/#/map/1) made by [Roche](https://www.roche.com/about/philanthropy/science-education/biochemical-pathways) (a medical supplier) which is still not exhausted
  - We are continuously learning new things we can add to this map
  - There is also a [second map](https://biochemical-pathways.com/cellular-molecular-processes) (signaling pathways)
- We have many ways that we can convert energy from the food we ingest (protein, fat, carbohydrates), we store in our body and then we convert to ATP
- [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate) is the main fuel source that different muscles in the body use and different functions in the body use to survive
- To convert those substrates into ATP, oxygen is required, and there are many, many different pathways

***The problem with this as well is that even though this is a field which we have studied quite a lot, we are still learning more and we don’t fully understand it still***

- Olav explains, “*If you dig too much into some of these different things that you start to lose track exactly of how do you increase performance of somebody.*”
- To use another example, today we use smart watches
  - Information is derived from  movement from your wrist and it’s based on [HRV](https://en.wikipedia.org/wiki/Heart_rate_variability)

**But what is performance?**

- If you say the telemetry, it goes back to thermodynamics or fundamental  loss
  - On the one side, humans need to move
    - As they are sitting now in chairs, they’re moving around, gesticulating with our hands, nodding our heads
  - Movement requires energy
- You can track movement and quantify it in cm over a day for each of the components
  - Or globally when we’re running

***The currency of energy for our muscles (or anything in the body) is ATP***

- In order to create ATP, we need different substrates to be broken down for combustion to take place, and we need oxygen
  - Most people probably remember the fire triangle where you need oxygen, temperature, and something to combust

***Measuring oxygen is probably the most practical way today to measure exactly how much energy we are using at any given time***

- We can then start to break this down to try to understand how much ATP is released, or what the energy yield is from that amount of oxygen
  - This is highly variable in humans as elite athletes are typically very efficient and the normal population is probably less efficient at
- Olav works to *not* lose track, and he has a large team that is extremely good at this
- One of the researchers Olav works with was just recognized as the #1 researcher in the cycling world this year
- They are digging a lot into everything from enzymatic activities to how energy is being released and so on
  - How can we do this better?

**One thing Olav has found much more useful is that sometimes we need to just “black box” this and remember what is important there**

- We know movement (being able to move) is the most important part to humanity
- If we can sit at work, afterwards have an energy surplus that allows us to come home and move around with our kids and play and be kind to wives and help them out at home and so on
  - That’s a situation we all feel good with

*The question is, how do we do that stuff? How can we track different parameters to understand how we can get there?*

- This is where Olav looks at humans as an engine/ machine
  - There’s fuel and energy input
- Using cars as an example
  - You can look at oxygen consumption
  - You have power
- In cycling people often use a power meter, but it’s not that important because the output from cycling will be distance per time

**One thing seen in people who train at a high volume versus a low volume**

- Often people who put in a *lower volume of training* need to expend a higher oxygen cost/ higher calorie cost for them to move a certain distance (do a certain amount of work)

**Measurements to capture efficiency of an athlete**

- Olav is fascinated about breaking down things into the smaller details, but the problem is that we have a limit to how much time we have available
  - And then how do we then make sure that the interventions we plan are the best?
  - How can we then quantify what it has in effect?
- The ultimate measurement of this is **distance per time**
  - In order to understand what mechanisms are actually happening here now, we can measure using **power** meter technology
- We can ask: is it biomechanically driven? (are you improving your biomechanics?)
  - You can look at power and telemetry and ask: is the biochemical part improving
- You can decide to say, “*Okay, we ‘black box’ it, we don’t necessarily need to understand it because we can see whether things are improving or not improving*.”
  - If it does improve, continue to do more of it
  - If it doesn’t improve, then use specialists to dig deeper and try to understand exactly what is happening on a deeper level

**Peter’s takeaway**

- The metric that matters is velocity (distance per unit of time)
- If you’re a runner, if you’re a cyclist, if you’re a swimmer, if you’re a triathlete, the winner and loser is determined by velocity, not power output, not any other metric
- Obviously, there’s a very strong correlation between power normalized to weight and velocity, but it is not one-to-one
  - For example, in a triathlon or a time trial where aerodynamics matters significantly, you can have people that put out more power, but they create more drag
    - That’s very true in swimming as well
  - In running, velocity is king
- Peter likes the way Olav broke it down into 2 drivers
  - 1 – How efficient are you at using the energy source to make ATP?
    - What is your loss ratio there?
    - Presumably the majority of that energy is lost in the form of heat
    - Peter remembers using a 1 to 5 ratio where you take the number of kJ divide by 5, and that was approximately your energy expenditure (very crude)
  - 2 – You also have to be equally focused on your mechanical efficiency

*Is that a reasonable synthesis of what you just said?*

- Yeah
- It helps if you look at the mechanical part and split that between power and velocity
  - Then you can say that one component is the biomechanical part, but another part is the work economy where you look at equipment (for example aerodynamics)

## Improving movement efficiency, and the importance of mindfulness in training to optimize performance [20:00]

**Peter shares a funny example**

- 10 years ago, back when he used to ride a bike and the only event he would do was the [time trial](https://en.wikipedia.org/wiki/Time_trial), he had 2 training partners that were much better than him
  - They were collegiate cyclists
  - We used to do this workout every Saturday, which was an 80 km ride on a time trial circuit, closed off, it’s flat
  - Each loop was maybe 7-8 km
  - We would not allow ourselves to go over 200 watts
    - We had a power meter and the [SRM](https://www.srm.de/) will tell you exactly what your wattage and your average wattage is
  - And each week we would see if we could get faster and faster while keeping the wattage at 200
- Peter explains that 200 watts is not a lot of watts, so it was not hard to hold that for the 80 km
- Over the span of a year, we were able to increase our velocity from maybe 20.5 mph to maybe 22 mph
  - Which is a very significant improvement in efficiency

**How much of that do you think we did by getting better in our CDA (coefficient of drag times frontal surface area), it didn’t require new equipment, then how much of that do you think we did metabolically?**

*In other words, we metabolically got better at turning energy into power*

- Olav explains that when you have a power meter, you don’t know the **metabolic efficiency**
  - They didn’t have the VO2 data and have no idea how the oxygen consumption changed over that year
  - So that’s not part of the equation
- But, if you look at the **work economy**
  - A power meter on a bike (like the SRM) only measures net mechanical power ‒ only the component of power that actually goes in the direction that you are moving the crank arm
  - Of course already there are 2 components, and that’s where the difference between *net mechanical power* and *gross mechanical power* comes in
  - ***There are several ways to produce 200 watts***
    - You can have a very large intracyclic power
- Peter qualifies their goal: to keep average power and normalized power the same, so no bursts of power
- Olav explains what most people don’t realize is that when your power meter shows 200 watts and you keep it super steady there, you actually have inside 1 second (or 1 revolution) a **variation of power**
  - You will have peak power production
  - He would not be surprised for some people riding at 200 watts to be pushing 1,000-1,200 watts at peak throughout every single revolution
  - This is something we already quantify by the power meters, but we don’t have to focus on that part here because you’re measuring the locomotive part of the power component

*Olav explains a couple of things*

- 1 – You are already riding at a power output that is very comfortable, and when you want to work on your economy you have already excluded the biomechanical part
  - Since you are not looking at the difference between gross mechanical power and net mechanical power
    - We already said we don’t care about the biomechanical part
  - We are only looking at what is transferred into forward propulsion (or velocity)

***What is important and undervalued is that the harder we go, more of our oxygen and blood will be prioritized toward driving the muscles forward***

- 2 – Is cooling
  - Peter hit it spot on when he said there is 20% efficiency, 80% heat
    - 20% is what you see in elites not average people (we’ll come back to this)

**There is no better setting to be focused on this than when you ride at a bit lower power**

- It allows you to apply a mindful and cognitive presence to your movement and how you are in the bike there and everything there
- This is something Olav often sees as a difference between the specialists and the triathletes because the triathletes are much more inclined to solve task with brute force than the specialists are
  - The specialists simply have more time on lower intensity, and they tend to build a better feeling for how they’re moving through the landscape more efficiently
- You lock at 200 watts and it becomes so measurable because you can start to evaluate what is happening with your velocity as a function of that
  - You may see that you are creeping down a bit with your head and feel these nuances
  - When you go in a wind tunnel, it’s a spot picture of exactly he position you’re holding for the moment
    - Obviously, part of that is looking at the aerodynamics of an athlete
    - The problem is, the moment you take that athlete off the bike and put him on the chair and ask him to go back into the position, if he doesn’t have an outline in front of him that tells him exactly the position to be in, that can already start to offset any other margins that you’re looking to gain from (clothing for example)
- In order now to evaluate clothing on an athlete (and not on a dummy or a doll), the problem with that is if you go off the bike and come back on again, you won’t have the same position unless you have an outline that you see that you’re fitting yourself into
  - You haven’t gotten the time to rehearse your position and actually start to feel and get aware about your whole body position there
- This is completely the contrary to when you’re riding 200 watts
  - You’re riding at a power output that allows you exactly to have that cognitive access to evaluate yourself, feel yourself, be aware of the surroundings, and everything there, and you are basically programming that into your backbone for “this is the position”
    - So when you go out in a race, you have trained that position so deep into your body that you can almost do it blind
- Peter thinks Olav is spot on
- Peter thinks that 5% improvement came almost entirely through frontal surface area
  - As Olav said, this ride is so relaxed, it’s not a hard ride, and this means all your cognitive reserve goes into wiggling your way into: how narrow can I get my shoulders?
    - What’s the best position of my knees on the top tube?
- It’s also interesting that it’s a luxury that the one-sport athlete has because at the time that was the only thing Peter competed at
  - He thinks a triathlete would have a harder time justifying that

**Do you think a triathlete would benefit from doing some of that kind of training that seems sort of like junk mileage because it’s so low in intensity?**

> “*It becomes junk mileage when you’re not mindful*”‒ Olav Aleksander Bu

- A lot of people will talk about a “high quality” workout as being a high-intensity workout

***Olav thinks that low intensity, medium intensity, and high intensity should all be high quality. All of them should be mindful workouts because you can use them for different purposes.***

- When you’re doing the **lower intensity workout**, you have the cognitive reserve to use your senses to give you better biofeedback and learn better what you can improve
- With the **higher intensity workouts** you are focused more on surviving instead
- Olav thinks this is most evident in swimming
- In cycling with triathletes, we see that because of the movement pattern, there are very few degrees of freedom when you are sitting on a bike
  - The best triathletes in the world are close to or on par with the best cyclists in the world
- In running, this of starts to become a little bit bigger difference between them simply because now you start to allow for a little bit more degrees of freedom

**Swimming is the worst**

- This is where you have so many degrees of freedom and so poor feedback while you need to have a very good spatial awareness of your body and what you’re doing there in order for you to utilize your oxygen for maximum propulsion
- For example, we were in the [flume at Tenerife T3](https://www.tz-leipzig.com/swimming-flume-tenerife-t3.html)
  - This is not like a countercurrent pool where there’s a jet sitting in front of you and pumping some water
  - This is a full-fledged wind tunnel where water is circulated in a full cross-sectional area around in a huge circle that is basically 3 meters wide, 1.5 m deep, 5-6 m long
  - It’s a cross-sectional area of water passing over you like you were in an endless ocean
  - Water quality is perfect, there’s no turbulence, just pure water running past

Peter asks, “*Is the athlete able to swim in place? It’s not like an* [*Endless Pool*](https://en.wikipedia.org/wiki/Swimming_machine#Volume-driven_machines) *where you’re being blasted with 5 mph current 2 ft from your face. You’re out far enough in the pool that it just feels like you’re in the ocean and you’re not moving, but you’re using a natural stroke?*”

- It looks very similar to a wind tunnel
- Basically what happens here is that you’re laying in this tank and the water is just passing
- You can set the speed in the same way as you do with an Endless Pool or countercurrent pool
  - For example, you set the speed to 1.5 meter per second and you jump in and you’re just swimming there and whether you go left or whether you go right or forward or back, the current is exactly the same here, there is no turbulence anymore

*Olav took a gold standard metabolic cart and we basically made an apparatus that allows them to use this while they are swimming*

- They are able to measure the ventilatory rate of oxygen consumption and carbon dioxide production
  - The fuel consumption of the “car” and the exhaust

***We know that*** [***Kristian***](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) ***and*** [***Gustav***](https://en.wikipedia.org/wiki/Gustav_Iden) ***have an equally high or higher VO******2*** ***max than elite swimmers in the world***

- So a bigger engine than the best swimmers in the world, the people are winning gold in the Olympics
- Peter rephrases this, “*When you push the speed high enough to the point where they reach the maximum amount of oxygen that they’re going to be able to consume… we always know that the bigger that number (the bigger the engine), they do more, they are able to consume more oxygen and put more calories to work than the world’s best swimmers*.”

**Why are Kristian and Gustav not as fast as the world’s best swimmers?**

- Olav had the bronze medalist from the Olympics swimming in the flume
  - He’s 1.95 tall and weighs > 90kg ‒  a massive guy with a lot of muscles
- He goes into the flume, swims at the same velocity as Kristian is doing and is using almost a liter *less* of oxygen
  - At that point, that was close to 25% less oxygen
- What we know is the more muscles you have in the body, the more oxygen you can also consume
  - Because if you have almost no muscles, there won’t be a lot of oxygen consumption because it’s mainly the muscles that are using oxygen during exercising
  - When you have an athlete that is massive, you would assume that he’s also using a lot of oxygen because there’s a lot of muscle involved
- But because he is so efficient, he actually swam at the same velocity with almost 25% less oxygen consumption than the best triathletes in the world

***That is mind-boggling, but it tells how important movement efficiency is for this whole equation***

- As a former swimmer, this does not surprise Peter
- He didn’t swim until he was 31 years old (almost 20 years ago), and it never ceased to amaze him, even when he was at his fittest on the bike (his VO2 max was >5 L) how people with seemingly such a lack of fitness could destroy him in a swimming pool
  - These people were technically so superior that he could consume 5 L of oxygen and they would consume 3

**Olav explains, “*****That’s where exactly being mindful using that cognitive reserve, not to do junk miles, but doing really mindful miles in the pool, on the bike exactly like you did, it’s so important, but very undervalued and it could have been used so much better.*****”**

## The relationship between VO2 max, power output, and endurance performance in different sporting contexts [34:45]

- People on this podcast have heard Peter say over and over again, “*VO**2* *max is the greatest predictor of lifespan*.”
  - Whether you smoke or don’t smoke, have diabetes or don’t have diabetes, whether you have end-stage kidney disease or heart disease or hypertension or all these things that play an important role in predicting the length of your life
  - VO2 max rises above every other biomarker we have to predict the length of life
- The reason Peter argues that that’s probably the case is that VO2 max is an exceptional **integrator of work** that is done
  - For the few times he has patients that will tolerate the mathematical equation, he would say loosely speaking: VO2 max equals the integral from T1 to T2 of work as a function of time DT
- And we know that that work is very valuable for your health
- We can quantify why it is that exercise helps you live longer
  - Why is it good for the brain? Why is it good for the heart? Why is it good for the immune system?
- VO2 max becomes a very reproducible way to document that work and it can’t be changed quickly
  - It’s not a cheap biomarker like vitamin D, where you can just take a bunch of vitamin D supplements and immediately change your vitamin D level

**With all of that said, when we get into the minutia of exceptional human performance, VO****2** **max is not the best predictor of performance**

- Let’s put swimming aside because it’s so obvious there

*Why would VO**2* *max not be the best predictor of performance in something like cycling for example, or running where the aerodynamic contribution in the case of cycling is easier to mitigate (still nowhere near as bad as swimming) and where the efficiency maybe isn’t as important?*

*Where do we see VO**2* *max not become the most important driver of endurance performance?*

- Olav agrees that VO2 max is probably the holy grail for understanding longevity or the best metric we have to quantify it
- To elaborate, you can also say that VO2 max is a measure of something
- Some people would say that having a good heart is a good predictor of longevity, but you can probably find people in bed that are really sick, that still have a good heart
  - You understand there has to be more nuances to this than just the heart itself
  - For example, a person with a good heart and good lungs can still have neurological disease
- All of these will limit you from reaching a high VO2 max, which again is so integral
- So why doesn’t VO2 max become a very good predictor of performance in cycling?
- Olav would argue it does, but then we are also starting to reach some **more limitations**
- You want to have as a high VO2 max as possible, even as a cyclist
- We are now facing some other problems when you are an elite athlete, and that is something we call “[maximum sustainable energy expenditure](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6551185/)”
  - To turn around more calories per time, that means that over time you will use more calories
  - In order now to support growth, you have to input more calories
    - Because you’re burning more, you need to bring more in
    - Otherwise, you start to run into deficit and in the worse case, end up with problems
- If we want **a good proxy surrogate metric for VO****2** **max**, we typically make an athlete run all-out for 1-5 minutes
  - Not too short, but not too long
  - Peter thinks 4 minutes is a good spot (Olav agrees)

***What we have to understand: you don’t need to be the best 4-minute athlete to win the Tour de France***

- This is more important for track cyclists
  - Then VO2 max maybe becomes the best predictor of performance again
    - It’s a little bit depending on context
- We already said there’s another limitation and that is the **maximum sustainable energy expenditure**
  - How much energy can you expend on different intensities in order to increase the speciality of what you’re going to be good at
- If you are going to be best in the world riding 160 km and then sprinting towards the finish line over a couple of hundred meters
  - You can even not argue that it’s a sprint even, but let’s say you are really going fast the last kilometers
  - The problem with this is that if you spend most of that energy that you have available now to increase your VO2 max, you’re spending less time on specializing what you’re really going to be good at
- You won’t find a track cyclist that you can put into Tour de France and think that he will win Tour de France, and you won’t find a Tour de France rider that you can put on a track and become the 1 km winner
  - Because they’re specializing on 2 different durations

***Simply because we have a limitation for how much energy that we can turn around per day, per week and so on sustainably***

> “*That’s the key here: sustainably. It basically means also that we have to focus more on that exact specificity that we’re looking to excel in*.”‒ Olav Aleksander Bu

- Then yes, VO2 max will still be the best predictor but not necessarily having the highest number
- That is the nuance to it

**Let’s stay with cycling and keep it simple and** ***not*** **include track cycling (which is far closer to an anaerobic effort)**

- Going back to the distance of the 112-mile time trial that a triathlete is doing in an Ironman
- For the most part, there’s no sprinting in there
  - He’s not sprinting at the very end
  - He’s probably trying to keep his effort relatively constant to prepare himself/herself to do the marathon run that’s following

*If there are 2 athletes that have the same VO**2* *max, does* ***power at VO******2*** ***max*** *give you another layer of insight?*

- Yes and no
- This is where you can “black box” a little bit
- We just talked purely about VO2 max focus on that

***There will be a fairly good correlation between oxygen consumption at VO******2*** ***max because you could argue that there’s really no power at VO******2*** ***max as long as you are above what we call “VO******2*** ***steady state”***

*You have a couple of different steady-state scenarios*

- One that a lot of people knows about is the [maximum lactate steady state (MLSS)](https://bmcsportsscimedrehabil.biomedcentral.com/articles/10.1186/s13102-024-00827-3)
- Above there you have something called **VO****2** **steady state**
- The moment you start to exceed your VO2 steady state, then it’s basically just a matter of duration before you will elicit VO2 max
- Olav explains, “*The closer you state your VO**2* *steady state, the lower the power you will [be] basically outputting*.”
- If you put out too high a power, you won’t be able to reach VO2 max because you’ll not be able to contract your muscles efficiently anymore, and you won’t be able to bring your ventilation or oxygen consumption up to a max

***There’s a sweet spot more or less where any power that sits between VO******2*** ***steady state and a higher power number will elicit VO******2*** ***max***

- It’s the amount of duration that is needed in order to get there, and this adds uncertainty because you need to know this
- Olav thinks it’s important that the listener understands that you can’t necessarily just go out and start talking about power at VO2 max and VO2 max because people will get confused because you have to know what was the **duration** of it as well
  - You have to know: how did you get there?

## How VO2 max is measured in the lab, and why it’s a crucial predictor of both lifespan and quality of life [44:45]

- Peter believes this is a test every human being, athlete and non-athlete, should have done because everybody needs to know their number and everybody needs to know where they stack up against people their age and their sex
  - It’s the most important modifiable metric we have to speak to both the length and quality of life

**If Peter came to Olav’s lab to have his VO****2** **max measured, what would we do?**

- Olav explains that metabolic measurements are being democratized
- We work very closely with a Canadian company called [VO2 Master](https://vo2master.com/) that allows you basically to put now a mask
  - Olav compares it to the old age when you had these big computer towers to having iPhones and Androids today that exceed the computational power of the [Apollo 11 expedition](https://en.wikipedia.org/wiki/Apollo_11) by a million times
  - The same thing is happening to metabolic analyzers: they are moving from being exclusive to labs to being democratized with a portable analyzer that sits on your face measuring oxygen uptake

*In the lab setting*

- Olav doesn’t work so much with relative values, but a lot of people do
- We’ve got to measure your weight to normalize to kilograms
  - For example an [Kristian](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) (an elite athlete) is 80 mL/min/kg
- What they do in the lab depends on what kind of modality that’s important to you
  - If it’s running, you’ll use the treadmill, and there are a couple of different ways to do this
  - The method is pretty much the same, but it uses different gear
- Some people will use what we call a “mixing chamber system” and some people will use what we call the “breath systems”
  - It involves having either a mouthpiece in your mouth where there sits a turbine with a sample line from it so that when you’re exhaling in this mask (or through this mouthpiece), we are measuring how much air you are breathing in and out per time
  - If it’s a turbine, we correlate it to how many RPMs this turbine is spinning out
- We know whether you are breathing for example, 50 L/min or a 100 L/min
- But we only measure your ventilation
  - We don’t know anything about your oxygen consumption yet
- Then what we also need a sample line that sticks in there
  - That basically collects the concentration of oxygen and carbon dioxide
- We know that the **ambient oxygen condition and ambient CO****2** **conditions** are roughly 20.9% oxygen and 0.05% CO2 (more or less roughly speaking)
- While you are running, you’re breathing in a certain amount of oxygen into your lungs (20.9%) and then you’re consuming some of the air into your lungs
  - Only about 25% of the oxygen you take into your lungs is being transported through your body
  - You’re exhaling roughly 75% of the oxygen
- Since we are measuring the oxygen concentration with this device, we know the delta between the oxygen concentration that goes in and the oxygen concentration that goes out
- We also measure the volume of air and can now extrapolate the amount of oxygen you’re actually extraction and your oxygen consumption

**Why is oxygen consumption important?**

- This comes back to [calorimetry](https://en.wikipedia.org/wiki/Calorimetry)
  - The [calorie](https://en.wikipedia.org/wiki/Calorie#Definitions) is a unit for knowing how much energy is needed to heat water from 14 to 15 degrees
    - It comes back to the fire triangle: you need something to combust, you need oxygen, and you need temperature
- There’s a field in chemistry called [stoichiometry](https://en.wikipedia.org/wiki/Stoichiometry)
  - Take carbohydrates, we know how many atoms of carbon, hydrogen, and oxygen there are in each molecule of carbohydrate
  - We want to convert this into ATPs
- If you look at [glycolysis](https://en.wikipedia.org/wiki/Glycolysis), we are taking glucose (C6H12O6) and we’re breaking that down into 2 pyruvates (C3H4O3), and at the same time this process is releasing ATP
  - In the process of releasing ATP, we are also releasing hydrogen ions
    - This is when you feel a burning sensation in your muscles
- [Lactate](https://en.wikipedia.org/wiki/Lactic_acid#) is actually a superfuel (C3H5O3)
  - If muscles have access to both lactate and glucose, they will prefer to use lactate
  - Lactate lacks 1 hydrogen molecule compared to lactic acid, and as long as you have an excess of this then you can bind back that hydrogen molecule and get C3H6O3 [lactic acid]
- You split 1 molecule of glucose into 2 molecules of lactic acid [[anaerobic glycolysis](https://en.wikipedia.org/wiki/Anaerobic_glycolysis)], and there is a certain amount of energy (or joules) that is released in the process
  - Forget ATP and simply consider: what is the potential joules that sit in a glucose molecule?
    - Then when we split this glucose molecule, how many joules are we releasing?
- With glucose (C6H12O6), we know there are 6 oxygen molecules
  - We know your oxygen consumption
  - And with stoichiometry we can calculate how many joules has been released in this process, and that ties back to VO2 max
- The more oxygen you are capable of turning around per time
  - The more calories or the more fats, proteins, carbohydrates, you are able to break down and release energy that you can use for the propulsion in the process

***The holy grail metric of VO******2*** ***measurement: the more oxygen you are capable of turning around per time, the more energy you are able to release for use in propulsion***

***Indirect calorimetry measured with VO******2*** ***max is a superior method to understand how much energy you are able to release in this process***

- Direct calorimetry is intrusive to measure and impractical

**To come back to the field of medicine**

- Having a *low VO**2* *max* means that the moment you start to have stress or get an infection, you are utilizing a much higher percentage of that ability to get healthy
  - You need energy to get healthy
- For an athlete that has a huge VO2 max, when they become sick, there is a relatively small chance in their capacity (or reserve) that is now utilized to get better
  - The moment they reduce their training volume, they get a huge excess of energy to recover
  - They have so much energy access to aid in the recovery process compared to a person who has so low a VO2 max that even walking up the stairs [is difficult]

**Peter thinks that’s such a great point and people don’t fully appreciate what a significant physiologic stress illness is**

- If you do the chemistry on what it takes to raise the body’s temperature from 98o Fahrenheit to 103o F, that is an enormous energy cost
- When we look at cardiac patients, when we look at any patients in the ICU and you look at the change in cardiac output that might be required to support a systemic inflammatory response syndrome, it is profound

***It really comes down to just having more reserve***

## Absolute vs relative VO2 max, the significance of functional threshold power in cycling, and the importance of longer duration tests for accurate assessments [54:00]

**You mentioned that you prefer to look at VO****2** **max in absolute terms**

*How much does Kristian and Gustav weigh?*

- Peter thinks those guys probably weigh 75 kilos
- Leading into the Olympics, Olav and his team looked at what happens when they tried to reduce the weight very conservatively (by global standards in sports)
  - They had it ingrained in their heads that, “*You need to bring up your relative VO**2* *max,*” and this is done very simply by reducing weight

***Interestingly, they found by accident after doing this a couple times that the relative VO******2*** ***max didn’t come up and the absolute VO******2*** ***max came down even more that the weight came down***

**Peter uses some numbers because he wants to make sure people understand this**

- Hypothetically, if they weight 80 kg and their maximal oxygen consumption is 6 L, you take 6 L (or 6,000 mL) and divide by 80 to get some #
- If you reduce the body weight to 75 kg, you have a much bigger number
  - All things equal, we’re much better
- The problem is that all things are *not* equal

***That 6,000 mL of oxygen might’ve come down to 5,500 mL, and now that ratio has actually gone down***

- Exactly and Olav points out that both the absolute and relative have actually gone *down*
- It’s a little bit shocking and we have a lot of theories to explain why this is happening
- Why do people still cling to this idea of reducing [weight]?
  - When you come up to a certain level, and this guy/girl responds to your training and starts to win championships
  - The training is perfect, but it is ingrained that the next step is to reduce the weight to make them more powerful

***When you reduce the weight VO******2*** ***max starts to come down, absolute and relative values start to come down***

**Does that happen because you’re unable to control where you’re taking the weight off?**

*For example, are you disproportionately losing lower body mass which is disproportionately contributing to VO**2* *max relative to the upper body?*

- No, unfortunately it is more complicated than that because it is without even losing muscle mass

*Is it related to basal energy expenditure?*

- Peter reasons that if your total body mass is coming down, your [basal energy expenditure](https://en.wikipedia.org/wiki/Basal_metabolic_rate) is coming down, and that is probably altering fundamental metabolic pathways at rest that must be translating to what’s happening under stress
- Olav thinks most probably, yes
- This is something he hasn’t had enough time to dive into because he’s looking more to drive performance

*Peter proposes an interesting experiment*

- Use [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) under the weight reduced setting compared to the previous setting
  - You could do indirect calorimetry during rest and see if that drops proportionately to the drop you saw in VO2 max absolute
  - You wouldn’t be able to get total energy expenditure (which is what you want)
- Olav proposes that you may think maybe this is just a temporary phase before you stabilize the weight, and then at some point it would start to come up again
  - But it doesn’t either
- He has spent a fortune on doing doubly labeled water studies and it’s a nice method, but it has several pitfalls
- What he has started doing lately is [resting metabolic rate](https://en.wikipedia.org/wiki/Resting_metabolic_rate)
  - Using a portable metabolic analyzer (like the [VO2 Master](https://vo2master.com/)), it allows us to do measurements before dinner and after dinner
    - Just to look at the foods
    - We do it after training to see what happens there
- Sometimes we even see it dip below normal resting levels, and we can only theorize what that is happening
- There are a couple of mechanics that we need to control and become better at

**Why Olav uses absolute values not relative values for VO****2** **max**

- Gustav weighs 73-74 kg
- Kristian weighs 80 kg and he’s 175 tall ‒ he’s a muscular guy
  - You also see that he has a little bit of extra fat on his body compared to what you would expect for an elite athlete
  - But what matters is performance
- When you make things relative, if you look at a power number
  - Let’s say 2 guys are producing 6 watts/kg, but everything equal, 1 guy is moving much faster
    - Aerodynamics would be equal to everything like this
    - The problem is that the raw power from a bigger guy that has 5 W/kg is much higher power, and with aerodynamic the same, he will move much faster
    - The same goes with VO2 max

***If you look at VO******2*** ***max relative values, and want to look purely at propulsion, you have to look in absolute terms instead***

- Because most of the racing that is being done today is not very hilly
- If it starts to become very hilly then relative values may give a better predictor of performance than absolute values

**Functional threshold power**

- In cycling, especially in the Tour de France, Peter has heard it stated that you can predict who would win the tour (absent a strategic blunder or an accident) by [functional threshold power [FTP]](https://www.bikeradar.com/advice/fitness-and-training/what-is-ftp-and-why-it-matters-for-cyclists) in watts per kilo
  - This data is a bit confounded because there were 2 decades of cycling when EPO was widely used by every top cyclist (but that still normalizes)
  - If you could know how many watts a cyclist could hold for 60 minutes divided by their weight, and you line those up in descending order, all things equal, that was going to be your championship finish
    - Of course, it’s never exactly equal, because you can make a strategic blunder, there can be an accident, lots of things can happen
- Peter supposes that’s not surprising given the vertical nature of the Tour de France: it is mostly won in vertical distance, not horizontal distance
  - Olav agrees

***Olav thinks when you take 60 minute power and divide it by kg to make it relative, that is a fairly robust metric***

**The problem is that people often use much shorter durations**

- If they use 8 minute power or 10 minute power, it’s a very different bet
- If you extrapolate that and still call that functional threshold power, and you divide it by your weight, what we don’t know is how much of that energy comes from [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) and how much comes from [glycolysis](https://en.wikipedia.org/wiki/Anaerobic_glycolysis)
  - This is especially true for shorter durations of time

*Peter wants to make sure people understand this point*

- This is more dangerous metabolically
- If you’re doing this analysis based on 5 minutes, what if during that 5 minutes 80% of the energy was glycolytic?
  - That’s producing a lot of lactate and the hydrogen that comes with that is going to paralyze you (lactate is great and we’ll come back to that)
  - You will not be able to tolerant that for 90 minutes or even 60 minutes
- But if you push the test out to 60 minutes, you can’t fake it because you will not be able to do an 80% glycolytic effort for 60 minutes
- At 60 minutes, it becomes a really good predictor

***The 60-minute power is an extremely precise way of describing your capabilities because then you have a single point (or 2 points), you have a duration that you’re capable of holding that power, and it gives you a fairly good idea of the level of the athlete***

- If you start to have 2 data points, maybe you ask also, “*What is your 5-minute power?*”
  - Now you’re starting to get some slope as well and can understand what characteristic is behind this athlete
- A **sprinter** will typically have a higher ratio between the 5-min and 60-min power
- A [TT](https://en.wikipedia.org/wiki/Time_trial) specialist will typically have a lower ratio between the 5-min power and 60-min power
- Back to the **maximum sustainable energy expenditure,** and why VO2 max is not necessarily a good predictor of performance for endurance events: because **specificity** becomes important there

***In general, Olav agrees with Peter that the 60-min power divided by kg is a good metric to compare athletes in the Tour de France***

- The athlete with the higher number is more likely to win
- Back in the heyday of oxygenated performance enhancing drugs, [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong), [Jan Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich) and these guys were able to put out 6.5 w/kg for 60 minutes [discussed in [episode #178](https://peterattiamd.com/lancearmstrong/)]
  - Today, people are only about to do 5.5 w/kg for 60 min
  - That gives you a relative sense of on and off these agents

## Portable VO2 testing devices as a practical alternative to lab-based tests [1:05:15]

- Twice now Olav has referred to a less technical, more portable indirect calorimetry device that what Peter is used to using in the lab during a VO2 max test
- Peter was under the impression that these portable devices are probably decent for measuring VO2 (the consumption of oxygen), but their accuracy is lacking vor measuring VCO2 (the production of carbon dioxide
  - Therefore it might be a good tool for estimating VO2 max but it’s not a great tool for estimating total energy expenditure (which is calculated by using VO2 and VCO2)

**Are there devices out there that we could be buying, that we could be testing ourselves on every month at home that would meet the criteria of being accurate enough in those domains?**

- Yes
- Olav thinks the accuracy of devices are starting to become fairly good
- He often does back-to-back testing between devices
- In the **laboratory**, he uses a mixing chamber system that is validated against many different methods
  - He still uses an old system: [JAEGER Oxycon Pro](https://www.ntnu.edu/documents/221360533/221362168/oxypro.pdf/91b256f4-97d7-4408-8eec-53869132a03d) with a mixing chamber system
  - He also really likes the [AEI MOXUS](https://aeitechnologies.com/moxus-modular-metabolic-system/), simply because it has some superior technologies in it compared to most of the other devices on the market
    - Most of the devices on the marker are using galvanic fuel cells to measure oxygen and then use infrared sensors to measure the CO2
    - The AEI MOXUS actually measures it using a zirconia instead, and the [zirconia cell](https://en.wikipedia.org/wiki/Fuel_cell#Solid_acid_fuel_cell) is one of the most sensitive cells we have
    - For example, if you want to look at [photosynthesis](https://en.wikipedia.org/wiki/Photosynthesis), you can’t use a galvanic fuel cell because it’s not sensitive enough while a zirconia cell is
- Portable devices now are using galvanic fuel cells
  - Such as the one Olav mentioned, the [VO2 Master](https://vo2master.com/)
- One of the benefits Olav and his team have is they entered into a partnership with VO2 Master to advance the technology
- Several years back, he did a screening of all kids of different portable metabolic devices on the market

*He needed to find a compromise*

- It doesn’t necessarily help to find a device that is a little bit more accurate than the VO2 master if an athlete doesn’t want to use it
  - If it has a rucksack and a lot of procedures
  - If it has a horrible user interface
- The strength of data does not come in using a device once or twice

***You need to measure regularly all the time, and it has to be done in a way that is not intrusive for the athlete***

**Tell me about the** [**VO2 Master**](https://vo2master.com/)

- You don’t need to plug your nose
  - The hallmark of measuring VO2 is you have to plug your nose and use a mask that creates a perfect seal so that it can measure the air flow rate in and out
- It uses a [Hans Rudolph mask](https://www.rudolphkc.com/shop) [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f1-olavaleksanderbu.png)

**Figure 1. Mask used for the VO2 Master**. Image credit: VO2Master

- Most labs are using these blue masks
- VO2 Master designed a device that actually mounts on this Hans Rudolph mask, and it does the same as you would with a metabolic cart in a laboratory
- It has galvanic fuel cells
  - There are maybe 5 manufacturers of galvanic fuel cells in the world that everyone uses, so it’s the same galvanic fuel cell in the VO2 Master
- The main difference between this device is that they have removed the turbine, and they’re using the same way of measuring flow that you do in Formula One and aerospace
  - They use differential pressure to quantify the flow
- The device is a headgear that just sits there
  - There’s no wires
- It connects to your phone, watch, whatever that you have, and this is how you collect your oxygen consumption

Peter asks, “S*o I could go out for a bike ride, if I’m going to go and do VO**2* *max intervals and hill repeats… wearing this thing?*”

- His favorite workout is the 4-5 minute hill repeat
- Then when he comes home, could he can see his peak oxygen consumption per each set?

- Olav explains that you can even connect it to your [Garmin computer](https://www.garmin.com/en-US/c/sports-fitness/cycling-bike-computers-bike-radar-power-meter-headlights/) and view it from your Garmin account
  - You can see your breathing frequency, tidal volume, your fraction of expired O2, your VO2
  - All the values combine there in the same together with your power, with your velocity, with your position, everything there in one place
  - It’s going to show heart rate versus power versus VO2 at every moment in time

**How accurately is it measuring VO****2** **relative to what you can do in the lab and how about VCO****2****?**

- Olav has had their device for VCO2 for almost 2 years now
  - They’ve been fortunate to be a little ahead of the curve and able to use the VO2 Master prototype
- Keep in mind, there are differences in the measurement of VO2 between devices
  - For example, in the [Oxycon Pro](https://www.ntnu.edu/documents/221360533/221362168/oxypro.pdf/91b256f4-97d7-4408-8eec-53869132a03d) there is the option to use it as a breath device or as a mixing chamber device
    - If you use it as a breath device, then you’re breathing straight through the turbine and there’s minimal resistance
    - If you use the mixing chamber system, then you have a 2.0 cm long hose and the breathing resistance now goes up a little bit
- As we know, breathing is not free either, your lungs need energy (ATP) in order to breathe
- The more resistance there is to breathing, the higher the oxygen consumption will be
- You can see with the exact same device (the same sensor) using a different method that there will be differences between the 2 machines
- Further, when you go out on the bike, you are creating a very high headwind when you are going fast, and you have to remember than any system that is based on measuring flow will now have interference from flow hitting the turbine/VO2 Master (or any metabolic device there)
  - That will start to influence the number a little bit

> “*We have to remember also that we are not really measuring the flow and we are not really measuring total oxygen consumption. We are inferring it based on methods that are basically saying that when we see that the turbine is rotating at this many RPMs per minute*.”‒ Olav Aleksander Bu

- We know that the RPMs per minute correlate to a certain thing
- So there will always be a little bit of uncertainty
- When you are in a **lab setting**, there is no headwind and you have very controlled conditions
  - You have the ability to get higher accuracy than out in the field
  - But we also know that what you do in the laboratory is quite far from what you do out in the field because you’re limiting the way your moving and cooling
    - A lot of things are different in the lab
- The question is always do you want accuracy of what you are looking at?
  - Are you just looking at oxygen consumption, and then you create an artificial setting which is not necessarily representable for what you’re doing?
  - It is a little bit of a give and take

**How much difference are you seeing in your athletes measuring VO****2** **and VCO****2** **in the lab versus using the mask out on the bike, doing 4 minute hill repeats where the velocity is not that high?**

- They’re probably still going 18-20 mph up a hill pushing a massive gear to hit that VO2 max
- When he does back-to-back testing between 2 devices for Kristian and Gustav, we see a difference of maybe 50 mL
  - Peter reacts, “*Really. That’s nothing…I thought you were going to say 500 mL*.”
    - If it were 500 mL, the device has no value anymore (that would be unacceptable)
- These guys have an absolute of 7 L
  - Understandably, it makes a difference at their level
  - But for most of the people listening, a 50 mL difference is less than nothing

***This is exciting because Peter was under the impression that these devices were still so far away that they were not worth entertaining the use of***

## The complexities of measuring ventilation and its impact on performance metrics like VO2 max and heart rate [1:15:45]

**Olav uses the mixing chamber system**

- A mixing chamber system has a little higher resistance, and typically we see a more stable breathing pattern because they’re being reminded more about exactly how they’re breathing (because they feel this resistance)
- What you see as a system gets less resistance is more variation going up and down

*Olav compares this to riding with a power meter for the first time*

- For a person not used to riding with a [power meter](https://en.wikipedia.org/wiki/Cycling_power_meter) who only looks at heart rate, when they use a power meter for the first time, the power goes all over the place
  - Because they’re not used to focusing on the power, and they don’t have the coordination/skills to keep it around a stable power

***Breathing is even worse than power because now you are one order further away from performance***

- Velocity is the first order principle, and that’s where performance happens
- Power is one step further away, and this system is very responsive to what you do
- Let’s say you are riding at 200 watts
  - If you went to 210 W/sec and back down to 190-200 W, you’re speed wouldn’t change at all
    - You’re velocity would be more or less the same, but you still have volatility there

**If you are using velocity as the gauge for whether a system is correct or not, you will always say this cannot be correct**

- You think if you go to 210 W, it should be immediately giving me this [increased velocity]
- How the velocity is measured is not necessarily good enough to capture small changes happening intracyclic in the power production
  - It’s smoothed out because of inertia, measurement, weakness, and so on
  - It gets even worse when you get to ventilation

**Ventilation ‒ we are measuring on the exhaust**

- Between where we are doing work and breathing in and exhaling out, there are so many compensating regulatory mechanisms in the body that are compensating for the lack in one place/ back and forth to make sure that we deliver energy as efficiency as possible to sustain propulsion
- When you are measuring VO2, you can have quite a bit of fluctuation and there are kinetics involved
- For example, if you are riding at a constant power of 300 W and you are consuming 4.5 L of oxygen
  - **If you hold your breath**, you can still output those 300 W but the VO2 comes down
    - Ventilation (or tidal volume and breathing frequency comes down), you start to feel something build up in your body, but you are still able to output those 300 W
    - At some point you are either forced to stop or you  have to start breathing again
    - At the moment you start breathing again, you have a huge depth in your body and will get a huge spike in ventilation (a huge spike in VO2)
    - When you break this down, that spike comes from a much larger tidal volume, breathing frequency comes up a lot, but also your fraction of expired O2 (the delta between how much oxygen you are consuming) is going to be much deeper than the 25% we initially said
    - Things are not reacting extremely quickly on the exhaust part and it’s almost like a PAD regulator where you are trying to bring this back to a stable setting
  - Your breathing comes down again, but you may still have a high VO2 and then suddenly VO2 undershoots a little bit because the fraction of inspired O2 comes up a little bit higher, but it’s not enough
- All of this is to say that you can maintain 300 W but have a lot of variations
  - Even from holding your breath while you’re sipping on your water bottle
    - That will influence your breathing and your VO2 for the next half a minute
- If you are swallowing (if you start to have a lot of spit), you are building a miniature depth that you will have to pay for afterwards
- Olav doesn’t like to make it standardized and say you can’t drink, you can’t swallow
  - You would have to be a machine, and that’s not who we are

**Comparing metrics of athletic performance to F1**

- Olav has alluded to F1 and that is Peter’s favorite sport
- As much as we can look at those cars and say they are the most remarkably engineered things with wheels that have ever been produced
  - Everything from these hybrid internal combustion engines through the chassis and the aerodynamics
  - Most people are shocked to learn that the aerodynamics of that car are such that it can drive upside down at 100 KPH

***All of those things are remarkable, but Peter still thinks we’re far more complex***

- Because at every element of that car can be modeled
  - There is an equation that explains every piece of it
- Whereas there is no equation to explain what Olav just described, and there’s an element of chaos in that [the human] system

**If you have a power meter, Peter suggests**

- If you have a heart rate monitor and a power meter, next time you’re on your bike, make a deliberate effort to change your ventilatory rate
- Vent a lot and vent a little and watch what the heart rate does even as you hold the power constant
- This is because that CO2 is very soluble, and CO2 is tracked by the brain very closely as a proxy for pH
  - The body is very particular about keeping the pH at 7.4
- As you slow down your ventilation rate and hold your breath and your carbon dioxide levels rise and your pH falls, you will see that **heart rate start to spike with no additional input in power output**
  - And of course the reverse is true

***It’s just a great example of what Olav explained, but it’s one where you can sort of be the guinea pig and watch it***

- Peter still gets a kick out of playing that game to see how much he can move his heart rate just by interfering with his ventilatory rate
- Olav adds, “*I think that that’s also why some people become better also and others not because I think that one thing that we very often tend to lose as we get older (or we go through different training) is that we lose that ability to play*.”

***Going out and playing is one of the best ways to learn what influences that and it also increases our awareness of that***

## Training interventions to increase VO2 max, and factors that impact performance outcomes [1:23:30]

**Elites are not necessarily perfectly calibrated**

- Some athletes, if you ask them to go and do a threshold workout or a workout with combined duration intervals between 60-80 minutes
  - That should be close to all-out, and they should be at exhaustion on the last interval
  - Some elite athletes are going to hard and they end up dropping power towards the end
  - Others go out a little bit too light and they have to go really hard towards the end to bring it up

***In both scenarios, if you were able to keep it at a very calibrated level, you would see that the total # of kilojoules you were able to accumulate would be higher than if you ended up going progressive***

- Or worst case, you end up going regressive because you went too hard in the beginning and were forced to come down towards the end

**What standard do you use?**

**For example, Peter loves doing VO****2** **max sets on a bike on a hill**

- He has a fixed distance that he rides
- It really depends on the wind
  - If he has a headwind, it will take about 5 minutes
  - If he has a tailwind, it could take 3:45
- It’s not an all-out effort because you want to be able to do it multiple times
- But it’s a very hard effort followed by about a one-to-one ratio of recovery
- He does a warm up, does this hill over and over, and it’s about an hour
- Peter has noticed that he typically ascends in power
  - He will start out at a very conservative power where he is not dead by the end, but by the last one he might be doing 10% more power than on the first set and he’s at his absolute limit

*How would you recommend that Peter change that if the goal is to maximize VO**2* *max and increase the engine size?*

- Should he be within 5% the whole way through?

***Olav points out that VO******2*** ***max is often confused with aerobic capacity when in fact it is aerobic power***

- We often “black box” the metric [FTP](https://www.bikeradar.com/advice/fitness-and-training/what-is-ftp-and-why-it-matters-for-cyclists) instead of saying 60 minute power, 20 minute power, or whatever
- What is really accurate when you say 20 minute power is that you can hold that power for that duration before you end up dropping too much

**With VO****2** **max, you’re measuring how much oxygen is used for an undefined time**

- We have normalized it as mL/min
- You can have a big range between athletes that have the same VO2 max
  - Some can do that for several minutes
  - Some can do that for let’s say, 1 minute

*The difference is time is important because we are looking to provide a stimulus to the body*

- If you go out and do 1 5-minute interval, then that’s the stimulus your providing
- If you do a VO2 max session for 90 minutes, this is one dimensional because we’re not talking about a single workout

> “*I think the most undervalued thing, which is not very sexy to talk about… is consistency. Consistency in the training over time*.”‒ Olav Aleksander Bu

- With consistency in training, you need to leave a little bit of reserve there
- The good thing with VO2 is that we’re measuring a quantity
  - Much in the same way when we talk about power versus work

*For example, when you do a VO**2* *max workout, you should go a little bit progressive*

- What happens is there is a priming effect happening in the body
- If you go out where you think that you maybe would be able to sustain throughout the workout, you might figure out that you still are able to go a little bit higher
  - At some point it’s the opposite
- Very often people think that when they’ve done VO2 max effort, then they’re basically done
  - That they won’t be able to repeat that
  - That they need 2 days of rest or maybe a week of rest before they can do that again
- But Olav has found multiple times in the last decade: that’s not true
  - We know that for example, if you do a VO2 max effort and then basically you give an adequate time of rest in between, you are able to go even *harder* on the next one
    - Even though the first one was to complete exhaustion

*Put some time and numbers to it so we can understand what you’re saying*

- Let’s say you do a **graded exercise test** (an old-fashioned way of quantifying VO2 max)
  - You increase the power by 5% every minute until exhaustion
- Let’s say the athlete finished around 500 W and 7 L of oxygen
  - Peter explains, “*Those are world-class numbers that are obscene.*”
- Olav qualifies this in that he hasn’t told what they did before this exercise test, and if he took this fresh, then the power number would be different
  - So this is already manipulate depending on what you’ve done before
- Let’s say they last for 6 min, and on the last one, the last minute is 500 W
  - Maybe they go a couple of seconds longer into the next one (this is also important)
- When you do a graded exercise test, if you come to the next step and you feel it is too hard, push as long as you can because every second counts
  - Because it’s more work, it’s more oxygen consumed, there’s a stronger stimulus
  - Olav wouldn’t advise doing this very often

**You should sparingly put “to exhaustion” workouts into your exercise program, and that ties back to consistency**

- Let’s say we give 10 minutes of rest in between
- Then if you do a new VO2 max, the same athlete will now bring more than 7.0L (7.1, or even higher)
- Power output also come up maybe 1 more minute at 1 higher power output
  - Now we are at maybe 525 W for 1 minute

Peter asks, “*You’re saying that that’s happening because they’ve been primed by the first set to be able to do that with only 10 minutes of rest?*”

- If there is **too long a rest** inbetween, then you start to lose the effect
- You could probably extend it up to 15 or maybe 20 minutes, but when you get past 20 min, Olav is not sure whether this would hold true anymore

***The rest needs to be short***

- This comes back to oxygen
- We know that the affinity of hemoglobin for oxygen and CO2 is affected by the temperature of the blood/body, and this is improving with a higher temperature
- After 20 minutes of rest, your body temperature will come down further than it was after 10 min of rest
  - The most interesting thing that will happen is that the [RER](https://en.wikipedia.org/wiki/Respiratory_exchange_ratio) value is heavily skewed toward O2 consumption and less CO2 production
    - When you do this, you would say this doesn’t qualify for a VO2 max
  - The VO2 numbers are equally high or higher, but he CO2 production is a little bit higher than 1.0 (in RER value)
  - In old-school books, the criteria for VO2 max is that you exceed an RER value of 1.1
    - You could argue that the VO2 max value was higher, are we not going to disqualify it if oxygen consumption was higher than the previous one?

## The respiratory exchange ratio (RER) and endurance sports, and how factors such as diet composition and exercise intensity influence RER values and performance [1:32:45]

**Let’s put one of your athletes on the bike riding really slowly: he’s at 100 W, he’s not even breaking a sweat. What is his RER at that moment?**

- Here, it’s very easy

***The*** [***RER***](https://en.wikipedia.org/wiki/Respiratory_exchange_ratio) ***is calculated instantaneously at any moment in time as the ratio of VCO******2*** ***to VO******2***

- There is a requirement for a certain amount of energy to be turned around per time
- And that’s why if you look at lactate as a surrogate, if you use stoichiometry and go back to glucose being broken down to lactate, we know how much CO2 is being produced in this process
- We also know the ratio between glucose and lactate and can use that as a surrogate to confirm these indications
  - The difference is that VCO2 is a volumetric measurement while lactate is a concentration, and concentration metrics are influenced by many other factors
  - That’s why lactate is not as good an indicator as VCO2, it’s a little more unpredictable
- Coming back to the athlete riding at 100 W, there you won’t necessarily see a very good ratio between VO2 and VCO2
- The RER value can be quite high because 2 things are at play here
  - 1 – Your [resting metabolic rate](https://en.wikipedia.org/wiki/Resting_metabolic_rate) accounts for a relatively larger percent of the total oxygen consumption
  - 2 – **CO****2** **production** now (as opposed to when you started) is at a higher number
    - The higher the VCO2, the smaller the percentage of the resting
- When we measure VO2 and VCO2, we are measuring the gross O2 and gross CO2
  - This is not only O2 as a function of exercise but of both exercise and basal resting metabolism
  - This is going to be heavily influenced by the carbohydrate content of the diet
  - Olav’s athletes are on a pretty **high carb diet**, so that means their resting RER is probably 0.5-0.9 (or higher)
- Peter reasons that Olav’s athletes get a nadir in their RER when energy expenditure gets high enough that it starts to dwarf basal energy expenditure and they’re achieving **maximal fat oxidation**
  - He would guess this would occur at a wattage that corresponds to 75-80% of their best 1-hour power
    - This would be maximum fat oxidation and minimum RER

***Olav explains it’s even higher for endurance athletes, especially long course triathletes, and this comes back to why VO******2*** ***max is not necessarily a good predictor of performance in longer events***

**VO****2** **max came down for Kristian and Gustav last year as a consequence of specialization training**

- Kristian and Gustav would typically test close to 90 mL/min/kg
- But in order to set new records in the [Ironman](https://en.wikipedia.org/wiki/Ironman_Triathlon), they had to bring it below 80 mL/min/kg

*You did this purely because of energy demand and energy consumption?*

- Yes, think of it like a curve, you can’t sustain [such a high rate]
- Back to the engine analogy: you  had to detune the engine and bring the fuel flow rate and O2 flow rate down to Le Mans versus a Formula One race
- You can’t prioritize repetition of those 5-min power surges (micro intervals) anymore because it’s too far away from what you need in the Ironman

***In the Ironman, you are not able to consume enough energy over the weeks and months to sustain a program that allows you to both increase your VO******2*** ***max at the same time as you are building up that long duration power output (say 4-hour power)***

- Peter suggests, “*What would be interesting for folks to understand is something called the WIC equation, which tells us the relationship between energy consumed and oxygen consumed and CO**2* *produced*.”
  - Basically energy expenditure = (3.75 x VO2) + (1.25 x VCO2)
    - VO2 and VCO2 are measured in L/min
- Olav would make it even simpler because we noted from 1 mL of O2 there are 20 joules of energy
  - And the efficiency of the body is approximately 20% propulsive and 80% thermal

***So you can measure how many mL of O******2*** ***you are consuming and multiply it by 20 (roughly speaking)***

- Peter reasons that you can assume what the VCO2 is (you don’t have to measure it)
- So a 6 L/min O2 that’s 30 calories per min of energy consumption (1800 calories per hour at 6L/min)
  - ***At that point, you now exceed the capacity of the human digestive system***
  - There is no means by which a human can ingest 1800 calories in an hour and get those calories out of the GI and into the circulatory system, into muscles

***At this level it becomes an energetic problem as much as a problem of stroke volume, heart rate, and capillary efficiencies***

- Olav adds, “*You can even say that you don’t even care about heart rate or stroke volume or cardiac output anyway because that’s what you even started with.*”
- VO2 encompasses stroke volume because cardiac output is a function of VO2 in the end anyway
  - The cardiac output is just to supply you with oxygen
  - ***Really oxygen is the key metric here***
- The energetic demand becomes so crazy that you have to ask: how important is it for you to be able to do super high 5-min surges in the Ironman?
  - Not important at all, ever
  - So you can’t spend time on training it
- If you could somehow feed more energy, then you can uphold more of that, and that’s what we did

***We looked at how to stay in this perfect balance, living at the edge because that will give us a better ability to race***

## Science-guided training for versatile athletes: maximizing VO2 max, power, torque, and cadence in cycling, and the importance of incorporating diverse stimuli to enhance performance [1:41:00]

**The distances of these long distance triathlons**

- An [Olympic distance triathlon](https://en.wikipedia.org/wiki/Triathlon_at_the_Summer_Olympics#Competition) is a total of 51.5 km: 1500 m swimming, 40 km biking, and 10 km running)
  - A world-class athlete is doing that in 1 hour 40 min (or 1:45)
- On the other end of the spectrum is the [Ironman](https://en.wikipedia.org/wiki/Ironman_Triathlon) distance: 2.4 miles in the water, 112 miles on the bike, and a full marathon run [26.2 miles]
  - World-class guys are going that in 7.5 hours; Kristian went 7:21)
- Peter adds, “*It’s simply unfathomable to anybody who’s done any of those things that they’re going that fast*.”
  - The energy demand of trying to do something all-out for 1:40 is a much easier fueling strategy than if you have to go at a submaximal effort for 7.5 hours

**Is it surprising to you that you can have one athlete who can be exceptional and world-class at both?**

- Peter finds it a little counterintuitive based on this discussion that you could be the best in the world at both of those

*Is there another sport where we would see such disparity?*

- We wouldn’t expect that the best 400 meter runner is also going to be the best 10k runner, and we wouldn’t expect that the best 5k runner would be the best marathoner

> “*This is where I think that we have hugely benefited from using science because it allowed us to break down the Ironman distance and understand where basically we could gain much more time than what had been done before*.”‒ Olav Aleksander Bu

- Think about the training method: we are organic creatures, and we respond to stress by getting stronger (given that we’re provided the conditions to allow it to grow stronger)
- Going back to Peter’s 5-min intervals for VO2 max training
  - During this training, you have a finite amount of time that you can do this exercise: 90 min, that’s it
  - In the same way that you go out and play with your breathing to see what you can do with your heart rate at a certain power
  - You’re looking to provide a maximum amount of stimulus to increase VO2 max
- We already said that the 5-min power or 3-min power is a good proxy to understand how high your VO2 max is

***Think of it this way instead: you are looking to accumulate the maximum amount of work you can do at a certain output***

- This is a better way at looking at how to provide the best possible stimulus to grow your engine, to grow your VO2 max

**Just to be clear, you’re saying that if you’re going out for 1 hour, what’s the most number of kilojoules you can expend as opposed to what’s the highest VO****2** **max you could sustain for that period of time?**

*Are you saying we could use kilojoules as the metric?*

- Yeah
- **Velocity** is the ultimate measurement of form, and the further we move away from this, the more gray it becomes
  - Because there are more mechanisms compensation that have an influence on what is happening
- Think of it this way, the reason we want to grow an engine is because we want to become faster
  - But when you are exercising, you’re not measuring VO2 max, you’re not measuring mL/min of O2 you’re consuming
- We know that the higher the intensity, the more O2 you will consume per time

***We are saying now that we are providing a stimulus to the body to say that we need more O******2******, and you need to respond to this and facilitate moving this forward (because you might have to do this session again next week)***

**The theory of** [**super compensation**](https://en.wikipedia.org/wiki/Supercompensation) **is the reason why we get strong**

- Exercise provides a controlled stress to the body that the body is then able to respond to and grow from
- When you go out and do your hill repeats, you accumulate 6-10 repeats
  - That means you are accumulating 30-50 minutes of high-intensity work

***You do that specific work with the idea that this will give you a bigger engine, but ultimately what you are really looking for is to become faster***

- You can also say that you don’t care if your VO2 max comes down but you become faster
  - **Efficiency** has increased
  - It will probably result from a mix of a lot of things

*Think of it this way*

- You ride at 400 W and you accumulate 30 min at 400 W
  - Peter wishes he could still doo 400 W for 5 min; those days are over
- Let’s say 300 W (it doesn’t matter), but 300 W is **close to exhaustion**
  - You have a little bit of resource so you can repeat this
  - You accumulate an average of 310 W over 30 minutes
- If you go to 50 min, a normal consequence would be either you’ve gotten fitter or you had a lot more in reserve than when you did 30 min of work
  - So the 30 minutes didn’t really bring you close to exhaustion, and the stimulus/ stress on the body was also much less
- Worst case, if you were capable of accumulating 50 min at 300 W 2 weeks ago, but now you can only do it for 30 min: that’s **detraining**
- Alternately, if you sit at 300 W for 30 min and you’re close to exhaustion, and the time you had available for training was 75-90 min

**Peter clarifies that he used to train, but now he exercises**

- When he would train, on big days his coach would not want him to begin the VO2 max set until he had done 2000 kilojoules
  - So he would go and do a relatively easy 200 W, 2000 kJ ride and then finish with a  very big main set of 6-min hill repeats
  - That was an enormous amount of total energy expenditure, but most of it was zone 1-2 (pure aerobic) and then finishing with VO2 max
  - He doesn’t’ remember what the rationale was for doing 2000 kJ of work before
- Now that he is not training, velocity and power don’t matter
- Peter is only training for the conditioning of it

Peter asks “*How long can I keep my VO**2* *max high?*”

- One of the things Peter thinks about is, “*At what age will my VO**2* *max (in relative terms, mL/kg) be smaller than my age in numbers?*”
  - It’s interesting to think about: where do we make that crossover?
- Olav thinks with the democratization of measuring equipment, this is something we will probably have a completely new picture of over the next 5-10 years

***Olav collects so much data from his athletes and the coaches he works with, and he has found that while we can make athletes faster, we haven’t gone as fast as it is possible to do yet***

- But the time it takes to analyze all these metrics and bring it back into our program is so time consuming
  - Sometimes you have to focus on the more important part of it
- We have a company called [ENTALPI](https://www.entalpi.com/) where we are building AI (natural language processing systems and numerical models) to allow us to utilize more of this data
  - To provide even deeper individualization for athletes

**When you exercise, your ability to put out 300 W is a function of force and circumferential velocity (or let’s say torque and cadence)**

- It’s very easy when you go out to think, “*Okay, now I’m going to go max*.”
- What you feel is torque, you don’t feel power in the same way
- If you aim for something that feels like it’s super heavy, that’s a big torque, but it doesn’t necessarily yield a very high power output

***The power is what drives energy demand for the body, not torque***

- Not entirely; it’s a little bit of a mix of the two

**Do you subscribe to the idea of shifting more towards higher torque, lower velocity, where you’re putting more of the stress on the musculature of the legs?**

*If you switch more towards a higher crank velocity, lower torque, you’re switching more of the demand in the direction of the cardiovascular system*

- Peter remembers that people used to talk all the time about the difference between [Lance](https://en.wikipedia.org/wiki/Lance_Armstrong) and [Jan](https://en.wikipedia.org/wiki/Jan_Ullrich)
  - One was pushing 95-100 RPM and the other was pushing 65-70 RPM
  - They’re putting out the same power, but with 2 different strategies
- Olav points out, this is something that’s very easy to measure
- If you’re going for a certain power output and you drop your cadence, you bring up the torque
- Peter suggests you make VO2 the metric that helps you decide, and that should correspond  most to fatigue
- Olav has found that you might bring down the VO2 as a function of increasing the torque
  - You get a little bit better ratio there
  - As a function of that, you also see CO2 come up a little bit more
    - So you are shifting to substrate a little bit
- The mechanism behind this is fairly easy to rationalize, simply because when you start using a higher torque, you are activating a larger cross-sectional array of your muscles
  - You’re also recruiting more [type II fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types) versus only type I fibers
    - You’re becoming more glycogen dependent as you make that recruitment
- You’ve heard the expression “slow twitch” and “fast twitch” fibers
  - More of that will be activated when you start to pedal faster, but you’re not even approaching the limit of a slow twitch fiber (or type I fiber) contractile velocity when you’re at 90 (or 100 or 110 [cadence])
    - It’s more a limitation of being able to coordinate your pedaling motion in order to have a better balance between gross power and net power

***People sometime forget that when you start to go at a higher cadence, the net power is the same but the gross power actually starts to go up, and this is why the VO******2*** ***also starts to go up***

> “*The VO**2* *(or the oxygen consumption) doesn’t care about your propulsive power, it cares about how much power is required now*.”‒ Olav Aleksander Bu

- Peter explains, “*It’s [the VO**2* *is] counting both the usable and wasted energy*.”
- Olav agrees and explains when you go with a little bit *lower cadence*, typically it’s easier to coordinate your pedaling motion than when you go with a higher cadence
- Let’s say you do a graded exercise test, if you aim for a low torque, the problem is that the ergometer now starts to force you to go to higher and higher power,
- And if you go with a low cadence, this will start to increase [motor unit](https://en.wikipedia.org/wiki/Motor_unit) activation
  - You’re recruiting more and more muscle fibers
  - And you won’t be able to get up to an equally high power output simply because the limitation that comes in now is that you have no more motor units
    - You have no more muscles to recruit anymore and you are forced to stop
- The only way to compensate for this is to bring up your cadence
  - Because if there’s no more muscles to recruit, the only thing you can do is start to work faster instead

**Back to Peter’s question about conditioning, creating the ability to put out big power**

***We know there’s a very good correlation between power and VO******2***

- Obviously more work more oxygen consumption
- It’s almost a **linear relationship**: if you increase your power by 10%, you will normally increase your oxygen consumption by 10% as well
  - For those people who are really into the pudding here, they understand that this is not entirely the case
  - This is a curve-linear relationship
  - But for simplicity, consider it a linear relationship
- Peter adds, you will not increase velocity by 10% in that situation because of the square relationship between velocity and drag
  - While those 2 things are moving up in a curve-linear relationship, the velocity relationship is actually a squared (or power) relationship
    - And therefore it gets harder and harder when you’re talking about elite athletes eking out an additional kilometer per hour when they’re already going 48 kph
- Olav suggests thinking about it this way: since there is an extremely good correlation between power and oxygen consumption, **how can I increase my oxygen consumption?**
  - Now we’re not talking about mL/min, we’re talking about *mL accumulated*
  - In the same way as we talk about the relationship between power and work, we can talk about the difference between mL/min and mL per session

***The question is: how do I provide a stronger stimulus to the cardiovascular system, respiratory system, to everything so I get a higher VO******2*** ***max?***

- You already have a power meter, so you have something that we know has an extremely close relationship with oxygen
- How can we increase the total oxygen consumption during that session?
- Olav would argue that doing 5 in on, 5 min off, will not necessarily yield the maximum work that you can do
  - Because we’re not looking at total work during the session
  - Obviously that would be better if you *brought down the intensity* in total

***Olav suggests to go out and play around with different intervals to find out how to pack in as many possible kJ of work at that power output during that session***

- If you do this over a month, he’s pretty sure that you will have a higher VO2 max than before

**What some of those games could look like**

- Peter used to experiment with every type of interval from 30 sec on, 30 sec off, up to 8 min on, 8 min off
  - ***The only thing that was constant was the one-to-one work-to-rest ratio***
- The work-to-rest could be as little as 30 seconds, 1 min, 2 min (even less)
- Classic cycling physiology is maximizing VO2 max and maximizing PVO2 max (powered VO2 max, critical power for example) is going to be attained at **3-8 min intervals**
  - Now it doesn’t mean you don’t improve the engine size when you’re doing intervals less than 3 min or more than 8 min, but you’re most efficient in your training time at those intervals

Peter asks, “*Are you arguing that’s not necessarily true, there could be gains outside of that if you’re using maximum kilojoules per unit time as your metric?*”

- Yeah, accumulated inside a session

**Think of  it this way: we are looking for stimulus**

- If you do 5 min, the stimulus you are proving now
  - At the power of VO2 max
  - Or if you had an oxygen mask and could measure oxygen, you’ll see that the total accumulated oxygen used during that session is very, very little
- If you try to combine those 30 minutes into 1 power output, you won’t be able to put out the same amount of power
  - If it was 300 in the 5 min interval, you would probably be forced to bring it down to 280, 270

**Why the 5 min interval? Could it also be 4 min or 3 min?**

- Peter wants to make sure the interval isn’t too small that we’re “cheating” and using pure glycolytic power
  - That won’t necessarily increase the mitochondrial function
  - He points out that we are so focused on VO2 max here because we want to make sure the system is flexible enough to oxidize both glucose and fatty acids through the mitochondria with oxygen

*At some level, don’t those interval durations get so short that we can be misled by what we’re seeing (assuming we don’t have the oxygen mask)?*

- If you have the oxygen mask, of course we’ll notice that
- But if we’re only relying on that correlation between power and VO2, that linear curve starts to separate in lower durations, doesn’t it?

***Olav brings up an important disclaimer: there’s no single workout that is the “golden workout”***

- We need different types of stimulus
- When you do different kinds of intervals at VO2 max, they will elicit different functions/ benefits in your body
- For example, if you do micro walls, you won’t necessarily bring your core temperature as high up as you would do if you do a long workout
- One thing that is very good for our body is to have more **plasma**, and that has an influence on VO2 max as well
- Bringing up the **core temperature** is also like working on being able to focus on relaxing when you get more fatigued as you’re doing longer intervals

## Physiological limitations on VO2 max [2:02:15]

**To bring the VO****2** **max to this highest is to disregard everything else**

- We don’t necessarily talk about endurance, fatigue, resistance
- What is the thing that causes us to bring up the oxygen?
- It’s also useful to think of the measurement method we’re using to quantify this
  - We are *not* measuring what’s happening inside the muscle

***We are measuring what comes out in the exhaust, and then we’re quantifying VO******2*** ***max as a function of that***

- If you do **mitochondrial respirations** ‒ if you do a biopsy and take out the mitochondria and put it into a chamber to measure the mitochondrial respiration
  - We’re not talking about 90 mL/min/kg
  - Even for *not* well-trained athletes, you are at 200 mL/min/kg
  - For elite athletes it is more than 300-500 mL/min/kg
  - This tells you how much oxygen the mitochondria is capable of using

**Peter’s takeaway:** ***we are never limited at the level of the mitochondria***

**When we ask the questions: where is the rate limiting step in oxygen utilization?**

- It’s not at the mitochondria
- It’s not that we are unable to put more oxygen through the system at the final point where it is needed for combustion
- Peter has always thought it’s at the level of stroke volume that it’s actually at getting the plasma to the muscle
- Olav agrees, “*Getting the oxygen, getting the hemoglobin transported to the cells is the most important thing. So it’s more of a central limitation than a peripheral limitation.*”
- From a mitochondria perspective, the ratio between what it can use is so extreme compared to what we are able to pump around or take up in our lungs and pump around to the body compared to what we can use without touching into that

**Olav’s athletes are using a lot of carbohydrates for fueling**

- We know that 60-90 g per hour is not a limitation either
  - It’s much, much higher than that
- We add [isotope tracers](https://en.wikipedia.org/wiki/Isotopic_labeling) to the carbohydrate to quantify this
  - It’s a similar concept to [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water), but here we add it actually to the carbon instead to look at the carbohydrate uptake
- We have done a lot of research with Morton specifically on Kristian and Gustav, and have found that the carbohydrate [that mitochondria can utilize] is so much higher than what we are able to supply through our system

***You’re limited in what the gastrointestinal tract can tolerate***

- You’re not limited at substrate utilization in the mitochondria

**What brings us to VO****2** **max?**

- You can increase the ventilation as high as you want, and yes, you will increase your oxygen
- But you’ll never get to your maximum level without sufficient work
  - You need work

***You will bring it up because you’re working more and you’re breathing more***

## The different energy systems used during work, and other things to monitor like VCO2 and heart rate [2:06:00]

**Back to the discussion of micro intervals and whether they are glycolytic or not**

- If you measure what is happening in the muscles, you’ll see that they are trying to use all energy systems, immediately, instantly
- We have a lot of buffer mechanisms in our body, and if the burst is short enough, then it won’t show up here
  - You basically have a long taper
  - You will never get a spike on VO2, but you can see that you have an elevated VO2 consumption over a little bit longer time
  - If you measure during the interval, it won’t show up on the exhaust because you take off the mask before it shows up
- But if you keep the mask on and measure for a longer interval (a couple minutes after the interval), you will see elevated O2 consumption compared to before you did the interval

***We can say that when you do a burst, it will most likely use all energy systems instantaneously as much as possible***

- You may think that first we use stored ATP, then we shift to [Pcr](https://en.wikipedia.org/wiki/Phosphocreatine), then it becomes [glycolytic](https://en.wikipedia.org/wiki/Glycolysis), and we go off to [beta oxidation](https://en.wikipedia.org/wiki/Beta_oxidation)
- Olav thinks the more correct way to view this, the reason why you can have short and high power output is because you are able to supply from all the energy systems instantaneously
  - Then you are depleting different energy systems
- Coming back to the micro intervals versus longer intervals, as long as you start to accumulate enough work during that session
- We talk about VO2 and VCO2

***VCO******2*** ***is really useful for getting an instantaneous picture of what kind of substrates you are using***

- Whether you are at an [RER](https://en.wikipedia.org/wiki/Respiratory_exchange_ratio) value of let’s say 0.8 (or even lower), but let’s say that you are 0.8-1.0  (it doesn’t make that much of a difference in your energy yield)
  - To understand your energy demand: if you use 20 joules of energy, 1 mL of oxygen
  - If you put this into the formula and you start to see that there is not a massive difference
  - If you want to be accurate, you want to do this
  - But if you want to understand from a **fueling strategy perspective**, then you need CO2 to understand how you are using different fuels at different times
- Realize that when you go in the lab and test, this is a completely different picture than if you brought somebody into the lab the moment they went over the finish line in a race
  - Now you would see that the power they hold there at the end, even though it’s much lower, it’s very close to their VO2 max

**There is a missing time component**

- We often talk about a spot picture, or something that happened in a fresh/ rested/ ideal state
- When you do micro intervals, you can also use your heart rate as a gauge
- In your micro intervals, if you see that you did 310 watts and you were able to accumulate 30 min of that
  - Now if you bring it to 330 W, and you do 35 min of that
  - You’ll see that it starts to become quite a lot of them, and most likely you’ll also have a very high heart rate
    - Maybe equally high as when you did 5-min intervals

**You can use heart rate as an indicator of how much time you have accumulated close to VO****2** **max**

- The thinking is that one of the conditions that has to be met for you to reach VO2 max is you need to pump a maximum amount of oxygen around your body
  - That is a combination of very, very high **heart rate** (close to maximum) and a high **stroke volume**

## Lactate threshold and other metrics to guide your training [2:10:30]

Peter remarks, “*It’s just occurred to me that I’ve got 8 pages of notes here of things I want to talk about with you, and we are halfway through the first page. So clearly this is part one of many podcasts we’re going to have to do together.*”

- If we can only discuss one more thing before we go, Peter would like to do a deep dive into [lactate](https://en.wikipedia.org/wiki/Lactic_acid#)

**Background on Peter’s exercise goals and interest in lactate**

- Peter has abandoned his athletic goals, and the only thing he trains for now is for health/ longevity
  - For the [centenarian decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/)
  - He wants to be as fit and strong as he can be in his 80s-90s without trying to worry about maximizing his performance today
    - He is trying to maximize his performance tomorrow
- His training volume is now so much lower than it used to be when he lived on a bike or lived in the water
- He’s trying to be maximally efficient, which is always risky because sometimes you just have to put the miles in
- He spends about 3 hours a week in zone 2

*There’s so many different ways to describe zone 2*

- He’s not doing this in terms of heart rate
- He’s really defining this in terms of mitochondria

***Zone 2 is his highest power output where his lactate stays below 2 mmol***

- This is very sustainable from an RPE perspective (it’s RPE 6-7)
  - He can talk, but it’s not comfortable talking
  - It’s definitely below his 1-hour functional threshold power, but it’s more challenging than that 200 watts riding around in circles, having fun, trying to just purely focus on position
- Peter checks his lactate constantly to make sure he’s hitting zone 2
- The rationale is that 2 mmol is about the tipping point about which you can be in a steady-state of producing lactate/ clearing lactate,
- Once lactate starts to get into the 3-4 mmol range, you wouldn’t have indefinite access to that energy system
  - You’re going to start accumulating so much hydrogen that at some point your physics of performance are going to be compromised

**Let’s now talk about this in terms of world-class athletes**

*If you had a continuous lactate sensor on an Ironman in his 7 hours and 30 minutes, give me a sense of what his lactate tracing looks like*

- This is where Olav differentiates between volumetric measurements and concentration metrics
  - Lactate is a concentration matrix
  - We don’t measure the volume of lactate
- Peter notes that the plasma volume is decreasing as an athlete is running

*Would you expect the lactate concentration to go up slightly, even if the production of lactate is constant?*

- Yeah
- Olav has made some discoveries over the last several years when we start to do Ironman training which are very different from a lot of the current understanding (we’ll touch on this more in an upcoming podcast)
- Universally, it’s about being able to more more per time
  - Even moving your head is movement
- It’s better if we break it down to local movements of parts of our body

***If Peter came to Olav [for coaching], the most important thing would be to bring joy of exercising and a sense of achievement into his training***

- Because that’s what’s going to get you out of bed

> “*If you look forward to exercising because you find it enjoyable, you’ll do more of it.*”‒ Olav Aleksander Bu

**The differences between riding at 1 mmol versus 2 mmol lactate**

- 1 mmol may be more sustainable for you over months and years, and think of what you can accumulate
  - It brings you more joy
  - It allows you to be more present and use it almost as a mindfulness session
- Often the problem with research is that it gives a spot picture of something
- We look at something in 1-2 sessions instead of looking over a long period (or lifespan), and this is where we often undervalue the joy of exercising
  - We go in with the expectation that we have to go hard, all-out
    - This is very demanding and taxing on the body

**Peter can completely relate to that and has accepted that as part of the transition in his life**

- There were many years where he had a belief system that said, “*Every single day without exception, you must burn the pack of matches fully at least once.*”
- It didn’t matter what the workout was, there was still an all-out effort of about 3-5 min somewhere in the day where his lactate would be in the 16-18 mmol range (incredible pain)
- Truthfully, Peter can’t do that anymore because he doesn’t have the mental fortitude for that much suffering anymore

***He loves to exercise, and there’s never a day that he doesn’t want to, but he also doesn’t have to look forward to that degree of suffering anymore***

- That’s the difference between being 50 and 30

**Peter still really enjoys quantifying his training, and he knows there are many people who don’t**

- Most of his patients are not measuring their lactate levels during their cardio training
  - Maybe 2-5% are

***Use your*** [***rate of perceived exertion (RPE)***](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion%20as%20a%20guide) ***as a guide and make it enjoyable***

- Peter still is a little bit of a data person and likes using this metric to maximize efficiency and track his progress
  - He wants to know, “*Am I able to get watts higher and higher and higher while keeping heart rate and lactate more or less the same?*”

**Define what a lactate threshold is and how it’s measured**

*Do you guys still do lactate performance curves?*

- Yeah, but more as a function of other metrics that Olav collects

***Lactate is a concentration metric and marker of substrate utilization***

- It’s a good metric, but not extremely accurate
  - This is a redundant metric
- Olav uses lactate as a guide to change training, and there are plenty of good surrogates or proxies you can use instead

***If you want to understand your substrate utilization better, Olav would argue that you can’t only do 1 measurement***

- You need to change intensities and get a range of measurements
- Your maximum lactate steady state concentration in a session can vary based on dehydration
  - If you have one lactate concentration today, it might change in 2 days time

*How Peter used to do it*

- He would do repeated intervals at ascending effort and
- If it was in the pool, we would swim 100 or 200
  - You would go out pretty easy for the first 1, check the lactate, fully recover, and repeat
  - You would get faster and faster with each one
  - Graph speed on the X-axis and lactate concentration on the Y-axis, and this becomes a power curve [sample graph shown below]
    - It’s very crude
    - He’s also tracking heart rate but focuses on speed

![](https://peterattiamd.com/wp-content/uploads/2024/03/f2-olavaleksanderbu.png)

**Figure 2. Running speed versus blood lactate concentration**. Image credit: [*Frontiers in Physiology* 2008](https://www.frontiersin.org/journals/physiology/articles/10.3389/fphys.2018.01320/full)

- You can eyeball them as 2 separate linear curves, and their intersection becomes the inflection point at which you go from sustainable to unsustainable lactate production (or nonlinear parabolic lactate production)
- Let’s assume that intersection occurred at 3.5 mmol (concentration of lactate) ‒ we would note what the pace was there
  - We would tell the athlete to be mindful of exceeding that pace
- This speaks to what Olav was saying
  - The pace is going to change depending on hydration, energy reserves, fatigue
- This is crude, but directionally we thought that you have to be very careful every time you exceed that pace in a race because you’re tapping into a very finite reserve

*Olav points out that the inflection point is very misunderstood*

- Some people still go by fixed blood lactate accumulation values (or concentration values)
  - For example, they stick to 4 mmol
  - If you’re going to publish a paper and you want it to be able to compare with other papers that are out there, that’s fine
  - But the problem with that is that 4 mmol can be accumulated in a whole range of different ways
    - You can go just above your second inflection point or just above maximum lactate state, and then you creep up towards 4 mmol, meaning that now you have to have a smaller power output in order to get there
    - Or you can go with a very high power output and it would take a short time for you to reach that 4 mmol
- How do you go backwards to say that 4 mmol should correlate to this power?
  - It’s highly dependent on the protocol that you’re doing

***The way Peter described it is fine***

- Peter wanted to use it as a way to control intensity as opposed to heart rate or other things
- We know that heart rate is also influenced by hydration, other stressors, etc.
- The way Peter talked about inflection points is perfect, and he makes it simple (depending on how long the protocol is)

## Analysis of a lactate power curve: exploring lactate dynamics in endurance training and performance [2:23:15]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f3-olavaleksanderbu.png)

**Figure 3. Power versus blood lactate concentration**. Image credit: [Loughborough University](https://www.lboro.ac.uk/sport/news/2020/april/training-zones)

**You can draw 3 lines on this curve**

- 1 – One line goes through the flat section of your lactate
  - This is where you would normally see fat metabolism
  - Defined at **LT1** [lactate threshold 1]
- 2 – Another line goes on the linear increase for every step you increase pace
  - Defined as **LT2** [lactate threshold 2]
- 3 – At some point you see there is a complete departure between increasing pace and lactate, and it goes up very hard (almost vertical)

- Some people use the nomenclature to call that LT1 and LT2, and Olav likes this because then you’re distinguishing it from [MLSS [maximal lactate steady state]](https://bmcsportsscimedrehabil.biomedcentral.com/articles/10.1186/s13102-024-00827-3)
  - MLSS requires you do a very specific profile: you could do a 20-30 min rolling effort where you’re looking at lactate every 5 min to see when it starts to increase
  - MLSS is the highest lactate value that you’re able to maintain steady state
- If you go a little higher in effort or intensity than MLSS, you’re accumulating more fatigue and the lactate is not stable anymore for the same power output
  - Lactate starts to go up and it’s not in steady state any more

**What capacity or duration is built into that assumption of LT2?**

- LT2 cannot be sustained indefinitely and there’s a point where it ceases to be a true steady state

*What does that look like in an athlete?*

- This depends on how powerful the athlete is
- There is also a misconception where a lot of people think that maximum lactate steady state [MLSS] is the equivalent of a [RIR](https://intercom.help/thetrainingplan/en/articles/2920138-reps-in-reserve-rir) value of 1 (this is not the case)

*One thing Olav discovered with his athletes is that the longer the distance you’re doing the lower the RIR value*

- If you look at it from a physics perspective this is logical
  - A stationary action principle or thermodynamics
  - How do you supply the body with the most sustainable energy in the simplest way possible?

Peter asks, “*At an Olympic distance. Are they able to hold LT2 for the whole race? Whereas at the Ironman, are they well below LT2 and closer to LT1?*”

**The problem is that lactate only looks at concentration, it doesn’t look at volume**

- An Ironman athlete has a very high utilization at VO2 max, and the LT1 will already occur
  - It sits close to 80% of VO2 max
  - If the VO2 max is 6 L/min, 80% of that is 4.8 L/min and they’re at about LT1
- You know that is *not sustainable* because you’re turning around so many carbs per hour that this doesn’t work anymore
- Peter thinks this depends on the [RER](https://en.wikipedia.org/wiki/Respiratory_exchange_ratio) because you’re now at maximum fat oxidation

*Peter points out that Olav’s athletes have 1 thing working for them and 1 thing working against them in terms of fuel utilization*

- They have the healthiest mitochondria on the planet
- The thing they have working against them is they’re on a very high carbohydrate diet
- They  have a capacity for insane fat oxidation, but their system is tuned towards a faster fuel [carbs], not a more energy dense fuel [fats]

**Would they hit 0.8 g/min of fat oxidation? Are they getting that high?**

- Olav would have to go back and look
- They can get extremely high, higher than 1 gram/min on a high carb diet

- We are out of time and it’s absurd to Peter that we have only covered ⅔ of 1 page of his notes (out of 8 pages)
  - We have not talked about what he wanted to discuss around muscle biopsies
  - Or anaerobic threshold
  - Or the use of temperature probes and understanding the effect of cooling during both competition and training
  - Heart rate variability training, desire, performance, and recovery
  - Peter also has questions about the use of PEDs and why they don’t seem as prevalent in triathlons as they do in other endurance sports
  - He also wants to talk about [MCT](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) density
- Olav looks forward to a second podcast
- He tries to be very clear on terminology, but it is important to remember that people might use these terminologies differently
- As long as a coach and an athlete have an understanding of something that works for them, don’t get discouraged
  - Don’t start quarreling over definitions
  - The most important thing is to have a language that works for you
- There’s still a lot of things that we don’t know and that’s the reason we are continuing to do all of this research

§

## Selected Links / Related Material

**Portable VO2 analyzer**: [VO2 Master](https://vo2master.com/) | [3:15, 45:30, 1:08:45]

**Company Olav co-founded**: [ENTALPI](https://www.entalpi.com/) | [9:15]

§

## People Mentioned

- [Kristian Blummenfelt](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) (Norwegian triathlete, won the gold medal in the men’s triathlon at the 2020 Summer Olympics, and 2021 Ironman World Champion) [1:15, 8:30]
- [Gustav Iden](https://en.wikipedia.org/wiki/Gustav_Iden) (Norwegian triathlete and 2022 Ironman World champion) [1:15, 8:30]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (American  professional road racing cyclist, winner of the Tour de France) [1:04:45, 1:52:00]
- [Jan Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich) (German professional road racing cyclist, Olympic champion and winner of the Tour de France) [1:04:45, 1:52:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/03/bio-olavaleksanderbu-500x500.png)

##### Olav Aleksander Bu

Olav Aleksander Bu is the chief scientist and co-founder of the companies [ENTALPI](https://www.entalpi.com/) and [SANTARA TECH](https://www.santaratech.com/). He has worked as the head of performance for the Norwegian Olympic team in triathlon since 2015. As an internationally renowned coach, who has made solid contributions in revolutionizing the way top athletes train through his unique training methodology “Entalpi”. As head coach for the Olympic and world record-holding champion Kristian Blummenfelt and world champion Gustav Iden, he has been vital in making history within triathlon in recent years. With his athletes and the “Norwegian Method”, he has forever changed the swim-bike-run landscape. Olav has been essential in winning an Olympic gold medal, breaking world records, and sweeping all three podium places in WTS in Bermuda 2018. [[ENTALPI](https://www.entalpi.com/team/olav)]

Instagram: [@olavaleksander](https://www.instagram.com/olavaleksander/?hl=en)