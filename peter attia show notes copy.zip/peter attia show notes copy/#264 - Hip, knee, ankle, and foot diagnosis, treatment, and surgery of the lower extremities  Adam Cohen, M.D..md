# #264 ‒ Hip, knee, ankle, and foot: diagnosis, treatment, and surgery of the lower extremities | Adam Cohen, M.D.

**Source:** [https://peterattiamd.com/adamcohen/](https://peterattiamd.com/adamcohen/)

---

Adam Cohen is an orthopedic surgeon with expertise in sports medicine. In this episode, Adam breaks down the anatomy of the lower extremities: the hip, knee, ankle, and foot. He explains in detail the common injuries, sources of pain, and what leads to the development of arthritis. He lays out the non-surgical and surgical treatment options as well as the factors that determine whether surgery is appropriate. The discussion includes various procedures like hip replacement, knee replacement, ACL reconstruction, repair of meniscus tears, and more. Additionally, Adam sheds light on the utility of biological therapies like stem cells and platelet-rich plasma (PRP) and how they compare to more traditional approaches.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

(NOTE: Find video clips of exams that Adam performed on Peter at the end of the show notes)

![The Peter Attia Drive](images/adamcohen/the_Drive_public.png)

Play

#264 ‒ Hip, knee, ankle, and foot: common injuries, prevention, and treatment options

#264 ‒ Hip, knee, ankle, and foot: common injuries, prevention, and treatment options

1x15s30s

0:002:09:45

## We discuss:

- Anatomy of the hip, hip dysplasia in infants, and the development of arthritis [3:00];
- Diagnosing hip pain in people under 50, stress fractures in the femoral neck, and more [11:15];
- Common hip injuries, gender differences, and problems that occur when the hip isn’t formed normally [19:30];
- Advancements in hip replacement surgery [25:15];
- Common hip problems in people over age 60 [27:30];
- The importance of muscular strength around the hips for injury prevention [30:30];
- Hip fractures due to osteopenia and osteoporosis [36:00];
- The utility of biological therapies like stem cells and platelet-rich plasma (PRP) [40:30];
- Cortisone as a treatment to delay the need for surgical intervention [53:30];
- Anatomy of the knee [56:30];
- Are activities like running that amplify forces bad for the knee? [59:45];
- Risk of future knee issues and arthritis following an ACL tear or other substantial knee injury [1:04:30];
- How the ACL injury happens and how it is repaired [1:08:30];
- Arthritis of the knee [1:19:00];
- Meniscus tears: how they happen and when surgery is appropriate [1:21:30];
- Total knee replacement: when it’s appropriate and how the recovery process compares to hip replacement [1:30:30];
- Surgical vs. non-surgical approaches to various knee injuries [1:40:45];
- Achilles tendon: tendinitis, rupture of the Achilles tendon, and prevention strategies [1:44:15];
- Anatomy of the ankle and foot [1:49:00];
- Common injuries to the ankle and foot [1:51:15];
- Tips for finding a good orthopedic surgeon [2:01:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Adam Cohen is board certified in both orthopedic surgery and sports medicine and has extensive training and expertise in various sports medicine injuries
- He is the director of Sports Medicine at [Ortho Manhattan](https://www.orthomanhattan.com/orthopedic-surgeons-new-york-city/adam-b-cohen-md/)
- He serves as the team physician for Horace Mann Athletics
- He also holds academic appointments at the [NYU Langone Health System](https://nyulangone.org/doctors/1700847316/adam-b-cohen) and the [Mount Sinai Health System](https://icahn.mssm.edu/profiles/adam-b-cohen)
- Adam previously served as the assistant team physician for the New York Yankees and served as a consultant for the US Open Tennis Championship, as well as provided orthopedic coverage for the New York City Ballet
- This episode is, in some ways, a follow-up to the [episode](https://peterattiamd.com/altonbarron/) with Dr. Alton Baron, which focused on the upper extremity
- This episode with Adam focuses on everything you need to know about the lower extremities ‒ the hip, knee, ankle, and foot
- For each of these, we walk through the anatomy, what can go wrong, what causes injuries, as well as what surgical and non-surgical management of these things looks like
- We then end the conversation looking at how someone can go and find a good surgeon if they need any of these issues addressed
- In addition to our conversation where Adam uses images and models, he also runs through the typical exams that he will do for each part of his assessment
  - These exams will make a lot more sense if you can see them rather than hear them
  - So for the audio portion of this podcast, we will not include any of the exam content
  - If you choose to listen to this in audio, you may still want to go and check out our [YouTube page](https://www.youtube.com/@PeterAttiaMD/videos) to look for the exams (see also the selected links)
  - Of course, you may just choose to watch the entire thing on YouTube so that you can see his images

## Anatomy of the hip, hip dysplasia in infants, and the development of arthritis [3:00]

- The hip joint is a ball and socket joint

![](https://peterattiamd.com/wp-content/uploads/2023/07/f1-adamcohen.png)

**Figure 1. Model of the hip joint**

- Unlike the shoulder, it’s a very contained concentric joint and much more stable under normal circumstances than the shoulder
  - It’s a deep socket
- The socket is called the [acetabulum](https://en.wikipedia.org/wiki/Acetabulum)
- The [femoral head](https://en.wikipedia.org/wiki/Femoral_head), it is covered with cartilage
- If we just focus on the [proximal femur](https://en.wikipedia.org/wiki/Femur#Upper_part) (shown below), we have the head, the neck, the subtrochanteric region, and the trochanteric region

![](https://peterattiamd.com/wp-content/uploads/2023/07/f2-adamcohen.png)

**Figure 2. Model of the proximal femur**.

**Many problems in the hip begin during development**

- The acetabulum is formed in utero beginning about fourth week, and then by the 30th week it starts to develop
- This is a good starting spot because a number of the problems seen in the hip start that early
- There is a condition called developmental [dysplasia of the hip](https://en.wikipedia.org/wiki/Hip_dysplasia#)
  - It used to be referred to as congenital dysplasia of the hip, but there are more factors involved than any congenital ones in particular

***Basically what happens is if the hip is not concentrically reduced either late in stages of pregnancy or in early childhood (the first several months of life), the acetabulum will not form properly***

- For example, if the ball is shifted out of the socket, let’s say due to positioning in utero where it’s not completely in, the acetabulum will not form correctly
- What that means is that after birth, if it’s sitting outward, this deep socket will not form and it’ll be quite shallow
- That has major implications later in life because if it’s not deep in the socket, it’s sitting on the edge of the socket, which means there’s greater pressure here, and that pressure can lead to mechanical overload and **arthritis**

> “*Even conditions that happen much later in life can start quite early*”‒ Adam Cohen

**Peter’s son had hip dysplasia at birth**

- One of Peter’s kids was breached, and as soon as he was born, they immediately said he has hip dysplasia
- He was in a brace (called a [Pavlik harness](https://en.wikipedia.org/wiki/Hip_dysplasia#Harnesses,_casts,_and_traction)), splayed open for nine months
  - It’s actually quite comfortable for the child
  - He basically only came out of it for a bath
- But nine months later, his hips were fine (remarkably)

**Adam’s takeaway** ***‒ We know that if the ball is not sitting in that socket, it will not form properly***

- So the harness keeps that positioning until the acetabulum forms properly
- The exams that pediatricians do, we always check the hip and we want to make sure that it’s in the socket
- Going forward, a lot more physicians and orthopedic pediatric specialists are using [ultrasound](https://en.wikipedia.org/wiki/Ultrasound) to better quantify that the hip is in the socket because we really don’t want to miss any dysplastic hips

***If you have a dysplastic hip, you are going to get arthritis***

- Dysplastic hips are not necessarily symptomatic
  - It doesn’t mean you’re going to need a hip replacement
  - But the acetabulum is not formed properly, and it’s a mechanical problem where the forces are unevenly distributed across that ball and there’s edge loading and that will break down over time no matter what you do
  - People with this are going to get arthritis

**Do we have a sense of the incidence of developmental dysplasia of the hip?**

- It’s about 1 in 1,000
  - Discussed in [*JAMA* in 2022](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2795295)
- An exam would miss more than ultrasound, and we shouldn’t miss any
- The ultrasound is not that hard to do (certainly teachable), and it confirms that the ball is in the socket and the socket is healing properly
- An animal study done many, many years ago put a cube shaped object in the acetabulum and found the acetabulum formed in the shape of a cube
  - It is going to develop based on what is sitting in that area
- If you wait too long, what happens is the soft tissue deep in the socket will become hypertrophied and it’s harder to get in
- Adam has patients (age 28-29) come to see him because their hip hurts
  - They never had a problem before, did not suspect anything wrong
  - They get an x-ray of the hip and are shocked to learn they have arthritis

**Arthritis of the hip [8:45]**

*Arthritis can be diagnosed with an x-ray*

- A plain x-ray is good enough to diagnose arthritis when it is symptomatic because you’ll see the absence or thinning of **cartilage**
- There is a spectrum where the process starts to happen before we’re even clinically aware of it, and detecting that is the future
  - The trick is to find out before someone has clinical arthritis: do we know about it, and what can we do to avoid it?

*Defining arthritis [9:30]*

- This is an important conversation Adam has with his patients
- The ends of all long bones have [cartilage](https://en.wikipedia.org/wiki/Cartilage) at the end (it’s a very smooth layer), and the only reason joints move pain free, without friction, is because of that cartilage
  - The coefficient of friction of cartilage is so smooth
  - It’s smoother than ice on ice; it’s smoother than Teflon
  - Cartilage is a biological substance that is constantly remodeling (albeit slowly) and can adjust to pressures

- Part of arthritis is the loss of that cartilage
  - The cartilage starts to thin
- Cartilage itself is avascular, and it gets nutrition through diffusion from the joints
- [Chondrocytes](https://en.wikipedia.org/wiki/Chondrocyte) (which is the cell of cartilage) create proteins to make the extracellular matrix so that it remains healthy, but they’re not very efficient at making the extracellular matrix, which is imperative
- If there is overload of the cartilage, the chondrocytes will respond and sometimes they die, sometimes they go into [senescence](https://en.wikipedia.org/wiki/Senescence)
- Take the knee for example, 2% of the cartilage is chondrocytes
  - They don’t have a lot of leeway when the load is substantial

## Diagnosing hip pain in people under 50, stress fractures in the femoral neck, and more [11:15]

**When a person comes to your office complaining of hip pain, what are the top three most common diagnoses for a person under 50?**

- Right away, Adam is thinking about the different layers of the hip from deep to superficial
  - Is this a bone problem?
  - Is it a bone cartilage problem?
  - Is it a connective tissue problem, a ligament problem?
  - Is the capsule too loose? (the ball is held in the socket by capsular layer)
  - Is it a muscle and tendon problem?
- We also have to recognize that sometimes hip pain is referred pain, that is, it could be coming from your back
- Adam’s also thinking about locations ‒ someone who has pain in the front of the hip is different from someone who has pain in the side of the hip or back of the hip
- So someone under the age of 50 would not necessarily be thinking about arthritis, but it obviously is always on your mind
- Finding out a clue to what the diagnosis often depends on when it hurts, where it hurts, and what their activity is
- Adam thinks about different types of patients: the endurance athlete, the power athlete, the non-athlete, the individual who is flexible (gymnasts, ballet dancers)
  - They have different patterns of hip problems

**Problems for endurance athletes start deep down in the joint**

- The first thing we have to rule out is that this is not a [stress fracture](https://en.wikipedia.org/wiki/Stress_fracture)
- Stress fractures can happen in a lot of different areas in the lower extremity, and we separate them out to high risk stress fractures and low risk stress fractures
- There is a risk of bad consequences if not treated
- If someone comes in and they have a marathon coming up and they say, “M*y hip hurts*,” we have to make sure that this is not a stress fracture

***A stress fracture is something that occurs slowly due to load on the bone that is in excess of what the normal healing capacity is***

- Bone constantly remodels, and every time we put stress on it, the micro-architecture is changing
  - There’s small tiny micro fractures that occur from normal weight-bearing
  - The body is very capable of adjusting to that load and making new bone

> “*When you start exercising, or working out, or running, the bone will get stronger based on the stresses that that bone sees*”‒ Adam Cohen

- When runners are training properly, there’s no reason to expect that that bone can’t adjust to the increased load that it’s seeing
- But oftentimes, due to over training, where you’re not giving that bone enough of a chance to heal, you develop these tiny little micro-fractures that aren’t given enough time to then heal, and then it gets compounded when you go run the next day and the next day
  - You’re increasing not only the number of times that you run, but you’re increasing the distance and the speed all at the same time
- You get **groin pain** because that’s where stress fractures of the **femoral neck** hurt

**The first thing Adam rules out is a stress fracture in the femoral neck**

- They occur in two locations: the compression side and the tension side of the femoral neck (indicated in red in the drawing below)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f3-adamcohen.png)

**Figure 3. A stress fracture in the femoral neck occurs at either red mark; the source of the blood supply is indicated by the blue arrow.**

- Stress fractures in the tension side are much more severe than in the compression side
- But the bottom line is that we need to know that this exists
- The **patient will feel groin pain** akin to what you would feel if you pulled a muscle, except it’s very weight-bearing dependent
- Most people come in and say, “*I think I tore a muscle. I think I have a muscle strain.*”
  - Adam doesn’t see a lot of muscle strains in runners without an injury
  - You’re not necessarily going to get an acute injury like that

***When patients have pain in the groin, Adam doesn’t let them run until you’ve found out if it’s a stress fracture***

- An MRI is the gold standard for diagnosis
- You always need to get x-rays to make sure the joint looks healthy
- There are other conditions that can cause groin pain, but it’s usually negative
- It’s usually hard to detect a stress fracture right when the pain starts
- The MRI is the gold standard to see that
  - It used to be bone scan, but that is impractical
  - An MRI really is excellent at looking because you can see the architecture of the bone and you can see what we call edema in the bone (or a bone marrow lesion), and sometimes a crack in the bone
- The diagnosis is graded ‒ there’s stress reactions and there’s a stress fracture
  - A **stress reaction** is like a pre-stress fracture
  - The reason why it’s a high risk stress fracture (as opposed to a low risk) is if it becomes a complete fracture

**What is a complete fracture of the femoral neck?**

- A complete fracture is where this completely separates from the ball, and that’s very important in this area because the blood supply to the head comes from this direction
- So all of the nutrients that the ball sees comes from this direction (indicated by the blue arrow in the drawing above)
- If this breaks and the blood supply is disrupted and not corrected quickly, then the bone in that area no longer has blood supply
  - It will die and can’t support the cartilage anymore
  - The cartilage will collapse, and you get [AVN (avascular necrosis)](https://en.wikipedia.org/wiki/Avascular_necrosis) of the head and that is a hip replacement
    - Which is obviously difficult for anybody

**Treatment for a stress fracture of the femoral neck**

- Rest
- If the stress fracture is on the **compression side**, you can go on crutches until you start to have no pain with weight-bearing
  - Once you have no pain with weightbearing, you can continue along that path
  - It takes **s*****ix to eight weeks to heal***, and then you can slowly start up your exercises to regain some of your endurance, physical therapy, etc.
- Oftentimes Adam will get a follow-up MRI to make sure that it is healing and not increasing
- If the stress fracture is on the **tension side**, it can more likely displace mechanically
  - That often will need to get ***surgery***, which is to put pins in
  - We will often just put three pins from here to here into the femoral head and it will heal and they heal quickly
  - And oftentimes you can let that individual bear weight sooner than if they had a stress fractures on the compression side
  - The recovery is quicker because they have to go to surgery
    - Adam has had patients with compression side stress fractures who were having so much difficulty with getting onto the subway, getting to work with the crutches, they wanted to have the surgery so that they can do that

## Common hip injuries, gender differences, and problems that occur when the hip isn’t formed normally [19:30]

- In the under 50 population, Peter has seen far more female patients have hip issues than male patients
  - He has had a number of young women (typically in their 40’s) who have had hip resurfacing and labral repairs
- There are different patterns of hip injuries

**In women**

- There are certain conditions of [ligamentous laxity](https://en.wikipedia.org/wiki/Ligamentous_laxity) that are more prevalent in women
- [Developmental dysplasia](https://en.wikipedia.org/wiki/Hip_dysplasia) is more prevalent in women, and sometimes that is the inciting issue

**In men, femoroacetabular impingement (FAI) is more prevalent**

- There are other types of hip problems that are more prevalent in men
- There’s a condition that we often have to treat that has implications to a lot of the structures around the hip called [femoroacetabular impingement (FAI)](https://en.wikipedia.org/wiki/Femoroacetabular_impingement)
- This involves a bump that develops on the front of the femoral neck (colored in red in the figure below)
  - You get a prominent bump of bone

![](https://peterattiamd.com/wp-content/uploads/2023/07/f4-adamcohen.png)

**Figure 4. Location of the bump of bone responsible for femoroacetabular impingement, shaded in red.**

- This area is called a **CAM lesion**, and what happens is it changes the shape at the head and neck junction so it’s not really spherical but rather an oblong shape
  - So that when it goes into the acetabulum, it can pinch on the acetabular rim
    - On the acetabular rim is not only the cartilage but the labrum
- In the picture below, if we open up the hip and we look inside, the cartilage is colored blue, and this lining is called the labrum

![](https://peterattiamd.com/wp-content/uploads/2023/07/f5-adamcohen.png)

**Figure 5. Anatomy of the hip joint with cartilage indicated in blue**.

***If the ball is no longer spherical, but oblong, the CAM lesion will pinch on the labrum and the labrum will tear and will injure the cartilage that is connected to that area***

**How does this happen?**

- In males, the growth plates close in the late teen years (it occurs slightly earlier in females)
- Repetitive stress from **high stress sports** such as hockey, football, basketball can cause an impingement and now the growth plate will have a delayed closure
  - This allows new bone to form in that area
- Because the growth plate closes a little earlier in women, this may not be as much of an issue
- It may also the the power type sport, where there’s a lot of ground reaction force when you land that tends to make this situation worse
- This is important because one of the risks of FAI that continues is you can get **arthritis**
  - Because if the cartilage is being injured, then there is an increase risk of needing a procedure later in life

**What is the role of the labrum in stabilizing that joint?**

- In the shoulder, the labrum creates kind of a vacuum around the glenoid head
- The hip seems to be a much more stable ball and socket than the shoulder
- In the hip, the labrum helps to create a seal around the ball and a sort of suction effect too (very similar to the shoulder)
- We have dynamic stabilizers in the hip

***It becomes more of a concern when the hip isn’t formed normally***

- When the hip isn’t formed normally, the acetabulum becomes flatter, which mimics the shoulder a bit in terms of lack of stability
- Some of the patients who have instability of the hip have some dysplasia such that the ball it’s never really in the hip
  - They have greater motion, and ballet dancers would be a perfect example of that
    - That comes at the cost of less stability
- Some of those individuals have a **hypertrophic labrum** where it gets bigger because it’s being asked to do more
- The ligament in the hip (the [ligamentum teres](https://en.wikipedia.org/wiki/Ligament_of_head_of_femur) shown in the previous figure) is a round ligament, and we didn’t think that did much
  - It provides some blood supply early on in life, and then later on doesn’t really provide much blood
  - But for people who are unstable, this provides a secondary restraint because the ligament connects the ball to the socket
  - So one thing we need to be aware of whenever you’re operating on the hip is to leave that alone in individuals who are unstable because it’s providing a bit of stability to that area

## Advancements in hip replacement surgery [25:15]

- In a hip replacement, basically you’re taking off the neck, and you’re inserting a metal stem down the shaft of the proximal femur
- Then you’re putting a metal cup in that region, and there’s different ways to do this, but the metal cup has a plastic liner on the inside (made out of [ultra-high molecular weight polyethylene](https://en.wikipedia.org/wiki/Ultra-high-molecular-weight_polyethylene))

**Why has that operation become so tolerable compared to the version of that operation Peter saw in medical school?**

*Today, it’s an outpatient surgery, and people go home and seem to recover so well, yet, 30 years ago, people used to be debilitated by that operation*

- A lot of the approaches are different now, and in every aspect of the surgery, technology has helped us
- When Adam was training as a resident, almost all of the hip replacements were done through a posterior approach (an approach through the back muscles)
  - The [gluteus muscles](https://en.wikipedia.org/wiki/Gluteal_muscles) were getting cut
- Now you go anteriorly, and it’s much easier to spare the muscle and ligaments when you approach from the front
- This is not one of the surgeries that Adam performs
- Today, patients are managed differently around the surgery ‒ they’re given medicine to decrease blood loss
- The whole process has become much more efficient and safer

**Does resurfacing leave the femoral head intact and only address the acetabulum?**

- No, it’s the opposite
- This is not a procedure that Adam does, so he’s not going to speak to the intricacies of that
- There are ways to preserve the amount of bone if the individual is young

## Common hip problems in people over age 60 [27:30]

**What problems of the hip are common in people over age 60, 65?**

- Arthritis and fracture are dominant injuries
- Adam also sees muscle and tendon problems
- Particularly, issues with the tendons on the side of the hip
  - This is not just in older individuals, but all individuals
- The main abductor of the hip is the [gluteus medius](https://en.wikipedia.org/wiki/Gluteus_medius), which is shown coming out in the diagram below
  - It sits on the back of the pelvis and attaches at the edge on the lateral or the outside of the femur
  - The gluteus maximus is not shown in the diagram below

![](https://peterattiamd.com/wp-content/uploads/2023/07/f6-adamcohen.png)

**Figure 6. Location of the gluteus medius**.

**Adam considers the** [**gluteus medius**](https://en.wikipedia.org/wiki/Gluteus_medius) **and the** [**gluteus minimus**](https://en.wikipedia.org/wiki/Gluteus_minimus) **to be the rotator cuff of the hip**

- Similar to the rotator cuff, it starts to degenerate after a certain age

***Weakness of the gluteus medius is very difficult because it’s incredibly painful, and it doesn’t have great healing potential***

- We see this in **endurance athletes** as well from **repetitive stress**; we also see this in **unstable patients** because those muscles are trying to dynamically keep the ball in the socket, so they are working harder
- **Ballet dancers** in particular have incredibly large and powerful gluteus medius minimus
  - Part of the reason is because they’re asked to do a lot to stabilize the hip
  - So we see tears there all the time and we often approach that just like a rotator cuff

**So are most of the injuries you see here, underuse or overuse?**

- Peter adds, “*It sounds like they’re mostly underuse*.”
- Adam doesn’t think so, but it depends

***The older we get, it doesn’t necessarily matter whether it’s overuse or underuse; these things will happen because that is just a normal trajectory of tendon problems (tendon pathology)***

- The tendon cells, over time, start to degenerate just like all of our cells and they go through a process of [senescence](https://en.wikipedia.org/wiki/Senescence) (like all tissue), and those senescent cells produce those factors that lead to degeneration of the tendon, cause inflammation and an incredible amount of pain
  - It’s hard to treat
  - It’s hard to reverse the process
- Now, if you knew it was happening before it started, would you be able to do anything?
  - We don’t have that ability yet, but we’re trying to figure out how to intervene before these injuries take place

## The importance of muscular strength around the hips for injury prevention [30:30]

**Peter sees a need for deliberate exercise to strengthen those muscles**

- When he used to be a cyclist, one of the challenges was becoming strong in one dimension
  - You get very, very strong quads, glutes, and hams
  - Your glute med and min do very little, and you’re not really doing any abduction of the hip, and as such, you get a very tight [tensor fasciae latae](https://en.wikipedia.org/wiki/Tensor_fasciae_latae_muscle) (labeled in red in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f7-adamcohen.png)

**Figure 7. Muscles of the thigh with the tensor fasciae latae labeled in red**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Tensor_fasciae_latae_muscle)

- A lot of cyclist get really bad [IT band pain](https://en.wikipedia.org/wiki/Iliotibial_band_syndrome) because they just lack strength there, and Peter was having debilitating IT band pain
- There is an obvious way to fix this which Peter was able to do non-surgically ‒ simply doing a lot of strengthening for the abductors

**Could this be preventive in some way?**

- If Adam could pick any muscle that needed to be worked on, it would be that muscle group (the **tensor fasciae latae**)
  - Start working on that from the early teens
  - It is implicated in so many lower extremity injuries at the hip and the knee

***A weak gluteus medias, weak abductors can cause a lot of injury, and it’s almost like bones, the stronger they are (the higher bone density you get early on), the longer it lasts, because it’s going to degenerate***

- Not only are you likely to have less injury ([ACL injuries](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury) too), but also knee injuries
  - It holds back the [valgus](https://en.wikipedia.org/wiki/Valgus_deformity#Terminology)

**Hip fractures**

- Hip flexors are incredibly strong ‒ the [psoas](https://en.wikipedia.org/wiki/Psoas_major_muscle) and [iliacus](https://en.wikipedia.org/wiki/Iliacus_muscle) are collectively known as the [iliopsoas](https://en.wikipedia.org/wiki/Iliopsoas) (shown in the figure below)
  - The Iliopsoas is what lifts your leg up if you stumble to save yourself

![](https://peterattiamd.com/wp-content/uploads/2023/07/f8-adamcohen.png)

**Figure 8. Hip flexors: psoas major and nearby muscles**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Psoas_major_muscle)

- There was a study done in South Korea that retrospectively evaluated elderly people who came in with a hip fracture (a femoral neck fracture)
  - They took CAT scans and measured the volume of their psoas muscle
  - The volume of that muscle was significantly smaller than that of an aged-matched control group who were getting CAT scans for other reasons
    - Now we don’t know why they were getting CAT scans, so that’s a little bit confounding
  - It showed that there was a significant decrease in volume in those patients who have hip fractures

**It’s important to get the hip abductor and the hip flexors strong and flexible**

- The problem with the [hip flexors](https://en.wikipedia.org/wiki/List_of_flexors_of_the_human_body#Hip) is that we’re always sitting
  - Even if they’re strong, and they’re often tight because we’re always in this position

***It’s important to make sure that they’re flexible because an imbalance in the flexibility of that muscle group will also impact the antagonistic muscles in the back, the gluteus maximus (which extends the hip), and the hamstrings (which also extend the hip)***

- Peter has become obsessed with the hip adductors and the importance of training them not just in the concentric phase but also eccentrically
  - He does exercises in the philosophy of [dynamic neuromuscular stabilization (DNS)](https://peterattiamd.com/michaelrintala/)
- This morning, Peter was doing a position called [DNS Star](https://youtu.be/Sl0GrgwyXcQ) (he does this most days)
  - You’re laying on your side, so if he’s on his right side, his right elbow is down
  - It’s sort of like a plank, but you’re on the knee and your hips are up and you’re extending yourself forward as you’re putting the hip back
  - You are eccentrically loading the adductor as you go back, and then you’re concentrically loading it as you bring yourself back up
  - If you do five reps of this slowly, you feel like someone is jamming an ice pick into those muscles; it’s remarkable how difficult it is
- Peter adds, “*You don’t need to do a lot, just a little bit of that stuff every day does so much in terms of lower body maintenance*.”
- Looking at this picture, Peter thinks it’s clear ‒ these small muscles have an unfavorable angle for leverage at their attachment in terms of contraction, so it has to be strong

## Hip fractures due to osteopenia and osteoporosis [36:00]

- Putting aside the 25-year-old skiing freak accident, let’s talk about the more predictable and far more catastrophic fractures of the femoral neck that occur in people due to osteoporosis and osteopenia
- Peter talks about these stats all the time and nobody believes them because they’re so absurd, “*If you’re 65 or older and you fracture that hip (depending on the study) 15-30% one year mortality.*”

**Can you explain why that is? How do these people present to you and why is it so challenging to take care of that fracture?**

- In a large percentage of those people, usually another disease has taken over their lives
  - They may have advanced stage cancer, they may have advanced renal disease, and the fracture is almost the last straw
- Hospitalization alone is catastrophic
- First, if you break your hip and come to the hospital, there has to be some medical management to make sure that it’s safe to proceed with surgery
- Everybody who has a hip fractures needs surgery
  - You can’t treat this non-operatively; to do so would be a death sentence
- The goal is to mobilize as quickly as possible
- Mortality of 20-30% within the first year has been stable for a number of decades
- The goal is to get you up and moving

**How much of that mortality is acute because of surgery versus failure to thrive and they tie within the year?**

- It’s not so acute; it really is spread out
- The management of these patients is very important early on
  - Adam likes to get a full team on board, a geriatric specialist
  - You need a team approach because you need them medically optimized before surgery so that they could safely go through the surgery
- Surgery should be done within 48 hours
- Before the medical management model of hip fractures, oftentimes you were able to get the surgery done quicker
- Now we have to do other things: get an echo, make sure the bloods are okay
- This probably gives better outcomes perioperatively; people get discharged sooner
- But the long-term outcome is still 20% [mortality]
- First of all, if you broke your hip, there’s a good chance you are weak
- Now your NPO (nothing by mouth)
  - The first day you come in no one will feed you anything; you don’t get a meal
- Then you’re in bed for two days, you have surgery and are in bed for a week

***Even for the people who don’t pass away, there’s about a 50% loss of function***

- If you were using a cane before, you’re using a walker
  - If you were using a walker before you’re now in a wheelchair
  - If you were walking normally, you might be using a cane
  - 50% of people go down a level in performance
- Early in Adam’s career, when he was a junior attending, a resident called to him and said, “*We have a patient with a femoral neck fracture. He is 40 years old. He was riding on the Westside highway and he crashed and he broke his femoral neck.*”
  - Adam advised him to consent the patient for surgery
  - When Adam goes in to see the patient he expected him to be miserable, but he said, “*Your resident just told me I have a 30% chance of dying this year*.”
  - The resident forgot to age adjust that
  - Adam told him, “*Don’t worry. You’re not going to die. Somebody else is, but not you.*”

## The utility of biological therapies like stem cells and platelet-rich plasma (PRP) [40:30]

Talking about degeneration of the hip, the first thing that comes to Peter’s mind is, “*Where do stem cells play a role here?*”

- When he hears that tendons, muscles, cartilage, and the osseous structure of the bone is going to weaken, all of those things makes him wish he could have newer and younger cells there

**What do we know about the utility of stem cell therapy here? What’s the state of the art today?**

- There are a lot of layers to this conversation because there’s the dark side and the bright side of this
- When we talk about **orthobiologics** (or biologics in general) it’s a class of therapies that are using your own natural resources to promote healing
  - You’re using a biologic product to encourage healing of diseased or injured tissue
- The most commonly used ones are blood, specifically platelets, bone marrow, bone marrow aspirate concentrate it’s called, and also fat
- For [PRP (platelet-rich plasma)](https://en.wikipedia.org/wiki/Platelet-rich_plasma), we take your blood (we draw it), and we take it down the hall and we spin it in a centrifuge
  - The centrifuge machine will separate out the different elements of the blood based on the density of those elements
  - After you’re done spinning it, you have a layer called the plasma layer (which is rich in plasma and platelets), and it separates out the red blood cells and a lot of the white blood cells
  - Now, you could spin it twice, you could do two-spin technique, you can spin it so that you’re keeping some of the white blood cells
    - We’ve categorized it into leukocyte-rich PRP, and leukocyte-poor PRP
  - This is a very simplified way that we think about it right now, and there’s certainly, if we fast-forward 10 years from now, this will be a ridiculous conversation because we are sort of in our infancy of understanding what we’re doing here

**The principle of PRP is we take those platelets which are involved in healing**

- We know this because if you cut yourself, the first thing that happens is the platelets come to the surface to form a blood clot and to form a scar, and then you heal
- Platelets are associated with an incredible amount of growth factors and healing factors, including the 800 to 1,000 proteins within the plasma
- You inject those platelets into a tendon, a joint with arthritis, a muscle and see what happens
- The problem is that as a physician you are allowed to do that procedure
  - There’s no rule that can’t say that anybody comes in and they say, “*I have this injury, can I have stem cells?*” And you say, “*Oh, sure. Let me give you a PRP*,” and I spin it and I inject it

**What does the actual science say about what’s actually working?**

- We’ve learned that it works for some things pretty decently and other things not well at all
- And we can only go by our randomized controlled trials and systematic reviews of randomized controlled trials to find out what seems to work
- 1 – [**Tennis elbow**](https://en.wikipedia.org/wiki/Tennis_elbow) seems to work with PRP
  - There’s good tier one data, maybe tier two data that suggests that it works for tennis elbow
- 2 – It works pretty decently for [**gluteus medius**](https://en.wikipedia.org/wiki/Gluteus_medius) **tears** and for **tendons**, and that’s about it
- Some will argue maybe in the **hamstring tendon** it works, but Adam is not convinced

**Are you talking specifically about PRP, or are you talking about the broader umbrella of stem cells?**

- The broader umbrella of stem cells don’t seem to work
- This is a very important point ‒ the cells in PRP are not stem cells
- The only stem cell therapies approved in the US are for blood disorders; there are no other stem cell therapies
  - The [FDA has a big warning page](https://www.fda.gov/consumers/consumer-updates/fda-warns-about-stem-cell-therapies) with a video that explains there are no stem cells
- Stem cells implies that I’m going to inject cells into you and those cells are [pluripotent](https://en.wikipedia.org/wiki/Cell_potency#Pluripotency)
  - They have the ability to become something else, and those cells are now going to become your cartilage or your tendon
    - That doesn’t happen

**What is the identity of the stem cell? What is the signature that allows a doctor to believe they have a stem cell?**

- Everybody Peter knows goes abroad for stem cell therapy
  - They tear the rotator cuff and go get stem cells injected and six months later the rotator cuff is fine without surgery
  - Cells in these clinics are typically not [autologous](https://en.wikipedia.org/wiki/Autotransplantation)
- Adam points out, “*It’s illegal to actually give stem cells. A few years ago, people were able to get products that were manufactured by companies who were selling umbilical cord blood or some derivative of umbilical cord, some umbilical product as stem cells. Wharton’s jelly, some of it’s called exosomes. All these things are not allowed. The FDA will not let you inject this into anybody.*”
- The FDA allows you to use your own [autologous] as long as it’s not manipulated, or what is considered minimally manipulated
  - You can take your bone marrow out of the pelvis and we get it from the pelvis, and you can concentrate that, but you can’t give any enzymes to it
  - You can’t digest it
  - You can’t make any changes to that product
  - You can only give it as is
- Fat has actually shown some promise with **osteoarthritis of the ankle**; there are some very good studies on ankle osteoarthritis and fat injections
  - Same with **knee**
  - You can do that because you’re minimally manipulating the fat
    - You are taking it and making it into smaller fat particles (it’s micronized fat), but you are not essentially altering the fat itself

**Is the idea that micronized fat regrows as cartilage?**

- No
- We don’t know what it grows as

> “*Right now, our best understanding of biologics in reality is that it reduces symptoms… It’s a good symptom modifying treatment when it works because we don’t have a lot for arthritis/ tendon problems.*”‒ Adam Cohen

**Current treatments for arthritis**

- Our toolbox of things to use when someone comes in with knee arthritis or hip arthritis are pretty pathetic
- You’re going to go to PT (physical therapy) because that’s been shown to help
- A brace might help
- Maybe take some [COX-2 inhibitor](https://en.wikipedia.org/wiki/COX-2_inhibitor) anti-inflammatories and some cream
- Adam summarizes non-surgical treatment, “*The repertoire of what I prescribe is pretty pathetic*.”
- There’s an opportunity with the biologic field to reduce symptoms in a safer way than say cortisone
  - Because cortisone is quite effective and safe as long as you’re not injecting over and over again

***There’s a space for biologics that is very reasonable, and the randomized controlled trials show that it works for knee arthritis probably better than anything***

**Criticisms of randomized controlled trials of PRP therapy [49:00]**

*Why don’t we have RCTs that can answer these questions definitively?*

- There are few things that Peter discusses with people in medicine that creates more polarization than the use of biologic therapies
  - People who have had these procedures will swear up and down by them when they work, but we don’t understand how they work
  - Of course we don’t have the counterfactual here, which is it’s possible your arm was just going to get better on its own
    - The only way you can ever escape that is with randomized controlled trials
- To that point, Adam points out, “*If we inject saline into somebody’s joint, a number of those patients are going to get better. That’s sort of the standard we use. How does PRP work in comparison to saline? And there are a lot of studies.*”

**Many randomized controlled trials looking at PRP have excellent results**

- Of all the data, PRP treatment for knee arthritis is the best tier one data
- It doesn’t seem to work well in hip arthritis

*Why do you think that it wouldn’t work for hip arthritis? Is it just possible that the studies haven’t been done correctly?*

- This brings up a very important point
- When you do a randomized controlled trial, let’s say for a medicine, a hypertensive medication, you know what dose you’re giving and you’re comparing it to some other treatment where you know the dose
- With platelet rich plasma (PRP), the doctor is taking your platelets of unknown concentration and unknown quality
  - They spin it in a machine either once or twice, then they end up with a produce containing a certain amount of platelets that they inject back into you
  - They don’t even know your disease process specifically

> “*When you put people into these studies, you get a lot of crappy data.*”‒ Adam Cohen

- There is a push in Adam’s industry by the Biologic Association (which is like an association of international associations; they’ve formed a biologic association registry called BARB) to create a **bio registry**
  - They want to know everything about what you’re injecting, the concentration of the blood you took from the patient

*What percentage of docs who are regularly giving this therapy are participating in the registry to the point where we can generate information?*

- Compared to the total, very few
- But it’s enough people that we can get really good data to find out what’s the dose, what’s the critical dose of platelets that we need to affect change
- We can also do a proteomic analysis of the actual fluid itself
  - And you match that with outcomes data from the registry
- You have a bio repository and a registry combined
  - Who did well and what did they get?
  - And they save samples of that stuff, too

**Peter’s takeaway** ‒ At best, this can only inform what a RCT (randomized controlled trial) should do; those data by themselves don’t tell us anything

- But this gives information that helps to lead the trial
  - You can see what looks like it works and try a particular dose

**Right now, PRP looks more effective at reducing symptoms than cortisone in the knee for arthritis.** ***Is there any reason to believe it can delay the requirement for total knee replacement?***

- Maybe if we look over the course of a year
  - Because this is what those trials looked at
  - Cortisone works very well in a short timeframe
    - It’s impressive for the first couple of weeks after you get one, and it helps
    - But in are some people the pain comes right back; it doesn’t have staying power

***When you compare steroids to PRP and look out over a year, the PRP patients are doing better***

- [Hyaluronic acid](https://en.wikipedia.org/wiki/Hyaluronic_acid) is another thing we inject; it also is doing better than cortisone if you look out
  - Adam doesn’t know if it’s a drug, he thinks it’s classified differently like a device but he’s not clear on that
- A [study](https://www.arthroscopyjournal.org/article/S0749-8063(20)30843-4/fulltext) of hyaluronic acid and PRP together seem to be more effective than other treatments we have
- The question is, “*Is it disease modifying?*”
  - There are studies that show it may be pushing off knee replacements for those patients, but Adam thinks we still don’t really know

**Inaccurate marketing of stem cell therapy**

- Adam cautions, “*There is so much deceitful behavior out there with regards to stem cell therapy that the organizations involved and the FDA and the Federal Trade Commission and CMS are all trying to crack down on the problem of people advertising “Come into my clinic. I have stem cells… It’s 100% guaranteed to help.”*”
- One of Adam’s colleagues at NYU did a [study](https://pubmed.ncbi.nlm.nih.gov/31770294/) where they looked at a thousand websites, and 94% of those websites who were promoting stem cell therapy were making inaccurate statements
  - And it just engenders distrust between doctor and patient
- About two weeks ago, Adam had a close friend from high school send him a brochure because he wanted to get an injection from his doctor of something like an umbilical cord or Wharton’s jelly injection (which is not allowed)
  - He circled on the brochure where it said, “*This is not intended to treat any condition*,” sent it back, and his friend said “*Nevermind*”

## Cortisone as a treatment to delay the need for surgical intervention [53:30]

**Before we leave the hip, what is the role of cortisone as a treatment to delay the need for surgical intervention?**

- Adam doesn’t love it because he worries about what it’s doing to the cartilage
- Because the hip replacement is such a successful operation, he is more apt to push for it (in the appropriate patient) than a cortisone injection
- The satisfaction rate for hip replacement surgery is 90-95% and the complication rate is low
- That’s not to say he doesn’t do it or wouldn’t do it, because there are certain circumstances that he would
- Adam would also give hyaluronic acid in the hip, although it’s not FDA-approved
  - It can be used off-label for that application
  - There are some studies to suggest that the gel can help
- We also know that if you give an injection right before hip replacement, there’s an increased risk of infection, and this is something we need to be cautious about

## Anatomy of the knee [56:30]

**Anatomy of the knee**

- The knee is more unstable than the hip joint
- If you look at the front of your knee, you often see that rounded area in the front ‒ that’s your kneecap or [patella](https://en.wikipedia.org/wiki/Patella)
- The quadricep tendon attaches to the top of the patella (shown in the model below), and then that tendon continues on as the patella tendon and attaches to the bone at the tibia

![](https://peterattiamd.com/wp-content/uploads/2023/07/f9-adamcohen.png)

**Figure 9. Model of the right knee.**

- If we fold the model of knee over and look under the surface of the kneecap, you can see the cartilage on the patella
- All joints have cartilage; this allows the end of the bones to glide smoothly
- On the side are the collateral ligaments, so the [medial collateral ligament](https://en.wikipedia.org/wiki/Medial_collateral_ligament) and [lateral collateral ligament](https://en.wikipedia.org/wiki/Fibular_collateral_ligament) [labeled in the diagram above]

> “*We’re always interested in maintaining the cartilage because once that disappears, we have trouble.*”‒ Adam Cohen

- The figure below shows the [anterior cruciate ligament](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament) and the [posterior cruciate ligament](https://en.wikipedia.org/wiki/Posterior_cruciate_ligament)
  - They’re called cruciate ligaments because they cross
  - [cartilage is represented in blue]
- Looking directly inside, you see two semicircular structures that are called the [menisci](https://en.wikipedia.org/wiki/Meniscus_(anatomy)) [singular meniscus]
  - You have two, the [medial](https://en.wikipedia.org/wiki/Medial_meniscus) and [lateral menisci](https://en.wikipedia.org/wiki/Lateral_meniscus)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f10-adamcohen.png)

**Figure 10. Model of the knee bent to show the structures inside.**

- You can see those cruciate ligaments better if we look at a picture instead of the model (below)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f11-adamcohen.png)

**Figure 11. Drawing of the right knee without the kneecap, \* labels each meniscus**.

- You can also see the meniscus (labeled above with a \*)
- The main role of the meniscus is to **distribute force** across that knee and they’re imperative to maintain the surface of the joint, the cartilage, from wearing down
  - Collectively, the menisci make up the bulk of the cartilage surface of the tibial plateau
  - Its function is to distribute stress; it distributes about 30% of the load of the knee through the joint
  - Without that meniscus, you end up having point loading or edge loading, and it will cause degeneration of the cartilage pretty rapidly if it’s removed
- The ligaments provide **stability** to the joint
- The anterior [cruciate ligament (ACL)](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury) is a commonly torn ligament
- Just to orient people, you’re looking at the right leg
  - The fibula is that little small bone on the outside, and we see both its attachment to the tibia (the platform on which the knee sits) and the lateral collateral ligament

## Are activities like running that amplify forces bad for the knee? [59:45]

**Peter always hears people talk about how running and walking amplify forces at the knee**

- When you’re running, you experience 8x the force of your body weight at the knee

*Is this correct, and if so, why is that the case?*

- It depends which joint you’re talking about
- If we’re talking about the kneecap, the amount of load that the kneecap sees with activities like squatting and lunging (not even a deep squat, just a regular squat), the pressure behind the kneecap is about 7x greater than the weight on your back
- The cartilage has an incredible responsibility here

**Is running good or bad for your knees?**

- One of the most important conversations that Adam has with patients is, “*Is running bad for me? Is this activity good for my knee or bad for my knee?*”
- The truth is we kind of know the answer to this in general: no activity is horrible for cartilage
- If your leg is put in a cast and we then look at your cartilage in a couple of weeks, the content of that matrix is going to be significantly depressed

***Nothing is worse for you than inactivity, but it’s an inverted U-shaped curve***

- Peter thinks it’s not symmetric U-shaped curve
  - He thinks more and more and more activity is probably better and better and better, but then you can go too far and it falls off
  - It’s not a perfect “U” where it’s pure Goldilocks where you want to be right in the middle of doing nothing and doing a lot
- Adam points out, “*We’ll never know because it’s dependent on a particular individual and so many factors.*”
- [Chondrocytes](https://en.wikipedia.org/wiki/Chondrocyte) respond to activity
  - They feel the stress and they make more matrix
  - They make all of the proteins within cartilage
  - A chondrocyte that’s being pressured is happy
  - A chondrocyte site that’s not being pressured isn’t going to do anything, and eventually it’s going to break down
- [Biomechanics](https://en.wikipedia.org/wiki/Biomechanics) also matter
  - In other words, if you watch an Ethiopian runner ([Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge)), for him to have the stride length that he has, he is hitting that ground so hard and that ground is hitting him back so hard and that’s what’s allowing him to stay in the air long enough to travel the distance he travels
  - Sure, he’s not the heaviest guy in the world. He probably weighs “a buck 20” soaking wet
  - But if he’s feeling 8x that, it’s close to a thousand pounds every time
    - But his mechanics are perfect, and Adam agrees it’s mostly mechanics

***If you have good mechanical alignment ‒ that is if we draw a line from the center of your hip to the center of your ankle and it goes right through the center of the knee, there’s a good chance you’re going to be okay***

- The center of the hip is where the femoral head (center of the ball) meets the acetabulum
- You should be able to drop a plum line from the center of the ball that cuts the patellar tendon and the patellar bone in half
- You draw the line from the center and you connect the center of the ankle
- Sometimes if you have other problems, if you are off to one side of another, and that’s where we have people who have [knock knee](https://en.wikipedia.org/wiki/Genu_valgum) or [bow-legged knees](https://en.wikipedia.org/wiki/Genu_varum), there is an increased amount of force through one of those compartments of the knee and you are at high risk for degeneration
  - Then if you get a [meniscus tear](https://en.wikipedia.org/wiki/Meniscus_tear) on top of that and you lose that surface area of force diffusion, that chondrocyte is no longer going to be happy

## Risk of future knee issues and arthritis following an ACL tear or other substantial knee injury [1:04:30]

**Once the knee is unstable**…

- Let’s say you have an ACL tear and then you measure the compressive force of that cartilage before and after an ACL tear, so a normal knee and then your contralateral knee
  - The amount that the cartilage gets compressed in an ACL deficient knee is substantially greater than an ACL intact knee
  - If you reconstruct that ligament, it still doesn’t come back to normal

***There’s something that happens once the knee is injured where the loads through that joint change, and sometimes permanently***

**Is that why if you have an ACL injury, you increase your risk of arthritis later in life?**

- You do
- You never fully get the chondrocytes back
- There are a couple issues here that we don’t fully understand
- First, a lot of it is “baked in the cake” at that injury
  - When you have an event on any joint

> “*The stats are that in about 15-20 years, half of the people who have an ACL tear (whether it’s reconstructed or not) have signs of arthritis*”‒ Adam Cohen

- Some studies show that if you’ve had your ACL reconstructed, you have a greater chance of arthritis, and that’s because you’re so active
  - You’re now able to do things because your knee is stable
- There haven’t been any RCTs that have randomized repair to no repair because it’s too hard to do
- There was a study in the 90s where they looked at the fate of doing ACL surgery versus not doing ACL surgery, but you can’t randomize it
  - This is where the data comes from that you may end up having more arthritis if you have it reconstructed
- Adam is not saying you shouldn’t reconstruct it
- We do ACL surgery because we want to protect the meniscus
  - Because if your knee’s flopping around, your meniscus is going to tear, and you’re not going to be able to play the sports you enjoy doing
  - By all means, it’s worth the risk of arthritis
- Not everybody [with arthritis in the knee] has an ACL tear; it’s 1 in 5

**Adam’s knee injury**

- Adam was hit by a car when he was 14-years-old (in the ‘80s)
- He had an [ACL tear](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury) and a [meniscus tear](https://en.wikipedia.org/wiki/Meniscus_tear)
- He had knee surgery that week, but nobody did anything
  - They just went inside and looked around (arthroscopic surgery)
  - They decided to treat it non-operatively
- The doctor came in talking to his dictaphone and said, “*14-year-old male injured his knee*”
  - Adam thought this was cool, and he’s the reason Adam wanted to be a doctor
- From age 15-30 Adam did not have an ACL
- He had a bucket-handle tear of the meniscus, which is a very severe meniscus tear
- Only at age 30 did he have the surgery done, after his fellowship was over
- He recently took x-rays of his knee, because he was curious
  - He did a standing alignment center of the head to the ankle
  - He has no arthritis in his knee, but his line is straight through the center
    - He doesn’t think that would’ve happened if he had some mechanical alignment issue
- Half people [with a torn ACL] get arthritis, half don’t
  - Within 15-20 years

**Adam does a lot of ACL reconstructions**

- He knows from his own practice that some people recover fairly well after the surgery, and there’s a small group of people who stay inflamed
- We’re identifying this cohort of patients, we call them an **inflamma-type**
  - That is if you take out their fluid, and you analyze that fluid, they have elevated [IL-1](https://en.wikipedia.org/wiki/Interleukin-1_family), [IL-6](https://en.wikipedia.org/wiki/Interleukin_6) ‒ inflammatory markers that are not coming back down to baseline in the [synovial fluid](https://en.wikipedia.org/wiki/Synovial_fluid)

> “*A lot of people recover, and then, some people go on to have sort of low burn chronic inflammation. And I don’t think this is just with ACL.*”‒ Adam Cohen

- Adam thinks this is where biologics may come in at some point to push someone back from the catabolic state to the anabolic state

## How the ACL injury happens and how it is repaired  [1:08:30]

- They are categorized as: ACL contact, ACL injury, and non-contact ACL injuries
  - The majority are non-contact
  - Some are also indirect contact
- ***Females have a higher risk of ACL tear than men***, and there’s a lot of factors
  - Including neuromuscular control
  - Early in puberty, during a growth spurt, boys tend to have testosterone, and that affects muscle growth
    - In females, that’s delayed
- You can look at **neuromuscular control factors** specifically by having patients jump off a box and see how they land (pre-injury)
  - They use this to evaluate their risk of injury
  - Females are more likely to land with a valgus knee, with an adducted hip (the leg goes in)
    - They have a weak [gluteus medius](https://en.wikipedia.org/wiki/Gluteus_medius), imbalance with the [adductors](https://en.wikipedia.org/wiki/Adductor_muscles_of_the_hip)
    - They land with their knees and valgus oftentimes with a very straight extended leg, slightly flexed, and a little bit pronated
- One of the programs Adam and his colleagues are trying to implement are **injury prevention programs**
  - They do a landing error scoring system and stratify people based on risk
  - Some receive special neuromuscular training
  - This is incredibly difficult to do

**Speculate what percent of ACL tears could have been prevented if the individual was maximally strong and had the highest amount of their genetic potential for neuromuscular control going into it**

- Peter assumes that virtually all ACL injuries are acute injuries, and he wonders how many of them are on top of a chronic weakness
- The only thing that gets close to answering that question are studies that look at injury prevention programs and follow those people
- The number that comes out of the literature is that you need to treat 90 people to save one ACL (**the** [***NNT***](https://en.wikipedia.org/wiki/Number_needed_to_treat) ***is 90***)
  - This probably speaks to how hard it is to treat, and how hard it is to prevent
- Potentially, when you strengthen the glutes; it’s also decreasing risks of other injuries too

**The mechanism**

- Adam moves the kneecap out of the way on the model of the right knee shown below

![](https://peterattiamd.com/wp-content/uploads/2023/07/f12-adamcohen.png)

**Figure 12. Model of the right knee with the kneecap moved out of the way**.

- When you land in a valgus position, what this does, we call this “condor lift off”
- You often see [MCL tears](https://en.wikipedia.org/wiki/Medial_knee_injuries) because this gets stretched
- The condyle lifts off of the surface, and that surface on the inside of the knee, this is called the medial part of the knee is the most congruent part of the knee
- On the lateral side, the surface of the tibia is convex; it’s very unstable in general
- So now, you’re only bearing weight basically on the unstable, non-congruent part of the knee
- When your foot lands in pronation by nature, the tibia internally rotates slightly at the same time that happens, the quadricep pulls, and then, it shifts out of place
- The only thing that typically will help that is that the hamstring on the back has the opposing force
  - So if you land with a flex knee, it can help stabilize the knee
- Peter adds, “*This is going to be something where people listening to us on audio will have no idea what we’re talking about*.”
  - You really have to see the model in 3D, and the way Adam describes it

**Is that also what’s happening in a ski injury?**

- Peter sees more people tearing their ACL skiing “than he can shake a stick at”
- It’s hard to know, because even when we have video analysis of skiing injuries (or even basketball injuries), sometimes it’s hard to get exactly that
- It’s probably a similar mechanism
- Hyperextension of the knee will also have the same problem
- The other problem is if your trunk is leaning over to one side at the same time, that’s an extra amount of force pushing the knee that way
- Adam sees football players get it all the time as soon as they plant, if they’re hit on their hip, and their body weight goes over that side, their foot is struck
  - There’s a lot of contact force
  - The quadricep contracts, the tibia internally rotates, it shifts out of place, and it’s ruptured

**What is the typical “cool down” period you want on an ACL when a person is injured, and what are the various considerations as to how long you might wait versus operating right away?**

- Adam prefers to wait until the knee is quiet
- He likes the initial inflammation to come down
- It’s good to go into the surgery with a quiet knee
- But there are plenty of studies that show you can do it right away, and there’s no adverse effect down the line
- Adam likes people to prepare themselves and get some prehab before the ACL reconstruction
  - So we’re all on the same page about what this means long term, and how to prevent the other side, and all the issues regarding recovery from the initial injury
- In his practice, they’re doing a lot of revision ACL reconstruction

**ACL reconstruction [1:14:30]**

*What are you typically using to repair the ACL?*

- They have different categories: [autograft](https://en.wikipedia.org/wiki/Autotransplantation) versus [allograft](https://en.wikipedia.org/wiki/Allotransplantation)
- The main autograft tendons that Adam uses are patellar tendon and hamstring
  - Although quadricep is being used a little bit more

*What part of the patellar tendon are you using?*

- We take the central third of the patellar tendon
  - So the width of the patellar tendon from medial to lateral is about 30 millimeters
  - We take 1 cm (or 10 mm) of the central third of the patellar tendon with a little bit of bone from the kneecap and bone from the tibial tuberosity, and that becomes your new graft
- It’s bone to bone attachment

**Is cadaveric ACL done anymore?**

- Yes
- You can ask for different types of allografts
  - BTB (bone-tendon-bone allograft)
  - Or you could do soft tissue allograft
- Bone to bone healing tends to be more predictable
- Allograft is really not a great idea
- In the younger cohort, there was a recent study that showed that you’re safe with allograft before the age of 34
  - The risk of a re-rupture is unnecessarily high if you use allograft
  - Because allograft tissue is somebody else’s tissue, and it takes longer for that tissue to mature and to get strong

*Typically how old are the cadavers from which you’re getting that?*

- Hopefully a young person
- There are ways to make sure you are only provided a younger tendon

**Is the main incentive to do an allograft to avoid patellar injury?**

- There are a number of reasons
- It’s an easier surgery to recover from upfront
  - People are busy and they may want to do recreational stuff occasionally (like hiking)
- If they’re in their 40s, it’s perfectly reasonable to use allograft
  - The rates of re-rupture are higher, but it’s still a reasonable option
- But if someone participates in high risk activities (level one sports), then allograft is not a great idea

**The big question is what is better ‒ the hamstring, the patellar tendon, or the quad tendon?**

- There’s not enough research to say definitively that the quad tendon is not in the game

*Which hamstring tendon are you taking?*

- It depends
- Some people take the [semitendinosus](https://en.wikipedia.org/wiki/Semitendinosus_muscle) along with the [gracilis](https://en.wikipedia.org/wiki/Gracilis_muscle); some people just take the semitendinosus
  - You can access that from the front, because the tendons attach right in the front of the medial tibia

*What happens to the rest of the hamstring?*

- It tends to scar in
- This is one of the reasons why people don’t necessarily want to do hamstring, because you have weaker hamstrings afterward
  - You do have the biceps femoris on the other side, and you have the semimembranosus that’s not affected, which are the other components of the hamstring
  - But the hamstrings will be weaker, and the hamstring is there also to protect you from an ACL injury
    - Because as the tibia moves forward, the hamstrings are pulling you back too

**Peter’s takeaway ‒** ***It sounds to me like if you can handle the additional recovery, and the pain of having your patellar tendon cranked open, that’s the better operation***

- The gold standard is still the patellar tendon, and the downside of that is it’s a little harder recovery early on
  - People do complain of kneeling pain, because of the bone removed from the kneecap, the incision on the front of the knee
- If Adam has an individual who is Catholic or active (gardening or yoga), he will recommend using the hamstring tendon

*Will 50% of people who tear their ACL need a total knee replacement within 15-20 years?*

- No, says Adam
- 50% will have arthritis, however, it doesn’t have to be symptomatic

## Arthritis of the knee [1:19:00]

- Peter realizes that an x-ray tells a big story here
- He’s seen an x-ray of his knee
  - He’s fortunate to not have arthritis
  - He has a big clear space between the femoral condyle, and the tibial plateau

**How narrow does that need to be before you would make the diagnosis of arthritis? And how correlated is the reduction in that space with symptoms?**

- It’s *not* correlated well
- Arthritis is hard to define, and Adam likes to think about **symptomatic arthritis**
  - Cartilage loss is considered arthritis, but very often it isn’t symptomatic
- When he thinks about arthritis, it’s a whole joint disease
  - The cartilage starts to break down
  - An inflammatory reaction happens
  - The [synovium](https://en.wikipedia.org/wiki/Synovial_membrane), which is on the inside of the knee also gets inflamed
  - The bone under the cartilage goes through changes

***The arthritis Adam is worried about is that whole joint arthritis; he’s not so worried about narrowing of the cartilage in isolation***

- It’s like a biologic process we’re really trying to avoid
- Adam sees people come in who were perfectly normal but say, “*My knees started hurting last week. I’ve never had a knee problem before.*”
  - An x-ray shows there is no cartilage left
  - He tells them “*I know you didn’t have arthritis, but now you do*.”

**So what tipped that person over?**

- If you took that x-ray a year earlier, it would look exactly the same
- It’s usually a traumatic event: a stumble, even nothing ‒ you lifted something heavy and twisted funny and felt a little something
  - Maybe the meniscus tears a little more

**It’s a very slow process**

- The [chondrocytes](https://en.wikipedia.org/wiki/Chondrocyte) have been not doing their thing
- The cartilage is worn away, but it’s been such a low burn that it hasn’t tipped the scale into a very painful process
- And then, it goes overboard, and it’s hard to bring it back at that point, because there’s not really any healthy cartilage left
- It’s a very difficult problem, and those people get knee replacements

## Meniscus tears: how they happen and when surgery is appropriate [1:21:30]

**The** [**meniscus tear**](https://en.wikipedia.org/wiki/Meniscus_tear) **is such a controversial area, what do we know about isolated meniscus tears?**

- Peter assumes there have been sham surgery studies
- Adam explains, “*The principle is if you have a meniscus tear and you don’t have arthritis, you need to strongly consider fixing that meniscus, because that’s what’s keeping us from getting arthritis*.”

**Does the meniscus tear mean separation from the tibial plateau, or is it a tear across the surface?**

- Below is a picture of the cross-section of the knee showing the lateral meniscus and medial meniscus
- The video also shows a model

![](https://peterattiamd.com/wp-content/uploads/2023/07/f13-adamcohen.png)

**Figure 13. Drawing of the knee with each meniscus labeled \*, cross-section shown at the bottom**.

- There are different types of meniscus tears drawn on the picture below
- There are tears that are at the periphery where there’s very good blood flow [labeled (a) in the picture below], and in those types of tears you can (and should) sew it back together

![](https://peterattiamd.com/wp-content/uploads/2023/07/f14-adamcohen.png)

**Figure 14. Different types of meniscus tears in the knee discussed in order a, b, c**.

- There are tears that go all the way across, and then, this piece can flip [labeled (b)]
  - It’s called a bucket handle tear
  - And that often will lock the knee
  - The inner piece, the outer piece is connected to the capsule
- There are tears that we call radial tears that go through here [labeled (c)]
  - Occasionally if it’s close enough to the rim, you could put sutures there, but sometimes you just need to trim it where you take out the torn piece of meniscus, and you just leave what remains
    - So that’s the difference between a meniscus repair, and a meniscectomy

**Do you primarily repair the bucket handle tear?**

- Yes, you put it back to where it is and you sew it back together

**Is all the controversy around meniscal surgery (that it is no better than sham surgery) based on a particular meniscal tear, or is it based on the fact that these studies didn’t stratify for those?**

- It’s a specific type of tear
- In general, we want to save the meniscus when we can
- So if you’re young and you have a meniscus tear, and you heard that sham surgery is no better than… that’s not you
  - You need to have your meniscus fixed, if it can be fixed
- If you have degeneration of the knee already, if you have arthritis, let’s say you have advanced arthritis of the knee, and your doctor gets you [this is the situation where studies say repairing the meniscal tear is no better than sham surgery]
  - The studies use radiographic diagnosis of arthritis
  - You don’t need inflammatory synovial fluid to make the diagnosis, but they are inflamed because that’s why they came to the clinic
    - The problem is we don’t know: is their pain from the arthritis, or is their pain from that new meniscus tear that they have?
- When Adam has a patient with radiographic arthritis (evidence of arthritis), and they have pain, and he gets an MRI
  - He will often try *not* to get an MRI, because he really just want to treat the arthritis
  - But let’s say they come in with an MRI, and they have a meniscus tear

***If they don’t have normal cartilage, and they have a meniscus tear, Adam wants to do nothing because this is the population of patients where those studies help us to say to our patients, “Listen, we do nothing. You’re going to be just as fine as if we do surgery”***

- But it’s easier for Adam to make a decision about a particular patient than to base it on some randomized controlled trial
- It’s a nice starting point to say let’s try, but he has untold numbers of patients who’ve had some arthritis, they have a new injury (a meniscus tear), they try conservative treatment, they’re not getting better, they do the surgery later, and they do okay

**Do you offer surgery regardless of the type of meniscal tear?**

- It depends on what kind of tear they have
- If the person is 60-years-old, they don’t usually get bucket handle tears
  - It’s more of a complete, complex degenerative…
  - Just like the tendon and the cartilage, the meniscus also goes through these changes with senescent cells, and it’s the matrix that is unhealthy
  - You can’t repair those tears ‒ if you put stitches in it, it’s not repairing
  - So in those cases you trim the piece

**The 40-year-old runner who comes in with new onset knee pain, they don’t have radiographic arthritis; the MRI shows a meniscal tear. Are there any versions of those you would fix?**

- Yes, Adam would try to
- This is assuming that their pain is from the meniscus, and that’s where this gets a little bit more like art than science
  - Because you can have some tiny tears that he’s not that worried about
  - Their pain may be from [patellofemoral syndrome](https://en.wikipedia.org/wiki/Patellofemoral_pain_syndrome), anterior knee pains
  - It depends on where their pain is
  - If their pain correlates to the tear, and it’s significant, it’s a good idea to try to address that, assuming that tear is a type of tear

**What are the things you need to rule out? How do you rule out patellofemoral syndrome? How do you rule out the MCL sprain (which might not show up) or other injuries?**

- Those things usually happen with an injury
- You’re not going to tear your [MCL](https://en.wikipedia.org/wiki/Medial_collateral_ligament) running unless you slipped and fell
- But a lot of Adam’s patients have patellofemoral pain, which is basically overloading of the patellofemoral joint
  - We talked about how if you squat, 7x body weight [force is felt by this area of the knee]
  - Running is a similar type of problem with the force at the kneecap, and if you increase your duration of running (your mileage) and the amount of times you’ve done it in a week, you’re going to overload the cartilage in the kneecap, and you’re going to generate pain
    - But that has a very particular feel to it in examination
    - You can tell the difference between patellar pain…
    - On examination of patellofemoral pain, Adam can’t find anything; he can’t load it enough to generate the pain, even if he bends your knee every which way
- With a meniscus tear, if there is no history of  injury, he wants to know why this would happen
  - If something twists and then they have a meniscus tear, the pain happened after an accident, then he understands

**What is the treatment for patellofemoral syndrome?**

- If they haven’t been doing anything, they haven’t been very active, then Adam sends them to PT to strengthen their quads
  - This is difficult because he’s asking them to do an activity that increases the load on the kneecap

**What causes the pain?**

- We don’t always know in one particular situation
- The picture below is a sagittal view (or a view from the side), and we see the thigh-bone (or the femur) and the leg bone (or the tibia)
- So this is looking at the side of your knee
- You see the quadriceps tendon, and then, you see the kneecap with its cartilage, and the cartilage on the femur, and the tibia [cartilage is blue]

![](https://peterattiamd.com/wp-content/uploads/2023/07/f15-adamcohen.png)

**Figure 15. Sagittal view of the knee, cartilage shown in blue; circle indicates the area of knee overloaded**.

- You also see the meniscus
- When you overload this part of the knee [circled in the picture above], your pain can be coming from the patellar tendon, the quad tendon, the cartilage, the bone, the fat pad
  - There’s fat inside the knee, and that sometimes gets pinched, and inflamed when you’re running, and that will generate symptoms

***So we don’t always necessarily know what causes the pain, but we do know that strengthening the quadricep helps the kneecap to potentially glide better, and can reduce symptoms***

- But Adam has had numbers of patients who go to PT, and they have worse pain
- So there is a need to be creative

**Peter’s takeaway** ‒ It seems that the recurring theme is inactive or poor mechanics as the root cause of most of these injuries

- When Adam sends a patient to PT, he may say, “*Listen, I don’t want you to do any quad strengthening this week. I want you to do hip strengthening. I want you to focus on the gluteus medius, because if your leg is adducting, you’re pulling the kneecap outside, increasing the force on that area.*”
  - He wants to correct that without doing anything to this
- If he really needs to work on the quad, he’ll do [blood flow restriction (BFR)](https://peterattiamd.com/jeremyloenneke/) in those circumstances because it uses lower loads and provides a similar amount of injury to the muscle as high load training would do

**How long after ACL repair do you let patients do BFR?**

- Adam sends them to a place that does it a lot
- As long as the swelling is down and they can tolerate it, he doesn’t mind starting relatively quickly
- You can titrate how much you’re doing, what percentage of blood flow you’re decreasing
- It’s a great way to start that process early before letting more atrophy set in

## Total knee replacement: when it’s appropriate and how the recovery process compares to hip replacement [1:30:30]

**What are the indications for total knee replacement?**

- If someone comes in, and they have advanced arthritis and they’ve failed conservative treatment
  - Advanced arthritis involves all compartments of their knee: the medial compartment, the lateral compartment, the patellofemoral compartment
    - Or really two severely degenerative compartments
- It’s a conversation to have, “*What has failed conservative treatment?*”
  - Have we tried PT?
  - Have we tried injections?
  - Have we tried a steroid hyaluronic acid?
  - Potentially have we tried PRP (if they’re interested)?
  - Have we tried bracing
- And their quality of life is so poor that they want to have something done, then we talk about new replacements

**Do you have a sense of how often body weight is a driver of this arthritis?**

- Peter doesn’t know what the numbers are today, but roughly a third of the country has a BMI over 30
  - And many of these people don’t have a BMI >30 because they’re overly muscled
- Excess weight is driving a lot of this arthritis
- This is why Adam shows patients the chart of:
  - This is 4x body weight when you do this
  - This is 7x body weight when you do this, just walking up the stairs or down the stairs
- Start small and consider if you lose 5 lbs how much weight you’re taking off your knee, if you multiply that
- If you can lose “this” amount of weight, you may not want a knee replacement, and you may not need one

**Adam never tells someone when it’s time for them to have a knee replacement; they’re going to tell him**

- They are going to say, “*I can’t do this anymore. I want something.*”
- As long as they are healthy enough to have the surgery, it’s reasonable
- But the **satisfaction rate after knee replacement** is different than hip replacement
  - It’s just an inherently less stable joint, and so, it’s harder to feel like it’s a normal knee

> “*People feel like it’s a normal hip, but they don’t feel like it’s a normal knee when it’s replaced.*”‒ Adam Cohen

**Anatomy of the knee replacement**

![](https://peterattiamd.com/wp-content/uploads/2023/07/f16-adamcohen.png)

**Figure 16. Model of a knee replacement**.

- Above is a model of a replaced knee
- Adam takes the front portion off and flexes the knee to show the three components
- We make cuts in the surface of the distal femur
  - We make a cut on the surface of the proximal tibia, and that matches an implant that fits right on that surface
  - The same with the tibial surface
- That is made of the high molecular weight polyethylene
- Occasionally we also will replace the surface of the kneecap with a plastic button
- And that’s your new knee

**Do you sometimes keep the native patellar if it’s fine?**

- Occasionally; it’s called resurfacing the patella
- Some people don’t resurface the patella, and studies show that there’s probably not a difference
  - In Europe, they hardly ever resurface the patella
  - It’s more common in the US, but Adam knows a lot of surgeons who don’t
- Adam resurfaces the patella most of the time, but not always
  - The reason being is because if there’s significant arthritis there, then he’s afraid that they’re going to have pain after
  - Because a lot of people with knee replacements still [have pain]
  - 85% satisfaction means that 15% are dissatisfied
  - And if Adam hasn’t replaced the patella, he’s thinking that maybe he should have

**How long does this operation take?**

- Anywhere from an hour to two hours depending on the complexity of the surgery

**How big is the incision?**

- It’s a straight, midline incision
- Anywhere from 10 cm; it depends on the knee

**Recovery after total knee replacement as compared to hip replacement [1:34:15]**

Unlike the hip where incredible progress has been made in the past 20 years, total knee replacement patients still struggle postoperatively

- Yes but less so
- We learned a lot during COVID, that you can do these outpatients very safely
- The technology is improving with total knee replacements too, where the incisions can be a little smaller

**What’s the dominant source of pain?**

- Is it the incisional pain?
- Peter assumes it’s more bone pain of what you’ve had to resurface
- Adam explains that none of that has changed, instead the perioperative management of pain has changed
  - We give injections into the capsule during the surgery
  - There’s other nerve blocks that are used
  - We send them home with pumps to get them through that initial stage

**What is the time to recovery for a motivated patient who has a knee replacement, and what are the limitations?**

- What do you tell a 50- or 60-year-old? (assuming they are one of the 85% satisfied with their knee replacement)
- Adam always tells them, “*This is going to take you a year of recovery*”
  - Because he doesn’t know who will have a shorter recovery time
  - There is a lot of people who continue to improve up to a year, and sometimes even longer
    - But he doesn’t say more than a year, because it’s just too painful to contemplate
  - Improvement is not linear, you’re probably getting 80% better in 6 months
  - People are showing improvements even beyond a year after surgery
- Adam sees patients at regular intervals
  - He will see them 10 days after surgery, 2 months after, 6 months after
  - Some people are walking in at 10 days without a cane, doing very well
    - They’re not jumping up and down
  - Other people come in at 6 months and they’re saying, “*I think something is wrong. My knee still hurts, I’m still having trouble.*”
    - Adam reminds them it might take a year

**What do you think differentiates those two patients?**

- Adam wishes he knew
- Sometimes it has to do with the strength of muscles, their [protoplasm](https://en.wikipedia.org/wiki/Protoplasm) before
- Sometimes it’s similar to the inflamma-type he discussed with the ACL where some people show prolonged inflammation after injury

**Have you ever looked at sampling synovial fluid to see how well the inflammatory milieu correlates with the recovery?**

- Adam knows this has been done, but he doesn’t know the data on that
- Peter thinks there is a lot to think about as far as immune modulation
- Adam thinks that information we get from ACL injury will help figure out the total knee replacement
  - Because nobody wants to put a needle in a knee that had a knee replacement, it slightly increases [the chance of infection]
  - Samples have been taken before surgery and we know that [IL-1](https://en.wikipedia.org/wiki/Interleukin-1_family), [IL-6](https://en.wikipedia.org/wiki/Interleukin_6), [tumor necrosis factor](https://en.wikipedia.org/wiki/Tumor_necrosis_factor) [are there]
    - Presumably what’s there right before surgery is right there after surgery

**At the one year post-op appointment for the patient that feels great, is there anything they can’t do?**

- Adam lets patients do the things they enjoy
- He has a patient now who ran a marathon with a total knee replacement
  - She’s young (50), and she knows the risk
  - Alignment issues/ mechanical issues led to her knee replacement, but now they’re fixed
- When Adam does a knee replacement, he make the cuts to allow for better alignment
  - Although not everybody does that
  - There are different ways to do a knee replacement where people maintain the alignment; it’s called a kinematic knee
  - Adam uses computer navigation so he can really titrate exactly where he wants to make the cut so that the alignment is as precise and he can make it
    - A lot of the newer technology and software allows us to be more precise in our cuts and the angles we want

**Hip replacements heal much quicker than knee replacements**

*Six months after total hip replacement, what do you tell patients not to do?*

- No contact sports because of the high risk of fraction
  - This is true with knee replacement too

**Is skiing considered a contact sport?**

- No
- Adam lets people ski with total knee replacement and total hip replacement
- It is a stress riser ‒ right above the metal in the knee is an area where it can break easily
  - And that is a really devastating injury to have a near place and then have it broken
- So Adam doesn’t want anybody doing any contact sports
- But he’ll let them play tennis
  - It used to be we would say only doubles tennis, but someone’s doing really well, he’ll let them play
  - But he will tell them, “*Listen, the more you’re on this high molecular weight polyethylene, which isn’t perfect, it’s going to wear out, because it’s mechanical too*.”

## Surgical vs. non-surgical approaches to various knee injuries [1:40:45]

**Are there other knee pains that you look at that are quantifiably not surgical, where you say, “*****Boy, operating on you would be a mistake.*****”**

- This often depends on the injury
- There are some injuries where there is no doubt that you have to have surgery
  - If you rupture your patellar tendon or your quadriceps tendon, the conservative treatment is to do surgery, because your leg will not work unless we reconnect the tendon

**Is the patella tendon typically ruptured above or below the patella?**

- The picture below shows the [quadriceps tendon](https://en.wikipedia.org/wiki/Quadriceps_tendon) and the [patellar tendon](https://en.wikipedia.org/wiki/Patellar_tendon)
  - The patella tendon is below

![](https://peterattiamd.com/wp-content/uploads/2023/07/f17-adamcohen.png)

**Figure 17. Sagittal view of the knee**.

- If either the quadriceps tendon or patellar tendon is ruptured, the patella will go with the unruptured side
  - They’re not connected anymore
  - You have to fix that, otherwise you can’t extend the knee
- For a lot of problems you can try conservative management
  - Occasionally for meniscus tears
  - There are people who have ACL tears who cope well without reconstruction
    - If they don’t participate in level one sports or don’t do pivoting/ rotational types of activities
    - You can bike or run with an ACL tear
    - There are a lot of people who cope well with an ACL tear
    - Adam did well with an ACL tear from age 15-30; he was fairly active with occasional swelling here and there

**During those 16 years that you had the ACL tear, how many times did you lose stability or did your knee go out (outside of the acute phase)?**

- Dozens

*Were you causing more injury? Were you increasing the risk of arthritis through that activity?*

- Absolutely
- Through the instability
- Peter compares it to the [subluxed shoulder](https://peterattiamd.com/altonbarron/), the more you sublux, the more you increase the risk of arthritis
  - You’re tearing the labrum and creating more instability
  - If you wait too long to get it repaired you might start to have arthritis at the glenohumeral joint

**More about arthritis**

- Adam explains that arthritis is not as common in the shoulder as the hip and knee
- And, if you’ve had a shoulder dislocation, you’re 10 to 20 times more likely to get arthritis of the shoulder than someone in the general population without a shoulder dislocation
  - So, we know it’s that traumatic event
- And the same thing is true for **ankle sprains and fractures** around the ankle, because that joint is so congruent, that cartilage in the ankle isn’t even that thick, it’s so congruent that if you don’t have an injury to the ankle, that ankle can last you quite a long time
  - It doesn’t have the same incidences as hip and knee arthritis
  - This is because it’s so engaging; the surface-to-surface level is so perfect
- You don’t have articulation of the ankle in the same way where you have more degree of motion
  - Think about the hip we talked about, where it’s edge loading in the developmental dysplasia; it’s not congruent ‒ that’s who gets the arthritis
    - The patient with the bump on the side, the acetabular impingement, they get arthritis
    - The knee, which is in the middle, that weight could go through the inside or the outside
  - The ankle, it’s right down the center, because that’s where the plumb line goes; so there’s not a lot of play, because it’s closer to the floor
- Adam sees less arthritis in the ankle
- He sees a lot of arthritis in the knee and hip, when there’s a mechanical problem

## Achilles tendon: tendinitis, rupture of the Achilles tendon, and prevention strategies [1:44:15]

- The foot and ankle are very complicated
  - The number of bones here and the number of ligaments is simply staggering
- Obviously, we’re not going to provide a master’s class on this due to the complexity of it

**Let’s focus on the big picture here ‒ what part of the anatomy do we need to understand to really get a sense of where people have pain here?**

- It depends on the population we’re talking about

*Athletes and people who are very active; for example, people who run a lot*

- The picture below show the heel bone and where the Achilles tendon attaches to the bone

![](https://peterattiamd.com/wp-content/uploads/2023/07/f18-adamcohen.png)

**Figure 18. Picture of the ankle and foot**.

- Adam sees a lot of [Achilles tendinitis](https://en.wikipedia.org/wiki/Achilles_tendinitis), and that’s a very difficult problem because there are not a lot of great treatment options
  - Surgery doesn’t do great with tendinopathy of the Achilles tendon, and only when it’s ruptured is there more of a plan on how to address it
  - Interestingly, there is *not* an increased incidence of tendon ruptures in the setting of tendinopathy
    - Adam doesn’t do a lot of foot and ankle surgery, but that’s his understanding of the literature
    - He’s treated lots of people over the years with Achilles tendinitis and doesn’t remember a case where it ruptured

**On the topic of rupture, how much of a concern are** [**fluoroquinolones**](https://en.wikipedia.org/wiki/Quinolone_antibiotic) **(**[**ciprofloxacin**](https://en.wikipedia.org/wiki/Ciprofloxacin)**/** [**levaquin**](https://en.wikipedia.org/wiki/Levofloxacin) **antibiotics)? How big is that increase in risk and for how long does it preside after the antibiotic?**

- Adam doesn’t know, but he’s seen it after one dose (within a week or two)
- What he tells people is, “*It’s not a reason not to take the medication, but if you start to feel anything, you have to stop and rest, because I feel like that is one of those situations.*”

**Are there warning signs to an Achilles rupture?**

- They start to develop pain, and this is when they should stop

**But it’s not tendinopathy. So what’s the pain?**

- Adam doesn’t know the mechanism
- There is some tendon inflammation

**What are we doing to prevent rupture of the Achilles?**

- Peter notes this is the middle-aged person injury, “*I’m going to run around with my kids and I hear the loudest band*”
  - Your calf balls up, and the next thing you know, you’re in a boot for weeks
- Adam thinks it’s important to maintain muscle strength, calf flexibility
  - Make sure your gastrocs and your soleus (shown in the figure below) have good flexibility, both of those separately

![](https://peterattiamd.com/wp-content/uploads/2023/07/f19-adamcohen.png)

**Figure 19. Frontal view of the leg and anatomy**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Soleus_muscle)

- Overtraining can be an issue in this circumstance, so proceed with care

***You can’t necessarily do everything you wanted to do when you’re 20 and 30, because that tendon degeneration is a biologic event that affects all of us***

- Peter feels like an important part of maintaining elasticity in the body is jumping
  - Jumping rope
  - He  has a particular jumping routine he always does; it’s not plyometric explosive stuff
- Adam agrees and thinks neuromuscular training is just as important
  - He thinks there’s a mismatch between the firing of the calf musculature and what you’re actually doing at that moment
  - Having more motor neurons and well-developed motor neurons may help prevent that and, just like it prevents ACL injuries

***There’s no way that [neuromuscular training] is not helpful for all lower extremity injuries ‒ to be able to know where you are in space and to have good training in those dynamic situations, because that’s when people are injured***

- Nobody wanted to trip on the sidewalk, but what happens when you trip?
  - Are you able to recover quickly?
  - Or do you end up with an injury?

## Anatomy of the ankle and foot [1:49:00]

- The figure below shows a model of the ankle and foot
  - The leg bone (or [tibia](https://en.wikipedia.org/wiki/Tibia)) joins to the [talus](https://en.wikipedia.org/wiki/Talus_bone), then articulates with the [navicular bone](https://en.wikipedia.org/wiki/Navicular_bone)
  - Then there are the [cuneiforms](https://en.wikipedia.org/wiki/Cuneiform_bones), [cuboid bone](https://en.wikipedia.org/wiki/Cuboid_bone) on the outside
  - The [metatarsals](https://en.wikipedia.org/wiki/Metatarsal_bones)
  - The [phalanges](https://en.wikipedia.org/wiki/Phalanx_bone)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f20-adamcohen.png)

**Figure 20. Model of the ankle and foot**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Navicular_bone)

- Turning the model to the side, the figure below shows the inner side of the ankle
  - The medial malleolus
  - The area where the tendons are that help to maintain your arch rest (shaded in blue)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f21-adamcohen.png)

**Figure 21. Model of the inner ankle and foot, blue highlights where tendons connect**.

- The drawing below shows the medial aspect of the ankle
  - The [posterior tibialis tendon](https://en.wikipedia.org/wiki/Tibialis_posterior_muscle), which is  incredibly important for maintaining your arch
  - The [flexor hallucis longus](https://en.wikipedia.org/wiki/Flexor_hallucis_longus_muscle), which goes to the first toe
  - The [flexors for the digits](https://en.wikipedia.org/wiki/Flexor_digitorum_longus_muscle)

![](https://peterattiamd.com/wp-content/uploads/2023/07/f22-adamcohen.png)

**Figure 22. Picture of the medial aspect of the ankle**.

- The picture below shows the ligaments of the medial aspect of the ankle
  - The [medial malleolus](https://en.wikipedia.org/wiki/Malleolus#Medial_malleolus)
  - This broad ligament is the [deltoid ligament](https://en.wikipedia.org/wiki/Deltoid_ligament)
  - The [spring ligament](https://en.wikipedia.org/wiki/Plantar_calcaneonavicular_ligament)
  - The [plantar fascia](https://en.wikipedia.org/wiki/Plantar_fascia), which helps to maintain your arch

![](https://peterattiamd.com/wp-content/uploads/2023/07/f23-adamcohen.png)

**Figure 23. Ligaments of the medial aspect of the ankle.**

- These are important structures to examine
  - To make sure the plantar fascia is component
  - To make sure the posterior tibialis tendon is working
- It’s important to go through walking on your toes, walking on your heels, to see how the gait progression is managed
  - See the video of the exam in the selected links section
- The picture below shows the outside of the ankle, or the lateral part of the ankle
  - This is where the [fibula](https://en.wikipedia.org/wiki/Fibula) is
  - Underlined in yellow is where **most ankle sprains** happen, and the main ligament that’s injured is called the [ATFL (or anterior talofibular ligament)](https://en.wikipedia.org/wiki/Anterior_tibiofibular_ligament)
  - The [calcaneofibular ligament](https://en.wikipedia.org/wiki/Calcaneofibular_ligament) and the [posterior talofibular ligament](https://en.wikipedia.org/wiki/Posterior_talofibular_ligament) is not sprained as often
  - This ligament up here [at the blue \*, the anterior inferior tibiofibular ligament] connects the fibula to the tibia, and when people have **high ankle sprains**, this is often the ligament that’s injured

***Whenever someone has an ankle sprain, it’s conservative treatment, and most people get better, but not everybody***

![](https://peterattiamd.com/wp-content/uploads/2023/07/f24-adamcohen.png)

**Figure 24. Ligaments of the lateral part of the ankle**. Image credit: [Wikepedia](https://en.wikipedia.org/wiki/Anterior_tibiofibular_ligament)

## Common injuries to the ankle and foot [1:51:15]

**To what degree does an ankle sprain tear that ligament?**

- It could be any degree
- If you have a sprain, that is, if your ankle twists and you have swelling, you’ve torn the ligament
- The question is, is it a complete rupture of the ligament?
- We arbitrarily say this is a grade one, grade two high ankle
  - They’re all tearing of the ligament
- The degree to which they’re torn or which they heal will dictate the next step

***It’s very rare to have a severe ankle sprain without any dislocation of a joint that would require surgery***

- Except for some syndesmosis injuries up higher; those often will require surgery
- But, for the run of the mill twisted my ankle playing basketball, the treatment is conservative strengthening the [peroneal muscles](https://en.wikipedia.org/wiki/Fibularis_muscles)
- But, doesn’t necessarily mean everybody’s going to recover, because sometimes what happens is the **cartilage gets injured**

> “*And, just like we talked about in the shoulder, and the knee, and the hip, any mechanical trauma to the joint puts you at increased risk for arthritis of that joint*.” ‒ Adam Cohen

**Which cartilage in particular, if you took the most common sprain?**

- [ATFL](https://en.wikipedia.org/wiki/Anterior_talofibular_ligament) ‒ the anterior talofibular ligament connects the fibula to the talus
  - And when that rotates this way, this does not rotate at all; you will cause injury to the cartilage because it abuts in this area [highlighted in blue in the model below]
  - You will see what we call osteochondral bone, and if you did an MRI, you would see bone edema there

![](https://peterattiamd.com/wp-content/uploads/2023/07/f25-adamcohen.png)

**Figure 25. Cartilage of the ankle joint highlighted in blue**.

- If someone is not recovering after an ankle sprain, Adam gets a MRI because he wants to see what their cartilage looks like and if they’ve injured the bone or cartilage
  - To see if anything else needs to be done

**If there is a small fracture, do you recommend conservative treatment (put them in a boot)?**

- If there is a crack in the area highlighted in blue above, the treatment depends on if that piece is what we call stable or unstable
  - You can have a crack in the cartilage and bone unit that is in place (in-situ) and you could leave that alone, maybe give a boot
  - If that piece is detached, that’s unstable

**What if you have a distal fibula fracture because the sprain is so bad that when their foot went out, it actually broke the bone? Does the talus ever break that tip of the fibula?**

- Sometimes, if the forefoot is externally rotated, this will hit the fibula, and the fibula will break
  - And that doesn’t necessarily need surgery
  - That can often heal without surgery
- But if you’ve also at the same time torn the inner ligaments, the deltoid ligaments, then you now have instability on both sides of the ankle
  - Then, you go in and you fix the fibula, and sometimes even the deltoid

**Is the sprained ankle “hands down” the most common injury to this part of the body?**

- Yes

**What type of surgery is most commonly done by the foot and ankle surgeon? Acute or chronic injury?**

- There are different types of practices
- There are a lot of degenerative problems, where you have arthritis of…
- Adam is not a foot and ankle surgeon
- Once the foot collapses, the arch collapses, and the [posterior tibialis tendon](https://en.wikipedia.org/wiki/Tibialis_posterior_muscle) is attrition to that
  - That’s a very painful condition
  - You often have to fuse the small bones of the joint in order to better create a stable platform to land
    - Occasionally, it’s the midfoot
    - Occasionally, it’s a [subtalar joint](https://en.wikipedia.org/wiki/Subtalar_joint)
    - You can even have an [arthrodesis](https://en.wikipedia.org/wiki/Arthrodesis) of the ankle itself; it’s called a [triple arthrodesis](https://en.wikipedia.org/wiki/Triple_arthrodesis)

**Does this occur when a person’s arch is so weak that they lose their arch?**

- There are stages
- In the early stage you can treat it in a boot
- Sometimes we go in and address the tendon itself
- In more advanced stages, you start to see changes in the ankle joints

**How is this occurring? Why isn’t this a problem that is fixed with foot exercises and PT? Why would we let a person get to the point where their arch completely collapses and the musculature becomes so compromised?**

- Some people have anatomy of their foot ‒ pronated, flat feet that are not easily correctable, even with exercise
  - It’s just mechanically different
  - And once that tendon become so stretched, these people don’t benefit from that or even orthotic arches
  - These people are prescribed orthotic arches, but that doesn’t mean that the disease process won’t progress
- A lot of the disease process is mechanical and a lot is biologic too
- We have decent ways of helping people if they don’t have a biologic problem
- We have decent ways of helping people with mechanical problems
- But, all of these factors play into whether someone would benefit from exercise
- Nonetheless, there are things that can be done
  - You can give people rigid shoes to help with their feet and allow them to exercise other parts
  - You can fuse the ankle so the pain goes away and still get on a plan to maintain the health of the rest of you
- But if your foot kills with everything you do, you can’t help any of the rest of it

**When people talk about an ankle fusion, normally are they talking about tibia to talus?**

- Yes, traditionally, that’s what is used
- This is not Adam’s field, but there are ankle replacement now which are becoming more popular
  - The technology has improved
  - But these are not necessarily the same patients

**What are the other injuries to the ankle and foot that require surgical intervention?**

- You can have fractures of the [proximal fifth metatarsal](https://en.wikipedia.org/wiki/Fifth_metatarsal_bone) (shown in the diagram below), where there’s a tendon attached called the [peroneus tendon](https://en.wikipedia.org/wiki/Fibularis_muscles), which pulls off that piece
  - That tends to heal; it rarely requires surgery

![](https://peterattiamd.com/wp-content/uploads/2023/07/f26-adamcohen.png)

**Figure 26. Diagram of the right foot with the peroneal tendon highlighted in red**. Image credit: [Mammoth Orthopedic Institute](https://www.mammothortho.com/peroneal-tendon-injuries-mammoth-orthopedic-institute.html)

- If you fracture higher up (less than a cm higher), this is in an area where the blood supply is pretty deficient (called the watershed zone), and often that won’t heal

***So you don’t worry about a fracture in one place, you can wear whatever shoes you want as long as it doesn’t hurt, but if you break it here [up higher], you need to be in a cast or boot for six weeks or have surgery to put in a screw; the difference is based on the blood supply to the bone***

- [Navicular](https://en.wikipedia.org/wiki/Navicular_bone) stress fractures are another type of fracture that is serious
  - This typically occurs in runners

**What about the other metatarsals?**

- Adam commonly sees second and third metatarsal stress fractures
  - The metatarsals are shown in yellow in the diagram below
- These stress fractures tend to heal

![](https://peterattiamd.com/wp-content/uploads/2023/07/f27-adamcohen.png)

**Figure 27. Diagram of the bones of the right foot, metatarsals shown in yellow**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Fifth_metatarsal_bone)

**Do they have watershed zones as well?**

- No, they tend to heal
- Just the fifth metatarsal [has a watershed zone with low blood supply]

**Adam worries about stress fractures**

- Oftentimes, you’ll see somebody with foot pain, they’re a runner, and then you find out they had three other stress fractures (so this is their third)
- At the first visit, you have to have a conversation about relative energy deficiency
  - Why are you not healing?
  - Do you need to see an endocrinologist?
  - Vitamin D?
- Anecdotally, Peter has seen this so much in female runner who are basically being put into eating disorders by running coaches
  - They’re undernourished
- It’s called the [female triad](https://en.wikipedia.org/wiki/Relative_energy_deficiency_in_sport) ‒ it’s a risk of osteoporosis, stress fractures, and menstrual abnormalities

**What is a** [**bunion**](https://en.wikipedia.org/wiki/Bunion) **and when does it need surgery?**

- Some people develop an abnormality of the first ray, at the metatarsal phalangeal joint (highlighted in blue in the model shown below)
  - This will start to deviate, where this portion which we call the bunion starts to be prominent on the inner aspect of the foot

![](https://peterattiamd.com/wp-content/uploads/2023/07/f28-adamcohen.png)

**Figure 28. Model of the right foot, blue highlights where a bunion can form**.

- At the same time, that can sometimes affect and crowd out the second toe and you’ll get something called a [hammer toe](https://en.wikipedia.org/wiki/Hammer_toe) of that second digit

***As long as you’re comfortable in your shoes and it’s not painful, a bunion is not necessarily something to do about, but if it starts to crowd out the toe and you start to develop pain, now we have to talk about correction and osteotomies (or cuts in the bone) to straighten out that area***

- Oftentimes, you need to correct the hammer toes of the other digits if they’re also affected

**How do you correct a hammer toe?**

*Does moving the toe over [correcting the bunion] do it sufficiently?*

- No
- Because after a while the tendon length changes, and so you have to cut the bone and pin it to a shorter stump so that it’s no longer painful

**When you repair the great toe, is there a screw that runs along the metatarsal?**

- There are different ways to do it
- Some people us plates, some people use screws
- The recovery is hard, and that’s why we don’t recommend it unless you’re starting to have pain

**How much of that is driven by wearing super tight shoes and how much of it is anatomic variation?**

- It’s a combination
- Tight shoes are a factor where some people are predisposed to develop it
- In cultures that wear tight shoes, you’re going to have a higher incidence of this problem

**How often do you see injuries to the** [**calcaneus**](https://en.wikipedia.org/wiki/Calcaneus)**?**

- We see stress fractures of the calcaneus as well
- Also [plantar fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis) is very common
- It’s important to recognize that heel pain is its own animal
- Sometimes it’s attrition of the fascia or the ligament
  - The [plantar fascia](https://en.wikipedia.org/wiki/Plantar_fascia) that attaches on the inner plantar surface of the bone; you could have stress fractures in this area
  - You can have insertional tendonitis, where the Achilles attaches to
  - And sometimes you can have heel pain because a nerve is compressed, much like you have carpal tunnel syndrome, you could have [tarsal tunnel syndrome](https://en.wikipedia.org/wiki/Tarsal_tunnel_syndrome)
  - Sometimes people get just get heel pain because they have a disc herniation that’s affecting [S1 nerve root](https://en.wikipedia.org/wiki/Sacral_spinal_nerve_1), only presenting as heel pain

***It’s one of those things where you have to really take a close step-by-step approach to diagnosing that problem***

## Tips for finding a good orthopedic surgeon [2:01:45]

**If someone watching this is in the process of interacting with the medical community, specifically the orthopedic community, how can they pick a good surgeon?**

*What are some of the tells that you’re speaking with a good orthopedic surgeon, versus someone who’s a hack?*

- You can ask them these questions
- You’re entitled to have a conversation with somebody
- You’re not going to know until you meet them
- And some people mesh well with people, other people don’t

**What are some questions that they can ask specifically to get a better sense of a person’s competence?**

- That’s a good question
- Judge by the rapport you’re having with the person
- If they say, “*I think you need surgery,*” ask a simple question:
  - “*Are there alternatives?*”
  - Or “*What are the alternatives?*”
  - Or “*Why do you think I need surgery now?*”
  - And “*Are there any non-operative approaches to it?*”
- Their answer will give you a good sense
  - If they are defensive in their response, that may not be someone who’s right for you
- Even if they’re right and you do need surgery, doesn’t mean you’re not allowed to ask the question about alternatives
- If someone comes in with a ruptured patellar tendon, Adam will say to them, “Y*ou need surgery.*”
  - Even though that visit could be four seconds, he could schedule them for surgery and be right in the assessment of what needs to be done
  - But that doesn’t make him a good doctor or a good surgeon
    - You need to explain why that’s the case, what to expect afterwards
  - Everybody deserves a conversation about these things
- Peter feels like when a surgeon can’t give you a clear breakdown of what the complications are, and what the probabilities are of those complications (especially in their hands)
- It’s one thing to quote the literature, but you want to know *your* risk
  - Ask, “*How many times do your patients get wound infections?*”
  - Ask, “*How many times do your patients still find themselves in pain a year out?*”
  - Ask, “*What will we do if I’m still in pain in six months? What does your intuition tell you is going on and how will we work that up?*”
- In Peter’s experience, surgeons who can’t go through that thinking aren’t very good at their job, and you’re playing a little bit with fire when you go under the knife from them
- Adam has found that approach to be important even when you’re not recommending surgery
- For example, if someone comes in with an ankle sprain and he sends them to PT but doesn’t explain what will happen in three weeks and just say, “*Follow up with me in a month if you’re not doing well* ”
  - He needs to go through the steps with them
  - He needs to explain that not everybody with an ankle sprain is going to get better
    - You will probably get better because most people do, but you might not
  - If 4-6 weeks go by and you’re still having pain or you don’t feel like you’re making improvements, then he needs to see you again
    - You may have an injury to the cartilage and you mand need to get an MRI

***Adam always give them the answer to what we are doing next if what he just recommended isn’t going to work***

**Peter’s takeaway** ‒

- This has been super helpful, he learned a lot
- Orthopedics is a little bit of a black box to him and probably a lot of doctors, “*We don’t have enough of an overlap*”
- This is such a subspeciality, and there’s so much you’re learning

***This will be very instructive for people, especially, when paired with the exam videos***

\*\*\*

## Exam videos

**All exams in one video**:

**Standing exam**:

**Lower leg, ankle, and foot exam**:

**Knee exam**:

**Hip exam**:

**Gait exam**:

§

## Selected Links / Related Material

**Adam practices medicine at**: [ORTHOMANHATTAN](https://www.orthomanhattan.com/orthopedic-surgeons-new-york-city/adam-b-cohen-md/) | [1:15]

**Previous episode with Dr. Alton Barron on the upper extremity**: [#232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities | Alton Barron, M.D.](https://peterattiamd.com/altonbarron/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 28, 2022) | [1:30]

**Incidence of developmental dysplasia of the hip**: [Incidence of Neonatal Developmental Dysplasia of the Hip and Late Detection Rates Based on Screening Strategy: A Systematic Review and Meta-analysis](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2795295) | *JAMA Network Open* (I Kuitunen et al. 2022) | [7:30]

**DNS Star exercise**: [DNS Star Pattern](https://youtu.be/Sl0GrgwyXcQ) | Sarah Wright (YouTube, September 5, 2021) | [34:45]

**Treating knee osteoarthritis with PRP plus hyaluronic acid**: [Intra-Articular Platelet-Rich Plasma Combined With Hyaluronic Acid Injection for Knee Osteoarthritis Is Superior to Platelet-Rich Plasma or Hyaluronic Acid Alone in Inhibiting Inflammation and Improving Pain and Function](https://www.arthroscopyjournal.org/article/S0749-8063(20)30843-4/fulltext) | *Arthroscopy* (Z Xu et al. 2020) | [53:45]

**Study of websites promoting stem cell therapy**: [Online Direct-to-Consumer Advertising of Stem Cell Therapy for Musculoskeletal Injury and Disease: Misinformation and Violation of Ethical and Legal Advertising Parameters](https://pubmed.ncbi.nlm.nih.gov/31770294/) | *The Journal of Bone and Joint Surgery* (M Kingery et al. 2020) | [54:30]

§

## People Mentioned

- [Alton Barron](https://altonbarronmd.com/about/) (orthopedic surgeon specializing in the shoulder, elbow, and hand) [1:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/07/bio-adamcohen-500x500.jpeg)

##### Adam Cohen, M.D.

Adam Cohen earned his Bachelor’s Degree from Washington University in St. Louis. He then earned his Medical Degree from New York Medical College where he received AOA Academic Honors and the Trustee Merit Scholarship for Academic Excellence. He completed his internship in general surgery and residency in orthopedic surgery at the St. Luke’s-Roosevelt Department of Orthopedics in New York City. He went on to do a research fellowship in Knee and Sports Medicine in San Diego. Dr. Cohen then returned to Manhattan to practice medicine and earned an appointment as an Assistant Clinical Professor at Columbia University from 2004-2014. During this time he also served as the Assistant Team Physician for the New York Yankees (from 2004-2008). He also served as a consultant for the US Open Tennis Championships and provided orthopedic coverage for the New York City Ballet.

Currently, Dr. Cohen is the Director of Sports Medicine at [OrthoManhattan](https://www.orthomanhattan.com/orthopedic-surgeons-new-york-city/adam-b-cohen-md/) and serves as the Team Physician for Horace Mann Athletics.  He holds academic appointments at the NYU Langone Health System and the Mount Sinai Health System.

Dr. Cohen has been recognized as a Castle-Connolly Top Doctor since 2015 and has been selected to appear in New York Magazine’s Top Doctor issue in 2017, 2018, 2019 and 2020.  He also received the Mount Sinai Orthopedic Residency “Teacher of the Year” honors in 2017.

Dr. Cohen has advanced training and expertise in sports medicine injuries of the shoulder, elbow, hip, knee and ankle.  He has extensive experience in arthroscopic minimally invasive surgery and advanced reconstructive procedures, including shoulder and knee replacement surgery. [[AdamCohenMD.com](https://adamcohenmd.com/about-adam-cohen-md-top-orthopedic-doctor-nyc)]

Website: [adamcohenmd.com](https://adamcohenmd.com/)

Facebook: [Adam Cohen MD – Orthopedic Surgeon and Sports Medicine Specialist](https://www.facebook.com/AdamCohenMD/)