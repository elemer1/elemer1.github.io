# #105 – Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted

**Source:** [https://peterattiamd.com/paulconti2/](https://peterattiamd.com/paulconti2/)

---

##### Check out more content with psychiatrist, Paul Conti, M.D.:

- *(September 17, 2018)* [Paul Conti, M.D.: trauma, suicide, community, and self-compassion](/paulconti/)
- *(April 10, 2020)* [Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted](/paulconti2/)
- *(January 10, 2022)* [Paul Conti, M.D.: How to heal from trauma and break the cycle of shame](/paulconti3/)

In this episode, psychiatrist Paul Conti, M.D. discusses the impact of the fear and uncertainty surrounding the COVID-19 pandemic and the resulting stress, anxiety, and trauma it may impart on the population. Paul examines how this situation has highlighted the challenges we face at the societal level as well as the individual level, and stresses the importance of seeking absolute truth above personal truth and taking action as individuals as a means to combat many of these pervasive problems.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/paulconti2/the_Drive_public.png)

Play

#105 - Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted

#105 - Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted

1x15s30s

0:001:26:44

## We discuss:

- Paul’s personal experience with a presumptive case of COVID-19 [2:15];
- Through the lens of trauma, Paul’s overall take on the lasting effects of this pandemic on society [4:30];
- The imperative to unite as a species given the isolating and suspicious nature of an invisible enemy [8:15];
- The indigent population and the affluent population—The commonalities and differences in how both populations have been affected [16:15];
- The prevailing feeling of demoralization spanning the population [25:30];
- Health care workers—What lingering psychological effects might they suffer from this? [35:00];
- Could this pandemic be a catalyst for changing the way people think about science, truth, and logic? [46:30];
- How our inability to deal with uncertainty exacerbates the problem, and the need for humility [58:00];
- What has been Paul’s recipe for self care during this time? [1:06:45];
- The forthcoming challenge of reintegrating back into the world when the quarantines lift [1:14:45];
- An urgent need for change which must come through individuals seeking absolute truth and taking action [1:19:15]; and
- More.

§

## Show Notes

## Paul’s personal experience with a presumptive case of COVID-19 [2:15]

- In early March, Paul and his family each has some symptoms that are common one of COVID-19
- They were not tested, but Paul is fairly certain they each had it
- Paul had the most severe symptoms including:
  - Felt extremely hot with alternating bouts of terrible chills
  - Awful headache
  - Deep nausea
  - He was NOT congested
  - Shortness of breath

> “I could really see the lethality in someone who has some of the medical comorbidities I’m fortunate not to have . . .it was scary.”

## Through the lens of trauma, Paul’s overall take on the lasting effects of this pandemic on society [4:30]

- Paul is frustrated with the fact that this situation we’re in seemed very predictable
- “so often there’s a predictability that we’ve gone 19 steps down a 20 step path, and then we are surprised when we get to the 20th step”
- We’ve been paving the way for trauma to happen both medically and socioeconomically, says Paul

> “And I think where I ring my hands and gnash my teeth is the idea that maybe we won’t learn from this and I’m worried that we…could then sort of traumatize ourselves out of existence.”

## The imperative to unite as a species given the isolating and suspicious nature of an invisible enemy [8:15]

**What do we know about how humans internalize this type of stress versus other types of stress that are more potentially uniting?**

⇒ [Sebastian Junger](https://en.wikipedia.org/wiki/Sebastian_Junger) has written very eloquently about this in his book [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381)

The idea of an invisible enemy (like a virus)

- We internalize this in a way that is more and more isolating and I think historically just makes people very suspicious of one another
- Paul believes we have a social structure that searches for an enemy
- Paul stresses the importance of uniting as a species rather than trying to blame others or fear that “others” are the problem

**Peter asks…** ***Do we even possess the ability for global cooperation?***

- Peter points out that it seems that only in sci-fi movies where there’s an alien attack on the planet do we see opposing nations unite against an enemy

*-Is there any reason to believe we even possess the ability for that degree of cooperation?*

- Paul says, “I don’t think we do right now” …  because it’s much easier to align around a common enemy
- But I think we can, says Paul
- He explains…
  - It requires different elements of the human being’s ability to call upon the deeper parts of our brain
  - The parts that don’t just react with what I think of as “traumatic aggression” in order to align around something that really isn’t an enemy

> “The virus isn’t plotting against us. It doesn’t have intelligence. It’s invisible. In order to unite, we have to recognize our shared humanity.”

## The indigent population and the affluent population—The commonalities and differences in how both populations have been affected [16:15]

> “This is a gigantic medical problem. It is a social problem. It is an economic problem. When you add those things together. . . it becomes a societally threatening medical, socioeconomic problem, and we haven’t had that before.”

- Paul works with people on both ends of the extreme in terms of the socioeconomic status
- He says they are both very impacted by this situation

**For the more indigent population…**

- It’s added desperation on top of desperation
- Half the population in this country couldn’t survive and move forward from $500 unexpected costs or a $500 shortfall
- Paul says that this subsection of the society has been sort of left behind
- And this is just exacerbating their situation

**For the more affluent population…**

- “I’ve never seen something that just supercharges this idea that if I fear enough, then I’ll be safe.”
- We are essentially living in a state of constant hypervigilant discomfort
- We have become prisoners of the insecurity that we have generated from, for example, the way “news” is presented
- it affects people even who say have enough economic means but still have this pervasive feeling that there’s always, always, always something to fear
- The fear drives suffering b/c it starts to spiral out of control and people get obsessive with negative thoughts that run  over and over and over

> “What is uniting us is this pervasive insecurity. And then these parts of our brain that want to keep us safe go into overdrive and inadvertently make us feel so much more vulnerable.”

## The prevailing feeling of demoralization spanning the population [25:30]

-Peter describes to Paul a personally feeling of sadness, irritability, and sort of a lack of interest in life at times

-Paul identifies these feelings of desperation as a sense of **demoralization**

- This sense of demoralization comes from the idea that no matter what you do and how hard you work…  you can be vulnerable anyway
- “*I’m not saying that we should be demoralized, but I’m saying I believe there’s truth to that because I think the world around us leads to that*.”

Paul also thinks that we’ve lost our way from a leadership standpoint adding to this problem

- People expect to be protected from things like this pandemic
- Yet, we’ve gotten away from relying on people with real expertise
- Instead, anyone with a strong opinion can use social media to scream louder and louder

## Health care workers—What lingering psychological effects might they suffer from this? [35:00]

- “I think the trauma is going to be pervasive and even generational.”
- Even before this pandemic, Paul says we have been stretching people to the limit
- They’re working in a system that doesn’t know them, care about them, value them

> “We’ve allowed the systems to evolve into this compounded ignorance where we can’t take care of the people who are supposed to take care of us, and they know that and they’ve known that for a long time, and they’re seeing it come to the forefront.”

**How would you think about managing the long term toxicity of this because especially if it’s sort of smoldering but not resolved?**

-First, we must acknowledge the trauma

-Next, we actually need to make things different

-Paul says that due to the trauma, we will most likely see a rise in things like:

- Alcoholism
- Domestic violence
- Suicide
- People giving up and walking away from things that are important to them

> “If we demoralize the population and we don’t rectify that, it’s not going to be okay. And if somehow it seems to be in six months, that will be a deceit that it will be tempting to just believe that and go on. But we have to have the courage of our convictions to know that that’s not okay.”

**Thought experiment**: *If there’s SAR-CoV-3 in 2030, what do we need to have in place to do a better job than we might be doing today?*

- What we need is an “**alliance of common sense”** says Paul
- That would be a group of influential people with the following mindset: “*I can’t pretend that something is okay just because it suits my interests. Even if I know it is false. I have to first prioritize looking at truth and can we, the people who would do this, which ideally could be a growing movement led by people with influence and with the ability to say we have to put aside whatever our wishes might be, whatever our animosities might be, that we actually do have to treat this like post 9/11 or like the second world war and say what we need to look at now is truth.*”
- This alliance should be able to be honest that our social, medical, and economic systems are not okay which ultimately results in things like uninsured people showing up at emergency rooms for primary care and demoralizing the staff

## Could this pandemic be a catalyst for changing the way people think about science, truth, and logic? [46:30]

**Personal truth vs. absolute truth**

- An example of a personal truth would be: *Ayrton Senna is the greatest formula one driver of all time*
- With absolute truths: *That’s really where science comes in*
- “For the majority of society, there’s a blurred line between absolute truth and personal truth or relative truth.”
- –*Truth and the brain:*
- Absolute truth resonates with logical systems in our brain.
- Relative truth/personal truth resonates with emotional parts (affective or limbic system) especially when we engage in the world around us
- “*I have a thesis that says we as a society are not engaging effectively because we have lost the distinction between those two that lets us make the personal truth secondary to the absolute truth*.”
- When you let personal truths rule the way you think about things… “*you end up thinking everybody who doesn’t believe that it’s an idiot*”

Paul says this event could be a catalyst for either

1. Throwing absolute truth out the window OR
2. For a new prioritization of logic and facts

- But for that to occur, he says we need an alliance of common sense where people agree to look at the logic and look at the facts when they disagree even if it goes against their current beliefs

**Does Paul worry that we have spent such a scant period of our evolutionary history with any formal language around logic and science?**

- Peter points out that “about one 10th of 1% of our evolutionary history has operated with even the nomenclature of science, the skill set and the tools for logical thought”
  - ⇒ Check out Peter’s article: [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/)
- Paul admits that yes, we have mostly been driven by emotion for all of history
- However, just because it’s a strong current against us doesn’t mean we can’t band together and paddle upstream

> “People’s emotion runs wild and what we need to do is to step up to the plate and develop greater control mechanisms and look at ‘How do we stop misinformation? How do we establish sources that are arbiters of truth outside of politics that are arbiters of what’s actually true?’ And we don’t have that.”

## How our inability to deal with uncertainty exacerbates the problem, and the need for humility [58:00]

Paul and Peter both agree that as a society we really struggle with being able to say “I don’t know”

- Instead, people will come up with things to say they know (hubris)
- But it’s incredibly important, says Paul, to have the humility to say I don’t know
- Science itself never proves anything, it just provides degrees of certainty
- Peter worries that we aren’t capable of getting to the point of understanding this concept

**Humility vs hubris**

- “*Admitting that we don’t know engenders humility, the humility that makes us careful.*”
- “*Hubris leads people to just declare that they know. And there’s a recklessness to that.*”

## What has been Paul’s recipe for self care during this time? [1:06:45]

- Connection to others can be an antidote to trauma
- Rather than money and success, Paul says this is a time to find things that are truly meaningful

> “For all the money, success, prestige, world mastery. I mean, if you could have all of it, you wouldn’t sacrifice the ability to be with one of your children. Like that stuff matters the most to us. And it’s also where we generate our own meaning. That’s where I don’t feel demoralized because I know that I have meaning to people and people have meaning to me. And then I can find within myself the strength to put one foot in front of the other, keep doing what needs to be done. Even though I sure do feel demoralized often.”

## The forthcoming challenge of reintegrating back into the world when the quarantines lift [1:14:45]

- We’re going to see more anxiety, more obsessiveness, more panic, more agoraphobia (fear of being outside of the home)
- we’re going to see more of the unhealthy coping mechanisms like drugs and alcohol
- We’re going to see more of the unintended results of that, like depression and accidents.

*-Why?*

- Because there is nothing there to prove that you are safe

This is about trauma and how this pandemic is traumatizing us and how we paved the way for the trauma of it to be so bad and we need to change that.

We need to work for change in the systems that allowed the trauma to happen in the first place …

If we don’t… “*Then we’ll be the individual sufferer from trauma who is trying to deal with that trauma by pretending everything is okay, which is a natural response because we’re afraid of it and we’re ashamed of it and we don’t know how to deal with it*.”

## An urgent need for change which must come through individuals seeking absolute truth and taking action [1:19:15]

**The common theme**: “Those of us who sit here in the peanut gallery who are not in a position of leadership are going to have to sort of become the movement of change. In other words, it’s not enough to just sit around and pontificate about this stuff. We are going to at some point have to do something about it. We’re going to have to take some sort of action.”

> “What we have to do is really unpalatable things. Stand against the status quo, enter into arenas that are politically charged, enter into minefields knowing there’s something unpleasant is going to happen.”

§

![](https://peterattiamd.com/wp-content/uploads/2020/04/paul-conti-original-1x1-1.jpeg)

##### Paul Conti, M.D.

Dr. Paul M. Conti is a graduate of Stanford University School of Medicine. He completed his training at Stanford and at Harvard, where he served as Chief Resident. He then worked in private practice while serving on the medical faculty at Harvard. He was named as one of Oregon’s Top Psychiatrists in 2008, his first full year of practice in Oregon. Dr. Conti is a general psychiatrist, treating all aspects of both mental illness and the impact of life stressors. His practice includes use of medications and psychotherapy, and he also routinely treats complex cases, co-occurring alcohol and drug issues, and does neuropsychiatric assessments. In addition to clinical treatment, Dr. Conti provides business-related and legal consulting services. [[pacificpremiergroup.com](https://www.pacificpremiergroup.com/meet-our-team/)]