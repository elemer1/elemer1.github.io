# #169 – Katherine Eban: COVID-19 Lab Leak: Examining all sides of the debate and discussing barriers to a full investigation

**Source:** [https://peterattiamd.com/katherineeban2/](https://peterattiamd.com/katherineeban2/)

---

Katherine Eban is an award-winning investigative journalist who [previously appeared on The Drive](https://peterattiamd.com/katherineeban/) to discuss the widespread fraud in the generic drug industry. In this episode, she discusses the content of her recent [Vanity Fair article](https://www.vanityfair.com/news/2021/06/the-lab-leak-theory-inside-the-fight-to-uncover-covid-19s-origins), which examined the evidence for the theory that the COVID-19 pandemic resulted from a virus lab escape as opposed to a natural virus that came from an animal host. Katherine and Peter walk through the evidence for both theories as well as discuss the long and troubling history of dangerous lab leaks and safety concerns about the Wuhan Institute of Virology.  They also talk about the controversy surrounding gain-of-function research and its funding by the US government. Finally, they conclude with a discussion on the likelihood of definitively establishing the origins of the virus given the Chinese government’s lack of cooperation and highlight the fact that the many barriers to performing a full investigation may be the most troubling aspect of the controversy. This episode was originally recorded on July 6, 2021.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/RmBJFDBChxA)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/katherineeban2/the_Drive_public.png)

Play

#169 - Katherine Eban: COVID-19 Lab Leak: Examining all sides of the debate and discussing barriers to a full investigation

#169 - Katherine Eban: COVID-19 Lab Leak: Examining all sides of the debate and discussing barriers to a full investigation

1x15s30s

0:001:39:43

## We discuss:

- An overview of the lab leak controversy [1:30];
- The troubling history of lab leaks of dangerous pathogens [8:30];
- The zoonotic transmission theory: did SARS2 come from a bat? [11:45];
- The debate about gain-of-function (GoF) research [26:15];
- Questions about US funding of GoF research in China [33:45];
- The uncertain significance of the furin cleavage site [51:30];
- Discerning what’s most important about both the zoonotic transmission and lab leak theories [1:01:15];
- Barriers to a full investigation [1:19:15]; and
- More.

§

## Show Notes

## Note: This podcast was recorded on July 6th, 2021. Because we want our subscribers to have access to comprehensive information about this controversial topic in a very quick time frame, these show notes differ in format from our usual approach. They are only loosely chronological and provide additional information not covered in the podcast.  Following the show notes there is an extensive list of links for those who desire to do more in-depth reading on this topic.

§

## An overview of the lab leak controversy [1:30]

- There is a brewing controversy around the origins of the virus responsible for COVID-19
  - There is no information in the public domain either regarding the viral sequence or other circumstantial evidence that would help answer the question about the origins of the virus
  - At the time of the pandemic’s arrival, it was believed that this was a virus of zoonotic origin
    - Thought to be a virus that occurred naturally
    - Likely originated from bats and transferred to an intermediary animal and then eventually humans in the wet markets of Wuhan, China
  - In early 2020, some critics began to question the zoonotic origin theory
    - they were met with the sharpest rebukes from both the scientific and political communities
    - The *Lancet* and *Nature Medicine* [both](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30418-9/fulltext) [published](https://www.nature.com/articles/s41591-020-0820-9) statements critical of the lab leak theory
    - Said such statements were xenophobic or otherwise ill-informed and conspiratorial
- Since that time, however, there has been a push for greater transparency
  - Starting in March 2021, an international coalition of more than 20 scientists (organized by [Jamie Metzl](https://en.wikipedia.org/wiki/Jamie_Metzl)) [published](https://www.nytimes.com/interactive/2021/03/04/us/covid-origins-letter.html) [four](https://www.nytimes.com/interactive/2021/04/07/science/virus-inquiries-pandemic-origins.html) [open](https://jamiemetzl.com/wp-content/uploads/2021/04/Open-Letter-to-the-World-Health-Organization-and-the-Members-of-its-Executive-Board-1.pdf) [letters](https://jamiemetzl.com/wp-content/uploads/2021/06/Letter-4-Draft-1.pdf) calling for an investigation into the lab leak theory
  - The call to investigate the lab leak theory is driven by two factors:
    - Unlike the cases of SARS-1 and MERS, which are very similar viruses, there has yet to be any identified species of origin and/or intermediary despite much effort
    - There has been an abject lack of transparency to date
      - In an autocratic nation like China, transparency is not a cultural norm, whether this was a lab leak or not
      - An inability to find the cause or discovery of a mistake would not have been acknowledged to the international scientific community
      - Why did we not take the lab leak theory seriously a year or 18 months ago when it might have been easier to gather information?
      - [Robert Redfield](https://en.wikipedia.org/wiki/Robert_R._Redfield), the former head of the CDC, offered to send in a team of experts to do widespread testing in Wuhan, especially the WIV
        - He thinks a lab leak could have been ruled out in a couple weeks if this had been done, but the Chinese government refused and destroyed records instead
        - It also blocked access to the mine where workers had been sickened months before the pandemic by a virus similar to SARS2

- The lab leak theory is not a unitary theory
  - Could be that researchers collected samples of natural viruses, a lab worker contracted one in the lab via aerosol transmission, and then the infected worker exposed others in the community
  - Could also be that researchers had been manipulating viruses to see if they would become more infectious, known as “gain-of-function” (GoF) research, and then that genetically modified virus was accidentally leaked into the community through an exposed worker

- Attention has focused on the Wuhan Institute of Virology (WIV)
  - Located near the Wuhan market where the first cases were identified
  - housed bat viral samples
  - had been doing the type of research that could create a virus like SARS2
  - *T*he lead coronavirus researcher at WIV, [Shi Zhengli](https://en.wikipedia.org/wiki/Shi_Zhengli), is known as “Bat woman”
    - She has had a very successful career
    - is well-known for figuring out that the mechanism of transition for SARS1 was through the ACE-2 receptors in human lung cells
  - The Chinese CDC is also located in Wuhan right next to the market
    - Also had a collection of bat viruses
    - Fewer clues have pointed in its direction, and we know less about its work because it was not US-funded, but it cannot be definitively ruled out as a potential source of a lab leak
- The Chinese government has impeded a full investigation of the pandemic from the beginning
  - Shut down the wet market, ordered laboratory samples destroyed, claimed the right to review any scientific research about COVID-19 ahead of publication, expelled journalists, blocked search terms, pulled papers offline, penalized citizens who spoke out or questioned what happened, limited access of WHO team
  - There is no information about 3 WIV lab workers who became ill in summer/fall 2019 in the public domain
  - By now it may not be possible to find out the true origin of the virus

## The troubling history of lab leaks of dangerous pathogens [8:30]

> “This is not like, ‘Oh, how could that ever happen?’ In a way it’s like, ‘How could it not happen?’ Because it’s happened over and over and over again.” —Katherine Eban

- There are [numerous](https://gillesdemaneuf.medium.com/the-good-the-bad-and-the-ugly-a-review-of-sars-lab-escapes-898d203d175d) [examples](https://armscontrolcenter.org/wp-content/uploads/2016/02/Escaped-Viruses-final-2-17-14-copy.pdf) of other infectious agents, especially SARS, escaping from labs before this pandemic
- In May 2021, former FDA Commissioner [Scott Gottlieb](https://en.wikipedia.org/wiki/Scott_Gottlieb) [said](https://www.independent.co.uk/news/world/americas/scott-gottlieb-covid-wuhan-lab-leaks-b1856813.html) that laboratory leaks “happen all the time”

**SARS1**

Since July 2003, there have been 4 incidents of SARS1 escaping from 3 different labs

Of these, 3 were caused by breaches in laboratory biosafety and each resulted in at least one case of SARS:

- In September 2003, a cross contamination in a Singapore lab caused one case of SARS
  - A PhD student [became infected](https://www.nejm.org/doi/full/10.1056/NEJMoa032565) with SARS after his samples of West Nile virus were cross-contaminated with live SARS virus in a BSL-3 lab
  - The student used to working in BSL-2 labs was given only 20 minutes of training before being allowed to work in a BSL-3 lab
    - He was working at an institute because a BSL-3 lab was unavailable at his university
    - 3 days after his first day in the lab, he became ill with SARS
    - An investigation found multiple problems with both record keeping and lab practices and showed that there had been SARS contamination within the BSL-3
  - Though it was a serious safety breach, the government did a thorough and transparent investigation and “used it as an [opportunity](https://gillesdemaneuf.medium.com/the-good-the-bad-and-the-ugly-a-review-of-sars-lab-escapes-898d203d175d) to fundamentally redesign its biosafety approach”

- In December 2003, an accidental spill at a lab in Taipei, Taiwan caused one case of SARS
  - This [second incident](https://gillesdemaneuf.medium.com/the-good-the-bad-and-the-ugly-a-review-of-sars-lab-escapes-898d203d175d) occurred at a military BSL-4 lab
  - Authorities were not notified in a timely manner
  - large epidemic potential because it involved international air travel shortly after infection
  - The infected researcher was a 44-year-old US-educated pathologist who found a rip in a bag in the negative-pressure transport cabinet of the laboratory
    - He was in a rush and did not want to clean the spill using the necessary method of vaporized hydrogen peroxide, which would have taken hours, so instead he used a 70% ethanol spray
    - Wearing a regular mask and surgical gloves and no surgical gown, he stuck his head inside the cabinet to spray the spill
    - Ten minutes later, he wiped the spill and put the bag with the leak on the trash cart
    - He had lost his building access card and had used a borrowed one to get into the building
  - He flew to Singapore the next day with 6 colleagues but did not have a fever or seek medical care until he returned to Taiwan 3 days later
  - Aware that might have SARS but not wanting to disgrace the lab or Taiwan, he quarantined at home with his father and would not to go the hospital until his father threatened to commit suidcide
  - The lab did not have an incident-reporting procedure in place
  - There was no follow-up medical monitoring even though he missed 6 days of work
  - His family and colleagues were quarantined, as were fellow airline passengers from several countries after they were located
  - The Taiwanese government temporarily closed the lab and sanctioned the researcher, who was barred from seeking research project funding
  - There was an international investigation and all understood that it could have been a disaster; it was lucky that only the pathologist was infected

- In February 2004, the third incident (technically two events) occurred in a BSL-3 lab at the Institute of Virology in Beijing and caused two cases of SARS
  - It’s “a [story](https://gillesdemaneuf.medium.com/the-good-the-bad-and-the-ugly-a-review-of-sars-lab-escapes-898d203d175d) of towering academic ego, shocking incompetence, obstruction of the truth and lack of accountability”
  - A senior researcher had “lost face” with his initial incorrect theory
    - Based on electron microscope results, virus expert Hong Tao identified chlamydia as the main pathogen in the atypical pneumonia that had started to be seen in Guangdong province
    - The pathogen turned out to be SARS, but because of Hong Tao’s senior status his theory was accepted, and China fell behind in research as exploring other hypotheses was banned or discouraged
  - Hong wanted to restore his reputation by making the CDC a leader in SARS research
    - As the CDC’s research expanded, some SARS strains and potentially infectious materials began to be kept in two other BSL-3 labs, which were doing research on the diarrhea and prion viruses
    - The SARS BSL-3 laboratory was right next door to a BSL-2 electron microscope room
    - The lab was so overcrowded that SARS was kept in a locked fridge in the hall
    - Researchers carried the virus into the BSL-2 room to use the electron microscope, but the virus inactivation technology used by the lab was inadequate
  - Two researchers contracted SARS and became ill
    - Details were not shared by the government and are largely unknown
    - Both seem to have recovered without infecting anyone else
  - The Chinese government began to inspect labs around the country

In April 2004, the 4th incident (also technically two events, and also at the Institute of Virology in Beijing) resulted in 9 cases of SARS (7 from one chain of transmission / hospital spread), including one death

- A student who worked in the viral diarrhea department, who did not work with SARS and was not qualified to work in the BSL-3 lab, became ill as she was traveling home for a visit
  - The details of how she contracted SARS are unknown (or undisclosed)
  - When she came back to Beijing she was admitted to the hospital for pneumonia
  - Her mother later took her back home, where she spent time in 2 different hospitals
  - Her mother then became ill and died, but the student still did not know she had SARS
  - A nurse who had taken care of her also became ill
  - The nurse was ultimately linked to 5 cases: the nurse’s parents and aunt, a doctor who had shared a room with the nurse when they were both patients, and the doctor’s daughter-in-law
- Meanwhile, another researcher at the lab became sick and was diagnosed with SARS
- The institute was temporarily closed
- Eventually almost 1000 people were quarantined, including more than 260 people associated with the Institute of Virology
- There were 9 total cases of SARS
- The government was not forthcoming in reporting the two earlier February cases from the same lab
- The Ministry of Health Report found numerous problems
  - Interdisciplinary labs, untrained staff, inadequate viral inactivation, inadequate safety precautions, poor health monitoring, poor implementation of the two-person access system
  - Several people in charge of the Institute (though not Hong) were sanctioned, but the sanctions seemed largely symbolic

**Incidents with other microorganisms**

In 1979, [anthrax spores escaped](https://en.wikipedia.org/wiki/Sverdlovsk_anthrax_leak) from a military research lab in Sverdlovsk (now called Yekaterinburg) in the former Soviet Union

- At least 66 people died
- The USSR denied that anthrax had escaped and blamed the deaths on tainted meat
- Medical records were expunged
- The research violated the Biological Weapons Convention
- Boris Yeltsin later admitted that the deaths resulted from a lab leak

The 1977-79 [Russian flu pandemic](https://en.wikipedia.org/wiki/1977_Russian_flu)

- Caused about 700,000 deaths
- Primarily affected younger population (<25 years old)
- Was similar to a strain that had circulated in the 1940s and 50s
- Many scientists believe that it was accidentally released from a lab or from a live vaccine trial

In 1978, an incident at a medical school in Birmingham, England resulted in one death and one mild case of smallpox

- A [40-year-old medical photographer](https://www.bbc.com/news/uk-england-birmingham-45101091) at the school died from smallpox
- It was believed to have been eradicated and the last known “natural” case had been a year before on another continent
- Health officials vaccinated 500 people in the two weeks after she got sick
- Her mother got a mild case that she survived
- The head of the smallpox lab at the school killed himself
- While investigators were sure she contracted it in the lab, it was never clear how

**Many laboratory breaches have occurred in the US**

- The [67 select agents and toxins](https://www.selectagents.gov/sat/list.htm?CDC_AA_refVal=https%3A%2F%2Fwww.selectagents.gov%2FSelectAgentsandToxinsList.html) are microorganisms that have “the potential to pose a severe threat to both human and animal health, to plant health, or to animal and plant products”
- Between 2003 and 2009, the US National Research Council [reported](https://www.cidrap.umn.edu/news-perspective/2011/09/report-395-mishaps-us-labs-risked-releasing-select-agents) that there were 395 incidents of “potential release of select agents” used in the lab in US government laboratories
  - 7 related infections resulted: 4 *Brucella melitensis,* 2 *Francisella tularensis,* and 1 *Coccidioides* (species unidentified)
  - 196 of those incidents were caused by “loss of containment” of dangerous pathogens
- In 2012 the CDC [reported](https://www.reuters.com/article/us-usa-anthrax-labs-analysis/how-to-fix-u-s-biosecurity-leaks-close-some-labs-idUSKBN0FJ0BC20140714) that incidents of microbes being lost or escaping from select-agent labs increased from 16 in 2004 to 128 in 2008 to 269 in 2010

- 2014 breaches
  - Anthrax from a BSL-3 CDC lab in Atlanta was improperly sterilized before being moved to a BSL-2 lab, no cases
    - a [CDC report](https://www.cdc.gov/labs/pdf/Final_Anthrax_Report.pdf) concluded that the primary reason for the breach was a lack of “an approved … study plan … to ensure that the research design was appropriate and met all laboratory safety requirements”
    - up to 75 people were potentially exposed
    - were given the anthrax vaccine and an antibiotic and no one became ill
  - Six vials of smallpox were found in a cold storage room at an FDA lab, no cases
    - possibly had been there since the 1960s
    - an [investigation](https://www.fda.gov/media/101811/download) found serious deficiencies in inventory control
  - A vial of [bird flu](https://www.vox.com/future-perfect/2019/3/20/18260669/deadly-pathogens-escape-lab-smallpox-bird-flu) was contaminated with a much deadlier version and then mailed across the US, no cases
    - used for research in a lab unequipped to handle dangerous viruses
    - Only discovered during the investigation of the 2014 anthrax incident
  - Then-CDC director [Thomas Frieden](https://en.wikipedia.org/wiki/Tom_Frieden) advocated “[reduc[ing] the number](https://www.reuters.com/article/us-usa-anthrax-labs-analysis/how-to-fix-u-s-biosecurity-leaks-close-some-labs-idUSKBN0FJ0BC20140714) of laboratories that work with dangerous agents to the absolute minimum necessary” to stem “an alarming rise in the number of incidents of lost or escaped microbes”

- In April 2002, [anthrax spores were found](https://www.cidrap.umn.edu/news-perspective/2002/04/anthrax-escapes-lab-room-usamriid-one-worker-exposed) indoors near a US Army Research Institute of Infectious Diseases (USAMRIID) lab in Maryland and a worker tested positive for anthrax
- exposure
- In 2001, anthrax stolen from a federal lab made 17 people sick and killed five others
  - A primary suspect, who later committed suicide, [worked](https://www.nytimes.com/2019/08/05/health/germs-fort-detrick-biohazard.html) at USAMRIID

**Ongoing issues with lab safety**

- It is the [people and processes in a lab](https://gillesdemaneuf.medium.com/the-good-the-bad-and-the-ugly-a-review-of-sars-lab-escapes-898d203d175d), not the actual BSL level certification, that determines how safe it is
- Laboratories are often located in major urban centers near universities, industry, and desirable living locations, but it is [much safer](https://www.reuters.com/article/us-usa-anthrax-labs-analysis/how-to-fix-u-s-biosecurity-leaks-close-some-labs-idUSKBN0FJ0BC20140714) to have them way from densely populated areas and transportation hubs

## Safety concerns at the Wuhan Institute of Virology (WIV)

- Research with incredibly dangerous pathogens is taking place in laboratories across the world with insufficient safety standards (10:24)
- Live SARS viruses are being studied in overcrowded laboratories in China and elsewhere with very few protections

[**Biosafety levels**](https://www.cdc.gov/training/quicklearns/biosafety/)

- BSL-1 (minimal hazard, e.g., non pathogenic strain of *E. coli*): follows standard microbiological practices (no eating, drinking, or applying cosmetics, washing hands after working with infectious materials and before leaving, routinely decontaminating work surfaces); work can be performed on an open lab bench or table; personal protective equipment (PPE) such as lab coats, gloves, and eye protection are worn as needed; sink available; doors to separate the working space
- BSL-2 (moderate hazard, e.g. *Staph aureus*):  access to the laboratory is restricted during work; PPE includes lab coats, gloves, eye protection, and face shields if needed; potential infection from aerosols or splashes prevented by working within a biological safety cabinet (BSC); an autoclave or an alternative method of decontamination is available; self-closing doors; sink and eyewash available
- BSL-3 (can cause serious disease through respiratory transmission, e.g., *Mycobacterium tuberculosis*): workers under medical surveillance (and might receive immunizations); access is restricted and controlled at all times; appropriate PPE required ([including](https://pubmed.ncbi.nlm.nih.gov/24552359/) powered air purifying respirators for work with select agents and N95 respirator for other agents); work performed within BSC; hands-free sink and eyewash available; air circulation control; lab entrance through two sets of self-closing and locking doors
- BSL-4 is the highest level of safety (high risk of aerosol-transmitted infections which are frequently fatal and have no treatment or vaccines, e.g., Ebola and Marburg viruses): change clothing before entering; shower upon exiting; decontaminate all materials before exiting; all work performed within an appropriate Class III BSC or in a full body, air-supplied, positive pressure suit; laboratory has dedicated supply and exhaust air, vacuum lines and decontamination systems, and is located in a separate building or in an isolated and restricted zone of the building

**Issues at the WIV**

- In 2018, US government representatives visited the WIV for the opening of its BSL-4 laboratory and [reported](https://www.washingtonpost.com/opinions/2020/04/14/state-department-cables-warned-safety-issues-wuhan-lab-studying-bat-coronaviruses/) that a shortage of highly trained technicians and clear protocols were threats to the safety of the lab
- Shi Zhengli of WIV herself had [stated](https://www.sciencemag.org/sites/default/files/Shi%20Zhengli%20Q%26A.pdf) that her coronavirus research had been conducted in BSL-3 and even BSL-2 laboratories
- The Wuhan institute of Virology is one of 3 labs doing GoF research on SARS2 – the other two are located in the US (Galveston, TX and Chapel Hill, NC)

## The zoonotic transmission theory: did SARS2 come from a bat? [11:45]

- The zoonotic theory holds that SARS2 also likely went from bats to an as-yet-unidentified animal (possibly a pangolin or a civet cat) to humans
  - SARS1 epidemic of 2002: bats to civets to humans
    - intermediary host species identified within 4 months
  - MERS in 2012: bats to camels to humans
    - intermediary host species identified within 9 months
- Statistical analyses of the the probability of a lab vs. zoonotic origin did not account for the likely millions of bat sequences that exist in nature but remain unknown
- The [CDC estimates](https://www.cdc.gov/media/releases/2019/s0506-zoonotic-diseases-shared.html) that 6 out of 10 infectious diseases in people come from animals, including diseases caused by coronaviruses
  - Globally, zoonotic diseases have [been on the rise](https://www.nature.com/articles/nature06536) for decades as humans continue to develop traditional animal habitats
  - Some form of human and animal contact (markets, farms) is far more common than lab accidents
- In the past, initial and intermediate host animals sometimes have not been identified long after outbreaks
  - the natural source of the Ebola virus remains a mystery (perhaps a bat or chimp)
  - But here Chinese authorities have tested up to 80,000 animal samples to see if they could find a host animal and have not been able to do so a year and 9 months later

- Viruses can generate untold numbers of variants
  - It can acquire additional “tools” in the intermediary host before making the final leap to humans
  - We see only the one-in-a-billion that natural selection picks for survival
- Genetic study shows the virus carries [all the messy hallmarks](https://www.cnn.com/2021/03/31/health/lab-leak-coronavirus-theory-comic-book-scn/index.html) of nature and none of the fingerprints that would have been left behind by laboratory manipulation

**SARS2 could have jumped directly from bats to humans without going through an intermediate host**

- In an October 2013 *Nature* [study](https://www.nature.com/articles/nature12711), Shi Zhengli reported that certain bat viruses could potentially infect humans without first jumping to an intermediate animal, entering human cells through the ACE2 receptor
- SARS-2 appears to be similar to a virus that infected Chinese miners in 2012
  - 6 miners who shoveled bat guano out of a mine in southern China (Yunnan province) were infected with a bat coronavirus
    - Guano was from rufous horseshoe bats, the same kind that triggered SARS-1
    - developed symptoms similar to future COVID-19 patients
    - 3 of them died
  - Chinese authorities never reported this to the World Health Organization as required
    - samples from the miners were taken to WIV where the virus was named BtCoV/4991
    - It was later renamed RaTG13 in lab records for unclear reasons
    - Only known now because an anonymous science teacher from India ([“The Seeker” on Twitter](https://twitter.com/TheSeeker268?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)) found this information in a database of Chinese student theses he searched
- The miners’ illness from RaTG13 (the closest known relative of SARS2) is evidence it can jump directly to humans under certain conditions (massive overexposure in that case)
  - Could explain why no one has so far found a trace of SARS2 in any intermediate host or in human populations before December 2019
  - Could also explain why SARS2 did not need to mutate multiple times before it first appeared in humans
- RaTG13 is 96.2% similar to SARS2
  - [Robert Garry](https://medicine.tulane.edu/departments/microbiology-immunology-tulane-cancer-center-tips-advisory-committee-tips-mentor/faculty) of Tulane and [Charles Chiu](https://profiles.ucsf.edu/charles.chiu) of UCSF [have stated](https://www.nbcnews.com/science/science-news/lab-leak-theory-science-scientists-rcna1191) that a virus like RaTG13 would still take decades to evolve into SARS2, a process that exceeds the capabilities of genetic engineering and can’t be forced in a lab
  - Others say it is possible that SARS2 was engineered from RaTG13 or a close precursor found in the mine
    - In WIV data, DRASTIC researchers found 8 more viruses from the mine that were closely related to SARS2
- Hundreds of samples were taken from the cave to WIV
  - The WIV’s database of ~22,000 virus samples and sequences was taken offline in September 2019, before the known start of the COVID-19 outbreak
  - Outside scientists do not have access to information about all the samples that emerged from the mine
  - It’s theoretically possible that one of these viruses was SARS2

> “We know that there are hundreds of samples that were extracted, and we presume that there was deep sequencing done on these samples. But … we don’t have access to all that information, so we don’t know if any of those other samples may have closed the gap from 96.2 to 100%.” —Katherine Eban [22:00]

- In October 2015, a research team [collected serum samples](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6178078/) from 218 residents in four villages in Yunnan province near bat caves
  - The region had not been affected by the SARS1 outbreaks in 2002–2003
  - Used 240 serum samples from random blood donors in Wuhan (more than 1000 km away) as controls
  - Found that 2.7% of the rural residents had antibodies to coronaviruses similar to SARS
  - Provides further evidence that some bat coronaviruses are able to infect humans directly from bats without an intermediate host
  - But it’s still unclear how the virus would get to Wuhan without leaving a trail
- There are no signs of deliberate genetic modification in the virus’s code (although this would not necessarily be possible to detect)
- One scientist said that the virus infects people in a novel way that is “too good” to have been a lab creation: “no human using a computer could do this”
  - Molecular-modeling software predicted that if you wanted to optimize an existing bat virus so that it would replicate well in human cells, you would design it in a different way than the SARS-2 virus
  - SARS-CoV-2 does binds human ACE2 with high affinity, but computational analyses find that the RBD sequence is [different](https://www.nature.com/articles/s41591-020-0820-9) from those that would be optimal for receptor binding, suggesting natural selection rather than human manipulation
- SARS-CoV-2 is not derived from any previously used virus backbone
  - if it were manufactured, a new, unpublished backbone would have to have been used, which seems unlikely

## The debate about gain-of-function (GoF) research [26:15]

**The precise definition of gain-of-function (GoF) research varies**

- The term “gain-of-function” was [probably coined](https://www.ncbi.nlm.nih.gov/books/NBK285579/)  at a 2012 meeting at the NIH
- An NIAID scientist has [said](https://www.ncbi.nlm.nih.gov/books/NBK285579/) that “the term gain-of-function … is a vague and unsatisfactory term for microbiologists”
- Generally means manipulating a virus to make it either more transmissible or more virulent
  - researchers have [re-created](https://nicholaswade.medium.com/origin-of-covid-following-the-clues-6f03564c038) the 1918 flu virus
  - made polio virus from its published genome sequence
  - put a smallpox gene into a different virus
  - In 2000, a Dutch team [genetically engineered](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC111474/) the spike protein of a mouse coronavirus so that only cats would be susceptible

- The goal of GoF research is to allow scientists to develop tests, treatments, and vaccines for potential outbreaks
  - [predict](https://nymag.com/intelligencer/article/coronavirus-lab-escape-theory.html) which microorganisms in nature are potential threats and then figure out how to protect humans or carrier animals ahead of time
  - Anticipate how dangerous viruses might spread
  - Allow surveillance and monitoring by identifying the most dangerous strains in nature and tracing them to see if mutations are developing
  - Perhaps could forecast mutations like the new delta variant of SARS2

**Debates about the value of GoF research**

The [discussion](https://www.nytimes.com/2014/06/30/opinion/anthrax-thats-not-the-real-worry.html) [began](https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(18)30006-9/fulltext) around 2011 when research was done on flu strains engineered to spread in ferrets

- A scientist named [Ron Fouchier](https://www.erasmusmc.nl/en/research/researchers/fouchier-ron) did GoF research with the H5N1 virus and through lab manipulations created a pathogen that he claimed was highly dangerous and infectious
- Led to the formation of an anti-GoF research alliance called the [Cambridge Working Group](https://www.cambridgeworkinggroup.org/about)

Scientists [have debated](https://www.ncbi.nlm.nih.gov/books/NBK285579/) its utility ever since

- Some say it is not the most useful approach scientifically
  - Even if we find one potentially dangerous mutation, there could be thousands of others we’d miss
  - Questionable value
    - [Marc Lipsitch](https://en.wikipedia.org/wiki/Marc_Lipsitch) of the Harvard School of Public Health says that GoF experiments have contributed [very little](https://nymag.com/intelligencer/article/coronavirus-lab-escape-theory.html) to pandemic preparedness and has written [articles](https://www.cidrap.umn.edu/news-perspective/2014/06/commentary-case-against-gain-function-experiments-reply-fouchier-kawaoka) outlining the arguments against them
    - [Nichloas Wade](https://en.wikipedia.org/wiki/Nicholas_Wade) observes, “From the hindsight of 2021, one can say that the [value](https://nicholaswade.medium.com/origin-of-covid-following-the-clues-6f03564c038) of gain-of-function studies in preventing the SARS2 epidemic was zero”
- Others say that regardless of its scientific utility, it is too dangerous
  - The risks of GoF research are [far greater](https://www.vox.com/future-perfect/2019/3/20/18260669/deadly-pathogens-escape-lab-smallpox-bird-flu) than those we typically take, like killing people while driving or even a lab leak affecting only those who work in the lab – this can have millions of victims
  - A 2012 [editorial](https://www.nytimes.com/2012/01/08/opinion/sunday/an-engineered-doomsday.html) in the NYT said that risks of GOF research outweighed the benefits
  - In 2012, the [*Bulletin of the Atomic Scientists*](https://thebulletin.org/2012/08/the-unacceptable-risks-of-a-man-made-pandemic/) [predicted](https://thebulletin.org/2012/08/the-unacceptable-risks-of-a-man-made-pandemic/) that, given the number of labs then doing GoF research, the chance of a lab leak in the next 12 years was 80%
  - In July 2014, Lipsitch and the Cambridge Working Group wrote a [statement](https://www.cambridgeworkinggroup.org/) (signed by 100+ scientists) saying that the risks of research with “potential pandemic pathogens” outweighed the potential benefits
- Still others say that other types of research can’t answer all our questions and thus GoF is sometimes necessary
  - loss-of-function experiments don’t always yield enough information
  - highly pathogenic variants of viruses might behave differently (e.g., in replication) than more benign ones
  - enhancing the ability of dangerous animal viruses to infect people helps us determine how close they might be to making the jump to humans in the wild
  - In 2011, [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) and [Francis Collins](https://en.wikipedia.org/wiki/Francis_Collins) (along with [Gary Nabel](https://en.wikipedia.org/wiki/Gary_Nabel), then the Director of Vaccine Research at NIAID) wrote an editorial for the *Washington Post* in which [they defended](https://www.washingtonpost.com/opinions/a-flu-virus-risk-worth-taking/2011/12/30/gIQAM9sNRP_story.html) GoF research on the grounds that the potential benefits (development of vaccines and treatments) made it a risk worth taking

**US requirements for GoF funding**

- The “pause” period (2014-2017)
  - In October 2014, the Obama administration [imposed a moratorium](https://nymag.com/intelligencer/article/coronavirus-lab-escape-theory.html) (pause) on GoF research “that may be reasonably anticipated to confer attributes to influenza, MERS, or SARS viruses such that the virus would have enhanced pathogenicity and/or transmissibility in mammals via the respiratory route”
  - Defined GoF as “research that improves the ability of a pathogen to cause disease”
  - In place [from 2014-2107](https://www.phe.gov/s3/dualuse/documents/gain-of-function.pdf), the pause  did not apply to “characterization or testing of naturally occurring influenza, MERS, and SARS viruses, unless the tests are reasonably anticipated to increase transmissibility and/or pathogenicity”
  - Scientists [debated](https://www.factcheck.org/2021/05/the-wuhan-lab-and-the-gain-of-function-disagreement/) where to draw the line in defining what kind of research should be considered too risky
  - Moratorium would seem to apply to:
    - the work published by [Ralph Baric](https://en.wikipedia.org/wiki/Ralph_S._Baric) of the University of North Carolina and Shi in 2015 that created a new virus with a spike protein gene from a bat coronavirus and a backbone from SARS
    - and to an NIH / EcoHealth Alliance-funded project at WIV, published in 2017, that created a new virus with spike protein genes from a bat coronavirus and a backbone from a different bat coronavirus
  - But there was a loophole in a [footnote](https://www.phe.gov/s3/dualuse/documents/gain-of-function.pdf) granting an exception if the head of the agency providing funding found that the research is “urgently necessary to protect the public health or national security”
    - *Science Magazine* [claims](https://www.sciencemag.org/news/2019/02/exclusive-controversial-experiments-make-bird-flu-more-risky-poised-resume) that about half of 18 projects were allowed to continue under the loophole or because the work didn’t meet the moratorium definition
  - Baric and a colleague wrote a [letter](https://osp.od.nih.gov/wp-content/uploads/2013/06/Gain_of_Function_Deliberative_Process_Written_Public_Comments.pdf) to the NIH objecting to the policy, stating that it “will significantly inhibit our capacity to respond quickly and effectively to future outbreaks of SARS-like or MERS-like coronaviruses”
    - Baric’s experiments were ultimately allowed to proceed
- The P3CO Framework Period (2017-present)
  - In January 2017, the Trump administration lifted the moratorium and replaced it with the Potential Pandemic Pathogen Care and Oversight [(P3CO) Framework](https://www.phe.gov/s3/dualuse/documents/p3co.pdf), which covered “research…reasonably anticipated to create, transfer, or use enhanced PPPs [potential pandemic pathogens]”
    - PPPs are defined as pathogens that are “1. likely highly transmissible and likely capable of wide and uncontrollable spread in human populations; and 2. likely highly virulent and likely to cause significant morbidity and/or mortality in humans”
    - enhanced PPPs result from “the enhancement of the transmissibility and/or virulence of a pathogen”
  - Required the funding agency to flag and report GoF research proposals for risk-benefit review

**The WIV had been doing GoF research on SARS viruses at the time the pandemic started**

- In November 2015, Shi and Ralph Baric [created a novel virus](https://www.nature.com/articles/nm.3985) by taking the backbone of the SARS1 virus and replacing its spike protein with one from a bat virus (known as SHC014-CoV), which could infect lab cultures of human airways
  - Showed that the virus could jump directly from bats to humans by using the same receptor
  - The new virus replicated as well as SARS1 in human lung cells
  - Could not be treated with the standard treatments for SARS1 or Ebola
- Classified US documents also suggest that three staff members at the WIV were sick in November 2019, before the first cases of COVID-19 were reported in China
- In December 2019, [Peter Daszak](https://en.wikipedia.org/wiki/Peter_Daszak), who had funded and worked with Shi, said in an [interview](https://www.youtube.com/watch?v=IdYDL_RK--w) that researchers at the WIV had been engineering the spike protein and developing chimeric coronaviruses that could infect humanized mice
- The US State Department determined that the WIV has collaborated on publications and secret projects with China’s military

## Questions about US funding of GoF research in China [33:45]

- In 2018, the NIH approved two grants to fund GoF experiments on avian flu viruses
  - Both were to scientists who had previously engineered the avian H5N1 virus to be transmissible among ferrets

**The EcoHealth Alliance Controversy**

- [EcoHealth Alliance](https://en.wikipedia.org/wiki/EcoHealth_Alliance) is an NGO focused on global environmental health and “dedicated to protecting wildlife and public health from the emergence of disease”
  - Part of its goal is to map the viruses in the natural world and use that information in part to preserve wild spaces
  - annual budget varies between $9-15 million
    - partners with numerous governmental, academic, and corporate institutions
    - allocates funds to facilities conducting gain-of-function research, which gives it a lot of power and influence within the virology field
- Supports The Global Virome Project, which sought to map viral strains around the world
  - Some question the safety of collecting viruses from nature all over the world and bringing the samples back to labs
- EcoHealth Alliance received $3.7 million in grant money from the NIH’s National Institute of Allergy and Infectious Diseases (NIAID) between June 2014 and May 2019
  - The Alliance also received funding from the Department of Defense
  - EcoHealth allocated ~$600,000+ in grant money to Shi’s lab at the WIV over a period of years
  - In April 2020, in response to an (inaccurate) question a reporter asked Trump about US finding of the WIV, the government terminated the grant
  - This decision was heavily criticized in an [open letter](https://www.sciencemag.org/sites/default/files/NL%20letter%20final.pdf) from 77 science Nobel Laureates and on [*60 Minutes*](https://www.ioes.ucla.edu/news/peter-daszak-on-60-minutes-coronavirus-research-upended-by-politics/)
  - The grant was reinstated in July with a set of [bizarre conditions](https://www.sciencemag.org/news/2020/08/nih-imposes-outrageous-conditions-resuming-coronavirus-grant-targeted-trump) such as explaining cell phone usage patterns in Wuhan
- Peter Daszak, the head of EcoHealth Alliance, has been a vocal critic of the lab leak theory
  - In February 2020 (shortly after the pandemic became international news), the *Lancet* published a [statement](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30418-9/fulltext) that rejected the lab-leak hypothesis, casting it as a xenophobic conspiracy theory
    - It was later discovered that the statement was organized by Peter Daszak
    - Though he and 6 others with ties to EcoHealth Alliance signed the statement, no conflicts of interest were declared (this was [amended](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)01377-5/fulltext?utm_campaign=lancetcovid21&utm_source=twitter&utm_medium=social) in June 2021)
    - If a lab leak occurred, Daszak would not necessarily be aware of it, but he would have a large interest in it not being true
  - Nicholas Wade has [sharply criticized](https://nicholaswade.medium.com/origin-of-covid-following-the-clues-6f03564c038) Daszak’s reaction to the pandemic, charging that instead of sharing the information he knew, “he immediately launched a public relations campaign” to discredit the lab leak theory
  - Daszak was the only American WHO selected for its January 2021 fact-finding trip to Wuhan
    - defended not asking the WIV for access to its databases
  - In April 2020 he called the lab leak theory “[pure baloney](https://www.democracynow.org/2020/4/16/peter_daszak_coronavirus)”
  - In June 2020, Daszak published an [article](https://www.theguardian.com/commentisfree/2020/jun/09/conspiracies-covid-19-lab-false-pandemic) called “Ignore the conspiracy theories: scientists know Covid-19 wasn’t created in a lab”
  - He continues to post articles critical of the lab leak theory on his [Twitter feed](https://twitter.com/PeterDaszak?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
- Daszak [left the UN-*Lancet* commission](https://www.dailymail.co.uk/news/article-9710875/Peter-Daszak-removed-COVID-commission-following-bombshell-conflict-report.html) investigating the pandemic origins in June 2021 after it became public that he had organized the initial statement
- Recent reports allege that Google has [funded EcoHealth Alliance research](https://www.foxnews.com/media/google-ties-to-wuhan-lab-coronavirus-daszak), raising questions about media neutrality about the lab leak theory
- In addition to the *Lancet* statement, a March 2020 [letter](https://www.nature.com/articles/s41591-020-0820-9) in *Nature Medicine* authored by Scripps virologist [Kristian Andersen](https://www.scripps.edu/faculty/andersen/), Robert Garry, and others also sharply criticized the lab leak theory
  - The objectivity of *Nature* [has](https://www.insidehighered.com/news/2018/10/03/book-publishers-part-ways-springer-nature-over-concerns-about-censorship-china) [been](https://www.insidehighered.com/quicktakes/2017/11/02/publisher-complies-chinese-censorship) [questioned](https://retractionwatch.com/2020/07/23/author-retracts-nature-commentary-over-concerns-about-sections-sponsorship/) based on evidence that it has censored Chinese language versions of its articles

**Controversial statements by US government officials**

- Officials have denied funding GoF research

- In May 2021, NIH Director Francis Collins posted a [statement](https://www.nih.gov/about-nih/who-we-are/nih-director/statements/statement-misinformation-about-nih-support-specific-gain-function-research) claiming that “neither NIH nor NIAID have ever approved any grant that would have supported ‘gain-of-function’ research on coronaviruses that would have increased their transmissibility or lethality for humans.”
- That same month, Anthony Fauci told a Senate hearing that “the NIH and NIAID categorically has not funded gain-of-function research to be conducted in the Wuhan Institute of Virology”
- Accusations of falsehood
  - *Independent Science* news observes that “the discrepancy between these official statements, and the opinions of relevant experts and the amount of evidence suggesting the contrary, is disturbing”
  - Richard Ebright [objected](https://jamiemetzl.com/origins-of-sars-cov-2/) that this statement is false unless “for humans” means “in studies with human subjects” (and, if it does, the statement is irrelevant to both US policies, neither of which are limited to transmissibility / lethality for humans)
- Disagreement over terms
  - [To some](https://nicholaswade.medium.com/origin-of-covid-following-the-clues-6f03564c038), the term “gain-of-function” applies only to enhancements of viruses that infect humans, not to animal viruses, meaning the enhancement of human viruses
    - But this is not the definition used in the moratorium
  - [Alina Chan](https://giving.broadinstitute.org/broadignite/team/alina-chan) mentioned in a [Twitter thread](https://twitter.com/Ayjchan/status/1370880584936001541?s=20) that there has been some disagreement about what would be classified as GoF
    - for example, there is disagreement about whether chimeric viruses count
    - The research in question was not designed to increase either transmissibility or pathogenicity
      - whether research is “likely” or “reasonably anticipated” to enhance transmissibility can be subjective
      - makes it unclear whether the EcoHealth Alliance grants funded GoF research
      - it was technically molecular characterization, which the NIH did not consider GoF

- Now there are numerous ongoing investigations (including by the HHS inspector general) about what the federal government knew about this research
  - Hard to disentangle conspiracy theories that have no basis in reality from the credible questions

> “I’m always mindful of this expression we have in investigative journalism: never assume conspiracy when incompetence is an option.” —Katherine Eban [1:26:15]

- Katherine believes there are valid questions about the funding
  - Why were we giving taxpayer dollars to a high-level Chinese laboratory where we now believe Chinese military scientists were working?
  - “Maybe we should make more of an effort to restrict our research dollars to the science laboratories of allies and not adversaries”

- There have been barriers to investigation in the US, not just in China
  - One’s stance on the lab leak became a political statement
    - Peter doubts this debate would have been as polarized if it had been just among scientists and politics did not play a role
    - Katherine says it became very politicized
      - in April 2020, Trump announced SARS2 was a lab leak
        - he had no evidence to establish his claim at that time
        - Some thought he was not trying to get to the bottom of the pandemic but using it as a way to bludgeon China using terms like “Kung flu”
      - his own agencies had put out a statement that the lab leak theory was false (for which there was also no evidence at the time)
    - Once polarizing public figures began to push the lab leak theory, it became off limits for mainstream thinkers and media to explore
  - Conflicts of interest hampered the U.S. investigation into COVID-19’s origin
    - The government did not want bad publicity associated with funding GoF research
    - many leading experts had either received or approved funding for gain-of-function research

> “A lot of those people I interviewed, they said the same thing to me: ‘I got into this because I wanted to know why the scientists were acting so unscientific. Why do you take a hypothesis off the table without evidence? If you’re having an investigation, don’t you pursue all hypotheses in an equal fashion until you have real evidence?’” —Katherine Eban [1:17:30]

- If a lab leak did occur at the WIV, the US bears some responsibility because we do similar research and have funded and worked collaboratively with them
- There is likely to be a lot more transparency around GoF research funding now

## The uncertain significance of the furin cleavage site [51:30]

- Cellular entry of both SARS1 and SARS2 viruses is mediated by the binding of receptors on the host cell surface (primarily ACE2) to the viral receptor-binding domain
- But ACE2 has a [10-to-20 fold higher affinity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7164637/) for SARS2 than SARS1
  - Furin, which is found on human cell surfaces, will cut any protein chain that carries a specific amino acid sequence
  - Unlike SARS1, SARS2 has a proline-arginine-arginine-alanine (PRRA) insert that, when combined with the subsequent arginine (R) on the end, creates arginine-arginine-alanine-arginine (RRAR), a furin cleavage site

![](https://peterattiamd.com/wp-content/uploads/2021/07/f1-eban2-1024x913.jpg)

**Figure 1. Comparison of SARS1 and SARS2 amino acid sequences and method of cell entry**.  ([Wu et al. 2020](https://www.sciencedirect.com/science/article/pii/S2589004220308348))

- This site [may be the reason](https://www.sciencedirect.com/science/article/pii/S2589004220308348) why SARS2 infection is stronger than SARS1
  - The virus can’t invade a cell until its two subunits have been cut apart, and the furin cleavage site ensures that the spike protein will be cleaved in exactly the right place
  - If S1 and S2 are cut before maturity, it may allow S1 more flexibility to alter its conformation to better fit the host receptor
  - makes the virus more infectious by allowing it to efficiently enter human cells

**Some evidence suggests that the furin cleavage site was added in a lab**

- Of all known subtype B beta-coronaviruses, only SARS2 possesses a furin cleavage site
  - The PRRA insert [is not found](https://www.sciencedirect.com/science/article/pii/S2589004220308348) in any other subtype B beta coronaviruses (although there is one in some other beta coronaviruses such as MERS, which is subtype C)
  - Its higher affin­ity for hu­man ACE2 re­cep­tors than any other an­i­mal species so far tested, in­clud­ing horse­shoe bats, suggesting it was be­ing cul­tured in hu­man cells
  - SARS2 seems to have only feeble affinity for bat cells, raising questions about whether it came from a bat
- SARS2’s most notable features, the furin site and the human ACE2-binding domain, were unlikely to have arisen simultaneously
- SARS2 also has a flat ganglioside-binding domain (GBD) on the spike protein which is different from other coronaviruses in its pattern of host evasion survival

![](https://peterattiamd.com/wp-content/uploads/2021/07/f2-eban2-1024x769.png)

**Figure 2. Spike protein, furin cleavage site, and the ACE-2 binding domain**. Sources: [1](https://www.miltenyibiotec.com/US-en/lp/recombinant-antigens-for-sars-cov-2-research.html#gref), [2](https://link.springer.com/article/10.1007/s10311-021-01211-0), [3](https://www.researchgate.net/publication/344026303_Increased_mortality_of_COVID-19_infected_diabetes_patients_role_of_furin_proteases).

- Eleven GoF experiments using an added a furin site to enhance the infectiousness of a virus [have been published](https://zenodo.org/record/4477212#.YIMDSOhKhPY), including one by Shi
- Shi had done experiments with furin cleavage sites at the WIV
- A Nobel Laureate, [David Baltimore](https://en.wikipedia.org/wiki/David_Baltimore), stated that the furin cleavage site was the “smoking gun” of gene manipulation (though he [later said](https://www.theguardian.com/world/2021/jun/09/leading-biologist-dampens-his-smoking-gun-covid-lab-leak-theory) he had overstated the case)
- There is no way to establish definitely if a virus has been manipulated
- Mutation, which typically affects single amino acids, seems a [less likely way](https://nymag.com/intelligencer/article/coronavirus-lab-escape-theory.html) for SARS2’s furin cleavage site to be generated (though it can’t completely be ruled out)
- SARS2 has a pair of arginine codons (double CGG)
  - This codon is more commonly seen in human cells than in coronaviruses
  - The human-preferred codon is routinely used in labs

**But existing data does not establish definitely that SARS2 was bioengineered**

In Nicholas Wade’s piece, he says there is no evidence of furin cleavage sites in any SARS-like beta coronaviruses

- But [studies](https://pubmed.ncbi.nlm.nih.gov/33340798/) have found furin cleavage sites in other beta coronaviruses (just not in subtype B like SARS2)
- A [2018 study](https://www.nature.com/articles/s41598-018-34859-w) found a furin cleavage site in MERS (a subtype C beta coronavirus)

[*Many coronaviruses*](https://www.nature.com/articles/d41586-021-01529-3) *have furin cleavage sites with the same codons*

- In SARS2, [about 3% of the nucleotides](https://web.archive.org/web/20210527162603/https:/twitter.com/K_G_Andersen/status/1391507230848032772?s=20) encoding arginine are CGG
- 5% of those encoding arginine in the virus that caused the original SARS epidemic are also CGG

*SARS2 could have picked up the furin cleavage site from a natural source*

- One potential source is an as-yet-unknown betacoronavirus
- Another is humans: a predecessor of SARS2 could have been circulating in the human population and then acquired a furin cleavage site from human cells
- SARS-2’s crucial features — the furin cleavage site and the ACE2 receptor — could be the result of recombination of a bat coronavirus (perhaps RaTG13) and another, unknown virus
- In the earliest days of the pandemic, researchers found [two distinct lineages](https://www.vox.com/22453571/lab-leak-covid-19-coronavirus-hypothesis-wuhan-virology-china) of the virus with different transmission patterns, suggesting either two wildlife sources or that the virus switched from one animal to another

> “There is no smoking gun per se. What there is is smoke coming out of a lot of windows. … There is enough smoke coming out of enough windows that we cannot take the lab leak hypothesis off the table, and so for me, the most credible people on this, they’re not saying it was a lab leak. What they’re saying is, ‘Why can’t we have a full investigation?’” —Katherine Eban [56:30]

## The lab leak theory: did SARS2 escape from a lab in Wuhan? [1:00:00]

Proponents of lab escape believe that they can explain all the available facts about SARS2 considerably more easily than can those who favor natural emergence

- Wuhan is home to WIV, where researchers were genetically engineering bat coronaviruses to attack human cells under the minimal safety conditions of a BSL2 lab
- The evidence much more easily explained by the fact that the initial outbreak city housed a laboratory doing aggressive SARS research on an extensive collection of bat viruses
- This theory includes a scenario in which a natural virus the researchers were working with escaped from the lab and an alternate scenario in which a virus that had been altered by researchers escaped

**It’s** [**too much of a coincidence**](https://nicholaswade.medium.com/origin-of-covid-following-the-clues-6f03564c038) **that a pandemic caused by a novel bat coronavirus started in a city that also happens to contain a laboratory doing aggressive SARS research on an extensive collection of bat viruses**

- The virus first appeared in Wuhan (population 11 million) without first appearing closer to the caves where the bats live
- The two closest known relatives of the SARS2 virus were collected from bats living in caves in Yunnan Province
  - but the pandemic broke out in Wuhan, which is 1,500 kilometers away
  - Horseshoe bats’ typical range is ~50 kilometers
- You would need a longstanding population of bats in frequent proximity with an intermediate host, which in turn must often cross paths with people
  - The infected person (or animal) carrying this highly transmissible virus must have traveled to Wuhan without infecting anyone else
  - Many cases had no link to the wet market in Wuhan as originally stated (the Chinese gov admitted in late May 2020 that it had ruled out the market as the origin point of the outbreak)

- The pandemic began at a time when horseshoe bats were hibernating

**SARS2 has not not evolved as would be expected with zoonotic transmission**

- The coronavirus spike protein makes multiple failed jumps to another species before it develops the necessary mutation
  - SARS1 had successive changes in its spike protein as the virus evolved, but SARS2 has changed hardly at all until recently
    - Peter thinks this is the most convincing piece of evidence for a lab leak
    - We’re only now seeing variants of this virus (e.g., the delta variant)
  - When SARS-CoV-2 was first detected in late 2019, it was [already pre-adapted](https://www.biorxiv.org/content/10.1101/2020.05.01.073262v1) to human transmission to an extent similar to late-epidemic SARS1
- The uniform structure of SARS2 genomes gives no hint of any passage through an intermediate animal host, and no such host has been identified in nature

## Discerning what’s most important about both the zoonotic transmission and lab leak theories [1:01:15]

- There are a lot of red herrings in this debate
  - If SARS2 was made in a lab, it doesn’t have to have been an attempt to create a perfect bioweapon, so it doesn’t really matter that it was not the most lethal contagious virus possible
  - And even if they were attempting to create a highly lethal and contagious virus, the leak was likely an accident and thus the virus was not necessarily in its final form
- Katherine doesn’t think there is a consensus view at this time
  - It’s been shattered and the scientific community is divided

**The strongest arguments for each side**

- Zoonotic origin
  - Based on the precedent of previous SARS outbreaks (SARS1 & MERS), it makes sense that this followed the same pattern
    - There isn’t specific evidence to contradict that despite the lack of identification of the animals involved
  - Because the virus is asymptomatic in many cases, it’s possible that it has an even earlier origin than we know, which would explain why it first appeared so far from where the bats live
    - Because of asymptomatic cases, the case fatality rate was infinitely lower than we initially thought
    - We didn’t realize this until serology was being done on asymptomatic people (done in a very [controversial study](https://www.who.int/bulletin/online_first/BLT.20.265892.pdf) by [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis))
  - Peter points out that, if it were a lab leak, a lot people would know and it would hard to keep them all quiet
- Lab leak theory
  - How would this have started naturally in the winter far from where the bats live in a market that doesn’t sell bats but does happen to be close to 2 labs doing research on these types of viruses?

> “Well, here are these laboratories that have the largest collection of bat samples, really in the world, who were doing some of the most aggressive testing, so there’s smoke coming out of that window.” —Katherine Eban [1:13:45]

- Wuhan labs have the largest collection of bat samples
- were doing aggressive gain-of-function research in which they were manipulating pathogens
- were doing it in as low as a BSL-2 setting
- When Chinese scientists wrote a paper making this point, it was immediately taken down

- We have been unable to find either the original bat or the intermediary host
- Especially compared to SARS1, SARS2 showed unusual stability (a relative lack of genetic drift or mutation) once it took hold in late 2019
- There’s a long history of / precedent for lab leaks

**The ultimate questions to ask about these theories**

- What’s the probability that this virus was brought into a lab?
- What’s the probability that the virus was manipulated in a lab?

> “What’s the likelihood that this thing made its way into a lab and got tweaked? That’s where you get into these other questions of, boy, the people who claim it didn’t aren’t doing themselves any favors in the way they’re acting. The EcoHealth Alliance, the *Lancet* paper, doesn’t look good in the light of day.” —Peter Attia [1:16:15]

- What’s the probability that the virus could unintentionally escape from a lab setting?
  - Likely very high – we know it has happened many times before (and harmless viruses have no doubt escaped many more times) and this was a low lab safety setting

## Barriers to a full investigation [1:19:15]

- There are multiple hurdles, both political and evidentiary, that stand in the way of a real investigation
  - “The question of COVID origin is the ultimate grassy knoll. This is one for the ages”
  - The anthrax lab leak in the Soviet Union in the 1970s was only disclosed after the authoritarian structure of the Soviet Union collapsed
  - The Chinese government exerts a lot of control over its citizens and it’s doubtful that Shi is free to share information or speak her mind
- This should be viewed not as a conspiracy but as two competing hypotheses, one of which was largely ignored because it was politically inconvenient to consider
- Presumably someone in China knows the answer to this question, but it’s unclear how much political capital other countries want to spend demanding answers from China
  - For example, [Scott Morrison](https://en.wikipedia.org/wiki/Scott_Morrison), the Prime Minister of Australia, pushed to have a lab leak investigation be part of the World Health Organization inquiry
  - China immediately blocked import of Australian goods
- The Biden administration [recently requested a report](https://www.whitehouse.gov/briefing-room/statements-releases/2021/05/26/statement-by-president-joe-biden-on-the-investigation-into-the-origins-of-covid-19/) on the pandemic’s origins to be delivered within no less than 90 days
  - but without more transparency on the part of the Chinese government our ability to uncover what happened will be limited
  - But “there is a lot of information that is potentially available to us if we are really to dig into our own filing cabinets”
    - Recently the virologist [Jesse Bloom](https://www.fredhutch.org/en/faculty-lab-directory/bloom-jesse.html) [reported](https://www.cnn.com/2021/06/23/health/coronavirus-sequences-database-scientist/index.html) that some early sequences from Wuhan were deleted from a shared Chinese-NIH database
- Peter says the primary issue is not even whether SARS2 came from a lab but that “there has been and likely will be forever an enormous obstruction to get to the truth about it”

> “Starting out … I was very dismissive because it sounded to me just like conspiracy theories. … But I think what’s happened is as time has gone on and no host animal has been found, and Trump has been removed and so there was a sort of space to ask this question … and China has failed to be transparent, and conflicts of interest have been exposed, and for my own reporting now I understand that a full investigation within the U.S. government was essentially blocked or restricted, I kind of give it even odds at this point. I think it’s a possibility. I don’t have a definite conclusion. If a host animal was found tomorrow, I would be like, okay. But I think there are just too many questions to be ignored right now” —Katherine Eban [1:22:15]

§

## Selected Links / Related Material

**Peter’s previous podcast with Katherine**: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) *The Drive*, Peter Attia (September 16, 2019) [0:45]

**Katherine’s other books**

- [Bottle of Lies: The Inside Story of the Generic Drug Boom](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1625753834&sr=1-1) by Katherine Eban (2019) [1:00]
- [Dangerous Doses: How Counterfeiters Are Contaminating America’s Drug Supply](https://www.amazon.com/Dangerous-Doses-Counterfeiters-Contaminating-Americas/dp/0151010501/ref=pd_lpo_14_t_2/139-2451850-0250862?_encoding=UTF8&pd_rd_i=0151010501&pd_rd_r=735c25b5-23f1-4f07-b242-2f6ccdf5812e&pd_rd_w=OiafM&pd_rd_wg=MMFnG&pf_rd_p=fb1e266d-b690-4b4f-b71c-bd35e5395976&pf_rd_r=9YB23MK89HPH7Y8N6RJM&psc=1&refRID=9YB23MK89HPH7Y8N6RJM) by Katherine Eban (2005)

**Overview of the lab leak theory controversy**

- [Experts weigh in on the Wuhan lab leak hypothesis](https://www.politico.com/newsletters/politico-nightly/2021/05/19/experts-weigh-in-on-the-wuhan-lab-leak-hypothesis-492915) Myah Ward and Renuka Rayasam, *Politico* (May 19, 2021)
- [The lab leak hypothesis, explained](https://www.vox.com/22453571/lab-leak-covid-19-coronavirus-hypothesis-wuhan-virology-china) Umair Irfan, *Vox* (Jun 7, 2021)
- [The COVID lab-leak hypothesis: what scientists do and don’t know](https://www.nature.com/articles/d41586-021-01529-3) Amy Maxmen & Smriti Mallapaty, *Nature* (June 8, 2021)

**Statements criticizing the lab leak theory**

- [Statement in support of the scientists, public health professionals, and medical professionals of China combatting COVID-19](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30418-9/fulltext) *Lancet* (Calisher … Daszak et al. 2020) [[amended](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)01377-5/fulltext?utm_campaign=lancetcovid21&utm_source=twitter&utm_medium=social) in June 2021 to reflect conflicts of interest] [40:30, 41:45, 1:16:30]
- [The proximal origin of SARS-CoV-2](https://www.nature.com/articles/s41591-020-0820-9) *Nature Medicine* (Andersen … Garry 202)

**Articles about previous lab leaks**

- [Case Study: Laboratory-Acquired Severe Acute Respiratory Syndrome](https://www.nejm.org/doi/full/10.1056/NEJMoa032565) *NEJM* (Lim et al. 2004)
- [The Good, the Bad and the Ugly: a review of SARS Lab Escapes](https://gillesdemaneuf.medium.com/the-good-the-bad-and-the-ugly-a-review-of-sars-lab-escapes-898d203d175d) Gilles Demaneuf, *Medium* (November 16, 2020)
- [Laboratory Escapes and “Self-fulfilling prophecy” Epidemics](https://armscontrolcenter.org/wp-content/uploads/2016/02/Escaped-Viruses-final-2-17-14-copy.pdf) Martin Furmanski, armscontrolcenter.org (February 17, 2014)
- [How to fix U.S. biosecurity leaks? Close some labs](https://www.reuters.com/article/us-usa-anthrax-labs-analysis/how-to-fix-u-s-biosecurity-leaks-close-some-labs-idUSKBN0FJ0BC20140714) Sharon Begley & Julie Steenhuysen, *Reuters* (July 14, 2014)
- [Report: 395 mishaps at US labs risked releasing select agents](https://www.cidrap.umn.edu/news-perspective/2011/09/report-395-mishaps-us-labs-risked-releasing-select-agents) Robert Roos, U of Minnesota CIDRAP (September 28, 2011)
- [How deadly pathogens have escaped the lab — over and over again](https://www.vox.com/future-perfect/2019/3/20/18260669/deadly-pathogens-escape-lab-smallpox-bird-flu) Kelsey Piper, *Vox* (March 20, 2019)
- Additional links
  - <https://www.cdc.gov/labs/pdf/Final_Anthrax_Report.pdf>
  - <https://www.fda.gov/media/101811/download>
  - <https://www.cidrap.umn.edu/news-perspective/2002/04/anthrax-escapes-lab-room-usamriid-one-worker-exposed>
  - <https://www.bbc.com/news/uk-england-birmingham-45101091>

**CDC information on biosafety levels**: [Recognizing the Biosafety Levels](https://www.cdc.gov/training/quicklearns/biosafety/) Centers for Disease Control

**CDC list of select agents**: [Select Agents and Toxins List](https://www.selectagents.gov/sat/list.htm?CDC_AA_refVal=https%3A%2F%2Fwww.selectagents.gov%2FSelectAgentsandToxinsList.html) CDC & USDA selectagents.gov (April 2021)

**Lab safety issues at the WIV**

- [State Department cables warned of safety issues at Wuhan lab studying bat coronaviruses](https://www.washingtonpost.com/opinions/2020/04/14/state-department-cables-warned-safety-issues-wuhan-lab-studying-bat-coronaviruses/) Josh Rogin, *Washington Post* (April 14, 2020)
- [Wuhan coronavirus hunter Shi Zhengli speaks out](https://science.sciencemag.org/content/369/6503/487) Jon Cohen, *Science* (July 31, 2020) [full text of interview [here](https://scim.ag/ShiZhengli)]

**Articles supporting the zoonotic origin theory**

- [The Origins of SARS-CoV-2: A Critical Review](https://zenodo.org/record/5075888#.YOhT8-hKgdU) *Zenodo* (Holmes … Andersen, Garry … et al. 2021)
- [The origin of SARS-CoV-2, revisited](https://sciencebasedmedicine.org/about-science-based-medicine/) David Gorski, *Science-Based Medicine* (May 31, 2021)
- [No, Science Clearly Shows that COVID-19 Wasn’t Leaked from A Wuhan Lab](https://www.forbes.com/sites/startswithabang/2021/05/20/no-science-clearly-shows-that-covid-19-wasnt-leaked-from-a-wuhan-lab/?sh=6adb19b95585) Ethan Siegel, *Forbes* (May 20, 2021)
- [The Lab Leak Theory Doesn’t Hold Up](https://foreignpolicy.com/2021/06/15/lab-leak-theory-doesnt-hold-up-covid-china/) Justin Ling, *Foreign Policy* (June 15, 2021)
- [Isolation and characterization of a bat SARS-like coronavirus that uses the ACE2 receptor](https://www.nature.com/articles/nature12711) *Nature* (Ge … Daszak, Shi 2013)
- [Virus Researchers Cast Doubt on Theory of Coronavirus Lab Accident](https://www.npr.org/sections/goatsandsoda/2020/04/23/841729646/virus-researchers-cast-doubt-on-theory-of-coronavirus-lab-accident) Geoff Brumfiel & Emily Kwong, NPR (April 23, 2020)
- [Lab leak Covid-19 theory is like something out of a comic book, virologist says](https://www.cnn.com/2021/03/31/health/lab-leak-coronavirus-theory-comic-book-scn/index.html) Maggie Fox, CNN (March 31, 2021)
- Additional links
  - <https://www.cdc.gov/media/releases/2019/s0506-zoonotic-diseases-shared.html>
  - <https://www.nature.com/articles/nature06536>
  - <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6178078/>
  - <https://web.archive.org/web/20210527162603/https:/twitter.com/K_G_Andersen/status/1391507230848032772?s=20>

**The debate about GoF research**

- [Gain-of-Function Research: Background and Alternatives](https://www.ncbi.nlm.nih.gov/books/NBK285579/) National Academies Press (April 2015)
- [A flu virus risk worth taking](https://www.washingtonpost.com/opinions/a-flu-virus-risk-worth-taking/2011/12/30/gIQAM9sNRP_story.html) Anthony Fauci, Francis Collins, & Gary Nabel, *Washington Post* (December 30, 2011)
- [An Engineered Doomsday](https://www.nytimes.com/2012/01/08/opinion/sunday/an-engineered-doomsday.html) *New York Times* editorial (January 7, 2012)
- [The unacceptable risks of a man-made pandemic](https://thebulletin.org/2012/08/the-unacceptable-risks-of-a-man-made-pandemic/) *Bulletin of the Atomic Scientists* (Klotz & Sylvester 2012)
- [Cambridge Working Group Consensus Statement on the Creation of Potential Pandemic Pathogens (PPPs)](https://www.cambridgeworkinggroup.org/) (July 14, 2014) [31:30]
- Additional links
  - <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC111474/>
  - <https://www.nytimes.com/2014/06/30/opinion/anthrax-thats-not-the-real-worry.html>
  - <https://journals.plos.org/plosmedicine/article/info%3Adoi%2F10.1371%2Fjournal.pmed.1001646>
  - <https://www.cidrap.umn.edu/news-perspective/2014/06/commentary-case-against-gain-function-experiments-reply-fouchier-kawaoka>
  - <https://www.phe.gov/s3/dualuse/documents/gain-of-function.pdf>
  - <https://osp.od.nih.gov/wp-content/uploads/2013/06/Gain_of_Function_Deliberative_Process_Written_Public_Comments.pdf>
  - <https://www.sciencemag.org/news/2019/02/exclusive-controversial-experiments-make-bird-flu-more-risky-poised-resume>

**GoF research conducted at the WIV**

- [A SARS-like cluster of circulating bat coronaviruses shows potential for human emergence](https://www.nature.com/articles/nm.3985) *Nature Medicine* (Menachery … Shi & Baric 2015)
- [615: Peter Daszak of EcoHealth Alliance](https://www.youtube.com/watch?v=IdYDL_RK--w) Vincent Racaniello, *This Week in Virology* (May 19, 2020)

**Peter Daszak and the EcoHealth Alliance controversy**

- [The Wuhan Lab and the Gain-of-Function Disagreement](https://www.factcheck.org/2021/05/the-wuhan-lab-and-the-gain-of-function-disagreement/) Lori Robertson, *FactCheck* (May 21, 2021)
- [British doctor Peter Daszak who tried to gag Wuhan lab leak theory is FIRED from UN commission investigating COVID after he was exposed for organizing letter denying leak claim in *The Lancet* medical journal](https://www.dailymail.co.uk/news/article-9710875/Peter-Daszak-removed-COVID-commission-following-bombshell-conflict-report.html) Harriet Alexander, *Daily Mail* (June 21, 2021)
- [“Pure Baloney”: Zoologist Debunks Trump’s COVID-19 Origin Theory, Explains Animal-Human Transmission](https://www.democracynow.org/2020/4/16/peter_daszak_coronavirus) *Democracy Now!* (April 16, 2020)
- [Ignore the conspiracy theories: scientists know Covid-19 wasn’t created in a lab](https://www.theguardian.com/commentisfree/2020/jun/09/conspiracies-covid-19-lab-false-pandemic) Peter Daszak, *The Guardian* (June 9, 2020)
- [NIH imposes ‘outrageous’ conditions on resuming coronavirus grant targeted by Trump](https://www.sciencemag.org/news/2020/08/nih-imposes-outrageous-conditions-resuming-coronavirus-grant-targeted-trump) Meredith Wadman, *Science* (Aug. 19, 2020)
- Additional links
  - <https://twitter.com/PeterDaszak?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor>
  - <https://www.foxnews.com/media/google-ties-to-wuhan-lab-coronavirus-daszak>
  - <https://www.ioes.ucla.edu/news/peter-daszak-on-60-minutes-coronavirus-research-upended-by-politics/>
  - <https://www.sciencemag.org/sites/default/files/NL%20letter%20final.pdf>

 **US government funding of GoF research**

- [Ban on gain-of-function studies ends](https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(18)30006-9/fulltext) *Lancet Infectious Diseases* (Burki 2018)
- [Statement on misinformation about NIH support of specific “gain-of-function” research](https://www.nih.gov/about-nih/who-we-are/nih-director/statements/statement-misinformation-about-nih-support-specific-gain-function-research) Francis Collins (May 19, 2021)
- [Framework for Guiding Funding Decisions about Proposed Research Involving Enhanced Potential Pandemic Pathogens](https://www.phe.gov/s3/dualuse/documents/p3co.pdf) (P3CO Framework) US DHHS (2017) [32:15]
- <https://twitter.com/Ayjchan/status/1370880584936001541?s=20>

**Discussion of improper influence of the Chinese government on the journal** ***Nature*****:**

- [China owns *Nature* magazine’s ass: Debunking “The proximal origin of SARS-CoV-2” claiming COVID-19 definitely wasn’t from a lab](https://harvardtothebighouse.com/2020/03/19/china-owns-nature-magazines-ass-debunking-the-proximal-origin-of-sars-cov-2-claiming-covid-19-wasnt-from-a-lab/) *Harvard to the Big House* (March 19, 2020)
- [An Unacceptable Breach of Trust](https://www.insidehighered.com/news/2018/10/03/book-publishers-part-ways-springer-nature-over-concerns-about-censorship-china) Elizabeth Redden, *Inside Higher Ed* (October 3, 2018)
- [Publisher Complies with Chinese Censorship](https://www.insidehighered.com/quicktakes/2017/11/02/publisher-complies-chinese-censorship) Elizabeth Redden, *Inside Higher Ed* (November 2, 2017)
- <https://retractionwatch.com/2020/07/23/author-retracts-nature-commentary-over-concerns-about-sections-sponsorship/>

**Evidence suggesting that SARS2 was manipulated in a lab**

- [SARS-CoV-2 is well adapted for humans. What does this mean for re-emergence?](https://www.biorxiv.org/content/10.1101/2020.05.01.073262v1) *bioRxiv* (Zhan, Deverman & Chan 2020) [1:00:00]
- [Cryo-EM structure of the 2019-nCoV spike in the prefusion conformation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7164637/) *Science* (Wrapp et al. 2020)
- [Furin: A Potential Therapeutic Target for COVID-19](https://www.sciencedirect.com/science/article/pii/S2589004220308348) iScience (Wu et al. 2020)
- [An Introduction to a Bayesian Analysis of the Laboratory Origin of SARS-CoV-2](https://zenodo.org/record/4477212#.YOiR6OhKgdV) *Zenodo* (Quay 2021)
- [Questions concerning the proximal origin of SARS-CoV-2](https://onlinelibrary.wiley.com/doi/10.1002/jmv.26478) *Journal of Medical Virology* (Seyran et al. 2020)

**Papers finding that other SARS-like viruses have a furin cleavage site**

- [Functional analysis of potential cleavage sites in the MERS-coronavirus spike protein](https://www.nature.com/articles/s41598-018-34859-w) *Scientific Reports* (Kleine-Weber et al. 2018) [54:15]
- [Furin cleavage sites naturally occur in coronaviruses](https://pubmed.ncbi.nlm.nih.gov/33340798/) *Stem Cell Research* (Wu & Zhao 2020)

 **Articles examining the evidence for the lab leak theory**

- [The Lab-Leak Theory: Inside the Fight to Uncover COVID-19’s Origins](https://www.vanityfair.com/news/2021/06/the-lab-leak-theory-inside-the-fight-to-uncover-covid-19s-origins) Katherine Eban, *Vanity Fair* (June 3, 2021) [1:15, 1:16:30]
- [Origin of Covid — Following the Clues](https://nicholaswade.medium.com/origin-of-covid-following-the-clues-6f03564c038) Nicholas Wade, *Medium* (May 2, 2021) [52:45, 53:15, 54:00, 55:45]
- [Origins of SARS-CoV-2](https://jamiemetzl.com/origins-of-sars-cov-2/) Jamie Metzl, jamiemetzl.com (April 2020 and continually updated) *[this blog post provides numerous links with further information]*
- [The Lab-Leak Hypothesis](https://nymag.com/intelligencer/article/coronavirus-lab-escape-theory.html) Nicholson Baker, *New York Magazine* (January 4, 2021)

**Calls for a full investigation of a possible lab leak**

- [Statement by President Joe Biden on the Investigation into the Origins of COVID-19](https://www.whitehouse.gov/briefing-room/statements-releases/2021/05/26/statement-by-president-joe-biden-on-the-investigation-into-the-origins-of-covid-19/) (May 26, 2021) [1:19:00, 1:21:15]
- [Investigate the origins of COVID-19](https://science.sciencemag.org/content/372/6543/694.1) *Science* (Bloom, Chan, Baric et al. 2021)
- Expert open letters organized by Jamie Metzl
  - [Call for a Full and Unrestricted International Forensic Investigation into the Origins of COVID-19](https://int.nyt.com/data/documenttools/covid-origins-letter/5c9743168205f926/full.pdf) (March 4, 2021)
  - [Call for a Full Investigation into the Origins of COVID-19](https://int.nyt.com/data/documenttools/virus-inquiries-pandemic-origins/d7a097a4c758a65a/full.pdf) (April 7, 2021)
  - [Open Letter to the World Health Organization and the Members of its Executive Board](https://jamiemetzl.com/wp-content/uploads/2021/04/Open-Letter-to-the-World-Health-Organization-and-the-Members-of-its-Executive-Board-1.pdf) (April 30, 2021)
  - [Call for a Comprehensive Investigation of the Origin of SARS-CoV-2, if Possible with Chinese Government Participation](https://jamiemetzl.com/wp-content/uploads/2021/06/Letter-4-Draft-1.pdf) (June 28, 2021)
- [Might SARS-CoV-2 Have Arisen via Serial Passage through an Animal Host or Cell Culture?](https://onlinelibrary.wiley.com/doi/full/10.1002/bies.202000091) *BioEssays* (Sirotkin & Sirotkin 2020) [with [this addendum](https://onlinelibrary.wiley.com/doi/10.1002/bies.202100017)]
- [The science around the lab leak theory hasn’t changed. But here’s why some scientists have](https://www.nbcnews.com/science/science-news/lab-leak-theory-science-scientists-rcna1191) Denise Chow, *NBC News* (June 16, 2021)
- [Letter Seeking International Inquiry into Origins of the Coronavirus](https://www.nytimes.com/interactive/2021/03/04/us/covid-origins-letter.html) Paris Group (March 4, 2021)

# KEY ORGANIZATIONS

- [Cambridge Working Group](https://www.cambridgeworkinggroup.org/about): a group of scientists who oppose gain-of-function research and wrote a public statement concluding that the risks outweigh the benefits [31:30]
- [DRASTIC](https://en.wikipedia.org/wiki/DRASTIC) (Decentralized Radical Autonomous Search Team Investigating COVID-19): group of independent researchers investigating the lab leak theory, some of whom are anonymous [1:16:45]
- [EcoHealth Alliance](https://en.wikipedia.org/wiki/EcoHealth_Alliance) (fka The Wildlife Trust): a New York City–based NGO focused on global environmental health and “dedicated to protecting wildlife and public health from the emergence of disease” that distributed US government funds for gain-of-function research [34:15, 36:30, 37:15, 38:45, 42:00, 42:45, 43:00, 1:16:30, 1:18:45, 1:32:15]
- **The Paris Group**: a group of 30+ scientists and policy experts who evaluate emerging evidence and have called for an international investigation of the pandemic’s origins

# KEY PEOPLE

- [Kristian Andersen](https://www.scripps.edu/faculty/andersen/): a virologist at Scripps Research in California who is critical of the lab leak theory and authored the March 2020 letter in *Nature Medicine*
- [David Baltimore](https://en.wikipedia.org/wiki/David_Baltimore): Nobel laureate from Caltech who initially called the furin cleavage site the “smoking gun” of the lab leak theory but later said he had overstated the case [53:00]
- [Ralph Baric](https://en.wikipedia.org/wiki/Ralph_S._Baric): virologist at the University of North Carolina who does GoF research on coronaviruses and has collaborated with Dr. Shi
- [Jesse Bloom](https://www.fredhutch.org/en/faculty-lab-directory/bloom-jesse.html):  Scientist at the Fred Hutchinson Cancer Center (Seattle) who revealed that genetic sequences from early SARS2 cases in China had been deleted from a shared Chinese-NIH database [1:21:30]
- [Alina Chan](https://giving.broadinstitute.org/broadignite/team/alina-chan): a scientist at the Broad Institute of MIT and Harvard whose work suggested SARS2 began highly adapted to humans [1:00:00, 1:01:00, 1:14:15]
- [Charles Chiu](https://profiles.ucsf.edu/charles.chiu): UCSF virologist who does not believe it would be feasible to create SARS2 from RaTG13 in a lab
- [Francis Collins](https://en.wikipedia.org/wiki/Francis_Collins): head of the NIH who supports GoF research [32:45, 33:15]
- [Peter Daszak](https://en.wikipedia.org/wiki/Peter_Daszak): head of EcoHealth Alliance and organizer of the *Lancet* statement condemning the lab leak theory [36:45, 42:00, 42:45, 1:18:30, 1:24:30]
- [Gilles Demaneuf](https://www.linkedin.com/in/gillesdemaneuf/): DRASTIC member and data scientist with the Bank of New Zealand
- [Rodolphe de Maistre](https://twitter.com/rdemaistre?lang=en): DRASTIC member and lab project director who had worked in China
- [Richard Ebright](https://en.wikipedia.org/wiki/Richard_H._Ebright): a molecular biologist at Rutgers University and member of the Paris Group who believes the epidemic was the result of a lab leak
- [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci): director of the U.S. National Institute of Allergy and Infectious Diseases (NIAID) who is an advocate of GoF research [33:00, 33:30, 34:00]
- [Ron Fouchier](https://www.erasmusmc.nl/en/research/researchers/fouchier-ron): Dutch virologist who did GoF research and claimed that he had created a form of the avian virus H5N1 that was transmissible among ferrets via aerosol [31:15]
- [Thomas Frieden](https://en.wikipedia.org/wiki/Tom_Frieden): former CDC director who advocated for a reduction in the number of labs working with dangerous microbes
- [Robert Garry](https://medicine.tulane.edu/departments/microbiology-immunology-tulane-cancer-center-tips-advisory-committee-tips-mentor/faculty): virologist at Tulane University who thinks the virus evolved naturally and criticizes the lab leak theory
- [Scott Gottlieb](https://en.wikipedia.org/wiki/Scott_Gottlieb): former FDA Commissioner who acknowledged that laboratory leaks happen frequently
- [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis): Stanford professor who studies evidence-based medicine [1:08:30]
- [Filippa Lentzos](https://en.wikipedia.org/wiki/Filippa_Lentzos): a Norwegian biosecurity expert at King’s College London and member of the Paris Group
- [Marc Lipsitch](https://en.wikipedia.org/wiki/Marc_Lipsitch): epidemiologist at the Harvard Chan School of Public Health who is a vocal critic of gain-of-function research
- [Jamie Metzl](https://en.wikipedia.org/wiki/Jamie_Metzl): senior fellow at the Atlantic Council who started a [blog](https://jamiemetzl.com/origins-of-sars-cov-2/) that became a major resource on the lab-leak hypothesis and organized expert open letters on the pandemic origins
- [Scott Morrison](https://en.wikipedia.org/wiki/Scott_Morrison): the Prime Minister of Australia, who pushed to have a lab leak investigation as part of the WHO investigation of the pandemic [1:28:45]
- [Gary Nabel](https://en.wikipedia.org/wiki/Gary_Nabel): former Director of Vaccine Research at NIAID who is an advocate for GoF research

- [Robert Redfield](https://en.wikipedia.org/wiki/Robert_R._Redfield): former head of the CDC who believes the pandemic was the result of a lab leak [48:30, 1:07:30]

- [Shi Zhengli](https://en.wikipedia.org/wiki/Shi_Zhengli) (“Bat Woman”): head coronavirus researcher at the Wuhan Institute of Virology (WIV) [24:45, 40:00, 1:26:00]
- [Nicholas Wade](https://en.wikipedia.org/wiki/Nicholas_Wade): a science journalist (formerly for the *New York Times*) who conducted a detailed evaluation of the evidence for the lab leak theory [52:45, 53:15, 54:00, 55:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/07/1x1-eban2-500x500.png)

##### Katherine Eban

Katherine Eban, an investigative journalist, is a *Fortun*e magazine contributor and Andrew Carnegie fellow. Her articles on pharmaceutical counterfeiting, gun trafficking, and coercive interrogations by the CIA have won international attention and numerous awards. She has also written for *Vanity Fair*, the *New York Times*, *Self*, *The Nation*, the *New York Observer* and other publications. Her work has been featured on *60 Minutes*, *Nightline*, NPR, and other national news programs. Her first book, *Dangerous Doses: a True Story of Cops, Counterfeiters and the Contamination of America’s Drug Supply*, was named one of the Best Books of 2005 by Kirkus Reviews and was a Barnes & Noble Discover Great New Writers pick. Her second book, *Bottle of Lies: The Inside Story of the Generic Drug Boom* was named one of the New York Times 100 Notable Books of 2019, the New York Public Library Best Books of 2019, the Kirkus Reviews Best Health and Science Books of 2019, and Science Friday Best Books of 2019. Katherine’s work has been awarded grants from the Alfred P. Sloan Foundation, the Fund for Investigative Journalism, the Alicia Patterson Foundation and the McGraw Center for Business Journalism at CUNY’s Craig Newmark Graduate School of Journalism. Educated at Brown University and Oxford, where she was a Rhodes Scholar, she lives in Brooklyn with her husband and two daughters. [katherineeban.com]