# #47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more

**Source:** [https://peterattiamd.com/matthewwalker1/](https://peterattiamd.com/matthewwalker1/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In part 1 of this 3 part series, Matthew Walker, professor of neuroscience at UC Berkeley and expert on sleep, describes the different stages, and cycles, of sleep, including what he calls the 4 pillars of sleep, and how they contribute to memory consolidation and numerous important pathways to mental health. We also get into the dangers of chronic sleep deprivation, such as the development of dementia, and the more acute dangers of sleep deprivation like fatal car crashes which are most often caused by drowsy driving. We also discuss the different and important roles of REM vs. non-REM sleep, and the impact that bad sleep habits can have specifically on those sleep stages.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/matthewwalker1/the_Drive_public.png)

Play

#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer's risk, mental health, memory consolidation, and more.

#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer's risk, mental health, memory consolidation, and more.

1x15s30s

0:001:43:11

## We discuss:

- Matthew’s background and interest in sleep [5:00];
- Sleep and Alzheimer’s disease, and the 4 pillars of sleep [11:15];
- Stages of sleep, sleep cycles, and brainwaves [40:15];
- Memory and sleep, and the risk of insufficient REM sleep [54:45];
- Evolutionary reasons to sleep [1:01:00];
- The early riser vs. the night owl, and tips for overcoming jet lag [1:09:15];
- Is there one type or stage of sleep that is most important? [1:16:30];
- The dangers of drowsy driving [1:25:45];
- The timeliness of Matthew’s book, and how the conversation of sleep has changed over the past several years [1:34:15]; and
- More.

## Show Notes

## Matthew’s background and interest in sleep [5:00]

- Started med school in UK at age 18 but professor told him *he was a scientist, not doctor* (focused on questions, not answers)
- Instead, he got undergrad in neuroscience at University of Nottingham
- Then got Ph.D. at Newcastle University and his research was funded by the Medical Research Council in London
- Went to Harvard for faculty position in psychiatry, there for 7 years – did not like winter or combative/competitive environment at Harvard
- Came to Berkeley, has been there since

*How did he develop his passion for sleep science?*

- Always interested in states of consciousness, anesthesia, hypnotism, brain switching between mental states
- Sleep is a key example: *state that happens to almost every living creature every 24 hours*
- Sleep accounts for ~1/3 of our lives – we understand eating, drinking, and mating, but not sleep
- “We sleep to cure sleepiness” is not an answer, we can’t seem to unravel the mystery
- Brilliant minds haven’t yet cracked it, so Matthew thought the topic would sustain a whole career

> “So it was, for me, this perfect collision of a fascination in an innate biological problem, and universal behavior conserved across evolution, together with the fact that we did it for a third of our lives. Plus the fact that science had not been able to crack this nut, it was one of the last great remaining scientific mysteries.”

## Sleep and Alzheimer’s disease, and the 4 pillars of sleep [11:15]

- Walker was studying the brainwave patterns in people with dementia but not getting anywhere
- Noticed that different pathologies hit sleep centers, others spared until late in process
- Needed to measure patients while sleeping, not aware: then results took off

*Could sleep disruption be a biomarker of dementia, or even an underlying cause?*

“Based on the weight of the data that we have, the evidence, I think it is causal. I think that sleep, at this stage, may be one of the most significant lifestyle factors that determines your risk ratio for Alzheimer’s disease. I feel the causal evidence for that now in humans and animals is strong enough to make that statement. And I don’t make that statement lightly.”

*Could poor sleep lead to neuronal energy deprivation (like vascular disease and insulin resistance)?*

- Sleep impacts oxidative stress
- From [Matthew’s book](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=): “Wakefulness is low level brain damage” and “sleep is the price we pay for wakefulness”
  - It’s a tenable hypothesis that evolutionarily, sleep may have been the default state ⇒ *“Perhaps the default state of life on the planet was sleep, and it was from sleep that wakefulness emerged.”*

**Alzheimer’s disease**

- The first thing is that we see that within insufficient sleep, you get increases in oxidative stress and that leads to a whole cascade of things that lead to neuronal death
- Hippocampus (memory) 1st damaged in Alzheimer’s (forgetfulness)

⇒ **Remarkable discovery**: In 2012, Rochester University team found that [brain has “sewage” system](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3551275/) (glymphatic system, glial cells) similar to lymphatic system

- Sanitation system that kicks in when in deep sleep and glial cells shrink up to 200% in size make room for cerebral spinal fluid fill brain and wash out “metabolic detritus” of wakefulness

![](https://peterattiamd.com/wp-content/uploads/2019/03/glymphatic-pathway-1024x892.png)

**Figure 1****. Schematic depiction of the glymphatic pathway. In this brain-wide pathway, CSF enters the brain along para-arterial routes, whereas ISF is cleared from the brain along paravenous routes. Convective bulk ISF flow between these influx and clearance routes is facilitated by AQP4-dependent astroglial water flux and drives the clearance of interstitial solutes and fluid from the brain parenchyma. From here, solutes and fluid may be dispersed into the subarachnoid CSF, enter the bloodstream across the postcapillary vasculature, or follow the walls of the draining veins to reach the cervical lymphatics.** Image credit: ([Iliff et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3551275/))

*How is this related to AD?*

- β-amyloid is one of things washed away, a core protein in Alzheimer’s formation which escalates Alzheimer’s risk
- PET scan to map β-amyloid in brain: obvious difference. If 7 hrs of sleep or less, there is marked difference in amount of β-amyloid built up compared to 7 hrs or more. Just an association, but when animals (rats) deprived of sleep or sleep is fragmented, get immediate β-amyloid buildup

⇒ [This study in humans](https://www.ncbi.nlm.nih.gov/pubmed/24887018) was the “turning point” for Matthew

- Take deep sleep away from a human for one single night and you can see significant **increase in circulating levels of amyloid and tau** the next day
- They still get 8 hours total, but you selectively take away their non REM deep sleep by playing auditory tones
- Their “sewage system” never kicks into gear to clear those proteins out

*What about variation among people: can you miss things you’d see in homogeneous populations?*

- For example, the term Alzheimer’s disease was likely based on a [patient with genetic mutation](https://en.wikipedia.org/wiki/Alzheimer%27s_disease#History) ([PSEN1 or PSEN2 mutation](https://en.wikipedia.org/wiki/PSEN1#Alzheimer's_disease)) and early onset (<1% of total Alzheimer’s pop, present in 50s and die by 60, so it’s like a different disease)
- 99% of cases of AD are late-onset AD
- APOE genotype ⇒ could these people have different susceptibilities to sleep deprivation?

The role of β-amyloid in AD

- May not main causal driver, more a result of AD
- But if sleep is more about clearance than generation, it is congruent with idea that other things on back end are driving it primarily
- Alzheimer’s so complicated because genetic predisposition + multiple pathways driving injury to very sensitive organ

Subtypes of Alzheimer’s

- Likely in the future we will have at least 5 subtypes of AD
- Uncomfortable pinning one path ingredient as causal trigger

Tau and AD

- Data better for tau predicting cognitive decline
- Tau accumulation can also result from sleep insufficiency
- Fact that find sleep to be a strong predictor for this risk means links between insufficient sleep and this heterogeneous disease are quite strong

The future of subtypes and AD:

- When we eventually subtype Alzheimer’s, we will likely find that subsets of sleep features are linked to subsets of Alzheimer’s
- e.g., deep sleep deprivation predictive of one subtype, sleep fragmentation predictive of another

**The 4 Pillars of Sleep [26:00]**

1. Regularity (consistency of schedule)
2. Continuity (waking up many times per night?)
3. Quantity (in total, and in each stage)
4. Quality (how good the “electrical signature” of sleep is; caffeine, alcohol, etc. can have an effect on quality)

*⇒ Alzheimer’s is very complex*: Different sleep features will be predictive of different aspects of the amyloid pathology cascade, for example

**Matthew’s upcoming paper (not yet published):**

- If bucket people into ten-year periods based on quantity and quality of sleep
- Then map β-amyloid loid and tau in brain late in life
- The question: *Was sleep at certain decades more critical at predicting these levels?*

*How did they measure this?*

- Have subjective questionnaires that have been shown to match well with quality and quantity (good predictive validity relative to objective gold standard measures)
- They ask patients about each decade

*What are hazard ratios?* ⇒ If sleep problems only increase risk by 25%, unlikely to see signal with all this noise with epidemiology… but if hazard ratio was 6 or 7 that is different

*What’s the magnitude here?*

- .45-.6 in risk reduction for those with better quality sleep
- “If you’re getting less sleep at almost any point in the lifespan, the risk that you’re going to have higher amounts of these Alzheimer’s disease proteins in your brain is greater.”

*β vs. tau*

- Sleep deprivation in different decades seem to be linked to increase in β vs. tau
- This shouldn’t be seen with one subjective global bias in questionnaire, so it seemed to transcend some inherent limitations of this approach.
- *B-amyloid*: strong predictive signal 30s and 40s, then again 60s and 70s.
- *Tau*: 50s and 60s through 80s.
- Β-amyloid is bimodal, seems that general memory bias would not explain this

*Peter is skeptical of the β-amyloid theory of AD because:*

- 1) Abject failure of pharmacological approach to β-amyloid reduction ⇒ [**The failure rate of amyloid antibody as a treatment for AD 99.6%**](https://www.ncbi.nlm.nih.gov/pubmed/25024750/)
- 2) [Autopsy studies](https://www.ncbi.nlm.nih.gov/pubmed/10072051) of people who died without clinical symptoms but still have β-amyloid suggest β-amyloid necessary but not sufficient

⇒ Furthermore…

- Poor sleep does so many things that are bad for your health that could feed into that (e.g., poor sleep affects CVD, which affects brain; glucose disposal also affects brain)
- Sleep deprivation therefore has many confounders so it would be hard to tease out mechanistic links

*Necessary but not sufficient?*

- There are cases of a non-trivial amts of β-amyloid found in the brain post-mortem of people with only in the early stages of MCI (mild cognitive impairment)
- This could mean that β-amyloid is irrelevant or that it is **necessary but not sufficient for AD**
- So Matthew argues that if it is necessary but not sufficient, why wouldn’t want to decrease odds by lowering β-amyloid? ⇒ “If you truly don’t want necessary in your life, and if you’re getting insufficient sleep, you’re placing a necessary there, where it doesn’t necessarily have to be.”

*How much sleep does Matthew get per night?*

- “I give myself a ‘non-negotiable’ 8 hours.”
- “If you understood what I knew about sleep, and all cause mortality, as well as most disease processes, you would realize that I’m being nothing short of utterly selfish in my preservation of an eight-hour sleep opportunity. I don’t want to die young, and I don’t want sickness and disease in my life.”
- His family has a history of CVD ⇒ “we know that deep sleep is probably the best form of blood pressure medication that you could ever wish for.”

*Focusing on prevention of AD*

- Since there are no robust pharmaceutical treatments for Alzheimer’s yet, the focus is shifting towards early stage prevention
- One of best preventative actions is to “capitalize on” sleep at night

> “I think I feel very comfortable saying that one of the best preventative actions that you can take on the basis of the science right now, is start to capitalize on your sleep at night.”

## Stages of sleep, sleep cycles, and brainwaves [40:15]

Humans (Mammals) have 2 stages:

1. Non-REM
2. REM

**Non-REM** has 4 stages: Cleverly titled=*Stages 1, 2, 3, and 4*

- Stages 3 and 4 are the very deep restorative stages
- Stages 1 and 2 are the lightest stages of sleep

**REM sleep**: (REM=Rapid eye movement, based on the bizarre horizontal shifting eye movements)

90 minute sleep cycles

- Every 90 minutes, your brain cycles between non-REM and REM sleep
- Then this is replayed every 90 minutes to create what we call a standard cycling architecture of sleep, or what we call a [hypnogram of sleep](https://en.wikipedia.org/wiki/Hypnogram)

![](https://peterattiamd.com/wp-content/uploads/2019/03/brainwaves-of-wake-and-sleep-848x1024.png)

**Figure 2. The brainwaves of wake and sleep.** Image credit: [Why We Sleep by Matthew Walker](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

Brainwaves when first lie down (before you fall asleep):

- [Alpha rhythm](https://en.wikipedia.org/wiki/Alpha_wave)
- Frenetic high-frequency electrical activity with small amplitude
- Analogy: If held microphone over sports stadium, before game, everyone talking to each other but not in any kind of coordination.  Get very nonsynchronous signal but voices (neurons) cancel each other out, but frequency high as goes up and down.
- Back of brain (visual brain), stops processing the outside world, frequency slows from 50 cycles/sec slowed to 10 cycles/sec (still relatively low amplitude)

Transitioning to sleep

- Eyeballs start to roll (slow rolling eye movements) first sign of transition to sleep (reason is unknown)
- First you go into the light stages of non-REM
- After 20 minutes you are into the deep stages 3 and 4

Stages of non-REM:

- In stage 1: [Theta waves](https://en.wikipedia.org/wiki/Theta_wave) begin
- Stage 2:
  - 50 cycles/sec down to 6-7 cycles/sec, amplitude getting bigger
  - Synchronous bursts of electrical activity called [sleep spindles](https://en.wikipedia.org/wiki/Sleep_spindle) (a second and half long) ⇒ Big slow wave, then burst of spindle
- Then stages 3 and 4:
  - Brain in synchronous chant of slow waves
  - 1 or 2 cycles per second, but size of waves are huge
  - In stadium analogy ⇒ during the game spectators are chanting in unison, louder and making same sounds together and can hear sound. Hundreds of thousands of cells now fire together and go silent together.
  - Looks in some ways like coma, but brain is not doing nothing
  - During this deep sleep, get info transfer in brain
  - Lose range like short wave radio, but slower waves increase distance over which you can get signal ⇒ So the brain is like a “long-distance information transfer”
  - [Delta waves](https://en.wikipedia.org/wiki/Delta_wave)

How to tell the difference between stage 3 & 4?

- Proportion of 30-second sleep consumed by deep slow wave
  - if less than 50%, stage 3
  - if more than 50%, stage 4
- Waves longer amplitude and slower in frequency in stage 4

Stages **must occur in order** with 2 exceptions:

- 1) Narcolepsy – from awake straight into REM
- 2) If chronically REM sleep derived, occasionally into REM sleep directly (e.g., heavy alcohol use)

Summary of the 90 minute cycle:

- Go through stage 1-4 on non-REM
- Then after 70 min, you go back to stage 2 on non-REM
- Then you will briefly transition to REM sleep
- Then you flip flop between non-REM and REM ⇒ back down into non-REM, back to REM, back to non-REM, back to REM

What changes is **the ratio of non-REM to REM within that 90 minute period, as you move across the night**

- In first half of night, majority of 90 minute cycle is deep non-REM
- In the second half of the night, the majority of cycle is REM
- If get 6 hours sleep (instead of 8), you’re losing 25% of sleep, but **could be losing up to 70% of all REM sleep**

![](https://peterattiamd.com/wp-content/uploads/2019/03/architecture-of-sleep-1024x423.png)

**Figure 3. The architecture of sleep. Image credit: [Why We Sleep by Matthew Walker](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)**

## Memory and sleep, and the risk of insufficient REM sleep [54:45]

> “Different types of memory rely on different stages of sleep at different times of night.”

**Matthew’s papers reviewing learning and memory**:

- [Sleep-dependent memory processing.](https://www.ncbi.nlm.nih.gov/pubmed/18803104)
- [Cognitive consequences of sleep and sleep loss](https://www.sciencedirect.com/science/article/pii/S1389945708700145)
- [The sleep-deprived human brain.](https://www.ncbi.nlm.nih.gov/pubmed/28515433)

Deep non-REM sleep (stage 3 and 4)

- Protects new learning from the day before
- “You need sleep after learning to essentially hit the save button on new memories so that you don’t forget.”

Stage 2 of non-REM

- Refreshes and prepares your brain for future learning and memory
- Sleep spindles exponentially increase towards the end of the night, so you get most of your sleep spindle-rich sleep in the last two hours of the night
- So the stage 2 non-REM sleep happens mostly in the second half of night and prepares your brain to learn
- “The more of those sleep spindles that you have, the greater refreshment of your memory and coding ability.”

*What’s the biggest detriment that persons face clinically with the reduction of REM?*

- Increased mental health issues: Anxiety, depression, suicidality
- Could say an anxious person can’t sleep because of anxiety, or lack of sleep causes anxiety; goes both ways
- “Sleep is emotional first aid.”
- In young teens, [strongest predictor of suicidal ideation, attempts, and completion is insufficient sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3296786/)
- REM sleep seems to [recalibrate emotional networks in brain](https://www.sciencedirect.com/science/article/pii/S0960982207017836) (middle part of [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex) and [amygdala](https://en.wikipedia.org/wiki/Amygdala))

Learning from a sleep deprived child

- When a 4-year-old misses one nap, can see change in behavior
- Parents of young kids seem to know that bad sleep equals bad mood and emotional reactivity the next day (amygdala)
- But shortly afterwards, we abandon the notion that sleep is essential and non-negotiable, and we stigmatize it with idea of laziness and sloth

## Evolutionary reasons to sleep [1:01:00]

- Sleep has become stigmatized as laziness and sloth
- In 70 years, we’ve lost 20-25% sleep
- By comparison, imagine a reduction in O2 saturation by 20-25% (It’s very clear that’s not a good idea.)

Peter’s personal story about his attitude towards sleep

- He resisted lots of sleep until about 2012
- “I’ll sleep when I’m dead”
- During med school, spent about 114 hrs per week working in the hospital and got about 28 hours of sleep a week
- A few years later, [Kirk Parsley](https://www.docparsley.com/) said to him, “So let me get this straight. You just decided that you’re going to sleep half of what is evolutionarily programmed? … Does it strike you as odd that evolution would have designed us to spend a third of our life, not mating, not watching out for predators, not hunting for food, but doing this thing for some other purpose? Do you think that thing must have been important?”
- Overnight it changed the way Peter thought about sleep, which was that evolution went to great lengths to do this

> “Sleep is the greatest life support system you could ever wish for. It’s a remarkable health insurance policy, it’s largely democratic, free and largely painless.”

**Sleep is the foundation of health**

- In terms of de-risking just about every disease that is killing us in the developed world, it’s very hard to look no further than sleep
- Nutrition and exercise are important, but sleep in the foundation
- “*Sleep is the foundation on which those two other things sit. It’s not the third pillar of good health, I think it is the foundation*.”

*⇒ How long can you survive without sleep?*

- The record someone survived without food might be 382 days (lean person maybe 30 days)
- Deprivation of sleep causes the quickest reduction of health
- [Guinness has banned trying to set record for sleep deprivation](https://www.sciencealert.com/watch-here-s-what-happened-when-a-teenager-stayed-awake-for-11-days-straight) (record might have been up to 24 days) because it’s so dangerous (cancer, mental health, CVD, metabolic syndrome, suicidality).
- Think about this:
  - [Felix Baumgartner](https://en.wikipedia.org/wiki/Felix_Baumgartner) went up in [hot air balloon to outer surface of Earth and then jumped out](https://www.youtube.com/watch?v=E-w2_nTnunc), fell over 1000/km/hr, broke sound barrier
  - That was NOT banned by Guinness, but sleep deprivation was – gives you sense of how dangerous it is not to sleep

## The early riser vs. the night owl, and tips for overcoming jet lag [1:09:15]

What is different about 2 people who both only sleep for 6 hours, but one person from 9 pm – 3 am and the other midnight to 6 am?

- Your brain has different taste sensitivities to non-REM and REM across the 24-hour clock face
- 9 pm – 3 am, you are mostly in deep non-REM
- 3 am – midday, would be mostly REM sleep
- Early to bed and early to rise and sleeping only 6 hours, it means you’re losing mostly REM

Jet lag and changing time zones:

- Example, if flying from California to London…
  - Wake up 10 min earlier for 5 days before, then very early on flight day
  - Sleep on first half of flight (not second as many people do) to line up what the people are doing in London
  - Build up “sleep pressure” so can sleep when night in London (the longer you are awake, the more you will build up sleep pressure)
- In example above, type of sleep you get will not be the same ⇒ if move your window of sleep to earlier in the day (short changing REM sleep) or to later in the night (short changing deep non-REM)

*Peter’s observations of sleep when flip flopping between CA and NY*

- When in NY: Trying to stay on CA time ⇒ Going to bed later, waking up later
- When in CA: very early sleeper and an early riser
- Tries to stick to 8 hours
  - Can do that very well in California
  - Not as well in New York
- First night back in California, he has much higher amount of deep sleep
  - “And that would explain it. It’s this phase shift that I’m capturing.”
  - Just came back from New York last night (so now in CA), went to bed at 8:30 p.m., and got up at 5 am, but had a huge deep sleep

⇒ Matthew’s reaction:

- “Exactly, so you dragged your eight-hour window.”
- “If you think about this sort of eight-hour window, and you slide it back on the clock face from midnight, to 11 p.m., to 10 p.m., to in fact, 9 p.m., you’re dragging that eight-hour sleep phase back, closer into the deep sleep-rich phase, the deep non-REM sleep that you want. . .And perhaps, you may actually see a little bit of a reduction in REM sleep.”
- “As you go to New York, you may see the opposite.”

⇒ Peter says he does generally see that pattern, gets more REM in NY and less deep non-REM

Other cues that affect sleep outside of time of day

- Light
- Caffeine
- Alcohol
- Meal timing

## Is there one type or stage of sleep that is most important? [1:16:30]

- Generally speaking, Matthew says “Mother Nature has found this equilibrium. Don’t mess with it. It’s the da Vinci Code of Sleep, and stick to it. You’re good to go.”
- The overall point is that your body naturally decides how much of each stage of sleep you need as long as you are getting the amount of sleep you need

Evidence that overall sleep deprivation is deadly

- In the 1983, they [deprived rats of sleep until they died](https://www.ncbi.nlm.nih.gov/pubmed/6857280/), and they died 20% sooner than they didn from starvation
- [Fatal familial insomnia](https://en.wikipedia.org/wiki/Fatal_insomnia) in humans:
  - Person dies in 18-24 months
  - Starts out looking like insomnia but gets worse over time
  - Strongly heritable, single gene for [prion protein](https://en.wikipedia.org/wiki/PRNP) ([Mad cow disease](https://en.wikipedia.org/wiki/Bovine_spongiform_encephalopathy) is also a prion protein disease)
  - Some degree of proof that insufficient sleep is fatal in human beings

Selective deprivation: Another round of [studies in rats deprived of either REM or non-REM](https://www.ncbi.nlm.nih.gov/pubmed/2648533)

- Live only 9-10 days with total sleep deprivation
- Same without total deprivation of REM sleep (9-10 days)
- “Yoked paradigm” ⇒ “It’s a very clever technique, where you can mimic the total amount of sleep deprivation in one other animal, but the other animal is still getting the chance to get REM sleep. So REM sleep selectively removed, the rats died basically almost as quickly as they did from total sleep deprivation.”
- Non-REM deprivation took longer to be fatal (about 20 days)

When did the different sleep stages evolve?

- “What I find either strange or exciting about that is, if you look from an evolutionary standpoint, those two types of sleep did not emerge at the same time.”
- True **REM is seen only in birds and mammals**
- No true REM sleep in reptiles, fish, insects, amphibians
- Two different evolutionary paths:
  - Non-REM sleep appears in almost all species
  - And REM sleep developed twice, independently, once in birds and once in mammals

Why do we die soon from REM deprivation?

- Birds and mammals evolved neuronally and therefore probably requires something essential in REM and when you deprive REM you affect the “superpower” (the cortex)
- Anything that has a complex nervous system, maybe that’s where the pressure for this thing called REM sleep emerged, says Matthew

**Importance of REM sleep** ⇒ We need to worry about both deep and REM sleep, but REM is arguably even more important (and alcohol affects REM sleep)

## The dangers of drowsy driving [1:25:45]

Sleep has been stigmatized as laziness

- [Margaret Thatcher](https://en.wikipedia.org/wiki/Margaret_Thatcher) and [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) famously proclaimed the uselessness of sleep
- Sleep is for the weak, sleep when you’re dead, etc.
- Would proudly say they only hot 4-5 hours of sleep a night
- “I don’t think it’s coincidental now looking back, that both of them went onto to develop Alzheimer’s disease.”

The first big reason why lack of sleep is frightening? ⇒ Chronic diseases (like Alzheimer’s)

The second big reason? ⇒ deadly car crashes

- “People with responsibility or authority should not glorify lack of sleep.”
- “In the hour that we’ve been talking already, numerous people have lost their life in a [drowsy-driving related accident](https://aaafoundation.org/prevalence-motor-vehicle-crashes-involving-drowsy-drivers-united-states-2009-2013/), based on the statistics.”

![](https://peterattiamd.com/wp-content/uploads/2019/03/sleep-loss-and-car-crashes-1024x685.png)

**Figure 4. Sleep loss and car crashes.** Source: [Why We Sleep: Unlocking the Power of Sleep and Dreams by Matthew Walker](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=sr_1_1?hvadid=255813179746&hvdev=c&hvlocphy=9027582&hvnetw=g&hvpos=1t1&hvqmt=e&hvrand=5660065833854923466&hvtargid=aud-646675774026%3Akwd-421937652607&keywords=sleep+matthew+walker&qid=1553631086&s=gateway&sr=8-1)

**Microsleeps**

- Total sleep deprivation obviously could causes someone to fall asleep at the wheel
- The much less obvious one, but the **much more common one is what we call** [**microsleeps**](https://en.wikipedia.org/wiki/Microsleep)
- Microsleep are small lapses where the eyelid will partially close
- They’ve done [systematic studies looking at microsleeps](https://www.ncbi.nlm.nih.gov/pubmed/12603781) at all different levels of sleep deprivation

> “Drowsy driving accounts for more accidents on our roads than either drugs or alcohol **combined**.”

- What is found is that once the eyelid partially closes, you no longer react
- By comparison, when drunk drivers swerve there is generally a reaction, some breaking
- The microsleeping person is a projectile missile
- Drowsy driving is more fatal

## The timeliness of Matthew’s book, and how the conversation of sleep has changed over the past several years [1:34:15]

[![](https://peterattiamd.com/wp-content/uploads/2019/03/book-cover-678x1024.jpg)](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316)

**Figure 5. Why We Sleep book cover.** Image credit: [amazon.com](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316)

When Walker’s book came out, Peter wondered if the world needed another sleep book

But 3 things are different about Matthew’s book

- Matthew’s understanding of sleep is exceptional
- Matthew’s credibility is exceptional
- We are at a point in time where people are ready to hear this

Why are we more ready to hear this now?

- Is it our increasing interest in optimizing performance? Can sleep be a tool for this?
- Peter believes we will look back in ~20 years at the way we discount the importance of sleep and be astonished in the same way we are astonished that doctors used to recommend different brands of cigarettes as early back as the 1960s

Matthew says we have reached the perfect storm:

- “The erosion of sleep time has hit an all-time high. We are now sleeping less than we have ever done in what seems to be the history of our species.”
- In 1942, the average person slept 7.9 hours per night
- Today, the average person sleeps 6 hours and 31 minutes
- The decline has not been linear, it is accelerating
- Perfect storm=Collision between increasing sleep deprivation and increasing sickness and disease that we’ve almost never seen before

> “There is no physiological system in the body, and there is no operation of the brain that isn’t wonderfully enhanced by sleep when you get it, or demonstrably impaired when you don’t get enough.”

§

## Selected Links / Related Material

**Matthew recently published NY Times best selling book**: [Why We Sleep: Unlocking the Power of Sleep and Dreams by Matthew Walker](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=sr_1_1?hvadid=255813179746&hvdev=c&hvlocphy=9027582&hvnetw=g&hvpos=1t1&hvqmt=e&hvrand=5660065833854923466&hvtargid=aud-646675774026%3Akwd-421937652607&keywords=sleep+matthew+walker&qid=1553631086&s=gateway&sr=8-1) (amazon.com) [14:30, 1:34:15]

**Strongest evidence of sleep and Alzheimer’s disease risk is a remarkable discovery that the brain actually has a sewage system coined the “glymphatic system”**: [A Paravascular Pathway Facilitates CSF Flow Through the Brain Parenchyma and the Clearance of Interstitial Solutes, Including Amyloid β](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3551275/) (Iliff et al., 2012) [16:15]

**Difference in amyloid build up in people getting seven hours of sleep or less, compared to seven of hours of sleep or more**:  [Self-reported sleep and β-amyloid deposition in community-dwelling older adults](https://www.ncbi.nlm.nih.gov/pubmed/24145859) (Spira et al., 2013) [19:00]

**Sleep deprived animals and humans of either deep non-REM sleep, or fragmented sleep, leads to immediate amyloid build up, centrally within the brain**: [19:45]

- **Sleep fragmentation in humans: [Sleep Fragmentation and the Risk of Incident Alzheimer’s Disease and Cognitive Decline in Older Persons](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3669060/) (Lim et al., 2013)**

- In a rodent model of AD, chronic pharmacological or environmental sleep disruption was associated with a more rapid accumulation of amyloid beta pathology: [Amyloid-beta dynamics are regulated by orexin and the sleep-wake cycle](https://www.ncbi.nlm.nih.gov/pubmed/19779148/) (Kang et al., 2009)

**Take deep sleep away from a human for one single night and you can see significant increase in circulating levels of amyloid and tau; “the turning point” for Matthew**: [Effect of 1 night of total sleep deprivation on cerebrospinal fluid β-amyloid 42 in healthy middle-aged men: a randomized clinical trial.](https://www.ncbi.nlm.nih.gov/pubmed/24887018) (Ooms et al., 2014) [20:15, 33:45]

**The failure rate of amyloid antibody as a treatment for AD 99.6%**: [Alzheimer’s disease drug-development pipeline: few candidates, frequent failures](https://www.ncbi.nlm.nih.gov/pubmed/25024750/) (Cummings et al., 2014) [34:30] Tk: [34:30]

**Substantial level of Aβ deposition can be found in the autopsied brain of cases with documented normal cognition**: [34:30]

- Reviewed in: [Amyloid imaging in cognitively normal individuals, at-risk populations and preclinical Alzheimer’s disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3777672/#bb0030) (Chételat et al., 2013)
- [Frequency of stages of Alzheimer-related lesions in different age categories](https://www.ncbi.nlm.nih.gov/pubmed/9330961) (Braak and Braak, 1997)
- [Clinico-pathologic studies in dementia: nondemented subjects with pathologically confirmed Alzheimer’s disease](https://www.ncbi.nlm.nih.gov/pubmed/3185902) (Crystal et al., 1988)
- [Clinical, pathological, and neurochemical changes in dementia: a subgroup with preserved mental status and numerous neocortical plaques](https://www.ncbi.nlm.nih.gov/pubmed/2897823) (Katzman et al., 1988)
- [Tangles and plaques in nondemented aging and “preclinical” Alzheimer’s disease](https://www.ncbi.nlm.nih.gov/pubmed/10072051) (Price and Morris, 1999)

**Matthew’s papers reviewing learning and memory**:

- [Sleep-dependent memory processing.](https://www.ncbi.nlm.nih.gov/pubmed/18803104) (Walker MP, 2008) [55:15]
- [Cognitive consequences of sleep and sleep loss](https://www.sciencedirect.com/science/article/pii/S1389945708700145) (Walker MP, 2008) [55:15]

**Sleep and the emotional regulators of the brain**: [The human emotional brain without sleep — a prefrontal amygdala disconnect](https://www.sciencedirect.com/science/article/pii/S0960982207017836) (Yoo et al., 2007) [57:15]

**Strongest predictor of suicide in young teens in is insufficient sleep**: [Insufficient Sleep and Suicidality in Adolescents](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3296786/) (Lee et al., 2013) [57:30]

**Guinness bans records of sleep deprivation**: Watch: [Here’s What Happened When a Teenager Stayed Awake For 11 Days Straight](https://www.sciencealert.com/watch-here-s-what-happened-when-a-teenager-stayed-awake-for-11-days-straight) |  BBC Crew (sciencealert.com) [1:07:30]

**Felix Baumgartner went up in a capsule in a hot air balloon to the outer surface of our planet and jumped out**: [Felix Baumgartner Red Bull Stratos FULL SPACE JUMP VIDEO](https://www.youtube.com/watch?v=E-w2_nTnunc) | Supteehee (youtube.com) [1:08:15]

**Total sleep deprivation of rats until death in the 1983**: [Physiological correlates of prolonged sleep deprivation in rats.](https://www.ncbi.nlm.nih.gov/pubmed/6857280/) (Rechtschaffen et al., 1983) [1:17:15]

**Selectively deprived rats of non-REM or REM**: [Sleep deprivation in the rat: X. Integration and discussion of the findings.](https://www.ncbi.nlm.nih.gov/pubmed/2648533) (Rechtschaffen et al., 1989) [1:20:15] (tk see more by ctrl F for selective sleep deprivation [in here](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3861693/))

**Drowsy-driving related accidents**: [Prevalence of Motor Vehicle Crashes Involving Drowsy Drivers, United States, 2009-2013](https://aaafoundation.org/prevalence-motor-vehicle-crashes-involving-drowsy-drivers-united-states-2009-2013/) | (aaafoundation.org) [1:30:45]

**Studies that dosed sleep to people from getting nine hours of sleep, to eight hours of sleep, seven, six, five, four, three, for one week, two weeks, three weeks**: [1:31:45]

- Chronic sleep restriction: neurobehavioral effects of 4 hr, 6 hr, and 8 hr TIB. (Dinges et al. 1999)
- [Patterns of performance degradation and restoration during sleep restriction and subsequent recovery: a sleep dose-response study.](https://www.ncbi.nlm.nih.gov/pubmed/12603781) (Belenky et al., 2003)

§

## People Mentioned

- [Francis Crick](https://en.wikipedia.org/wiki/Francis_Crick) (wonderful scientist who discovered the helical structure of DNA but couldn’t crack the code of sleep) [10:45]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) (mutual favorite F1 driver, Peter’s son is named after him) [14:45]
- [Michael Stipe](https://en.wikipedia.org/wiki/Michael_Stipe) (musician) [40:45]
- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (sleep expert) [1:03:45]
- [Felix Baumgartner](https://twitter.com/felixfastestman?lang=en) (jumped out of a hot air balloon from near outer space) [1:08:15]
- [Margaret Thatcher](https://en.wikipedia.org/wiki/Margaret_Thatcher) (bragged about not needing sleep, got Alzheimer’s) [1:26:15]
- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) (bragged about not needing sleep, got Alzheimer’s) [1:26:15]
- [Olivia Attia](https://peterattiamd.com/sneak-peek-peter-attia-drive/) (Peter’s daughter) [1:36:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/03/bio-image-2-500x500.jpg)

##### Matthew Walker Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the [Center for Human Sleep Science](https://www.humansleepscience.com/).

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, [Why We Sleep](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=sr_1_2?hvadid=241932529822&hvdev=c&hvlocphy=9027599&hvnetw=g&hvpos=1t1&hvqmt=e&hvrand=17708652427798493544&hvtargid=aud-646675774026%3Akwd-4848544835&keywords=why+we+sleep&qid=1553972278&s=gateway&sr=8-2). It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[[sleepdiplomat.com](https://sleepdiplomat.com)]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)