# #97 – Peter Hotez, M.D., Ph.D.: COVID-19: transmissibility, vaccines, risk reduction, and treatment

**Source:** [https://peterattiamd.com/peterhotez/](https://peterattiamd.com/peterhotez/)

---

In this episode, Dr. Peter Hotez M.D., Ph.D., Dean for the National School of Tropical Medicine Baylor College of Medicine, shares his expertise on viral disease and how it applies specifically to the coronavirus disease (COVID-19) and the virus that causes it (SARS-CoV-2). Dr. Hotez informs us about the current state of disease progression, which has many unknowns, but has thus far been greatly determined by the delayed response time and lack of testing. Moreover, we discuss what we can do on a country, state, community, and individual level in order to collectively slow transmission of the disease. He shares with us a potential hope in convalescent plasma therapy and underscores the need for US federal involvement – particularly in the creation of a specialty task force to address areas of concern and unknowns.

Disclaimer: This is information accurate as of March 13, 2020, when it was recorded.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/peterhotez/the_Drive_public.png)

Play

#97 - Peter Hotez, M.D., Ph.D.: COVID-19: transmissibility, vaccines, risk reduction, and treatment

#97 - Peter Hotez, M.D., Ph.D.: COVID-19: transmissibility, vaccines, risk reduction, and treatment

1x15s30s

0:0057:01

## We discuss:

- The disease and the virus: transmissibility and lethality [04:30];
- Disease transmission: US playing catch-up [12:00];
- Convalescent plasma coronavirus therapy [16:00];
- Remdesivir drug treatment and vaccination challenges [19:45];
- Disease mechanism and reported pathology [27:45];
- Most concerning geographic regions in the US [39:00];
- Risk reduction [46:30]; and
- More.

## Show Notes

## The disease and the Virus: transmissibility and lethality [04:30]

**Virus Nomenclature**

- SARS-CoV2 is the virus; COVID-19 is the disease which that virus spreads
- MERS-CoV, SARS-CoV, SARS-CoV-2 (i.e., COVID-19) are three examples of coronaviruses
- This virus is not SARS-CoV-1, it’s not MERS-CoV, and it’s not influenza. It is a unique virus with unique characteristics but has particular similarities to SARS-CoV-1
- Based on the historical and current global health threats caused by Coronavirus pathogen,  this vaccine type should be prioritized

**The world has seen three pandemics caused by coronavirus in the 21st century**

1 | Severe acute respiratory syndrome coronavirus (SARS-CoV-1) was identified in 2003 following a 2002 outbreak, originating in Asia

![](https://peterattiamd.com/wp-content/uploads/2020/03/pasted-image-0.png)

**Figure 1. World diffusion of SARS-CoV-1 pandemic in 2003 seeing transmission from Asia to rapid growth in Canada.** Image credit: ([Banos and Lacasa., 2007](https://journals.openedition.org/cybergeo/12803?lang=en))

2 | Middle East respiratory syndrome coronavirus (MERS) appeared in 2012 from Saudi Arabia

![](https://peterattiamd.com/wp-content/uploads/2020/03/pasted-image-0-1.png)

**Figure 2. World diffusion of MERS-CoV pandemic in 2012 originating from the Middle East. Confirmed cases from 2012-2013.** Image credit: [Vox.com](https://www.vox.com/2015/6/5/8735037/what-is-mers-virus)

3 | The novel COVID-19 (SARS-CoV-2)

![](https://peterattiamd.com/wp-content/uploads/2020/03/unnamed.png)

**Figure 3. World diffusion (ongoing) of SARS-CoV-2 pandemic of 2020 originating in Wuhan, of Central Hubei province, China.** Image credit: ([The New York Times](https://www.nytimes.com/2020/03/07/world/coronavirus-news.html))

**The novel COVID-19 coronavirus is comparatively a higher concern …**

- SARS-CoV-2 – or COVID-19 – is not the most lethal or transmissible of viruses but it is high in both categories

![](https://peterattiamd.com/wp-content/uploads/2020/03/Screen-Shot-on-2020-03-14-at-12-51-26.png)

**Figure 4: How the new coronavirus (SARS-CoV-2) compares with other infectious diseases.** Image credit: ([New York Times](https://www.nytimes.com/interactive/2020/world/asia/china-coronavirus-contain.html?auth=login-email&login=email))

*COVID-19 is particularly lethal for certain sub-population groups while others are less affected*

- Children and adolescents don’t seem to get sick but are viral carriers, increasing transmission rate
- The most vulnerable people are those that are/have one or more of the following:
  - Over the age of 70 years old
  - An underlying condition (metabolic disease – heart disease, diabetes, hypertension)
  - On immunosuppressive therapy
  - Healthcare worker/first responders

There are two primary mysteries about groups afflicted:

1. Adolescents and young children don’t get sick
2. Healthcare workers contract a severe version of the virus, despite their age group

*A perfect storm whereby the populations becoming ill makes the virus particularly destabilizing and dangerous…*

- In afflicting healthcare workers, the virus takes out caretakers of those who are or become sick
- Those that provide care are severely impacted
  - In Wuhan, China – reports suggested that at least 1,000 healthcare workers became infected and about 15% of those became seriously ill
- First responders have to self-quarantine if they come in contact with the virus, so that is another pillar of aid that gets hit

## Disease transmission: US playing catch-up [12:00]

- The U.S. was very behind in diagnostic testing and allowing the virus to circulate for a long period of time
- Ruoran Li and [Marc Lipsitch](https://twitter.com/mlipsitch?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) have reported from [studies](https://dash.harvard.edu/handle/1/42599304) out of China that when there is a longer time-to-response, healthcare infrastructure takes the load of impact

![](https://peterattiamd.com/wp-content/uploads/2020/03/ESzBI_BU4AECqLL.jpg)

**Figure 5. Comparison of Guangzhou and Wuhan intervention impact.** Image credit: ([Marc Lipsitch](https://twitter.com/mlipsitch/status/1237354878248333313))

- Guangzhou intervened much earlier in epidemic and had a much smaller peak in bed demand
  - Early intervention spares the health system from intense stress (e.g., Philadelphia vs. St. Louis)
- Early intervention means action is taken prior to the number ramp (e.g., citing Guangzhou that intervened when they had 7 cases and 0 deaths vs. Wuhan that had 495 confirmed cases, 23 dead)

**In the US, there is concern about hospital inundation**

- US will not intervene as did Guangzhou
- Already too late in response time
- The U.S. first case was likely at the beginning of February and the spread of virus went unaddressed for more than a month

**In order to slow the disease spread, social distancing is important**

- The U.S. will now start to test and we will see in the next 1-2 weeks which communities have significant levels of transmission
- We could potentially intervene in those places and shift the growth curve

> “We have lost the opportunity to avoid an epidemic” —Peter Hotez M.D., Ph.D.

## Convalescent plasma coronavirus therapy [16:00]

*In an* [*interview*](https://twitter.com/NewDay/status/1238423471287345153) *with Alisyn Camerota on CNN … Peter referenced how he emphasized that this is not the time to assign fault*

Quote TK “Now is not the time to assign fault … we can do that later. Right now we have to focus on the task at hand” – Peter Hotez M.D., Ph.D.

- One of the first order of action is to find an intervention while vaccine and antiviral drug intervention are pursued
- Colleague [Arturo Casadevall](https://twitter.com/acasadevall1?lang=en) is pushing the idea for a **low-cost** antibody therapy intervention
- The [strategy](https://hub.jhu.edu/2020/03/13/covid-19-antibody-sera-arturo-casadevall/) takes antibodies from individuals that have been infected and have since recovered
- Casadevall and his colleagues have already [started](https://www.fool.com/investing/2020/03/04/takeda-pharmaceutical-announces-a-plasma-derived-t.aspx) testing this therapy for use
- One [report](https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(20)30141-9/fulltext) summarizes the effectiveness of convalescent plasma as a potential therapy for COVID-19, citing historical situation learnings (e.g., SARS-CoV-1, The 1918 Spanish Flu)

*The logistics of this solution are not as straightforward…Government intervention is necessary*

- Method requires apheresis, blood banks, centrifuge
- Would require Center for Biologics Evaluation and Research (CBER FDA) guidance
- Arturo thinks putting together a federal task force would be necessary

*The solution is scalable …*

- 300mL for someone seriously ill (so 1 donor to 1 recipient)
- As a prophylaxis treatment, 5mL for someone equates to ~ one donor for dozens of individuals

## Remdesivir drug treatment and vaccination challenges [19:45]

- Remdesivir has been recently recognized as a promising antiviral drug against a wide array of RNA viruses
- Gilead’s antiviral drug Remdesivir stands out for potential to treat coronavirus. The drug has rapidly moved to phase 3 studies, with data expected by April
- Antiviral medication development and application will move a lot faster than vaccines

**Technical challenges associated with vaccine developments**

- Vaccines are the highest bar there is in terms of testing because it involves immunizing healthy individuals
- Makes it difficult to compress timelines
- Development and trial process can last 2-3 years

1. Phase 1 for safety
2. Phase 2 expanded to demonstrate safety and some efficacy
3. Phase 3 for safety and efficacy in natural disease conditions

- Process should not be rushed
- With respect to Coronavirus vaccines – there is a risk of immune enhancement –  where vaccine could actually make things worse (seen in lab animals)
- Similar to 1960’s Respiratory syncytial virus (RSV) [vaccine](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3255794/) – inactivated vaccine in which vaccine recipients did worse, with more hospitalizations

**Vaccination promise with spike protein receptors**

- One [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2750777/) identified  a target for vaccine and therapeutic development
- From which an NIH [grant](https://grantome.com/grant/NIH/R01-AI098775-03S1) was submitted based on the identification of a highly promising lead candidate vaccine antigen, the receptor-binding domain (RBD) of the SARS-CoV spike (S) protein

![](https://peterattiamd.com/wp-content/uploads/2020/03/unnamed-3.png)

**Figure 6. SARS-CoV-2 spike proteins are similar to SARS-CoV proteins (pictured).**  Image credit ([Du and Jiang, 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2750777/))

- SARS-CoV-1 and SARS-CoV-2 have about 80% similarity in terms of genetic code bound to the same receptor such that vaccine development approval for SARS-CoV-1 could also apply to SARS-CoV-2

*Hotez and his colleagues have NIH funding but no investment…*

- The vaccine could be repurposed but the team require prospective donors in order to move it to clinical trials
- Funding is often a problem when creating vaccines for neglected diseases
- For funding support please email Peter directly: [hotez@bcm.edu](mailto:hotez@bcm.edu)

## Disease mechanism and reported pathology [27:45]

- SARS-CoV virus use Angiotensin‐converting enzyme 2 (ACE2) as a functional receptor
- The ACE2 receptor binds the SARS‐CoV S protein with high affinity, explained in a 2005 [paper](https://www.embopress.org/doi/10.1038/sj.emboj.7600640)
- These type II alveolar cells (AT2) cells are particularly prone to viral infection due to high ACE2 expression

**ACE2 receptor for entry may explain diverse symptoms in infected individuals**

- ACE2, a cell-surface protein on cells in the kidney, blood vessels, heart, and, importantly, lung AT2 alveolar epithelial cells
- The GI manifestations are consistent with the distribution of ACE2 receptors
- The receptors are most abundant in the cell membranes of lung AT2 cells, as well as in enterocytes in the ileum and colon
- At least 10% of reported hospitalized patients presented presented with GI symptoms

**The major route of transmission is not clear… there may be multiple**

- Some identified modes: Microdroplets on surface, directly on someone, airborne, fecal
- Recent [paper](https://www.medrxiv.org/content/10.1101/2020.03.09.20033217v2) reported fomite survival on different surfaces:
  - aerosols, up to 3 hours post aerosolization
  - up to 4 hours on copper
  - up to 24 hours on cardboard
  - up to 2-3 days on plastic and stainless steel (13hr median half-life on steel; 16hr median half-life on plastic)

**Ro and transmissibility**

- The collective picture explains why virus is so transmissible:
  - Can live on multiple surfaces for at least 8hr to 72hr
  - Mode of transmission is significant because virus can survive and transfer in a number of different ways
- This means there is a high reproductive number (Ro)
  - Refers to the number of people that will get infected if a single person has this virus
  - 2.24-3.58 get infected for a single individual
  - Compared to that of the seasonal flu: 1.2-1.3
  - And compared to measles: 12-18
- There are a lot of individuals who do not get sick but spread the virus
- And some other become very ill and will a high mortality rate
  - Mortality rate: 0.6-3.4 /4%
  - 4-20x higher than influenza
  - Among older populations, mortality is 10-20%

**Transmission is an issue in nursing homes**

- First community transmission in Kirkland, Washington
- Killed 13 people; ~13% mortality
- There was not a lot of guidance around transmission of disease and nursing homes
- Peter [testified](https://www.youtube.com/watch?v=N1k4wys-0ps) in front of Congress, calling the virus an “angel of death for older people”

> “Over the years I have always had an interesting career that balancing being a working scientist – an M.D., Ph.D. vaccine scientist for neglected disease interventions with that advocacy in places where I have seen gaps […] and help raise awareness.”  —Peter Hotez M.D., Ph.D.

## Most concerning geographic regions in the US [39:00]

- Any urban area of the US is vulnerable
- We have seen it take off in Seattle, New Rochelle, some uptick in NYC
- Where there are congregations of big, urban populations
- Have to believe that any large urban centers are vulnerable
- Large urban centers generally have better public health infrastructures so that could be another reason those areas are more vulnerable

*An increase in testing will give a better picture of infection rate and numbers*

- There is and will be a big demand on the healthcare system
- There is risk of hospital bed shortage

> “The next two weeks will be the critical period where we may start to see this reach a peak.”  —Peter Hotez M.D., Ph.D.

- Antibody therapy offers people hope and helps to avoid the spread of panic
- There is not a lot of margin for hospitals to operate so the coping in response to demand remains to be a big unknown
- [Ezekiel Emanuel](https://en.wikipedia.org/wiki/Ezekiel_Emanuel) has [written](https://jamanetwork.com/journals/jama/article-abstract/2674647) about U.S. healthcare and cost structure

**Model estimates of disease spread**

> “All models are wrong, some are useful” —George Box

- Mac Lipsitch has [estimated](https://www.cbsnews.com/news/coronavirus-infection-outbreak-worldwide-virus-expert-warning-today-2020-03-02/) that over 70% of the world’s population may become infected
- Estimates are based on models

> “One thing that always impresses me working with modelers is that a modest change in assumptions of what goes into the model can often have huge differences. The only comfort I take in that is if current models for infection rate are anything like the models I have worked with: a small change in assumption can result in 2-3 logarithmic reduction in deaths…” —Peter Hotez M.D., Ph.D.

## Risk Reduction [46:30]

- We still have some say in our response to this:
  - at the federal, local, state and personal level
  - Self isolating and quarantining when necessary (any signs or symptoms)

**The plea for federal guidance and specialty task forces**

- We need specialists to come together as a task force on a given issue (e.g., antibody-based technology, nursing home care structures, mental health experts, metabolic disease teams) – all to try and understand what is going on
- Older individuals in clusters are high risk but the challenge is to weight risk vs socialization important
  - Want to protect and isolate individuals
  - Socialization and seeing other is very (psychologically important)

> “This is where I say I am a vaccine scientist but pretty good at understanding infectious disease epidemiology. But there is a point where decisions become so tricky that I start to exceed where I feel comfortable.” —Peter Hotez M.D., Ph.D.

**In the coming weeks…**

- Peter will be focusing on incidence and prevalence data in the weeks to come
- As we increase testing, we will be able to observe which new communities become infected
- Vaccine trials have begun in Washington which is a positive but we will also see immune enhancement, if there is any, in volunteer population
- Make sure to take a retrospective look to what was learned the previous week
- We have to continually reevaluate

> “This is where we are right now and this virus is racing so quickly […] new pathogens in general set you [an infrastrucutre] to look stupid […] but this one especially because it is so fast moving and transmissible” —Peter Hotez M.D., Ph.D.

§