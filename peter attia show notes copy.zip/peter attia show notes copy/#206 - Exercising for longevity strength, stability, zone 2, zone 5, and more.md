# #206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more

**Source:** [https://peterattiamd.com/exercising-for-longevity/](https://peterattiamd.com/exercising-for-longevity/)

---

In this special episode of The Drive, we have pulled together a variety of clips from previous podcasts about [exercise](https://peterattiamd.com/category/exercise/) to help listeners understand this topic more deeply, as well as to identify previous episodes which may be of interest. In this episode, Peter discusses his framework for exercise, what he’s really optimizing for, and how to train today to be prepared for a good life at age 100. He describes the importance of strength and stability, and why deadlifting is an important tool to consider for longevity. Additionally, he details why training in zone 2 and zone 5 is important, gives a primer on VO2 max, and describes the most effective ways to engage in those types of exercise. Finally, Peter reveals his current exercise routine.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/exercising-for-longevity/the_Drive_public.png)

Play

#206 - Exercising for longevity: strength, stability, zone 2, zone 5, and more

#206 - Exercising for longevity: strength, stability, zone 2, zone 5, and more

1x15s30s

0:001:14:02

## We discuss:

- What is Peter optimizing for with his exercise? [3:00]; *(from [AMA #12](https://peterattiamd.com/ama12/))*
- Preparing for a good life at age 100: Training for the “Centenarian Decathlon” [6:00]; *(from [AMA #5](https://peterattiamd.com/ama05/))*
- The importance of preserving strength and muscle mass as we age [21:45]; *(from [AMA #27](https://peterattiamd.com/ama27/))*
- The value of deadlifts for stability and longevity when done properly [27:30]; *(from [episode #103](https://peterattiamd.com/strong-convictions-loosely-held/))*
- The importance of zone 2 aerobic training [35:45]; *(from [episode #103](https://peterattiamd.com/strong-convictions-loosely-held/))*
- The most effective ways to engage in zone 2 exercise [40:00]; *(from [AMA #19](https://peterattiamd.com/ama19/))*
- Zone 5 training and VO2 max [44:15]; *(from [AMA #21](https://peterattiamd.com/ama21/))*
- A primer on VO2 max [52:00]; *(from [episode #151](https://peterattiamd.com/alexhutchinson/))*
- Stability—the cornerstone upon which all exercise and movement relies [1:03:00]; *(from [AMA #12](https://peterattiamd.com/ama12/))*
- Peter’s current exercise routine [1:07:45]; *(from [AMA #32](https://peterattiamd.com/ama32/))*
- More.

§

## Show Notes

\***Notes from intro**:

- We realize there are a lot of new listeners who haven’t had the chance to listen to all of our older episodes, so for this week we’re experimenting with a different format
- We put together a variety of clips from previous podcasts that discuss exercise and Peter’s framework for exercise
  - The links at the end of the show notes direct you to what portion of previous episodes are featured in this podcast
- We put these clips in order of what we think is the best way to listen
- Peter will provide some commentary before (and in between) each clip
- Our hope is that this will allow you to understand this topic better, and also help identify some previous episodes you may be interested in listening to to dive deeper
- The first set of clips looks at what Peter is optimizing for with his exercise, and why he thinks training for the Centenarian Decathlon is so important
- Some of these clips are from AMAs, so if you’re not a subscriber, you’ll be able to get an idea of what we cover on those episodes
- Additionally, for the stability and DNS content clips (in our episodes with [Beth Lewis](https://peterattiamd.com/bethlewis/) and [Michael Rintala](https://peterattiamd.com/michaelrintala/)), we actually filmed instructional videos of them showing how to do these various exercises
- As this is the first time we’re doing this, please let us know if this is something you like, would want more of, and how we can make it better

## What is Peter optimizing for with his exercise? [3:00]

From episode [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/); discussed from [30:30] – [33:45]

**Peter is looking at exercise through the lens of longevity, not performance**

- The difference is important
- If your goal was to break 2 hours and 40 minutes on the Chicago Marathon next year, the training required would be totally different from that needed to maximize longevity
  - Longevity is a very difficult performance goal
- When you start to look into the far recesses of amazing physical performance, training would be very specific for that
  - This is not what Peter is discussing
  - Training for this type of performance is generally not collinear with longevity and at times they can be outright orthogonal
    - So this is the difference between something being in-line with (collinear) or at-odds with (orthogonal)
- Exceptional physical performances requires maximum cardiac output, just beneath [VO2 max](https://en.wikipedia.org/wiki/VO2_max)
  - This level of performance and training puts an amazing strain on the body
  - While this is better than sitting on the couch all day, it is past the point of optimizing longevity returns
  - This comes at some longevity cost relative to training at a lower energy system

**Why training for the “Centenarian Decathlon” is so important**

- This podcast is geared toward this “Centenarian Decathlon”

> “*This is the idea of being the most kick-ass 90-year old possible*”‒ Peter Attia

- This is based on 2 energy systems:
  - 1 – Strength and stability
  - 2 – Low-end aerobic energy system (which is zone 2, we’ll talk about that in a moment) which is punctuated with brief bursts of zone 5
  - These energy systems matter because this is generally where life takes place

> “*Life is zone 1, zone 2, and zone 5*”‒ Peter Attia

- By training in zone 2 and zone 5 (with much more focus on zone 2), we’re preparing metabolically and structurally for longevity

## Preparing for a good life at age 100: Training for the “Centenarian Decathlon” [6:00]

From episode [#50 – AMA #5: calcium scores, Centenarian Decathlon, exercise, muscle glycogen, keto, and more](https://peterattiamd.com/ama05/); discussed from [18:15] – [33:45]

**What does Peter wish he incorporated into his exercise at age 25 to be in this race for the gold medal in the “Centenarian Decathlon”?**

- For most people, a system of the body is going to fail first
  - Some people die suddenly when their mind and body are fine; they are an exception to this discussion
  - For many people their mind fails first, cognition is taken from them and then eventually they die or their body breaks down
- For most people, the decline of mind and body, and the burden of disease occurs as the body fails first
- This prompted Peter to think about how to mitigate the decline / fail of the body
- He engaged in [backcasting](https://en.wikipedia.org/wiki/Backcasting) (instead of forecasting), to think of what he wants to do when he is 100 and work backwards from that to determine what to do today at age 45 (or any age)
  - He borrowed the term backcasting from [Annie Duke](https://twitter.com/AnnieDuke?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) who wrote [*Thinking in Bets*](https://www.amazon.com/Thinking-Bets-Making-Smarter-Decisions/dp/0735216355)
  - See [episode #60 with Annie Duke](https://peterattiamd.com/annieduke/)
- This led to the question‒ *What do I have to physically be able to do to be satisfied with my life at 100 years old?*
- He thought about how old his kids would be when he is 100, and how old will their kids be
  - He realized at this age, his grandkids will have kids
  - When Peter is 100, he will likely have great-grandchildren that are between the ages of 1-8

**What will Peter want to be able to do at 100 to be happy?**

- He doesn’t want to be bedridden with disease
- He wants to retain his cognitive faculties
- There are lots of physical activities he want to be able to do
  - Shoot a bow and arrow
  - Exercise (he enjoys it)
- [Activities of daily living](https://en.wikipedia.org/wiki/Activities_of_daily_living) are important
  - Things he would want to do with his great-grandkids when they are 1, 3, 4, 5, etc.
  - Be able to drop into a squat position and pick up a child that weighs 30 lbs
  - Be able to get up off the floor using a single point of support, such as just 1 arm
  - Be able to lift something that weighs 30 lbs over his head; this is about the weight of his carry-on suitcase
  - Be able to get out of a pool without a ladder
  - Be able to walk up 3 flights of stairs with 10 lbs of groceries in each hand
- He made a list of 18 things‒ this became his centenarian decathlon (even though a decathlon is only 10 things)
- He asked‒ *What are physical tasks that will approximate the things he wants to be able to do for daily living at age 100?*

**What exercises will be useful to prepare to do the things Peter wants to do at age 100?**

- A 30 lb goblet squat can approximate picking up a 30-lb kid who comes running at you

![](https://peterattiamd.com/wp-content/uploads/2022/05/f1-exerciseroundup-831x1024.png)

**Figure 1. The goblet squat.** Image credit: [xbodyconcepts.com](https://xbodyconcepts.com/how-to-squat-with-perfect-form-a-4-step-guide/)

- Working back from 100 years old, and realizing there is going to be a decline with age, Peter can set goals for age 80, age 60, and today
- Peter’s training today centers around the goals of what he wants to do when he is 100-years-old
  - He doesn’t do any training related to racing or competing in anything (not that this is bad)
- Peter was not thinking of longevity and life at 100 years of age as a 25-years-old

**Peter’s framework for thinking about exercise for longevity has 4 components [13:45]**

- 1 – Stability
- 2 – Strength
- 3 – Aerobic performance
- 4 – Anaerobic output
- Each of his 18 goals (for his Centenarian decathlon) touch on at least 1 of these items in this framework; some touch on more than 1
  - The goblet squat requires both strength and stability
  - Walking up 3 flights of stairs with 10 lbs of groceries in each hand is on the threshold of aerobic/ anaerobic output and also requires strength
- **Stability** is where most people first begin to fail
  - This begins around the time that children start school
- Peter has noticed that young children are so good at stability‒ the way they squat, the way they move is so natural
- The field of [dynamic neuromuscular stabilization](https://drryanhamm.com/what-is-dns-dynamic-neuromuscular-stabilization) is based on this principle that there are 13-14 movements that are innate to us
  - By the time we are about 1.5-years-old, we do them all perfectly
  - Then it’s basically all downhill from there
- Decline of stability is accelerated by school, once you start sitting
  - We lose the ability to maintain tension through our pelvic floor and throughout our entire core
  - The [core](https://en.wikipedia.org/wiki/Core_(anatomy)) describing the: diaphragm, obliques, [transversalis fascia](https://en.wikipedia.org/wiki/Transversalis_fascia), and the entire [pelvic floor](https://en.wikipedia.org/wiki/Pelvic_floor)

**Peter recommends:**

- Spend as much time as possible working on static stability then dynamic stability
  - Incorporate these principles into what you are doing strength-wise
- At the age of 25, you can do a lot of exercises incorrectly and get away with it
  - But correct form is very important in the long run
- Peter thinks he’s always squatted and deadlift somewhat incorrectly
  - He’s never fully engaged his pelvic floor doing those
  - He got away with doing those incorrectly for a long time but now realize the damage that has occurred as a result

**An anecdote‒ Peter’s breathing squat routine from high school:**

- It’s an amazing routine, *but he doesn’t know if he recommends it*
- In high school he lifted 6 days a week, 3 hours a day
- Once a week they did a routine of breathing squats
  - Take your best 10-rep weight (a weight that you would fail with at 10-reps), load it on your back and do a squat (1 rep)
  - Go down and up at your normal cadence
  - At the top of the squat, you take 3 of the deepest breaths you can take
    - Each breath taking 10 seconds for a total of 30 sec
    - Breathe in for 5 sec, breathe out for 5 sec (x3)
  - After taking these 3 deep breaths at the top of the squat, do another squat
  - Continue this routine for a total of 20 reps
- This set takes 10 minutes
- The only thing Peter has done since that rivals this degree discomfort of is an airbike [tabata](https://en.wikipedia.org/wiki/High-intensity_interval_training#Tabata_regimen)
- Peter describes this squat routine, “*as one of these knuckle-head things we got out of our bodybuilder magazines (powerlifting magazines), and the idea was that nothing would stimulate more strength and growth than that activity*”
  - It worked
  - Over the course of 1 year doing this, he added over 100 lbs to his squat
    - And that was starting at a level where he was already pretty strong
- This workout was so painful that he would start getting uptight the day before
- This relates to “super slow” or slow training‒ lifting slow and accumulating time under tension ~90 seconds
  - On of the proponents of this is [Doug McGuff](https://www.drmcguff.com/) who wrote [*Body by Science*](https://www.amazon.com/gp/product/0071597174?ie=UTF8&tag=baye&linkCode=as2&camp=1789&creative=9325&creativeASIN=0071597174)
  - 90 seconds feels like an eternity
  - Until you time yourself lifting, you don’t realize how little time is spent under tension
- Peter’s memory from this breathing squats workout is that his upper body hurt as much as his lower body
- There are a lot of on-going centenarian studies (listed below) and Bob wonders how many of these centenarians could do this decathlon‒ none of them
  - The Einstein one in NY of Ashkenazi Jews‒ [The Longevity Genes Project](https://www.einsteinmed.edu/centers/aging/longevity-genes-project/) at Albert Einstein College of Medicine’s Institute for Aging Research
  - [Thomas Perls](https://profiles.bu.edu/Thomas.Perls) study has an aggregate of different ethnicities [the [New England Centenarian Study](https://www.bumc.bu.edu/centenarian/)]

**Peter comments on anyone who is a centenarian today**

- This is an extreme statement, but Peter thinks that anyone who is a centenarian today lived this long because of their exceptional genes
  - They haven’t hacked their way there
  - Most of them haven’t done anything different (better/ worse) than their peers
  - On average today’s centenarians tend to smoke more, exercise less, and eat worse than their peers

> “*What we’re talking about (people our age) is… hacking our way to centenarians*”‒ Peter Attia

- This is very deliberate
- This is a new model to force your way to become a centenarian and will require deliberate attention around what you mind and body are doing

## The importance of preserving strength and muscle mass as we age [21:45]

From episode [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/); discussed from [58:00] – [1:03:30]

**How much lean mass are people losing over time?  What is aging robbing you of as time goes on?**

- The lowest rate of decline in lean mass (shown by studies) is 1-2% per year after age 50; see the table below
- Between ages 20-80, this is a loss of 35-40%
- The strength decline may be even greater
  - Some studies show 4% loss of strength per year

![](https://peterattiamd.com/wp-content/uploads/2022/05/f2-exerciseroundup-1024x416.png)

**Figure 2.  Loss of lean muscle and strength over time.**  Image credit: [*MLTJ* 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3940510/)

- This is difficult to put in context when you understand what compounding does

> “*If you have the aspiration of kicking ass when your 85, you can’t afford to be average when you’re 50*”‒ Peter Attia

- You’ve got to have cardiorespiratory fitness, strength, and even muscle mass
- They looked at men and women leg strength versus grip strength (a leg extension and a grip exercise)
  - The leg strength was measured in Newton meters (Nm) doing leg extensions
  - The grip strength was measured in kilograms
- The average age of participating men was 54 and for women it was 53
- They were followed prospectively for 5-6 years
- This study looked at all-cause mortality
- The change in men’s leg strength (shown in panel 1 of the figure below) is not subtle
  - This shows that the weaker one is, the quicker the decline in strength
  - *For every 0.2 unit reduction in strength per ct area they saw a significant increase in mortality*
    - Strength was normalized for muscle size
    - Muscle area was measured by [computed tomography (CT) scan](https://en.wikipedia.org/wiki/CT_scan), to look at cross-sectional area
    - Lean tissue mass was determined using [DEXA (dual energy-x-ray absorptiometry)](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)
    - They took that normalized unit of strength per CT area and observed when it was reduced by 0.2 units, there was a 26%
    - When muscle area was measured by DEXA, a 0.2 reduction in strength was associated with a 39% increase in mortality
    - Even without this normalization the result is the same
- Grip strength was normalized by a DEXA arm measurement
  - *Reduced grip strength was associated with a 23% increase in mortality*
- These were statistically significant results; shown in the figure below
- For women, there was a larger confidence interval

![](https://peterattiamd.com/wp-content/uploads/2022/05/f3-exerciseroundup-1024x649.png)

**Figure 3.  Kaplan-Meier survival curves for strength grouped by standard deviation.** Image credit: [*The Journals of Gerontology Series a* 2006](https://academic.oup.com/biomedgerontology/article/61/1/72/549632?login=false)

- Peter finds the table below (Figure 4) to be an easier way to appreciate the statistical relevance of their findings

***Peter’s takeaway: Normalizing strength by size of muscle and prospectively following people we see a trend‒ strength is the more important parameter***

![](https://peterattiamd.com/wp-content/uploads/2022/05/f4-exerciseroundup-978x1024.png)

**Figure 4. (Table 4) Specific torque-mortality risk per standard deviation in men and women.**  Image credit: [*The Journals of Gerontology series a* 2006](https://academic.oup.com/biomedgerontology/article/61/1/72/549632?login=false)

## The value of deadlifts for stability and longevity when done properly [27:30]

From episode: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/); discussed from [42:00] – [51:00]

**How has Peter’s thinking changed on deadlifts?**

- Long before powerlifting was in vogue, Peter would lift weights every day with a friend in high school
- [Powerlifting](https://en.wikipedia.org/wiki/Powerlifting) is different from olympic lifting, powerlifting is 3 lifts: the [deadlift](https://en.wikipedia.org/wiki/Deadlift), the [squat](https://en.wikipedia.org/wiki/Squat_(exercise)), and the [bench press](https://en.wikipedia.org/wiki/Bench_press)
- Peter grew up doing a lot of deadlift, squatting, and bench pressing
  - He was always horrible at the bench press
- In 2016 Peter partially tore one of his obliques
- After this he was never able to deadlift again without some discomfort
  - Even though it is a great total hip hinge, compound movement, he got away from doing deadlifts
- This changed when he began [Dynamic Neuromuscular Stimulation (DNS)](https://www.rehabps.com/REHABILITATION/Home.html) in 2017/ 2018
- Learn more about DNS in these episodes of *The Drive*:
  - [#131 – Beth Lewis: The Art of Stability: Learning about pain, mitigating injury, and moving better through life](https://peterattiamd.com/bethlewis/)
  - [#152 – Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization (DNS)](https://peterattiamd.com/michaelrintala/) )
- Through DNS Peter realized the deadlift was going to be beneficial because it becomes a beautiful audit for everything working perfectly

***Peter deadlifts at least twice a week (often 3x a week), both straight bar and trap bar; he doesn’t go that heavy***

- In terms of weight for deadlifts, Peter might have had 400 lbs on the trap bar in the past year
  - He usually stops at 350-375 on the trap bar
  - On the straight bar he goes lighter, maybe 185 lbs
- He does a lot of slow eccentrics
- He films every single rep of every set
  - He studies it and sends it to his coach, [Beth Lewis](https://www.instagram.com/bethlewisfit/)
  - He works to make his deadlift perfect

> “*I’d rather take a light weight and deadlift it perfectly several times per week”*‒ Peter Attia

- ***His typical workout is 4-5 sets of 10 reps***
  - These are not killing, crusher sets
  - At no point is he past his limit
- He can push himself harder in other things

**Peter’s goal is to do the deadlift perfectly, and he is constantly checking his form**

- Does he have just the right amount of thoracic extension?
- Does he have just the right curvature in the lumbar spine?
- Does he activate his glutes?
- Does he activate his hamstrings?
- Is he pulling back instead of pulling up?
- Is he wedging correctly?

> “*All of this little stuff translates biomechanically to the activities of daily living that matter to me.  Like getting up off the floor, picking up one of my kids, lifting a piece of luggage, or something like that.*”‒ Peter Attia

***If he can do the deadlift and it feels right, then he knows he ready to do everything correctly***

- When something doesn’t feel right during a deadlift, he knows
  - 1 – How to recognize that feeling
  - 2 – The steps to bo back and correct it
- Peter wants to put together a video on deadlift and preparation
  - There are about 10 exercises he does to get ready to deadlift; they don’t take long (10-15 minutes)
  - He’s not sure how much of the benefit is the actual deadlift versus all the things he does to do the deadlift correctly
- Only recently did Peter realize you can deadlift in a way that puts your spine under traction
  - This is counterintuitive; you might think your spine is under compression when lifting under an axial load
  - It turns out when you learn the right positioning, then you can deadlift and actively create traction in the spine
    - You understand how to create intra-abdominal pressure
    - You know how to elongate your spine
  - This is why the deadlift is the most important thing Peter does before he gets on an airplane
    - He’s going to be sitting for 5-6 hours
    - He doesn’t want his spine to be compressed
    - The deadlift primes him to maintain that activated form of traction

## The importance of zone 2 aerobic training [35:45]

From episode [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/); discussed from [37:00] – [41:00]

- Zone 2 training has been covered in a variety of episodes; this was most recently covered in the second podcast with [Iñigo San-Millán](https://www.inigosanmillan.com/)
  - [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/)
- Peter spends 3-4 hours per week training in zone 2 and thinks it’s incredibly important for all of his patients
- You want to put a rate-limiter on the intensity of your workout when you do zone 2 training

**How has Peter’s thinking on zone 2 training changed?**

- When Peter was a cyclist, he spent 10-12 hours a week training in zone 2
  - Now he spends 3-4 hours per week in this zone
- In late 2014 when Peter stopped competing in time trials, he stopped doing any low intensity training (which is a major component of training for competition)
- He went from cycling to rowing and running
- He was obsessed with being as efficient as possible; everything was an all-out effort
  - If he was running, it would be a 6-minute mile, not a 9-minute mile
- Meeting Iñigo and going through literature on zone 2 training before having him on the podcast brought to light the benefits of this type of training
  - Metabolic benefits‒ insulin-dependent and insulin-independent glucose disposal
  - Improvement of mitochondrial function, health, and density
  - Increased release of neurotrophic factors that can come from this type of activity, such as [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) secretion
- Peter realized he needed to reincorporate zone 2 training into his exercise program

> “*One of the things about zone 2 that I really enjoy is, it’s just not that hard… it’s just nice to get on the bike… and that’s my time to listen to podcasts and audiobooks*”‒ Peter Attia

***Takeaway:*** We can do zone 2 our entire lives; we can do it safely, and it yields enormous dividends

## The most effective ways to engage in zone 2 exercise [40:00]

The next clip is from episode [#145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/); discussed from  [14:00] – [18:30]

- There is not a best device, but choose one where you can easily reproduce the same output
- Peter likes the bicycle because it has a clear metric that he can adjust‒ the wattage
  - Watts are easy to track
  - He uses an ergometer; he puts his road bike on a device called a [Wahoo KICKR](https://www.wahoofitness.com/devices/indoor-cycling/bike-trainers) which is hooked up to a computer where he sets the numbers of watts he wants and it adjusts the resistance

**Peter on his Wahoo KICKR [explaining a zone 2 workout](https://www.instagram.com/p/BsLfg6kg0Q9/)**:

- Other devices can be good for zone 2 training
  - His wife likes to ride a [Peloton](https://www.onepeloton.com/bike) (he doesn’t like it); she doesn’t got into a class but sets the resistance and the RPM she puts in, and it spits out a wattage
    - So she has to adjust her cadence to stay at a specific wattage
    - It’s the difference between in erg-mode and spin-mode
  - She also likes a rowing machine
    - Peter is not fond of rowing for zone 2
    - He likes the rowing machine for zone 5, but that’s because he’s not a very good rower
    - Someone who has good form (like [Beth Lewis](https://www.instagram.com/bethlewisfit/?hl=en), [previously on the podcast](https://peterattiamd.com/bethlewis/)) can get a good zone 2 workout on a rowing machine
  - Cycling is second nature for Peter; it’s a very efficient thing for him to do
  - He’s not fond of ellipticals because it’s hard to stay in the proper zone
    - You may have one that works for you, where you can get your heart rate high enough and move quick enough
    - The key is‒ *how much energy do you have to put in to maintain a sustained dose?*
    - The bike on the erg-mode of a trainer makes it easy; he doesn’t have to think about it; it’s putting 200 watts to his wheel no matter what he does in terms of speed
- Regardless of the device, it’s the **wattage** that matters
- He is also always measuring **heart rate**
- Treadmills are also a great way to do this
  - For most people though, running gets them out of zone 2 quickly
  - ***He advises patients to do brisk, incline walking***
    - Start at a 10-15-degree incline at 2.5-3.0 miles per hour (maybe less)
    - This is empirical, you have to figure out what incline and speed will keep you in zone 2

**How do you know you’re in zone 2?**

- Track power output (watts), heart rate, and lactate
- Peter has noticed his heart rate will be elevated if he’s sick, dehydrated, or something
  - In this case back off; adjust the wattage down a bit

## Zone 5 training and VO2 max [44:15]

From episode [#153 – AMA #21: Deep dive into olive oil, high-intensity exercise, book update, and more](https://peterattiamd.com/ama21/); discussed from [49:30] – [55:30]

- Another pillar of Peter’s framework of exercise focuses on the upper end of aerobic, verging on anaerobic exercise (zone 5 training)
- Zones are a function of the underlying system used to track exercise intensity
  - This could be heart rate-based training
  - Or power-based training (following wattage output)
- Peter thinks of zone 5 as [VO2 max](https://en.wikipedia.org/wiki/VO2_max) training
  - We [talk about VO2 max in AMA #27](https://peterattiamd.com/ama27/) and compare someone with low fitness (at the bottom 25% of VO2 max) to someone with elite fitness (at the top 2.5% VO2 max)
    - There is about a 5-fold difference in benefit between these 2 groups
    - This shows the importance of VO2 max
- People often spend too little or too much time in zone 5
- This discussion will help you determine what that sweet-spot is
  - This assumes that you are not training specifically for competition or athletic events that require unusual levels of fitness around the zone 5 energy system
- If you are training to be a kick ass 90-year-old, then you don’t need to spend as much time in zone 5 as you might think

**What is Peter’s approach to zone 5 training and other anaerobic training protocols?**

- Peter mostly uses the stairmaster for his zone 5 training
  - This is his favorite piece of equipment other than the bicycle
- He does 1 zone 5 workout a week‒
  - 3 minutes of zone 2
  - 1 minute at VO2 max (this is quite difficult to keep this up for 1 minute)
  - Repeat this 4-minute pattern for 20-30 minutes
  - He does this on the tail-end of a zone 2 workout; so this is his longer aerobic day
- Because he knows what his VO2 max is, he can convert it into [METS (Metabolic equivalent of task)](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task)
  - The stairmaster allows you to work at watts and METS
- When he’s outdoors on his bike, he likes to do a training-type/ VO2 max ride
  - 4 minutes at 125% [FTP (functional threshold power)](https://en.wikipedia.org/wiki/Sweet_spot_(sports))
  - Followed by 4 minutes of recovery
- There’s lots of ways to hit zone 5 but Peter’s take is that most people spend too much time in zone 5 and not enough time in zone 2

**More about Peter’s stairmaster machine**

- He uses a fancy one like they have at the gym; it has a series of steps that rotate ([similar to #4 & #8 on this list](https://www.bestproducts.com/fitness/equipment/g501/stair-stepper-machines-climbers/))
- The higher the intensity, the less resistance it provides; this makes you climb the steps faster
- At 8 METS he steps quite slowly
- At 20 METS it feels like there is no resistance and he’s running up the steps
- If you’re working 100% (balls-to-the-wall), you can exceed your VO2 max in terms of the work you’re doing
  - [Alex Hutchinson](https://alexhutchinson.net/) writes about this in his book [*Endure*](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866)
  - Alex was also the guest for episode [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/)
- Alex Hutchinson elegantly writes‒ ***the limits of human performance in terms of going all out, is about 10 seconds***
- You may think you’re going all out for 80% of a spin class, but you’re not
- Consider the difference between a 100 m and a 200 m sprint, run by the best athletes on the planet
  - By the time [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) is running the 200 m, he is slowing down in the second half of the race
  - The 100 m is about a 10-second race; this is about the limit of what a true all-out-effort means
- Consider 2 variants of [Tabata](https://www.ritsumei.ac.jp/rs/category/tokushu/150715/):
  - 1 – The 20:10 Tabata (*seconds of strenuous exercise: seconds of rest*)
  - 2 – The 10:20 Tabata
  - Anyone who has tried this knows you can go so much harder for the 10:20 than the 20:10
- Peter likes to use an [Airbike](https://www.roguefitness.com/assault-airbike-and-accessories) for Tabata exercise
- The 20:10 Tabata is favored because this is the one that was studied by Irisawa and [Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata)
  - Irsiawa developed the protocol and Tabata wrote the paper
    - This should be called the Irsiawas instead of the Tabata
  - Published in *BMC* in 2019, [Tabata training: one of the most energetically effective high-intensity intermittent training methods](https://jps.biomedcentral.com/articles/10.1007/s12576-019-00676-7)
- The problem with the 20:10 Tabata is you’re actually pacing yourself (whether consciously or subconsciously)

## A primer on VO2 max [52:00]

This next clip is from episode [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/); discussed from [38:00] – [49:30]

- An analogy to think about [VO2 max](https://en.wikipedia.org/wiki/VO2_max) is‒ ***VO******2*** ***max is like the size of your engine***
- Physiologically, VO2 max tells you how quickly you can take oxygen from the air, into your lungs, get it into your blood, pump it to your muscles, and have your muscles use it in the metabolic processes that provide energy to move you
  - ***VO******2*** ***max is a rate; it’s how much oxygen per unit of time can you process***
- VO2 max was first discussed/measured in the 1920s by a guy named [A.V. Hill](https://en.wikipedia.org/wiki/Archibald_Hill), a very good runner himself
  - If you ask someone to go out and run at a gentle pace, let’s say they consume 2 liters of oxygen per minute
  - Tell them to speed up, and now they’re doing 3 liters of oxygen per minute
  - Tell them to speed up again, and now they’re going really fast and they’re losing 4 liters of oxygen per minute
  - Tell them to speed up again, and they are still only using 4 liters of oxygen a minute
  - In other words, ***there’s a plateau‒ a point at which, even though you’re working harder, you’re not using any more oxygen; this is one’s VO******2*** ***max***
    - This plateau looks like a physiological limitation
    - This is a point where, no matter how much you push yourself, you can’t get more oxygen (*even though you can still go faster using other forms of energy*)
    - This is ***the limits of your aerobic system***
    - This doesn’t tell you how fast you can run

> “*That [VO**2* *max] tells you what sort of aerobic engine you have to play with*”‒ Alex Hutchinson

- People are used to hearing VO2 max reported, not in liters per minute but mL per min per kg

**Examples of VO****2** **max**

- An outlier VO2 max is a number bigger than 2 L or 5 L; this would be 75 or 80 mL
- Alex (a runner) was tested at just over 5 L/min
- If you compared him to a rower, the rower would make him look pathetic because the rower would be using 7 L/min or more
  - A rower is also twice his size, so this doesn’t mean that the rower is better because he has way more muscle to use the oxygen he’s taking in
- If you want to compare apples-to-apples (athletes of different sizes), for a crude approximation, you divide by weight
  - This is reported as milliliters of oxygen per minute per kilogram of body weight
  - For Alex, 5 L/ min works out to 80 mL/min∙kg
  - For Peter who also measured at around 5L/min, he is heavier so this worked out to around 70 mL/min∙kg
- You could argue that you should divide by lean mass not total body weight to account for skeletal tissue, fat, etc. as the amount of these tissues can vary but they doesn’t use more oxygen during exercise
  - There’s a whole rabbit hole you can go into, but at a certain point it doesn’t matter that much
  - For comparing to yourself, to see if you’ve increased your VO2 max, it doesn’t matter what you’re dividing by

> “*You can’t just measure someone’s VO**2* *max and know how fast they’re going to race*”‒ Alex Hutchinson

- When Peter was cycling competitively, there was a guy he would ride with whose VO2 max was 55-60 mL/min∙kg (Peter’s was 70 mL/min∙kg); but there was never a day where Peter could ride faster than him
  - Maybe his friend was a more efficient athlete

**Historical limits of VO****2** **max‒** **what is it that causes VO****2** **max to plateau?**

- There is a lot of confusion and debate about the limits of VO2 max
- If you want to measure endurance by testing how fast someone can run a mile as hard as they can, but there are many factors that can affect this
  - Motivation, pacing, lots of factors
- The nice thing about VO2 max (and why scientists like it) is, in theory it’s independent of motivation
  - The plateau in oxygen intake is a property of their body and not a result of if they’re excited about the study/ exercise
- The cause of this plateau could be in the lungs, in the heart, in the circulation, or in the muscle’s ability to extract oxygen from the bloodstream and make use of it metabolically in the mitochondria
  - This is controversial and limitations can arise in any part of this cascade
  - Conventional wisdom is that the lungs are not the limitation, you can always breathe enough in and they don’t respond to training because they’re overbuilt
    - But a review was published arguing that in some cases (such as highly-trained endurance athletes), the lungs aren’t overbuilt and can be a limitation on VO2 max
    - Published in the *Journal of Applied Physiology* in 1985, [Is the healthy respiratory system built just right, overbuilt, or underbuilt to meet the demands imposed by exercise?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7864246/)
  - There is also the situation where an athlete is so fit, their heart pumps blood so quickly past their lungs, that it doesn’t have time to fully stock-up on oxygen
    - This results in exercise-induced arterial [hypoxemia](https://en.wikipedia.org/wiki/Hypoxemia)
    - This is usually an issue at altitude
    - About half of endurance athletes experience this at sea level
  - There is debate on this because there isn’t any 1 single answer; ***limits of VO******2*** ***max can occur anywhere along the cascade of taking oxygen in and the muscle using it in the production of energy***
- Peter notes that the way the oxygen consumption is calculated relies on measuring the oxygen concentration breathed out and calculating the difference (the delta) between that and the oxygen concentration in the air (breathed in)
  - It would be interesting to test VO2 max while reducing the [FIO2 (the fraction of inspired oxygen)](https://en.wikipedia.org/wiki/Fraction_of_inspired_oxygen)
    - To put this in context, the typical FIO2 in any room is 21% oxygen
    - If FIO2 was reduced to 20%, 19%, 18%, etc. and if the lungs are not the limitation for VO2 max, then you should see the same  VO2 max (or measure the same absolute delta between inhaled versus exhaled oxygen) in all of these conditions of different oxygen %
      - This would be an interesting experiment to eliminate lungs and capillary exchange of oxygen as a limit on VO2 max
      - Alex doesn’t think a study this detailed has been published
      - People have compared 21% oxygen to 10% and 15% oxygen
- Less oxygen is available at altitude and funny things happen
  - You would think that the first thing to happen is, you would go anaerobic sooner and produce more lactate; but the opposite happens
    - This is called the [lactate paradox](https://journals.physiology.org/doi/full/10.1152/nips.01382.2001)
    - If you exercise to exhaustion at lower levels of altitude, you produce less lactate than you would a sea level
    - There’s debate over what causes this and if it’s a real thing

> “*The picture that makes sense to me is, these things are not just about how much oxygen is making it to the muscle, it’s also‒ what is your brain-oxygen level*”‒ Alex Hutchinson

- There are these other circuit-breakers limiting VO2 max, that aren’t on the path from mouth to lung, to blood, to muscle
- There are other factors that detect low oxygen and cut off the supply to the muscle to make sure we don’t get stupid [deprive the brain of oxygen]

## Stability—the cornerstone upon which all exercise and movement relies [1:03:00]

This clip is from episode [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/); discussed from [24:30] – [29:00]

**Peter along with** [**Beth Lewis**](https://www.instagram.com/bethlewisfit/?hl=en) **and** [**Michael Rintala**](https://rintalachiro.com/) **filmed instructional videos showing how to do various exercises**

- Peter can’t recommend them enough
  - It’s one thing to hear talk about the exercises, it’s quite another thing to see them and be able to do them yourself

**Videos from Peter:**

[Hip hinge (VMO)](https://www.instagram.com/p/B783YrVgfW7/):

[Deadlifts](https://www.instagram.com/p/B7RUUQugzFW/):

[Scapulae](https://www.instagram.com/p/B7JWOwJABSX/):

[Concentric intra-abdominal pressure](https://www.instagram.com/p/B3uJAXsAIk7/) (to stabilize the ribs):

**The importance of stability**

> “*Stability is the cornerstone upon which your strength is delivered, your aerobic performance is delivered, and your anaerobic performance is delivered.  And it’s the way that you do so safely*”‒ Peter Attia

- Stability is the way that we transmit force from the body to the outside world
  - In the safest manner possible
  - Across the muscles which are designed to carry that load
  - This is opposed to seeing the dissipation of force across joints that are not fit to do so
- Consider picking up something that weighs 60 lbs, you have to exert 60 lbs of force on the world around you (according to [Newton’s Laws](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion))
  - You want all of that 60 lbs to be transmitted from your muscle, to the ground, to this thing you are picking up
  - You don’t want anything dissipating out your back, knees, or hips
  - ***Most of us are born with the ability to do this naturally, but it generally gets lost by the time we begin grade school***
    - Why? A relative lack of activity and an abundance of sitting
- When Peter looks at his  2 ½ year old move, it’s a perfect clinic in force transmission safely across the body
- If you look at Peter move, prior to becoming obsessed with [dynamic neuromuscular stabilization (DNS)](https://www.rehabps.com/REHABILITATION/Home.html), you see inefficiencies and force leakage (at his scapula, his knee, his elbow, his back, his hips
  - ***This is one of the root causes of a lot of the chronic injuries many of us have***
- Stability is the foundation upon which all exercise should be done
- Recently Peter discussed this with a patient who had a question‒ *should she do DNS or continue with the pilates she’s done for many years?*
  - A great pilates teacher is already teaching many of these principles
- Stability is somewhat discipline agnostic but heavily dependant on the practitioner and the student

**The correct patterns of movement are characterized by the ability to:**

- 1 – Get air fully into your lungs
- 2 – Get your diaphragm low into your abdomen
- 3 – Flatten out your pelvic floor
- 4 – Generate concentric, robust, intra abdominal pressure that stabilizes every aspect of them
- [Postural restoration (PRI)](https://www.posturalrestoration.com/programs-courses/introductory-courses/postural-respiration), [DNS](https://www.rehabps.com/REHABILITATION/Home.html), and [pilates](https://en.wikipedia.org/wiki/Pilates) are all different ways one can learn these principles of stability

> “*Of the 4 pieces of exercise that we will talk about, this is the one [stability] that probably will take the most tinkering for people to find the right type of practitioner*s”‒ Peter Attia

## Peter’s current exercise routine [1:07:45]

From episode [#196 – AMA #32: Exercise, squats, deadlifts, BFR, and TRT](https://peterattiamd.com/ama32/); discussed from [3:00] – [6:00]

- In this last clip Peter talks about the macro structure of his current exercise routine
  - The macrostructure hasn’t changed much in the last year
  - The microstructure (exercises) has changed a lot
- ***Cardio days***‒ Tuesday, Thursday, Saturday, Sunday
  - 45 minutes of zone 2 training on Tuesday, Thursday, Sunday
  - Saturday is 1 of the following:
    - A zone 2 workout (45”) followed by zone 5 workout (30”)
    - A longer bike ride, more of an anaerobic workout
- ***Weightlifting***‒ Monday, Wednesday, Friday, Sunday
  - 9 months ago, he switched to an upper body/ lower body split
  - He used to lift 3 days a week, and do upper body and lower body everyday
  - Now he does lower body on Mondays and Fridays, and he does upper body on Wednesdays and Sundays
  - He always lifts AFTER doing cardio because the reverse has been shown to erode strength-training gains

**What happens if you miss a day?**

- Last Sunday was supposed to be a cardio/ ride followed by a lift day; but he was on the track all day
  - He knew that in advance, so he did the lift on Saturday
  - But he was short-changed on the zone 2 workout
- He will never compromise a lift; he will always get 4 lifts in per week
  - Sometimes it means moving the days around or doubling-up on another day

**Do you have a preference for the time of day to exercise?**

- Monday – Friday, this happens in the morning once the kids are out the door, off to school
- The weekends are more flexible

§

## Selected Links / Related Material

**What is Peter optimizing for with his exercise**: [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 10, 2020) |  discussed from [30:30 – 33:45]

**How to train for the “Centenarian Decathlon”**: [#50 – AMA #5: calcium scores, Centenarian Decathlon, exercise, muscle glycogen, keto, and more](https://peterattiamd.com/ama05/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 22, 2019) | discussed from [18:15 – 33:45]

**Study of genetics of centenarians**:

- [Institute for Aging Research:  Longevity Genes Project](https://www.einsteinmed.edu/centers/aging/longevity-genes-project/) | Albert Einstein College of Medicine | [20:15]
- [BU School of Medicine:  New England Centenarian Study](https://www.bumc.bu.edu/centenarian/) | Boston University | [20:15]

**The importance of preserving strength and muscle mass as we age**: [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 20, 2021) | discussed from [58:00 – 1:03:30]

**Review of loss of lean muscle and strength due to aging**: [Strength and muscle mass loss with aging process. Age and strength loss](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3940510/) | *MLTJ* (K Keller and M Engelhardt 2013) | [23:00]

**Kaplan-Meier curves**: [Strength, But Not Muscle Mass, Is Associated With Mortality in the Health, Aging and Body Composition Study Cohort](https://academic.oup.com/biomedgerontology/article/61/1/72/549632?login=false) | *The Journals of Gerontology series a* (AB Newman *et al.* 2006) | [24:15]

**Benefits of deadlifts**: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 6, 2020) | discussed from [42:00 – 51:00]

**Dynamic Neuromuscular Stabilization**: [The Prague School and Dynamic Neuromuscular Stabilization](https://www.rehabps.com/REHABILITATION/Home.html) | Rehabilitation Prague School (2022) [30:45]

**Episodes of** ***The Drive*** **on Dynamic Neuromuscular Stabilization**:

- [#131 – Beth Lewis: The Art of Stability: Learning about pain, mitigating injury, and moving better through life](https://peterattiamd.com/bethlewis/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 5, 2020) | [31:00, 43:15]
- [#152 – Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization (DNS)](https://peterattiamd.com/michaelrintala/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 5, 2020) | [31:00]

**Why Peter made zone 2 training a big component of his exercise regimen**: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 6, 2020) | discussed from [37:00 – 40:45]

**Episode of** ***The Drive*** **on Zone 2 training with Iñigo San-Millán**: [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 28, 2022) | [36:00]

**The most effective ways to engage in zone 2 exercise**: [#145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 18, 2021) | discussed from [14:00 – 18:30]

**Zone 5 and anaerobic training protocols**: [#153 – AMA #21: Deep dive into olive oil, high-intensity exercise, book update, and more](https://peterattiamd.com/ama21/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 15, 2021) | discussed from [49:30 – 55:30]

**Paper on the Tabata method**: [Tabata training: one of the most energetically effective high-intensity intermittent training methods](https://jps.biomedcentral.com/articles/10.1007/s12576-019-00676-7) | *British Medical Journal* (I Tabata 2019) | [51:15]

**Dive deep into VO****2** **max**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 1, 2021) | discussed from [38:00 – 49:30]

**Review of the limits of the respiratory system on VO****2** **max**: [Is the healthy respiratory system built just right, overbuilt, or underbuilt to meet the demands imposed by exercise?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7864246/) | *Journal of Applied Physiology* (JA Dempsey, A La Gerche, and JH Hull 1985) | [1:00:00]

**The lactate paradox, where maximum aerobic exercise at high-altitude generates less lactate than expected**: [The Lactate Paradox in Human High-Altitude Physiological Performance](https://journals.physiology.org/doi/full/10.1152/nips.01382.2001) | *Physiology* (PW Hochachka *et al.* 2002) | [1:02:15]

**The importance of stability**: [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 10, 2020) | discussed from [24:30 – 29:00]

**Peter’s current exercise routine**: [#196 – AMA #32: Exercise, squats, deadlifts, BFR, and TRT](https://peterattiamd.com/ama32/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 21, 2022) | discussed from [3:00 – 6:00]

§