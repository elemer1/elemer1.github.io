# #123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19

**Source:** [https://peterattiamd.com/joanmannick-nirbarzilai/](https://peterattiamd.com/joanmannick-nirbarzilai/)

---

##### Check out more content from Nir Barzilai, M.D:

- *(Jan 7, 2019)* [#35 – Nir Barzilai, M.D.: How to tame aging](/nirbarzilai/)
- *(August 10, 2020)* [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](/joanmannick-nirbarzilai/)
- *(April 25, 2022)* [#204 – Centenarians, metformin, and longevity](/nirbarzilai2/)

In this episode, Joan and Nir discuss their extensive research into rapamycin (including the category of analogs to rapamycin known as rapalogs) and metformin, respectively. Based on his work with metformin, Nir shares how he believes it could be a pro-longevity drug and the clinical trial he’s leading to test this belief. Joan discusses her work with rapalogs, their ability to suppress the immune system as well as provide immune-enhancement, and the clinical trials she has led that inform her insights. We also talk about the potential beneficial roles of both metformin and rapamycin in reducing mortality from COVID-19, reducing the risk of neurodegenerative diseases, and delaying aging as well as its related diseases.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/joanmannick-nirbarzilai/the_Drive_public.png)

Play

#123 - Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19

#123 - Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19

1x15s30s

0:002:17:59

## We discuss:

- Joan’s career, interest in aging, and work with rapamycin analogs [3:45];
- When Nir became convinced metformin could be a pro-longevity agent [15:00];
- How metformin and rapamycin impact the hallmarks of aging and extend lifespan [24:15];
- Enhancing the immune system with rapalogs and metformin [34:15];
- Potential of metformin and rapamycin in reducing mortality from COVID-19 [41:30];
- Insights from Joan’s studies investigating the immune-enhancing effects of rapalogs [59:30];
- Vaccines and treatments strategies for COVID-19, and the likelihood of long-term immunity [1:08:15];
- The potential role of rapalogs and metformin in neurodegenerative disease [1:14:30];
- Nir’s TAME trial—primary objectives and latest updates [1:18:00];
- Potential synergistic effect when combining metformin with rapamycin [1:25:45];
- Why Peter stopped taking metformin and started taking rapamycin [1:27:30];
- Story from Nir’s book that demonstrates the challenge of doing good scientific studies [1:37:30];
- The biology of aging—epigenetic clocks, proteomics, and Nir’s centenarian data [1:42:00];
- Joan’s dream experiment to test immune-enhancing effect of RTB101 [1:57:15];
- Concluding thoughts on COVID-19 [1:59:45]; and
- More.

§

## Show Notes

## Joan’s career, interest in aging, and work with rapamycin analogs [3:45]

**Early career**

- Started career in academic medicine after training in infection disease
- She was running a basic science lab when she had a transformative moment—
- She read a [review by Cynthia Kenyon](https://www.nature.com/scitable/content/a-c-elegans-mutant-that-lives-twice-47284/) in which she pointed out that genetic mutations in worms that cause doubling of lifespan suggests that organisms have the capacity to live longer than they normally do

“I just thought that was the coolest piece of research and the coolest idea that sort of threw medicine on its head.” —Joan Mannick

**Foray into aging research**

- She began doing aging research in her lab after that
- Eventually moved to [Novartis](https://www.novartis.com/) in a group called the New Indications Discovery Unit
- Despite reservations at first, Novartis agreed to let Joan “work on aging”
- Novartis already had a rapamycin analog, and there was data that mTOR inhibitors have beneficial effects on aging and lifespan
- Joan thought the **immune function** was an area where you could see improvement in a relatively short period of time
- In 2014, Joan did a [trial](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly) giving older adults an mTOR inhibitor to see if they could make their immune function better

*Given that the clinical application for rapamycin was immune suppression—what made Joan think that you could actually use the same drug to enhance the immune response to a vaccine?*

- Because of all the data that [mTOR inhibition has beneficial effects on aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) and every organism tested
- The [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) (interventions testing programs) run through NIH showed inhibition of mTOR could **extend the life of mice** ([Harrison et al., 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/); [Miller et al., 2011](https://pubmed.ncbi.nlm.nih.gov/20974732/))
- This was enough for Joan to feel that “S*omeone’s just got to do the trial in humans and see if this is true in humans*”

[**Joan’s 2014 paper at Novartis**](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)

- Knowing that the only way this will ever move forward is if the drug was safe and did not suppress the immune system, they started with a very low dose with intermittent dosing
- They were looking to see if the patients had an enhanced immune response to the flu vaccine

*-Study details*

- The drug used was RAD001 (a.k.a. [everolimus](https://en.wikipedia.org/wiki/Everolimus))
- The doses given to the 4 different arms—
  - 1) Placebo arm
  - 2) 0.5 mgs of RAD001 daily
  - 3) 5 mgs once a week
  - 4) 20 mgs once a week
- The goal was to partially inhibit mTOR, because when you *completely* inhibit mTOR, you stop T cells from proliferating and you’ll get immunosuppressed

*-The ending observations*:

- - The two lower doses (0.5 mgs daily and 5 mgs once a week) were the best
  - Turning mTOR down (not off) in the elderly is the best for enhancing immune function

## When Nir became convinced metformin could be a pro-longevity agent [15:00]

- The normal clinical indication of metformin is an early-line treatment for patients with type 2 diabetes
- While at Yale doing his first postdoc with [Ralph DeFronzo](https://www.uthscsa.edu/patient-care/physicians/providers/1851408843/Ralph-DeFronzo), Nir spent the year looking for the mechanism of action of metformin (which wasn’t yet being used in the US)
- In 1991, Nir’s [study](https://pubmed.ncbi.nlm.nih.gov/1955512/) was the first to show that metformin specifically targets hepatic glucose production — aka the insulin sensitivity of the liver much more so than the muscle
- Metformin finally began gaining more interest in the US after the [DPP](https://care.diabetesjournals.org/content/25/12/2165) found metformin was people from developing diabetes
- There were also many [association studies](https://www.sciencedirect.com/science/article/pii/S1550413116302297#bib76) with all kinds of cancer as well as Alzheimer’s disease and MCI
- **The turning point for Nir** came when he read a [paper](https://pubmed.ncbi.nlm.nih.gov/25041462/) showing that people on metformin, even those who were diabetic and obese, had less mortality when compared to control patients without diabetes who were not taking metformin

⇒ Nir’s 2016 paper talking about the UKPDS and DPP papers: [Metformin as a Tool to Target Aging](https://www.sciencedirect.com/science/article/pii/S1550413116302297#bib76)

> “And all of a sudden we have everything. We have all ages, all the old age-related disease, clinical association studies, we’d have mortality. That just made metformin the perfect tool for us to push geroscience ahead.” —Nir Barzilai

**ITP studies**

*What is the ITP?*

- The [interventions testing program](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/compounds-testing) is a multi-institutional program established to test diets, supplements, and drugs purported to extend lifespan and delay disease and dysfunction to evaluate whether or not there is an effect on longevity
- See this [paper](https://onlinelibrary.wiley.com/doi/10.1111/j.1474-9726.2007.00311.x) describing how the ITP studies are designed
- You have a committee, you get the drug, you have animals who are genetically **heterogeneous**, they animals get the drug in the same was in three different centers around the United States so that we have a standard way to say “yes or no” to whether it’s pro-longevity

In [cohort 7](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/), they tested metformin alone, and metformin *plus* rapamycin, in mice—

- Metformin only:
  - In two of the centers, the mice they lived longer (13% and 10%)
  - But in the third center, mice lived 1% **less**
- Metformin plus rapamycin:
  - Mice had a 23% increase in lifespan
  - These are the **longest-living** animals so far in the ITP

ITP studies for rapamycin alone—

- In [cohort 2](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/), mice given **rapamycin alone** starting at 20 months of age extended lifespan by 14% in females and 9% in males
- In [cohort 3](https://pubmed.ncbi.nlm.nih.gov/20974732/), mice given rapamycin alone starting at 9 months of age extended lifespan by 10% in males and 18% in females
- See the ongoing ITP studies looking at rapamycin: [The Rapamycin Phase II Study – Tissues Available for Collaborative Studies](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/rapamycin-phase-ii-study-tissues-available)

*The lack of enthusiasm about metformin for longevity*

- In the metformin alone ITP studies, 1 of the 3 sites showed no improvement of lifespan
- This means there are now people who are not impressed with metformin as a longevity agent
- \*But Nir makes the following point: **It’s a little bit too late to discuss mice now, because we have all this data in humans. It’s possible that metformin will have a better effect in humans than in mice.**

## How metformin and rapamycin impact the hallmarks of aging and extend lifespan [24:15]

Nir’s recent paper in Cell Metabolism: [Benefits of Metformin in Attenuating the Hallmarks of Aging](https://pubmed.ncbi.nlm.nih.gov/32333835/)

![](https://peterattiamd.com/wp-content/uploads/2020/08/metformin-hallmarks-of-aging-1024x553.png)

**Figure 1. Mechanisms of metformin action in attenuating hallmarks of biological aging—The cellular uptake of metformin is via the organic cationic transporter 1 (OCT1), after which it exerts three arms of action- 1) metabolic; 2) oxidative and 3) inflammatory. 1) Metformin inhibits mitochondrial complex I and thereby oxidative phosphorylation leading to an increased AMP:ATP ratio, causing a direct activation of AMPK. AMPK-dependent mechanisms (blue) contribute to the downstream inhibition of mTORC1 (improved nutrient-sensing and autophagy), activation of PGC-1α (improved mitochondrial biogenesis), transcriptional regulation via DNA/histone modifications and miRNAs. Extracellularly, metformin downregulated Insulin/IGF1 signaling, also leading to mTORC1 inhibition. 2) The inhibition of mitochondrial ETC also leads to AMPK-independent effects (red) including reduced reactive oxygen species (ROS), reduced advanced glycation end-products (AGEs) and thereby reduced macromolecular damage. 3) The AMPK-independent (red) anti-inflammatory and senotherapeutic effects of metformin are evident via the downregulation of pro-inflammatory cytokines, NF-κB signaling, and activation of Nrf2-Gpx7 and ATM-signaling, respectively. These three arms work to mitigate the aging-induced dysregulation in cells, thereby attenuating hallmarks of aging.** Image credit: [Kulkarni et al., 2020](https://pubmed.ncbi.nlm.nih.gov/32333835/)

**How Metformin is working for longevity**

- Nir does NOT believe metformin *independently* targets all of the hallmarks of aging
- Let’s say that, on the cellular level, it fixes aging
- And once it fixes cellular aging, a lot of things improve
- For example, maybe the fact that insulin levels go down doesn’t ONLY have to do with metformin’s effect on glucose, but because…
  - Autophagy has increased
  - Mitochondrial function is better
  - Genetic stability is good
  - Etc.
- After an experiment where you see so much effect, some might say it’s all epigenetics, but the question is: **Did metformin do it? Or is it what metformin did on aging that created the effects?**

**Three major arms of metformin**

1. Metabolic—targets [complex I in the mitochondria](https://en.wikipedia.org/wiki/Respiratory_complex_I#:~:text=Complex%20I%20is%20the%20first%20enzyme%20of%20the%20mitochondrial%20electron%20transport%20chain.&text=Complex%20I%20is%20the%20largest,NAD%2B%20%2B%20CoQH2%20%2B%204H) which increases [AMPK](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase#:~:text=5'%20AMP%2Dactivated%20protein%20kinase,when%20cellular%20energy%20is%20low.) and targets the [mTOR pathway](https://en.wikipedia.org/wiki/MTOR)
2. There’s a decrease in oxidative stress ([ROS](https://en.wikipedia.org/wiki/Reactive_oxygen_species) production) and a decrease in DNA damage (a consequence of using a low dose of a mitochondrial poison)
3. The relationship to immune function and inflammation

> “We have the clinical data on metformin, but I wouldn’t tell you what exactly is the most relevant target in the whole.” —Nir Barzilai

**Mechanisms for how rapamycin (and rapalogs) might extend lifespan**

1—[**Less protein and lipid synthesis**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4402229/) which may decrease proteotoxic stress just by having less proteins made that your protein degradation system has to deal with

2—**Autophagy**, however, rapalogs don’t consistently induce autophagy

- It’s cell-dependent—so how much of a role autophagy has in the benefits of rapalog is probably tissue-dependent
- In many cell lines, there’s no induction of autophagy
- In the few cell lines that do have induction of autophagy, it’s hard to distinguish the tissue of origin (e.g., Is it the liver versus the cells from neurons?)

3—[**Regulation of the SASPs**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6121351/) (similar to metformin)

- Senescent cells accumulate as we age resulting in the secretion of inflammatory cytokine
- Inhibiting mTOR will decrease SASPs, which will decrease systemic inflammation

## Enhancing the immune system with rapalogs and metformin [34:15]

**Why immune enhancement matters**

- From a longevity standpoint—
  - Anything that you can do that’s going to enhance the immune system at the adaptive level (which is what you’re getting out of a vaccine) is going to help with cancer surveillance
  - Prior to COVID-19, Peter’s thought was that the real reason we want to have enhanced immunity is to delay the onset of cancer
- Today, there’s a heightened focus on coronavirus as well as influenza which makes enhancing immunity more relevant to the present moment

**Immune enhancement via rapalogs**

*Why did T cells get better at recognizing an antigen when a patient was pulsed with a drug that is inhibiting senescent cells?* (Tissue specific or cell specific autophagy? Reduction in protein synthesis and lipid synthesis?)

- It’s going to be complicated, says Joan
- But one of the factors and how you respond to a vaccine is actually [innate immunity](https://en.wikipedia.org/wiki/Innate_immune_system) —  you need innate immunity to bring in the adaptive T and B cells to respond to antigen

*Where some of the issues lie for the elderly population—*

- They have a [defect in type I interferon production](https://stke.sciencemag.org/content/10/509/eaan2392) after getting a flu vaccine
- There are all sorts of stimuli to the innate immune system that should induce interferon, but there’s a [defect in immune cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4506866/)
- With aging comes exhaustion of T cells — but with mTOR inhibition, there’s a [decrease in exhausted T-cells](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly) in older humans (Tyler Curiel [showed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4693453/) the same thing in older mice)

*Possible solutions?*

- Joan has shown that with mTOR inhibitors, you can [enhance interferon production](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20) in interferon induced gene expression
  - In other words, you are enhancing the innate immune function which is helping the adaptive immune system work better when you get vaccinated
- When you give an mTOR inhibitor, in particular a rapalog, T cell exhaustion decreases
  - Joan says that they don’t yet know the mechanism for that

NOTE: You can’t just give IV interferon because

- 1) it’s dangerous, and
- 2) It’s not the interferon per se, it’s that the lack of interferon is a proxy for a failure to recognize in the first place

*What did Joan learn about this in her* [*2014 paper*](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)*? Did they look only at T cell or also B cell assays? Did you look at neutralizing antibodies and T cell killing?*

- They only looked at hemagglutination inhibition (HI titers)
- Didn’t look at neutralizing antibodies and didn’t look at T cell function
- They looked at shifts in 76 different peripheral blood subsets—the rapalogs didn’t shift any of the subsets very much, except there was about a 25 to 30% decrease in the PD1, CD4, and CD8—the exhausted T-cells that accumulate with age
- The fact that these go down may indicate another part of the adaptive immune system that’s getting improved from the rapalog

**Immune benefits of metformin**

*When did it become apparent to Nir that metformin had immune benefits?*

- In the 40s-60s, metformin was used around the world for influenza in the elderly
  - The literature is in Czech and Swedish and Philippines—with little translation to date—but all of them were positive responses to using Metformin as an immune enhancer against the flu, malaria, and some other indications
- Patients with type 2 diabetes who were taking metformin [immunized better against the flu](https://www.webmd.com/diabetes/news/20090603/diabetes-drug-makes-vaccines-work-better)

## Potential of metformin and rapamycin in reducing mortality from COVID-19 [41:30]

In the case of COVID-19, we need a drug that will—

- Enhance immune function
- Decrease the cytokine storm/inflammatory response
- Help the elderly body sustain a severe disease (i.e., be tough when faced with severe disease)
- Additionally, you probably wouldn’t just increase their immunity by 10 to 20%, you would **reduce their comorbidities first and foremost**

**Metformin and rapamycin**

- These drugs can reduce comorbidities—and by doing so that may confer the mortality benefit as much so as their ability to enhance the immune system
- It’s also important to note that the reduction in comorbidities and the enhancement of the immune system are NOT **dependent** on each other

**Diabetics on metformin vs. diabetics NOT on metformin**

A [paper from China](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7356425/) looked at 283 diabetic patients with COVID-19

- 104 of them came to the hospital already taking metformin
- 179 of them were not taking metformin
- Just **2.9%** of people on metformin died versus **12.3%** of the to no-metformin group who died

![](https://peterattiamd.com/wp-content/uploads/2020/08/Luo-et-al.-2020.png)

**Figure 2. Although no significant difference was found in the hospital stays between two groups (P = 0.74), the in-hospital mortality of 2.9% (3/104) in the metformin group was markedly decreased compared with the mortality of 12.3% (22/179) in the no-metformin group (P = 0.01).** Image credit: [Luo et al., 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7356425/)

- It’s also worth noting that the use of metformin in China for diabetic people is between 60 and 70% — yet, the most people who were hospitalized were NOT using metformin
  - The implication of this observation is potentially that
    - i) the diabetics on metformin were less likely to need to go to the hospital (or maybe even get COVID-19 at all), and
    - ii) The mortality from COVID-19 probably had more to do with the cytokine storm/inflammatory response, or with their ability to handle severe disease, than it did with the immunization

**Contrasting influenza with COVID-19**

- The main train of thought about how influenza kills people used to be that it can paralyze the immune system making the individual more susceptible to other infections such as a bacterial infection
- However, Joans says that may not be the case
- There is now some debate around that due to a [2015 NEJM paper](https://www.nejm.org/doi/full/10.1056/NEJMoa1500245) which looked at what actually causes pneumonia in the elderly that gets them hospitalized
  - And it’s not mainly because of a combination of virus and bacteria (that is some of it) but **the majority is the virus itself**
  - The most common virus is actually rhinovirus—the cause of the common cold
  - The elderly just can’t handle viruses the same way as younger people do — and they can die **without** getting bacterial superinfection
  - The virus itself causes damage, and then the immune response to the virus also causes damage

*How does that impact our thinking about SARS-CoV-2?*

- It causes much more direct damage to the pneumocyte, therefore to the end organ
- Do we believe that at the immunologic response level, it is eliciting a much more toxic autoimmune response or cytokine response than say influenza?
- The coronavirus infects cells, including lung cells, and that causes direct damage from the virus
- The host response to the virus is generally a good thing because it will get rid of the virus
- However, if it gets excessive, you’ll get a cytokine storm which will cause major life threatening consequences **independent of the virus**
- **The hypothesis**: If you can enhance the ability of the host to get control of the virus very early on and quickly, then you won’t be susceptible to the cytokine storm and you will stay with mild disease

**How a rapalog could reduce the risk of succumbing to COVID**

*Where a rapalog has the greatest potential to reduce the risk of succumbing to COVID?*

- In people taking mTOR inhibitors, they’re [innate antiviral gene expression is enhanced](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/) *when they get a viral infection*
- This suggests that early on after exposure to the virus, the rapalog may have benefit by boosting the body’s response to the virus so we can clear it better and prevent severe symptoms

![](https://peterattiamd.com/wp-content/uploads/2020/08/increase-in-antiviral-gene-expression-1024x573.png)

**Figure 3. RTB101 increased antiviral gene expression.** Image credit: [Mannick et al., 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/)

**How metformin could reduce risk of succumbing to COVID-19**

- First, the [China cohort](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7356425/) suggests that the people taking Metformin were disproportionately less severely ill, and therefore less likely to end up in the hospital
- Additionally, Nir started his own study at Einstein after he got emails from physicians in Spain and Italy who noticed the same thing for patients on metformin

*A possible mechanism? ⇒* [**Recent study published in medRxiv**](https://www.medrxiv.org/content/10.1101/2020.06.19.20135095v2)

- (caveat=study is not reviewed and lacks details)
- The study had access to data on over 6,000 patients through the University of Minnesota

–*2 things stand out from the study—*

- Women on Metformin have 21% less mortality to COVID-19
- Even more important, they had an 80% decrease in plasma TNF alpha levels — so there’s a kind of a link to the **inflammatory response**

Peter’s takeaway

- There’s no indication that metformin alters ACE-2 expression
- So any benefits that you’re describing that turn out to be real are either based on—
  - Immune enhancement; or
  - Immune modulation
- I.e., You’re turning up the immune system when you want it to be turned up or toning it down when you need it to be toned down

Nir’s take:

- Nir thinks it’s doing both (turning up the immune system when you want it to be AND toning it down when you need it to be)
- Two ways metformin helps—
  - 1) Less people on metformin are hospitalized (i.e., their immunity is better)
  - 2) When they’re in the hospital, less of them go into an inflammatory response
- Caveat – the [China cohort data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7356425/) doesn’t tell the whole story—it just looked at outcomes (i.e., deaths), so Nir says not to make too much of it
- \*His point is this: We really need to look at several issues: i) the immune response, ii) the cytokines, and iii) the ability of the body to sustain severe disease

*But wouldn’t the patients be taken off metformin when they arrive in the hospital?*

- Yes, says Nir
- But there are still [lingering effects even after going off metformin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5847877/) — “*When you substantially change the aging phenotype of a cell [with metformin] it’s not that you stop and it goes back to old. So I think it’s okay five days later, it can still be effective.*”
- Metformin should be used to prevent, not treat, COVID-19

> “People should get metformin to prevent COVID-19, not to treat COVID-19.” —Nir Barzilai

**Rapalog and the prevention of mortality from COVID-19**

*Prevention of infection*

- First, there is some data that mTOR inhibitors may interact directly with SARS-CoV-2 and inhibit replication—a direct antiviral effect that’s seen with CMV and BK virus in transplant patients where they have lower CMV and BK viral infections, probably because of a direct effect of mTOR inhibition
- *Any evidence of that in the other four coronaviruses that commonly occur?*
  - No, but there have been a bunch of transcriptomic, metabolomic, proteomic, big data analyses that have identified mTOR and rapalogs as potential drugs that would interfere with the replication of SARS-CoV- 2 ([see this article](https://www.frontiersin.org/articles/10.3389/fphar.2020.00856/full))

*Enhanced immune function to prevent severe disease*

- In Joan’s [2019 phase 2b study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/) with [RTB101](https://www.lifespan.io/road-maps/the-rejuvenation-roadmap/restorbio-rtb101)
  - They looked at 17 different viruses that caused respiratory tract infections in older people (4 of which were the common coronaviruses)
  - They saw was that mTOR inhibitors upregulated antiviral gene expression which reduced
    - i) the incidence of coronavirus infections, and
    - ii) the severity of coronavirus infections

![](https://peterattiamd.com/wp-content/uploads/2020/08/summary-of-phase-2-studies-RTB101-1024x558.png)

**Figure 4. Phase 2 studies showing the ability of RTB101 to decrease the incidence and/or severity of respiratory tract infections.** Image credit: [resTORbio.com](https://www.restorbio.com/)

## Insights from Joan’s studies investigating the immune-enhancing effects of rapalogs [59:30]

[**2014 Novartis study using rapalog (RAD001)**](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)

- Looked at the ability of rapalogs to enhance the response to the flu vaccine
- Noticed that the people who were getting the rapalog were reporting fewer respiratory tract infection as adverse events (not just the flu, but all respiratory tract infections)
- These results brought forth the idea that if rapalogs were enhancing the immune system, it’s not going to be enhancing just the response to a flu vaccine, but also would *enhance the response to all sorts of different pathogens*

[**Phase 2 study in 2018**](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.)

*They wanted to explore the following*:

- If mTOR inhibitors really do enhance immune function, this shouldn’t be specific to a rapalog—a drug inhibits mTOR by changing the conformation of mTOR (an allosteric inhibitor)
- There are other kinds of mTOR inhibitors which block the catalytic site (catalytic inhibitor) and they should also have benefits if this is really an *mTOR-mediated* effect

*In the study, the drugs used included*:

- An allosteric inhibitor—a rapalog called RAD001, aka [everolimus](https://en.wikipedia.org/wiki/Everolimus)
- A catalytic inhibitor—BEZ235, aka RTB101
- And they used them both together

*What they were looking at*:

- They looked not only at vaccine response, but at infection rates for a whole year in the elderly

*NOTE about dosing equivalents of rapalog and* [*RTB101*](https://www.lifespan.io/road-maps/the-rejuvenation-roadmap/restorbio-rtb101):

- The rapalog, RAD001, given at 0.5 mg daily, and also when given at 5 mg weekly, inhibited TORC1 but not TORC2
- RTB101 has a comparable TORC1 inhibition to the 0.5 mg daily of RAD001
- RTB101 has a shorter half life (4-6 hours) than RAD001 (everolimus)

**Summarizing studies looking at RTB101**

Joan did two phase 2 studies using RTB101 alone and in combination with everolimus

- In the first study [[2018 phase 2a Novartis study](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.)], the combination looked the best when you dosed it for just 6 weeks
- In the second study [[2019 phase 2b study by resTORbio](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/)], they extended dosing for 16 weeks in a sicker population, and the RTB101 alone was better
- In both studies—
  - RTB101 alone decreased respiratory tract infections
  - The combination decreased respiratory tract infections in the 2018 study but not in 2019 study

![](https://peterattiamd.com/wp-content/uploads/2020/08/reduction-in-RTI-1024x594.png)

**Figure 5. RTB101 reduces the incidences of respiratory tract infections caused by multiple viruses including coronavirus.** Image credit: [resTORbio.com](https://www.restorbio.com/)

[PROTECTOR study](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-phase-3-protector-1-trial-rtb101-clinically) — the 2019 phase 3 study by resTORbio

- This study used RTB101 alone
- This study failed to meet its endpoint
- Joan explains why it failed…
  - The FDA did not want the endpoint to be *laboratory-confirmed* respiratory tract infections (which is where Joan had previously seen the benefit of RTB101)
  - The FDA argued that people don’t care if a respiratory tract infection is laboratory-confirmed, all they care about is how they feel and function (e.g., their symptoms)
  - The FDA demanded that they show you can decrease respiratory symptoms that are consistent with a respiratory tract infection, but they don’t have to be due to a respiratory tract infection
  - The study “failed” because they couldn’t decrease the **total** respiratory symptoms that the elderly have
- *Why did they show?* ⇒ RTB101 was able to **decrease the** ***severity*** **of the symptoms**

> “I think what the mTOR inhibitors are doing is not stopping people from getting infected, but if you get infected, there’s a better immune response and your symptoms will be milder.” —Joan Mannick

**What resTORbio is looking at now with respect to COVID**:

- resTORbio is doing a [trial in nursing homes](https://clinicaltrials.gov/ct2/show/NCT04409327?term=restorbio&draw=2&rank=1) now looking at severity and not just incidence of infection
- Joan’s thought as to why people are having less severe symptoms: “*Once you get infected, you’re better able to* ***upregulate the interferon-induced, innate immune response*****”**

## Vaccine and treatment strategies for COVID-19, and the likelihood of long-term immunity [1:08:15]

**Vaccines must be developed to be safe and effective in the elderly**

- Nir says that with rapamycin and metformin, the goal is to **reinforce the host**, not to fight the virus
- Who are the people that are dying from COVID? — It’s the older people
- What matters is people’s age, and more specifically, it’s their **biological age**
- Multi-morbidity is a risk factor — but all that really means is how old you are, *biologically*
- This is not only important for metformin and rapamycin’s relevance, it’s also important for how we are **developing vaccines**
- Nir says the vaccines being developed are not considering the older host
- The New York Times [reported](https://www.nytimes.com/2020/06/19/health/vaccine-trials-elderly.html) that many vaccines aren’t being tested in people over the age of 65

> “I think the vaccine is going to be such a trap. And the way to go over that is either realizing how to do it with the biology of aging. . .or the elderly have to be on metformin or a rapalog in order to get their immunity going. I think this is the next disaster. If we have a vaccine that doesn’t protect the elderly, we did nothing.” —Nir Barzilai

**Another vaccine concern—*****Is long-term immunity even possible?***

- It’s common to have only a year or less of immunity to other versions of coronavirus after being infected
- So there’s a legitimate concern that a vaccine for COVID-19 will not be enough to create herd immunity in the long run
- “*The probability then that a vaccine is going to provide lifelong immunity the way we get it from several of our most famous vaccines, seems quite low*.” says Peter
- Now we have a fifth coronavirus that’s here to stay, but unlike its other four cousins, this one can really whack you
- We NEED a better strategy around **immune enhancement and immune-targeted therapies for the most immune-vulnerable** (e.g., monoclonal antibodies)

⇒ See [Link to episode of The Drive with David Watkins](https://peterattiamd.com/davidwatkins/) for more on monoclonal antibodies, and vaccine strategies for COVID-19

**A new awareness on the importance of immune enhancement**

- Joan says the one positive from the COVID-19 pandemic is that it’s created an awareness that immune enhancement is an important issue
- Prior to this pandemic, nobody really cared about respiratory tract infections, they cared about cancer and other rare diseases
- But not Joan says there’s “bandwidth” to see if they can figure out the efficacy of rapalogs for immune enhancement to stop things like severe infections to COVID-19

## The potential role of rapalogs and metformin in neurodegenerative disease [1:14:30]

**Parkinson’s disease and rapamycin**

- For Parkinson’s disease—and other neurodegenerative diseases—there’s an accumulation of toxic protein aggregates
- If you enhance autophagy in preclinical models that has benefit
- Rapalogs aren’t great at inducing autophagy, but [RTB101](https://www.lifespan.io/road-maps/the-rejuvenation-roadmap/restorbio-rtb101) at high doses is very good at inducing autophagy although it’s hard to achieve those concentrations *in the brain*
- But… if you combine a rapalog with RTB101, you can *lower the concentration of RTB101 that’s needed to induce autophagy* so you don’t have to get so much across the blood brain barrier
- That was the logic behind [resTORbio’s ongoing trial](https://www.restorbio.com/clinical-trials/) which is using that combination for Parkinson’s disease

⇒ Matt Kaeberlein [wrote a piece](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6762017/) explaining the potential to both ameliorate and potentially clean up a lot of the protein aggregation/disaggregation that’s occurring in the central nervous system (CNS)

![](https://peterattiamd.com/wp-content/uploads/2020/08/nihms-1028054-f0001.jpg)
**Figure 6. mTOR links aging and AD—The top part of the figure depicts the involvement of mTOR in key processes common to aging. These hallmarks of aging contribute, in different degrees, to an increased risk for AD and other age-associated neurological diseases, as well as cognitive decline during normative aging. Rapamycin and other pharmacological interventions that attenuate mTOR activity may be beneficial for delaying the progression of AD and other age-associated dementias, as well as for preserving brain function in the healthy elderly.** Image credit: [Kaeberlein and Galvan, 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6762017/)

**The role of metformin in the risk reduction for Alzheimer’s**

- Anything that normalizes glucose and insulin, as metformin does, is going to have a direct benefit on dementia and mild cognitive impairment (MCI)

*Is there any direct data that suggests that metformin should be a part of the toolkit to reduce the risk of Alzheimer’s disease?*

- Not directly, says Nir
- However, there are two NIH funded projects that will take a couple of years to look at people with MCI
- [One study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5079271/) looking at MCI and metformin showed decreased deterioration in *some* of the domains of Alzheimer’s disease

For the studies that DON’T show improvement, Nir offers these possible explanations—

- One, they’re from China so either it’s not similar mechanisms, or the genetics and environmental interaction somehow
- Secondly, and more likely…
  - Metformin delays mortality by 20% which therefore means you’ll get more people on metformin living longer
  - So it might just be the number of the people on metformin that have Alzheimer’s increases because they are hanging around longer.
- \*This is why **we need clinical studies and not association studies**\*

## Nir’s TAME trial—primary objectives and latest updates [1:18:00]

**Nir on metformin and rapamycin**

- Nir said he decided to focus his research on metformin NOT because it was the “best drug”
- In fact, he believes rapamycin will a better longevity agent
- But he chose metformin because his ultimate goal is to advance the field of preventing age-related diseases
- And because there was more data about the safety of metformin compared to rapamycin, he felt like it was the better path to advancing the field

**Update on Nir’s** [**TAME studies**](https://www.afar.org/tame-trial#:~:text=The%20Targeting%20Aging%20with%20Metformin,the%20ages%20of%2065%2D79.)

- Part of the problem with TAME is that there’s no commercial interest
- Metformin is a very cheap drug (cheaper than a placebo pill)
- So nobody wants to pay for a Phase 3 study for five years
- The [American Federation of Aging Research](https://www.afar.org/) (AFAR) is a group of people from a non-profit and non-industry that is supporting TAME

*TAME has 3 arms:*

 1—Prevention of age-related disease and mortality

- This is the primary outcome/FDA outcome
- This will cost about $35 million coming via the AFAR grant

 2—Identifying biomarkers

- They are going to make sure that they know what are the biomarkers for metformin action and for aging
- This was funded by the NIA in order to take plasma and blood, DNA, and anything they need to be able to do omics and other things and find biomarkers

 3—The geriatric part

- How many hospitalizations? What’s the ADL? The frailty index? Etc.
- This could be done at the very end looking at the people with **metformin vs. without metformin**
- This hasn’t yet been funded

Other aspects of TAME:

- 3,000-3,500 subjects
- [14 trial centers](https://www.afar.org/tame-trial#tametrialsites)
- They will also be able to look at immunity enhancement – for the flu vaccine and perhaps the future COVID-19 vaccine in 2021

## Potential synergistic effect when combining metformin with rapamycin [1:25:45]

There’s not a huge amount of mechanistic overlap between metformin and rapalogs, says Peter

Rapalogs—

- [Impairing synthesis of proteins](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4402229/)
- [Inhibiting SASPs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6121351/)
- Some autophagy (depending on the way that you inhibit and/or the tissue)

Metformin—

- Metabolic benefits such as normalizing glucose and insulin
- Decreases oxidative stress
- Decreases inflammation

*Could there potentially be a benefit in combining metformin with a rapalog?*

- “*I don’t think we know enough, yet*.” says Joan
- However, the [ITP study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) that used both did show a large, positive effect on lifespan of mice
- Joan has looked at people who were getting the rapalogs or [RTB101](https://www.lifespan.io/road-maps/the-rejuvenation-roadmap/restorbio-rtb101) who are on or off metformin, just to see if I could see a difference, but we’re way **under powered** so she can’t say anything definitive yet
- Need to understand side effects—
  - Every drug that has a biologic effect has a side effect so if you use two drugs that have a biological effect, you’re just going to get more side effects
  - We’ve got to make sure that the benefits are outweighing the risks
- **Example**, if both of rapalog and metformin are enhancing autophagy
  - That could be synergistic and a good thing
  - However, if the patient has cancer, we would want to stop autophagy

⇒ See [episode of The Drive with Eileen White](https://peterattiamd.com/eileenwhite/) for more on cancer and autophagy

## Why Peter stopped taking metformin and started taking rapamycin [1:27:30]

⇒ Check out Peter’s emails on this topic: [Metformin and exercise](https://peterattiamd.com/metformin-and-exercise/) and [Metformin and exercise – déjà vu all over again?](https://peterattiamd.com/191013/)

- Started taking metformin 2010
- 2,000 mg per day
- Experienced nausea for about 2 months (then no side effects beyond that)
- In retrospect, he should have started at 500 mg and worked his way up
- With his patients, Peter typically titrates up the dosing over time:
  - For example, 500 mg before bed ⇒ 500 mg BID (twice per day) ⇒ 1,000 mg at night, and so on

***Why did he stop taking metformin?***

*1—Lactate levels*

- He stopped after he looked closely at his lactate levels during [Zone 2 exercise](https://peterattiamd.com/ama12/) (and at baseline)
- Zone 2 means keeping lactate below 2.0 millimole (basically trying to see how much work you can do under purely aerobic conditions)
- Peter was very surprised at how high my lactate levels were at baseline–about 1.6 millimole
- After talking with [Iñigo San Millán](https://twitter.com/doctorinigo?lang=en) (previous [podcast guest](https://peterattiamd.com/inigosanmillan/)), Peter did self testing and found that the metformin was indeed increasing his lactate levels (which makes sense given it’s a mitochondrial toxin)
- NOTE: Peter’s concern was not at all lactic acidosis—
  - It was about his mitochondria being less efficient as someone who is exercising frequently
  - In other words, as someone who is metabolically healthy and maximizing the dose of exercise, it did not seem like there was any additional benefit that comes from metformin

2—*After reading about the results from the* [*MASTERS*](https://onlinelibrary.wiley.com/doi/full/10.1111/acel.13039) *trial (Peter summarizes the takeaways from this trial* [*here*](https://peterattiamd.com/191013/)*)*

- This trial looked at the effects of metformin on the response to progressive resistance training (PRT) in relatively healthy seniors age 65 and older
- While all the subjects had an increase in muscle mass following a 14 week exercise intervention, the group on metformin had less gains
- This suggests that metformin might be blunting hypertrophy (muscle mass growth)
- In Peter’s [article](https://peterattiamd.com/191013/), he speculates the reason for this: “*The anti-inflammatory and antioxidant effects of metformin are disrupting the body’s adaptive response to the pro-inflammatory and reactive oxygen species (ROS)-promoting effects and the biological signals they elicit.*”

*But what about muscle strength and function?*

- Nir pushes back on the idea that metformin is “bad” for exercise
- He points out that while the metformin group had less muscle mass growth, the **function was actually the same**
- In other words, the metformin group is doing better work **per gram of muscle** compared to the placebo group
- Nir says the story is different if you look at the transcript data—
  - Metformin is decreasing mTOR, and exercise is increasing mTOR, so all the mTOR transcripts were higher in the exercise-only group and were blunted by metformin
  - Per Nir, 516 of the transcripts were different between them and they were only in the metformin group.
  - And those were the transcripts that we want to see with aging, such as transcripts for autophagy
- **Nir’s main point****s**:
  - In this elderly population, metformin kept the young profile of the muscle
  - At the end, maybe you had less muscle, but you had the same function, and you gained by metformin protecting 500 transcripts that are aging transcripts

**Peter says his main question about metformin and exercise is the following**:

*If you are metabolically healthy and you are maximizing the dose of exercise, is there additional benefit that comes from metformin?*

*Or is this a drug that is better reserved for people who are not taking the maximum dose of the drug known as exercise?*

- Nir’s answer: **There’s an independent [positive] effect of metformin when you’re exercising, at least in people older than 70.**
- Nir says this is why he is personally taking 1,500 mg per day of metformin and exercising daily

**Peter’s experience with taking rapamycin**

- In 2011/2012, Peter knew he wanted to start taking rapamycin based on just the data in the mice, yeast, flies, worms, etc.
- His biggest concern was immune suppression
- And it was still unclear as to how to dose it
- But then, Joan’s [2014 paper](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly) was published giving him more confidence that it was safe
- Joan’s paper suggested 5 mg once a week was a pretty good place to start
- Peter triangulated that data with data from [Matt Kaeberlein’s dogs](https://dogagingproject.org/about-project/)
- He settled on **6 mg once a week**
- What still remains unclear for Peter is ***how to cycle it***
  - Current protocol is—on for 8 weeks, off for 5 weeks
  - “*But, truthfully, without more advanced testing, I’m really making it up and therefore I don’t like talking about it like I just did*.”
- Side effects:
  - Aphthous ulcers, but mostly just at the beginning during an acclimation period
  - Fingernails grow slower
  - Other than those observations, Peter says he doesn’t “feel” anything while taking it

## Story from Nir’s book that demonstrates the challenge of doing good scientific studies [1:37:30]

\*The following is a story from Nir’s new book: [Age Later: Healthspan, Lifespan and the New Science of Longevity](https://www.amazon.com/Age-Later-Healthiest-Sharpest-Centenarians/dp/1250230853)

- Nir was a reviewer of the single biggest study ever on caloric restriction out of the University of Wisconsin
- In the [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/), one group of rhesus monkeys had their calories restricted and compared to control monkeys allowed to eat ad libitum
- The monkeys were followed for their entire life to see if calorie restriction extended lifespan

![](https://peterattiamd.com/wp-content/uploads/2020/08/calorie-restricted-rhesus-monkeys-1024x859.png)

**Figure 7. Animal appearance in old age. (A–B) Photographs of a typical control animal at 27.6 years of age (~age of average lifespan). (C–D) Photographs of an age-matched animal on CR.** Image credit: [Colman et al., 2010](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/)

- In the middle of the trial, Nir was part of a committee that was reviewing the data
- Nir noticed that the calorie restricted monkeys started to gain weight
- At first he thought that it had something to do with aging (e.g., slowing metabolism)
- However, looking closer he saw that all three cohorts of monkeys (each with different ages) were gaining weight at the same time
- Turns out that the **monkey handlers were feeding the calorie restricted monkeys more food out of compassion**

Reaction from Peter:

- It speaks to the human nature of science
- You can have the most perfect idea, the most beautiful theory imaginable, but it is so difficult to do clinical trials
- The decisions you make can come back to haunt you forever—if you pick the wrong patient population, the wrong indication, etc.

> “I’m constantly amazed at how often science actually works out when you consider all of the permutations in which it could go wrong.” —Peter Attia

## The biology of aging—epigenetic clocks, proteomics, and Nir’s centenarian data [1:42:00]

Recent paper looking at some changes in methylation and epigenetic age: [Reversing age: dual species measurement of epigenetic age with a single clock](https://www.biorxiv.org/content/10.1101/2020.05.07.082917v1)

**Methylation and epigenetic changes**

- Epigenetic changes are not due to the sequence of the DNA, but on top of the DNA, there is a way to control whether a gene is activated or not
- One of the ways to control that is [methylation](https://en.wikipedia.org/wiki/Methylation), and methylation is one way where the environment interacts with our genome
- With aging, methylation is either increasing or decreasing, and very often the consequences is a change in a gene activity
- David Sinclair, [in his book](https://www.amazon.com/Lifespan-Why-Age_and-Dont-Have/dp/1501191977), really thinks that this is a major cause of aging, and the key to how we stop aging

**Epigenetic clocks**

- People like Horvath and Morgan Levine have looked at methylation sites and tried to correlate them to chronological age
- But more important than chronological age, is **biological age**
- There’s now a huge body of work that really shows that methylation clocks are really good clocks of biological age, in particular when you see if they predict mortality
- All of a sudden this methylation concept became not only a predictive biology, a biomarker, but also became a business

*Concerns*:

Joan says,

*“Are these changes all pathologic or are some of them compensatory and actually good? So is reversing a biologic clock going to mean you’re in a better state or not?*”

Peter adds,

- Let’s just say a person shows up at time T-naught, and they have methylation status M-naught
- You then apply an intervention that is beneficial (rapamycin, metformin, etc.)
- Fast forward to another time point—even if you have not undone methylation, how do you know you haven’t done good that is proactive as opposed to retroactive?

Nir says,

“*It’s one thing to have a biomarker that predicts biological age, but we want much more than that. We want biomarkers to predict if we’re targeting aging.*”

**Patient case study**:

- Peter’s patient used a clock that predicted his biological age to be 34 (younger than his chronological age)
- But after a 5-day water only fast, the same biologic clock said his age was 27
- To get 7 years younger in 5 days seems nonsensical—”You can reverse engineer these things in any way you want, actually.”

> “Every time I’ve looked at one of these, I have found the data to be somewhat unhelpful because I don’t know what to make of them.” —Peter Attia

**Nir has a** [**Nature Medicine paper**](https://pubmed.ncbi.nlm.nih.gov/31806903/) with Tony Wyss-Coray doing a clock from proteomic viewpoint

-Took thousands of patients between the age 65 and 95 and looked at proteins and asked: *What does change between age 65 and 95?*

- The most important thing about the proteins was that there were a bunch of breakdowns in collagen, granular sites of platelets, etc.
- Nir says he came to realize that these breakdowns are important biomarkers because what we’re going to do when “treating aging” (with metformin, rapamycin, etc.) is stop the breakdown that is typical to aging.
- Proteomics are much more reactive than methylation, says Nir

**Peter’s overall thoughts on methylation and epigenetic clocks**: “*To me, the really interesting stuff is that the metabolomic, proteomic, transcriptomic level, of which maybe methylation becomes an additional thing that matters. But I think I just struggle with any one of these things being a magic bullet.*”

**Nir’s take**:

- Nir points out that there was a [Cell paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826138/) where it was attempted to rejuvenate the thymus with growth hormone, metformin, and DHE
- They showed methylation reversal
- So, it’s not that methylation can’t be reversed or that it doesn’t matter, says Nir, but he is more interested in the other “omics” in the same way Peter is

**Proteomic data and aging**:

- Joan points out a limitation with looking at proteins:
  - At Novartis, they did some looking at proteomics and aging
  - The problem, says Joan, is that some of the proteins (e.g., [GDF15](https://en.wikipedia.org/wiki/GDF15)) that go up with age are sometimes actually [a good thing] (as shown in the [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study))
  - In other words, moving the proteome to a younger age can sometimes actually be bad clinically

**Two more things about the proteomic data from** [**Nir’s Nature Medicine paper**](https://www.biorxiv.org/content/10.1101/751115v1.full):

- 1—Children of centenarians have about ⅓ of the proteome of people who are typically aging so there is some relationship to longevity
- 2—the proteome of females is much more stable
  - In men there are ~560 proteins that are changing
  - In women, there are only ~200 that are changing
  - Nir’s suspects the rate of aging in women is actually different — but unclear as to why

**Studying centenarians**

*The “superpower” of centenarians*: Their superpower is NOT that they survive better when they get diseases, it’s just that they phase shift when those diseases hit them—When they’re 80, they’re just acting like physiologically 60 year olds.

- Their aging has been delayed enough to prevent major age related diseases, but it’s not that they didn’t age
- They have a [compression of morbidity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4988893/)—Towards the end of their life they are frail enough so that whatever disease they get, it kills them and it does so quickly
- So rather than look at their genes and biomarkers at the late stage of life, it makes more sense to compare what they looked like at age 80 compared to their 80 year old, non-centenarian peers

Nir’s paper showing offspring of centenarians have less heart disease despite no better lifestyle habits of the controls: [Effect of Exceptional Parental Longevity and Lifestyle Factors on Prevalence of Cardiovascular Disease in Offspring](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5698168/)

- This paper is looking at the offspring of centenarians
- Despite no difference in behaviors and lifestyle, they had 40% of the heart disease of the control suggesting genetics plays a major role in slowing age related disease

## Joan’s dream experiment to test immune-enhancing effect of RTB101 [1:57:15]

*If Joan had unlimited funding, what experiment would she do to test the hypothesis of* [*RTB101*](https://www.lifespan.io/road-maps/the-rejuvenation-roadmap/restorbio-rtb101) *with respect to immune function?*

- Phase 3 trial in an elderly population
- She would look at lab confirmed respiratory tract infections, including COVID-19, and see if they could reduce the **severity of illness**
- She would have 3 groups
  - RTB101
  - A rapalog ([Everolimus](https://en.wikipedia.org/wiki/Everolimus))
  - Placebo
  - Note: she would NOT add the combo of RTB101+rapalog because that didn’t work as well in resTORbio’s [phase 2B study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/)

*How and when would she dose the drug?*

- There’s a peak of hospitalizations and deaths in people, particularly 70 and older, right during the 4 months of winter cold and flu season
- She would give the drug during that period and show that they have **decreased hospitalization**, and **decreased severe symptoms**
- Joan’s view is that the most benefit is coming from when the patient is on drug as opposed to post-wash out

## Concluding thoughts on COVID-19 [1:59:45]

Peter’s take on what should be the focus—

- The FDA and scientific community needs to adapt and **increase their tolerance for risk** when studying agents like metformin and rapamycin
  - Peter says, “*I feel less nervous taking rapamycin personally than an antibiotic.*”
- We clearly need to do to be prepared for future viruses
  - Contact tracing
  - Stockpile of PCR tests and reagents for PCR
  - Stockpile of antiviral meds
  - And we need more immune modulating therapy options
  - For more on preparedness, see [episode of The Drive with Stanley Perlman](https://peterattiamd.com/stanleyperlman/)
- Our goal should be making people more resilient
  - We should fund large studies looking at what definitively enhances our immune system
  - Things like…
    - Sleep
    - Vitamin D & C
    - Metformin
    - Rapamycin
    - Etc.

> “My view is that there are agents like metformin and rapamycin that could play a significant role in preparedness. Basically what it really comes down to is resilience. That’s really what you’re talking about, is host resilience.” —Peter Attia

**Joan’s take**:

- Rapalogs may have a double benefit—
  - 1) Low doses would be used to prevent infections and *severity* of infections
  - 2) High doses that are immunosuppressive might actually have benefit for that over-reaction of the immune system in response to COVID-19
    - Here’s a [small study out of Hong Kong](https://pubmed.ncbi.nlm.nih.gov/24105455/) showing an mTOR inhibitor was beneficial for patients with severe influenza and here’s a [clinical trial](https://clinicaltrials.gov/ct2/show/NCT04341675) looking at rapamycin in hospitalized patients with COVID-19
- **A word of** **caution**: We definitely need more data on drugs like rapamycin and metformin — “*I do think these shouldn’t be used until we PROVE that they have benefit.*”

**Nir offers some advice**: “*I don’t want to see studies that are not clinical studies. That’s my whole schtick here. I think we want, and we need, to find how we do things effectively, as fast as possible, and that it’s still led by science.*”

⇒ See Nir’s webinar comparing the pandemic to a war situation: [2 Be or not 2 Be](https://www.youtube.com/watch?v=iwbEDjw73lY)

**How we can do better scientifically**:

- We can better scrutinize drugs in phase 1 trials before moving to phase 2, says Peter
- We must be thinking more about structural changes to how we do science (using oncology as the example of how NOT to do it ⇒ see [Azra Raza episode of The Drive](https://peterattiamd.com/azraraza/))
- Joan makes the point that we have to find a way to work within (and with) regulatory authorities and that creates many challenges
  - ResTORbio’s [failed phase 3 trial](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-phase-3-protector-1-trial-rtb101-clinically), for example, did not meet its endpoint largely due to what the FDA required

**Better biomarkers** **are needed** — “*Better biomarkers are going to allow for better studies. Bottom line. And right now our biomarkers are so crude as to border on unhelpful at times.*”

§

## Selected Links / Related Material

**Joan’s company looking at rapalogs and mTOR inhibitors to target aging**: [resTORbio](https://www.restorbio.com/) | (restorbio.com) [1:00]

**Nir’s longevity gene projects looking at centenarians**: [Longevity Genes Project](https://www.einstein.yu.edu/centers/aging/longevity-genes-project/) | (einstein.yu.edu) [1:30]

**Nir’s LonGenity study on the genetics of longevity by focusing on the offspring of centenarians**: [LonGenity](https://www.einstein.yu.edu/centers/aging/research/longenity-longevity-genes-projects/longenity.aspx) | (einstein.yu.edu) [1:30]

**Nir’s book**: [Age Later: Healthspan, Lifespan and the New Science of Longevity](https://www.amazon.com/Age-Later-Healthiest-Sharpest-Centenarians/dp/1250230853) by Nir Barzilai | (amazon.com) [1:45, 1:35:30]

**Nir’s previous appearance on The Drive podcast**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [3:45]

**Paper by Cynthia Kenyon that influenced Joan to study aging which showed that genetic mutations in worms can cause doubling of lifespan**: [A C. elegans mutant that lives twice as long as wild type](https://www.nature.com/scitable/content/a-c-elegans-mutant-that-lives-twice-47284/) (Kenyon et al., 1993) [5:00]

**Pharma company that Joan worked at prior to resTORbio where she ran trials using rapalogs**: [Novartis](https://www.novartis.com/) | (novartis.com) [5:45]

**Data that mTOR inhibitors have beneficial effects on aging and lifespan in every organism tested**: [Rapamycin: An InhibiTOR of Aging Emerges From the Soil of Easter Island](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) (Arriola Apelo and Lamming, 2016) [7:00, 10:15]

**Joan’s 2014 study showing a rapalog enhanced the immune response to the flu vaccine system in older adults**: [mTOR inhibition improves immune function in the elderly](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly) (Mannick et al., 2014) [7:00, 11:15, 34:15, 38:25, 59:30, 1:02:45, 1:35:15]

**Lloyd Klickstein episode discussing rapamycin and mTOR inhibition**: [#118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging](https://peterattiamd.com/lloydklickstein/) | Peter Attia (peterattiamd.com) [13:25, 1:35:00]

**Nir’s study was the first to show that metformin specifically targets hepatic glucose production aka the insulin sensitivity of the liver much more so than the muscle**: [Mechanism of metformin action in obese and lean noninsulin-dependent diabetic subjects](https://pubmed.ncbi.nlm.nih.gov/1955512/) (DeFronzo et al., 1991) [16:00, 1:33:00]

**The DPP studies show that metformin will prevent people from developing diabetes**: [The Diabetes Prevention Program (DPP)](https://care.diabetesjournals.org/content/25/12/2165) (Diabetes Care, 2002) [16:45]

**A metformin paper Nir says was the “turning point” for him which showed that people on metformin had less cardiovascular events and less mortality when compared to control patients**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls](https://pubmed.ncbi.nlm.nih.gov/25041462/) (Bannister et al., 2014) [17:15, 24:15]

**Nir’s 2016 paper talking about the UKPDS and DPP papers**: [Metformin as a Tool to Target Aging](https://www.sciencedirect.com/science/article/pii/S1550413116302297#bib76) (Barzilai et al., 2016) [17:30]

**Website for the Interventions Testing Program (ITP)**:  [[Interventions Testing Program (ITP): Compounds In Testing](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/compounds-testing) | (nia.nih.gov) [19:15]

**Paper describing how the ITP studies are designed**: [An aging Interventions Testing Program: study design and interim report](https://onlinelibrary.wiley.com/doi/10.1111/j.1474-9726.2007.00311.x) (Miller et al., 2007) [19:15]

**ITP studies (Cohort 7) testing metformin alone, and metformin** ***plus*** **rapamycin, in mice showing biggest effect in life extension with metformin plus rapamycin**: [Longer lifespan in male mice treated with a weakly estrogenic agonist, an antioxidant, an α‐glucosidase inhibitor or a Nrf2‐inducer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) (Strong et al., 2016) [21:00, 1:26:40]

**ITP study (Cohort 2) showing mice given rapamycin alone starting at 20 months of age extended lifespan by 14% in females and 9% in males**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009) [22:00]

**ITP study (cohort 3) showing mice given rapamycin alone starting at 9 months of age extended lifespan by 10% in males and 18% in females**: [Rapamycin, but not resveratrol or simvastatin, extends life span of genetically heterogeneous mice](https://pubmed.ncbi.nlm.nih.gov/20974732/) (Miller et al., 2011) [22:00]

**See the ongoing ITP studies looking at rapamycin**: [The Rapamycin Phase II Study – Tissues Available for Collaborative Studies](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/rapamycin-phase-ii-study-tissues-available) | (nia.nih.gov) [22:00]

**Nir’s recent paper in Cell Metabolism showing how metformin hits every one of the hallmarks of aging**: [Benefits of Metformin in Attenuating the Hallmarks of Aging](https://pubmed.ncbi.nlm.nih.gov/32333835/) (Kulkarni et al., 2020) [24:45]

**A rapalog reduces protein and lipid synthesis which may decrease proteotoxic stress just by having less proteins made that your protein degradation system has to deal with**: [Coordinated regulation of protein synthesis and degradation by mTORC1](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4402229/) (Zhang et al., 2015) [32:40]

**Yale study showing the elderly have a defect in type I interferon production after getting a flu vaccine**: [Aging impairs both primary and secondary RIG-I signaling for interferon induction in human monocytes](https://stke.sciencemag.org/content/10/509/eaan2392) (Molony et al., 2017) [36:30]

**Stanford study show that while there are stimuli to the innate immune system that should induce interferon, but there’s a defect in immune cells in the eldery**: [Age-associated Failure to Adjust Type I Interferon Receptor Signaling Thresholds after T-cell Activation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4506866/) (Li et al., 2016) [36:30]

**mTOR inhibition decreases the exhausted T cells in older mice**: [Chronic mTOR inhibition in mice with rapamycin alters T, B, myeloid, and innate lymphoid cells and gut flora and prolongs life of immune‐deficient mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4693453/) (Hurez et al., 2015) [37:15]

**Metformin might make vaccines work better**: [Diabetes Drug Makes Vaccines Work Better](https://www.webmd.com/diabetes/news/20090603/diabetes-drug-makes-vaccines-work-better) | Daniel J. DeNoon (webmd.com) [41:00]

**Paper from China showing people who were taking metformin had less mortality from COVID-19**: [Metformin Treatment Was Associated with Decreased Mortality in COVID-19 Patients with Diabetes in a Retrospective Analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7356425/) (Luo et al., 2020) [43:15, 54:15, 2:05:15]

**A study which looked at what actually causes pneumonia in the elderly that gets them hospitalized and found it was the virus itself (rather than virus plus bacterial superinfection)**: [Community-Acquired Pneumonia Requiring Hospitalization among U.S. Adults](https://www.nejm.org/doi/full/10.1056/NEJMoa1500245) (Jain et al., 2015) [46:45]

**Observational study showing women on metformin had a 21% less mortality to COVID-19**: [Observational Study of Metformin and Risk of Mortality in Patients Hospitalized with Covid-19](https://www.medrxiv.org/content/10.1101/2020.06.19.20135095v2)  (Bramante et al., 2020) [51:30]

**In silico analysis of 36 drugs, including metformin, as potentially interacting with COVID/SARS**: [In Silico Discovery of Candidate Drugs against Covid-19](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7232366/) (Cava et al., 2020) [53:15]

**Even after stopping metformin, Nir showed that there are lingering effects**: [Metformin regulates metabolic and nonmetabolic pathways in skeletal muscle and subcutaneous adipose tissues of older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5847877/) (Kulkarni et al., 2018) [56:00]

**A bunch of transcriptomic, metabolomic, proteomic, big data analyses that have identified mTOR inhibitors and rapalogs as potential drugs that would interfere with the replication of SARS-CoV- 2**: [An Open Question: Is It Rational to Inhibit the mTor-Dependent Pathway as COVID-19 Therapy?](https://www.frontiersin.org/articles/10.3389/fphar.2020.00856/full) (Terrazzano et al., 2020) [58:00]

**Joan’s 2018 phase 2a study looking at the immune enhancing effects of rapalogs**: [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20) (Mannick et al., 2018) [58:30, 1:00:55, 1:04:00, 1:58:15]

**Joan’s 2019 phase 2b study showing decreased incidence and severity of viral infection with rapalog (RTB101)**: [LB2. TORC1 Inhibition with RTB101 as a Potential Pan-Antiviral Immunotherapy to Decrease the Incidence of Respiratory Tract Infections Due to Multiple Respiratory Viruses in Older Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/) (Mannick et al., 2019) [58:30, 1:04:00, 1:56:45]

**Joan’s phase 3 PROTECTOR study looking at RTB101 alone which failed to meet its endpoint**: [resTORbio Announces That the Phase 3 PROTECTOR 1 Trial of RTB101 in Clinically Symptomatic Respiratory Illness Did Not Meet the Primary Endpoint](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-phase-3-protector-1-trial-rtb101-clinically) | (restorbio.com) [1:04:30, 2:11:45]

**resTORbio is doing a trial in nursing homes looking at severity of symptoms in COVID-19 patients**: [Phase 3 Study to Determine if RTB101 Reduces the Severity of COVID-19 in Older Adults Residing in Nursing Homes](https://clinicaltrials.gov/ct2/show/NCT04409327?term=restorbio&draw=2&rank=1) | (clinicaltrials.gov)  [1:07:45]

**The New York Times reported that many vaccines aren’t being tested in people over the age of 65**: [Older Adults May Be Left Out of Some Covid-19 Trials](https://www.nytimes.com/2020/06/19/health/vaccine-trials-elderly.html) | Paula Span (nytimes.com) [1:09:00]

**Episode of The Drive discussing monoclonal antibodies, and vaccine strategies for COVID-19**: [#115 – David Watkins, Ph.D.: A masterclass in immunology, monoclonal antibodies, and vaccine strategies for COVID-19](https://peterattiamd.com/davidwatkins/) | Peter Attia (peterattiamd.com) [1:11:00]

**resTORbio is looking at rapalogs as a treatment for Parkinson’s disease**: [Clinical Trials/Patients](https://www.restorbio.com/clinical-trials/) | (restorbio.com) [1:14:15]

**Matt Kaeberlein’s paper explaining the potential to both ameliorate and potentially clean up a lot of the protein aggregation/disaggregation that’s occurring in the central nervous system (CNS)**: [Rapamycin and Alzheimer’s disease: Time for a clinical trial?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6762017/) (Kaeberlein and Galvan, 2019) [1:15:15]

**One study looking at MCI and metformin showed decreased deterioration in some of the domains of Alzheimer’s disease**: [Metformin in Amnestic Mild Cognitive Impairment: results of a pilot randomized placebo controlled clinical trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5079271/) (Luchsinger et al., 2016) [1:16:15]

**Nir’s TAME trial**: [The TAME Trial: Targeting the Biology of Aging.](https://www.afar.org/tame-trial#:~:text=The%20Targeting%20Aging%20with%20Metformin,the%20ages%20of%2065%2D79.) | (afar.org) [1:20:15, 2:08:00]

**Non-profit that is supporting the TAME trials**: [American Federation of Aging Research](https://www.afar.org/) | (afar.org) [1:22:30]

**Rapalogs are probably inhibiting SASPs**: [mTORC Inhibitors as Broad-Spectrum Therapeutics for Age-Related Diseases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6121351/) (Walters and Cox, 2018) [1:26:00]

**Episode of The Drive discussing the role of autophagy in cancer**: [#114 – Eileen White, Ph.D.: Autophagy, fasting, and promising new cancer therapies](https://peterattiamd.com/eileenwhite/) | Peter Attia (peterattiamd.com) [1:27:30]

**Episode of The Drive with Iñigo San Millán discussing zone 2 exercise**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com) [1:29:30]

**MASTERS trial that look at the effects of metformin on the response to resistance training**: [Metformin blunts muscle hypertrophy in response to progressive resistance exercise training in older adults: A randomized, double‐blind, placebo‐controlled, multicenter trial: The MASTERS trial](https://onlinelibrary.wiley.com/doi/full/10.1111/acel.13039) (Walton et al., 2019) [1:30:00]

**Peter’s summary of the MASTERS trial**: [Metformin and exercise – déjà vu all over again?](https://peterattiamd.com/191013/) | Peter Attia (peterattiamd.com) [1:30:00]

**Study showing a negative impact of metformin on aerobic efficiency**: [Metformin inhibits mitochondrial adaptations to aerobic exercise training in older adults](https://onlinelibrary.wiley.com/doi/full/10.1111/acel.12880) (Konopka et al., 2018) [1:32:45]

**Data from Matt Kaeberlein’s lab giving rapalogs to dogs**: [Matt R. Kaeberlein, PhD: Publications](https://www.pathology.washington.edu/faculty/kaeberlein) | (washington.edu) [1:35:30]

**University of Wisconsin caloric restriction study in rhesus monkeys in which Nir discovered the calorie restricted monkeys were being fed more food out of “compassion”**: [Caloric restriction delays disease onset and mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) (Colman et al., 2010) [1:37:30]

**Recent paper looking at some changes in methylation and epigenetic age**: [Reversing age: dual species measurement of epigenetic age with a single clock](https://www.biorxiv.org/content/10.1101/2020.05.07.082917v1) (Horvath et al., 2020) [1:42:00]

**David Sinclair’s book which discusses methylation and epigenetic clocks**: [Lifespan: Why We Age―and Why We Don’t Have To](https://www.amazon.com/Lifespan-Why-Age_and-Dont-Have/dp/1501191977) by David Sinclair and Matthew D. LaPlante | (amazon.com) [1:42:55]

**Nature medicine paper looking at the proteomic data and epigenetic clocks**: [Undulating changes in human plasma proteome profiles across the lifespan](https://www.biorxiv.org/content/10.1101/751115v1.full) (Lehallier et al., 2019)  [1:46:45, 1:51:00]

**Experiment showing methylation reversal when attempting to rejuvenate the thymus with growth hormone, metformin, and DHE**: [Reversal of epigenetic aging and immunosenescent trends in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826138/) (Fahy et al., 2019) [1:49:30]

**Framingham Heart Study**: [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study) | (wikipedia.org) [1:50:00]

**Compression of morbidity in centenarian**: [Compression of Morbidity is Observed Across Cohorts with Exceptional Longevity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4988893/) (Ismail et al., 2017) [1:55:00]

**Nir’s paper showing offspring of centenarians have less heart disease despite no better lifestyle habits of the controls**: [Effect of Exceptional Parental Longevity and Lifestyle Factors on Prevalence of Cardiovascular Disease in Offspring](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5698168/) (Gubbi et al., 2017) [1:56:15]

**Article which quoted Nir saying rapamycin could reduce the morbidity of COVID-19 by 50%**: [COVID-19: Leading clinician calls for focus on the biology of aging](https://www.longevity.technology/covid-19-leading-clinician-calls-for-focus-on-the-biology-of-aging/) | Danny Sullivan (longevity.technology) [1:56:45]

**Nir’s webinar where he compares the battle against COVID-19 to a war where you have to attack the enemy but also protect the host**: [2 be or not 2 be with Nir Barzilai. #COVID19 and more](https://www.youtube.com/watch?v=iwbEDjw73lY) | Longevity Leaders (youtube.com) [1:59:45]

**Episode of The Drive with coronavirus expert, Stanley Perlman**: [#117 – Stanley Perlman, M.D., Ph.D.: Insights from a coronavirus expert on COVID-19](https://peterattiamd.com/stanleyperlman/) | Peter Attia (peterattiamd.com) [2:03:00]

**Small study out of Hong Kong showing a mTOR inhibitor was beneficial for patients with severe influenza**: [Adjuvant treatment with a mammalian target of rapamycin inhibitor, sirolimus, and steroids improves outcomes in patients with severe H1N1 pneumonia and acute respiratory failure](https://pubmed.ncbi.nlm.nih.gov/24105455/) (Wang et al., 2014) [2:06:30]

**Clinical trial looking at rapamycin in hospitalized patients with COVID-19**: [Sirolimus Treatment in Hospitalized Patients With COVID-19 Pneumonia (SCOPE)](https://clinicaltrials.gov/ct2/show/NCT04341675) | (clinicaltrials.gov) [2:06:30]

**A suggestion to do a clinical trial giving mTOR inhibitors to prevent severe COVID-19 infections**: [Immunoregulation with mTOR inhibitors to prevent COVID‐19 severity: A novel intervention strategy beyond vaccines and specific antiviral medicines](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7272823/) (Zheng et al., 2020) [2:06:30]

§

## People Mentioned

- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) [5:00]
- [Lloyd Klickstein](https://www.restorbio.com/about/#management-team) [5:45, 13:25, 1:35:00]
- [Dan Vasella](https://en.wikipedia.org/wiki/Daniel_Vasella) [6:15]
- [Mark Fishman](https://hsci.harvard.edu/people/mark-fishman) [6:15]
- [John Mannick](https://bwhbulletin.org/2019/10/24/in-memoriam-john-mannick-md-department-of-surgery/) [7:45]
- [Ralph DeFronzo](https://www.uthscsa.edu/patient-care/physicians/providers/1851408843/Ralph-DeFronzo) [15:30]
- [Ana Maria Cuervo](https://en.wikipedia.org/wiki/Ana_Maria_Cuervo) [29:30]
- [Tyler Curiel](https://lsom.uthscsa.edu/mimg/team-member/tyler-j-curiel-m-d-m-p-h/) [37:15]
- [Matt Kaeberlein](https://www.pathology.washington.edu/faculty/kaeberlein) [1:15:15, 1:35:30]
- [Iñigo San Millán](https://twitter.com/doctorinigo?lang=en) [1:29:30]
- [David Sinclair](https://en.wikipedia.org/wiki/David_Andrew_Sinclair) [1:42:55]
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) [1:43:00]
- [Morgan Levine](https://medicine.yale.edu/profile/morgan_levine/) [1:43:00]
- [Tony Wyss-Coray](https://profiles.stanford.edu/tony-wyss-coray) [1:46:45]
- [Tom Pearls](https://www.bumc.bu.edu/busm/profile/thomas-perls/) [1:55:30]
- [Stanley Perlman](https://medicine.uiowa.edu/microbiology/profile/stanley-perlman) [2:03:00]

§