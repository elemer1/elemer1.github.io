# #335 ‒ The science of resistance training, building muscle, and anabolic steroid use in bodybuilding | Mike Israetel, Ph.D.

**Source:** [https://peterattiamd.com/mikeisraetel/](https://peterattiamd.com/mikeisraetel/)

---

Mike Israetel is a sports physiologist, competitive bodybuilder, and co-founder of Renaissance Periodization, where he coaches athletes and professionals in diet and weight training. In this episode, Mike shares his journey from powerlifting to academia, breaking down the core principles of resistance training, including exercise selection, volume, intensity, and frequency. He debunks common misconceptions about strength training, explains how to structure an effective program for beginners and advanced lifters, and provides candid insights into his experience with anabolic steroids, discussing their effects on muscle growth, performance, and health risks. This conversation offers a deep dive into the science of building muscle, the realities of bodybuilding at the highest levels, and the potential of AI-driven breakthroughs to advance human performance and longevity.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/mikeisraetel/the_Drive_public.png)

Play

#335 ‒ The science of resistance training, building muscle, and anabolic steroid use in bodybuilding | Mike Israetel, Ph.D.

#335 ‒ The science of resistance training, building muscle, and anabolic steroid use in bodybuilding | Mike Israetel, Ph.D.

1x15s30s

0:002:51:18

## We discuss:

- Mike’s academic journey, and early experiences in powerlifting, personal training, and sports physiology [3:30];
- Mike’s transition from powerlifting to bodybuilding, and his scientific and artistic approach to sculpting muscle and optimizing aesthetics [9:15];
- The value of strength training, time efficiency, and how it differs from endurance training [14:45];
- Neurological fatigue in strength training: balancing recovery and pushing the limits [26:15];
- The relationship between training intensity and volume, why muscle growth is not linear, and how different approaches affect results [35:00];
- Sustainable and effective approaches to maximizing muscle growth: training close to failure while minimizing fatigue [40:00];
- An efficient and effective resistance training program for beginners with limited time [49:00];
- Advice for finding a good trainer [1:06:30];
- Troubleshooting training plateaus: optimizing exercise selection, intensity, and recovery for muscle growth [1:13:30];
- The impact of genetics, age, and lifestyle on muscle growth [1:27:45];
- The importance of nutrition, protein intake, and consistency in both training and diet for muscle growth [1:31:00];
- The use of anabolic steroids to boost muscle growth: doses, drug combinations, and side effects [1:35:45];
- Long-term impact of steroid use on muscle retention, the role of genetics and individual variability, and their impact after discontinuation [1:52:15];
- Trade-offs of long-term usage of supraphysiologic doses of testosterone: health, performance, and Mike’s future plans [2:00:45];
- The potential for AI-driven medical breakthroughs to reverse aging and disease [2:07:30];
- The role of AI in accelerating drug development, advancing human longevity, and overcoming biological limitations [2:19:45];
- The philosophical implications of simulated reality, the impact of robotics on human labor and economics, and the challenge of predicting the future [2:25:15];
- Would having kids change Mike’s philosophy around anabolic steroid use? [2:32:15];
- The role of GLP-1 agonists in bodybuilding and general weight management, and the moral and philosophical debates surrounding their use [2:35:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Mike Israetel holds a PhD in sports physiology and is currently the head science consultant for Renaissance Periodization
- He is a competitive body builder and was formerly a professor of exercise and sports science at the School of Public Health at Temple University in Philadelphia
- As a co-founder of Renaissance Periodization, Mike has coached numerous athletes and busy professionals in both diet and weight training
- Mike also has a very popular [YouTube channel](https://www.youtube.com/@MikeIsraetelMakingProgress) where he loves to do debunking videos that are both informative and endlessly amusing
- In today’s conversation, Mike shares his personal journey
  - From his early experiences in powerlifting and bodybuilding
  - To his academic training in exercise science
- We discuss the core principles of resistance training
  - Exercise selection
  - Volume
  - Intensity
  - Frequency
- Mike debunks the common fear that strength training will make people overly muscular without intention
  - He explains why this belief is unfounded
  - He highlights the dedication required to build significant muscle mass
- We outline what a resistance training routine could look like
  - For someone new to the gym
  - Or transitioning from sports
- For more experienced lifters, we explore how to optimize resistance training for muscle growth
- Mike shares his personal experience with anabolic steroids
  - Outlining their impact on muscle growth, mental health, and performance
  - He discusses the pros and cons, including the significant physical change and potential long-term health risk
  - It’s worth pointing out here that Mike is one of the most candid individuals that Peter has ever met when it comes to discussing his use of anabolic steroids, growth hormone, and things of that nature
- What is remarkable is just how jaw dropping the numbers are in terms of usage
  - Compared to the doses of testosterone Peter has prescribed for many patients under physiologic circumstances, it was impossible to fathom the types of doses that bodybuilders are using
- We discuss the role of genetics in muscle growth and strength, as well as the influence of age and other lifestyle factors
- This conversation offers insights into the science of resistance training and practical advice for anyone looking to build muscle
- While also exploring the experience of someone who has been in the bodybuilding world

## Mike’s academic journey, and early experiences in powerlifting, personal training, and sports physiology [3:30]

- There’s going to be some folks listening and watching us who are probably very familiar with Mike’s work and they’ve probably come to learn about him as Peter has through endless years of being both amused and educated by his content on YouTube
- But there’s probably a group of people here just in my audience that aren’t overlapping with yours

**Give folks a chance to get to know you, and talk a little bit about your background**

- Mike came to the US from Russia when he was 7
- Before that, he grew up in Moscow, Russia
- In the US, he grew up in the metropolitan Detroit area in a place called Oak Park, Michigan

*What did you study in undergrad?*

- Movement science, kinesiology at the University of Michigan

*What sports were you playing then?*

- He wrestled in high school, but he wasn’t very good at it, wasn’t dedicated
- He got into lifting hardcore towards the middle and end of high school
- By the time he was in college, he was gearing up to start competing in powerlifting
- He actually started the Michigan Powerlifting Club
  - A team that went to meets and all that stuff
  - He was a competitive powerlifter in his undergraduate years

Peter adds, “*For folks who might be confused about all the different disciplines,* ***powerlifting*** *is the sport where there are 3 and only 3 lifts. There’s a deadlift, a bench press, a squat, and you win by having the highest total weights across the three*.”

- So squat plus bench plus deadlift equals total, and the person with the biggest total for the weight class
  - Or absolute or by formula wins the whole thing
- Mike was not into bodybuilding yet

*Did you go off and do your PhD right away after undergrad?*

- No, he got a master’s
- In the exercise science field, going straight from undergraduate to a PhD is very rare
  - Usually you need a lot more preparatory work because the undergraduate curriculum typically just doesn’t teach you a whole lot of applied super specialized exercise science
- He learned anatomy and physiology very well, but much more general curriculum
  - Especially at an RO1 school like Michigan,  they didn’t super hyper specialize
  - He learned almost nothing about sports whatsoever
  - Resistance training wasn’t a big focus there; he must have had 2 bullet points of how to resistance train in any one of his classes
  - It was chronic disease management, health, clinical application
- Right after undergrad, he went to Appalachian State University to get a Master’s degree under [Dr. Travis Triplett](https://phes.appstate.edu/faculty-staff/travis-triplett) and [Dr. Jeff McBride](https://phes.appstate.edu/faculty-staff/jeffrey-mcbride)
- That was a subspecialty of exercise science: strength and conditioning
  - So much closer to what he was super passionate about
- Mike then worked for 1 year as a personal trainer
  - It’s like jail
  - He did a year in Manhattan with his colleague [Mr. Nick Shaw](https://rpstrength.com/pages/team/nick-shaw), who’s now the co-founder and CEO of their company, [RP](https://rpstrength.com/)
  - They trained folks at a private personal training studio in Manhattan (like CTOs of major companies)
- Mike had never met a truly rich person until he met someone who was worth like $50 million
  - Turns out they’re just really nice cool people that are really chill and have the same problems everyone else does, trying to get in shape
- In that year, Mike realized he didn’t know enough, and then he enrolled in the PhD program for sport physiology at East Tennessee State University under [Dr. Mike Stone](https://www.etsu.edu/chs/exercise-science/faculty/stonem.php)
- That was an amazing time
- He probably learned more in that 3 years than he ever learned at school
  - Totally immersive
  - Got to work with teams, got to work with athletes, strength and conditioning coach
  - Truly sports science work

> “*We integrate all of the variables, sport coaching, strength and conditioning, sports medicine, nutrition, the whole gamut. Incredible experience.*”‒ Mike Israetel

- Mike got a PhD there and then taught at the University of Central Missouri for a while
- Taught at Temple University in Philadelphia for a while
- Then he went full depth into private industry founding RP
  - This happened during the time he was in the PhD program
- Sometime during the years at Temple, it became apparent that he was more productive not teaching because there was so much to do with the company
- So he took some time away from teaching
- Then he came back to teach under his friend [Dr. Brad Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/exercise-sciences-recreation/bradley-schoenfeld/)
  - Who’s the world expert scientifically in muscle hypertrophy
  - Mike taught at his master’s program for a while
- He left that recently to do private industry full time

**When did you start putting out these videos on** [**YouTube**](https://www.youtube.com/@MikeIsraetelMakingProgress)**?**

- Peter only discovered them a couple years ago, but thinks he’s been doing this much longer
- Mike started posting videos on YouTube in 2020 during peak COVID
  - He records most of his YouTube videos at his home studio
  - If he drops the “C word”, the video guy’s like, “*Different take*.”
  - They one-take almost everything and that they will roll back
    - The algorithm will flag it and put a COVID warning

## Mike’s transition from powerlifting to bodybuilding, and his scientific and artistic approach to sculpting muscle and optimizing aesthetics [9:15]

**Going back to your personal evolution as you’re going through this journey of master’s, PhD, industry, are you still focusing on powerlifting personally?**

- Mike was focused on powerlifting up until he got into the Master’s program
- Towards the end of undergrad he picked up a muscle magazine at the grocery store
  - *Flex Magazine* had an issue that summarized the prior [2002 Mr. Olympia contest](https://en.wikipedia.org/wiki/2002_Mr._Olympia) with all the pictures of the bodybuilders
    - [Ronnie](https://en.wikipedia.org/wiki/Ronnie_Coleman) won again; that was his 4th or 5th time winning Mr. Olympia and he didn’t look his best

Everyone suspected [Jay Cutler](https://en.wikipedia.org/wiki/Jay_Cutler_(bodybuilder)) could have beat him if he showed up that year (He almost beat him in 2001)

![](https://peterattiamd.com/wp-content/uploads/2025/02/f1-mikeisraetel.png)

**Figure 1.** Jay Cutler and Ronnie Coleman. Image credit: [M&F](https://www.muscleandfitness.com/flexonline/ifbb/jay-cutlers-streak/)

- Mike remembers reading the magazine and looking at the pictures ‒ it was enlightening because Mike realized he had an eye for aesthetics
- Some people will see muscular physiques and they kind of all look the same, like giant veiny, overcooked hot dogs (which is not wrong)
- Mike looked at the physiques and he was really taken aback, especially by some of them
  - [It was a feeling akin to what] normal people get when they look at very good art: that whoa, I’m looking at something very special, something that’s emotive

***That’s when Mike started to pursue his own hypertrophy training (muscle growth training)***

**What were you looking like at the time?**

- He was roughly 190 lbs. at 5’ 6”
  - Fairly lean, but not anything crazy and so muscular
  - If he had clothes on, people would be like, “*Oh, it’s just a short person.*”
  - But shirtless, he looked like he had clearly lifted weights for some time

Mike shares, “*I really also realized that while there’s a huge passion for me in lifting heavy, I also had a passion for getting pumps and doing higher reps and doing lots of volume and seeing my body change visually. That was a huge trip.*”

- Then it became this thing where he was an artist in muscle growth and fat loss
- His canvas was his own body, and he wanted to learn how to sculpt it very well

> “*Most selfishly, just so I could occupy a super hero looking body.*”‒ Mike Israetel

- He ended up looking more like a villain; balding will do that

***It was a real personal journey for him at first and still is***

**By comparison, what do you weigh right now?**

- 235 lbs., substantially lean
- Later, we’ll talk a lot about bodybuilding and cycles

*Are you in a cycle now? And if so, are you on the way up or on the way down in terms of mass?*

- Mike is at the top of where he’ll be for a little bit (maybe up, but very slowly)
- This is roughly the fattest he’ll get
- Peter jokes, “*I didn’t want to say anything Mike, but yeah, you’re looking a little chubby.*”
  - Mike replies, “*Looking pretty fat. Yeah, I’ll cry about it later*.”

*If you had to guess your body fat right now*

- It would be maybe 9ish%

![](https://peterattiamd.com/wp-content/uploads/2025/02/f2-mikeisraetel.png)

**Figure 2. Mike Israetel**. Image credit: [Team Fullrom](https://teamfullrom.com/pages/meet-the-team)

- Mike still has some striations in his glutes
- He has one of the least aesthetic physiques imaginable (thank you genetics for that one)
- He also gained a ton of weight earlier in his career that was muscle and fat, and it stretched his skin out and gave him massive love handles
  - When you lose that weight, the skin is still sticking around
  - He’s planning on some extensive cosmetic surgery in a few months to address that issue

**For Mike, the whole journey fundamentally is a personal journey of wanting to occupy a body that is 2 things**

- 1- A body that he aesthetically enjoys being in
- 2 –  body that he had a large hand in creating or curating
- The curation is almost as fun as the creation
  - You see an artist draw something on a canvas and a huge amount of joy comes from creating the main arc of everything you’re doing (the main shapes, main lines, main coloring)
  - But you know when artists have something almost complete and they do a little pencil in pencil there?
  - Once you have something that looks amazing and you’re optimizing, oh, there’s something super beautiful about that
  - It’s like watching someone take a very finely tuned F1 car and just wrench a couple of the screws in and polish it off (it’s just so beautiful)
- Mike shares, “*Not that my body is attractive, it’s not… but less grotesque is what I’m aiming for, and I don’t know if it’s working or not. My hairiness kind of precludes any of that.*”
- When Peter thinks of an artist mucking around with a canvas, he only thinks of [Bob Ross](https://en.wikipedia.org/wiki/Bob_Ross) because he doesn’t have much experience watching an artist create something
  - Usually he’s seeing the finished product

![](https://peterattiamd.com/wp-content/uploads/2025/02/f3-mikeisraetel.png)

**Figure 3. Bob Ross**. Image Credit: [Wikipedia](https://en.wikipedia.org/wiki/Bob_Ross)

- But like most people who grew up in the 70s and 80s, Peter recalls watching Bob Ross on Saturday mornings with great fondness ‒ he made it look so easy
- Not only did he make it look so easy, he’s communicating an empowerment about creating art
  - Everybody could be doing this
- He’s like, “*You see this cloud in the way, we’re going to make it a tree.*”
- If Mike had to describe his physique and genetics, it would be like a lot of Bob Ross style having to fix things that are like, oh, that looks terrible

## The value of strength training, time efficiency, and how it differs from endurance training [14:45]

- To bring this up to present, right now Mike competes in bodybuilding and he provides a lot of education to folks
- Peter’s audience is clearly interested in exercise, strength training, and the aesthetics of strength training
- It’s very easy to look at bodybuilders and say, “*That’s a little odd*.”
- What is obvious is that’s just a spectrum

> “*Anybody who wants to have more muscle and less fat probably has something they can learn from a bodybuilder.*”‒ Peter Attia

- There’s probably no athlete, there’s no person out there that truly understands how to manipulate exercise and nutrition in the context of body composition [than a bodybuilder]
  - And that’s true even in the presence of anabolic steroids
  - Anabolic steroids might make that a little easier (which they will talk about later)

**Where do you see the value of strength training?**

*Do you think that there is a diminishing return in the amount of muscle at some point?*

- Peter has said very tongue in cheek that the list of 90-year-olds out there complaining, wishing they were not as strong and not as muscular is a very short list
- Most people at the end of life are saying the exact opposite, “*I wish I was stronger, I wish I had more muscle.*”

*Are there extremes that people should be mindful of?*

- If you have to be mindful of extremes, in almost every case you have already been on a multi-years-long, very immersive, very infatuated, very disciplined journey of resistance training and focused nutrition and the organization of many variables and parts of your life around that task
- It’s unlikely to be something you pick up a lifting hobby and just find yourself excessively muscular (oops)
  - The myth of accidental muscle
- Almost nobody accidentally becomes hyper muscular to the extent that they’re on that side of the spectrum, that trade-offs are starting to become apparent

***Probably the biggest trade-off in the short to medium term is opportunity cost: things you could have spent doing outside of being in the gym***

**⇒** The way the science of resistance training works is for almost all of the health benefits and the longevity benefits and the quality of life benefits, the amount of time you need to be training per week is measured in the 1-3 hour range (with 3 being like you’re really full sending it)

- If you went on ChatGPT and asked for a list of all the things the typical American does for X number of hours a week
  - The top 100 time use cases
- You may find that 1-3 hours is somewhere in the 50 or 60 rank
- There’s so many things that people do that are way more than that
  - Social media consumption, TV, the list goes on

***If you really fully invest yourself, it’s going to take some time***

- It could take 8 hours a week
- People will jog for 40 minutes every morning and not think anything of it, and then when you present to them the idea of resistance training, they’re like, “*Well, now that’s going to take some time.*”

**⇒** Actually, it does not take nearly as much time because the intensity of the effort is so grotesquely high and the recovery demands are so high that you have to be very pulsatile with it

- It’s not something you have to do every day

> “*Probably the biggest return on investment the average person can make is to train for roughly half an hour two times a week, Monday and Thursday.*”‒ Mike Israetel

- If you do it properly, it can comport an unbelievable amount of benefits across the board

***For most people, the consideration that they can begin to do this excessively, it’s just not something realistic until and unless they’re really into it, like a huge hobby***

*Mikes analogy*

- If you are watching Formula One for 30 minutes a day every other day on your phone, realistic considerations of this is taking up too much of your time is out the window
- Now if you start canceling podcast guests because you’re following the circuit around the world and staying in five-star hotels and booking the hyper rich guy suite for all the races
  - Someone could say you’re really into this
  - You’re like, “*Nonsense. It’s only costing me 3 million a year.*” (then, yes)
  - But it’s obvious when you’re going to be so involved
  - You don’t just walk into that sort of thing

**Peter’s takeaway**

- Spending 8 hours a week on strength training is at the upper limits of what a person might do
- Conversely, if your goal is to be a really good endurance athlete, you’re not at that level if you’re only putting in 8 hours a week
  - A world-class cyclist is probably on their bike 30 hours a week (full-time job)
  - Of course not all of that is at maximum intensity, probably 70-80% of that time is going to be at [Zone 2](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/)

**Yet there’s something very different about strength training, which is are you really getting benefit at the equivalent of whatever we would call Zone 2 in the gym?**

*Is this just where the comparison between cardiopulmonary training, where there’s a clear benefit from submaximal efforts and strength training don’t jive?*

- That’s definitely the case
- Mike likes to use the term **resistance training**: it’s the term for going into the gym and applying things to your muscles

**⇒** Hypertrophy and strength are outputs of resistance training

- You can get some benefits from very submaximal efforts
- But resistance training is based on applying high forces and high levels of fatigue as its primary modality of how it makes you better
  - And so it’s when you get into that world, that’s what’s going to happen
- *Analogy*: if you’re trying to be a special operator, eventually a Navy SEAL type of person, the sound of gunfire freaks you out, you’re in the wrong place

***We get almost all the benefits from pushing either very heavy loads or lighter loads, but very close to muscular failure***

- Which people have described as unpleasant, a burn in the muscle, a lot of pain
- The weights slow down, so it takes a lot of psychological effort to keep going
- There is not really an equivalent of just getting on the bike and putting in the miles
  - Getting to a pace where Zone 2 you can breathe, you can talk a little bit still
- That’s not weight training, but precisely because weight training is so intensive, you need lots of recovery time between sessions and you can do lots of disruption and damage in each session
- Also the total yield on how much it changes your physiology is very high for each session and per unit time
- That means if you’re not working super hard per any one unit time, you’re going to need a lot of work (that’s endurance training)
- If you’re working insanely hard per unit time, you won’t need a lot of work
  - Nor can you recover from that much work
  - Which is why the top end is 8 or 10 hours for even professional bodybuilders, of time spent in the gym every week

> “*For people that just want the basic benefits, yeah, we’re talking about an hour or two hours a week, and that’s really all you need if you’re pushing sufficiently hard.*”‒ Mike Israetel

- Realistically, you can recover for more if you make time in your schedule and really prioritize recover

Peter asks, “*Do you think this is simply a consequence of the fact that endurance training relies more on type I muscle fibers and strength and hypertrophy training are more dependent on the actions of type II fibers?*”

- Peter thinks this is such an interesting contrast in how optimization of [cardio training] is a totally different philosophy than [resistance training]
- The reason he is harping on this is he knows when you take people who are used to doing endurance training, it’s a hard switch for them to adopt what Mike just said

**Is the best way to explain to that person the why, that’s the difference between a** [**type I and a type II fiber**](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)**?**

- That is probably a core difference
- Mikes adds 2 other things you can put into that equation
- 1 – The physical forces are much higher in magnitude
  - You’re going to be putting a lot of tension through your connective tissues and through your muscles when you’re resistance training than you are when you’re doing bicycle work, for example
  - With high absolute forces, the proximate damage and disruption to the body is graded exponentially and not linearly
- *Analogy*: it’s like if a wiffle ball flies past you, you might not even hear it
  - If a 50 caliber bullet flies past you, it’s going to tear parts of you off and it’s never even touched you
  - Very, very different amount of damage from much, much higher forces
- 2 – Some combination of neural and psychological drive, the kind of drive it requires to be good at endurance, at least the base building part, the aerobic base work that you do is kind of being in a state of calm equanimity
  - You get your flow going, you get your music going, you get your breathing going, you look at the road ahead of you and you can just crank
- But in lifting, you have to turn up the juice to really feel the maximum situation

*Another quick analogy offhand*

- If you are a trillionaire (like Mike) and you have a fleet of Cessna private aircraft at your beck and call
- When you fly a [Cessna](https://en.wikipedia.org/wiki/Cessna), you can fly it for some time
  - It requires a decent amount of maintenance, but it’ll fly for a long time
- It’s just never getting up to velocities that are really crazy
- If you take an [SR-71 Blackbird](https://en.wikipedia.org/wiki/Lockheed_SR-71_Blackbird) out for a spin at Mach 3, you have to do 10 times the number of maintenance hours per flight hour on that thing or something to that magnitude
  - Because at Mach 3, what’s happening to the plane is just running through subsequent brick walls
  - That’s what 3x the sound barrier is like: you’re just rattling that thing into dust
- When you’re pushing your body really hard and the weights are slowing down and their sets of 5 or sets of 8 or sets of 10, your body’s very close to its limits
- Both your faster twitch muscle fibers (which are required) take way more damage
- They’re also not as well proliferated with blood supply and they heal slower
- And the amount of absolute force is higher and the amount of neural drive it takes
- In contrast, you can hop on a bike for an hour at Zone 2 every day and afterwards people are like, are you tired?
  - And you’re like a little bit, I kind of feel also a little bit refreshed in a sense
- You don’t really feel refreshed after grinding the leg press for 5 sets of 15
  - You feel like someone beat the crap out of you (and you don’t owe anyone money)

***That absolute intensity of lifting and high relative intensity, that’s what tends to make the big, big fatigue cost***

## Neurological fatigue in strength training: balancing recovery and pushing the limits [26:15]

**Can you say more about the neural part of this?**

- Peter agrees with everything Mike said, and the neural component is what he knows the least about
- Which is you cannot discount the CNS fatigue literally that comes from doing this type of work
- As an example, Peter remembers watching **sprinters** train
  - If you study the mechanics of sprinting, you realize it really comes down to force per unit mass
  - That’s how hard they can hit the ground with their foot relative to their mass
  - These are athletes who need to be almost comically strong without gaining any excess weight
  - Even though we look at sprinters and think they’re very muscular, it’s their strength to weight that’s really profound
- They have to train in a way that minimizes hypertrophy and maximizes strength
- For example, they’ll focus heavily on exercises where they can push the concentric phase and not the eccentric phase
- It was explained to Peter that doing this allowed them to spare themselves from some of the neurological fatigue

*Is there any validity to that?*

*What’s happening in both the central and peripheral nervous system during the recovery phase?*

- Mike is glad Peter brought up the [peripheral nervous system](https://en.wikipedia.org/wiki/Peripheral_nervous_system)
- One of the big misconceptions is that there’s muscular fatigue, connective tissue, systemic fatigue, blood vessels and everything still left the heart has to pump

**⇒** The peripheral nervous system is a thing too, and it also takes a substantial amount of fatigue

Mike explains, “*The nervous system takes fatigue and it takes fatigue in the same way you would expect any system that’s pushed those limits to take, various components of it, experience, wear and tear, various substrates depleted and need to be repleted.*”

*2 examples*

- 1 – In the [axon](https://en.wikipedia.org/wiki/Axon) of any single given nerve, you have a balance of electrolytes inside and outside, which allows the proliferation of the electrical signal
- You run that system long and hard enough and it starts to get out of whack to where you try to get another impulse going and it’s like, ugh
- It needs to do a lot of pumping to take what’s supposed to be inside the cell that’s now outside the cell to get back in there to a level of concentration that would be fully recovered
- Typically that happens quickly, but if you run that system a lot, there are various points at which some of the structures that are supposed to do that (they’re also proteins), you use them enough and they start to kind of break a little bit
  - And you need to produce more proteins to replace the channels themselves that do that pumping back and forth
- Typically, that protein construction is measured on the order of minutes, hours and days (not seconds)
- *Analogy*: you could imagine it as like a transatlantic cable
  - You throw enough current through a cable and the fish nibble at the cable enough, you need to start replacing the cable
  - Now if you’re really, really using the crap out of that cable, yeah, it’s going to undergo some not so great things
- The closer neuron junctions (or the neuromuscular junction between the neuron and the muscle itself), you have vesicles of neurotransmitters
  - You pump enough of those in, you get the cool stuff of communication
  - You can run low on a neurotransmitter, and then the electrical signal arrives and neurotransmitter is like, sorry, not enough of us to do anything
  - Unless you experience fatigue expressed as weakness and you need time to reconstruct a lot of those neurotransmitters, place them into vesicles, have those vesicles translocate to the synaptic cleft, and then sit there and get ready
  - And that is a process that typically happens rapidly, but if you really exhaust it, can happen over some time
- A really austere illustration of that is ecstasy
  - He’s never done this, just heard about it
  - If you clear enough of that neurotransmitter, you don’t feel the same the next day
  - You feel different and it takes a day or 2 to get back up to those levels
- Similar types of mechanisms are at work when you are going to very close to true failure on let’s say a squat or a leg press
  - You’re cooking your muscles
  - It takes every single capacity of the nervous system to say push, push, push is at maximum
  - And so you end up doing quite a bit of homeostatic disruption all the way along the axon, all the way through the cell body and in the synaptic cleft neurotransmitters getting everywhere, gunk building up
  - That’s going to take some time to fix, which is why we see typically that people don’t regain their prior strength after fatiguing and resistance exercise for anywhere from several hours to several days (depending on how hard you go)

**⇒** If you have really, really hard workouts, it might take several days for you to be able to have a really, really hard workout again for that same muscle group

- Luckily, because a lot of this is peripheral nervous system based and local musculature based, if you train the living crap out of your chest one day and your triceps, you can train back and biceps, which have nothing much to do with those movements pretty robustly the next day

***Much of the fatigue is local***

- It’s not all local: the [central nervous system](https://en.wikipedia.org/wiki/Central_nervous_system) (brain and spinal cord), specifically the brain has a variety of mechanisms by which it controls your central fatigue
- [Tim Noakes](https://en.wikipedia.org/wiki/Tim_Noakes) was a big proponent of the **central governor model**
  - Though in the explicit terms, which he described might not be the case or somewhat close
  - There’s absolutely central governing going on, and when your body can tell through a variety of mechanisms that like, pretty messed up here, it’s going to pull back on how hard you can do anything
  - Some of those neural structures might even be operating at full bore, but they’re just degraded enough to where full capacity isn’t full capacity anymore
- In all those variety of ways (and many others) your body after accumulating a certain amount of fatigue will need to back off
- Mike adds, “*If you think you can train ultra hard for the same muscles twice a day every day, you are welcome to try it (in medical supervised context), you won’t last.*”

***It’s really good that we have a break planned in, but it’s also really cool because weight training is one of those things where you get a dose of it and for days after under the hood, it’s upgrading your body, your nervous system, your muscles, and your tendons***

> “*It’s really neat that you can do 20 or 30 minutes of intense physical activity and resistance training and then for days later be experiencing the actual accrued benefits.*”‒ Mike Israetel

- When you’re entering the gym, if you’re training properly, you are asking a lot of your physiology
  - You are pushing it to its limits
- If you’re not, you’re not using your time best and you’re not getting the best outcomes

**⇒** A lot of the absolute best results come from pushing very, very hard (not necessarily to limits, but you have to test the limits)

- Peter finds it interesting what he could do up to a certain age
  - He stopped pushing to those limits at about age 19
- What he could get away with then was ridiculous
- He attributes it to 2 things
- 1 – Youth, stupidity and inexperience
- 2 – Having started at a very young age
- From age 13-19 he was training 6 hours every day except Sunday
  - Sundays he only trained 2 hours per day
- He looks back at those workouts he did and doesn’t know how he did it
- More importantly, how much better he could have been if he didn’t train that much
- It wouldn’t be uncommon for Peter to do 6 super hard rounds of sparring with 3 fresh opponents, one guy, a weight class below him, one guy in his weight class, and then one guy for 2 rounds, a weight class above him
- Mike agrees that Peter did that backwards
- It was much harder and more dangerous to do it in that way
  - The idea that the guy that could hit the hardest was his last guy
  - When he was the most fatigued and his defenses were less accurate

## The relationship between training intensity and volume, why muscle growth is not linear, and how different approaches affect results [35:00]

**Peter’s highlights Mike’s super important point**

- The non-linearity of force is very counterintuitive
- It’s not obvious why being on a bike is nothing compared to doing an all-out set for 10 reps in the gym [with weights]
  - Even riding at a very high level of power: a 1-minute all-out on the bike is nothing compared to when you’re doing an all-out set for 10 reps in the gym
    - Remember on a bike, your leg is going around at 90 times per minute
    - A 1-minute all-out is 90 reps
  - It’s such a difference in force
- He loves the example of the wiffle ball going by you versus a 50 caliber bullet
- This idea of the profound level of difference in tissue destruction is an important one
- Peter was on [Dorian Yates podcast](https://youtu.be/xjm4IcSSHrs?si=xgtH6vO3XxKZrpFC) a few months ago, he explains, “*Poor Dorian, he wanted to interview me because it was his podcast, but I just wanted to interview him.*”
  - It was very interesting how little time he spent in the gym for a bodybuilder of that era
  - It was very progressive: he was doing 1 set to failure per exercise, and he was doing each body part once a week

**Are most people even capable of pushing that hard?**

- For a person who just wants to train 30 minutes twice a day [Peter meant to say twice a week], they can get all the benefit in the world, but there’s an asterisk there, which is that 30 minutes twice a week is going to be the most difficult 60 minutes total of your week?

*For* [*Dorian*](https://en.wikipedia.org/wiki/Dorian_Yates)*, why could he produce such a massive physique?*

![](https://peterattiamd.com/wp-content/uploads/2025/02/f4-mikeisraetel.png)

**Figure 4. Dorian Yates**. Image credit: [M&F](https://www.muscleandfitness.com/flexonline/the-heavy-duty-life-and-career-of-dorian-yates/)

- (They will talk about drugs later)
- Is it just the sort of thing where virtually nobody can actually push that hard, that consistently?
- Or was it just that nobody thought to do it the way he was doing it at the time?
- Plenty of people thought that’s how it works
- [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) did that only in a more extreme version than even Dorian did
- Lots of Mentzer acolytes did it

***It’s not the most efficient or the most effective way to train, but it is quite effective because if you go very close to failure with very heavy loads, all of the subcomponents of your musculature, all your motor units***

- Which is the motor neuron and all of the cells that it activates, they’ll get recruited and they will be asked to work to their limits
- They’ll take on a great deal of damage and disruption
- They’ll sense a ton of tension and they’ll produce great results for you

*The other thing is that the relationship between both intensity and volume of how much you do work in the gym, especially volume is curvilinear and hyperbolic*

**⇒** It means if you do one all-out heard set per muscle group per week, you get maybe something like 30% of what you could have gotten with 5 sets because your body has very good sensing mechanisms for tension and metabolites and all these other things that cause muscle growth

- Which is not **what Dorian did**, he did roughly 14 of those per week per muscle group
- When the body detects that you’re pushing on the pedal, it’ll give you a real good wallop of result
- But, when you keep pushing on the same pedal over and over, the systems are greatly desensitized to giving you more muscle growth
  - The biggest reason is probably because the human body is attuned and evolved to an environment called food insecurity
  - And so in order to make a real good case for allocating that much to muscle growth, you’re going to have to have a real distinct signal to ask your body to put more and more into that process
- If you are [myostatin deficient](https://www.pnas.org/doi/10.1073/pnas.0604893104#:~:text=Lack%20of%20myostatin%20function%20results,in%20normal%20individuals%20(1).), you grow muscle all the time

*Mike’s summary of the relationship between number of hard sets and muscle growth*

- You do 1 set close to failure, you get a lot of gains
- You do 3 sets close to failure, you get substantially more gains (but not 3x as many)
- You do 5 sets close to failure and you do just a little bit better than 3
- You do 7 or 8 sets close to failure in one workout and it’s statistically undifferentiable from 5

***If you want to do not a ton of volume for any 1 muscle, if you work really hard and bring yourself very close to failure, you can do super, super well with that alone***

**Mike’s chef analogy**

- If you have someone who really knows how to make food and you give them 1 hour in the kitchen with a variety of menu items, they can really wow you with what you’re eating
- Give them 3 hours, and they can wow you more, but it’s not 3x more
- It’s going to take a lot longer to produce 3x more the “wow”
- With 3 hours, they can make a difference, but probably only people who are very culinarily attuned can tell

**⇒** Getting some of the way to your body’s maximum ability actually brings you most of the way as far as results

- And that’s why Dorian could do what he did

## Sustainable and effective approaches to maximizing muscle growth: training close to failure while minimizing fatigue [40:00]

**What** [**Dorian**](https://en.wikipedia.org/wiki/Dorian_Yates) **did**

- He did roughly 14 sets per week per muscle group-ish
- That gets into the territory of a very robust signal of growth to the muscle
- It’s not the highest signal of growth because fatigue isn’t just local (its systemic)
  - If you decided not to train your legs very hard or your back very hard, the amount of systemic fatigue is much lower
  - Then you could push your arms, shoulders, and chest to 25, 30, 35 sets per week and experience more growth enhancement (as compared to those 15 sets per week)
- But 15 sets a week might bring you to 70 or 85% of what all of those muscles could eventually have hypertrophied if you only ever specialized in them

***Dorian was insanely jacked all over, but in retrospect he could have benefited from more specialization phases on various weak points***

> “*By immortal standards they were the biggest arms you’ve ever seen in your life*.”‒ Mike Israetel

- By competitive bodybuilders of his era standards, relative to the rest of his physique, he could’ve had bigger arms, bigger shoulders
  - He could’ve poured more volume into those muscle groups and lessened everything else
- Dorian seemed to have an all-around approach
- Mike adds, “*Up until about a year ago, so did I, and so I never looked very aesthetic, but boy were my legs super big because they could just eat up the growth all the time.*”

**If Dorian was doing 14 sets per body part per week, would that mean 14 sets to failure of 14 different exercises so we’re not counting the warm-up sets and things of that nature?**

- It’s not 100% clear exactly what Dorian did or if he even did everything exactly as it was written on paper all the time
- In his training videos, you don’t always see just 1 set
- He would also have this thing like a warm-up set that for him was a warm-up, but for most people would absolutely be a work set
- So it may be more like 2 or 3 equivalents of a working set per exercise

Peter’s summarizes, “*There’s a total throwaway set and then there’s a modest set, and then there’s a two rep and reserve set that, again, that’s a real working show and then it’s a set to failure.*”

- According to Dorian’s categorization the only work set was the one that was absolutely the true muscular failure sometimes with forced repetitions
  - Which you would also have to integrate because **forced reps** is when someone helps you lift the rest of the weight
  - Or if you do a **drop set**, you use less weight right after you went to failure
    - We shouldn’t count that as just one set ‒ it wouldn’t be the most correct way to think about it

**When you compare that to the example of the 3-hour chef, so now the person who’s willing to put in 30 sets per body part per week, do any of those sets need to be to failure or are you counting those as hey, these would be sets of 2 reps in reserve?**

**⇒** The literature has found that if you don’t systemically fatigue the whole body too much, you can push any given muscle (or several muscles) into the 30, 40, 50 set range per week

- Almost every study done to elucidate that understanding was done with muscular failure studies, true failure
  - Truer failure than you’ll see in the gym
  - Most of us have never trained that hard consistently
- In these studies, undergraduates are recreationally trained so they can neither do a lot of damage nor are they impeded by age and prior injury
- They’re trained in laboratory conditions with master students screaming at them to keep going

**Whatever amount of sets you have to do to get a certain amount of growth, you can get there in a few different ways**

- You can get there with let’s say 30 sets that are 4 reps shy of failure
- You can get there with 22 sets that are 1 or 2 reps shy of failure
- You can get there with 20 sets that are all the way to absolute muscular failure

***If you are really training not so super hard for reps in reserve, you’ll have to do substantially more sets to see the same hypertrophy***

> “*Study after study after study illustrates that when you’re getting one or two reps away from failure, it is often statistically undifferentiable on raw growth than going all the way to failure.*”‒ Mike Israetel

- However, the **fatigue** of true failure training is exponentially higher
  - Probably because of that nervous system component
- As far as a training strategy for efficiency and long-term sustainability, most of your sessions should be 1 or 2 reps in reserve
- If you’re doing dumbbell presses you finish your last rep and you think you could’ve done 1 or 2 more, but that’s it ‒ it’s best to stop
- What you’re getting into if you do more is a 10:1 **fatigue:stimulus ratio**
  - Whereas everything before was 1:1, 2:1, 3:1, 5:1 [ratio of fatigue:stimulus]

***That’s a lot of fatigue cost to pay when the literature says the results will end up being a tiny bit better or not better at all***

Peter adds, “*Which says nothing of the risk of injury when you drop that dumbbell on your pec… when you fail in a set of dumbbell presses… I would never know.*”

- Mike’s take is that the vast proportion of people that really propose that training to failure is somehow special for results, they didn’t reason their way into that
  - They emoted their way into that
- Training to failure is something the 13 to 19-year-old you would’ve really found a lot of spirit energy in

Mike adds, “*It’s adult male putting on his hat of ‘I’m a mountain goat and I run into shit. That’s what I do.”*

- Mike saw an adorable video of some goats and dogs
  - A pit bull was sitting under this little thing, and there’s a teenage goat that’s looking at him
  - The goat jumps up on his hind legs and tries to hit the dog in the head
  - The pit bull backs up, and the goat just tries to do that again
  - The goat just wants to hit stuff
- So when you’re a young male, you’re prone to wanting success for yourself, you’re the type-A personality ‒ you couldn’t live with yourself if you weren’t optimally successful in life because you didn’t work hard enough
- Those kinds of folks generally tend to go to muscular failure for just that spirit energy (it feels right, damn it)
- From the sport experience, when you’re really, really tired, your whole existence is screaming at you to stop
- Ignoring those things and going all the way until you’ve pushed it as far as your body can go, there’s something very magical there for the soul

***For results in the gym, there’s not much magical there ‒ you have to get close to it, you just don’t have to go all the way***

## An efficient and effective resistance training program for beginners with limited time [49:00]

- That person is clinging to what Mike said earlier: you can get really good results if you spend 30 minutes in the gym, twice a week

**Tell me what that program looks like for a young person**

- A young person who has been somewhat active throughout their life, but mostly in sports
  - Tennis, cross-country, but they’ve never been a gym rat
- They’d like to have some hypertrophy and want to look a little better
- They’re 40-years-old and a little intimidated

*Mike explains what week 1 could look like, and it’s not the same every single week*

**⇒** For simplicity, say your training on Monday and Thursday

- You want some symmetry
  - You don’t want to train with weights on Monday and Tuesday and then spend time on other things for the rest of the week
- You want to train every major muscle group on Monday and Thursday
- Routines that have the muscle group separated are called **split-routines**: chest 1 day, back the next
  - Mostly pro-bodybuilders are the only ones that benefit from that, and there’s a lot of nuance about how to execute it

***Whole body training is probably best for almost everyone who is trying to get the health benefits, longevity benefits, the aesthetic benefits***

- You want to conserve time, but you want a high degree of effect
- Choose lifts
- Choose exercises that involve 2 components
- 1 – Exercises that train large muscle masses
  - You’re not going to be doing a lot of forearm curls or tibialis anterior calf raises
  - You’re going to be training muscles like the quadriceps, the glutes, the hamstrings, the musculature of the back, the chest, the shoulders, the arms
- 2 – Exercises that train more than 1 muscle at a time
- Then we’re using muscles very efficiently because we’re pushing multiple muscles to their limits in one exercise
- This is generally going to be **compound movements**, multi-joint movements, things like [pull-ups](https://youtu.be/NBOmFfctBWQ), [pull-downs](https://www.youtube.com/watch?v=5gL2XgHghLY), [barbell](https://www.youtube.com/watch?v=GIqICKwpUHw) and [dumbbell bent over rows](https://youtu.be/5PoEksoJNaw?si=0j27tIB4d5tsVHJJ)
  - They engage almost every muscle in the back and the forearm flexion muscles, the biceps
- You do 1 set of [bicep curls](https://youtu.be/21A1HD3swbs?si=UoYeXWjX4pWTudV2) (Mikes does 1 set of underhand pull-ups) and you got your videos and 3 other muscles checked off
- One of Mike’s pet peeves is to see personal trainers training a housewife who’s 55, and having her do rear deltoid cable fly one at a time (waste of time)
  - Was there some kind of physique show which the judges said she needs bigger rear delts, but nothing else?
- Other compound movements: [close grip bench presses](https://www.youtube.com/shorts/VYC2QZEOIUI), [push-ups](https://youtu.be/-z5guzTBmr4?si=uhsRBVgPX50cjr9r), [overhead presses](https://www.youtube.com/watch?v=0n86YPrgDBs&t=94s), [upright rows](https://youtu.be/V3h_1IUY-f0?si=rzGbAmWyGF6wVGFa), [squats](https://www.youtube.com/watch?v=o5WxCJfT6WM), [deadlifts](https://www.youtube.com/watch?v=WAn7OPr2RdE)

***Compound movements are insanely time efficient because you train your whole upper body in a few exercises***

Mike adds, “*If you do some kind of rowing machine, you do some kind of machine or barbell or dumbbell, that’s a close grip press, you do some kind of upright row situation, then you’ve technically trained every single muscle in your upper body to a substantial extent because every single exercise trains three or four muscles at a time.*”

Peter asks, “*What about for the lower body besides a deadlift and a squat?*”

- Various [stiff-legged deadlifts](https://youtu.be/bYFSqrikw2U?si=xY6_03l5kaD5rNFB) or [good morning](https://www.youtube.com/watch?v=nWyx81AfTos&pp=ygUYR29vZCBNb3JuaW5nIFByb3BlciBmb3Jt); [RDL](https://www.youtube.com/watch?v=0Sd1AZZ77aw&t=127s) is the same category of movement
- That trains your entire back, specifically your spinal erector musculature, which is insanely important for healthy aging
- It trains your glutes, your hamstrings, your sartorius, parts of your adductors, and it actually trains your calves too
- You integrate some kind of **lunging pattern** into that or some kind of **squatting pattern**
  - Be it a [hack squat](https://youtu.be/K4jvbLskI9g?si=YG0YbH_cLif3Rdgc), [leg press](https://www.youtube.com/watch?v=7H-KpNTYw_k), [barbell squat](https://www.youtube.com/shorts/OU43QxRmNhg), you name it, and all of a sudden you’ve run out of muscles to train in your lower body because everything has been done to a high degree of diligence
- When Mike sees 45-year-old financial advisors who don’t have a lot of time doing leg extensions in the gym he always hopes they have a good reason to be doing those
- Because if he’s not squatting or lunging or doing leg presses or something, he’s just using up time in the gym training one thing at a time for no good reason at all

**When this person’s coming into this situation and they don’t have a high training history, what are the tools you use to teach them how to do these compound movements safely, especially the lower body ones?**

- Squats and deadlifts are not going to be starting out with a ton of weight

**⇒** Start with low weight

- There’s no movement the human body can do which unloaded and not pushing the muscles and tendons to their extreme has any higher risk probability than any other movement
- You can start with a deadlift or a squat that’s body weight or less
- You can brace your arms on a [Smith machine](https://en.wikipedia.org/wiki/Smith_machine) and unload yourself while you squat
  - You take multiple sets like that that are very submaximal
- Ideally, you’re with a personal trainer
  - Because live communication about how to exercise is irreplaceable
  - Your assessment of what you’re doing is very difficult
- If not, you can use YouTube

**⇒** RP has a huge library for free on [YouTube](https://www.youtube.com/@RenaissancePeriodization/featured) and in the [RP hypertrophy app](https://rpstrength.com/pages/hypertrophy-app)

- Every exercise you’ll ever see in there has a video demonstration one click away
- If you’re working with a personal trainer, the first session is all about them taking you through movement patterns
  - Fine gunning technique with lots of encouragement
  - You’re not seeking perfection, just basic competency
- You begin with 3-4 **warm-up sets** per exercise
  - It’s a teaching session because they’ve never lifted heavy, never pushed to failure
  - They’ll get sore and it’s enough tension and disruption that they will grow muscle
- The next session you work through a different series of movements
- The next week, you do the same workout
  - A few technique oriented sets
  - Then go for slightly more repetitions: instead of 5, maybe now it’s 10
    - Or you put a little bit of weight on the bar
- Over time, slowly every week you increase the weight a little bit more
- Several weeks later, your technique looks real good

***Most people can learn really good techniques in a few weeks***

> “*That three or four week entry period is amazing because it takes the probability of injury and just almost completely eliminates it.*”‒ Mike Israetel

- In that entry period you’re not just going in and seeing how strong you are on the 1st day (profoundly stupid)
- After that easing in period, you’re now competent in the movements
  - You feel competent as a member of general gym culture (you don’t feel lost)
- You’re up to a weight and rep combination that’s challenging physiologically every set
  - Not just neurologically challenging for how to do the technique
- Over time you just increase the load on the bar a little bit
- And if you’re no longer getting sore or really tired, you start increasing the number of working sets
- Working sets wise, in the beginning you’re doing zero working sets ‒ they’re all **practice sets**
  - Because you’re so untrained, they’re work sets for you, but not to anyone else
- A few weeks after 2 work sets and so on until you’re doing anywhere between 3-6 **working sets** per exercise

**There’s another twist here for the person that wants to save a lot of time and actually get some cardiovascular benefits as well**

- Pair exercises to train muscles are are mostly unrelated
- For example: do a seated dumbbell shoulder press, rack those dumbbells and do some [goblet squats](https://www.youtube.com/watch?v=ubV_MaOsjDw) or [deadlifts](https://www.youtube.com/watch?v=WAn7OPr2RdE)
  - There’s no muscle overlap whatsoever
- You could do a nice hard set of seated dumbbell shoulder presses and sit for 1-2 minutes
- Or if you’re really time conscious and you want extra cardiovascular benefit, you take 5-10 seconds, breathe/shake it out and hit the next working set for that paired exercise
- While you’re doing the 2nd exercise, the muscles for the 1st exercise are recovering locally, and so when you’re done with the exercise 5 or 10 seconds later, it’s time for set 2 of the 1st exercise

***You pair these unrelated exercises such that when you’ve done 4 sets of 1 exercise with a 2nd, then you’ve really done 8 total working sets and knocked off 80% of your entire upper body in the amount of time it takes to do a dumbbell press by itself (which only trains the front delts and triceps)***

- Another example: pair a [close-grip bench press](https://www.youtube.com/shorts/VYC2QZEOIUI) with a [row](https://www.youtube.com/watch?v=5PoEksoJNaw&pp=ygUaRGIgYmVudCBvdmVyIHJvdyB0ZWNobmlxdWU%3D) or [lat pull-down](https://www.youtube.com/shorts/gFHQ5S6rPwo)

Mike advises, “*Rest times in the gym (outside of getting a drink or just trying not to faint) are probably not your best friend if you’re just going for general health, general aesthetics, this kind of stuff, especially beginning.*”

- You’re either working one muscle group or several with one exercise
- Or you’re transitioning between exercises
- Or you’re working the other one
- Or you’re setting up your weights for your next machine that you’re going to be doing
- Which means as soon as you get in and warm up, it’s go, go, go, back to back to back to back
- You’re 5 or 10 seconds for transition, to catch your breath barely, you’re not going to be talking to a lot of people at the gym

***That allows us to condense a lot of work into 30 minutes, and most people will need something like 15 to 30 total working sets for their whole body per session***

- You’re working almost the entire time

**⇒** Generally it’s a good idea to do sets of 10 to 30 repetitions because those kinds of loads don’t need a ton of time to have your best performance

- You can get good enough performances with a short time for recovery
- And because it’s a lot of reps, not only does it get you very meaningful strength increases because the absolute load is lower, much lower injury risks
- Look, you do one-rep maxes all the time, you’re going to have it coming one way or another

***If you never touch a weight that’s heavier than a 10-rep max, the probability of an injury in one given set is much, much smaller; and because it’s a higher volume of work, you get a great hypertrophy stimulus and you get great cardiometabolic benefits***

> “*You do a set of 15 barbell squats followed by a set of 15 push-ups, your cardio’s working*.”‒ Mike Israetel

**Mike’s training prescription**

- You have 2 sessions like that per week (each one lasting 30 minutes)
- You have 2 sessions of Zone 2/Zone 3 cardio where you’re really trying
- 4 sessions total per week, with good sleep and good body weight, good nutrition and you’re well on your way
- If you look at the American College of Sports Medicine [requirements](https://www.acsm.org/education-resources/trending-topics-resources/physical-activity-guidelines) of what constitutes rigorous physical activity, this combination adds up to a total of 2-3 hours of difficult physical activity a week
- Mike gets it when people say, “*I don’t have time for exercise.*”
  - He’s heard that when you have children time dilates like black hole tech stuff

**⇒** You can probably make time at least for that resistance training session

- Will it be ultra easy? No way
  - It’s going to be really tough
- Mike doesn’t train like that, he needs his break
  - He’s trying to be lazy and scroll on Instagram between sets
- But if you want to get the maximum results for the minimum amount of you, you’re working all the time

*Back to Mike’s advice*

- You start with 1 or 2 paired sets
- Then you get up to 3 or 4 paired sets on 5-8 exercises per session and that’s a lot of work

***It will train your entire body in one session and you will require 1-3 days of rest afterwards***

- You rest for 2 days and you come back
- There’s 2 workouts in a week, and each one takes about half an hour
- If you ever want the workouts to take less time, work faster and rest less
- Yeah, it’s going to hurt
- It’s going to be miserable, unless you accept the fact that you know all the benefits of endorphins and everything like that
- It’s kind of like how do you become a millionaire?
  - You’re very, very good at something
  - You get very, very good people skills and you grind for years starting your empire

**This is going to be tough, but also there is now more and more research accumulating that doing difficult things physically is good for your mental health**

- There’s a lot of publicity lately on cold plunges, [Huberman](https://www.hubermanlab.com/topics/heat-exposure-and-cold-exposure-to-optimize-health) and all that stuff
- A cold plunge because it’s so annoying, it makes you more grateful for the “not pain” you’re engaging in the rest of the day and it’s really good for you

*Mike has a better one*

- You do a 30-minute session of back to back to back compound free motion or dumbbell or barbell or even machine work and sweat your balls off and huff, and puff ‒ the rest of the day seems like a breeze and the endorphin kick is massive
- The cold plunge has some benefits, Mike is not entirely sold that they’re enormous in many cases

***This kind of resistance exercise has benefits that if we just took one-by-one time to talk about on this podcast, we could talk about nothing else and do 4 podcasts in a row (that kind of massive benefit)***

## Advice for finding a good trainer [1:06:30]

**What are the questions that a person can be asking when they go into their gym or are looking online for a trainer?**

- Peter points out that it’s hard enough to find a good doctor, and that’s a highly regulated industry
- It’s probably even more difficult to figure out if a trainer is really good
- You want a person to help you learn to do a squat and a deadlift safely
- A person who can integrate whatever pre-existing injuries you have
- Mike agrees, it’s very tough
  - Because if you aren’t an expert or a very knowledgeable person yourself, it’s very difficult to figure out who is doing a good job
- Mike has no idea how to measure a good doctor versus not a good doctor
  - Most doctors are equally confident in telling you what they think is going on and very differentially accurate
  - It’s a tough question
- You want to chat with them and ask a few questions
- These are all marginal pieces of advice; there’s no absolute
- 1 – The thing that comes close to the absolute of having a high guarantee that they’re good at what they do is if they’re certified in the [Menno Henselmans PT course](https://mennohenselmans.com/online-pt-course/)
  - Menno is an expert in this field
  - Trainers that he certifies have a high probability of being able to deliver to you what it is that you want out of them
- There are other fine certifications out in the world, but a lot of certifications, if you are just reasonably intelligent and you studied for an hour and voila, you’re certified
  - So the certification doesn’t go very far
- 2 – It helps if your trainer has an undergraduate in kinesiology or some related field
  - That is not by itself ensuring you that they’re going to be good, but it sloughs off a lot of backend
  - You’re going to get rid of a lot of not great trainers
- 3 – You can almost entirely ignore what they look like because the preponderance of the reason people look like they do is genetics
  - The other is diet
  - The other is just how long have they been doing stupid or smart things to their body
  - So don’t just think a trainer knows what they’re doing because they’re ripped (he can’t give you his genetics)
- 4 – Understanding the scientific literature, especially just the broad strokes basics, and you’re probably in better hands than not
  - If someone can explain to you the reasons for why you are doing certain things
  - Ask them if it’s okay if you voice note, record them, and when you get home feed that into [Claude 3.5](https://www.anthropic.com/news/claude-3-5-sonnet) or [GPT40](https://chatbotapp.ai/landing-gpt4o)
    - All these [LLMs](https://en.wikipedia.org/wiki/Large_language_model) are designed to be insanely agreeable and very kind, but when you’re wrong, wrong, they’ll be like, “*That’s a good point, however…*” 8 point list
  - Then you’ll know if they’re right or an idiot
- 5 – There’s a big factor of how you get along with the trainer
  - You’re going to want to find the training ideally as pleasant as possible
  - If the trainer is someone that you just kind of vibe with, they can dig into you and really get you going, but they’re also super fun to talk to outside of when you’re not dying during training
  - If they can get you to become responsible for showing up on time in a sense of you and your trainer are on the same team
  - Even if they’re not super evidence-based, they just get you in and get you moving: that’s half the battle right there
- 6 – Have a trainer for a few weeks, few months and see if they know things or not
  - Some of your trainers will suck and you might need a few weeks, a few months to realize, “*Man, everything I’ve heard about how this whole process works, my trainer doesn’t even agree with me.*”
- *Analogy*: the 1st car you buy might just be a thing that has a steering wheel and wheels and goes places
  - And after you’ve appreciated what is you don’t like about your car, your next car could be a bit more of an educated purchase

## Troubleshooting training plateaus: optimizing exercise selection, intensity, and recovery for muscle growth [1:13:30]

**Advice for the person who’s been lifting weights for a long time**

- This person is in the gym 3-4x a week (an hour at a time), but they’re not happy about their progress

Mike asks, “*How hard are they working? Are they really trying, or are we saying that maybe they’re trying, maybe they’re not?*”

- It’s a very different answer if they’re trying or if they’re not

*Let’s say they’re trying quite hard, and they want to be really jacked*

- You look at them and think they might be slightly over training
- Let’s say they’re training the whole body 3 days a week and they’re in there 90 minutes at a time
  - They’re going to 1 to 2 rep in reserve on every set
  - They’re hitting 20 to 30 sets per body part per workout

*Mike’s approach*

- 1 – You would need to go down a a troubleshooting checklist
  - On the [RP Strength YouTube channel](https://www.youtube.com/@RenaissancePeriodization), there are multiple videos of how to troubleshoot your [muscle growth](https://youtu.be/PAlLYTHeKLc?si=uwD17mS8y9oJtcAg), how to troubleshoot your [diet](https://youtu.be/Qvf9kgkPjs4?si=QEiBVT2Beb6k2PWL), how to troubleshoot your [recovery](https://youtu.be/bZod37igzQk?si=6nkMaRkQtTIUtaZD) [[lack of progress](https://youtu.be/rKaw-Z3Jb90?si=4NdUcuNI2nhSgJQY)]
- 2 – You can consider yourself with variables that occur in the gym
- 3 – You can consider yourself with variables that occur outside of the gym

**Variables that occur in the gym**

- One variable is **exercise selection**
  - For example if your arms aren’t as big as you want, and you’re only doing underhand pull-ups and close-group bench press
  - Add in a few sets of curls and triceps extensions

**⇒** A lot of times people don’t have the specific exercise selection for what it is they want; they’re just doing general training

- Another variable to consider is **technique**
  - Some people have not so great technique
  - Good technique involves putting the muscle into high force positions at a very deep stretch, long muscle lengths at high forces
  - For example, doing pec flies but you’re only going all the way down to here when you need to open up like crazy and take a few seconds down there in the deep stretch
  - Technique is so exercise specific and so individual that you really should get a qualified trainer, or someone you trust, or videos on your own analysis
- Another question you have to ask is about **volume and volume intensity**
  - If you’re hitting 2 reps in reserve, no need to improve above that
  - But if you observed them and at the end of their set you asked them to do a few more, and they were consistently getting 4 more reps (4 reps in reserve), then they’re not hitting enough training stimulus
    - This is an important one
- Peter talked about this on [Instagram](https://www.instagram.com/peterattiamd/reel/CpP3ifkDKDF/) and the point he wanted to make is that you don’t know what 2 resps in reserve means until you go to failure
  - You have to fail many times to actually know how bad 2 reps in reserve is and 1 rep in reserve
  - And they’re not the same every workout

Peter adds, “*You fail at a different number of reps, but there’s like a signal, there’s a twitch, there’s a discomfort that you have to experience, but you can’t experience it until you blow past it.*”

- In the [RP app](https://rpstrength.com/pages/hypertrophy-app), there’s a good system to help you test the waters and determine that
  - The app will ask you to put in your weights, roughly 10 to 20 rep maxes, and you’ll do as many reps as you think is 3 reps or 4 reps to failure, depending on what it’s wanting you to do, and you’ll write your repetitions in for every single set
    - Maybe it’s 16 reps at 90  lbs. on this exercise
  - The next week, the app auto programs a progression for you
    - It’ll either ask you to do 17 reps at 90 lbs., or it’ll ask you to do 95 lbs. anew for the 16 reps you did last time
  - It does that every single session; it pushes you a little bit ahead
  - Your only job is to do what is written
- *Problem*: At the end of your cycle, if  you never actually failed at a weight ‒ you’ve never trained close to failure
  - Example of failure: you tried to get to 17 reps, you got 16 but 17 wouldn’t move and you had to put the bar down
- *Solution*: The next time you program in your weights and you do 3 reps in reserve for that first week, go a little harder than you think you should
  - Then at some point during the middle or end of that cycle, you will actually hit failure trying to get to those objective targets

*Here’s the big problem with trying to estimate failure*

- If you go based on how hard something feels, it’s different
  - Like you had a tough day at work versus an easy day; you ate well versus you didn’t; you slept well versus you didn’t
  - It’s all perceptual, which is nuts
- *Analogy*: it’s like not having a mirror but asking someone to stand in front of you and help you put on makeup
  - Thanks for your input, but I need a frigging mirror because I don’t know if you’re just messing with me
    - Do I look like a clown; did I put lipstick over here instead of on my lips (who knows)?

*If you have an* ***objective criteria****: this is what you did last week and you want to go a little bit beyond*

- Inevitably 1 of 2 things will happen over the long term
- 1 – You will reach muscular failure and you will be unable to do a repetition (more realistic)
- 2 – You will get infinitely strong forever and now you’re Superman
- *Solution*: Put numbers on a board and add 2.5-5 lbs. or 1 rep each week (that’s the goal)
- If you can’t do it, success ‒ you went to failure
  - Now you know where the limit is
  - Now you’re building intuition
- If you did get those numbers, next week you go higher, and you go higher

**What volume would be a red flag where you would say a volume/sets per body part was below X?**

- In the beginning, a few sets are totally fine
- For an intermediate person, below 5 or 10 sets per week is not sufficient effort to expect your best results

***10-20 sets per week is fine, but for many people you have to use a second qualifier, which is what is actually happening to you***

- If you aren’t getting super sore or super mega tired in your muscles a day or 2 after training
- If your strength continues to be stable or increases session to session to session and you’re on that fewer than 20 work sets per muscle per week
  - Per muscle, not per body part
  - In other words, bicep would need to be 20 sets per week (wow)

Peter realizes, “*I think we have a pretty good explanation for why somebody at this table has small biceps.*”

*You’ll be able to intuit rather quickly if it’s too little or too much*

- If all of the signs show that you’re not actually excessively fatigued, your **volume is either okay or less than it could be**
- If you’re not getting great results visually, but you’re always running into strength plateaus, if you’re always tired and sore, and if you’re north of 20 sets per muscle per week, on average hard sets, then probably doing less is good because you have almost every **indicator of doing too much**

*The other variable involved in the gym: when is the last time you took a break?*

- There is a concept called **cumulative fatigue**: your muscles and the rest of your body recover very well between sessions, but not 100% (maybe 90 or 95%)
- If you’re a mathematics fan, if you multiply 0.95 by 0.95 by 0.92 by 0.9 by 0.95 enough, you’re down to 50% recovery within 6 or 8 weeks
- And then how could you possibly be making gains?

***Solution: for the average person, 1 week every 2 months, don’t go to the gym***

- Stay active, maybe do a bodyweight squat or push-up or 2
- Ideally, try going on vacation
- Have some fun, eat some cheat foods, and be a little less active so that your body can recover in a way that it can never recover between sessions
- But it gets a whole week to do this

***And once a year, take 2 weeks like that ‒ active rest***

- One week off is called a [deload](https://health.clevelandclinic.org/deload-week) [[RP video](https://youtu.be/mo91YlX8eew?si=o0rc5dcSiNU_pGZ4)]
- When you take 2 weeks off in a row, and you do the lightest, easiest stuff (10 minutes) ‒ that reduces your systemic cumulative fatigue so much that it brings it back down to almost zero
- Some people will say, “*Look, 16 weeks I’ve been cranking. First 12 weeks, great results. Last 4 weeks, I don’t know if I’m moving the needle*.”
  - Well, maybe you’re just really tired
  - Pushing the pedal down harder is usually not the best way to do things
  - It might be time for a break

**⇒** Your muscles resensitize to the stimulus if you take time off

*When you come back*

- Go back to 2 or 3 sets of everything, not 4 or 5 sets of everything
- You’re going to get really sore and really pumped from just a few sets, and you’re going to be growing again
- You do that for another 6-8 weeks, you get tired again, your strength starts to plateau, take another week of easy training or no training at all, and that’s how the cycle repeats itself

**Mike now takes the time to find out about someone’s frame of reference**

- Before he consults people on how to pursue incrementally more optimal outcomes for muscle growth
- He wants to know
  - What have their gains been like?
  - How much work have they been putting in?
  - How long have they been training?
  - He wants to see how genetics play and age a role in this
- Mike has consulted people who were in their 60s, weighing about 150 lbs. and they aspire to be in the low-mid 200s, fairly lean
  - He told them, “*Outside of an anabolic steroid cycle that’s probably got an even chance of killing you as it does of getting you jacked, you’re not going to get that jacked, and your progress rate is just going to be much slower than the 20-year-olds at your gym.*”

**⇒** Sometimes we forget that age has a profound effect on our results (when we look around at all the young people)

Peter asks, “*Do you attribute this to the hypertrophy of* [*type II fibers*](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)*, which are necessary for the power generation that’s necessary for producing the gains we’re talking about?*”

- That’s definitely a component of it
- Another component is overall systemic ability to **recover**
  - You have so much DNA methylation and all this other kind of damage and accretion of the wear and tear of age that your organelles and your cells don’t work as well as they used to
  - Your organs don’t work as well as they used to
  - A lot of times you’re taking for granted the fact that now in your mid-sixties you run a top 500 corporation and you have more stress than most people could handle in a day
    - You have that in an hour
    - But back when you were making the gains of your life when you were 18, your job was to show up to school, go to the gym, eat at the cafeteria, and smoke weed
    - Of course you have the gains of your life
    - People discount that
- People look to athletes and go, “*Oh, my God. That bikini competitor, she looks amazing. I want that body.*”
  - Well Linda, you’re 56, you have 3 children (1 in college, 2 are not), you are a CTO for a major company, and you sleep 5 hours a night
  - That bikini competitor trains a few clients, she posts on [OnlyFans](https://onlyfans.com/) and she does nothing else other than train, recover, and watch Netflix, and sleep 9 hours a night of uninterrupted sleep (she’s also 27)
  - It’s two completely different worlds

> “*With social media, there is nothing that surprises me anymore about how unmoored some people can be from realistic expectations.*”‒ Mike Israetel

## The impact of genetics, age, and lifestyle on muscle growth [1:27:45]

**Genetics is the most important factor other than time spent in the gym**

- You have to understand that your goals have to be referenced to what your genetic likelihood of achieving them are
- The only way you’ll find that out is if you work at it for a while and see what happens
- Some people work at resistance training for 3 years ‒ they’ll accrue 5 lbs. of muscle, burn 3 lbs. of fat, and they’ll be like, “*This next year, I want to gain 10 pounds of muscle.*”
  - That’s not how hyperbolic curves and asymptotic curves work
  - You got it backwards
  - If in 3 years you gain 10 lbs. of muscle, in the next 3 years maybe you can gain 5
    - That’s realistic
    - It does not work in reverse

**It’s really important to contextualize multiple qualities**

- 1- How much recovery, and rest, and relaxation time do you get compared to work and being under-slept
- 2 – Genetics
- 3 – Age

Mike adds, “*The reason I’m ranting about this, Peter, is because I’ve had many clients who were willing to put in whatever work it was going to be necessary to put in, but they were older, they did not have particularly great genetics, and they had already gotten most of the muscle gain that they were going to get. Not all, but most.*”

- So outside of pharmaceutical enhancement, what they were asking for was impossible

***The biggest factors for results are that trifecta along with how much of a professional bodybuilder or fitness person do you want to be for the next several months***

> “*People will arbitrarily assign themselves an amount of muscle they want. It does not work like that*.”‒ Mike Israetel

- Put in the diligence, put in the time, see how it goes
- If things are going well, you can crank it up a little bit and get a little bit better gains
- It’s going to take time
- If things are not going so well, you have to optimize to make them go a little better

***Outside of the basics, you’re not going to be able to get a category leap of results short of a great pharmaceutical renaissance***

**Mike predicts the early 2030s will be the great pharmaceutical renaissance**

- Then you can just turn [myostatin](https://en.wikipedia.org/wiki/Myostatin) off and get as jacked as you want
- Until then, realism can be a painful pill to swallow
- Peter thinks it will be interesting to see if we can turn myostatin off in adults and if it will have the same impact that it has in the cartoons
- Animals that are myostatin knockouts are some of the most enjoyable things to look at

![](https://peterattiamd.com/wp-content/uploads/2025/02/f5-mikeisraetel.png)

**Figure 5.** Myostatin deficient bull. Image credit: [*PNAS* 1997](https://www.pnas.org/doi/10.1073/pnas.94.23.12457)

**⇒** It’s not clear if you took a mature adult and inhibited myostatin if you would get the same benefits

## The importance of nutrition, protein intake, and consistency in both training and diet for muscle growth [1:31:00]

**When something out of the gym is playing a role in your unjackedness, is nutrition often a factor or is that generally not?**

*In other words, is it so rare that someone is not getting enough protein or not getting enough calories that that’s the problem?*

- It’s a thing
- Maybe more with women and older women than men
- You may even see more **anabolic resistance** in older men
- Mike thinks it’s not difficult to align your nutrition well, eat mostly healthy foods, some junk here and there is totally fine, getting in enough protein

Mike’s advises, “*If you want to be real serious about optimizing your muscle gains, something like a gram per pound protein per day.*”

- So if you weigh 150 pounds, 150 grams of relatively high quality protein

***Get a couple boxes of*** [***David Bars***](https://davidprotein.com/collections/shop-bars) ***and eat them between meals, and that takes care of protein***

- The other thing is muscle size is philosophically concordant with being bigger
  - Muscle’s made of stuff
  - So when someone wants to be 165 pounds jacked at 150 pounds, it’s curious how they think that’s ever going to happen
  - ***Some people just don’t eat enough***
- The biggest problem Mike has seen is lack of consistency (intermittency)
- He’s had so many clients in the professional realm, older folks who do very good for a couple days, then they fall off the wagon for days at a time

***Lack of consistency is a surefire way to guarantee that you don’t get very good gains***

**Reasonable expectations for muscle growth and how to achieve them**

- If you want to get as jacked as possible within the realm of several months time
- Seek to eat enough food to get the scale to go up about half a pound per week

***If you training hard for 12 weeks, you should gain maybe 6 lbs. or so***

- And if you’re eating a gram per pound per day of protein spread into roughly 3-4 evenly spaced meals, that really is all you need to know about nutrition for how to get jacked
  - Very roughly, a lot of wiggle room there
- That covers probably 90% of the variance

**The 80/20 rule**

- As discussed earlier with [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates), how how we could do so few cents to get so many results
- That 80/20 type of rule applies to almost everything else in the human body, including nutrition
- If you’re getting enough protein regularly and you’re getting enough calories to gain body weight, if you don’t get really the muscle gains that you were expecting, there aren’t a lot of knobs and levers for us to pull that are going to get these enormous results
  - That’s the situation for nutrition

**⇒** Mike can’t say enough about consistency, especially when you’re older and you have lots of stress from your professional endeavors

- Now if you do everything right 5 or 6 days of the week and 1 day is meh, you’ll do great
- But if the good days are outnumbered by the “*I sure hope my trainer doesn’t find out about these days*,” you’re not doing your due diligence

## The use of anabolic steroids to boost muscle growth: doses, drug combinations, and side effects [1:35:45]

- Mike mentioned the topic of anabolic steroids earlier and has spoken very openly about them
- Peter has talked about them [episodes [#274](https://peterattiamd.com/derekmpmd/) , [#291](https://peterattiamd.com/derekmpmd2/), [#196](https://peterattiamd.com/ama32/), [#180](https://peterattiamd.com/preview-ama-28-all-things-testosterone-and-testosterone-replacement-therapy/)]

**⇒** A couple times already, Mike has made the point: your genes are genes are going to start to become your limit

Peter adds, “*There’s some confusion about: is testosterone and anabolic steroid. And of course, the answer is absolutely yes, it is.*”

**Non-medical anabolic steroid use**

- Let’s take [testosterone replacement therapy (TRT)](https://en.wikipedia.org/wiki/Androgen_replacement_therapy) where testosterone in a hypogonadal man is restored to typically the upper limit of a normal physiologic range
  - Give everyone good genetics
- We’ll take that off the table for a moment
  - Park it in the context of what does anabolic-androgenic steroid use look like in the physique bodybuilding community

*The pros and cons of different drugs, how much it can unleash, and Mike’s experience*

- [Anabolic-androgenic steroids](https://en.wikipedia.org/wiki/Anabolic_steroid) are all derivatives of the testosterone molecule manipulated in various ways to accentuate some characteristics and de-emphasize other characteristics
- They’re typically taken by athletes in the competitive sphere, bodybuilders, physique athletes, and gym people who want a super physiological level of muscle mass and sometimes super physiologically low levels of body fat concomitant with that
- They’ll take anywhere between high-end testosterone replacement therapy dose to 10 or 20 times that amount per week

*Peter has talked about TRT before in the* [*podcast*](https://peterattiamd.com/preview-ama-28-all-things-testosterone-and-testosterone-replacement-therapy/) *and wants to give people some doses*

- He typically doses patients twice a week to try to get a smoother level as opposed to once a week
- If the ideal dose for a given individual to get them in the right spot is a 100 mg of [testosterone cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) weekly, we would always prefer that the patient take 50 mg intramuscularly twice a week or [sub-Q](https://en.wikipedia.org/wiki/Subcutaneous_administration)
- Peter doesn’t think he’s ever given a patient more than 70 mg twice a week (or 140 mg a week)
- The median dose for physiologic replacement is probably 40 mg twice a week (or 80 mg a week)

Peter asks, “*Are you saying that there are people out there that would routinely take 800 to 1600 milligrams of testosterone in a week?*”

- Oh, yeah

***Sometimes that’s not all testosterone, it’s other steroids in combination***

- Usually people take at least that replacement level of testosterone, often more, because testosterone does some really good things for health and general function

**Testosterone tends to aromatize into estrogen quite readily**

- Which is good because estrogen is cardioprotective, neuroprotective, increases your strength, helps your mood, helps your sex drive
- Estrogen actually increases your anabolism in the presence of androgenic steroids and testosterone
- Estrogen by itself, not very anabolic, but estrogen in the presence of testosterone is more anabolic than if you had all the testosterone in the world, but we’re unable to aromatize estrogen

***Baseline low testosterone is often taken at somewhere between 250 mg a week and all the way up to a 1000 mg a week***

- Depending on how you’re handling the side effects of that excess estrogen production at the higher levels

**⇒** That’s usually taken as [enanthate](https://en.wikipedia.org/wiki/Testosterone_enanthate), [cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate), some people prefer [propionate](https://en.wikipedia.org/wiki/Testosterone_propionate) if they inject every day

**Once daily injections seem to provide the smoothest curve**

- If you put in half a week’s worth of super physiological testosterone at one time, your mood for the next several hours is curious

*Help me understand what that feels like; let’s say your taking 700 mg a week (100 mg a day), that’s a 7x physiologic dose*

- Most people feel something
- But it’s probably a normally distributed population of experiences where some people just can’t tell
- Some people feel something for sure that they can describe
- Some people have panic attacks and will never use again
- Or they are driven to extreme violent thoughts and extreme sexual thoughts and actions
  - Those folks are quite rare, but they do happen
- The average effect of a high degree of anabolic steroids (for simplicity, testosterone) is to imagine what is the average psychological proclivity of a female, what is the average psychological proclivity of a male, different in many regards, and then you move the needle over one notch into **a magical category called “enhanced male”**

***You typically exhibit more male-like patterns of thought and behavior than even males do ‒ steroids don’t accentuate every quality you have, just the more masculine qualities***

- A recent video on the RP Strength channel talks about this: [Roid Rage is REAL](https://youtu.be/AJcc2xFRm74?si=IEtUsft0B5lPZ9J7)

*What are the most masculine qualities?*

- This hits everyone a little bit differently, but on average you become quieter
- Men typically are not as expressive as women
- You come to show fewer facial expressions of emotion
- You don’t process other people’s emotions as well
- You can’t fine-tune what they feel as much, and you don’t care as much
- Way less empathy
- You are more likely to be irritable
  - More likely to have anger and aggressive sorts of thoughts
- You become more attuned to the dominance hierarchy in general
- You become someone who thinks more about where you stack up in the dominance hierarchy in a way that you take affronts and slights more poorly than otherwise
  - For example, if someone on social media says you’re a bad person, if you’re not on a lot of testosterone, you might think that person is having a bad day
  - If you’re on a lot of testosterone, you’re more likely to be like, “*I wonder if he’d say that to my face. I wonder if he would be real quiet around me because he would know that I’m not someone to be messed with*.” (weird thoughts like that)
    - Women almost never have thoughts like that
    - Men have regular thoughts like that in the right context
    - People on steroids have more thoughts like that in almost every context than they would like to have
- You become linguistically less expressive and your fluidity of communication falls
  - It’s generally not good for most relationships
- Sex drive is another one
  - It’s difficult for women to appreciate what the male sex drive is like on a quantitative and qualitative level
  - Both of those tend to magnify, especially if you’re not bringing your estrogen down
  - If you bring estrogen low enough, you don’t even remember what the hell sex is for, why people are even in that sort of thing
  - But if you have a lot of androgens, a lot of estrogen, the hunger, the thirst becomes very annoying

Peter asks, “*At that level of testosterone, are you taking an aromatase inhibitor?… I can’t imagine how high the estradiol level becomes… Typically estradiol would be over 100 at that point. That’s left alone?*”

- It depends on a few things
- Different people respond differently, both physique and psychology, to high levels of estrogen
- High levels of estrogen for some people are like swimming in a pool of magical clouds, and they love it and their physique looks great
  - They get nice and watery; their joints feel amazing
  - Their recovery’s awesome
  - Their sleep is awesome
  - Sex drive’s awesome
  - Everything’s great
- For some other people, they get a lot of estrogen and it actually prevents them from getting good sleep at higher levels
  - They’re water buffalo bloated and they can’t even see their abs anymore, even though they’re 8% body fat
  - They get mood swings, all this crazy stuff
- Peter finds this amazing and not entirely unlike women if they’re undergoing hormone replacement therapy in perimenopause
  - It’s not a one-size-fits-all
  - They can have tremendous variability in their response to estrogen and, of course, progesterone

**The other thing is what we’re learning in evidence-based approach to anabolic steroid utilization and performance-enhancing drug utilization is called the “safer use model”**

- Probably the biggest promulgator of it is a gentleman named [Joe Jeffery](https://www.instagram.com/joe_physiquecollective/?hl=en) in the United Kingdom
  - Super, super expert, exceptional bodybuilding coach
  - Great bodybuilder in his own right
  - He just reads literature all day long
- Folks like him tend to espouse that probably the best way to manage estrogen is to ***use some combination of exogenous drugs that are androgens themselves*** to get the estrogen level you have the best notable metrics at, how you feel, how you look, how your blood work is, health, etc.

*Here’s an example: you take a 1000 mg of testosterone*

- It actually goes into your thigh in a needle
- It’s intense; it’s a lot
- And that comes with a concomitant aromatization, so you have a lot of estrogen
- Some people, they feel totally great
- For some people it’s too much
- For those that it’s too much estrogen, they might be able to take 500 mg of testosterone and then 500 mg of Primobolan (a 50/50 split)
  - Now they get all the good estrogen from testosterone, but not too much of it
  - They get most of that anabolic drive from the rest of the Primobolan, but without the addition of any more estrogen
  - It could be 250 testosterone and 750 mg of Primo; it could be 750 test and 250 Primo (and anything inbetween)
- [Primobolan](https://en.wikipedia.org/wiki/Metenolone_acetate#) is a synthetic anabolic-androgenic steroid developed in the ’60s, and it’s designed not really to convert into estrogen hardly at all
- Other steroids like it are [Masteron](https://en.wikipedia.org/wiki/Drostanolone_propionate)
  - They not only don’t convert into estrogen, but they actually antagonize estrogen conversion for the testosterone you’re shooting in to some extent
- A lot of bodybuilding coaches have the wisdom to know works for most people; they will start you on a certain cycle and then level up one drug, level down another to get that androgen-to-estrogen ratio to be something that you have your best performance at, best health
- The sex drive component, especially if you have a lot of estrogen going on, qualitatively it can change
- For Mike personally, he never got enormous sex drive upregulation
  - He got some, but nothing crazy
  - And he’s been as high as just north of 2000 mg per week
  - Currently, he’s at 250 mg per week, but his sex drive is more or less the same

Peter asks, “*Is there any difference in androgen receptor expression that you’re able to appreciate between 250 and 2000? Are you so saturated in your androgen receptors already that… Do we actually know if there’s a benefit to all the additional testosterone that you could have been on at almost 10X, your current dose 8X.*”

- You won’t know until you try

**Did you appreciate a difference in positive effects [with high doses of testosterone]?**

*Peter doesn’t doubt that there could be a difference in negative effects, but if the positive effects are accrued through testosterone binding to the androgen receptor, that complex leading to more nuclear transcription, wouldn’t what you said suggest that you might have already hit maximum benefit at 250 [mg per week]?*

- Yeah
- There are some reasons to believe that your [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor) density escalates up when exposed to more androgens and not down in some cases
- And so that means the more gear [steroids] you take, the more benefit you have rather linearly

***In Mike’s experience (and the experience of most people you talk to), it’s again slow newsreel, same asymptotic curvilinear relationship***

- This is something Mike didn’t discover until quite recently
- He probably gets almost the same gains at 1000 mg that he does at 2000
- Anything north 1500 mg just drives Mike mentally insane and seems to not really affect his physique hardly at all

**Side effects of high doses of testosterone**

Peter asks, “*How much water retention do you get at these doses?*”

- Considerable
- Although if you manage your estrogen well, it’s not as much as you would think

Peter asks, “*Managing estrogen with aromatase inhibitors?*”

- [Aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor) in many cases are incredibly toxic drugs and you generally want to avoid taking them if you can
- Sometimes you have to get really dry for a contest, but that’s only a few weeks out from the show, and so the modern wisdom with the evidence-based crowd (the safer use crowd) is to manage your estrogen with differential amounts of testosterone and non-estrogenically converting compounds like Primobolan and Masteron versus taking just as much testosterone as you ever would
- But taking an aromatase inhibitor on top of that because aromatase inhibitors in a unbelievable range of circumstances, fuck you up
  - They’re neurotoxic, they’re cardiovascularly toxic
  - It’s bad, bad news
  - These are the compounds you use when you have breast cancer and they’re like, “*You’re going to die if you don’t take these*.”
    - They are gigantic hammers for a very small nail
- If you want to see who’s done the worst to their health across the bodybuilding industry, it’s whoever runs the most AIs, as we call them (aromatase inhibitors)

***There are various other pharmaceutical ways to control estrogen than using aromatase inhibitors***

- Probably the best way for health and effect is only use as much estrogenically converting drugs, [Nandrolone](https://en.wikipedia.org/wiki/Nandrolone) derivatives and testosterone as you need to get whatever estrogen you feel best at
- And the rest of the anabolic load should come from things like Primobolan and Masteron that don’t really do much to your estrogen at all, but increase your androgen and anabolism

**How do you differentiate between when you’re using testosterone versus Nandrolone?**

- Mostly by experience
- [Nandrolone](https://en.wikipedia.org/wiki/Nandrolone_decanoate) has some really cool positive effects, kind of exaggerated versions of testosterone
- Some people are naturally very dry and so if they don’t take a Nandrolone for their very hard training cycles, they will have insufficient body and joint water, hydration
  - Joints will creak and they’ll get hurt a lot and it’s just really bad recovery
  - But you put them on a Nandrolone variant and all of a sudden they have enough intramuscular and intra-joint water to where they feel great everything’s working
- Other people will get on Nandrolones and have so many of the side effects
  - Way too much estrogen conversion
  - They feel like a giant water buffalo
  - If they just take testosterone, they’re plenty hydrated, so they don’t need to do that
- Nandrolones also have this curious side effect, it’s colloquially termed “Deca Dick”
  - [Nandrolone decanoate](https://en.wikipedia.org/wiki/Nandrolone_decanoate) is a substance, brand name called Deca
  - It is erectile dysfunction approximately caused by the presence of Nandrolones
  - It’s curious because Nandrolones typically with their estrogenic effects, elevate sex drive
    - The more estrogen you have to a point, the more sex drive you have if you have presence of androgens (testosterone)
  - So you’re horny, but little Billy down there doesn’t work as well as he used to (or at all)
  - That’s a tradeoff between that and the training benefit

**Mike’s advice**

- Generally, there’s nothing better than to start out with a solid plan that makes sense with a coach that knows what they’re doing
- Start at very low doses of everything and slowly play with compounds and scale up
- Highly note your beneficial effects and highly note your deleterious effects (or downsides), and see where you can strike a balance that’s acceptable to you
  - And considers long-term consequences

## Long-term impact of steroid use on muscle retention, the role of genetics and individual variability, and their impact after discontinuation [1:52:15]

**How old are you, Mike?**

- 40
- He knows he looks 50 (not where Peter was going)
- Peter is guessing that Mike has good genes, eats well, trains very hard, and is using enough anabolic steroids to fuel a small country
- If we subtracted that last one out of the equation because I don’t have a sense of what the relative contribution is, what would you look like if you did everything the same minus the anabolic steroids or if you were on regular TRT?
  - Regular TRT: taking a 200 mg of [cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) a week

**Do you have a sense to quantify how many pounds lighter you would be in terms of total muscle mass?**

Mike asks, “*Having had used steroids before at high doses or not having ever had used them? Very different answer*.”

- Mike started using high doses of anabolic steroids when he was 27 years old
- Let’s go back to when he was 27 and put him on the same path of training intensity, all of the scientific principles that come into it, etc., but he’s never gone down the path of taking megadoses of steroids
  - And if he ever took testosterone, it’s literally to bring his total T up to 800 ng/dL

***At Mike’s current body fat, he would weigh 200 lbs. (versus 230, 235)***

- Now 35 lbs. of muscle is a lot of muscle
- He would still be very jacked

**Before he ever started taking anabolic steroids, he was already an elite power lifter**

- He weighed 270 lbs. and had probably 30+% body fat
- He DEXA-ed himself in a Master’s program when he was totally drug free and he had a fat-free mass between 175-185
  - He’s 5’6”
  - His FFMI (fat-free max index) was under 30
    - [FFMI (fat-free max index](https://pubmed.ncbi.nlm.nih.gov/7496846/)) is total fat-free mass in kilograms divided by height in meters squared and just for reference
    - It’s pretty hard to be above 25 without anabolic steroids
  - He was 28, 29-years-old
- Peter thinks that suggests that Mike had some interesting genetics

Mike adds, “*I have very elite genetics… Anyone who sees this on video will notice that my head is curiously shaped. My mastication muscles are absurd. I looked like this before I ever took any steroids.*”

![](https://peterattiamd.com/wp-content/uploads/2025/02/f6-mikeisraetel.png)

**Figure 6. Mike Israetel**. Image credit: [Facebook](https://www.facebook.com/photo.php?fbid=10117445132002443&set=pb.2216008.-2207520000&type=3)

- Mike has the genetics for this and also got plenty out of steroids
  - Maybe not as much as some other people
- Some people without steroids are not overly jacked, but with steroids it’s a total transformative event
- Then when they retire and they come off of steroids, they go back to being mortal sized
- Whereas other people come off of steroids and they keep most of their muscle mass and they’re on TRT and they just look so jacked for forever
- There’s a huge, huge variation

***For Mike, steroids did a lot but nothing crazy ‒ he gained 30-ish pounds over 13 years***

- He didn’t gain 70 pounds of muscle

**Reverse question: tomorrow you just decide to keep doing everything you’re doing training-wise and gradually taper down anabolic use**

- Peter assumes Mike will need to be on testosterone the rest of his life

Mike replies, “*I don’t have to be. My testicular shrinkage has been zero. My spermatogenesis is seemingly zero. Some people just don’t suppress.*”

*How many weeks a year are you completely off any anabolic agent?*

- Zero
- And that’s been 13 years
- Peter finds it hard to believe he would continue to make testosterone
- Mike thinks this is hugely genetically variable
- Even if he’s not making any now, within several weeks, his testosterone production would likely resume
- Now if he had balls the size of capers then, yeah, it’s be an uphill battle
- Most people can resume normal testosterone production after the cessation of anabolic androgenic steroids, but not all
  - Maybe like 90/10

***You don’t want to be that 10, which is why it’s a huge that you don’t just start steroids or TRT without a real long hard think about what the hell you want out of life***

- Especially if you have yet to have children but want children
- Mike knows people personally who’ve done 1 of 2 things
  - 1 – Father children while on full steroid cycles
  - 2 – Blasted for a long time and cannot have children, tried everything (their spermatogenesis is gone)
- Peter can’t imagine that 90% of people that use anabolic steroids for >2 years would be able to resume testosterone production
- Mike thinks that most of the stuff you hear about how the comeback is difficult, is from people for whom the comeback is difficult
- Having been in the bodybuilding, power lifting space for a long time, most of the people he sees come off are normal afterwards

**If you were to go down to regular TRT today, how much of that 35 lb. of delta supplemental muscle would you keep?**

- If he went down to 100 mg a week or none

***He’d probably keep about half ‒ in other words, there is a difference between the muscle you gained versus the muscle you never had***

- Huge
- Which is why if you have a natural bodybuilding federation that allows you to compete after you’ve used steroids ‒ it’s a crock of shit (not fair)
- Mike respects every athlete and thinks it’s wonderful that they’re doing what they’re doing and in a sense it’s a different category
- If he was making a natural bodybuilding federation, you would have to sign paperwork that says, “*I’ve never used anabolic steroids*.”
- Because the literature we have now on how much muscle you gain and keep forever is unequivocal
  - We even have mechanistic data on how it happens
  - Your satellite cells that are incorporated under your musculature, which are kind of dormant and then they get in and then they grow big
  - We have no reason to believe they ever leave
- *Analogy*: it’s like letting your aunt come live with your for a few weeks, and they’re like, Aunt Linda’s here forever
- Having ever done higher doses of androgens for weeks or longer on end can give you a higher level of muscularity, especially if you’ve gone beyond your natural limit

**⇒** People generally can gain only so much naturally and only so much on steroids

- Steroids are not unlimited for gains

**Advantage gained from steroid use**

- If you were going to ever have 160 pounds of fat-free mass, and if you went from 150 to 160 with steroids, but you could have gotten there and would take you 3x longer without steroids, then the inherent advantage you don’t have because ***you just got there faster***
- But if you got to 180 on steroids and then you quit all the steroids and now you’re back down to 170, you could walk around and maintain that 170 on a normal secretion of testosterone (or a normal TRT), you would’ve never been able to do that without the steroids

***Steroids offer a permanent advantage for muscle gain***

- If you’ve ever been hyper muscular from steroids, you’ll probably never be as small as you would’ve normally been ever again
- That’s a big deal in Olympic sports because you can just kind of hide out, don’t get into the doping pool, crank it, get into the doping pool, you’re drug free, but you have muscle, it’ll never leave you
  - That’s a massive advantage

## Trade-offs of long-term usage of supraphysiologic doses of testosterone: health, performance, and Mike’s future plans [2:00:45]

**What is your personal calculus for the number of years remaining where you want to be doing supraphysiologic doses of testosterone?**

*Do you think about the trade-offs of long-term health?*

- Incessantly
- Mike’s calculation has many fold variables that go into it
- This includes getting regular blood work
  - He’s always done this, before he got in, during it, all the time
  - He’s got good genetics for health resilience
  - He’s never had blood work that indicated he should stop
  - The last time he had blood work he was on 1500 mg [Trenbolone acetate](https://en.wikipedia.org/wiki/Trenbolone_acetate) (totally gnarly stuff), and his overall total cholesterol was 79 or something

Peter reacts, “*That’s almost impossible to imagine. You’re on lipid lowering drugs though.*”

- Nope
- Keep in mind, Mike is 7% body fat and leanness is a humongous variable for health

**Mike is on blood pressure medication**

- Mike’s wife is a medical doctor so he’s always checking his blood pressure, always making sure it’s on the low end
- He doesn’t know what his blood pressure would be if he wasn’t treating it with medication
  - He’s never off this medication
- Mike currently takes 250 mg a week ‒ that’s his sports TRT (he calls it super TRT)

Peter asks,  “*Your BP at 250 and your BP at 2000, you would be on the same dose of a blood pressure drug.*”

- Mike took double the blood pressure medication roughly at that does and he titrated it so that his BP would always be below the normative values for best health (120/70)
- When he took the most drugs, he was almost always in a fat loss phase because you’re just not eating much food and you’re very lean and you’re doing lots of physical activity
- Those are all hugely antagonistic variables to high blood pressure
- If he was massing and weighed 280, he would have to take the “kitchen sink” of blood pressure meds and it would still be worth it to do that

Mike adds, “*If I can make a public service announcement, it just doesn’t matter why your blood pressure is high, fucking control it with drugs and then look to lifestyle or whatever or whatever.*”

- So many people are totally backwards on this where they want to clean up their lifestyle so that they can get off blood pressure meds
- Why? We’re in what, gen-9 of blood pressure meds? They don’t even have side effects anymore

***Why the hell wouldn’t you take a pill that reduces almost every single health malady and extends your lifespan by a generation?***

- It’s so funny, people will take Trenbolone that was manufactured in a bathtub in China, but they’re not going to take Novo Nordisk’s best blood pressure drug
  - They’re insane

***It’s good to make sure that your blood pressure and all lipid values are very good***

**Is your blood pressure the only noticeable deviation from normal health that you experienced that you and your wife were able to measure in this?**

- Mike’s lipid values probably aren’t as good when he’s bulking up
- He was on fewer drugs then
- The last time he ever had a total cholesterol over 200 was when he was 13-years-old and spent a whole summer playing video games and being totally inactive
  - He was a portly child and weighed about 202
  - When he turned 14, he began to do sports

**Mike’s health has always been really responsive to body fat levels**

- If he has a high body fat, he’s probably not in amazing health
- If he’s has a low body fat, he can take a lot of steroids and still be relatively “in” the numbers
- Now there’s lots of stuff we can’t measure, so his body has taken a considerable amount of damage over the years from anabolic androgenic steroids use

**Damages resulting from androgenic steroid use**

- Cardiovascular damage
- Mike’s left ventricular wall is probably larger than it should be
- He’s had plenty of [echoes](https://en.wikipedia.org/wiki/Echocardiography), most of them quite some time ago, and they’re all great
- The overall inflammatory exposure to the crazy training volumes
- Stress levels and independent psychological stress that the anabolic steroids foist upon him, no doubt has been bad for his brain
  - And bad for everything else and so on down the line
- Luckily he was smart enough at the beginning to always control his blood pressure

**⇒** Blood pressure is a huge killer for people on drugs

**⇒** Mike has always paid attention to lipid values (that’s another huge killer)

- He eats healthy almost all the time ‒ that’s a big deal

**Do you use a 5-alpha reductase inhibitor to manage DHT?**

- No
- Peter thinks his [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone) must be 200, and [worries about the effects on] his prostate
- Who knows, Mike has never checked
- No doubt it has taken a hell of a beating over the years
- While he used drugs relatively intelligently, he probably did too much
  - He mostly didn’t use super high doses by bodybuilding standards
  - He only used high doses a few times
- If he had a chance to do it over again, he’d use less
- In the future as he continues to compete in bodybuilding into his early 40s, he’s probably never going to go much over 500 total mg because it seems that his anabolic sensitivity is so high that he doesn’t need much more than that
  - North of that, his psychological side effects are so nasty that it’s not worth it anymore
- No doubt he’s degraded his fluid intelligence substantially from what it could have been (sadly)

## The potential for AI-driven medical breakthroughs to reverse aging and disease [2:07:30]

**Mike is hedging on**

- He knows this is going to sound insane
- He believes there is a high probability that in the early to mid-2030s, we will see the fusion of informatics and biology powered by AI such that ***we will be able to point by point re-engineer the entire human organism at a variety of levels and undo damage as was never possible before***
- He never exposed himself to as much statistical risk as would have made an even chance [that he wouldn’t make] it to age 50
  - He thinks he even has a chance of making it into his 60s (which would be the mid 2040s)

***Mike thinks major categories of disease will be completely solved in the 2030s***

- He thinks aging reversal would be mastered in the mid to late 2030s
- If that happens, then he’s at longevity escape velocity and looks like he succeeded

> “*If I die before then, I’m totally comfortable with all of the choices that I’ve ever made and it’s been one hell of a run*.”‒ Mike Israetel

**Understanding your own mortality and coming to grips with it important for any person, but especially with the risks Mike has taken with his body**

- This never surprised him
- If he dies from a heart attack an hour after this conversation, he won’t die surprised
  - He’ll die from a heart attack and be like, “*This is it*.”
- *Analogy*: It’s like a race car driver; nobody gets into that car and thinks it’s the safest thing they could be doing
  - Most of them have come to grips with the fact that they could die, but they’re good and they’re well compensated
  - It’s been worth it to them, and most importantly, they really wanted it

**Recently it’s become apparent to Mike (and many futurists) that most people listening to this may never die**

- Up until recently, that was not apparent and you kind of had to figure out, “*How do I want to live my life?*”
- Some cases require a longevity/quality of life trade-off
- And Mike made that early

*Would he make the same choice again?*

- On the margins, he probably would’ve been safer
- There’s a lot of crazy shit they do in bodybuilding that he categorically never did or tried even once
- His blood work and everything was pretty good the entire time, so he feels okay about it (not great)

*Peter is was less optimistic about the longevity escape*

- He thinks of the hedge as the exact opposite
- Peter’s hedge is, it would be wonderful if in a decade we had technology that treated disease in a way that could restore his heart to the heart it was when he was 20
- He thinks about the reduction in function
- His coronary arteries are still clean as a whistle, but his heart is nowhere near what it used to be
  - Because his maximum heart rate is 30 beats, 40 beats per minute lower than it was when he was a teenager
  - Which is directly an aging thing
- If you look at the electrical system of his heart, **these are things he can’t treat**
- He can do all the things possible to not have his blood pressure go up, so he don’t get [LV (left ventricular hypertrophy)](https://en.wikipedia.org/wiki/Left_ventricular_hypertrophy)
- He can keep his coronary arteries clean as a whistle indefinitely ‒ we have the modern pharmacology to do that
  - Isn’t it crazy that you can say that?
  - It’s wonderful; it’s incredible
- But you can’t change the architecture of the muscle yet

***Peter’s hedge is about staving off chronic disease as long a possible, staying healthy as long as possible, stay in the game as long as possible***

- If it turns out that was for nothing, we’re sitting here 10 years from now and he’s in his early 60s and someone comes along and says, “*Peter, all that stuff you did was totally unnecessary. You could have been eating Cheetos, drinking margaritas all day long. I have a pill that’s going to make you 20 years old again*.”
  - He would have no regrets
- He would have regrets if he put his eggs in the basket that said, “*I’m going to drink the margaritas all day. I’m not going to exercise. I’m going to wait for the exercise pill to come along.*” and it doesn’t come along

**One of Peter’s favorite thought experiments**

- If you just consider modern human history, we’re just talking about 250,000 years
  - Let’s forget everything that came before Homo sapiens
- You go back in time 250,000 years ago, 200,000 years ago, 150,000
- You do this in 50,000 increments until you hit 10,000 years ago and then 5,000 years ago, and then 2,500 years ago and then a 1,000 years ago

*You go in and you ask them to predict the future*

- Letting them see everything that’s happened before
  - Of course, that would be a difficult thing to do most points in time, they don’t even know anything beyond that
- It would be impossible to imagine because the pace of change during that 250,000 years was pretty much nothing
- 5,000 years ago we got agriculture
- Then a couple 100 years ago we got the first Industrial Revolution
- We start to get 2 more big step function changes
- But even if you go back in time 100 years
  - 100 years we’re in the roaring 20s, life couldn’t be any better
  - Nobody knows that there’s this depression coming
  - Nobody knows what technology is coming, all of these things

***So we couldn’t predict anything***

- You go back in time 40 years, Peter doesn’t think anybody could have predicted what we’re doing today

Mike adds, “[*Ray Kurzweil*](https://en.wikipedia.org/wiki/Ray_Kurzweil) *successfully did*.”

- If you’re conservative, 60 to 70% accuracy, which is wild because the baseline accuracy is zero
- Throughout the 80s and 90s, he made a substantial amount of correct predictions all the way through the 2020s
- He was almost the only person to predict the arrival of artificial general intelligence (he predicted the year 2029)
  - Now there is debate that he was probably too conservative and AGI will be here by 2027
- In the early 2000s they did a lot of asking questions of AI experts, people working in the space, and almost all of them said Ray was an insane person
  - About half of them said, “*We could never actually create artificial general intelligence*.”
  - The other ones were like, “*Oh in 2100 or 2070…*”
- Every 5 years that you ask this, everyone trends closer and closer to Ray Kurzweil’s original prediction
- He’s not doing magic

**The rate of progress**

- Earlier Peter said something interesting: “*We started 250,000 years ago, then we go into 125, then 50 then so on…. Things get faster, progress happens exponentially quicker.*”
- But if you plot every single event on human and animal history and geological history, it all plots on the same logarithmic scale, very, very tight clustering
- And right around 2045, the line is fucking vertical
- And so when Mike makes predictions (which are not his, he’s just parroting what other smarter people have said) of possibly getting traction on almost every kind of disease in the 2030s
- This isn’t the wishful thinking of a child
  - Mike adds, “*Though mentally I’m below the average child, at least in my own heart.*”
- This is something that is inevitable based on our incremental understanding and manipulation of the world

***It is the most accurate type of prediction that you could make bereft of exact knowledge because it’s the thing that tracks on that exponential progression***

- If we’re pessimistic about it, we’re actually estimating that things will somehow progress substantially less than they have been

**Computing power is an easy one**

- That curve of computing power in the early 2020s, people thought [Moore’s law](https://en.wikipedia.org/wiki/Moore%27s_law) was dead
- But then AI picked up the pace and it’s outpacing Moore’s law like crazy
- Exactly on the trajectory that Ray Kurzweil was the first one, probably the best to formalize

***So when Mike says crazy shit like we’re going to kibosh aging, we’re going to kibosh disease and all this other stuff, it’s tantamount to someone in the 1930s (peak depression era days) hearing that in the 2020s, you can make $16 an hour working at McDonald’s and that in the United States, the poorest people are the fattest***

**Can you imagine describing to a person in the 1930s what you do for a living?**

- Social media… they don’t know what that is
- We’re still in the same physical world, we’re still the same humans
- Anytime you think there’s no way it’s going to get this good, all disease eradicated
- When’s the last time you’ve treated a patient with cholera?
  - Do we have cholera in the modern Western world anymore?

Peter responds, “*This is where I’m less optimistic, no more confident to be clear, I want to be very clear.*”

- Mike concedes that he could be wrong about all of this
- Peter agrees with everything said in terms of computing velocity, etc.

**It comes down to the manipulation of biology**

- Certain things would need to be true

*Silly example*

- Do we believe that in 10 years we will be able to take an egg that has been put into a frying pan, fried, the clear part has turned white and make the white part clear again?
- Do we think 10 years will bring the technology to do that?

Mike replies, “*Yeah. Hell yeah.*”

Peter asks, “*But why do we think that we’ll be able to unfold proteins again?*”

- Because Google’s [DeepMind](https://deepmind.google/) project just mastered protein folding last year, and earlier this year, it took the first open contracts with major pharmaceutical companies
- Peter is familiar with that, and it’s a remarkable problem for which a [Nobel Prize](https://casmi.northwestern.edu/news/articles/2024/nobel-prize-honors-innovators-shaping-the-future-through-ai.html) was awarded
- Peter is not sure that entropy would allow the reversal
- What DeepMind did ‒ it’s incredible that they could actually take an amino acid sequence and predict the protein structure in folding
- But when the protein has folded, which is why the egg goes from clear to white in the pan, how do we un-denature that?

***Mike’s answer: through industrially designed enzymes, which we do not have the brain power to design, but for which in the 2030s, AI will be comically overpowered for***

- We think we’re very complex, and by our own standards we’re insanely complex
- But AI is so much smarter than us already in many of the relevant ways and soon to be smarter than us, to a degree that most of us have difficulty conceptualizing

**Mike’s analogy**

- Imagine explaining to your dog why the only season inside of your house is a light summer day
- The dog doesn’t know what seasons are
- Its total communicative throughput involves gestures and emotions
- It knows its name, it knows sit, it knows a few other things
- You can’t explain this to a dog; it’s impossible

***Mike thinks AI in 10 years will probably be several orders of magnitude smarter than us (we are the dogs in that analogy)***

- Peter doesn’t necessarily think that
  - It’s not that he’s pessimistic… he just thinks others might wonder why Peter isn’t MORE optimistic

## The role of AI in accelerating drug development, advancing human longevity, and overcoming biological limitations [2:19:45]

**Mike’s optimism about the future of AI for drug development and more**

- Mike thinks AI will be dealing with problems that are much more complex than the reengineering of human biology

- When the raw understanding of how to manipulate matter and energy to get any kind of shape you want at a given energy input, when that’s there, the only question is, are we going to try to do it or not?
- That’s where Mike comes back to the incentives and constraints problem
- The biggest hurdle to the development of advanced pharmacology and genetic engineering and so on to do this kind of thing is going to be regulatory in nature
  - Hands down, FDA, everything’s off by 5 or 10 years
- Once AI has enough time to cook on these problems, the candidate drugs released will run through trials with just an unreal record
- Peter thinks AI is going to do a great job of the 1st step of the process, which is trial and error to find the right molecule
  - It’s brute force; it’s super painful
- [AlphaFold](https://deepmind.google/technologies/alphafold/) changes that

*How is AI going to streamline the phase one trial where we have to prove once we have the* [*IND*](https://en.wikipedia.org/wiki/Investigational_New_Drug)*?*

- No, it doesn’t streamline that at all
- It just flies through it, knocks out phase I, knocks out phase II, knocks out phase II, market
  - Peter still thinks going through this is going to take a decade
- But at the end of that decade, we have super drugs hitting the market all at the same time as opposed to the incremental process
- The increments are all handled up front by the AI and that last decade is just, we just got to do this

Peter asks, “*So your example would be, it’s like coming up with* [*retatrutide*](https://en.wikipedia.org/wiki/Retatrutide) *in 2014 when we had* [*liraglutide*](https://en.wikipedia.org/wiki/Liraglutide) *as the first generation GLP-1 that sucked.*”

- Yep
- We already knew how to build retatrutide back then and we could have just done it
- No one cared because the money wasn’t there/there’s lots of other candidate drugs you could work on
  - Peter hadn’t thought about that

***Mike thinks if the AI is powerful enough, it’ll just give you candidates that are killers right offhand***

Peter asks, “*How will it know that, because… didn’t we need to see that, okay,* [*semaglutide*](https://en.wikipedia.org/wiki/Semaglutide) *was better than liraglutide?*”

- Peter doesn’t know if this was predictable
- You had to actually see the experience to then go from semaglutide to [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) and realize that maybe it’s the [GIP](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide) as well as the [GLP](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) that’s really good.
- It’s a very tantalizing proposition, but Peter wonders how much of it can be figured out through simulation, which is what would be necessary
- Mike thinks, eventually all of it

**The second rung of what’s starting to happen now**

- The *first rung* is candidate **drugs based on protein structure alone** and will that protein structure fold into the receptor we’re targeting well enough to give us some activity
- The *second phase* is computationally going to be tractable quite soon: ***simulating every single protein in the human body and seeing how that candidate drug interacts with every single other protein and they just optimize the selection criteria for***
  - To dial up the effect and dial down the side effect

Mike asks, “*Are you familiar with* [*gepirone (brand name Exua)*](https://en.wikipedia.org/wiki/Gepirone)*, a new major depressive disorder medication?*”

- No
- Mike thinks it’s an SSRI
  - [[Wikipedia](https://en.wikipedia.org/wiki/Gepirone#) says it’s a partial agonist of the serotonin 5-HT1A receptor and an active metabolite of geipirone is an α2-adrenergic receptor antagonist]
- It only targets the serotonin receptors in specific parts of the brain as opposed to just you’re going to get it all
- It has seemingly no more probability to reduce sex drive or ultra consumption of food patterns than a placebo
- That’s not even developed with AI
- That’s just a more selective targeting

***We can get almost 100 to 0 ratio targeting with that phase two approach***

**Hypothetical drug development example**

- Now you just want muscle growth and skeletal muscles only; you got it
- Entirely AI driven and when the first phase I participant takes that first pill, there’s an almost 100% chance that you’re just going to be like, “*Holy crap, what else do you feel? How’s your blood work?*”
  - Everything’s totally normal because we’ve tested it on every single other receptor in the human body
- There are definitely bumps in the road with that
- It’s not quite just that simple, but it’s on the way there

> “*The power of computing all of this and then using that computation to test it in the human body and getting iterative loops on that is to me not to be understated.*”‒ Mike Israetel

**If somehow biology is magically intractable for older folks**

- Mike thinks you will be able to scan the human brain, and the brain machine interface and mind uploading is going to happen by the 2040s
- So then it doesn’t matter what the hell your body’s like, you live in the cloud
- Peter has thought about that a bunch and is not sure he likes it

Mike asks, “*Why not? You can always just unplug.*”

## The philosophical implications of simulated reality, the impact of robotics on human labor and economics, and the challenge of predicting the future [2:25:15]

**If you had to choose in** [***The Matrix***](https://en.wikipedia.org/wiki/The_Matrix) **whether you wanted to just stay in “the matrix” and be completely oblivious to the swamp that you actually live in, or would you rather be unplugged from “the matrix” and eat the porridge every day and hang out with Morpheus?**

- Mike has a worse answer
- He’d fight on the side of the machines; he wants the machines to win
- In or out of “the matrix”?
  - Mike would let them use him as best they can
- [The Matrix](https://en.wikipedia.org/wiki/The_Matrix_(franchise)) is an unbelievable series of films
  - Until the last one

Peter asks, “*How could they possibly have ruined that franchise?*”

- Mike hasn’t seen it because his friend (someone he trusts very dearly) [Dr. James Hoffmann](https://rpstrength.com/products/coach-james-hoffmann) said, “*Just don’t watch it*.”
- He’s seen the last 3 [Star Wars films](https://en.wikipedia.org/wiki/List_of_Star_Wars_films) and he wishes he could unsee those
- Peter’s advice, after you see the final version of *The Matrix,* you have to go and watch the first two 3x over again to purge it
- Mike’s take on the second film in the series: it’s the greatest action film ever made
  - The freeway scene, you just can’t beat that
  - That’s the only reason that movie is any good
- The Matrix presupposition is preposterous on almost every ground that you think about it
  - The machines had in the plot of The Matrix a type of fusion, but they also used us as batteries (are you kidding?)
  - Also, how are they feeding us?
- The other thing is they said that we tried to make *The Matrix* sublime and angelic
  - Entire crops were lost, people rejected it
  - Bullshit
  - You put someone unknowingly into a *Lord of the Rings* fantasy in which they’re like the king and they get to win the game: they’re just going to play that for forever

**Mike anticipates a high probability that vast fractions of the human race will disappear into the simulation willingly**

- Imagine a place where you can run your brain at 1,000X normal speed and live 1,000 lives in the span of a regular human lifetime
  - You’re a vampire in one of them
  - You’re a superman in another one
  - Or you’re living a whole lifespan where you’re totally unaware that you made yourself forget
    - And then you wake up after you die and you’re like, “*Holy shit, this is all a game*”
    - You could do all of that for forever
- Who’s going to look at reality and then go, “*I’m good on that. I want to live in a ‘Lord of the Rings’ fantasy.*”
- A lot of people play [*World of Warcraft*](https://en.wikipedia.org/wiki/World_of_Warcraft) right now for most of their waking life

***In the future, that’s going to be a choice***

- Now, some people aren’t going to want to do that, and that’s total respect

**Our real world is going to change**

- Look at modern Austin, Texas
- It’s kind of an idyllic place if you think about it compared to 1900 London
  - There’s no air pollution
  - There’s no crime, relatively speaking, etc.

**Mike’s optimism about the era of robotics**

- So in the 2030s, here’s another little gem of optimism: the era of robotics is coming
- If the average robot costs a fifth less of inputs to sustain per year maintenance etc. than a human, but produces roughly the same output as a human
  - And this is a sick joke because robotics will exceed human production very quickly

***You can make as many robots as you want, and that multiplies the GDP linearly with each robot***

- [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) has spoken about this
- There’s a potential for robots in the 2030s or 2040s to be 10 to 1 to the average human

**⇒** You institute a 10% tax on the robotics industry and no human ever has to work again (universal basic income completely solved)

*So then what will humans do?*

- They’re going to do a lot of stuff
- Some people will engage in productive activities
- Some people will live their awesome lives in the reality of a physical world
- A lot of people (incrementally more and more) are going to plug in to increasingly more well-simulated virtual reality and spend a lot of time over there

***Mike thinks the kind of stuff that’s coming in the future is either World War III and everything dies (the machines choose to kill us) or something so sublime we can barely understand it***

**If you describe to the average person in 1300s England how the average American lives today**

- They would be like, “*What the hell are you talking about? Kings don’t live like this.*”
- Can you explain to a subsistence farmer what [Uber Eats](https://www.ubereats.com/) is?
  - Peter agrees, you couldn’t explain it to the King of France 500 years ago
- Peter can’t fathom what a world looks like in a 100 years, whether he’s here or not
  - He spends very little time trying to imagine this
- Mike thinks about this a lot

***Peter thinks it will be more difficult to predict the next 100 years than going back 100 years and trying to predict today (based on the trajectory of growth)***

- Mike thinks Peter’s approach to health and wellness has been infinitely more wise than his own
- This will give yourself the best possible chance to make it to the crazy 2040 stuff
- Operating from a framework of everything you do is longevity oriented ‒  Mike thinks everyone should be living that that
- If in 2032 they solve reverse aging, a few months later all of us take the pill and we’re all 22 biologically
  - We could all have the biggest fucking party of all time
- It’ll be great, but you might not make it to that party if you’re throwing back Cheetos right now
- In Mikes defense, he used some drugs but was incredibly health conscious in that context and still is

*Back in the 1940s there was a serious discussion of quality of life versus longevity*

- You try to sell someone no more beer, no more cigarettes
  - Like why?
  - So I could live 20 years longer
  - For what?
  - So I could work on a factory 20 years longer and grind my fingers off on the stamping press
  - You give them back their beer and cigarettes

*In the mid-2020s legitimate thinkers in the space are talking about longevity, escape velocity, are talking about true immortality*

- Not capital “I” Immortality, lowercase “i”
- You still could still get hit by a bus, but brain in the cloud type of stuff

***Now is probably the most pertinent time where reading Peter’s*** [***book***](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.sDx7nZW3sunuWkgfOJeAvwMSsdscLP6BFTG6M4_1RD93NrzHyDC4qVPPb1zkDVYk9CDRH-_TorXOxX9jgiv8tU13N235ImcsYEwYnI2_OfAu0aq7wy7vU4x7f_iBfHcD86nyMxSjH_mqMTp2hm5QUvriujZP9dDlbjHG3BbGtuVAcjqNsKPyuuDwmUmCuqdU9MgnVVrqUyrH7RUYFbIjfw._q-q0BYisx1j4E7Rky-Gpu4AdrT5MLVTTeB1qIj6pfY&qid=1731699020&sr=1-1)***, consuming his material, listening to your stuff and the experts that he has on is the smartest thing people in their 40s and 50s and 60s could do***

- Because look, if you’re in your 20s, whatever, rock on
- If you’re in your 40s, 50s, 60s, you might make it to this paradise stuff in the 2030s, but barely
- Tell yourself, “*Thank God I ate some friggin broccoli and went to bed at 9:00 PM*,” where as an alternative you could have had one too many margaritas and Cheetos and not made it that far

## Would having kids change Mike’s philosophy around anabolic steroid use? [2:32:15]

**If you had kids, would it change your philosophy around training anabolic steroid use?**

*It’s really a question of trade-off*

- Up until a few years ago, Mike thought he was going to have kids
- And he was very aware of the trade-offs

***The answer is, probably not***

Mike adds, “*I’m statistically likely with my current exposure and no increase in biotechnology throughput to croak in my 60s or 80s, probably more like 70s, maybe late-60s.*”

- That suggests that his steroid use is a 20-year reduction of lifespan (realistic worse case)

**How are you quantifying that?**

- Very heuristically
- Mike is familiar with what kind of cycles other people have done, what kind of body weights they’ve gotten to, body fats, health metrics
- It looks like most bodybuilders from [Arnold’s](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger) era are still kicking

*Do you attribute that to the fact that they were just using a fraction of the drugs?*

- It’s by no means clear that they were using a fraction of the drugs
  - Some of those guys were cranking it
- They were using fewer drugs on average, but with many exceptions
- Mike attributes that to the fact that as long as your blood pressure is not chronically elevated, and as long as you don’t have shitty genetics for longevity, you can do a lot of shit to yourself and still make it quite far
  - Whereas other people take great care to do everything and they croak in their mid-fifties because that’s just the card they were dealt
- Most older pro wrestlers, bodybuilders, they’re still with us
- A decent fraction of them have died, but many people just die in their mid-70s
- Many of them had grotesque abuses
  - Many pro-wrestlers had a cocaine problem, and the steroids were just a “drop in the bucket”

> “*It’s just not true to say that anabolic endogenic steroid use, even in extreme circumstances, just straight up drops you like a fly*.”‒ Mike Israetel

- Severe alcoholism will do you in
- There are not a lot of 70 or 80 year olds that are severe alcoholics

***Anabolic steroid abuse is a category of risk lower than that ‒ Mike estimates there’s a 5-20 year lifespan reduction from the steroids he’s taken***

**⇒** Peter wants to make sure that people understand that we’re *not* talking about physiologic replacement of testosterone, because the evidence is abundantly clear that we do not see any reduction in lifespan or increase in risk of cardiovascular disease, cancer, or other things

- Mike doesn’t like the term abuse
  - Call it intelligent, purposeful, high-dose androgen exposure
- There’s huge quality of life increase
- It’s definitely taken years off his life, and it will probably peg him into his 60s somewhere

## The role of GLP-1 agonists in bodybuilding and general weight management, and the moral and philosophical debates surrounding their use [2:35:45]

**Are we seeing more bodybuilders now use** [**GLP-1 agonists**](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist)**?**

- Yes
- It would make the most difficult part of bodybuilding easier, which is the calorie restriction
- There are 3 groups of people in bodybuilding today
- 1 – People that have emphatically adopted the use of GLP-1s
- 2 – People that either use or don’t use but don’t say much about them
  - Either don’t care or don’t know or they’re using, but they’re shush about it
- 3 – People that are absolutely viciously opposed to them for reasons that are almost always wildly irrational, but moralistically understandable

Peter asks, “*Just to be clear, is there a category of bodybuilder who fully endorses the liberal use of anabolic steroids, but opposes the use of GLP-1 agonists?*”

- Vehemently

***The argument is, you have to suffer through the hunger to call yourself a competitive bodybuilder***

- There’s 2 types of suffering: the pain of the gym and the pain of starving
- If they’re saying you have to have both of those to be one of us, then steroids are not a problem
  - They allow you to push yourself much harder
  - So maybe steroids are an important part of bodybuilding if the suffering is the card and the GLP-1 agonist is not

**⇒** Mike is in the camp of: if we’re in the business of using any form of pharmacology to enhance your physique, then we should take whatever we can get provided it’s safe

**There are 2 things that folks aren’t considering**

- If you can achieve a certain level of body fat through caloric restriction without GLP-1s, when you use any given dose of GLP-1s to reduce your hunger, you get 2 things out of that
- 1 – Now you can push to even more exotically lean levels, which you should be
  - We’re not trying to race to the same point
  - The destination changes
  - If you can get some faint glutes striations and win a few shows without GLP’s, maybe you can get completely stripped out of your mind with them
  - It’s just as hard
- Hungry at 3% body fat is a very different look than just as hungry at 6%
  - One is GLP enhanced, one is not
  - That’s a big deal to remember
- 2 – You have to deal with side effects of GLPs
  - They give you heartburn
- There is a certain amount of food focus they don’t eliminate
  - Watching people on TV eat tasty foods when you’re in prep is not as difficult because you’re not physiologically as hungry, but you still have cravings
  - Cravings are lower, but they’re still there and you still dream about food and the whole gamut
  - It’s not complete kiboshing of hunger
    - Mike hopes one day very soon we’ll achieve that, and that’ll be a miraculous thing that’ll save hundreds of millions of people from the obesity epidemic
- But then, if you have more bandwidth (because shit is easier), you’ll just push your conditioning further, get even leaner
  - That’s a big deal that people seem to forget

**The other deal is there is a preposterous amount of assuming that work and diligence are the big variables that separate bodybuilders**

- Usually that assumption is made by people with elite genetics and it’s just ***not true***
- Mike’s jujitsu coach, a gentleman named [Mr. Will Starks](https://www.tapology.com/fightcenter/fighters/106898-william-starks), is a phenomenal professional MMA athlete [shown below]
  - Will eats a very clean diet, very healthy diet, but he has tons of freebies, potato chips, pizza here and there, no big deal
  - He trains for mixed martial arts; he’s a pro
  - He has glute striations
  - He walks around and lives his life at 7% body fat ‒ that’s just how he exists in the world
  - It would take him one cycle of training to turn pro
  - He’s drug-free

![](https://peterattiamd.com/wp-content/uploads/2025/02/f7-mikeisraetel.png)

**Figure 7. Will Starks**. Image credit: [Instagram](https://www.instagram.com/p/DCCByFPOS42/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

- If you look at his glutes in the gym, you would think that takes a lot of hard work
- Mike explains, “*Bullshit, it took no work at all, he trains his ass off in MMA, but how many MMA guys do you see striated glutes? It’s almost not a thing.*”
- Mike’s plan for him to turn drug-free pro: have him diet for 6 weeks and start resistance training for hypertrophy (for the 1st time in his life)

Mike asks, “*If you have someone on stage against him who takes second place, but they started their diet at 20% body fat and their diet took 18 weeks, who worked harder?*”

- You would say the guy with the striated glutes did, but you would be wrong

***When you look at people using GPLs, you assume everyone has decent genetics, but that’s not true***

**⇒** People who have been fatter before have a much harder time getting lean for a bunch of different reasons

- They’re dealing with the same genetics that got them fat, and they have excess fat cells that scream hunger signaling into the ether all the time

***The idea that bodybuilding is about earning your keep and grinding and suffering is true, but we already use enhancement in so many different ways, why not use enhancement in this other way?***

**What do you think that tells us about the morality of GLP-1 use much more commonly?**

- The majority of people using GLP-1 agonists and dual agonists are not bodybuilders; it’s normal people
- Let’s take out the category of people with type 2 diabetes or with such significant obesity that it’s impacting their health in ways that are direct and measurable through the excess adiposity
- The majority of people who use a GLP-1 agonist right now are overweight but might be perfectly healthy

***Most of what they say is that you have to earn your fitness; if you are lazy and you just take a pill and you lose all the weight, you haven’t addressed the root cause of the issue, which is your poor diet***

- There is something to say there
- But Mike doesn’t understand much further about their logic
- They’re not thinking a lot; they’re just having a lot of feeling

*The reality is that probably the 2 biggest predictors of how obese someone is are your genetic hunger drive and your degree of conscientiousness*

- A lot of people use physical fitness as a proxy for conscientiousness, the ability to organize your life, to delay gratification, etc.
- The only thing that the GLPs eliminate as a category of problem is the **hunger drive** (they reduce it substantially)
- So now we’re left with people that are leaner, some of whom just have average conscientiousness, but now low food drive and now they’re leaner
- This especially upsets people that have lost weight themselves on their own and they took a certain **moral worthiness**, a certain gold star on their chest for it, to say, “*I was conscientious and willful enough to do this.*”
  - Those people are correct: what they did was monumental and ultra impressive
  - They feel ripped off because other people are now doing it by just taking a weekly injection

Mike believes, “*But that belief in yourself, that flexing of your conscientious muscle that you did, it’s your benefit for yourself to keep.*”

- The other way to think about it is if you had to lose 20 pounds and really focus yourself to do it and to keep the weight off, you’re focused all the time
- What you could do is take an anorectic drug (GLP-1 for example), and now you don’t have to try as hard to limit yourself because your appetite is normal
  - And you can take all of that bandwidth of willpower and effort and conscientiousness and apply it to something else (business, family life)

***If you have to diet hard enough to lose a bunch of weight, your bandwidth for your work, your bandwidth for family, your bandwidth for enjoying your life have to go down***

Peter asked, “*Has that been your experience? Which is it hasn’t actually changed what you’re eating, it’s just given you the privilege of focusing less on the starvation and the management of diet?*”

- Exactly

*Mike’s wife was either genetically or epigenetically geared to get fat*

- At one point, she was almost 200 pounds (at 4’11”)
- She probably has more willpower than Mike has ever seen in a single human being
  - She’ll break herself before she quits at stuff
- Her **hunger signaling** was so profound ‒ she battled it her whole life, had lots of victories, lots of defeats
  - She almost failed out of medical school because she was dieting so hard to try to stay to certain body fat that her brain just wasn’t working
- Her introduction to GLPs (to [Ozempic](https://en.wikipedia.org/wiki/Semaglutide)) was the kind of thing that borders on the religious experience
  - For the first time ever to be like, “*Oh, this is how normal people live their lives*.”
  - And now she’s whatever body weight she wants to be and lives at a category level of life experience she was unable to access before because
  - Especially for females of reproductive age, having 70 pounds extra adiposity ‒ how the world sees you, how you see yourself is totally different

**It’s easy for bodybuilders and other folks to say, “*****We just got to get through it*****.”**

- But these guys don’t do anything except shoot steroids, play PlayStation, and train with weights
- For Mike, it’s very easy to connect with his wife on food drive after he had to diet down to a body fat that was appropriate for competitive bodybuilding
- You feel what it’s like to be obsessed ‒ all you’re thinking about is food
  - Food tastes good to a level that you’re like, “*Am I eating drugs?*”
  - And you’re in pain physically from the expansion of your abdominal tract and you’re still eating and your eyes are this wide, like a hungry ravenous dog who is tortured and not allowed to eat for a long time
  - That’s how a lot of people live in the world

**There are 2 variables that primarily determine how fat you are: food noise and conscientiousness**

- If we just end the food noise ‒ just to remove one impediment is amazing
- Some people will still be overweight even if they’re on Ozempic because eating enough Rheese’s Cups will defeat any amount of pharmacology
- People come at this from a morality, you have to earn your keep

**Mike’s views on the use of GLP-1 receptor agonists in sports**

- Now in sport competition, hell yeah, it’s cheating
- But in bodybuilding competition, they don’t test for drugs at all ‒ it’s not cheating at all
- People take this morality, this cheating stuff, and they put it out in the real world

*Use by cyclists*

- Cycling is a sport where the rules are clear: no performance enhancing drugs
- But to date, all the performance enhancement has been on the generation of power, EPO, testosterone, things like that

**⇒** But anybody who’s ever ridden a bike knows it’s half power, half weight; and cyclists spend a lot of time being hungry

- Mike thinks many of them do [use GLP-1 agonists] (some don’t)
- But if there is a drug that solves a very big problem for you, that makes you better, and you’re purporting to be a drug-free federation, then yes, you should be testing for it and it should be a banned substance

**Parting comments**

- A lot of people are going to find this conversation super interesting
- Peter should probably sit down with Mike and do this again because he has a list of topics they didn’t get to

---

## Selected Links / Related Material

**Mike co-founded Renaissance Periodization**: [RP Strength](https://rpstrength.com/) (2024) | [1:15, 7:00]

**Mike’s YouTube Channel**: [Mike Israetel](https://www.youtube.com/@MikeIsraetelMakingProgress) (2024) | [1:30, 8:30]

**Dorian Yates podcast with Peter**: [Peter Attia MD: Improving Health and Aging Better Through Exercise](https://youtu.be/xjm4IcSSHrs?si=xgtH6vO3XxKZrpFC) | Dorian Yates Nutrition (August 20, 2024) | [36:00]

**RP YouTube channel**: [@RenaissancePeriodization](https://www.youtube.com/@RenaissancePeriodization) (2024) | [55:15]

**RP hypertrophy app**: [Muscle Growth Made Simple](https://rpstrength.com/pages/hypertrophy-app) (2024) | [55:15, 1:17:45]

**American College of Sports Medicine Physical Activity Guidelines**: A[CSM Physical Activity Guidelines](https://www.acsm.org/education-resources/trending-topics-resources/physical-activity-guidelines) (2024) | [1:02:45]

**Menno Henselmans PT course**: [The Henselmans PT Course Certification](https://mennohenselmans.com/online-pt-course/) (2024) | [1:08:30]

**Peter’s Instagram post explaining reps in reserve**: [peterattiamd](https://www.instagram.com/peterattiamd/reel/CpP3ifkDKDF/) (2023) | [1:17:15]

**High-protein David bars**: [David Shop Bars](https://davidprotein.com/collections/shop-bars) (2024) | [1:31:45]

**Episode of** ***The Drive*** **that discussed anabolic steroids**: [#274 – Performance-enhancing drugs and hormones: risks, rewards, and broader implications for the public | Derek: More Plates, More Dates](https://peterattiamd.com/derekmpmd/) (October 9, 2023) | [1:36:00]

**Episode of** ***The Drive*** **that discussed testosterone replacement therapy**: [1:36:00]

- [#291 ‒ The role of testosterone in males and females, performance-enhancing drugs, sustainable fat loss, supplements, and more | Derek, More Plates More Dates Pt.2](https://peterattiamd.com/derekmpmd2/) (February 26, 2024)
- [#196 – AMA #32: Exercise, squats, deadlifts, BFR, and TRT](https://peterattiamd.com/ama32/) (February 21, 2022)
- [#180 – AMA #28: All things testosterone and testosterone replacement therapy](https://peterattiamd.com/preview-ama-28-all-things-testosterone-and-testosterone-replacement-therapy/) (August, 27, 2021)

**RP Strength video on what it feels like to be on a high dose of testosterone**: [Roid Rage is REAL](https://youtu.be/AJcc2xFRm74?si=IEtUsft0B5lPZ9J7) | Renaissance Periodization (October 22, 2024) | [1:41:30]

---

## People Mentioned

- [Travis Triplett](https://phes.appstate.edu/faculty-staff/travis-triplett) (Professor of Physiology of Exercise and Director of the Exercise Science Undergraduate Program at Appalachian State University; Mike’s Master’s advisor) [6:30]
- [Jeffrey McBride](https://phes.appstate.edu/faculty-staff/jeffrey-mcbride) (Professor of Human Movement Studies at Appalachian State University; Mike’s Master’s advisor) [6:30]
- [Nick Shaw](https://rpstrength.com/pages/team/nick-shaw) (Co-Founder and CEO of RP strength; former competitive bodybuilder and an IFB Pro) [6:45]
- [Mike Stone](https://www.etsu.edu/chs/exercise-science/faculty/stonem.php) (Professor of Exercise and Sport Science, Director of the Sport Science Laboratory, and Program Coordinator for the Sport Physiology and Performance PhD program at East Tennessee State University; Mike’s PhD advisor) [7:30]
- [Bradley Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/exercise-sciences-recreation/bradley-schoenfeld/) (Professor of Exercise Science at Lehman College; expert in muscle hypertrophy) [8:15]
- [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman) (retired professional bodybuilder known as “The King,” shares the record for most Mr. Olympia titles) [9:30]
- [Jay Cutler](https://en.wikipedia.org/wiki/Jay_Cutler_(bodybuilder)) (retired professional bodybuilder and 4-time Mr. Olympia winner) [9:45]
- [Tim Noakes](https://en.wikipedia.org/wiki/Tim_Noakes) (Emeritus professor in the Division of Exercise Science and Sports Medicine at the University of Cape Town, South Africa) [31:30]
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) (retired professional bodybuilder who won the Mr. Olympia title 6 consecutive times) [36:00, 1:33:00]
- [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) (1951-2001, IFBB professional bodybuilder, devised the *Heavy Duty Training* program) [37:30]
- [Joe Jeffery](https://www.instagram.com/joe_physiquecollective/?hl=en) (physique coach in the UK and bodybuilder) [1:45:00]
- [Ray Kurzweil](https://en.wikipedia.org/wiki/Ray_Kurzweil) (American computer scientist, author, entrepreneur, futurist, and inventor) [12:15:15]
- [James Hoffmann](https://rpstrength.com/products/coach-james-hoffmann) (Coach at RP Strength and former Program Director Exercise and Sport Science at Temple University) [2:26:00]
- [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) (Businessman known for his roles in the companies SpaceX, Tesla, and media platform X, formerly Twitter) [2:28:00]
- [William Starks](https://www.tapology.com/fightcenter/fighters/106898-william-starks) (Professional MMA athlete and jiu jitsu coach) [2:40:00]

---

![](https://peterattiamd.com/wp-content/uploads/2025/02/bio-mikeisraetel-600x548.jpg)

##### Mike Israetel, Ph.D.

Mike Israetel​ earned his PhD in Sport Physiology from East Tennessee State University. Dr. Mike is a seasoned expert in the field of fitness and performance. Formerly a professor at Lehman College, Temple University, and the University of Central Missouri, he taught a variety of exercise science courses focusing on nutrition, strength, and hypertrophy. ​

Dr. Israetel has also worked as a sports nutrition consultant for the U.S. Olympic Training Site in Johnson City, Tennessee. He has personally coached countless athletes in nutrition and weight training, and continues to push his own limits as a competitive bodybuilder and professional Brazilian Jiu Jitsu grappler.

Dr. Israetel coauthored many ebooks including [*The Renaissance Diet 2.0*](https://www.amazon.com/Renaissance-Diet-2-0-Scientific-Performance-ebook/dp/B08FHB9HSN/ref=tmm_kin_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&qid=&sr=)*,* [*Scientific Principles of Hypertrophy Training*](https://www.amazon.com/Scientific-Principles-Hypertrophy-Renaissance-Periodization-ebook/dp/B08WKNGSLW/ref=tmm_kin_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&qid=&sr=)*,* [*Understanding Healthy Eating*](https://www.amazon.com/Understanding-Healthy-Eating-Science-Based-Affects-ebook/dp/B07YN576KX?ref_=ast_author_dp&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&dib_tag=AUTHOR)*,* [*Scientific Principles of Strength Training,*](https://www.amazon.com/Scientific-Principles-Strength-Training-Israetel/dp/148359548X?ref_=ast_author_dp&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&dib_tag=AUTHOR)[*Recovering from Training*](https://www.amazon.com/Recovering-Training-Fatigue-Maximize-Performance-ebook/dp/B07HRZSYHN/ref=tmm_kin_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&qid=&sr=)*,* [*The Minicut Manual*](https://www.amazon.com/Minicut-Manual-Dr-Mike-Israetel-ebook/dp/B07YMLP9ND?ref_=ast_author_dp&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&dib_tag=AUTHOR), and [*How Much Should I Train*](https://www.amazon.com/How-Much-Should-Train-Introduction-ebook/dp/B07NKVBQ61?ref_=ast_author_dp&dib=eyJ2IjoiMSJ9.Ow7A_esdPX2Bp5mZyx4uJtSF_k5QZ1KCayFy8XNYmsR_PWjlL_LSTRzp-EZsHtVJP-65KRZi2yZ3uQWtpzwUVF9WqftwkvFRcHzCwaSPq9CyRasW7sW03nRwh0Jh3cx2.OsE9tFAUilBm8NTXjVrLfnPFhnZGq2F5WIHwiKEFFrw&dib_tag=AUTHOR). He cofounded [Renaissance Periodization](https://rpstrength.com/) and is currently their head science consultant. [[RP](https://rpstrength.com/pages/team/michael-israetel)]

Instagram: [drmikeisraetel](https://www.instagram.com/drmikeisraetel/?hl=en)

Mike’s YouTube Channel: [@MikeIsraetelMakingProgress](https://www.youtube.com/@MikeIsraetelMakingProgress)

RP YouTube Channel: [@RenaissancePeriodization](https://www.youtube.com/@RenaissancePeriodization)Website: [RP](https://rpstrength.com/)