# #112 – Ned David, Ph.D.: How cellular senescence influences aging, and what we can do about it

**Source:** [https://peterattiamd.com/neddavid/](https://peterattiamd.com/neddavid/)

---

Ned David is the co-founder of [Unity Biotechnology](https://unitybiotechnology.com/), a company developing senolytic medicines—molecules that target and destroy senescent cells in the human body. In this episode, Ned explains the science of cellular senescence and how it impacts the aging process. Ned discusses how senolytics may delay, prevent, treat, or even reverse age-related diseases, including cancer, cardiovascular disease, and neurodegenerative disease. As a serial entrepreneur, Ned also provides advice on how to transform a simple idea into the creation of a company.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/neddavid/the_Drive_public.png)

Play

#112 - Ned David, Ph.D.: How cellular senescence influences aging, and what we can do about it

#112 - Ned David, Ph.D.: How cellular senescence influences aging, and what we can do about it

1x15s30s

0:002:15:34

## We discuss:

- Defining longevity and the principles of aging [2:50];
- The control knobs of aging and how we can turn them [15:10];
- Role of cellular senescence in aging and cancer [27:00];
- History of senescence in scientific study [40:30];
- The cellular senescence paradox [46:00];
- Developing medicines that target cellular senescence [52:15];
- Ned’s lessons on risk analysis in business [1:05:15];
- The search for a molecule that could eliminate senescent cells [1:15:15];
- Senescent cell elimination example in osteoarthritic knees [1:30:30];
- Extending lifespan by removing senescent cells [1:45:00];
- Senolytic molecule example in macular degeneration reversal [1:52:30];
- The future of senescent cell targeting [1:58:30];
- The role of cellular senescence and metabolic syndrome [2:01:30];
- The role of cellular senescence and brain health [2:03:30]
- How building the company Kythera prepared Ned for his grander project of creating Unity Biotechnology [2:05:45];
- Advice for someone considering an entrepreneurial career path versus an academic career path [2:08:50]; and
- More.

§

## Show Notes

## Defining longevity and the principles of aging [2:50]

**What does “longevity” mean to Ned?**

“Well, longevity for me would be being able to live without the indignities that I’ve witnessed. We all witnessed in our lives all of these features of aging that seemed to be an escapable.”

“Longevity would be the ability to use what I know how to do just science, biology, and be able to change how we get to live our lives, to be free of these indignities.”

**Principles of aging**

–*Three principles*:

  #1—Aging is not a rigid thing, it’s flexible and malleable

  #2—Nature has “control knobs”

  #3—Natures control knobs can be “twisted” by humans (such as with drug development)

> “So nature is clearly gone to town on this and created these marvelous examples of disparate lifespan, but sort of the same creature, the same biochemistry.”

**First evidence that there were “control knobs”**

  1—Very similar creatures have very different lifespans

- *Example*: A hard clam (one that you could eat) lives about 40 years, but it has a deep ocean dwelling relative called the quahog clam that lives at least 500 years
- *Example in mammals*: [Tiny shrew](https://en.wikipedia.org/wiki/Shrew) (less than 1 year lifespan) vs. [Bowhead whale](https://en.wikipedia.org/wiki/Bowhead_whale) (~200+ years)

  2—Cynthia Kenyon’s work in [C. elegans](https://en.wikipedia.org/wiki/Caenorhabditis_elegans) (worms)

- Kenyon [showed](https://pubmed.ncbi.nlm.nih.gov/8247153/) that by knocking out a single gene ([Daf-2](https://en.wikipedia.org/wiki/Daf-2)) could double it’s lifespan
- Later work [suggested](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/) knocking out the [daf-16](https://en.wikipedia.org/wiki/Daf-16) gene in combo with caloric restriction was perhaps the most extrapolatable insight to mammals

> “To me, it was the Daf-2 to Daf-16 observation that opened up the field and said that there were these knobs that you could turn and you could get these radical impacts on longevity.”

## The control knobs of aging and how we can turn them [15:10]

**The control knobs of aging**:

1. Calorie restriction, rapamycin, and mTOR
2. Young blood
3. Mitochondrial aging
4. Methylation of DNA
5. Cellular senescence

**1—Calorie restriction, rapamycin, and mTOR**

- C*alorie restriction* (CR)
  - In the 1930s, [Clive McKay](https://en.wikipedia.org/wiki/Clive_McCay) at Cornell unexpectedly [showed](https://www.jstor.org/stable/15813?seq=1) that his rats that were restricted from food lived longer
  - “*It brought forward this idea that as we live, your biology is making a decision about the rate at which you are aging.*”
- R*apamycin*
  - A molecule discovered on Easter Island made by soil bacteria has shown to extend life in a variety of organisms
  - David Sabatini [figured out](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC133939/) the aging effects of rapamycin were similar to calorie restriction in that they are both turning the same control knob ⇒ [mTOR](https://en.wikipedia.org/wiki/MTOR)

**2—Young blood**

- Lifespan effects of joining the circulatory systems of old mice with young mice were demonstrated in the 1970s
- You can take two animals, one’s young and one’s old, and you literally suture them together ([parabiosis](https://en.wikipedia.org/wiki/Parabiosis)) and their circulatory systems join
- Result was that the young was good for the old animal and it could extend life by as much as 15%

**3—Mitochondrial aging**

- Mitochondria are the descendants of ancient bacteria with their own DNA and genomes
- The mutation rate of their DNA is somewhere between a hundred and a thousand fold faster than our nuclear mutation rates
- As a consequence, you can look at mitochondria in someone in the 70s, for example, and find that half of them can’t function normally (meaning can’t utilize oxygen to make energy or do all the other things that mitochondria do that are important)

“*…that’s something that we’ve learned that is clearly part of this aging story.*”

**4—Methylation of DNA**

- *This COULD be a knob… The “[methylation](https://en.wikipedia.org/wiki/Methylation) clock”*
- When you’re young, everything is lined up perfectly and gene expression is not “noisy”
- But as you age, suddenly you’ve got methylations where you’re not supposed to have them and you’re missing them in other places
- It looks as though that MIGHT give rise to “noisy” gene expression **such that cells don’t read the right genes (the epigenome) at the right times**

> “It’s possible that the act of being alive and that aging actually is modifying these little methyl groups in such a fashion as to cause aging. . .No one knows if these changes in this epigenetic clock are the cause of features of aging or the result of features of aging or even a little bit of both. And that’s going to be super interesting area of biology.”

- **\*Interestingly… twice in our lives we press a factory reset of your methylome:**
- - once at conception
  - and then once more a few weeks into your life (for making germline cells in the sex organs
    - So those are the only two times at this factory reset gets pressed.
- We now know you can do this **artificially,** thanks to the work of [Shinya Yamanaka](https://en.wikipedia.org/wiki/Shinya_Yamanaka), who [won the Nobel Prize](https://www.nobelprize.org/prizes/medicine/2012/press-release/) in 2012…
  - He initially identified a candidate list of genes that were turned on in this sort of embryological state
  - He was delivering the genes in various combinations (He ultimately paired down to about two dozen)
  - Then he then would take various pair-wise combinations and figured out how few he could do and still manage to turn on one of these embryonic genes.
  - He weeded it down to four and he got the Nobel prize for that
- After this work by Yamanaka…
  - people have made efforts to see could you actually impose features of youth but this is a little dangerous leap because… “*Just because you don’t have the methyl groups on your DNA doesn’t mean they translate into the phenotype that is youth*”
- **In summary**… “*this whole question about this methyl clock is something that it’s an intense area of interest in the biological community. It’s evolving a lot. There’s a bunch of labs that are working on this and it’s going to be a very interesting next five years to see where this drops out.*”

⇒ For more on methylation, check out:

- The Drive episodes with David Sinclair ([Part 1](https://peterattiamd.com/davidsinclair/) and [Part 2](https://peterattiamd.com/davidsinclair2/))
- [The Drive episode with Chris Masterjohn](https://peterattiamd.com/chrismasterjohn/)

**5—Final control knob—Cellular senescence**

- See next section below

## Role of cellular senescence in aging and cancer [27:00]

> “If you look at all of these aging mechanisms and these knobs that I’ve described, they all play a role in this. We don’t yet know what the sort of underlying primordial clock that ticks that makes us age. What we do know is that you have a series of these component mechanisms that work collectively and they create this phenomenon that we call aging.”

**Cellular senescence**

- Ned has spent that lasts 8+ years largely focusing on the “control knob” called [cellular senescence](https://en.wikipedia.org/wiki/Cellular_senescence)
- **Why?** ⇒ “*Of all of the mechanisms, it struck me as the simplest mechanism to perturb and make medicines that you can use to treat human beings.*”

–*What is a senescent cell?*

- A cell that stops dividing and is no longer functional
- But rather than go through apoptosis, it stays there
- Kids don’t have these
- But as you age they start to accumulate
- But it wasn’t known whether that cell was good for you, bad for you, or neither… until more research was done

**What happens when you eliminate senescent cells from these animals?**

⇒ Experiment: [Clearance of p16Ink4a-positive senescent cells delays ageing-associated disorders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3468323/)

- [Judy Campisi](https://www.buckinstitute.org/lab/campisi-lab/) and [Jan Van Deursen](https://www.mayo.edu/research/faculty/van-deursen-jan-ph-d/bio-00027650) have both genetically engineered mice where you could eliminate senescent cells
- If you take two animals born from the same mother within seconds of each other
- Then you eliminate the senescent cells from one of the animals around mid-life
- This animal lives on average about **30% longer** AND when they do die, **they die with many of the features of aging either absent or reduced**

![](https://peterattiamd.com/wp-content/uploads/2020/05/figure-1.-Baker-et-al-2011-neddavid.png)

**Figure 1. Treated mice had substantially delayed onset of lordokyphosis and cataracts compared to untreated mice.** Image credit: [Baker et al., 2011](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3468323/)

*-Cellular senescence* ***protects against cancer****… so why mess with it?*

- The ability to make senescent cells is vitally important to our survival
- A genetically engineered mouse that cannot make senescent cell will be **full of tumors** before it gets to reproductive age
- The cellular senescent system is an anticancer system and you do not want to mess with the emergency brake
- However, Ned says that they don’t mess with the brake system, they only “show up after” and remove the secencent cells after they are made

**What happens when a cell gets DNA damage?**

- First, it tries to repair it
- If it can’t be repaired, it then “decides” whether to go down the path of:
  - 1) [Apoptosis](https://en.wikipedia.org/wiki/Apoptosis), or
  - 2) Senescence
  - However, “*we don’t understand how cells make a choice between the two*”
- Ned considers this an interesting thing to be studied

**How do senescent cells poison the healthy cells around them?**

⇒ Judy Campisi’s work in discovering how senescent cells exert bad biology on the cells around them: [2007 paper](https://www.nature.com/articles/nrm2233?proof=trueHere) and [2009 paper](https://pubmed.ncbi.nlm.nih.gov/20148189/?from_term=%28Campisi%2C+Judith%5BAuthor%5D%29+AND+%28%28%222008%22%5BDate+-+Publication%5D+%3A+%222009%22%5BDate+-+Publication%5D%29%29&from_sort=&from_page=2&from_pos=3)

- They secrete into the micro environment around them stuff that distorts tissue function and contribute both to features of natural aging as well as very particular diseases of aging
- And this is done via this [secretome](https://en.wikipedia.org/wiki/Secretome) called [SASP](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype)
- SASP is a paracrine (as opposed to endocrine) feature, says Peter, “*this paracrine effect is to secrete it and poison your neighbor right next to you*”

–*However…*

- If you allow senescence to happen, but then you block the SCs from being toxic then you might be onto something…

**Cancer and senescence**

- It was also [demonstrated](https://science.sciencemag.org/content/309/5736/886/tab-figures-data) that if you CAN’T make cells become senescent, you dramatically **increase tumors** in mice and that’s a powerful lesson about what not to do…which is to not mess with the underlying biology
- However, showing up AFTER the cells are allowed to become senescent…
  - …and only then eliminating the senescent cells…
  - …you can produce a series of **youth effects while not increasing cancer risk**

## History of senescence in scientific study [40:30]

- In the early 1960s it was widely believed that cells from us from mammals could have infinite capacity to divide (And this was made famous by [Alexis Carrel](https://en.wikipedia.org/wiki/Alexis_Carrel))
- The leaders in the field all believed this but it turns out this was the result of the fact that the food that was being fed to these cells, which was derived from chickens, was contaminated with chicken cells … So every time cells were fed food, they were also fed other cells and gave this impression that these cells were dividing forever,
- In the early 1960s, a clever guy named [Leonard Hayflick](https://en.wikipedia.org/wiki/Leonard_Hayflick) came along and [coined this term, senescent cells](https://pubmed.ncbi.nlm.nih.gov/11413492/), meaning cells that lose the ability to divide in culture
- And he says something very prophetic… “*this may contribute to features of aging*”

⇒ **Great story**: Ned bumped into Hayflick at an airport and showed him a picture of the mice with and without senescent cells and told him “*this is what happened when we delete these cells that you said may cause aging*”

> “It was one of these great moments where you get to see this person who really architected this major insight in biology confronted with the historical result right to his face and watching him trying to process it all.”

**–***Around 1995…*

- Judy Campisi was the first individual to find a marker that we could look at in vivo, meaning tissue in a living creature, and see senescent cells
- And there wasn’t a lot of them so it was hard to understand how so few cells could do so much bad for so many cells

*-In 2008…*

- Judy Campisi described for the first time this thing that I mentioned earlier called the [SASP](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype) which is how these cells exert bad stuff
- And it’s over a hundred factors that have been characterized these cells make now that drive their negative biology

*-Over the last eight years…*

- Ned’s been working on this and it turns out that SASP is very different in different tissues, it’s very different from different cells within those tissues, and different disease states

## The cellular senescence paradox [46:00]

**The bad things that senescent cells are doing:**

- Broadly speaking, it can cause inflammation (and then [fibrosis](https://en.wikipedia.org/wiki/Fibrosis))
- More granularly, you see things like:
  - [TNF alpha](https://en.wikipedia.org/wiki/Tumor_necrosis_factor_superfamily) targeted by the drug [Humira](https://en.wikipedia.org/wiki/Adalimumab)
  - [VEGF-A](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor_A) which is the target of things like Lucentis and Eylea, multi multibillion dollar drugs for the treatment of diseases of the eye.
  - [CTGF](https://www.ncbi.nlm.nih.gov/pubmed/28026993), which if you make an antibody against that, you have efficacy in a rare lung disease

**Positive side of SASP**

- Many things occurring through evolution are seemingly irrational decisions made by evolution
- But upon further inspection, many of these so-called “decisions” are things which benefit the young

–*Cellular senescence, for example, blocks tumor formation in the young:*

- “It’s an awesome mechanism to block tumor formation in young reproductively competent organisms.”

–*SASP and wound healing*

- A [paper](https://pubmed.ncbi.nlm.nih.gov/25499914/?from_term=%28Campisi%2C+Judith%5BAuthor%5D%29+AND+%28wound%5BTitle%2FAbstract%5D%29&from_sort=&from_pos=1) published by Campisi and [Demaria](https://eriba.umcg.nl/people/marco-demaria/) showed that SASP is important in wound healing

> “Essentially senescence got co-opted into suppressing tumors in one case and in a very different case was co-opted into helping heal wounds. . .And so I think that what you see in these diseases of aging is often the sort of unintended consequences of a system that was absolutely awesome for the young, at the expense of the old.”

## Developing medicines that target cellular senescence [52:15]

**How Ned got involved and started a company**

-Of all the possible “controls knobs”…

- mTOR/caloric restriction
- Loss of circulating youth factors (young blood)
- Mitochondria
- Methylation
- Cellular senescence (CS)
  - It’s that last one, SC, that is the **easiest one to drug**

**The question Ned had was**: *How do we make medicines that target a fundamental mechanism of aging?*

- In 2011, Ned read a [paper by Jan M. van Deursen](https://www.ncbi.nlm.nih.gov/pubmed/22048312)
  - The mice had a mutation which caused them to make far less of the **BubR1 protein**
  - van Deursen, being a cancer researcher, created this animal thinking it was going to get tons of cancer
  - That’s because BubR1 is there to make sure your spindles line up meaning that you should not be able to divide until all your chromatin is perfectly aligned and everything is in perfect tip top order and you’re ready to undergo mitosis.
  - So if you take away BubR1, a lot of faulty division should follow and you should get a lot of cancer

- *So what actually happened?*
  - They didn’t get a bunch of cancer
  - The mice were polyploid, meaning they had weird numbers of chromosomes (too many, too few, etc.)
  - They were **full of senescent cells**
  - And they aged very rapidly and had features of aging that would onset very rapidly and kill them

![](https://peterattiamd.com/wp-content/uploads/2020/05/Naylor-et-al.-2012-neddavid.jpg)

**Figure 2. Germline deletion of p16Ink4a in BubR1 progeroid animals dramatically impacts overt age-associated phenotypes and delays cellular senescence. Representative images of 5-month-old mice are shown. The inset images are SA-β-Gal-stained fat depots, demonstrating the dramatic attenuation of cellular senescence. SA-β-Gal, senescence-associated-β-galactosidase.** Image credit: ([Naylor et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4051295/))

> “For me, it was an experiment that suggested that … the senescent cells were actually driving these features of aging.”

- W*hy were the results so compelling to Ned*?
  - If you added senescent cells through this mutation that gave rise to the production of less BubR1 protein,
  - Then when you eliminated a subset of those senescent cells you could ameliorate a subset of the effects of SC
  - And doing so would improve many of the features of aging, for example…
    - They’re bent spines
    - Organ atrophy
    - Cataracts in their eyes

**How did that turn into a company making a drug?**

- Shortly after the paper came out, Ned met with Jan van Deurson and they started a company ([Unity](https://unitybiotechnology.com/))

**Over the next several years, Ned was trying to answer 4 specific questions**:

1. Do senescent cells contribute to **natural aging** as opposed to some genetically contrived mouse?
2. Could we find a disease, any human disease, that we could model in an animal where we can eliminate senescent cells and take that disease and either stop it or even better send it backwards?
3. Could we find a molecule that could trigger the elimination of senescent cells from a living creature safely?
4. Is getting rid of senescent cells safe?

–*Addressing question 4: Safety…*

- We know that children make SC but the get rid of them afterwards
- Adults retain the ability to make SC but they don’t get rid of them, they accumulate
- So, in a sense, that is evidence that getting rid of them (but allowing the body to make them) is probably safe

*-Addressing question 2: Is there a disease that would improve by eliminating SCs?*

- Ned wanted to find diseases of “being old”
- Things that the FDA has regulatory paths for and end points that you can get drugs approved on

*-Addressing question 1: Do senescent cells drive features of natural aging?*

⇒ 2016 paper: [Naturally Occurring p16(Ink4a)-positive Cells Shorten Healthy Lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845101/)

- This paper was answering the question: *How did we figure out that senescence was driving features of natural aging?*
  - They used natural aging mice
  - But they had the ability to eliminate senescent cells
  - Got to do that in a very slow, multi-year experiment
  - The results were “*really the trigger for de-stealthing the effort and speaking openly about what we’re doing because if it didn’t contribute to natural aging and it didn’t cause a particular disease of aging and we couldn’t find molecules, there was no company.*”

## Ned’s lessons on risk analysis in business [1:05:15]

**Learning the hard way**

- From starting companies and project early on, Ned noticed that there was a lot of wasted time due to a lack of risk assessment and strategy
- Through this learning experience, Ned developed a new intellectual process before beginning a new project or starting a company

**The strategy**

- The approach begins with a bold idea that is simple, beautiful and easy to picture the end state
- Next, he writes down all the existential risks to that beautiful, simple dream

–*For example…*

- Before starting [Unity](https://unitybiotechnology.com/) (company created to try to make a drug that targets senescent cells), the four risks were:
  - 1) What if senescent cells don’t contribute to natural aging?
  - 2) What if they don’t cause a particular disease of aging that the FDA will approve as an indication?
  - 3) What if you can never find a molecule to eliminate them?
  - 4) What if eliminating them is unsafe?
    - If any of those four things did not work out, it would basically stop your ability to move forward with the project
- **Peter’s takeaway:** “What I’m hearing you say is embedded in your questions was actually a very thoughtful risk analysis that reverse engineered success.”

*-Once you’ve identified those key risks…*

- You can then build work plans that try to systematically remove each of those risks
- Everything Ned did at Unity for the first four years, and all the money they spent, was for the addressing those four risks

> “And whenever I go after a new thing, I always try to just go back to that simple, beautiful idea and then say, can I write down the risks to this beautiful idea? Then you build plans from them. And then you build budgets. And then you politely ask people for money.”

**Is this type of thinking good for academia?**

- Yes, says Ned, I think in any setting where you have a problem or a technological thing you’re trying to solve…
- I think it drives a certain degree of honesty when things are failing you know what to see because if you see something isn’t working, you can make a **go/no-go decision** in an academic setting and pivot to another project
- Because there’s no end of creative ideas that you could be working on. They’re limitless.

> “The important thing is to conserve your most valuable resource, which is your time.”

## The search for a molecule that could eliminate senescent cells [1:15:15]

**The quest to answer question #3:** *Could we find a molecule that could trigger the elimination of senescent cells from a living creature safely?*

- Early on, Ned realized that there was the possibility that they could either
  - a) eliminate the cells, or
  - b) come up with ways to reduce the pathological SASP that these cells were creating
- They decided to go with plan plan A because…
  - you wouldn’t have to dose the drug over and over again
  - In fact, you could potentially just take is one time, kill the cells, and sort of solve the issue
  - Many times, the “safety” of a drug becomes a problem because you have to take it a bunch, so this approach lowers that risk
- Ned and team moved forward with creating **molecules that could eliminate senescent cells** (*“senolytic” molecules*)

⇒ In a [Phase 1 study](https://unitybiotechnology.com/wp-content/uploads/Hsu-L05-UBX0101-Senolytic-ACR2019.pdf), Ned was able to show that when you eliminate senescent cells from the painful knee joint of a human being with osteoarthritis, a single administration of a senolytic medicine eliminates pain dramatically in these humans for “as long as we’ve looked”

- “*This sort of validates the notion that you can now have a drug that’s far safer because what kills most drugs actually is the fact that they’re unsafe and that generally is a result of treatment again and again and again.*”

**How do you identify which cells are the senescent cells in vivo?**

⇒ Ned’s [2017 Nature paper](https://www.ncbi.nlm.nih.gov/pubmed/28436958/) showed clearance of senescent cells in a mouse’s knee with osteoarthritis reduced pain and repaired cartilage

- In this study, Ned and team took mice with osteoarthritis (OA) in their knee
  - (OA is the second most prevalent disease of aging, first is T2D)
  - (And **OA and the primary cause of pain** in older people)
- They then eliminated senescent cells which could
  - i) **eliminate pain** and
  - ii) **repair cartilage** in the mouse’s knee
- Peter points out that his is counterintuitive based on the finding that senescent cells are needed for wound healing
- Ned says the theory about what’s going on in osteoarthritis is….
  - Senescent cells accumulate at sites of osteoarthritis and they may be **trying to heal**
  - But unlike in the skin when they literally fall off in the context of healing, these cells remain and essentially continue to sound the alarm over and over and over again
  - And we think it could be giving a sort of flawed attempt at wound healing that could be driving the pathophysiology of disease
  - Plus, inside of a joint, it’s a very delicate balance of one cell layer too many and all of a sudden you have a different outcome than you had prior to the insult (as opposed to a scrape on your knee doesn’t have to heal perfectly to still work functionally)

**The search for a senolytic molecule**

- They spent the first 2.5 years of this whole effort searching fruitlessly and not finding a senolytic molecule
- The first molecule finally identified was a MDM2/p53 interaction inhibitor
- What MDM2 does is it goes around and marks proteins with a little molecule called [ubiquitin](https://en.wikipedia.org/wiki/Ubiquitin) and it marks them for destruction
- And [p53](https://en.wikipedia.org/wiki/P53) is one of its client proteins
- So if you break up the interaction between MDM2 and p53…p53 doesn’t get marked for destruction and it’s concentration in the cell goes up
- Judy Campisi along with Rémi-Martin Laberge [discovered](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2933881/) that when you did this to senescent cells, **senescent cells died preferentially**

Peter asks, “**So your drug then targets p53?”**

- It doesn’t target p53, it actually binds on the MDM2 side
- So p53 goes up in concentration and the senescent cells die selectively
- And this turned out to work very well in Ned’s trauma osteoarthritis models in mice

**Experiment with cells from a damaged human knee**

- [Jennifer Elisseeff](https://www.bme.jhu.edu/faculty_staff/jennifer-h-elisseeff-phd/) got knees from patients undergoing total knee arthroplasty (knee replacement)
- She took the cartilage at the site of the osteoarthritic lesion
- and she would digest out the extracellular matrix
- and she’d take the cells that actually make your cartilage, and she would grow them in 3D culture
- And she would either expose those little blobs of baby cartilage to either vehicle or Ned’s drug
- And she observed that exposure to the drug…
  - i) **eliminated senescent cells** that were very prevalent from this site of damage
  - ii) Furthermore, those cells from the sick person’s knee, when soaked in Ned’s drug started **growing cartilage in the plastic dish.**
- That said, they haven’t yet proven in a *living human being* that this drug can grow cartilage when it’s still in your knee
  - “*But that experiment suggests that you have this innate capacity if you are unburdened by the senescent cells and their bad stuff they’re making.*”

## Senescent cell elimination example in osteoarthritic knees [1:30:30]

[Phase 0 study](https://unitybiotechnology.com/wp-content/uploads/Laberge-ACR.pdf)

- They took biopsies of little bits of their synovial membrane from patients with osteoarthritis in their knees and they counted senescent cells
- They saw that the more senescent cells they had, the worse osteoarthritis they had, the more bone deformation they had in the knee, the more **pain** they had

[Phase 1 study](https://unitybiotechnology.com/wp-content/uploads/Hsu-L05-UBX0101-Senolytic-ACR2019.pdf)

“*In human beings, we have eliminated senescent cells from patients’ knees with a single injection of this drug. And we can not only eliminate or dramatically reduce pain, but we can also eliminate factors the senescent cells are making…*

*…this molecule is* ***safe enough, selective enough, and potent enough*** *that we can do it. So it doesn’t just work in plastic dish, but it works actually within the knee of a patient suffering from osteoarthritis.*”

-Study Design:

- Double blind study
- 48 patients
- Three people would get the drug versus one person getting placebo
- It was a single dose of the drug at day zero injected into the knees of patients with painful osteoarthritis
- There were 6 different dose levels in the treated patients

–*Results*:

- Before the injections, patients rated their pain at an **avg. of 6.2** (on a scale of 0-10)
- As you go up in dose, you get more and more pain reduction and durable impact on pain levels
- At the highest dose, patients **pain levels dropped to just above 1.0**
- **Three months later, the pain was not returning**

**Upcoming phase 2 study of knee injection drug**

The [phase 2 study](https://clinicaltrials.gov/ct2/show/NCT04129944?term=NCT04129944&rank=1) is in progress

- The question: *If you eliminate senescent cells from somebody’s knee, how long does the pain stay away?*
- Duration: 6 months
- Dose levels will be: Placebo, 0.5 mg 2 mg, 4 mg
- Number of patients: 45 per dose level
- Patient criteria: Must have painful osteoarthritis of the knee with a pain score between a 4 and 9
- How to measure results:
  - Checking pain levels by survey of the patients
  - Watching structural changes via MRI and x-ray

> “Not only is this a means to treat the primary reason it hurts to be old, but it’s a read through to this whole idea of medicine which is ‘could you treat diseases of aging by eliminating these cells at sites of disease?’”

**Would this work in degenerative disc disease in the back which is such a common source of pain with aging?**

- So many people suffer [degenerative disc disease](https://en.wikipedia.org/wiki/Degenerative_disc_disease)
- Especially in [L4-L5](https://www.spine-health.com/conditions/spine-anatomy/all-about-l4-l5-spinal-segment) and [L5-S1](https://www.spine-health.com/conditions/spine-anatomy/all-about-l5-s1-lumbosacral-joint)
- it would be very interesting to note if you did directed injections of senolytic agents like this, if you could restore this signal, could you by eradicating enough senescent cell, create an environment where the existing cell could proliferate into a healthy enough place where it takes up water
- When we eliminate senescent cells from mice from midlife until death, and we do x-ray on their spines, we see a [41% improvement in the maintenance of the intervertebral disc volume](https://pubmed.ncbi.nlm.nih.gov/30900385/)
- The improvement was a **reduction in decline**
- It is still unknown if there could possibly be a **restoration** of disc volume over time
- That said, the phase 2 study should help to answer that question

**Will the efficacy/safety of this new drug be impacted by progressive dosing (like corticosteroids)?**

- The idea is that it would not be negatively impacted by more doses
- The prediction would be that use of the drug would actually tip the scale in favor of the chondrocyte over the senescent cell
- Ned says an example of progressive dosing working without a negative impact on safety or efficacy would be in **oncology** (but only in the cancers that don’t spread, Peter adds)
- But in the case of Ned’s drug, it’s possible that the worst case scenario is you need the drug injected every 6 to 12 months so the risk of too much dosing is limited

## Extending lifespan by removing senescent cells [1:45:00]

- Ned’s provided scientific examples of helping with healthspan

–*What about* ***lifespan*** *vis-a-vis atherosclerosis, cancer, or other diseases that actually shorten life?*

- Atherosclerosis is another disease in which senescence plays a role, says Ned
- The tough part in treatment is that atherosclerosis is a systemic issue (as opposed to local osteoarthritis in the knee)

–*A* [*paper in Science*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5112585/) *by Jan Van Deursen and Bennett Childs*

- They showed in rodents that senescent cells (SC) accumulate in the atherosclerotic plaques
- The SCs have 3 origins
- Senescent endothelium (the barrier)
- Macrophages (immune cell that came to the rescue)
- Myofibroblastic type (fibroblast that attempted to repair the damage)
- And when you eliminate these senescent cells, you can…
  - 1) Reduce plaque volume
  - 2) Thicken the fibrotic cap that forms on the surface of an atherosclerotic plaque (and therefore make it less clinically dangerous)

-Still a tough market for new drugs

- Despite this positive evidence, it’s a very tough place to do drug development, says Ned
- Because the money going into statins and PCSK9 inhibitors
- Plus the studies tend to looks at outcomes like deaths and events and take longer

**Is there an application in oncology?**

- From this [2016 paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845101/)…
  - In mice from whom they eliminated senescent cells (from midlife until death)
  - They had the SAME cancer prevalence
  - However, the animals from whom the cells were eliminated **get cancer 30% later in their lives**
  - “*So you basically created centenarians. You just phase shifted chronic disease by a third.*” says Peter

**Other diseases impacted by the drug**

- Some diseases were dramatically reduced
- The age effects of kidney function
- Cataracts
- Their spinal lordosis looks youthful
- These animals seem to preserve features of youthful behavior
- Overall, the animals die of the same things but just later in life
- *Why is that?* ⇒ One explanation is that there is something perverse that senescent cells do to the tissue microenvironment

**Regarding cancer…**

> “The [senescent cells] system is an anticancer system in the young could become a pro-cancer system in the old by doing something to the tumor microenvironment that makes it more amenable to tumorigenesis.”

–*Implications in cancer treatment/prevention*:

- A “two-hit” strategy
  - In a tumor prone situation…
  - If you could purposefully **make** cells senescent (which is what chemotherapy does in many cases)
  - Then do a two hit strategy where you drive the cells into senescence and then you exploit a senescence associated “Achilles’ heel”
  - It could be a strategy in which you deliberately are trying to drive tumor cells into senescence and then killing them
- Additionally, there are a series of cancers that we think that are age associated that may be essentially the product of a highly senescent environment:
  - So cancers of the skin.
  - Cancers of the bladder
  - An interesting thought would be: *Could you go in and eliminate senescent cells and change the trajectory of disease?*

## Senolytic molecule example in macular degeneration reversal [1:52:30]

[**Macular degeneration**](https://en.wikipedia.org/wiki/Macular_degeneration) **(MD)**

- The “dry” version makes up 7 out of 8 cases of MD
- The “wet” version of MD (only 1 of 8 cases) is treatable with anti-VEGF antibodies
- The dry disease moves more slowly, but it makes you just as blind
- The dry MD is an area in which **senolytic medicines may play a role**

**Upcoming trial**

- Soon, Ned and team will be testing their first molecules into the human eye
- They will start with a very select population to demonstrate safety
- And then branching outwards into multiple diseases of the eye.

*-How do you deliver the vehicle? Is it an injection?*

- Very similar to clinical practice for anti-VEGF delivery.
- It goes right into the vitreous fluid of the eye
- The drug goes into the various sub compartments within the eye
- And the drug is able to get to the senescent cells

–*The clinical hypothesis*: **One or more of these progressive diseases of the aging eye will stop progressing when senescent cells are eliminated**

*-What is the drug targeting?*

- There are two molecules that are advancing toward the clinic
- Both of them are inhibitors of the BCL2 protein family
- These are molecules that inhibit the inhibitors of apoptosis
- In other words, they cause cells to enter programmed cell death
- But interestingly, in animals that they don’t cause that to happen in *normal healthy eyes*…they only target cells that have been damaged by the disease process

> “There is something about cells and their fate that determines which apoptosis vulnerability you have and they have different Achilles heels. And we don’t understand mechanistically why that is. We’ve sort of figured this out empirically and picked molecules based on their behavior against the cells that we find to be senescent in these human diseases.”

## The future of senescent cell targeting [1:58:30]

**What will the future of targeting senescent cells (SCs) look like?**

–*Ned’s take*:

- I think it’s going to be a small number of things to target, says Ned
- I think it’ll be context specific
- I think there’ll be super creative ways that we and others come up with to exploit these different vulnerabilities.
- I don’t think biology is going to have made 24 different keys to this lock.
- They think it’s going to make a half dozen and we actively search for these.

–*Peter’s take:*

- It’s just interesting to me that you can turn one key and get a benefit
- Think about how often that doesn’t work—i.e., the futility of that in chemotherapy where you target this one piece of cell cycle replication and very quickly the cell mutates away around that drug

**Why are SCs easier to target than cancer cells?**

- Cancer is incredibly hard because cancer exploits the single best tool biology has, which is variation.
- Cancer cells can divide and mutate and become anything to avoid death.
- Senescent cells on the other hand can’t divide by definition so their ability to access variation is dramatically reduced.
- “*We like to think of senescent cells as cancer cells that can’t divide.*”

## The role of cellular senescence and metabolic syndrome [2:01:30]

- There is some data in support of senescence in that cellular niche, but it’s very complicated biology
- It’s an area of intense literature debate.

*“What I will say about type 2 diabetes in humans …”*

- There was a large [meta analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845101/) of a [genome wide association studies](https://en.wikipedia.org/wiki/Genome-wide_association_study) looking for the genetic correlation between illness of aging and loci
  - I.e., *Where did these mutations map?*
- What you saw is that one of the very big peaks for diseases of aging maps into the control system for the establishment of cellular senescence (the [p14arf](https://en.wikipedia.org/wiki/P14arf) locus)
- This is where a very important gene that people use for senescence all the time called [p16](https://en.wikipedia.org/wiki/P16) and it’s gene lives in this locus)
  - For type 2 diabetes… mutations that give rise to T2D live there
  - Mutations that give rise to late onset Alzheimer’s live their frailty lives there
  - Atherosclerosis lives there

## The role of cellular senescence and brain health [2:03:30]

- Ned’s group working on understanding the role of senescent cells and cognitive decline
- Your brain has many glial cells ⇒ The cells in your brain that are NOT your neurons but they hold the rest of it together
- They outnumber neurons by about 10 to 1
- There’s a dramatic increase in senescent glial cells, specifically astrocytes and microglia
- **The question that needs to be studied**: W*hat would happen if you could eliminate senescent glial cells*?
  - W*ould that enhance cognition*?
  - W*ould it harm cognition?*
- Ned and team are [actively looking into this](https://www.nature.com/articles/s41586-018-0543-y)

> “It’s hard to imagine that the pro-inflammatory environment created by this vast number of senescent glial cells is good for you. . . it would just be very hard to imagine that senescence is not playing a role in aspects of cognition loss as we age.”

## What prepared Ned to start Unity Biotechnology [2:05:45]

**What is Kythera?**

- Kythera was a company that Ned and two others founded (including [Keith Leonard](https://unitybiotechnology.com/team/keith-r-leonard-jr/), who’s a CEO at Unity) about 15 years ago
- The idea was to piggyback off all the biology that’s been explored for oncology and inflammatory disease and taking those molecules from that and applying them to the biology of aesthetics
- They took four things into the clinic and one out of the four things worked and it was a molecule that causes fat cells to explode
- They went from an in vitro observation all the way to a launched commercial product called [Kybella](https://www.mykybella.com/) (which is available at your dermatologist)
- “It was a great learning experience of just how to develop pharmaceuticals in something that didn’t have historical resonance at all … and where the stakes weren’t as high for whether you succeeded or failed.”
- Ned sais that is where he could hone his skills of making really high quality decisions on risk and drug development
- Ned says without the experience of Kythera, it would have been impossible to build Unity: “*I would have none of the intellectual or emotional toolkit to do what we did.*”

## Advice for someone deciding between business and academics [2:08:50]

**1—Don’t create a false choice.**

- You can be an academic and still found a company
- There are wonderful things that you can do from the seat of academia in company creation if you are so lucky and so positioned to do so.
- “*Don’t fall into this idea of a false choice. And I see people do that. I think out of some emotional discomfort, this desire to just move and confuse action with progress. And I’d say just slow down, take a deep breath, you don’t have to rush your life.*”

**2—Animate what you do with a single beautiful idea.**

- Find something that moves you, that literally gives you goosebumps
- “That feeling when a hard battle for data that was 18 to 24 months in the experiment finally works and you’re looking at the data and you feel like the future taking root in the present. The only thing I can compare it to is love from your kids. It is the only thing that has the same emotional gravitas.”

**3—Learn from people that are better than you.**

- Find people with more experience that will have patience with you

> “I learned from real experts and I don’t claim to be an expert at much of anything, but I do claim to have a deep appreciation for learning from people who are better and more skilled than myself.”

§

## Selected Links / Related Material

**Ned’s company developing molecules to target senescent cells:** [Unity Biotechnology](https://unitybiotechnology.com/) [0:50, 1:58:45]

**Cynthia Kenyon’s work showing knocking out a single gene (Daf-2) could double lifespan in C. elegans**: [A C. Elegans Mutant That Lives Twice as Long as Wild Type](https://pubmed.ncbi.nlm.nih.gov/8247153/) (Kenyon et al., 1993) [10:45]

**Paper by Nir** **Barzilai** **and Pedro Beltran about an antibody that antagonizes the IGF receptor**: [Late-life Targeting of the IGF-1 Receptor Improves Healthspan and Lifespan in Female Mice](https://pubmed.ncbi.nlm.nih.gov/29921922/?from_term=Barzilai+N+IGF&from_pos=2) (Mao et al., 2018) [13:10]

**Cynthia Kenyon’s article about adding caloric restriction with knocking out daf-16**: [The first long-lived mutants: discovery of the insulin/IGF-1 pathway for ageing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/) (Kenyon, 2011) [13:45]

**Clive McCay’s observation in the 1930s that animals that were restricted with food lived longer**: [Prolonging the Life Span](https://www.jstor.org/stable/15813?seq=1) (McCay and Crowell, 1934) [15:15]

**David Sabatini’s work in understanding the aging effects of rapamycin being similar to calorie restriction in that they are both turning the same control knob**: [The Immunosuppressant Rapamycin Mimics a Starvation-Like Signal Distinct from Amino Acid and Glucose Deprivation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC133939/) (Peng et al., 2002) [16:15]

**For more on methylation and reprogramming cells back to youth, check out the following episodes of The Drive**: [22:00]

- The Drive episodes with David Sinclair:
  - Part 1: [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Peter Attia (peterattiamd.com)
  - Park 2: [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/) | Peter Attia (peterattiamd.com)
- Chris Masterjohn: [#46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more](https://peterattiamd.com/chrismasterjohn/) | Peter Attia (peterattiamd.com)

**2012 Nobel Prize for figuring out how to artificially press a factory reset of your methylome**: [The Nobel Prize in Physiology or Medicine 2012](https://www.nobelprize.org/prizes/medicine/2012/press-release/) | (nobelprize.org) [24:30]

**Genetically engineered mice which had senescent cells eliminated died with many less features of aging**: [Clearance of p16Ink4a-positive senescent cells delays ageing-associated disorders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3468323/) (Baker et al., 2011) [29:30, 52:15]

**Judy Campisi’s paper detailed the the means by which senescent cells exert bad biology in the surrounding cells via SASP**:

- [Cellular senescence: when bad things happen to good cells](https://www.nature.com/articles/nrm2233?proof=trueHere) (Campisi et al., 2007)
- [MicroRNAs miR-146a/b Negatively Modulate the Senescence-Associated Inflammatory Mediators IL-6 and IL-8](https://pubmed.ncbi.nlm.nih.gov/20148189/?from_term=%28Campisi%2C+Judith%5BAuthor%5D%29+AND+%28%28%222008%22%5BDate+-+Publication%5D+%3A+%222009%22%5BDate+-+Publication%5D%29%29&from_sort=&from_page=2&from_pos=3) (Bhaumik et al., 2009) [37:45]

**Eliminating cells from the ability to become senescent increasing cancer risk**:

- [Suppressing Cancer: The Importance of Being Senescent](https://science.sciencemag.org/content/309/5736/886/tab-figures-data) (Campisi, 2005)
- [An Important Player in Maintaining a Balance Between Inflammation and Tumor Suppression](https://pubmed.ncbi.nlm.nih.gov/19471128/?from_term=%28Campisi%2C+Judith%5BAuthor%5D%29+AND+%28%28%222008%22%5BDate+-+Publication%5D+%3A+%222009%22%5BDate+-+Publication%5D%29%29&from_sort=&from_page=2&from_pos=10) (Bhaumik et al., 2009) [39:45]

**In the early 1960s, Leonard Hayflick coined this term, “senescent cells”**: [Hayflick, His Limit, and Cellular Ageing](https://pubmed.ncbi.nlm.nih.gov/11413492/) (Shay and Wright, 2000) [40:30]

**Cellular senescence and SASP is important for wound healing**: [An Essential Role for Senescent Cells in Optimal Wound Healing Through Secretion of PDGF-AA](https://pubmed.ncbi.nlm.nih.gov/25499914/?from_term=%28Campisi%2C+Judith%5BAuthor%5D%29+AND+%28wound%5BTitle%2FAbstract%5D%29&from_sort=&from_pos=1) (Demaria et al., 2014) [49:30]

**Ned’s 2016 paper showing that senescence was driving features of natural aging**: [Naturally Occurring p16(Ink4a)-positive Cells Shorten Healthy Lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845101/) (Baker et al., 2016) [1:02:45, 1:49:30]

**Companies started by Ned in the early 2000s**: [1:12:30]

- [Achaogen](https://finpedia.co/bin/Achaogen/) (AKAO)
- [Kythera Biopharmaceuticals](https://www.kythera.gr/en/)

**Unity’s human clinical data showing you can dramatically reduce pain for a person with an osteoarthritic knee with a single administration of a senolytic medicine**:  [Safety, Tolerability, Pharmacokinetics, and Clinical Outcomes Following Single-Dose IA Administration of UBX0101, a Senolytic MDM2/p53 Interaction Inhibitor, in Patients with Knee OA](https://unitybiotechnology.com/wp-content/uploads/Hsu-L05-UBX0101-Senolytic-ACR2019.pdf) (Hsu et al., 2019) [1:18:00]

**Ned’s 2017 Nature paper showing clearance of senescent cells in a mouse’s knee with osteoarthritis reduced pain and repaired cartilage**: [Local clearance of senescent cells attenuates the development of post-traumatic osteoarthritis and creates a pro-regenerative environment.](https://www.ncbi.nlm.nih.gov/pubmed/28436958/) (Jeon et al., 2017) [1:19:30]

**Discovery that when p53 concentration increases, senescent cells die preferentially**: [p53: Pro-aging or pro-longevity?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2933881/) (Keizer et al., 2010) [1:25:15]

**Unity’s phase 1 study in humans showing that eliminating senescent cells from patients’ knees with a single injection of their drug dramatically reduces pain**: [Safety, Tolerability, Pharmacokinetics, and Clinical Outcomes Following Single-Dose IA Administration of UBX0101, a Senolytic MDM2/p53 Interaction Inhibitor, in Patients with Knee OA](https://unitybiotechnology.com/wp-content/uploads/Hsu-L05-UBX0101-Senolytic-ACR2019.pdf) (Hsu et al., 2019) [1:30:30]

**Unity’s phase 0 study in patients with osteoarthritic knees and took a biopsy of their synovial membrane and counted senescent cells**: [Senescent Synoviocytes in Specific Regions of Osteoarthritic Knees Correlate With Disease, Biomarkers, Synovitis, and Knee Pain](https://unitybiotechnology.com/wp-content/uploads/Laberge-ACR.pdf) (Laberge et al., 2019) [1:31:45]

**Unity’s upcoming phase 2 study further investigating the efficacy of their drug—a single injection of synolytic molecules in the osteoarthritis knee of human patients**: [A Study to Assess the Safety and Efficacy of a Single Dose of UBX0101 in Patients With Osteoarthritis of the Knee](https://clinicaltrials.gov/ct2/show/NCT04129944?term=NCT04129944&rank=1) | (clinicaltrials.gov) [1:37:00]

**Study that showed when you eliminate senescent cells from mice from midlife until death, you see a 41% improvement in the maintenance of the intervertebral disc volume**: [Systemic Clearance of p16 INK4a -Positive Senescent Cells Mitigates Age-Associated Intervertebral Disc Degeneration](https://pubmed.ncbi.nlm.nih.gov/30900385/) (Patil et al., 2019) [1:41:45]

**Paper showing that senescent cells accumulate in the atherosclerotic plaques in rodents and the drug can thicken the plaques of atherosclerotic plaques**: [Senescent intimal foam cells are deleterious at all stages of atherosclerosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5112585/) (Childs et al, 2016) [1:45:30]

**The GWAS meta analysis that makes Ned think senescent cells may play a role in age associated type 2 diabetes**: [Review: A Meta-Analysis of GWAS and Age-Associated Diseases](https://pubmed.ncbi.nlm.nih.gov/22888763/) (Jeck et al., 2012) [2:02:00]

**Early evidences that eliminating senescent glial cells in the brain could help with cognitive decline**: [Clearance of senescent glial cells prevents tau-dependent pathology and cognitive decline](https://www.nature.com/articles/s41586-018-0543-y) (Bussian et al., 2018) [2:03:30]

**Company Ned co founded which prepared him for created Unity**: [Kythera](https://www.kythera.gr/en/) [2:05:45]

§

## People Mentioned

- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) [10:45]
- [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/) [12:45]
- [Pedro Beltran](https://pubmed.ncbi.nlm.nih.gov/?term=Beltran+PJ&cauthor_id=29921922) [12:45]
- [Clive McKay](https://en.wikipedia.org/wiki/Clive_McCay) [15:15]
- [David Sabatini](https://biology.mit.edu/profile/david-sabatini/) [16:15]
- [David Sinclair](https://twitter.com/davidasinclair?lang=en) [22:00]
- [Shinya Yamanaka](https://en.wikipedia.org/wiki/Shinya_Yamanaka) [24:00]
- [Judy Campisi](https://www.buckinstitute.org/lab/campisi-lab/) [29:00, 37:45, 44:30, 49:30, 1:02:45, 1:20:00]
- [Jan van Deursen](https://www.mayo.edu/research/faculty/van-deursen-jan-ph-d/bio-00027650) [29:00, 54:15, 58:00, 1:01:30, 1:02:45, 1:45:30, 1:49:30]
- [Leonard Hayflick](https://en.wikipedia.org/wiki/Leonard_Hayflick) [40:30]
- [Alexis Carrel](https://en.wikipedia.org/wiki/Alexis_Carrel) [40:30]
- [Marco Demaria](https://eriba.umcg.nl/people/marco-demaria/) [49:30]
- [Darren Baker](https://www.mayo.edu/research/faculty/baker-darren-j-ph-d-m-s/bio-00027985) [1:02:45]
- [Keith Leonard](https://unitybiotechnology.com/team/keith-r-leonard-jr/) [1:09:00, 2:06:15]
- [Bob Nelson](https://unitybiotechnology.com/team/robert-t-nelsen/) [1:10:30]
- [Kristina Burow](https://unitybiotechnology.com/team/kristina-burow/) [1:10:30]
- [Jennifer Elisseeff](https://www.bme.jhu.edu/faculty_staff/jennifer-h-elisseeff-phd/) [1:22:45, 1:27:15]
- [Rémi-Martin Laberge](https://www.linkedin.com/in/remi-martin-laberge-a0b06b3b/) [1:25:15]
- [Ned Sharpless](https://www.cancer.gov/about-nci/leadership/director) [1:26:00]
- [Bennett Childs](https://scholar.google.com/citations?user=p8q0RUEAAAAJ&hl=en) [1:45:30]

§

![](https://peterattiamd.com/wp-content/uploads/2020/05/ned-bio-image-neddavid-500x500.jpg)

##### Ned David, Ph.D.

Ned co-founded UNITY in 2011, largely because he thought it was “simply the coolest biology he had ever seen.” Before UNITY, Ned co-founded four other biotechnology companies that together raised over $1.5 billion in financing and today employ over 400 scientists, engineers, and business people. Ned builds companies because he sees company creation as a means to create technologies that change the world. Ned is a co-founder of Syrrx (acquired by Takeda), Achaogen (AKAO), Kythera Biopharmaceuticals (KYTH, acquired by Allergan), and Sapphire Energy. Ned holds pending and issued patents in fields such as nanovolume crystallography, antibiotic resistance, aesthetic medicine, and cellular senescence. He has served on the board of directors of Kythera Biopharmaceuticals, Sapphire Energy, and the Buck Institute for Research on Aging and is a member of the board of trustees of the University of California Foundation. Ned was named one of the Top 100 innovators in the world under 35 by the MIT Technology Review. He holds a Ph.D. from the University of California, Berkeley in Molecular and Cellular Biology and an A.B. in Biology from Harvard University. [[unitybiotechnology.com](https://unitybiotechnology.com/team/nathaniel-david/)]