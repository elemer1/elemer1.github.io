# #257 ‒ Cognitive decline, neurodegeneration, and head injuries: mitigation and prevention strategies, supplements, and more | Tommy Wood, M.D., Ph.D.

**Source:** [https://peterattiamd.com/tommywood/](https://peterattiamd.com/tommywood/)

---

Tommy Wood is an Assistant Professor of Pediatrics at the University of Washington, where he studies brain injury and how lifestyle choices and environmental factors contribute to brain health, cognitive function, and chronic disease. In this episode, Tommy delves into the complexities of age-related cognitive decline and explores interventions to counteract it. Drawing from his experience working with Formula 1 drivers, he highlights the connection between cognitive function and the right type of demands and training leading to improvement. Next, he explores the various theories on the different types of pathology in dementia and neurodegeneration. He makes the case that a large fraction of dementia is preventable through lifestyle choices and nutrient status, and provides an in-depth overview of interventions and supplements that support cognitive function. Finally, he provides a comprehensive overview of head injuries, including concussions and traumatic brain injuries (TBIs), discussing symptoms, how to mitigate damage following an incident, and long-term management.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tommywood/the_Drive_public.png)

Play

#257 ‒ Cognitive decline, neurodegeneration, and head injuries: mitigation and prevention strategies, supplements, and more | Tommy Wood, M.D., Ph.D.

#257 ‒ Cognitive decline, neurodegeneration, and head injuries: mitigation and prevention strategies, supplements, and more | Tommy Wood, M.D., Ph.D.

1x15s30s

0:002:07:06

## We discuss:

- Tommy’s professional work, unique skill sets, and interests [3:00];
- Age-related decline in cognitive function and memory [5:45];
- Improving brain function with the right level and type of demand [20:15];
- Formula 1 as a model for how to perform under high cognitive demand and how to increase multitasking capacity [31:30];
- Advice for the person reaching middle life looking to mitigate cognitive decline [37:45];
- Tasks and activities that support and improve cognitive function [45:30];
- Neuropathology of Alzheimer’s disease: exploring the role of amyloid and tau proteins [49:30];
- Why Tommy believes dementia research funding should be focused on environmental and lifestyle-based risk factors [1:05:15];
- Benefits of lowering homocysteine and boosting omega-3’s, and evidence-based supplements that support cognitive function [1:09:00];
- A unifying theory of dementia [1:20:45];
- How muscular strength can help with both the prevention and survivability of dementia [1:24:15];
- Head injuries: comparing concussions against traumatic brain injuries (TBIs), mitigating the damage after an incident, and the long-term management of head injuries [1:29:15];
- Is hyperbaric oxygen treatment helpful after a TBI? [1:45:45];
- Supplements that aid recovery from a TBI: creatine, DHA, and choline [1:49:30];
- Demands faced by F1 drivers, and testing interventions to improve their performance [1:57:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Dr. Tommy Wood is an Assistant Professor of Pediatrics and Neuroscience at the University of Washington
- Tommy’s research interests include determining how multiple types of brain injuries can impact brain health across lifespan as well as developing easily accessible methods with which to track health, performance, and longevity in both professional athletes and the general population
- Tommy has acted as a performance consultant for professional athletes in a dozen different sports
  - Most recently he worked with a number of Formula 1 drivers through Hintsa Performance, which is how Tommy and Peter met about five years ago
- Tommy also serves as an Associate Editor of the Wiley Journal *Lifestyle Medicine*
- He is a founding Trustee and Director of the British Society for Lifestyle Medicine
- He works with a number of digital health companies for charities that focus on how lifestyle and the environment can affect long term health and chronic disease
- In this episode, the conversation is focused on the brain
  - Although they do pepper in some conversations around F1
- First they speak about age-related cognitive decline
  - What cognition and cognitive decline is
  - An in-depth discussion around memory, reaction time, executive function, memory retrieval, and more
  - The root causes of age-related decline
  - Cognitive demand, including how we should think about distractions and multitasking
  - Skills needed to avoid a sharp age-related cognitive decline, and the benefits of different types of brain stimulation
- They discuss different theories on the different types of pathology in dementia and neurodegeneration
- They speak about lifestyle factors that can help prevent dementia and the importance of muscle
  - They look at various supplements that can help with the prevention and survivability of dementia
- The discussion ends on the topic of head injuries
  - What a concussion and traumatic brain injury (TBI) are and their various symptoms
  - What someone can do to minimize the severity of these injuries

## Tommy’s professional work, unique skill sets, and interests [3:00]

- Peter last saw Tommy six months ago at [COTA](https://en.wikipedia.org/wiki/Circuit_of_the_Americas) (a Formula 1 facility)

**Background on Tommy’s work**

- Tommy has a varied experience and background with is useful for what he does, but it can be confusing because people will know him from one arena but not know the work he does elsewhere
- He is an [Assistant Professor of Pediatrics and Neuroscience](https://www.peds.uw.edu/user/1778) at the University of Washington in Seattle
  - Where the majority of his work is in basic animal preclinical research in brain injury
  - He looks at ways to treat the injured newborn and pediatric brain
  - He also does some work in traumatic brain injury (TBI)
- Before he became a professor, he trained as a medical doctor in the UK
  - He worked as a doctor in Central London for a couple of years before he did his PhD in physiology and neuroscience
  - Currently, he does not have an active medical license
  - But his medical training informs a lot of the work he does
- Alongside that formal training pathway, he spent a lot of time working with athletes
- Tommy was an athlete as a student
  - Rowing was his main sport, and he spent time coaching rowers
- Later during his PhD and postdoctoral work, he worked with a company that worked with athletes trying to improve performance (or their overall health) and their longevity in sport
  - This was the main thing he saw many people wanting to focus on
- Through that he got to work with [Formula 1](https://en.wikipedia.org/wiki/Formula_One) drivers via a company called [Hintsa](https://www.hintsa.com/company/)
  - This is where he does some additional work in athletic performance and health
- Tommy knows Peter has had their good mutual friend [Luke Bennett](https://ch.linkedin.com/in/luke-bennett-5880878a) on the [podcast](https://peterattiamd.com/lukebennett/) before
- Tommy also has interest in long-term cognitive function
- He looks at how the brain responds to injury, to repair or mitigate injury processes
  - He’s really interested in how all these things tie together

> “*What I’m really interested in is how do all these things tie together? How do aspects around lifestyle and the environment affect how your brain functions throughout your entire lifespan?*”‒ Tommy Wood

- He does some work with dementia charities in the UK related to the effects of lifestyle and environment on brain function
- He is also a Founding Director of the [British Society of Lifestyle Medicine](https://bslm.org.uk/)

***Tommy is particularly interested in how we can use lifestyle to improve population health***

## Age-related decline in cognitive function and memory [5:45]

- As we get older you see a pretty linear steady decrease in cognitive function
  - Aspects of executive function and working memory
  - The exception is historical memory, and that’s probably because of the way that those memories are encoded
    - They’re sort of moved from the main memory to storing machinery
    - They’re spread throughout the cortex and protected from some of the changes that happen as we get older
- This leads to significant  long-term loss of cognitive capacity, which could be called cognitive dysfunction
- You might see an accelerated trajectory where a person goes from what we call [mild cognitive impairment](https://en.wikipedia.org/wiki/Mild_cognitive_impairment) (which can be diagnosed with standardized cognitive tests) into frank dementia (of which there are many subtypes)
  - The one most people are concerned about is [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)
- There are probably multiple things that drive both of those paths, but in some individuals, this accelerated decline then ends up in them having the diagnosis of [dementia](https://en.wikipedia.org/wiki/Dementia)

**Let’s give people a real sense of what cognition actually is**

- One of the most common things Peter hears from patients is some sort of complaint around memory
  - Obviously that’s one component of cognition
  - He doesn’t hear many people complain about decreased executive function or processing speed
    - Perhaps because most people aren’t pushing those to their limits
    - Or because we don’t have readily available tools to internally discern decreases in that

**You can define the domains of cognitive function**

- 1 – Executive function revolves around complex decision making
  - An example for the average person is when you think about saying something, but then you realize it’s a bad idea
  - Your prefrontal cortex is jumping in and saying, “*That’s a really bad idea*”
- 2 – Short-term memory
- 3 – Long-term memory
- 4 – Processing speed
- 5 – Reaction time
- When you talk to individuals about cognitive function, they have their own things that they want to be good at
  - It’s very personal
  - You can use a standardized battery of tests clinically, and there is usually some aspect of function that is declining over time
  - There are aspects that an individual may want to be better at, and they can put focused attention into improving that
    - Tommy believes you can improve that at pretty much any stage of life

**Memory is something people will mention the most and notice in themselves**

- There are two parts to memory, and it’s different in most people, even in the setting of age-related cognitive decline and those who have pathological cognitive decline
- 1 – Encoding that memory in the first place
  - The information comes in, and your brain signals through [acetylcholine](https://en.wikipedia.org/wiki/Acetylcholine) other neurotransmitters to actually say, “*This is something that we want to recognize and store*.”
  - That’s the process that seems to be particularly lost in those with pathological cognitive decline
  - That’s why things like [cholinesterase inhibitors](https://en.wikipedia.org/wiki/Cholinesterase_inhibitor) were and are still used in Alzheimer’s disease, because that helps to bolster some of those encoding processes, through acetylcholine signaling
  - A lot of the process starts in the [hippocampus](https://en.wikipedia.org/wiki/Hippocampus), but over time as you get consolidation of these memories, they may get moved around
  - Historical memories get shifted throughout the [neocortex](https://en.wikipedia.org/wiki/Neocortex), which is basically the rest of the outside of the brain
- 2 – Memory retrieval
  - The information is in there; this is the process of getting it out
  - Retrieval speed seems to slow down with age
  - We often think of this as pathological
  - But part of it may be that over time you just accumulate more information, and this makes it harder/ take longer to bring out a certain piece of information
- Peter remembers this is the argument that [Arthur Brooks](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) made about aging (in [episode #226](https://peterattiamd.com/arthurbrooks/))
  - As you add memories, you’re creating volumes in a library, and the more volumes in the library, the longer it takes the librarian to go and get a specific reference

**How can we figure out the relative contribution of library size versus librarian speed when it comes to accessing memories?**

- Examples that resonates with Peter:
  - He meets somebody and can’t remember their name, but five minutes later he can (or he has an idea)
  - He wants to say something and at the last minute, he can’t remember, but then 10 minutes later he kind of remembers
- Tommy thinks it is probably very difficult to parse all of these out, “*I don’t think we could pretend that we know exactly the relative contributions*”
- Some of this is certainly affected by other factors
- It seems that sleep impairment or suboptimal sleep impairs retrieval
- Subjective stress seems to also play a role here
- Some of it is accepting that your library is larger and some of it is thinking about other factors that may be impairing or allowing for that process to be suboptimal such that retrieval is harder
- Another factor ‒ as your library gets bigger, your librarian becomes more selective in therms of things they put on the bookshelf
  - Imagine you’ve met thousands of people in your life, and you add a hundred more
  - It’s very easy to say, “*This is the first time I met this person, and I may never see them again. It may not be worth encoding that memory.*”
  - You may become more selective in what actually gets stored, and this is not necessarily a pathological process
  - This may be your brain doing its normal job of determining what’s worth storing

**What is a memory physically and why is there a finite amount of storage?**

- Peter has an understanding of why a hard drive is finite, and if I only have two terabytes on a hard drive and I keep adding video to that, eventually at some point there is no more storage capacity
- He doesn’t have enough of an understanding of what a memory is and why it would therefore have a physical constraint
- This is beyond Tommy’s area of expertise, and he knows this is a topic that is hotly debated
- Some people have said that comparing human memory to a hard drive is complete fallacy
  - But we use this because it’s something we can understand, and it helps us apply a very complex process to our own thinking and understanding of how our brains might work
- In reality, that is *not* how memories work, and there shouldn’t be a limit on capacity in the same way there is with a physical hard drive
- However, there are probably still a finite number of things that your brain will choose to encode and store for the same reasons that you only want to have the information that’s probably maximally useful for your survival
  - And then, that puts some constraints on how the system sets up, what it decides to store and then retrieve
- Peter’s 8-year-old son was asking him these questions last night, “*Where memories in his brain were and how they get there*”
  - It’s amazing (and disappointing) when kids ask questions you can’t come up with an answer to
  - Peter wasn’t thinking of great questions like this at that age

**Peter’s takeaway** ‒

- As time goes on, presumably two things are working against an aging individual ‒ one is pathological and one is not
- The non-pathological one is you have a greater reservoir of memories and your brain might be selectively choosing how to prioritize new encounters and new memories
  - With some understanding that the denominator keeps growing, it has to be selective
- The pathological, age-related changes that occur related to the librarian (this is probably controversial)
  - The librarian slows down and their vision reduces in a way that makes it more complicated for us to retrieve memories, do computational cycles and processes of executive function, and all the important pieces of cognition

**What do we think is at the root of age-related decline?**

- Tommy thinks about what we know with aging ‒ we tend to see a decrease in size (atrophy) of the [frontal](https://en.wikipedia.org/wiki/Frontal_lobe) and then the [temporal](https://en.wikipedia.org/wiki/Temporal_lobe) parts of the brain [shown in the diagram below]
  - In particular, the medial temporal, and this is where you [hippocampus](https://en.wikipedia.org/wiki/Hippocampus) sits as well as some parts of the [cortex](https://en.wikipedia.org/wiki/Cerebral_cortex) around it (like the [parahippocampal gyrus](https://en.wikipedia.org/wiki/Parahippocampal_gyrus) [entorhinal](https://en.wikipedia.org/wiki/Entorhinal_cortex) region[)](https://en.wikipedia.org/wiki/Parahippocampal_gyrus)

![](https://peterattiamd.com/wp-content/uploads/2023/06/f1-tommywood.png)

**Figure 1. Lobes of the cerebral cortex (right hemisphere, lateral surface view)**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Lobes_of_the_brain)

- There are different schools of thought of why those areas of the brain may be particularly vulnerable
  - Maybe because of their specific function for memory
  - Maybe because they’re involved in the initiation and continuation and structure of sleep (very important for memory consolidation and various processes of recovery and repair)
  - These areas seem to be particularly susceptible to negative outside influences and then also susceptible to beneficial supportive processes (like putting greater demand on those areas of the brain such that they respond and increase in their function)

**Things important for a healthy brain**

- Various buckets of things that are required for a healthy brain: vascular supply, supply of metabolic energetic substrate, and important things around structure and function
  - This last one could be structure related to neuronal membranes, and the importance of [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) [omega-3 fatty acids](https://en.wikipedia.org/wiki/Omega-3_fatty_acid)
    - They are concentrated in synapses, they’re very important for communication between neurons
  - Mitochondrial function is an important part of that
- And then, you might think of actually placing a demand on those structures
  - In most aspects of biology, the function of an organ is proportional to the demands placed on it so that you increase capacity
  - But then, that also requires some period of recovery, and that’s where sleep and other things come into play
- Plus, you might want to avoid negative outside factors
  - Regarding dementia, we know that there’s some risk associated with things like smoking, potentially air pollution, chronic inflammatory or infectious conditions like periodontal disease

***You want to have this supply of substrate, you want to have good function, you want to make sure you allow that area to rest and recover; you want to avoid things that then may impact those processes***

- What may be driving a lot of this is what we ask those regions of the brain to do declines naturally over time based on how we currently structure our lifespan

## Improving brain function with the right level and type of demand [20:15]

**Demand and what we ask of the system**

- Peter knows you cannot maintain muscle mass without putting the muscles under significant demand that is so strenuous that you wouldn’t be able to maintain it indefinitely (you can only do it for a few hours)
  - You can think of exercise as a [hormetic](https://en.wikipedia.org/wiki/Hormesis) stress
- Peter hasn’t thought about it this way, but there are certain organs for which he would guess this is not true, such as the liver or kidneys
  - Do hepatocytes need to feel the insult of alcohol to otherwise perform well?
- Tommy has thought about the liver and the case about alcohol holds
  - It’s not that the liver doesn’t function without alcohol exposure, but if it wants to optimally deal with a certain type of product (ethanol), it wants to metabolize it
  - We know with chronic alcohol exposure, before you get to the point of liver damage, there is up-regulation of [cytochrome P450 2E1](https://en.wikipedia.org/wiki/CYP2E1), [aldehyde dehydrogenase](https://en.wikipedia.org/wiki/Aldehyde_dehydrogenase), mitochondrial function, and metabolism to regenerate [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (which is a rate-limiting step for alcohol detoxification)
  - So yes, if you stress the liver with alcohol, it will up-regulate its function in order to have a greater capacity when the next drinking session occurs
- Tommy thinks there are parallels across multiple organ systems
- Just to clarify, Peter states, “*We would all agree that the health benefits of alcohol are none*”
- But you’re going to do a better job of tolerating two drinks if you occasionally have a drink, as opposed to if you never drink

***If you want an organ system to function in a specific way, if you want your brain to improve its function in a specific domain, you have to apply a relevant stressor that is hormetic, give it time to recover and adapt, and then you will get an increased capacity later***

- Exercise might be a way for people to better understand it because you can kind of see that happening
- This is very relevant to the brain

**What might be a difference between a positive and a negative demand?**

- Most of the people listening to this podcast right now are under some cognitive demand, as talking about this stuff requires some concentration to pay attention to
  - That level of cognitive demand will depend on your familiarity with the subject
- Tommy thinks the idea of cognitive demand is relative to the individual as well as what they want their brain to function best at, but there are multiple different ways you can come at it
- For **the process of generating skills**, think about how a toddler interacts with their environment such that they are developing motor skills, language skills, social skills
  - Often, there is this concerted effort for a short period of time, where you are right at the limit of your current capacity, being able to stand, being able to walk, being able to climb a tree, being able to pronounce a certain word
    - Maybe you could put a timeframe on it (20-30 minutes), and adults may be able to do this for longer (right on the edge of your skillset)
  - Then, there is some failure, and the process of failure up-regulates the process of focus and attention, up to a point before we get frustrated
  - Then there is some rest and recovery
    - Your toddler is going to sleep a bunch after they have spent a lot of time exploring the environment, trying to improve their skills
- This provides an idea of the type of focused attention that you put into something that then drives **plastic reorganization**, which is what we care about
- We want to try and drive an increase in functional capacity in some domain of cognitive function, and it’s probably going to be something that looks like that
- There are benefits to continually doing things at the level of your current capacity
  - If you’re an athlete, you’re not always pushing the boundaries, not always doing a red-line session that drives a bunch of adaptation
- The brain is similar, but that’s very different from how most adults perform in their day-to-day work
  - Where yes, it feels cognitively demanding, but you are multitasking, task switching, so you’re never providing focused attention on a specific subject
  - And you are also not really providing that stimulus to increase skill in a specific area necessarily
  - Even though you feel busy, even though something feels cognitive demanding, those stimuli are not the same in terms of what’s driving a functional change in some area of the brain

**Peter wonders where distraction and lack of focus fits into the mix. Are there any heuristics for what is too much task switching? Too much distraction?**

- Peter went through a bout of this yesterday; he was trying to get a lot done, and one more thing got put on his plate
  - There was a window of 10 minutes where he accomplished literally nothing by toggling back and forth between three different emails, texts, WhatsApp, and a document he was trying to work on
  - He couldn’t get anything done
  - To be that debilitated is pretty unusual for him
  - He would have been better off literally walking around the house for that 10 minutes
  - So clearly there is a threshold there where you’ve crossed a line from being busy and focused/ productive to busy and unproductive
- Tommy would make the argument that humans in general **cannot multitask** in the way that Peter describes

**There are probably two different types of multitasking**

- 1 – One is the automatic performance of learned subroutines that kind of just happen, and you could do multiple of them at the same time
  - Say you’re a dancer, and you are running subroutines, the steps you’ve learned, interacting with a partner, listening to the music
  - You are technically multitasking, but those are all learned subroutines that are essentially happening automatically or subconsciously
- 2 – What Peter describes as multitasking is that process of focusing on one thing, then another thing, then another thing
  - We know that there’s a loss function in terms of the time it takes to get back onto a new task from the previous task
  - It’s something on the order of 20+ seconds for you to refocus onto something
  - *Say you are switching your focus every minute or two; the amount of time you actually have to focus on one specific task is dramatically reduced because a significant proportion of that is just spent with your brain figuring out what it is you’re asking it to do*

***The majority of people cannot directly focus on multiple things at the same time, switching from one thing to the other; most people cannot do that well, even though they think they can***

- Peter relates this to exercise ‒ if he is doing a steady state zone 2 workout on a stationary bike, he can listen to a podcast/ audiobook and be completely focused while still managing to be on a bike and pedal
  - But if he’s doing a higher intensity cardio workout or lifting weights, he can’t listen to audiobooks/ podcasts
  - Those tasks demand just a little more attention and are not as automatic
- Tommy thinks that traditional work-based multitasking is probably the point where there’s this biggest gap between perceived demand and the amount of beneficial cognitive stimulus you’re actually getting
- This reminds him of something that a former colleague at Hintsa ([James Hewitt](https://jameshewitt.net/about/)) would call this the “*cognitive middle gear*”
  - He also used to be a professional cyclist
  - This is the point where effort is high, but sort of the end product is minimally useful
  - If you can think about athletes who may go out and thrash themselves at threshold for an hour and do that every day, it feels really hard
  - But in terms of physiological adaptations that improve performance, ***there’s a big gap between how hard it is and benefit***
  - Multitasking is the same, “*It’s a physiologic no-man’s land*”
    - It’s too hard to give them the wide aerobic base and not hard enough to give them that peak performance

## Formula 1 as a model for how to perform under high cognitive demand and how to increase multitasking capacity [31:30]

- Peter and Tommy have been fans of this sport for a very long time
- Many people listening to this have become fans of F1 through Netflix’s [*Drive to Survive*](https://en.wikipedia.org/wiki/Formula_1:_Drive_to_Survive) series
- Anybody who’s watched the sport will appreciate how much they need to be able to do while driving
- On a personal level, this is something Peter can relate to, because he has spend a lot of time in a car and in a simulator
  - And he is nowhere near being able to do what a F1 driver does
- A F1 driver is traveling at unbelievable speeds; their straight-line speed is 200-220 mph
- The amount of things that they have control over on this computer that masquerades as a steering wheel in front of them is unbelievable
  - Between every corner, they’re making some adjustment
  - They’re switching the brake bias with one knob, which shifts the emphasis or force between how much brake is on the front wheels versus the rear
  - They’re altering the slip angle of the differential, which is allowing inner wheels versus outer wheels when they’re going around corners to move at different relative speeds
  - They’re adjusting the drag reduction system when appropriate
  - They’re adjusting access to battery power if they’re passing or overtaking or trying to defend
  - They’re pushing a radio button to talk to their engineer who’s talking to them the whole while
- Peter has been driving for nine years, and he can’t come close to managing all of those variables in the simulator
  - The most he can handle when he is driving is driving and talking and maybe adjusting brake bias here and there

**How do those guys do so much, and what do we need to do to get better at that capacity?**

- Peter asks, “*Is it sport-specific and because these guys have been driving carts since they were five, things I have to think about while driving, they don’t?*”
- Tommy things that is a lot of it
- This is similar to the idea of running several **learned sub-routines** at the same time (something the brain is very good at)
- If you’ve spent your entire life as a racing driver (which they have essentially), these guys have been casting since they were young kids
- Then when the computer setup changes or there are new things on the car based on new regulations, they’re just stripping off a top layer and adding on a new one
  - So what they have to learn is very minimal compared to everything else that’s probably happening automatically

***There is a huge cognitive demand, and probably a lot of what they’re actually using their brain power for in the moment is reacting to others (you can’t learn that)***

**When you have drivers that move up the ranks, are there things that coaches will do with the drivers during those big transition years to really help them get up to speed?**

- There’s a pretty big jump from F3 to F2, from the standpoint of complexity of the car, and again from F2 to F1
- For example, Peter has watched the drivers before races, play sort of half physical, half cognitive games where they have little lights on a board and they have to touch them or they’re playing catch or juggling or doing all these sorts of things
  - Are those things doing anything to sharpen their brain or do they just look cool?
- Tommy thinks it’s probably a bit of both
- He would argue that for some drivers it certainly seems to be beneficial
- It’s very different from driver to driver
- There are definitely some drivers who have a dummy steering wheel so they can move through the patterns of doing everything, even if they’re not on the track
  - And this is often the same as when we are learning subroutines
  - Say you you’re learning a new dance, you’ll do the steps one by one without music, then you’ll start to string them together, then you’ll add complexity; and it’s the same thing
  - There are multiple opportunities for them to practice some of these skills even though they don’t get a huge amount of time actually racing on the track
- These drivers are doing reaction games, and some of them may do it in terms of practicing starts
  - Some of it may be [placebo](https://en.wikipedia.org/wiki/Placebo)
  - It helps them feel like they’re getting ready, which is great, and anything you can do to improve that, you would welcome
- But then the other part of it may be moving you onto the appropriate part of the [Yerkes-Dodson arousal curve](https://en.wikipedia.org/wiki/Yerkes%E2%80%93Dodson_law) [shown in the figure below]
  - Which basically says that there’s this inverted U-shape curve of how aroused you are and how you perform
  - And that curve is different based on the sport
  - Having some period where you are having to focus and react but also remain relatively relaxed is incredibly important
    - You want to be fast off the start line, but then the first thing you have to do is get into turn one when you have eight guys around you trying to navigate at the same thing and you have to react to them
    - So if you were very tense, that would decrease your performance in that setting

![](https://peterattiamd.com/wp-content/uploads/2023/06/f2-tommywood.png)

**Figure 2. Common version of the Yerkes-Dodson law**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Yerkes%E2%80%93Dodson_law)

- Some of it is just getting you to the point where you are **focused but then also relaxed**
- If you’re doing it with some kind of skill-based thing that requires you to also be relatively fluid, you can’t do that if you’re very stiff and tense
  - It could be catching a ball suddenly
  - It’s some of it’s this balance of getting into the right mindset before you then have to do something once you get into the car

## Advice for the person reaching middle life looking to mitigate cognitive decline [37:45]

**As a person reaches middle life and is thinking about what lies ahead in older age, what apex set of skills do they need to have to give them the highest amount of physiologic headroom to minimize this age-related decline?**

- Most of us are never going to be professional drivers or athletes
- The need for really complex motor skills and cognitive skills may go down as we age
- But we want to avoid the pathologic cognitive decline
- Tommy thinks a lot of this is individual

***If you want to be able to perform a specific task in the next four or five decades, then you would want to push your skills as far as you can in that arena while you’re able***

- For example, if you wanted be able to drive cars for as long as you’re able
- We cannot completely stop the aging process, but you may be able to slow the decline and/or if you increase your level of capacity, it’ll take longer to get to a point where function is lost such that you can no longer engage in that activity
- Thinking about the brain, there is a whole bunch of things related to **language skills**
  - Memory
  - How you interact with your environment ‒ social interaction is critically important
    - This is something that is probably under-discussed in relation to long-term cognitive function
    - That is a critical aspect, particularly as people spend less time with others because of societal effects

***When you think broadly about how cognitive function declines with age, it seems to mirror very closely the amount of demands that we put on our brains and how society is constructed***

**Cognitive function essentially increases from birth to some peak in late teens or early twenties**

- This is the period of formal education where it’s your job to learn and develop skills
- This is when most sports are learned
- This is when languages are learned
- After that, you spend a lot of time doing the same thing over and over again
  - You become hyper-specialized in one specific skill and that’s rewarded in a number of jobs
    - If you’re a surgeon, you want a lot of those processes to be automatic; you don’t want to think about all of them continuously
    - This is beneficial, it makes you better at your job
- In that period of skill building, there’s not much effort put into providing the kinds of stimuli that drive plastic reorganization in the brain that may increase headroom
- Some of that natural decline with aging is a function of how we use our brains in general in society
- There is a drop-off when we retire
  - In various different types of data sets, those who retire earlier seem to experience cognitive decline sooner
  - That’s probably because the majority of the cognitive demand we get in our daily lives comes from work

***If you’re trying to maintain a basic set of cognitive functions, it is important to actively work on ways to increase headroom, increase absolute capacity throughout the lifespan***

- At some point capacity will decrease, but you want to push that out as far as you can, and hopefully you’ll die of something else before you lose the majority of your cognitive capacities

**Cognitive decline after retirement**

- Everybody is aware of the anecdote where “*Sally was just sharp as a tack, and then she retired and all of a sudden it all went to hell in a handbasket.*”
- But there must be other contributors to it:
  - Maybe people who retire younger also have more health challenges
  - Maybe they’re of lower socioeconomic
  - You could come up with a lot of confounders that could explain this, but Peter suspects there is also a signal there to where if you retire and in its place add nothing cognitively, you could expect to see a decline
- Peter wonders how much of this has to do with a sense of purpose
- Maybe retirement should be thought of as a financial decision ‒ where you no longer have to work for money, but you are going to work on something else
  - It may not be as cognitively demanding
  - It may have a greater sense of purpose
  - You might derive more satisfaction from it even though it’s not as cognitively challenging

**Do we have any sense of how that factors into it, or is that just so far outside of our ability to understand risk?**

The majority of studies that have looked at this fall into two camps which partially answer this question

- 1 – Population-based studies look at the **removal of stimulus** through retirement
  - They usually account for medical conditions that might cause you to retire early because that’s an important confounder
- 2 – Other studies suggest that **cognitive activity late in life is protective** against incident dementia or cognitive decline
  - If you regularly play chess, dance, or something else that’s cognitively stimulating

***The two parts of that would say that removal of work as a major cognitive stimulus increases risk, but that adding some other kind of cognitive stimulus mitigates that risk***

**Cognitive training**

- There are several studies where you do some kind of cognitive training, and you can see significant improvements in cognitive function
  - Maybe it’s computer-based brain training in older adults in their 70s
- A big [meta-analysis](https://jnnp.bmj.com/content/91/11/1201.long) (done by [Jin-Tai Yu](https://research.com/u/jin-tai-yu), a professor in Shanghai) looked at all the different potentially modifiable factors for cognitive decline [summarized in the figure below]
  - They found the two most important protective factors were early in life education and late in life cognitive activity
    - The more you learn and skills you develop early in life and the longer you do that for, the greater headroom you have
  - There is enough observational evidence to support these findings
- There are some interventional trials in older adults to say if you are no longer working but replace work with cognitively stimulating activities, you are probably mitigating most of the risk

![](https://peterattiamd.com/wp-content/uploads/2023/06/f3-tommywood-1024x589.png)

**Figure 3. Evidence-based modifiable factors that influence risk of Alzheimer’s disease**. Image credit: [*Journal of Neurology, Neurosurgery, and Psychiatry* 2020](https://jnnp.bmj.com/content/91/11/1201.long)

## Tasks and activities that support and improve cognitive function [45:30]

**Not all cognitive tasks are created equal**

- We’ve discussed this in the podcast in the past [[AMA #46](https://peterattiamd.com/ama46/)] where for example, there wasn’t any evidence that doing crossword puzzles is going to do anything for you other than make you better at doing crossword puzzles
- Dancing is different because no two steps are exactly the same, and you’re always sort of problem solving (especially if it’s a complicated dance)
- Solving a business problem is more elaborate than doing Sudoku or predictable word games
- The same goes for paint by numbers versus painting; the latter has a much higher level of cognitive load

**Cognitive training such as brain games**

Tommy knows of two streams of evidence that maybe support this

- 1 – Studies around cognitive activities performed on a computer
  - There are a number of different ways to do online brain training
  - There’s a system called [Brain HQ](https://www.brainhq.com/?v4=true&fr=y), which probably has the best [evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8138705/) to support it
    - It’s a subscription service (Tommy has no relationship with it)
    - It was developed by one of the researchers who did a whole bunch of the primary basic research in terms of how we learn in the first place back in the nineties
    - They have some nice data that shows that if you do these complex training games, which are often reacting to something or shifting focus (they’re very interactive), then you can see parallel improvements in things like verbal memory and executive function, things that you actually care about in real life
    - You’re not just getting better at the game, you’re getting better at certain cognitive functions
  - There are also [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7286064/) using video games where if you randomize people to play Solitaire versus Angry Birds versus Mario 3D
    - The 3D game results in better improvements in working memory, and there is some response in inhibition, which is a version of executive function

> *“The more complex, the more interactive something is, seems to be the greater the improvements in cognitive function associated with it*.” —Tommy Wood

**Physical activity**

- 2 – Related to that is work in physical activity, such as dancing
  - [Studies](https://www.frontiersin.org/articles/10.3389/fnhum.2017.00305/full) have compared dancing to circuit training that is as cardiovascularly challenging but without that element of social interaction, music, movement, steps, reacting and you see better improvements in the dancing group
- Some people have termed this open skill versus closed skill physical activity
  - Closed skill is unidirectional, doing the same thing again and again, so sitting on an exercise bike inside, you’re not doing anything else at the same time except maybe listening to a podcast, versus say table tennis or badminton
  - So the physical nature of it, the cardiovascular stimulus is the same, but you’re not reacting to the environment and other people

*“When you do those open skill types of physical activities, you seem to see some greater improvements in cognitive abilities*”

- Those various things that say that the more domains or the more complex the interaction associated with the activity, the greater the associated improvements
  - When you walk outside on an uneven surface and you have to be able to physically and cognitively be aware of what’s beneath your feet, that is going to be a lot better for you than walking on a treadmill or around a track in circles

## Neuropathology of Alzheimer’s disease: exploring the role of amyloid and tau proteins [49:30]

- Listeners to this podcast have a decent understanding about Alzheimer’s disease and Alzheimer’s pathology [[explore previous podcasts and newsletters](https://peterattiamd.com/category/diseases/neurodegenerative-disease-prevention/)]

**Refresh people’s memories on the difference between Alzheimer’s disease specifically and other kinds of dementia such as vascular dementia, frontotemporal dementia, Lewy body dementia, and even forms of dementia that don’t necessarily fit neatly into these boxes**

- These are the four main types of dementia (Alzheimer’s disease, vascular dementia, frontotemporal dementia,and  Lewy body dementia)
- There are other ones associated with other neurodegenerative conditions
  - Parkinson’s disease or ALS
  - They can be complex and multi-domain
  - You might see changes in different areas of the brain
- The main thing that ties together the two forms of Alzheimer’s disease (early-onset and late-onset) is the neuropathology
  - This is something that’s worth digging into because both the genesis of the eponym as well as how we now use it is very interesting
  - If you slice somebody’s brain open, the primary atrophy and pathology seems to exist within the medial temporal lobe is [amyloid plaques](https://en.wikipedia.org/wiki/Amyloid_plaques) and [tau tangles](https://en.wikipedia.org/wiki/Neurofibrillary_tangle) (hyperphosphorylated tau) within the neurons
    - Although it can be throughout the brain

**The initial case of Alzheimer’s disease**

- The initial case of Alzheimer’s disease was [Auguste Deter](https://en.wikipedia.org/wiki/Auguste_Deter), who [Alzheimer](https://en.wikipedia.org/wiki/Alois_Alzheimer) treated in an asylum for several years and then looked at her brain after she died
  - He saw these things under a microscope, then collected other cases where they saw similar things
  - And this was done right at the beginning of biological psychiatry, where they were trying to find biology that explained psychiatric symptoms
    - One of the things you could do at the beginning of the 20th century, was look at things under a microscope after that person had died and that’s how they classified it
- However, we can get into how actually these pathological hallmarks correlate very poorly with somebody’s symptom burden and disease progression and the reasons why they accumulate may be very different from person to person and may matter much less from one person to the next
- Yet, it’s these pathological hallmarks that created the classification of what we call Alzheimer’s disease
- Peter wrote about this story in his chapter on Alzheimer’s disease in his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1684261292&sr=8-1), and they exhumed her body many years later and examined her brain
  - She did not have the typical Alzheimer’s disease that we see today
- Auguste Deter was in a small subset that get a variant of the disease that is genetically predetermined
- She may have had a mutation in [*PSEN1*](https://en.wikipedia.org/wiki/Presenilin-1#Alzheimer's_disease), but that’s hotly disputed
  - There was a paper in [*Lancet Neurology* 2013](https://www.thelancet.com/journals/laneur/article/PIIS1474-4422%2812%2970307-1/fulltext) where they sequenced her brain and they supposedly found this mutation in *PSEN1*, but then another group got another sample of her brain and couldn’t find any mutations associated with familial or early onset Alzheimer’s disease
  - Though if she did have an early-onset dominant mutation (monogenic), none of her children got it
  - There are a lot of people who think there is no evidence she had a mutation
- Mutations of genes that cause **early-onset Alzheimer’s** (autosomal dominant inheritance): [*APP*](https://en.wikipedia.org/wiki/Amyloid-beta_precursor_protein)*,* [*PSEN1*](https://en.wikipedia.org/wiki/Presenilin-1#Alzheimer's_disease)*,* and [*PSEN2*](https://en.wikipedia.org/wiki/PSEN2)
  - It is not uncommon for someone to be stricken in their forties and dead before age 60

**What is the best case explanation for her disease, its severity and the histologic findings?**

- After Alzheimer examined her brain, supposedly he was encouraged by his mentor ([Emil Kraepelin](https://en.wikipedia.org/wiki/Emil_Kraepelin)) to gather together cases and build a common pathological process
  - Some say Alzheimer was reluctant to try and group these people together because they were so different
  - Alzheimer’s cases are all so very different
- In the version of the story where she doesn’t have a dominant mutation in *PSEN1*, she did have a decrease in her cognitive faculties
  - There are a whole bunch of environmental other factors that could play into that
- Her husband put her into an asylum
- We know one of the fastest ways to trigger cognitive impairment/ decline is to remove somebody from their environment, completely remove all stimulus, social interaction, and all the things that ground them in who they are
- That version of the story says that because of the asylum she was put into, it triggered an acceleration of her cognitive decline
  - Which then may be a maximized version of what we might see in individuals nowadays who experience cognitive impairment and then dementia

**Do we know her** [***APOE4***](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) **status when they were looking for** ***PSEN1*****?**

- That’s a good question, and Tommy doesn’t know if anybody has checked that

**Do you know what the discordance is between the presence of amyloid beta on a histologic sample and the presence/ severity of dementia-related symptoms in that person?**

*The contrapositive of that is to ask about the severity of symptoms in a person and the absence of amyloid beta on a pathologic specimen after they’ve died*

- In an ideal world, it would be a one-to-one mapping that is 100% concordant
  - Anybody who has symptoms would have amyloid beta on autopsy, and nobody who doesn’t have symptoms would have amyloid beta

*How messy is it?*

- Tommy agrees, “*It’d be nice if we could put an R squared or an R value on this to see how tightly correlated they are*.”
- He thinks people have tried to do that correlation and the R is somewhere around 0.1
  - Peter clarifies, “*It’s virtually unrelated*”
- There’s maybe a couple of percentage points in the variability in cognitive function that’s explained by the variability or the amount of amyloid that you have (in animal models and humans)
- There are several studies where they’ve made some very good drugs that can decrease plaque burden in the brain, but that doesn’t seem to then correlate with later cognitive functions
  - These drugs may have a high risk of side effects, although that’s a whole other story that we don’t need to get into today
- Pretty much anybody who dies with dementia or experiences dementia will have some burden of amyloid plaque and tau tangles
  - Tommy doesn’t know of a case where somebody had dementia without any of these
- We also know that these things naturally accumulate over time and there are multiple cases where they’ve looked at the pathology where you have significant burden of these neuropathological hallmarks with *no decrease in cognitive function* (or beyond what might be expected given that person’s age)

> “*There’s a possibility that there’s some other factor*”‒ Tommy Wood

**Other factors that come into play in the pathology of dementia [58:15]**

- 1 – The phenotype of microglia function
  - [Microglia](https://en.wikipedia.org/wiki/Microglia) are the main immune cells of the brain, and are being increasingly interrogated in Alzheimer’s disease

- 2 – Lysosomal function
  - The [lysosome](https://en.wikipedia.org/wiki/Lysosome) processes proteins for breakdown, and that process gets impaired and may trigger accumulation of some of these things [amyloid plaque and tau tangles]
- 3 – The alternative is to maybe think that some of these hallmarks may be epiphenomenal, they just accumulate in the face of **neuronal stressors**
  - In the case of late-onset Alzheimer’s disease, your brain is going to get exposed to a bunch of things: decreasing metabolic function, vascular disease, it may be smoking
  - And then as neurons get stressed, they start to accumulate some of these proteins

**There are some lines of evidence that suggest that some of the amyloid and tau proteins are actually a beneficial response**

- Amyloid beta has some antimicrobial and metal collating effects, so it may be this actually a response to a stress that’s then supposed to be protective
- You get to a point where if you can force amyloid plaques to accumulate in large numbers, where they do start to become damaging in their own, but up to that point, it may be more of an epiphenomenon or a response to a neuronal stress rather than this core sort of underlying pathological process
  - They’ve [shown](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6811362/) this very clearly in animal models

**Peter’s takeaway**

- On the one hand you could ask, “*Is amyloid beta necessary but not sufficient for amyloid plaque?*”
- The classic example would be [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)
  - apoB is necessary but not sufficient for atherosclerosis
  - You have to have it, but by itself it’s not enough
  - You also have to have inflammation, endothelial damage or dysfunction for the apoB particle to get in there and cause damage
  - But apoB is causally related, and that’s why reducing apoB reduces events

*If that were true of amyloid, could it explain part of the observation that lots of people have amyloid without symptoms because it’s only necessary, but by itself it’s not sufficient?*

- But that wouldn’t necessarily imply causality because to have causality, you would have to say removing amyloid because it is necessary though not sufficient, removes the disease
- We don’t really have evidence of amyloid reducing strategies working
  - People will argue the flip side to that ‒ that we are applying those therapies too late

**How do you think about the causality and the necessary but not sufficient argument, and also this temporal argument that we may be way outside of our window to do anything about it?**

- Tommy is open to that idea, though he is skeptical based on the range of animal and human evidence so far

***It’s possible that amyloid beta is necessary, but if it is necessary, we don’t have evidence that it is sufficient to cause dementing processes***

- Some recent work supports the idea that it may not be necessary or sufficient
- There is a process called PANTHOS, which is a poisonous anthos (flower)
  - [Published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9174056/) by [Ralph Nixon’s](https://med.nyu.edu/faculty/ralph-a-nixon) group out of NYU last year
  - They showed in a specific knockout model in mice that amyloid is accumulating inside the neuron
    - It’s aggregating inside failing lysosomes
    - Lysosomes are supposed to process proteins
    - Aggregation of amyloid within the neuron leads to cell lysis (the neuron bursts open), the neuron dies, and they leave a plaque in its place
  - Traditionally we think about amyloid plaque accumulating outside the neuron, a whole bunch of protein sticking together and eventually injuring the neurons around it
- In that setting, there’s a nice quote by Nixon about treating Alzheimer’s disease that essentially says that if you’re trying to remove amyloid, it’s the same thing as trying to revive somebody from the dead by removing their tombstone

***The plaque is the tombstone of a previous neuron that failed its ability to process protein, and then [died and] left this [plaque] in its place***

- There’s still a lot of work to be done to say is this what’s actually happening in humans, which haven’t been genetically manipulated as we do with a lot of mouse models
- Peter finds this to be a very stark concept because it implies that amyloid is an absolute marker for something horrible
  - Just as walking through a town and seeing lots of tombstones tells you if they occurred over a short enough period of time, something bad happened in this town
  - But removing the tombstones does nothing to erase what just happened in that town

**What is the critical response to their model?**

- What is the response of people who think that amyloid is necessary (at a minimum), maybe even sufficient for Alzheimer’s disease?
- Maybe the first major criticism would be to show that this happens in humans
  - Tommy thinks they’re working on some pathological samples to see if this is the case
  - All you’ve done is you’ve moved the amyloid from outside the cell to inside the cell where it first accumulates
- With intracellular accumulation, all you’ve done is you’ve moved the site of initial accumulation
  - That doesn’t then stop it causing damage, being a primary cause de facto
  - Once that first neuron itself, and then the structures around it are damaged, you might get microglial activation and this immune response that can trigger some of the assumed processes
- There is the possibility that even if the process is intracellular accumulation of Aꞵ, you could still say, “*Oh, well, everything else is still the same*”

## Why Tommy believes dementia research funding should be focused on environmental and lifestyle-based risk factors [1:05:15]

*What are some of the other theories? (vascular, metabolic, genetic)*

- Tommy begins by pointing out, “*It’s important for me to mention that a lot of the work and thought I’ve done in this arena is not on my own. I primarily have worked a lot with* [*Dr. Josh Turknett*](https://www.turknett.com/team/josh-turknett-md/)*, who is a neurologist, which I am not, and obviously has a lot of front facing experience in this.*”
- This discussion comes from a [paper](https://www.mdpi.com/2073-4409/11/18/2789) they wrote together about the **demand model** [summarized in the figures below]
  - It is very much a collaboration with Josh Turknett and others, “*I won’t pretend that I suddenly figured anything out by myself because I certainly didn’t, nor can I say that I figured it out*.”

![](https://peterattiamd.com/wp-content/uploads/2023/06/f4-tommywood.png)

**Figure 4. The coupling of demand and cognitive function whereby increasing cognitive demand benefits cognitive function**. Image credit: [*Cells* 2022](https://www.mdpi.com/2073-4409/11/18/2789)

![](https://peterattiamd.com/wp-content/uploads/2023/06/f5-tommywood.jpeg)

**Figure 5. Cognitive demand as an upstream process driving cognitive function and important for preventing decline**. Image credit: [*Lifestyle Medicine* 2022](https://onlinelibrary.wiley.com/doi/full/10.1002/lim2.70)

***For late-onset Alzheimer’s disease, there’s such a broad number of environmental and lifestyle-based risk factors that seem to be critically important, and that’s really where Tommy would focus research efforts***

- You can definitely say that even if the brain is responding to neurological stressors or the absence of expected inputs with the accumulation of certain pathological hallmarks, there’s still some upstream process that’s driving that, and that’s where he would want to focus
  - Summarized in the figure from his paper below
- The best evidence so far is in factors around diet, lifestyle and peripheral health, with cardiovascular health being an important one
- There was a [*Lancet* Commission report in 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7392084/) that looked at dementia broadly and tried to estimate what amount of dementia, what proportion of dementia would be preventable
  - They estimated that 40% of dementia is preventable based on population attributable risk and a bunch of different risk factors looking at physical activity, body composition, diet quality, smoking, hearing loss (which Tommy thinks of as lost cognitive demand), educational status

> “*My guess is that this is actually an underestimate because they didn’t include sleep, they didn’t include nutrient status, particularly homocysteine status, which other individuals have suggested has a population attributable risk of around 20% for late-onset Alzheimer’s disease*.”‒ Tommy Wood

- When you do a population attributable risk (or fraction), you say, “*If we remove this entirely, what proportion of that disease would disappear?*”
- There is a mounting body of evidence that says these risk factors interact, but a population attributable risk assumes a linear effect, that it’s additive, but in reality we know they are actually interactive

## Benefits of lowering homocysteine and boosting omega-3’s, and evidence-based supplements that support cognitive function [1:09:00]

**Can you say more about homocysteine?**

- In his practice, Peter manages [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) very aggressively
  - He targets 8-9 as the upper limit he wants to see even though the lab reference range says 13-14 is normal
  - He is very liberal with his use of methylated B vitamins to keep homocysteine down
- Peter’s concern is mostly cardiovascular because there is good evidence that homocysteine impairs clearance of two molecules (SDMA and [ADMA](https://en.wikipedia.org/wiki/Asymmetric_dimethylarginine) [symmetric and asymmetric dimethylarginine]) that impair [nitric oxide synthase](https://en.wikipedia.org/wiki/Nitric_oxide_synthase)
  - This has an important role in the cardiovascular endothelial world
- [Professor David Smith](https://www.pharm.ox.ac.uk/team/a-david-smith), a former chair and head of the Department of Pharmacology at the University of Oxford, has done a huge amount of work on homocysteine and cognitive decline
  - He is the chair of the scientific advisory board of a dementia [charity in the UK](https://foodforthebrain.org/scientific-advisory-board/) where Tommy is also on the advisory board
- David Smith has done a number of interventional studies looking at this, with the [VITACOG](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2935890/#pone.0012244.s005) study being the main one
  - They randomized individuals with elevated homocysteine to a B vitamin supplement [0.8 mg folic acid, 0.5 mg B12, & 20 mg B6 daily], and then looked at rate of cognitive decline and rate of brain atrophy
  - They showed that if you could reduce homocysteine, you can slow [cognitive decline](https://pubmed.ncbi.nlm.nih.gov/21780182/) and [brain atrophy](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0012244)
  - The greatest risk is with a homocysteine above 13
  - There’s also an elevated risk in those with a homocysteine above 11
    - The cutoff that Tommy uses for cognitive decline that’s based on hard evidence in the clinical literature is 11

**There are a number of potential reasons why decreasing homocysteine slows cognitive decline and brain atrophy**

1 – There may be a direct mechanistic effect related to the neuropathological hallmarks

- Homocysteine seems to activate [Cdk5](https://en.wikipedia.org/wiki/Cyclin-dependent_kinase_5), which phosphorylates [tau](https://en.wikipedia.org/wiki/Tau_protein) and then also inhibits [phosphatase 2A](https://en.wikipedia.org/wiki/Protein_phosphatase_2), which dephosphorylates tau
- So it may contribute to the accumulation of **tau tangles**, hyperphosphorylated tau in neurons

2 – More broadly, and where Tommy thinks the majority of the action is (excluding cardiovascular), is the importance of the methylation cycle in creating functional neuronal membranes

- #2 relates to evidence of how the level of homocysteine or B vitamin supplementation interacts with omega-3 status
  - We know that if you want to try and put particularly a molecule of DHA into a lipid membrane, you need to attach it or you need to create a [phospholipid](https://en.wikipedia.org/wiki/Phospholipid)
  - And that process of creating say [phosphatidylcholine](https://en.wikipedia.org/wiki/Phosphatidylcholine), which then attaches to your DHA so it can sit in your membrane, it’s very methyl intensive
    - It requires several methylation steps
  - The [VITACOG study](https://www.sciencedirect.com/science/article/pii/S0002916523277655?via%3Dihub) showed that the rate of brain atrophy was only slowed in those who had the highest tertile of [omega-3 status](https://en.wikipedia.org/wiki/Omega-3_fatty_acid)
  - The [B-proof study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9464144/) in the Netherlands also showed the benefit was greatest in those who had the highest levels of DHA
  - The [OmegAD study](https://pubmed.ncbi.nlm.nih.gov/30958356/) (supplemented with EPA and DHA) saw benefit in those who had the lowest levels of homocysteine

***All of these studies point to an interaction between B vitamin status and omega-3 status in terms of cognitive decline and brian atrophy, and the best way to think about it is that probably both are required in order for DHA to be inserted into a neuronal membrane in a functional way***

**Recommended supplements [1:12:45]**

**What dose of DHA are we talking about?**

- 1-2 grams of DHA a day
- Peter recaps, “*I want to make sure people understand what it is you’re saying here, which is if you lower your homocysteine from 13 or 14 to 9 or 10, all the while maybe taking some DHA… doing these two things together, which don’t require any medical care*”
- You can pretty much always get your homocysteine into that zone with the right amount of methylfolate, methyl B12, sometimes B6 is needed
- Couple that with high quality DHA
  - Peter likes Nordic Naturals and Carlson’s (he has no affiliation with either company)

**Would you say that that’s a 20% risk reduction in all-cause dementia just doing something like that?**

- Yes, for just the homocysteine, they’ve calculated population attributable risks and it’s more than that
- Another 20% has been attributed to poor omega-3

**Peter’s takeaway** ‒  “*This is kind of frustrating because I know that there are literally hundreds of thousands of people listening to us speak right now whose homocysteine is elevated, whose DHA is low, and they are unaware and their doctors are unaware of everything you just said. And there’s no drug (including a $30,000 a month drug) that is going to come close to that level of prevention.*”

**Why do you think there is such a disconnect in how we think about prevention?**

- Peter adds that they haven’t even talked about the obvious stuff: sleep, exercise, not having type 2 diabetes, controlling blood pressure, not smoking
- Homocysteine is not obvious, “*And yet a 20% risk reduction when you’re starting with an absolute risk, that’s as high as AD is, that’s like having a winning lottery ticket in your pocket and just not knowing it.*”
- Tommy can’t explain why this is not better understood
- When he’s talked to physicians about this, he’s had old-age psychiatrists respond, “*I’m immediately going to start measuring homocysteine and supplementing B vitamins plus or minus omega-3s.*”
- [David Smith](https://www.pharm.ox.ac.uk/team/a-david-smith) has gotten to the point where he’s incredibly frustrated

> “*This pretty significant body of randomized clinical trials showing these improved outcomes [from lowering homocysteine and supplementing with omega-3s]  has not been incorporated into prevention guidelines*”‒ Tommy Wood

- This body of randomized clinical trials has not been incorporated into things like the *Lancet* Commission report, which look at population attributable risk

**Tommy’s takeaway ‒** ***It’s cheap and easy to to measure homocysteine, measure an omega-3 index (or assess the DHA intake in your diet); I can’t say for certain, but I think there’s massive potential benefit here with high quality evidence to support it***

**Do you think there’s just a bias in the medical community against non-pharmacologic interventions?**

- Peter adds, “*There are few people that are going to stand here and be more critical of the supplement industry than I am. I really think it is a filthy industry, especially in the United States… the total lack of regulation, the complete predatory nature of it, and the total lack of quality control*”
- But that doesn’t mean every supplement is a bad idea
- Peter probably takes 9-10 supplements a day including: methylfolate, methyl B12, B6, EPA and DHA
- He has patients that show up in the practice and they have a list of 40 supplements
  - 37 of them are garbage, but 3 of them are worth it
- This might be an example where you tell your doctor, “*Look, I need to know what my homocysteine level is. I need to know what my EPA, DHA levels are. And I can fix this on my own*.”

**Supplement brands Peter likes (he has no affiliation with any of them)**

- Jarrow for methylfolate and methyl B12
- Pure Encapsulations B6

**Do you have any supplements that you’ve tested or found to be particularly trustworthy as far as manufacturers go?**

- Tommy likes Thorne because he knows they have a very stringent regulatory process and there’s multiple points in the process where they test for impurities or contaminants
  - If he’s working with a tested athlete, any supplement they take has to be [NSF](https://en.wikipedia.org/wiki/NSF_International) for sport certified so you know there’s no banned products in it
  - Pure Encapsulations is good
  - Momentous is good
- Part of the problem is the medical system you’re working in, and **guidelines around supplements are missing**
  - In the UK it’s nationalized healthcare and in the US it could be several different types of systems
  - In the UK you can prescribe things like vitamin D
  - There’s a big gray area where you then start recommending your patient go to the pharmacy to buy a supplement
  - There’s this indication that the [National Institute of Clinical Excellence (NICE)](https://en.wikipedia.org/wiki/National_Institute_for_Health_and_Care_Excellence) have said, “*This indication, you can prescribe it or it’s available*”
- Tommy works with a bunch of physicians who are interested in lifestyle medicine, but they’re very against supplements
  - They don’t do supplements, and anybody who does recommend supplement si sort of not allowed in the club

***This is hugely problematic because there is good evidence to say there is benefit in supplements***

- Part of the problem may be the regulatory system
  - Will you get in trouble if you start getting homocysteine tests on everybody
  - Homocysteine tests have to be processed quickly, and it’s a slightly more expensive blood test compared to others
  - There is some bias in terms of whether people think supplements are allowed or not

## A unifying theory of dementia [1:20:45]

- In Peter’s view, “*Alzheimer’s disease and dementia in general [are a] very, very complicated formidable opponent. Ideally, have as many things as possible in your quiver.*”
  - Wouldn’t you want everything on the table?
  - He never understood the rational that suggests you *only* want lifestyle, supplements, or drugs [use them all]
    - This mindset permeates into cardiovascular medicine, cancer, everything, and it created a bunch of silos of people who each probably have some truth and expertise but are equally limited by their blindspots

**What’s your unifying theory of homocysteine, low levels of omega-3/ marine-based fatty acids, glucose hypometabolism, low-grade ischemia, and microvascular disease?**

*Do you think it’s working through a final common pathway of neuronal damage which leaves the tombstone in its wake and the only thing they have in common is they leave the same tombstone?*

- Yes that summarizes Tommy’s current thought process
- He has been working with others, including David Smith, Josh Turknett, Jin-Tai Yu
- The big [meta-analysis](https://jnnp.bmj.com/content/91/11/1201.long) on modifiable risk factors for cognitive decline or late-onset Alzheimer’s disease done by Jin-Tai Yu was discussed earlier

- In Tommy’s current thought process, all of these things are necessary:
  - Healthy vascular supply
  - Metabolic substrates are available to neurons in the brain and you have the nutrients required to build a quality structure
  - You have the absence of things that may impair repair processes
- Some things are clear risk factors, like smoking
- To tie everything together, you require [cognitive] demand on the system that creates a stimulus for adaptation
  - The things listed earlier are required in order to respond to that stimulus
- You have a period of recovery and adaptation that allows for consolidation and plasticity
- Any individual may have an issue in one or more of those areas, but then what ties them together is the tombstone that they leave in their wake
- The exact way that that looks, the exact number of tombstones, how those tombstones look, or what else is going on is probably an expression of things like genetics and other factors
  - Which then explain some of that variability

***The tombstones may be the final common pathway, but everything that’s important is happening upstream of that***

## How muscular strength can help with both the prevention and survivability of dementia [1:24:15]

**Why do you think strength has such an important bearing on both the avoidance of dementia (from an incidence standpoint) and also survivability?**

- One of the strongest associations Peter has ever seen with mitigating risk is strength
- But he doesn’t think that the strength of your grip and the ability to open a jar is particularly important
- Just to give people some numbers, when you compare the top 10% or so of people from a strength perspective to the bottom 10%, it’s about a 70% reduction in both incidence and mortality associated with all-cause dementia
- Strength is one of the things that we have control over that rises to the top of modifiable factors that influence dementia risk
- Peter asks, “*What do you think from a physiologic standpoint explains such a stark relationship?*”
- In Tommy’s experience of talking about muscle mass and muscle strength with hard outcomes (dementia or all-cause mortality), usually the response is, “*All right. Calm down, bro. Clearly, you like to lift weights, and therefore you think that that’s the answer to everything. And people who are healthier are stronger and that’s just the confounding factor.*”
  - But there is good evidence this is *not* the case
- You can take individuals in their 70s, and put them on a very basic resistance training program, and you can see improvements both in white matter connectivity
  - You can do an MRI scan or you can test them on various tests of cognitive function and you see improvements as a result of this training program

***The simplest reason why is that some kind of novel movement is a direct neuromuscular stimulus***

- You are stimulating the brain to create new connections, driving plasticity because the recruiting of motor fibers, that motor skill is in itself a **cognitive stimulus**
- But then we also know that the muscle that you have and the amount that you move it is an important **glucose sink**
  - We know that pre-diabetes and type 2 diabetes are significant risk factors for cognitive decline and dementia
  - So it may be you’re increasing glucose flux that helps regulate blood sugar
- There is this exploding area looking at [myokines](https://en.wikipedia.org/wiki/Myokine), produced by moving your muscles
  - Things released by muscle tissue that may support brain function: [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1), [VEGF](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor), [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor)
    - They may support neuronal function and may be survival factors to keep neurons around
- We know that exercise is also **anti-inflammatory**, through a hormetic process
  - Chronic inflammatory conditions can be associated with increased risk of dementia, and you are decreasing systemic inflammation through physical activity
- Tommy doesn’t know which of these is most important, if any
  - He’s not sure he really cares that much because he knows it’s a very important intervention
- Strength/ exercise has been documented to work and you can implement it at pretty much any stage

***One of the reasons why strength is so beneficial is because it has these multiple pleiotropic effects, and they’re probably at least additive (if not synergistic) as well as the healthier you are, the stronger you are***

- When Peter is met with resistance about the importance of strength and muscle mass he feels that even if they shorten your life, they would still be more than worth it in terms of improving the **quality of your life** (especially in that final decade)
- You realize that in that marginal decade of life, having poor movement, being in pain, having low strength limits your capacity for doing just about everything that people would find pleasure in
  - Whether it be playing with their kids, or simply going for a walk, or carrying out any basic activity of daily living at the extreme level

## Head injuries: comparing concussions against traumatic brain injuries (TBIs), mitigating the damage after an incident, and the long-term management of head injuries [1:29:15]

**Can you explain what a concussion is?**

- Peter had a friend who suffered a very significant head injury riding a bike about 10 years ago
  - A jogger didn’t notice him riding and bolted out between some parked cars
  - They hit head-to-head
  - The jogger got the worst of it because the cyclist was wearing a helmet, but they were both devastated
  - The cyclist was going 40 km/hour and sustained a concussion that was so bad that he wasn’t himself for about two years (he’s more or less himself now)
  - The jogger sustained multiple fractures to her head
- Tommy points out, “*The idea of what concussion is, is quite hotly debated, but in general, you would classify a concussion as a mild traumatic brain injury.*”
- With more severe traumatic brain injuries you might think of things like complete open skull fractures and direct penetrating trauma to the brain

***With a concussion, the skull remains intact, but there has been some transmission of force or a blast wave (if it’s a blast injury) that is transferred to the brain***

**In order to have symptoms of a concussion, you have some kind of disturbance of neuronal function**

- That can either be because of abrupt loss
  - There are some significant head impacts in particular where you can get shearing of axons, direct axonal injury of the neurons, and then that cell is essentially lost as you ripped it apart
- But even more milder impacts may cause disturbances that include a neuron firing when it shouldn’t
  - This can then create this pattern of activation that’s not expected or in an area of the brain where it wouldn’t normally occur in a way that it wouldn’t normally occur
  - And then this can then cause these downstream processes within cells that can cause mitochondrial damage, swelling
- You then might see the accumulation of certain pathological proteins
  - For example, tau (just like you see in Alzheimer’s dementia) is also a response to direct neuronal injury in a concussion
- Tommy works with a neurosurgeon whose definition of concussion is, “*Any impact or force to the brain that causes the disturbance of function of one neuron*”
  - Unfortunately, that’s not something that we can measure because you probably need multiple or large sections of the brain to have aberrant function for you to be able to actually detect it
  - But those are the various processes that are going on when you get a head impact
- Peter summarizes, “*So it could be as mild as a headache for a few days following a head trauma, or it could be (in the case of this friend of mine) for a couple of years they had a lot of photosensitivity. They had a lot of auditory sensitivity. They had difficulty processing things. They were much more irritable.*”

**How common are those types of more severe symptoms (than just a headache for a few days) after a hit to the head?**

- It’s quite difficult to say how common things are because millions of concussions happen every year in the US alone, most of which probably go unreported
- You only get a formal assessment when you see more significant symptoms, when you’re playing sport, or when it’s happened in front of a doctor
- The downstream effects are varied:
  - It can be around verbal effects, photosensitivity, noise sensitivity
  - Effects on memory, focus, reaction time
  - And it depends on how you’re measuring things
  - Probably some of it is exactly which area of the brain was impacted
  - And then there is a systemic response aspect as well
- You can only really do this in animal studies, but part of the disease process after a traumatic brain injury is a **systemic immune response** that seems to contribute to some of the symptoms
  - So how much of an inflammatory response do you get?
  - How much of a fever do you get?
  - That can then cause some issues throughout the brain as well

**What do we know about the short-term (and long-term) management of concussion, and what is the relationship between a concussion and a traumatic brain injury (TBI)?**

- Peter thinks there is probably a greater understanding of [TBI](https://en.wikipedia.org/wiki/Traumatic_brain_injury) occurring in the battlefield and in American football
- Tommy points out that there are various severities of both concussions and TBIs
- A concussion is sometimes also known as a **mild traumatic brain injury (MTBI)**, which is where most of our focus today will be on
  - Because the more severe brain injuries (if you do have skull fractures or penetrating head trauma or you have significant loss of consciousness) require intensive care, specialists, and neurosurgical treatment, and that’s probably beyond what most people here will be thinking about
- If instead you’re thinking about concussions on the sports field or blast related or subconcussive exposures (which might happen in sports or in the military), there is increasing evidence that says that damage from subconcussive impacts or blasts can accumulate and cause issues with cognitive function
  - An example would be sniper fire, you essentially have a mini explosion happening right next to your head several times a day if you’re in the range practicing
  - And there you call it **subconcussive** because each individual one doesn’t necessarily cause symptoms, nor would you be able to detect it, but the damage seems to accumulate over time
- Depending on how you define concussion, you may or may not get symptoms anyway

**If you have a significant head impact for example on the sports field, there are probably two aspects that are worth separating**

- 1 – The formal medical process and assessment that you should undergo
- 2 – Impact assessment ‒ in multiple sports now they have some baseline cognitive testing so that when you do get concussion, they retest you and make sure you get closer to your previous baseline before you’re allowed to play again

**Tommy is particularly interested in how we can mitigate the effect of an impact initially**

- Are there supplementation and other strategies that we can do to make somebody more resilient to that impact?
- Are there other things that we can do to support recovery or minimize the effect of the impact?
- With **short-term post-concussion management**, there are two or three things that are particularly important
- 1 – Thermoregulation, which is basically managing normal body temperature
  - Tommy’s PhD looked at the effects of temperature on response to brain injury, and it’s very clear that the hotter your brain gets after an injury, the worse your outcome
  - This is true for any type of brain injury: stroke, TBI, neonatal and pediatric brain injuries that Tommy studies
  - A lot of sports happen in heat-stressed environments
  - Experimentally, if you head up the brain first (which happens during exercise) and then you have an impact and the brain stay hot, that seems to worsen outcomes

***Getting somebody out of a heat-stressed environment, cooling them down, using things like Tylenol to help regulate body temperature is important because a few hours later, an inflammatory response is going to kick in, and it’s very common to get a fever***

**How long does that power (or potential) of that intervention last?**

*If a person has a concussion at 2:00 on Sunday afternoon, should they take Tylenol and cool themselves off for the rest of the day? For a couple of days?*

- That’s a great question, and it’s something that the field probably still struggles with

***A period of 24-72 hours after the initial injury is probably the most critical, and the most important thing is preventing fever***

- Fever causes issues because you increase the mismatch between metabolic rate and capacity to produce energy to match that metabolism
- If you have mitochondrial dysfunction, you’re basically increasing that gap in terms of required energy production, and that exacerbates the injury

**Can cooling be beneficial for TBI? [1:38:45]**

*Is there any evidence for cooling? Is there any evidence that someone sustaining a concussion should go beyond just getting out of the sun and taking Tylenol, but perhaps be laying down, or at least have their head covered in ice?*

- Peter knows that when you’re doing certain types of heart surgery, you can cool the patient to 19-degrees Celsius (that was the “sweet spot” back when he was training) and that is very protective

***The short answer is no, there is no evidence for that***

- The long answer dives into animal models, and this is something Tommy has published extensively on
  - Hypothermia is magic for acute brain injuries
  - If you can decrease core temperature by 3-4-degrees C for 24-72 hours after the injury, you get a significant reduction in brain injury
- In one specific scenario, cooling to 33.5-degrees C core temperature for three days was brought into the resuscitation guidelines in 2010
  - For babies that have some kind of issue around birth
  - They are cooled externally, not using [ECMO](https://en.wikipedia.org/wiki/Extracorporeal_membrane_oxygenation) or anything like that
    - Some of these kids can go on ECMO, but that’s because of respiratory failure

***In an animal model, huge bodies of work say if you create a TBI and then cool the animal down, they get decreased injury, but dozens of trials (billions of dollars) have tried to replicate this in humans, and it has not worked***

- People thought that the temperature or duration wasn’t right
- In TBI, this is a very heterogeneous population; so maybe the population wasn’t right

***In reality, there is no evidence that hypothermia works for concussions or any kind of TBI, but what does seem to work is maintaining normo-thermia (a core temperature at or below 36.5-degrees C)***

- Some people sell cool caps and things, but there is no high-quality evidence that these things work
  - Particularly, because you’re externally cooling the brain, you’re probably not going to get the brain cold enough to do it
  - What you need to do is cool the blood going up to the brain, but there’s not much evidence there

***Focusing on preventing and managing fever is very beneficial, and active cooling below that doesn’t seem to add anything***

- Peter recalls studies where they cooled the neck and achieved a significant reduction in brain temperature
- Tommy adds that these external devices haven’t been shown to be beneficial when they’ve trialed hypothermia for TBI
- This is another issue with milder external forms of cooling, how do you know the brain is actually being cooled?
  - If they’re cooling the scalp, they will measure scalp temperature and reason that if the scalp is colder the brain is colder, but that is not necessarily the case
  - There is no documented evidence that these things can directly significantly cool brain temperature
- Peter sees two problems: (1) we don’t know if we’re cooling the brain in these studies and (2) we don’t know if cooling the brain would minimize/ mitigate risk
- It could be the complexity of the human model
- For infants, they have a surface area that allows for easy external cooling
  - In fact, that’s one of the challenges of taking care of pediatric patients, they are very susceptible to insensible losses in the way that adults are not

**What is your explanation for the discordance between that and the pediatric and animal literature?**

- Two questions remain
- 1 – The majority of cooling studies are probably not cooling soon enough
  - Based on animal studies, there is a very narrow window after an acute brain injury when you need to start cooling therapy
    - Within 6 hours, but probably within 3 hours is ideal
- If you are running a clinical trial, it’s almost impossible to start cooling therapy within 3 hours (or 6 hours)
  - It’s the same as doing [thrombolysis](https://en.wikipedia.org/wiki/Thrombolysis) in stroke
  - Trying to get it as soon as possible is very difficult
- There are a couple issues here, and the ability to start cooling therapy immediately maybe part of the issue
- The original cooling trials in the neonatal literature warmed the control group and kept them at 37-degrees C
  - The control group was hot
  - If you look at a baby’s normal temperature after they’re born, they don’t immediately go to 37-degrees C
    - They may never get there
    - They’ll slowly warm up over a day or so
  - But in those trials, the control group was immediately warmed up to 37, and they also frequently had fever and they weren’t managing those fevers
    - Because that was the era when you worried about kids getting cold
    - This may have made the controls worse off
  - In more modern cooling trials, the control group is kept at 36.5-degrees C (core temperature)
    - And compared to that, the cooling group doesn’t seem to have a benefit

***Some of the effect in neonates may be due to a worsening outcome in the control group, rather than benefit in the intervention group***

## Is hyperbaric oxygen treatment helpful after a TBI? [1:45:45]

- Patient’s ask Peter all the time about hyperbaric oxygen use in the chronic phase
  - He is ambivalent about this, and general thinks the hyperbaric oxygen industry is a racket
  - There are definitely indications for it; it matters for wound healing
  - It might be reasonable to consider hyperbaric oxygen for brain injury, but  he hasn’t found any compelling data

**Can hyperbaric oxygen treatment be helpful after a brain injury?**

- The phase of injury is critically important
- In the **acute phase of injury**, there is evidence that hyperbaric oxygen can be **detrimental**
- There are some studies where they’ve tried to get hyperbaric oxygen in as early as possible after TBI, and they’ve had an increase in negative side effects (unpublished work)

**Presumably hyperbaric oxygen treatment creates more reactive oxygen species in a hyper-inflammatory environment?**

- Exactly, “*You’re essentially driving oxidative stress*”
- Tommy doesn’t think there is any evidence to support hyperbaric oxygen use during the acute phase of injury, “*That is not something that I would recommend*”

**Possible benefits of hyperbaric oxygen therapy in the chronic phase of injury**

- Longer term, in the chronic phase, there is a possibility of benefit
- There are some data out there to suggest that those after concussion traumatic brain injury, they may see improvement after exposure to multiple rounds of hyperbaric oxygen
- Criticisms of the literature:
  - 1 – Most of these trials are single-arm, uncontrolled studies
  - It’s actually quite hard to create a control group in hyperbaric oxygen studies because you can tell when the chamber is being pressurized; so to create a scenario where you have a sham effect that may create the same placebo is quite tricky
  - 2 – All the people in the study improved
  - Tommy read a study where they did six months of hyperbaric oxygen twice a week and everyone improved
    - “*In my mind, you’re just invoking Voltaire who said that medicine is the art of entertaining the patient while nature cures the disease. That brain was going to get better anyway.*”
- There are some early data that suggests that improved cognitive function
  - Maybe you’re restoring metabolic function within the brain, mitochondrial function
  - At least 30-plus exposures to hyperbaric oxygen seems to be required
    - It takes several months
    - Again, this is sort of anecdotal/ pilot data
    - This is not large, randomized control trials or anything like that

***Tommy thinks there is potential benefit***

**How long after the injury should hyperbaric oxygen treatment begin?**

- A couple of weeks
- Wait until the full initial phase of the injury has resolved

***Two 60-minutes sessions, twice a week, at two atmospheres, potentially for several months***

- Peter replies, “*Well, it’s certainly long enough for Voltaire to take over, so it’s very difficult to know.*”

## Supplements that aid recovery from a TBI: creatine, DHA, and choline [1:49:30]

**Is there any benefit to adding supplements such as creatine monohydrate, and the marine omega-3 fatty acids (DHA and EPA)?**

- Peter has talked previously about using 5 g of creatine monohydrate daily [[see episode #46](https://peterattiamd.com/chrismasterjohn/)]
  - There are lots of benefits associated with creatine monohydrate, both cognitively and physically
- 2-4 g EPA DHA has benefit
- Tommy points out, “*One of the problems with TBIs, it’s difficult to predict, therefore it’s hard to do good quality prophylactic studies*”
  - There are no good studies that gives a bunch of people creatine before they get a TBI
- But in animal models, you can see that if you supplement with creatine for several days before a TBI is significantly neuroprotective
  - In both rats and mice
  - Supplement maybe 5-7 days with a loading-type dose, so the equivalent of 0.2 grams per kilo, which would 20 grams per day for a week
  - This dose has been shown to significantly increase brain creatine levels by doing something like [magnetic resonance spectroscopy](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy)
    - You can point an MRI scanner at the brain, and you can see the levels of creatine in it
- [Studies](https://pubmed.ncbi.nlm.nih.gov/35414265/) of high school football athletes have looked at that same measure over a football season and seen a decrease in brain creatine in the dorsolateral prefrontal cortex and the primary motor cortex related to the number of impacts that the kid gets
  - This suggests that endogenous levels of [creatine](https://en.wikipedia.org/wiki/Creatine) are being used up by impact, and provides  a short-term pH and energy buffer that may be protective when there’s impact

**How TBI affects creatine levels in the brain**

- We know that with standard dosing of creatine, we can increase the brain creatine levels
- We also know that with impacts, brain creatine seems to decrease
- One of the thought processes behind something called **second impact syndrome** is that you have a concussion, you recover and seem to be doing okay, but the next concussion has an out-sized effect

*We saw an awful example of this in the NFL this year, with the Dolphin’s quarterback, right?*

- One of the things people think might be happening is that you’ve depleted brain creatine with the first impact, and then there is a greater effect of the second impact
- There are probably multiple things that happen
- Brain [choline](https://en.wikipedia.org/wiki/Choline#Choline_as_a_nutrient) also seems to decrease in a similar manner

***There’s a case to be made for prophylactic creatine in those who are at high risk; Tommy suggests a loading period of 20 grams for a week to can increase brain creatine***

**More about creatine supplementation**

- Several studies suggest creatine may improve some of the problems that happen **after a concussion**
- Creatine can offset some of the cognitive deficits caused by sleep deprivation
- In multiple studies, creatine supplementation improves cognitive function [[reviewed in 2021]](https://www.mdpi.com/2072-6643/13/2/586)
  - The greatest effect seems to be in those who are oldest
  - But if you have some deficit in cognitive function (which may be related to creatine if it’s through a concussion), then supplementation may be beneficial
- There is some evidence that it may help with mood
  - Creatine has been tested in two randomized controlled trials where they’ve added it on top of SSRIs and those who responded poorly to SSRIs and saw improvements in depressive symptoms [studies listed in selected links section]

**Peter’s takeaway** ‒

- Presumably, just being on 5 g of creatine daily for long enough will get you to what the 20 g loading dose will do
- Because you can’t predict when you’re going to have a TBI, and you can’t always be taking 20 g and waiting

**EPA and DHA**

- Tommy thinks [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) is probably the more important omega-3 fatty acid, and it’s very similar to some of the processes we thought about with cognitive decline around neuronal structure and normal neuronal function
- There was a nice [study](https://pubmed.ncbi.nlm.nih.gov/26765633/) looking at supplementing with different levels of DHA throughout a high school football season
  - They supplemented with either 2, 4, or 6 g of DHA
  - There was no greater benefit with a higher dose with a higher dose
  - They saw a decrease in player-related circulating [neurofilament light](https://en.wikipedia.org/wiki/Neurofilament_light_polypeptide) (which is a blood biomarker of neuronal injury that you can pick up when you get a concussion)
  - Across the season, neurofilament light tended to increase in the athletes, but that was mitigated in the DHA supplementation groups

**Are there any other supplements that you think should be a part of the toolkit for basically anybody?**

- The reality is, we are all at risk of a TBI
  - You could get into a car accident
  - You could be walking down the sidewalk and someone bumps you while they’re on an electric scooter
  - Different sports and different stages of live will have a higher versus lower risk of TBI

*If there is a low-risk way to mitigate it, we should all be doing it, given that none of us know when we’re going to have an accident*

- DHA and creatine were already discussed
- Assuming you are in good metabolic health (we know blood sugar regulation is important) and your homocysteine isn’t 15
- The final thing on this list is [CDP-choline](https://en.wikipedia.org/wiki/Citicoline) (also called citicoline)
  - If you eat a couple of eggs a day (on average), you’re probably getting enough

***Tommy recommends taking 1-2 g of CDP-choline per day post-impact***

- Evidence suggests there is some improvement in neuropsychological outcomes in survivors of TBI who supplement with choline
  - Evidence does *not* suggest that choline helps with very severe traumatic brain injuries

***Three supplements worth considering are DHA (2 g/day), creatine (5 g/day), and CDP-choline (1-2 g/day)***

## Demands faced by F1 drivers, and testing interventions to improve their performance [1:57:30]

- Tommy gets to spend a lot of time on the inside of F1

**What’s something that you think would surprise the casual observer about the sport, and maybe something about the demands of the driver?**

- The thing that surprised Tommy the most is, “*How much attention is paid to the health and performance of the driver relative to the health and performance of the car.*”
- Historically in F1, the car was everything
- Now, because of the amount of travel and media commitments, drivers probably spend half of their time with media commitments, rather than working on the car, with engineers, or in the simulator
- It’s highly variable from driver to driver how much time they spend with their coach in the gym
- Tommy works with F1 drivers, and you have to be really certain that the thing you’re asking the driver to do is going to be beneficial
  - With other high-level endurance athletes, if he gives them a list of 100 things to do to improve their performance, they’ll do it, no questions asked
    - They’re usually “type-A”
  - Even if you don’t have 100 randomized controlled trials, you’re working with this idea of positive asymmetry
    - Very little risk and very high potential benefit

***It really forces you to focus on what’s going to be the most impactful thing that actually going to make it into the driver’s processes***

- F1 drivers have 23 races a year
  - In every race the car has to be a little bit different
  - Every circuit is different
- A street circuit like Monaco has pretty much nothing in common with a big track circuit like Manza
- A circuit that has lots of high-speed corners without many low speed corners is totally different than the reverse
- Circuits with long straightaways where you want very low drag are very different from circuits that are short and fast
- Each of those changes everything about the dynamics of the car
  - How temperature gets into the tires, stays in the tires, degrades, track surface
- The minute they finish that race on Sunday, they’ve got two weeks, sometimes one week, to completely change the car to optimize it for what they think it’s going to do and behave the next week
- The jet lag demands on the driver are insane#2
  - It’s hard to fathom how much they are crisscrossing the globe

**Without naming any names, what intervention or advice that you’ve given a driver are you most proud of in terms of the impact it’s had on his performance?**

- Something Tommy thought was really impactful recently, was helping a driver who is focused on time off the starting line
  - In general, Tommy is not directly interacting with the driver
  - The driver has a coach
  - A lot of the interactions involve Tommy and the coach tinkering with things
- There are different ways to get the driver ready to react and have an optimal reaction speed off the line, but then you also want to balance that against how they might react later in the race
  - This relates to the arousal curve discussed earlier
- They tried various supplements, time; things around the timing and dose
  - Tyrosine
  - Creatine
- There are other skills that translate across fields, such as playing the drums
  - You have to be relaxed, but timing is critical
- The driver improved, but Tommy can’t say that anything he did made the difference
- It was a nice process of scientifically tinkering with things to get to the goal

§

## Selected Links / Related Material

**Coaching company where Tommy worked with Formula One drivers**: [Hintsa Performance](https://www.hintsa.com/company/) | [5:00]

**Previous episode of** ***The Drive*** **with Luke Bennett**: [#95 – Luke Bennett, M.D.: The emotional, cognitive, and physical demands that make Formula 1 a unique and special sport](https://peterattiamd.com/lukebennett/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 2, 2020) | [5:00]

**British Society of Lifestyle Medicine**: [About BSLM](https://bslm.org.uk/about/about-us/) | [5:30]

**Previous episode of** ***The Drive*** **with Arthur Brooks**: [#226 ‒ The science of happiness | Arthur Brooks, Ph.D.](https://peterattiamd.com/arthurbrooks/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 10, 2022) | [11:45]

**Meta-analysis of modifiable factors for cognitive decline**: [Evidence-based prevention of Alzheimer’s disease: systematic review and meta-analysis of 243 observational prospective studies and 153 randomised controlled trials](https://jnnp.bmj.com/content/91/11/1201.long) | *Journal of Neurology, Neurosurgery, and Psychiatry* (Jin-Tai Yu et al. 2020) | [44:45]

**Previous episode of** ***The Drive*** **discussing cognitive demand for preventing decline**: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 17, 2023) | [45:30]

**Brain training online**: [BrainHQ: Braining training that works](https://www.brainhq.com/?v4=true&fr=y) | [46:45]

**BrainHQ**: [Testing a Novel Web-Based Neurocognitive Battery in the General Community: Validation and Usability Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8138705/) | *Journal of Medical Internet Research* (R Capizzi et al. 2021) | [46:45]

**Cognitive benefits of video games**: [Enriching hippocampal memory function in older adults through video games](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7286064/) | Behavioral Brain Research (G Clemenson et al. 2020) | [47:45]

**Dancing has greater cognitive benefits than aerobic exercise**: [Dancing or Fitness Sport? The Effects of Two Training Programs on Hippocampal Plasticity and Balance Abilities in Healthy Seniors](https://www.frontiersin.org/articles/10.3389/fnhum.2017.00305/full) | *Frontiers in Human  Neuroscience* (K Rehfeld et al. 2017) | [48:15]

**Cognitive benefits of dance, RCT**: [Effect of 3-Month Aerobic Dance on Hippocampal Volume and Cognition in Elderly People With Amnestic Mild Cognitive Impairment: A Randomized Controlled Trial](https://www.frontiersin.org/articles/10.3389/fnagi.2022.771413/full) | *Frontiers in Aging Neuroscience* (Y Zhu et al. 2022) | [48:15]

**Alzheimer’s disease content on the website and previous episodes of** ***The Drive***: [Cognitive Health & Neurodegenerative Disease](https://peterattiamd.com/category/diseases/neurodegenerative-disease-prevention/) | PeterAttiaMD.com | [49:45]

**PSEN1 mutation in initial case of Alzheimer’s disease**: [A presenilin 1 mutation in the first case of Alzheimer’s disease](https://www.thelancet.com/journals/laneur/article/PIIS1474-4422%2812%2970307-1/fulltext) | The Lancet Neurology (U Muller, P Winter, & M Graeber 2013) | [52:45]

**Animal models studying accumulation of amyloid plaques**: [Disease-directed engineering for physiology-driven treatment interventions in neurological disorders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6811362/) (Part IV. B.) | *APL Bioengineering* (T Wood & E Nance 2019) | [59:30]

**Amyloid accumulates in neurons with failing lysosomes**: [Faulty autolysosome acidification in Alzheimer’s disease mouse models induces autophagic build-up of Aβ in neurons, yielding senile plaques](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9174056/) | *Nature Neuroscience* (J Lee et al. 2022) | [1:02:15]

**Demand model of dementia, review**: [Demand Coupling Drives Neurodegeneration: A Model of Age-Related Cognitive Decline and Dementia](https://www.mdpi.com/2073-4409/11/18/2789) | *Cells* (J Turknett and T Wood 2022) | [1:06:15]

***Lancet*** **commission report on dementia prevention**: [Dementia prevention, intervention, and care: 2020 report of the Lancet Commission](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7392084/) | *Lancet* (G Livingston et al. 2020) | [1:07:30]

**VITACOG study, treatment with B vitamins slows homocysteine and slows brain atrophy and cognitive decline**:

- [Homocysteine-Lowering by B Vitamins Slows the Rate of Accelerated Brain Atrophy in Mild Cognitive Impairment: A Randomized Controlled Trial](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0012244#s4) | *PLOS ONE* (AD Smith et al. 2010) | [1:10:15]
- [Cognitive and clinical outcomes of homocysteine-lowering B-vitamin treatment in mild cognitive impairment: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/21780182/) | *International Journal of Geriatric Psychiatry* (C Jager et al. 2012) | [1:10:15]
- [Omega-3 Fatty Acid Status Enhances the Prevention of Cognitive Decline by B Vitamins in Mild Cognitive Impairment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4927899/) | *Journal of Alzheimer’s Disease* (A Oulhaj et al 2016)

**VITACOG study, those with high levels of omega-3 benefited most**: [Brain atrophy in cognitively impaired elderly: the importance of long-chain ω-3 fatty acids and B vitamin status in a randomized controlled trial](https://www.sciencedirect.com/science/article/pii/S0002916523277655?via%3Dihub) | *The American Journal of Clinical Nutrition* (J Fredrik et al. 2015) | [1:12:15]

**B-proof trial, high levels of DHA maximize benefits of vitamin B supplementation**: [DHA status influences effects of B-vitamin supplementation on cognitive ageing: a post-hoc analysis of the B-proof trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9464144/) | *European Journal of Nutrition* (A van Soest et al. 2022) | [1:12:15]

**OmegAD study, benefits of omega-3 influenced by homocysteine**: [Homocysteine Status Modifies the Treatment Effect of Omega-3 Fatty Acids on Cognition in a Randomized Clinical Trial in Mild to Moderate Alzheimer’s Disease: The OmegAD Study](https://pubmed.ncbi.nlm.nih.gov/30958356/) | *Journal of Alzheimer’s Disease* (F Jerneren et al. 2019) | [1:12:30]

**Creatine discussion on** ***The Drive***: [#46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more](https://peterattiamd.com/chrismasterjohn/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 25, 2019) | [1:50:00]

**MRI of high school football athletes**: [American Football Position-Specific Neurometabolic Changes in High School Athletes: A Magnetic Resonance Spectroscopic Study](https://pubmed.ncbi.nlm.nih.gov/35414265/) | *Journal of Neurotrauma* (N Vike et al. 2022) | [1:51:15]

**Creatine supplementation**: [Creatine Supplementation and Brain Health](https://www.mdpi.com/2072-6643/13/2/586) | *Nutrients* (H Roschel et al. 2021) | [1:53:15]

**Creatine supplementation as an adjunct therapy for depression**:

- [Cognitive effects of creatine monohydrate adjunctive therapy in patients with bipolar depression: Results from a randomized, double-blind, placebo-controlled trial](https://pubmed.ncbi.nlm.nih.gov/27890303/) | *Journal of Affective Disorders* (R Toniolo et al. 2017) | [1:53:45]
- [A randomized, double-blind, placebo-controlled, proof-of-concept trial of creatine monohydrate as adjunctive treatment for bipolar depression](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5775367/) | *Journal of Neural Transmission* (R Toniolo et al. 2018) | [1:53:45]

**DHA supplementation in football players**: [Effect of Docosahexaenoic Acid on a Biomarker of Head Trauma in American Football](https://pubmed.ncbi.nlm.nih.gov/26765633/) | *Medicine and Science in Sports and Exercise* (J Oliver et al. 2016) | [1:54:30]

§

## People Mentioned

- [Luke Bennett](https://ch.linkedin.com/in/luke-bennett-5880878a) (M.D., Managing Director of Sports Business for Hintsa Performance) [5:00]
- [Arthur Brooks](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) (Author and Professor of Public Leadership and Management Practice at Harvard) [11:45]
- [James Hewitt](https://jameshewitt.net/about/) (Performance Scientist, researcher at Loughborough University, entrepreneur) [30:45]
- [Jin-Tai Yu](https://research.com/u/jin-tai-yu) (Professor at Fudan University – State Key Laboratory of Medical Neurobiology and MOE Frontiers Center for Brain Science) [44:45, 1:22:30]
- [Ralph Nixon](https://med.nyu.edu/faculty/ralph-a-nixon) (Professor of Psychiatry and Cell Biology at NYU Grossman School of Medicine) [1:02:15]
- [Josh Turknett](https://www.turknett.com/team/josh-turknett-md/) (Neurologist, entrepreneur, co-founder of Turknett Leadership Group) [1:06:15, 1:22:30]
- [David Smith](https://www.pharm.ox.ac.uk/team/a-david-smith) (Professor Emeritus of Pharmacology at Oxford) [1:09:45, 1:15:30, 1:22:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/06/bio-tommywood.png)

##### Tommy Wood, M.D., Ph.D.

Thomas Ragnar Wood earned his Bachelor degree in biochemistry from Cambridge and Medical degree from Oxford. He worked as a junior doctor in London for two years before completing a Ph.D. in Physiology and Neuroscience from the University of Oslo.

Dr. Wood is a Research Assistant Professor of Pediatrics at the [University of Washington](https://www.peds.uw.edu/user/1778) where he is the Director of Preclinical Research for the Division of Neonatology. Dr. Wood’s research focuses on animal models of premature brain injury and neonatal hypoxic-ischemic encephalopathy with the goal of investigating factors that contribute to brain health, development, and resilience across the lifespan.

Dr. Wood serves as Associate Editor of the Wiley Journal *Lifestyle Medicine.* He is a past President-elect of Physicians for Ancestral Health. He served as a founding director of the British Society of Lifestyle Medicine, and is currently on the scientific advisory board of Hintsa Performance. Dr. Wood works with a number of digital health companies and charities that focus on how lifestyle and the environment can affect long-term health and chronic disease. Dr. Wood has competed in multiple sports including rowing, CrossFit, powerlifting, and ultra-endurance racing. He has also worked with professional athletes as a performance consultant. Alongside his career in medicine and research, Tommy has published and spoken on multiple topics surrounding functional and ancestral approaches to health, including examining the root causes of multiple sclerosis and insulin resistance. [[Physicians for Ancestral Health](https://ancestraldoctors.org/tommy-wood-md-phd-fellow/)]

Instagram: [@drtommywood](https://www.instagram.com/drtommywood/?hl=en)

Twitter: [@DrRagnar](https://twitter.com/drragnar?lang=en)

Podcast: [Better Brain Fitness](https://www.brainjo.academy/the-better-brain-fitness-podcast/)