# #115 – David Watkins, Ph.D.: A masterclass in immunology, monoclonal antibodies, and vaccine strategies for COVID-19

**Source:** [https://peterattiamd.com/davidwatkins/](https://peterattiamd.com/davidwatkins/)

---

In this episode, David Watkins, professor of pathology at George Washington University, shares how insights from his HIV and Zika virus research could apply to SARS-CoV-2 protection strategies. David introduces monoclonal antibodies as an intervention to prevent and treat COVID-19 infection, and also discusses how they could be used as a hedge to vaccine development. Additionally, David’s immunology tutorial explains the innate and adaptive immune systems and their differentiated responses to viral infection.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidwatkins/the_Drive_public.png)

Play

#115 - David Watkins, Ph.D.: A masterclass in immunology, monoclonal antibodies, and vaccine strategies for COVID-19

#115 - David Watkins, Ph.D.: A masterclass in immunology, monoclonal antibodies, and vaccine strategies for COVID-19

1x15s30s

0:001:37:32

## We discuss:

- Background and current interest in immunology [4:30];
- Immunology 101—The innate and adaptive immune system [10:15];
- Defining antibodies, importance of neutralizing antibodies, and serology testing for COVID-19 [19:00];
- B cells—How they fight viruses, create antibodies, and fit into the vaccine strategy [25:00];
- T cells—Role in the adaptive immune system and ability to kill infected cells to prevent viral spread [36:15];
- Valuable lessons from HIV applied to SARS-CoV-2 [51:00];
- Lessons to be taken from the hepatitis C success story [1:01:30];
- Monoclonal antibodies, vaccines, and the most promising strategy for preventing and treating COVID-19 infection [1:04:45];
- COVID-19 vaccines in development [1:19:00];
- How David’s work with Zika virus informs his thinking on SARS-CoV-2 [1:25:20];
- Why a vaccine for COVID-19 doesn’t need to be perfect to be effective [1:27:45]; and
- More.

§

## Show Notes

## Background and current interest in immunology [4:30]

- Born in Uganda, but grew up in the [West Indies](https://en.wikipedia.org/wiki/West_Indies) where he developed a keen interest in nature
- Undergraduate degree in botany and zoology
- Then went to the United States to study immunology (specifically evolution of the immune system)
- Considers himself an evolutionary biologist
- Went on to Boston and worked on the HIV epidemic
  - HIV most dramatic example of evolution that I certainly have ever seen, says David
  - Virus populations can change after infection in two weeks which means the infecting virus can be essentially removed and a new virus appears under pressure from the immune response
- He now studies many viruses that are tropical diseases

*What was the biggest change in the evolution of the immune system as you studied it?*

- The advent of the [adaptive immune response](https://en.wikipedia.org/wiki/Adaptive_immune_system)
- We also have [innate immune responses](https://en.wikipedia.org/wiki/Innate_immune_system) that are incredibly important
- But the evolution of [T cells](https://en.wikipedia.org/wiki/T_cell) and [B cells](https://en.wikipedia.org/wiki/B_cell) allowed the immune system to have greater memory to respond to pathogens
- And this is the basis for vaccination which has saved more human lives than any other public health measure

## Immunology 101—The innate and adaptive immune system [10:15]

**Innate vs. adaptive immune system**

- Using the example of a virus
  - A virus enters a cell
  - The virus can’t replicate by itself, and needs to get into that cell and replicate.
  - It starts replicating, produces copies of itself, which are sent out into the blood to infect other cells
  - That infection event triggers the **innate immune response**
  - There are sensors inside cells that will then trigger the production of [interferons](https://en.wikipedia.org/wiki/Interferon)
  - The interferons turn on both the innate and **adaptive immune system**
  - The adaptive immune system has two major arms
    - [T cells](https://en.wikipedia.org/wiki/T_cell)
    - [B cells](https://en.wikipedia.org/wiki/B_cell)

![](https://peterattiamd.com/wp-content/uploads/2020/06/figure-1-davidwatkins-1024x686.png)

**Figure 1. The innate and adaptive immune response.** Image credit: [creative-diagnostics.com](https://www.creative-diagnostics.com/innate-and-adaptive-immunity.htm)

*–****The adaptive immune system in action****—Let’s say a person ingests an influenza virus:*

- Pieces of the virus ([antigens](https://en.wikipedia.org/wiki/Antigen)) are being presented to the B cells
- And the B cells have [receptors](https://en.wikipedia.org/wiki/B-cell_receptor) (which become [antibodies](https://en.wikipedia.org/wiki/Antibody) to a virus) on their surface, and they recognize this antigen as “not self” and bind to the antigens **very weakly**
- This recognition then stimulates a B cell to divide
- Every time the B cell divides, **it makes an error** in copying this receptor on the cell surface
- And some of those errors make that antibody *less able to bind*, and that B cell will die
- But some make it *better able to bind* to the antigen (a piece of the virus)
- Eventually you arrive at an antibody that now **binds very tightly** to the antigen
- They then circulate in the bloodstream
- A year later, if you encounter the same virus, those antibodies are already pre-made and they will bind to that virus and stop it from infecting cells

**\*And that is the basis of how a vaccination works\***

- You present a virus to B cells so that it can make the necessary antibodies so that the person is protected when they encounter the live virus in the future

![](https://peterattiamd.com/wp-content/uploads/2020/06/figure-2.-adaptive-immune-system-davidwatkins-960x1024.png)

**Figure 2. Adaptive immune system.** Image credit: [chegg.com](https://www.chegg.com/homework-help/questions-and-answers/understanding-dual-nature-adaptive-immune-response-dual-nature-adaptive-immune-response-al-q37493016#question-transcript)

## Defining antibodies, importance of neutralizing antibodies, and serology testing for COVID-19 [19:00]

*When you get infected with a virus…*

- The first antibody that shows up is [Immunoglobulin M](https://en.wikipedia.org/wiki/Immunoglobulin_M) (IgM)
- But the IgM antibodies fade away after 2 or 3 months
- So if you get a [serology test](https://en.wikipedia.org/wiki/Serology#Serological_tests) and you see IgM then that means you recently had the virus
- After the IgM tails off, you will get [IgG antibodies](https://en.wikipedia.org/wiki/Immunoglobulin_G)
- These are the antibodies that will contain your **neutralizing** antibodies (ones that actually prevent an infection)
- (Although, IgM antibodies can also carry out neutralization)

**An experiment displaying the enormous variability from person to person** (Upcoming paper out of the [Rockefeller lab](https://www.rockefeller.edu/))

- 70 people who had coronavirus
- They looked for the presence of **neutralizing** antibodies
- Almost 20% of them **did not** make *neutralizing* antibodies
- In other words, 20% of people that had IgG/IgM antibodies did not actually have antibodies that could neutralize the virus when a special assay was done
- Furthermore, each person made a different volume ([titer](https://en.wikipedia.org/wiki/Antibody_titer)) of neutralizing antibodies (some made tons and others made little)
- It’s unclear how those 20% without neutralizing antibodies were able to survive the virus/or how they clinically responded to the virus
  - I.e., They could have had a lower inoculum of infection, or they might have been asymptomatic

*-David’s takeaway:*

- There’s enormous variability in the **B cell response** to coronavirus
- The B cell response is what creates antibodies
- The open questions are…
  - C*an those individuals that did NOT make a good neutralizing antibody response be reinfected*?
  - If so*, how soon after*?
  - And that ability to be infected… *does it correlate with neutralizing antibodies in the serum*?

## B cells—How they fight viruses, create antibodies, and fit into the vaccine strategy [25:00]

**Defining attenuated virus and vaccines**

⇒ Example—[17D yellow fever vaccine](https://en.wikipedia.org/wiki/Yellow_fever_vaccine)

- This is a very successful, [attenuated vaccine](https://en.wikipedia.org/wiki/Attenuated_vaccine)
- It was derived from somebody in Africa who had yellow fever, then put into monkeys, then in the laboratory for many rounds of tissue culture
- What emanated was a virus that was **weakened** (i.e., attenuated virus)
- This attenuated virus has many differences genetically from the original virus in Africa
- But when the attenuated vaccine is injected into a human…
  - The virus will replicate
  - The innate immune and adaptive immune system will respond
  - T cells and B cells will be generated
  - Antibodies will then be generated against the vaccine virus
- The **best vaccines are often using attenuated** (weakened) versions of the original virus
- Some **drawbacks** of attenuated viruses:
  - Some people’s immune responses can not handle the attenuated virus (usually older people)
  - 1 in 300,000, will get sick from the virus and some of them will die
- *⇒ Other examples of live attenuated viruses*: measles, mumps, and chicken pox

**When studying immune responses to the 17D yellow fever vaccine…**

- All the vaccinated individuals make “beautiful” neutralizing antibody responses against 17D yellow fever
- Even if you dilute their serum to 1 in 5,000, it will still stop the virus from infecting cells
- However, there’s a large range in the ability of the people that were vaccinated to respond to the *wild-type virus*
- For example, when they took the virus out of a dead monkey that died of yellow fever…
  - A few individuals didn’t make *any responses* against the wild-type primary islet because these viruses that come right out of a monkey, for example, are incredibly well adapted to replicating in the monkey and have not been adapted to replicate in tissue culture
  - And this **primary islet is incredibly important to test any vaccine against**

**Summary of how B cells work against a virus**:

- The B cells arrive pretty soon after that innate response takes place
- Next, they go through an evolutionary replicative cycle until they converge on the perfect antigen
- The antibodies eventually reach affinity matured—meaning they get better and better at binding to the piece of virus that they attach to
  - This occurs in the lymph nodes where the architecture is very important because you’ve got T cells that are absolutely necessary to help them develop in those lymph nodes
- Then they exit the lymph nodes about **7 to 14 days later**, and then they become either:
  - a) Memory B cells—which are very small B cells that circulate, or
  - b) Plasma cells—big cells in the bone marrow which essentially become the **factories of antibodies**
- If one of those **plasma cells** is making considerable amounts of neutralizing antibodies, *you will be protected from an infection with that virus that you’ve just seen for a long time*
- **\*Note\***: That will vary from virus to virus, but that’s essentially the ontogeny and evolution of the B cell response

**Implications when doing** [**serology testing**](https://en.wikipedia.org/wiki/Serology#Serological_tests) **for coronavirus**:

- Today, when someone is getting checked for antibodies for coronavirus…
- It’s quantifying the number of IgG or IgM
- But it doesn’t tell you if those antibodies on the region of the spike protein on the surface of the virus that is critical in binding to the receptor on the human cells for entry
  - \*In other words, *it’s not distinguishing whether or not* ***neutralizing antibodies*** *are present*
- We know that neutralizing antibodies are very important, but the value of those antibodies that are *not neutralizing* is unclear

## T cells—Role in the adaptive immune system and ability to kill infected cells to prevent viral spread [36:15]

**T cells are the other arm of the adaptive immune system**

⇒ A good example of the power of T cells is looking at the [CD8 T cell](https://en.wikipedia.org/wiki/Cytotoxic_T_cell)

- David made a discovery in the early days of HIV in the animal model of HIV infection called [simian immunodeficiency virus](https://en.wikipedia.org/wiki/Simian_immunodeficiency_virus) (SIV)
  - Note: SIV is a RNA virus and it’s notoriously error prone when it copies itself
- They infected monkeys with a simian immunodeficiency virus then looked at the virus two weeks later and they **couldn’t find the virus that they infected those monkeys with**
- There was a virus replicating in the blood, but it was a **new virus**
- What David discovered was that…
  - The T cell response had wiped out the initial infected virus
  - All that was left replicating in that animal now was a virus that had mutations in that area
- “*When you see dramatic effects like this, you understand the power of the* [*cytotoxic T-cell*](https://en.wikipedia.org/wiki/Cytotoxic_T_cell) *(CD 8/CTL)*”

**T cells and cancer**

- David says that antibodies which turn on T cells have been show to wipe out tumors in certain instances
- This is the “awesome power” of the CD8 T cells
- NEJM paper: [Release the Hounds! Activating the T-Cell Response to Cancer](https://www.researchgate.net/publication/269284795_Release_the_Hounds_Activating_the_T-Cell_Response_to_Cancer)

**Failed attempt to develop a T cell vaccine for HIV**

- David “fell in love” with T cells
- He spent 20 years trying to make a vaccine against HIV based on inducing T cell responses, but he “failed spectacularly” and was not able to make it work
- Recently, he discovered the power and the beauty of B cell responses and antibody evolution (explained earlier in the podcast)
- But the same way in which a B cell antibody evolves to become the perfect fit binding antibody…is the same way that the HIV virus had evolved in the face of this CD8 T cell onslaught
  - “*There’s two sides of the same coin.*”

**How killer T cells kill viruses**

- A T cell kills a virus with a completely different method than B cells
- Once a virus enters a cell, it will make thousands of copies of itself and released them into the blood
- An antibody (from a B cell) can stop the virus from getting into the cell (that’s proven difficult to do with HIV)
- But once that virus is in the cell, the antibody cannot do anything
- This is where a T cell comes into the picture

–*An infected cell is like a virus factory—and you need to shut that virus factory down*

- What we need is a cell that can recognize an infected cell and kill it before it releases all the progeny virus
- And it has to be able to recognize an infected from an uninfected cell
- And that is what a [CD8 T cell](https://en.wikipedia.org/wiki/Cytotoxic_T_cell) does in a very elegant way
- When the virus binds to the receptor and gets into the cell, it starts to make its own proteins in that cell
- Then we have these “buckets” called [major histocompatibility complex molecules](https://en.wikipedia.org/wiki/Major_histocompatibility_complex#:~:text=The%20major%20histocompatibility%20complex%20(MHC,for%20the%20adaptive%20immune%20system.&text=The%20presented%20self%2Dantigens%20prevent,system%20targeting%20its%20own%20cells.) (MHC)
- These buckets sample what’s on the inside of the cell, and they put it up on the surface of the cell
- And in the buckets on the cell’s surface are pieces of the virus in an infected cell
- So a killer T cell will come along and it will looks for non normal cells
- If it finds one, It binds to that and it blows holes in that infected cell to close the factory down
- So these MHC buckets are like “flags” on the surface of an infected cell that say, “kill me”
- A CD8 T cell plays a critically important role in almost any viral infection

Helper T cells

- You need both arms of the adaptive immune system,
  - i) antibodies and their ability to neutralize viruses before they infect cells, and
  - ii) killer T cells to shut down infected cells
- However, we can’t generate either of those without [helper T cells](https://en.wikipedia.org/wiki/T_helper_cell)
- Helper T cells (e.g., [CD4](https://en.wikipedia.org/wiki/CD4)) are important for providing a milieu for the development of the CD8 killer cells and for the B cells
- The most dramatic example of the importance of CD4 cells is HIV

Other examples of killer T cells at work…

- You can’t get a skin graft from someone else because T cells would recognize the skin as foreign because of the MHC molecules presenting the foreign cells on the surface
- T cells have a role in stopping cancer, i.e. cells that do not respond to normal cell cycle growth, and yet they will not go on to develop cancer anytime soon because the CD8 cell is able to recognize those cancer cells as non-self, which is the key determinant and to eradicate them
- With organ transplantation, we have to give patients who have been given a transplanted organ immune suppressing drugs which is really suppressing the arm of the immune system to prevent them from doing their job

## Valuable lessons from HIV applied to SARS-CoV-2 [51:00]

**Why there hasn’t been a successful HIV vaccine**:

- Most vaccines are based on immunizing an individual so that they develop neutralizing antibodies
- There are very few T cell-based vaccines
- For HIV, the first attempt was to make neutralizing antibodies by vaccination, but it’s very difficult to make a neutralizing antibody against HIV and [SIV](https://en.wikipedia.org/wiki/Simian_immunodeficiency_virus) (primate equivalent of HIV)

–*When someone is infected with HIV (or a monkey with SIV)….*

- Problem 1: **Huge population** of the virus with **enormous variability** in the virus
  - 10 to 100 million copies of virus per ML in those first few weeks
  - Almost all of them are different
    - So when you talk about HIV, you’re basically talking about lots of different HIV
  - The question for a vaccinologist: *How am I going to make a vaccine that I’m going to give to 100 people, but those 100 people are all going to be exposed to different viruses*?
- Problem 2: We’ve been unable to generate by vaccination a **neutralizing antibody** against HIV
  - For example, you can vaccinate monkeys for SIV and generate huge levels of antibodies that bind but **none of them seem to neutralize the virus**
    - And that’s due to the biology of the virus
      - There are very few copies of envelope on the surface of a HIV variant
      - That envelope is a protein, but it’s covered in a shield of sugars making it hard to get in and to bind to the regions of the envelope that are important for binding the CD4 and getting into the cell

**How we’ve stopped the HIV epidemic without a vaccine**:

- The advent of [highly active antiretroviral therapy](https://en.wikipedia.org/wiki/HIV/AIDS#Treatment) (HAART) in the mid-’90s
- Within a span of about two years, HIV went from uniformly fatal to a chronic disease where people can live with T-cell counts that would’ve rendered them dead within months in the past
- In other words, the HIV epidemic was stopped **without a vaccine**

> “As we stand here with the coronavirus epidemic three months old, I think we should have faith that science will find a solution to this.”

*What led up to that point…*

- [Ron Desrosiers](https://pathology.med.miami.edu/research/desrosiers-research-laboratory) of the New England Primate Center, [isolated a virus](https://pubmed.ncbi.nlm.nih.gov/3159089/) that looked very similar to HIV ([SIV](https://en.wikipedia.org/wiki/Simian_immunodeficiency_virus)) which became animal model that we are able to test therapies on
- Next came the behavioral method to slow the transmission,  using condoms
  - \*For coronavirus, that means social distancing
- Next came a repurposed drug called [AZT](https://en.wikipedia.org/wiki/Zidovudine)
- This brought virus loads down but they would come back up because the virus’s ability to escape
- Then [Ray Schinazi](https://en.wikipedia.org/wiki/Raymond_F._Schinazi) discovered that a combination drugs was an effective treatment and this was the “game changer”
- In parallel, David and others were working on vaccines and immune responses and found that the **virus could escape from just about any immune response thrown at it**
- Finally, the groundbreaking [PrEP studies](https://en.wikipedia.org/wiki/Pre-exposure_prophylaxis) (Pre-exposure prophylaxis) resulted in [TRUVADA](https://en.wikipedia.org/wiki/Emtricitabine/tenofovir) which prevents a sexually active person from getting infected with HIV
- We still have a large number of people already infected and they need to get on treatment, but in that example, **science found a solution to the epidemic**
- In short, the epidemic was solved **without a vaccine**

> “Many of us that worked in the HIV epidemic are now better able to deal with the coronavirus because we’ve learned a lot of valuable lessons from HIV.”

## Lessons to be taken from the hepatitis C success story [1:01:30]

**Hepatitis C**

- [Hepatitis C](https://en.wikipedia.org/wiki/Hepatitis_C) is a virus that replicates to enormous levels, even higher than HIV
- It similarly generates lots and lots of variants
- It’s a virus that’s going to be very, very difficult to find a vaccine for.
- [Ray Schinazi](https://en.wikipedia.org/wiki/Raymond_F._Schinazi), PhD biochemist, was involved in the discovery of these first drugs that not only treat Hep C, but they **cure Hep C**

**Peter’s view on this**:

- It’s quite possible there has been no greater advancement in medicine in the past 10 years than the drugs that cure Hep C
- Hep B, Hep C, and HIV are the “big 3” of bloodborne transmission viruses
- Hep C probably has the quickest consequences if you are untreated
- Hep B can be vaccinated against
- HIV, while there is no cure or vaccine, it was not as easy to transmit (e.g., A solid needle, going through a double glove is pretty low transmission)
- But Hep C was a very transmissible virus, and when Peter was in med school 20 years ago, there was no treatment and no vaccine
- If you got Hep C, you had a 40-50% chance of dying of liver failure
- But today, there’s a 30 to 60-day course of a medication which cures the person with Hep C
- In other words, still no vaccine, but there is a cure for Hep C

## Monoclonal antibodies, vaccines, and the most promising strategy for preventing and treating COVID-19 infection [1:04:45]

**COVID-19 in context**

- David believes we will have a much better ability to create a vaccine for COVID-19 compared to HIV or even the [1918 flu](https://en.wikipedia.org/wiki/Spanish_flu)
- How much worse is this than the common flu?
  - Peter’s take is that it’s nowhere near the original thought of being 25x worse
  - Peter thinks when you look at the IFR, and especially if you age stratify, it’s probably 2-8x “worse” than the flu
  - David thinks it’s probably closer to 10x worse
  - And he points out there’s still much we don’t know
    - E.g., *What about the amount of virus that you see initially?*

**Promising observations about coronavirus**

- Coronavirus has much, much less ability to “escape” compared to HIV
- Also, it’s not a chronic virus meaning it’s possible to generate an antibody response

**Unknowns about antibodies**

- It’s unclear the exact titer of neutralizing antibodies needed
- In terms of the ability to generate neutralizing antibodies, we don’t yet know…
  - What percentage of antibodies are neutralizing
    - “*The key experiments are putting these vaccine concepts into humans and looking at their neutralizing antibody response. But we don’t know what levels of neutralizing antibody responses will be sufficient to prevent infection. And I think that’s a very important issue.*”
  - We don’t know the frequency of people who would be able to develop them
  - We don’t know the duration that they will last in terms of protection from reinfection
    - “*Duration is a key issue with respect to infected people and with respect to vaccines because you’ve got to make a neutralizing response and then you’ve got to keep that neutralizing response up to a level where it will prevent infection.*”

**Monoclonal antibodies for preventing COVID-19 infection**

> “The most exciting hope that we have for treating [coronavirus] is **neutralizing antibodies delivered as** **monoclonal antibodies****.”**

⇒ Explaining how using [monoclonal antibodies](https://en.wikipedia.org/wiki/Monoclonal_antibody) could prevent COVID-19

- In the case of an attenuated yellow fever vaccine, if you vaccinated 100 people…
  - ~90% of them **will make** a response against the *vaccine virus*
  - ~20% of them **won’t make** a response against the *wild type virus* (the live virus that circulated) so they’re going to be susceptible to infection
- But you’re going to have a few individuals that are going to make **wonderful antibody responses against the vaccine virus AND the wild type virus**
- You then go in and get the memory B cells of those people
- Then you clone the genes of those neutralizing antibodies that have reached affinity maturation and now bind very well to the piece of virus that prevents the virus from getting inside the cell
- Next, you test them in animal models
- Then I’m going to grow them up in large vats
- Finally, you inject these monoclonal antibodies into people, say at a nursing home in the case of COVID-19, “***and that is going to prevent infection***”
- *How long will that last?* ⇒ Probably **3 to 6 months** depending on the dose you give and how you genetically engineer that antibody
- “This is the most exciting aspect and the most hopeful treatment for coronavirus, and it’s a new type of vaccinology, if you will.”

> “I think the way forward for the vaccine field is to get those individuals that make the best antibody responses, clone their best antibodies, grow them up in vats, and then distribute that to the people that need it. And this can be used for prevention and it can be used for treatment.”

**A combo of vaccine plus monoclonal antibodies is the most promising strategy**

–*The goal of a vaccine, for the most part, is a B cell strategy*

- Which is put in some form of attenuated/inactivated virus that elicits an immune response that is appropriate
- If we’re lucky, the B cell immune response generates specific antibodies called **neutralizing** antibodies.
- If we’re lucky, we get big effector B cells that turn into [plasma cells](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/plasma-cell) which hang out in bone marrow for when you see this infection again

–*In parallel, you can pursue the monoclonal antibody strategy:*

- First, figure out who the “Olympic champions of making neutralizing antibodies” are
- Then, using recombinant engineering/recombinant DNA technology, you make synthetic copies
- Next, you inject the neutralizing antibodies into people so that even if their own B cells aren’t able to make neutralizing antibodies, they will have them to fight off the virus
- **The main issue**: They only last maybe 3 to 6 months so they will need to be injected at some regular frequency, say two to four times per year

*-David’s response*:

- Let’s not forget that **a cheap vaccine is really the best way to go** with all of this
- And David thinks one of the vaccine approaches will result in durable neutralizing antibodies
- A vaccination would increase herd immunity in the younger people by vaccination and therefore reduce the number of transmission events to the elderly
- HOWEVER, the elderly don’t do so well with vaccines b/c they don’t make such robust immune responses
- So, injecting them with a **combination of monoclonal antibodies** would be the way to go in the older population

*How feasible is creating and distributing a monoclonal antibody vaccination?*

- Well, [Humira](https://en.wikipedia.org/wiki/Adalimumab), one of the most prescribed drugs that we have today, is a monoclonal antibody that’s repeatedly given to people.
- The advent of monoclonal antibodies is going to be very important to treat infectious diseases and may be the way of the future, says David

\*\*\*

**Ebola treatment of monoclonal antibodies that neutralizes the virus dropped the death rates significantly**: [Two Ebola drugs show promise amid ongoing outbreak](https://www.nature.com/articles/d41586-019-02442-6) | Amy Maxmen (nature.com)

- [REGN-EB3](https://en.wikipedia.org/wiki/REGN-EB3) | (wikipedia.org)

**Ongoing trial using monoclonal antibodies to neutralize HIV to see if it can prevent infection in Africa**: [HVTN 703/HPTN 081](https://www.hptn.org/research/studies/703_081) | (hptn.org)

## COVID-19 vaccines in development [1:19:00]

- Attenuated and inactive virus vaccines make up the majority of vaccines
  - Examples of attenuated virus vaccines: measles, mumps, and varicella zoster
  - Examples of inactive virus vaccines: Polio, hepatitis A, and rabies
- More rarely, vaccines are made with spike protein: E.g., Hep B and HPV

Yet, most of the current vaccine approaches are newer approaches of taking DNA or mRNA from these viruses or spike proteins directly

- A few groups working on vaccines include: [Pfizer](https://www.pfizer.com/science/coronavirus/vaccine), [U of Oxford](https://www.fiercebiotech.com/biotech/astrazeneca-s-covid-19-vaccine-enters-phase-2-3-clinical-trial), [Moderna](https://www.clinicaltrialsarena.com/analysis/covid-19-vaccine-moderna/)
- Via WedMD: [COVID-19 Vaccine: Latest Updates](https://www.webmd.com/lung/news/20200610/covid-19-latest-updates)

![](https://peterattiamd.com/wp-content/uploads/2020/06/Figure-adapted-with-leading-COVID19-vaccination-groups-847x1024.png)

**Figure 3. Leading COVID19 vaccination groups.** Image credit: [scientificamerican.com](https://www.scientificamerican.com/article/genetic-engineering-could-make-a-covid-19-vaccine-in-months-rather-than-years1/)

*Why might there be concern with using* ***attenuated*** *versions in a human vaccine?*

- David explains with an example…
  - [Ron Desrosier](https://umiamihealth.org/sylvester-comprehensive-cancer-center/research/faculty/ronald-c-desrosiers-md-phd) (the guy who isolated SIV and the subsequent clones of that virus), [discovered](https://pubmed.ncbi.nlm.nih.gov/1470917/) that if you attenuate SIV by knocking out a piece of [Nef](https://en.wikipedia.org/wiki/Nef_(protein)) and you infect animals, the virus still replicates but it’s weak with a very low level of replication
  - 20 weeks later, those animals are protected from the wild type virus
  - Great, right?
  - However, it was noticed that monkeys that were given this Nef-attenuated virus, *many years later* started developing clinical signs of SIV infection
  - It had repaired itself and was now pathogenic
- Another [experiment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2937616/) by David…
  - David took attenuated virus-infected monkeys and then challenged them with a different virus
  - There was some level of protection
  - However, a few animals had very, very high virus loads and we’re not protected at all
  - The **incoming virus had recombined with a vaccine virus** to form an entirely new virus that was highly pathogenic

> “You have to be very, very careful before going into thousands and millions of people with whatever vaccine construct you might have.”

*-Every way to make a COVID-19 vaccine is being tried at the moment:*

- The Oxford approach, for example, is to use a chimp adenovirus to express the spike protein of the coronavirus
  - They want to see what neutralizing antibodies that generates
  - What is the neutralizing titer
  - And how long does that antibody titer stay there
- Not necessarily just in monkeys, in humans, because in the end, that’s the only experiment that we truly care about.

**The goal of a COVID-19 vaccine is different than HIV**

- *In the case of HIV*, we’re trying to provide sterilizing immunity because once HIV starts replicating it forms the necessary mutations to escape from any sort of immune response
- *In the case of coronavirus*, we’re trying to knock down initial virus inoculum to a level where it doesn’t cause symptoms as well as reduces the amount of transmission

## How David’s work with Zika virus informs his thinking on SARS-CoV-2 [1:25:20]

*Is there anything that you’ve learned through your years of studying Zika that factors into how you think about coronavirus?*

- Zika virus is only a problem if it infects pregnant women
- There are many children that don’t look as if they’re unusual, but because this virus infects brain tissue, they will have many, many neurological deficits
- I think a vaccine against Zika virus faces the same problems that you need to induce **neutralizing antibodies** that can be **durable**

**David’s** [**Zika monoclonal antibody approach**](https://pubmed.ncbi.nlm.nih.gov/28978754/)

- In collaboration with Dennis Burton, they made antibodies that could be injected into monkeys and completely prevent infection
- They did the same experiment on pregnant monkeys that were **already infected** but could not prevent transmission to the fetus

## Why a vaccine for COVID-19 doesn’t need to be perfect to be effective [1:27:45]

*When developing any drugs/vaccines for a virus, the approach you might take depends on…*

- i) the biology of the virus and
- ii) what you need to do to ameliorate suffering from that virus

**A vaccine for COVID-19**

We don’t need a vaccine that is perfect, it just has to be *good enough*

- It must have neutralizing antibodies
- It has to reduce the viral load because
  - i) that would reduce the transmission, and
  - ii) the viral load is proportional to the damage
    - More virus is more entry through cells that bear the [ACE-2 receptor](https://en.wikipedia.org/wiki/Angiotensin-converting_enzyme_2)

*Assuming we could reduce the viral load upon first contact by 70-80% through some combination of monoclonal antibodies or effective vaccines…*

- That could have a commensurate reduction in mortality and spread
- And much of the damage out the gate with coronavirus was nosocomial (transmission within hospitals) which also probably means higher viral loads
- So a combo therapy of a non-perfect vaccine with monoclonal antibodies that could reduce viral load would be crucial

**Monoclonal antibodies**

> “Monoclonal antibodies, for me, are the way forward to prevent and treat almost all infectious disease. And they’re a logical extension of a vaccine.”

- David’s lab is trying to develop monoclonal antibodies against both this novel coronavirus
- While also keeping an eye toward the future on the next one that is evitable
- Making monoclonal antibodies simply means …
  - taking from the best responders with the best antibodies
  - Cloning them and
  - distributing that to everybody
  - Because we’re not all able to make those robust and highly specific and high-binding neutralizing antibodies

**One last message from David**: Try everything, create a combination of approaches, and value human data above all else

§

## Selected Links / Related Material

**NEJM paper about T cells and cancer**: [Release the Hounds! Activating the T-Cell Response to Cancer](https://www.researchgate.net/publication/269284795_Release_the_Hounds_Activating_the_T-Cell_Response_to_Cancer) (Sznol and Longo, 2015) [40:00]

**Ron Desrosiers isolated SIV, a virus that looked very similar to HIV, which became the animal model that we are able to test HIV therapies on**:  [Isolation of T-cell Tropic HTLV-III-like Retrovirus From Macaques](https://pubmed.ncbi.nlm.nih.gov/3159089/) (Daniel et al., 1985) [58:30]

**Ray Schinazi made a game changing discovery that a few drugs in combination was an effective treatment for HIV**: [Raymond F. Schinazi](https://en.wikipedia.org/wiki/Raymond_F._Schinazi#Discovery_and_development_of_lamivudine_(3TC)) | (wikipedia.org) [59:20]

**Groundbreaking PrEP studies lead to TRUVADA, a drug that prevents sexually active people from getting HIV**: [Pre-exposure prophylaxis](https://en.wikipedia.org/wiki/Pre-exposure_prophylaxis) | (wikipedia.org) [59:45]

- Truvada: [Emtricitabine/tenofovir](https://en.wikipedia.org/wiki/Emtricitabine/tenofovir) | (wikipedia.org)

**The 1918 flu pandemic**: [Spanish flu](https://en.wikipedia.org/wiki/Spanish_flu) | (wikipedia.org) [1:05:00]

**Ebola treatment of monoclonal antibodies that neutralizes the virus dropped the death rates significantly**: [Two Ebola drugs show promise amid ongoing outbreak](https://www.nature.com/articles/d41586-019-02442-6) | Amy Maxmen (nature.com) [1:12:15]

- [REGN-EB3](https://en.wikipedia.org/wiki/REGN-EB3) | (wikipedia.org)

**Ongoing trial using monoclonal antibodies to neutralize HIV to see if it can prevent infection in Africa**: [HVTN 703/HPTN 081](https://www.hptn.org/research/studies/703_081) | (hptn.org) [1:16:45]

**Update on COVID-19 vaccines**: [COVID-19 Vaccine: Latest Updates](https://www.webmd.com/lung/news/20200610/covid-19-latest-updates) | Kathleen Doheny (webmd.com) [1:19:00]

**Several companies working on a COVID-19 vaccine**: [1:19:00]

- [Pfizer](https://www.pfizer.com/science/coronavirus/vaccine)
- [U of Oxford](https://www.fiercebiotech.com/biotech/astrazeneca-s-covid-19-vaccine-enters-phase-2-3-clinical-trial)
- [Moderna](https://www.clinicaltrialsarena.com/analysis/covid-19-vaccine-moderna/)

**Ron Desrosier discovered that if you attenuate SIV by knocking out a piece of Nef and you infect animals they are protected from the wild type virus**: [Protective Effects of a Live Attenuated SIV Vaccine With a Deletion in the Nef Gene](https://pubmed.ncbi.nlm.nih.gov/1470917/) (Daniel et al., 1992) [1:20:40]

**David’s experiment taking attenuated SIV-infected monkeys and challenging them with a different virus showed some level of protection, but a few animals that had very, very high virus loads and we’re not protected at all**: [Macaques Vaccinated with Simian Immunodeficiency Virus SIVmac239Δnef Delay Acquisition and Control Replication after Repeated Low-Dose Heterologous SIV Challenge](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2937616/) (Reynolds et al., 2010) [1:21:30]

**David’s Zika monoclonal antibody approach that could prevent Zika infection**: [Neutralizing Human Monoclonal Antibodies Prevent Zika Virus Infection in Macaques](https://pubmed.ncbi.nlm.nih.gov/28978754/) (Magnani et al., 2017) [1:26:00]

§

## People Mentioned

- [Esper Kallás](https://bv.fapesp.br/en/pesquisador/6909/esper-georges-kallas/) [25:45, 1:12:00]
- [Myrna Bonaldo](https://pubmed.ncbi.nlm.nih.gov/?term=Bonaldo%20MC%5BAuthor%5D&cauthor=true&cauthor_uid=28978754) [25:45]
- [Stanley Perlman](https://medicine.uiowa.edu/microbiology/profile/stanley-perlman) [34:00]
- [Ron Desrosiers](https://umiamihealth.org/sylvester-comprehensive-cancer-center/research/faculty/ronald-c-desrosiers-md-phd) [58:30, 1:20:40]
- [Ray Schinazi](https://en.wikipedia.org/wiki/Raymond_F._Schinazi) [59:20, 1:02:30]
- [Dennis Burton](https://www.scripps.edu/faculty/burton/) [1:17:20, 1:26:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/06/1x1-davidwatkins-500x500.jpg)

##### David Watkins, Ph.D.

David is a professor of pathology at the George Washington University Medical School, where he recently relocated from the University of Miami. Dr. Watkins was elected a Fellow of the American Academy of Microbiology and was Vice Chair of Research in Pathology at the University of Miami, prior to this recent transition. David’s early work was focused on the similarities between non-human primate Simian Immunodeficiency Virus (SIV) and Human Immunodeficiency Virus-1 (HIV-1) which then progressed into investigating novel ways to make an effective vaccine against HIV using the yellow fever vaccine. Watkins was also involved in developing a treatment against ZIKA virus during the viral outbreak of 2015-2016. He is currently involved in applying his knowledge and experience with HIV and ZIKA to the COVID-19 therapeutic landscape.