# #145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor

**Source:** [https://peterattiamd.com/ama19/](https://peterattiamd.com/ama19/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob take a deep dive into zone 2 training. They begin with a detailed definition of zone 2 and continue by discussing the importance of adding it to your exercise regimen. They talk about how to program zone 2 training, including intensity, frequency, and duration, and metrics for tracking improvement. Additionally, they provide a detailed overview of all things related to magnesium supplementation. The two conclude with insights about how to effectively engage with your doctor in the pursuit of getting your questions answered and considerations for finding a physician that’s right for you.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #19 show notes page](https://peterattiamd.com/ama19). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Defining zone 2 exercise (3:30);
- The most effective ways to engage in zone 2 exercise (14:00);
- The process of training a deconditioned individual with zone 2: Dosage, frequency, and metrics to watch (19:45);
- Training for health vs. performance, and the importance dedicating training time solely to zone 2 (25:00);
- Why Peter does his zone 2 training in a fasted state (31:30);
- Improving mitochondrial density and function with zone 2 training (34:00);
- Metrics to monitor improving fitness levels from zone 2 training (36:30);
- Advice for choosing a bicycle for zone 2 exercise at home (42:30);
- Comparing the various equipment options for aerobic training: Rowing machine, treadmill, stairmaster, and more [48:15];
- Back pain and exercise, and Peter’s stability issues as a consequence of previous surgeries (51:45);
- A deep dive into magnesium supplementation, and Peter’s personal protocol (55:30);
- Advice for engaging with and questioning your doctor (1:03:15); and
- More.

§

The Peter Attia Drive

Zone 2 training, magnesium supplementation, and how to engage with your doctor

§

## Show Notes

## Defining zone 2 exercise [3:30]

**Exercise framework**:

- Peter has a framework for exercise which has four components: Stability, strength, aerobic efficiency, and anaerobic performance (see [AMA #7](https://peterattiamd.com/ama07/) and [AMA #12](https://peterattiamd.com/ama12/))
- So when we talk about zone 2, we must understand that it is but **one component**

**Defining zone 2 exercise**:

⇒ Zone 2 exercise was covered in a [previous podcast with Iñigo San Millán](https://peterattiamd.com/inigosanmillan/)

- **Zone 2 is defined** as your highest metabolic output/work that you can sustain while keeping your lactate level *below two millimole per liter* (mmol/L)
- Biochemically, what’s happening as you exercise (or do anything) is the process of respiration, the process of using substrate
- We use glucose, we use fatty acids, we use oxygen, and we undergo a chemical process.
- We take the chemical energy that is stored in the bonds of those molecules and turn that into electrical energy (via the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain))
- It then gets turned back into chemical energy as we borrow from that energy to make [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate)—our currency for how we do everything

*-The first step*:

- Turning glucose (just using glucose in this example for simplicity) which it’s a six carbon ring, into two smaller molecules that are each made up of three carbons called [pyruvate](https://en.wikipedia.org/wiki/Pyruvic_acid)
- This step yields some energy, and costs some energy

–*Step two*: The body has a choice whether to:

- A) Continue this process *outside of the mitochondria* where I make another by-product called lactate (which can generate a little bit more ATP); Or
- B) Take that pyruvate and shuttle it into the mitochondria, and undergo a separate chemical pathway and a separate process called the [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) where you can make MANY more ATPs

![](https://peterattiamd.com/wp-content/uploads/2021/01/atp-generation.jpg)

**Figure 1. ATP generation.** [[source](https://peterattiamd.com/ketosis-advantaged-or-misunderstood-state-part-i/)]

![](https://peterattiamd.com/wp-content/uploads/2021/01/krebs-cycle-1024x710.png)

**Figure 2. Krebs Cycle.** [[source](https://www.khanacademy.org/science/biology/cellular-respiration-and-fermentation/pyruvate-oxidation-and-the-citric-acid-cycle/a/the-citric-acid-cycle)]

**==> Krebs Cycle explained by Khan Academy [here](https://www.youtube.com/watch?v=juM2ROSLWfw)**

*-How does your body decide between A and B pathways to ATP?*

- If you need to make ATP really quickly, you’ll take that former pathway and make lactate because you don’t need oxygen to do it—meaning you’re not limited by the amount of oxygen that is being taken up by the muscle
- If you have more time on your hands, you’ll take the latter pathway—meaning you will utilize oxygen and actually take that substrate into the mitochondria, and you will be able to make tons of ATP

**What differentiates individuals…**

- Note: Not all people are not created equal—Both genetically, but more importantly, **through training**
- What differentiates the highly trained/metabolically fit from the untrained/metabolically unfit…is that **ability to, under a greater and greater array of metabolic demands, make that input of substrate into the mitochondria**
- *Mitochondrial health* then can be somewhat estimated and proxied by the ability a person has to do this

*-How would you measure this?*

- One of the most valuable ways to do this is to measure lactate levels
- If you start producing too much lactate, it will actually escape the muscle and get into your circulation… which can then be easily measure with a **finger prick**

**Lactate levels at rest and during exercise**

- A healthy person when they’re sitting there at rest has a lactate level of about *1.0 mmol/L*
- Basic activities of daily living (walking, standing, eating) shouldn’t at all be pushing you to generate higher levels of lactate to the point that you accumulating lactate

*What happens if you start doing something a little more strenuous?*

- At some point, you’re going to have to start generating lactate (even the fittest person ever)
- If you need to make energy (ATP) faster than you’re able to deliver oxygen to your muscles, at some point the **lactate begins to accumulate in excess of what is cleared**

*It’s a bit more complicated…*

- The organ that is primarily responsible for clearing lactate is the liver (via gluconeogenesis), and that takes longer so there’s a big time lag there
- The other thing is that different people have different amounts at which they clear lactate from the cytoplasm of the cell—which is done via transporters called MCTs—and different people can have different levels of MCT expression

**The upshot:**

- The fitter a person is, the healthier a person is, *the more work they can do with less lactate*
- For a given individual, we use this metric of zone 2 as a place to understand
  - how metabolically healthy they are;
  - how good their mitochondria are; and
  - how much work can be done while keeping your lactate about 1.7 to 2.0 mmol/L

⇒ For example, You could say, “My zone two is 200 watts.” And that would mean you could hold 200 watts on a bike for a very long period of time, because you’re never really going above 2.0 mmol

- 2.0 mmol/L is a very sustainable level of lactate production well below lactate threshold
- Lactate thresholds for most people is about 4.0 mmol/L
- An athlete, for context, is really only able to hold a 4.0 mmol pace for tens of minutes if not less
- And peak output is going to produce lactates easily over 10 and in some cases over 20 and those efforts can only be sustained for seconds
- You can think of zone 2 as your “all day pace”

**In the** [**podcast with Iñigo San Millán**](https://peterattiamd.com/inigosanmillan/)**…**

- They discussed a [study](https://pubmed.ncbi.nlm.nih.gov/28623613/) that compared 3 groups of people: i) type 2 diabetic ii) normal fit people, and iii) to world-class athletes (cyclists)
- The difference in the amount of power that the athletes could put out on a bicycle while keeping lactate at 2.0 mmol/L was staggering — Especially once you normalize for weight and you get how many watts per kilos

![](https://peterattiamd.com/wp-content/uploads/2021/01/sanmillan-and-brooks-1024x730.png)

**Figure 3.** Image credit: ([Brooks and Millan, 2018](https://pubmed.ncbi.nlm.nih.gov/28623613/))

## The most effective ways to engage in zone 2 exercise [14:00]

**Machines for doing zone 2 exercise**:

- Bicycle (Peter’s preference)
- Treadmill (2nd best option)
- Rowing machine (will work for efficient rowers but Peter says doing zone 5 on a rower is best)
- Elliptical (Peter’s least favorite but can be done)

**Bicycle**

- When doing zone 2, you want a machine where it’s very easy to reproducibly produce the same output
- And a bike bicycle has a very clear metric that I can adjust which is the **wattage**
- Peter sets his road bike on a device called a [Wahoo KICKR](https://www.wahoofitness.com/devices/bike-trainers) which is hooked up to a computer where you tell it the numbers of Watts you want and it sets the resistance for you
- Peter loves this way to doing zone 2 because it takes all the thinking out of it, you can just “tune out” and know you’re staying in zone 2

⇒ Check out Peter using his Wahoo Kickr and [explaining his zone 2 workout](https://www.instagram.com/p/BsLfg6kg0Q9/) on IG

**Treadmills**

- Treadmills are also a great option
- For most people, running gets them out of zone two a little too quickly
- With patients, Peter prefers them to do brisk walking on an incline
- You have to figure out which incline and speed will keep you, personally, in zone 2, but once you know then you can set it and go
- He starts people between 10 and 15 degrees incline and 2.5-3.0 mph on the speed

*–How to know you’re in zone 2?*

- Using heart rate
- Checking lactate
- (more details on this later in the podcast)

**Rowing machine**

- Peter is not fond of the rowing machine for zone 2
- He prefers to use the rowing machine for zone 5
- However, someone who is an efficient rower like [Beth Lewis](https://www.instagram.com/bethlewisfit/?hl=en) ([previous podcast guest](https://peterattiamd.com/bethlewis)) can get a zone 2 work out on the rowing machine

**Elliptical**

- Peter is not hugely fond of ellipticals for zone 2 because it’s hard to stay in the proper zone
- And it’s really important that you’re not vacillating in and out of “zone 2”

## How to measure lactate levels to ensure you are staying in zone 2 [18:30]

- Nowadays, Peter takes one measurement at the very end of the workout via a finger prick
- NOTE: When he was first starting doing this, he would check every 15 minutes and adjust his wattage up or down until he would converge on the proper wattage to be in zone 2

\*Tips:

- You have to use soap and water (not just alcohol) on your finger because lactate is very difficult to get off and you want to have no contaminating lactate levels
- Also, Peter takes the third drop of blood for measurement

## The process of training a deconditioned individual with zone 2: Dosage, frequency, and metrics to watch [19:45]

Looking again at the [2018 study](https://pubmed.ncbi.nlm.nih.gov/28623613/) by San Millan and George Brooks:

- If you look at the power output on the endurance athletes, they were around I think 300 watts before they were at two millimole

![](https://peterattiamd.com/wp-content/uploads/2021/01/300-watts-1024x589.png)

- Peter says, “*Most people don’t understand what 300 watts feels like for five minutes or for even one minute, let alone four hours. It’s a modern miracle of physiology that some athletes can do that.*”

\*\*\*

**Training a deconditioned/metabolically ill individual**

- Someone who is very metabolically ill may be already at 2 mmol of lactate at rest
- So right after they jump on the bike their lactate starts to shoot up
- So it becomes quite the challenge to get that person to sustain 45 minutes (recommended zone 2 dose)
- Essentially, they are immediately getting out of mitochondrial oxidation and they’re burning nearly all glucose instead of fat (which is not the purpose of dedicated zone 2 exercise)

*How would Peter go about training that person?*

- Let’s say you take a person who’s resting lactate is 1.5 to 2.0 mmol (NOTE: Metformin will raise your resting lactate by the way)
- This persons mitochondria probably does not work that well
- You put that person on a bike at 100 watts, their lactate could easily be 5.0 mmol in 20 minutes

*What do we do with that person? How do we get that person in shape?*

- Short answer is you just accept the fact that in the short term their lactate is going to blow past 2.0 (meaning their not in zone 2)
- So in the beginning, Peter would rely what’s called rate of perceived exertion (RPE)
- Combing that metric with heart rate and lactate and you can start to triangulate on zone 2

*But the* ***really*** *metabolically inflexible person…*

- It’s really an art to it
- sometimes you have to just rely more on RPE
- You can estimate their maximum HR (70-80% of max), but that’s complicated because that’s for true maximum, not predicted maximum and generally somebody who is that metabolically unhealthy has no clue what their true maximum heart rate is

***The good news?*** These people generally will start to show results very quickly

- Ideally like to have these people exercising up to three hours a week
- But Peter will settle for three bouts of 20 minutes to get started
- But the more time a person can do this, the quicker they will make progress

**Recommended dosage**:

- San Millan believes that the minimum effective dose is really **three hours a week, and no sessions shorter than about 45 minutes**
- Peter is pushing our patients to do three or four sessions weekly no shorter than 45 minutes per session
- *In an ideal world*, Peter would do **four two-hour sessions per week**

\*\*\*

[Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) [broke the world record](https://www.youtube.com/watch?v=GpBZhK5Kpd0) for a marathon (26.2) miles at 2:01:39

- For context, get on a treadmill and go at 13 miles per hour for two hours
- The incredible part about this record is that Kipchoge would have had his lactate below two millimole that entire time except for maybe the last 15 minutes or so

## Training for health vs. performance, and the importance dedicating training time solely to zone 2 [25:00]

***Does it matter how you get your total zone 2 time in?***

For example, *does it make any difference if you did three one hour sessions, or I did six sessions of 30 minutes?*

- You’d be better off doing the three one hour sessions than the six 30 minute sessions, says Peter
- This is still somewhat of an empirical observation, but until demonstrated otherwise, Peter recommends each session to be at least 45 minutes

**Training for life vs. training for a sport**

- Even the elite athletes spend about 70% of their time in zone 2, but they typically do workouts that vary in intensity through the session depending on what sport they are training for
- A cyclist, for example, might do a ride that’s two hours at varying intensity
- But non-athletes like Peter even when using a bike are just using it as a tool to train your mitochondria so you should not be trying to mix and match zones

Peter’s regimen might look like this:

- A session of zone 2 only
- A session of zone 5 only
- A HIIT session (which is sort of neuromuscular) separately
- The morning of this podcast, for example, Peter did weights and then I did HIIT afterwards
- The next day he plans to do an hour of zone 2

“*I use these things to make myself healthier*” …  as opposed to training for a sport

## Why Peter does his zone 2 training in a fasted state [31:30]

Peter likes to go into his zone 2 sessions in a **fasted state** (he does morning workouts)

- The reason is that he wants maximum substrate—meaning as much fatty acid and glucose available for his muscles
- The way you want to maximize fatty acid availability is to have insulin level be as low as possible, because **insulin impairs lipolysis**
- Peter has noticed that *the higher his glucose level during a zone 2, the higher his lactate level will be*

Another anecdotal observation:

- He recently had to take a corticosteroid (Prednisone) which raises your glucose quite a bit
- He was shocked at how much higher his lactate numbers were (typically he finishes a zone 2 workout at 1.9 mmol but he’s be at 3.1 mmol)
- He thinks it’s probably something to do with the hepatic glucose output being driven by prednisone

> “If you can do these [zone 2 sessions] fasted, you’re stressing the system in a good way.” —Peter Attia

Bob points out that if your [RQ](https://en.wikipedia.org/wiki/Respiratory_quotient) is closer to the fat burning stage at the very beginning of the workout (which is what would happen if you were in a fasted state vs. if you just ate a meal), you’re more likely to be oxidizing more fat sooner in the workout because you wouldn’t have to take as much time to “shift” from glucose as fuel to fat

## Improving mitochondrial density and function with zone 2 training [34:00]

- A benefit of zone 2 training is increasing mitochondrial density & function
- The question: ***Does it increase in all muscles during zone 2 training or is it just the primary muscles being worked?***
  - It’s hard to know without more extensive studies with biopsies, says Peter
  - Peter’s intuition is that it probably wouldn’t have much of an effect on non-working muscles

Bob’s take:

- There are hypertrophy studies where participants will do single limb exercise
- They take a biopsy of both the right leg and the left “untrained” leg
- In those cases, they might see [some improvements in some markers of muscle function](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3511348/)
- Bob suspects that single leg zone 2 training might result in some type of adaptations that would be beneficial such as preservation (rather than growth) in skeletal muscle in the non-exercised limb; See:
  - [Broke Your Right Arm? Exercise Your Left. It May Help, Really.](https://www.nytimes.com/2018/05/16/well/move/exercise-sports-injury-arm-leg-broken-strain-sprain.html) | Gretchen Reynolds (nytimes.com)
  - [Unilateral strength training leads to muscle-specific sparing effects during opposite homologous limb immobilization](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00971.2017) (Andrushko et al., 2018)
  - [Contralateral effects of unilateral strength training: evidence and possible mechanisms](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00531.2006?rfr_dat=cr_pub++0pubmed&url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org) (Carroll et al., 2006)
  - [Training with unilateral resistance exercise increases contralateral strength](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00559.2005) (Munn et al., 2005)
  - [Contralateral effects of unilateral resistance training: a meta-analysis](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00541.2003) (Herbert and Gandevia, 2004)
  - [Single-leg cycle training is superior to double-leg cycling in improving the oxidative potential and metabolic profile of trained skeletal muscle](https://journals.physiology.org/doi/full/10.1152/japplphysiol.01247.2010) (Abbiss et al., 2011)

**Observationally**, if you look at professional cyclists, they look like emaciated above the waist with legs like horses, suggesting *most of the benefit in terms of building muscle comes in the muscles being worked*

## Metrics to monitor improving fitness levels from zone 2 training [36:30]

Zone 2 exercise done properly should improve mitochondrial function, fat utilization, and lactate clearance (See episode of the Drive with [inigo episode](https://peterattiamd.com/inigosanmillan/)? [Mito dens.](https://diabetes.diabetesjournals.org/content/57/4/987.figures-only),

*But what about functional threshold power (FTP)?*

**FTP**

- FTP is [functional threshold power](https://www.trainingpeaks.com/blog/what-is-threshold-power/)—a very important cycling vernacular
- It’s s not really a longevity marker, it’s a *performance marker*
- In fact, you can almost predict the winner of the Tour de France on the first day of the race if you know everybody’s FTP in watts per kilos
- It is defined as the maximum power you can sustain for one hour
- the most painful way to measure it is to do a one hour all out “death test”, but a more practical was is to do a 20 minute and then 90% discount that
- For example,
  - if you can hold 330 watts for 20 minutes, your FTP is about 300 watts
  - Then you divide that by your weight in kilos — so if you weighed 75 kilos, your FTP would be four watts per kilo (a middle of the pack cat three cyclist)
  - For context, a professional cyclist is going to be north of five watts per kilo and even close to six

*How do you train to make FTP go higher?*

- If you want to increase it, you have to train it
- Zone 2 alone will not increase FTP that much, nor will it increase it very quickly
- If you want to do an FTP increasing workout, then you’re doing lots of training across all the zones
- Peter, who no longer trains across zones in a single workout, has seen his FTP increase by about 15 to 20 watts (i.e., not much) from his zone 2 workouts

**Better metrics to track**

-With zone 2 done properly, you should see:

- Improving fat oxidation
- Improving lactate clearance
- And therefore improved mitochondrial function
- And with those improvements, you should technically be able to increase your output while staying in your zone 2

“In an ideal world,” says Peter, “your heart rate at zone 2 is probably not going up that much, but your wattage or work output (miles per hour, incline, watts, mets, etc.) is going up.”

## Advice for choosing a bicycle for zone 2 exercise at home [42:30]

**A real street bike hooked to a device to make it “stationary”** (Peter’s preference)

- In Peter’s case, he prefers using a real bicycle (brand [Pinarello](https://pinarello.com/)) and strapping it into a [Wahoo KICKR](https://www.wahoofitness.com/devices/bike-trainers)
- Wahoo KICKR makes a device called the Wahoo KICKR that you set your bike onto so you’re riding your street bike on a device

**Stationary bike**

- A stationary bicycle is designed to be ridden in a stationary fashion indoors
- You can buy them based on software or based on hardware
- Example: [Peloton](https://www.onepeloton.com/bike)
  - So for example, when you’re buying a Peloton, you’re buying it based on the **software**—that it comes with this nice monitor and it’s plugging you into a community of doing these classes, etc.
  - From a hardware perspective, it’s not a good bike at all (e.g., the lowest position of the handlebars is still way too high)
- Example: [Keiser](https://www.keiser.com/fitness-equipment/cardio-training) brand
  - If you’re buying a stationary bike from the standpoint of form factor, Peter says the Keiser bikes are hands down the best

**Other gadgets and software**

- Bob also rides a street bike strapped to a [Wahoo KICKR](https://www.wahoofitness.com/devices/bike-trainers)
- But additionally, he uses a gadget called [Climb](https://www.wahoofitness.com/devices/bike-trainer-accessories/kickr-climb-indoor-grade-simulator) which can change the incline of the ride
- He combines the Climb with a software called [Sufferfest](https://thesufferfest.com/pages/cycling)
- Essentially, this combo simulates the proper incline to correspond to the screen which is showing footage of moving up a mountain or descending down

**Fans for cooling**

- Peter has a ceiling fan plus a standing fan that blows directly on him
- Wahoo makes a fan called [Headwind](https://www.wahoofitness.com/devices/accessories/kickr-headwind-bluetooth-fan-us) that adjusts to the resistance and the speed so it actually blows harder the faster you go to simulate being on the road
- \***Note about temperature**: Peter says if the ambient temp is above about 70 degrees, it wouldn’t be surprising if it impaired your performance on zone 2

## Comparing the various equipment options for aerobic training: Rowing machine, treadmill, stairmaster, and more [48:15]

**Rowing**

- Peter says you can make a lot of great cases for rowing
- Performing the row with proper form requires a coordination that translates into many other aspects of life
- It’s hip hinging, it’s rowing, it’s kind of everything in one (except for a push) and when you know how to do it well, you’re fully connected from hands to feet
- The caveat: You better be darn good at the proper form because if you’re not then…
  - i) you’re not going to be able to do it in zone 2; and
  - ii) You’re going to risk injury

⇒ See the [show notes](https://peterattiamd.com/bethlewis/) for the episode of The Drive with Beth Lewis for a masterclass on rowing

**Treadmill or bicycle**

- For most people, it’s much easier to maintain zone 2 via walking on a treadmill at an incline or getting on a decent bicycle

**What about walking outdoors?**

- Most people are not able to get to zone 2 with walking on a flat ground
- You’re most likely spending most of your time in zone 1 because you’re not at a high enough intensity

**What about jogging?**

- In Peter’s experience, most people are actually escaping zone 2 when running (i.e., intensity too high)

**Stairmaster**

- Peter loves the StairMaster for zone 2 (and zone 5)
- You’re literally climbing a rolling staircase
- “*There’s something about fighting gravity in a sort of deliberate way that I like*.”

## Back pain and exercise, and Peter’s stability issues as a consequence of previous surgeries [51:45]

How is exercise in its different forms, resistance training, aerobic training, stability helped with your back pain?

**Peter history of back surgery**

*Knowing what you know now, would you have had the same back surgery you had before?*

- “I absolutely would not have undergone [back surgery]” says Peter
- Back in the year 2000, his back procedure was a total disaster for a few reasons:
- The doctor not only operated on the wrong side, but he was such a “callous buffoon” that he refused to take any responsibility or accountability for his mistakes
- This botched surgery led to a number of additional procedures that have unfortunately left Peter in a very vulnerable position—incredibly low stability in his lower back
- One main objective for Peter (for the rest of his life) is to figure out a way to avoid a two level fusion
- He’s unstable at L5 and S1 due to the fact that he has complete bilateral laminectomies
- If he get into trouble again, they will likely need to fuse him at L4, L5, and S1

*What would he have done instead?*

- He would have proceeded with a non-surgical intervention at the time
- And if he DID need to go ahead with a surgery, he would have done much more homework on who the right person was to do it

**More details on the procedure and the ensuing consequences:**

- The first one was a discectomy—but because it was done on the wrong side, it injured a nerve that wasn’t actually part of the problem in the first place
- He needed to go back for a discectomy on the other side, but there ended up being more complications after that
- Eventually it was necessary to fully just clean everything out in that space, it required removing even more bone…so it became more and more and more involved as time went on
- Once the lamina are fully cut on both sides, you really take a stability hit at that joint
- For example, in full extension or full flection, now the vertebral bodies can start to move a little bit in an anterior posterior direction that they shouldn’t be moving

**How Peter has adapted**

- “So for me, so much of what I do every single day is really geared towards ‘how do I reduce the probability of chronic pain and injury as I continue to age?’”
- “Parts of my body I think that are quite young, probably younger than my chronologic age. But my spine is not one of them.”
- “Part of that’s due to some congenital issues. Part of that’s just due to stupidity and wear and tear, and the kind of stuff I did growing up. And obviously part of that is iatrogenic.”

**Importance of exercise for reducing back pain**

- It may seem counterintuitive to some, but being more active and mobile can help in terms of decreasing in the back pain

> “I’m at my worst when I’m in situations where exercise is taken away from me.” —Peter Attia on the health of his lower back

## A deep dive into magnesium supplementation, and Peter’s personal protocol [55:30]

**What magnesium is important**

- Magnesium is a super important mineral found at its highest quantity in bone (about [50-60% present in bones](https://ods.od.nih.gov/factsheets/Magnesium-HealthProfessional/#en4) and most of the rest in soft tissues)
- But it’s probably the second most predominant [cation](https://en.wikipedia.org/wiki/Ion#Anions_and_cations) (positively charged ion within a cell) and and is [essential both for the functions of many enzyme systems and for neuromuscular transmission](https://www.ncbi.nlm.nih.gov/books/NBK218735/#:~:text=Calcium%20is%20the%20most%20abundant,amount%20is%20found%20in%20bones.)
- Magnesium has both physiological and biochemical functions
  - It is needed for the activation of many enzymes (for example enzymes concerned with the replication of DNA and the synthesis of RNA) and for parathyroid hormone secretion, which in involved in bone metabolism.
  - It is also needed for muscle and nerve function—i.e., activation potentials: the underlying hallmark of what’s called neuromuscular transmission (how we do everything from flinching, to flexing a muscle, to respiring)
- It also has important interrelationships with other cations like calcium, potassium, potassium has one (inside the cell), sodium has one (outside the cell), whereas magnesium has two positive charges (inside the cell)

![](https://peterattiamd.com/wp-content/uploads/2021/01/pathway-of-cations-ama19-1024x854.png)
**Figure 4. Pathway of calcium, magnesium, potassium, phosphorus absorption across the intestinal epithelium (\*\*focus red circle).** [[source](https://cjasn.asnjournals.org/content/10/7/1257.figures-only)]

**Magnesium depletion**

- Magnesium depletion is not uncommon even for otherwise healthy people
- The good thing about magnesium is it a low risk supplement (with normal kidneys)
- Potassium, on the other hand, is a dangerous thing to be taking in large doses (it’s actually part of the cocktail used to execute prisoners on death row)

***How would you replace it and to what purpose?***

*Why do we need it?*

- It’s a big part of maintaining the potassium concentration in the cell—An action potential requires sodium to rush in a cell and potassium to rush out of a cell. And those gradients have to be maintained. That requires electromagnetic force. Magnesium plays an important role in that.
- The active transport of restoring sodium and potassium *requires* magnesium

***What are the different forms?***

Two broad categories of magnesium:

- 1) Poorly absorbed, and
- 2) efficiently absorbed

-Magnesium **citrate** or magnesium **oxide**

- These are the *poorly absorbed* forms of magnesium
- This form can help with bowel function—when a person’s bowel function has slowed down, one of the first things you should be trying is a form of magnesium that is not very well absorbed
- Most people benefit greatly from some amount of that in their supplement routine
- Peter will start people with ~400 milligrams of magnesium oxide/citrate
- With a very constipated person, Peter will have them on 800, 1,200, even two grams
- You want to titrate that based dose up based on bowel function and watching out for the opposite effect of diarrhea or very loose stools
- **Peter’s protocol**: ~400-500 mg per day (when not fasting)

-Magnesium **chloride** (trade name [Slow Mag](https://www.amazon.com/Slow-Mag-Magnesium-Chloride-Calcium-Packaging/dp/B00E4MRRXI))

- This form is *efficiently absorbed*—it gets fully into your system and doesn’t really cause any GI distress
- One indication for Slow Mag is for the symptom of cramping
- NOTE about fasting:
  - When people are fasting, Peter uses more Slow Mag and less (or zero) mag oxide
  - When people are fasting, they’re struggling to get enough sodium and potassium, and they’re obviously not getting enough magnesium.
  - So whenever patients are complaining of cramping with or without a fast, the first thing we check is how much magnesium are they getting in the form of slow mag
- **Peter’s protocol**: 2 tablets of Slow Mag when not fasting; When fasting, 3-4 tablets

***What about magnesium L-threonate?***

- - L-threonate is less about the magnesium and more about what L-threonate does
  - L-threonate is a CNS transporter—magnesium doesn’t cross the blood brain barrier very effectively so the threonate is taking whatever magnesium you’ve got and getting it into the CNS as well

- *Why does this matter?*

- First, it’s being investigated for its potential benefits in the treatment of **mild cognitive impairment**.

- Secondly, it may improve sleep (which Peter has found to be true empirically)

- **Peter’s protocol**: Peter takes [Magtein](https://magtein.com/?gclid=Cj0KCQiA2uH-BRCCARIsAEeef3lIWbZACznW4OHAMt9mEbKbtn_RHCePMa0o0l44ucJ3XzleihWNhRgaAvwLEALw_wcB) as a standalone supplement (2 capsules)

\***Summarizing Peter’s magnesium protocol:**

- Peter takes 3 forms of magnesium: oxide, chloride (Slow Mag), and L-threonate (Magtein)
- When *NOT fasting*, he takes ~400-500 mg of oxide (morning), 2 tablets of Slow Mag (morning), and 2 capsules of Magtein (before bed)
- When *fasting*, he stops the oxide, takes a double dose of Slow Mag, and continues to take his Magtein before bed

## Advice for engaging with and questioning your doctor [1:03:15]

Weekly emails on this topic:

- [How to find a good doctor](https://peterattiamd.com/how-to-find-a-good-doctor/) – 7/12/20
- [Colorectal cancer screening](https://peterattiamd.com/colorectal-cancer-screening/) – 7/27/20

\*\*\*

**How to talk, engage, and question your doctor**

- First, Peter admits that physicians are in a tough position—many doctors must see upwards of 6 patients an hour to maintain their practice which squeezes the time they have for answering questions from patients unrelated to the particular visit
- So coming into an appointment and hitting them with tons of questions they weren’t prepared for creates a difficult scenario

**Best practice**: Send them an email before your appointment to give them a chance to reflect your questions, read up on it, and have their point of view ready

- Please remember, you’re still the consumer, so if the doctor is utterly dismissive of what you want to discuss, then you have a right to go get another doctor

> “Medicine is not that special. There’s nothing special about the fact that we spent four years going through certain types of school. There’s good doctors, and there’s bad doctors.” —Peter Attia

Medicine comes down to these four A’s: **advocacy, affability, availability,** and **ability**

- Your doc many not score a perfect 10 in all 4 categories but you better get some fraction of those to a level that is your satisfaction

If you’re not getting an answer that you’re comfortable with from your doctor, you should go find another doctor — “*Yeah, that’s a bit painful. But we’re talking about your health here. So it’s probably worth that investment*.”

§

## Selected Links / Related Material

**Episode of The Drive with zone 2 expert Iñigo San Millán**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com) [0:45, 5:45, 13:30]

**Weekly newsletter emails from Peter that discuss finding and engaging a doctor**: [1:30, 1:03:15]

- [How to find a good doctor](https://peterattiamd.com/how-to-find-a-good-doctor/) | Peter Attia (peterattiamd.com)
- [Colorectal cancer screening](https://peterattiamd.com/colorectal-cancer-screening/) | Peter Attia (peterattiamd.com)

**Goalie Ron Tugnutt of the Boston Bruins saved 70 shots in a three-three tie**: [Ron Tugnutt made 70 saves in game with Nordiques](https://www.nhl.com/news/ron-tugnutt-70-saves-game-centennial-memory/c-287899670) | John Kreiser (nhl.com) [2:45]

**Part 2 of the Studying Studies series where “Peter” is pictured following a chimney sweep (see Figure 2)**: [Studying Studies: Part II – observational epidemiology](https://peterattiamd.com/ns002/) | Peter Attia (peterattiamd.com) [3:00]

**Study that compared 3 groups of people: i) type 2 diabetic ii) normal fit people, and iii) to world-class athletes where difference in the amount of power that the athletes could put out on a bicycle while keeping lactate at 2.0 mmol/L was staggering — Especially once you normalize for weight and you get how many watts per kilos**: [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://pubmed.ncbi.nlm.nih.gov/28623613/) (San-Millán and Brooks, 2018) [13:30, 19:45, 24:00]

**Device that both Peter and Bob use for zone 2 training which allows you to strap in your road bike and control watts and resistance**: [Wahoo KICKR](https://www.wahoofitness.com/devices/bike-trainers) | (wahoofitness.com) [14:30, 42:45, 45:30]

**Popular stationary bike — but one that Peter doesn’t personally like because of the hardware (i.e., not comfortable)**: [Peloton](https://www.onepeloton.com/bike) | (onepeloton.com) [14:45, 43:00]

**Episode of The Drive with rowing expert Beth Lewis**: [17:15]

- *Show notes*: [#131 – Beth Lewis: The Art of Stability: Learning about pain, mitigating injury, and moving better through life](https://peterattiamd.com/bethlewis/) | Peter Attia (peterattiamd.com)
- *YouTube*: [#131-Beth Lewis: The Art of Stability—Learning about pain, mitigating injury & moving better in life](https://www.youtube.com/watch?v=t48iqNwS6PY) | PeterAttiaMD (youtube.com)

**Eliud Kipchoge holds the world record marathon time of 2:01:39**: [Kipchoge breaks marathon world record in Berlin with stunning 2:01:39](https://www.worldathletics.org/news/report/berlin-marathon-2018-eliud-kipchoge-world-rec) | (worldathletics.org) [24:15]

**Eliud Kipchoge also ‘unofficially’ broke the 2 hour mark in the marathon**: [24:15]

- [Breaking2](https://www.nike.com/running/breaking2) | (nike.com)
- [Eliud Kipchoge Breaks Two-Hour Marathon Barrier](https://www.nytimes.com/2019/10/12/sports/eliud-kipchoge-marathon-record.html) | Andrew Keh (nytimes.com)

**Studies looking at how single limb exercise impacts the skeletal muscle of non-worked limbs**: [35:15]

- *This study may suggest mitochondrial biogenesis in non-exercised muscle*: [Pronounced Effects of Acute Endurance Exercise on Gene Expression in Resting and Exercising Human Skeletal Muscle](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3511348/) (Catoire et al., 2012)
- *These studies show not so much hypertrophy in the immobilized limbs, but some level of preservation in muscle mass*:
  - [Broke Your Right Arm? Exercise Your Left. It May Help, Really.](https://www.nytimes.com/2018/05/16/well/move/exercise-sports-injury-arm-leg-broken-strain-sprain.html) | Gretchen Reynolds (nytimes.com)
  - [Unilateral strength training leads to muscle-specific sparing effects during opposite homologous limb immobilization](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00971.2017) (Andrushko et al., 2018)
  - [Contralateral effects of unilateral strength training: evidence and possible mechanisms](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00531.2006?rfr_dat=cr_pub++0pubmed&url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org) (Carroll et al., 2006)
  - [Training with unilateral resistance exercise increases contralateral strength](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00559.2005) (Munn et al., 2005)
  - [Contralateral effects of unilateral resistance training: a meta-analysis](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00541.2003) (Herbert and Gandevia, 2004)
  - [Single-leg cycle training is superior to double-leg cycling in improving the oxidative potential and metabolic profile of trained skeletal muscle](https://journals.physiology.org/doi/full/10.1152/japplphysiol.01247.2010) (Abbiss et al., 2011)

**Road bike brand Peter uses and straps it onto a Wahoo KICKR for zone 2 training**: [Pinarello](https://pinarello.com/) | (Pinarello.com) [42:45]

**Stationary bike brands recommended by Peter**: [43:45]

- [Keiser](https://www.keiser.com/fitness-equipment/cardio-training)
- [LeMond](https://lemond.com/)

**Gadget Bob uses to simulate an incline on his stationary bike**: [Climb](https://www.wahoofitness.com/devices/bike-trainer-accessories/kickr-climb-indoor-grade-simulator) | (wahoofitness.com) [45:30]

**Software Bob uses for his zone 2 training on his bike**: [Sufferfest](https://thesufferfest.com/pages/cycling) | (theSufferfest.com) [46:00]

**Wahoo makes a fan that adjusts to the resistance and the speed so it actually blows harder the faster you go to simulate being on the road**: [Headwind](https://www.wahoofitness.com/devices/accessories/kickr-headwind-bluetooth-fan-us) | (wahoofitness.com) [46:45]

**Episode of The Drive with James O’Keefe where they discuss the importance of magnesium**: [#134 – James O’Keefe, M.D.: Preventing cardiovascular disease and the risk of too much exercise](https://peterattiamd.com/jamesokeefe/) | Peter Attia (peterattiamd.com) [55:45]

**Brand of magnesium chloride Peter uses**: [Slow Mag](https://www.amazon.com/Slow-Mag-Magnesium-Chloride-Calcium-Packaging/dp/B00E4MRRXI) | (amazon.com) [59:00]

**Brand of magnesium L-threonate Peter uses**: [Magtein](https://magtein.com/?gclid=Cj0KCQiA2uH-BRCCARIsAEeef3lIWbZACznW4OHAMt9mEbKbtn_RHCePMa0o0l44ucJ3XzleihWNhRgaAvwLEALw_wcB) (magtein.com) [1:02:15]

On Amazon: [Magtein Magnesium L- Threonate – Bioavailable and 100% Water Soluble Magnesium – Clear Brain Fog, Improve Memory, Focus and Attention, Support Sleep and Mood – 30 Day Supply- 60 ct. Veggie Capsules](https://www.amazon.com/gp/product/B011M06YFG/ref=ppx_yo_dt_b_asin_title_o04_s01?ie=UTF8&psc=1)

§

## People Mentioned

- [Iñigo San Millán](https://twitter.com/doctorinigo?lang=en) [0:45, 5:45, 13:30, 19:45, 23:00]
- [Ron Tugnutt](https://en.wikipedia.org/wiki/Ron_Tugnutt) [2:15]
- [George Brooks](https://ib.berkeley.edu/people/faculty/brooksg) [13:30, 19:45]
- [Beth Lewis](https://www.instagram.com/bethlewisfit/) [17:15]
- [Euclid Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) [24:15]
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) [30:00]
- [James O’Keefe](https://peterattiamd.com/jamesokeefe/) [55:45]

§