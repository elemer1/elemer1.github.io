# #292 ‒ Rucking: benefits, gear, FAQs, and the journey from Special Forces to founding GORUCK | Jason McCarthy

**Source:** [https://peterattiamd.com/jasonmccarthy/](https://peterattiamd.com/jasonmccarthy/)

---

Jason McCarthy is a former US Special Forces member and the founder of [GORUCK](https://www.goruck.com/), a company specializing in rucking equipment. In this episode, Jason recounts his journey from military service to navigating the challenging transition back into civilian life and ultimately embracing the mission of introducing rucking to the masses. Delving into the significance of rucking in military training and its applicability to the wider population, he discusses the mental and physical benefits of rucking as a mode of training, provides practical tips for beginners, and answers frequently asked questions about packs, weights, footwear, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jasonmccarthy/the_Drive_public.png)

Play

#292 ‒ Rucking: benefits, gear, FAQs, and the journey from Special Forces to founding GORUCK | Jason McCarthy

#292 ‒ Rucking: benefits, gear, FAQs, and the journey from Special Forces to founding GORUCK | Jason McCarthy

1x15s30s

0:002:30:13

## We discuss:

- Jason’s upbringing and what inspired him to join the military [3:15];
- Jason’s path to becoming a Green Beret, his calling to serve, and staying true to oneself [10:30];
- About the Green Berets: their role in the military, the unique abilities, missions, and more [20:00];
- The mental and physical challenges of special forces training and selection [25:00];
- Rucking challenges as a Green Beret [37:00];
- How Jason trained in his off time and stayed mentally prepared [46:30];
- Jason’s difficult decision to leave the army, and the challenges many veterans face returning to civilian life [51:30];
- Jason’s struggles after leaving the army: loss of identity, feelings of shame, and the how he overcame a period of despair [57:15];
- The origin of GORUCK [1:10:30];
- The GORUCK Challenge [1:24:30];
- The company’s evolution from event organizer to manufacturing specialist spurred by the growing interest in rucking as a form of training [1:35:30];
- FAQs about rucking: packs, weight, rucksack vs. weighted vest, chest straps, and more  [1:38:45];
- Commemorating Normandy: GORUCK’s plans for the 80th anniversary of the Normandy landings [1:51:30];
- Footwear for rucking, and how GORUCK got into the footwear business [1:57:30];
- How to avoid the most common injuries from rucking, and the benefits of rucking for VO2 max, strength, and sleep quality [2:05:00];
- Advice for using rucking as a mode of training, and the advantages of rucking over other forms of training [2:12:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Jason McCarthy served in the US Special Forces from 2003-2008
  - He served in Iraq in 2007, where he was awarded a Bronze Star and an Army Commendation Medal
  - He also served in Europe and West Africa in 2008
- Jason currently serves on the Board of Directors for the Green Beret Foundation
- He is also the founder of [GORUCK](https://www.goruck.com/), which makes rucking equipment
- If you’ve been listening to this podcast lately or followed Peter on social media for the past couple years, you know how much he enjoys rucking and how much he speaks about it
- Peter wanted to have Jason on this podcast to talk a little about his story
  - Jason is not unique or alone as someone who has trained extensively using rucking
    - Anyone in the Special Forces has done that
  - How did Jason think about bringing this to the masses?
  - We’ll talk a lot about Jason’s background and decision to join the military after 9/11
- We talk about the training in the special forces, and how rucking has been used for many years in the military
  - How brutal some of the rucking training sessions are
- We talk about how Jason felt a little directionless when he left the military, and how this idea of creating a company that does what GORUCK does became a part of his salvation
- We answer some of the more frequently asked questions about rucking
  - Do you need a special rucksack or can you use just a backpack?
  - The difference between a rucksack and a weight vest
  - How to think about how much weight to use
  - Should you use a chest strap or a hip belt?
  - Differences in types of footwear, and what the pros and cons are around that
  - Common injuries and how to avoid them
  - The frequency you should be doing it when you’re starting out
  - How to train for longer rucking events
- In many ways this both a story of Jason and rucking, and it’s also a very practical how-to guide
- Peter has wanted to do this episode for a long time now because he gets so many questions about rucking
  - And Peter does not consider himself an expert
  - He also thought it would be really great to have this information all in one place
- Peter’s hope at the end of this is that everybody decides to do some form of rucking, at least once and a while

## Jason’s upbringing and what inspired him to join the military [3:15]

- People who listen to this podcast have heard Peter talk about rucking a lot over the past year or two
- Peter points back a lot to Jason and [Michael Easter](https://eastermichael.com/about/)
  - [Michael was a guest in episodes [#225](https://peterattiamd.com/michaeleaster/) and [#284](https://peterattiamd.com/michaeleaster2/)]
- We are going to talk a lot about rucking today, and Peter think’s it’s important for people to understand what it is and how-tos
- To put Jason’s mission in context, it makes sense to understand his journey

**Where Jason grew up and his background in the military**

- Jason was born in Ohio
- His mom was really young when she had him (age 18)
- They moved to Gainesville, Florida, and Jason was the unofficial mascot for the women’s tennis team (go Gators)
- He bounced around with his mom and was very close to her
- The military was not really a thing for him early on
  - His grandfather fought in Korea as an artillery officer, but he never talked about it
  - His uncle was a helicopter pilot, but Jason didn’t see him that much

**Was your dad in the picture?**

- He was and still very much is
- He’s still in Ohio along with both sets of grandparents
- His parents were in high school together
- Ohio was always a grounding thing for him, and his grandparents had an extraordinary amount of influence on his life

**In college, what did you want to do?**

- To give the timeline, Jason went to Bolles School in Jacksonville, FL
  - It’s a very competitive athletic school
  - High school was the hardest thing he’s ever done
    - The English department kicked his butt
    - He had 8 classes and would rather go back to the Special Forces Qualification Course than do a year of English at Bolles
- Jason played tennis and a little basketball
- Growing up, he was always into sports and being really active
- He didn’t know what he was going to do with his life
- He wasn’t good enough to play tennis at a big school
- He played D3 tennis at Emory in Atlanta
  - That was a great way for him to focus
- At Emory, he studied economics and art history
  - Both of his grandmothers were docents at the Dayton Art Institute in Ohio
  - Being in art museums was an important part of how he grew up
- He did well in college and graduated in May of 2001
  - He was very focused in college
- After college, he remembers applying to places that people told him he should: your bank, your consulting firm
  - At age 22, he didn’t know what any of that was
  - What do you do at Goldman Sachs or McKinsey if you’re 22?
    - Importantly, you pay your dues
- Jaysons explains, “*You have to figure out how to get into these larger organizations, and I didn’t know how to do that yet.*”
- So he went and traveled around Central America and backpacked a little bit, then came back and got a job working at a call center of a marketing firm in Dayton Beach on 9/11
  - Literally across the street from the racetrack
- That was the day that anybody that was alive remembers exactly where they were on 9/11

***For Jason, it was just this enormous sense of sadness and anger that led to rage, and as a 22 years old, military aged male, with no dependants, no attachments, he felt compelled to serve our country***

- Saying you want to serve, watching the night vision goggles (NVGs) and everything is in green on CNN is a lot different that actually signing up to go fight in a time of war
- Jason looked at all kinds of places: the CIA, the FBI, the whole alphabet soup universe
  - Those places take a long time to get into, and rightfully so
    - Even though he had just gone to college
  - The application process is long
- It was a time when everybody wanted to serve our country and you couldn’t just walk up, pick your branch, and become an officer
  - There was a line a mile long of young people that wanted to serve our country because of what happened at 9/11
- Now it’s 2003 and he had started working at a bank in DC and is still applying to places
  - It keeps not clicking

**What happened in that year and a half between 9/11 and early 2003?**

- He felt really down where he was in Daytona Beach and Jacksonville Beach, he felt really far away from what was going on
- He went and visited some friends in New York and being at Ground Zero just felt very communal in a positive way
  - It felt like that’s where the decisions were being made
  - It felt like that was just such an important place at that time, and he wanted to see it
- He went to New York in October of 2001, and you could smell it anywhere you were
- God bless the people that worked through that
  - Day after day, they just pulled bodies out of the rubble
- Jason still gets goosebumps when he thinks about the amount of sacrifice and the service that went into that day and then to the handoff to the military
- The military is kind of a family business, and you’re best served, if you’re familiar with what that looks like

## Jason’s path to becoming a Green Beret, his calling to serve, and staying true to oneself [10:30]

- Peter points out that in late ‘01 and most of ‘02 presumably anybody could walk into a recruiting office and join the Marines or join the Army or things like that (not necessarily special forces)

**Was that something you were thinking of or were you still thinking you wanted to be in the CIA or something?**

- [Johnny Michael Spann](https://en.wikipedia.org/wiki/Johnny_Micheal_Spann) died, and his story was very inspirational for Jason
  - He was the first casualty of the war
  - And he was in the ground branch or the paramilitary side of the CIA
  - He had come over from the Marines and he was chosen for that mission
    - This was the John Walker Lindh prison uprising where Mike Spann died
  - He had special language skills, which was why he was given that mission

***Jason realized what he wanted to do: he wanted to be on the tip of the spear serving our country***

- That led him down the path of the CIA, and it’s a long process
  - He went through almost all of it
  - He was 22 years old, a very active person, and he wanted to join the paramilitary side of the CIA
- The CIA doesn’t take people and turn them into soldiers
  - It takes very, very well-trained, highly experienced soldiers, and it plugs them into a different mission set
    - Jason didn’t know any of that
- There were lots of one-on-one interviews, and there was this guy interviewing him who finally told him, “*Look we don’t train… We don’t train people off the street to go do this. You need to go join the special forces, or you need to do something like that inside of the military first and then come and work with us*”
  - Jason kept asking how he could get this, and finally a year later he got the answer
- So he doubled down on the officer route again because he felt like that was what he should be doing
  - If you have a college degree you can go the officer route rather than the enlisted route (right out of high school)
- There are far fewer numbers of officers, and those numbers are determined by Congress
- The enlisted ranks can grow very quickly

**Fast forward and now there’s the buildup to Iraq**

- Jason knows what it felt like to live in America at that time
  - We started to become very divisive and all that, which put some strain on his thought process
- He joined up to go to Afghanistan and fight Al-Qaeda
  - But ultimately, you don’t get to choose, when you’re serving
- He remembers reading the [*Generation Kill*](https://en.wikipedia.org/wiki/Generation_Kill) series that came out in Rolling Stone, and it was written about the recon Marines that took Baghdad
  - That was March ‘03
  - It was later made into TV series, movie, and stuff
- He thought, “*Man, these wars are passing me by.*”
  - Little did he know that they would go on for so long
  - It just felt like he needed to do something
- So he bypassed the officer route and started talking to the Army
  - They had this program where you could enlist and they would guarantee you slots into the schools that comprise the special forces pipeline
    - The only caveat is you got to keep making it
    - There’s a lot of different schools in that pipeline
    - It starts out with basic training, and airborne school, and then a prep course, and then selection, and then another prep course, and then phase 2 and phase 3 and phase 4, and survival school, and language school and all sorts of stuff
    - And so you just have to keep making it through and then they give you that little green beret and you feel like you’re king of the world

*In the Army, they basically said, “You will be able to rise to the level of your capacity.”*

- And you have to get lucky
  - If you get injured, you get recycled
- Part of the calculus is that there are a lot of infantry options in the Army
  - You can go through basic training and join the infantry
  - When you’re infantry qualified, you can serve in the 101st
  - You can go to Airborne School, and now you can serve in the 82nd Airborne or whatever the case may be
- You can still fight and that’s what Jason wanted to do was fight
  - It’s odd because he was not a kid that started fights
  - He just wanted to fight for our country

**Where do you think that came from?**

*Did you talk about this with any of your friends in college? Did you get the sense that any of them felt similarly compelled, and if not, why do you think this was unique to you?*

- Jason has thought about this and doesn’t really understand
- Out of his high school class, there were 2 of them that joined the military
- Jason’s wife would join the CIA later and serve on the front lines in Africa
- There were 3 of them in a class of 150, 160 who all graduated in ‘97
  - They all graduated from college in ‘01
- In college, there was an ROTC program at Emory which Jason thought wa a little bit odd
- Both of his grandfathers revered the military
  - They had both worked really hard and been successful, both loved our country
- But one thing Jason doesn’t think his grandfather got right, he had this idea after [Black Hawk Down in Mogadishu](https://en.wikipedia.org/wiki/Battle_of_Mogadishu_(1993)) with Bill Clinton that, “*Nobody should ever serve in this man’s military.*”
  - Jason thinks that that’s a very knee-jerk and a very human reaction to say when you don’t like someone politically
- But you always need people to serve this country, or else everything that we hold dear crumbles

**In other words, the need for service should be completely nonpartisan?**

- Amen
- It’s not just military men, Jason felt compelled to fight
- He was a military aged male who had been active his whole life, who was predisposed to want to do hard things and challenges
  - And that’s not more important or better than someone who wants to become a teacher, because we need both
- Jason explains, “*It took all of the data points in my life that brought me to that point. I really wanted to do something special with my life.*”
  - It’s a scary time
  - How do you do that?
- Did he do that by joining company A, B, C, D?
  - No, that’s a stepping stone to something else

> “*You have to push on life and it’s going to push back and you have to learn what matters to you and what doesn’t. What are you going to do and what are you [going to] refuse to do, and for what reason? And you have to learn these things the hard way and everybody’s a little bit different*.”‒ Jason McCarthy

- It took 2 years after 9/11 for him to finally join
- It was not an immediate thing, there was a lot of cowardice baked into that process
- It was really hard, and then keeping it secret from his family
  - His mom cried at the kitchen counter when he finally told her he joined the Army

**Did your conviction waiver by the fall of 2003?**

- Peter notes that public sentiment had not fully shifted on Iraq then
- He asks if Jason was thinking, “*Hey, Al-Qaeda based out of Afghanistan, probably half in Pakistan at this point, that’s where the fight is. Not sure I understand this Iraq thing.*”
- Personally, Jason never really understood the buildup to Iraq
  - [WMD](https://en.wikipedia.org/wiki/Weapon_of_mass_destruction), he never really got it
- He now has the litmus test about **regret**
  - Regret is about the worst thing that you can carry around with you everywhere you go in life
  - Most of us know when we’re going to regret something, we just don’t listen to that voice that’s inside of our head

***Jason knew for a fact (politics be damned) that he would regret it for the rest of his life if he didn’t join up and serve our country at that time***

- It was hard ‒ he was joining up to fight, he was not becoming an officer
  - He was going through this enlisted route to become a special forces soldier
  - Intentionally going to fight on the tip of the spear
  - And we were about to start a second war on a new front
- What wavered was the thought, “*Oh man, did I make the wrong decision? I can probably get out of this and I can probably go try the CIA again. I can probably go cash in some favor from somebody somewhere and get an officer billet and be safer*.”
- Being safer doesn’t always spare you from regret
  - In fact, it’s usually just a way to delay what you know you need to do, the right thing for you and your path

***That was a really, really hard decision and in a lot of ways, it was an extremely selfish decision; but for Jason, for the rest of his life, he had to be willing to roll the dice at that time***

## About the Green Berets: their role in the military, the unique abilities, missions, and more [20:00]

- The main difference between [Green Berets](https://en.wikipedia.org/wiki/Green_beret#United_States_Army_Special_Forces) and the [SEALs](https://en.wikipedia.org/wiki/United_States_Navy_SEALs), the [Delta SEAL Team Six,](https://en.wikipedia.org/wiki/SEAL_Team_Six) the [Rangers](https://en.wikipedia.org/wiki/United_States_Army_Rangers) is, those are in essence strike forces in the Marines
- The [Marines](https://en.wikipedia.org/wiki/United_States_Marine_Corps) take the beaches, they secure the land, and then a bigger force comes in
  - It is speed and violence of action
  - They’re doing it with other marines

*The classic mission for the Green Berets that people will remember*

- Right after 9/11, a few ODAs (Operational Detachment Alphas, a team of Green Berets) went into Afghanistan into the boneyard of the Soviet Empire, and instead of fighting as the Soviets did (which is more assaulters, more helicopters, more whatever), instead of just throwing more of our own people at it, we linked up with the Northern Alliance and fought by, with, and through them in order to defeat the Taliban
  - And that happened in under 3 months
  - That is the sweet spot for what we in Army Special Forces Green Berets are synonymous

**How long had they been around?**

- June of 1952 (Korea)
- Vietnam was a lot of the similar work was done with local indigenous tribes, the mountain yards in Vietnam

**Green Berets are in 100 countries right now and they’re working with local forces**

- If you go to Africa, Green Berets are diplomats
  - Diplomats working out of the embassy is fine, but who’s really controlling that country is the military
  - You need military people to go and be diplomatic with those people, and we do

***We train up, partner forces, and then we get them to achieve our desired in state, our mission set***

- In the case of Afghanistan after 9/11, it was to overthrow the Taliban and do it with the minimal footprint possible
  - So you can send very few Green Berets in and God bless the [Air Force](https://en.wikipedia.org/wiki/United_States_Air_Force) while we’re at it, because having air cover and that’s a total game changer

**Where did you learn the diplomatic skills to be thrown into Afghanistan and realize that you have to now work with the Northern Alliance?**

- Peter points out that is very different from saying, “*Hey, this is our show,*” because now you were working as partners to do this together

*Was that explicitly taught? Was that part of the training or are they selecting for that as they’re weeding people out?*

- The guys who were one those teams were some of Jason’s cadre: Triple Nickel, ODA 555, 595
  - Those guys had just come back
- It was part of the selection process

***When you get into it, whether it’s the military or business or anything, so much is determined by who you serve with and what you are looking for out of the people***

- You need this strong culture
- The question, “*Do you play well with others?*” is very much part of the Special Forces pipeline, and there’s a language component
  - You have to be able to speak a foreign language

**How long did it take you to learn a foreign language?**

- He already spoke German because he had studied abroad and lived in Germany for over a year

**The culminating exercise of the Special Forces Qualification Course is called Robin Sage**

- It’s a mock war spread out all over North Carolina
- He jumped out of an airplane with 125 pounds on a rucksack between his legs
  - And then you land, it hurts
  - Then we rucked for 18+ hours (with 125 lbs on their back)
- They rucked to link up with what is a gorilla chief (a warlord)
- And you’re testing your ability to think in a gray area because the military is very doctrinally based
  - It’s black, it’s white: if this happens, you do this; if that happens, you do that
  - And this is a world where the warlords have malleable morals
- So you roll up and this is your point of contact and there’s an execution that happens within 4 minutes of you being there
  - This is in the training environment, but this is real
  - This is exactly how it happens
- You think, “*Well, how can you not lose your cool?*”
  - You lose your cool, you burn rapport; you’re done
    - You have sacrificed the mission because of your dogmatic principles that you brought with you from America
  - And if you don’t like that, don’t leave our shores and don’t take this job because you have to learn how to conduct yourself like that because you still need to work with them
- If you don’t work with the Northern Alliance, you’re going to lose against the Taliban

## The mental and physical challenges of special forces training and selection [25:00]

- Most people are familiar with what Hell Week is like for the SEALs and their underwater demolition ([BUD/S](https://en.wikipedia.org/wiki/United_States_Navy_SEAL_selection_and_training#BUD/S)), that they go through for months leading up to it
- Peter has 3 good friends who are former SEALs, and they’re very much like Jason, which is to say they’re not what people would expect stereotypically
  - These aren’t super aggressive individuals

**What predicts a person’s success going through that grueling series of physical tests?**

*And knowing what you know today, having the mental toughness you have today, could you physically go back and do it again?*

*What was physically involved in the most demanding part of that training?*

- You see this stuff on the Discovery Channel, and you think that that’s what it is
  - The yelling and the screaming (which plays really well on TV)
    - That part is laughable
  - It’s very short: hours out of years of training was yelling

***The hardest thing that you’re competing against is your own mind***

**Rucking is the foundation of special forces training**

- What Jason has done at [GORUCK](https://www.goruck.com/) is very much tapped into this (we’ve not invented this)
- What Jason learned, he owes to the people that taught him
  - It’s a tribal culture, and he’s grateful that he was able to share some time with them in that regimen
- He had no idea what rucking was when he joined the Army
- He started out doing stuff in the gym on normal stuff that you would do with the mirrors everywhere and people, and then he ran a lot thinking, “*Okay, I’ll cardio and I’ll get strong.*”
  - It’s better than nothing
  - You need to have miles on your legs and you need to be strong
- But that is not what this is about
- In Special Forces selection, ultimately to be a great teammate, you first have to be a great individual
  - So they test you really, really hard to make sure that you are the type of individual that has the ability to do really, really hard things and not quit
- You start out with 45 lbs dry weight: meaning water doesn’t count, any consumables don’t count
  - They weigh you when you get there

> “*Don’t be late, light, or last are the rules*.”‒ Jason McCarthy

- There’s a series of checkpoints that you get throughout the pine forests outside [Fort Bragg](https://en.wikipedia.org/wiki/Fort_Liberty) at a place called Camp McCall
- You’re just doing land navigation: route, after route, after route, after route
  - You’re plotting it with a map and compass (you have nothing)

*Are you doing this alone or in teams?*

- To start out, it’s always alone
- You have to be a great individual first
- You learn stuff like:
  - If you plot this route, you get water, you get vegetation (thorn bushes), and that’s going to slow you down
    - You would get there and the vegetation is so thick, you lose which direction you’re going
    - You get all turned around because you’re trying to save 2 miles of walking around this draw, this heavy vegetation next to the water
  - Your feet hurt, you’ve got blisters because you’ve put so many miles on them on uneven ground
  - Your feet get wet, which makes it harder

**What would be a typical distance for that type of navigation early on?**

- You’re doing it overnight, 5 points, and it’s going to take you 6-8 hours
  - It seems like forever
- The Special Forces Selection (SFAS) is 3 weeks, and you’re just doing this over and over and over
  - It doesn’t stop

**Did they explain why? Did they say there is a physiological reason why rucking is the foundation of what they do?**

- There was zero of that
- It was more, “*You’re here to be tested*.”
- It was silent
- There was a whiteboard in the barracks, and everybody’s in there, and the cadre would write the next hit time on the white board
  - That was the only way instructions were communicated

***The main point is if you’re looking for someone to give you more information or to help you solve your problems, you’re in the wrong place***

- This is not like the Army where someone’s going to walk around and make sure that you have everything
- They’re going to weigh your ruck at the end of your iteration and if you’re 44.9 pounds, you’re done; adios, see you later

**So you’re responsible for putting the ballast in the pack?**

- Oh, yeah
- There were rocks everywhere
- Walking around on pebbles after being out and about and your feet are sore
  - Not just your muscles are sore, but the skin is sore
  - You have flip flops on for the shower, and your feet are just shifting around and it hurts
- They would put a little bit of that gravel in a bag and use fish scales
- You can weigh your ruck, and if you’re dumb, you’re going to put 55 lbs in it
  - If you’re smart, you’re going to put 47 lbs in (just because scales are different)
- If 2 lbs is going to be what undoes you, you’ve got bigger problems
- You want to make sure you’re not late, light, or last

***It’s breeding this culture or autonomy and the selection process is weeding people out (self-selection)***

**How many people start at that 3 week selection process?**

- Hundreds at that time

*What’s the attrition?*

- Maybe 20% makes it

*Of the 80% who don’t make it across that 3 weeks, how many raise the flag and how many show up light (meaning they’re trying, but they fail)?*

- Most people self-select
- They give you a flare and you’d be out in the middle of your navigation at night when it’s cold or raining
  - The conditions of course matter
  - And when you see people popping up their flares, that means, “*I quit.*”
  - The cadre then comes and gets them and puts them in the back of the pickup truck and takes them to the “quitters fire”
    - Which they conveniently locate right next to the people still going through the course
    - They have the warm fire; don’t fall prey for that

**The folks who end up quitting, what do they end up doing?**

- They serve honorably somewhere else
  - Alaska
  - The 82nd Airborne
  - Straight to war
- These are the people that are showing up, toeing the line

***You can’t know if you have what it takes to go through this until you go through it***

**Predictors of success**

- You need to be physically fit
- You need to be able to carry weight
- Jason didn’t know if he could do all that, but he figured it out

***What it boils down to is there is no predictor***

- You can’t look at a lineup and pick out those who will succeed (the high school quarterback or statue of what physicality should be)
  - From Jason’s experience, those are the first ones gone
- Peter explains that when he asked this question to friends who are Navy Seals, that’s exactly what they said
  - If you were the all-American captain of the water polo team that looks like an Adonis, you’re probably the first one that’s going to quit
  - One of his friends mentioned that one of the toughest guys in their BUD/S was the most physically underwhelming person he had ever seen
    - 5’8” with a slight build, and English wasn’t his first language (he was Mexican)
    - He didn’t look imposing in any way, shape, or form
    - But the guy was mentally so tough
- It’s not just quitting, it’s performing
  - It’s not enough to not quit
  - You have to make your hit times, and then you have peer reviews to test if you play well with others
- You’re stacked ranked because they put you in groups at certain points, and if you’re consistently last, the cadre start pressuring you (you don’t belong here)
  - That starts to eat inside your brain until they’re giving you the words that you’re going to tell yourself
  - Then once you tell yourself for the last time, then you’re gone
  - All you have to do is say, “*I quit. I’m done*.”
    - Jason doesn’t even like to even use those words
- That’s the beauty of it: it’s the unknown and you have to push someone
- It won’t work in 2 days; it won’t work in 5 days
  - You have to push this over days and weeks and months because you’re just wearing down someone’s will, because it gets hard

**How old are you now, and how old were you when you did this?**

- Jason is 44 now and he was about 24 when he did this

**Could you do it again?**

- Jason would love to say yes, but the risk is much higher now just because injuries are so much more prevalent, and you don’t recover as quickly
- Peter is amazed because every one of his friends who were SEALs said the same thing
  - Your mind is clearly at least as strong as it was when you were in your 20s
  - The fundamental difference is you don’t have the recovery capacity today that you had in your 20s
  - They all said no for the same reason
- Jason has another buddy who was an enlisted Green Beret for a long time and then just went back and joined the Officer Corps
  - To do that for the infantry, he had to go back to Ranger School
    - Ranger School is 62 days
  - He did that and he’s a couple of years younger than Jason is
    - Yes, you can do that
- The volume of ocean work at BUD/S is really, really, really significant
  - They’re feeding you a lot at BUD/S
  - They don’t feed you in the Q course

**How much weight did you lose?**

- In certain phases he was down to 180, and they laughed and called him Skeletor by the end
  - He was tall and skinny
  - He had to work really hard
- He thought you were supposed to look like Arnold Schwarzenegger or Rambo or these guys who had played Green Berets

***What Jason found is that you can never be too strong, but you can definitely be too big***

- The more weight that you have on your body that’s nonfunctional, the more you have to carry around with every step, that makes you slower
  - And you don’t want to do that
- How do you become this kind of lean, super medium-sized, perfect specimen of efficiency?
  - Naturally it does that for you because you’re just **rucking** so, so much

**How were you being fed throughout these training activities?**

- [MREs](https://en.wikipedia.org/wiki/Meal,_Ready-to-Eat), boxes
- There was a little bit of time at the chow hall at Camp McCall, but not really
  - You just don’t have time for it

*What’s in the MREs?*

- A couple of thousand calories of stuff that’ll last 10 years
- They’ve gotten pretty good, and hunger is the best sauce
- Jason recalls, “*One of the phases we went dumpster diving and we found a whole bunch of stuff, and we ate it and it was incredible. It’s one of the best meals I’ve ever had*.”

## Rucking challenges as a Green Beret [37:00]

- The 45 dry was Jason’s foray into rucking
  - 45 dry was uneven and tank trails
    - Tank trails are basically sandy trails that tanks would go on, on bases
    - You can make better time on those because they’re not sloped and stuff quite as much
- We would’ve straight up ruck run competitions
  - You have to meet certain time standards on that
  - And that is just you
  - You have a we call a “rubber duck” version of a rifle that you have to carry with you (in your hands), which is just asymmetrical carry of several pounds for 10-12 miles
  - Those were foot races
- The 45 dry was a lot of miles across the pine forest
- Then you get into team tactics, and that means you’re carrying heavier machinery
  - Heavy machine guns, tripods, there’s more ammo
    - At this point, it’s blanks in training
  - There’s larger machine guns, there’s a saw
  - You’re dispersing the load a little bit across the team, but everyone’s ruck gets a lot heavier (call it 85 pounds)
- You’re patrolling much more slowly
- You’re learning what a wedge is, you’re learning how to do ambushes and raids, and you’re getting to an attack point and you’re setting your rucks down
  - You’re going lighter to attack a target, and then you’re back to your rucks, and then you’re egressing with your rucks

**Tell me about what the sacks looked like, because presumably when you’re carrying all of these trimmings, you’ve got to be strapping them on. What does the base pack look like?**

- The big green Army [ALICE pack](https://en.wikipedia.org/wiki/All-purpose_Lightweight_Individual_Carrying_Equipment) is enormous (80-90 liters)
  - It doesn’t go above your head, so it’s not like the big hunting packs or whatever
  - It’s kind of on your shoulders
- And then you also had what’s called “load-bearing equipment,” this kind of vest of sorts
  - It would have a belt on it where you would store other stuff (magazines etc.) which prevented you from using the hip belt on the ALICE pack

*You’ve got that big pack on your back, with or without a chest strap?*

- Without
- There was kind of a hip belt, but it’s not really a load transfer
- That’s also true in the real world of combat, you have stuff on your front that you need
- Using the sternum strap and hip belts and all this stuff
  - That’s fine if you’re going to insert over a mountain to get to your target and then drop your ruck
  - But if you’re carrying stuff on any type of an urban assault, that’s not in line with the priorities of work
    - Jason had his pistol
    - His chest rig was right on his chest
    - Magazines from his M4 were right there, and he’s not going to unclip his hip belt to then get at his ammo
    - You want to get that ammo as fast as you possibly can

*So all of that load is on your shoulders?*

- Yes
- Until you get into the 125 lb insertion and stuff, and at that point you’re doing everything that you can to carry that load
  - You’re trying to just change it up so that the blood can flow to different places
  - If you jack it down on your hips, great; it’ll give your shoulders a little bit of relief
  - And you jack it down on your shoulders, it’ll give your hips a little relief
  - The blood, you can kind of feel it coming back to life
    - It’s just such a great feeling as that happens
  - You’re just adjusting it constantly

**Tell us about the 125 lb exercise. You were parachuting with that pack?**

- It’s a team effort to waddle to the airplane, get on, and collapse back and sit down
- Then you hook up, and you’re jumping into an airstrip from 800-1000 feet (not too high)
- Your parachute is coming open immediately
  - It’s not a halo line, it’s a static jump, which basically means that your backpack at that time is your parachute, and you hook up into the side of the plane
    - It’s like what you saw in [*Band of Brothers*](https://en.wikipedia.org/wiki/Band_of_Brothers_(miniseries)) (one of the greatest series ever created)
  - You see them hook up and then as they’re going out, the parachute deploys immediately and your rucksack is off your belt, and it’s dangling in between your legs

*What’s holding it? Are you holding it with your hands?*

- No, it’s attached to your belt, and then you lower it down (there’s a lowering line)
  - Right before you land, you lower it down because if you don’t, the risk of injury (breaking your legs or whatever), the way that you would fall would be harder
- In a parachute landing fall, you land with 2 feet and then you kind of roll your legs over to disperse the force against your body (it still hurts)
  - You fall faster with all that weight and you land, you hit like a sack of potatoes
  - Jason remembers landing: he wiggles his toes and my knees like, all right, nothing’s broken
    - Good. Get up.
- Then you’ve got to get that thing on, and you’re getting on all 4s
  - You get it on and roll over like a dog and grabbing the back of your hamstringing to pull one of your legs forward and then pressing up
- Once you have your team, 1 person does not have a ruck on, they help you and then you help somebody else get up
- Once you get it up, it’s easier (it’s still really hard, but it’s easier)
- It’s a team effort to get down and then get back up, and it’s just excruciating

***If that’s going to be the hardest thing in your life, you’re also in the wrong business because that’s basically just physically demanding and some of the other problems***

**What was the physical part of that? How long did you guys have to go?**

- 18 hours and it’s just horrific
- It’s so slow
- It’s in a combat situation
- They have timelines you’re trying to hit (it really sucks)
- It’s North Carolina pine forest
  - There’s some hills, not hard balls (it’s not concrete)

**How often do you take the pack off to rest?**

- You just want to get there
- All of a sudden they simulate that there’s potential enemy over there; hide
- The last thing you want to do is stop because you just want to keep going and get there
  - That starts to eat away at you; it’s all you can think about
- The only thing Jason would equate it to is being cold
  - It just starts to consume your thoughts no matter what’s going on
  - If you’re that cold, it just eats away at you
  - And that pack at that weight just eats away at you
  - You can’t think tactically
  - Head on a swivel paying attention to enemies, it doesn’t happen
    - Commanders are susceptible to risk aversion (as we all are)
    - You need to have everything in order to be prepared for this mission
- There’s this other maxim which is “speed is security”
- If there’s greater assumption of some risk, if you have fewer things but you have greater speed, that’s a worthwhile thing to consider
  - How do you achieve mission success?
  - Do you actually need 125 pounds?
    - But that’s beside the point in training
    - At this phase of your training, you are in really good rucking shape
    - You are in really good shape of everything
- This is the beginning of a mock war, and they need to make sure that you are exhausted and not thinking lucidly
- They need to make sure that you can operate under conditions of extreme stress
  - They do that, and it’s very effective
- The thing is that when you go through that, when you are done, you know that you did something
  - You can’t cheat yourself
  - You know what you had to do to do it

***You get an amazing feeling of gratitude for the human body and the human mind; that is the gift that you get with these people that you share this sacred experience with***

- You don’t want to shortchange yourself of that in any way
  - You want the full “[red pill](https://en.wikipedia.org/wiki/Red_pill_and_blue_pill)” experience (take the red pill, do the thing, and watch what happens to your mind when you’re done)

**At this point, have all the people who are going to select-out done so?**

- Correct
- Almost nobody washes out by that phase
- The practicality of the Army has every incentive to weed people out as quickly as possible
  - They don’t want to keep people in a training pipeline for years only to find out at the very end, it costs millions of dollars to do this in addition to just wasting time
- The body has grown accustomed to this
- You start with 45 lbs dry, you’re going at various speeds to include shuffling and fast to over uneven terrain
- You’re getting up to 85 lbs
- You’re starting to know that this is really vital to your ability to operate and do this job
  - You start to take it upon yourself to do this, which Jason did a lot of

***Jason started rucking a lot (on his own time) because that was the thing that he needed to do to achieve mission success and pass this damn course***

**How much time did you have for yourself?**

- You would go through a phase, and then sometimes it would be a month until the next phase started
- There were so many people going through at that time, slots and phases and all this
- They just needed a lot of people to do this job
- So you have to maintain your degree of physicality, that’s part of it

## How Jason trained in his off time and stayed mentally prepared [46:30]

**What workouts would you do on your own when you were at home for a month to stay in shape?**

- On base, Jason would go and park at one of the gyms, and he would go on long rucks of varying degree of weight
  - There’s tank trails everywhere
- He would also do things to harden his feet and keep them hard
  - CliffsNotes version: start out with thin, thin socks, and if you develop any hotspots, wring those socks out or trade your socks and keep going
  - But, don’t let it develop until it gets blisters
  - The hotspots will eventually turn into calluses if you treat them correctly
  - You start getting blisters, and blisters have no bearing on your physical performance other than that they go straight to your brain like, “*This is so much pain. And you just start to think about it, and it consumes you*.”

***So you have to start to think about how you prepare your feet for this? How do I do this?***

*Jason would put a lot of miles in and then would do these mad dashes into the gym*

- He never actually loved going inside of the gym
- He would put headphones in
- This is back in the federal laden universe of when pre-game was really pre-game workout
- He’d go into the gym like a madman
  - He didn’t know what he was doing
- [CrossFit](https://en.wikipedia.org/wiki/CrossFit) started midway through the [Q Course](https://en.wikipedia.org/wiki/United_States_Army_Special_Forces_selection_and_training), and that was an interesting thing
  - It was sandbags and pull up bars and stuff like that
  - One of the guys came out, they had these 2 instructions: it was razor and blade (awesome call signs), and he’s like, “*Man, there’s this new thing called CrossFit, and it is awesome, high intensity training. And this is what you need to be the heroes that your country demands of you at this point. It is so good. It is so fast.*”
- We would do one CrossFit workout, and then we’d go on a 10-mile run or ruck, and then we’d come back and do another CrossFit workout
  - It was so simple
- You don’t cheat yourself because if you look around and see anybody cheating, you do not want to serve with them
  - That was motivation right there

***There was this culture of iron sharpening iron all the time, and you just live like that (animalistic in a good way)***

- On his own time, Jason swam a lot

**Jason dedicated himself to becoming the best he could be**

- He could control those variable but he can’t control unconventional warfare
  - He can’t control the problems that they’re going to give him
  - He can’t control his perfect reaction to this or that (it’s unknowable)
- He doesn’t know what these things are going to be, but he knows the best thing he can do is to set himself up for the optimum physical response that he has to anything
- At times he found some of the doctrinal things that they were teaching to be a huge challenge
  - Linear ambush versus an L-shaped ambush
  - Like why are we doing this and you’re asking that question?
    - It was like, why don’t you low crawl for the next hours until you come up with a good answer for that question
    - Okay, got it ‒ no more questions college boy

***Some of these were really hard, but Jason found that he could make it up to the team by just being in great shape, carrying more weight longer, and doing it with smile on his face***

- That was the variable that he controlled
- He took up a lot of **swimming** personally
- There was this hippie street in North Carolina called Hay Street where there was a yoga studio
  - Jason told nobody he was doing **yoga** every day when he wasn’t out in the field
  - He was doing it because he wanted to *not* get injured
    - Because the volume of work and reps, you can feel it (you’re getting sore)
    - It’s just a lot of weight and miles and reps
    - He wanted to set himself up for success
- He started getting his ass kicked by these older ladies at this yoga studio
  - They probably knew he was in the Army, but he was trying to camouflage that
    - He didn’t want to talk about it
- He was doing yoga to give himself a little bit of an edge
- At least he thought it was an edge, and half of the battle going into anything is to go in confident
  - If you’ve cut corners, you know it andt he cadre is going to find out
    - But you know it and that burrows inside your brain
    - Then when something doesn’t go your way, you start to play the “what if” game (so dangerous)
- Jason explains, “*If you’ve done what you can do and you show up ready, the outcome is going to be what it’s going to be. And so I was committed to that process and I really am grateful that I had that opportunity to see what I was made of according to a standard that I had nothing to do with establishing.*”

## Jason’s difficult decision to leave the army, and the challenges many veterans face returning to civilian life [51:30]

**When did you go into the field?**

- He joined in October of 2003, earned his Green Beret in May of 2006 (in 2.5 years)
- Peter remarks, “*That’s unbelievable how long that takes, right?*”

*Jason knows how much he owes*

- He’s grateful for the amount of knowledge he got from people who had gone and done amazing things with a human spirit that is burning so brightly
  - For them to share some of that with him throughout his training and just to breathe some of that same air
- He owes at least what they gave him and more
- That was sacred time for him
- It got even more sacred when he got to his team and they were deployed to Iraq in 2007

**That was a really nasty time in Iraq**

- A lot of guys and girls were dying in the surge that was going on
- Jason was not immune to questioning his own decisions and mortality and, “*Why did I do this?*”
- He then came back and served in [Stuttgart](https://en.wikipedia.org/wiki/Stuttgart), out of Germany
- Then we also went down to the [Islamic Republic of Mauritania](https://en.wikipedia.org/wiki/Mauritania) and did work by with and through some of the partner forces down there for a period of time, which was great
- He got out in late 2008

**What determines when you’re going to get out?**

- Jason’s initial contract was 5 years
- Jason remembers men who served in World War II storming the beaches of Normandy, most of them served for a couple of years, and then they came back and resumed a normal life
  - They started businesses or worked for a company
- Jason never had the opportunity to talk to somebody about what that was like
  - He wasn’t able to even ask the right questions if he could have
- He thought he would check the box “serve your country” and come back and be ready for McKinsey and Goldman Sachs

***He thought he would come back and be ready for his regularly scheduled life, but this service to our country it changed his heart in the process***

- That was the hard part: when it was time to transition out

**What were the options if you chose to renew that? Could you have stayed right there in the field?**

- Yeah, you finally start to get good at what you’re doing
- You’re not just trained, you’ve actually applied your training
- It’s one thing to train for war, and it’s another to fight in a war
  - Not just physically
    - The physical reactions are pretty straightforward
- The actual emotional contemplation of your own mortality and how do you function against that?
  - What are the quiet moments like at war when someone on another team dies or when your flag is at half mast because an IED struck someone in the next town over or whatever it might be
    - How do you process that?
    - And if you don’t process that, you don’t know what it’s like
  - Jason knows what that’s like and it’s not great
- He also learned how to draw strength from his team, and trust in his training and fight through it

**What do you think it says about processing that, if anything speaks to the relative differences that people experience when they leave the military?**

*In other words, when you think about whether it be PTSD or lesser versions of that, do you think that that has anything to do with how one processes grief in the field?*

- Jason thinks the book [*Tribe*](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=sr_1_1?crid=1Y2FN0Y8KQUWY&keywords=tribe+by+sebastian+junger&qid=1706037489&sprefix=tribe+by+%2Caps%2C90&sr=8-1) by [Sebastian Junger](https://www.sebastianjunger.com/about) is a fantastic book on this
  - It’s one of his favorites
  - [Sebastian was a guest in [episode #195](https://peterattiamd.com/sebastianjunger/)]
- Sebastian is a national treasure, the way that he brought so much of Jason’s thinking forward on this
  - It’s not necessarily the problem of the soldiers, it’s the problem of society and just being so disconnected
  - When you go from this culture that you’re living and breathing in with these guys that you love, you’re just so much a part of something that matters
    - You matter to them, and they matter to you at a very deep level
    - Your families matter to each other, and you’re motivated by the mission and service
    - You wake up that you’re doing good and it feels really, really good
  - When that infrastructure goes away
    - And there are other components to that infrastructure
    - In the military, everything’s taken care of: housing, chow halls
    - You’re in that, and you’re allowed to focus on being a part of the team
- Jason’s transition was extremely hard
  - You just lose a sense of identity, but practically you lose a structure
  - You lose a purpose, you lose friends

**How many of your brothers did you go from speaking with and seeing every day to not having contact with outside of the occasional phone call?**

- All of them basically
- No one else he was close to was leaving at the same time in reasonable geographic proximity
  - And that’s normal because you go back to where you are from

**He is now 5 years removed from the normal structure of society**

- Friends he had before have moved on, they’ve probably gotten married, had kids, been promoted
  - They’ve been at that bank for 5 years, and Jason has been doing something different

## Jason’s struggles after leaving the army: loss of identity, feelings of shame, and the how he overcame a period of despair [57:15]

**When Jason left the military, he felt like he was quitting**

- They went right back to Iraq
- Going on in Iraq, that’s not what mattered
  - What mattered was this team that we had and our ability to serve together, and we were safer and we were more effective and we were better able to carry out our mission together
- It’s natural that people come and people go no matter what, but to do it of his own volition felt like he was quitting on my team
- And that was a lot to process because then the practical side of, well, you’re giving up a job
  - You’re giving up an income
  - You’re giving up purpose, identity
  - You’re giving up the structure of: you wake up, you do PT, physical training in the morning, you go for a run or a ruck or you lift weights or you do whatever
  - There’s a lot of comradery that comes out of that, and you feel a lot better

**He started to reject all of the things that he thought he didn’t love about the Arm**y

- The structure of “*I’m never doing PT again, never going to wake up early again*.”
- He thought everything was going to be efficient, so optimized, and he’s in control of his destiny all the time now
- For that “freedom” he gave up a ton
  - The freedom to go it alone, what’s the point?
- It took Jason a while to rebuild a group, a team of friends or people that he wanted to do stuff with
- It took him a while to be vulnerable enough to let anybody in so he wasn’t just robotic about the whole thing
- He really didn’t want to talk about the Army at all

> “*I would run away from Army questions. Grew my hair out, basically had a series of, if not half-truths, just full on lies about no, I didn’t serve there*.”‒ Jason McCarthy

*Why do you think that was?*

- He felt like he’d quit and had this deep sense of shame
- Jason explains, “*Why would you get out when you’re winning the Super Bowl?*”

**Did you think about going back?**

- Yeah, very much

**Jason’s personal life was very complicated**

- He got married a year and a half into his time in the army
- They had grown up together, went to high school together, and he finally knocked that cowardice as well
- Things come in twos: he joined the army and finally told the girl he loved her
- The courtship was handwritten letters from basic training
- Jason told her what he was doing before he joined up
- We eventually got married
- She eventually applied to the CIA as a language instructor
  - They were like like, no, no, no
  - They made her a case officer
  - She went to the farm and graduated to become a case officer, maybe 5 days before Jason became a Green Beret
  - She was put on a smoking hot plane to Dartford to help work on that issue right after she graduated and then was posted in war-torn, West Africa, Abidjan for 3 years after that
- Jason was at Fort Carson, and then he was in Iraq and she was in West Africa
- Then he was in Mauritania, and she actually visited him there
  - They were married at this point

**Was part of the reason you left to be with your wife?**

- Yes, he was going to join Ground Branch
- He was finally going to bo back and join where [Mike Spann](https://en.wikipedia.org/wiki/Johnny_Micheal_Spann) had served in the paramilitary side of the CIA
  - Now, he knew the people and he brought the skill
- Jason cried when he was driving out of Fort Carson
  - You take a razor blade to your base pass, it’s on your car, it lets you slide through a certain entry point so that you don’t have to stop and do the same security as if you’re a civilian
  - He cried all the way through Kansas, going back home to Florida to get on a plane to fly to Africa
- We’re about to get on a plane to fly to Africa, and he was like, “*What is going on?*”

***He just did not foresee that this was a loss of something; it was a grieving process***

- At that point he and Em had been married for almost 5 years and never lived together
  - That doesn’t work
- The thinking was that she can’t join the Special Forces, but he could join the agency
  - Having at least 1 boss of a company is easier to coordinate, and that was naive as well
    - It’s really, really hard to make that stuff work, those tandem couples
    - It’s nice in theory, but really someone has to be willing to take a backseat or else both suffer, both are compromised in their careers

**What happened when you got to Africa?**

- It was not perfect; it was about what you would expect
- There was this skip to the end
- Satellite phone calls on top of a bunker with mortars coming in to his wife in Africa on meetings and working 100 hours a week by Wednesday

***They had just grown apart***

- He brought all of his baggage with him
  - Which was he’d given up everything to be there
- She was used to working and working and working
  - Case officers are measured in scalps, meaning how many people do you recruit that are assets
  - Just like anything else, the harder you work, the more you’ll achieve
- It was hard to incorporate Jason into that
- He didn’t have a job and couldn’t really work there
- The embassy had openings, for a janitor
  - He’d spend plenty of time cleaning the head and wasn’t above that
  - But at that point in his life, he did not have the self-confidence to go from being a Green Beret to being a janitor at the US Embassy in Abidjan
    - He couldn’t stomach that
- He was there for 2 months, and then he flew back to New York and was sleeping on a buddy’s couch, trying long distance stuff
- They met in Morocco
  - The things that you do to salvage something that’s in the crash and burn phase of its time

*There is a happy ending to this*

- She came back to the States, and we did get divorced
  - That’s the greatest failure of my life
- Years later, we got remarried
- We have a great family, and we’re very happily married and Jason can’t imagine life without her

**What’s the failure?**

- Divorce from the girl that he loved his entire life, not making that work

*Do you think it could have worked in that first version?*

- Hypotheticals are a very difficult thing to answer
- There are scenarios where it could have worked
- It was hanging on by a thread, and then it wasn’t
- The fact that it does work now is proof that yes, it could have worked
- Peter suggests, “*Maybe it’s possible that it works so well now because you both lost it.*”
- That could be true
- Jason was used to doing well at things
- He doesn’t want to rationalize something and say, “*Oh, it’s all good that this failure happened.*”

***The silver lining to it was that it made him a lot more compassionate and understanding that you don’t know what people are going through, so be kind***

- At the time he didn’t want to talk about it
- He stopped seeing people and became a hermit
- It was him and his dog, a country song, and a bottle of whiskey

***It was not a healthy phase in his life at all because he was out of the Army, he didn’t have a job, he didn’t have prospects for a job, and he didn’t have a marriage anymore***

**How are you supporting yourself?**

- He had a little bit of money saved up, and he didn’t have a lot of expenses

**Presumably you had the** [**GI bill**](https://en.wikipedia.org/wiki/G.I._Bill) **and you could have gone back to grad school. Did any of these other ideas entice you?**

- That’s what he did
- He went back to business school in DC

> “*It’s another case of I’m grateful to the American taxpayer for that opportunity because as you kick this off, it’s how do you process grief, and how do you do, what is that like? PTSD… but the time that bought me to help figure my stuff out. I had a lot to offer. I just couldn’t do it at that time.*”‒ Jason McCarthy

- Jason had a lot to offer; he just couldn’t do it at that time
- He has a lot to offer now and is really happy to offer that to our country, the world, the next generation
  - He’s very motivated to do that
  - That’s in no small part because the American taxpayer was willing to finance his school for a couple years and help him transition a little bit and gain a little bit more confidence
- Going through all of this, it starts to stack
- [Murphy](https://en.wikipedia.org/wiki/Murphy%27s_law) is around and he’s just striking left and right

**What Jason learned in SERE school (which is survival school) is everybody has a breaking point**

- No matter how tough you are, you will crack
- Everybody cracks
- It will happen, so that is a maxim for life, and to think that you won’t is just hubristic

*When did you realize you were heading in that direction?*

- It was just really, really bad
- Jason lost the desire to do anything
- There wasn’t some moment; he wasn’t suicidal in that sense
- He was just not well
- He has a lot of energy in life: he’s active, he likes to do stuff
- It took his dog (which Emily gave him); that was the greatest gift he ever got until they had kids
  - They had 1 dog that had been with her in Africa
  - Emily and him were still friends throughout this, oddly
  - She looked at him and she was like, “*You need him even more than I do. You can have him*.”
- You could maybe even argue that they wouldn’t have gotten back together without that happening because then his life was just not good
  - Living in a basement without any mission or purpose
  - He had nothing to do

**Jason asked a friend for help, which was very humiliating**

- Jason was the guy that doesn’t ask for help, ever
  - That becomes your shtick and that’s what the Army is, especially Special Forces, especially these Special Operations units
    - Yes, there’s a team component and tactically if you need help but you don’t need help solving your problems
    - Emotional problems, you don’t bring those to the team

***When you have to ask for help with emotional problems when you get out, it’s a very foreign territory, and it’s a very shameful thing***

- This is a problem that we need to take head on and say, “*There’s a lot of strength in asking for help, and you’re going to need it.*”
- You need to be part of something bigger than yourself
- You need to take care of yourself
- You need to do the things that were healthy in the Army that brought you this value
  - You need to still do those things: physical training, take your pick
  - It’s a very social organization: you get to know the people around you, and you develop deep and lasting friendships through doing hard things
    - That develops a lot of comradery, and you need to do those things and be active
- It’s very easy to fall into this state of, “*All that’s gone. I’ll never be as cool as I was, and I don’t know what I’m going to do with the rest of my life. I don’t have any transferable skills. This is just not what I signed up for anymore*.”
- You can go down that spiral, and everybody’s got a breaking point

**What year is this? How far after 2008?**

- It’s fast; it’s 2009
- He ended up starting school late 2009
- It was a full year of “not good,” but a year at that time felt like a long time
- School felt like an easy thing
  - He was like, “*Okay, I’ll go back to school, I guess.*”
  - It didn’t feel like progress to him

**During that period of time, are you picking up a rucksack again?**

- The funny thing is, the only thing that got him off the couch was Java, his dog
- Jason explains, “*I believe in community. The social health part of our lives is vital to everything that matters the most.*”
  - To him, you + dog is foundational ‒ it’s the bare minimum for a community
    - You +1, and for him, that was a dog
- The dog had to go out, he needed exercise, he needed someone to take care of him

***Serving someone else (in this case a dog) was a huge unlock for him to face the world again***

- It’s still very humbling to think about
- He’d just been this Special Forces soldier that felt like he could do anything with his team
- Now, he couldn’t do anything, and it took a dog to get him out of that state

## The origin of GORUCK [1:10:30]

**GORUCK was in the background of all this**

- Emily actually had the idea for it in West Africa because Jason had built her a “go bag” full of supplies and stuff for her to put in her car and one to put at her house
  - It was just in case
- A “go bag” is what we would put in the trunk of the Humvee because if our vehicle is disabled and we have to fight, we need more bombs and ammo and water and radios and batteries and all that stuff

**Do you have a go bag at home right now?**

- Yeah, it’s mostly medical stuff
- Some weapons ‒ what Jason is cautious about are these times where it becomes lawless and everybody jumps on I-10 or I-95 and then people are running out of gas
  - Whether there’s hurricanes or power outages or these things
  - How long does that last? Who knows?
- Peter agrees, “*I think a lot of people don’t remember what happened during Hurricane Katrina, which people probably remember there was a real delay on the part of the federal government in getting aid in there.*”
  - It was surprisingly short as to how long it went from no power, no food, no water to complete lawlessness and violence (4-5 days)
    - You could make the argument that that’s the most compelling reason for self-armament
    - It’s not the home invasion, in bed and someone breaks into the house
    - It’s the total societal breakdown that comes with a natural disaster or something like that
- Jason points out that you’re more likely to hurt someone you love in the situation where there’s a robber in your house
  - Just give them everything
  - These are only things; this doesn’t matter
  - The idea that you’re going to shoot someone cold in your hallway?
    - You have to be extremely well-trained, and you have to be able to target and discriminate and make sure it’s not a bad guy
    - Is this your first time in that kind of situation?
    - If so, you’re stressed
    - In the middle of the night, you’ve just been woken up
    - Go shoot with a heart rate of 160 sometime and see how you’re doing (it’s hard)
  - Those are not Jason’s deep dark fears
- The **worst case scenario** are the natural disasters and stuff like that

***Jason has a go bag and a med pack in the back of his truck, and his office is a safe house***

**When Jason and Emily were trying to figure out what he was going to do when he was in Africa**

- She suggested he go do the ruck thing
- They called it a go bag, go ruck
- They had a S-O-P (standard operating procedures) for what would go in their go bags
  - He tailored it to what they had there
  - He just used an extra bag that he had brought with him
  - It was for just in case
- What she meant was to take the Special Forces way of life
- Jason built a go bag for Emily’s boss and another person at the embassy
- He thought he could fill a year doing this
  - Upgrade people’s home security and teach them a little bit about what to do just in case

**The idea was born in West Africa but the business did not start there**

- There was a language barrier because everyone spoke French
- The import/export business of using diplomatic pouches to send stuff to populate people’s go bags
- Building a business from scratch in West Africa as a diplomatic spouse, your marriage better be on perfect ground, and you better be in there for the long haul
- The smash and grab year that Jason was going to have doing that would not have worked, but the idea endured

*Jason moved back, and he was just still searching for something to do*

- He needed a hobby, and this became a hobby
- But these bags were too military, and he didn’t want anything to do with the military
- He needed to make them less military but still awesome like the ones he had in the military
- He put an ad in Craigslist, New York City for a backpack designer, got a bunch of people that wrote in and found this couple that was in Bozeman, Montana

***That started a year and a half-ish process of working with them on a couple prototypes***

**What were the specs that you gave them?**

- Jason started out with an old assault pack that he had
- An assault pack is a stripped down version that you would take on an assault
  - When you think about assaulting in places around the world, doorways are narrow, and you’re in a stack to go into a room (meaning there’s 4 of you, and you’re as close as you can possibly get)
  - You can’t have these huge rucks because you’re going in and clearing the room, milliseconds are life
  - You have to have really small silhouettes of stuff and more what you would associate with an urban style backpack, not a big giant hiking pack or a big giant ALICE military pack or whatever
- They started with one of the assault packs and stripped away all the stuff that made it look too military

**Peter guesses he immediately realized that the weight had to come in the form of iron plates**

- When their mutual friend ([Jocko](https://echelonfront.com/instructors/jocko-willink/)) rucks, he’s using a more traditional pack where it’s got a pole on it and you’re basically dropping heavy plates onto

*When you were in the military and you were doing your own training, how were you loading up a pack, putting weights in the back?*

- Rocks and stuff
  - You would wrap them in something so that it would protect the interior lining
- Jason explains, “*Full story, I did not start GORUCK with this idea that rucking was going to be the thing. I did not think about it like that at all. This whole series is something that Emily and I have tapped into. It’s not something that we’ve invented or really created.*”

**Who were you thinking the customer was when you got a hold of these people in Montana?**

- This was the summer of 2010, Jason was in business school
- There’s this idea about [total addressable market size](https://en.wikipedia.org/wiki/Total_addressable_market) and you can go to retail and you get press and you can do all this stuff
  - Direct to consumer was still not quite what it is now
    - Amazon was not Amazon yet
- Jason was surrounded by some artisans and stuff in New York and he wanted this to be beautiful and simple as well
  - “*Simplicity is the ultimate sophistication*,” as DaVinci said
  - It’s also less to go wrong
- The summer of 2010 in between years at business school, Jason drove around to 48 states in his Ford Expedition with his dog, and he approached small men’s stores and other retail places about having them carry this
  - He drove to 48 states over 10-12 weeks
- It was painful ‒ you have these hopes and grandiose dreams
- He didn’t know how to do Facebook ads or Google ads, but he could get in a car and drive around to go meet people face-to-face and tell them the story
- He bought a sports rack to go on top of the truck
  - He needed extra space with so many rucks that we were going to sell
- He didn’t sell any rucks. None.
  - Every state, he was finding a new store
- Toward the end of his first year in business school, he started making a list of all the higher end men’s stores around the country
  - He did that only because of the price point of GR1

**We were making GR1 exclusively in America, and it cost him more than he wanted to charge everybody else**

- When he saw the price, he was like, “*Oh, my gosh. What is this? This is insane*.”
- But he never thought that founded by a Green Beret and made in China had a good ring to it

*What was the price premium to make it in America versus China?*

- 4x
- Jason didn’t cost it at the time, but that’s what it would be now
- They never made them in China
- He thought, “*Okay. Well, this is an advantage that I do have*.”

> “*One thing that Special forces teaches you is don’t fight fai*r.”‒ Jason McCarthy

- Never launch a ground war in Asia ([*The Princess Bride*](https://en.wikipedia.org/wiki/The_Princess_Bride_(film))); never fight fair
- Bring the Air Force with you to a gunfight, always. Why would you not?

***Use what is your unique strength that you have. Bring that to the fight.***

- Jason thought that it was him driving around and going and meeting people at these shops and convincing them of the story and the quality and all this stuff, but that was an unmitigated disaster
  - It just didn’t work

**Was this because of the price? Was it because people didn’t understand who would in their right mind want to buy a backpack to put weight in it to walk around?**

- There was no rucking at the time
- This was just an everyday, cool carry bag with a lifetime guarantee
- Peter doesn’t have a [GR1](https://www.goruck.com/collections/gr1) and asks, “*The GR1 was not one that was fit to have the slots of the weights in it?*”
- GR1 has a back panel with a zipper on the back of it
  - It’s a completely separate compartment
- Jason had an assault pack that was like that in war that was designed to put a hydration bladder there
- The problem with the hydration bladder there is that it’s this big giant lump in the middle of it and it’s very uncomfortable
  - It’s a very terrible position for it
  - But when we deployed, we would put our laptops in there
- It was designed to put a hydration bladder or a laptop there, and it became this travel bag
- Jason poured every dollar into GR1 inventory

**How much did it cost to make?**

- $295, and that was the price on the website
- At the time there was this idea of the **golden ratio** where you would charge 4x, and that’s wholesale pricing
- Jason split the golden ratio saying, “*Okay. Well, if it costs 200 bucks, how do you calculate cost?*”
- It’s a very tricky thing
  - Let’s say the direct costs were $100
  - Then you can charge $300, and we’ll be able to make some of that up direct, but he can still have some margins at $147.50 to sell to wholesalers
  - The wholesalers will be more about press, and direct is where there’s more margin (that was the thinking)

**When you toured 48 states in 2010, what size inventory did you have?**

- Probably 2,000 rucks

**Are people rejecting the idea of a backpack or the idea of rucking?**

- Rucking was definitely not a thing; it was not the start point for this (but we will get to that quickly)
- It was just, “*Hey, this is bombproof gear. Here’s this great story, and I think it would go well in your store*.”
- It might be that over time it ends up in Nordstrom’s (or in these higher end stores) because it’s quality and craftsmanship and all of that
- People Jason would meet would say, “*Uh-huh, uh-huh, yes*;” then it was just silence
  - Everyone loved the story, but it was an unproven brand trying to charge $300 for what people perceive to be a backpack that’s very simple and black
- It’s the anti-features because everybody points to all these features but Jason think’s that’s terrible because it’s more stuff to break
  - His thinking was, “*Show me all the stuff that it doesn’t have, and tell me why it’s going to last forever.*”

***That was very much against the grain of what people wanted to hear***

- They didn’t have all these crazy colors, it was black, it was a Model T Ford
  - That was not a compelling argument
- Stores would have to buy the inventory and educate people, and that’s really hard
- People were unwilling to take the chance and Jason understands that

**Jason poured all this money into it and sold none**

- He’s back in business school, still being floated by the taxpayer
- He was thinking, “*Man, I got to do something.*”
- There was a partnership with an obstacle course racing company called [Tough Mudder](https://toughmudder.com/)
- This was part of the longer journey of finding partners and working by, with and through them to get the word out on what GORUCK is
- Jason started showing up to these Tough Mudders, and this is when that market was really hot
  - They were getting 10,000 people a weekend to show up
- Jason started the first ever Tough Mudder in May of 2010
- He thought it was going well, then nothing
- The next one wasn’t until the fall out west
- Jason put together a team, and we stuffed the rucksack with bricks, and we wrapped those bricks with duct tape
  - We did Tough Mudder together as a team
  - He brought together a bunch of his old buddies that he’d served with to do that first one

***That was fun; that was how he got back into rucking***

- Then people were like, “*Wow, I want to do that.*”
- One thing led to another and he thought why not do something based on Special Forces training but doesn’t require this huge obstacle course

***So he created an event called the GORUCK Challenge, which basically became*** [***Fight Club***](https://en.wikipedia.org/wiki/Fight_Club) ***with backpacks***

## The GORUCK Challenge [1:24:30]

- First it was led by Jason, and current and former Special Forces
- It was, “*Hey, meet me at 10:00 AM at the beach in San Francisco. Details not forthcoming*.”
- He was doing this through Facebook, and Tough Mudder had it on their site for a while
  - They partnered with them for about a year until they became a little too successful or something

**The hardest thing to do is go from 0 to 1**

- You have this great thing, and how do you break through?
- He had so many other partnership talks and US manufacturing partners and all this stuff, but this was the one that ended up working because it gave him a platform to fall back on what he knew
  - How he had been trained
  - Again, it goes back to, “*How much I owe*.”

**You would just travel around the country spontaneously popping up for a GORUCK Challenge?**

- Like [Tyler Durden in *Fight Club*](https://en.wikipedia.org/wiki/Fight_Club) with backpacks

*The overhead was him flying out there, and the business model was pretty simple*

- The cost of the challenge was half the price of the rucksack, and you got to keep the rucksack
  - If GR1 was $295, the price to enter this event was $147.50 and you got to keep the ruck
- The first ones, Jason brought your bricks for you, and he brought duct tape

**How many people are showing up to these?**

- 20 for the first one
- 6 fore the second one, and he had to beg 4 of those people to show up
- He was taking pictures, and people were really responding to this because it was a very challenging thing
- There was no published route, there was no published course, there was nothing

**Typically, how long would a route be when you showed up?**

- It started out as 5 hours
  - That proved to *not* be long enough
- The “[Tough Challenge](https://www.goruck.com/pages/goruck-events),” which was our original event, ended up settling in at about 10-12 hours
- We have all different lengths now
  - There’s a 24-hour version
  - There’s a 3-hour version and a 6-hour version

**How is the weight determined?**

- We’ve kept it the same since the beginning
- If you’re >150 lb, you have 30 lb
- If you’re <150 lb, you have 20 lb
- In the early days it was bricks, so 6 bricks or 4 bricks, and you had to put those in the rucks
  - It was Jason or the Special Forces cadre going along with the group the whole time; there was no separation
- Peter remarks, “*That’s not a lot of weight, but it’s enough weight that for somebody who is not necessarily in great shape, this is a hard thing for them to show up and do.*”
- Jason explains that it’s a lot more weight when you’re doing “Indian runs”
  - You line everybody up in rows of 2s, you slap the ruck of the person in the back, and they sprint to the front
  - 10 miles of that

*That’s what you guys do for the whole challenge?*

- That was part, and then you’re stopping along the way and doing physical training
- It gets a lot heavier when you start ripping logs out of forests and carrying it down 5th Avenue

***These are not things that people show up to do when they just want to start to get in shape; this was meant to be an extreme rite of passage that you would show up and do***

- The same way how you would get confident ‒ you earn it

>  “*You do really hard things and you show yourself what you’re capable of because you can’t cheat yourself*.”‒ Jason McCarthy

- People were just blown away
- When they were done, people are just exhausted and so proud of themselves
  - They’ve made friends with these people that they had nothing in common with

**How many of these were you doing a month?**

- It was every weekend
- He would post the start time the week before
- He would go somewhere, do a route recon on Friday
  - That was hours and hours
  - Where am I going to find a log?
  - Where is all this other stuff that I can do?
  - What’s closed? What’s open?
- Jason got smart and started telling people to bring their own bricks
- Say it started at 10:00 on Friday night was the first one
  - 12, 14 hours later it’s noon, and then you can start at 10:00 Saturday night as well
  - Then you’re going overnight, and then you’re done Sunday morning

*The challenge would be back to back?*

- Oh, yeah
- 2 different groups
- Jason is sleeping under a bridge or in a parking lot somewhere for a few hours between the events
- The greatest pep talk in the history of GORUCK is the one that the Cadre gives himself between those 2 events because it’s brutal

**How many guys did you have doing this with you?**

- Hundreds
- We’ve put on 10,000 of these since 2010

*How many of you were instructors that were going to do both the Friday and Saturday?*

- It was always just 1, just Jason
  - Until you training somebody else, so then you have 2 of you, but they have to do and shadow and be shadowed, and then they can do it

**Part of the thing is you can’t believe how much people are willing to do**

- When you’re transitioning out of the military, you think that you have this exclusive license to doing really hard things

***What Jason has found is that there’s people all over this great country who really want to do hard things***

- They just didn’t choose the military and that’s okay
  - Jason wouldn’t have chosen the military either without 9/11
- Jason explains, “*You’ve got these people and man, the human spirit just burns so brightly. It’s such a gift to get to spend that time around these people. It’s just magic, and you get to see it, and you get to feel this transformation that they have as individuals and as a team.*”
  - It works because it’s in the human terrain
- Jason was with these cadre who are well-versed in the human terrain and pushing people and training people and getting them to where they need to be as a team
- He was doing this all over the place, and then, more of us were doing it
  - And more and more and more
- It got to where we were running over 1000, 1200 a year of these
- Then, the pandemic crushed a ton of it

***Rucking came in as an important part of this because it was a rite of passage***

- It’s like you’re never going to want to do this again
- But people started to say, “*Well, how do I train for this?*”
  - Jason answered, “*No, it doesn’t matter. Just show up and take your licks.*”

**Of the people who were showing up, were most people completing it?**

- Oh yeah, that was the point

*What was the feeder population? Were these runners primarily?*

- There was a very front page prevalence of Special Forces in the media, and that’s what they tapped into
  - People wanted to be around that
- The Afghanistan surge under Obama was 2010 or 2011, and Jason was leading a GORUCK challenge in Boston when Bin Laden was killed
- Peter is wondering about the types of athletes coming in to be able to do something so extreme without specific training for it
  - He doesn’t think he could have done this on his first day of doing a ruck, simply because of the amount of discomfort due to how foreign it was
- The beauty of it was that it was a team event
  - If Jason saw that you were struggling with your ruck…
  - One of Jason’s favorite learning points was they would get these big strong dudes who have egos and think they should be the strongest and carry all the weight and never show weakness

**In one event in Key West, we were moving toward index (12 hours in), and it’s brutal and hot**

- He saw a guy unable to keep up with the team and asked him to give that person his pack
- The guy was like, “*Nope, a real man doesn’t give his pack up.*”
- Jason explained to him, “*There’s 2 courses of action here. The first course of action is you’re going to give up your pack, you’re going to submit to the speed that the team needs to go on to get to the index point now. We’re going to finish happy. We’re going to have beer when we’re done. It’s going to be a celebration of life. The human spirit will burn brightly. The second is you and your ego are going to quit this event right now, and for exactly 60 minutes, not a minute less, not a minute more, this squad is going to do squad pushups on this sidewalk until it runs like the River Nile with their sweat. If you want to inflict that upon your team, 12 hours in, that’s what your choice is right now.*”
- He gave up his pack, someone carried it for him, and we got to the end
- Jason got a note after him like, “*Thanks so much, because I needed that in my life*.”
  - Imagine that, he’s one of us, that doesn’t have feelings, that has a hard time asking for help
  - He thought he was checking the box on something that was another mud run, but he got a lot more out of it

> “*That is a great gift to be able to give that to somebody and to do it with a purity of heart. That was not about me. That was about him and his team, and that brought them together*.”‒ Jason McCarthy

- Then they were up all night partying in Key West, and it was a ton of fun

***The thing is those whom much is given much is expected. Those who can carry more weight, they do carry more weight***.

**How did you choose who was going to carry 60 lbs? (his 30, plus their 30)**

- Jason didn’t care, the beauty of it is that for the team to optimize, they had to rotate it
- The **log** was a great instructor too, because they would get the log and they would immediately reject it, because it’s very heavy
  - They’re expecting this to go on for a very little bit of time
  - They would do it
  - And what you have to realize over time is that you can’t keep getting the strong people exclusively to carry this, because they have a breaking point too
    - They will get exhausted
  - You have to rotate people with frequency
- Jason would let them fail for a little bit, because pain is the greatest teacher of them all
  - Then, they would start infighting, but Jason would never let that continue
  - He would explain, “*Look, the first hour, you’re going to fight it. The second hour, you’re going to finally start to develop a system that works. And the third hour, you’re going to be ready to carry this thing for the rest of the event.*”
    - They’re like, “*What?*”
    - They’re 20 minutes in, thinking that they’re about to put this down and Jason’s like, “*No, no, no*.”

**How much does this log typically weigh?**

- They’re big and they’re always gnarly
- It’s whatever we could rip out
- They’re not telephone poles
- One side is way heavier with roots and nasty stuff right into your shoulder
  - There was a lot of learning points and teaching points, and it was very extreme and it felt great
    - Jason felt like he had a mission and purpose again, and that was fantastic

***Serving others and giving back with what he had learned about building teams, personal endurance, and overcoming ‒ teaching that to other people was very, very rewarding. That was the foundation.***

## The company’s evolution from event organizer to manufacturing specialist spurred by the growing interest in rucking as a form of training [1:35:30]

- Peter asks, “*It wasn’t until COVID that, basically, the idea of using rucking as the training came about, if I heard you correctly?*”
- No, it started much earlier than that
- People started asking how to train for this, and they started to self-organize and form ruck clubs across the country
- Jason thought, “*That’s insane. Who does that?*”
  - Meanwhile, he used to do it
- These ruck clubs become social clubs as well
- It finds out that people are looking to be part of something bigger than themselves
  - They want to find friends that want to go do stuff
  - Not everybody just wants to doom scroll
- Going for a ruck, then grabbing dinner with the people that you know, that you talk to about your life and what matters to you, and you listen to what matters to them, that stuff is hugely important
  - Those are the lessons Jason learned in SF (in Special Forces), and that’s just what we saw from the community
- It became this groundswell of people who wanted to self-organize
  - Those are easy tea leaves to read, and we started building around that

**At this point, is the company an event running company that provides a pack?**

- Yes
- It took 2.5 years of figuring out how to develop the packs
- We had internal sewers
- We have a repair department called “Scars,” which is where we offer our lifetime guarantee
- We have the DNA of a manufacturing company as well
- We just also have the energy of our own events company
  - It’s kind of a weird thing that we still wrestle with a little bit
  - Jason can’t imagine a world without both, but it’s unusual
- Usually, a manufacturer will sponsor a race or an event series or whatever
  - We developed both, from the ground up, out of necessity, and it sort of turned into, “*How do I train for this?*”
  - And then, it was, “*What else can we do?*”
- We started to make longer events, harder events, heavier events, lighter events, and shorter events
  - Because you don’t always want a 24-hour event like this or a 12-hour event like this
- Then it started to be, “*Okay, well, let’s live that life.*”
- We developed the [Rucker](https://www.goruck.com/collections/training-rucksacks), which was a pack specific for rucking
  - Remove the laptop because you could put a ruck plate in the laptop compartment
  - What we found was, if you do that at a GORUCK challenge and you drop your ruck and the iron meshes with that zipper right there, it’s going to break it
    - No matter how well we build it, you can’t do it
    - The zippers are the weak part in almost every piece of gear, no matter the gear, so we always use the best zippers
    - But you can’t endure a crush load against a zipper like that
  - We removed that as a failure point for rucking and training, and the Rucker was born
- Then, we had cast iron plates
  - We’ve been messaging that for a while, almost decade

## FAQs about rucking: packs, weight, rucksack vs. weighted vest, chest straps, and more  [1:38:45]

- People who’ve listened to this podcast or heard Peter talk about it become a real fan of this
- Peter has talked about how, sometimes, he almost don’t include it in his tally of weekly exercise
  - If he’s adding up the number of hours in a week that he’s exercising, it’s almost an afterthought to include the ruck
    - Even though the ruck is a great source of exercise
- He talks about how he does it for his mental health, because it’s the only thing he does without any other input
  - If he’s on the bike, he’s listening to a podcast
  - If he’s in the weight room, he’s listening to music
- Rucking is something where he’s decidedly never carrying a phone
  - So either he’s alone in silence or he’s doing it with a friend or his wife
- Peter has really fallen in love with it, and he has yet to bring somebody on on a ruck that hasn’t either fallen in love with it or come to appreciate why this is a great thing to do

**Peter gets a lot of questions about rucking**

*Do you need a rucksack?*

- Peter and his wife have a Ruck 4.0, tons of weights to slot in all different permutations
- But for somebody who doesn’t want to spend $300 on one of these, can they just use their own backpack
- Yes
- The last thing Jason ever wanted was to be the [Willy Loman](https://en.wikipedia.org/wiki/Willy_Loman) of backpacks

***He thinks people should be more active and try whatever you’ve got***

- Put 10-20 lbs in your backpack (a bag of rice, water, whatever) and go walk around your neighborhood
- Cinch it down and make it as tight as you can
- Jason is reluctant to tell people to put too much more weight in because that’ where it gets more uncomfortable
  - And once you add too much more weight to something that’s not built for rucking, it becomes a bad ride and you’re like, “*I hate rucking*.”
- You can find a bunch of people who hate rucking
  - It’s usually people that served in the military, that carried a ton of weight, who got no sleep, and had to take fighting positions when they got there
- Jason is talking about 20 pounds, 30 pounds for pick one: your mental health, physical health, social health (if you’re talking to your wife or a friend or a loved one)

***Don’t give yourself any excuses that you have to go buy something, because you have what you need to go get started right now***

- Peter’s kids use their backpacks and school books

**What guidance do you offer about some of the parameters around weight?**

*Let’s start with a person who is not that fit but they want to give this a try*

- This person could put in 10,000 steps, but that’s about the extent of their fitness

***Try 20 lbs for a couple miles***

- It’s one of those things where this is completely different from running
- If you are walking as part of your daily life, it is the same movement
  - You’re not doing this thing where there’s all this different gait and new things with your Achilles, the way that you land or foot strike or heel strike
    - It’s so much simpler than that
- It’s just carrying a little bit of weigh, and the thing is that your shoulders will get a little bit sore the first time
  - That’s good
  - That’s how they get stronger

***This should not be some crazy thing where you start out with a third of your body weight or more***

- Start out simply, go for a walk
- It’s so great to be outside
  - The sunshine and the wind and all of that, those are additional benefits
- If you want to start on your treadmill, that’s fine
  - You’ll get the physiological side of it at that point
- If you want to go a couple miles, great, go a couple miles, come back and try it again tomorrow
  - You’ll get a little sore

*What kind of guidance would you provide as you escalate the weight and/or if you’re a person who’s already kind of fit and wants to add this in?*

- There are some variables here:
  - The speed that you ruck
  - The weight that you carry
  - The elevation
- You have to listen to yourself and also consider what are your goals in this?
  - If you’re training for a hike or a hunt
  - This is a great thing to do to baseline your fitness

***There’s no reason to go out of the shoot too hard***

- Jason started out with minimal packs in basic training
  - It was 45 dry, and relative to his weight (200 lbs), that’s still less than 25%
    - And he was in really good shape otherwise
- If you come to Jason’s driveway and work out or go on a ruck with him, he doesn’t care how much weight you carry

*You need to consider your specific situation*

- If you’re used to carrying weights
- If you’re used to squatting a lot
- If you’re doing things that are going to prepare you to carry weight, then try 30 or 45 lbs
  - If you’re really fit
- There’s no shame in starting out with 30 lbs
  - Go for a couple miles
  - What’s the worst thing that happens?
    - You realize you want to make it a little harder

***Getting out there is part of the joy, without the pressure of how many lbs your carrying ‒ just simplify it all***

**What is the difference between a rucksack and a weight vest?**

- Peter used to us a weight vest to train for hunting trips, but he knows Jason has thought a lot about the ergonomics of this
- Jason remarks, “*It was fun to see you and* [*Dr. Huberman*](https://www.hubermanlab.com/about) *going back and forth on this a little bit. I think he had spent more time with a weight vest, and that actually inspired* [*Michael Easter*](https://eastermichael.com/about/) *and I to go even deeper into weight vest versus rucksack*.”
- An important thing is that weight vests are vital to the success of soldiers and police officers and those who are in those kinds of dangerous jobs
  - There’s a component of train like you fight
  - You need to be comfortable in a weight vest, if your job requires you to wear a weight vest to do things (like stop bullets)
- However, people that wear weight vests have typically **terrible posture** because of it
  - It is just kind of a compression downward, that doesn’t really open up in order to breathe better
    - You have to create this cavity of air in the front of your belly, which the more fatigued you get, the more that you do that when you’re wearing a weight vest
  - So, you’re kind of hunching over a little bit
  - It’s not good for what you want your spine to look like
- You have to “own your breath to own your pose,” and rucking is no different
  - If you can own your breath, it means your shoulders are back and you can take a really deep breath while you’re rucking
- The weight vest also looks a little different than a rucksack
  - You can’t quite blend in quite as well
  - This is getting into the aesthetics less than the physiological response
- The rucksack is more comfortable, and Jason says that from the standpoint of he can put his shoulders back
  - It’s posture corrective for him, it rolls his shoulders back when he cinches it down tight
  - This works well to maintain solid posture that is the opposite of lower back or neck curvature forward

**Thoughts on using a chest strap**

- One of the tings Peter remembers from when they went out for a ruck last year was that Jason didn’t use the chest strap that comes on the rucksack
  - And he wasn’t using the hip belt
    - Which is an attachment you can by for $20 or something
- Peter has played with both of these and he also prefers to to use the chest strap
  - He finds it makes it harder to breathe, and he prefers to have it wide open
  - This means there’s a little more pressure on his shoulders, but it’s a worthwhile tradeoff because he has unrestricted breathing
- He does quite fancy the hip belt

*Is it a throwback to your time in the military that you don’t use a chest strap or hip belt?*

- Jason did grow up rucking without a hip belts
- The fit for him, when you start to transfer the load around your hips, it reduces some of the stability he has with the weight and the way his shoulders go back and the way he breathes
- When you get into very heavy loads (hunting style or heavy military ammunition), he has found there’s a lot of value in alternating how you’re doing it
  - Because you want the blood flow to go certain ways
  - Even when it’s a shoulder-only carry, there’s little tips and tricks (flex your shoulders around just a little bit) so you can get the blood flow to go there a little bit more
- Jason doesn’t use it
  - It’s not a comfortable thing for him
  - For the load to transfer, it can be at odds with how much you cinch the rucksack down
    - Peter agrees, if you want it to be cinched tight on the hips, you can’t cinch it down much on the shoulders
- Hunting packs are enormous and they’re really long
  - They’re built to carry really heavy loads

***Jason prefers the feeling of the shoulder carry***

- He was taught that you want the pack high and tight on your back to make the weight stable

***Whatever you’re using, you want it to be stable***

- The more stuff is shifting around inside of your ruck, if you step on uneven ground, then you have the opportunity to tweak your back in the wrong spot

> “*I really like that feeling of stability high and tight on my back, just right up on my shoulders*.”‒ Jason McCarthy

*Would you suggest that folks muck around with this and figure out what feels best to them?*

- Yes, absolutely
- The idea of the resistance side of rucking starting with your shoulders and going all the way down to your feet, you’re starting that resistance with your upper body
- And when you transfer all the load to your hips, you’re starting it much lower on the body
- It’s different strokes for different folks, and people like it certain ways depending upon how the fit is
  - Especially at lighter loads, people who are used to carrying book bags or they’re used to doing these types of things, you’re used to carrying that on your shoulders
    - You’ve already prepared yourself
    - You’re walking in part of your daily life, you’re training for this, you’re ready
- There’s this idea of ride that through, and as you get more weight, say you start to get up to 45 or you start to maybe max out at a third of your body weight, it puts more pressure on your system, your technique, and you might want to transfer the load or you might want to do it a little bit differently
- If Jason does really long, really heavy rucks, he will occasionally use the sternum strap in the front, because it’s going to take some of the load off his shoulders, which allows the blood flow to come back to his shoulders and his hands
  - That then just gives him that little break, and then he continues with the mission

## Commemorating Normandy: GORUCK’s plans for the 80th anniversary of the Normandy landings [1:51:30]

**Nowadays, how many events do you typically lead in a month or in a year?**

- Jason doesn’t lead a lot of events
- He has people over to his driveway every weekend when he’s home
  - People come over from the community
- Or we run events
- What it means to be a GORUCK event is certainly broadened
- We’ve decentralized it a lot
  - Bring the people together in the parks
  - Bring the people together in your driveways
  - This doesn’t need to be so complicated
  - Go for rucks wherever you want to go
- He probably only leads 20 events a year now

**Did you lead an event in Normandy?**

- He did, and we’re going back next year in May and June for the 80th [anniversary of [D-Day](https://en.wikipedia.org/wiki/Normandy_landings)]
- We went for the 75th
- We have different kinds of events
- The one that Jason and his wife did together was a 75 km ruck (about 50 miles)
  - It started in [Utah](https://en.wikipedia.org/wiki/Utah_Beach) and ended at [Omaha](https://en.wikipedia.org/wiki/Omaha_Beach)
  - It passed through all the cities you saw in [*Band of Brothers*](https://en.wikipedia.org/wiki/Band_of_Brothers_(miniseries)) ([Pointe du Hoc](https://en.wikipedia.org/wiki/Pointe_du_Hoc))

*Did you do it on the beach? Or did you do it above the cliffs?*

- You can’t do it on the beach
- You’ve got to go around to the cities and around an inlet
- Then you come up to the German cemetery, almost at dawn
  - Which is black tombstones
  - You walk around, and it’s one thing to know that we were on the side of right and justice

> “*God bless those men and everybody in our country that had any part in that war, because we did right*.”‒ Jason McCarthy

- You walk around that German cemetery, and you see 16, 17, 18-year-old kids that are buried there
- It’s just another perspective that you get from seeing that, especially that far in

- Then, you go to Pointe du Hoc, and you see where the Rangers scaled that wall against those machine gun nests
  - The amount of sacrifice that’s gone into this
- From there, we hand railed the final piece from Pointe du Hoc to Omaha, and it took us to Omaha
  - This is Jason’s favorite ruck on planet Earth
- The American Cemetery is there
  - That’s the most American place on planet Earth
  - Jason gets goosebumps thinking about it
  - To see what they had to endure for that to happen is mind blowing
  - Think not only of their passing, think of the glory of their spirit
  - It’s hard when you’re there because it’s a very solemn place
  - But man, there’s a lot of glory of a lot of spirit there

*They will do an 80th anniversary there ‒ they’re running a lot of different events*

- - There’s an 80 kilometer (or roughly a 50 miler), probably the same-ish route
  - There’s a 26.2
  - We’ll put on some 12 milers, do some commemorative hero workouts
  - We’ll do some of our challenges of different lengths
  - We’ll put on some scavenger hunts, we’ll put on some stuff for the kids
  - We have 2 chateaus right on the beach, pretty close to Pointe du Hoc, and we’ll be running stuff out of there
  - We have this really crazy long endurance event as well called [GORUCK Selection](https://youtu.be/KCtxMnO142M), which is patterned after Special Forces Assessment and Selection
    - It’s the toughest endurance event in the world
    - It’s pass rate’s sub 1%
      - It’s the only event where we try to get people to quit
    - It’s 48 hours in late May
    - We’re doing it for the first time overseas in Normandy
    - It’s the dark side of GORUCK,  but people ultimately wanted the biggest test they could possibly find
    - This past year, 1 person finished
      - The year before 0 people finished
      - The year before that, 1 person finished
    - That’s the first event we’re kicking off with, and then we get into the more fun stuff

- *Peter responds, “80K doesn’t sound like it’s just pure fun stuff. That sounds pretty challenging.”*

*That event is Jason’s favorite event to do as a participant*

- You have to put the miles in to train up
- The first time we ever did it, we did it in DC, and it was a torrential downpour
  - Jason went in with a little bit too much pride, like, “*Oh, I’ve been rucking for a long time*.”
  - You have 20 pounds, so you end up having 25 including your stuff
  - He was like, “*Oh no, I’m good*.”
  - Jason explains, “*Man, I had to go to the well to pass that thing*.”
    - And it was under 20 hours
    - You’re rucking, you’re not shuffling, you’re not ruck running or anything like that, if you want to hit that kind of time back
  - The beauty is just it does wear you down
    - It’s longer than you want
    - It’s harder than you think
    - The 40 mile mark is about where you’re like, “*I’m ready to be done.*”
- What you’ll find, over the course of these longer events, is that there’s highs and lows for all of you, but they don’t always come at the same time
  - So you’re there and you need someone’s help, and they help you.
  - And then, you, in turn, do that for them

***It really brings you closer to people that you’re there with, and that was great experience***

**You won’t do the 80K?**

- Jason and Emily will probably choose a shorter distance, only because they have a lot of events to put on
- That takes you out of commission for a couple days

**You’ll do this right on June 6th?**

- We’re there for 2 weeks prior
- Normandy is a great place; it’s also very big
- It’s going to be very busy leading up to the anniversary
- On June 6th, all the heads of state will be at the American Cemetery
  - Which means there’s more traffic, there’s more checkpoints, it’s harder to operate
- We plan it to let people show up early
  - We run our events during the week and the weekend prior
  - Then, if people want to stay, they can stay; and if they want to go home by then, they can go home
- People should go to Washington DC as well and see our nation’s capital, see the Lincoln and the Washington
  - You can’t get as close to the Capitol as you used to, but go see the Jefferson, the MLK, and the FDR
  - Go see them and read what’s up there
  - Read the Gettysburg Address at the Lincoln: it’s amazing
- As well, the more people that go to Normandy, the better
  - It’s just an amazing place

## Footwear for rucking, and how GORUCK got into the footwear business [1:57:30]

**Why do you guys make footwear, and why do you think the footwear you make is really good?**

- Peter wears their footwear; he’s wearing the [Ballistic Trainers](https://www.goruck.com/collections/ballistic-trainers) now
  - He loves both the high top and the low top
  - They have about an 8 mm drop
- These are very supportive and Peter found prior to wearing these, that he was destroying shoes
- There are certain minimalist shoes that he likes, but he felt he needed more support
- Peter adds, “*You’re almost a footwear company at this point now, aren’t you?*”
- We are
- An important thing happened when Jason  met a guy named [Paul Litchfield](https://www.sneakerfreaker.com/news/reebok-pump-desinger-paul-litchfield)
- There’s a lot of chemistry involved in the process of building footwear, and there’s a lot of dark arts
- You can sew a rucksack, you have some sewing machines and a cutting table
  - You can iterate a million times
- Footwear is way more complicated, with lasts and molds and foam chemistry and all this stuff
- Jason met Paul when he was still at Reebok
  - He was running the Advanced concepts group at Reebok at the time
- Paul had invented something called the [Reebok Pump](https://en.wikipedia.org/wiki/Reebok_Pump) and it had been one of the foremost shoe dogs of his generation (and still)
  - Sold over a billion pairs of shoes
- There’s a lot of expertise that comes with that to help navigate the dark arts, because starting your own shoe company, while it sounds sexy, it’s a great way to build a terrible product
- You have to liaise with the factory and get the molds built, and there’s a lot that goes with it
- It was important that we had someone who’s a real expert, and Jason is a really aggressive product tester
  - He hates everything till he accepts it

*Great art is never finished, it’s only abandoned*

- - So there’s always this kind of relentless pursuit of excellence, but you have to have somebody who is just dogmatic in their beliefs, that knows what they’re doing, that is a subject matter expert, that has dedicated their life to this as a profession
  - Without that, Jason was unwilling to get into the footwear business

- Jason explains, “*The reason why footwear is so important is that if you lined up a hundred people who are masters of the ruck, most of them at this point would come from the Special Forces community, and you said, ‘What’s more important, the ruck sack or the boot?’ 90% if not 100% will say, ‘The footwear.’*”

- The reason why is because when that goes wrong, it is just excruciating
- Napoleon lost because of foot problems, right?
  - You can lose wars, you can lose everything, based upon the feet of your soldiers
  - And if they’re not doing well, it’s really hard to do anything
- You’re living on your feet all of the time
- In the military, we were always just modifying our footwear to make it more like a sneaker, but still supportive
- There’s all this stuff in the civilian sector about **minimalist footwear**
  - You cannot go through the training that we went through in minimalist stuff
  - Your feet just need more support under that kind of load

**We took the jungle boot from the military and made that ours**

- That was the boot Jason wore in the Special Forces qualification course
- We stripped away the weight
- We added tread that was lightweight that would still work with that
- Most importantly, we provided the support for your feet for all of the miles
  - It lets you scale up the weight and the distance
- Because this is GORUCK, we want stuff to last forever
  - It doesn’t, but we want it to last forever, and that’s how we build it
  - That’s just in our ethos and we’re uncompromising about that

> “*We were unwilling to do it unless we could build a best-in-class, world-class product, and we want it to solve a real world problem, not just a stylistic problem, like, ‘Oh, this is going to be a cooler looking shoe.’ That’s a terrible problem to solve.*”‒ Jason McCarthy

- The problem is you live on your feet and you’re carrying weight of any amount, volume, distance, whatever it might be, and we need to build something around that
- That’s a harrowing task
- Now, there’s all different facets of how people carry
  - Is it off-road or is it on trails?
  - How did people grow up?
- Look at how [*Born To Run*](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307266303/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1706191673&sr=8-1) kind of ignited that
  - The vibrant 5 finger shoes
    - Which Jason calls, “*The 5 Finger Death Punch*,” when he would see it at events, because people would just destroy themselves when they would wear this
    - They’re so unsupported with so much weight for so long
- People just don’t know and they are looking for answers

***If you are carrying weight or you’re living on your feet, you need supportive footwear***

- Peter agrees, “*I love my minimalist footwear, but I have learned, I would say, the hard way that rucking is not the time for it.*”
- Peter describes his feet as hypermobile and it seems to make him even more susceptible to injury on uneven terrain with that much weight

**Talk about the Ballistic Trainer versus the boot. How would you help somebody navigate those?**

- People make decisions based off how things look or how simple they are
- We come from a Special Forces background, so the [boots](https://www.goruck.com/collections/macv-series) are inspired by our jungle boots that we used to wear
  - We just sort of stripped them down
- The [Ballistic Trainers](https://www.goruck.com/collections/ballistic-trainers) started out as the best garage gym shoe on the planet
  - There was a little bit of, “*Hey, how do we solve a problem that you can lift, push, pull, drag sandbags or barbells or stuff as well*.”
  - But this is GORUCK, so you need to be able to ruck in them as well
- At that time, [CrossFit](https://en.wikipedia.org/wiki/CrossFit) had started out with a really minimalist drop for lots of different reasons, but many of them weren’t very good over the long haul
- We came in with an 8 mm drop shoe (the Ballistic Trainer)
  - This also happens to be the best shoe for CrossFit
  - For us it’s also the best garage gym shoe and you can ruck with it and live in your feet with
  - **The drop does matter** (so basically the rucking offset or the heel lift), and that’s how you prevent things like shin splints
    - It takes a little bit of strain off the Achilles and keeps it a little safer
- You can argue philosophical positions forever
  - You should have a stronger Achilles, a stronger shin, and a stronger foot
  - The word “should” is not really very useful
- The thing is, people grew up with a lot of asphalt and the more you weigh, the more strain you’re putting on your feet with every step
  - How do you walk, and all of those things
- Yes, it’s important to strengthen your feet as well
  - Walk around your house barefoot
- But when it comes time to perform and you have a lot of weight [you need supportive footwear]
  - Your foot has 3 arches and you need to support them all over a lot of dynamic movements: pavement, uneven terrain, whatever it might be
    - There’s a lot that goes into doing that successfully, and the stuff we build is designed for that
- Peter does most of his activity barefoot, but he takes care of his feet when he rucks and when he does his heavier carries

## How to avoid the most common injuries from rucking, and the benefits of rucking for VO2 max, strength, and sleep quality [2:05:00]

**What are the most common injuries you see in people who ruck?**

*What are the steps you recommend people to take to mitigate those?*

- If you do it at lighter loads, you don’t see a lot of injury
- You’ve seen this proven in Special Forces training
  - The #1 cause of injury is running, and there’s no close second
  - Lifting is #2, and marching is way down the list

***The injuries that you’ll see are usually from people that start too fast, too soon, with too much weight***

- So, slow down, reduce the weight, listen to your body
- If you start to get shin splints, they’re not going to get better from doing more of the same thing
  - You can ice and rest
  - You can also just reduce the weight, the distance, and the time
- Jason’s standard is a 45 lb plate
  - He carries it often
  - It’s by the door at his office, it by the door at his house
  - If he walks the dog, he rucks the dog
  - If he can take a phone call outside, he puts the 45 lb plate on and walks around the neighborhood while he takes the call
    - This lets him squeeze a few more hours out of the day that he doesn’t have to dedicate to just fitness
- Some days you don’t feel like doing that much, or some days you want a little bit more
  - You just have to listen to yourself
- If you start running with weight, you’re putting a lot more strain on yourself, so make sure that you’re physically able to do that
- There’s a middle ground that’s a **shuffle** that is really, really interesting, and when Jason wants to do a little bit more and he doesn’t want his knees to feel like he just went on a long run
  - He tries to keep his feet as low to the ground as possible, and he moves them as fast as possible; just kind of shuffle
  - His heart rate goes up a lot more, and you can really accelerate that pretty quickly

***The faster you go and the more that you gallop, the greater risk that you’re going to have of injury***

- For most people walking with 20-30 pounds, you’re not really going to see a lot [of injuries], other than shin splints if you’re unready
- If your Achilles starts to hurt, dial it back a little bit, get a little more ready, or look at supportive footwear
- If your shoulders are sore, then decrease the weight
  - Or if it’s a good sore, then that’s them getting stronger
- Peter finds that he rucks less in the winter
  - For whatever reason, he enjoys the heat more and has less motivation to go out in the winter
- He finds that when he ramps up the volume in the summer, that first week, he feels it in the shoulders again
  - But it’s easy to distinguish a good sore (this is foreign to me) from a bad sore (this is causing an injury)

*What happens when you ruck with too much weight*

- If you get too much weight, you’ll start to lean your body forward
  - You’ll pivot at your hips a little bit too much while you’re doing it
  - You’re doing that because you’re trying to put the weight over your stronger muscles, and you’re kind of cheating
- Jason explains, “*You know how Arnold talks about, ‘I don’t care how many pushups you can do. I want to see you do 10 perfect pushups’?*”
  - Master the movement first and then get into the miles and all that
  - Do the movement correctly
  - Remove the ego a little bit about how much weight that you have, especially if you’re starting, until you get comfortable or know what you’re capable of, and keep good form while you’re doing it
  - This will reduce the risk of really anything
  - ***You shouldn’t start hunching over and stuff***

**For someone starting out, what would be the frequency you would recommend they do it, if they’re starting out at a modest weight? Would you put any limit on it?**

- This is very subjective depending on:
  - Their step count
  - Do they work out otherwise

***Try a couple miles, a couple times a week***

- If you try 2 miles with 30 lbs and that was good, you can do that
- Peter agrees, “*At a light enough load, once you’re in a cardio zone 2 or below, there’s really no limit to what I think you can do in terms of frequency.*”

**People always ask Peter if it’s a zone 2 workout when he’s doing his ruck**

- No, it’s zone1/zone4
- He’s never at a steady state heart rate of 130-140
  - The only way he can do that is the ruck shuffle (he explained how he does this at the track at the school)
    - If he does a shuffle, he can titrate the speed of the shuffle to zone 2
- Walking around his house, his heart rate is either pretty low or pretty high (when going up steep hills)
  - This is part of the reason why he doesn’t really bank it as exercise in his mind
  - He enjoys those pushes up the hills, because then you’re getting that VO2 max
  - He also really likes walking down the steep hills, because you’re working on: “*How do your brakes work?*”
    - And brakes are the things that fail when we age
    - Walking down a very steep hill with weight on your back is a really good way to train [eccentric strength](https://peterattiamd.com/avoiding-injury-part-i-eccentric-strength/) while the muscle is lengthening

Jason asks, “*Would you recommend going very slowly while you do that, or is there any value in increased speed while going downhill?*”

- Peter doesn’t think there’s a value in increased speed going downhill
- Only sprinters do that to teach the muscle how fast the legs can go
- The risk-reward for a normal person is not there to justify it
- Peter is not going incredibly slow
  - He’s going at the safest pace possible when he goes down
  - Whereas, going up, he’s really limited by his cardio system
    - He’s basically going up as fast as his lungs will carry him
- Jason adds that the way down hurts his knees more, the faster he tries to go
- His wife is a really good runner and whenever they go for runs, she’s like, “*Got to make up speed on the downhills.*”
  - Jason is not willing to do that on a training run, and it’s the same thing for rucking
- Going downhill is a leg workout
- One of Peter’s favorite workouts is a heavy 80-100 lb pack
  - He doesn’t do this often because this truly is a workout
  - Where he lives, there are 4 short but very steep hills, and it’s up and down all 4
- Jason and [Michael Easter](https://eastermichael.com/about/) have gotten into carrying 100 lbs for 1 mile ‒ baseline your time against that

**What’s a benchmark time that one should think of for a 100 lb? And you’re doing this as a shuffle?**

- What gets exhausting is when you change too much from a walk to a shuffle
  - You need to pick a cadence that you can maintain
- It might take Jason 9:30 to shuffle a mile with 100 lbs on his back
- Peter was about to say that 10 minutes sounds like it would be pretty tough
- Jason has seen a really competitive runner do it in 6:30
  - That’s insanity
  - It’s still a VO2 max type of game
- He wonders at what point it starts being more about a strength carry (a really extreme weight?)
  - Peter thinks that with a heavy enough weight where you can’t shuffle, it probably shifts more to pure strength

**The value of rucking for sleep**

- Jason prioritizes how well he sleeps
- Getting steps counts, and some percentage of those with weight on his back is a useful tool for him to sleep well
- It’s also fun to have challenges with a ruck on his back, he harkens back to those days when he did that, and the foot races

## Advice for using rucking as a mode of training, and the advantages of rucking over other forms of training [2:12:45]

**What do we know about the plates?**

- GORUCK sells these amazing [plates](https://www.goruck.com/collections/ruck-plates) that make this so easy to plug-and-play
  - They slot right into the pack

**What’s the over-under on TSA pre here in the US allowing those through security?**

- Peter adds that it would be great to be able to takes plates along when he travels, and even to just utilize them in the time he’s at the airport
- Jason has personally done this 50 times and they’ve never been confiscated
- There’s a raging debate inside of the GORUCK community and a lot of people have gotten their plates confiscated (enough to where it comes up)
- Jason has found that the best way to do it
  - First off, you have to be willing to check it or sacrifice it if it doesn’t go through
  - But you separate it out: you put it in its own thing
    - You can put a little descriptor on what it is, or you have to be ready to tell them what it is
    - The more people that know what rucking is, the more likely it’ll be okay

*Have you got a sense of whether the people who are getting confiscated are lighter plates versus heavier plates?*

- The heavier ones are more likely to get confiscated
- Jason has always carried a 20 or 30 lb plate to the airport

**The other thing Jason does is use a stuff sack instead of a plate**

- You get somewhere and you can find rocks outside the hotel
  - Finding 20 lbs of that is not hard
- You can wrap a dumbbell from the hotel gym (which he’s done)
  - It’s not as nice of a ride
- There’s the ability to multi-use things that you travel with
  - Use your dirty clothes bag and put rocks in it
- The reason Peter wants to bring the plate is when he goes on vacation to Europe or something where you’re not going to have the luxury of going to the gym every day, but you are going to walk 10 miles a day
- Jason has also had success with a **sandbag** that goes in and takes up a little bit more volume, but isn’t iron
  - It’s not always great stacking; but it’s easy in, easy out

**You mentioned the treadmill earlier, what are the advantages or disadvantages to rucking on a treadmill?**

- The disadvantages are very clear: you’re not outside
  - [Michael Easter](https://eastermichael.com/about/) talked about these fractals and you’re missing out on sunshine and wind and light and all of that kind of stuff
- Some advantages to treadmills are simply safety and practicality
- Jason has a couple friends that are surgeons at Mayo and they get home at 3:00 in the morning and they want to get their workout in then, and they’re on their treadmill

***You should do what works for you***

- Americans are spending around 93% of their time indoors now
- Give yourself a little bit more freedom to go outside
- Jason is more comfortable walking around with a rucksack on than he is with a weight vest or a big giant hiking hunting pack
  - You kind of look like you can blend in
  - You can go ruck and get the groceries
  - You can bake it in
- Treadmills are fine
- Staring at some screen the whole time, there are other downsides to that

**If somebody wants to do one of these really extreme events like the 80 kilometer Normandy challenge, how do they train for it?**

- Peter explains that we really know how to train for a marathon
- He wants to know the build pattern of volume to get ready for something like this
- You need to do a marathon
- You need to at least do 40K
- The way Jason has always cheated the distance is by adding weight and trying to maintain the same speed

*Jason is trying to do the 80K in under 20 hours*

- So you’ll need to be able to ruck a marathon in 10 hours

*How much weight is this event done with?*

- 25 lbs (not that much)

*How much would you increase that to maintain the pace? You’d go 50 pounds or something?*

- 50-60 lbs almost all the time
- Jason never trains with 25 lbs
- You can also do what he was talking about earlier with the sock system to toughen up your feet
- With rucking, you can go a certain distance and drop your weight to go faster
  - Picking up speed, you’re hitting systems a little bit differently in the same type of movement
- You have to experiment with it
- Unlike running, you have this other variable you can control
  - 100 lbs is a lot different than 60 lbs
  - And you reach this point where an incremental amount of weight added feels like an exponential amount of weight added
    - That can change over time relative to how much you ruck or what you’re comfortable with

**If you have 1 hour**

- You can do a lot of different things
- You can go lighter and faster
- You can go heavier and slower
- You can go middle-of-the-road and try to push on one of those systems a little bit more, and that’s fun

**Jason’s goal is for rucking to be the new running**

- The goal is that rucking is bigger than running

*What’s that going to take?*

- We’re in the early stages of it
- First off, it takes awareness that people are actually rucking
  - Everybody that joins the military is rucking
    - Now you’ve got millions of people
- You go to airports: roll bags and stacking stuff so that everything is easy all the time
  - You sit on a flight for 10 hours and then you stand on a walking escalator, and then you go sit at your gate?
  - Don’t do that
  - Put everything on your back; you have hands-free movement (that’s freedom)
  - You can do this at the airport, while you’re traveling
- Go to Europe, there’s cobblestone roads, and roll bags are just not… (it’s just a ball and chain around your life)
- The first step is to just say, “*This is better because,*” and you get people to buy into that
- Then there’s just the physiological side: this is extremely healthy for people to do

> “*The best things that you want out of life require passion and energy and activity… and the more that you do, the more confident that you get doing things.*”‒ Jason McCarthy

- This is a really important lesson that everybody has to relearn throughout the course of their life: you have to keep doing stuff
- The body is anti-fragile
- The more that you work it, the stronger it gets
  - That’s an amazing thing that we have, and to not know what we’re capable of is just a shame
- Let’s intentionally do these physically harder things than nothing, than just living our lives on phones, or always standing to then sit, to never move

***There’s so much benefit that comes from your ability to move yourself and to carry weight, and you are built and born and have evolved in order to do this***

- Peter adds, “*It is our superpower, right?* [*Michael*](https://eastermichael.com/about/) *wrote about this in* [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1705948070&sr=8-1) *that there’s nothing that’s evolved to carry more than we do.*”
- You can work it into your life
- The risk of injury is fractional
- Most people would count a hour and a half with 60 lbs on their back as exercise

**The scalability, it’s a very simple thing to do. You carry weight.**

- It’s not a new machine that’s going to turn into a towel rack
- It’s not Mr. Spandex yelling at you through some screen on a bike
- It’s not a new band
- It’s none of these gimmicks
- It’s so simple; this has been going on for millenia
- It’s been proven in all of the special operations communities
- It’s foundational to our ability to survive and thrive as a species
- Jason explains, “*It’s such an unlock in our lives when you take this kind of responsibility and you say, ‘I want to be a more active person,’ and all of a sudden, you’re around active people. You’re figuring out how to move forward*.”
- It’s very much tied to a mental outlook of life
  - Do you want to take your two fingers and roll your bag onto the walkway and stand there, and then go find a seat and sit down and stare at your phone?
  - Or do you want to take the bull by the horns?

**One of the things Peter talks about with patients is this marginal decade, and what are the activities you want to be able to do in the last decade of your life**

- These are quantifiable things that are noted very specifically
- Peter wants to be able to ruck 3 miles over uneven surface with 20 lbs on his back
- Peter is so grateful for what Jason is doing
- He hopes that a lot more people are going to try rucking after listening to his

He suspects they will experience what he and everybody he’s dragged on a ruck has experienced, which is: “*I’m going to do that regularly.*”

§

## Selected Links / Related Material

**Jason’s company**: [GORUCK](https://www.goruck.com/) (2024) | [1:15, 6:30, 1:10:30, 1:16:00]

**Book about the experience of war**: [Tribe: On Homecoming and Belonging](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=sr_1_1?crid=1Y2FN0Y8KQUWY&keywords=tribe+by+sebastian+junger&qid=1706037489&sprefix=tribe+by+%2Caps%2C90&sr=8-1) by Sebastian Junger (2016) | [55:15]

**GORUCK rucksacks**: [Training rucksacks](https://www.goruck.com/collections/training-rucksacks) | GORUCK (2024) | [1:38:00]

**GORUCK footwear**: [Footwear](https://www.goruck.com/collections/footwear) | GORUCK (2024) | [1:57:45]

**Michael Easter’s book**: [The Comfort Crisis: Embrace Discomfort To Reclaim Your Wild, Happy, Healthy Self](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1705948070&sr=8-1) by Michael Easter (2021) | [2:15:45]

**Fitness festival**: [Sandlot Jax Fitness Festival](https://www.sandlotjax.com/) | Go Ruck Sandlot Jax (2024)

§

## People Mentioned

- [Michael Easter](https://eastermichael.com/about/) (best-selling author of [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1705948070&sr=8-1) and [*Scarcity Brain*](https://www.amazon.com/Scarcity-Brain-Craving-Mindset-Rewire/dp/0593236629/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)) [3:45, 1:45:30, 2:11:30, 2:15:45, 2:21:45]
- [Johnny (Mike) Spann](https://en.wikipedia.org/wiki/Johnny_Micheal_Spann) (CIA officer and first American killed in the 2001 Afghanistan invasion) [10:45, 1:00:45]
- [Sebastian Junger](https://www.sebastianjunger.com/about) (New York Times bestselling author, journalist, and documentary filmmaker)  [55:15]
- [Jocko Willink](https://echelonfront.com/instructors/jocko-willink/) (retired Navy SEAL and co-founder of Echelon Front) [1:15:45]
- [Andrew Huberman](https://www.hubermanlab.com/about) (Professor of Neurobiology, and by courtesy, of Psychiatry and Behavioral Sciences at Stanford School of Medicine and host of the podcast [*Huberman Lab*](https://www.hubermanlab.com/podcast)) [1:45:15]
- [Paul Litchfield](https://www.sneakerfreaker.com/news/reebok-pump-desinger-paul-litchfield) (athletic shoe designer who invented the Reebok pump) [1:58:15]

§

![](https://peterattiamd.com/wp-content/uploads/2024/03/bio-jasonmccarthy.png)

##### Jason McCarthy

Jason McCarthy earned a Bachelor’s degree in Economics from Emory University, where he was a 3x Academic All-American. After 9/11, he enlisted in the US Army and became a Green Beret in the Special Forces. He served in Iraq, West Africa, and Europe. He received a Bronze Star and Army Commendation Medal with “V” Device (indicating valor). Jason went on to earn a Masters of Business Administration from Georgetown University. In 2008, Jason co-founded [GORUCK](https://www.goruck.com/) with his wife Emily. Their goal was to build a rucksack with life or death quality standards that would thrive in Baghdad and NYC. In addition to building the toughest rucking gear, they organize training, events, and GORUCK clubs. The [Sandlot JAX Fitness Festival](https://www.sandlotjax.com/) is one such event where the goal is to make fitness fun. Jason also serves on the Board of Directors of the [Green Beret Foundation](https://greenberetfoundation.org/board-of-directors-advisors/), a non-profit organization that supports present and past Green Berets and their families. [[Forbes](https://www.forbes.com/sites/amitchowdhry/2018/02/12/goruck-jason-mccarthy/?sh=11001132196d) and [GORUCK](https://www.goruck.com/pages/about-goruck)]

Instagram: [jasonjmccarthy](https://www.instagram.com/jasonjmccarthy/?hl=en)

X (formerly Twitter): [@GORUCK](https://twitter.com/GORUCK)

Website: [GORUCK](https://www.goruck.com/)