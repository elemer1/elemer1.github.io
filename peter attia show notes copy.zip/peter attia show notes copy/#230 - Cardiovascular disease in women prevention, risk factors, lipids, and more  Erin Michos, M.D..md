# #230 ‒ Cardiovascular disease in women: prevention, risk factors, lipids, and more | Erin Michos, M.D.

**Source:** [https://peterattiamd.com/erinmichos/](https://peterattiamd.com/erinmichos/)

---

Erin Michos is an internationally-known leader in preventive cardiology and women’s cardiovascular health. In this episode, Erin discusses current trends in cardiovascular disease (CVD) through the lens of female biology and the observation that major adverse cardiac events in both sexes are on the rise. She walks through risk factors including LDL-cholesterol, apoB, and Lp(a) and makes the case for the importance of early preventative measures. She explains various interventions for reducing risk including a discussion of statins, GLP-1 agonists, PCSK9-inhibitors, and drugs that lower Lp(a). She goes in-depth on female-specific factors that contribute to CVD risk such as pregnancy, grand multiparity (having five or more children), oral contraceptives, menopause, and polycystic ovary syndrome (PCOS). Additionally, she explains her approach with patients as it relates to the use of hormone replacement therapy and provides advice for people wanting to lower risk both through lifestyle changes and medications.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/erinmichos/the_Drive_public.png)

Play

#230 ‒ Cardiovascular disease in women: prevention, risk factors, lipids, and more | Erin Michos, M.D.

#230 ‒ Cardiovascular disease in women: prevention, risk factors, lipids, and more | Erin Michos, M.D.

1x15s30s

0:002:15:05

## We discuss:

- Erin’s background in preventive cardiology and women’s health [2:30];
- Recent trends in cardiovascular disease in women, mortality data, and how it compares to cancer [5:15];
- Why early preventative measures are critical for cardiovascular disease risk [13:15];
- ApoB as a causal agent of CVD, and why high apoB levels are not being aggressively treated in most cases [19:45];
- The rising trend of metabolic syndrome and other factors contributing to the regression in progress of reducing cardiac events [27:00];
- GLP-1 agonists—Promising drugs for treating diabetes and obesity [33:30];
- Female-specific risk factors for ASCVD (pre- and post-menopause) [37:15];
- Polycystic ovary syndrome (PCOS): prevalence, etiology, and impact on metabolic health, lipids and fertility [47:00];
- The effect of grand multiparity (having 5+ children) on cardiovascular disease risk for women [52:30];
- The impact of oral contraceptives on cardiovascular disease risk [55:00];
- The effect of pregnancy on lipids and other metabolic parameters [58:45];
- The undertreatment of women with familial hypercholesterolemia (FH) and how it increases lifetime risk of ASCVD [1:02:00];
- How concerns around statins have contributed to undertreatment, and whether women should stop statins during pregnancy [1:09:45];
- How Erin approaches the prescription of statins to patients [1:16:00];
- PCSK9 inhibitors and other non-statin drugs [1:21:15];
- Advice for the low- and high-risk individual [1:28:30];
- The impact of nutrition, stress, and lifestyle on lipids and CVD risk [1:31:00];
- Lp(a) as a risk enhancer for cardiovascular disease [1:41:15];
- The effect of menopause on cardiovascular disease risk [1:50:30];
- How Erin approaches decisions regarding hormone replacement therapy (HRT) for her patients [1:55:30];
- The urgent need for more data on women’s health [2:03:30];
- Erin’s goal of running a marathon in every state [2:09:45]; and
- More.

§

## Show Notes

## Erin’s background in preventive cardiology and women’s health [2:30]

- Erin has been at Hopkins for 22 years
  - She did her residency from 2000-2003 and stayed on for a cardiology fellowship
  - Then she joined the faculty
  - She’s been faculty for over 15 years
- Peter did his residency in general surgery there too, from 2001-2006
  - This made him realize they probably passed each other somewhere in the emergency room during residency

**When Erin went into medicine, did she know she wanted to do cardiology?**

- When she went into medicine, yes
- In college, she didn’t know she was going into medicine
  - There are no doctors in her family; she’s the first one
- She started her undergraduate studies at Northwestern as a molecular biology major
- She interacted with so many pre-med students who were her classmates
  - Their enthusiasm about entering the field was contagious
- She was doing a lot of bench science, which is a really good experience
  - Erin adds, “*I think anybody entering science and medicine should have some bench lab work experience*”

- She began to long for more direct clinical research with direct patient exposure
- In her last year of undergrad, she switched to being pre-med
- She applied to both PhD and medical programs
- When she started medical school, she fell in love with cardiology
  - As medical student, even before residency
- She has a real interest in diet and nutrition, and exercise and lifestyle

> “*We think that over 90% of cardiovascular disease is due to preventable modifiable risk factors*”‒ Erin Michos

- There’s so much we can do for prevention and this is why Erin really loves being a preventive cardiologist
- When she entered residency, she already had her eye on a cardiology fellowship
- She did 3 years of a medical residency (which is standard) and 4 years of cardiology
  - The cardiology program was longer because it emphasized research
  - She did 2 years of research on a T32 program in cardiovascular epidemiology, and that’s where she got her master’s in health science

## Recent trends in cardiovascular disease in women, mortality data, and how it compares to cancer [5:15]

**Why doesn’t prevention get more attention?**

- Data from the [INTERHEART study](https://pubmed.ncbi.nlm.nih.gov/15364185/) show that 90% of myocardial infarction risk was due to preventable risk factors
- Peter tells his patients that [ASCVD (atherosclerotic cardiovascular disease)](https://peterattiamd.com/ama34/) is the leading cause of death
- He was surprised last year to realize how much bigger the gap is between ASCVD and cancer globally than in the US
  - ASCVD is #1 in both the world and US
  - But outside the US, ASCVD causes 18-19 million deaths where as cancer causes 10-11 million deaths (per year)
  - ASCVD causes almost 2x more deaths than cancer
- Peter asks, “*When you take into account what you just said, that between smoking, hypertension and controlling* [*apoB*](https://en.wikipedia.org/wiki/Apolipoprotein_B)*, you could basically turn that into a disease that would barely rank on the top 10. Does it surprise you that this doesn’t get more attention?*”
- It surprises Erin, and she’s concerned that we’re reversing these trends

**Recent trends in cardiovascular disease**

- The first [statin](https://en.wikipedia.org/wiki/Statin), [lovastatin](https://en.wikipedia.org/wiki/Lovastatin), was approved in 1987
- That along with efforts in smoking cessation and blood pressure treatment, there was a significant decline in cardiovascular disease mortality in men
- During this time, unfortunately, CVD mortality was rising in women till around the year 2000 when this came to attention
- And after that time there was dramatic decline in cardiovascular disease mortality in women and continued decline in men
- But unfortunately, in recent years we are no longer making these strides in progress anymore
- In fact, we’re no longer even stagnated
- There has been a frank uptick in cardiovascular disease mortality in both men and women due to the epidemics of obesity and diabetes and cardiometabolic diseases
- Cardiovascular disease mortality is on the rise in younger women
  - And when you look at rates of change, ***the fastest growing heart disease death rate is in middle-aged women aged 45 to 64***
- So we really need to double down on our preventive efforts, and it’s really disheartening to see that we’re no longer making the progress that we used to
- If these trends are not overturned, heart disease is set to overtake cancer as the leading cause of death in younger women as well
- Peter comments on mortality data
  - In middle age, cancer is the biggest killer
  - In old age, cardiovascular disease and neurodegenerative disease dominate
- He finds this very concerning that cardiovascular disease may eclipse cancer in middle age

**Erin’s focus on women’s health**

- Erin is focused on women’s health, and cardiovascular disease is the leading cause of death in women
- Women more often fear breast cancer, but far more women are likely to die of cardiovascular disease than cancer
  - However, in younger individuals (under the age of 65), cancer is still the leading cause of death in women
- One of her [studies](https://academic.oup.com/ehjqcco/article/8/3/315/6130732?login=false) tracked death rates in younger women under the age of 65 in the US looking at CDC WONDER data over a 20-year period from 1999 to 2018 (see the figure below)
  - They showed during this time that cancer mortality has been declining in younger women
  - ***But since 2010, heart disease mortality in younger women is no longer declining, and it’s actually rising at 0.5% per year***
  - It’s narrowing the gap between cancer deaths and heart disease deaths in women under 65

![](https://peterattiamd.com/wp-content/uploads/2022/10/f1-erinmichos-1024x798.png)

**Figure 1.  Mortality fates of women under 65 due to heart disease and cancer, 1999-2018.**  Image credit: [*EHJ:QCCO* 2022](https://academic.oup.com/ehjqcco/article/8/3/315/6130732?login=false)

- Erin is discouraged, “*If these trends are not overturned, heart disease is set to overtake cancer as the leading cause of death and younger women, which is really discouraging considering that we have so many more tools now for prevention*”
- The American Heart Association has sent out surveys over the years to women about their awareness of heart disease being the leading cause of death in women
- Back in 2009, 65% of women reported that they knew that heart disease was the leading cause of death
  - But 10 years later in 2019, only 44% of women reported that heart disease was the leading cause of death in women
    - They were more likely to report cancer as the leading cause of death
- This lack of awareness is worrisome
  - It was particularly prominent among non-Hispanic Black women and among Hispanic women
  - And also among the younger women, who arguably we can do the most for as prevention is most effective if started earlier
- Peter finds in talking to female patients, there is a greater fear of breast cancer than ASCVD,  even though the mortality from heart disease is somewhere between eight and 10 times greater than that of breast cancer
  - It’s amazing to think that they would be more afraid of something that has a log lower difference in mortality

**What explains the lack of awareness about heart disease mortality?**

- Erin thinks there’s still this lingering notion that somehow heart disease is a man’s disease
- The problem is women have historically been under-enrolled in randomized clinical trials, so we previously had limited data on efficacy and safety of therapies in women
- So women think that they’re at lower risk than they really are
- And clinicians perceive women to be at lower risk
  - Even when clinicians are given the same 10-year estimated risk, or burden of risk factors
  - And this leads to undertreatment
- Erin particularly sees this with women who have [FH (familial hypercholesterolemia)](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia) who are undertreated
- Because on average in the non-FH population, women tend to develop cardiovascular disease about 10 years later than men
- It’s somehow thought that premenopausal women of reproductive years are somehow protected, but this is NOT true for FH

**More about familial hypercholesterolemia (FH)**

- FH affects 1 in 250 individuals
- It’s autosomal dominant, women are equally affected as men
- It’s associated with a 20-fold increased risk of CVD
- Women with FH have an earlier onset of ASCVD
  - About 20 to 30 years earlier than women without FH
  - And they continue to be undertreated
- Notably, in the FH population, women have the same early age of onset of CVD as men do
  - So they are not protected, they don’t have this premenopausal advantage
- So it’s still really disheartening to see that these women who have very high genetic risk are not being treated because of concerns about pregnancy (which we can talk about management around there)
- It’s better to have even short interruptions in treatment than to let these women who have genetically very high LDLs be marinating in this atherogenesis for decades and decades untreated
  - Which dooms them to earlier onset morbidity and mortality if not treated

## Why early preventative measures are critical for cardiovascular disease risk [13:15]

**What fraction of men who experience a major adverse cardiac event do so before the age of 65?**

- Peter notes, “*The answer was fully half*”
  - These data were from 5-6 years ago
- 65 is used as a dividing line between young and old
- Even for women (who have this time shift of about 1 decade), still *a third* of of women who will experience a major adverse cardiac event in their life will do so before the age of 65

*Is this still the case?*

- Yes, unfortunately women of reproductive age are still at risk for ASCVD
  - They may be lower risk on average
  - They are less likely to be treated
- Data from the [YOUNG-MI](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7700756/) (young myocardial infarction cohort before the onset of their myocardial infarction) reveal that women were less likely to be treated and were perceived to be at lower risk

> “*This is really concerning about the undertreatment of women and this presumption that they’re lower risk*”‒ Erin Michos

- We know that smoking and diabetes, in addition to the FH (familial hypercholesterolemia), also eliminate any premenopausal advantage
- It’s not only the magnitude of LDL elevation, but it’s the duration of exposure
- So even exposure to mild or moderately elevated LDL for a sufficient number of years does increase the risk of ASCVD to an earlier onset compared to individuals who have had lifetime low LDL
- And so by waiting to treat individuals until later of life, you’ve left atherogenesis/ atherosclerosis propagate unchecked during this time

***It’s never too late to implement prevention, but prevention is better implemented when started earlier***

- Peter agrees and adds, “*There’s two ways I try to explain this to patients, and usually at least one of them works*”
  - 1 – Sometimes patients will come in with some recollection of calculus and you can remind them about the area under the curve in the integral and you can sort of explain that an enormous driver of atherosclerosis is indeed exposure to apoB
    - Listeners to this podcast are very astute, they understand that [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) includes [LDL](https://en.wikipedia.org/wiki/Low-density_lipoprotein), VLDL, etc.  (reviewed recently in [episode #229 of The Drive](https://peterattiamd.com/understanding-cardiovascular-disease))
    - You want to minimize the area under the curve, and that means starting earlier and lowering apoB or LDL cholesterol more
    - The longer you wait, the more you need to really lower that apoB
  - 2 – The other way that resonates with people is to think about saving for retirement, which is you’d start saving in your twenties (in an ideal world)
    - You wouldn’t have to save an enormous amount if you were saving in your 20s, but you’d be chipping away at it and building up your coffers and generating a slow and steady incremental return and letting the effective compounding take its toll
    - Of course, if you wait until you’re 40 or 50, you’re going to have to be more aggressive in your savings and you’re going to also require a higher rate of compounded return if you want to have the same amount when you retire
    - If you wait until you’re 60, “*Boy, you’ve got to really sock away a lot of money and you’ve got to really hope for some pretty impressive returns in the stock market*”
  - Somewhere between those two explanations, people start to understand what you’re saying and what people like [Peter Libby](https://cics.bwh.harvard.edu/people/peter_libby) have said, which is “*It’s time exposure to apoB*”

**Do you get the sense that it also works that way with blood pressure and some of the other really clear causative agents for ASCVD?**

- Yes, you wouldn’t say to a younger adult who has a systolic blood pressure of 160 that your 10 year risk is low because you’re only 30, and we’re not going to treat you
  - This would allow high blood pressure to continue one and damage arteries causing silent vascular damage
  - Instead, you would treat them

*The problem with the 10-year risks in younger adults*:

- Sure younger adults are going to have a lower short-term risk over the next 10 years, but they have a high **lifetime risk**
- We do them a disservice by ignoring these high values because they haven’t crossed some kind of theoretical 10-year threshold
- With the exception of the guidelines for FH), we treat if it’s above 190 [LDL-C >190 mg/dL]
- But a lot of patients have mild to moderate elevated cholesterol in younger age years that is not being treated
- Erin is not just concerned about preventing a heart attack in her patients in the next 10 years, she’s also concerned about the next 40 years

***This is where we need to have much more focus on prevention, and this does emphasize the role of lifestyle as well, and healthy dietary changes***

- And a healthy lifestyle should really begin *in utero*
- Peter adds, “*You just took a real page out of* [*Allan Sniderman’s*](https://www.cardiomuhc.ca/allan-sniderman) [*JAMA paper*](https://jamanetwork.com/journals/jamacardiology/article-abstract/2647086) *from a few years ago where he really just took aim at this ridiculous notion of 10-year risk being remotely helpful in young people*”
  - Allan discussed this on the [podcast](https://peterattiamd.com/allansniderman/) last year
- Peter likes to take patients to the [MESA risk calculator page](https://www.mesa-nhlbi.org/MESACHDRisk/MesaRiskScore/RiskScore.aspx) and demonstrate for them how much it is driven by age
  - At the low end of that calculator (age 40-45), there’s almost no variable you can put in there that gets you to a high enough 10-year risk that you would trigger treatment
  - Conversely, at a high enough age, there’s almost no variable you can put in there for which the risk is low enough

*In other words, age is the biggest driver of risk*

## ApoB as a causal agent of CVD, and why high apoB levels are not being aggressively treated in most cases [19:45]

**We treat the causative agent when we’re dealing with blood pressure and smoking and yet we somehow ignore the causative agent of apoB when we’re talking about lipids and focus instead on the time horizon of risk.  How did we get here?**

- Randomized clinical trials serve as our primary evidence base for guideline recommendations
  - They’re very, very important
  - But they’re expensive
  - And so generally, you run them over a short time period (5 years), and you want to enroll *high risk people* that are going to have events over the next 5 years
- The problem is, it’s not feasible to do a randomized clinical trial for decades and decades, and so by nature, these *lower risk individuals* and younger adults are not included in these trials

***It comes down to the fact that we don’t have data specifically for treatment in this population (lower risk, younger adults)***

- Erin hones in on lifestyle changes, particularly for younger adults
- We’ll talk more about women-specific factors later, but if women are entering pregnancy in poor cardiometabolic health, they are more likely to have adverse pregnancy outcomes like preeclampsia and gestational diabetes
  - This not only increases their risk of short-term complications at delivery, but also impacts their riska decade or more after their index pregnancy
  - And data shows more women are entering pregnancy in poor cardiometabolic health

> “*We need to shift improvement in cardiometabolic health earlier in life, which means in young adults and women of reproductive age*”‒ Erin Michos

**Is there a double standard when it comes to treating high apoB?**

- Peter notes, “*We don’t have a study that says not smoking if you’re aged 30 to 40 is going to reduce your risk of cardiovascular disease, but yet there’s not a physician out there that doesn’t recommend smoking cessation to a person the minute they pick up a cigarette*”
  - This is because causality of smoking has been identified
- The same is true for blood pressure, “*We don’t have a hypertensive study that looked at people aged 25 to 35, or 35 to 45, where we reduced blood pressure and showed a dramatic reduction in events, because they probably weren’t going to have the events in the time horizon of the study*”
  - But it’s easy for any physician to treat hypertension in a 35 year old because they’re treating a causal agent
- Peter sees the same level of causality for apoB, yet there is this double standard where we ignore the causal agent
- Erin agrees, there is overwhelming evidence that LDL is a causal factor in atherosclerosis
  - There is data from observational studies, genetic studies, interventional trials
  - It all meets the criteria for a causal factor
- She’s not sure why there hasn’t been a greater uptick in treating at younger ages
- Maybe it’s the focus on the **10-year risk score**
  - Although none of the randomized clinical trials enroll people on the basis of a 10-year cut point
  - The pooled cohort equation has never been tested in a randomized clinical fashion about treating people based on a full cohort equation cut point versus another cut point (that has never been tested)
  - The trials have specific enrollment criteria and they really weren’t based on ten-year risk scores, they were based on other factors
  - She’s not sure why we have this over-reliance on 10-year risk scores

**Progress in recent guidelines**

- Erin was a co-author on the [2019 ACC/AHA primary prevention guidelines](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000677), where they acknowledged the limitations of these 10-year risk scores
  - They can *overestimate* risk in certain populations, such as older adults and those with higher socioeconomic status
  - And they can *underestimate* risk in other populations, such as those with more social deprivation and these other unique risk factors that are not captured in these 10-year risk scores.
- The guidelines acknowledge that you should do some kind of risk assessment as a starting point
- For *very low-risk* *individuals* (less than 5% ten-year risk), **lifestyle** may be enough
- For *high risk individuals* (above 20% ten-year risk), you want to use your **high intensity** [**statin**](https://en.wikipedia.org/wiki/Statin) to lower LDL by 50% or more
- Now the guidelines do allow more room now for the borderline intermediate risks to *consider* these risk enhancing factors of which **apoB** and **Lp(a)** are some of them
- The new guidelines also acknowledge **female-specific factors** surrounding early menopause and adverse pregnancy outcomes like preeclampsia (we’ll come back to this topic)
  - The presence of these risk enhancers in those of *borderline intermediate risk* would favor the initiation of statins

**A coronary artery calcium score is another biomarker to assess ASCVD risk**

- If there is still uncertainty about risk (after you estimate 10-year risk and consider those risk enhancing factors), Erin will get a [coronary artery calcium score (CAC)](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) to help refine risk a little bit better and guide shared decision making
- In Erin’s practice, she uses a lot of coronary calcium scoring and particularly for elevated scores
  - She’ll even treat individuals similar to secondary prevention population
  - But we know that even that doesn’t work very well in the *younger population* that we’re talking about (less than 40), because it takes time for plaque to calcify
  - So a zero calcium score in a young adult isn’t as reassuring as a zero score in an older adult
- Peter has gone back and forth in his practice about how to use calcium scores and has come to the same conclusion, which is for patients younger than 50, a zero calcium score is not that informative

**Coronary artery calcium scores (CACs) have some limitations**

- 15% of zero calcium scores are false negatives
- If you do a [CTA (a CT angiogram)](https://en.wikipedia.org/wiki/Computed_tomography_angiography) you’re going to see calcification that was missed because the CTA has much finer slices than the CAC, or you’re going to see soft plaque
  - In one series, Peter found that almost 2% of zero CAC scores actually had hemodynamically significant lesions on CTA
- Aside from the false negatives, the physiology of the disease tells us that’s the wrong metric to care about
- It’s more interesting when you have a perfectly clean CTA in a 70 year old with hyperlipidemia
  - To which you can say, clearly this person has other factors that are protective (we might not understand what they are)
  - And this is a patient for whom aggressive treatment probably isn’t necessary

## The rising trend of metabolic syndrome and other factors contributing to the regression in progress of reducing cardiac events [27:00]

**Is this regression due to the increase in metabolic dysfunction in the population more so than a reduction in preventative measures or interventions for ASCVD?**

- Erin notes that both of these things are occurring

**1-Undertreatment**

- Individuals are still undertreated
- Even if you look at high risk patients (those with ASCVD from the [GOULD Registry](https://www.jacc.org/doi/10.1016/S0735-1097%2818%2932308-8) in the US or the [SANTORINI registry](https://www.sciencedirect.com/science/article/pii/S2667089521000250) in Europe), these patients are not at their goal for LDL levels
  - They’re undertreated
  - In the GOULD registry of US patients with ASCVD, more than two-thirds remained with an LDL above 70
    - We can argue that maybe they should even have their LDL as low as 55
    - But we even use a threshold of 70 as the goal for initiating a non-statin therapy to a statin
  - And over a two-year period, only 17% had their lipid lowering therapy intensified
- The use of combination therapy (including with [PCSK9 inhibitors](https://en.wikipedia.org/wiki/PCSK9#PCSK9_Inhibitor_Drugs)) is very underutilized, at something like 6% in this cohort
- ***We’re certainly not treating with the tools that we have, which is really disheartening***

**2-Metabolic dysfunction in the population**

- But also on the backdrop of this, is the epidemic of **obesity**
  - And along with that comes diabetes and other disorders related to insulin resistance, including worrisome trends with increasing maternal mortality, rising rates of gestational diabetes
  - This is increasing worldwide

> “*The cardiometabolic health of the US population is getting worse over time*”‒ Erin Michos

- And so we’re shifting more morbidity to younger and younger age groups
  - And that will likely affect anticipated life expectancy

*What fraction of people in the United States now have* [*metabolic syndrome*](https://en.wikipedia.org/wiki/Metabolic_syndrome)*?*

- Erin doesn’t know off the top of her head, but it’s huge
- Diabetes rates are going up with ***over 1 in 10 US adults having diabetes***
  - Many with diabetes don’t even know they have it
- These are alarming trends, especially when we have a lot ot therapies we can do for prevention
- Erin points out, “*One of the most important prevention therapies I can prescribe for my patients is lifestyle changes*”
  - Even modest weight loss can have a pretty significant impact on triglycerides and blood pressure reduction
- So it’s always important that we can talk about all the new exciting therapies we have for weight loss, like the [GLP-1 receptor agonists](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist) and the [dual agonists](https://en.wikipedia.org/wiki/Tirzepatide), but really still ***emphasizing a healthy lifestyle from childhood is still such an important strategy for prevention***

**The metabolic syndrome epidemic is multifaceted, how do you rank the culprits behind it?**

*How much is due to lower exercise levels versus food availability, hyper-palatability, and specific elements within the diet?*

- Erin is working to prevent or reverse the trends of obesity on a population basis
- She points out, “*We put too much blame on the individual, but we have major societal population problems with the easy access to poor quality food, these highly processed foods that are extremely palatable but contain a lot of saturated fats and other additives and sugars. The way our jobs are structured to be more sedentary and long commute times, having access to safe places to exercise and having time to do so, and the increased stress levels in life. I mean, there’s so many social determinants of health that have led to this problem*.”
  - There are huge parts of the country that are **food deserts**, where there is not access to fruits or vegetables
  - There are also **food swamps**, where only cheap and easy, highly processed packaged foods are available
- As individuals, we do have some responsibility for our life choices
- Erin contends that larger issues should be placed in regulation and policy on a population level
- Once an individual is obese, it’s much harder to lose weight
  - It’s far more complicated than just calories in, calories out
  - There are all kinds of hormonal regulations
- The good news is we do have some new pharmacological agents that are beneficial in weight loss, that do not have cardiovascular harm like some of the older weight loss drugs
  - These may actually be cardiovascularly beneficial
  - We [know](https://pubmed.ncbi.nlm.nih.gov/34425083/) the GLP-1 receptor agonist, at least in patients with type 2 diabetes, reduces the risk of major adverse cardiovascular events and stroke
- Erin is part of an outcome trial ongoing right now with the GLP-1 receptor agonists in persons who are overweight and obese, but without diabetes
  - She’s anticipating this will also be beneficial for cardiovascular disease

**Erin’s takeaway:**

- While we have new options to treat obesity, she’s really trying to focus on ***prevention of obesity*** in the first place, because it’s certainly not feasible to treat two-thirds of US adults who are overweight and obese
- The statistics are astronomical, they’re astounding

***We really need to focus on population interventions***

## GLP-1 agonists—Promising drugs for treating diabetes and obesity [33:30]

**Which** [**GLP-1 agonist**](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist) **are we looking at now? Is it** [**semaglutide**](https://en.wikipedia.org/wiki/Semaglutide) **or** [**tirzepatide**](https://en.wikipedia.org/wiki/Tirzepatide)**?**

- They are different
- Semaglutide is a GLP-1 receptor agonist
  - In patients with type 2 diabetes, we have cardiovascular outcome data for the injectable, subcutaneous dose
  - There is an outcome data trial ongoing for the oral formulation, but we don’t have that data yet, so usually Erin prescribes the injectable form
- [Tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) is ‘the new kid on the block’
  - It’s a dual agonist, a GIP GLP-1 receptor agonist
  - It has been approved also for **diabetes**, although the outcome trial for diabetes is ongoing (the SURMOUNT outcome trial)
  - But it also has been evaluated for **weight loss** and really showed dramatic weight loss, up to 50 pounds in the highest dose, which is really remarkable
- We can’t compare trials head to head because they were not compared head to head
- In the [trials with tirzepatide](https://www.nejm.org/doi/full/10.1056/NEJMoa2206038), there was about a 30 or so pound weight loss
- Tirzepatide is not yet FDA approved for weight management, although it will likely have this indication soon
  - It is approved for type 2 diabetes
- Semaglutide is approved for both type 2 diabetes for reduction in major adverse cardiovascular events
  - It also has a separate weight loss indication for persons who are obese with a BMI above 30, or overweight with a BMI over 27 in the setting of one or more obesity related cardiovascular risk factors who need additional weight management after diet and lifestyle attempts

**What is the mechanism by which the GLP-1 agonist and the dual receptor agonist reduce cardiac events?  Is it beyond weight loss?**  **What about** [**SGLT2 inhibitors**](https://en.wikipedia.org/wiki/SGLT2_inhibitor)**?**

- Erin doesn’t think we fully understand all the mechanisms for benefits of GLP-1 receptor agonists
- We do know the benefits of reducing major adverse cardiovascular events are independent of its [A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) lowering
- These are interesting agents that in persons with elevated glucose such as diabetes, they lower blood glucose
- But in persons who don’t have elevated glucose (such as those who are overweight and obese who don’t have diabetes), GLP-1s don’t cause hypoglycemia
  - They only lower blood glucose in a glucose-dependent fashion
- The benefit on [MACE (major adverse cardiovascular events)](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events) has been shown in persons with Type 2 Diabetes, is independent A1C lowering and may in part be related to favorable changes and other risk factors such as reduction in blood pressure and weight loss
- There’s improvement in the lipid panel that’s being investigated also in [NAFLD (non-alcoholic fatty liver disease)](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease)
- There may be anti-inflammatory effects; there may be anti-atherosclerotic effects
- There also may be some effects in the kidney
- We do see a reduction in [albuminuria](https://en.wikipedia.org/wiki/Albuminuria) with these agents, as well

## Female-specific risk factors for ASCVD (pre- and post-menopause) [37:15]

**In premenopausal women, what’s happening in a woman’s body when she’s 25 that’s different from a man’s body when he’s 25 that impacts the process of ASCVD?**

*Differences in risk factors for women*

- Diabetes and smoking confer a greater relative risk in women than in men
- Women have unique risk factors that we’ll talk more about throughout their lifespan related to
  - Menarche when early or late
  - Polycystic ovary syndrome
  - Infertility
  - Spontaneous pregnancy loss
  - Parity
  - Adverse pregnancy outcomes like preeclampsia
  - Lack of breastfeeding
  - Early menopause
- Chronic inflammatory conditions like rheumatoid arthritis and lupus are more prevalent in women

*Cardiovascular disease also can be different in women*

- This is why we need more trials in women
- Women are more likely to have [ischemia](https://en.wikipedia.org/wiki/Ischemia) with non-obstructive coronary disease from coronary microvascular dysfunction or [coronary vasospasm](https://en.wikipedia.org/wiki/Coronary_vasospasm)
- They’re more likely to have [SCAD (spontaneous coronary artery dissection)](https://en.wikipedia.org/wiki/Spontaneous_coronary_artery_dissection)
- They’re more likely to have [stress cardiomyopathy](https://en.wikipedia.org/wiki/Takotsubo_cardiomyopathy) than men
- Erin points out, “*We really need more data about treating cardiovascular disease in women*”

**Differences in sex hormones in women that affect ASCVD**

***Estradiol is the predominant female sex hormone in women of reproductive age that seems to have the beneficial effects with lowering LDL and conferring some cardiovascular protective properties***

- There are 3 types of estrogen
  - 1 – [Estradiol (E2)](https://estradiol) is the predominant one in women in childbearing age, and this is the most potent form of estrogen
  - 2 – [Estriol (E3)](https://en.wikipedia.org/wiki/Estriol) is the main estrogen producer in pregnancy
  - 3 – [Estrone (E1)](https://en.wikipedia.org/wiki/Estrone) is the only estrogen produced after menopause
    - It’s also the weakest estrogen
- Puberty is a process that starts in the brain, the hypothalamus in the brain suddenly begins secreting [gonadotropin-releasing hormone (GnRH)](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone)
  - [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) and [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) levels gradually increase during puberty, which stimulate the molecule maturation and estrogen production in the ovaries and also the secondary sex characteristics like breast changes and changes in body composition
  - This gets to the point where then there’s the onset of menarche or the first menses (typically around age 12)
- Erin asks adult women about the onset of menarche because both *early* menarche (before the age of 11) and also *late* menarche (after the age of 17) has been associated with increased cardiovascular disease risk later in life
  - There is likely hormonal and cardio metabolic imprinting that’s related to this
- Lots of factors are related to the onset of menarche‒ socioeconomic factors, environmental factors, and genetic factors
- Elevated BMI is a risk factor for early onset menarche‒ “*Which is why, again, it’s so important that we think about healthy lifestyle starting in childhood*”

**Lipids change through the menstrual cycle**

- Total cholesterol can change as much as 10-12 mg/dL (similar differences are seen in LDL cholesterol)
  - This is probably not clinically significant in terms of atherogenesis as most women of reproductive age have lower LDL
  - It *does matter* when thinking about the **timing of measuring lipid panel** during the menstrual cycle
- During the menstrual cycle, the hypothalamus releases GnRH, which causes the pituitary gland to release FSH
  - The figure below shows how the levels of these hormones change over the course of the menstrual cycle

![](https://peterattiamd.com/wp-content/uploads/2022/10/f2-erinmichos-1024x992.png)

**Figure 2.  Hormone levels throughout the menstrual cycle.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Menstrual_cycle)

- FSH is acting on the ovaries to mature the follicles
- The follicles of the ovaries is what secretes estradiol
- And so estradiol causes the maturation of the egg and the thickening of the uterus lining and preparation for a fertilized egg implant
- Increased estradiol triggers the release of LH, which induces ovulation and release of the egg
- And so ovulation ends the follicular phase (see the figure above)
- After ovulation, you’re in the luteal phase where estradiol with progesterone prepare the womb for implantation
- But if the egg isn’t fertilized, the corpus luteum (which is secreting the progesterone) breaks down, and this leads to a drop in progesterone level in the beginning of the menstrual period

**What this means for lipids**

***Total cholesterol and LDL increase rapidly after mense and peak during the follicular phase***

- Then this is followed by a decline in the luteal phase, which corresponds to the rise in the peak concentration of estrogen and progesterone

***When estradiol is the highest in the menstrual cycle, this leads to a fall in total cholesterol and LDL***

- **HDL** is highest around ovulation
- **Triglycerides** didn’t really have a consistent pattern during the menstrual cycle
  - So there isn’t specific guidance
- It’s interesting to note this change in cholesterol during the menstrual cycle
  - This is useful to know for women who are at very high risk for ASCVD and we’re trying to target these really intensive thresholds (like LDLs less than 70 or even lower)
  - So while there’s no specific guidance around this, Erin generally recommends clinicians measure the lipid panel during the menses so that it’s ideally measured, monitored, and compared at the same time during the menstrual cycle
    - Usually the menses is easiest to benchmark to
- Peter relates, “*We do that when we’re concerned with women becoming perimenopausal and we want to start getting a sense of what’s happening, we always use day 5. So if the initiation of menses, even if it’s spotting is day 1, but we always just pick day 5 and that way we have a really consistent view specifically of FSH and estradiol. Progesterone is zero at that time, but the FSH and the estradiol really give us a sense of how close she’s probably getting to menopause and then we correlate that with symptoms to sort of start to think about initiating HRT.*” (but this is a whole other topic)
  - Erin adds, FSH would be the highest during the early follicular phase and then it declines after ovulation
  - LH is low during the early follicular phase and peaks around ovulation (which stimulates the egg to be released)

***In terms of lipid panel, it’s good to be measuring around the same time each month***

- For premenopausal women, on average there is about 10-year offset of ASCVD in women developing it later than men
- This may be due to the **loss of estradiol after menopause**
  - LDL levels rise after menopause
  - Women may have higher LDLs later in life
- When we get back to what we started with, about the integration of duration of LDL exposure in terms of cholesterol years, ***women may have had lower number of cholesterol years during their childbearing years and then higher levels later in life***
  - And that might be why they have this offset
- But again, you don’t see this in FH (familial hypercholesterolemia) and we don’t see this in diabetes

***Realize that each person is an individual and so we do women a disservice when we presume that all women somehow are lower risk or protected during their premenopausal years***

- Earlier we said we see myocardial events (atherosclerotic myocardial infarction) in younger women too
  - They’re at lower risk but not zero risk

## Polycystic ovary syndrome (PCOS): prevalence, etiology, and impact on metabolic health, lipids and fertility [47:00]

[**Polycystic ovary syndrome (PCOS)**](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome) **is the most common endocrine abnormality of women of reproductive age**

- Estimates are about 5 to 13% of women in the general population are affected
  - It affects women of all races and ethnicities
- It’s characterized by this triad of [hyperandrogenism](https://en.wikipedia.org/wiki/Hyperandrogenism), ovulatory dysfunction (irregular menses or [anovulatory cycles](https://en.wikipedia.org/wiki/Anovulatory_cycle)), and polycystic ovary morphology
  - So just having a cyst ovary in itself is not enough for diagnosis
  - You need to have these other criteria
- It is a heterogeneous disorder and there are differences in risk with PCOS
- If you talk about the classical PCOS that has the **hyper androgen form**, this seems to be the one that is the most strongly linked with cardiovascular risk and the cardiometabolic phenotype
- We really think that [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance) is the hallmark underlying the pathogenesis of this
  - That there are molecular defects in insulin activities in PCOS that leads to impaired glucose tolerance and glucose insulin resistance and hyperinsulinemia
- Studies have shown that about 95% of obese women with PCOS and about 75% of lean women with PCOS have insulin resistance
  - There is a lean PCOS phenotype, though most women with PCOS do have an elevated body mass index

***This insulin resistance is probably driving a lot of the cardiometabolic complications***

*Cardiometabolic complications in women with PCOS*

- There is a triad of dyslipidemia‒ elevated LDL, elevated triglycerides, and low HDL
  - This is the metabolic syndrome pattern
- PCOS is associated with hypertension and incident hypertension
  - This is actually independent of BMI
  - But obesity increases the risk and makes the risk greater
- And there is an association, not only with increased subclinical atherosclerosis, but also with increased cardiovascular disease later life.
  - Erin recently published a [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/35575750/) where they showed that women with PCOS were 2-fold more likely to have coronary calcium
    - They’re also more likely carotid plaque
    - And it’s associated with increased cardiovascular disease later life
- Estimates have varied across studies and this is likely because of how PCOS was defined and how cardiovascular disease was defined, and so it’s not quite consistent across every study

***On average, there is about 30-50% increased risk of future cardiovascular risk for women with PCOS***

- There is a debate about whether PCOS is causally related to CVD
- The excess risk for these women seems to be during reproductive age
- After menopause, having a prior history of PCOS doesn’t seem to confer the same level of risk
  - This is likely because of all of the increased risk after the menopause transition
  - The low estradiol and the more androgen phenotype after menopause probably outweighs or overshadows any prior risk due to PCOS
- But there does seem to be this long term risk
- When you look at [Mendelian randomization studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6300389/), they suggest that the elevated testosterone, the hyper androgen, the obesity, the higher insulin levels, insulin resistance and lower levels of sex binding globulin do appear to have a causal relationship with PCOS based on genetics
- And so it may be that these are the mediating factors that link PCOS with future cardiovascular disease risk

**Impact on fertility**

- PCOS is associated with infertility
- One of the mainstays of treatment for PCOS in women who are not wanting to become pregnant is oral contraceptives
  - To reduce the hyperandrogenism
- Erin recently published a [study](https://pubmed.ncbi.nlm.nih.gov/35175837/) looking at national data of pregnancies at delivery and showed that women with PCOS who did become pregnant were at greater risks for preeclampsia
  - There were more cases of gestational diabetes and cardiovascular complications in women with PCOS
- It’s important to note that not only are they at increased risk, have decreased fertility and trouble getting pregnant, that once they do become pregnant they are at increased risk of cardiovascular complications in delivery

***So it’s really important with PCOS that we optimize healthier lifestyle and weight management to mitigate some of the cardiometabolic risk***

- Erin thinks a GLP-1 receptor agonists may help women with PCOS (who are not trying to become pregnant), help them with weight management and insulin resistance
  - Even statin therapy may reduce some of the testosterone or androgen associated risk

## The effect of grand multiparity (having 5+ children) on cardiovascular disease risk for women [52:30]

**Are multiple pregnancies associated with an increased risk of ASCVD or a decreased risk based on the estrogen?**

- When you look at parity (or the number of live births), there does seem to be a J-shaped relationship with more than 4-5 live births being associated with subsequent risk of cardiovascular disease
  - The reason for this is not quite known
- Erin showed in the [MEZA study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7244341/) (Multi-Ethnic Study of Atherosclerosis) that women who had grand multiparity were much more likely to be in poor cardiovascular health later in life at middle aged to older age compared to less parus women
- Women tend to gain weight with each pregnancy
- There may be also dysregulation of adipokines that sets the stage for later cardiometabolic complications
- This is why it’s really important that we try to optimize women’s cardio metabolic health before pregnancy and between pregnancies, to try to prevent these long term complications
- Erin wouldn’t tell a woman that they can’t become pregnant a certain number of times, but she would really try to work with them to try to optimize their cardiometabolic health

**Confounders in epidemiology studies on the number of pregnancies and cardiovascular disease**

- Peter thinks the obvious observation is that the more pregnancies a woman has, the more likely she will have difficulty getting back to her never-pregnant state of metabolic health
  - This seems like a big risk factor
- Erin points out that epidemiology studies don’t ask men about their parity history
- A couple [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5625954/) *did* ask men about their number of children, and increased parity seems to be a risk factor for CVD in men too
- This gets to Peter’s point about confounding by social economic factors and cultural factors, education factors that might lead a family to have more children rather than less
- But the risk does seem to be a little greater in women suggesting that there may be some true biological effects, maybe weight mediated beyond just confounding by socioeconomic and cultural factors

## The impact of oral contraceptives on cardiovascular disease risk [55:00]

**What is the impact on a woman’s lifelong risk of ASCVD of using oral birth control for a decade?**

- Let’s say the woman goes on oral birth control from age 25-35, has kids from 35-40, and then goes through menopause at 50
- Women of reproductive age may initiate oral contraceptive therapy for various reasons other than pregnancy prevention‒ treatment of menstrual cycle disorders, PCOS, acne, there’s lots of reasons
- The risk depends on the formulation and type; so we can’t link all contraceptives in 1 bin
- Estrogen can increase triglyceride levels and it can lower LDL (which is a good thing)

*What is the net effect on apoB?*

- Peter has seen analysis that once you correct for apoB, triglycerides below 400 mg/dL don’t really mean anything
  - Above that level you have to start worrying about pancreatitis
  - But apoB was capturing the risk
- If you’re only looking at LDL-C and triglycerides, it’s possible that a rise in triglycerides is problematic because that could actually raise apoB as you now have to increase the potential number of both cholesterol and triglyceride trafficking particles
  - But Peter would guess that this analysis isn’t usually done
- Erin adds that pregnancy also increases triglyceride levels a lot
  - So preventing an unwanted pregnancy outweighs the risk from a slight change in this lipids due to oral contraceptives
- She thinks the changes in lipids are relatively modest, especially since lower estrogen formulations are typically used now
- However, for women who already have high baseline triglycerides to begin with, it can trigger severe hypertriglyceridemia above 500 mg/dL
  - So you wouldn’t want these patients to go on oral contraceptives
- The **transdermal combined oral hormonal contraceptives (the patch)** is *less* likely to cause clinically relevant elevations in triglycerides
- There are other types of contraceptives that can be used by very high risk women with established cardiovascular disease or women who have FH (familial hypercholesterolemia) and have very high LDL levels
  - Long-acting reversible methods like the [IUD](https://en.wikipedia.org/wiki/Intrauterine_device) and [implant](https://en.wikipedia.org/wiki/Contraceptive_implant) are safe and effective
  - [Progesterone-based IUDs](https://en.wikipedia.org/wiki/Intrauterine_device#Hormonal) like the Mirena with the progesterone releasing IUD system, they can marginally *lower* associated with lower HDL, but usually these revert back to pre-insertion levels by 1 year
  - Most of the time for the IUDs, the triglycerides and LDL and the cholesterol ratios remain pretty stable

## The effect of pregnancy on lipids and other metabolic parameters [58:45]

**What happens to a woman during pregnancy?**

- Peter recalls, during 1 of his wife’s pregnancies he did a thorough look at her lipids all the way through pregnancy and was shocked at how much her lipids rose during pregnancy
  - She is one of those people who genetically has a very low level of apoB
  - Her baseline LDL is probably 60-70 mg/dL
  - Her HDL-C might be 80-90 mg/dL
  - Her triglycerides around 40 mg/dL
  - By the end of her 2nd trimester/ beginning of the 3rd trimester, she looked like she had metabolic syndrome without the triglycerides
- There are changes in the lipid panel, which is why women with known lipid disorders are recommended to have consultation with a lipid specialist prior to pregnancy
- But even normal pregnancies, serum total cholesterol, triglycerides, LDL cholesterol, Lp(a) and HDL cholesterol levels all gradually increase
- And as pregnancy proceeds, they peak during the 3rd trimester

***You can have about a 25 to 50% increase in total cholesterol, and as much as 150-300% increase in triglycerides, and LDL increase by 66%***

- These are **normal physiologic changes** because it’s designed to promote accumulation of maternal fat stores that’s going to be a source of calories for the mother and the fetus during later stages of pregnancy and lactation
- The cholesterol increases are needed for utero, placental vascularization, placental steroids, synthesis, placental transport function
  - These are important physiological effects
- For someone like Peter’s wife, who started out with low cholesterol levels, these changes are generally thought to be non-atherogenic because they return back to pre-pregnancy levels following delivery
- Erin notes, “*Pregnancy is not a good time to get a baseline lipid panel because it’s not going to be representative of what a woman’s typical lipid panel is*”
- For women who have concern for **lipid disorder**, having a baseline lipid panel before pregnancy is helpful so that you can know what to expect
- And women with **FH**, they have the same relative increases, but they’re starting with such a high baseline level that the magnitude of elevation is even greater

## The undertreatment of women with familial hypercholesterolemia (FH) and how it increases lifetime risk of ASCVD [1:02:00]

**Define FH beyond familial hypercholesterolemia**

- [FH](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia) affects about 1 in 250 people
- It’s [autosomal dominant](https://en.wikipedia.org/wiki/Dominance_(genetics)), women are equally affected as men
- The FH phenotype is LDL above 190
  - There are different scoring systems that you can look with additional criteria based on personal family history of ASCVD
  - [Genetic tests](https://www.ncbi.nlm.nih.gov/gtr/conditions/C0020445/) are available
  - There are apps that you can download to determine the likelihood that your patient has a probable FH
- Just even having the phenotype of having an LDL above 190 (which is not all [monogenic](https://en.wikipedia.org/wiki/Genetic_disorder#Single_gene_disorder) FH) is still associated with increased lifetime risk with a 20 to 30 year earlier onset of ASCVD in females

***But having the monogenic mutation, their increased risk is even greater than their LDL value***

- So that’s why genetic testing is really helpful, not only for cascade effects for determining the risk of their first degree relatives and their offspring, but also because they have a greater risk even beyond their absolute LDL value

> “*30% of women with an untreated FH will have a myocardial infarction before the age of 60*”‒ Erin Michos

- This is why we can’t ignore FH, we need to screen for it and treat it
- Women get the same onset as men, they don’t have the female advantage
  - Probably because they’re losing many years of statin therapy because this concern about pregnancy
  - Women with FH are undertreated
- It is interesting to note that women with FH don’t have an increased risk of congenital malformations or preeclampsia (which is good)
- Women may have a slight increased risk for myocardial infarction
  - So we can talk about shared decision making about treatment during pregnancy versus withholding treatment for a short period of time during pregnancy and lactation
- In some countries, you can actually test for the mutation in cord blood
- And lipid levels in children with FH are similar whether they inherited the gene from their mother or the father
- But for contraception, because of their increased risk for atherosclerosis, we would want to avoid any higher estrogen compounds
  - Either use low dose estrogen oral contraceptives, or preferably IUDs or barrier techniques, especially if they’re over the age of 35 to avoid the estrogen oral agents (even low dose)
- Peter adds that we don’t know the genetic cause of FH for most people with this disease
  - Last he checked there were more than 2,500 different genetic mutations that produce that phenotype

**How many of the genetic drivers of FH do we know contribute to the phenotype of having increased risk of ASCVD beyond that associated with high LDL-C?**

- When Erin evaluates patients for FH she sends them for genetic testing (if they’re willing) to determine if they have the monogenic form of FH due to a mutation in the [LDL receptor](https://en.wikipedia.org/wiki/LDL_receptor) or [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) of [PCSK9](https://en.wikipedia.org/wiki/PCSK9) or if they have a [polygenic](https://en.wikipedia.org/wiki/Polygene) risk that can produce a similar phenotype to FH
  - She certainly wants to reduce their lipids
- There has been a concern for a long time about avoiding statins in pregnancy
- This actually led to overabundance of caution with just not treating women of reproductive age with statins at all because of fear that they might accidentally become pregnant

***We do them a disservice because a third are going to be a risk for a MI (myocardial infarction) before age 60 if they have FH and we don’t treat***

**Statin use during pregnancy**

- We have more data now suggesting that women who did become pregnant while on statins did not show [teratogenic effects](https://en.wikipedia.org/wiki/Teratology)
- And so statins are probably not teratogenic
- We don’t have a ton of data here, which is why we still have some caution

***For most women who are planning a pregnancy, we do generally stop the statins during conception, during pregnancy, and during breastfeeding***

- If a woman does become pregnant while on statins, Erin reassures them and they stop the statin
- There’s a really interesting body of work now about whether statins can actually prevent **preeclampsia**
- So in the setting of preeclampsia, there’s this abnormal trophoblast invasion and this leads to impaired spiral artery remodeling
  - Essentially what’s happening is there’s placenta ischemia and this sets off a whole cascade of adverse hormonal and anti-inflammatory markers
  - So we have this *increase* in [sFlit-1](https://en.wikipedia.org/wiki/Soluble_fms-like_tyrosine_kinase-1) and a *decrease* in [placental growth factor](https://en.wikipedia.org/wiki/Placental_growth_factor)
  - There’s this increased sensitivity to [angiotensin II](https://en.wikipedia.org/wiki/Angiotensin#Angiotensin_II), there is other inflammatory and oxidative stress
  - And this sets the stage, not only for complications during the pregnancy like preeclampsia, but also is likely contributing to vascular damage that increases a woman’s risk long term after delivery
- So statins are being investigated for preeclampsia prevention because we know in [animal studies](https://pubmed.ncbi.nlm.nih.gov/27856999/) they can decrease sFLIT-1, they can improve endothelial function, they can decrease inflammation and oxidative stress
- There was one [study](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.121.053963) that was published where they gave women who are pregnant who are at increased risk of preeclampsia, pravastatin starting at 35 weeks gestation, and didn’t show any benefit in preventing preeclampsia but this isn’t really surprising because it was just given way too late
  - If you know anything about the pathogenesis of preeclampsia, preeclampsia can generally start after 20 weeks of gestation, so you likely would have to intervene much earlier in the process
- There is a randomized clinical trial ongoing now, enrolling about 1500 women who are at high risk because of a prior history of preeclampsia, and they’re starting the pravastatin versus placebo earlier, around 12 weeks of gestation (so right after the first trimester)
  - The primary outcome is going to be the proportion that develop preeclampsia or fetal loss and maternal death
  - And they’re looking at other things like preterm delivery
  - We don’t have those results yet but it may be a whole pendulum switch from this absolute avoidance of statins during pregnancy, to maybe actually using statins for preeclampsia prevention if this trial is successful

## How concerns around statins have contributed to undertreatment, and whether women should stop statins during pregnancy [1:09:45]

**Is there a trend toward a fear of using statins?**

- Yes, even in the non-pregnant state
- Erin hears people cite this false statement, “*Statins don’t work in women in primary prevention*”
  - They just didn’t enroll enough women in trials and in primary prevention
  - Women are at lower risk so they’re less likely to have events during the short terms of the trials

> “*Women benefit from statins just as much as men*”‒ Erin Michos

- A [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/25579834/) that included over 18 randomized clinical trials, over 40,000 women, have shown that statins benefit women in both primary and secondary prevention
  - Without interaction by sex, meaning in similar risk individuals, women benefit from statins just as much as men
  - In primary prevention there was a ***15% reduction in major adverse cardiovascular events***, as well as for every 1 mmol/L (or 39 mg/dL) lowering of LDL
  - And in secondary prevention there was a 22% reduction, as well as all cause mortality was lower in women with statins
  - Of course, the women that were enrolled in these trials were at higher risk, but the important thing is that they benefited similarly to men with no effect interaction

**Was it in the ballpark of men where your primary preventions could be anywhere from 60 to 100 and your secondary preventions might be 30 to 50?**

- This sounds about right to Erin, she doesn’t have the data in front of her, but it sounds right

***But despite the evidence clearly showing that they benefit, women are less likely to be offered a statin***

- We saw this from the [PALM registry](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5714300/)

***And if offered, women are more likely to decline or discontinue***

- In the usage registry, women were 30 to 50% more likely to report statin associated muscle symptoms and stop statins for this reason
- Even in secondary prevention, studies of individuals who have post myocardial infarction, young women under the age of 55 were significantly less likely than men to be on a statin 2 months after their [MI](https://en.wikipedia.org/wiki/Myocardial_infarction)
  - And these are the highest risk individuals, with a recent MI
  - And women are still less likely to be on a statin
- One of Erin’s [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6405598/) using nationally representative data from the medical expenditure panel survey found women were 45% less likely to be treated on a statin than with men
  - This is way to represent US adults with ASCVD
  - It’s a way to represent 11 million women with ASCVD

**What is the reason for this disparity in prescribing statins for women?**

*Is this due to physician ignorance or is this the patient, the woman saying “This is not the right thing for me”?*

- The [PALM registry](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5714300/) shows women are less likely to be offered a statin
  - So this is on the physician side
- We see this across all kinds of subgroups in both primary prevention, secondary prevention and also whether they were treated by a cardiologist or primary care‒ women are less likely to be on a statin
- But if the clinicians do the right thing and offer, women are more likely to decline or discontinue

***It’s a combination of things***

- Women may still perceive themselves to be lower risk
- Women may be more fear adverse
- Women report more likely to have statin associated muscle symptoms
  - And so this gets down to how much is real versus the [nocebo effect](https://en.wikipedia.org/wiki/Nocebo)?
  - Is it biological differences related to women’s smaller body size, influence of hormones?
  - Or is it that maybe women are more socialized to report symptoms or read these warning labels, or a possible symptom that could happen or be more concerned?
- We have overwhelming data about the safety of statins
- Serious muscle injury is 1 in 100,000
- In randomized clinical trials, there’s no difference of muscle symptoms between treated and placebo but we know in real world practice, up to 30% of statin treated patients report muscle symptoms
  - There’s this tremendous nocebo effect
- In trials like the [SAMSON trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8453640/), up to 90% of statin associated symptoms was elicited by the placebo too (shown in the figure below)
  - Patients were having symptoms on the statins but 90% of those symptoms were also elicited on the placebo, so it was more the act of taking the medication compared to the medication itself

![](https://peterattiamd.com/wp-content/uploads/2022/10/f3-erinmichos-1024x769.png)

**Figure 3.  Symptom scores are similar in patients taking a statin and placebo.**  Image credit: [*Journal of the American College of Cardiology* 2021](https://www.sciencedirect.com/science/article/pii/S0735109721057016?via%3Dihub)

- We know the nocebo effect is real but the problem is that this can be challenging to counsel
  - There’s a lot of medical misinformation out there
  - Symptoms are real to the patient and if they’re convinced they’re having these symptoms, it could be hard to break that mindset
- Erin’s practice is focused on building trust and a relationship over time
  - Sometimes she starts slow or uses alternative doses every other day or 3x a week to try to get patients back on their statin
  - She has them take a muscle symptom survey and see that a low of the aches and pains they are having are unrelated to the statin
- High risk patients who have report statin associated muscle symptoms or statin intolerance, really should be given a rechallenge

**The good news is we are in an era where we have more options than ever before**

- Ezetimibe
- PCSK9 inhibitors
- Closerin
- Bempedoic acid
- And more things in the pipeline
- We have ways to get to the LDL goal if patients are willing to work with us
- These other therapies are meant to be as an **adjunct to diet and lifestyle and maximally tolerated statins**
- For some patients the maximally tolerated statin is zero statin, and so sometimes we have to move to some of these other agents to get their LDL under control

## How Erin approaches the prescription of statins to patients [1:16:00]

**Erin’s statin workflow**

*For the highest risk patients with ASCVD she wants to get their LDL-C as low as possible as quickly as possible*

- We do a lot of disservice by starting on these really low dose statins where the patient doesn’t come back for 6 months to a year, and then they never get intensified and patients don’t get to the goal
- She starts with the **high intensity statin** upfront
  - It’s more likely they’ll stay on it
- She uses **combination therapy** early
- She aims for <55, optimal LDL-C is probably around 30 or lower in these patients

***High intense statins will lower the LDL by about 50% but if you need a greater reduction, think about combination therapy early***

- We have some data now about the safety of giving [PCSK9 inhibitors](https://en.wikipedia.org/wiki/PCSK9#PCSK9_inhibitors) even in the hospital setting after an acute myocardial infarction, they can have important changes in plaque stabilization and plaque reduction

> “*I wanted to make the plug about using combination earlier and more aggressively*”‒ Erin Michos

- For the **lower risk primary prevention patient**, the moderate intensity statin would be fine
  - It depends on their age, if it’s a man over 40 or women over 50, get a coronary calcium score
  - If they’re above this 75th percentile, she’s also thinking of a high intensity statin and aiming for an LDL less than 70
  - She also considers PCSK9 inhibitors even in primary prevention patients, if they have significant plaque, very high calcium scores above 300
  - But in a lower risk person where we’re just trying to shift them lower

**Which drug does Erin prefer to start with,** [**rosuvastatin**](https://en.wikipedia.org/wiki/Rosuvastatin) **or** [**ezetimibe**](https://en.wikipedia.org/wiki/Ezetimibe)**?**

- It depends on where they start at
- If they have ASCVD and are very high risk, she will begin with a [PCSK9 inhibitor](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target)
- If they have elevated Lp(a) she won’t use a statin
  - [Ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe) and [bempedoic acid](https://en.wikipedia.org/wiki/Bempedoic_acid) don’t lower Lp(a)
- It used to be to get PCSK9 inhibitors approved, the patient had to be on a statin and ezetimibe
  - Now it’s a little bit easier to get the PCSK9 approved even if you don’t have ezetimibe on board

***Ezetimibe can lower LDL by about 16 mg/dL but you want to really get the LDL way down in these very high risk patients***

**Erin moves pretty quickly to PCSK9 inhibitors**

*Does she have any preference between* [*Praluent*](https://en.wikipedia.org/wiki/Alirocumab) *and* [*Repatha*](https://en.wikipedia.org/wiki/Evolocumab)*?*

- These are monoclonal antibodies that bind and inhibit PCSK9
- They were never compared head to head
- Evolocumab (trade name Repatha) and Alirocumab (trade name Praluent) had a similar 15% reduction in major adverse cardiovascular events in their respective trials (the FOURIER and ODYSSEY trials, [reviewed here](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7237602/))
  - And they had similar reduction in Lp(a)
  - Erin uses which ever one she can get approved; it usually depends on the patient’s insurance
  - She tends to use evolocumab more because you don’t have to do the dose adjustment, the sure click pattern is really easy

## PCSK9 inhibitors and other non-statin drugs [1:21:15]

**The story of** [**PCSK9 inhibitors**](https://en.wikipedia.org/wiki/PCSK9#PCSK9_inhibitors)

- PCSK9 is a hepatic protein that’s involved with LDL receptor degradation
- It’s interesting how quickly we moved from genetic studies to translational studies (even from the bedside)
- We know that individuals with PCSK9 loss of function mutations had very low LDLs and a very low lifetime risk of cardiovascular disease
- Where as gain-of-function PCSK9 mutation resulted in high LDLs and increased CVD risk

***By inhibiting PCSK9, it prevents dehydration of the LDL receptor, and this results in an upregulation of LDL receptors on the surface of the hepatocyte which leads to greater clearance of LDL out of circulation***

**Benefits of PCSK9 inhibitors**

- The PCSK9 inhibitors that we were talking about ([evolocumab](https://en.wikipedia.org/wiki/Evolocumab) and [alirocumab](https://en.wikipedia.org/wiki/Alirocumab)) are monoclonal antibodies
  - They lower LDL by about 50-60%
  - They also lower Lp(a) by around 25%
- We have two outcome trials, FOURIER and ODYSSEY
  - FOURIER‒ patients who have stable ASCVD
  - ODYSSEY‒ patients with recent acute coronary syndrome
  - They show that PCSK9 inhibitors also reduce major adverse cardiovascular events (as we would anticipate)
- We now have longer term data for follow up, which shows even after these trials end, that earlier exposure to evolocumab (exposure to a lower LDL) has a legacy effect with continued lower risk of events
- Erin thinks the trials were pretty short (around 2 years) and the curves were just starting to separate
- She thinks with longer treatment, you would’ve had even a greater reduction
- Unfortunately in both of these trials, women were only about 25% of participants
- Women start out with higher LDLs for various reasons
  - After menopause, women tend to have higher LDLs compared to men
- But women had a similar reduction (compared to men) in LDL with PCSK9 inhibitor therapy
- In terms of MACE reduction (major adverse cardiac event), there was no interaction by sex
  - Meaning that these high risk women who either have ASCVD or recent acute coronary syndrome, benefited to a similar degree as men did
  - There was no major adverse event difference between the sexes, although women are more likely to report injection site reactions

***The guidelines now recommend PCSK9 inhibitors as an add-on to statins in high risk patients with ASCVD or heterozygous FH (who need additional LDL lowering)***

- Erin uses PCSK9 inhibitors in high risk primary prevention
  - Such as those with high calcium scores who need LDL lowering

**Inclisiran (trade name Leqvio)**

- [Inclisiran](https://en.wikipedia.org/wiki/Inclisiran) is the new kid on the block, it inhibits PCSK9 via small interfering RNA (a different mechanism, not a monoclonal antibody)
  - It prevents the translation of the PCSK9 protein (the protein is never made)
- We have [data](https://www.nejm.org/doi/full/10.1056/NEJMoa1912387) from the ORION 9, 10 and 11 trials, which was looking at LDL lowering, showing that again, women had higher LDLs at baseline but they had similar reduction with this treatment (summarized in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/10/f4-erinmichos-1024x689.png)

**Figure 4.  LDL reduction achieved with inclisiran.**  Image credit: [*NEJM* 2020](https://www.nejm.org/doi/full/10.1056/NEJMoa1912387)

- This drug is a subcutaneous injection
  - After the 1st baseline in 3 months, it’s given every 6 months
- It’s designed to be given in a clinic setting as opposed to monoclonal antibodies (which people give at home)
- And the frequency of every 6 months may be attractive for adherence because you give it in the clinic
  - Only one more time a year than a flu shot, and you can lower LDL by about 50%
  - It may be helpful for adherence
- It has been approved for LDL lowering and we’re starting to onboard it throughout the country and in our clinics
- But it should be noted that we don’t yet have the outcome data
- The ORION 4 is the cardiovascular outcome trial that’s ongoing, and Erin anticipates with a 50% reduction in LDL, that this will certainly translate into a reduction of major adverse cardiovascular events
- We don’t have that data yet but these are all potential options for patients that need more intensive LDL lowering

**Bempedoic acid**

- [Bempedoic acid](https://en.wikipedia.org/wiki/Bempedoic_acid) is another new drug that is available; it’s an oral drug
  - This one also might be interesting for women
- Bempedoic acid it blocks [ATP-citrate lyase](https://en.wikipedia.org/wiki/ATP_citrate_synthase), which is an enzyme in the cholesterol synthesis pathway
  - It’s upstream of [HMG-CoA reductase](https://en.wikipedia.org/wiki/HMG-CoA_reductase), which statins inhibit
  - It works in the pathway where statins work, where it blocks cholesterol synthesis

***By blocking cholesterol synthesis, this leads to upregulation of the LDL receptor on the surface of the liver and more clearance of LDL out of circulation***

- But what’s notable about this is that [prodrug](https://en.wikipedia.org/wiki/Prodrug), the enzyme to activate it is only in the liver (not in the muscle)
- It does not have the same reported muscle symptoms that have been seen with statins
- Interestingly, it doesn’t seem to have the risk of new onset diabetes or the increase in glucose that we see with high intensity statins.

***Alone bempedoic acid lowers LDL about 18% (in the range of*** [***ezetimibe***](https://en.wikipedia.org/wiki/Ezetimibe)***)***

- It lowers LDL a little more (21%) if it’s used as a monotherapy without statins
  - This is good for statin-intolerant patients

***It also comes as a fixed dose with ezetimibe, and in combination with ezetimibe there is about a 36% reduction in LDL (in the range of the moderate to high intensity statins)***

- Pooled analyses from the CLEAR studies indicates that women seem to have a little greater LDL lowering with bempedoic acid than men; they achieved 30% reduction in LDL
  - The [CLEAR study](https://www.ajconline.org/article/S0002-9149(22)00322-8/fulltext) looked at the LDL lowering effects of bempedoic acid in ASCVD and FH patients
- Bempedoic acid has been approved for LDL lowering but we don’t have outcome data yet for high risk patients with statin intolerance
  - The big cardiovascular outcome trial (CLEAR outcomes) enrolled a population with statin intolerance
  - Nearly 50% of trial participants were women, likely because women are more likely to have statin tolerance
  - This study has been closed out, and we’re anticipating we may hear the results maybe in March of 2023

## Advice for the low- and high-risk individual [1:28:30]

- Peter notes, “*Everybody gets atherosclerosis if you live long enough*”, so in the long term everybody is high risk

**What about a woman in her 30s whose LDL cholesterol is 130-140 mg/dL?**

- Nothing is going to happen to her in the next decade, but in the long term, she doesn’t want to have atherosclerosis in her 80’s
- Erin tends to use one of the high intensity statins because they are a bit more potent in lowering LDL
  - Such as [atorva](https://en.wikipedia.org/wiki/Atorvastatin) or [rosuva](https://en.wikipedia.org/wiki/Rosuvastatin)
  - But only in patients without [CKD (chronic kidney disease)](https://en.wikipedia.org/wiki/Chronic_kidney_disease)
- Erin uses rosuva a lot, patients tend to have a bit less muscle-associated symptoms
  - The dose may be 5, 10, 20; and patients feel like they’re taking a lower dose compared to an atorva dose of 20, 40, 80
  - She tells patients they can’t compare milligrams from one agent to another agent because they’re completely different drugs
  - So rosuva is good for statin hesitant patients and she will begin with a low dose to gain their trust and begin the habit of taking a statin
- These drugs are used in the background of **lifestyle changes**

> “*And then seeing a little bit is believing*”‒ Erin Michos

- When patients start getting their numbers back and making progress, often then she adjusts their dose up, based on how things are going

**For high risk patients**

- Erin starts at the highest dose right out at the bat
- Sometimes patients check vitamin D, thyroid levels, and coenzyme Q10
  - There really isn’t very good data that coenzyme Q10 prevents statin associated muscle symptoms, but if my patients want to take that because it makes them feel better with the concept taking a statin, she doesn’t object to it
    - But she doesn’t actively prescribe it because there really isn’t good data to support it
  - The same thing with vitamin D, there really isn’t good data that taking a vitamin D supplement can prevent statin associated muscle symptoms
    - But many patients want to take that
- Erin’s  philosophy is if she could get them on the statin and get their LDL lowering, she’s  willing to work with them on some of these other things, really trying to get their buy-in to get them on a therapy that will lower their LDL
- It’s really important that she refers them to the preventative cardiology nurse who discusses nutrition because she doesn’t want them to think that she don’t value diet and lifestyle

## The impact of nutrition, stress, and lifestyle on lipids and CVD risk [1:31:00]

**What effect can you see on LDL cholesterol by manipulating types of fats in the diet, particularly for women who want to avoid using lipid lowering medication?**

- Erin notes, “*We know that a lot of lipids are predominantly genetically determined but there is influence in diet*”
- She wants to emphasize to patients that this is really a combination approach and that she does take diet and lifestyle very seriously as well

***About 80% of LDL is synthesized by the liver, so there is a strong genetic component***

- Erin has lots of patients that are strict vegan and do everything right and they still have high cholesterol and they get so frustrated
  - If they had a bad diet, their numbers would be so much worse
  - So it’s important to note all the good things that they’re doing for their diet but also acknowledge that sometimes they’re going to need a little help with pharmacotherapy because of the strong genetic determination
- But the other 20% is influenced by **diet**, so diet does matter
  - Particularly in younger adults, thinking about adolescents and young adults

> “*If we can shift everybody a little bit lower in their LDL by following a healthy diet from early childhood, this will reduce the total burden of years with LDL elevation*”‒ Erin Michos

**Erin counsels her patients**: about reduction in saturated fats and focusing on the healthier fats (the polyunsaturated and the monounsaturated fats), increasing fiber, fruits, vegetables, whole grains into their diet, and really trying to avoid processed foods (which are the worst, especially processed meats)

- There’s some patients that already have ASCVD and they don’t want to take a medicine, and at this point, it’s too late

***Diet’s important but if you already have plaque in your arteries, you’re pretty far along in the process and we need to do everything to prevent further progression and even reverse disease***

- We know from the [IVUS studies](https://www.sciencedirect.com/science/article/pii/S0735109715026820?via%3Dihub) that high intensity statins and significant LDL lowering can cause [atheroma](https://en.wikipedia.org/wiki/Atheroma) volume regression
- It’s really a combination of pharmacotherapy and lifestyle changes

***For a very low risk young adult, Erin pushes as hard as she can with healthier lifestyle changes***

- Peter notes that he has gone back and forth so much on this stuff
- He just went through as many of the Cochrane collaboration meta-analyses as he could on the impact of different fatty acids on cardiovascular disease
  - The [Cochrane collaboration from 2018](https://doi.org//10.1002/14651858.CD012345.pub3) looked at the role of [PUFAs (polyunsaturated fatty acids)](https://en.wikipedia.org/wiki/Polyunsaturated_fatty_acid)
  - The [one in 2020](https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD011737.pub3/full) looked at [SFA (saturated fatty acid)](https://en.wikipedia.org/wiki/Saturated_fat) substitution with PUFA and [MUFA (monounsaturated fatty acid)](https://en.wikipedia.org/wiki/Fat#Monounsaturated_vs._polyunsaturated_fat)
  - The conclusion he came away with is, “*I don’t know how much any of that stuff matters once you’re in* ***energy balance****. In other words, in the context of over nutrition, I think it all is bad. In the context of adequate nutrition, the ambiguity in these data was enormous.*”
- On the basis of [PREDIMED](https://www.nejm.org/doi/full/10.1056/NEJMoa1800389) and the [LYON heart study](https://www.ahajournals.org/doi/10.1161/01.CIR.99.6.779) (and other epidemiology), MUFA is probably the most important fatty acid

**Peter’s takeaway:** Probably 50% of your fat intake should be MUFA, and after that it looks like PUFAs are a little better than SFA, but there’s no evidence to suggest that aggressive restriction of SFA is protective

*The recommendation is different for people who have incredible hypobetalipoproteinemia*

- For them, consuming massive amounts of saturated fat is a clear problem

**Stress is another lifestyle factor contributing to cardiovascular disease**

- When Peter thinks about all the lifestyle factors, he wonders if the one that gets the least attention is stress, because we don’t have a pill for it
- We can offset the harm of nutrition more easily with pharmacotherapy
- But it’s difficult to manage the effects on endothelium and the sympathetic nervous system of a person walking around with simmering hypercortisolemia
  - He wishes we had a better handle on how to help these people
  - Outside of blood pressure management, we don’t have a pill for that

**Erin recommends a Mediterranean diet**

- The HACC guidelines talk more about a moderate fat intake diet
- Erin recommends a [Mediterranean style diet](https://en.wikipedia.org/wiki/Mediterranean_diet) to her patients
  - This is pretty palatable and easy to follow without getting too crazy
  - It’s generally low in saturated fats and higher in unsaturated fats
  - It contains a lot of fruits and vegetables
  - But it’s also the **Mediterranean lifestyle** with increased physical activity
    - Although exercise may have less impact on lipids than diet, but it has a significant impact on overall cardiovascular risk
    - Exercise helps with both weight maintenance and increased level of fitness

> “*Being more fit is one of the strongest favorable factors for lower cardiovascular risk*”‒ Erin Michos

- Erin encourages regular physical activity as well

**The effects of mental health on cardiovascular disease**

- Erin doesn’t think you can talk about cardiovascular health without talking about mental health
- She was co-author on the [American Heart Association statement](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000947) that came out last year about the mind/heart/body connection, where they really talk about both positive psychological factors and negative psychological factors that influence cardiovascular health (both in indirect ways and direct ways, summarized in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/10/f5-erinmichos-1024x610.png)

**Figure 5.  Psychological factors that influence cardiovascular health**.  Image credit: [*Circulation* 2021](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000947)

*Indirect influence of mental health*

- Individuals with more **negative psychological factors** like anxiety, stress, depression, anger, they might be more likely to have poor coping habits, such as eating more poorly and not getting physical activity and having more smoking or more alcohol intake and less follow up with preventive interventions
- Whereas individuals with **positive psychological factors** such as having a sense of purpose and more optimism, they may be more likely to eat healthy and exercise and take their medications and follow up with preventive visits

*Direct mechanisms where mental health influences cardiovascular disease*

- Stress leads to activation of the sympathetic nervous system, increasing heart rate, increasing blood pressure, increasing release of stress hormones like cortisol
  - That can lead to more insulin resistance, more fat deposition in the visceral cavities and more low grade chronic inflammation
  - We know that inflammation can also be a trigger for plaque rupture

> “*I do think it’s important that we think about the whole person*”‒ Erin Michos

***We can make all these recommendations about managing their lipids and things but if we don’t take into account some of the challenges that people have in their personal lives and social determinants of health, we may not be able to effectively deliver preventive interventions***

**The 5 pillars through which we can impact a person’s health‒ nutrition, exercise, sleep, emotional and mental health, and pharmacotherapy**

- When Peter thinks of these 5 pillars, “*The lowest impact in my view on cardiovascular disease is through nutrition. I think the other four trump it all day every day and twice on Sundays. I don’t even think it’s close*.”
- He mentions it because the general public seems to think that nutrition is the most important lever in controlling cardiovascular disease risk
- He sees the person who ostensible is eating “a healthy diet”, yet they still have these biomarkers that are horrible and/or they have evidence of clinical disease
  - Yet they think they have it under control because of their dietary choices
  - He wants to tell them, “*No, you don’t even have it close to under control, and your diet is not even remotely helpful at controlling this.*”
    - He compares it to rearranging the deck chairs on the Titanic
- The other 4 pillars are going to move the needle far more, though in different amounts in different people
- For some people, he doesn’t think stress plays a role while in others, it plays an enormous role
- Everytime Peter is in Europe (especially in Italy), he comes to the same conclusion, their lifestyle is 90% of it
  - They’re not as wound up as we are
  - They’re way more active
  - They eat less
  - There is a sense of , “*It’s all okay*”

## Lp(a) as a risk enhancer for cardiovascular disease [1:41:15]

- We’ve talked about [Lp(a) on the podcast](https://peterattiamd.com/benoitarsenault/), but we haven’t discussed it through the lens of women versus men, what happens during pregnancy, what happens after menopause

**Primer on Lp(a)**

- [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) is an LDL-like *particle* that contains 2 proteins‒ apoB (which is the mark of the bad moieties) and apolipoprotein(a) [abbreviated apo(a)]
  - The Lp(a) particle is depicted in the figure below where apoB is the red shape and apo(a) is the multi-colored, squiggly structure on the outside of the particle (linked by KIV9 to apoB)
- Lp(a) shares protein with other atherogenic lipoprotein

***Lp(a) also has an apolipoprotein(a) moiety, and that’s what distinguishes Lp(a) from LDL***

- This apo(a) is unique because it has these 10 sub-domains of these kringle IV domains, and the kringle 2 [KIV2] can expand 2 to 40 times (highlighted in yellow in the figure below)
  - This genetic variability leads to a lot of heterogeneity in the population

![](https://peterattiamd.com/wp-content/uploads/2022/10/f6-erinmichos-959x1024.png)

**Figure 6.  Genetically, apo(a) has a variable number of kringle IV type 2 (KIV2) repeats (highlighted in yellow)**.  Image credit: [*Journal of the American College of Cardiology* 2017](https://www.sciencedirect.com/science/article/pii/S0735109716372540?via%3Dihub#bib9)

- 80% or more of individuals carry 2 different isoforms of apo(a), 1 inherited from each parent
- And so it’s important to recognize this heterogeneity in the multiple isoforms because ***this accounts for some of the differences in cardiovascular risk that we see by race or ethnicity***
  - With higher Lp(a) levels being seen in black and South Asian individuals compared to white individuals

**Differences in Lp(a) in women**

- Lp(a) is generally 5-10% *higher* in women than men
- This also changes over the course of life
  - Lp(a) is relatively constant in men
  - In women, it tends to increase after **menopause**
- During **pregnancy** Lp(a) increases
  - It doubles between weeks 10-35
  - Erin notes, “*We think Lp(a) levels fall back to their pre-pregnancy baseline after delivery and this short increases is probably not atherogenic*”

**Why do we care about Lp(a)?**

- It’s atherogenic, proinflammatory and prothrombotic
- It’s associated with cardiovascular risk and as likely from Mendelian randomization studies causally related to both ASCVD as well as specific aortic stenosis
- Even in individuals who have LDLs less than 70 (like in the [Copenhagen General Population Study](https://www.bmj.com/content/371/bmj.m4266.long)), Lp(a) above 50 mg/dL is still associated with risk of cardiovascular meds

***High Lp(a) is still associated with risk even when LDL is low, and you really need to measure it because you may be missing some residual risk depending on whether Lp(a) is making up a significant component of LDL***

- Mendelian randomization studies do suggest that Lp(a) is causally associated with cardiovascular risk in women
- But the impact of therapies and lowering Lp(a) and what that translates into actually lowering cardiovascular risk is a little bit uncertain

**Options for lowering Lp(a)**

- [Apheresis](https://en.wikipedia.org/wiki/LDL_apheresis) is an option for a patient with very high Lp(a) who has progressive cardiovascular disease
- Monoclonal antibodies that block PCSK9, [evolocumab](https://en.wikipedia.org/wiki/Evolocumab) and [alirocumab](https://en.wikipedia.org/wiki/Alirocumab), as well as [inclisiran](https://en.wikipedia.org/wiki/Inclisiran) can lower Lp(a) about 20-25%
- In trials, individuals with higher Lp(a) levels derived the greatest benefit from these therapies

**Erin’s takeaway:** ***If somebody has elevated Lp(a), think about moving quickly to PCSK9 [inhibitors] if they have another indication such as elevated LDL***

- Lp(a) is a **risk enhancer**, and this is why we measure it

**New therapies are being studied right now in trials**

- [Pelacarson](https://www.ionispharma.com/medicines/akcea-apoa-l/) is an [antisense oligonucleotide](https://en.wikipedia.org/wiki/Antisense_therapy) targeting Lp(a)
- [Olpasiran](https://www.amgen.com/newsroom/press-releases/2022/05/amgen-announces-positive-topline-phase-2-data-for-investigational-olpasiran-in-adults-with-elevated-lipoproteina), which is a [small interfering RNA](https://en.wikipedia.org/wiki/Small_interfering_RNA) that also targets the synthesis of Lp(a)
- And there’s some other ones being studied as well, another small interfering RNA
- Ongoing trials should show how much lowering Lp(a) actually translated into reduction of  MACE (major adverse cardiovascular events)
  - The [HORIZON trial for Pelacarson](https://my.clevelandclinic.org/clinical-trials/1424-horizon-a-multicenter-trial-assessing-the-impact-of-lipoprotein-a-lowering-with-tqj230-on-major-cardiovascular-events-in-patients-with-cardiovascular-disease) is enrolling high-risk secondary prevention population with elevated Lp(a)

**Is there any concern about seeing a rebound increase in LDL after using an antisense oligonucleotide?**

- Peter adds, “*When you knock out LP(a), all of those additional LDLs that would’ve been LP(a)s become LDLs. So your apoB concentration stays the same even though you’ve shifted the distribution from between Lp(a) and LDL*”
- Erin replies, “*I think this is why we need the trials*”
- With LDL there is a pretty linear relationship between lowering LDL by 1 mmol/L (or 39 mg/dL) and a 20-30% reduction in major adverse cardiovascular events
  - This is why therapies like bempedoic acid and inclisiran  got approved based on their LDL lowering properties even without outcome data
- We don’t really have that data for Lp(a) other than modeling data
- Certainly high levels of Lp(a) is associated with increased risk
- But some modeling data says you might need to reduce Lp(a) as much as 50 to a 100 mg/dL to have a meaningful reduction ASCVD in the short-term
- Other therapies such as niacin lower Lp(a), but it was not shown to have a clinical benefit in 2 outcome studies
  - Albeit those studies didn’t enroll based on Lp(a)
  - We’re not using niacin, the same with hormone replacement therapy (HRT)

**Hormone replacement therapy is associated with lower Lp(a)**

- Estrogen therapy or hormone replacement therapy (HRT) is associated with lower Lp(a) levels, but we’re not recommending it for the sole purpose of lowering Lp(a)
  - Because this therapy has been associated with increased cardiovascular risk
    - Particularly in high-risk individuals with ASCVD
    - Or individuals who have multiple risk factors
    - Or individuals who are many years out from the menopause transition

> “*We really need the data*”‒ Erin Michos

**Drugs approved that lower Lp(a)**

- We know Pelecarson or Olpasiran can reduce Lp(a) by 80-90%
  - Which is remarkable considering statins, bempedoic acid, and ezetimibe don’t lower it at all
  - Statins may even increase it
  - PCSK9 inhibitors only lower it by 25%
- Erin adds, “***It’s remarkable that we now have therapies that work in terms of lowering Lp(a), but what does that mean in terms of event reduction?***”
- She notes, we’ve been burned from other studies (like [CETP inhibitors](https://en.wikipedia.org/wiki/CETP_inhibitor)) where biomarker data is sometimes not enough and you actually have to show that it can meaningfully reduce risk

**Back to Peter’s question about lowering Lp(a) with antisense oligonucleotides**

- Erin suggests “*Maybe offsetting some of the LDL increase might offset any reduction in benefit*”

**Further study of Lp(a) is needed**

- The other thing she thinks warrants further study is epidemiology studies on *very low* Lp(a) levels
  - Is this associated with an increased risk of diabetes?
  - If so, what does that mean if you lower Lp(a) to a very low level
  - We don’t know and this is why we really need the trial data
- Peter remembers Tom Dayspring recently sending him an [analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7724642/) of ODYSSEY which demonstrated that the greater the reduction in Lp(a) through the use of [Praluent (alirocumab)](https://en.wikipedia.org/wiki/Alirocumab), the greater the reduction in MACE
- Erin agrees, “*Both in FOURIER and ODYSSEY, individuals who experienced the greatest reduction in Lp(a) had greater relative and absolute reduction in MACE (major adverse cardiovascular events). So it seems to be that lowering Lp(a) may in part be an important mediator in the benefits that we see with these agents, and it may just not be all due to their LDL-lowering effects, but maybe also due to Lp(a)-lowering effects.*”
- This is very encouraging about these new agents, but this is modeling post-hoc analysis from these trials
- The PCSK9 inhibitors also lowered LDL
- So now when you think about agents that only target Lp(a), Erin adds, “*Is that going to be sufficient enough to have a meaningful reduction in major adverse cardiovascular events? I’m really hopeful because I think it’s causal, we know it’s associated with risk. I’m really excited about the therapies in this area, but [you] got to show me the data.*”

## The effect of menopause on cardiovascular disease risk [1:50:30]

**Is there anything more to it than simply the loss of estradiol leading to an increase in LDL? And if so, what’s the actual mechanism by which that’s happening?**

- Estrogen levels begin dropping during [perimenopause](https://en.wikipedia.org/wiki/Menopause#Perimenopause)
- Perimenopause can last several years before menopause

**Definition of menopause**: when a woman hasen’t had a menstrual cycle for 12 months (this usually happens around age 51)

- Early onset of menopause (before age 40 or even 45) is associated with *increased* cardiovascular risk
- When the primary estrogen of women during reproductive age (estradiol) drops dramatically, there is a change to estrone (E1)
  - E1 is the weakest type of estrogen formed in the adrenal glands and other adipose tissues
- After menopause, women have lower levels of estrong than men do
  - Men have higher estrogen levels because they have much higher testosterone levels and have increased peripheral conversion of testosterone to estradiols
  - Peter adds that pre-menopausal women have higher testerone than estrogen if you compare the same units
- After menopause many people think the ovaries are just not active anymore
  - That’s *not* true, the ovaries continue to produce androsterone and testosterone but they don’t make estradiol
  - They keep making significant amounts of androgens until age 80, and these androgens are what get converted in fat and muscle tissue into estrone
- Erin mentions this because a lot of her research has been about sex hormone levels after menopause
- She has [shown](https://www.sciencedirect.com/science/article/pii/S0735109718343614?via%3Dihub) that postmenopausal women who have higher androgen levels have a greater risk of developing ASCVD and heart failure (HF) over the next 12 years (summarized in the figure below)
  - These are women who have higher testosterone to estrogen ratios had a more male-like pattern
  - And this was even after adjusting for risk factors like blood pressure and lipids and diabetes

![](https://peterattiamd.com/wp-content/uploads/2022/10/f7-erinmichos-1024x735.png)

**Figure 7.  Ratio of testosterone to estradiol and the incidence of CVD, CHD, and HF in post-menopausal Women**.  Image credit: [*Journal of the American College of Cardiology*](https://www.sciencedirect.com/science/article/pii/S0735109718343614?via%3Dihub) 2018

- She did a number of analyses of the MESA study (the multiethnic study about arteriosclerosis)
- She [showed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6359942/) that **women with higher androgens** had more coronary artery calcium progression, worse endothelial reactivity, and increased concentric remodeling, an adverse cardiovascular phenotype
- Compare this to [PCOS](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome)‒ the riskier phenotype is the hyperandrogenism state (testosterone and androstenone and higher LH levels) as a marker of PCOS

**Hormonal changes during menopause have many effects**

- A lot of things happen related to these hormonal changes
- You have more visceral fat deposition in the abdomen
- And more insulin resistance
- And this leads to this dyslipidemia pattern of increased triglycerides, increased LDL and decreased HDL
- There’s more endothelial dysfunction
- Increased blood pressure, increased sympathetic tone
- A lot of cardiovascular risk in women is more linear with aging
- So for the most part blood pressure and diabetes risk tends to be more of an aging effect rather than an ovary effect
- Lipids is one thing that really seems to be an ovary effect
  - We do see relatively acute changes in the lipid panel following the final menstrual period with this rise and total cholesterol and LDL
  - Erin thinks that’s one of the reasons that women tend to have risk a little bit later in life and after menopause, is because they tend to have this more dyslipidemia pattern a little bit later in life

## How Erin approaches decisions regarding hormone replacement therapy (HRT) for her patients [1:55:30]

- This pattern, this increased risk, had led to this whole body of work about these harmful changes and maybe giving menopause hormone therapy would be beneficial
  - We prescribed HRT for years
  - Erin’s mother used to be on hormone therapy
  - This was all well before the [Women’s Health Initiative Study (2002)](https://jamanetwork.com/journals/jama/fullarticle/195120)
- There are favorable and unfavorable changes that occur with hormone therapy, especially combined therapy
- **Favorable changes** include lower HDL and increased HDL
  - This is from systemic oral estrogen (and to some degree transdermal)
  - Vaginal estrogens don’t have much systemic absorption
- For women who just have the genitourinary symptoms, even in women with cardiovascular disease or history of stroke, you can use vaginal estrogens safely
- Oral estrogens dilate the blood vessels through a nitric oxide effect
  - Which may be cardioprotective
- **Unfavorable changes**‒ Estrogens can increase [CRP (C-reactive protein)](https://en.wikipedia.org/wiki/C-reactive_protein)
  - Women have higher CRP levels and estrogens are [prothrombotic](https://en.wikipedia.org/wiki/Thrombosis)
  - This is why there is some increased risk with oral contraceptives, particularly in women who are older of reproductive age and combined with smoking and also during pregnancy
    - Estrogens can increase [prothrombin](https://en.wikipedia.org/wiki/Thrombin) and decrease [antithrombin III](https://en.wikipedia.org/wiki/Antithrombin)
- Estrogen (from oral contraceptives or hormone therapy) can increase triglycerides
- In higher risk women, particularly those that are farther out from the menopause transition or those with established cardiovascular disease, these adverse changes may outweigh any favorable benefits
- And that’s why probably the Women’s Health Initiative reported risk from HRT
  - This study had the mean age of 63, and most of these women were quite far from the menopause transition
  - They also used an oral conjugated equine estrogen with progestin formulation, and we saw a 2-fold increased risk of venous thromboembolism
  - So this is why the guidelines all changed, and we don’t recommend hormone therapy for the sole purpose of cardiovascular disease prevention because we have many other things we can use for prevention (like statins)
- But the pendulum doesn’t have to swing so far away, if you look at sub-analyses of these trials of women that were closer to the menopause transition (younger women), we don’t see this excess harm

**Recommendations for using hormone therapy to manage menopause symptoms**

- A lot of women are quite symptomatic at menopause
  - Vasomotor symptoms can be very disabling for many women with the hot flashes and the brain fog
  - In fact, vasomotor symptoms in them themselves (when frequent or persistent) are associated with cardiovascular risk
- Erin adds, “*For symptomatic women who are under the age of 60 or within 10 years of menopause who have symptomatic menopause (menopausal hot flashes or night sweats), consider a hormone therapy*”
- Women who go through menopause early (if they don’t have other contraindications), menopausal hormone therapy is recommended to at least the natural age of menopause or age 51
- But generally we’re not recommending it if a woman’s more than 10 years out for menopause or over age 65
  - This is where the increased risks are emerging in these trials
- And we want to avoid **oral estrogens** in women with a history of cardiovascular disease, blood clots, high triglycerides, gallbladder disease or prior breast or endometrial cancer
  - Particularly the oral estrogens
  - There’s probably a little bit less risk with **transdermal estrogens** which are still systemic but they don’t have the first pass effect
- Erin works really closely with their menopause clinic doing a cardiovascular risk assessment prior to use of menopausal hormone therapy
  - When risk is uncertain, she gets a coronary calcium score to make sure that they don’t have any calcified plaque
  - If their score is zero, she feels pretty comfortable with using hormone therapy in them for treatment of their vasomotor symptoms
  - But if they have significant atherosclerotic disease, she tends to not recommend it
- Again, if they’re only having genital urinary symptoms, **topical estrogen** is fine
- The risk, it really probably depends on a lot of factors
  - When you start the hormone replacement, your age and initiation
  - How many years you’ve been since menopause
  - Your menopause age
  - How long you take the therapy, the duration
  - The type of therapy, the dose, and the route of administration
  - And probably your incoming health
- Peter thinks this is another reason for young women (in their 30’s) for whom menopause isn’t even on the radar to be as healthy as possible and do as much preventative work as possible, because it give them more optionality at menopause
  - He thinks this would be a boost to quality of life, bone health, muscle mass, and brain health
  - He agrees heart health isn’t on his radar for HRT because as Erin said, we have so many better tools to reduce the risk of ASCVD that we don’t need to rely on estradiol as one of those tools
    - Regarding the use of HRT to lower cardiovascular risk, “*It’s basically a pea shooter in a bazooka fight when we have big, big guns to reduce the risk of cardiovascular disease*”
- Peter adds we don’t want HRT to hurt somebody while we use it for its many benefits on the brain, bone health, vasomotor symptoms, eventually vaginal atrophy and things like that for which we don’t have alternatives
- To Erin’s point, the difference between a 50-year old woman with a clear [CTA](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) (where we have no ambiguity about using HRT) versus a woman with a worrisome CTA is he has more hesitation for using HRT for the latter (even if we choose a transdermal)
  - There is a slight increase in risk and we need to weigh in the balance

**Peter’s takeaway:** ***Prevention is the key.  Start early and be aggressive to give yourself more options later in life.***

- Erin agrees, the risk for HRT is in women with established cardiovascular disease
- So try to prevent that plaque in the first place
- If there’s no atherosclerosis, then the vasodilatory effects and the lowering of LDL may be helpful in preventing the initiation of atherosclerosis
- But for a woman who already has disease, the slight increase in inflammatory markers, a pro-formatic effect may tip them over to having a vascular event

> “*How we live the first half of our lives really influences our freedom for morbidity and mortality the second half of our lives*”‒ Erin Michos

**Is there a relationship between progesterone and lipids once we get into that manopause state?**

- HRT must include progesterone for women who have an intact uterus
- Again, we’re *not* using it for cardiovascular benefit

## The urgent need for more data on women’s health [2:03:30]

**Women are disproportionately underrepresented as subjects in clinical trials.  Is this changing in cardiovascular medicine anytime soon?**

- Women have been historically unenrolled in cardiovascular clinical trials, usually only comprising 25-30% of trial subjects
- Erin [published](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2766226) an analysis reviewing the literature of lipid lowering trials between 1990 and 2018 (it doesn’t reflect the more recent trials), and found the overall representation of women was only 29% in those trials
- Some things like [acute coronary syndrome](https://en.wikipedia.org/wiki/Acute_coronary_syndrome) have a lower prevalence in women than men
  - So the field has benchmarked it to something called a **participation to prevalence ratio** where a ratio of 1.0 would be an adequate representation to the prevalence of the disease in the population
  - And we showed that women were underrepresented with a prevalence to participation ratio, generally 0.5 or less
    - Meaning that even though if they had lower burden of disease, they were still under-enrolled in trials related to this
- Another [analysis](https://www.ahajournals.org/doi/10.1161/JAHA.119.015594) looked at cardiometabolic drug through 2017 that got FDA approval for new molecular entities, and again women only made up about 36% of subjects in these trials
- In an [editorial](https://pubmed.ncbi.nlm.nih.gov/32357082/) she wrote, they looked at all kinds of different things and women in all of these disease entities were under-enrolled in trials
  - Such as stroke, acute coronary syndrome, heart failure, hypertension
- Some things are getting better, in the [CLEAR-outcomes trial](https://pubmed.ncbi.nlm.nih.gov/33470195/), nearly half of the participants were women
- Erin thinks this disparity is because women are a statin-intolerant population
- Some of the GLP-1 studies like [REWIND](https://pubmed.ncbi.nlm.nih.gov/31189511/) (which studied dulaglutide) had about 46% women
  - That was largely a primary prevention trial
  - This is an encouraging example of improvement
- But women still, for the most part are under enrolled in trials

**Women’s inclusion in clinical trial leadership is also low**

- Erin thinks there is under-involvement of women in clinical trial leadership (she’s passionate about this)
  - These steering committees of these trials have a dearth of women cardiovascular investigators
- There was a [paper](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2769766) a couple years ago that looked at major cardiovascular trials published in the leading journals (*New England Journal, JAMA, Lancet),* and only 10% of trial leadership committees were women
  - More than half (about 56%) of these trial leadership committees had *no* female representation on the trial
  - None of the trial steering committee were women investigators
  - Less than 10% had a woman in the first or last author position (which would indicate a senior leadership position)

***We know from other studies that the likelihood that a study will report a sex and gender specific analysis actually is increased when there’s more women authors of the study and more first and last authors women***

- Erin thinks women tend to publish more about science related to women
  - So this matters
  - There is some data from [her work](https://www.ahajournals.org/doi/10.1161/JAHA.121.024233) and some [other authors](https://www.ahajournals.org/doi/10.1161/CIRCHEARTFAILURE.119.006605) that have shown a modest correlation between the proportion of women authors and enrollment of women participants in trials
  - She did a [study](https://www.ahajournals.org/doi/10.1161/JAHA.121.024233) on atrial fibrillation which showed that for every 1% increase in women authors, there was a 19% higher enrollment of women participants in the trials

**How to improve clinical trials**

- There is a lot we can do to tackle this
  - Have more representation by diversifying study teams and investigators
  - We also need to include more patients in trial designs
  - Include more women in trial designs, patient-centered designs
- She hears that women are approached but often are declined participation in trials
- She thinks women tend to be a little more risk-averse and this is where it’s really important to **provide education**
  - Dispel misconceptions
  - Emphasize benefits
    - Even if we don’t’ know if a drug is going to be beneficial or not
    - There’s a lot of benefits with being part of a trial because you have more access to gold standard care and more access to study investigators
- It’s really important to include women in the design and try to understand some of these **design issues**, which may be not so obvious
  - Such as making sure there’s no hidden costs that often people are paid for the drug or device
  - There can be things related to transportation or time off work or providing for childcare, other responsibilities by having more flexible follow-up, more pragmatic trials or having a follow-up being online or by phone or by PCP
    - That may get over some of the barriers to enrolling women in the trials
- Making sure that the study designs are not so restrictive in terms of the **inclusion exclusion criteria**
  - We shouldn’t just exclude women of childbearing age if they have a plan for preventing pregnancy (adequate contraception); women should be eligible for these trials
  - Not to mention we actually need more trials in pregnant women too
    - It’s just so important to understand what works and what’s safe.
- There’s a lot of barriers to overcome in trial teams, trial designs, funding agencies, institutions
- Even the journals that publish these trials should be asking why there’s not enough women in the trials

> “*Randomized clinical trials is our largest evidence base and we want to make sure that something is efficacious but safe and that women benefit to a similar degree as men do*”‒ Erin Michos

## Erin’s goal of running a marathon in every state [2:09:45]

**How many marathons has Erin run?**

- 38, she has been trying to do 1 in every state (she’s done 36)
- She’s not really talented at it (she’s a slow runner); her goal is just to finish
- She had 4 marathons planned for 2020 and they all got canceled due to COVID
  - The one she signed up for in 2021 was also canceled
  - And without a marathon on the calendar she got out of the habit of doing long distance runs
  - She relies on social support with running groups
- But outdoor events are back, she’s registered for a marathon in October
  - It will be her first marathon in 3 years
  - She’s hoping to get state 37 (New Jersey)
- She’s been doing other races for fun
  - A 12-miler in Baltimore last weekend

> “*It’s just the act of doing something and setting goals for yourself and I love it*”‒ Erin Michos

§

## Selected Links / Related Material

**90% of cardiovascular disease is due to modifiable risk factors**: [Effect of potentially modifiable risk factors associated with myocardial infarction in 52 countries (the INTERHEART study): case-control study](https://pubmed.ncbi.nlm.nih.gov/15364185/) | *Lancet* (S Yusuf et al. 2004) | [5:30]

**Young women with myocardial infarction are less likely to be treated**: [Women who experience a myocardial infarction at a young age have worse outcomes compared with men: the Mass General Brigham YOUNG-MI registry](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7700756/) | *European Heart Journal* (EM DeFilippis et al. 2020) | [14:30]

**Episode of** ***The Drive*** **summarizing the role of apoB, LDL, etc. on ASCVD**: [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 31, 2022) | [16:00]

**Episode of** ***The Drive*** **with Allan Sniderman**: [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 29, 2021) | [18:45]

**10-year risk prediction is not helpful for young people; Allan Sniderman’s** ***JAMA*** **paper**: [The Benefit Model for Prevention of Cardiovascular Disease: An Opportunity to Harmonize Guidelines](https://jamanetwork.com/journals/jamacardiology/article-abstract/2647086) | *JAMA Cardiology* (G Thanassoulis, MJ Pencina, & AD Sniderman) | [19:00]

**MESA (the multi-ethnic study of atherosclerosis) risk calculator**: [MESA 10-Year CHD Risk with Coronary Artery Calcification](https://www.mesa-nhlbi.org/MESACHDRisk/MesaRiskScore/RiskScore.aspx) | [MESA Website](https://www.mesa-nhlbi.org/default.aspx) (2022) | [19:00]

**2019 ACC/AHA Guideline on the Primary Prevention of Cardiovascular Disease**: [2019 ACC/AHA Guideline on the Primary Prevention of Cardiovascular Disease: Executive Summary: A Report of the American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000677) | *Circulation* (DK Arnett et al. 2019) | [24:00]

**Weight loss with tirzepatide**: [Tirzepatide Once Weekly for the Treatment of Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2206038) | *NEJM* (AM Jasterboff et al. 2022) | [34:30]

**Meta-analysis of association between polycystic ovary syndrome and cardiovascular risk**: [A Systematic Review and Meta-Analysis of the Association Between Polycystic Ovary Syndrome and Coronary Artery Calcification](https://pubmed.ncbi.nlm.nih.gov/35575750/) | *Journal of Women’s Health* (O Osibogun et al. 2022) | [49:30]

**Mendelian randomization studies of PCOS**: [Large-scale genome-wide meta-analysis of polycystic ovary syndrome suggests shared genetic architecture for different diagnosis criteria](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6300389/) | *PLoS Genetics* (F Day et al. 2018) | [50:15]

**Women with PCOS are at greater risk for cardiovascular complications and other during pregnancy**: [Pregnancy and Reproductive Risk Factors for Cardiovascular Disease in Women](https://pubmed.ncbi.nlm.nih.gov/35175837/) | *Circulation Research* (AC O’Kelly et al. 2022) | [51:30]

**Women who have 5+ children are more likely to be in poor cardiovascular health later in life**: [Multiparity is associated with poorer cardiovascular health among women from the Multi-Ethnic Study of Atherosclerosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7244341/) | *American Journal of Obstetrics and Gynecology* (O Ogunmoroti et al. 2019) | [52:45]

**Increased parity may also be a risk factor for CVD in Men too**: [Number of Offspring and Cardiovascular Disease Risk in Men and Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5625954/) | *Epidemiology* (MC Magnus 2017) | [54:30]

**Animal studies investigate statins for prevention of preeclampsia**: [Simvastatin Alleviates Pathology in a Rat Model of Preeclampsia Involving ERK/MAPK Pathway](https://pubmed.ncbi.nlm.nih.gov/27856999/) | *Reproductive Sciences* (X Dong & D Shi 2017) | [1:07:30]

**Pravastatin use in the 3rd trimester does not reduce preeclampsia**: [Pravastatin Versus Placebo in Pregnancies at High Risk of Term Preeclampsia](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.121.053963) | *Circulation* (M Dobert et al. 2021) | [1:08:30]

**Meta-analysis show statins benefit women**: [Efficacy and safety of LDL-lowering therapy among men and women: meta-analysis of individual data from 174,000 participants in 27 randomised trials](https://pubmed.ncbi.nlm.nih.gov/25579834/) | *The Lancet* (J fulcher et al. 2015) | [1:10:30]

**PALM registry shows statins are underprescribed and women less likely to be offered a statin**: [Lipid Management in Contemporary Community Practice: Results from the Provider Assessment of Lipid Management (PALM) Registry](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5714300/#R11) | *American Heart Journal* (AM Navar et al. 2017) | [1:11:45]

**Women 45% less likely to be prescribed a statin than men**: [Gender Differences in Patient‐Reported Outcomes Among Adults With Atherosclerotic Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6405598/) | *Journal of the American Heart Association* (V Okunrintemi et al. 2018) | [1:12:30]

**SAMPSON trial showed statin-elicited side effects observed similarly with placebo**: [Side Effect Patterns in a Crossover Trial of Statin, Placebo, and No Treatment](https://www.sciencedirect.com/science/article/pii/S0735109721057016?via%3Dihub) | *Journal of the American College of Cardiology* (JP Howard et al. 2021) | [1:14:30]

**Review of FOURIER and ODYSSEY trials of PCSK9 inhibitors evolocumab and alirocumab**: [What Lessons Have We Learned and What Remains to be Clarified for PCSK9 Inhibitors? A Review of FOURIER and ODYSSEY Outcomes Trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7237602/) **|** *Cardiology and Therapy* (RHM Furtado and RP Giugliano 2020) | [1:20:45]

**Phase 3 Clinical trial of Inclisiran (ORION trial)**: [Two Phase 3 Trials of Inclisiran in Patients with Elevated LDL Cholesterol](https://www.nejm.org/doi/full/10.1056/NEJMoa1912387) | *NEJM* (KK Ray et al. 2020) | [1:24:30]

**CLEAR study, and the LDL lowering effects of bempedoic acid in ASCVD and FH patients**: [Long-Term Safety and Efficacy of Bempedoic Acid in Patients With Atherosclerotic Cardiovascular Disease and/or Heterozygous Familial Hypercholesterolemia (from the CLEAR Harmony Open-Label Extension Study)](https://www.ajconline.org/article/S0002-9149(22)00322-8/fulltext) | *The American Journal of Cardiology* (CM Ballantyne et al. 2022) | [1:27:15]

**High intensity statins plus lowering cholesterol absorption and reduce atheroma volume (IVUS trial)**: [Impact of Dual Lipid-Lowering Strategy With Ezetimibe and Atorvastatin on Coronary Plaque Regression in Patients With Percutaneous Coronary Intervention: The Multicenter Randomized Controlled PRECISE-IVUS Trial](https://www.sciencedirect.com/science/article/pii/S0735109715026820?via%3Dihub) | *Journal of the American College of Cardiology* (K Tsujita et al. 2015) | [1:33:45]

**Cochrane collaboration evaluating role of PFUAs on cardiovascular disease**: [Polyunsaturated fatty acids for the primary and secondary prevention of cardiovascular disease](https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD012345.pub3/full) | *Cochrane Database of Systematic Reviews* (AS Abdelhamid et al. 2018) | [1:34:15]

**Cochrane collaboration evaluation substitution of SFA with PUFA and MUFA**: [Reduction in saturated fat intake for cardiovascular disease](https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD011737.pub3/full) | *Cochrane Database of Systematic Reviews* (L Hooper et al. 2020) | [1:34:30]

**PREDIMED study of a Mediterranean diet supplemented with extra-virgin olive oil and nuts and prevention of cardiovascular disease**: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet Supplemented with Extra-Virgin Olive Oil or Nuts](https://www.nejm.org/doi/full/10.1056/NEJMoa1800389) | *NEJM* (R Estruch et al. 2018) | [1:35:00]

**LYON heart study of a Mediterranean diet and cardiovascular disease**: [Mediterranean Diet, Traditional Risk Factors, and the Rate of Cardiovascular Complications After Myocardial Infarction](https://www.ahajournals.org/doi/10.1161/01.CIR.99.6.779) | *Circulation* (M de Lorgeril et al. 1999) | [1:35:00]

**American Heart Association statement about the mind/heart/body connection**: [Psychological Health, Well-Being, and the Mind-Heart-Body Connection: A Scientific Statement From the American Heart Association](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000947) | *Circulation* (GN Levine et al. 2021)

**Previous episode on** ***The Drive*** **about Lp(a)**: [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (June 13, 2022) | [1:41:00]

**Copenhagen general population study of LDL and cardiovascular risk**: [Association between low density lipoprotein and all cause and cause specific mortality in Denmark: prospective cohort study](https://www.bmj.com/content/371/bmj.m4266.long) | *BMJ* (CD Lindhardt Johannesen et al. 2020) | [1:44:00]

**HORIZON clinical trial using Pelacarson to lower LP(a) and determining effects on MACE**: [Clinical Trials](https://my.clevelandclinic.org/clinical-trials/1424-horizon-a-multicenter-trial-assessing-the-impact-of-lipoprotein-a-lowering-with-tqj230-on-major-cardiovascular-events-in-patients-with-cardiovascular-disease) | Cleveland Clinic (2022) | [1:45:00]

**Analysis of ODYSSEY trial showing benefits of reducing Lp(a)**: [Lipoprotein(a) lowering by alirocumab reduces the total burden of cardiovascular events independent of low-density lipoprotein cholesterol lowering: ODYSSEY OUTCOMES tria](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7724642/)l | *European Heart Journal* (M Szarek et al. 2020) | [1:49:00]

**Higher androgen levels in postmenopausal women associated with greater ASCVD risk**: [Endogenous Sex Hormones and Incident Cardiovascular Disease in Post-Menopausal Women](https://www.sciencedirect.com/science/article/pii/S0735109718343614?via%3Dihub) | *Journal of the American College of Cardiology* (D Zhao et al. 2018) | [1:53:30]

**Women with higher androgens have an increased adverse cardiovascular pahenotype**: [Association of Endogenous Sex Hormone Levels with Coronary Artery Calcium Progression Among Post-Menopausal Women in the Multi-Ethnic Study of Atherosclerosis (MESA)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6359942/) | *Journal of cardiovascular computed tomography* (V Subramanya et al. 2019) | [1:54:00]

**Women’s Health Initiative Study on hormone replacement therapy**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women](https://jamanetwork.com/journals/jama/fullarticle/195120)

[Principal Results From the Women’s Health Initiative Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/195120) | *JAMA* (JE Rossouw et al. 2002) | [1:55:30]

**Women comprise only 29% of subjects in clinical trials of lipid-lowering therapies**: [Participation of Women and Older Participants in Randomized Clinical Trials of Lipid-Lowering Therapies](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2766226) | *JAMA Network Open* (SU Khan et al. 2020) | [2:04:30]

**Women comprise only 36% of subjects in clinical trials of cardiometabolic drugs**: [Ten‐Year Trends in Enrollment of Women and Minorities in Pivotal Trials Supporting Recent US Food and Drug Administration Approval of Novel Cardiometabolic Drugs](https://www.ahajournals.org/doi/10.1161/JAHA.119.015594) | *Journal of the American Heart Association* (MS Khan et al. 2020) | [2:05:15]

**Editorial on the under enrollment of women with CVD in trials**: [Cardiac Device Clinical Trials: Where Are the Women and What Are Their Outcomes?](https://pubmed.ncbi.nlm.nih.gov/32357082/) | *Journal of Women’s Health* (A Minhas & ED Michos 2020) | [2:05:30]

**Women make up 10% of clinical trial leadership committees**: [Representation of Women in Cardiovascular Clinical Trial Leadership](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2769766) | *JAMA Internal Medicine* (KJ Denby et al. 2020) | [2:06:30]

**Correlation between the proportion of women authors and enrollment of women participants in trials**:

- [Association of Women Authors With Women Enrollment in Clinical Trials of Atrial Fibrillation](https://www.ahajournals.org/doi/10.1161/JAHA.121.024233) | *Journal of the American Heart Association* (SU Khan 2022) | [2:07:15]
- [Representation of Women Authors in International Heart Failure Guidelines and Contemporary Clinical Trials](https://www.ahajournals.org/doi/10.1161/CIRCHEARTFAILURE.119.006605) | *Circulation: Heart Failure* (N Reza et al. 2020) | [2:07:15]

**Cardiovascular disease is the leading cause of death of women in the US, factors that enhance risk**: [The Use of Sex-Specific Factors in the Assessment of Women’s Cardiovascular Risk](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.119.043429) | *Circulation* (A Agarwala et al. 2020)

**10 sentinel risk factors for CVD**: [Ten things to know about ten cardiovascular disease risk factors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8315386/) | *American Journal of Preventive Cardiology* (HE Bays et al. 2021)

**Risk factors for ASCVD in women**: [Primary Prevention of Atherosclerotic Cardiovascular Disease in Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5279938/) | *Current Cardiovascular Risk Reports* (RA McKibben et al. 2016)

**Dietary recommendations for preventing CVD**: [A Clinician’s Guide to Healthy Eating for Cardiovascular Disease Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6713921/) | *Mayo Clinic Proceedings: Innovations, Quality & Outcomes* (VA Pallazola et al. 2019)

**Evidence for the role of Lp(a) in ASCVD**: [Lipoprotein(a) in atherosclerotic cardiovascular disease and aortic stenosis: a European Atherosclerosis Society consensus statement](https://academic.oup.com/eurheartj/article/43/39/3925/6670882) | *European Heart Journal* (F Kroneberg et al. 2022)

**Role of LDL and Lp(a) in CVD**: [Relationship of low-density lipoprotein-cholesterol and lipoprotein(a) to cardiovascular risk: The Multi-Ethnic Study of Atherosclerosis (MESA)](https://pubmed.ncbi.nlm.nih.gov/36253168/) | *Atherosclerosis* (R Rikhi et al. 2022)

**Stress as a risk factor for cardiovascular disease**: [Psychological Factors and Their Association with Ideal Cardiovascular Health Among Women and Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5962331/) | *Journal of Women’s Health* (L Mathews et al. 2018)

**New strategies to lower LDL for preventing CVD**: [New Strategies for Lowering Low Density Lipoprotein Cholesterol for Cardiovascular Disease Prevention](https://pubmed.ncbi.nlm.nih.gov/36213094/) | *Current Cardiovascular Risk Reports* (Sp Gaine et al. 2022)

§

## People Mentioned

- [Peter Libby](https://cics.bwh.harvard.edu/people/peter_libby) (cardiologist and Professor at Harvard Medical School) [17:15]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) (cardiologist and Professor at McGill University) [18:45]

§

![](https://peterattiamd.com/wp-content/uploads/2022/10/bio-image-erinmichos.jpeg)

##### Erin Michos, M.D.

Dr. Erin Michos is an Associate Professor of Medicine within the Division of Cardiology at Johns Hopkins School of Medicine.  She has a joint appointment in the Department of Epidemiology at the Johns Hopkins Bloomberg School of Public Health. She is the Associate Director of Preventive Cardiology with the Ciccarone Center for the Prevention of Cardiovascular Disease at Johns Hopkins.  She is a Fellow of the American College of Cardiology (FACC) and a Fellow of the American Heart Association (FAHA).

Dr. Michos completed medical school at Northwestern University in Chicago, IL, and then completed both her Internal Medicine residency and Cardiology fellowship at the Johns Hopkins Hospital in Baltimore, MD. She also completed her Masters of Health Science degree in Cardiovascular Epidemiology at the Johns Hopkins Bloomberg School of Public Health.

Her research interests are in the areas of Preventive Cardiology and Cardiovascular Epidemiology, with particular focus on (1) physical activity and nutrition; (2) risk prediction for cardiovascular disease including the use of coronary artery calcium scores and biomarkers, (3) lipids and statin therapy, (4) cardiovascular disease among women, and (4) vitamin D.

As part of the Johns Hopkins cardiology faculty, her clinical duties entail seeing patients in the Preventive Cardiology outpatient clinic and the Echocardiography lab. She also teaches students at the Johns Hopkins University Medical School and the Bloomberg School of Public Health. She is the Chair of the Women’s Task Force for the Cardiology Division at Johns Hopkins. She is part of the Editorial Board for the journal Circulation.

Dr. Michos is a co-investigator on the NIH-funded Multi-Ethnic Study of Atherosclerosis (MESA) and Atherosclerosis Risk in Communities (ARIC) studies. She is an investigator in an on-going NIH-funded clinical trial (STURDY trial) studying vitamin D and fall prevention. She is the Training Director for the AHA fellowship program for the AHA’s Go Red for Women Strategic Focus Research Network at Johns Hopkins for research in women’s cardiovascular health.

Dr. Michos has authored or co-authored over 200 manuscripts in peer reviewed journals. She also contributes a monthly article for the US News and World Report Health Section for the public audience. She is also a frequent contributing writer to Johns Hopkins Medicine’s Healthy Heart and Healthy Woman websites.  [[Johns Hopkins](https://publichealth.jhu.edu/faculty/2456/erin-donnelly-michos)]

Twitter: [@ErinMichos](https://twitter.com/erinmichos)