# #101 – Ryan Holiday: Finding stillness amidst chaos

**Source:** [https://peterattiamd.com/ryanholiday2/](https://peterattiamd.com/ryanholiday2/)

---

##### Check out more content with Ryan Holiday:

- *(January 27, 2020)* [Ryan Holiday: Stillness, stoicism, and suffering less](/ryanholiday/)
- *(March 27, 2020)* [Ryan Holiday: Finding stillness amidst chaos](/ryanholiday2/)

Ryan Holiday, bestselling author and author of [Daily Stoic](https://dailystoic.com/), discusses practical ways to find stillness and apply the insights of stoic philosophy in the midst of COVID-19 chaos. Ryan discusses the importance of taking back a feeling of control, the benefits of structure and routine, and the idea of being prepared for anything.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ryanholiday2/the_Drive_public.png)

Play

#101 - Ryan Holiday: Finding stillness amidst chaos

1x15s30s

0:001:22:44

## We discuss:

- Using times of adversity to evaluate and reflect how you’ve set up and prioritized your life [2:30];
- What insights might the famous stoics provide amidst this COVID-19 pandemic? [8:15];
- The possible consequences of the socially isolating nature of a pandemic (and why we need good leaders) [13:00];
- Stoicism—what it means and how to apply it [18:45];
- Lessons taken from the life of Winston Churchill—stillness, structure, routine, hobbies, empathy, forward thinking, and more [23:30];
- Alive time vs. dead time—taking control of your time and making it count [38:45];
- Auditing how the world (and its leaders) are handling the COVID-19 pandemic through the lens of stoic philosophy [44:15];
- Asserting control and using routine to find stillness in an environment not conducive for it [52:15];
- Why you should find a way to exercise, especially now [58:30];
- How to find purpose during this time—goal setting, having a project to work on, and the benefits of keeping a journal [1:02:00];
- What is Ryan most optimistic about and what is he most concerned about over the next few months? [1:08:45];
- How can you follow Ryan’s work and messages about stoicism and stillness? [1:17:45]; and
- More.

§

## Show Notes

## Using times of adversity to evaluate and reflect how you’ve set up and prioritized your life [2:30]

**A chance to see things from a new perspective**

- The only potential positive of a dramatic setback, adversity, or obstacle is that it is a chance to see things differently or look at things differently
- For Ryan personally, his pace of life and travel has slowed down and it gives him a chance to ponder whether this new setup is actually closer to what he wants
- For Peter, this is the longest he’s gone without traveling if forever—something he would have told you was “impossible” to pull off
- “*A lot of the things we think are non-negotiable, we’re just actually not willing to negotiate, but of course they aren’t non-negotiable.*”

Ryan mentions:

- [Robert Greene](https://en.wikipedia.org/wiki/Robert_Greene_(American_author)) once told Ryan, “it’s all material”
- [Jorge Luis Borges](https://en.wikipedia.org/wiki/Jorge_Luis_Borges) quote, “you got to use it all”

> “I think deciding that you’re going to experience this in a way that you emerge from it at least sort of wiser and better at what you do. . .is sort of the way to think about it.”

## What insights might the famous stoics provide amidst this COVID-19 pandemic? [8:15]

**Two big ugly heads about this pandemic**:

1. The physical risk to people and the uncertainty around that (we still don’t know the denominator in terms of total cases so we don’t really know the death rate)
2. The undeniable economic tragedy being imposed on many people

**What might the famous stoics, or philosophers like Winston Churchill have to say about this situation?**

- Churchill might suggest putting some space between yourself and the media hysteria
- [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius) – Ryan points out that he actually lived through the [Antonine Plague](https://en.wikipedia.org/wiki/Antonine_Plague) in Rome which lasted for 15 years … and much of his writing occurred during this time
- When Marcus writes [Meditations](https://www.amazon.com/Meditations-Marcus-Aurelius/dp/1503280462), he is writing in the exact scenario that a lot of us are in right now, trying to keep ourselves from being exposed but also trying to do our jobs at the same time
- The fear was spreading at the same rate as the disease
- But as a leader, Ryan says Marcus brought calmness, clear headedness, and courage

**Speculating what Marcus Aurelius might have said in today’s pandemic**: “*The thing we actually have to be worried about is sort of selfishness and greed and panic. . .these things sort of ruin your character as well as your life.*”

**Ryan adds**:

> “People are really struggling with how to sort of temper themselves and how to limit themselves and have self-discipline and put other people’s needs above their own. So I, I think, you know, from history we can see that these are sort of timeless struggles that we’ve always had.”

## The possible consequences of the socially isolating nature of a pandemic (and why we need good leaders) [13:00]

⇒ David Brooks wrote in the NY Times: [Pandemics Kill Compassion, Too](https://www.nytimes.com/2020/03/12/opinion/pandemic-coronavirus-compassion.html)

- The gist of this article was to point out that there are certain externalities that are very difficult that can be uniting (think post-[9/11](https://en.wikipedia.org/wiki/September_11_attacks))
  - [Sebastian Junger](https://en.wikipedia.org/wiki/Sebastian_Junger) has written very eloquently about this in his book [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381)
- But with pandemics, it forces everyone into isolation and sort of pits us against each other (b/c we don’t want someone to infect us, for example)

–*Ryan, however, says that he doesn’t fully agree with the point being made…*

1. For one, we are so connected with the internet nowadays
2. Secondly, a pandemic affects EVERYONE … not just some people… so in that sense we are kind of all going through it together

**The more concerning problem, says Ryan, is a** ***lack of leadership***:

> “Historically, the defining feature between whether it sort of makes us better or makes us worse, or how it manifests itself culturally, is what the leadership does.”

## Stoicism—what it means and how to apply it [18:45]

*Ryan’s book that Peter has read four times*: [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585)

**Stoicism**

- The central precept of stoicism is basically that **we don’t control what has happened or what is happening, but we control how we respond to those things**
- In other words, it’s sort of letting go of the things that we are not in control of in favor of focusing on things that we actually immediately are in control of

-Stoic philosophy was actually born from a time when pandemics were very real in addition to…

- Exile
- War
- Marriage problems
- Cheating business partner
- Broken leg without the same healthcare we have today

“Life is capricious and random and Murphy’s Law is real, what can go wrong does.” says Ryan

**The question that stoicism brings to light is…**

> “How do you respond and how do you focus NOT on who’s to blame, how unfortunate it is, or any of those things. [But rather], how do you instead focus on, ‘okay, here’s how I’m going to move the ball forward.’”

## Lessons taken from the life of Winston Churchill—stillness, structure, routine, hobbies, empathy, forward thinking, and more [23:30]

*In* [*Stillness is the Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585)*, Ryan writes about the amazing story of* [*Winston Churchill*](https://en.wikipedia.org/wiki/Winston_Churchill)*’s life…*

- Churchill has the most up and down life you could imagine … going from political exile to world leader and Nobel Prize winner
- And there were endless ups and downs along the way — many of the downs from unjustified exile from his own people
- Yet somehow, Churchill managed to keep pushing forward and went on to do amazing things
- And we he did get put back into leadership positions, rather than “punish” those who wrong him or didn’t believe in him, he instead showed empathy and compassion
- He was also able to focus on the task ahead rather than worrying about the past

> “The great ones don’t seem to dwell on the past because there really isn’t a lot of benefit that comes out of that backwards looking thing.” —Peter Attia

**Churchill’s structure and routine**

*So how did Churchill pull off this amazing life full of accomplishments?*

-First, it turns out, he was a creature of habit, routine, and discipline even in the most stressful of times

- E.g., He would write at the same time of day, he would nap at the same time of day, etc.
- He walked daily, he dressed up for dinner, he didn’t see his wife before noon, etc.

-Secondly, he made time for hobbies and time away from “work”

- Yet, he was so prolific in his writing and accomplishments it begs the question how he had time
- Peter quotes [Parkinson’s law](https://en.wikipedia.org/wiki/Parkinson%27s_law): “work expands so as to fill the time available for its completion”
- Churchill believed the [cultivation of hobbies was very important](https://www.azquotes.com/picture-quotes/quote-the-cultivation-of-a-hobby-and-new-forms-of-interest-is-a-policy-of-first-importance-winston-churchill-104-2-0276.jpg)

**A couple good quotes from Ryan on this topic**:

- Ryan says it’s not clear that working around the clock leads to better outcomes:

 “*It’s not necessarily clear to me that you’re going to do a better job of those things if you neglect that sort of self care that comes from being in nature, being still, you know, detaching from it.*”

- Ryan says hobbies protect us by giving his some space between information and subsequent reactions:

“*And so one of these things these hobbies do . . . and a little bit of order and structure in our lives do is they kind of just protect us from just reacting and reacting and reacting all the time.*”



## Alive time vs. dead time—taking control of your time and making it count [38:45]

Ryan has written about the concept of ‘[Alive time vs. dead time](https://humanparts.medium.com/will-you-choose-alive-time-or-dead-time-8d7b8ba212)’

> “You don’t control the fact that you’re stuck in your house. You don’t control that. . . but you do decide what you’re going to use this time for.”

**Re-energize**

- Ryan says that if you use this “down time” to detach and rest and rejuvenate, there is nothing wrong with that  (if you actually emerge well rested)
- The point though is that it should be deliberate

**Re-evaluate and try new things**

- Now is also time to really question a lot of things about our lives—the decisions we make about, the businesses that we have, the goals that we’ve been striving towards
- We should also try new things – especially things that we may not have ever made time for

“As awkward as this is, this feeling, this helplessness, there’s not a huge amount of value in just being upset about it. I mean, yeah, it feels good in the moment, but it doesn’t really produce much benefit in the long run.” —Peter Attia

## Auditing how the world (and its leaders) are handling the COVID-19 pandemic through the lens of stoic philosophy [44:15]

**Having a plan for anything**

- Stoicism teaches the importance of being prepared for the worst
- It’s not always pleasant to imagine things going wrong but what you really don’t want is to get caught off guard
- Because as Murphy’s Law says, what can go wrong does

**A flaw in America’s setup**

- Ryan says the way the America is set up with 50 strong states backed by a strong central government has us prepared for segregated catastrophes (e.g., helping when California has wildfires, or New Orleans is hit with a hurricane)
- But as we’ve seen, it was not set up well to handle a massive, interconnected problem affecting all 50 states
- Peter hopes we learn from this as a country… perhaps to decentralize command to allow for individual states to take responsibility for being prepared and to be able to make their own decisions

–*Comparing that at the individual level…*

- We might have life insurance, some cash saved up if we lose our job, babysitter on call in case of an emergency…
- However, do we have a plan in place for if all those things go wrong at once?

**Does stoicism tell us anything about the likelihood that we as a society will learn from this?**

- Truthfully, history says that we will not learn a proper lesson, says Ryan
- Ryan quotes Hemingway in [Farewell to Arms](https://www.amazon.com/Farewell-Arms-Hemingway-Library/dp/1451658168/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), “The world breaks everyone. And afterwards, sometimes the broken people are stronger in the broken places. . .but the people that don’t break, the world kills.”

*-How Ryan relates this to life and stoicism…*

- The myth of stoicism is that it makes you unbreakable
- It’s actually about making you stronger
- The reality is really bad stuff happens and we have no choice but to sort of assent to it

> “Where I think philosophy really comes in, what it’s actually about is emerging from this better and stronger. . . The worst thing we could do to those people [that will die from this] would be to emerge from this and essentially learn nothing to go back to business as usual.”

**What does Ryan hope we learn?**

- We understand how to be better prepared
- We know what to do and how to handle a pandemic
- But what Ryan stresses mostly, is that we need to do a better job of selecting our world leaders with higher character and not just about if they agree with same policies as us

## Asserting control and using routine to find stillness in an environment not conducive for it [52:15]

*How do people find stillness in their life when so much is going wrong?*

- People are losing jobs, kids out of school, homeschooling, can’t pay bills, stuck inside (especially new yorker)
- Ryan stresses the importance of asserting control in your life
- Ryan, for example, has decided to wake up to an alarm every morning even though he could sleep as much as he wants and sort of just “kill” another day
- He is being deliberate about his time

Ryan tells the story of [Rubin “Hurricane” Carter](https://en.wikipedia.org/wiki/Rubin_Carter) who was wrongly convicted of murder and spent almost 20 years in prison

- In prison, you obviously have little control of anything
- During his imprisonment, Rubin decided to take control over every little tiny thing he could

> “He decided that how he was going to wrap his head around the lack of control that he had was he was going to assert control and other ways. And I think that’s an interesting approach that might be worth thinking about for people. So, how can you find some ways to assert agency in the midst of all of this powerlessness and, and I think you’ll find that that’s really reassuring.”

## Why you should find a way to exercise, especially now [58:30]

- Exercise is really important for mental and physical health
- Your gym being closed might make it harder but there are apps available to help you make due with what you have at home
- Worst case scenario, get out there and take a walk
- Taking 20 minutes to exercise or simply move around pays enormous dividends, says Peter, physiologically, psychologically, and spiritually
- Ryan’s wife uses the [Future personal training app](https://www.future.fit/?code=first99&utm_source=google&utm_medium=cpc&utm_campaign=G_Search_Brand_Future_App_EM&utm_content=Future_Fit_App_EM&gclid=Cj0KCQjwyPbzBRDsARIsAFh15JZ1EkUDA7xgEyUYU87mui462h3xqWLE6KSqUduwJMvriZrK0_t3cLkaAqWoEALw_wcB)

## How to find purpose during this time—goal setting, having a project to work on, and the benefits of keeping a journal [1:02:00]

**Journaling**:

- Stoics were a big proponent of journaling
- Ryan recommends it to people … he describes the benefit as follows:

*“I’m really trying to use it as a place to sort of remind myself and reiterate to myself, like how I want to be inside this. It’s sort of reminders of like, ‘Hey, you’re worried about X, Y, and Z. You know, one way not to think about that is to think about other people instead.’*

*So I’m trying to just like sort of buck myself up a little bit in the morning, kind of remind myself of what’s important to me. I think journaling is not this, just this stream of conscious sort of thing you’re doing. It’s not performing for history. To me it should be, it’s like, it’s like playing scales on the guitar or on the piano. You’re running yourself through it over and over again. So that it gets more imputed into your memory and kind of into your being.*”

- Peter tells the story about how his 11 year old daughter was having a hard time comprehending how she was going to have to stay at home and “shelter in place”
- Peter then told her the story of [Anne Frank](https://en.wikipedia.org/wiki/Anne_Frank) who lived in an attic for years and kept a journal throughout the whole experience
- Her journal was an incredible feat and valuable piece of work for society
- But at the time, Anne was thinking about that… it was giving her a project, something to do, a purpose
- This sort of goes to show the power of something like journaling

**Purpose, goal setting, and projects**

During this time, we should be asking ourselves, “*What goals or things can we give ourselves (and our kids) that we can throw ourselves into that allows us to sort of escape from this a little bit?*”

Examples…

- Try to set new PR on the deadlift
- Lose 5 pounds
- Read the Harry Potter Series

> “Like you can create things to throw yourself into that allow you to feel some momentum and accomplishment and purpose. . . rather than wallowing in your resentment or anger or boredom.?”

##

## What is Ryan most optimistic about and what is he most concerned about over the next few months? [1:08:45]

**Upside/hopeful about**:

- He hopes it redefines the role of the US president and redefines the importance of a lot of the alliances and relationships internationally that we have with a lot of, a lot of different countries.
- We should hopefully rethink how we do business with other countries and perhaps bring our manufacturing back to the US instead of relying on China
- “I think this is a wake up call in a lot of ways. . .I think it sort of knocked people out of the stupor or the slumber that we are in”

**Some concerns of Ryan**:

- While [Tyler Cowan wrote](https://marginalrevolution.com/marginalrevolution/2020/03/the-coronavirus-killed-the-progressive-left.html) that the pandemic may have killed the “woke” culture…
- Ryan is actually worried that the revolutionary extremes on both the left and right will “seize upon the wreckage that emerges from this and are actually empowered.”
- Ryan is worried for the millennial generation who were starting to sort of mature (saving up, good jobs, buying homes, etc.) and they’ve been hit by another economic disaster
- Ryan can help but wonder what will happen to Medicare and Medicaid and social security
- What about the people who were about to retire and just watched years of their gains evaporate?

**What is Peter most worried about?**

- “In the short term I’m certainly worried about a handful of geographies that I don’t think . . . have this supply to meet the ICU demand. So I think New York is for sure very likely going to be overrun.”
- Peter is thinking about the doctors who are having to make terrible decisions on who to treat with their limited time and resources, “*you didn’t take a class in that.*”
- Peter is frustrated with that fact that we just don’t have enough data to understand the magnitude of this virus… it could be completely devastating in it’s impact on life or it could be closer to the flu virus and in that case we’ve unnecessarily destroyed our economy
- Peter is also worried about the tremendous debt we’ve accumulated recently and honestly wonders what will happen when the US is one day unable to pay up it’s growing debt

> “It’s okay that those things are upsetting and it’s okay that I can worry about them a little bit, but I’m trying to check myself to make sure I’m not worrying about them at the point where it ceases to be productive. You know, worry is only productive when it motivates me to do something.” —Peter Attia

##

## How can you follow Ryan’s work and messages about stoicism and stillness? [1:17:45]

- [Daily Stoic newsletter](https://dailystoic.com)
- [Daily Dad newsletter](https://dailydad.com)
- Twitter
  - [@dailystoic](https://twitter.com/dailystoic?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
  - [@ryanholiday](https://twitter.com/RyanHoliday?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

**Books**:

- [Obstacle is the Way](https://www.amazon.com/Obstacle-Way-Timeless-Turning-Triumph/dp/1591846358) is “particularly well-suited” for this moment in time for those who may have been “knocked on your ass and you’re trying to figure out ‘what next’?
- [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585) is best for those you might be suffering from anxiety, stress, or worry over this and you’re interested in calming your racing mind

§

![](https://peterattiamd.com/wp-content/uploads/2020/01/Ryan-Holiday-bio-image-ryanholiday-450x500.png)

##### Ryan Holiday

Ryan Holiday is the bestselling author of [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585), [Trust Me, I’m Lying](https://www.amazon.com/Trust-Me-Lying-Confessions-Manipulator/dp/1591846285), [The Obstacle Is the Way](https://www.amazon.com/Obstacle-Way-Timeless-Turning-Triumph/dp/1591846358), [Ego Is the Enemy](https://www.amazon.com/Ego-Enemy-Ryan-Holiday/dp/1591847818), [Conspiracy](https://www.amazon.com/Conspiracy-Peter-Gawker-Anatomy-Intrigue/dp/0735217645/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) and other books about marketing, culture, and the human condition. His work has been translated into over 30 languages and has appeared everywhere from the New York Times to Fast Company. His company, Brass Check, has advised companies such as Google, TASER, and Complex, as well as multiplatinum musicians and some of the biggest authors in the world. He lives in Austin, Texas.

Websites:

[Ryanholiday.net](https://ryanholiday.net/)

[DailyStoic.com](https://dailystoic.com/)

[DailyDad.com](https://dailydad.com/)