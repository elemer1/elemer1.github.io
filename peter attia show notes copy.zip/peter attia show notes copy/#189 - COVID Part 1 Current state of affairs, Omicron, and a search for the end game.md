# #189 – COVID Part 1: Current state of affairs, Omicron, and a search for the end game

**Source:** [https://peterattiamd.com/covid-19-current-state-omicron/](https://peterattiamd.com/covid-19-current-state-omicron/)

---

##### Check out more of my recent content on COVID:

- *(January 3, 2022)* [COVID Part 1: Current state of affairs, Omicron, and a search for the end game](/covid-19-current-state-omicron/)
- *(January 23, 2022)* [Why I’m for COVID vaccines, but against vaccine mandates.](/why-im-for-covid-vaccines-but-against-vaccine-mandates/)
- *(January 24, 2022)* [COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more](/covid-part2/)
- *(January 29, 2022)* [A follow-up to my article on vaccine mandates](/a-follow-up-to-my-article-on-vaccine-mandates/)

In this episode, Peter sits down with Drs. [Marty Makary](/martymakary/) and [Zubin Damania (aka ZDoggMD)](/zubindamania/), both previous guests on The Drive. Marty is a Johns Hopkins professor and public health researcher and ZDoggMD is a UCSF Stanford trained internist and the founder of Turntable Health. This episode, recorded on December 27, 2021, was in part inspired by some of the shoddy science and even worse messaging coming from top officials regarding COVID-19. In this discussion, Marty and ZDoggMD discuss what is known about the omicron variant, the risks and benefits of vaccines for all age groups, and the taboo subject of natural immunity and the protection it offers against infection and severe disease. Furthermore, they discuss at length the poor messaging coming from our public officials, the justification (and lack thereof) for certain mandates and policies in light of the current evidence, and the problems caused by the highly politicized and polarized nature of the subject. Themes throughout the conversation include the difference between science and advocacy, the messaging which is sowing mistrust in science despite major progress, and a search for what a possible “end” to this situation might look like.

NOTE: Since this episode was recorded over the holiday and published ASAP, this is an audio-only episode with limited show notes.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/covid-19-current-state-omicron/the_Drive_public.png)

Play

#189 - COVID-19: Current state of affairs, Omicron, and a search for the end game

#189 - COVID-19: Current state of affairs, Omicron, and a search for the end game

1x15s30s

0:002:45:14

## We discuss:

- Comparing omicron to delta and other mutations [4:15];
- Measuring immunity and protection from severe disease—circulating antibodies, B cells, and T cells [13:15];
- Policy questions: what is the end game and how does the world go back to 2019? [18:45];
- A policy-minded framework for viewing COVID and the problem of groupthink [24:00];
- The difference between science and advocacy [39:00];
- Natural immunity from COVID after infection [46:00];
- The unfortunate erosion of trust in science despite impressive progress [57:15];
- Do the current mandates and policies make sense in light of existing data? [1:02:30];
- Risks associated with vaccines, and the risk of being labeled an anti-vaxxer when questioning them [1:18:15];
- Data on incidence of myocarditis after vaccination with the Pfizer and Moderna vaccines [1:26:15];
- Outstanding questions about myocarditis as a side effect of mRNA vaccination and the benefit of boosters [1:35:00];
- The risk-reward of boosters and recommendations being ignored by policy makers in the US [1:40:30];
- Sowing distrust: Lack of honesty and humility from top officials and policy makers [1:43:30];
- Thoughts on testing: does it make sense to be pushing widespread testing for COVID? [1:52:15];
- What is the end point to all of this? [1:58:45];
- Downstream consequences of lockdowns and draconian policy measures [2:05:30];
- The polarized nature of COVID—tribalism, skeptics, and demonization of ideas [2:10:30];
- Looking back at past pandemics for perspective and the potential for another pandemic in the future [2:20:00];
- What parents can do if their kids are subject to unreasonable policies [2:25:00];
- Voices of reason in this space [2:28:45];
- Strong convictions, loosely held: the value in questioning your own beliefs [2:32:15];
- More.

§

## Show Notes

## Comparing Omicron to Delta and other mutations [4:15]

- It is important to differentiate between fact and opinion
- Omicron is a new surge so a lot of the information is in flux
- There is some laboratory data (3 labs) that show that Omicron does not infect lung cells as well as the Delta variant
  - This is why we’re not seeing the cough and as much severe disease
  - We see more upper respiratory/ bronchus symptoms
- Omicron is more contagious
- Epidemiological data from South Africa
  - Their numbers are down now, over 35% off their peak
  - There is a shorter length of hospital stay- 2.5 days versus 8 days
  - Hospitals there were not over run
- Bedside data also suggest Omicron causes a more mild illness
- The observation of a milder clinical syndrome is complicated by the high seroprevalence in South Africa (from previous infection)
  - There is some natural immunity and vaccine immunity in this population
  - This is a more immune population and this has to be taken into consideration with the observation that this virus is a little more replicable and maybe a little less pathogenic
- Question- with the immunity present in our population, will Omicron cause less of a problem than Delta (in terms of outcomes that we care about)?
  - The population had less immunity when Delta began to spread
  - Delta seems to cause more severe disease than Omicron
  - Omicron begins to spread as there is more immunity in the population
  - Omicron is very transmissible but seems to cause milder disease
- When are there enough mutations [in SARS-CoV-2] to cause new variants to be considered a different coronavirus instead of a variant?
- Is this going to be the 5th seasonal coronavirus
- Put this in context, there are 4 coronaviruses the circulate year to year and account for about 25% of the cases of the common cold
  - So will this (Omicron) become the 5th seasonal coronavirus?
- The Russian flu of 1889-1891
  - Many postulate that this horrible pandemic may have been caused by a coronavirus that turned into 1 of the 4 seasonal coronaviruses that we live with today
  - This preceded the Spanish flu (of 1918)
- A seasonal cold can actually kill somebody who’s medically fragile with comorbidities
  - Hospitalists see this every winter
  - Standard viruses can cause a very nasty syndrome; these viruses include: influenza (the flu), coronavirus, adenovirus, and RSV
  - People with comorbidities fill up the hospital
  - Hospitals operate at capacity
- The question is at what point does this coronavirus become different from seasonal viral disease?
- Thinking of this through the lens of evolution, Omicron would be the best (in terms of the virus’s best interest) because it is highly communicative and not lethal
  - The worst viruses are harder to spread and kill their hosts
- Is there an evolutionary argument or logic to suggest that as the virus becomes  more evolutionarily fit it will kill less and spread more?
  - This seems to make evolutionary sense
  - Compare it to SARS-1
    - It had higher fatality rate
    - It could be detected symptomatically when it was contagious
    - When people were asymptomatic, they weren’t contagious
    - This virus could be stopped by behavior restrictions
    - What is now considered hygiene theater, pointing a temperature gun at somebody’s head would have worked (to identify who is infectious) with SARS-1
    - Evolutionarily, this wasn’t avery successful virus
  - SARS-CoV-2 spreads with it’s asymptomatic and causes severe disease in vulnerable people (typically)
    - But there are so many vulnerable people that this ended up causing a pandemic level of drama
  - Now Omicron spreads so fast that everyone gets exposed at some point
    - It causes less severe disease (we think)
    - This is a very successful virus that gets rewarded by being part of the pantheon of our seasonal biome that affects humans every year

- Maybe Omicron is nature’s vaccine
  - For 93% of the population living in poor countries in the world, they don’t have access to a vaccine right now
  - It may be ideal to get the vaccine over getting the infection
  - But maybe that is the silver lining of this variant, providing immunity to those not vaccinated
    - Maybe this is how the pandemic ends

## Measuring immunity and protection from severe disease—circulating antibodies, B cells, and T cells [13:15]

- A Johns Hopkins study in pre-print shows the importance of T-cell immunity in protection from COVID
  - This is an under recognized part of the immune system and absent from  much COVID discussion
  - T cell immunity is solid against Omicron as it is for Delta
- Peter brings up the expression, “*what gets measured, gets managed*”
  - Immune strength is inferred by measuring circulating antibodies
    - This is not the same a neutralizing antibodies
    - Both are part of B cell immunity
  - Then there is T cell immunity
    - See the [podcast with Steve Rosenberg (on cancer) for an in-depth discussion of B cell versus T cell immunity](https://peterattiamd.com/stevenrosenberg/)
  - There is not a laboratory test for T cell immunity
  - There is not even a commonly available test to measure neutralizing antibodies
  - One can’t really measure what memory B cells are doing
- It seems like we’re flying blind and making a lot of assertions about immunity based on what might be the least important thing that can be measured (levels of circulating antibodies)
- Antibody levels go up and down
  - When people get a second dose of vaccine the antibody levels go up tenfold compared to the first dose
  - That second dose is good for activating memory B cells and memory T cells
  - Antibodies come and go; they linger for moths in the system and then they wane
  - Having this intense focus on only 1 aspect of the immune system (antibody titers) creates a scenario where we’re chasing our tail to keep those levels high
    - The higher they are the less likely one is to test positive
    - This has created an expectation that the vaccine is somehow failing
- Cellular immunity is still strong when antibody levels wane; it is still preventing severe illness
- Focusing on circulating antibodies creates a cascade of surrogate markers that don’t really measure what we’re directly interested in

**What do we really care about?**

- # of people in the hospital, sick and dying
- Long-COVID
- How do we look at this; do we have good measurement criteria to look at this?
  - Question- are we immune to severe disease
- Realize people are still going to get cold and flu symptoms
  - They’re still going to potentially be infectious during that period
  - But they’re not going to settle into cytokine storm, [ARDS](https://www.nhlbi.nih.gov/health-topics/acute-respiratory-distress-syndrome), and being prone in a ICU ready to die

## Policy questions: what is the end game and how does the world go back to 2019? [18:45]

- Imagine if we tested for influenza every flu season and graphed on a daily basis the number of cases
- 10-25% of the population will get infected with a respiratory virus every year because there are many viruses; we’re not going to eradicate these pathogens
- Chase antibody titers or protection from severe disease

## A policy-minded framework for viewing COVID and the problem of groupthink [24:00]

- What the world looked like in 2020 is very different from today
- In hindsight pulling kids out of school in March of 2020 was the wrong thing to do though it was a reasonable precaution
- The view of this has changed over time as more knowledge and experience is available
- A framework to view COVID
  - 1) Preventing infections (social distancing, masks, vaccines, lifestyle modification)
  - 2) Treating infections (drugs)
  - 3) Providing supportive care for people who end up in the hospital (ventilion, steroids, etc.)
- Knowledge has come a long way in less than 2 years
- How many people in the US are at risk of dying?
  - A rough calculation comes to 1.4 million
  - What will reduce this number without destroying society?

[30:30]

- Many new therapeutics have not been incorporated into practice everywhere; this is a glimpse of what is broked in the broader healthcare system
- Suffering from problems of group think in medicine
- Benefits of specific interventions discussed
- Scheduling of vaccine booster doses largely dependant on what was tested in the clinical trial
- Evidence for supplemental vitamin D being helpful is not strong
  - There is a difference between supplemental vitamin D and vitamin D acquired by being in the sun
- What should the message to patients be when 99.6% or whatever of people are going to get better, no matter what, in other words, staying home and doing nothing, they’re probably gonna be just fine
  - It is important to consider the patient’s risk factors and age, etc.
  - It is essential to risk stratify
- Doctor’s are put in a terrible situation in the US; they are put on the frontlines of the pandemic without any good data for a long time
  - The basic, bedside clinical research needed to answer questions quickly were not performed quickly
- This created a vacuum that was filled with political opinion
- Stats are discussed on how research money was spent

## The difference between science and advocacy [39:00]

- The difference between science and advocacy is very important but this line has been blurred
  - This is something Peter talked about with [Rogan](https://open.spotify.com/episode/5DuxGhOJSa7X0AKvJGwwta) and a fundamental issue here
  - Science is a process and information changes over time
  - The job of an advocate is different, it is to communicate something with complete certainty
  - There is uncertainty in science and this is not reassuring
- Conversations about science and ideas of policy are needed
  - The [email from Francis Collins to Fauci](https://www.dailymail.co.uk/news/article-10324873/Emails-reveal-Fauci-head-NIH-colluded-try-smear-experts-called-end-lockdowns.html) was chilling
- One of the big questions now is how to avoid group think
- How science has been corrupted and there has been a shutdown of scientific discussion
- Academic bullying is a problem
- Why has the NIH not done a study on natural immunity?

## Natural immunity from COVID after infection [46:00]

- What we know
- Contradiction between policy and scientific evidence
  - Conflict between public health and scientists
- None on the podcast are virologists; are there other examples of viruses where natural immunity does not develop after infection is cleared?
  - Yes, Strep throat is an example
  - The flu (influenza) changes to make the pathogen different each year
  - Measles is an example where recovery provides sterilizing immunity and protection from reinfection
  - Paul Offit discussed in a prior podcast the spectrum of immunity developed after recovery from infection
  - Some coronaviruses cause the common cold (cold coronaviruses)
  - Other coronaviruses cause severe disease, there have been 3 in history: SARS, MERS, and COVID 19 (aka SARS-CoV-2) (hot coronaviruses)
  - Study of SARS 17 years out show solid natural immunity
  - MERS was studied 3 years out and the natural immunity was solid
  - Start with the hypothesis that natural immunity works
    - We don’t see people get reinfected with severe illness
    - Rhesis monkeys were rechallenged with the virus; they were not reinfected
    - Cleveland clinic study of hospital workers exposed to COVID found no reinfection and vaccination did not add to protection
    - Washington University study did bone marrow biopsies and looked at the activated T cells in the system
    - Study in Israel showed that natural immunity was 27 times more protective adjusted for age than vaccinated immunity

**Studies of natural immunity to COVID [51:15]**

- Study of natural immunity in Israel
- Analyzed the rate of people who tested positive, did not get the vaccine, and then tested positive again
- Data on boosters reducing hospitalization in people over 65 by 10-fold
- The fear in public health circles that if they talk about natural immunity then people may try to get infected; this is risky
- Let’s be more honest in the conversation
- The 2 studies cited by the CDC [53:00]

> “*These studies would not qualify for a seventh grade science fair. The methodology was so poor.*” -Marty Makary

- 1 study in Kentucky, the rates of reinfection in both vaccinated and natural immune group were exceeding low
  - The sample size was too low
- The second study made conclusions about population risk by surveying people in the hospital
- But numbers from these studies get quoted all the time

- Peter asks about a meta-analysis
  - Martin Cutler (who was the Harvard professor now he’s at Brownstone Institute) has summarized the 141 studies on natural immunity
- The question is- does reinfection lead to severe disease and patients needing to be put on a ventilator?
- There is not a lot of evidence published on this
  - This is knowable but it is frustration that this information is not published

## The unfortunate erosion of trust in science despite impressive progress [57:15]

- Discussion of breakthrough infections and infection during pregnancy
- The internet amplifies these anecdotes into larger, distorted data sets influences fear and policy decisions
- This is where science is needed to tease out this information
- An advocacy position says vaccines cure everybody; this is arrogant
  - Science acknowledges that vaccines are a probabilistic game
  - Vaccines reduce the probability of infection, the severity of infection, but that’s all probabilistic
- Demonstration of the scientific method in the last 2 years
- Erosion of trust in science and medicine
  - What will be the cost in the future because of this

> “We’ve won the battle and lost the war from a scientific perspective” – Peter Attia

- The problem with vaccine mandates as an advocacy position

## Do the current mandates and policies make sense in light of existing data? [1:02:30]

**Effects of the pandemic on vulnerable members of society, children**

- The Brown University Study on childhood cognitive scores from 2020-2021
  - Reduced verbal, motor, and cognitive performance compared to kids born before the pandemic
- Mental health crisis

**Do the policies and mandates make sense? [1:03:30]**

- How much do vaccines reduce the ability to spread infection?
- Lancet study, peak viral shedding showed peak viral shedding was equal in vaccinated and unvaccinated people
  - The difference was the time of virus shedding, 1 day versus 3 days, respectively
- Question- when a vaccinated person is asymptomatic (not pre-symptomatic) are they infectious?
  - These data are not available
  - The answer is, they are probably not infectious
  - Community cocooning effects, seen in places like the Bay area where the vaccination rates are 90+ %; there really aren’t that many cases
- Benefits of vaccination [1:08:00]
  - Reduction in disease severity
  - Reduced disease transmission
- Would there be a different policy view if the vaccine didn’t reduce severity of illness by more than 50%, but it reduced transmission by 99%
  - The main goal here would be dropping transmission and achieving true herd immunity
- If the goal is the opposite to reduce severe disease, policy changes dramatically
  - This shifts from a community level decision risk to an individual level decision
- Mandates can backfire

“ It seems to me that we’re using the wrong policy tool.” – Peter Attia

- Therapeutics we have today (just FDA approved) have cut COVID deaths to zero in the clinical trials
  - Once they get distributed, no one should be dying of COVID, with rare exceptions
  - These studies are still small, about 1000 in each arm
  - In a real population, some people treated will still die
- Do the policies of a 10-day quarantine for college students who test positive make sense when their disease will likely be mild?
- What is the evidence to support recommendation/ mandates of boosters?
- This seems to be an opinion based on the best evidence available, an editorializing of sorts

**What are the costs of COVID policies [1:16:30]**

- Anxiety in teens kept at home away from their social network
- Pressure of using Zoom
- Now that we have better immunity against severe disease, do we need to change our society over COVID
  - Does every child need to be vaccinated
- Policies are damaging our community and society

## Risks associated with vaccines, and the risk of being labeled an anti-vaxxer when questioning them [1:18:15]

- J & J data, 6 cases of [VTE](https://www.cdc.gov/ncbddd/dvt/facts.html#:~:text=Venous%20thromboembolism%20(VTE)%2C%20a,can%20cause%20disability%20and%20death.) (venous thromboembolism, blood clot) in 7 million doses
  - An incidence of about 1 in 1 million caused the vaccine to be pulled
  - There is a difference between peacetime and wartime vaccine communication
- Danger of letting vaccine rates for measles drop below 90%
- Risks of vaccination and benefits are worse for young people

> “There is a very small group of non-age diverse, non-ethnically diverse, poor political appointees with political allegiances, making all the decisions on COVID for the country” – Marty Makary

**The label of anti-vaxxer has squashed legitimate questions [1:23:45]**

- A tribalism had developed where a person who questions something that threatens the message of vaccinate everyone is labeled an anti-vaxer
  - These questions became squashed
- Last year Marty was calling for lockdowns and universal masking
- But after vaccine rollout he recommended an age-based approach
- People with natural immunity can wait for the second dose of vaccine
- Problems with the VARS system of tracking vaccine complications; problems with follow-up
- The vaccine still makes sense in certain contexts; its nuanced

## Data on incidence of myocarditis after vaccination with the Pfizer and Moderna vaccines [1:26:15]

- The party line (and what CDC says) is the risk of myocarditis in young people from natural COVID infection is much greater than the risk of developing myocarditis as a result of vaccination
  - The denominator of how many people are infected with COVID is not known, this is underestimated
  - This stat relies on study of hospitalized patients, and of course they are sicker
- The  European authorities have acknowledged the risk of myocarditis from the Moderna vaccine and don’t recommend it for people under 30
- The risk of myocarditis is around 1 in 7,600 in males age 15-25; 90% of this complication was clustered around the second dose
  - [Published in the NEJM](https://www.nejm.org/doi/full/10.1056/NEJMoa2109730)
- Most of the myocarditis was mild but 1 person died (22 years old)

> “But look, by and large, this is a safe vaccine. But for parents asking these questions about vaccinating their kids against an illness that has an ultra rare rate of death in healthy children, this is a reasonable conversation to have maybe the rate of death from the vaccine parallels the rate of death from COVID in a healthy child” – Marty Makary

- The CDC reports, there are 668 deaths in children over 2 years
  - Many believe that these deaths are in children with comorbidity medical conditions
  - But they still need to be protected
- A German study in pre-print of children age 5-17 show that no previously healthy children have died from COVID
  - This changes the calculus for parents
  - A conversation is needed; there is not a one-size-fits all strategy
- New England Journal of Medicine study, published on December 8 looked at boosters in people under 30
  - There are no deaths in people under 30 who are vaccinated with the primary series
  - You can’t go lower than zero deaths
- A [study published in Circulation in July of 2021](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.121.056135) stratified risks and benefits by age
  - For 12-17 year olds, the Moderna vaccine is 3-4x more likely to be associated with myocarditis
  - The supplemental data came out 2 day ago and it’s 5x
  - 8-10 cases of myocarditis per million doses; this is 56-69 cases, 38 ICU admissions, and 1 death
  - More data is needed on this; what about the kids who make an unremarkable recovery? Are there any chronic issues?
  - Some of these kids had preexisting cardiac abnormalities

## Outstanding questions about myocarditis as a side effect of mRNA vaccination and the benefit of boosters [1:35:00]

- The WHO said the universal booster program threatens to prolong the pandemic and recommends against these boosters [1:39:45]
  - Boosters will increase global inequalities because 93% of the population of poor countries has no vaccine

## The risk-reward of boosters and recommendations being ignored by policy makers in the US [1:40:30]

- The WHO says that people under the age of 6 should not be wearing a mask
- Many European countries have restricted or banned the moderna vaccine from anyone under the age of 30 because of the risk of myocarditis
- Is the US making policy errors?
- The FDA bypassed their technical experts to recommend boosters for everbody
  - The experts said boosters are not needed for everyone over 18
  - Now there’s enthusiasm to boost teenagers; a lot of the world is not on board with this
- Data is lacking for Omicron when Pfizer put out a press release promoting boosters
  - But this began the group think on promoting boosters for everyone
- COVID vaccines are not like the measles vaccine; they do not provide sterilizing immunity
  - High level herd immunity is not achieved by vaccination

## Sowing distrust: Lack of honesty and humility from top officials and policy makers [1:43:30]

- Fauci is in the horrible position of being the nations top expert on infectious disease in a moment when nobody knew anything
- What is the long game?

> “Where’s the humility?  People are hungry for honesty right now.” – Marty Makary

- Francis Collins thinks it’s unlikely that COVID came from the Wuhan lab
- Discussion of gain-of-function research
- This situation is similar to when doctors get sued over a medical error
  - It isn’t the graveness of the error, it’s the arrogance of the physician and their lack of humility when they interacted with the patient
- ZDoggMD interviewed Fauci as part of a documentary filmed before COVID (not yet released) about vaccine advocacy and the anti-vaccine movement
  - He has been attacked by activists on conspiracy angles
  - It felt like science itself was under attack to some degree
- But Fauci needed the insight to be honest
  - If masks should be saved for healthcare professionals, say so
- We forget he’s 80, 81 now
- He is rational, calm, logical, and science based so what is going on now is difficult
- We shouldn’t be putting our entire faith and trust in 1 individual
- It is good to hear multiple different medical opinions
- Marty was very nervous about the pandemic in the outset after talking to doctors in Wuhan
- He made recommendations to the White House at the onset of the pandemic but they replied that it was okay because they talked to Dr. Fauci
  - They hedged their bets that it would fizzle out like SARS-1 in 2003
- As a physician it’s easier to give reassurance than it is to say, “*yes, I’m very concerned*”
- The problem is the focus on just one single opinion

## Thoughts on testing: does it make sense to be pushing widespread testing for COVID? [1:52:15]

- ZDoggMD asks, with the availability of the vaccine and therapeutics, does it make sense to have a widespread prush for testing?
- Peter doesn’t think so
  - There isn’t a precedent for tracking rates of infection for respiratory illnesses
  - What we pay attention to is hospitalizations and severity of illness, death
  - Morbidity and mortality are the statistics that matter, but somehow infection rate has become the metric that matters
  - We don’t measure influenza infection rates
- ZDoggMD discusses personal downsides and upsides of testing
  - For someone who is young and asymptomatic, to be screened with an antigen test and identified as positive it’s stressful
  - The 5-10 day quarantine is difficult
  - The upside is, if this is a true positive, this person can stay home and not infect other people
  - But if the virus is already widespread, does it really make a dent in something like Omicron?
- Peter thinks the test shouldn’t be ordered unless the outcome would change how the patient is managed
  - Test the symptomatic patient who therapeutics can help
  - Testing asymptomatic athletes seems ridiculous
- Physicians have been put on this singular mission to hunt viral replication and block it at all costs
  - what’s lost is treating the entire person
  - The sustainability of this system has also been lost
- Mass testing creates a burden
- There is also a limited supply of tests, about 160 million tests per month

## What is the end point to all of this? [1:58:45]

- This has been evolving from the beginning
- How do we transition to an endemic virus?
- We don’t want to overwhelm our hospitals
  - Should we pay nurses and doctors an overtime bonus to get through this?
- How many lives have been saved?
- How many lives were cost by substance abuse, overdose, and economic disaster?
- Marty notes this is difficult because people are conflating two different problems that are happening simultaneous in the United States
  - 1) COVID-19 public health threat, mostly from the Delta strain
  - Virus infecting 10-20 million Americans who are still at significant risk; those without natural or vaccine immunity
  - We’ve still got to get them vaccinated
  - 2) 250 million americans have some form of immunity; they are at risk of mild illness and now we’re waging world war II to transiently beat back a mild infection
- The context of the risk of mild infection of those with some form of immunity is not being discussed
- The people dying are those adults with no immunity
  - Some are also older people who are unboosted
- There are about 7,000 people being hospitalized with COVID a day, most of them with no immunity
  - These are adults who often have a risk factor like obesity
  - This is not talked about
  - This is a precise problem but we’re holding everyone else hostage
- Marty thinks people are fed up and pushing back
- Australia  had the toughest lockdowns; their goal was zero COVID infections
  - Their prime minister just said, “*we’ve got to get past the heavy hand of government. We’ve got to treat people like adults. We have to move from a culture of mandates to a culture of responsibility.*”
  - This is the way to move forward
- ZDoggMD relates this to the form and function of COVID
  - The different forms are the masks and mandates and lockdowns and so on and so forth
  - The function is to obtain some outcome that we all agree is reasonable
  - It’s reasonable that we don’t want bodies piling up in the ER parking lot of the hospital
  - Occasionally this happened in some areas, but on mass, it has not
  - How do we prevent this?  Target focused protection of the groups mentioned earlier
  - Boosting a 16-year old or a college student is not a high yield way to do this
- He looks at the hospital numbers in Ontario, Canada and their ICU utilization and wonders why they are going on lockdown

## Downstream consequences of lockdowns and draconian policy measures [2:05:30]

- What does the MMR vaccination rate (and other vaccines) look like for last year?   Has there been a shift?
- ZDoggMD has read anecdotes about the level of kids going in for routine vaccinations dropping in the 80% range
  - Because parents are frightened and there is a backlash against vaccines in general
  - What will the outcome of this be?
- Peter asks, “*what is the long term consequence of this for a generation, all the people who have been marginalized, all the people who have been dismissed in their concern, all the people who have been told you are a horrible human being for questioning a vaccine*”
- Marty doesn’t think our policy makers are getting good medical advice
  - As soon as Omicron cropped up in South Africa, our public health officials retreated to the one blunt tool that they know, a third dose of vaccine across the board
  - There is data to support a booster of older people but not young people
  - Half of NY city is closed down
- What about therapeutics?
- What about learning to live with it?
- ZDoggMD notes that rational thinking is not how politicians tribalize our world; it’s a badge of tribal identity to say I believe in this or that regardless of what the long term outcome is
  - They want to rally their base
- Travel to South Africa was stopped because it’s easy, it’s politically expedient
- Omicron is everywhere; this was said from the beginning
- Vaccination is a blunt instrument used to try and reduce cases
  - So it’s surprising that testing is encouraged because this is going to increase the number of cases

> “*There’s this weird political tribalization that makes it irrational to people who are looking at it from an objective standpoint*” – ZDoggMD

## The polarized nature of COVID—tribalism, skeptics, and demonization of ideas [2:10:30]

- Peter asks how many people are in the middle of these 2 polar opposite views on COVID
  - On the one hand, people think this is a pharma conspiracy to make more money; the only thing that works is ivermectin
  - The other group is everyone needs to have a booster every Monday and we never want to see the world as it was in 2019 again until this virus goes the way of smallpox, a zero COVID policy world
  - How many people are not in one of these 2 groups?
- ZDoggMD’s experience with his platform has created a synthesis middle position they call the alt middle; it’s not a politically central position
- Peter Linberg of [The Stoa](https://www.thestoa.ca/) talks about this **thesis position** of COVIDians
  - This supports lock downs, COVID vaccines for everyone, mandates, closed schools
- The **anthesis position** is the other position
  - This supports ivermectin as a therapeutic
  - This is all about control
  - COVID is not as serious as we think
- ZDoggMD asks, “*What is the synthesis of those positions? Where do you find truth? There’s everything is a little bit partial. So this ultimate perspective is you can call it the center, but it’s really a synthesis position in integral holistic position.*”
- When he talks to people, walks them through it a little bit, he’s never talked to a thesis or antithesis person that hasn’t ultimately settled on a more synthesis position
  - This gives him hope
- But what happens publicly is reward for polarizing into one of the 2 extremes; this needs to change
- ZDoggMD notes that podcasts like [Joe Rogan’s](https://www.joerogan.com/) are so popular; he often espouses a synthesis rationalist position even when entertaining people on the show that are really more anthesis or more synthesis
- The woke idea ideologues are common in rational people
  - Not many rational people want to hurt a trans person or exclude someone based on their sexual orientation or their race
  - This ideology diminished real racism and inequality
  - We’ve had decades of progress
- We talk about COVID-idiots, but are you going to call an African American in Baltimore who’s afraid of getting the vaccine because of Tuskegee and the long history of medical abuse a COVID-idiot?
  - This generates a ton of cognitive dissonance until you can see this from a integral perspective that all this stuff has a bit of thin partiality to it
- People are trying to synthesize something that is evolving
- ZDoggMD feels like Twitter has weaponized the pandemic lunacy
  - This is why he’s staying away from Twitter now
  - Humans react
  - This has been potentiated on mass now with technology, the drive to go in group out group
- People have been paralyzed by fear
  - They are being demonized but are actually good people
- Marty thinks these are good points and we need to do all we can to stand against tribalism
  - We can listen to others
  - We can admit when we’re wrong
  - These are characteristics that are being completely lost in the echo chambers of cable news and hearing what you wanna hear
  - Big tech is allowing people to live in an alternate reality
  - News makes the other side look like they’re crazy because that’s how news has framed their position

> “We gotta fix this because the next pandemic is probably gonna be more severe” – Marty Makary

## Looking back at past pandemics for perspective and the potential for another pandemic in the future [2:20:00]

- Older patients remember what it was like to go through the polio epidemic
- Other epidemics: H1N1, SARS, MERS, Ebola, Zika
- The next serious pandemic may be antimicrobial resistance
  - It’s increasing each year
- Maybe it’s influenza virus (the flu)
- The overall global fatality rate for COVID-19 is somewhere around two tenths of 1%
- What if the next strain of influenza has a fatality rate of 2%?
  - We can’t do this with the current polarized echo chamber of the news and politicization of the immune system

> “We can’t do this in the future. We’re going to need diverse opinions, an open form of discussion, honesty, humility.” – Marty Makary

- Marty is very concerned about where we are in our current situation

## What parents can do if their kids are subject to unreasonable policies [2:25:00]

- Should a 12 year old not be able to play sports if they’re not vaccinated?
- A lot of people are fed up
- Democracy does work, but it takes time
- Polls show that people want a reasonable approach
- Marty predicts that pharma will change the language to discuss an annual booster, “*are you up to date with your booster*”
- Things people should talk about and ask about
  - An endpoint to restrictions in schools
  - Criteria to remove masks
  - A single dose of the Pfizer vaccine for their children or spacing out the doses
  - Some people with natural immunity should feel good about their immune protection

## Voices of reason in this space [2:28:45]

- ZDoggMD is a fan of [Dr. Monica Gandhi](https://infectiousdiseases.ucsf.edu/people/monica-gandhi), UCSF infectious disease
  - She is very much obsessed with getting us back to living instead of living in fear all the time
  - She’s a pragmatist, very, very smart and data driven
- Marty replies, “*There’s really just one person. And that’s Dr. Anthony Fauci.*”
  - He’s a true gentleman
  - Marty has had different opinions on how to manage the COVID strategy
- Marty agrees that Monica Gandhi is terrific
- [Amesh Adalja](https://publichealth.jhu.edu/faculty/3528/amesh-adalja) from Johns Hopkins has been correct on India and Delta and so many other things
  - He was previously on this podcast, [#106 – Amesh Adalja, M.D.: Comparing COVID-19 to past pandemics, preparing for the future, and reasons for optimism](https://peterattiamd.com/ameshadalja/)
- [Martin Kulldorf](https://brownstone.org/author/martin-kulldorff/) from Harvard who is now with the Brownstone Institute puts out great information

> “And I would say more importantly, I do not listen to anyone. Who’s a politically pointed physician, anyone the current past or future, if someone trying to become a politically appointed physician or was I just block them right out. And I go to these go-to people who I trust” – Marty Makary

- ZDoggMD adds a couple more; he will go to someone who is very politically angled on social media, who takes strong stances, but he doesn’t give them blanket trust
  - He is a big fan of [John Mandola](https://twitter.com/drjohnm) on Twitter; he’s a cardiologist
  - [David Katz](https://davidkatzmd.com/) from Yale is good at looking at the big picture; he’s very rational

## Strong convictions, loosely held: the value in questioning your own beliefs [2:32:15]

- Peter notes the type of person who he doesn’t believe is one who says the same exact thing over and over, that doesn’t feel differently about this now versus 6 months ago or 18 months ago
- School closures last year are a good example, he doesn’t believe anyone who doesn’t think we got that wrong
- Something ZDoggMD points out when he talks about the alt middle is, “*you should be able to question every single one of your beliefs because there’s really, you know, if you’re sticking to one single view there, you’re probably missing something*”
- It gives credibility when someone says they were wrong about something for these reasons, and this is how their thinking has changed
- A hedge fund manager who is never willing to change their point of view in the presence of new information is going to end up losing money
- It helps to be malleable based on the available data
- In medicine the reward is uncoupled from the outcome and this creates mass confusion
  - It’s difficult to sort out the really good critical thinkers
  - ZDoggMD agrees that people would benefit from  having the endpoint sync with their thinking
  - It’s hard to know what the outcomes are for improving healthcare; what is the endpoint?
- Therapies have constantly pivoted in response to new information
  - The doctor may think a patient was not going to benefit from steroids, but when they do, they continue the steroid treatment
- Marty notes the thing that irks him, thinking of criticism of government is when someone is called a flip flop
  - A good response should be constantly changing
- ZDoggMD asks, “*How are you going to persuade somebody of something you think is important based on the data that you have if you do not show them that you’re flexible in your thinking, but firm in your convictions, loosely held and that new data would change your mind?*”
  - This flexibility is needed

§

## Selected Links / Related Material

**Previous podcast with Marty Makary**: [#68 – Marty Makary, M.D.: The US healthcare system—why it’s broken, steps to fix it, and how to protect yourself](https://peterattiamd.com/martymakary/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))

**Previous podcast with Zubin Damania**: [#37 – Zubin Damania, M.D.: Revolutionizing healthcare one hilariously inspiring video at a time](https://peterattiamd.com/zubindamania/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))

**Collection of information on COVID-19 on** **PeterAttiaMD.com**: [Coronavirus (SARS-CoV-2 / COVID-19) Information: Podcasts & Articles on SARS-CoV-2 / COVID-19](https://peterattiamd.com/covid-19/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/)

**Previous podcasts on COVID**:

- [#97 – Peter Hotez, M.D., Ph.D.: COVID-19: transmissibility, vaccines, risk reduction, and treatment](https://peterattiamd.com/peterhotez/) | The Peter Attia Drive Podcast (peterattiamd.com)
- [#98 – Peter Attia, M.D. and Paul Grewal, M.D.: Coronavirus (COVID-19) FAQ](https://peterattiamd.com/covid-19-update-03152020/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#99 – Peter Hotez, M.D., Ph.D.: Continuing the conversation on COVID-19](https://peterattiamd.com/peterhotez2/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#100 – Sam Harris, Ph.D.: COVID-19—Comprehending the crisis and managing our emotions](https://peterattiamd.com/samharris2/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#102 – Michael Osterholm, Ph.D.: COVID-19—Lessons learned, challenges ahead, and reasons for optimism and concern](https://peterattiamd.com/michaelosterholm/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#106 – Amesh Adalja, M.D.: Comparing COVID-19 to past pandemics, preparing for the future, and reasons for optimism](https://peterattiamd.com/ameshadalja/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#104 – COVID-19 for kids with Olivia Attia](https://peterattiamd.com/covid-19-for-kids/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#105 – Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted](https://peterattiamd.com/paulconti2/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#107 – John Barry: 1918 Spanish flu pandemic—historical account, parallels to today, and lessons](https://peterattiamd.com/johnbarry/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#115 – David Watkins, Ph.D.: A masterclass in immunology, monoclonal antibodies, and vaccine strategies for COVID-19](https://peterattiamd.com/davidwatkins/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#117 – Stanley Perlman, M.D., Ph.D.: Insights from a coronavirus expert on COVID-19](https://peterattiamd.com/stanleyperlman/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](https://peterattiamd.com/joanmannick-nirbarzilai/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#137 – Paul Offit, M.D.: An expert perspective on COVID-19 vaccines](https://peterattiamd.com/pauloffit/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#159 – Peter Hotez, M.D., Ph.D.: Evolution of the anti-vaccine movement, the causes of autism, and COVID-19 vaccine state of affairs](https://peterattiamd.com/peterhotez3/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#160 – Paul Offit, M.D.: The latest on COVID-19 vaccines and their safety, herd immunity, and viral variants](https://peterattiamd.com/pauloffit2/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))
- [#169 – Katherine Eban: COVID-19 Lab Leak: Examining all sides of the debate and discussing barriers to a full investigation](https://peterattiamd.com/katherineeban2/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))

**Posts on COVID-19 from PeterAttiaMD.com**:

- [COVID-19: How to interpret screening tests: video, spreadsheet, and primer](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (April 14, 2020)
- [COVID-19: What’s wrong with the models?](https://peterattiamd.com/covid-19-whats-wrong-with-the-models/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (April 20, 2020)
- [SARS-CoV-2 and the host response: psychological stress](https://peterattiamd.com/sars-cov-2-and-the-host-response-psychological-stress/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (June 7, 2020)
- [COVID framework: How does this thing end?](https://peterattiamd.com/covid-framework-how-does-this-thing-end/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (June 21, 2020)
- [Masking emotion in the age of COVID-19](https://peterattiamd.com/masking-emotion-in-the-age-of-covid-19/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (November 15, 2020)
- [COVID-19: A few things worth checking out: 12-13-2020](https://peterattiamd.com/a-few-things-worth-checking-out-12-13-2020/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (December 13, 2020)
- [Britain’s COVID-19 vaccine gamble; The upside of quitting](https://peterattiamd.com/britains-covid-19-vaccine-gamble-the-upside-of-quitting/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (January 10, 2021)
- [Does vitamin D deficiency raise COVID-19 risk?](https://peterattiamd.com/does-vitamin-d-deficiency-raise-covid-19-risk/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (January 31, 2021)
- [Should you get the COVID-19 vaccine?](https://peterattiamd.com/should-you-get-the-covid-19-vaccine/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (February 14, 2021)
- [A win for Topo Chico; COVID-19 vaccine second dose](https://peterattiamd.com/a-win-for-topo-chico-covid-19-vaccine-second-dose/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (February 21, 2021)
- [Metformin and COVID-19 mortality risk; a timeline of Kobe’s last day](https://peterattiamd.com/metformin-and-covid-19-mortality-risk-a-timeline-of-kobes-last-day/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (March 28, 2021)
- [mRNA vaccine technology](https://peterattiamd.com/mrna-technology/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (April 11, 2021)
- [Was COVID-19 the only culprit behind the extraordinary increase in deaths last year?](https://peterattiamd.com/was-covid-19-the-only-culprit-behind-the-extraordinary-increase-in-deaths-last-year/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (May 2, 2021)

**VPZD Show, ZDoggMD’s podcast with Vinay Prasad**: [The ZDoggMD Show Podcast](https://zdoggmd.com/podcasts/) | Dr. Zubin Damania ([zdoggmd.com](https://zdoggmd.com/))

**Marty’s website**: [MartyMD.com](https://www.martymd.com/)

**ZDoggMD’s website**: [Zdoggmd.com](https://zdoggmd.com/)

**ZDoggMD’s YouTube channel**: [ZdoggMD](https://www.youtube.com/user/ZDoggMD)

**Peter discusses the difference between advocacy and science with Joe Rogan**: [#1735- Peter Attia](https://open.spotify.com/episode/5DuxGhOJSa7X0AKvJGwwta) | Joe Rogan, [The Joe Rogan Experience](https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk) | [39:15]

**Differences between B cell and T cell immunity**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) | The Peter Attia Drive Podcast ([peterattiamd.com](https://peterattiamd.com/podcast/))

**Myocarditis in teens following COVID-19 mRNA vaccination**: [Myocarditis With COVID-19 mRNA Vaccines](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.121.056135) | *Circulation* (B Bozkurt, I Kamat, and P Hotez 2021) | [1:33:30]

**Myocarditis occurred mostly after the second vaccine dose in teenage boys**: [Myocarditis after BNT162b2 mRNA Vaccine against Covid-19 in Israel](https://www.nejm.org/doi/full/10.1056/NEJMoa2109730) | *NEJM* (d Mevorach *et al.* 2021) | [1:28:45]

**Safety of mRNA vaccine in adolescents**: [Evaluation of mRNA-1273 SARS-CoV-2 Vaccine in Adolescents](https://www.nejm.org/doi/full/10.1056/NEJMoa2109522) | *NEJM* (K Ali *et al.* 2021)

**Virologist argues that a 3rd dose of the COVID-19 vaccine is not needed for many people**: [Are COVID-19 vaccine boosters needed?](https://www.virology.ws/2021/08/19/are-covid-19-vaccine-boosters-needed/) | V Racaniello, [Virology Blog: About viruses and viral disease](https://www.virology.ws/) (August 19, 2021)

**Natural immunity and protection against the Delta variant**: [Duration of SARS-CoV-2 Natural Immunity and Protection against the Delta Variant: A Retrospective Cohort Study](https://academic.oup.com/cid/advance-article/doi/10.1093/cid/ciab999/6448857) | *Clinical Infectious Diseases* (P Kim *et al.* 2021)

**A single dose of mRNA vaccine provides greater protection to those previously infected**: [T-cell and antibody responses to first BNT162b2 vaccine dose in previously infected and SARS-CoV-2-naive UK health-care workers: a multicentre prospective cohort study](https://www.thelancet.com/journals/lanmic/article/PIIS2666-5247(21)00275-5/fulltext) | *The Lancet* (A Angyal *et al.* 2022)

§

##### Marty Makary M.D., M.P.H. & Zubin Damania, M.D.

**Marty Makary M.D., M.P.H.**

Dr. Marty Makary is a Johns Hopkins professor and public health researcher. He is a member of the National Academy of Medicine, serves as Editor-in-Chief of the 2nd largest trade publication in medicine, called Medpage Today, and he writes for The Washington Post, The New York Times, and The Wall Street Journal. He is the recipient of the Business Book of the Year Award for his New York Times bestselling book [*The Price We Pay*](https://nam11.safelinks.protection.outlook.com/?url=https%3A%2F%2Fsmarturl.it%2Fthepricewepay&data=04%7C01%7Cp%40attiamedical.com%7C941394cd72c64b161e8808d9c266f76e%7C818179767cb4449aa341c29596a5fcc4%7C1%7C0%7C637754569798684779%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000&sdata=se5f85eHDb0ebTzUESYZgY%2Fm8A2Lu4WHqaQA1e85gCY%3D&reserved=0). He is a graduate of the Harvard School of Public Health, has served on the faculty of the Johns Hopkins School of Public Health for the past 16 years, and served in leadership at the World Health Organization.

**Zubin Damania, M.D.**

Zubin Damania, aka Zdogg MD, is a UCSF/Stanford trained internal medicine physician and founder of Turntable Health, an innovative primary care clinic and model for Health 3.0 that was part of an ambitious urban revitalization movement in Las Vegas spearheaded by Zappos CEO Tony Hsieh. During a decade-long career as a hospitalist at Stanford, Zubin led a shadow life performing stand-up comedy for medical audiences worldwide as a way to address his own burnout. His videos and live shows have since gone epidemically viral with nearly a half a billion views on Facebook and YouTube, educating patients and providers while mercilessly satirizing our dysfunctional healthcare system. The goal of his movement is to rapidly catalyze transformation by leveraging the awesome power of passionate and engaged healthcare professionals. [[zdoggmd.com](https://zdoggmd.com/about-z/)]

Facebook: [ZDoggMD](https://www.facebook.com/ZDoggMD)

Twitter: [@zdoggmd](https://twitter.com/zdoggmd)

Instagram: [@zdoggmd](https://www.instagram.com/zdoggmd/)