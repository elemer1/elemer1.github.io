# #144 – Phil Maffetone: Optimizing health and performance through maximal aerobic function

**Source:** [https://peterattiamd.com/philmaffetone/](https://peterattiamd.com/philmaffetone/)

---

Phil Maffetone is an author, health practitioner, and coach with decades of experience helping everyone from amateurs to world-class athletes optimize their health and performance. In this episode, Phil explains the importance of developing the aerobic system, defines maximum aerobic function (MAF), and explains how to determine your MAF heart rate. He then demonstrates how to integrate that into a training protocol which is designed to help people move faster at a sub maximum heart rate and increase fat utilization as the primary source of fuel—emphasizing the importance of nutrition on one’s capacity to oxidize fat. Phil also extracts training insights from the amazing feats of world-class marathoners, explores the impact of a low-carb diet on one’s capacity for high intensity exercise and anaerobic performance, and explains the downstream effects of being “overfat.”

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/philmaffetone/the_Drive_public.png)

Play

#144 - Phil Maffetone: Optimizing health and performance through maximal aerobic function

#144 - Phil Maffetone: Optimizing health and performance through maximal aerobic function

1x15s30s

0:001:22:12

## We discuss:

- Phil’s background in running, and training insights from a six-day race (2:30);
- The difference between being “fit” and being “healthy” (11:00);
- Defining the aerobic and anaerobic systems, and why VO2 max doesn’t predict performance (18:15);
- Defining maximum aerobic function (MAF), determining your MAF heart rate with Phil’s 180 Formula, and why a strong aerobic system is crucial to health and performance (24:00);
- Using the MAF test to track and improve your aerobic fitness (37:30);
- How increasing your sub-max pace at a given heart rate can increase your maximum pace (40:00);
- The impact of nutrition on one’s ability to use fat as fuel while exercising (43:00);
- Phil’s nutritional approach with patients, the concept of “carbohydrate intolerance” (51:45);
- Assessing the impact of a low-carb diet on high intensity exercise and anaerobic performance (58:00);
- Extracting insights from world-class marathoners (1:04:45);
- How being “overfat” affects health and performance, and ways to decrease excess body fat (1:13:30); and
- More.

§

## Show Notes

## Phil’s background in running, and training insights from a six-day race [2:30]

**Background in running**

- Phil has been running since high school and college
- It started when he into a 5K, and it was a complete disaster
- But gradually, he progressed to the marathon
- Culminating in running a six day race

**The six-day race**

- The six day race is a race where you run around a track and the person who accumulates the most miles or kilometers is the winner
- You can start and stop any time
- Phil is fascinated by this style of race: “It’s really akin to having a mouse in a lab where you do something to this mouse, and then you put him back in the cage, and have him run on the wheel for awhile.”
- It was also a great opportunity to really hone my skills of observation in terms of gait
- Phil has wired with some ultra runners, like [Stu Mittleman](https://en.wikipedia.org/wiki/Stu_Mittleman) who he trained up for the six day race
- Talking to an athlete, you’re able to figure out when they’re ACTUALLY tired vs. when they say they are

*What did Phil discover to be the optimal strategy?*

- Start the race by walking (everybody else starts out running)
- Gradually pick up the pace, start jogging, until you hit your maximum aerobic heart rate
- About 2-3 hours into your first run, you start cooling down and take a half an hour break
- There’s no hard running at all during the race, no high heart rate, no high intensity training needed
- Sleep takes a back seat during the race — sometimes even taken very small naps as short as 7 minutes
- The crazy thing is when you interfere with your circadian rhythm you could literally hallucinate after day four
- It’s a bit like the RAAM, the [Race Across America](https://en.wikipedia.org/wiki/Race_Across_America), in cycling (see [Peter’s interview with Mike Trevino](https://peterattiamd.com/miketrevino/))
- The key to the six day race, says Phil, is to individualize the strategy based on the athlete while also making sure that not sacrificing the health of the person in pursuit of performance
- With Stu Middleman, Phil says that he accumulated about 100 miles per days without sacrificing his health — a win, win

## The difference between being “fit” and being “healthy” [11:00]

**Phil’s background in seeing professional athletes as patients**

- In his undergraduate college days, his goal was to study sports but to eventually get out into the real world and help everyday people with their health (as opposed to athletes)
- When he started practicing medicine in the 1970s, there was a boom in running and he started seeing many amateur athletes (e.g., 10K runners, half marathon runners, etc.)
- A lot of them were getting injured, and Phil wanted to know *why*
- He gradually started seeing more advanced athletes through referrals to the point where many professionals runners were coming to him (including marathons, triathletes, [Iron Man](https://en.wikipedia.org/wiki/Ironman_Triathlon) contenders)
- By the mid 1980s, Phil had seen professional athletes in all sports, and that was the majority of his patients (including [Mark Allen](https://en.wikipedia.org/wiki/Mark_Allen_(triathlete)) and [Paula Newby-Fraser](https://en.wikipedia.org/wiki/Paula_Newby-Fraser))

**When did Phil realize something was wrong with the way athletes were training/competing?**

- Phil began seeing how someone could run a marathon at an incredible pace — and the thought was “*wow, what an example of optimal health!*”
- However, it wasn’t exactly the case — they were broken down, they were getting sick
- Back then, for example, “it was a badge of courage to have a high white blood count because you were a runner”
- [Kenneth Cooper](https://en.wikipedia.org/wiki/Kenneth_H._Cooper)’s “aerobic revolution” was gaining mass adoption but something wasn’t working — “*people were falling apart*”

> “I started putting all these things together, and it was pretty clear that something wasn’t right.” —Phil Maffetone

**Being healthy vs. begin fit**

⇒ See Phil’s 2016 paper: [Athletes: Fit but Unhealthy?](https://link.springer.com/article/10.1186/s40798-016-0048-x)

![](https://peterattiamd.com/wp-content/uploads/2021/01/fit-but-unhealthy-801x1024.png)

**Figure 1. Fit but unhealthy: A training and eating paradigm.** [[source](https://link.springer.com/article/10.1186/s40798-016-0048-x)]

- Phil began having a hard time delineating between the relationship between being *healthy* and being *fit*
- He has an epiphany after he ran the New York City Marathon in 1980
- When he crossed the finish line, a lightbulb went off —“These athletes are fit but unhealthy”

> “Fitness and health are two separate definitions, and they need to be balanced whether you’re a grandmother who goes out for a walk four or five times a week, or you’re training for the race of your life as a professional.” —Phil Maffetone

*From that experience, Phil began thinking about the average person*

- He developed the [MAF test](https://philmaffetone.com/maf-test/), for example, for the average person (not just the athlete)
- This was a functional test designed to monitor progress in cardiovascular health — Could people walk faster and faster over time at the same low heart rate than they could a month or two earlier.
- Soon after that, Phil began noticing that guys were running faster now at the same heart rate— “*I thought, wow, this is interesting.*”

## Defining the aerobic and anaerobic systems, and why VO2 max doesn’t predict performance [18:15]

**What do we mean by aerobic and anaerobic systems?**

Aerobic system:

- Fat burning is associated with aerobic
- All of the factors that are associated with fat burning—
  - the aerobic muscle fibers,
  - the mitochondria, and
  - the ability to convert fatty acids into energy (ATP)

Anaerobic system:

- Using glucose (rather than fat) for making ATP
- Phil uses heart rate to determine whether you’re drifting into that anaerobic state
- Therefore, if you stay under a certain HR, you’re in an aerobic state

> “You’re training your body to burn more fat as an energy source, therefore, you’re going to store less fat, and you’re going to get rid of any excess fat.” —Phil Maffetone

**VO2 max**

- Despite common belief, VO2 max is not a great predictor of much

*How is the test done?*

- It’s a relatively straightforward test to administer provided you have the machinery to isolate gasses, specifically oxygen and carbon dioxide
- The test is normally done on either a treadmill or a stationary bike where you can control the resistance or the load that the athlete is under
- You want to measure how much oxygen is coming out of their respiratory system, and how much CO2 is coming out
- You know how much is going in, and, therefore, the difference is the amount of oxygen consumed

*Peter’s explanation of VO2 max*

- If you’re sitting at rest, you have a VO2, and an amount of oxygen that’s consumed
- The purpose of the test is to ramp up the level of exertion until you reach the *maximum level of oxygen consumption*
- Therefore, VO2 max is simply the maximum amount of O2 consumed
- The fitter you are, the more oxygen you’re able to consume
- A lot of people *erroneously* think this is a test of the heart and lungs, but it’s really a test of **what your muscles can do in terms of utilizing that oxygen**

**VO2 Max isn’t predicting performance**

- The research actually says that you can’t predict marathon finish time by VO2 max.
- But people don’t like hearing that because they have this idea that VO2 max is directly associated with performance
- They think they need to rev up their VO2 max by doing hard training, which will get them performing better, and that’s where the whole system breaks down

> “This VO2 max is something we have been worshiping, and we’re worshiping the wrong thing.” —Phil Maffetone

## Defining maximum aerobic function (MAF), determining your MAF heart rate with Phil’s 180 Formula, and why a strong aerobic system is crucial to health and performance [24:00]

**Maximum aerobic function**

- [MAF](https://philmaffetone.com/what-is-maf/) stands for maximum aerobic function
- In essence, the goal of being healthy and fit is to develop the aerobic system, says Phil

*Why is developing the aerobic system the goal?*

- This is what our ancestors did—we developed a really incredibly powerful aerobic system by doing the things in our lifestyle that drive that aerobic system to develop

> “We didn’t sprint after animals. We jogged after animals.” —Phil Maffetone

![](https://peterattiamd.com/wp-content/uploads/2021/01/MAF.png)

**Figure 2. MAF method.** [[source](https://philmaffetone.com)]

**Developing the concept of “maximum aerobic heart rate”**

- While studying anthropology in college, Phil began to wonder why are we doing all this “other stuff” in modern day
- “The concept of max aerobic function has been really with me for quite some time.”
- When he started working with runners, he began talking about the pace that these athletes could run at a given “aerobic heart rate” which he called, “maximum aerobic heart rate”
- He would try to have the runners’ pace be right up against their maximum aerobic pace.

*And how did Phil come up with this maximum aerobic heart rate for an individual?*

An individual’s maximum aerobic heart rate was originally derived with a combination of

- a physical exam in his (history, lab work, posture, strength, etc.); and
- observing the person on a track
  - monitor their heart rate
  - monitor their gait using different heart rates and seeing what heart rate would be when their gait would break down
- Next…
  - Phil would assign them a MAF heart rate and have them go and train
  - He would test them again to see if it correlated

*The formula was born*

- Two or three years later, Phil developed a formula for people that wanted to get as close to their MAF as possible without doing all the manual work with a physician
- The [MAF 180 Formula](https://philmaffetone.com/180-formula/) was born

**Phil’s 180 formula [28:00]**

[MAF 180 Formula](https://philmaffetone.com/180-formula/)

- A person is going to be at their maximum aerobic output—meaning they’re going to be maximally fat oxidizing—at an approximate heart rate of 180 minus their age, plus or minus a few modifications
- You begin with 180 minus your age and individualize it to your health and fitness needs
- For example, you would subtract 10 from your number if:
  - You’re recovering from an illness
  - You’re severely overtrained
  - You’re in rehab from an injury
  - You’re on medication
- You would subtract 5 from your number if:
  - You have asthma
  - You are a bit [overfat](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5206235/)
  - You haven’t exercised consistently in a while
- You can ADD 5 to your number if:
  - You’re a competitive athlete with no health problems

![](https://peterattiamd.com/wp-content/uploads/2021/01/180-formula-1024x735.png)

**Figure 3. The MAF 180 Formula for determining your MAF HR.** [[source](https://philmaffetone.com/180-formula/)]

⇒ See Phil’s paper validating this approach: [The Development and Initial Assessment of a Novel Heart Rate Training Formula](https://www.wemjournal.org/article/S1080-6032(15)00131-3/fulltext)

**How did Phil track HR in the 70s & 80s before modern tech?**

- Began by manually checking heart rates
- Then used some clips you put on the ear (they were not accurate, unlike the earbuds that are used today which work well)
- At some point he finally got a heart monitor that was used in cardiac rehab in hospitals — it was a big and obnoxious
- When he needed to use it he would go to the track, put it on an athlete, then take it off for the next guy
- “*I thought, okay, once they feel what 130 heart rate or 150 heart rate is like, they’ll be able to train that way. Well, that didn’t work*.”
- He started to realize people needed real time feedback to get the most out of their training
- It progressed that way, and then when the wireless heart monitors came out, everyone wanted to buy one

**Back the discussion around the 180 Formula…**

The math formula of ‘180 minus age, plus adjusting based on all other factors’, is a **way to gauge the proper intensity**

*How does Phil then prescribe volume?*

- Phil noticed that athletes and his patients were getting injured
- And as a coach, it was clear that if he could just keep his patients from from getting injured, they would perform better
- He found himself constantly dealing with fixing a runner’s knee, or whatever, then they would go out and train until the next injury happened
- Phil says he was constantly treating symptoms rather than the root cause
- Eventually, he started looking closely at his patients’ training routine
- In many cases, his athletes were over training
- From there, he became a coach

What he found being a coach

- Phil found that people could do **a lot less training, at a lot less intensity, and perform in a race a whole lot better**
- “When you taper, you get stronger”, says Phil

Phil became obsessed with, ‘*How do you build the best aerobic system?*’

- Working with a number of patients, Phil noticed that those who did the traditional two days a week of interval training on the track, **they never got faster at the same heart rate**
- Others who did the MAF style training seemed to excel quite quickly from one month to the next in terms of being able to go faster at the same heart rate
  - For example, they could be running starting at a nine minute a mile pace at their MAF heart rate. They might be running 8:30 a month later, same heart rate. A month later, now they’re running at an eight minute pace.

## Using the MAF test to track and improve your aerobic fitness [37:30]

Explaining the concepts of MAF heart rate and the MAF test

- Let’s say someone determine that their MAF heart rate is 130
- At that heart rate, they are running at a nine minute mile pace
- The question becomes: *While keeping my heart rate at 130, can I get faster? Can they go from 9 minute mile to an 8:30 mile to an eight minute mile while staying at 130?*
- By definition, that person will become aerobically fitter and more efficient

*Is there a point at which you begin to adjust up the heart rate?*

- Phil says he would like to keep that person at 130
- You could “cheat” up to 132 and 133 only to find out two months later that you’re back to where you were?
- But “I don’t want to spend that time, because at some point, I’ve had enough experience to know that’s not a good use of our time”
- Phil says to stay at 130 to allow your body to develop that aerobic system

*How does someone run faster at the same heart rate?*

- The answer is that you’re building the aerobic system and becoming better able to generate energy from fat
- You’re increasing fat burning so now you have more energy
- And the more energy stores that engine has, the faster it can go

*When do you plateau?*

- At some point, you will hit a plateau
- Phil’s experience is that it take three to six months before people hit a plateau

## How increasing your sub-max pace at a given heart rate can increase your maximum pace [40:00]

> “For an endurance athlete, it’s the greatest benefit they can obtain. Because if they can go faster at a sub max pace, they can go faster at a max pace.” —John Ioannidis

*Peter asks the following hypothetical*:

- You if look at the results of a 10k race, the top runners will likely finish around 30 minutes
- By definition those runners had to be running well **above their MAF target pace**

*Peter asks an important question*: If you take the top 10 finishers of that race, and then a week later have them run at their MAF heart rate, would they be able to cover greater distances at their MAF heart rate than the other people they beat in the 10k race?

- “We do have evidence that that is true, hypothetically” says Phil
  - There are outliers, i.e., someone who can will themselves to perform remarkably on race day but “these are people who are ready to fall apart any minute” says Phil
  - If we take those outliers away, then yes, we have this hierarchy of athletes who have an increasingly better sub max condition that corresponds to their race pace
- Peter comments that if this is true then it would really lend credence to the idea that **even if you’re training for a 5K or a 10K, you still want to push your MAF protocol**
- In other words, it still matters how much distance you can cover at that lower heart rate and lower intensity, where you are running at your maximum fat oxidation, and maximum aerobic capacity, if even you are planning to run a race using a pace that is above your MAF level
- Phil says it’s pretty clear now that **sub max performance predicts maximum performance**
- “*I think it comes down to* ***how much fat burning do we need****, and even for a mile, there’s a lot of fat burning taking place in a one mile race*.”

⇒ See Phil’s study: [5km Race Prediction from Submax Performance Tests: A pilot study](https://philmaffetone.com/5km-race-prediction-submax-performance-tests-pilot-study/)

## The impact of nutrition on one’s ability to use fat as fuel while exercising [43:00]

**How nutrition impacts fat oxidation potential**

- When Peter was in medical school, the conventional wisdom was that fat oxidation could not exceed one gram per minute
- Many years later, Peter adopted a strict ketogenic diet for several years
- He underwent an enormous dietary switch, from being an ultra distance athlete basically mainlining carbohydrates with formulas rotting his gut, to strict ketogenic
- While a carb eater, he would do VO2 max testing—which shows a lot of data on the way to your VO2 max such as fuel partitioning data
- In that state, Peter was nowhere near oxidizing one gram of fat per minute—In fact, he was pretty much only oxidizing glucose the entire time, even at his low intensity
- Fast forward several years when he’s on his ketogenic diet for three years and he’s become very adapted to it
- In his keto state, during VO2 max testing he hit a fat oxidation of 1.73 grams per minute just prior to reaching his VO2 max
- He remembers thinking, “how is that even possible??”
- He would go on to learn that world class athletes training on a very low carbohydrate diet were able to hit up to 2.2 grams per minute
- In other words, the conventional wisdom we have about sports nutrition and sports science is largely predicated on assumptions of what people are eating

Phil came to that same conclusion as Peter but in a different way

- Many of the subjects in the studies on this were big carbohydrate eaters that distorted the research completely
- Despite the research data, Phil had experience with patients and athletes that informed him that “there was something about fat”
- Occasionally in the lab, Phil would come across athletes that would make people say, “Wow, this is amazing. How could this person burn so much fat? We don’t understand this. It must be a problem.”
- But as the years went by, it was clearly not a “problem” at all—in fact it was a great thing
- By staying close to his patients, Phil alway knew that his athletes were getting healthier— “I *know they’re burning more fat because they’re running faster at the same MAF heart rate.*”
- Then, Phil gradually started thinking more scientifically about this…

- And the fat burning component became that factor that we can measure more and more
- He was able to determine that this type of lower-intensity training and lower-carb eating impacted people’s capacity to burn fat

**The nutritional component of fat burning [48:45]**

Peter points out the confusing nature of the nutritional component to fat oxidation

- “It creates a lot of confusion for people, which is that it tends to be in flux. So it’s not constant.”
- For example, between the ages of 13 to 18, Peter says he could eat as much food of any type that he wanted
- “Six or seven sandwiches for lunch every day, so a whole loaf of bread turned into sandwiches, plus french fries, plus a one-gallon thing of orange juice. Just disgusting quantities of food. But absolutely no impairment of performance or health.”
- But, by the time he was into his late 20s and my 30s, my tolerance for that amount of carbohydrate went down
- He was still exercising a ton, way more than most people, but he become metabolically ill

> “I became the example of that guy who can’t outrun his bad diet.” —Peter Attia

## Phil’s nutritional approach with patients, the concept of “carbohydrate intolerance” [51:45]

Peter asks: How was Phil able to coach up individuals on the idea of carbohydrate tolerance given that

- i) two people can be similar in a number of ways and yet be different in the nutritional regard, and
- ii) any given individual is likely going to see a deterioration of that over time.

Phil says we all become more insulin resistant as the years go by, but he is careful to refer to this as “carbohydrate intolerance” as people can better relate to that idea

**Phil’s “holism” approach**

- Back in undergraduate school, Phil’s idea of “holism” came from studying philosophy
- Holism is the idea that all systems are connected and work in conjunction with each other
- And more specific to his patients, holism means *weaving together exercise, nutrition and stress management*
- “*Out of that came this idea that we’re all individuals, and we all have uniquenesses, and I carry that with me into my clinical world*.”

*As it relates to nutrition…*

- Measuring insulin resistance back in the 80s was basically unheard of, says Phil
- As a clinician, because you do a good evaluation, you assess the patient, and you spend a lot of time talking to the patient, and you learn about so many things, including insulin resistance
  - How sensitive are they to insulin?
  - How do they respond?

⇒ Simple example: The New York City executive works in an office all day, and is also training for a marathon, goes out for lunch, comes back, and is so tired

- You simply ask them, “Bob, what did you have for lunch?”
- You start putting two and two together, says Phil

**The Two-Week test**

- Phil came up with a challenge for his patients called the [Two-Week Test](https://philmaffetone.com/2-week-test/)
- Essentially, for two weeks, the patient removes all the junk food from their diet, and also cuts way down on the natural carbohydrates like lentils and beans and rice and fruits
- After the two weeks, you looks at their symptoms and see if any are better
- And in Phils experience, he says about **75% of people get better**
- Next, you begin to add things back into the diet carefully to see at what point things start to trigger the bad symptoms again
- Phil points out the importance of enlisting the patient in the process: “*I want them to use their instincts and intuition to understand what it feels like to eat too much carbohydrate before you’ve gotten there*.”

> “Of all the miracles I’ve seen in clinical practice, the Two-Week Test is one of them because you see these people become new people after a very short period of time, and it’s really amazing.” —Phil Maffetone

## Assessing the impact of a low-carb diet on high intensity exercise and anaerobic performance [58:00]

**Assessing the impact of a keto diet on performance**

- Peter spent several years on a very low carbohydrate diet and saw enormous improvements in my **aerobic** fitness
- His anaerobic fitness (higher level intensity fitness), *did not* deteriorate, but it took a *very long time* for that to come around
- The conclusion Peter drew was that athletes who were very involved in *glycolytic activity* really ought not restrict carbohydrates as much as athletes whose sports are happening more at the aerobic level
- However, a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5950743/) that Phil was part of found something different

**The 2018 study**: [Effects of a 4-Week Very Low-Carbohydrate Diet on High-Intensity Interval Training Responses](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5950743/)

- A 4-week study that put recreationally trained athletes on a very low carbohydrate diet
- Diet was not standardized, but averaged 8% carbs, 15% protein
- Performance remained similar between groups, but the very low carb, high fat (VLCHF) group ended up with higher mean and peak fat oxidation
- **Conclusion**: very low carbohydrate intake *did no*t deteriorate high-intensity performance

*Phil’s comments about the study*:

- In a [separate publication](https://pubmed.ncbi.nlm.nih.gov/32000572/) for the same study, VLCHF was reported to decrease leptin, but had no effect on adiponectin, resistin, IL-6, glucose, or triglycerides — showing that the high fat diet did not have any adverse effect on inflammation
- But the [2018 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5950743/) really came from the idea that athletes can still burn high amounts of fat when they do interval training as shown in [Paul Laursen’s 2015 study](https://bmjopensem.bmj.com/content/1/1/e000047)
  - Paul’s study showed that, in well-trained individuals, high intensity training can still produce large amounts of fat burning (as opposed to burning 100% carbohydrate)
- Paul points out that the participants in his study weren’t professional athletes and wonders how the pros would respond
  - [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) and [Stephen Phinney](https://www.virtahealth.com/people/stephen-phinney) have done [some studies](https://pubmed.ncbi.nlm.nih.gov/26892521/) with higher level athletes (also see [Rethinking fat as a fuel for endurance exercise](https://pubmed.ncbi.nlm.nih.gov/25275931/))
- Also, in retrospect, Paul would’ve like to see the study go longer to see what would happen as the participants fully adapted to the low-carb diets — “to really stabilize that metabolic change”

**Phil’s main focus**: Helping people move faster at a sub max heart rate

- “*In fact, I don’t care what you do with your training or your diet. If you could run faster at the same heart rate as the months go by, whatever you’re doing is working, keep doing it*.”
- The [MAF test](https://philmaffetone.com/maf-test/) is just a tool, a powerful one, that helps people track their progress
- “*When they see they’ve gotten faster, and now they’re going to start doing some weight training, fatiguing type weight training, or they’re doing some intervals, and then they get slower, now you’ve got their attention*.”
- The original goal was to get people to do this protocol of exercising right at their MAF HR using how they feel rather than staring at their heart rate —
- But that never really happened — knowing HR is crucial
- Every once in a while he might come across an athlete that knows exactly how to run at that max fat burning level, but it’s uncommon

> “But for most people, we are in a ‘no pain, no gain’ world, and we’re seeing injuries.” —Phil Maffetone

## Extracting insights from world-class marathoners [1:04:45]

**Phil’s 2014 book**: [1:59: The Sub-Two-Hour Marathon Is Within Reach—Here’s How It Will Go Down, and What It Can Teach All Runners about Training and Racing](https://www.amazon.com/gp/product/B00LKCP6AQ/ref=dbs_a_def_rwt_hsch_vapi_tkin_p1_i7)

**In October of 2019, Eliud Kipchoge broke the 2 hour mark**: [Breaking2](https://www.nike.com/running/breaking2)

- It wasn’t recognized as official as it was sort of a contrived example of what could be done under the most optimal conditions
- That said,  there’s simply no denying that what Kipchoge did was unbelievable
- In the [2018 Berlin Marathon](https://en.wikipedia.org/wiki/2018_Berlin_Marathon), Kipchoge got very close in an official race with a time of 2:01:39 — the official world record

**Phil’s thoughts**

Back in the 1990s…

- Phil knew that someone would eventually break the 2 hour barrier — he even wrote an article about the inevitability because the lead pack runners were running faster and faster and world records were being broken all the time
- “*There was no evidence that said this is going to stop, we’re going to hit a plateau, and we’re not going to get any faster*.”

When you start crunching the numbers:

- what if you wore a lighter shoe;
- What if you were three pounds lighter;
- What if you were shorter;
- What if your body type was this or that; and
- of course, what if you were a **better fat burner**

From there Phil considered: What does your MAF test need to be to run under two hours?

- He was working with running starting to hit **five minute pace** for their MAF test
- “*So I thought there’s no indication that they’re reaching a limit, that they’re hitting a plateau in performance, so why couldn’t it keep going*?”

*Does Phil think Kipchoge could get faster?*

- We know much about Kipchoge’s nutrition or what he consumes during his races (if anything)
- Obviously, he was burning a lot of fat, says Phil
- If properly trained, he wouldn’t have needed any added nutrition
- And maybe not even water
- Water is this interesting thing because it has a lot of weight
- If you dehydrate a small amount, the time factor is significant enough where you’re running faster
- There’s this window—Phil says maybe 2% dehydration from a weight standpoint— where you’re not impairing performance but you are getting lighter so you’re going to be able to run faster.

**When is a marathoner’s prime?**

*The longevity (or lack there of) of marathoners*

- Many of the top racers tend to be from places like Kenya and they are doing it to break out of poverty… and they end up burning out — “it’s really sad, but I think that’s what’s happened” says Phil
- He imagines being able to take one of those athletes and optimally train them — “*I think you’d have a two hour marathon broken already in a real race*.”

*When is a marathoner’s prime?*

- Many world class marathoners acknowledge they might only have a dozen marathons in them in their entire career where they’re going to really be able to run at a certain level
- If they were to spread those 12 marathons over 15 years, that’s a different philosophy than the “churn and burn” philosophy
- [Meb Keflezighi](https://en.wikipedia.org/wiki/Meb_Keflezighi) won the Boston Marathon in his late 30s
- Kipchoge is in his mid-30s
- In Phil’s book, he writes about the makeup of a 1:59 marathoner
- Someone who is in their 30s
- Not somebody who could run a great 10K (anymore) but certainly could have been great in their 20s
- But now in their 30s and even early 40s, they will have built a great endurance base — “*now they’ve got the best of everything*”

> “People often say, ‘These are amazing people. They’re outliers.’ I don’t think they’re outliers. I think it’s the norm.” —Phil Maffetone

## How being “overfat” affects health and performance, and ways to decrease excess body fat [1:13:30]

**The term “overfat”**

See Phil’s paper: [Overfat and Underfat: New Terms and Definitions Long Overdue](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5206235/)

- Phil is not fond of the term overweight, and prefers overfat
- It’s adipose tissue we should be concerned with, not mass
- Phil’s published a few papers in 2017 ([here](https://www.frontiersin.org/articles/10.3389/fpubh.2016.00279/full), [here](https://www.frontiersin.org/articles/10.3389/fpubh.2017.00190/full?ncid=txtlnkusaolp00000618), and [here](https://www.frontiersin.org/articles/10.3389/fpubh.2017.00290/full)) on the usage of “overfat” and “underfat”
- Waist circumference and waist to height ratio are suggested as a better indicators of metabolic health than BMI
- Phil and his co-author estimated **the prevalence of overfat to be 91% in US adults** and 69% in US children; Obesity is leveling off, but increases in abdominal fat are not

*How is society’s trend of overfatness affecting health and performance?*

- They’re related in terms of terms of the [diminishing performance of age group athletes](https://overcast.fm/+EpDsfM8Zs/19:16), says Phil
- The overfat condition can typically add weight to the body, so that’s going to affect running performance
- But more significantly, those people with excess body fat have some downstream problems that can be very serious
  - blood fat abnormalities
  - blood sugar abnormalities
  - blood pressure abnormalities
  - And ultimately chronic illness
- In that situation, people are obviously not going to be performing their best

**Other problems with overfat/excess body fat**

*Impairs immune system*

- Get sick more often, says Phil
- He and Paul Laursen wrote a [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7190793/) on this regarding topic regarding COVID-19

*Physical problems*

- People with excess body fat also have physical impairment problems more frequently
- From the basic, simple injury, like plantar fasciitis to move severe pain patterns
- Low back pain on the less serious all the way to the arthritides that are affecting runners

*Why isn’t more emphasis being put on reducing excess body fat?*

- Peter’s take is that people are starting to acknowledge this but it always takes longer to spread through society
  - For example, sugar consumption is actually declining, but it sometimes takes awhile for this decline to necessarily translate into some of the health benefits
- Furthermore, these things are so multifaceted
  - For example, activity levels might be declining even while certain elements of nutrition improve, and so the net effect of that could be a reduction
  - E.g., Quality of sleep could be declining, and that can offset any benefit that we see

**Health vs. performance**

- A lot of people struggle with the idea that health and performance are not necessarily the same thing
- Too often people that are not very healthy believe that the key to getting healthier is to train for a marathon, or an Iron Man
- Peter says as a doctor it can put him in an awkward position: “*On the one hand, I’m so grateful that they have found something to do to be active and to train for, and I don’t want to discourage that, but I also want them to understand that there’s nothing especially healthy about doing an Iron Man*.”

*Phil’s message around that*:

1-Start with walking

- All a deconditioned person needs to do is start by walking around the block
- The fat burning benefits that they’ll get from that simple act are huge

2-Food is more important

3-Reducing stress is also a key factor

**Final message**:  “*Food and exercise are keys. And it’s really, really simple. Just don’t eat junk food, and take it easy out there*.”

§

## Selected Links / Related Material

**Phil’s website**: [philmaffetone.com](https://philmaffetone.com/)

**Phil’s books**: [MAF Books](https://shop.philmaffetone.com/collections/maf-books) | (philmaffetone.com) [00:45]

**Episodes of The Drive discussing zone 2 exercise**: [1:45]

- [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com)
- [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/) | Peter Attia (peterattiamd.com)
- [#145 – AMA #15: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/) | Peter Attia (peterattiamd.com)

**The bike race called across the US called RAAM that Peter mentions**: [Race Across America](https://en.wikipedia.org/wiki/Race_Across_America) | (wikipedia.org) [9:15]

**Peter’s interview with Mike Trevino who competed in RAAM**: [#17 – Mike Trevino: life-lessons from ultra-endurance, mindset, hard work, and removing limitations](https://peterattiamd.com/miketrevino/) | Peter Attia (peterattiamd.com) [9:15]

**Phil’s MAF Test designed to help you identify your MAF HR and track you progress**: [MAF Test](https://philmaffetone.com/maf-test/) | (philmaffetone.com) [17:30]

**The formula (MAF 180 Formula) for determining the proper HR to train at**: [The MAF 180 Formula: Heart-rate monitoring for real aerobic training.](https://philmaffetone.com/180-formula/) | (philmaffetone.com) [28:00]

**Phil’s paper validating this 180 Formula approach**: [The Development and Initial Assessment of a Novel Heart Rate Training Formula](https://www.wemjournal.org/article/S1080-6032(15)00131-3/fulltext) (Høeg et al., 2015) [28:00]

**Phil’s study suggesting that sub max performance predicts maximum performance**: [5km Race Prediction from Submax Performance Tests: A pilot study](https://philmaffetone.com/5km-race-prediction-submax-performance-tests-pilot-study/) | (philmaffetone.com)[42:30]

**Phil’s Two Week Test which he uses for his patients struggling with symptoms of carbohydrate intolerance**: [Carbohydrate Intolerance and the Two-Week Test](https://philmaffetone.com/2-week-test/) | Phil Maffetone (philmaffetone.com) [54:30]

**Phil’s 2018 study that contradicted Peter’s thinking about low-carb diets and their effect on top anaerobic performance**: [Effects of a 4-Week Very Low-Carbohydrate Diet on High-Intensity Interval Training Responses](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5950743/) (Cipryan et al., 2018) [58:45]

- *A separate paper on it showing that the high fat diet did not have any adverse effect on inflammation*: [Effects of a four-week very low-carbohydrate high-fat diet on biomarkers of inflammation: Non-randomised parallel-group study](https://pubmed.ncbi.nlm.nih.gov/32000572/) (Cipryan et al., 2020) [59:30]

**Paul Laursen’s 2015 study showing that high intensity training can still produce large amounts of fat burning (as opposed to burning 100% carbohydrate)**: [Rethinking the role of fat oxidation: substrate utilisation during high-intensity interval training in well-trained and recreationally trained runners](https://bmjopensem.bmj.com/content/1/1/e000047) (Hetlelid et al., 2015) [59:30]

**Studies by Jeff Volek and Stephen Phinney looking at ultra athletes, low carb diets, and fuel partitioning**: [1:01:15]

- [Metabolic characteristics of keto-adapted ultra-endurance runners](https://pubmed.ncbi.nlm.nih.gov/26892521/) (Volek et al., 2016)
- [Rethinking fat as a fuel for endurance exercise](https://pubmed.ncbi.nlm.nih.gov/25275931/) (Volek et al., 2014)

**Phil’s 2014 book predicting someone would break the 2 hour mark in the marathon and how they would do it**: [1:59: The Sub-Two-Hour Marathon Is Within Reach—Here’s How It Will Go Down, and What It Can Teach All Runners about Training and Racing](https://www.amazon.com/gp/product/B00LKCP6AQ/ref=dbs_a_def_rwt_hsch_vapi_tkin_p1_i7) by Phil Maffetone | (amazon.com) [1:04:45]

**Eliud Kipchoge unofficially broke the 2 hour mark on the marathon**: [Breaking2](https://www.nike.com/running/breaking2) | (nike.com) [1:05:00]

**Phil’s paper explaining the term “overfat”**: [Overfat and Underfat: New Terms and Definitions Long Overdue](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5206235/) (Maffetone et al., 2016) [1:13:30]

**Phil’s paper about the danger of COVID-19 for “overfat” people**: [The Perfect Storm: Coronavirus (Covid-19) Pandemic Meets Overfat Pandemic](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7190793/) (Maffetone and Laursen, 2020) [1:15:00]

§

## People Mentioned

- [Stu Mittleman](https://en.wikipedia.org/wiki/Stu_Mittleman) [3:45, 6:45, 35:15]
- [Mike Trevino](https://www.teamtrevino.com/bio) [9:15]
- [Mark Allen](https://en.wikipedia.org/wiki/Mark_Allen_(triathlete)) [14:30]
- [Paula Newby-Fraser](https://en.wikipedia.org/wiki/Paula_Newby-Fraser) [14:30]
- [Kenneth Cooper](https://en.wikipedia.org/wiki/Kenneth_H._Cooper) [16:30]
- [Arthur Lydiard](https://en.wikipedia.org/wiki/Arthur_Lydiard) [36:15]
- [Paul Laursen](https://twitter.com/paulblaursen?lang=en) [59:30, 1:15:00]
- [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) [1:01:15]
- [Euclid Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) [1:05:00]
- [Meb Keflezighi](https://en.wikipedia.org/wiki/Meb_Keflezighi) [1:12:15]

§

![](https://peterattiamd.com/wp-content/uploads/2021/01/bio-photo-maffetone-500x500.png)

##### Phil Maffetone

Phil Maffetone is a coach and health practitioner working in exercise, sports medicine, biofeedback, and nutrition. He’s an author of numerous books covering a number of aspects of exercise, sports medicine, biofeedback, nutrition. He has a bachelor’s degree in human biology and a doctorate in chiropractic, with certifications in physiotherapy, Chinese medicine, and kinesiology. Phil was a private sports practitioner and coach between 1977 and 1997, and now a consultant, writer, independent researcher, and lecturer.