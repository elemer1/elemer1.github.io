# #222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.

**Source:** [https://peterattiamd.com/mattkaeberlein3/](https://peterattiamd.com/mattkaeberlein3/)

---

##### Check out more content with expert, Matt Kaeberlein, Ph.D.:

- *(Aug 20, 2018)* [Rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](/mattkaeberlein/)
- *(Sep 13, 2021)* [The biology of aging, rapamycin, and other interventions that target the aging process](/mattkaeberlein2/)
- *(May 16, 2022)* [AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](/ama35/)

Dr. Matt Kaeberlein is a globally recognized expert on the biology of aging and recurring on *The Drive*. In this episode, Matt explains his research findings on nutrition as it relates to aging and longevity, including the results from his recent review article in Science. From there, he and Peter dive deep into the literature on calorie restriction (CR), explaining the nuance, benefits for lifespan and healthspan, and potential downsides of CR. He discusses the epigenetic changes that occur with age and potential benefits and downsides of epigenetic reprogramming, often viewed as a panacea for reversing aging. Matt also explains the impact of dietary protein on aging, including the interesting dichotomy around how protein, a critical macronutrient, and rapamycin, a geroprotective molecule, have opposite effects on mTOR. Additionally, he talks about low-protein vs. high-protein diets and their effects on muscle mass and mortality, as well as the impact of IGF-1 signaling and growth hormone on lifespan.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/mattkaeberlein3/the_Drive_public.png)

Play

#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D

1x15s30s

0:002:27:23

## We discuss:

- Challenges with understanding the effects of nutrition and studying interventions for aging [3:30];
- How Peter’s and Matt’s convictions on nutrition and thoughts optimal health have evolved [8:15];
- Calorie restriction for improving lifespan in animal models [16:15];
- Utility of epigenetic clocks and possibility of epigenetic reprogramming [22:00];
- Mutations and changes to the epigenome with aging [31:45];
- Epigenetic reprogramming: potential benefits and downsides and whether it can work in every organ/tissue [35:15];
- First potential applications of anti-aging therapies and tips for aging well [43:00];
- Impact of calorie restriction on the immune system, muscle mass, and strength [47:00];
- Insights from famous calorie restriction studies in rhesus macaques [55:00];
- An evolutionary perspective of the human diet [1:03:45];
- Anti-aging diets: Separating fact from fiction—Matt’s 2021 review in Science [1:12:30];
- Mouse models of time-restricted feeding in the context of calorie restriction [1:19:30];
- Nutritional interventions that consistently impact lifespan in mice, and concerns around efficacy in humans [1:27:00];
- Differing impact of calorie restriction when started later in life [1:31:00];
- Lifespan extension with rapamycin in older mice [1:37:15];
- Relationship between protein intake and aging, and mouse studies showing protein restriction can extend lifespan [1:43:30];
- Impact of protein intake on mTOR, and why inhibition of mTOR doesn’t cause muscle loss [1:50:45];
- Low-protein vs. high-protein diets and their effects on muscle mass, mortality, and more [1:55:30];
- The impact of IGF-1 signaling and growth hormone on lifespan [2:06:30];
- Parting thoughts on the contribution of nutrition to healthspan and lifespan [2:19:45];
- More.

§

## Show Notes

**\*Notes from intro:**

- Matt Kaeberlein is a returning guest, he’s been on the podcast a number of times, most recently on [AMA 35 in May of 2022](https://peterattiamd.com/ama35/)
- Matt is not only one of our most recurring guests, but he’s also one of the people Peter will consistently share emails with discussing various topics
- In this episode, we really focus the conversation around nutrition as it relates to aging and longevity
- This really came out of a paper that Matt wrote as a [review article](https://www.science.org/doi/10.1126/science.abe7365) about a year ago, which Peter remembered reading in draft, really appreciating it and loved reading the final version of it
- Even though nutrition science is not the topic Peter is most interested in talking about (given things he’s mentioned in the past‒ diets and fads and the religion around that stuff), we tried to really make this as biochemical a discussion as possible
- We discuss Matt’s recent [review article](https://www.science.org/doi/10.1126/science.abe7365) and we talk pretty deeply about the literature on caloric restriction
- We talk about epigenetic clocks, aging and its effect on DNA and cell reprogramming
- We then focus around protein and aging
  - This is the one macronutrient that stands out
  - Carbohydrates and fats are really there for energy use, protein is not
- Peter Attia: ([02:13](https://www.rev.com/transcript-editor/Edit?token=C5SFIGPL6ziSGpkW6SlgthhW0gXk25WIVQXb-ZzwudBSBcQEydyj-DzLaXXGvJ9FI8YQHmqb6pNJ9m0Tt9oooLU6Crw&loadFrom=PastedDeeplink&ts=133.77))
- We then get into this seeming dichotomy around protein and mTOR
  - You’ve heard Peter talk a lot about mTOR
  - We understand that a drug that inhibits mTOR, namely rapamycin, seems to produce a whole bunch of wonderful effects and yet protein, particularly an amino acid called leucine, seem to really trigger mTOR
  - How can those two things simultaneously be true if having muscle is good, but taking rapamycin is probably good?
- We get into the importance of muscle mass, the RDA on protein itself, IGF, growth hormone, and a lot more
- Peter points out, “*This is a topic for which we just don’t have easy answers and it’s possible you’re going to walk away from this entire conversation with more questions than answers. My goal is that you come away from this realizing that there’s quite a bit of uncertainty here, but I have a better way that I can think about it and I have a better sense of what questions to ask.*”
- For those of you who may not remember who Matt is, or maybe even didn’t listen to any of our previous podcasts, here’s a really brief reminder
  - Matt is a globally recognized leader in a basic biology of aging
  - He’s a professor of Laboratory Medicine and Pathology and an adjunct professor of Genomic Sciences and an adjunct professor of Oral Health Sciences at the University of Washington in Seattle
  - His research interests are focused on the basic mechanisms of aging in order to facilitate translational interventions that promote healthspan and a healthy way of life

## Challenges with understanding the effects of nutrition and studying interventions for aging [3:30]

- Peter remarks, “*I don’t think a week goes by that we aren’t exchanging an email about some aspect of the relationship or the interspace between nutrition and longevity*.”

Questions‒

- Does that speak to our ignorance?
- Does that speak to the ubiquity of such content?
- What does that say about us?”
- Matt’s take, “*Having been in the aging field for a long time, I certainly recognize how complicated that biology is. And I think the biology of nutrition is equally complicated. And when you get at the interface of those two it’s really hard, I think, sometimes to draw definitive conclusions*.”
- He also thinks this will be a little bit of a theme‒ there are many things we don’t understand yet about optimal nutrition and how that intersects with optimal health span
- Peter and Matt have spent a lot of time on the podcast speaking about molecules that may protect against aging: rapamycin, and more recently‒ NMN, NAD, and Metformin
  - [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/)
  - [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/)
  - [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/)
- It’s almost easier to ask these questions from the standpoint of geroprotective molecules because the intervention is much cleaner
- Just yesterday, Peter, Matt and [David Sabatini](https://www.davidmsabatini.com/research) had a back and forth about rapamycin‒ timing of the dose, frequency within the dosing schedule, the dose itself
  - Even with a drug this can be complicated
- The benefits of a drug are still trying to be pieced together, imagine putting this together for the topic of food/ nutrition
- Matt adds, “*The big piece that gets lost with the animal models on top of all that complexity is the environment*”
  - In animal studies, the mice are kept in a well controlled environment, relatively pathogen free, and they live in that same environment their entire life
  - Compare that to the human experience where our environment is extremely complicated, and it changes throughout life
- Also, the epidemiological studies on optimal nutrition are from 20, 30, 40 years ago
- The average human environment is very different today than it was when those studies were done
  - How does that potentially change the interaction between nutrition and health outcomes?

**Difficulties of studying interventions for aging**

- People age very slowly
- People in their 70s today were in their 30s 30 years ago, and that environment was different than today’s environment

> “*I think the key is to recognize that limitation and be potentially even more careful about assuming causation from correlation over many decades*”‒ Matt Kaeberlein

## How Peter’s and Matt’s convictions on nutrition and thoughts optimal health have evolved [8:15]

**How Peter’s convictions on nutrition have changed over the past decade:**

- His convictions have become looser as time goes on
- He views fewer and fewer things with certainty
- Clinically, Peter views nutrition from a very simple 2×2 framework

![](https://peterattiamd.com/wp-content/uploads/2022/09/f1-mattk.png)

**Figure 1.  2×2 clinical framework for viewing nutrition.**

- People are not distributed equally in these buckets
- There are not many people who are adequately muscled and undernourished

- You can’t sort someone into a bucket by looking at them
  - You need to do some functional testing and look at their biomarkers
  - This might include a [DEXA scan](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)
- It’s important to sort people into a bucket to answer the questions‒
  - Do you need an energy deficit?
  - Do you need an energy surplus?
  - What’s your protein intake need to be to achieve that in combination with your calorie needs?
- By far, the hardest to treat is the “over nutritioned, under muscled”
  - Unfortunately that’s a very common phenotype
- Matt agrees with this approach and adds, “*There’s no one size fits all… and it’s is an ongoing learning process*”
  - It’s really important that we be willing to change our beliefs about nutrition and other aspects of health as more data comes in

**Problems with the changing advice of nutritionists**

- Matt remembers when he was in his early 20s, he read a diet guru book that promoted the theme of eating anything you want as long as you cut out the fat
  - That you could have this really high, simple carbohydrate diet just as long as you kept the fat low, you’d be fine
  - Now we know that’s exactly wrong
- How do we know that 10 years from now we’re not going to look back at what the diet gurus are saying today and be like, “*That just makes no sense.*”?

**Finding optimal health, actionable steps, in face of confusing science [12:15]**

- Matt says: It’s not that nutrition science across the board is low quality, it’s just a really hard problem
  - There are really good scientists doing really good work in this area

***To some extent, the biology of aging and the biology of nutrition share that‒ these are extremely complicated biological systems we’re trying to understand in the context of this changing environment over time***

- It’s important to recognize what the limitations are and not draw really strong conclusions such as‒ everybody should eat a low protein diet

> “*That’s a mistake to recommend across the board nutritional strategies for everyone*”‒ Matt Kaeberlein

**Matt’s perspective on optimum health**

- If you can be somewhere close to optimal nutritional intake (just say total calories and body composition is somewhere close to where it should be), that’s a big chunk of what you need to give yourself the best chance of being healthy going forward
- You don’t have to optimize every single thing
- Starting from that big picture perspective allows you to get most people most of the way there
- And then when they’re most of the way there you can focus on how do we get that last 10, 20, 30%, whatever it is
- Peter agrees and adds, “*There are most things in his life where he doesn’t like the 80/20 principle… but for nutrition get 80% right, complete optimization is not worth it*”
  - His good friend, [Tim Ferriss](https://tim.blog/about/) is the king of this‒  “How can I get 80% of the learning with 20% of the time?” and Peter has never seen anybody who can do it like Tim
    - Time can learn a language in a month
    - Peter is the opposite, he’s the guy who loves the tail, he loves the asymptote, he love the perfection of something
    - But for nutrition, he is the opposite
- “*It’s instead better to put your energy into exercise*” says Peter
  - “*You have far more of an ROI on the exercise front than eeking out incremental value on the nutrition front*”
  - Peter and previous guest [Layne Norton](https://biolayne.com/about/) have had riffs on this back and forth
  - Peter notes there is a vocal group of people on Twitter who will waste endless hours debating the finer points of their dietary pet peeves but can’t do 10 pull-ups
- Nutrition matters, but as [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) once said, “*It’s amazing how little we know about this subject matter*”
  - And for most of our existence we were worried about the too little problem
  - The too much problem has become a relatively recent phenomenon
  - And they’re bad in different ways, acutely, chronically, they have different limitations

## Calorie restriction for improving lifespan in animal models [16:15]

**Early studies in model organisms**

- From the animal literature, caloric restriction seems to reproducibly improve lifespan
- The first experiments were published in the early-mid 1930s (so they probably started in the 1920s)
  - People have been looking at this for 100 years
  - Early studies were all in rats
  - Studies were designed from a developmental perspective, concerned with malnutrition
- Findings of early studies of restricting calories during early life/ development of rats show‒
  - Smaller body size
  - Lifespan increases by 40-50%! (living their whole lives in the laboratory)
  - Rats also seem to be healthier as they live longer

> “*So this concept of health span and the period of life that is spent in good health free from disease and disability, it seemed as if caloric restriction was not only increasing lifespan but also extending health span*”‒ Matt Kaeberlein

- These results led to studies of caloric restriction in both rodents (rats,  mice) and simpler organisms (invertebrates)‒ fruit flies, *C. elegans*, and yeast
- The common theme in these results is restriction of nutrients can increase lifespan and apparently healthspan too
  - There is a lot of nuance there we can dive into and unpack but this is the general take home message
  - This was found over and over again, across a great evolutionary distance
  - Caloric restriction seems to slow aging

**What causes natural death in old laboratory mice?**

- Every old mice will have cancer at their time of death
  - An estimated 75-80% of lab mice would die of cancer
- Most are euthanized before they reach this endpoint
- They are not dying from atherosclerosis (the leading cause of death for humans)
  - Their arteries are not littered with plaques the way ours are
  - These are inbred mouse strains
  - Mice do develop functional declines in every tissue and organ as they age (much like people do)
- A legitimate criticism of the interpretation of the caloric restriction literature‒ what this is really doing is preventing cancer?
  - This may account for the lifespan effect
- But caloric restriction also seems to delay or outright prevent declines in tissue and organ function

## Utility of epigenetic clocks and possibility of epigenetic reprogramming [22:00]

**Functional measures of aging and the utility of “clocks”**

- People in the field are really enamored with aging clocks, [epigenetic clocks](https://en.wikipedia.org/wiki/Epigenetic_clock), and biochemical markers
- Matt thinks these are useful, but more so would be showing that the heart is still functioning like a young heart
  - Or the immune system in an elderly individual is still functioning like it does in a young individual
- There are lots of type of clocks
- When most people use this term today, they mean an epigenetic clock
  - This relies on changes in epigenetic marks, changes in the genome that occur with age
  - In every organism where it has been studied, characteristic changes are seen in the epigenome with age
  - This can provide a good **chronological** measure of aging
  - These clocks might have value in forensics‒ analyze the DNA evidence to see how old the perpetrator is
  - In the [dog aging project](https://dogagingproject.org/about-project/), this could be used to determine the age of a rescue dog
- Matt is not convinced that epigenetic clocks (and other types of clocks) are actually measuring biological aging
  - This is hard to prove
  - This field is in flux
  - The proof is being able to show at an individual level (mouse/person/dog) that you can predict their biological age at some point in their life and with some precision, predict what’s going to happen in the future
- We really want to know for the **individual**‒
  - What are their future health outcomes
  - How long are they going to live
- Longitudinal studies in people have taken samples 10, 20, 30 years ago and measured epigenetic profiles then ask, “*How well does that correlate with mortality outcomes in the future?*”
  - They work to some extent
  - People debate how well they work and if they are better than other markers for predicting mortality

> “*I’m a skeptic by nature and I want to actually see the proof*”‒ Matt Kaeberlein

- **A word of caution**‒ some people in the field talk about changing the epigenome as if it will change everything about aging, but there is no data to support that
- What we know know about the biology of aging is that epigenetic changes are 1 of 8-10 molecular processes that seem to contribute to aging (that the field has reached consensus on)
  - So epigenetic changes is only 1 of those processes
  - Is there a hierarchy?
  - It’s possible that it could drive a lot of the other changes but we don’t have data to support this

> “*So this idea that reversing the epigenome is reversing aging is at best an exaggeration, at worst an outright lie. I mean, it’s just not true.*”‒ Matt Kaeberlein

**How could you test the role of epigenetic changes in aging in mice?**

- Matt thinks we’re conceptually close
- There are these 4 factors called the “[Yamanaka factors](https://www.cell.com/cell/fulltext/S0092-8674(06)00976-7)” that can reprogram the epigenome
  - If you take cells in culture, in a laboratory and you passage them many, many times you can see changes in the epigenome, just like you might see changes in the epigenome in an animal, in tissues
  - You can put these reprogramming factors into the cells and turn them on and they basically wipe clean the epigenetic changes that have happened over time
  - They can restore those cells back to a [pluripotent](https://en.wikipedia.org/wiki/Cell_potency#Pluripotency) state that can differentiate into any cell type
- More recently, people are trying to express these reprogramming factors in an animal
- The [most compelling work](https://www.cell.com/cell/fulltext/S0092-8674(16)31664-6) is in a premature aging model of mouse (the progeroid model)
  - These mice are very short lived (maybe 25% of the normal mouse lifespan), very sick
  - These reprogramming factors can extend the lifespan dramatically, maybe 50%
  - These are impressive changes that are consistent with the idea that you fixed or made something better
- The NEXT experiment would be to express these reprogramming factors in an old mouse and make it young again
- Another [experiment shows](https://onlinelibrary.wiley.com/doi/10.1111/acel.13578) improvement in 1-3 tissues
- Matt is most impressed with work from [David Sinclair’s lab](https://sinclair.hms.harvard.edu/research), where they use this optic degeneration model
  - They [showed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7752134/) they could reverse degeneration of the eye with these factors
  - They tried to do the same thing in an old mouse but the data was mixed
  - To some extent they could regenerate the optic nerve in an old mouse

> “*That’s certainly impressive, exciting, but nobody has ever taken an old mouse and turned it into a young mouse*”‒ Matt Kaeberlein

- Matt is convinced it could be useful therapeutically
- He would really be excited if somebody could do as good as rapamycin in a mouse

**Can reprogramming match the benefits of rapamycin?**

- 1 – Rapamycin can extend lifespan by at least 25%
  - But the dose has not been optimized
- 2 – Rapamycin can reverse functional declines in many tissues
- This hasn’t been done by reprogramming with these factors yet
- Matt remarks, “*Show me you can take a two and a half year old mouse, make it look like a one year old mouse and then it lives to be five years old, I’ll be really excited… But I think the enthusiasm has just gotten so far ahead of where the science is*.”

**How does epigenetics relate to DNA?**

- The DNA is where all the information is, but then that DNA has to get turned into RNA, that’s called transcription or [gene expression](https://en.wikipedia.org/wiki/Gene_expression)
- And then that RNA has to get turned into protein and in general it’s the protein that does the work.
- So what these **epigenetic changes**, the **methyl groups** that sit directly on cysteine residues in the DNA do primarily, is **affect expression of the genes**

***So basically what you’re seeing with aging, we think, is a shift in the epigenome that leads to certain genes being expressed that shouldn’t be and certain genes not being expressed that should be***

- Matt thinks there’s a little bit of a debate about which is more important right now but it probably doesn’t really matter, right?
- The idea is you’re getting things turned on and turned off inappropriately as we get older
- So there’s a loss of regulation, which probably contributes to a loss of homeostasis

## Mutations and changes to the epigenome with aging [31:45]

**Homeostasis is a useful way to think about aging**

- If you’re healthy, your body is generally in homeostasis
- As we get older, it becomes harder and harder for our body to maintain homeostasis
- When you get out of homeostasis, if your defense mechanisms are working right, you can get back in
  - If you get COVID for example, your immune system works, you’re out of a homeostasis but you come back in and then you’re okay again.
- As we get older it gets harder to come back into homeostasis and that’s why we start to see pathology and mortality

**Why does our ability to heal decline with age?**

- Peter compares how long it takes a cut to heal for his 5 year old son and himself
  - 2 weeks ago his son was on a scooter, going down the steepest hill in the world
  - He face planted, and when he came up all Peter could think is, “*How quickly can we get to the hospital?*”
  - It was a bloodbath, but 6 days later there was 1 tiny scar, 9 days later you would have no idea he ripped his face on the pavement
  - Peter (age 50) gets a cut, and it takes 9 months until the scar is gone

**Peter’s takeaway**‒ “*There’s a very clear distinction between a five year old’s DNA and a 50 year old’s DNA in terms of how he can literally make new proteins that are better than my proteins*”

**What is the difference in their DNA?**

- We know **mutations** accumulate as we age
  - Honestly that’s what drives a lot of cancer
  - We have know this for a long time
- The [epigenetic changes](https://en.wikipedia.org/wiki/Epigenetics) are on top of this
- Peter wonders how much that factors into the example he just gave
  - Mat is sure it does to some extent
- Peter asks, “*What else explains why his collagen’s so much better than mine?*”
- Matt thinks there are probably many reasons
- **Inflammation** is a huge driver of our loss of ability to recover as we get older
- All sorts of things go wrong if you have a high level of sterile inflammation in your body, including **the ability of stem cells to function**
- A lot of injuries require stem cells to function, to build back what’s been broken
- Peter asks, “*Could it be that I have more senescent cells and more senescent cell factors that are impairing the ability of cells to heal?*”
- Just to throw a wrench in that, there’s actually a body of thought that senescent cells actually promote wound healing
  - Again, this is where the biology’s so complicated
- Matt thinks the crux of the question they started from is ***if you only fix the epigenome, do you fix everything?***
- The fair answer is‒  nobody knows
- He would be shocked if epigenetic changes drive all of aging, but it’s possible

> “*I think we have to be open to that idea that epigenetic changes sit on top of, or upstream of the other hallmarks of aging.*”‒ Matt Kaeberlein

- You will not fix mutations by fixing the epigenome

***The question is, do mutations happen with enough frequency to be a major contributor to functional declines that go along with aging***

- Mutations certainly contribute to cancer

## Epigenetic reprogramming: potential benefits and downsides and whether it can work in every organ/tissue [35:15]

**What is it about reprogramming that we think is going to fix an aging neuron or an aging cardiac myocyte?**

- Some tissues are rapidly turned over (gut  epithelium, fingernails, hair), but others do not (neurons, cardiac myocytes)
- Heart failure is also a big problem
- This is an area where the biology of what’s really happening is poorly understood
- The real answer is, “*We don’t completely kno*w”
- A simplistic answer is, people are trying partial reprogramming
  - They are not reprogramming back to a pluripotent state, that would be dangerous
  - In a single celled organism, it’s no problem to go back to the pluripotent state and start over
  - In a complicated animal, if we reprogram you back to the pluripotent state, it’s not going to end well

***The idea is to go back far enough that you restore the epigenome to its pristine state, young state, and then hope that when you do that, you restore gene expression to where it’s supposed to be***

**Potential benefits of epigenetic reprogramming**

- Maybe one way to think about it is you restore the homeostatic mechanisms to a more youthful state where then the homeostatic mechanisms that all of our cells have can basically clean up the rest of the mess
- We know as we get older, for example, we all accumulate **damaged mitochondria**
  - Changing the epigenome (which is the nuclear genome) isn’t going to fix anything that’s wrong with your mitochondria directly
  - But maybe by fixing the epigenome, you restore the homeostatic mechanisms that then maintain mitochondria in a healthy state and you can fix the damage to the mitochondria
- The evidence is suggestive that if you do it just right, you can improve function in at least some aged tissues/ organs by partial reprogramming
  - Matt has yet to see anything that convinces him, that anybody has made an old heart into a young heart in an old animal with partial reprogramming in the heart
  - But you can improve function
- The same thing’s true with rapamycin‒ short term treatment with rapamycin in mice makes an old heart function more like a young heart
  - He would never argue that we have taken that old heart and made it young
    - We don’t know that, and that’s hard to prove
    - You can see some evidence that it should be possible with partial reprogramming to do that

The question is: ***Will epigenetic reprogramming work in every tissue/organ?***

- We don’t really know
- Maybe we will see really large effects on lifespan and healthspan in mice
- How do you do that in the brain?
  - Because so much of who we are and what we are comes from our experiences and our memories
  - How do you ensure that you can reprogram somebody’s brain in a way that isn’t going to change that?

> “*My big concern is that we don’t mislead people into thinking that we’re close to reversing aging*”‒ Matt Kaeberlein

- Thinking that we are close to reversing aging is a problem from the perspective of the general public
- It’s also a problem from the perspective of the scientific community
  - Some scientists look at this and think, “*This is snake oil.  This is just not true.*”
- Peter’s concern is people think this will be available in 10 years and use this to do whatever they want because they can be reprogrammed later… that’s very risky
  - Peter’s answer to this is, “*Guys, you can do both. You can believe that in 10 years, we’re going to fix this problem, but you could still actually care about your health.*”
- Matt notes, “*I think you can just look back over the last 20, 30 years and look at predictions people made on how fast these things were going to come along and get into the clinic. And none of that has happened. So I totally agree with you.*”
- He also takes a view of strong skepticism when people say “This is going to happen in 10, 15 years.”
- His advice is, “*Don’t expect major changes in treatments to improve lifespan and healthspan in the next 20 years*”
- This doesn’t mean he’s not optimistic
  - He thinks there are opportunities there
  - It wouldn’t sur0ise him to see some of these things make it to the clinic, but he doesn’t expect it
  - There are so many barriers that we don’t yet appreciate… barriers in moving things through clinical trials

**Potential downsides to epigenetic reprogramming**

- We don’t know the potential side effects
- What happens if you reprogram too far?
- We know that certain types of cancers are a side effect of this partial reprogramming in mice
  - This doesn’t mean it can’t be worked out
- There are reasons to be concerned that this is going to be hard to implement therapeutically
- The FDA is going to be extremely skeptical of this kind of approach
  - People are going to need to show with really rock solid, compelling data that reprogramming strategies are not going to cause significant side effects
  - This may be a long road to get reprogramming strategies into the clinic
- Maybe somebody will identify a small molecule that can do some of this
  - That may be an easier path to the clinic… the best case scenario

## First potential applications of anti-aging therapies and tips for aging well [43:00]

**Peter wonders if the first wins are going to be what** [**David Sinclair**](https://sinclair.hms.harvard.edu/people/david-sinclair) **has done, a very niche application**

- An amazing application would be to target osteoarthritis
- If you could figure out a way to regenerate human cartilage without joint replacements, those are huge wins that seem a little more feasible
- Peter thinks this stuff will take 4x as long and cost 4x as much as we think

> “*Before it gets out to where it hits the mainstream, from a clinical perspective, it’s a really long path*”‒ Matt Kaeberlein

- A niche application is exactly the strategy people have tried to take with [senolytics](https://en.wikipedia.org/wiki/Senolytic)
  - These are molecules that will clear [senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence)
  - That path has been hard too
  - [Unity](https://unitybiotechnology.com/about-us/) is the largest company in this space and their first clinical trial for osteoarthritis failed
    - Now they’re looking at the eye, because it’s a nice indication
    - For some of eye diseases, there isn’t any solution, and you can, in principle target it quite precisely to the eye

**Advice for aging well**

- Peter would describe epigenetic reprogramming to people like buying a lottery ticket
  - And so if your entire financial planning system is based on winning the lottery, the odds that you’re going to win are pretty low
  - Instead if you’re going to play the lottery, play it in the context of an otherwise great saving and investing strategy

***Matt adds that you don’t have to do EVERYTHING right, get 80% of the way there***

- Nutritionally this is very challenging for some people, but most can do that
- Exercise, you don’t have to optimize your physical activity, but do something
- Peter thinks you get the most benefit from exercise
  - [Exercise](https://peterattiamd.com/category/exercise/) has been covered a lot in previous podcasts
  - 50% of the benefit of exercise is captured from going from nothing to about 15 MET hours per week
    - 15 [METs](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task) times 1 hour would be 1 way to get there
    - But in reality, no one who’s that unfit is going to do 15 METs
    - They could do 3 hours a week of 5 METs
    - 5 METs is a very, very brisk walk or a slow jog, something to that effect
    - By extension, Peter does about 100 MET hours per week of exercise

***The point is that you can get (depending on the study) 30-50% of the benefit (of exercise by) going from being completely sedentary to 15 MET hours per week.  This is pretty amazing***.

- Matt adds, “*Which is a big benefit. And again, it’s remarkable that that information isn’t out there and most people in the general public don’t know that… The magnitude of the benefit compared to the effort that you put in, I think most people just don’t know that.  And it’s unfortunate*.”

## Impact of calorie restriction on the immune system, muscle mass, and strength [47:00]

**What do we know about the effect of caloric restriction (CR) on the immune system of laboratory animals?**

- It’s complicated and there are several confounding factors
- 1 – Laboratory animals are kept in what’s called a specific pathogen free environment
  - That doesn’t mean there’s no pathogens
  - But it’s a relatively low pathogen environment where they are not obligated to really use their immune systems against all the challenges that we would face in the real world
- One question has come up‒ are animals that are on caloric restriction **immune compromised**?
  - The data is mixed
  - Some studies on pathogen challenges on CR animals show they respond better than age-matched *ad libitum* fed control animals
  - *Ad libitum* just means these animals get to eat as much as they want
  - [Sepsis](https://en.wikipedia.org/wiki/Sepsis) experiments show that CR animals die much more quickly than controls
- 2 – This gets complicated by the question of optimal nutrition with CR
  - Some studies use **CRON** (caloric restriction with optimal nutrition)
  - Or **CRAN** (caloric restriction with adequate nutrition)
  - This can be controlled in mouse studies, we can make sure they get all the micronutrients and vitamins that they need when they’re on this CR diet
  - That all goes out the window when you move into the real world and people start practicing caloric restriction
  - Matt comments, “*If I wanted to do caloric restriction off the top of my head, I wouldn’t even know what to do to make sure that I’m getting optimal nutrition.*”

***In the state of CR without optimal nutrition, that’s where you really worry about side effects, particularly immune deficits***

- It doesn’t matter if you’re aging more slowly if you get influenza and die
- Matt becomes really worried when we start talking about recommending these nutritional strategies to the general public, based solely on mouse studies
- 3 – Humans live in greater environmental complexity than laboratory mice
- 4 – Humans have greater genetic complexity/ diversity than laboratory  mice

> “*There’s all sorts of things that are just different about laboratory animals compared to people living in the real world*”‒ Matt Kaeberlein

**How does frailty (sarcopenia) change in an animal in a CR environment?**

- Most functional measures of aging seem to be preserved in calorically restricted animals
  - This includes measures of frailty and sarcopenia
- The same is true with [rapamycin](https://en.wikipedia.org/wiki/Sirolimus)
  - This surprised a lot of people when these studies were done
  - Because [mTOR](https://en.wikipedia.org/wiki/MTOR) plays such a big role in muscle synthesis, the thought was that if you inhibit mTOR with rapamycin or CR, you would see accelerated sarcopenia
    - This was not observed in laboratory animals
- The important complication here is that all of the caloric restriction studies Matt’s aware of‒ when they look at muscle function, they normalize to body weight
  - An calorically restricted mice weigh 30-35% less than *ad libitum* fed mice
- Peter notes that grip strength is normalized to weight
- In calorically restricted mice, they have maintained muscle function proportionate to their body weight
- Apply this to a hypothetical person‒
  - You’ve got a 60 year old person who needs to lose 30% of their body weight, but of course you want to maintain their muscle mass, their muscle function
  - Would you view it as a good thing or a bad thing if they lost 30% of their body weight AND 30% of their strength?
    - Peter doesn’t think this would be good
    - If they needed to lose 30% of their body weight, presumably their body composition isn’t great to begin with
    - They may be better than when they started
    - Optimal might be to lose 30% of body weight but disproportionately lose adipose tissue
    - This might mean losing 10% of strength (or none), depending on the change in lean body mass
- Matt explains this is a complication of CR studies, it’s difficult to figure **what normalization they did** to look at metabolic rate, or muscle mass, or lean mass, or fat mass, or muscle function
  - Usually these studies will be normalized to body weight
- This problem comes up in some of the intermittent fasting studies
  - The question is are they isocaloric, or are they calorically restricted when they’re put on intermittent fasting?
  - And people will claim they’re isocaloric, but the mice lose weight
  - But what they really are is  isocaloric WHEN normalized body weight
    - So they’re really calorically restricted
  - But to understand this, you have to dig to get how the normalizations were done

**Once you achieve an optimal weight, is additional CR beneficial for longevity?** **[52:50] new section?**

- That makes the assumption we know what optimal weight is
- Matt thinks that’s the crux of the question, “*We’re asking, does CR impact longevity positively?*”
- We know if you go on CR you’re going to lose weight
- So if the answer to that is yes, then by definition, optimal weight is lower than what we think. Right?
- Matt thinks about this from the perspective, “*What are the downsides potentially to caloric restriction? And if we don’t know that caloric restriction has big benefits in terms of healthspan and perhaps lifespan, what are the downsides? And do those downsides outweigh the uncertainty we have about whether caloric restriction is beneficial?*”
  - People in the field have not paid attention to this
- We all expect if you do a clinical trial of a drug, you’re going to report **adverse events**, and you’re going to look at side effects
- Very rarely do people think about that before they write a book recommending that people should do diet X
- Even in some of the nutritional clinical trials, they don’t really carefully monitor adverse events

***It’s a bias in the way we think about interventions, where we feel nutritional interventions are, by their very nature, safe and certainly for extreme nutritional interventions, that’s clearly not true. So I think we should be thinking about what are the risks associated with significant caloric restriction in people as a therapeutic strategy.***

## Insights from famous calorie restriction studies in rhesus macaques [55:00]

- Peter has read the caloric restriction study at the University of Wisconsin and the NIA ([National Institute on Aging](https://www.nia.nih.gov/)) 1000 times
  - This is the experiment to end all experiments with regards to CR
- This was a huge NIH funded effort that ran for a couple decades, given the lifespan of rhesus monkeys
- There are 2 groups of animals
  - 1 – At the University of Wisconsin
  - 2 – At Bethesda, Maryland at the NIA
- The **Wisconsin animals** (both controls and CR) were fed a very processed diet
  - At least after the fact, the investigators there suggested they wanted to more mimic a standard American diet
  - The amount of sugar, pure sucrose, in their diet was 28.5% of total calories
  - The CR animals were fed 30% less than what the control animals were fed
  - In that experiment, they found a benefit to caloric restriction‒
    - The CR animals outlived the control animals and had fewer age-related diseases
  - The [original paper in 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) showed a compelling effect on lifespan
    - But this might have been due to reduced rates of cancer
  - CR animals had fewer age-related diseases
    - The dietary composition and caloric restriction had a beneficial impact on the aging process
- The experiment in **Bethesda** may have not been deliberately different but the DIET was different
  - These animals were actually fed the closest diet that could mimic their real diet
  - It didn’t have any sugar in it, only about 3% sucrose
  - It was almost a vegetarian, pescatarian diet
  - Fish was the dominant source of protein
  - It was a high quality diet relative to the Wisconsin animals
- The complicating factor in Bethesda was the animals didn’t come in at all the same age as they were in the Wisconsin study
- The net result of the Bethesda study was there was no difference
  - The CR animals did not live longer
- So while the [Wisconsin study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) published in 2009 said, “*CR works*” the [NIA study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3832985/) published in 2012 sais, “*CR doesn’t work*”

**How do you reconcile the opposite findings of the Wisconsin study and NIA/ Bethesda study?**

- The NIA study at Bethesda did show some improvements in health span metrics, so CR did not extend lifespan but appeared to have some beneficial effect on healthspan
- Since the NIA study came out, they had a [reconciliation paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/) to try and figure out why they got different results
  - Their conclusion is that a lot of it comes down to the difference in diets
  - If you look at the actual body weights of the animals and how much food they ate (not just the composition), you could make an argument that the Bethesda control monkeys were somewhat slightly calorically restricted
- The Bethesda study was a little less controlled for age of onset of CR, some of them were older when they started CR
- There were some genetic differences in the animals used in Bethesda too

> “*There’s a combination of factors that make it a little bit difficult to conclude that it all is about the diet*”‒ Matt Kaeberlein

- It’s interesting because we see this a lot of times in basic science studies, where different labs get different results in what seems to be the same exact experiment
  - When you start to dig into it, there’s all these differences in the way it was done
  - It’s really hard to know which of those differences contributed to the different outcomes
- In this particular case, because it was a 30, 40 year experiment, we’re never going to find out
  - The study won’t be repeated because of how long it takes
  - And also the view on primate research has changed
- Matt’s gut feeling is that the *Wisconsin study probably is closer to a typical American situation*

**Consider the typical American diet**

- For someone who is moderately obese and are eating terrible, Matt asks, “*Is it caloric restriction or is it just returning to what you would call an optimal body weight, optimal body mass?*”
  - We don’t know the answer

**How do molecular signatures of aging change with caloric restriction?**

- [Roz Anderson](https://andersonlab.medicine.wisc.edu/anderson-rozalyn/) (who’s still at Wisconsin) has been a leader in the [study of molecular signatures](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4382298/) of caloric restriction in the monkeys and asked, “Does it look similar to the molecular signatures of caloric restriction in rodents?”
  - A lot of the questions that people have around caloric restriction studies in mice are, “*Will it work the same way in people?*”
- A lot of what we see in terms of changes in **mTOR signaling** and **mitochondrial function** and other **metabolic pathways** is in fact shared between mice and monkeys
  - That is one important outcome from these studies that we can definitely say is rock solid
- Matt tends to believe that the dramatic declines in age-related disease seen in the Wisconsin studies are telling us something
  - But is this telling us that NOT being obese reduces the risk for a lot of diseases?
    - We already know that from the human literature

**How much of the effect is from CR versus DR (dietary restriction)?**

- The Wisconsin experiment suggests that if you have an awful diet, reducing the amount of awful food you eat is a good thing
- The NIA experiment doesn’t tell us the contrapositive
  - It doesn’t suggest that if you have a good diet, eating less will help you live longer
- We don’t know if the Wisconsin animals lived longer simply because (1) they lost weight or (2) they lost weight AND they were eating less processed food
- Additionally, the NIA monkeys were eating a superior diet to the Wisconsin monkeys, but they also ate less in total than the Wisconsin monkeys
- So if you ate more of a good diet, would that be detrimental?
  - We don’t know
- If they had been body weight matched or caloric consumption matched, that would’ve been an interesting comparison to be able to see if there differences

## An evolutionary perspective of the human diet [1:03:45]

- Peter recently read [Herman Pontzer’s](https://globalhealth.duke.edu/people/pontzer-herman) book, [*Burn*](https://www.amazon.com/Burn-Research-Really-Calories-Healthy/dp/0525541527/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1657890212&sr=1-2)
  - It discusses the ecology and evolution of humans as a species and how we are different from our closest evolutionary cousins
  - We have an incredible capacity to store excess energy
  - He measures metabolic rates using experiments with [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) and compares: modern humans, current hunter-gatherers, and primates
  - Our energy needs are far greater than anything else, this is needed to support our brain
  - He argues we are better able to store energy because we have a hard time tolerating a low energy environment
  - He discusses the lack of obesity in animals in captivity that are overfed
    - Instead they put on lean mass
  - He argues that metabolic sickness comes not with the inflation of subcutaneous fat but when it spills out into the viscera, liver, peripancreatic space, perinephric space, and pericardial space
    - The problem is fat that escapes the normal depot of subcutaneous fat is inflammatory and metabolically disturbing
- Peter mentions this book to say, “*It’s just one more confounding variable that makes it difficult to compare us even to an organism as complex as a rhesus monkey*”
- Matt agrees this is a criticism of the caloric restriction literature
  - Especially the mouse studies‒ there are all sorts of differences between people and mice
  - The metabolic state people have evolved to fill is completely different from mice
- But even lab mice as they get older will show metabolic syndrome‒ insulin resistance and other changes you see in people
- Mice gain adiposity with age, they do in fact become obese with age
- In the Wisconsin study, a significant fraction of the control fed monkeys developed diabetes
  - About 25% of the controls were pre-diabetic by the end of the study even though they weren’t overweight
  - Getting 28.5% of your calories from sugar is probably going to impair your metabolism

**An evolutionary perspective of the human diet**

- Matt relates this to the argument that certain diets are better for humans because it mimics what we evolved to eat
  - He doesn’t know if this is true or not
  - You could argue both sides
- He doesn’t see any particularly compelling reason to think that was the optimal longevity diet that humans ate 100,000 years ago
  - Peter finds the evolutionary diet argument illogical
  - “*By necessity, we had to be opportunistic omnivores.  To even suggest that our hunter-gatherer forefathers were sitting around pontificating about what they were and were not going to eat is just the dumbest thing I’ve ever heard*”
  - The argument becomes nonsensical when you realize our evolution necessitated the most flexibility from a nutritional standpoint
    - We ate anything and everything

***Evolutionarily, we probably never existed in an environment where food abundance was go great that we could reach a level of over-nutrition***

- Matt adds, maybe this **metabolic flexibility** is one of the reasons why humans seem to be fairly robust towards earring really, really crappy diets
- “*Obviously, we have an obesity epidemic and all of that stuff happening, but people seem to be able to tolerate a wide variety of different diets, some of which are pretty darn bad for them for many, many years before you start to really see the significant consequences. And it may be that metabolic flexibility.*”
- Peter makes a different point, “*People can survive in really remarkable health with diets that look nothing like one another*”
  - Compare a strict vegan diet to a ketogenic diet
  - Somebody eating a really well formulated, strict vegan diet, where they’re not getting any animal protein (which clearly our ancestors all had animal protein whenever they could), they’re often a little protein malnourished, but they’re very healthy
  - Somebody on a ketogenic diet is eating a much higher fat, higher protein diet, and they can be very healthy
  - And probably the only thing these diets have in common is a lot of leafy vegetables

> “*That to me speaks to the resilience of our genome in terms of its interaction with nutrition*”‒ Peter Attia

- Matt agrees, this brings them back to where he started, “*Which is that there’s no reason to think that the ancestral diet is best*”
- He now thinks our dietary options and the typical diet is evolving rapidly now
  - The quality of the food, the stuff that’s in it, the preservatives, is dramatically different than it was 50 years ago, both in caloric content and nutritional content
  - The taste is absolutely different, which contributes to why a lot of people want to eat more
- We’re in an environment of high calorie, really good tasting food that’s often cheap
- The environment that we evolved into obviously is completely different than it is today
- But our environment is changing at an accelerating pace, and that makes it really complicated to try to get into the minutia of what is optimal
- This is where Matt struggles with the data that comes from epidemiological studies of people 20 years ago
  - The environment, the food quality is just very different for most people today than was even 20 years ago

> “*Maybe we should be thinking about what’s good enough first, because I think it’s going to be really hard*”‒ Matt Kaeberlein

**The grandmother test**

- When Peter watches the extremists on both sides argue, he says 2 things
- 1 – There are good and bad ways to do the same diet
  - “*I don’t want to hear somebody tell me that everybody on a vegan diet is doing well because I watched a lot of those kids in college and they literally were going to kill themselves eating ramen noodles and crackers and cookies all day. So, you can be vegan and eat pure garbage. You could be keto and eat pure garbage*.”
- 2 – If you’re eating those diets well, you’re doing all your shopping on the perimeter of the grocery store
  - “*It doesn’t matter if you’re carnivore, vegan, keto, low carb, paleo, whatever. If you’re doing those diets in the way that they were at least thought to exist, you aren’t going down any aisles of the grocery store.*”

***That’s the grandmother test‒ if your great grandmother didn’t recognize what you’re eating, it doesn’t pass the test***

- That doesn’t mean it’s not good, Peter doesn’t want to say a protein bar is not a good thing to eat
  - You just have to acknowledge there’s a little more **risk** there
  - Eating a carrot is inherently less risky than eating a protein bar with 14 ingredients in it

***We need just a little humility around what is known, what is not known.  And as we push the envelope of convenience of nutrient density, of economics, price, shareability, portability, the ability to preserve things, we’re going to take some risks.***

## Antiaging diets: Separating fact from fiction—Matt’s 2021 review in *Science* [1:12:30]

- Matt was asked by one of the editors at *Science* to write a [review](https://www.science.org/doi/10.1126/science.abe7365) on [mTOR](https://en.wikipedia.org/wiki/MTOR)
- He’s been thinking a lot about caloric restriction and particularly other nutritional strategies that people have been studying in the field‒ ketogenic diet, protein restriction, time-restricted feeding, intermittent fasting
  - And what do we actually know about those diets and their effects on aging?
- This isn’t something that his lab researches directly
  - Matt has previously done work on caloric restriction in invertebrates and *C. elegans*
  - They have never really have done a lot of dietary interventions in mice
- Before he dove into the literature, he had this impression that all of these diets were similar in some ways and had maybe comparable effects on lifespan
  - This was his impression from reviews, but he doesn’t think much of what gets into the literature as review articles are actually reviews
  - Reviews are more one person’s opinion piece on their specific thing that they study, which is unfortunate

> “*Reviews on caloric restriction and other dietary interventions, they’re very one-sided*”‒ Matt Kaeberlein

- Matt proposed to the editor that he should do a critical review of this space and think about “*What do we know, what do we don’t know, are they equivalent? And to the extent possible, can we gain any insights into whether or not these nutritional strategies, whether there’s evidence that they have an impact on the aging process in people?*”
  - This was a very ambitious thing to tackle
  - He’s not sure he really appreciated exactly how challenging that was going to be, because it’s a huge area of literature

***And turns out, that there are many more questions than there are answers when you really dive into it***

- Matt had a fantastic set of co-authors, all really great early career scientists who really helped with this and did a lot of the legwork
  - 1 – [Alessandro Bitto](https://dlmp.uw.edu/faculty/bitto), was a postdoc with him
  - 2 – [Mitchell Lee](https://www.linkedin.com/in/mitchell-lee-54296143), was a former graduate student of his
  - 3 – As was [Crystal Hill](https://www.pbrc.edu/research-and-faculty/postdocs/Hill-Cristal-PhD.aspx), who’s at the Pennington Biomedical Research Institute
    - She works on FGF21 and protein restriction
  - These were the 3 co-authors on this paper with him, just really fantastic early career scientists

**Diets addressed in the** [**review**](https://www.science.org/doi/10.1126/science.abe7365)

- Question #1‒ what are the different popular dietary interventions that people have claimed have an effect on aging?
  - They came up with 6 or 7
- True ‒ is pretty straightforward‒ limit overall caloric intake from 20-65%
  - This is mostly research in mice
  - Then they looked for parallels in humans
  - They didn’t go deep into caloric restriction because that literature is huge and other people have done a pretty good job of reviewing it
  - They touched on some important points
- Variants of caloric restriction include **intermittent fasting** and **time-restricted feeding**
  - In most studies in mice, the experimental group ate less calories than the control, so this is a flavor of caloric restriction not isocaloric
    - He thinks of it as intermittent caloric restriction
- To *differentiate* between time-restricted feeding and intermittent fasting‒
  - The easiest differentiator is **time-restricted feeding** is limiting the number of hours in a 24-hour period that the animal or person eats
    - That window can be 12-6 hours, sometimes more extreme
  - A 24-hour or more fast defines **intermittent fasting**
- Time-restricted eating gets more complicated because there’s evidence that’s not only about how big the window is, but where in the day of the window is
  - In their review of the literature they found a clear connection between how much we eat and when we eat that ties into circadian rhythms and that circadian biology

***Subsequent studies reemphasize the importance of when we eat and what we eat***

- Matt thinks both are probably going to be significant in terms of the consequences of the long-term health effects

- **Fasting-mimicking diets** are diets that have been engineered to some extent to induce the same metabolic changes as caloric restriction, usually very low sugar, relatively low protein, high fat, but also very low calorie
  - That goes in the bucket of a flavor of caloric restriction
- Other diets are **ketogenic diets**
  - An *ad lib* ketogenic diet might end up restricting energy, but not deliberately
  - Matt doesn’t know if that answers the question of whether the benefit comes from caloric restriction
- And **protein restriction**, some are isocaloric protein restriction
  - You have to look closely at each paper to figure out if it’s isocaloric or not
- If the diet is not *ad lib*, there are psychological consequences to not eating when you want, to being hungry all the time
  - Good, bad, indifferent.
  - But those have biological consequences as well

## Mouse models of time-restricted feeding in the context of calorie restriction [1:19:30]

**Insights from a circadian diet**

- When Matt wrote the [review](https://www.science.org/doi/10.1126/science.abe7365), there wasn’t much on this topic
- People were thinking about in in the context of time-restricted feeding
- Thinking that there might be differences in the window of time-restricted feeding in humans early in the day, late in the day
- There’s been a couple of papers in mice that make a compelling case that ***the lifespan benefit*** from, say a 30% caloric restriction diet, ***is a combination of WHEN the animals are eating and HOW MUCH they’re eating***
- Most of the benefit comes from the calories
- For example, let’s say you get a 30% lifespan extension from 30% caloric restriction
  - ⅔ of that benefit comes from the calories
  - ⅓ of the benefit actually comes from the fact that those mice eat all their food in a short window and are fasted essentially the rest of that 24-hour period
- Now a calorically-restricted mouse is going to eat its food right away, but ***if you force them to eat little bits throughout the day you lose a portion of that lifespan benefit***

**How would you compare to a human, a mouse eating for 1 hour then going 23 hours without food?**

- A mouse lives about 3 years
- To compare mice to humans, the length of lifespan is not the approach to take when it comes to metabolism
- A back of the envelope calculation, its a 1:4 ratio, where 1 day mouse fast might be a 4-5 day fast in people
  - That’s not perfectly true because a mouse will go into ketosis relatively quickly within 24 hours
  - A human can go into ketosis that quickly too, depending on their diet
- If you go back to the [classic experiments](https://pubmed.ncbi.nlm.nih.gov/3958810/) of [Rick Weindruch](https://experts.news.wisc.edu/experts/richard-weindruch) and [Roy Walford](https://roy.walford.com/), those mice are fed a calorically restricted diet, but they’re also fed three times a week (they’re fasting)
  - Peter reacts, “*It’s insane. They’re basically doing a two-week fast between their meals.*”
  - Matt explains that you see a pretty dramatic reduction in organ size, even in 24 hours in a fasted mouse, and these mice are only fed 3x a week
  - They’re going through this reduction in organ size and then this really rapid hypertrophy
- You can see that decrease in organ size and then rapid increase even on some of the fasting mimicking diet work that [Valter Longo](https://gero.usc.edu/faculty/longo/) has done

**An experiment to compare the impact of calories not time of day for feeding**

- Peter asks if anyone has done an experiment to mimic the way humans eat
- Take 2 groups of mice
- The controls are fed 100% of the nutrient, but they’re fed every 2 hours over the course of the day
- The CR group is fed 70% of what the controls get, and they’re fed at the same time intervals,  constantly throughout the day
- This compares the impact of calories and there is only fasting when they sleep
- At least 1 of the 2 studies Matt was referring to did this
  - [Fasting drives the metabolic, molecular, and geroprotective effects of a calorie restricted diet in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8544824/)
  - [Circadian alignment of early onset caloric restriction promotes longevity in male C57BL/6J mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9262309/)
  - That’s how they were able to identify that ⅔ of the benefit came from the reduction in calories and ⅓ came from the additional fast
- One point Matt made in the [review](https://www.science.org/doi/10.1126/science.abe7365) is, the vast majority of the literature around intermittent fasting and time-restricted feeding and fasting mimicking diets, they’re calorically restricted
  - So, there’s a fasting period and a caloric restriction component
  - And none of the prior studies really teased that out in a way that allowed us to have an understanding of how much of the benefit is calories and how much IS fasting, and maybe how much is WHEN you’re fasted
    - That’s still is an open question

**Eating early in the day versus late in the day**

- Matt is not an expert in this area and doesn’t have an opinion about which is better
- This is where he thinks mice are not going to be a good model for humans
  - These studies need to be done in people
- Peter recalls, “*Some have suggested that an early feeding window versus a late feeding window produces better pairing of our insulin sensitivity to our nutrient arrival*”
- Matt thinks this makes sense
  - Most people would agree that if you’re eating something that causes your blood sugar to spike, doing that right before you go to bed is probably suboptimal
  - So if you’re going to do a time-restricted feeding, it might be better to eat earlier and not right before bedtime
- These kinds of questions are really complicated in humans because you could ask about different benefits‒
  - Overnight blood glucose levels
  - Sleep quality
  - Other biomarkers
- These benefits might be different in different people and different from each other
- Matt notes, “*In my mind at least it’s not even really clear how we evaluate what is better and what is suboptimal. It may depend on what your endpoint is, what you’re actually interested in optimizing.*”
- Peter has seen in people who wear a [CGM (continuous glucose monitor)](https://en.wikipedia.org/wiki/Continuous_glucose_monitor) that early feeding produces an overall lower average glucose
  - Even if you do the same meal early in the day versus late in the day
  - There’s something about how long it takes glucose levels to come down at night versus in the morning
    - It could be you’re more insulin sensitive in the morning and therefore it comes down quicker
    - It could be something to do with pairing sleep with the nutrition that is tweaking this and there’s a feedback loop where the excess glucose creates a little more cortisol
    - But at the same time, you theoretically should have the lowest cortisol at night anyway
  - Generally it doesn’t produce a great quality of sleep
  - This gets into the minutiae that Peter wants to hear more about

**Matt’s big picture takeaway**

- These nutritional intervention studies in mice are very powerful for dissecting the biological mechanisms that underlie the effects that they have
- Some of these diets clearly have effects on aging

***Matt is very hesitant to suggest that people should adopt any of these diets based on the rodent literature where it’s at today (for a whole variety of reasons)***

- Studies in mice are super useful for understanding the biology but he’s not sure they are going to work the same way in humans

## Nutritional interventions that consistently impact lifespan in mice, and concerns around efficacy in humans [1:27:00]

**Studies of a ketogenic diet**

- There have really only been 2 studies that have looked at the lifespan and healthspan of mice on a ketogenic diet
  - They were slightly different
- In mice you have to go really, really low sugar to get the mouse to go into ketosis (1% or less carbohydrate diet)
  - This is different from people
- One [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4862866/) of lifelong ketogenic diet saw *no effect on lifespan*
- Another [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5605815/) used an intermittent ketogenic diet, something like every other day or maybe once every 3 days or something
  - On the other days they ate a regular diet
  - In some ways this was an intermittent caloric restriction
  - *They found a 15% increase in lifespan*
- The **fasting-mimics diet papers** are using intermittent-ketogenic diets

***Maybe that’s one thing to agree on is that intermittent ketogenic diets in mice can increase lifespan and seem to have benefits for healthspan***

- The effects aren’t huge

**Caloric restriction is a nutritional interventions that consistently give big effects on lifespan**

- In the most extreme study, they used 65% caloric restriction and this gave about a 65% increase in lifespan‒  a big, big effect size
  - This is [the Weindruch and Walford paper](https://pubmed.ncbi.nlm.nih.gov/3958810/)
  - Matt doesn’t remember the details but thinks their studies were early onset caloric restriction
  - This study was interesting because they did a graded response of 25-65% caloric restriction, and this produced a graded response in lifespan that was roughly linear
  - Animal care protocols wouldn’t allow you to do this study today

*How angry are the mice on ⅓ of their normal caloric intake?*

- One of the remarkable things about caloric restriction in mice is that they are **more active** throughout life than *ad lib* fed mice are
  - Maybe it’s an evolutionarily selected foraging response
  - You give them a running wheel and they’ll just run and run and run

**Behavioral changes is one of Matt’s real concerns about caloric restriction in people**

- We should be realistic and recognize you’re never going to get a significant fraction of the population to calorically restrict
- It’s hard enough to get people to calorically restrict down to a healthy weight
- To get them to go 30% beyond that, it’s just not going to happen
- Matt knows people who have done every possible anti-aging intervention you could imagine
- He knows a lot of people who’ve dabbled in various forms of caloric restriction

> “*True caloric restriction has real psychological consequences*”‒ Matt Kaeberlein

- There’s social isolation that you get when you’re calorically restricting
- But then there’s the biological changes in the brain and you’re hungry all the time
- We often don’t appreciate those aspects of some of these nutritional interventions
- But in the mice, it’s hard to know what their psychological consequences are

## Differing impact of calorie restriction when started later in life [1:31:00]

**What do we know about caloric restriction later in life in the mice versus earlier?**

- The NIA experiment we talked about earlier in monkeys, the early fast didn’t improve longevity
  - The late fast appears to have, although that was sort of a subgroup analysis
  - It’s hard to draw a causation there
- For a long time, the dogma was that caloric restriction didn’t work if you started it past, I don’t know, 15 months of age, which is maybe the mouse equivalent of a 40, 50 year old person
- Most of the early caloric restriction studies were done starting sometime pre-development
- Early rat studies were pre-development and 6 or 9 months of age
- If you do a graded onset of caloric restriction, you can get lifespan benefits from caloric restriction at 20, 22 months of age
  - In other words, don’t go right from *ad lib* to 40% restriction the next day
  - Whether it’s as good as starting early, Matt thinks the consensus is still that the answer is NO
  - You’re never going to get the same magnitude of benefit from caloric restriction, starting late as you do starting early

***Matt doesn’t think we know for sure whether it’s possible, if you did it just right, that you could get most or all of the benefits from starting late in life***

- Peter notes, “*On this topic of CR in mice the dogma has generally been… that CR in mice only works early in life.  How applicable is that to humans?*”
- There are some data that try to get at this question‒ a [2019 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6861129/) by [Hahn](https://www.linkedin.com/in/oliver-hahn-ph-d-2363b3141) with 800 female mice
- For the 1st 3 months they ate an *ad libitum* diet
- At 3 months they were randomized to 2 groups, (1) 40% caloric restriction and (2) *ad lib*
- This study continued until 24 months, then each of those groups were further split
- Everyone was the same for the 1st 3 months but by the end there were a total of 4 groups: (also summarized in panel (a) in the figure below)
  - 1 – Caloric restricted (labeled in the figure below as DR, dietary restricted)
  - 2 – *Ad lib* (AL)
  - 3 – Caloric restricted from 3 months to 21 months, then *ad lib* (DRAL)
  - 4 – *Ad lib* to 21 months then caloric restricted (ALDR)

*Findings‒*

![](https://peterattiamd.com/wp-content/uploads/2022/09/f2-mattk.png)

**Figure 2.  Mouse lifespan for different diets.**  Image credit: [*Nature Metabolism* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6861129/)

- The *ad lib* group lived the shortest (the blue line in the figure above)
  - The maximum lifespan was 1200 days
  - The median lifespan was about 900 days
  - This is a reasonable lifespan for control animals
- The all CR mice had a maximum lifespan of just below 1,400 (the red line in the figure above)
  - Their median lifespan was around 1,150

- What’s interesting are the middle groups…
- Before we get to that, Matt points out that beginning CR at 3 months is pretty early onset of CR
  - This goes back to discussion of rat studies earlier, where really large benefits of CR come from being restricted during development itself
- The big question is, “*What happens if you start caloric restriction late in life?*”
- This study did a sort of flip/ crossover design where they started CR late in life
  - This produced a significant but not huge effect
  - Extension of lifespan is much less in the group that began CR at 24 months (the green line in the figure above) than the group that was CR since 3 months (the red line in the figure above)
    - This fits with the literature
    - Earlier [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC397416/), by [Steve Spindler](https://stemcells.ucr.edu/stem-cell-center/faculty/stephen-spindler) started CR at maybe 15 months [correction‒ 19 months]
    - They saw a significant, but not as large benefit from starting CR late in life
- This current study asks a really interesting question, “*What happens if you’re CR’d for an earlier period in life and then back on AL? Do you lose the benefit?*”
  - The answer is NO
  - Those animals lived longer than mice that went on CR late in life
  - Follow-up questions:
    - Is it about the total amount of your life that you’re restricted?
    - Is it about when you go on and when you come off?

> “*We don’t really know what the mechanisms are*”‒ Matt Kaeberlein

- The difference in the maximum lifespan is trivial, the real differences between the groups is in the median lifespan

***Matt’s takeaway‒ we can’t draw too many conclusions from humans from this, but what is the underlying mechanism?***

*Questions‒*

- Is it about the total time you’ve been on CR?
- Is it an interaction with how old you are (the developmental process) when you do CR?
- What happens when you go on CR at the end of life, which is mostly the degenerative process?

## Lifespan extension with rapamycin in older mice [1:37:15]

**Comparison to what we know about mTOR and rapamycin**

- With rapamycin, the data are pretty clear that you can start [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) well into middle age and maybe even into very old age, and get most of the benefit
- If you compare the curve here where they started the mice on CR at 22 or 24 months, the effect is pretty small compared to CR
- With rapamycin, you get almost exactly the same benefit, starting at 20, 22, 24 months as you do starting early in life
  - So that might tell us that there’s a difference
  - There clearly is a difference- a different mechanism or a different dose effect
- Peter talked about this with [Rich Miller](https://www.richmillerlab.com/biog) on the [podcast](https://peterattiamd.com/richardmiller/)‒ the fortuitous accident, about getting the correct formulation of rapamycin for absorption/ bioavailability

**Matt tells the story of rapamycin**

- In the early 2000s the NIA started a program called [The Interventions Testing Program](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp)
  - The idea here was really smart
  - We could create a tool where the scientific community could nominate interventions for lifespan testing in mice, and it was set up so that it would be done in triplicate, three sites
    - There still are three sites for the ITP
- So anybody in the community can nominate any intervention
- There’s a selection committee that selects them every year
- If an intervention is selected, then the Intervention Testing Program sites start the cohorts of mice on that intervention in whatever year it was selected for
- Sometime back in the early 2000s, [Dave Sharp](https://www.einsteinmed.edu/faculty/7486/david-sharp/) nominated rapamycin
  - He was ahead of his time
  - This was before/ around the time the 1st invertebrate studies on mTOR and rapamycin were published
  - He was thinking about it from a cancer perspective
- This program typically tests 5-6 interventions or drugs each year
  - So they have a huge number of animals at each of these 3 sites that are destined for this type of testing (ITP)
- [Randy Strong](https://www.uthscsa.edu/academics/medicine/profile/strong) was one of the PIs on the ITP, he has a really strong biochemistry background
  - He recognized quickly that rapamycin wasn’t stable in food
  - Rapamycin gets broken down in the pH of the gut
    - So basically if they just put the powder in the food, there’s no bioavailability, it doesn’t get taken up by the mice
- They realized this problem when they were supposed to start the experiment
- Randy or somebody said they could figure out a way to stabilize rapamycin and put it in food so they could do the lifespan experiment in mice
  - What they didn’t recognize was that it was going to take 18 months or so to figure this out
- Before this, everyone in the field (including Matt) thought you had to start an intervention early in life, or you weren’t going to get much of a benefit
- Fortunately, they went ahead with the experiment, starting at 20 months of age

***They found was that they got this robust lifespan extension from starting with rapamycin treatment at 20 months of age***

- Just to give some context, that’s about the mouse equivalent of a 60 or 65 year old person
- Matt loves this experiment because first of all, nobody thought it was going to work except maybe Rich Miller
- It was really the first time anybody had convincingly shown that you could start an intervention in middle age, in a mouse, and get a robust lifespan extension
- When Matt reviewed the paper and saw that result, he realized this changes everything
  - This paper came out in 2009, so it’s been 13 years since then

> “*We actually have a chance for translational geroscience, because you might be able to intervene late in the aging process and have significant impact*”‒ Matt Kaeberlein

- The whole paradigm in the field has changed
- Today, most people studying interventions test for efficacy late in life
  - Because that’s what we need to do in people
- So this result with rapamycin was super important for the field for that reason
  - And it all came about by an accident
  - Nobody would’ve designed that study that way beforehand

**The bioavailability of rapamycin**

- This recently came across Matt’s radar, and he’s heard several results that convince him it’s true
- He mentioned the reason why they had to make this eRapa (encapsulated) is because rapamycin isn’t stable at the gastric pH of mice
  - The same thing seems to be true in people
  - So there are people who are getting their rapamycin from the [Rapamune](https://www.pfizer.com/products/product-detail/rapamune), which is the brand name ( Sirolimus is the generic), it comes in these triangle shaped pills
  - There are also people who are getting it from compounding pharmacies

***Matt has heard of several cases now where the bioavailability is much lower in the compounded rapamycin in a capsule than in the actual Rapamune***

- People should be aware of this
- He doesn’t think most physicians are aware or it nor are compounding pharmacies
- Peter has never had it compounded, he only prescribes Sirolimus or Rapamune
  - It’s not a cheap drug so he can understand why there’s a desire to compound
  - The cost is around $5, $6 a mg

## Relationship between protein intake and aging, and mouse studies showing protein restriction can extend lifespan [1:43:30]

- One of the other things that came out of Matt’s review article of the animal stuff was protein restriction
- Of all the topics in nutrition, this is the one Peter is most interested in

> “*Don’t tell anybody, but I care an awful lot about protein*”‒ Peter Attia

- Peter is deliberate about trying to eat a gram of protein per pound of body weight, spread out into 4 buckets
- There’s reasonable evidence to suggest that if you consume too much protein in one sitting, you’re going to oxidize some of that protein
  - Typically more than 0.25 grams per pound
- It’s not that more is harmful, you’re just not getting the amino acids you need for muscle protein synthesis (his objective)
- The RDA says he’s crazy, recommended daily allowance of protein is 0.8 grams per kg
  - This is less than half of what he consumes
- He’s doing this on the basis of other data that suggests that this is the amount of protein consumption you need for optimal muscle protein synthesis

**Where does this disconnect?**

- We can talk about the biology of aging and the rodent studies
- The RDA question is a different question
  - It’s Matt’s understanding that this was developed for 95% of the population when sedentary
  - This is not necessarily the optimal amount and probably depends on lifestyle and lean body mass
- There’s a lot of confusion among the general public about what the [RDA](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5347101/) means
  - It’s not necessarily a bad thing to be above the RDA in some areas, maybe a lot of areas
  - Peter jokingly thinks of the RDA for protein as what you need to not waste away, wither up, and die

**What is the relationship between protein intake and aging?**

- This is a really important question
- It’s gotten a lot of attention in the field but there’s a lack of clarity about what we actually know and what we should be recommending to people

**Mouse studies show protein restriction can extend lifespan**

- There are different flavors of protein restriction and it’s not clear that the mechanisms are the same across these different flavors of protein restriction
  - 1 – Restrict all protein down to some low %
  - 2 – Restrict [tryptophan](https://en.wikipedia.org/wiki/Tryptophan)
  - 3 – Restrict [methionine](https://en.wikipedia.org/wiki/Methionine)
  - 4 – Restrict [branched-chain amino acids](https://en.wikipedia.org/wiki/Branched-chain_amino_acid) (leucine, isoleucine, and valine)

***The common mechanism that does seem to potentially underlie all of these forms of protein restriction is inhibition of mTOR***

- Protein is an *activator* of [mTOR](https://en.wikipedia.org/wiki/MTOR) and we know a fair amount about the biochemistry of that, that particularly branch chain amino acids can directly activate mTOR through [sestrins](https://en.wikipedia.org/wiki/SESN2)
- It seems intuitive that protein restriction would be beneficial by turning down mTOR
  - This is the simplest possible mechanism for why protein restriction (especially branched-chain amino acid restriction) would be having an impact on lifespan and healthspan in mice
- It seems counterintuitive that consuming increased protein would be beneficial, because you might be hyper activating mTOR

**FGF21 (fibroblast growth factor 21)**

- [FGF21](https://en.wikipedia.org/wiki/FGF21) is the other important player in protein restriction (particularly total protein restriction)
- FGF21 is secreted in response to a low protein diet, and then has effects on liver metabolism
- It also inhibits mTOR and reduces [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)
- So that seems to be required for the lifespan extension that is seen from protein restriction in mice, potentially partially upstream of mTOR in liver metabolism.
- Overexpression of FGF21 has been [reported](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3466591/) to be sufficient to extend lifespan in mice

**Questions about protein restriction studies**

- 1 – Is protein restriction always beneficial in mice?
- 2 – Can we separate it from caloric restriction?
- You have to look closely at the studies and determine, did the mice on protein restriction eat less, eat the same amount and eat more?
  - You can find examples of all of those
  - This has to do with the different compositions of the diet
- When you restrict for certain amino acids (such as methionine), mice will eat more but they don’t seem to gain weight and they live a little longer
  - So there could be a different mechanism there that we don’t really understand

**Matt’s takeaway from protein restriction studies in mice**

- Branch chain amino acid and methionine restriction studies are pretty clear that those animals are consuming more calories than the *ad libitum* mice (certainly if you match to weight), and they’re living longer
- We don’t know the mechanism by which methionine exerts this effect
- Lots of mechanisms have been proposed:
  - mTOR likely plays a role
  - [Methionine](https://en.wikipedia.org/wiki/Methionine#S-adenosyl-methionine) is used to synthesize [S-adenosylmethionine (SAM)](https://en.wikipedia.org/wiki/S-Adenosyl_methionine) which is a methyl donor for DNA methylation so maybe it’s important for epigenetic modifications
  - Methionine is the first amino acid in every protein, so there could be effects on protein synthesis
  - There’s evidence linking methionine restriction to sulfur amino acid biology, which has been implicated in aging
- Literature on **inhibition of protein synthesis in invertebrates** show this is enough to extend lifespan
- mTOR is a primary regulator of protein synthesis
- So when you inhibit mTOR, you can also inhibit protein synthesis
- That’s part of the challenge here, is this network is so interconnected that when you tweak one part of it, you have effects throughout the network, and it’s really hard to know which of those effects are causal

## Impact of protein intake on mTOR, and why inhibition of mTOR doesn’t cause muscle loss [1:50:45]

**How long is mTOR activated in response to the increase in amino acids?**

- Matt is not sure
- It will depend on what you eat in combination with the protein, when you eat, and how active you are
- Peter talked to [David Sabatini](https://www.davidmsabatini.com/research) about this, through the lens of BCAA (branched-chain amino acid) drinks
  - A few years ago it was recommended to pound branch chain amino acids during a workout to get as much anabolic signal as possible (maybe things have changed now)
  - [Bobby Saxton](https://www.linkedin.com/in/robert-saxton-98b4bb72?original_referer=https%3A%2F%2Fwww.google.com%2F) was the guy in his lab who did the [Science paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4698017/) that looked at the leucine sensor for the mTOR pathway

***The answer was, it didn’t’ stay on long at all***

- Free amino acids are very short in their ability to turn on mTOR
- It’s so short-acting that the idea of using BCAA analogs to treat [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) was going to require drugs that could stay on much longer

**This short-acting signal fits with the concept of homeostasis**

- Matt adds, “*This gets back to the whole homeostasis concept*”
- Cells and tissues have evolved to maintain metabolites, and amino acid are metabolites
- Amino acids are involved in many different metabolic reactions within certain levels
- There are all sorts of mechanisms to ensure that if a metabolite it’s outside of that range, we soak it up and we do something else with it
- Matt thinks it makes sense that you’re probably not going to have a persistent increase in branched-chain amino acids, far outside the normal range
- HOWEVER, slightly elevated branched-chain amino acids chronically can have big effects on the sort of downstream processes
  - There are [some inborn diseases of childhood](https://academic.oup.com/hmg/article/23/R1/R1/2900649) where you have elevated levels of branched-chain amino acids
  - There are consequences to even having somewhat modest increases in mTOR, say, hyperactivation of mTOR signaling chronically
  - So again, the context really matters

***It’s Matt’s intuition that it’s probably hard to get very large, persistent increases in mTOR simply from taking a branch chain of amino acid supplement***

- Peter adds, “*The anabolic data suggests it’s not necessary*”
  - The muscle protein synthesis window is open long enough that simply delivering a great source of whey protein in the hours after a workout seems sufficient to not restrict muscle potential growth
- Matt points out‒ “*It’s important to appreciate… not only how high mTOR gets turned or or how low it gets turned down, but also where that happens*”
  - This is true with [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) as well

**Why doesn’t inhibition of mTOR cause muscle loss?** [1:50:00]

- People for a long time thought that rapamycin (an [mTOR inhibitor](https://en.wikipedia.org/wiki/MTOR_inhibitors)) would cause muscle loss, but we don’t see that in mice or in people or in dogs
  - Matt guesses that has maybe more to do with WHERE mTOR is being affected, than HOW MUCH we’re inhibiting mTOR

**Do we know where the selectivity of rapamycin is?**

- Is it more selective in hepatocytes?
- Is it more selective in adipose tissue?
- Matt doesn’t know of any good studies that have carefully looked at this
- It gets even more complicated because, even in a mouse, where you can essentially control almost everything (what the mice are eating and when they last ate has), it [BCAA consumption] has as big as or maybe a bigger effect on mTOR signaling than rapamycin
- There have been a couple studies that looked at this and they got different answers, and Matt’s not sure who to believe because he doesn’t think either was wrong
- It’s complicated and that’s why Matt will often gravitate back towards the question, “*What are the functional consequences we can actually measure?*”
  - For example, you think treating a mouse with rapamycin is going to cause sarcopenia; let’s do the experiment and find out
    - The answer is no, it doesn’t
    - So that tells us, it’s at least not as simple as we thought it was going to be

## Low-protein vs. high-protein diets and their effects on muscle mass, mortality, and more [1:55:30]

**On the flip side, is more protein versus less protein activating mTOR in a way that is counterproductive?**

- Matt thinks it can, in certain cases
- He doesn’t know if anybody has carefully done that study in mice
- There was an interesting [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5087279/) by [Steve Simpson](https://www.sydney.edu.au/research/our-researchers/academic-staff/stephen-simpson.html) and colleagues, here they did this nutritional geometry work, where they looked at a range of diets with different composition of 3 macronutrients (carbohydrates, fats, and proteins) and asked, “*What does it look like in terms of metabolism, energy expenditure, lifespan?*”
- Diets where the mice lived the longest were towards the low end in protein
  - But there were some things that called into question exactly what was going on there, because it wasn’t the case that the diets that were energetically lowest gave the longest lifespan, as you might expect from caloric restriction

***An ad lib diet with 40% protein resulted in the best absolute lifespan (they were not calorie restricted at all)***

**How do we reconcile this body of literature?**

*Matt’s interpretation‒* there are many ways to get there

- We really don’t understand the inner relationships of these macronutrients in the diet with enough sophistication to get beyond sort of broad general prediction
- This is an area where his intuition from the data he’s seen (and his observations of people), is that in humans, this relationship between protein and health during aging is probably very different than it is in mice

***He thinks mice are able to tolerate a very low protein diet without some of the consequences that we see in people***

- He doesn’t know that’s true, but that’s his intuition
- Peter agrees, the number of problems that occur in humans when they are undermuscled are insane
  - Metabolic consequences
  - Our muscles are the single most important sink we have for glucose
  - “*Our ability to tolerate glucose and maintain glucose homeostasis in the presence of larger, more metabolically, healthy muscles is the difference between having diabetes and not having diabetes*”
  - We don’t study any animal (including primates) where sarcopenia and osteoporosis are problematic
    - Yet, how many people over the age of 75 are suffering from one of both of these phenomena?
    - Peter wouldn’t be shocked if at least 80% of people over 75 experience this
  - Activity level falls off a cliff once people hit 75 and muscle mass dramatically plummets
    - It’s difficult to say which one is feeding which

> “*There’s no question that something is happening to our species at about the age of 75 that is a structural problem*”‒ Peter Attia

- Peter’s take on aging, “*I don’t care if I live to a hundred and don’t have cancer, if I’m an invalid for the last 25 years and I can’t play with my grandkids and throw a ball*.”
- Matt adds, the question for people is, “*How important is dietary protein in that maintenance of muscle or loss of muscle (in people who are going the wrong direction)?*”
- Peter thinks the data shows protein is quite important
  - There are lots of studies that have compared the RDA to double the RDA standard
  - Protein makes a very big difference following the training that is necessary to stimulate muscle protein synthesis
- Matt agrees, training and protein intake have to be coupled
- Peter recalls data showing that protein intake alone can make some difference in muscle protein synthesis
  - But it’s not nearly the difference you get when you pair it with hypertrophy training

**Why is there a vocal camp in the aging field that argues for low protein as the best nutritional strategy for aging and healthspan in people?**

- Matt’s takeaway‒ “*You can find the answer you want for almost any question in this area that intersects with nutrition and aging. There will be a study that will fit your belief.*”
- He tries to take a global view and understand what the totality of the data saying
- But there are epidemiological studies and one in the field most people will point to when they go to humans and they talk about low protein, the [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988204/) that [Valter Longo](https://www.longolab.org/) was I think the senior author on and [Morgan Levine](https://altoslabs.com/team/principal-investigators-san-diego/morgan-levine/) was the first author on where they looked at protein consumption and all-cause mortality as a function of age in people
- There were some studies in yeast as well

***The take home message was that low protein is beneficial up to about 65 years of age, and then once you get above 65 years of age, it kind of flips and people who ate a higher protein diet have lower all-cause mortality***

- To be clear we’re talking specifically about all-cause mortality
- When Peter looks at deaths per 100,000 people (to adjust for population size of each age group) at age 40, 50, 60, 70, 80‒ above the age of 65, deaths goes up very non-linearly
  - You could argue that a high protein strategy, even throughout life, is better because the absolute reduction in mortality would be lower due to the benefit you would have later in life
  - Matt agrees, the impact of a change in mortality late in life is going to swamp the same impact on mortality early in life
- Matt thinks the question here is, “*What are the relative effects?*”
- In their model, the relative risk crossed somewhere in the 60s
  - In other words, your total mortality benefit was lower eating a high protein diet
  - That actually surprised Matt because for exactly the reason you said, the relative impact of the high protein diet early in life would have to be an order of magnitude greater than the relative impact of it late in life
  - Matt doesn’t remember the exact details, but in the paper you can see the curves cross later than he would have expected given they picked age 66 (see the figure below)
    - Matt would have thought the age would be in the 50s
  - He tried to do his own modeling but he couldn’t get the data

![](https://peterattiamd.com/wp-content/uploads/2022/09/f3-mattk.png)

**Figure 3.  Association between protein consumption and mortality.**  Image Credit: [*Cell Metabolism* 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988204/)

**Questions from this study:**

- When should you switch your diet?
- At what age does the risk equal out?
- Matt found that once you get past 50, the benefit of a high protein diet on mortality seems to outweigh any detriment
- ***Peter thinks if you restrict protein late in life, it would have no benefit on healthspan***
  - Excluding people with renal insufficiency
- Matt intuitively agrees, but the mouse rapamycin experiments makes him hesitate
  - Everybody who knew anything about muscle said if you gave a mouse rapamycin throughout life, ti was going to get sarcopenia, and that just didn’t happen
- Peter is saying, there is clinical data suggesting a huge difference in muscle mass for people over the age of 65 who are protein deficient versus protein significant
- Matt asks, “*Do we have controlled studies where people were eating low protein and doing resistance training late in life? They’re a nuance here that could complicate things. But I think in general, you’re probably right*.”

## The impact of IGF-1 signaling and growth hormone on lifespan [2:06:30]

**IGF-1**

- The other complication is the convention of using [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) as a biomarker for protein intake
  - It’s certainly associated with protein intake
  - *What is it a proxy for?*
- IGF-1 is insulin-like growth factor one; it’s a hormone
- You can think of it as a growth promoting hormone, part of this central pathway that promotes growth in many, many different tissues
- If you have high growth hormone levels, you’ll have high IGF-1 levels and high mTOR
  - IGF-1 is a part of the mTOR pathway as well, upstream of mTOR (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/09/f4-mattk.png)

**Figure 4.  Activation of mTOR by leucine, IGF-1, and Glucose.**  Image Credit: [*Obesity* 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3317169/)

- Think about this from the opposite perspective, instead of high IGF-1 signaling, the next figure shows the effects of low IGF-1 signaling
  - Low growth factor levels (such as IGF-1) is a result of caloric restriction and some diets

*The effects of this on downstream processes is summarized at the bottom of the figure; these are processes that benefit from caloric restriction*

![](https://peterattiamd.com/wp-content/uploads/2022/09/f5-mattk.png)

**Figure 5. Connections between pathways of low growth factor signaling and mTOR and the effects on downstream processes.** Image credit: [*Science* 2021](https://pubmed.ncbi.nlm.nih.gov/34793210/)

- The reason why people have been really interested in IGF-1 in the field of aging biology comes from studies in very simple laboratory model systems
  - The insulin-like receptor in *C. elegans* called [daf-2](https://en.wikipedia.org/wiki/Daf-2) is the most famous one and 1st gene clearly shown from a mechanistic perspective to contribute to aging
  - This work was done by [Cynthia Kenyon](https://profiles.ucsf.edu/cynthia.kenyon) and [Tom Johnson](https://www.colorado.edu/iphy/people/faculty/thomas-e-johnson) before her
  - Cynthia published a [classic paper](https://pubmed.ncbi.nlm.nih.gov/8247153/) showing that if you make a mutation in *daf-2*, it could double the lifespan of worms and they seem to be healthier about twice as long
  - What that mutation does is it turns down signaling through this pathway
  - It’s a little bit more complicated in worms, because it’s called the insulin/IGF-1 signaling pathway, so it’s not identical
    - There’s one path in worms that kind of takes the place of both IGF-1 signaling and insulin signaling, but you can kind of think of them as equivalent
  - And then there are a whole bunch of studies in mice for mostly mutations in the growth hormone, upstream signaling, upstream of IGF-1, that lead to increased lifespan

Peter asks, “*So this means GH (growth hormone) does not activate the production of more IGF-1?*”

- That’s right, you have high GH and low IGF-1 signaling
- Often it’s the receptor that’s mutated
- These animals tend to be very long lived
  - They rival caloric restriction in terms of the magnitude of life span extension
- There are several different mutations in this pathway, it’s complicated and there have been controversies about mutations that directly affect IGF-1 itself and the effects on lifespan

***But there’s no question that mutations that reduce growth hormone signaling in mice extend lifespan***

- It’s important to understand that those studies are all cases where the animals are deficient in growth hormone through development‒ these animals are very, very small
- One [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6008442/) used a monoclonal antibody to the IGF-1 receptor, and they treated mice late in life and got an lifespan increase of 14-15%
- Peter remembers this study; that antibody did not penetrate the CNS
  - He remembers Matt saying this would provide all the benefits of IGF in the brain with the potential harm of IGF in the periphery
- This is another complication‒ the effects of IGF in the brain on for healthspan and cognitive function might be fundamentally different than high IGF-1 in the periphery
- This study is the best evidence in mice that you can get some benefit from reducing IGF-1 signaling in middle age

***Should you take growth hormone to combat aging?***

- Lots of patients ask Peter to be put on [growth hormone](https://en.wikipedia.org/wiki/Growth_hormone), and he just won’t do it
- Peter hasn’t seen enough data in humans to suggest that it’s safe
  - Or conversely, evidence to suggest it’s not safe
- If you believe that more growth hormone = more IGF = more mortality
  - And look at how much growth hormone is being used/ abused in sports
  - It’s hands-down the most abused drug in sports for maybe 40 years
  - So where are the bodies?
- At the same time, it’s still a leap of faith
- There’s not the luxury of rapamycin data showing humans who have taken rapamycin for 23 years
- Peter took growth hormone (GH) and anabolic steroids to help with recovery after his shoulder surgery
  - He doesn’t know if this is unrelated, by he felt the worst he’s ever felt after a week of growth hormone and [nandrolone](https://en.wikipedia.org/wiki/Nandrolone)
    - His blood pressure went up
    - His blood sugar went up
    - He couldn’t sleep
    - There were a lot of confounding factors – shoulder surgery and a nasty virus so it could all be irrelevant
- From Matt’s understanding of mouse studies on on growth hormone, he would have predicted this therapy would make you feel bad
  - It certainly should cause increased risk for a bunch of different diseases, including cancer
  - From the literature it’s not clear that there are significant benefits for strength, there’s some evidence that muscle mass may increase
  - But it’s also not clear that there’s any significant risk, which is a little surprising
- Peter has a couple of patients who have taken it (other doctors prescribed it), and they claim they feel infinitely better on it
- Maybe in 20 years we’ll have enough to say that by the time you’re 60, you should be on a slow amount of growth hormone
  - This is an important question
  - There is enough data to suggest that such a study is not unethical
  - Peter finds this to be one of the most confusing questions in this space, and Matt agrees

***Does IGF-1 signaling contribute to mortality? [2:13:30]***

*Matt’s takeaway: IGF-1 is probably not that informative in people, particularly once you get past 50 years old*

- Peter adds, “*It’s important for people to understand that just like testosterone is mostly bound to sex hormone binding globulin there’s only a small amount of testosterone that’s free. It’s the same with IGF-1. It has these* [*IGFBPs*](https://en.wikipedia.org/wiki/Insulin-like_growth_factor-binding_protein) *(or binding proteins) that bind most of it. And therefore total IGF is not really completely informative as to what’s happening, even in terms of the quantity that’s there for signaling because it’s not the unbound portion of it.*”
- Some people look at things like the IGF to IGFBP ratio, the bigger that number is in theory, the more IGF signaling you would have
  - When you look at epidemiologic curves which show IGF levels rising on the X-axis and mortality increasing on the Y-axis, Peter has never seen one of those curves that just goes up
    - Sometimes they’re U-shaped, sometimes they’re down sloped, sometimes they’re flat and it depends on the indication
  - *The story seems much more complicated than IGF is bad*

**Confounding factors in the literature**

- Going back to the [Levine paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988204/), it’s important to recognize that the **population** you’re looking at might make a big difference
  - If 30% of the population is obese and a high % have metabolic disease or diabetes, then having high IGF-1 in that context might be very different than for somebody who is insulin sensitive, exercising, and eating a high protein diet
  - These kinds of things don’t typically come out in these epidemiological studies
- Matt also looked in the literature to see what other studies have shown that same relationship, and they’re all over the place

**Is a high protein diet detrimental?**

- You can find studies epidemiological that really don’t show any downside to eating a high protein diet in people
- It’s hard for Matt to draw too much confidence that high protein is significantly detrimental when you’re younger than 50
- Further, he feels pretty confident that a higher (higher than the RDA level) of dietary protein intake when you’re above 50 is beneficial, particularly if you’re exercising
  - He would be concerned if the person is overweight, diabetic, and sedentary‒ high calorie + high protein could be problematic
- Peter agrees, a lot of the epidemiology is tainted by high protein in the context of high calorie

**Studies in people who have very low growth hormone signaling**

- It’s interesting to think about people who have mutations in the growth hormone pathway
  - They go through their entire lives with low growth hormone signaling
- [Valter Longo](https://www.longolab.org/) published [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/) on little people of Ecuador
- There have also been studies of the [Laron Dwarf Syndrome](https://en.wikipedia.org/wiki/Laron_syndrome)
- The most famous one published in [*Science*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/), where they looked at lifespan and age related health outcomes in the people with low growth hormone signaling versus controls in their same environment
  - Interestingly, there is no difference in lifespan
  - But the reduction in cancer risk is profound
  - 1 person in the cohort developed a cancer, was treated, and lived the rest of her life
  - The rate of diabetes was a little lower, but in that part of Ecuador they had a very low diabetes rate (maybe 5%)

*So why didn’t they live longer?*

- They had a higher rate of alcoholism, liver failure, and accidents
- This gets back to the social and psychological consequences in humans that are different from mice
- Growth hormone deficient mice are probably not subject to the same social pressures as people with very low growth hormone signaling are
  - This pressure may contribute to other things later on, like alcoholism

**Matt’s takeaway‒** ***I think that you can impact at least a subset of age related biology by being constitutively low in growth hormone through your entire life. What would happen if you did that in bursts, post developmentally, just after puberty say from your twenties and thirties?***

- There are no naturally occurring examples of intermittent low growth hormone signaling to look at and evaluate
- Peter asks, “*Is there enough data to look at people with acromegaly during different periods of their life to see if they have a higher incidence of cancer?*”
- That population would be small, but maybe it’s possible

## Parting thoughts on the contribution of nutrition to healthspan and lifespan [2:19:45]

**Matt’s take on the protein content of diet and growth hormone signaling as it relates to healthspan and cancer risk**

- Epidemiological studies are a mixture of normal people typically, and so the lifestyles most people are living are what gets weighted in those types of analyses
  - Lifestyles may be very different if you are normal weight and eating high protein, maybe high calorie (because you’re extremely active) than if you’re overweight, sedentary and eating a hot calorie diet
  - That’s underappreciated and probably really important
- Matt speculates about the cancer risk‒ ***he doesn’t think that high growth hormone signaling and high IGF-1 signaling, everything else being equal in a person leads to a higher risk of developing cancer***
- Even if it is the case that higher signaling through that pathway = higher risk of cancer, we can make an argument that it doesn’t seem to be the case (at least in certain populations of people) that high growth hormone signaling or treating with growth hormone dramatically increases the cancer incidence
- Peter points out, “*We should also differentiate between high causes it versus low removes it, just because we have a genetic example of where not having it creates a deficiency of cancer.  So going from sort of a 100 to 30 decreases cancer, doesn’t mean going from 100 to 130 increases cancer.*”
  - The point is, we don’t know… it could
- Matt goes deeper into the cancer risk‒ “removed it” isn’t quite right
  - There are many steps that have to happen in cancer to go from  pre-initiation of cancer, to cancer, to metastasis, to somebody dying from it
  - And there are different defense mechanisms that act at each of those steps
  - His guess is growth hormone and IGF-1 are primarily acting at the very early steps where we know that if you promote cell division, that is a sort of a permissive early environment that allows mutations to happen and cancers to get a foothold
  - In most cases, it seems that those early cancers are detected and wiped out by our immune system
  - One of the reasons why I think a lot of cancers become more prevalent as we get older is because the function of the immune system to detect and clear those cancers declines
  - There is other stuff going on that contributes to the process,  such as accumulation of senescent cells
- In theory, a 60 year old person who is exercising, eating an appropriate diet might be biologically a 40 year old person (or have an immune system functioning like a 40 year old)
  - They might have a little bit higher IGF-1 and a little higher risk of early cancer but they have a much lower total risk of developing cancer because their immune system has a better chance of catching it and getting rid of it

> “*And those are things we don’t even think about*”‒ Matt Kaeberlein

- Peter adds, “*We’ve created more questions than answers*”
- Matt replies, “*It’s a complicated question*”
- And we didn’t dive into the genetic interaction with caloric restriction
  - Even in mice where we can control everything else, if you look across genotypes, you get different results from the same diet and the effect of caloric restriction on lifespan
- So maybe we can’t answer the big detailed questions

**Matt’s takeaway‒**

- 1 – We’ve learned a ton from nutritional studies in laboratory animals about the biological mechanisms
- We’ve learned a lot about which proteins and pathways are important and that has led us to things like rapamycin, which might be a more effective intervention in humans
- 2 – You don’t have to worry about every little detail
  - Most people can get a big chunk of the way there by eating a relatively healthy diet
  - Don’t worry so much about how much protein, how much carbs, how much fat

> “*Eat good foods, don’t overeat, and be active, exercise*”‒ Matt Kaeberlein

- Matt worries that society does this and scientist sometimes do it too as they get into the weeks
- Questions like, “*What should my fasting window be?*”
- Matt thinks you can get most of the benefits without worrying about a lot of that

§

## Selected Links / Related Material

**Matt’s previous appearances on** ***The Drive*** **podcast**:

- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2018) | [0:45]
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2020) | [0:45]
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2020) [0:45]

**Matt’s review of antiaging diets**: [Antiaging diets: Separating fact from fiction](https://www.science.org/doi/10.1126/science.abe7365) | *Science* (MB Lee, CM Hill, A Bitto, and M Kaeberlein 2021) | [1:30, 1:14:00, 1:17:45, 1:23:15]

**Episode of** ***The Drive*** **with David Allison**: [#197 – The science of obesity & how to improve nutritional epidemiology](https://peterattiamd.com/davidallison/) | David Allison, Ph.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 8, 2022) | [15:45]

**Dog aging project (Matt co-directs)**: [About the Project](https://dogagingproject.org/about-project/) | Dog Aging Project (2022) | [23:15]

**Expression of Yamanaka factors in progeroid mice extends lifespan**: [In Vivo Amelioration of Age-Associated Hallmarks by Partial Reprogramming](https://www.cell.com/cell/fulltext/S0092-8674(16)31664-6) | *Cell* (A Ocampo *et al.* 2016) | [26:30, 30:15]

**Expression of Yamanaka factors in aged mice**: [Multi-omic rejuvenation of naturally aged tissues by a single cycle of transient reprogramming](https://onlinelibrary.wiley.com/doi/10.1111/acel.13578) | *Aging Cell* (D Chondronasiou *et al.* 2022) | [30:15]

**David Sinclair’s work using Yamanaka factors in a mouse model of optic degeneration**: [Reprogramming to recover youthful epigenetic information and restore vision](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7752134/) | *Nature* (Y Lu *et al.* 2020) | [28:30]

**CR study in rhesus monkeys at the University of Wisconsin**: [Caloric restriction delays disease onset and mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) | *Science* (RJ Colman *et al.* 2009) | [55:15]

**NIA study in Bethesda of CR in rhesus monkeys**: [Impact of caloric restriction on health and survival in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3832985/): the NIA study | *Nature* (JA Mattison *et al.* 2012) | [57:00]

**Comparison of CR studies in rhesus monkeys at the University of Wisconsin and the NIA**:

- [Caloric restriction reduces age-related and all-cause mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988801/) | *Nature Communications* (RJ Colman *et al.* 2014) | [58:30]
- [Caloric restriction improves health and survival of rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/) | *Nature Communications* (JA Mattison *et al.* 2017) | [58:30]

**Roz Anderson’s study of molecular signatures of CR**: [A Conserved Transcriptional Signature of Delayed Aging and Reduced Disease Vulnerability Is Partially Mediated by SIRT3](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4382298/) | *PLoS ONE* (JL Barger *et al.* 2015) | [1:01:15]

**Herman Pontzer’s book**: [Burn: New Research Blows the Lid Off How We Really Burn Calories, Lose Weight, and Stay Healthy](https://www.amazon.com/Burn-Research-Really-Calories-Healthy/dp/0525541527/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1657890212&sr=1-2) by Herman Pontzer (2021) | [1:04:00]

**Classic CR study by Weindruch and Walford**: [The retardation of aging in mice by dietary restriction: longevity, cancer, immunity and lifetime energy intake](https://pubmed.ncbi.nlm.nih.gov/3958810/) *The Journal of Nutrition* (R Weindruch, R Walford, S Fligiel, and D Guthrie 1986) | [1:22:00, 1:28:45]

**Effect of CR when food is parsed out in 2 hour intervals**:

- [Fasting drives the metabolic, molecular, and geroprotective effects of a calorie restricted diet in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8544824/) | *Nature Metabolism* (H Pak *et al.* 2021) | [1:23:00]
- [Circadian alignment of early onset caloric restriction promotes longevity in male C57BL/6J mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9262309/) | *Science* (V Acosta-Rodriguez *et al.* 2022) | [1:23:00]

**Lifelong ketogenic diet does not extend lifespan in mice**: [Adaptive changes in amino acid metabolism permit normal longevity in mice consuming a low-carbohydrate ketogenic diet](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4862866/) | *Biochim Biophys Acta* (N Douris *et al.* 2015) | [1:27:30]

**Cyclic ketogenic diet increases lifespan by 15% in mice**: [Ketogenic diet reduces mid-life mortality and improves memory in aging mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5605815/) | *Cell Metabolism* (JC Newman *et al.* 2017) | [1:27:30]

**2019 Hahn study, CR in mice began at 3 months and switched at 24 months** : [A nutritional memory effect counteracts benefits of dietary restriction in old mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6861129/) | *Nature Metabolism* (O Hahn *et al.* 2019) | [1:33:15]

**Steve Spindler CR initiation at midlife in mice (19 month) extends lifespan**: [Temporal linkage between the phenotypic and genomic responses to caloric restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC397416/) | *PNAS* (JM Dhahbi *et al.* 2004) | [1:35:45]

**Episode of** ***The Drive*** **with Rich Miller**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 8, 2021) | [1:38:15]

**RDA for protein**: [Optimizing Protein Intake in Adults: Interpretation and Application of the Recommended Dietary Allowance Compared with the Acceptable Macronutrient Distribution Range](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5347101/) | *Advances in Nutrition* (R Wolfe 2017) | [1:44:45]

**FGF21 overexpression extends lifespan of mice**: [The starvation hormone, fibroblast growth factor-21, extends lifespan in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3466591/) | *eLife* (Y Zhang *et al.* 2012) | [1:48:15]

**Leucine sensor for the mTOR pathway**: [Sestrin2 is a leucine sensor for the mTORC1 pathway](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4698017/) | *Science* (RL Wolfson *et al.* 2016) | [1:51:30]

**Importance of the ratio of macronutrients for metabolism, energy expenditure, and lifespan**: [The Ratio of Macronutrients, Not Caloric Intake, Dictates Cardiometabolic Health, Aging, and Longevity in Ad Libitum-Fed Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5087279/) | *Cell Metabolism* (SM Solon-Biet *et al.* 2016) | [1:55:45]

**Epidemiological study supporting a low protein diet for health and longevity**: [Low Protein Intake is Associated with a Major Reduction in IGF-1, Cancer, and Overall Mortality in the 65 and Younger but Not Older Population](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988204/) | *Cell Metabolism* (ME Levine *et al.* 2014) | [2:01:45]

**Deletion of** ***daf-2*** **in** ***C. elegans*** **doubles lifespan**: [A *C. elegans* mutant that lives twice as long as wild type](https://pubmed.ncbi.nlm.nih.gov/8247153/) | *Nature* (C Kenyon *et al.* 1993) | [2:07:30]

**Targeting IGF-1 receptor with a monoclonal antibody late in life improves lifespan and health span of mice**: [Late-life targeting of the IGF-1 receptor improves healthspan and lifespan in female mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6008442/) | *Nature Communications* (K Mao *et al.* 2018) | [2:09:15]

**Valter Longo’s study of people in Ecuador who have mutations in the growth hormone receptor gene**: [Growth Hormone Receptor Deficiency is Associated With a Major Reduction in Pro-aging Signaling, Cancer and Diabetes in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/) | *Science Translational Medicine* (J Guevara-Aguirre *et al.* 2011) | [2:17:00]

**Matt’s website**: [Our Science](https://kaeberlein.org/our-science/) | kaeberlein.org (2022)

**The Healthy Aging and Longevity (HALO) Research Institute at the University of Washington**: [UW Healthy Aging and Longevity Research Institute](https://halo.dlmp.uw.edu/) | UW Medicine (2022)

**UW Nathan Shock Center of Excellence in the Basic Biology of Aging**: [UW Nathan Shock Center](https://halo.dlmp.uw.edu/uwhalo/nsc/) | UW Medicine (2022)

§

## People Mentioned

- [David Sabatini](https://www.davidmsabatini.com/research) (expert in the mTOR pathway and mechanisms that regulate growth and how these are altered in diabetes and cancer) [5:30, 1:51:00]
- [Tim Ferris](https://tim.blog/about/) (Best selling author, expert on habits, and an early-stage technology investor/advisor) [14:00]
- [Lane Norton](https://biolayne.com/about/) (Physique coach and natural bodybuilder with a PhD in nutritional science) [15:00]
- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) (Expert in obesity research and nutritional epidemiology, Dean of the Indiana University School of Public Health) [15:45]
- [David Sinclair](https://sinclair.hms.harvard.edu/people/david-sinclair) (Professor of genetics and co-Director of the Paul F. Glenn Center for Biology of Aging Research at Harvard Medical School) [28:30, 43:00]
- [Rozalyn (Roz) Anderson](https://andersonlab.medicine.wisc.edu/anderson-rozalyn/) (Professor of Medicine & Director of Metabolism of Aging Program at the University of Wisconsin-Madison) [1:01:15]
- [Herman Pontzer](https://globalhealth.duke.edu/people/pontzer-herman) (Professor of Evolutionary Anthropology and Global Health at Duke University) [1:04:00]
- [Alessandro Beto](https://dlmp.uw.edu/faculty/bitto) (Postdoc with Matt) [1:15:00]
- [Mitchell Lee](https://www.linkedin.com/in/mitchell-lee-54296143) (Matt’s former graduate student, CEO & Co-Founder Ora Biomedical, Inc.) [1:15:00]
- [Crystal Hill](https://www.pbrc.edu/research-and-faculty/postdocs/Hill-Cristal-PhD.aspx) (Postdoc researcher of neurosignaling at the Pennington Biomedical Research Institute) [1:15:00]
- [Richard (Rick) Weindruch](https://experts.news.wisc.edu/experts/richard-weindruch) (Professor of medicine, geriatrics and gerontology at University of Wisconsin-Madison) [1:22:00]
- [Roy Walford](https://roy.walford.com/) (Gerontology researcher at UCLA and advocate of caloric restriction) [1:22:00]
- [Valter Longo](https://www.longolab.org/) (Professor of Gerontology and Biological Sciences at UCS) [1:22:30, 2:01:45]
- [Oliver Hahn](https://www.linkedin.com/in/oliver-hahn-ph-d-2363b3141) (Postdoctoral fellow investigating aging and longevity in the [Wyss-Coray Lab](https://web.stanford.edu/group/twclab/cgi-bin/people.html) at Stanford University)  [1:33:15]
- [Steven Spindler](https://stemcells.ucr.edu/stem-cell-center/faculty/stephen-spindler) (Expert in CR, Professor of Biochemistry at UC Riverside) [1:35:45]
- [Richard Miller](https://www.richmillerlab.com/biog) (Professor of Pathology at the University of Michigan, expert on aging) [1:38:15]
- [David Sharp](https://www.einsteinmed.edu/faculty/7486/david-sharp/) (Professor of Molecular Pharmacology and Neuroscience and Ophthalmology at Albert Einstein College of Medicine) [1:39:15]
- [Randy Strong](https://www.uthscsa.edu/academics/medicine/profile/strong)  (Professor of Pharmacology at UT Health San Antonio Texas and Director of the NIA Aging Interventions Testing Center) [1:39:45]
- [David Sabatini](https://www.davidmsabatini.com/research) (co-discoverer of mTOR) [1:51:00]
- [Robert (Bobby) Saxton](https://www.linkedin.com/in/robert-saxton-98b4bb72?original_referer=https%3A%2F%2Fwww.google.com%2F) (co-first author on paper identifying leucine sensor for mTOR pathway) [1:51:15]
- [Stephen Simpson](https://www.sydney.edu.au/research/our-researchers/academic-staff/stephen-simpson.html) (Professor and Academic Director of Life and Environmental Sciences at the University of Sydney) [1:55:45]
- [Morgan Levine](https://altoslabs.com/team/principal-investigators-san-diego/morgan-levine/) (Founding Principal Investigator in the Altos lab at the San Diego Institute of Science) [2:01:45]
- [Cynthia Kenyon](https://profiles.ucsf.edu/cynthia.kenyon) (Professor of Biochemistry and Biophysics at UCSF) [2:07:30]
- [Thomas Johnson](https://www.colorado.edu/iphy/people/faculty/thomas-e-johnson) (Professor of Integrative Physiology at the University of Colorado Boulder) [2:07:30]
- [Nir Barzilai](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) (Director of the Institute for Aging Research at Albert Einstein College of Medicine) | [2:09:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/09/bio-pic-mattK.jpeg)

##### Matt Kaeberlein, Ph.D.

Matt Kaeberlein, Ph.D., is a Professor of Pathology, Adjunct Professor of Genome Sciences, and Adjunct Professor of Oral Health Sciences at the University of Washington. His research interests are focused on basic mechanisms of aging in order to facilitate translational interventions that promote healthspan and improve quality of life. He has published nearly 200 papers in top scientific journals and has been recognized by several prestigious awards, including a Breakthroughs in Gerontology Award, an Alzheimer’s Association Young Investigator Award, an Ellison Medical Foundation New Scholar in Aging Award, a Murdock Trust Award, a Pioneer in Aging Award, and the Vincent Cristofalo Rising Star in Aging Research. His contributions have also been recognized with Fellow status in the American Association for the Advancement of Science, the American Aging Association, and the Gerontological Society of America. Dr. Kaeberlein is a past President of the American Aging Association and has served on their Executive Committee and Board of Directors since 2012. He has also served as a member of the Board of Directors for the Federation of American Societies for Experimental Biology and is currently the Chair of the Biological Sciences Section of the Gerontological Society of America. Dr. Kaeberlein serves on the editorial boards for several journals, including Science and eLife. Dr. Kaeberlein’s scientific discoveries have generated substantial public interest, with featured stories in major media outlets including appearing on the front page of the New York Times, the Today Show, CNN, the UK Telegraph, Popular Science, Time Magazine, Scientific American, NPR, USA Today, National Geographic, and many others. In addition to his primary appointments, Dr. Kaeberlein is the founding Director of the [Healthy Aging and Longevity Research Institute](https://halo.dlmp.uw.edu/uwhalo/basic-biology-of-aging/) at the University of Washington, the co-Director of the [University of Washington Nathan Shock Center of Excellence in the Basic Biology of Aging](https://halo.dlmp.uw.edu/uwhalo/nsc/), and founder and co-Director of the [Dog Aging Project](https://dogagingproject.org/). [[kaeberleinlab.org](https://kaeberlein.org/)]

Facebook: [Matt Kaeberlein](https://www.facebook.com/matt.kaeberlein)

Twitter: [@mkaeberlein](https://twitter.com/mkaeberlein?lang=en)