# #287 ‒ Lower back pain: causes, treatment, and prevention of lower back injuries and pain | Stuart McGill, Ph.D.

**Source:** [https://peterattiamd.com/stuartmcgill/](https://peterattiamd.com/stuartmcgill/)

---

Stuart McGill is a distinguished professor emeritus at the University of Waterloo and the chief scientific officer at [Backfitpro](https://www.backfitpro.com/about-us/) where he specializes in evaluating complex cases of lower back pain from across the globe. In this episode, Stuart engages in a deep exploration of lower back pain, starting with the anatomy of the lower back, the workings of the spine, the pathophysiology of back pain, and areas of vulnerability. He challenges the concept of nonspecific back pain, emphasizing the importance of finding a causal relationship between injury and pain. Stuart highlights compelling case studies of the successful treatment of complex cases of lower back pain, reinforcing his conviction that nobody needs to suffer endlessly. He also covers the importance of strength and stability, shares his favorite exercises to prescribe to patients, and provides invaluable advice for maintaining a healthy spine.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/stuartmcgill/the_Drive_public.png)

Play

#287 ‒ Lower back pain: causes, treatment, and prevention of lower back injuries and pain | Stuart McGill, Ph.D.

#287 ‒ Lower back pain: causes, treatment, and prevention of lower back injuries and pain | Stuart McGill, Ph.D.

1x15s30s

0:002:35:47

## We discuss:

- Peter’s experience with debilitating back pain [A: 3:30, V: 0:30];
- Anatomy of the back: spine, discs, facet joints, and common pain points [A: 14:45, V: 14:11];
- Lower back injuries and pain: acute vs. chronic, impact of disc damage, microfractures, and more [A: 24:45, V: 24:48];
- Why the majority of back injuries happen around the L4, L5, and S1 joints [A: 31:00, V: 31:30];
- How the spine responds to forces like bending and loading, and how it adapts do different athletic activities [A: 36:15, V: 37:20];
- The pathology of bulging discs [A: 43:15, V: 45:12];
- The pathophysiology of Peter’s back pain, injuries from excessive loading, immune response to back injuries, muscle relaxers, and more [A: 46:00, V: 48:30];
- The three most important exercises Stuart prescribes, how he assesses patients, and the importance of tailored exercises based on individual needs and body types [A: 56:15, V: 59:36];
- The significance of strength and stability in preventing injuries and preserving longevity [A: 1:08:15, V: 1:12:46];
- Stuart’s take on squats and deadlifting: potential risks, alternatives, and importance of correct movement patterns [A: 1:19:30, V: 1:25:33];
- Helping patients with psychological trauma from lower back pain by empowering them with the understanding of the mechanical aspects of their pain [A: 1:30:00, V: 1:37:08];
- Empowering patients through education and understanding of their pain through Stuart’s clinic and work through BackFitPro [A: 1:39:00, V: 1:46:59];
- When surgical interventions may be appropriate, and “virtual surgery” as an alternative [A: 1:46:45, V: 1:56:08];
- Weakness, nerve pain, and stenosis: treatments, surgical considerations, and more [A: 1:55:30, V: 2:05:48];
- Tarlov cysts: treatment and surgical considerations [A: 2:00:15, V: 2:11:21];
- The evolution of patient assessments and the limitations of MRI [A: 2:02:15, V: 2:13:34];
- Pain relief related to stiffness and muscle bulk through training [A: 2:07:00, V: 2:18:40];
- Advice for the young person on how to keep a healthy spine [A: 2:14:15, V: 2:26:49];
- Resources for individuals dealing with lower back pain [A: 2:25:30, V: 2:39:24]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Stuart McGill holds the title of professor emeritus at the University of Waterloo, where he has dedicated 40 years of overseeing his laboratory and research clinic dedicated to advancing the understanding of back pain
- Currently he serves as the chief scientific officer of [BackFitPro](https://www.backfitpro.com/) where he specializes in evaluating complex cases of lower back pain from across the globe
- He has authored 245 scientific articles and multiple textbooks
- Peter wanted to have Stuart on for the obvious reason that very few people listening to this will have *not* had their lives impacted by lower back pain
  - Even if it’s just a short bout that lasts for only a few days
  - Sadly, many of you have had far greater impact
    - Perhaps lower back pain has plagued you for many years
- In this episode we do a deep dive into all things that pertain to lower back pain
- We begin by discussing
  - The anatomy of the lower back
  - How the spine works
  - The pathophysiology of back pain
  - Where people can have issues as it relates to their back
- We talk about why Stuart believes there’s no such thing as nonspecific back pain, and why he is so adamant about finding a causal relationship between an injury and pain
  - A physical reason for the pain
  - Not necessarily an acute injury that resulted in it
- Ultimately, we talk about why people who are experiencing back pain should be empowered to do something about it
- Stuart really believes that nobody should suffer endlessly because of back pain
- Peter is very excited about this episode because he knows, even just looking at the relatively small sample population of his patients, that this is a topic that many people will find value in
  - And if you’re not finding value in it today, it might be a podcast you want to come back to when you do experience lower back pain
    - Though he hopes that never happens
- Lastly, this is an episode where Stuart shows off a variety of models and positions to better explain what we’re covering in the conversation
  - While the show notes will have all of the images, this may be an episode you want to watch on video

## Peter’s experience with debilitating back pain [3:30]

**Stuart read Peter’s book [**[***Outlive***](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1702317286&sr=8-1)**] and changed his behavior**

- A few years ago, Stuart’s family doctor (who is one of his former students) did his blood work, and found he was just on the edge of needing [Crestor](https://en.wikipedia.org/wiki/Rosuvastatin) or [Lipitor](https://en.wikipedia.org/wiki/Atorvastatin)
  - His physician suggested, “*Let’s run the experiment,*”
  - Stuart loves to work hard physically and finish it off with a beer, which 6 days out of 7, he’s denying himself of that
- Long story short, the experiment paid off, and he’s sleeping a little better and is a little more mentally sharp
- Peter thinks maybe he doesn’t have to be quite as restrictive
  - He doesn’t necessarily believe in denying all the pleasures of life

**Why the topic of biomechanics for a healthy back is of great interest to Peter**

- The very abridged version of the story is Peter grew up doing all sorts of really aggressive things and really took to powerlifting when he was about 14
  - He found himself reasonably strong for a little scrawny kid
  - Between about the ages of 14-19, he really pushed
    - He couldn’t bench press to save his life, but seemed pretty strong in a squat and deadlift
    - He ignored any claims his parents made that maybe he was doing a little too much
- Truthfully, Peter had no formal instruction
  - He was just watching the other grown men in the gym who were insanely powerful and trying to replicate what they were doing
  - Peter had no sense of what he was doing
- Fast-forward to age 21, and he’s rowing crew, and for the first time in his life he experienced lower back pain
  - This really rocked his world, because he always thought that people who got lower back pain were people who did nothing
  - He never thought that someone who was as active as he was could get it
- For about 2 weeks, the back pain completely disabled him
  - He could barely get around
  - As a college student, he didn’t really have any resources and didn’t know what to do
  - This was in the summer, so he didn’t have classes, but he had to stop rowing
    - Otherwise he was able to work
- The back pain went away and he thought everything was fine
  - He never thought about it again until the summer 3 years later, when he was 24 years old
- He was in San Diego riding his bike up the steepest hill, a patch of mountain called Mount Soledad
  - There’s a section of this thing where you make a sharp right turn, and at that moment it’s about a 25 degree pitch
  - Peter experienced this very sudden pain in his lower back and like a typical idiot, just kept on pushing and climbing to the top and finished the ride
- But then went on to experience the exact same thing: for two weeks he was debilitated and couldn’t do a thing other than lay around and walk, but then it got better and he just forgot all about it
- Fast-forward to the big one
  - This occurred in Peter’s 3rd year of medical school
  - He’s now 27 years old, and the remarkable consistency of this is not lost on him
    - It is every 3 years by the summer, the summer of ‘94, ‘97 and 2000
  - He’s riding his bike from class to the gym, he gets to the gym, hops off his bike to lock it up, and all of a sudden he feels that same familiar, horrible pain in his back
- But this time it’s a little worse than the previous 2 bouts
  - It was so bad that he did something he’d never done before: he decided not to go into the gym
    - He just slowly got back on the bike and limped his way back to his apartment and wasn’t able to do anything other than just lay in bed
- He assumed he’d be fine the next morning and he woke up the next morning and actually couldn’t get out of bed
- Luckily, Peter and his roommate each had separate phone lines, so Peter was able to call him from his room
- So began a really painful journey over the next couple of weeks where the only place he could find relief was bent at 90-degrees forward, where he would basically stand and bend over the nurses station
  - By this point, he was doing clinical rotations and as every good, gunning medical student knows, there was no way he was going to miss a day
  - He would drag himself to the hospital each day and somehow manage to get through
- The nurses and residents took pity on him, and they were injecting him full of [Toradol](https://en.wikipedia.org/wiki/Ketorolac)
  - This went on for a month
- It got so bad that eventually the pain progressed from just being debilitating in his lower back to a nerve pain that felt like his foot was being skinned
  - It was interesting in that the pain in his lower back started to subside as it was replaced by the feeling of his left foot being skinned from the bottom
- This story gets worse and worse before getting better, but needless to say, Peter has a graduate degree in back pain
- There is a happy ending to this story, which is after this bout (which took a year to resolve), he made it a mission to figure out what was going on
- Fortunately, any time he’s had back pain since then, it has been a very, very short-lived experience

**Peter plants one last seed that we can come back to before we jump into this**

- If a reasonable person were to look at an MRI of Peter’s spine today at age 50, you would say, “*How does he walk? This person must be in so much pain he doesn’t know his name.*”
- But for the most part, Peter is not in pain at all
  - Occasionally, he gets a little tight in his lower back, but he doesn’t have radicular pain
- He’s not limited in anything he does

***This suggests that the correlation between the image of his back on an MRI and his symptoms is pretty light***

- Peter adds, “*The fact that you’re smiling so much as I tell you this story tells me not that you’re taking pleasure in my pain, but rather the familiarity of my story.*”
- Exactly, Stuart has been doing pattern recognition

**There’s only one thing that would account for the repeated acute episodes**

- Stuart recognizes that in the interim between each episode, Peter was quite fine
- Then it shifted to a ridiculous pain and now he’s at the stage of life where it’s more an occasional grumpiness when he crosses what we call the “tipping point”
- Stuart asks, “*Did the pain go to your foot, Peter?… Big toes or little toes?*”
  - Yes, it was burning pain that was like the bottom of the foot was being skinned
- There’s one detail Peter should have shared that might explain this: when he finally had surgery, it turned out that he had a free fragment that was about 5 cm long from the L5 S1 disc
  - That free fragment had broken off
  - Stuart was going to guess this
    - He was going to ask which foot
    - The 5th route goes to your big toe
  - The unbearable pain Peter was having presumably was because that free fragment was parked on the [S1](https://en.wikipedia.org/wiki/Sacral_spinal_nerve_1) [nerve root](https://en.wikipedia.org/wiki/Spinal_nerve#')
    - Even though it ended up taking 2 surgeries to get that out, and those surgeries ended up causing more damage that needed more repair (that turned into a journey of 1000 cuts)
    - He was on the road to recovery
    - The radicular pain seemed to be directly a result of the S1 nerve root
- Stuart is smiling because Peter told him exactly what the pain mechanism was
  - He knew it was a disc switch an open fissured disc bulge
  - It would be on the side of his foot, right or left
- Stuart asks, “*What foot was it?*”
  - It was the left

**Stuart explains, “*****You had a posterior left-sided, biased open, fissured disc bulge that would open and close as a function of the flexion postures bending down to lock your bicycle.*****”**

- Before we get into the mechanisms, let’s walk through the anatomy of the back

## Anatomy of the back: spine, discs, facet joints, and common pain points [14:45]

- Peter remarks, “*You could almost argue it’s a miracle we don’t get more injured even though the frequency with which we do is intense*.”
- Stuart would almost argue the opposite
- There was a TV show where they asked various experts around the world, “*If you got to re-engineer your particular area… How would you re-engineer it and make it better?*”
  - Stuart was the spine guy, and they had a cardiac person, an endocrine person
  - Every expert said they couldn’t, it was perfect
    - Every system in your body comes with a trade-off, and there are rules that manage that trade-off

**The spine**

- This spine is a series of vertebrae forming a flexible rod
- This allows us to dance and move and procreate, tie our shoes, and do all of these wonderful things
- But at some point now, say are picking your child out of the crib, you reach across the crib, gather your child, pull them in
  - If you had a flexible rod (consider a series of stacked oranges) it would fall apart
  - You need a flexible rod that you can then stiffen to bear load
    - You cannot push rope, but you can push stone, or in this case an I-beam to bear load

***All of these things [a flexible rod that can stiffen to bear load] are necessary to have a functional spine***

**The structure of the discs [intervertebral discs]**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f1-stuartmcgill.png)

**Figure 1. Anatomy of a normal intervertebral disc**. Image credit: [Miami Neuroscience Center](https://miamineurosciencecenter.com/en/conditions/herniated-disc/)

![](https://peterattiamd.com/wp-content/uploads/2024/01/f2-stuartmcgill.png)

**Figure 2. A section of the spine showing multiple vertebrae**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Vertebra)

- Let’s look at the structure of the discs, which are the fabric
- The disc actually forms the subcategory of a biological fabric
- It’s not a ball and socket joint
- Could you imagine if we had vertebrae with ball and socket joints?
  - You would need an enormous musculature around that flexible rod to control all the balls and sockets
  - You would need an enormous motor cortex to coordinate all of these
  - You would be so wide, you couldn’t walk, you couldn’t run, etc.
- We have this very slender torso because we have discs
- The **stress strain curve** of a disc starts out with a little bit of a neutral zone in the neutral range
- As you approach the end range, the disc provides stiffness, a mechanical stop to motion
  - Fabulous, you didn’t need all this complex musculature to do so
- The disc creates tremendous evolutionary efficiency in your spine
- Either end of the torso strategically is a ball and socket joint
- The ball and socket joints of the hips and shoulders are designed to create power
- Power is force x velocity
- If you were to watch a sprinter sprint, the extensor muscles explode like a hammer hitting a stone, a stiffened structure
  - If they hit rope, the hips would bulge and you couldn’t run anywhere
  - You can’t even walk without sufficient stiffness in the core

***In terms of anatomy, we have a flexible disc that is a fabric, and the great advantage is the efficiency of your dimensions: we’re light, narrow in the waist, we can run, etc.***

**The price that you pay though is being a structure of many collagen fibers**

- Consider Stuart’s shirt, which is a fabric
  - If you wanted to delaminate the fibers, you would have to create stress strain reversals back and forth and slowly you would de-bond the fibers

*This is what happens to people’s discs*

- They de-bond the fibers with too much load and motion simultaneously
- This is what Peter must have done as a younger fellow
- The concentric rings of collagen that are held together with [collagen-type X](https://en.wikipedia.org/wiki/Collagen#Human_types) (the binding substance)
  - They hold a pressurized gel, which is this incompressible hydraulic fluid that creates the ball
  - That gets pressurized, but it’s always seeking the weakness in the wall
- If you delaminate the collagen fibers, then the [nucleus](https://en.wikipedia.org/wiki/Intervertebral_disc) seeps through
  - In some situations, the fibers are pulled together and they create a fragment (as Peter described earlier), or if it’s an open fissure and contained underneath the posterior longitudinal ligament, there’s a good chance it’s going to get vacuumed back in and off you go over another 2 or 3 years

**Nerves of the spine**

- If you have a disc bulge, there is the spinal cord centrally behind the vertebra and at each lumbar or spinal joint is a pair of nerve roots [shown in yellow in the figure above]

**Peter asks about the point of fixation, which are the facet joints**

*If anteriorly, this structure is bounded and the vertebral bodies are stuck together through their sharing of the discs on the back, we have these other joints that come from each of them called these* [*facet joints*](https://en.wikipedia.org/wiki/Facet_joint)

![](https://peterattiamd.com/wp-content/uploads/2024/01/f3-stuartmcgill.png)

**Figure 3. Facet joint articulation between two vertebrae highlighted**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Facet_joint)

![](https://peterattiamd.com/wp-content/uploads/2024/01/f4-stuartmcgill.png)

**Figure 4. Facet joints of the spine**. Image credit: [HealthCentral](https://www.healthcentral.com/condition/spondylolisthesis/pars-fractures)

- Stuart uses a model to explain, “*The facet joints are guiding of motion. You can see as I’m flexing and extending and twisting this model spine, these are articular joints in the back that are guiding motion.*”
- If Stuart were to look at Peter’s MRI at the level of the disc bulge, the facet joints will now be getting a little thicker, a bit more gnarly looking

***Almost always, 2-3 years after a major disc injury, the facets take on much more load***

**Analogy: think of air in your car tire**

- If you let a little air out of your car tire it bulges on the road, it gets a bit sloppy to drive your car
  - You have to tune the pressure

***This is exactly what happens with your body: when you lose the controlling stiffness of the disc, you get more work performed on the facet joints and they wear a little bit faster than the adjacent joints, and they grow thicker***

**Facet pain is very different from disc pain: it’s more of a ache**

- It comes on a bit more slowly
- If you have a wound up facet joint, it can take 2 or 3 months to wind it down versus a disc that can wind down in a couple of weeks

**Looking at the model now**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f5-stuartmcgill.png)

**Figure 5. Spinal column vertebrae**. Image credit: [Johns Hopkins Medicine](https://www.hopkinsmedicine.org/health/treatment-tests-and-therapies/facts-about-the-spine-shoulder-and-pelvis)

- This bottom disc, L5 is normal
- L4 has been damaged. I’m just going to apply a torque to this spine
- Stuart asks, “*Do you see how the majority of the motion now is occurring at the joint that’s lost stiffness?*”
- Think of it like a knee that has a damaged ACL ligament
  - It no longer has the guidance and the rotation motion of the knee which is normal
  - It now substitutes with shearing motion
    - Shearing motion indicates it’s the metric for instability
    - Now you can see the shearing instability
- Now look at the work being performed by the facet joints at the level of the disc being damaged and losing stiffness
  - Now those will get grumpy and they will wear a little bit faster if you continue with the behavior that you did prior to
- Injury and this cascade changes the rules a little bit
- Initially, the goal was to create power in the shoulders and the hips and transfer it through a controlled spine, but now the game has changed a little bit
- Peter is 50 years old and will have a little bit of joint instability

***It’s more important now to create a muscular girdle around the joint that has lost a bit of stiffness and for the next little while do your core exercises, develop a bit more muscular control, arrest the shearing motions***

- Stewart remarks, “*You and I are very similar, by the way. I’m in my late 60s now, my pain is gone, so the joint has become so stiff, I can still do everything I want to do, but the joint itself has stiffened up.*”
- [Professor Kirkaldy-Willis](https://journals.lww.com/spinejournal/citation/2006/08150/in_memoriam__a_tribute_to_william_kirkaldy_willis,.3.aspx), the famous Canadian spine surgeon, wrote a book called [*Managing Low Back Pain*](https://www.amazon.com/Managing-Back-Pain-William-Kirkaldy-Willis-dp-044307948X/dp/044307948X/ref=dp_ob_title_bk)
- He described very well the process that most of us go through, the instability, and the very acute episodes that come every two or three years that are very debilitating to a muscular ache
  - You wake up in the morning on one side with this ache in your back, but if you push one heel away or put a pillow under your waist or something like that, you can get rid of the ache
  - Then if you live a little bit longer and behave by the new rules

> “*I don’t have any back pain. I can encourage that you’ll seek that relief as well*.”‒ Stuart McGill

## Lower back injuries and pain: acute vs. chronic, impact of disc damage, microfractures, and more [24:45]

**Give us a sense of the prevalence of acute lower back pain episodes**

*Is an acute lower back pain episode defined as one that lasts up to some period of time? Two weeks or something like that?*

- No, Stuart doesn’t define it that way at all
- He’s not the guy who can give you those statistics
  - He’s not doing population studies to track incidence
- All he worries about is the people who come and ask for help with their back pain
- As a younger scientist, he used to study: What is back pain? What is an acute episode?
  - Is it sufficient to be debilitating so you don’t have to work?
    - He was a professor and could have an acute attack and go to work, but if he was a construction work, he couldn’t
- Even the definition of whether it was disabling or not gets lost so Stuart didn’t really get into those statistics
- He doesn’t categorize pain as being *acute* lasting a certain period of time, and *chronic* lasting a longer period of time, because when we measure people with back pain, ***very rarely do we find chronic back pain***
- It’s almost always due to them repeatedly insulting their back with many acute attacks and offenses all day long
- They think they have chronic pain because it lingers
- When we show them a strategy or whatever the treatment happens to be, to stop the insults that occur throughout the day, all of a sudden their pain goes and then they realize, “*I never did have chronic back pain*.”

**How chronic back pain is different from what most people experience**

- Chronic back pain is pain that is intransigent, unrelenting
  - Their brains have changed, they’ve been traumatized
- Chronic pain does not always having a strong mechanical trigger
- The pattern that Peter described of the 2-week disabling, terribly disabling pain, there’s only one thing that that could be: an open fissure disc bulge

**The mechanism of disc comfort**

- Peter asks, “F*or example, is that disc actually innervated? Is the pain that’s being perceived due to sensory fibers of the disc or is it the response of the body sensing that damage, going into some protective mechanism that is seizing all the muscles within the proximity of it?*”
- It could be either or it could be both
- By the way, Stuart explains, “*All these models that I’m using, the highly bio-fidelic models are made by* [*Dynamic Disc Designs*](https://dynamicdiscdesigns.com/).”
- When a disc is healthy, people say, “*Well, what’s the number one thing you can do to keep a healthy spine?*”
  - Stuart tells them “*Keep your end plates healthy*,” and they wonder about that
    - Don’t damage your joints
    - Stuart clarifies by email that the vertebral end plates are the top and bottom of the vertebrae
    - [The 1st figure below shows the anatomy of the vertebral column, the vertebral body (circled) make contact with the intervertebral discs via the endplates that Stuart refers to; the end plates are marked with an asterisk]
    - [The 2nd figure below shows a damaged end plate]

![](https://peterattiamd.com/wp-content/uploads/2024/01/f6-stuartmcgill.png)

**Figure 6. A section of the spine showing multiple vertebrae**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Vertebra)

![](https://peterattiamd.com/wp-content/uploads/2024/01/f7-stuartmcgill.png)

**Figure 7. A damaged end plate from a vertebrae**. Image credit: [*Back Mechanic*](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1)

- Stuart refers to Peter’s book and explains that if you damage your knee ligaments, you’ll now have disabled mobility in your last decade
  - The same is true with the spine
- Stuart points out in the model, “*If you can look into the nucleus of this model, you’ll see that there are red vessels and yellow nerves.*”
- Different papers will say different things:
  - There’s no nerves inside the disk
  - There are nerves in the outer third
  - There are nerves all the way through
- Stuart explains why this is: a healthy virgin disc doesn’t have any vascular tissues going into it, nor does it have any nerves
  - The reason is when you squeeze a disc, you build up tremendous intradiscal pressure that kills any kind of vascular sprouts or neural sprouts
    - It’s a healthy environment containing the pressure

***When you damage the disc and you lose the ability to contain the high pressure, now all of a sudden vascular sprouts grow in and so do nerves***

- It’s so unfair ‒ you damage the disc and now the body grows a hardware, more nerves to feel pain even more
- Then eventually, this just goes to a very fibrous, gnarly structure, highly innervated
  - But now it just basically wrestles to bone and all the pain goes away
- But you can see the damage line, the contrast there
  - You can see those fibers posterior laterally on the right that have delaminated
- Stuart squeezes the discs (he’s going to squeeze and flex)
  - Do you see the fibers delaminating and allowing the nucleus to seep out?
    - [the 1st figure below shows where the nucleus is in the intervertebral disc]
    - [The 2nd figure below shows 2 vertebrae with a disc between them and damage causing the nucleus to seep out]
    - By email Stuart explains that this 2nd figure shows microfractures of the end plate that occur with an overload of compressive force

![](https://peterattiamd.com/wp-content/uploads/2024/01/f8-stuartmcgill.png)

**Figure 8. Anatomy of a vertebral joint with the intervertebral disc and nucleus illustrated in blue**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Intervertebral_disc)

![](https://peterattiamd.com/wp-content/uploads/2024/01/f9-stuartmcgill.png)

**Figure 9. A vertebral joint and type of damage that can occur**. Image credit: [*Back Mechanic*](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1)

**Here’s the antidote**

- Stay stacked and tall
- Stuart squeezes the model, the whole disc bulges in a diffuse bulging pattern, but nothing comes out of the delaminated region

**There’s a little bit of an explanation of why some studies will show an innervated disc and other shows they’re not innervated at al**l

- Think of where you get cadavers from
  - It’s not young, healthy people dying and donating their body
  - It’s almost always older people
- Those discs are innervated, unless they’re horribly down the cascade and they’ve grisled, and all the nerves have now disappeared once again
  - Peter was totally unaware of this adaptation ‒ it’s very cruel and quite counterintuitive

## Why the majority of back injuries happen around the L4, L5, and S1 joints [31:00]

**What is it about the way we interact with the world and the curvature of our spine that tends to produce the majority of injuries at either the interface between L4 and L5, or the interface between L5 and S1?**

- First of all, it’s the thickest part of the spine
- If Stuart was to take a thin willow branch and bend the willow branch back and forth: no stress

![](https://peterattiamd.com/wp-content/uploads/2024/01/f10-stuartmcgill.png)

**Figure 10. Spinal column vertebrae**. Image credit: [Johns Hopkins Medicine](https://www.hopkinsmedicine.org/health/treatment-tests-and-therapies/facts-about-the-spine-shoulder-and-pelvis)

**Tissues damage because of one metric, and it’s strain**

- Not the force supplied, not the pressure
- It’s just strain on the tissue; that is the metric of when it’s going to disrupt
- The radial distance to the neutral axis is thin
  - This is the axis down the middle of that thin rod that doesn’t go into compression or tension, it’s all very low
- Now let’s take a thicker stick and we bend it and it shatters right away, because it’s much thicker

**Structures can be flexible or good at bearing compression, but not both**

- Go back to the flexible willow branch: it’s wonderful at bending
  - But don’t ask it to bear compression, because it buckles right away
- The thicker stick can bear tremendous compression, but it doesn’t tolerate bending.
- Look at the neck, very thin, small diameter vertebra
  - It’s made for bending and mobility, fabulous

***But as you move down the spine and get to the bottom two where the thickest is, they do not tolerate bending near as much as they tolerate compression***

- There’s the first anatomic feature that describes why the bending stresses are greatest at the thicker two joints, which are at the bottom

**The other things that matter are the shape of the disc**

- Some discs are ovoid and the bigger the skeleton, they tend to go to a [limacon](https://en.wikipedia.org/wiki/Lima%C3%A7on)
- You have the spinal cord there, and then the two lobes of the limacon
- The bigger the spine, the more limacon the disc becomes

***When you twist a limacon, you create a stress riser on the edge of each lobe***

- The bigger the person, you will see they don’t tolerate sit-ups
  - Look at YouTube: who is the man who has the world record for consecutive sit-ups?
    - Do you think he has a thick spine or a thin spine?
    - He won’t be a powerlifter
- Stuart has worked with some fabulous powerlifters and strongmen and competitors, and not one of them does a sit-up
  - They train other things to tune their body and make it suitable to that particular training stimulation

***We see that shape and thickness determines why L4 and L5 are the target***

- We know that they don’t twist as well as a slender spine

**The facet joints are also very interesting**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f11-stuartmcgill.png)

**Figure 11. Facet joints of the spine**. Image credit: [HealthCentral](https://www.healthcentral.com/condition/spondylolisthesis/pars-fractures)

- Some facet joints are orientated like that in the sagittal plane, while others are orientated more open as we say

*If you look at a gymnast*

- Stuard would never choose to be a gymnast, but you can tell, look at his facets, they’re closed
  - He doesn’t twist very well
- When you flex forward and pull a load, those facet joints just glide past one another
- A gymnast by definition is someone who has a lot of mobility in their spine
  - You will see that their facet joints tend to be open

*What patients get* [*spondylolisthesis*](https://en.wikipedia.org/wiki/Spondylolisthesis) *(the broken* [*pars bone*](https://en.wikipedia.org/wiki/Pars_interarticularis) *that holds the facet joint on)? [shown in the figures below]*

![](https://peterattiamd.com/wp-content/uploads/2024/01/f12-stuartmcgill.png)

**Figure 12. Location of the pars interarticularis bone**. Image credit: [Spines Dorset LTD](https://spinesdorset.com/conditions/pars_defect)

![](https://peterattiamd.com/wp-content/uploads/2024/01/f13-stuartmcgill.png)

**Figure 13. Pars fracture and slippage of vertebral bodies**. Image credit: [RecoverPhysio](https://www.recoverphysiohastings.co.uk/what-we-treat/spondylolysis/)

- You are going to say, dancers, gymnasts, the very people that had the mechanical advantage to twist
- Now when they go into extension, their facet joints are like shingles on a roof
  - They bend the pars bone creating stress strain reversals, and eventually that bone will get a stress fracture or a stress reaction
    - And if they keep going, full-blown spondylolisthesis

***There are all kinds of reasons, Stuart is just giving a few now as to why those two discs are really stress risers***

- In his Ph.D. thesis, Stuart developed a very detailed anatomical model of the spine
  - A computer model that hit home loud and clear
- Stuart explains, “*We did stress maps of real people moving. The pain in the injury was almost always at the site of the highest stress.*”

***The metric strain that actually leads to damage, if it is below the tipping point, it actually strengthens you***

## How the spine responds to forces like bending and loading, and how it adapts do different athletic activities [36:15]

**For listeners that might not have a background in engineering, can you explain the difference between stress and strain and what happens under tensile load, compressive loads and things like that?**

- Let’s now talk about stress and strain
  - So stress and strain are normalized to an area, and we won’t’ get into that
- Let’s talk about **applied load** and **deformation**
- If you apply a force to a structure, it deforms
- Mature skeletal bone breaks at a certain amount of deformation
  - A child’s bone breaks at a different level of deformation
- When you take a long bone and you bend it, the upper surface goes into tension that’s trying to pull apart
  - The lower surface goes into compression

*Some biological structures are stronger in tension than they are in compression*

- A child is actually weaker in compression in a bending bone, and the adult is weaker on the tensile side
  - For example, a greenstick fracture (or a buckled bone) in a young child would be very rare to see in an adult

*The behavior of biomaterials when you load them and how they deform explains a lot of injuries*

- If you were to put Stuart on the witness stand (as people do occasionally) to explain, is the damage that we see in this MRI (or in the cadaver or whatever) consistent with this particular mechanical alleged scenario, yes or no?
  - That’s how we reconstruct that
  - Tissues, stress and strain, shear, bend, tensile, pull apart, etc.
  - And the deformation causes very specific types of damage

**Using concrete as an example**

- Concrete is so strong in **compression** and yet in **tension**, it is so weak that we need to come up with a hack
  - How can we use this material to allow it to be both strong in compression and tension?
- If you have a bridge made out of concrete and you’re driving on top of it, the bridge wants to deform
- Which means you’re putting the top in compression (which it *can* handle), but the bottom in tension (it *can’t* handle)
- So we put rebar in because the steel rebar is of course strong in tension
  - The saying is the whole purpose of concrete is to hold the rebar in place

*When you think about the spine*

- Take an axial load on the spine
- As Stuart pointed out, the **cervical spine** is not built for tolerating a big axial load
  - It’s designed more to provide movement
  - It’s a joint for great flexibility
- The **lumbar spine** (for all the reasons just explained) is really designed around taking a large compressive load and in the process it has sacrificed the mobility we have in the neck

**But now let’s talk about load in the context of flexion and extension, where you now do have within the disc, it’s not just pure compression**

- **Flexion** is bending forward, and **extension** is going back
- Now if you have an axial load in that position, which you could easily have if you’re deadlifting something or squatting something, any given disc, especially in that lower spine region can be under compression and tension at the same time

*Compare a deadlift to a yoga master*

- When Stuart gives a lecture to a group of radiologists they describe very well all the subcategories of disc bulges and disc deformations and that kind of thing, but they’ve never been taught what the **applied load** nor the **adaptation** was
- A deadlifter almost always gets a posterior disc bulge
  - A deadlifter is under tremendous compressive load, and if they say get to the bottom of where the hips run out of room, now the femur collides with the pelvis and thereafter the rotation takes place in their low back because the nucleus is under such enormous compressive pressure
  - Remember this model, Stuart had to bend it forward to get the nucleus to squirt back
    - So you’re creating a center of hydraulic effort posteriorly
- Now let’s consider a person who’s adapted their spine to do yoga

> “*This is why I say please never mix up deadlifts and yoga*.”‒ Stuart McGill

- If you adapt your spine to be very flexible, you adapt the [type X collagen](https://en.wikipedia.org/wiki/Collagen#Human_types) holding the [type I](https://en.wikipedia.org/wiki/Type_I_collagen) and [type II](https://en.wikipedia.org/wiki/Type_II_collagen) (the heavy grisly collagen and then the elastic collagen), all those fibers together
- A powerlifter wants them to be stiff and tough
  - They even wear an exoskeleton of a lifting suit to add even more stiffness and toughness
- But for the yoga master, that would be the kiss of death
  - They want nice, viable, flexible spines
  - They soften the ground substance holding the collagen together
  - So when they bend forward in contrast to the disc bulge going backwards, the front of the disc now buckles under compression
- Typically, when the powerlifter bends forward and crushes the disc bulge posteriorly
- But when the yoga person (or a person with a very flexible spine) bends backwards, the collagen under compression buckles

***So one gets a disc bulge from extension and the other gets a disc bulge from flexion***

- Isn’t that interesting?
- And it all depends on how they’ve adapted their spine
- Stuart’s final point in all of that is, “***Don’t mix up the adaptation schedules. If you want to be a powerlifter, train your hip mobility, shoulder mobility, but torso stiffness, trying not to throughout the day do a lot of bending versus the yoga master, please stay away from the very heavy loads*****.**”

## The pathology of bulging discs [43:15]

**What is the pathologic response to the anterior bulging of the disc?**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f15-stuartmcgill.png)

**Figure 14. Comparing a bulging disc, a herniated disc, and a free fragment of a herniated disc**. [Image credit: Miami Neuroscience Center](https://miamineurosciencecenter.com/en/conditions/herniated-disc/)

- Peter explains that when you have that **posterior bulge**… the spinal cord stops quite high up
  - The spinal cord does not run down the entire canal
    - It stops around L2
  - [A *posterior* bulge occurs on the back side while an *anterior* bulge occurs on the stomach side]
- So for most of the people experiencing lower back pain vis-à-vis a herniation, fortunately the herniated disc is not hitting your spinal cord
  - It is hitting the nerves that emanate from it
- But again, there’s so much real estate in that area
- It’s insane because you don’t just have the [nerve roots](https://en.wikipedia.org/wiki/Nerve_root), you have the [dorsal roots](https://en.wikipedia.org/wiki/Dorsal_root_of_spinal_nerve), you have all of these other tiny little nerves that are going to the facets and to the disc and to the vertebral bodies that’s running musculature into your genitals, of everything that’s important
  - [Nerve roots are shown in yellow in the previous figure]
- For the person that is very flexible, who presumably lacks spinal stability, they will go along with their merry life and be flexible
  - The **anterior bulge** is not as a rule, picking up any nasty nerve root compressions
  - And on the grand scheme, it’s probably a non-clinical issue for them until they want to lift [something heavy]
    - If they were in an emergency situation, they’ve come across a car wreck, someone is in the car and if they don’t get them out, the car’s going to explode
    - We will all be placed into these situations at some point in our life and whether or not we have the physicality to deal with them is another issue
    - That’s the downside of that particular adaptation and lifestyle perhaps

**Which of these types of injuries leaves a person more susceptible to the movement of the vertebral bodies in a slipped fashion where we now get that spondylolisthesis?**

- [Spondylolisthesis](https://en.wikipedia.org/wiki/Spondylolisthesis) is when the vertebral body on top moves relative to the bottom (the interior one)
- The answer is both

***A very flexible spine can get shear translations just the way as a stiffer spine can***

- So again, we wouldn’t a priori judge and attribute one of those to the symptoms
- We always go by the assessment
  - It could be either spine for sure

## The pathophysiology of Peter’s back pain, injuries from excessive loading, immune response to back injuries, muscle relaxers, and more [46:00]

- Going back to the story Peter opened with, that very first bout of back pain he had when he was 21 year old
  - It was clearly the previous 7-8 years of really, really heavy lifting
    - Certainly the technical  knowledge Peter has today about how to do these things correctly was completely absent

**If you had to guess (pure speculation), what was the process that led to that injury on that day (that manifestation)?**

*If Peter had MRIs examining his spine every year starting at the age of 13 until that first real insult at age 21, what would you have seen?*

- Stuart has done studies on veteran NHL hockey players (11-year veterans)
  - He saw them for low back problems
  - It was a fabulous natural experiment because they brought their MRIs every year
- He would look at their MRs from the 1st year, the 2nd year, and then he would watch the cascade
  - He would ask, “*What happened in the 8th year?*”
    - That was the year they started with a trainer and the trainer believed in doing ass-to-grass squats with a heavy weight
    - Stuart could see what happened to the spine
    - When was the last time you saw a hockey player do an ass-to-grass squat in the NHL?

*That was a wonderful experiment to give us insight into what Peter is describing*

- Stuart is probably one of a handful of people in the world who had available a radiology suite in their cadaver lab
  - We would take cadavers and apply very specific loading scenarios to it and we would watch the cascade of damage over time
- He puts both of those together to answer what he expects he would’ve seen

***We would’ve seen a lovely young spine in 14-year-old Peter, and then over time we would’ve seen delamination from the inside out***

- Peter was accumulating the delamination, but on the outside it was still pristine

***Peter never knew [about this damage] and the delamination would continue to progress layer upon concentric layer until that day when he was 21, and the last layer was breached and the nuclear gel extruded just a little bit***

**Development of the spine occurs before the immune system develops**

- Early after fertilization around the end of the first month (as a blastocyst), that little flat plate rolled (it’s called [neurulation](https://en.wikipedia.org/wiki/Neurulation)) to create your primitive spinal cord
  - On that day, your mother has not given you an immune system yet
  - Now it’s fused up; that nuclear gel has never seen the immune system yet
  - The end plates are pristine; it’s never seen your blood (which is where the immune system is active)
- Now you’re 21; for the first time that nuclear gel comes out and sees the blood immune environment, and it kicks off a hell of an **inflammatory response**
  - So strong that you couldn’t even move (it locked you up)
    - That takes two weeks to subside

**Here’s the rub from some of the recent literature on anti-inflammatory medication**

- Peter was going to ask if he would have been better off if he had taken a [Prednisone](https://en.wikipedia.org/wiki/Prednisone) taper or had some local anti-inflammatory therapy
  - Stuart replies, “*Of course not. But… your logic is fantastic*”
  - The answer is it could have gone either way
- The anti-inflammatory might’ve cleaned up the immune response and given you faster resolution
- Or what the recent literature is showing: there’s a purpose for that inflammatory response
  - It brings in the immune system and all the macrophages, etc and it starts eating up the extruded material
  - Now that process can go one of two ways as well
    - It can wall off what’s extruded (Stuart thinks Peter experienced that into a free floating body)
    - Or it chews it up (digests it, for lack of a better word)

***Stuart wishes he knew Peter then because he bets he could have got Peter to just lay on his tummy and breathe and that vacuums in***

- Stuart did [experiments](https://www.backfitpro.com/medical-scientific-articles/2009/[91]Scannell,J.P.(2009)Disc-prolapse-Evidence-of-reversal-with-repeated-extension[Spine].pdf) where they would create partial disc herniations and then if you **traction the spine and give a little bit of motion** (he would wiggle your legs)
  - You can vacuum in the disc bulge in a matter of 2-3 minutes and people will say you’re dreaming
  - No, we’ve measured it in some types of subcategories that’s actually possible
- The answer to the inflams is at least some of the more recent data is showing **dispense with the anti-inflammatories**

***Let the inflammatory response give the patient hell for two weeks***

- It’s the best medicine for them in the long-term because it is helping to reduce the long-term disc bulge

**Peter’s anecdotal experience treating his back pain**

- These days when Peter has a flare up, what he finds to be the most efficacious is not any sort of anti-inflammatory, but a light muscle relaxant like [Baclofen](https://en.wikipedia.org/wiki/Baclofen)
  - These episodes are really minor and they don’t interfere with what he does other than he would back off on heavy lifting
    - He doesn’t squat, deadlift, or do any heavy stuff like that anymore
  - He doesn’t use a [benzo](https://en.wikipedia.org/wiki/Benzodiazepine) or anything that is sedating, just something that allows the paraspinous muscles to sort of relax a little bit
    - That allows him to do some deep breathing
    - It’s mostly just a vehicle to break the cycle of tension but not the inflammation cycle
  - Peter is not familiar with the literature that Stuart just spoke of, but he’s mindful of the downsides of taking [Prednisone](https://www.ncbi.nlm.nih.gov/books/NBK534809/)
    - He doesn’t want to suggest people shouldn’t take Prednisone, but one needs to be circumspect about the frequency with which they do it

**Where Stuart thinks Peter is at now with regards to his back**

- Peter probably has a little bit of micro movement in a shear mode
  - So this joint isn’t translating as it should
  - It’s lost a little bit of height
  - And those are the things that are causing the low-grade aches
    - Not kicking off the heavy acute attacks that Peter used to have as a younger man

*Stuart wants Peter to come see him*

- Stuart understands that Peter’s brother has a farm in Canada that he occasionally visits
- He invites Peter to spend an extra day, come by [Gravenhurst](https://en.wikipedia.org/wiki/Gravenhurst,_Ontario) and they’ll have some fun
- What he would do with Peter is he would get him to stand just as he is and he would bet Peter stands differently when he gets out of that chair after doing this podcast for a bit versus of when he’s just walking around
- There would be forward lean and [antalgia](https://en.wikipedia.org/wiki/Antalgic_gait) and if Stuart were to palpate Peter’s [erector spinae,](https://en.wikipedia.org/wiki/Erector_spinae_muscles) he explains, “*They would be active and I would lift the toe shoe to open up your hips a little bit, ears over your shoulders, shoulders over your hips, and now all of a sudden we’ve achieved that muscular relaxation that you’re after.”*

**Stuart’s advice for Peter, the next time he needs to take a muscle relaxant**

- Lay on your tummy, maybe put your hands, palms up under your hips, maybe make a fist
  - Again, Stuart doesn’t know Peter’s spine well enough, doesn’t know where Peter is
  - Stuart suggests finding a nice little relaxation place
- Melt into the table every time you exhale
  - Keep doing that and see if that doesn’t remove the ache
- We will play with your hands to realign that little shearing micro movement and then stand up
- We might open up your hips a little bit with a [psoas](https://en.wikipedia.org/wiki/Psoas_major_muscle)-specific stretch, and then you will monitor your back muscles and see if you’ve shut them down
- But then if Stuart said, poke your head forward, muscles on, pull your chin back, muscles off, soften your knees a little bit
- Some people will stand with a strategy of ramming their knees back into heart extension
  - Feel your erector spinae
- Maybe it’s just simply jazz knees and soften your knees
  - In other words, those little postural cues

***Stuart has seen Peter enough moving on YouTube and whatnot, that he bets they could hack their way around that without the use of meds***

- Peter will happily add an extra day to his next Toronto trip when he’s up at his brother’s farm, and he’s sure his brother will want to join as well

## The three most important exercises Stuart prescribes, how he assesses patients, and the importance of tailored exercises based on individual needs and body types [56:15]

**Explain the** [**McGill big 3 exercises**](https://www.chirocentre.com.au/stuart-mcgills-big-three-low-back-exercises/)**, provide the rationale for them, and talk about some of the hallmarks of your assessment**

[Here’s another helpful video: [(Do these daily) The McGill Big 3: Full Breakdown with Brian Carroll](https://www.youtube.com/watch?v=P8YiZO3OGjk)]

- Peter has been doing these consistently for quite some time and really fancies them
  - The third one (bird dog), he only does occasionally
- Peter asks, “*Is this kind of like your core nutrition… everybody should be doing this? You don’t wait till you have back pain to do this. Is that safe to say?*”
- No, it isn’t
- This is a bit of a myth and something that Stuart has been fighting his whole career
- There are some people that are far too stiff and this is not the mechanism of their back pain (we don’t need to go there)
  - Have you ever seen the type of body build where they have a huge pneumatic cushion in front called a belly, it slaps on their thighs, it’s that pendulous
    - Do you ever see spine instability in that type of architecture? Stuart doesn’t
    - Those people have difficulty getting on and off the floor
    - ***The big three is not for them***
- Again, the assessment always leads us to the solution
- Stuart explains, “*I need to have a discussion of what stability is in terms of creating resilience and performance. Then why are those particular exercises important, and then how to do them.*”

> “*We’re going to talk about non-specific low back pain and how I think it’s a myth and it doesn’t exist. That will take us into the assessment*.”‒ Stuart McGill

**A basic discussion of stability**

*Analogy: the example of a backhoe*

- A backhoe is a machine with a tractor and it has an arm on the back to dig earth
- The first thing the operator does is put down the stabilizer bars to lock the tractor into the ground
  - Because if you don’t do that, you can’t pull earth, you just pull the machine around
- So what’s the human equivalent of that?
  - We live in a linkage just like machinery
  - In other words, let’s take the bench press muscle [pec major](https://en.wikipedia.org/wiki/Pectoralis_major) [shown below]
    - Pec major originates on my rib cage, spans the ball and socket joint of the shoulder, and inserts on the humerus

**Figure 15. The Pectoralis muscles**. Image credit:[StatPearls](https://www.ncbi.nlm.nih.gov/books/NBK545241/figure/article-32427.image.f1/)

- Stuart explains: when I contract and shorten the pec major, it flexes my arm
- So if I wanting to do a push or a punch, there it is, on the distal side of the joint
- Proximally, that same muscle shortening collapses my rib cage towards my shoulder joint
- So all I used was the muscle that spans the joint
  - That isn’t a very effective push
  - All I’m doing is collapsing my own linkage
    - Or as an engineer, we would say, well, you’ve just created an energy leak
- I’m now going to build proximal stiffness
  - I’m going to lock my core, create stiffness through my torso, which is proximal to the joint
  - So now when I contract the muscle, 100% of the motion is directed distally
  - Now I’ve got my push

*So what is the best, most efficient way to create a proximal stiffness?*

- We searched for years doing all kinds of tests of every abdominal exercise you could think of, back exercises, twisting, power off presses, throwing things, etc.
- The three exercises that kept bubbling up to the top in the criteria of **sparing the spine while you’re doing them**
  - Because these people are hurting, and you don’t have carte blanche to load up their spine
  - It was later in Stuart’s career that we found there is a residual stiffness that occurs

***If you are an NFL football team and if you do the big three prior to practice, you will run and cut just a little bit faster***

- So you’re on the field, you run and you cut: the stiffer the core when the hips explode into external rotation, you’re now creating a faster directional change

**The patient assessment**

- Stuart will have the patient sit on a stool and ask them if they have any symptoms right now
  - Let’s say they don’t
- Next, he asks them to drop their chest down
  - They say, “*My left toe is going numb and I’ve got back pain*”
- He asks them to bring their chin down
  - They might say that will increase their pain (or decrease it)

***The point is that posture created their pain***

- If that is true, then when they lay on their back and they imprinted their back into the floor doing a Pilates roll-up (for example), that would be their specific pain trigger
  - So it’s not much of a therapeutic exercise

**The foundation of the modified curl-up**

- Stuart advises to put your hands under your low back as you’re laying on the ground, lift your elbows
  - Now, hover up your head, neck and shoulders, and we’re going to propel the abdominal contraction
  - Breathe through pursed lips, and allow the diaphragm to become the athlete inside this barrel
- Now if the person has a rotator cuff issue, we will hack it and make it tolerable

*Another assessment*

- Stuart would see people and ask them to take a dumbbell (or a kettlebell) and raise it up laterally in the frontal plane like this for the side of the core
- That would trigger pain in a lot of people

**We could then do a side plank on the floor**

***The beauty of the side plank is only half the musculature is heavily challenged; the downside is heavily challenged, the upside is not***

- You’ve only got half the load on the spine, very spine sparing
- Stuart prescribes the side plank on 10-second intervals

***Why? We use the Russian training science to show you build endurance through repeated 10-second exposures***

- You’re not getting tired to the point where you break form, nor do you develop a neural fatigue
- And you get a much higher tolerable training level with this, what we call the [Russian descending pyramid](https://www.livescience.com/56030-best-back-exercises-for-beginners.html#:~:text=For%20people%20with%20back%20pain,seconds%20of%20rest%20in%20between.)

**The bird dog is for the back muscles**

- Look at the beauty of the bird dog where you extend one leg, the opposite arm
  - One half of my low back is active, one half of my upper back is active on the other side, we’re developing a nice DNF pattern
  - We’re creating stiffness and stability in the core
  - We’re teaching the brain to disassociate ball and socket joint motion of the shoulders and hips with only half the spine load of say a Roman chair extension or something like that

**Then we did experiments where we would train people**

- We would just have a single session exposure
- We would measure the core stiffness prior to doing the big three
  - They’d do the big three on the Russian descending pyramid and then we would remeasure their torso stiffness
- They were stiffer and some of my muscle physiology colleagues said, “*Well, you’ve added a turgidness to the muscle*.”
- But Stuart doesn’t think so
  - He thinks the brain created a lasting neural stiffness
  - And in some people it lasts about 20 minutes, in some people it lasts longer
- Some patients will say, “*You know, when I do the big three, I don’t have pain for the next hour.*”

**Stuarts prescription**

- What you’re going to do is mid-morning, do a 12-minute big 3 session
- Mid-afternoon do another 12

***These are the little tricks and hacks to slowly wind a person down out of pain; that was the aim of the big 3***

**Then Stuart started to look at the performance side**

- If you train a group of athletes versus graduate students (the typical university experiment), not much difference was found in the athletes
  - But in the graduate students, we would see an increase in stiffness over a six-week training trial

*Really interesting things started to happen*

- If you do isometric holds in the manner Stuart’s described, **you punch harder**
  - They took a group of Muay Thai athletes and when they [did the big 3 and we measured the punching impulse](https://www.backfitpro.com/medical-scientific-articles/2015/[25]-Lee,B.-(2015)-The-effect-of-long-term-isometric-training-[J.-Strength-Condit.].pdf), it was greater after they trained for 6 weeks
- When we did dynamic core exercises, it **increased the closing velocity**
  - The closing velocity is when you first get the first muscle, and then you relax closing velocity, and then you strike with a second bolt, boom, boom

***The closing velocity was faster with dynamic core exercises, but the strike force boom at the end was greater***

**Stuart has studied combat techniques, and he explains 3 styles**

- Let’s take [Joe Frazier](https://en.wikipedia.org/wiki/Joe_Frazier) and you would see him just always on forward progression, but the punches came from his body weight behind them
  - He would create a beautiful thrust line straight, but his body rotated and he lent his weight into them, and that was his footwork
  - It wasn’t the greatest for getting hit because that means you get hit a lot
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson), different body type, a very compact type of a body, but contrast his footwork
  - It was just beautiful
  - He would drop step, drop step, drop step, hook the liver, come back very quickly, hook, boom, and cross, and there was the knockout again
    - All coming from the hips, drop step, boom
  - You see it’s all hips
- Then [Ali](https://en.wikipedia.org/wiki/Muhammad_Ali_(British_boxer)) breaks all the rules with the Ali shuffle, and then he would turn, rotate, hang on to it, and then at the end look at a beautiful thrust line all through the stick on core
- Stuart can go through athlete after athlete
- He never worked with Jagger, but there is Jagger doing the bird dog in his training
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt), the fastest man on the planet does the bird dog breeding extensor pulsing power into a stone

## The significance of strength and stability in preventing injuries and preserving longevity [1:08:15]

**As he has aged, Peter has become interested in looking at the greatest performers**

- Peter adds, “*There’s no doubt that the best athletes have a remarkable natural talent that the rest of us don’t have*.”
- Stuart agrees and he has measured it

**The importance of natural stability**

- Peter thinks that his lack of natural ability has meant that he always suffered from an unbelievable amount of energy leakage
  - In whatever he has done, whether it’s been boxing, swimming, powerlifting
- He realizes that there’s such a chasm between himself and the really good ones, and it’s not due to hard work
  - It is due to probably some combination of natural ability and coaching that has allowed the really good ones to do what Stuart has demonstrated
    - Which is a great punch begins in the back foot and it’s transmitted through the hip and it goes into the opposite fist
- It’s just hard for people to understand how that through-line of force can’t lose anything along the way
- Stuart adds, “*The stories I could tell you about the number of athletes being de-tuned by their trainers and coaches violating this principle that you’re describing, it’s astounding to me.*”

***Peter points out that it’s not just that energy leakage costs you performance (it clearly does), but it predisposes you to injury***

> “*When I exercise today, I don’t care about the performance. I care about the preservation and longevity of my body for whatever number of years I have left. So this is really where I think stability matters*.”‒ Peter Attia

**What are the exercises that we need to be doing so that as we age and we walk up a flight of stairs or carry something heavy, we don’t hurt ourselves? (Because we don’t have that core stability that can resist the deformation that’s going to allow energy to seep out of the system)**

*Stuart shares a story that shows the arrogance that exists among some medical staff*

- Stuart was teaching a class and showing some data from an elite athlete and there will be therapists and clinicians in the room who say, “*We don’t deal with elite athletes, we deal with the elderly or we deal with sick people.*”
  - But Stuart was showing them what the human body has the potential to do
- Occasionally a medical group or a hospital will ask Stuart to assess 3 patients in the auditorium in front of all of their medical staff
- He was at a facility in Europe, and the first person was a rugby player
  - He had 20 minutes to declare what he thought was going on
- The next one was a woman in her early 70s, clearly distraught
  - Her posture and carriage showed that she was defeated by the world
- She came onto the stage and Stuart asked her to tell her story
  - She said a little few sentences, and then she said, “*But the therapist says that I have to leave my home now. When I get off the toilet, I’m a bit unsteady and she’s afraid I’m going to fall on the floor. I can’t get off the floor by myself and I’m just going to lay there and no one will discover me. I have to leave my home.*”
  - She started to cry at this point and she said, “*What’s going to happen to my cat?*” and all this sort of stuff
- Stuart asked someone to bring him a stool to be the simulated toilet
  - She turned and had no idea how to move and just sort of plopped and collapsed on the toilet
    - Stuart wants you to see his lower body kinematics as he’s moving
  - Then Stuart asked her, “*Would you get up off the chair?*”
    - Her knees were together, and she just sort of collapsed and he had to help her
    - She was going to collapse onto the floor
- Stuart said to her, “*I want you to humor me now. You’re my mirror*.”
  - When he coaches, he tries to use minimum words
- He told her, “*Do this with your hands. Put your knee cap between your thumb and your hands as you slide your hands down. Good. Now, I want you to be a leaning tower. Leaning tower, forward and backwards and play with the curve of your back. Do you have any pain now?*”
  - She said, “*No*.”
- He said to her, “*Watch my shoulders. You’re shrugged. I want you to anti-shrug.*”
  - She did that
- Next he said, “*Pull your hands up your thighs by pulling your hips through. Don’t lift with your back, pull your hips through*.”
  - She had it done in three repetitions
  - That was now her pattern
- Then he said, “*Okay, think of what we’ve just done and sit on the toilet.*”
  - He added, “*Whoops, spread your feet apart.*”
- And there she went, slid her hands down and then she put her knees together and he said, “*Now stand up.*”
  - And she was going right back to the incompetent movement that caused her inability and disability before
  - Stuart said, “*Spread your knees apart and pull your heels underneath you. Sniff some air, now lean forward and do what you now know how to do.*”
    - And she did a perfect squat
- Stuart asked her, “*Do it again*.”
- By the third repetition, a big smile came on her face
- Stuart said, “*What’s up with you?*”
  - She said, “*I don’t have to leave my home, do I?*”
  - He said, “*No*.”
- Do you know many of those hard baked surgeons and clinicians started to cry as well?
  - ***For the first time they realized all Stuart did was teach her weightlifting 101***
- And remember how this story started with the arrogance of some of our colleagues who say, “*I don’t want to hear stories about elite athletes. I deal with old people or sick people,*” and that’s why they continue to not have the skillset to help their people

***All Stuart did was learn from the best weightlifters in the world, people who know how to move load, learn what the efficiency was and turn it into a hack to change a person’s life***

- Honda used to race F1 cars and the reason was they learned about automotive technology, and the gearshift change in your Honda Civic came from the F1 racetrack

> “*So that’s why we work with elite athletes so I can bring it down.*”‒ Stuart McGill

- Stuart loves working with them, of course they just give it away free to us
- Yet some of our colleagues are just so closed off, they don’t want to hear about elite performance
- Peter reacts, “*That’s an absolutely beautiful story…  I think the saddest part of that story is how many of those patients don’t get the chance to sit on a stage with you for 30 minutes and learn that movement.*”

**Peter feels optimistic that we are in a place now where people are starting to appreciate the importance of strength and stability and that we’re less afraid of this**

- There’s more discussion of the importance of resistance training and that it’s not a “young guy” thing to do
  - It’s an “everybody” thing to do

Peter asks, “*Given the arc of your career, am I being just sort of delusional or do you really think that we’re in a coming of age here?*”

- Stuart tries to answer every question with, “*What’s the evidence and what’s the application?*”
- The evidence at the university with all our first year students, one of their first courses they took was on just basic fitness evaluation, range of motion, strength, hand grip, VO2 max, some of these markers,
  - They would measure each other, and we kept the scores year after year of the incoming class
  - The students got terribly soft (as shown by that data)
- Now, whatever year was the year where the students had grown up with the personal computer, it was right at the very late ’90s
  - All of a sudden we saw the incoming class fitness plummet
- Then something happened
- They were a soft bunch for about five years, and then slowly to your point, they started to come back
- Stuart thinks Peter’s perception is right on
  - It did go to a terrible state however many years ago that was, 15 or 20 years ago, but it is coming back
- Now some of our colleagues are terribly misguided as well
  - They think (because they heard on social media), “*Oh, you’re not a real woman until you can deadlift twice your bodyweight.*”
  - Well wait a second; if they could come here and see the number of people who’ve been caused by overzealous trainers and going bonkers on deadlift magnitude

## Stuart’s take on squats and deadlifting: potential risks, alternatives, and importance of correct movement patterns [1:19:30]

**Peter is conflicted when he thinks about particular squats and deadlifts**

- He has no desire to do anything that he deems stupid anymore
- His days of gritting through painful anything are long over, and he knows the difference between discomfort that is worth pushing through and pain that is not
- On the one hand, he now feels that he is so tuned-in to how to do a deadlift movement correctly that it’s a wonderful audit for his stability system
  - He’s embarrassed about how much he didn’t know when he was deadlift
    - At no point did he understand the importance of tension in the arms, intra abdominal pressure, the variability and foot pressure on the ground
    - It was just pure brute force stupidity
  - Today he knows things that allow him to modulate force and on a good day, push the envelope a little bit
- On the on hand he thinks he should be deadlift his whole life
  - He doesn’t need to deadlift 400 lbs anymore
  - But he should be deadlift because it’s this **great audit**
- On the days that he doesn’t feel it, he backs off
  - There’s a lower risk approach to get it

***In other words, deadlifting is valuable, but you have a narrow operating window in which you can potentially hurt yourself***

- Peter still will go periods of his life where he’ll deadlift every week and then he’ll take 3 months off feeling like he doesn’t want to push it

**How would you advise a middle-aged person or even a non-middle-aged person who’s thinking through this particular issue?**

- Stuart has so many thoughts going through his mind
- With a 50-year-old who has back pain, he wants to know, “*What are your goals?*”

*Stories about* [*Ed Coan*](https://en.wikipedia.org/wiki/Ed_Coan) *(the greatest powerlifter of all time)*

- Stuart was with Ed a couple of weeks ago
- When Ed would **set a personal best**, he’d take a couple of months off afterwards
  - To set a personal best is so demanding of your body
    - If you set a true personal best, most people experience **micro fracturing** just underneath the end plate of the [trabecular bone](https://en.wikipedia.org/wiki/Trabecula)
  - If you look at the great strength athletes, they train deadlift
    - If you go to our [website](https://www.backfitpro.com/), look at the [testimonials](https://www.backfitpro.com/testimonials/) at the bottom the number of world class deadlifters who were on there
    - Stuart has worked with quite a few of these people through their injuries

***Those microfractures could be a good thing or a bad thing***

- The professional powerlifter will take a week off
- They train heavy deadlifts or squats *once a week* because it takes a week for the [bone callus](https://en.wikipedia.org/wiki/Fibrocartilage_callus) to not only attach through the chemical electro attraction, but to really scaffold on takes a week
- If you deadlift in another three or four days the way some trainers do, that allows those micro fractures to accumulate until finally you’ve got a full blown endplate fracture
- These are the people that come here and then Stuart will say, “*How about this for a goal? Do you have kids?*”
  - Stuart has since learned about Peter’s [centenarian decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/), which he loves
- Stuart asks clients, “*Would you rather as your goal, have the ability to play with your grandchildren on the floor when you’re 80 and get off the floor and pick them up?*”
  - They pause for a minute and they’ll say, “*Yeah, I like that goal*.”
- Stuart tells them they can’t have both
  - If you think you’re going to continue having deadlift personal bests, you’ll have artificial hips and all of these other things
    - Because how many old powerlifters do you know?
    - Do you really want to be like that group of athletes?
- Stuart can talk them into changing their long-term goals

> “*Now is the time to get on the program and make sure you get there. If that’s the case, we eliminate deadlifts*.”‒ Stuart McGill

**The monster walk**

- Stuart saw an athlete yesterday ‒ they’re at the end of their career and he took them out and they went for a 10-minute walk to a hill
- He explained, “*Here’s why you’re not going to do deadlifts, but here’s what I want you to do*,” and he showed them the [monster walk](https://www.livestrong.com/article/13778143-monster-walk-exercise/)
- He told them to go to the bottom of the hill, lean back into the hill, walk backwards
  - He instructed them to align your foot, ankle, knee and hip and push through the knee, through the knee, through the knee, backwards up the hill
- Do you know after 30 meters, they were absolutely done

***Here they are doing all this deadlifting and they don’t even have the leg strength endurance to walk backwards 30 meters***

- It’s totally inappropriate stimulation of their athleticism to make it through to 80
- They walked down the hill, and they did three sets
- They could hardly walk

**Next, they played the neurological grip, which Stuart likes to do a lot of now**

- He instructed, “*Walk forwards up the hill, but pretend you have 100 dollars in your butt cheeks. Don’t let anyone take it. Now, walk forwards up the hills*.”
- They say, “*I’ve never felt this before.*”
- The brain perceives exhausted quads
  - It now has to go and get the glutes; it’s the only thing left
- Quite often we’ll do an **exhaustion focus** to stimulate the thing that we really want to stimulate

***Stuart convinced that person to train to get a well-rounded and sustainable athleticism that will spare their joints***

- They still have great training capacity, but their athleticism is going to go through the roof
- Stuart has taken some very accomplished powerlifters and taken out all the squats and just do sled work, backwards walking uphill
  - Some of these old-time techniques

***Their joints settle down, they get a sustainable fitness, and they lose this idea of maximum effort, squats and deads, and now they’re thinking of the word sufficient strength, sufficient mobility, sufficient endurance***

- Stuart explains, “*We’ve been doing this long enough now that we’ve tracked them, and those are the ones that are getting through*.”

**Ask an orthopedic surgeon who they are replacing hips on**

- It’s 50-year-old Caucasian women who have done yoga for 30 years, and men around 50 who’ve done deadlifts all their life
- Who are they *not* replacing hips on?
  - The middle of the road moderates
  - Not the ones who’ve rusted out and not the ones who’ve worn out

**This idea of sufficient fitness**

- Stuart believes we are all called upon to do things in life at certain times
- It’s more fun to just to be able to continue to do those things
- Stuart doesn’t do deadlifts, but he picks up 100 pound bucked-up logs (as an example)
  - That’s his stone lift
  - He will load that into the log splitter; he still splits his own wood
  - People comment on his hands ‒ an athlete who came in yesterday shook his hand and he couldn’t fit his hand around Stuart’s
    - That’s from 65 years of splitting firewood
- When Stuart was young, he didn’t have dumbbells, his dad would give him cinder blocks
- He’ll take grip strength any day over how much you deadlift

**Best proxy for longevity**

- People often ask Peter why he thinks **grip strength** is such a great proxy for longevity
- And he explains that it’s the same reason he thinks **VO****2** **max** is a great proxy for longevity

***Those are probably the two best biomarkers we have, and it sounds crazy that your VO******2*** ***max and your grip strength are better predictors of how long you’re going to live than whether or not you smoke, drink, and what your family history is for cancer***

- Those things all matter, but it’s amazing how dwarfed they are by those two
- Peter’s best explanation for it is that those are the best two integrators for the work you’ve done
  - You can’t cram for a VO2 max the week before
  - If you have a high VO2 max, you have done the work to get it
  - If you have a strong grip, you didn’t just buy little grip squeezers on Amazon and filter away at them while you were on calls on Zoom
    - You had to do the work
    - You had to be carrying heavy things, whatever it be, chopping wood, carrying cinder blocks, doing farmer carries
  - And of course, that also speaks to stability that you have to be able to transmit force from the torso right to the hand

## Helping patients with psychological trauma from lower back pain by empowering them with the understanding of the mechanical aspects of their pain [1:30:00]

**The psychological trauma that exists in the patient with lower back pain**

- Peter is thinking very specifically about some of his patients or friends who have been in the throes of lower back pain
- And if nothing else, Peter takes a great degree of comfort from his third injury (the one in 2000) because it lasted so long and because it was so debilitating, and because he’s here today without pain
- His confidence around small recurrences is so high that he doesn’t tend to awfulize about it and work himself up
- But he has great empathy for a person who doesn’t have that knowledge

***Peter doesn’t know how to help someone sometimes because he can’t tell what is mind and what is body at this point***

*How can we help those patients?*

- Stuart is certainly much more conscious of the point Peter is making now than he was 30 years ago

**A patient who the medical system had given up on**

- This story illustrates something that happens very often
- Peter mentioned earlier how MRIs don’t show you the mechanism of pain and Stuart can give all kinds of reasons why
- A patient came to see Stuart and he said, “*Hi doc, I hear you’re different. I’ve got this pain. I’ve been everywhere. I went to the pain clinic, they gave me narcotics, and now they say, ‘The pain is in my head.’ I can live with the physical pain. I cannot live with someone telling me the pain is in my head because that means I’m crazy. And if I’m crazy, I don’t deserve to live. You’ve got two weeks, and in two weeks, I’m blowing my brains out*.”
- Now there’s a heavy psychosocial challenge and a little bit of a story of what the system does to people
  - And it’s not unusual for someone to come to his clinic suicidal
- In the evaluation, the patient did not have any point right now
- When asked about what causes his pain he explained, “*Well, it’s when I do a certain movement that I get a flash of pain and it feels like someone has broken a beer bottle and have ripped open my hamstringing muscles. It’s awful.*”
- Stuart asked him to show him what creates this pain so he could understand it
  - Stuart used a muscle EMG over the torso, the glutes, etc., and they put on the 3D spine monitor
- The patient stood there and did a very weird thing, he would himself around in a circle, and when he got to the top, dead center he let out a cry of pain and Stuart heard a little cavitation, a little pop come out of his back
  - That was the crack of the [sciatic nerve](https://en.wikipedia.org/wiki/Sciatic_nerve)
  - He was in a bad way
  - Stuart laid him, prone on a table and tried to give him a bit of decompression before he went home
- Stuart explained, “*I know exactly what the mechanism of your pain is. Here’s what you should do over the next 3 days, but I want you to come back, but promise me you aren’t going to do anything silly.*” (remember his earlier threat?)
  - Stuart called him later that night and again the next day, just to make sure
- When he came back, Stuart explained what the data showed and what the mechanism was
  - As he was winding himself around, he was using muscle
    - Muscle is stiffening and stabilizing
    - It’s centrating of the joints
  - As he got to top dead center, he shut all his muscles off
    - He completely relaxed
    - And then was a little shear translation or a clunk (and that’s what we heard), and that’s what trapped the sciatic root
- Stuart coached him, “*Okay, you have no pain. Push my fingers out harder. Good. Hold that. Now talk to me, and keep talking to me with that controlling*.”
  - He asked him to keep the tone and go through the motion that causes his pain, and as he came to the top, dead center, he encouraged him to keep control
  - He didn’t clunk
- It took him about 4 months to wind down the ache, but he never had another clunk or trap
- 10 years later, he brought his daughter in to see Stuart
  - He brought Stuart a case of beer and Stuart asked how he has been
    - Fabulous, he never had another episode
- Some people will think that that’s a fantastic impossible story
  - But he was so coachable, he understood, he was a mechanical mind

***This was a suicide case from the medical system not having a sufficient evaluation procedure to really get at what the mechanism of his pain was, to a point where they defaulted, and said, “We’ve tried everything with you. It’s not working, therefore, the pain is in your head.”***

> “*It was a process of understanding the mechanism, giving him a strategy to address the mechanism, and the psyche just changes. It empowered him*.”‒ Stuart McGill

**A police officer with debilitating back pain**

- Stuart was giving a lecture in England, and there was a fellow off to the side, and he was slumped down
  - Now, if you get a clinical psychology textbook, the picture of depression is this: knees together slumped down in that demeanor
  - Also, if you have a posterior disc bulge, that is not a good position to be
- He was starting with clinical depression beating a disc bulge, and those two don’t go together
- During the break, he came over to Stuart, he was a very quiet spoken fellow, and he said, “*I hear what you’re saying. Do you have 30-seconds for me to tell you my story?*”
- The man used to be a police officer, he hurt his back and went through the [NHS](https://www.nhs.uk/) system
  - They only gave him exercise that hurt him more
  - Finally, they gave him a pamphlet, *How to Live With Your Back Pain*, and he explained, “*That book destroyed me. What do you mean I have to live the rest of my life with my back pain? And no one’s ever touched me or shown me any of this.*”
- Stuart showed him the squat procedure (the one he went through with the older woman, discussed earlier), and he encouraged him to sit tall in his chair
- At the end of the lecture, he went over to him and asked him how’s your pain?
  - He said, “*It’s gone,*” and he started to cry
    - Because he realized now what the system had done to him
    - In the meantime, he lost his job and he realized that he’d been stolen from, and those are his words
  - He said, “*They stole my career from me, giving me that book, ‘How to Live with My Back Pain.’ Why didn’t anyone show me what my pain was like? You just did in 30 seconds.*”
- Stuart has been watching this pattern for so many years
  - You could see it a mile away

***Those are two stories to link the mechanics, and ultimately what we’re trying to do is to empower people in showing them they have the ability within themselves. They just need to understand the mechanism. And most of the time they are able to mitigate the cause, and then build a robust foundation***.

## Empowering patients through education and understanding of their pain through Stuart’s clinic and work through BackFitPro [1:39:00]

**Stuart wrote** [***Back Mechanic***](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1)**, and he started the experimental research clinic at the University of Waterloo**

- He’s never heard of another clinic where they follow-up with every single patient that they ever saw
- We did a two-year follow-up with every single patient who came in, and we subcategorized them, because we assessed everyone into the mechanism of their pain pathway
- We gave them an appropriate exercise prescription
- We followed up to see did they even comply, because some people didn’t, and then how are you doing after two years?

*Stuart’s experience on the efficacy of empowerment and they psychology issue*

- If you were in the subcategory that everything has failed, you’ve been told you need surgery, so you’re at the end of the road now, you’re a surgery case
  - In the two-year follow-up, following the plan that he just described, with this thing called virtual surgery (which is part of it) ***95% reported that they avoided surgery*** and they were glad that they did

**What stands out to Peter in most of these stories is Stuart’s consistent, adamant drive toward understanding the mechanism of pain**

- It’s a question of, “*How do we break this down into a physics and biology problem?*”

Peter asks, “*Is your Ph.D. through the School of Kinesiology?*”

- It is, but there is a lot of mechanical engineering in there
- When Peter thinks of all the different practitioners that interact with patients who have lower back pain; ranging from neurosurgeons, orthopedic surgeons, chiropractors, physical therapists, kinesiologists
  - There are so many people
  - And Peter never wants to suggest that the profession determines the school of thought
    - He really thinks there are great people, and there are lousy people, within all of those categories
- In all of Peter’s bouts of misery, nobody ever explained to him what was going on
- Even as a medical student, he could look at the MRI and see the fragment
  - It had come out, and it might’ve taken months for it to be reabsorbed
- There wasn’t a discussion of, “*We need to understand the ‘why’ this is happening, so that we’re going to fix the underlying behavior that’s causing it*.”

**What are the characteristics that you see driving that type of search for a true mechanistic understanding of the pain?**

*Is that a function of the individual or of the school of training?*

- Both

***No billing code exists for an assessment of back injury mechanism (you can’t bill an insurance company)***

- When Stuart started the experimental research clinic, he set aside 2 hours to see a back-pained person
  - That’s all he ever saw patients for, 2 hours
  - He had not been through medical school training, and had only have ever been a guest professor at a medical school

**His medical colleagues asked what he was with patients during that 2 hours**

- Stuart had spent 30 years figuring out how to test shear, tolerance to compression, pulling a nerve root one way and the other
  - Is is flossing? Is it friction? Etc.
- He set a handful of people in the world that would take cadaveric spines and create the injuries

***So he knew how to measure them, and what to look for in terms of the full pattern***

*The first political impediment to all of this is there’s no billing code*

- Therefore, you’re left with clinicians who are billing for a procedure that they’ve been trained to perform
- Stuart explains, “*If you have nonspecific back pain, it’s an absolute crap shoot*. *Whether a manipulation for mobility, an exercise prescription for stability, just a movement tool, not to create a stress riser or a stress concentration on the tissue that is sensitized. Simple as that.*”

***The solution is to train clinicians, and that’s what Stuart has been doing through*** [***BackFitPro***](https://www.backfitpro.com/clinicians/certification/)

- He doesn’t care if you come from a chiropractic, physical therapy, coaching, training, physiatry, neurology, radiology even, background
- All he cares is that you have passion

**It’s a** [**50-hour online course**](https://www.backfitpro.com/mcgill-method-summits/) **of Stuart going through anatomy, physiology, neurology, psychology, biomechanics, etc., and then, the probably 100 subcategories of pain mechanisms**

- Then how do you test for all of these, and then how do you coach them?
- After all of that, we have three days together where we do hands-on skills training at a table
- There’s no subcategory in the medical rubric that trains how to assess back pain from the perspective of biomechanics, psychology, neurology, physiology, etc. (they don’t exist)
  - That was Stuart’s challenge
- It’s called the [Summit course](https://www.backfitpro.com/mcgill-method-summits/), and you can read about it on [backfitpro.com](https://www.backfitpro.com/)

Peter asks, “*Is it only for practitioners, or is there a variant of that course that an individual can take to become sort of the master of their own domain?*”

- Stuart has only known clinicians to register for it
- He doesn’t think they would stop a member of the lay public from taking it
- However, the gatekeeper of all of this is there’s a fairly extensive written exam at the end
  - Also, there’s a practical exam, where the person must assess a real patient, usually online with one of Stuart’s examiners
  - They have to come up with a written explanation of the pain pathway, and then a program of what they’re going to do with the person, and then they have to coach elements of it
    - So they have to see the coaching scale, as well
- Stuart is agnostic in terms of preparation
  - There are fabulous chiropractors and there’s the absolute opposite. There’s fabulous therapists, there were fabulous professors and terrible professors
- Peter thinks this is a very interesting course and would love to figure out a way to make the time
  - 50 hours online and 3 days in person

## When surgical interventions may be appropriate, and “virtual surgery” as an alternative [1:46:45]

- We’re not talking about surgery without understanding how you got there
- It should always be assumed that you want to understand how you got there [understand the mechanics of the pain]

**What are the indications in your mind for where a patient is better off getting a surgical procedure?**

*Also talk about what you think are the best indications for discectomy, fusion, etc. versus where would you take a contrarian approach, where many people would say, “Yes, surgery,” and you would say, “Let’s push a little bit harder before.*”

- In the follow-up visits with patients at Stuart’s clinic, 95% of the people who were told they needed surgery avoided it

**Patient 1: a stay-at-home mom with two young kids who every day has to go to the gym and ride the elliptical for 20 minutes as a stress reliever**

- Stuart will tell her to get the surgery and ask if they are going back to the gym the next day
  - No, they would lay in bed and behave like a post-surgical person
    - Then they would slowly build themselves back
- In other words, surgery may work for them because it’s forced rest
- Stuart recommends, “*Now I’m going to give you a tool that will mimic the forced rest. It’s called* ***virtual surgery****. Tomorrow, here’s the plan. Here’s how you’re going behave. We are going to desensitize, strategically, the pain mechanism as we’ve measured it, and we’re going to retune your body with strategic mobility and stability plus movement skill, so we don’t replicate the stress concentrations that caused your problem in the first place. Let’s see how you are*.”

***If they can do that, 95% will avoid surgery***

Peter asks, “*What  are the patients who you would not offer that virtual surgery to?*”

- We don’t take patients off the street, ever
  - They always come through physician referral
  - So Stuart is hoping they’ve been checked for red flags
    - He adds, “*Do you know how many have not, even though we state in the referral directions to the referring medic?*”
- 1 – Looking for obvious red flags is #1
- 2 – Number two is when the pattern doesn’t fit
- Stuart was smiling when Peter was telling his original story, only because it was such a familiar spot on pattern consistency
  - Peter fit the pattern, and Stuart knew exactly what it was
- When it doesn’t fit the pattern, Stuart will send them back to their doc
  - Maybe there’s a turgidness under the patient’s liver, and they’re not able to move that pain by moving stress concentrations around the spine
    - So it’s not a nerve
    - It’s nothing vertebral or facet

**In terms of patients who need surgery**

- Stuart sees far too many post-surgical patients
  - Maybe their surgery was botched
  - When Stuart sees a horrible scar on the outside of the skin he wonders what carnage has gone on inside
- Sometimes it’s a “shit happens” story
  - The nerve scarred in and adhered
  - Or the post-rehab was terrible
    - Maybe they’re given toe touches after a micro disc surgery and now they’re re-herniated

***The surgeons are at their best in cases of a real heavy*** [***stenosis***](https://en.wikipedia.org/wiki/Spinal_stenosis)

- So there’s not much room in the neuro canal
- The facet joints are thick in behind, so you’ve got encroachment from behind
- You’ve got a calcified disc bulge coming from the front
- Surgeons are best at providing a couple level laminectomy to give the nerve some space

***Some of the*** [***spondylomalopathies***](https://www.hopkinsmedicine.org/health/conditions-and-diseases/cervical-myelopathy) ***are obvious surgery cases***

- An obvious one is post-trauma, and they need a little bit of hardware to stabilize their spine, but it may also be [spondylolisthesis](https://en.wikipedia.org/wiki/Spondylolisthesis)
  - The listhesis, or the shear translation, is just choking off the [cauda equina](https://en.wikipedia.org/wiki/Cauda_equina), or another nerve
  - In that case, we recommend surgeons who we have really good luck with

Peter asks, “*In that situation, if the spondylolisthesis is significant enough, is the only treatment a fusion?*”

- Yes
- Peter asks about any stability you can generate in the [paraspinous muscles](https://www.physio-pedia.com/Paraspinal_Muscles), in the [QL](https://www.physio-pedia.com/Quadratus_Lumborum), in the [psoas](https://www.physio-pedia.com/Psoas_Major) to compensate for that?
- He would assume that there’s some threshold: 1 mm of spondylolisthesis might be tolerated, and at some level they would say, “*No, it’s too unstable.*”
- Stuart wouldn’t agree with that ‒ it’s not the distance at all
  - You go with the assessment

*Evidence Stuart offers*

- In the clinic they are inundated with athletes who are taperin now for the Olympic trials
- They come in pairs
- We might have 2 young women who are competing for a place on the U.S. Olympic Team in gymnastics, both have the same [spondy](https://en.wikipedia.org/wiki/Spondylolisthesis)
  - One they’ll recommend 6 months off of gymnastics, and a heavy stabilization program
  - The next one really wants to make it to the trials
  - Stuart can predict with 100% accuracy, who’s going to make it
- He wouldn’t say at all that we don’t try a heavy exercise stability program, regardless of the amount of slippage
  - And he’s done that with people trying to make the Special Forces in the U.S.
    - You’ve got to do a speed sit-up test and all of these things with a heavy spondy
    - He gives them the program to try and get there, and they might make it

## Weakness, nerve pain, and stenosis: treatments, surgical considerations, and more [1:55:30]

**What about nerve pain?**

*Patients who are either having weakness (such as a foot drop) or significant pain (like Peter had)*

- Stuart sees them all the time
- If he can get the nerve pain to move on the assessment, please don’t have surgery
  - Let the clinic have a try at it, and most of the time they will be pleased

> “*If I can get the nerve pain to move on the assessment, please don’t have surgery.*”‒ Stuart McGill

**Rules Stuart plays by**…

**Hypothetical assessment:** a person who’s having intermittent [sciatic pain](https://en.wikipedia.org/wiki/Sciatica), and the assessment reveals a ruptured [annulus](https://en.wikipedia.org/wiki/Intervertebral_disc), a protruding segment of disk that depending on activity is getting nearer to the nerve root (that’s driving the sciatic pain)

- Peter assumes that during the assessment, what Stuart is getting at is through some of those positional things (such as laying the person on their front, manipulating the legs) is getting the herniation to retreat into the annulus

*So you’re saying if you can demonstrate resolution under a changing movement pattern, that gives you enough confidence that this doesn’t need to be removed surgically?*

- Stuart is not looking for resolution, but if he can move the pain a little bit; and, “*Can I make it worse, and can I make it better? Now I’m starting to understand the variables that make it worse, make it better, and I play with those.*”
  - He’s not trying to sound boastful
  - He’s trying to be scientific
- Not long ago, during the NHL playoffs, Stuart flipped on the TV and listened to the announcer
  - He recognized two of his patients in the NHL playoff series
- A little bit later, he flipped to the Tennis Tour and saw another of his patient’s
- That night on UFC, he saw another patient

***Stuart explains, “In one day I see three different pro sports. Every single one of them had sciatica when they came to me. That’s some evidence that I can offer.”***

**Stuart remembers one of those players in the NHL**

- If he fully flexed, he would stir up sciatica, and increase the risk of a full-blown acute attack
- So we got him to move well, he played hockey, mindful of a skating style that he didn’t get too flexed up
- We didn’t allow him to tie his own skates
  - He said, “*Tying my own skates really set my back up.*”
  - Now, NHL players are very particular about how they tie their skates, but they coached one of the training staff to tie a skates for him
    - Some people will laugh at that, but that was all part of the plan to keep the capacity as high as he could to utilize in the game
- How he sat on the bench was also instructed

**Another fellow in the** [**UFC**](https://en.wikipedia.org/wiki/Ultimate_Fighting_Championship) **was no slouch**

- [Jiu Jitsu](https://en.wikipedia.org/wiki/Jujutsu) really put his spine in a place where it could fire off an acute attack
  - You do not want to be in the cage fighting for your life and having an acute attack
- We would limit the mat time on Jiu Jitsu
- He would stand up, do all kinds of things to minimize the cumulative stress on the disc bulge causing sciatica
- He competed
- Stuart is not afraid of nerve irritation, sciatica, etc., and it certainly doesn’t fall into the category of, “you need surgery.”
  - We’ve proven that far too many times

***Heavy instability, and when we fail to arrest the shearing movements, trapping nerves, a stenosis and it’s gone on for quite a time; when we can’t hack our way around it, it’s best to see a surgeon***

**Many different forms of stenosis**

- Central [stenosis](https://en.wikipedia.org/wiki/Spinal_stenosis)
- It might be a foraminal stenosis and a bit of arthritic activity, where they can just basically take a dremel tool and burr out around the foramen or the hole at the lateral nerve comes out

## Tarlov cysts: treatment and surgical considerations [2:00:15]

**A Tarlov cyst**

- A lot of medical colleagues say, “*Well, a* [*Tarlov cyst*](https://en.wikipedia.org/wiki/Tarlov_cyst) *(the neural cyst), they don’t cause pain.*”
- Stuart will prove to you very quickly whether or not that’s causing pain by pulling the nerve root one way or the other
- Typical pattern recognition might be a physio: might do a slump test (which is you straighten one leg and you flex the spine and neck)
- But the net stress in the middle of the cord is zero
- You’re pulling it one way; you’re pulling it the other way
  - It just goes into a little bit of tension
  - If that’s a Tarlov cyst that won’t be triggered
- A Tarlov cyst doesn’t like being pulled one way
- That patient on an exam might say, “*I don’t get pain with a slump test, but I can’t stand driving my car*.”
  - When Stuart asks them to tell him about their car, they say, “*Well, I sit upright, put my head back, and extend my leg to push on the accelerator.*”
  - He explains that they’re pulling the nerve root one way and asks, “*Where is the pain?*”
    - In their big toe
- Stuart is now going to inform his inspection of the MRI, because radiologists missed it
  - They’re not going to find a Tarlov cyst distal on the fifth root
  - But Stuart knows that the symptom and the assessment took him there logically to say, “*I know there’s something hanging up there that’s directionally specific. It’s not a friction, it’s a direction-specific tension.*”
  - And he’s found a Tarlov cyst
- The surgical procedure there is to try and drain the cyst
  - Typically it comes right back
  - But there’s a doc in Dallas who they refer all their patients with Tarlov cysts to

## The evolution of patient assessments and the limitations of MRI [2:02:15]

**Patient assessment**

- Stuart explains, “*After the first year of the experimental research clinic (running 2 years), I changed it to a 3-hour consult.*”
- He needed more time
- If the person was an old athlete, and they still had films
  - He asks, “*Remember how we used to get MRIs?*”
- They go through all the medical images

**What are the things you are looking for in the MRI that maybe aren’t as readily apparent or obvious to the radiologist?**

- Peter presumes the can explain to somebody what the MRIs are showing
  - But it’s showing axial cuts, coronal and sagittal cuts
  - They’re T1-weighted
  - They’re T2-weighted, so they highlight the disc
    - A nice healthy disc looks white on the MRI
    - Peter’s discs are jet black

*What are things you are picking up on that MRI read?*

- All of those things

**The very last** [**study**](https://pubmed.ncbi.nlm.nih.gov/29738991/) **he ever published as a professor was exactly that**

- He didn’t do very much cervical spine-specific work; most of it was lumbar
- We took whiplash patients, and every single one of them had been denied compensation because they’re now more than 2 years post whiplash
- They still continue to have symptoms
- The medical profession and the legal system was declaring them pain magnifiers
  - Saying they were exacerbating their pain for financial gain (terrible)

***The*** [***MRs***](https://en.wikipedia.org/wiki/Medical_record) ***said, “There’s no reason for your pain.”***

- Really? The MR is a static picture. What do you expect?
- We took video fluoroscopy, which is a real-time, moving X-ray
  - We’re watching the bones move now and we would have them move through their pain
  - And their pain wasn’t very rarely at the end range of motion
    - It was actually somewhere in the middle of the range
    - They would move their head like this and then the spine would clunk, and then they’d go, “*Ugh*,” and then they continue to move through
- On the video of fluoroscopy, we’d watch the rotations occurring between every vertebra

***But we know what instability is: it’s when the rotation stops and the shear begins. The ratio of rotation and shear is the marker of that cervical instability***

- Stuart shows with his hands: here would be the neck moving, rotating well, and then it would clunk
  - It was the clunk that corresponded 100% with the shot of pain
- Now, you and I both know that when a muscle contracts, it does 2 things: it creates force but it also creates stiffness

***The body uses stiffness to control motion***

**Stuart asks us to observe him (you can play along if you like)**

- Lightly stack your ears over your shoulders and have a pitch to your head that’s neutral
- Stare straight ahead
- Now, lightly touch yourself under your jaw, just above your Adam’s apple. Don’t retract your two stiff feet
- Relax
- Now, push your tongue hard to the roof of the mouth behind your front teeth
  - You felt the deep flexors activate
  - Now corners of your mouth, grimace down
- Do this to your neck
- Now keep that
- Imagine the person who’s rotating and then has the clunk
- Keep that controlling stiffness and repeat the offensive movement

***Would you believe in most people the clunk was arrested? It was gone, proving that the MRI had no ability to pick up that dynamic pain trigger.***

- We just proved what their pain trigger was
- You can imagine the psychological relief that they had to know that it isn’t in their head
- The medical profession was wrong
- And finally, they’re empowered now, because they have a strategy to start learning just a little bit of a strategy to take the clunk out

***If you arrest the clunk over time, the joint will stiffen. The bad news is you don’t move so well through that joint. The good news is the pain clunk is gone.***

## Pain relief related to stiffness and muscle bulk through training [2:07:00]

**If you’re in your early 50s**

- Things are going to be stiffening in your body, and you’re going to be experiencing this now over the next 15 years particularly
- The good news is your pain will go

**You know who really gets this?**

- Stuart has worked with a couple of former Mr. Olympias
  - That’s the top professional level of bodybuilding
- They put a lot of mileage on their joints
- They don’t really get joint pain when they’re competing because the muscles are so big, so bulky
  - They have enormous wrench handle moment arms and the stiffness holds the joints together
- When we work with them tapering down back to civilian life, some of them don’t look that different than you and me
- Believe it or not, they ache like hell
  - All their joints have these shearing translations to them now

***The cure is getting a little bit of the muscle bulk back to add some controlling stiffness and all their aches go away***

- Stuart doesn’t know if that answered Peter’s question on instability, sciatica, brachial plexus nerve traps, numb thumb and first finger
- They’re not indicators for surgery at all
- Try some of these voluntary skills and let nature take its course
  - Most of the time it will work out well with some patience and skill

**Peter’s experience going through his MRI**

- One of the really good spine surgeons Peter knows, she is happy *not* to operate
  - The really good surgeons are really happy to not operate on somebody
  - Partly what makes them so good is their judgment about when to and not to operate
- Peter goes through all his MRIs with her, even if it’s not a dedicated spine MRI
- They’re always collectively amazed at how bad his spine looks on MRI, relative to the fact that he doesn’t have any symptoms
- One of the discussions they had prompted her to contrast Peter’s back with that of another patient she had who has no obvious disc pathology, and yet is in debilitating pain
  - She explained, “*Look at the difference in the musculature of your psoas, your QL, your erector spinae. These are big beefy muscles here, and now compare it to this other patient. First of all, the muscles are about half the size and they look like Wagyu. They’re very fatty.*”
  - Her interpretation was that this person never lifted anything in their life, and though they don’t have any disc pain, their discs haven’t been decimated like Peters, but they’re more debilitated
  - She explained, “*Their inactivity has led to instability and tremendous pain*.”

**Both Peter and Stuart agree that both the deadlift till you drop strategy and the do nothing strategy are bad. Can you speak to why that person might be in pain?**

- Peter doesn’t want anybody to come away from this podcast feeling, “O*h, I better not lift weights*,” because that’s clearly the wrong message
- Stuart would want to know this person’s training program or daily routine in physical terms
- He’s willing to bet she’s a mobility monster
  - She keeps pushing the end range, softening the joints even more
  - So, on MRI, they look plump and pristine
  - He bets if we put her under a load, or we put her in bed, and she had this instability that he’s showed earlier, and she lays in bed, and the joints just fall like that a little bit, she’ll get a hell of an ache to her back
- His first question would be, “*When you roll over in bed, do you ever have a sharp pain?*”
  - That question is so indicative of if she has nice plump discs, but micro movements
- Asking, “*How many pillows do you go to bed with at night?*” is a wonderfully telling question
  - The more the pillows, the more the joint instability
  - It’s a quite high correlate
- If he had a conversation with her, he bets we will get some real insight from that, versus the person who has a mature strength history, and the joints are held together, a little bit of arthritis

> “*People are going to nail me for this one, but a little bit of arthritis is good for adding certain amount of joint stability and holding it all together.*”‒ Stuart McGill

**Stuart had a fracture of C4 as a young fellow**

- He would have some terrible episodes checking his blind spot or craning his neck to back a trailer up or something
- He has zero pain now
- His  neck is bulletproof again
- It looks horrible on a CT or an MR

***His point is the arthritis has now stabilized the joint. All the pain’s gone. He doesn’t move it very well, but he doesn’t worry about it.***

**Another example where an MRI is not predictive of pain or activity level**

- Stuart’s sister is a vet, and she sends him the X-rays of a dog
  - Terrible
- A you know, spine arthritis and nerve compromise in dogs is very breed specific
  - They lose their hind end
  - It just atrophies just like in a person
- She says, “*What do you think this dog’s doing right now?*”
  - And Stuart said, “*Well, it’s just laying in its bed.*”
  - She goes, “*No, that just won the frisbee catching championship*.”

***So again, Stuart keeps coming back to the assessment***

- Stuart doesn’t want to see another MRI of his spine unless the pattern doesn’t fit and he can’t move the pain anymore
  - An MRI of his spine doesn’t look so good; he’s got a few miles on his back
- Stuart does everything he wants to do with certain guidelines
  - He’s not 16 and he doesn’t have infinite capacity
  - So, he plays with that tipping point all the time

## Advice for the young person on how to keep a healthy spine [2:14:15]

**What would you say to the person who’s watching or listening to us right now, who is in their 20s or 30s; how would you counsel them with respect to what they could do to maximize the longevity of their spine?**

- Stuart replies, “*A young fellow comes into your office with a cigarette hanging out of his mouth, what would you say to him that he hasn’t already heard? I would love to take you over to the cancer ward at the hospital and I want to show you how your last days are going to look. That might convince a few of them on the lunacy of what they’re doing to themselves. It won’t be a hundred percent effective, and I would hazard a guess it wouldn’t be close to a hundred percent.*”
  - That’s how he answers this question

***Stuart doesn’t have very good luck when he sees someone who’s just all balled up***

- A 30-year-old called him last week, all balled up, he says, “*Whenever I do exercise, I’m just exhausted.*”
- Stuart asked the caller to get someone to hold his cellphone away from him so he could see all of him, and he asked him, “*When you sit at your chair, sit upright. Do you have any pain?*”
  - No
- Next he said, “*Good. Drop your chest down and slouch and lower your head. Do you have pain?*”
  - Yeah, I do
- Stewart replied, “*Now, don’t you think I just proved to him what caused your pain?*”
  - He said, “*Well, I’ve heard that before. I’ve sat like a cashew since I was 14*.”
- Stuart coached him to sit up, and also lay on his tummy for a bet to let this thing calm down
- He asked him what he does when he gets up in the morning
  - The man gets a cup of coffee and drives to work
- Stuart replied, “*Tomorrow  I want you to get up half an hour early and go for a walk.*”
  - Do you know he was bucking on that?

***The point is, Stuart doesn’t think he changed his behavior one little bit and he’s going to have to suffer more before he comes to a realization that he does have the power to do something***

- Peter shares this sentiment exactly
- That’s why he’s often referred to his third bout of back pain (the one that lasted a year), as the best worst experience of his life
  - He wouldn’t wish that duration or depth of pain on anyone
  - But what was so good about it is that it lasted for so long that it created a lifelong change in behavior, and an appreciation for something which is without that experience, this idea of a centenarian decathlon wouldn’t exist
- Peter explains, “*You have to sort of see what a life looks like with immobility and pain. Because even though I was only 27, I lived that year as though I was 87. And a year is long enough that it imprints*.”
- If it was only a week, no matter how bad it is, he doesn’t think it would’ve imprinted
- He’s said this before many times, “*But to this day, I still enjoy parking as far away as possible in the parking lot, even if there are plenty of spots close to the grocery store or wherever. Because I remember what it was like to not be able to walk from the car to the grocery store*.”

***Peter thinks it’s probably the nature of our species in that it’s very difficult to make a short-term sacrifice for a long-term objective without a more pressing reason***

- The larger population listening to this are people who have experienced back pain personally or watched someone they care about go through this

**What are the best resources we can point people to that can help with the types of exercises, maybe some do’s and don’ts around lower back pain?**

- Peter loves that he clarified the big 3 are great if you need stability

*But if you need mobility, we might need something different*

- Stuart challenged himself with exactly the same issue 15 years ago just as the internet was getting going

> “*But here’s the thing: There is no such thing as nonspecific back pain.*”‒ Stuart McGill

- And if that’s what the person operates on in their strategy, this nonspecific thing, it will only be dumb luck if they’re able to come up with a strategy to mitigate it

***They have to have an assessment; they can go and see someone who is very knowledgeable in converging on an understanding of their pain most of the time***

**This is why Stuart wrote** [***Back Mechanic***](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1)

- Now it’s not on the internet, and the reason is they have to have some background understanding of how their back works and then go through a series of self tests
  - That’s what the book does
- The first thing is it just says, “*Draw a table. What are activities that cause you pain? What are activities that either take your pain away or are neutral? Write them all out.*”

**Here is how you pattern recognize activities that cause you pain**

- All of those activities involve you bending backwards
- Change a light bulb overhead, and that triggers your pain?
  - We’re starting to learn a little bit about what could the candidates be
- Then we take them through some physical tests
  - Sit on a chair, slouch, extend, drop one shoulder back
  - Hold five pounds out at front with arms straight (so that’s a compression test)
  - Then we do a few self-shear tests
- Then we do some nerve tensioning postures to start converging on subcategories of their pain
- Then we say (for a simple one), “*If you have this subcategory, you get pain when you sit in front of your computer. Going for a walk is relieving*.”
- The next person sitting in the computer is their relief, and they go for a walk and that causes their pain
  - Probably more in the stenosis older person kind of category
  - The other one is a younger dynamic disc bulge

**Advice**

- 1 – Stick with lumbar support
- 2 – Have a strategic exercise session that you do every day
  - You’re going to do the big three
  - We’ll mobilize the hips
- You’re not going to sit longer than an hour at your computer
  - You just cannot reach a stage of sufficient health if you continue with that behavior, etc.
- So, that’s why you won’t find it on the internet
- You’re going to find a lot of people who do *not* have the expertise but offer a quick fix for your back pain

**Stuart has a little bit of good news for Peter in terms of his back**

- Stuart retired early; he retired at age 60
- He reached a stage where he realized what his job was
- He started as a professor in 1986
- Student meeting meant students came to see him, and they would get up and they’d work through things
  - They’d do things in the laboratory and whatnot
- Students started to migrate to this idea, “*Oh, sir, could we have an online call for student hours?*”
  - His answer was, “*No, you can’t. You get down here.*”
- In other words, Stuart’s job turned into a sitting job and it was killing him
- He realized his health and fitness was declining
- He still walked to the university
  - He strategically bought a home right on the edge of campus so he would have a 20-minute walk to and from
- Still, he was declining
- So he walked away; he shut the door to his office
- He never thought anyone would ever ask him again, as he’s not producing new data anymore
- But he was wrong on that estimate

***The point is, he healthier now than he ever was in the latter 15 years of his computerized work life***

- He rarely goes on the computer and it’s fabulous

> “*But my point in this story is I think you’re going to look forward to a resurgence of your health. Maybe you’ve got it dialed in… maybe you don’t.*”‒ Stuart McGill

- Stuart suggests that retiring doesn’t mean leaving your whole medical family and expertise
- He’s still working, and he sees patients 2 days a week, but the other 5 days, he lives a healthy life

## Resources for individuals dealing with lower back pain [2:25:30]

- Many people listening are going to say, “*You know what? I am not happy with the assessment or lack thereof that I’ve received. I’m not happy with the care that I’m receiving with respect to my lower back injury. I need to go and see Dr. McGill.*”

**What is involved in arranging that type of consultation with you?**

- Stuart feels awkward saying this, but that is why he wrote *Back Mechanic*
- He doesn’t see anybody until they’re read the book
- Most of them say, “*I don’t need to see you now.*”
  - They’ve been through the self-assessment
  - They’ve got enough out of it
- If they’re not getting enough from the book, on his website ([backfitpro.com](https://www.backfitpro.com/backpain/)), we have two layers of clinicians
- 1 – We have the **Certified Clinicians** who’ve taken that 50-hour course
  - They’ve gone through the hands-on skills training
  - They’ve written the exam
  - But Stuart has never worked with them personally
- 2 – We have a different level called **Master Clinicians**
  - Stuart has worked with every single one of those people and trained them
  - He’s seen patients with them
  - They have his confidence now that he can send them any patient and they will subcategorize them and know pretty well what to do with them
  - Stuart will continue to train those individuals
  - He seeks out stars or people who have the passion and the skill to study with him and become one of their master clinicians

**How many master clinicians are there in North America?**

- 12-15 (not many)
- They are all identifiable on the [website](https://www.backfitpro.com/backpain/master-clinician/)
- The number of certified clinicians are growing all the time
  - There’s 30-40 of them
  - They add to that every couple of months
- Stuart’s [book](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1) is a quick read, but it was a very difficult book to write
  - Writing medical textbooks for medical colleagues is easy: you putin references, you make your points, you show the strength of evidence
    - But you can’t do that with the public
    - You  have to give them enough of the truth to guide an effective strategy
    - You can’t overwhelm with with jargon, and that’s why those things are difficult to write

***Stuart’s book (***[***Back Mechanic***](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1)***) is his solution to this conundrum***

- Going to the internet (the “wild west”), you can get screwed up as much as you can be helped

§

## Selected Links / Related Material

**BackFitPro**: [Back Pain Rehabilitation, Injury Prevention & Exercise](https://www.backfitpro.com/) | BackFitPro (2023) | [1:15]

**Book by Professor Kirkaldy-Willis**: [Managing Low Back Pain](https://www.amazon.com/Managing-Back-Pain-William-Kirkaldy-Willis-dp-044307948X/dp/044307948X/ref=dp_ob_title_bk) by William Kirkaldy-Willis, 4th edition (1999) | [24:15]

**Anatomy models of the spine**: [Dynamic Disc Designs](https://dynamicdiscdesigns.com/) (2023) | [27:45]

**Partial disc herniations corrected with traction and motion**: [Disc prolapse: evidence of reversal with repeated extension](https://www.backfitpro.com/medical-scientific-articles/2009/[91]Scannell,J.P.(2009)Disc-prolapse-Evidence-of-reversal-with-repeated-extension[Spine].pdf) | *Spine* (J Scannell & S McGill 2009) | [52:30]

**Stuart’s big 3 exercises**: [Stuart McGill’s “Big Three” Low Back Exercises](https://www.chirocentre.com.au/stuart-mcgills-big-three-low-back-exercises/) | Chiro Center (2023) | [56:15]

**Stuart recommends this video explaining his big 3 exercises**: [3 Core Exercises You Should Do EVERYDAY! (The McGill Big 3)](https://youtu.be/LXYPETeHZlA?si=5WJY8iEX4yuyAR_M) | YouTube (elifts, B Carroll 2021) | [56:15]

**Muay Thai athletes punch harder after doing McGill’s big 3**: [Effect of long-term isometric training on core/torso stiffness](https://www.backfitpro.com/medical-scientific-articles/2015/[25]-Lee,B.-(2015)-The-effect-of-long-term-isometric-training-[J.-Strength-Condit.].pdf) | *Journal of Strength and Conditioning Research* (B Lee & S McGill 2015)  | [1:02:00]

**Testimonials on Stuart’s website**: [Testimonials](https://www.backfitpro.com/testimonials/) | BackFitPro (2023) | [1:23:00]

**The monster walk**: [The Monster Walk Exercise Targets Your Entire Lower Body With Just a Mini Band](https://www.livestrong.com/article/13778143-monster-walk-exercise/) | Caroline Juster, Livestrong (2023) | [1:25:00]

**Stuart’s book**: [Back Mechanic](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1CJB7YPTYHXNX&keywords=back+mechanic+by+dr.+stuart+mcgill&qid=1702571656&sprefix=back+mechanic%2Caps%2C101&sr=8-1) by Stuart McGill (2015) | [1:39:00, 2:20:48, 2:27:30]

**Stuart’s Summit Course**: [McGill Method Summit](https://www.backfitpro.com/mcgill-method-summits/) | BackFitPro (2023) | [1:44:15]

**Additional training for clinicians**: [Become A McGill Method Provider](https://www.backfitpro.com/clinicians/certification/) | [backfitpro.com](https://www.backfitpro.com/) (2023) | [1:44:15]

**Stuart’s study on whiplash patients**: [Digital tracking algorithm reveals the influence of structural irregularities on joint movements in the human cervical spine](https://pubmed.ncbi.nlm.nih.gov/29738991/) | *Clinical Biomechanics* (C Balkovec et al 2018) | [2:03:30]

**Articles written for the layperson on Stuart’s website**: [Category: McGill Articles](https://www.backfitpro.com/category/mcgill-articles/) | [backfitpro.com](https://www.backfitpro.com/) (2023)

§

## People Mentioned

- [Kirkaldy-Willis](https://journals.lww.com/spinejournal/citation/2006/08150/in_memoriam__a_tribute_to_william_kirkaldy_willis,.3.aspx) (Canadian spine surgeon who wrote [*Managing Low Back Pain*](https://www.amazon.com/Managing-Back-Pain-William-Kirkaldy-Willis/dp/044308789X)) [24:15]
- [Joe Frazier](https://en.wikipedia.org/wiki/Joe_Frazier) (one of the greatest heavyweight boxers) [1:06:45]
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) (world heavyweight champion from 1987 to 1990) [1:07:00]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali_(British_boxer)) (famous British boxer) [1:07:30]
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) (sprinter and world record holder) [1:08:00]
- [Ed Coan](https://en.wikipedia.org/wiki/Ed_Coan) (widely regarded as the greatest powerlifter of all time) [1:22:15]

§

![](https://peterattiamd.com/wp-content/uploads/2024/01/bio-stuartmcgill.png)

##### Stuart McGill, Ph.D.

Stuart McGill earned a Bachelor of Physical Education from the University of Toronto. He earned a Masters in Science at the University of Ottawa to earn a Masters in Science, then a Ph.D. at the University of Waterloo. Dr. McGill stayed at the [University of Waterloo](https://uwaterloo.ca/kinesiology-health-sciences/people-profiles/stuart-mcgill) as a professor of Kinesiology and Health Sciences for 32 years. He is now a distinguished professor emeritus.

His laboratory and experimental research clinic investigated issues related to the causal mechanisms of back pain, how to rehabilitate back-pained people and enhance injury resilience and performance. During his academic career he authored over 240 peer-reviewed scientific journal papers, received many international awards, and mentored over 40 graduate students.

His work continues at Backfitpro Inc. where he is the chief scientific officer. He sees elite athletes and people with difficult back cases. He has also authored several books on the mechanics of pain, fitness, and performance as it pertains to the back including: [*Ultimate Back Fitness and Performance*](https://www.amazon.com/Ultimate-Fitness-Performance-Sixth-Stuart-McGill-dp-0973501839/dp/0973501839/ref=dp_ob_title_bk), [*Low Back Disorders*](https://www.amazon.com/Low-Back-Disorders-Evidence-Based-Rehabilitation-ebook/dp/B01BIB1PHQ/ref=tmm_kin_swatch_0?_encoding=UTF8&qid=1702663488&sr=8-6), [*Back Mechanic*](https://www.amazon.com/Back-Mechanic-Stuart-McGill-2015-09-30/dp/B01FKSGJYC/ref=sr_1_1?crid=1OOUUNKK9RR6Q&keywords=stuart+mcgill+back&qid=1702663488&sprefix=stuart+mcgill+back%2Caps%2C146&sr=8-1), and [*Gift of Injury*](https://www.amazon.com/Injury-Stuart-McGill-Brian-Carroll/dp/0973501863/ref=sr_1_4?crid=7ZX6PQJMGOXI&keywords=stuart+mcgill&qid=1702663527&s=books&sprefix=stuart+mcgill%2Cstripbooks%2C97&sr=1-4). [[backfitpro.com](https://www.backfitpro.com/about-us/)]