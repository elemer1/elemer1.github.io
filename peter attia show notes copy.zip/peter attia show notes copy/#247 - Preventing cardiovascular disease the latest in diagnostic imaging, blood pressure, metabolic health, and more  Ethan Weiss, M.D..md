# #247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.

**Source:** [https://peterattiamd.com/ethanweiss2/](https://peterattiamd.com/ethanweiss2/)

---

Ethan Weiss is a preventative cardiologist at UCSF, an entrepreneur-in-residence at Third Rock Ventures, where he is working on a project related to cardiometabolic disease, and a [previous guest](https://peterattiamd.com/ethanweiss/) on The Drive. In this episode, Ethan compares and contrasts the diagnostic imaging tools, CAC (coronary artery calcium score) and CTA (CT angiography), used to image plaque—including the latest in CTA software—and how these tools inform our understanding of ASCVD risk and guide clinical decision-making. Ethan discusses the types of plaque that cause events and the data that make a case for optimal medical therapy over stenting outside of particular cases. He explains why high blood pressure is problematic and walks through the data from clinical trials testing aggressive treatment. He talks about the best way to actually measure blood pressure, why we shouldn’t simply accept that blood pressure rises with age, and how he uses different pharmaceutical agents to treat hypertension. Additionally, Ethan explains our current, but limited, understanding of the role of metabolic health in ASCVD. He discusses the impact of fat storage capacity and the location of fat storage and explains how and why there is still a residual risk, even in people who have seemingly normal lipids, don’t smoke, and have normal blood pressure.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ethanweiss2/the_Drive_public.png)

Play

#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.

#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.

1x15s30s

0:002:12:54

## We discuss:

- Ethan’s entrepreneurial work in the cardiometabolic disease space [4:30];
- Calcium scans (CAC scores) and CT angiography (CTA), and how it informs us about ASCVD risk [6:00];
- Peter’s historical CAC scores, CTA results, and how one can be misled [10:45];
- How Peter’s CTA results prompted him to lower his apoB [14:45];
- Calcium scans vs. CT angiogram (CTA) [21:15];
- How Ethan makes clinical decisions based on CTA results and plaque burden, and the importance of starting treatment early to prevent ASCVD [28:15];
- Improved methods of CTA to grade plaque lesions and how it’s shaped medical decisions such as stenting [33:45];
- Why Ethan favors optimal medical therapy over stenting outside of particular situations [41:45];
- The need for FFR CTA, and the potential for medical therapy to eliminate ASCVD [54:00];
- The fat attenuation index (FAI) and other ways to measure inflammation in a plaque [57:30];
- Statins and exercise may increase the risk of calcification, but what does this mean for risk? [59:45];
- The root cause of statin hesitation despite evidence that statins are a profoundly important intervention [1:05:30];
- Importance of keeping blood pressure in check, defining what’s normal, and whether we should just accept higher blood pressure with age [1:10:45];
- Blood pressure variability, how to best measure it, and data suggesting the enormous impact of keeping blood pressure down [1:21:00];
- Drugs for treating high blood pressure recommended by the ALLHAT trial [1:35:15];
- What the SPRINT trial says about the aggressive treatment of hypertension, and the risks of such treatment [1:38:15];
- Confirmatory results in the STEP trial for blood pressure, and how Ethan uses the various pharmacological agents to lower blood pressure in patients [1:43:15];
- The role metabolic health in ASCVD: what we do and don’t know [1:51:00];
- The impact of fat storage capacity and the location of fat storage on metabolic health and coronary artery disease [1:56:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Ethan Weiss was a previous guest on [episode #52](https://peterattiamd.com/ethanweiss/) (May of 2019); at that time, Ethan was a professor of Cardiology at UCSF
- He still holds a position at UCSF where he focuses on preventative cardiology, but his main job is as an entrepreneur-in-residence at [Third Rock Ventures](https://www.thirdrockventures.com/people/ethan-weiss), where he is working on a project related to cardiometabolic disease, something that we touch on in this episode
- He continues to have a small clinical practice in preventative cardiology, and a lot of our discussion really focuses on that
- Peter wanted to have Ethan back on to pick things up where they left off on the previous podcast
- In this episode, we focus a lot on ASCVD (atherosclerotic cardiovascular disease), and we talk about the diagnostic tools available to understand risk
- Because many listeners weren’t necessarily listeners three or four years ago when we talked with Ethan, we go through an overview of the difference between a CAC (coronary artery calcium score) and a CTA (CT angiogram) as diagnostic tools that give us enormous insight into someone’s existing and future risk of ASCVD
- We speak about some of the newer versions of the CTAs
  - Which really aren’t so much about the CTAs, but are about some of the software overlays that are used to at least theoretically make the CTA more valuable
- We talk a little bit about how extreme endurance athletes may or may not be at higher risk for calcification, and we talk about potentially the role of statins in that
- We then move on to a discussion about blood pressure
  - This is such an important point that this will not be the final word on blood pressure
- We discuss the holy triad of risk for cardiovascular disease
  - 1 – Hypobetalipoproteinemia (which is just a fancy word for elevated apoB); we discuss extensively
  - 2 – Smoking; this seems so obvious that it really warrants little attention for people that are health conscious, but we have done at least on podcast on smoking cessation
  - 3 – Blood pressure; Peter thinks this topic is really important
- We talk about the importance of knowing your blood pressure, how to actually check your blood pressure
  - Why high blood pressure is problematic beyond just the heart,
  - If you think it’s bad for your heart, wait until you see what it does to your kidney
- Then we talk about the different pharmaceutical agents out there and the trials that have taught us how these things work and when they should be instituted
- Finally, we end the conversation looking at what we know and don’t know about how metabolic health plays a role in ASCVD
  - There is still residual risk in people who have perfectly low and normal lipids who don’t smoke and have normal blood pressure
- This is a fascinating discussion, and it’s only the thin end of a wedge in the exploration of the role of blood pressure and some of the more nuanced cellular metabolic ill effects in ASCVD

## Ethan’s entrepreneurial work in the cardiometabolic disease space [4:30]

**Ethan’s career has evolved over the past couple of years**

- Ethan had a bit of a midlife crisis and decided he didn’t want to keep doing the same thing for the next 25 years
- He was given the opportunity to get involved with a local group of investors who create biotech companies
- He closed his lab and has become a volunteer clinical faculty at UCSF
  - He sees patients infrequently
  - He spends most of his time working to build a new company (he’ll explain more later)

## Calcium scans (CAC scores) and CT angiography (CTA), and how it informs us about ASCVD risk [6:00]

**A quick recap of what a calcium score (CAC) is and a CT angiogram (CTA)**

- They spent a lot of time talking about the distinction between [calcium scanning (CAC)](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) and [CT angiography (CTA)](https://en.wikipedia.org/wiki/Computed_tomography_angiography) in [Ethan’s previous podcast](https://peterattiamd.com/ethanweiss/) (at 1:40:15)
- They used the analogy that a calcium scan demonstrates a site of a prior injury
- What we know is that the more calcium you have in your arteries, the worse you do
  - The higher the risk of both cardiovascular and all cause problems
  - We suspect that calcium represents a healed plaque, so the amount of calcium you have in your arteries is strongly related to the amount of plaque that you have in your arteries

***We know that the amount of plaque you have in your arteries is related to your risk of having heart attacks and dying from heart attacks***

- Ethan uses an analogy with his patients‒ a calcium scan is like a satellite image of your heart
  - It gives you a sense of any damage that has occurred over your lifetime
  - It also gives you a nice adjunct indicator of your overall risk of dying from a heart attack
- One of the nice things about a calcium score is it’s very, very low in radiation
  - Even CTAs are low now (we’ll talk about that later)
- The calcium scan is also a very inexpensive tool; *some* places do these scans for ~$200
  - (But you can still find some places still charging $2,000+ for the same scan)
- The calcium scan is a low-risk procedure; it doesn’t require dye
- And it provides great insight, especially the first time it’s done

**Ethan did a “full 180” on the utility of calcium scans**

- When he first started his cardiology practice in the early 2000s, he thought [calcium scans](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) were annoying, and he didn’t know what to do with them
- Obviously there’s epidemiologic value in understanding the risk of different populations
- Now he finds value in many contexts and even in individual patients
- A calcium scan doesn’t have value for everybody; in a 25-year-old, it is probably not worth anything
- Calcium scanning is now a tool that he uses regularly
- Peter explains this to patients as a 2×2 of young versus old and zero versus non-zero calcification (see the figure below)
  - There are two areas where the scan provides insight (shown in blue below)
    - Older people (70+) who have zero calcification
    - Young people (45 or 50) who already have calcification
  - And there are two areas where the scan does not provide insight (shown in white below)
    - If a 40-year-old has a calcium scan of zero, you haven’t really learned a lot
    - Further, if a calcium scan of zero in a 40-year-old is accompanied by other risk factors, Peter would not be dissuaded from aggressively treating those risk factors
  - Similarly, when an 80-year-old has a calcium scan of zero, you might be less inclined to push for aggressive measures
    - Even though there could be false negatives

![](https://peterattiamd.com/wp-content/uploads/2023/03/f1-ethanweiss2-1024x499.png)

**Figure 1. 2×2 for interpreting calcium scan results, with informative results highlighted in blue**.

- Peter has spent some time in the literature on this and learned that a calcium scan is a relatively imprecise measure
  - The thickness of the slices that are used in that scan are significantly greater than the slices that are used in the [CT angiography](https://en.wikipedia.org/wiki/Computed_tomography_angiography)

## Peter’s historical CAC scores, CTA results, and how one can be misled [10:45]

- When Peter was in his mid 30s (2008/2009), he had his first calcium scan
  - At the time, his doctor thought he was crazy because he was 35 and exercising at least 24 hours a week
  - Peter has a family history of horrible ASCVD, so this scan made sense to him
- His calcium scan showed he had a score of six
  - He had a single foci of calcium in his [LAD (left anterior descending artery)](https://en.wikipedia.org/wiki/Left_anterior_descending_artery)
  - Nobody seemed to care because his lipids were not that bad
    - His LDL-C was about 120 mg/dL
  - But this changed his life and interest in this field forever
- Fast forward to 2016 (6-7 years later), he had a CT angiogram and a calcium scan
  - The calcium scan showed a score of zero
  - The CT angiogram (which is at much finer resolution) found a tiny speck of calcium in the proximal LAD; no other findings
- The remarkable radiologist [Bob Peters](https://www.linkedin.com/in/robert-peters-md-28b40a7) explained that this is not uncommon, “*That little speck you had six years ago can easily be missed*”
  - If you had five calcium scans, half of them would miss it because it’s just too small, but now in the CTA, we can see it
- Peter repeated the CTA very recently in 2022
  - He’s partially interested in the progression of soft plaque
  - This time the calcium score came out as two and the CT angiogram was identical to what it was in 2016 (6 years earlier)
  - So you could certainly believe that if he had a CTA in 2008 or 2009, it would’ve looked similar
  - And you could argue that for basically the same lesion, the score was six, then zero, then two (in that order)

**Have you seen this yourself in patients where you’ve had the luxury of both longitudinal assessment and simultaneous CAC and CTA?**

- Ethan cannot think of anybody, but this doesn’t surprise him
- But he is curious what the percentiles of those results were
  - He can imagine that calcium score of six when Peter was 35 was 99th percentile
    - It was 75-90th percentile
- There’s a big difference even between six and two and a huge difference between six and zero
- Peter’s guess is that at a low enough calcium score, this is not uncommon
- When Peter dug into the literature, he realized that 15% of people who have a zero calcium score have a finding on CTA‒ either a calcium that was not picked up or a soft plaque
  - So it’s not just the 15% that have something, but 10% of those people have something that would be deemed relevant on a CTA
  - Further, 1.5-2% of those people who have a negative CAC have an unstable plaque on CTA
- Ethan is not familiar with the data, but he would imagine that 15% is largely represented in younger people
  - Peter would have to go back and look; that’s a great question
  - Here are a few studies on that topic ([Ergun et al., 2011](https://pubmed.ncbi.nlm.nih.gov/20734235/), [Abdalla et al., 2020](https://www.ejropen.com/article/S2352-0477(19)30052-8/fulltext), [Feuchtner et al., 2021](https://www.mdpi.com/2308-3425/8/11/157))

## How Peter’s CTA results prompted him to lower his apoB [14:45]

The other question Ethan has is, *what has Peter’s average* [*apoB*](https://en.wikipedia.org/wiki/Apolipoprotein_B) *been?*

- It has gotten lower and lower over the past 15 years
- At the time of his first calcium scan, he didn’t know what apoB was
  - This was about the time he met [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876), and Peter began to target an apoB of 30-40 mg/dL
- Peter never had a particularly high apoB, but the CTA finding gave him more concern because he didn’t have obvious risk factors
  - He’s normotensive
  - He doesn’t smoke
  - His apoB at the time was 85-90  mg/dL
- But Peter had watched countless men in his family die from heart attacks, some as young as in their late 40s
  - He realized this is probably polygenic, and there’s something going on here that is not the standard “plug and play” risk factor

**Ethan gets the really tough cases where the risk factor isn’t simply a high LDL-C**

- The tools are focused at lowering apoB through number of means
- We’ll come back and discuss blood pressure later

**Ethan’s thoughts on Peter’s results**

- There was clearly something else there
- It’s hard to make the argument that Peter was a “ticking time bomb” with a “widowmaker,” that he was going to drop dead of a heart attack
- Peter had a tiny minuscule lesion

***The question is‒  what would’ve happened to you over the next 15-20 years had you not taken the intervention that you did pharmacologically?***

**ApoB, a causal agent of ASCVD**

- Peter points out that apoB is necessary but not a sufficient criteria for atherosclerosis and as such, removing it removes atherosclerosis
- Pharmacologically keeping his apoB low is Peter’s best guess as to why there has been no progression in this disease in the last 15 years
  - He’s taken away the causal agent
- Ethan agrees, apoB is absolutely necessary for disease, and the data suggest that if apoB levels are “bottomed out”, you can’t get atherosclerosis
  - This has been demonstrated in both humans and many other animal species
- He thinks high apoB is sufficient for disease in some cases (like [FH, familial hypercholesterolemia](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia))
- He doesn’t think you have to have something else to get atherosclerosis in cases where apoB is sky high
- There are arguments about the sufficiency of apoB
  - Lean mass hyper nonsense is an argument people make about high apoB not being sufficient
  - There are definitely some people with FH who don’t go on to have ASCVD so this suggests some other genetic modifier or something else that protects them

**Peter’s takeaway**‒

- ApoB is *not* sufficient but *is necessary* for ASCVD
- Compared to smoking and [small cell lung cancer](https://en.wikipedia.org/wiki/Small-cell_carcinoma) (the most smoking-associated cancer), smoking is even weaker
  - Smoking is neither necessary nor sufficient
  - But nobody in their right mind that would argue that not smoking does not improve risk
  - The analogy is that’s the equivalent of saying that reducing apoB does not improve ASCVD risk
- Peter doesn’t think elevated apoB is safe

**The influence of diet on apoB levels**

- Peter is hoping they can formulate an argument that there are other ways to treat apoB besides diet
  - Because the diet that is making apoB high, is producing other benefits
  - Can you keep the diet, and address a high apoB pharmacologically?
- Ethan points out that part of the nature of the heterogenetic response is that [penetrance](https://en.wikipedia.org/wiki/Penetrance) of an environmental factor in this case is not 100%, in terms of causing risk
  - Most environmental factors are *not* completely penetrant; maybe [cyanide](https://en.wikipedia.org/wiki/Cyanide_poisoning) has complete [penetrance](https://en.wikipedia.org/wiki/Carbon_monoxide)
  - [Carbon monoxide](https://en.wikipedia.org/wiki/Carbon_monoxide) at a certain concentration has 100% penetrance

## Calcium scans vs. CT angiogram (CTA) [21:15]

Ethan tells patients, “*What you get from a* [*CTA*](https://en.wikipedia.org/wiki/Computed_tomography_angiography) *is clarity and more information, which in most cases is really, really good*”

- This comes at a small cost in terms of increased radiation, some potential risk of the contrast (relatively small), and the biggest cost it it’s hard to get it paid for
  - It’s more expensive if you pay for it yourself out of pocket, which is usually the case for his patients
  - Almost none of them are reimbursed by insurance
- Calcium scans are also paid for out of pocket (90%), but they are inexpensive (a $100-200)
- This is one of the problems with our healthcare system, the cost to patients is *not* transparent unless they go and do some digging
  - And it’s not clear to them what they are going to pay until after they have it done
  - Fewer than 50% of Ethan’s patients have insurance coverage for a CT angiogram, and the negotiated rate is different based on the carrier you have
  - Patients will spend $700 to $3000

***If CTA’s were covered universally, Ethan would go to this test over the calcium scan***

- It provides so much more information
- In a lot of cases (like when Peter was 35), we don’t have a lot of data and the calcium score by itself just doesn’t add that much
- Peter tells his patients that the IV contrast is virtually a non-risk outside of a handful of settings, which are clearly well understood and we know how to handle those pretty well
- The radiation these days is low, in the neighborhood of two millisieverts for a person our size
  - That’s 4% of your annual allotment of radiation
- The typical cost is $2,000 to $2,500
  - Some insurance carriers are able to negotiate a lower rate
  - The rate is also different at different institutions
  - Ethan advises patients to shop around

**What do you get for your money? What different information do different scanners provide?**

- Different scanners provide different resolution
- The amount of radiation exposure is also different
  - Peter notes this can be 10x different; some scanners expose you to 20 millisieverts (up to 40% of your annual allotment for radiation, which Peter thinks is too much)
- Ethan points out another layer of complexity‒ how these different tests are applied and getting the information
- When Peter orders these CTA scans, he gets beautiful images‒  they’re 3D reconstructed and then they’re 2D sectioned
  - You’re looking at the lumen, the tube of the artery
- In both a CTA and calcium scan, that little speck of calcium shows up in the wall of the artery
- You’re also looking for soft plaque, but soft plaque doesn’t show up anywhere in the calcium score
  - So **you can have a significant burden of cardiovascular disease without any calcium**; that’s the thing that might gets missed a lot and that shows up in that 15% of people who have a zero calcium score
- Another possibility is that where the calcification is placed is *not* problematic; it’s just that it’s a harbinger of whatever it took to get there

***Do you look at patients with a high burden of soft plaque and no calcification as having even higher risk?***

- Ethan thinks a high burden of plaque is a problem, period
- Could a high burden of calcified plaque be less risky because it’s more stable? In theory, yes
  - But he gets really nervous about trying to impute plausibility and things like that to drive clinical decision-making

> “*I think the reality is a lot of plaque is bad*”‒ Ethan Weiss

- A calcium score of 4,000 is high risk; “*by definition [this] means they’ve got a shit load of calcium*”
  - Even if they don’t have any soft plaque, the risk is still high

***Ethan prefers the information he gets out of a CTA; it provides so much more information, and you don’t have to make that distinction between soft and hard plaque***

- Ethan is not sure the field is at the point yet where they can make a compelling argument about plaque characteristics
- Since the 70s when pathologists were doing autopsies on people who died of sudden cardiac death, the field has been trying to understand characteristics of plaque, vulnerable plaque, and what confers risk of rupture and an event
  - This is still poorly understood

***Ethan only uses a CTA as an estimation of how much plaque is there***

## How Ethan makes clinical decisions based on CTA results and plaque burden, and the importance of starting treatment early to prevent ASCVD [28:15]

**Do you think that in the research setting, things like intravenous ultrasound or intravascular ultrasound (where they can actually look and measure the thickness of the cap on the athero), are any better, even if they’re impractical from a clinical perspective?**

- Ethan thinks we might convince ourselves it means something that it doesn’t
- In the early days (until 1979) we learned that ruptured plaque leads to a thrombosis, and that’s what causes a heart attack
- [ISIS-2](https://pubmed.ncbi.nlm.nih.gov/2899772/) was published in the late 1980s; it showed that if you gave [streptokinase](https://en.wikipedia.org/wiki/Streptokinase), you could reduce the risk
- We learned early on that the plaques that ruptured and led to sudden cardiac death were often the smaller plaques
- Patients often come in after somebody prominent dies
- After [Sheryl Sandberg’s](https://en.wikipedia.org/wiki/Sheryl_Sandberg) husband died on a treadmill a few years ago, Ethan had probably 25 people call that week wanting to come in for a risk assessment
  - He doesn’t know anything about that case, but his guess is that in younger people who die of a heart attack suddenly, the cause is relatively mild plaque that wouldn’t trigger any discussion of revascularization and wouldn’t make anybody nervous

> “*Those [mild, small plaques] are the plaques that end up causing problems*”‒ Ethan Weiss

**We can begin to weave together reasons why that might be**

- Maybe in a person who’s got more plaque burden, there’s more chance for ischemic preconditioning and therefore the chance of a malignant arrhythmic response to the ischemia is lessened because of that
- Ethan’s point is that we don’t have a satisfactory understanding of the characteristics of plaque (or it’s volume) that would allow him to change the way he practices medicine

***For this reason, he treats any plaque (30% plaque), pretty much the same way he treats people with extensive plaque; he treats them maximally with the best medical therapy he can offer***

- Peter shares this sentiment
  - With his patients he is treating the causative risks, not the end-stage problems
  - It’s insane to think you need to wait until you have a  30% stenosis or a calcium score of 200 to start acting
- This goes back to the smoking analogy‒ Peter tells someone the second they pick up a cigarette to put it down; he doesn’t wait until their pulmonary function tests are problematic or they’ve been smoking for 20 years and their risk is significant
- For Ethan, this is the sort of “eye bleeding” experience that he has with insurance companies when he wants to add [PCSK9 inhibitors](https://en.wikipedia.org/wiki/PCSK9#Inhibitors) to statins (or other meds)
  - Often they’ll say the patient needs to have an event first

> “*You’re going to ask me to let my patient have a heart attack so that I can prescribe the drug that’s going to prevent them from having a heart attack? I mean, it’s really incredible*.”‒ Ethan Weiss

- The problem is that all of these trials are so incredibly expensive to do that the information that we’re going to get from the most rigorous randomized clinical trials is going to be limited
  - They’re not going to ask and answer all the questions you’re interested in; it’s just not feasible
- So we have to find a way to make decisions to treat patients independent of this gold standard level evidence, and hopefully the insurance companies come around
- Peter has accepted the fact that we’re never going to have the gold standard evidence that we need in the most important demographic; the demographic for whom we have the most runway to effect change (40-year-olds)
  - There will never be a study done on the 30-year risk of ASCVD in a cohort of 40-year-olds
    - One group whose apoB is reduced to 30 because we’ve used a PCSK9 inhibitor plus or minus whatever other agent we need
    - Versus the group that’s managed with standard of care or some placebo or something else
  - Yet Peter feels more convinced of the outcome of that theoretical trial than he does of virtually any other theoretical trial he could ever think of

> “*And yet, it’ll never be done and therefore there will never be an evidence-based case for true prevention of ASCVD*”‒ Peter Attia

- In his [upcoming book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=3JBEH14X6GEJB&keywords=OUTLIVE%3A+The+Science+and+Art+of+Longevity&qid=1675262516&sprefix=outlive+the+science+and+art+of+longevity%2Caps%2C136&sr=8-1), Peter says something very bold, “*ASCVD should basically be an orphan disease. There’s actually no reason it needs to be the leading cause of death. It really doesn’t even need to be in the top 10. It’s that preventable if you start early enough and if you’re maximally aggressive.*”
  - It just becomes a question of working through the challenges of tolerating side effects in patients who are sensitive

## Improved methods of CTA to grade plaque lesions and how it’s shaped medical decisions such as stenting [33:45]

**FFR CT-angiography**

- There were two trials that looked at [FFR (fractional flow reserve)](https://en.wikipedia.org/wiki/Fractional_flow_reserve) in combination with CT-angiography, [FAME](https://www.nejm.org/doi/full/10.1056/NEJMoa0807611) and [FAME 2](https://www.nejm.org/doi/full/10.1056/NEJMoa1205361)
- FFR is performed in a cath lab; it’s basically a way to detect a pressure gradient across a [stenosis](https://en.wikipedia.org/wiki/Stenosis)
- Ethan explains it to patients with this analogy‒ if you take a garden hose and squeeze it, there is pressure proximal to where your finger squeezes the hose, and the pressure on the other end is going to be lower
- Effectively what they do is use a wire with a pressure sensor on one end, they put a wire one end of a blockage and another wire on the other end of the blockage and measure the delta
- FFR = pressure distal to the lesion ÷ pressure proximal to the lesion
- Using a mathematical formula, you can impute the diameter of the artery relative to the diameter of the unobstructed artery (or the garden hose in this analogy), and that gives you a way to get at the severity of the blockage
- This stems from the 40-year odyssey to try to take a very qualitative measure (of the % stenosis), which happens in a catheterization laboratory
  - If you’ve ever seen it, it’s done very much by gestalt
- The difference between 30 and 50 is probably not that meaningful

***Ethan thinks of the FFR as high-grade, modest, and low-grade; this has been the #1 tool developed to try to supplement the information you get from that very qualitative assessment of how bad does a lesion look visually***

**Other improvements**

- [IVUS (intravascular ultrasound)](https://en.wikipedia.org/wiki/Intravascular_ultrasound)
- There have been quantitative coronary angiographies where they actually try and take cursor and electronically draw around the diameter of the vessel
- Back in the old days, [Mike Gibson](https://scai.org/c-michael-gibson-md-mscai) used to do this blush thing; it would basically count the number of frames it takes for the contrast dye to leave the myocardium
  - That was another indication of how severe the lesions were

“*FFR evolved as a hemodynamic way to be able to impute the severity of the stenosis*”‒ Ethan Weiss

**When a stent is beneficial [36:30]**

- [FAME](https://www.nejm.org/doi/full/10.1056/NEJMoa0807611) was the first study to show that if you had a significant pressure drop that there was a bad lesion, and it conveyed worse outcomes in people who didn’t get a stent
  - If the ratio of the pressure in the upstream sensor was higher than the downstream sensor

*There are two subsets of people who should get a stent:*

- 1 – Somebody who is actively having a [MI (myocardial infarction)](https://en.wikipedia.org/wiki/Myocardial_infarction), and they show up in the ED (emergency department) with chest pain; these are [STEMIs (ST-elevation MI)](https://en.wikipedia.org/wiki/Myocardial_infarction#STEMI) where there is complete obstruction of blood flow); this is what everyone is now calling [ACS (acute coronary syndrome)](https://en.wikipedia.org/wiki/Acute_coronary_syndrome), and we used to call unstable angina
  - [PCI (percutaneous coronary intervention)](https://en.wikipedia.org/wiki/Percutaneous_coronary_intervention) is standard of care
  - [Thrombolytics](https://en.wikipedia.org/wiki/Thrombolysis) are used sparingly and only in remote places where they can’t get into a cath lab
  - Most hospitals have STEMI teams that the ER department can page, and everybody come in from the technicians in the cath lab to the interventional cardiologist, the fellows, everybody else so that the patient can get a stent and clear the blockage within the first 24 hours (this is an emergency)
- 2 – non-STEMI has the same pathophysiology‒ there is ruptured plaque and a thrombus sitting on the plaque but it doesn’t completely obstruct blood flow
  - There is no STEMI team activation, but there is general consensus that those people benefit from going to the cath lab early and having a stent to fix that blockage
- The only distinction between those people is the [ST](https://en.wikipedia.org/wiki/ST_segment) change on the [EKG](https://en.wikipedia.org/wiki/Electrocardiography) when they present
  - This is sensitive but not 100% sensitive
  - Some lesions are obscure; for example, a posterior MI, you’d have to do posterior leads to be able to see that

***A STEMI is an emergency where the patient goes straight to the cath lab. A non-STEMI (or ACS) is urgent. These people generally end up in the cath lab, and it wouldn’t be a bad thing to have them go there relatively quickly depending on how unstable they are.***

- Unstable symptoms being:
  - Blood pressure is labile
  - Heart failure
  - Ongoing chest pain that is refractory to medical management
  - *These people should go straight to the cath lab*

- What has changed over the past 15 years is that people with plaque-but without symptoms-generally don’t get stented
  - With the exception of plaque in the [proximal LAD](https://en.wikipedia.org/wiki/Left_anterior_descending_artery) or left main

**Are these symptoms in day-to-day life or under stress and provocation?**

- People who have *any symptoms at rest* fall into that first category; these are **unstable symptoms**
  - They should be hospitalized and would go to the cath lab in a 24-hour window
- If you’re arguing with your wife and you get chest pain, you can argue if that is unstable or stable symptoms
  - It’s mostly the non-classic [exertional angina](https://en.wikipedia.org/wiki/Angina#Stable_angina) where you’re walking up a hill and you get chest pressure/ tightness/ rarely pain; it gets better when you stop or take a [nitroglycerin](https://en.wikipedia.org/wiki/Nitroglycerin_(medication)) (stable symptoms)
- People who have plaque but not symptoms (either stable or unstable) are generally treated medically (with some exceptions)
- The people Ethan finds most interesting are those with [classic stable angina, stable symptoms](https://en.wikipedia.org/wiki/Angina#Stable_angina)
  - When they walk up a hill, they feel chest tightness like somebody is tightening a belt around their chest
  - And when they stop walking, it gets better
  - These people require the most thought

## Why Ethan favors optimal medical therapy over stenting outside of particular situations [41:45]

**When stenting does** ***not*** **offer additional benefit**

- The [COURAGE trial](https://www.nejm.org/doi/full/10.1056/NEJMoa070829) taught us that it’s okay to have a lot of plaque and not necessarily intervene on it
- This is part of the reason why FAME is not that interesting to Ethan because we’ve already answered the question about stenting people without symptoms
  - Even if they have significant lesions, stenting doesn’t offer a benefit over optimal medical therapy
- Now there is some discussion around not stenting in patients with symptoms
- Some people think medical therapy in all cases (people with symptoms), and there’s this nuance in between with people who think you should give a trial of medical therapy and see if the symptoms get getter
  - Going to the cath lab is not automatic

***Ethan’s philosophy‒ if you can make the symptoms go away with medical therapy, then there’s no need to stent the artery, but he does use interventional cardiology for people who have refractory symptoms***

- The unstable emergency acute setting is a different story

**What about the patient with a really high calcium burden (north of 1,000) who never experienced symptoms and is in their 50s (young)? Would you put them on a treadmill at 15** [**METs**](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task) **to see if they have any ST changes or wall motion abnormalities?**

- Ethan does not
- Even if they had symptoms in a stress test, he would still probably try to optimize medicines
- It would be different if somebody came in who was on great medicines and was still having symptoms

***Routinely, he does not do anything to people who have high calcium. The CTA might not be very useful because there is so much calcium that it obscures the ability to see into and beneath the vessel.***

- Ethan doesn’t automatically stress test in someone with high calcium and no symptoms

***He doesn’t use stress testing anymore as a way to follow coronary disease. That was something they used to do in the old days.***

**Use of FFR to guide stenting**

- The [FAME trial](https://www.nejm.org/doi/full/10.1056/NEJMoa0807611) took a bunch of asymptomatic people, did a FFR on them to measure fractional flow reserve, and gave the people a stent who had a pressure drop of 20-30% (0.7-0.8 P2 to P1)
- Using FFR to guide stenting became standard of care in the cath lab

***But now after many years of understanding the data, the consensus is that aggressive stenting is not necessary***

- Evidence comes from several trials that show that **optimal medical therapy** is effective, even in a mildly symptomatic patient
  - [COURAGE trial](https://www.nejm.org/doi/full/10.1056/NEJMoa070829)
  - [ISCHEMIA trial](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.120.049755)
  - [ORBITA trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(17)32714-9/fulltext)

**Questions about the benefits of a stent [46:30]**

*For the person who gets a CTA and a 50% stenosis is found, is that significant or not? How successful are the algorithms used to analyze the pressure drop?*

- The question in Ethan’s mind is‒ do the physics make sense?
  - And he doesn’t understand the physics
- Can you make a calculation in a meaningful and reproducible way?

***To Ethan, this is a distraction, he wants to identify asymptomatic people who are at higher risk***

- Is there a group of these people who are special and might show a benefit from stenting?
  - This is something that no other group of patients has ever shown in the history of interventional cardiology

***We’ve been doing this for a long time, looking for a group of people (outside of the acute MI setting) who would benefit from a stent being placed in their artery, and we’ve had a hard time trying to do that***

- In a sense, [COURAGE](https://www.nejm.org/doi/full/10.1056/NEJMoa070829) was the beginning of the end of this; that trial was conceived of and executed by a group of interventional cardiologists who wanted to demonstrate the superiority of stenting over medical therapy
  - It was designed that way and all the bias was weighted towards getting that outcome, but it did not get that outcome
- And there have been dozens of studies since then, and there’s nothing that screams, “*Hey, look, our job as preventative cardiologists or thoughtful internists should be to go looking for people who might benefit from a stent in the absence of symptoms.*”

***Ethan agrees with what Peter said earlier, if everybody got truly optimal medical therapy, if we didn’t have barriers to using all these tools in everybody, this disease would largely be controlled***

**Questioning the value of stenting**

- Ethan believes there is something else going on that’s residual (Peter may be an example)
- But the quality of medical therapy today is so good that it’s going to be hard to demonstrate the value of stenting people
- That assumes that stenting doesn’t do something *harmful* (which is an open question)
- Even before there were great PCSK9 Inhibitors, why wouldn’t opening an artery lead to improved outcomes outside of the acute MI setting?
  - This question has always plagued Ethan, even as a cardiology fellow
- You’re opening up a severely blocked artery and restoring blood flow back to the heart; it doesn’t make sense that there are not more improved outcomes
- There are lots of explanations for why that might be
  - Ethan speculates that the process of going into the clogged artery, blowing up a balloon inside it, and deploying a stent, might push the contents of that plaque downstream
    - Much like what happens when you break up a beaver dam in a stream; it goes downstream and causes its own set of problems

**Has a study been done on people who were asymptomatic at the time of being stented (they were not an acute STEMI), who then go on to have subsequent events, to determine the location of the plaque?**

- For example, if a person gets stented in the mid-LAD and goes on to have another event, can we identify a pattern?
  - Is it distal in the LAD?
  - Is it in a part of the heart where there has been some mechanical change that took place as a result of that stent?
- Peter speculates that maybe the reason why stenting doesn’t work is you’re playing whack-a-mole and the person has lots of disease, and you just happened to pick the one that had the most stenosis
  - Although stenosis by itself is a poor predictor of future events

**Does it come down to how lousy stenosis is as a predictor of events?**

- Ethan replies that stenosis is a good predictor
- But the plaques that end up leading to bad things are often not the plaques that would need to get stented anyway (discussed earlier)

**If you have a 90% stenosis, and you haven’t experienced any symptoms from it yet, is this telling you that if you throw a clot there, you’re going to survive?**

- That’s right because there’s [collateralization](https://en.wikipedia.org/wiki/Collateralization)
- And that’s probably the mechanism that ischemic reconditioning leads to this growth of collaterals
  - It’s like if there’s an accident on the freeway, you can get off on the side streets and wind your way through; it takes a lot longer and it’s not great when there’s a lot of traffic, but if there’s no traffic and it’s relatively light flow, you do fine

**Has a 30% stenosis been tested?**

- No; it can’t be tested because you would never stent a 30% lesion
- Now with the advent of [high-sensitivity troponins](https://www.acc.org/Latest-in-Cardiology/ten-points-to-remember/2022/07/14/18/12/High-Sensitivity-CTn-and-2021-Chest-Pain) and other more sensitive measures, if you look at [troponin](https://en.wikipedia.org/wiki/Myocardial_infarction#Cardiac_biomarkers) or [CK elevations](https://en.wikipedia.org/wiki/CPK-MB_test) after a long intervention, they most certainly go up
  - Not in all cases, but they do go up
- And so, the question is, are you basically creating a little MI in the process of putting the stent in?
- And does that then cause downstream risk in the form of arrhythmias or other issues later on in life?
- There is not great data on this, only some observational data looking at the area under the curve of the troponin elevations post-PCI as a predictor of outcomes
- Ethan thinks the more troponin you have, the worse you can expect to do

## The need for FFR CTA, and the potential for medical therapy to eliminate ASCVD [54:00]

- Peter recalls that the [PRECISE trial](https://www.sciencedirect.com/science/article/pii/S0002870321004774?via%3Dihub) used FFR CTA and found no difference in all-cause mortality, no difference in MACE (major adverse cardiovascular events), but a reduction in the need for catheterization
- Ethan explains this has become the value added from doing these non-invasive adjuncts to CT angiography
- This is the reason why at UCSF they do CT FFR on most of the CTAs (not all)
  - In theory you reduce the number of people who go to the lab

***For Ethan, this comes back to the primary issue‒ in the absence of symptoms, people with plaque should probably receive optimal medical treatment and be left alone; taking them to the cath lab has very little value***

- Once you get to the cath lab, the chance of them getting a stent goes up astronomically
- You can theoretically prevent unnecessary stents with CT FFR, but you can do that without the FFR

> “*You don’t need the FFR*”‒ Ethan Weiss

- Peter doesn’t get hung up when a study like that doesn’t find a difference in ACM (all-cause mortality) because he thinks that is a short time horizon (1 year)
- He does get a bit alarmed when there’s absolutely no difference in MACE (major adverse cardiac events), when you see no difference in anything related to cardiac pathology and the only difference is an algorithmic difference that you can make on your own
  - Maybe we should reserve judgment until the final study is published
  - But Peter found himself very underwhelmed by this
  - It didn’t change his thinking‒ he is struggling for the use case for FFR
  - He doesn’t really use FFR with his patients
- Ethan points out that you have all these levers you can pull, and do your job is to figure out which one to pull
  - People can over-complicate it
- In relatively low-risk people, maybe you could get away with a statin or a statin + low dose of [Zetia (Ezetimibe)](https://en.wikipedia.org/wiki/Ezetimibe)

***If you have 30% plaque or greater in an artery in your coronary vasculature, Ethan is pulling all the levers; he doesn’t need any other information; and pulling all those levers is a pretty good intervention***

**Use Peter as an example**

- Let’s assume there is something in Peter that is off, and after he had his first calcium scan 15 years ago, every lever got pulled; and maybe that is why his disease has not progressed
  - *Which means if we just pulled all the levers all the time, we could take this disease off the table for virtually the entire population*
- This is the mission statement of Ethan’s friend [Sek Kathiresan’s](https://www.vervetx.com/leadership-team/sekar-kathiresan-md/) company [Verve](https://www.vervetx.com/approach/); they want to CRISPR out PCSK9
  - Sek believes that if you did that, you’d eradicate this disease
  - Ethan doesn’t totally agree with him, but in general, he thinks he’s probably right
- The question is do you need to go to that extreme to solve for this problem, and could you apply that solution to everybody feasibly and worldwide?

## The fat attenuation index (FAI) and other ways to measure inflammation in a plaque [57:30]

**What exactly is the fat attenuation index (FAI)?**

- Ethan has no idea
- He graduated from medical school in 1996 and did his residency for two years and then started my cardiology fellowship at UCSF 25 years ago
- He has learned to tune out (put blinders on to) some of this stuff just because it’s something new every few weeks
- He’s not completely up to speed on this latest and greatest fat attenuation index
- He imagines it’s some CT-based way to look at the characteristics of the plaque and to see if it’s potentially vulnerable (Is that the idea?)
- From Peter’s understanding, the [FAI (fat attenuation index)](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(18)31114-0/fulltext#:~:text=A%20novel%20imaging%20biomarker%E2%80%94the,computed%20tomography%20angiography%20(CTA).) looks at the characteristics of the fat around the plaque
  - It’s not trying to predict vulnerability per se
  - It’s actually trying to predict how much inflammation there is
- Ethan is not familiar with FAI, but you can measure the amount of inflammation in a plaque using [FDG-PET and PET/CT](https://academic.oup.com/bmb/article/120/1/55/2527491)
  - He doesn’t think it’s being used clinically
- Looking at epicardial fat with the fat attenuation index is an interesting idea
  - Epicardial fat is visceral fat, and it probably does impact risk in some way
- But what are you going to do with that information? You’re already pulling all the levers
  - Maybe you’d focus a little bit more on metabolic stuff (we’ll come back to this)

## Statins and exercise may increase the risk of calcification, but what does this mean for risk? [59:45]

**There are subsets of people in whom an elevated CAC is not a predictor of risk**

- [James O’Keefe](https://www.cardiotabs.com/james-okeefe-md) has [commented](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6179786/) on the fact that certain athletes who exercise a lot, and have a very high degrees of cardiorespiratory fitness might have a higher frequency of coronary calcification

*How robust are those data? And more importantly, what does it mean?*

- Ethan thinks it’s plausible
- We know that increasing shear forces across the endothelial surface can certainly lead to damage and that would potentially increase calcification
- In patients with a bicuspid aortic valve, those who exercise at extreme levels do appear to have an increased rate of calcification of that valve
  - Ethan qualifies this‒ none of these studies are controlled
- He thinks the same *could* be true in a coronary artery vascular bed
  - The increasing shear, as you would expect to by increasing flow as you would during extreme exercise, *could* potentially lead to some damage and therefore calcification
  - He thinks it’s plausible
- There is the example of people taking statins where there is a disconnect between the amount of calcification in the artery and the amount of risk
  - That’s a difficult concept to understand and explain
  - Ethan can make up explanations like what you’re doing is healing the plaque and stabilizing the plaque (what statins are thought to be doing), and that that’s a good thing and not a bad thing
  - It’s incontrovertible that statins probably do increase the risk of calcification despite lowering the risk of events
- We don’t have the 40 years of really rigorous randomized trials showing that some exercising versus some version of placebo increases the risk of calcification
- Would Ethan say don’t exercise? Absolutely not
- Would Ethan tell some patients not to exercise to that extreme level? He’s on the fence

**If a person goes from 50 MET hours per week of exercise to 100, and that increases their calcification, does that increase their risk?**

- Let’s assume that high amounts of cardiorespiratory fitness come at the expense of some endothelial damage (we don’t know if this is true, but it is mechanistically plausible)
- Let’s assume that risk increased with this increase in exercise, but is that risk more or less than the benefit gained from the additional exercise?
- Other things that increase the burden of calcification are net negative (smoking more, having higher blood pressure, having worse lipids), and the correction of that works in the same direction as the improvement of the risk modifier
  - With exercise, it’s not the same

***It seems unambiguous that more exercise is better than less, and more calcium is worse than less***

***The only example of discordance is that more statins are better and also lead to more calcium***

- Ethan puts this in the context of a patient who has a calcium score of 800. Does this mean anything if the patient exercises a lot?
  - Ethan is not yet comfortable with saying “*Don’t worry about that*”
  - Whereas if they were on a statin, he would be comfortable with this statement

***Ethan tells patients that we have to assume that that calcium is representative of plaques in the arteries, and that having plaques in the arteries is a bad thing, and we should treat you accordingly even though you exercise a lot***

- Further, if you want to be sure, have a CT angiogram done to see how much plaque you actually have
- Ethan doesn’t know of any evidence that this calcification is not plaque related (extravascular, in the intima or media)

> “*I can’t give you a free pass on the calcium because you exercise a lot*”‒ Ethan Weiss

- Exercising is great; don’t stop exercising
- But the burden of proof is on us to show that that is not risky, and if we did a CT angiogram and it showed you didn’t have any plaque and all the calcium is extravascular somewhere else, then sure, Ethan would be okay with that
  - But that if we do it and we see plaque, he’s not aware of any data that would say, “*Let’s not treat you,*” which is the subtle but important difference between the statin story because the people on statins are already by definition on the risk-reducing therapy that’s been shown to save lives
- There is still that lever to pull in the exercise person who is statin-naive

## The root cause of statin hesitation despite evidence that statins are a profoundly important intervention [1:05:30]

**What percentage of your patients take statins?**

- This is a biased group of people because it’s all self-selected
- 90-95%

**Is the implication that the 5-10% who don’t take a statin have some side effect that they are not able to tolerate?**

- A small number of Ethan’s patients don’t take them because of true side effects
- An equal number of patients (maybe even slightly larger group)don’t take them because they’re afraid of them
  - Ethan doesn’t mean that to be pejorative
  - There’s been a tremendous propaganda campaign to demonize statins that’s been going on for a long time (25 or 30 years), and it’s been very successful
  - Some people who just flat out won’t take them or it takes him years of having the same conversation over and over to convince them to
  - But he never forces it

**What’s the core belief that’s at the root of that fear?**

- As Peter asks this, he acknowledges that probably 5% of patients are going to experience muscle side effects that will warrant not taking statins (because it impedes their quality of life)
  - Other [side effects](https://en.wikipedia.org/wiki/Statin#Adverse_effects) are [transaminase elevations](https://en.wikipedia.org/wiki/Elevated_transaminases) that are too much (especially if mixed with [Zetia](https://en.wikipedia.org/wiki/Ezetimibe#Adverse_effects))
- Peter asks, “*Where do you think that [fear] comes from and why don’t we see that with other classes of drugs to the same extent?*”
- Ethan thinks this happens to be one of the most prescribed classes of drugs in the history of humankind
  - And so it’s just the denominators bigger
- This is sort of the same thing that gets at a lot of the skepticism around science and big pharma
  - There’s a whole world of people out there with these vast conspiracy theories about the development of statins, and about how [Rory Collins](https://www.ndph.ox.ac.uk/team/rory-collins) is an evil person and he’s engineered this whole conspiracy to try to get the whole world on these poisons
  - And if you hear something enough, and you aren’t an expert and don’t have access to all the data that we have access to, it can be compelling
  - The documentaries are terrifying
    - As were the Wakefield documentaries in the late nineties were terrifying to young mothers who were worried about giving their kids MMR vaccines

> “*It’s very easy to convince people to be scared of something. It’s a lot harder to make people unscared of something.*”‒ Ethan Weiss

- There’s a group that is very skeptical of big science and big pharma
  - Obviously there are plenty of things that big pharma has done wrong and we can go through the examples of that, but this is not one of them

***Statins are one of the most profoundly important interventions that we have in modern medicine***

- It’s astonishing that this is being effectively compared to smoking (to cigarette companies)
- Peter adds that people will quickly point to [Purdue and the opioid crisis](https://peterattiamd.com/patrickraddenkeefe/) as proof positive that pharma entities are evil
- Peter has pointed out before, “*It’s really difficult for us as a species to think dialectically and to hold seemingly contradictory truth simultaneously that pharma companies can do good things and bad things. And that seems to be true across the board. That seems to be true of every person as well. Any given individual can do something good and something bad*.”
  - The exceptions would be those that are universally good or universally bad as people

## Importance of keeping blood pressure in check, defining what’s normal, and whether we should just accept higher blood pressure with age [1:10:45]

**Blood pressure**

- This has become more of a concern to Peter over the past two years through the lens of the kidney, a special organ that does not get much attention
- Peter explains to his patients that their bootstrapping approach to living a few extra years requires a phase shift in time
  - So if you’re 50 years old, you really need to be held to the standard of a healthy 40-year-old
  - This is how you need to think about it, if you want to live an extra 10 years
- You want to think in terms of your coronary arteries, your bone density, your kidneys
- Peter uses [cystatin C](https://en.wikipedia.org/wiki/Cystatin_C) to estimate [glomerular filtration rate](https://en.wikipedia.org/wiki/Glomerular_filtration_rate#Cystatin_C) (they’ve largely abandoned creatinine)
- The kidney is not uniquely but exquisitely sensitive to high blood pressure
- The vasculature is also incredibly sensitive to blood pressure
- It probably has to do with the fact that the kidney is such a tiny organ that takes such a high amount of our cardiac output, and Peter suspects just like the heart and the brain, it’s very sensitive to pressure
  - It’s through this lens that he thinks even the slightest elevation in blood pressure is going to interfere with long-term kidney health and also heart and brain health

**Explain from the ASCVD perspective the importance of blood pressure and how it stacks up with smoking, apoB, and some of the other heavy hitting risk factors**

- Ethan agrees that we neglect the kidney as an organ and nephrology as a subspecialty of medicine
- He used to give a lecture on hypertension to the first year of medical students at UCSF, and he did that in conjunction with a kidney pathologist ([Jean Olsen](https://www.asn-online.org/about/bio.aspx?ID=47720&title=BRCU+Faculty), now retired)
  - Who interestingly had been at Hopkins when Ethan was a medical student and was his advisor
  - She gave the pathology part of the lecture and Ethan gave the clinical part
  - From giving that lecture 10 years ago he learned so much about the importance of the kidney and regulating blood pressure

**The kidney is an important cause of blood pressure**

- If you go back and look at [Rick Lifton](https://www.rockefeller.edu/our-scientists/heads-of-laboratories/1139-richard-p-lifton/) who was one of the premier human geneticists in history, member of the national academy, and probably should win a Nobel Prize
  - He characterized all of the single gene mutations that lead to extreme increases or decreases in blood pressure
- 20 years ago, there were 10 single gene mutations that caused people to have really, really low blood pressure, where they had to constantly supplement salt etc
- And there were 10 single gene mutations that led to extremely high blood pressure
- Somewhere around 19/20 of these things were located in the same location, in the proximal collecting duct of the kidney
  - It was like you couldn’t have picked a place that was more important evolutionarily for how we handle volume and salt and salute

***The kidney an incredibly important organ both as a cause of high blood pressure and also as a consequence***

- Most people know that when they go to their doctor and they get their [blood pressure](https://en.wikipedia.org/wiki/Blood_pressure) checked, normal is about 120 over 80 millimeters of mercury (120/80 mmHg)

**What do we know about how much that changes in a healthy person across the course of the day?**

- When they’re sleeping, when they’re ambulatory and walking around but not under stress (i.e. not exercising), when they are exercising vigorously, when they’re under stress, physiologic stress, psychological stress
  - All of these different things that we do every single day
- Surely our blood pressure must change and yet most of us (Ethan included) have virtually no idea of how our blood pressure is changing under those situations
- This is fascinating and Ethan has thought a lot about what we assume is normal (120/80 mmHg)
- Blood pressure across different animal species is mostly in that range; there are some outliers
  - A giraffe is the best example of an outlier species with much higher blood pressure; it needs to be able to pump blood up that long neck to its head
- It’s strange from an evolutionary perspective that we would have the same blood pressure as a mouse
- Ethan thinks this speaks to conservation around the vascular system that we have
- 120/80 mmHg is normal whether your 7, 17, or 75

***We don’t have a good understanding of what is epidemiologically normal (for blood pressure) as we age***

- On average, with each decade of life, your blood pressure goes up
  - So if you look at a population of people, is that part of normal healthy aging or is that a function of pathology?
  - Maybe there is decreased kidney function or increased vascular stiffness over time
- For a long time we assumed that a blood pressure that was normal for somebody in their 20s-30s was probably too low and not normal for somebody who was in their 60s-80s
  - We had a sort of permissive hypertension in elderly people because we thought they required it; it was just part of the aging process
- Only in the past 10+ years have we begun to ask specifically, in well-designed clinical trials, is this the case when it comes to looking at important clinical outcomes
- Ethan’s take on this is different than it was 15 years ago; he now thinks that 120/80 mmHg is normal no matter where you are in life and anything above that is abnormal

***Ethan tells his patients he wants to get them as close to 120/80 mmHg without harming them***

- Harms can be in the form of side effects or impact on lifestyle
  - Toxicity, [hyperkalemia](https://en.wikipedia.org/wiki/Hyperkalemia), risk of death
  - It’s not a simple intervention like treating LDL or apoB lower and lower; where there’s really no danger at all of lowering these
  - There is a consequence of lowering blood pressure too low

***Should we just accept that blood pressure goes up with age?***

- Peter asks for clarification, “*When blood pressure drifts up to 125, 130, 135, 140 in an aging population, we’re actually calling that pathologic in the same way that I think we would all agree that the reduction in glomerular filtration rate. The reduction in ejection fraction, the reduction in pulmonary function, okay, yes that occurs with aging, but that doesn’t mean that it’s not part of an aging process and therefore part of something we want to minimize. Correct?*”
- Ethan agrees and adds that we lose muscle mass as we age
  - Is that something we want to accept as normal or do we want to do what we can to preserve the muscle mass we had when we were younger?
- We need to fall back on what good, high quality clinical trials have shown; it’s not an opinion-based thing
  - We have [evidence](https://www.nejm.org/doi/10.1056/NEJMoa1511939) that being closer to 120/80 impacts [improves] mortality and that permitting 140/90 (even in an older person), leads to a significant increase in risk of dying
- There is a decrease in function of a lot of things that goes along with aging that combines to lead to this increase in blood pressure, but that’s not a reason to leave it alone

## Blood pressure variability, how to best measure it, and data suggesting the enormous impact of keeping blood pressure down [1:21:00]

**How reflective is taking blood pressure when you are sitting, totally relaxed of the blood pressure when you’re sleeping for eight hours or exercising for 90 minutes a day or sitting at your desk stressing over an email? How much variation is there?**

- Tons
- The first time Ethan was in the cath lab, it was amazing to see the variation in blood pressure of patients just lying on a table before and after they were sedated

***There is no doubt that there is a huge amount of variation from second to second, minute to minute, hour to hour, day to day and beyond in blood pressure, and Ethan thinks it’s very easy to get distracted by that***

- Ethan remarks, “*When I’m sitting in traffic, my blood pressure is not 120 over 80. When my kid spills coffee all over the computer, it’s not 120 over 80. When I’m exercising it’s not 120 over…*”

**There is physiology and there is pathophysiology**

- Physiologically our blood pressure does go up, and it’s meant to go up during some of these cases
  - It’s a function of increased cardiac output, which is one of the components of blood pressure

**The best way to measure blood pressure and Peter’s experience [1:22:45]**

- Ethan falls back to what clinical trials have shown and how they are measuring blood pressure in these trials (as this affects decisions made to adjust medicines)
- This got a lot of attention when [SPRINT](https://www.nejm.org/doi/10.1056/NEJMoa1511939) was first published in 2015
  - There was all kinds of pushback from almost every angle you could think of
  - Because the way they measured blood pressure wasn’t the way we typically measure it
- 1 – They had people in a quiet room
- 2 – They used an automated cuff, one that was best in class at the time
- 3 – They measured blood pressure three times with five minutes in between each measurement, and then they took the average of those measurements
- This is the optimal way of measuring blood pressure, even if it ends up yielding numbers that are lower than typical
- It’s obviously much different than having somebody rush in after parking their car and run into the office in a sweat and show up and somebody slaps a cuff on them and measures the blood pressure
- The [SPRINT trial](https://www.nejm.org/doi/10.1056/NEJMoa1511939) was so spectacular that it was stopped early
  - This was not a pharma sponsored trial
  - The NIH/government sponsored trial and was agnostic to different agents
  - It was not about the physicians who enrolled patients in the trial had access to almost any therapy during that trial
  - This was not about sort of proving the benefit of one drug over another

 ***The SPRINT trial was purely about testing the hypothesis that getting as close to 120/80 rather than letting people float up to 140/90 was better (or not), and it turned out that it was better (with caveats)***

**Peter’s antidote with his blood pressure**

- Peter started testing his blood pressure in the past couple years 3-4x a week when he is sitting at the desk working
  - Because both his parents have hypertension
- He had always attributed his low blood pressure to the fact that he was super healthy and did all these other things
- But he realizes there is a lot of genetics to this, so he started checking his blood pressure every couple days
- His typical reading averages 110/70 mmHg while he was sitting at his desk working
- But then something happened in August, it was consistently a little bit higher (125-130/80 mmHg)
- So Peter got another cuff and started doing the full protocol (outlined earlier) three times a day with both the OMRON cuff and the Withings cuff
- He realized he can always breathe his blood pressure down to normal
  - Breathing often didn’t lower the blood pressure for that first reading, the second he sits down
  - It was not uncommon for the first reading to be as high as 140/90 if he was doing something active (not exercising); so this was equivalent to the guy who shows up from the parking garage, had to walk up one flight of stairs, sits down for a reading of 140/90 but five minutes later its 117/74
- Peter has been in a back and forth discussion with his doctor and colleagues about this
  - Is this something he needs to care about?
- His data for the past six months shows an average below 120/80, but he feels like he’s cheating because to get those readings he has to take five minutes of being calm and still
  - He knows this in in line with how the SPRINT study was done, but deep down, he knows his blood pressure is *not* 120/80 when he’s sitting at the computer writing (because he’s checked)

**So the way the SPRINT trial was done, we have to assume that people’s blood pressure when they first sat down might have been higher**

- Ethan thinks it sounds like something has changed in Peter
  - It was a book deadline in August, no question about it
  - If that’s the case then it’s understandable and okay
  - If it was truly a change and there was no explanation for it (like a lot of things in medicine), then he would pay more attention to it
  - It sounds like the explanation was the added stress from the book
- This story reminds Ethan of his daughter
  - She is legally blind and plays basketball
  - They were discussing a potential procedure she could have to improve her vision because part of her decrement of visual acuity (20/200) is that she has pretty bad lateral [nystagmus](https://en.wikipedia.org/wiki/Nystagmus)
  - The ophthalmologist said if you could make that better, you could improve her visual acuity, and he explained that somebody stumbled onto the idea if you simply cut the extraocular muscles and just reattach them, that nystagmus can go away
  - But his daughter didn’t want to do this because she thought this was *cheating*, and they haven’t been able to convince her to do it yet
- All this is to say that Ethan doesn’t think Peter is *cheating*; he’s optimizing the measurement
- It would be great to do a 24-hour ambulatory blood pressure monitor (and have this over time serially)
  - This would provide a sense of what the average blood pressure is over a 24-hour period

**Blood pressure when sleeping, and other ways to measure blood pressure [1:30:15]**

*Normal changes in blood pressure*

- When you’re sleeping, your blood pressure should be low (that’s physiology)
- When you’re out and about doing things, it’s going to be higher
- A 24-hour ambulatory blood pressure monitor can quantify all the spikes

*How does an ambulatory BP cuff work?*

- It’s an old-school cuff
  - Not like the new technology where they can measure blood pressure without doing the finger thermometer
- Ethan has never seen the device but he imagines that it has some hardware attached to to that tells it to inflate and measure blood pressure just as you would with one that you have in your office
- It measures once a minute (or whatever it is) over the course of 24 hours
  - So it’s constantly inflating, deflating, over the course of the day
  - Patients of Ethan who’ve worn them say that after a while you get used to it and just can ignore it

*Blood pressure during sleep*

- We know that hypertension during sleep is abnormal
- Sleep should be a time when your blood pressure is the lowest
- A 24-hour ambulatory blood pressure monitor is another tool we have to get at this question
- It’s interesting that we measure blood pressure just once or twice a year and we assume this very variable number is actually meaningful
  - It’s remarkable that it has been meaningful at all considering the poor sample we are taking
- Peter asks his patients to measure their blood pressure twice a day at home, using the method described for at least two weeks once a year
  - They will measure more if they have reason to do so
- Peter has tried a bunch of devices that supposedly measure blood pressure (little risk-based devices), but he’s never found them to work

**Is there anything on the horizon to make measuring blood pressure easier?**

- You would think so, but Ethan is not seeing any other devices people can wear that accurately measure blood pressure
- You’d think that at some point, even if it’s an intravascular device, that you could use a miniature device, an implantable event monitor
  - Like a loop recorder we use them to detect arrhythmias
  - It sounds bad when you think about it, but it’s really not that big of a deal
  - There has to be a way to get a pressure transducer into an artery safely that you could leave there for some period of time
  - It feels like that’s going to come, but Ethan hasn’t seen it
- To have something non-invasive would be amazing, but again he just hasn’t seen it
- [Peter finds](https://en.wikipedia.org/wiki/Continuous_glucose_monitor) CGM (continuous glucose monitors) to be a remarkable tool, and he would think measuring blood pressure is even more important because glucose glucose in many ways is less variable than blood pressure
  - At least glucose variability is more predictable
  - Peter thinks you can get by with spot checks of glucose more than you can with spot checks of blood pressure

> “*To have a true continuous ambulatory BP monitor would really be a game changer in medicine*”‒ Peter Attia

**Awareness and treatment of high blood pressure**

- When the NIH first did a survey (1975/76)to see how many people have hypertension, how many know about it, how many people are controlled, only 50% of people who had hypertension were even aware of it
  - Only 30% were actually ever treated
  - And only 10% were controlled
- Ethan doesn’t know what the most current numbers are, but awareness has gone up, it must be north of 80% now
  - Treatment of 75 or 80% has probably achieved control in around 50%
  - So we’re still missing the opportunity to treat 50% of people with this disease

## Drugs for treating high blood pressure recommended by the ALLHAT trial [1:35:15]

- Back to the [SPRINT trial](https://www.nejm.org/doi/10.1056/NEJMoa1511939); it was drug agnostic
- Did it recommend to start with a thiazide move to a calcium channel blocker and then an ACE or vice versa?
- Ethan doesn’t remember
- [ALLHAT](https://jamanetwork.com/journals/jama/fullarticle/195626) was the first NIH sponsored blood pressure trial, in 2002
  - They tested a [calcium channel blocker](https://en.wikipedia.org/wiki/Calcium_channel_blocker) ([amlodipine](https://en.wikipedia.org/wiki/Amlodipine)), an [ACE inhibitors](https://en.wikipedia.org/wiki/ACE_inhibitor) ([lisinopril](https://en.wikipedia.org/wiki/Lisinopril)), a [thiazide-like diuretic](https://en.wikipedia.org/wiki/Thiazide-like_diuretic) ([chlorthalidone](https://en.wikipedia.org/wiki/Chlortalidone)), [beta blockers](https://en.wikipedia.org/wiki/Beta_blocker), and alpha agonists
  - Beta blockers and alpha agonists were stopped early because they were harmful
  - The target was 120/80
  - Normal was actually 120-130/80-85
  - Borderline was 130-140/85-90
  - Stage I hypertension was >140/90 (there were also stages II and III)

***The ALLHAT trial established using three classes of drugs for first line treatment of primary hypertension‒ calcium channel blocker, ACE inhibitors, or thiazide-like diuretics***

- When they redid this for [JNC 7](https://www.nhlbi.nih.gov/files/docs/guidelines/express.pdf) (versus JNC VI), normal was <120/80
  - Pre-hypertension was 120-140
  - Hypertension was >140/90
  - Ethan can’t remember what changed in JNC 8, but there was some controversy and [NHLBI](https://www.nhlbi.nih.gov/) stopped after that

## What the SPRINT trial says about the aggressive treatment of hypertension, and the risks of such treatment [1:38:15]

**Was the impetus for SPRINT to test a new hypothesis, that we should be more aggressive in the management of hypertension?**

- There were epidemiological [observational studies](https://pubmed.ncbi.nlm.nih.gov/16443415/) that showed that the risk of bad outcomes (mostly cardiovascular disease) was a step function lower in patients whose blood pressure was ≦120/80
  - Then a small step increase in people who had was was then classified as normal
  - Then a large step increase in people who were considered high normal or even early stage hypertension
- But this was a prospective observational study, so the NIH designed a study to prospectively evaluate whether treating people to these two different goals resulted in a change in outcomes
- To Ethan’s recollection, there was nothing about the different agents used [in the [SPRINT trial](https://www.nejm.org/doi/10.1056/NEJMoa1511939)] that was meaningful
- People got to the two goals they were randomly assigned to, but it wasn’t blinded because you couldn’t be blind to your blood pressure (summarized in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/03/f2-ethanweiss2-1024x701.png)

**Figure 2. Systolic Blood pressure in the two treatment groups over the course of the SPRINT trial**. Image credit: [*NEJM* 2015](https://www.nejm.org/doi/10.1056/NEJMoa1511939)

- You can ask the question, was it a benefit of the medicines or was it a benefit of the blood pressure
- But the reality is this was a really striking difference such that the NIH stopped the trial early because of benefit in that group with lower blood pressure

> “*I think it [the SPRINT trial] was one of the most important and practice changing trials that we’ve had. I don’t think that it came without some cost/ risk.*”‒ Ethan Weiss

**Risks with targeting a blood pressure of 120/80**

- There were real issues
- There was a greater increase in the risk of falls, [syncope](https://en.wikipedia.org/wiki/Syncope_(medicine)), and even a risk of significant kidney dysfunction
  - It was all reversible, but it was all there
- What Ethan took away from that trial was that it looks like you get a mortality benefit for getting closer to 120/80; so let’s get there if we can, without creating one of these problems
  - Obviously if you’re falling all over the place because you’re dizzy or if your kidney function deteriorates because your kidneys aren’t getting enough blood flow or something else bad happens, then we’re not going to do that
- Peter thinks this is why his doctor has been relatively unexcited about doing anything for his blood pressure (120/78); he still remember when Peter stood up in the morning too quickly, fell, face planted, and split his head on the table
  - Under his normal set of relatively low blood pressure
  - Just over a year and a half ago
  - He would have an occurrence where he would get up and need to sit back down again in the mornings once or twice a week
  - Peter is also not keen to take any medication for his blood pressure
- Ethan points out that blood pressure is not like cholesterol; there is a U-shaped curve where too low of a blood pressure is bad
- Peter’s blood pressure was probably right where it ought to be or a tad low
  - Maybe he was a little dehydrated in the morning
- Ethan doesn’t know of any evidence that treating below 120/80 is advantageous
- Peter’s question was, “*Should we treat such that I never have a reading above 120/80 again?*”
  - He thinks that’s probably too aggressive based on these side effects
  - Ethan doesn’t think that is even feasible, especially considering the way Peter exercises
- Ethan imagines if Peter wore a 24-hour ambulatory blood pressure when exercising (especially isometric resistance training), his blood pressure would register way up
  - Peter thinks this is a great idea
  - He has looked for the last two years for new technology to measure blood pressure continuously, and every device he tried has failed
  - He needs to do it the old-school, low-tech way
- Ethan adds, “I*f some smart engineer out there wants to figure out a great important thing to work on, this is definitely at or near the top of my list in terms of things that haven’t been solved.*”

## Confirmatory results in the STEP trial for blood pressure, and how Ethan uses the various pharmacological agents to lower blood pressure in patients [1:43:15]

**Did the STEP trial last year sharpen our thinking at all?**

- The [STEP trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2111437) simply assuaged any fears that people had that there was something unusual about the SPRINT trial

***The STEP trial was a nice confirmation that SPRINT was probably not spurious, but it was real and robust and repeatable***

- The other thing STEP had going for it over SPRINT is it included patients with type 2 diabetes (excluded from the SPRINT trial)
  - STEP was a longer trial with a more representative population

**What are your thoughts on the specifics of various agents? Do we have one reason to prefer one over the other when it comes to renal protection?**

- Peter hears a little bit of discussion of [ARB](https://en.wikipedia.org/wiki/Angiotensin_II_receptor_blocker) versus [ACE](https://en.wikipedia.org/wiki/ACE_inhibitor) versus [calcium channel blocker](https://en.wikipedia.org/wiki/Calcium_channel_blocker)
- The question is (independent of the effect on blood pressure) about different agents (an ACE inhibitor, an angiotensin receptor blocker, or a calcium channel blocker) that can equally lower blood pressure and can get everybody down to 120 over 80, and the symptoms and side effects become non-issue
  - Each of those will have a slightly different set of symptoms
- Earlier in the conversation Ethan pointed out the lack of awareness and lack of treatment to control blood pressure

***Ethan’s first advice is get the blood pressure controlled, and then we can try to optimize and find the right combinations of things for you, given your other circumstances***

- The NIH used to use this term extenuating or special circumstances
  - For example, if somebody had angina, even though beta blockers were no longer first line for treatment of primary hypertension, if you had angina, you’d include the use of a beta blocker in that hypertensive regimen
  - It was really an antianginal but it lowers blood pressure
- The first step is just ***get to the goal***, but he does tend to do things differently in some **contexts**
- **Age** is a big deal in both directions
  - Young people don’t like taking diuretics
  - In old people, diuretics can be a little bit more challenging; there are more electrolyte abnormalities, a greater incidence of hyponatremia, and kidneys issues
- If Ethan had to pick his favorite agent among the three classes that are best at managing high blood pressure, it would be [chlorthalidone](https://en.wikipedia.org/wiki/Chlortalidone) or a thiazide diuretic
  - He doesn’t use it as much because it’s harder to use
- [Amlodipine](https://en.wikipedia.org/wiki/Amlodipine) is a great drug because it’s easiest to use
  - It doesn’t require any monitoring, you don’t have to monitor electrolytes, you don’t have to monitor kidney function
  - It’s a benign drug with very few side effects other than a not super infrequent amount of swelling in the ankles
    - It’s not really edema, but it’s the sort of non-edema ankle swelling the people (especially women) don’t like having

**There are data to suggest that** [**ACE inhibitors**](https://en.wikipedia.org/wiki/ACE_inhibitor) **or** [**ARBs**](https://en.wikipedia.org/wiki/Angiotensin_II_receptor_blocker) **may be more indicated in certain subpopulations**

- The [HOPE trial](https://www.nejm.org/doi/full/10.1056/NEJM200001203420301) suggested there may be a benefit of using ACE inhibitors in people that have [atherosclerotic coronary disease (CAD)](https://en.wikipedia.org/wiki/Coronary_artery_disease)
- With ARB there is an aortic diameter thing, there may be a little increase in aortic size and that may be a benefit to ARBs

***Ethan likes ACE inhibitors and ARBs the best, but they do require monitoring***

- You need to get electrolytes because in some patients there can be issues, especially with potassium
- They can impact kidney function
  - It’s a weird thing where the benefit to people with kidney disease is high, but kidney doctors are also very nervous about the potential toxicity to the kidney
  - Yet in people with existing kidney disease, that is probably the drug
- Diabetics are other place that he uses ACE inhibitors and ARB first line
  - Because that’s been shown to reduce the progression to **diabetic nephropathy**
- He thinks they are renal protective beyond just getting the blood pressure lower
- You also have to pay attention to **tolerability**; this is probably the biggest reason for non-compliance (a term Ethan hates)
- For older people who tend to get more [orthostatic](https://www.mayoclinic.org/diseases-conditions/orthostatic-hypotension/symptoms-causes/syc-20352548#:~:text=Orthostatic%20hypotension%20%E2%80%94%20also%20called%20postural,Orthostatic%20hypotension%20can%20be%20mild.), Ethan would stay away from diuretics
  - To reduce the risks of falls; it’s a huge source of injury in older people
- Peter thinks falling is an enormous risk for an elderly population; between the head bleed and the femur fracture,these are devastating consequences for someone in their eighth decade and beyond (often life ending)

## The role metabolic health in ASCVD: what we do and don’t know [1:51:00]

- Peter tells patients there are **four big pillars of risk for ASCVD**‒ smoking, hypertension, apoB, and metabolic health
- That last one is kind of squirrely because you can’t point to one number that tells your risk (like the others, or smoking or not smoking)
- Instead he talks about the sources of fat that exist outside of your subcutaneous deposits of fat
- The generally accepted principle of this is that one of our remarkable advantages of evolution as a species, is our ability to store energy
- We have this vast network of **subcutaneous adipose tissue (white adipose tissue)** that is incredibly adept at storing triglycerides
- People have very different genetic capacities for how much fat/energy they can store
  - Peter likens this to a **bathtub**
  - Everybody has a different size bathtub, and the water coming in the bathtub is how much you’re eating, and the water leaving through the drain is how much energy you’re expending
  - If you’re accumulating fat, you are obviously consuming more than you’re expending
  - But at some point you could fill that bathtub up, and water can escape the bathtub, and that’s when really bad stuff happens
  - You don’t need to get a lot of water out of the tub for really bad things to happen (ask anybody who’s had a leak in their house)
- You can talk about the places where this energy escapes (when the bathtub is full)
  - Around the viscera, within the muscle itself, in the pancreas, the heart

**Why is it so bad if you overwhelm the “bathtub”?**

- Ethan is so incredibly impressed at how Peter tells this story because it’s exactly how he tells it
  - Ethan learned it from [Steve O’Rahilly](https://www.mrl.ims.cam.ac.uk/research/principal-investigators/professor-sir-stephen-orahilly/), who is the godfather of this concept
- There is a relationship in terms of risk and weight that is imperfect
  - BMI is not a great measure of risk for the individual
  - BMI is good for epidemiology, for large populations
- How much fat you carry (overall adiposity) is important
- But in the last 20 years, it’s not so much *how much fat* you have as it is *where you carry it*
- We are evolutionarily programmed to store energy in these places around our hips and our butt and our legs but not so much in our bellies, definitely not in our organs (very bad)
- There are a number of genetic alleles that predispose to both these differences in body composition but also to differences in risk of developing diseases like coronary disease and diabetes
- This is so fascinating that Ethan is going to devote the rest of his life to understanding and trying to fix this

**Start by examining the extremes of biology**

- [Lipodystrophies](https://en.wikipedia.org/wiki/Lipodystrophy) are rare genetic diseases where people are born with the inability to store fat ([generalized lipodystrophy](https://en.wikipedia.org/wiki/Congenital_generalized_lipodystrophy)), or with an isolated inability to store fat in the gluteal femoral and subcutaneous regions of the legs
  - They have a selective loss of adipose tissue in their butt and their legs and therefore a huge overabundance of fat in the abdomen, in the viscera, in the liver and the pancreas and the heart
  - *These people have tremendous metabolic disease and extraordinary levels of risk for Coronary Artery Disease*
  - There are small numbers of these people, and the studies are all observational
- A [paper](https://www.ahajournals.org/doi/10.1161/01.CIR.103.18.2225) from Canada 20 years ago showed that people born with these sort of congenital forms of severe insulin resistance (either lipodystrophy or type A insulin resistance) have astronomical coronary artery disease risk
  - There are women who are having bypass operations in their 30s and 40s, which is basically unheard of in women

***The question of why this is remains unanswered; there are lots of different potential hypotheses***

- We do know there is a very strong association between different body shapes and the risk of developing type 2 diabetes and coronary artery disease

## The impact of fat storage capacity and the location of fat storage on metabolic health and coronary artery disease [1:56:15]

- If you look at the epidemiology curves of coronary disease over the past 30 years, we’ve we’ve done an amazing job of reducing the risk of coronary artery disease events using all the tools we have at our disposal
  - Controlling blood pressure, smoking cessation, lipid management, etc.
- Yet coronary artery disease (CAD) is still the #1 cause of death in the world, even in the COVID era
  - Are we not adequately using the tools we already have?
  - Are we missing something else? Is it a combination?
- Ethan would guess it’s a combination of the two, and this is what he wants to focus the rest of his career thinking about
- Peter agrees, it’s a combination
  - We start too late and don’t go low enough on lipids
  - We fail to recognize and don’t get enough traction on blood pressure
  - Nearly 20% of people still smoke
  - The pillar of poor metabolic health is so improperly understood; we’re not identifying people at risk
  - He thinks about how little he knows about his own metabolic health, even though he has a good sense from any blood test you can do
    - A [DEXA scan](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) will tell how much [VAT (visceral adipose tissue)](https://en.wikipedia.org/wiki/Abdominal_obesity) he has
    - His [transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases) are adequate, so he assumes he has no liver fat
    - Otherwise, it’s a real blind spot
- Ethan points out that we start with the most blunt tool of all ([BMI](https://en.wikipedia.org/wiki/Body_mass_index)) then move on to other things, but our resolution into metabolic health is still very low

**Ethan’s thought experiment on metabolic health and coronary artery disease**

- Is the problem with [VAT](https://en.wikipedia.org/wiki/Abdominal_obesity)?
  - Is that a defect and the ability to store fat where it should be stored (in the gluteal femoral depot)?
  - Is there something different about VAT?
- Is there truly a benefit to having more fat in the gluteal femoral?
  - To your bathtub analogy, if you could make a bigger bathtub, would you be more metabolically healthy?
- [Gerald Schulman](https://medicine.yale.edu/profile/gerald-shulman/) did an experiment where he looked at a mouse model where the mice had profound insulin resistance and he would just put more and more subcutaneous fat into those mice
  - And they got fatter and they got less insulin resistance
  - Paradoxically as they got fatter, they got healthier
  - That intervention, allowing them to get fatter (making them have a bigger bathtub), improved them.
- But that doesn’t answer the question, is VAT bad simply because it’s not in the subcutaneous space or is it doing something fundamentally different?
- We want to understand if there are cytokines coming out of those cells in the VAT that are different from the cytokines coming out of the other cells?
  - And how does that factor into it?
- We are learning all kinds of things about the difference in basal [lipolytic](https://en.wikipedia.org/wiki/Lipolysis) rate between the two depots
  - We’re just describing these depots based on what we can see and how we can describe them based on a DEXA scan
  - This is very low resolution compared to what we care about

**The importance of fat storage capacity**

- What we can say is that in a patient with lipodystrophy (as an extreme) who has normal lipids, but not normal triglycerides, those people have extreme increases in risk independent of their traditional risk factors
- We think that there’s a group of people who represent some polygenic version of this [lipodystrophy] where there’s a **relative decrease in fat in the legs**
  - And once you see them, you can’t not see them.
  - People who may have a tiny little pot belly, but their lipids were sort of not that bad, their legs are super skinny, and they had a bypass at 38 or 40 or 41
- Ethan thinks what we’re going to learn is that gluteal femoral storage capacity is going to be an important driver of risk in this context
  - And finding ways to change that (if it’s possible) would be of great benefit
- If you talk to the plastic surgeons, they’ve begun to understand that there are metabolic consequences to taking fat out of places like the legs and the hips that are very different from taking fat out of the belly
  - This is poor evidence, but it’s helping to guide us towards this idea that there’s something there
  - It’s like like Jerry’s experiment of putting in more subcutaneous fat
- Peter thinks this is also playing a very big role in people who aren’t showing up for bypass at 38-years-old, who don’t have complete lipodystrophy (where they have no ability to store fat on their legs and hips)

**The question is, are there targeted and directed therapies that can be aimed at the metabolic tip of that spear?**

- This is what Ethan is doing, and he thinks so
- They need to do the experiment to demonstrate that
- But using human genetics as a guide, there are a large number of alleles that seem to confer this concordance of change in both directions
- For example, people who have alleles that confer more glute femoral
- What’s important is the ratio of visceral fat to gluteal femoral fat (DEXA report fat mass ratio)
  - There are different levels that are normal or abnormal for women and men
  - Having a **high fat mass ratio** (more visceral fat than gluteal fat) is bad
- There are alleles that confer a high fat mass ratio and they also confer a bunch of changes into other things that we know are bad (including lipid-based biomarkers and coronary disease)

**Genetics underlying lipodystrophy, and high fat mass ratio as a risk factor for coronary artery disease [2:02:45]**

*How concordant are these alleles? So do you have enough data to look at identical twins and say that the genes are completely concordant between them and the phenotype of high fat mass ratio?*

- Ethan doesn’t know of any twin data
- They are common enough that you can find heterozygotes and homozygotes, and it looks like there’s a dose response
- Therapies will be tested first in patients with lipodystrophy
- Ethan hopes and expects we will move beyond that and try to target other metabolic associated diseases, and ultimately the most metabolic associated disease, which is ASCVD

*What percentage of the patients with a phenotypically appreciated lipodystrophy have an identified set of genes or gene that results in that?*

- On the order of 50%
- It’s a great question because we don’t really look
- Recognition and diagnosis of lipodystrophy is abysmal
- [Steve O’Rahilly](https://www.mrl.ims.cam.ac.uk/research/principal-investigators/professor-sir-stephen-orahilly/) will say the problem is that we don’t take our patient’s clothes off, and so you never see if a patient has lipodystrophy
  - Check out Steve’s 2019 Banting Memorial Lecture:
    - [The lecture](https://professional.diabetes.org/webcast/banting-medal-scientific-achievement%E2%80%94%E2%80%9Ctreasure-your-exceptions%E2%80%9D%E2%80%94studying-human-extreme)
    - [The associated paper](https://us-west-2.protection.sophos.com/?d=diabetesjournals.org&u=aHR0cHM6Ly9kaWFiZXRlc2pvdXJuYWxzLm9yZy9kaWFiZXRlcy9hcnRpY2xlLzcwLzEvMjkvMTc3OTkvVHJlYXN1cmUtWW91ci1FeGNlcHRpb25zLVN0dWR5aW5nLUh1bWFuLUV4dHJlbWU=&p=m&i=NjM5MjEzOGNjNDEyOGMxMjM1MGU4MzY2&t=VTJPNDd2NmNRWkhqYWJQcmJJUmllOTZoRUhiM1lZZXFuWnEzTGkxNjJ3UT0=&h=40eee14d8cb640b2911bfc3a102b305f&s=AVNPUEhUT0NFTkNSWVBUSVbBx_ZrjZBUdNKO75nnkymNwKXP8smZZcjVHKJ9S92mFA)
- Some patients of lipodystrophy who are big in the advocacy groups and they’ve been incredibly helpful to us
  - They often tell the story that their own personal diagnosis of lipodystrophy happened by accident because it happened to be a warm day and they were wearing a skirt and the doctor was able to see that their legs were super skinny and muscular

***Ethan can’t answer this question because we don’t know what the denominator is***

- Partial lipodystrophy is classified by how it has been historically defined
- There is [familial partial lipodystrophy (FPLD)](https://en.wikipedia.org/wiki/Familial_partial_lipodystrophy) 1 , 2, 3, 4, and beyond
- FPLD1 doesn’t have a monogenic cause
  - It’s by far and away going to be the most common
  - But there’s not an agreed upon way to make that diagnosis, which is a major problem that needs to be addressed,
  - Your average doctor has never heard of lipodystrophy, and clearly would never even be thinking about it (Ethan had this experience himself)
  - If you see leanness and muscularity you would never think it is a problem

**Peter’s takeaway**‒

- This is interesting in that it becomes the index upon which you can build a far greater set of insights
- While this population experiences such an extreme consequence of this, even absent a lipodystrophy, this is still a problem
- The lipodystrophy patient has a broken bathtub; it’s not like a normally shaped bathtub
  - It’s a bathtub that is more quick to overflow because it’s simply smaller and therefore they show up much sooner with this problem
  - And if the clinician would simply walk in the bathroom and go, how come that’s not an oval? Well, I need to be looking harder

***Ethan thinks the lipodystrophy patient represents a very rare version of what happens when the whole thing goes awry, but that there are going to be more common versions of this that exist***

- He thinks it’s similar to the distinction between familial hypercholesterolemia and run of the mill hypercholesterolemia

> “*We’ve learned a lot from rare diseases*”‒ Ethan Weiss

- In this case, we already have an abundance of human genetic data that suggests this sort of polygenic version of this thing
- There’ll be some papers coming out soon with collaborators of Ethan’s that will show that the **FMR (fat mass ratio)** itself conveys more risk even than smoking status
  - That’s a pretty amazing finding, right?

***If you have a high FMR (meaning you have a lot of fat up here and not very much fat down here), your risk of significant bad things in the form of coronary disease events is higher than it would be even if you smoked cigarettes***

- Ethan finds this comparison astonishing; none of us would’ve believed that

- Peter likes the analogy of [FH (familial hypercholesterolemia)](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia), because it is also a very heterogeneous waste basket of genetic things; more than 3,000 different genotypes produce the FH phenotype
  - The [PCSK9-mutation](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia#PCSK9) led to the most power drug on the market (PCSK9-inhibitors)
- It will be interesting to how how genetic insights from lipodystrophy will help form therapeutic options for people who don’t have lipodystrophy
  - Ethan doesn’t think these rare genetics will be as informative as PCSK-9
  - But the genetics that underlie the common variation in phenotype [of fat storage] are going to be very interesting
- Of the single gene mutations that cause disease, the most common is [FPLD2](https://rarediseases.info.nih.gov/diseases/3126/familial-partial-lipodystrophy-type-2) (a mutation in  [lamin gene](https://medlineplus.gov/genetics/gene/lmna/#conditions)), and this leads to progeria, cardiomyopathy, muscular dystrophy, and lipodystrophy
  - A complicated mess of protein is expressed in the nuclear laminate
  - It’s hard to imagine that a common variation in that gene is going to lead to problems

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Ethan Weiss**: [#52 – Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone – two topics that are surprising interrelated](https://peterattiamd.com/ethanweiss/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 6, 2019) | [0:45, 6:15]

**Ethan is an entrepreneur-in-residence**: [Third Rock Ventures](https://www.thirdrockventures.com/people/ethan-weiss) **|** [1:00]

**Patients with a zero calcium score who have significant findings of atherosclerosis by CTA**:

- [Prevalence and extent of coronary artery disease determined by 64-slice CTA in patients with zero coronary calcium score](https://pubmed.ncbi.nlm.nih.gov/20734235/) | *The International Journal of Cardiovascular Imaging* (E Ergun et al. 2011) | [13:45]
- [Coronary artery anomalies in patients with zero calcium score: A new evidence supports the 2016-NICE guidance](https://www.ejropen.com/article/S2352-0477(19)30052-8/fulltext) | *European Journal of Radiology* (K Abdalla et al. 2020) | [13:45]
- [The Atherosclerotic Profile of a Young Symptomatic Population between 19 and 49 Years: Coronary Computed Tomography Angiography or Coronary Artery Calcium Score?](https://www.mdpi.com/2308-3425/8/11/157) | *Journal of Cardiovascular Development and Disease* (G Feuchtner et al. 2021) | [13:45]

**ISIS-2 RCT of streptokinase**:

[Randomised trial of intravenous streptokinase, oral aspirin, both, or neither among 17,187 cases of suspected acute myocardial infarction: ISIS-2. ISIS-2 (Second International Study of Infarct Survival) Collaborative Group](https://pubmed.ncbi.nlm.nih.gov/2899772/) | *The Lancet* (1988) | [29:15]

**Peter’s upcoming book**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=3JBEH14X6GEJB&keywords=OUTLIVE%3A+The+Science+and+Art+of+Longevity&qid=1675262516&sprefix=outlive+the+science+and+art+of+longevity%2Caps%2C136&sr=8-1) by Peter Attia with Bill Gifford (March 2023) | [33:15]

**FAME trials that looked at FFR in angiography**:

- [Fractional Flow Reserve versus Angiography for Guiding Percutaneous Coronary Intervention](https://www.nejm.org/doi/full/10.1056/NEJMoa0807611) | *NEJM* (P Tonino et al. 2009) | [34:00]
- [Fractional Flow Reserve–Guided PCI versus Medical Therapy in Stable Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1205361) | *NEJM* (B De Bruyne et al. 2012) | [34:00]

**The COURAGE trial showed that stenting does not provide benefits for all patients with plaque**: [Optimal Medical Therapy with or without PCI for Stable Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa070829) | *NEJM* (W Boden et al. 2007) | [42:00]

**RCTs find that invasive management of coronary artery disease is not better than optimal medical therapy**:

- [Optimal Medical Therapy with or without PCI for Stable Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa070829) | *NEJM* (W Boden et al. 2007) | [42:00]
- [Outcomes in the ISCHEMIA Trial Based on Coronary Artery Disease and Ischemia Severity](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.120.049755) | *Circulation* (H Reynolds et al. 2021) | [42:00]
- [Percutaneous coronary intervention in stable angina (ORBITA): a double-blind, randomised controlled trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(17)32714-9/fulltext) | *The Lancet* (R Al-Lamee et al. 2018) | [42:00]

**The PRECISE trial**: [The prospective randomized trial of the optimal evaluation of cardiac symptoms and revascularization: Rationale and design of the PRECISE trial](https://www.sciencedirect.com/science/article/pii/S0002870321004774?via%3Dihub) | *American Heart Journal* (M Nanna et al. 2022) | [54:00]

**Verve Therapeutics**: [Verve Therapeutics: Our approach: We are pioneering a new approach to the care of patients with cardiovascular disease](https://www.vervetx.com/approach/) | [57:00]

**James O’Keefe commented that athletes with very high degrees of cardiorespiratory fitness may have a higher frequency of coronary artery calcification**: [Cardiovascular Damage Resulting from Chronic Excessive Endurance Exercise](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6179786/) | *Missouri Medicine* (H Patil et al. 2012) | [1:00:00]

**Targeting a blood pressure of less than 120 mmHg resulted in less mortality (SPRINT trial)**: [A Randomized Trial of Intensive versus Standard Blood-Pressure Control](https://www.nejm.org/doi/10.1056/NEJMoa1511939) | *NEJM* (J Wright et al. 2015) | [1:20:30, 1:23:00]

**ALLHAT blood pressure trial**: [Major Outcomes in High-Risk Hypertensive Patients Randomized to Angiotensin-Converting Enzyme Inhibitor or Calcium Channel Blocker vs Diuretic: The Antihypertensive and Lipid-Lowering Treatment to Prevent Heart Attack Trial (ALLHAT)](https://jamanetwork.com/journals/jama/fullarticle/195626) | *JAMA* (C Furbert et al. 2002) | [1:35:45]

**Prospective observational study of blood pressure and risk of cardiovascular disease**: [Blood pressure usually considered normal is associated with an elevated risk of cardiovascular disease](https://pubmed.ncbi.nlm.nih.gov/16443415/) | *The American Journal of Medicine* (A Kshirsagar et al. 2006) | [1:38:15]

**STEP trial**: [Trial of Intensive Blood-Pressure Control in Older Patients with Hypertension](https://www.nejm.org/doi/full/10.1056/NEJMoa2111437) | *NEJM* (W Zhang et al. 2021) | [1:43:15]

**HOPE trial use of ACE inhibitors to control blood pressure has benefits for cardiovascular disease** | [Effects of an Angiotensin-Converting–Enzyme Inhibitor, Ramipril, on Cardiovascular Events in High-Risk Patients](https://www.nejm.org/doi/full/10.1056/NEJM200001203420301) | *NEJM* (S Yusuf et al. 2020) | [1:48:00]

**People born with a congenital form of severe insulin resistance have astronomical risk of coronary artery disease**: [Premature Atherosclerosis Associated With Monogenic Insulin Resistance](https://www.ahajournals.org/doi/10.1161/01.CIR.103.18.2225) | *Circulation* (RA Hegele, 2001) | [1:55:15]

**Check out Steve O’Rahilly’s 2019 Banting Memorial Lecture**: [2:03:45]

- [The lecture](https://professional.diabetes.org/webcast/banting-medal-scientific-achievement%E2%80%94%E2%80%9Ctreasure-your-exceptions%E2%80%9D%E2%80%94studying-human-extreme)
- [The associated paper](https://us-west-2.protection.sophos.com/?d=diabetesjournals.org&u=aHR0cHM6Ly9kaWFiZXRlc2pvdXJuYWxzLm9yZy9kaWFiZXRlcy9hcnRpY2xlLzcwLzEvMjkvMTc3OTkvVHJlYXN1cmUtWW91ci1FeGNlcHRpb25zLVN0dWR5aW5nLUh1bWFuLUV4dHJlbWU=&p=m&i=NjM5MjEzOGNjNDEyOGMxMjM1MGU4MzY2&t=VTJPNDd2NmNRWkhqYWJQcmJJUmllOTZoRUhiM1lZZXFuWnEzTGkxNjJ3UT0=&h=40eee14d8cb640b2911bfc3a102b305f&s=AVNPUEhUT0NFTkNSWVBUSVbBx_ZrjZBUdNKO75nnkymNwKXP8smZZcjVHKJ9S92mFA)

§

## People Mentioned

- [M. Robert Peters](https://www.linkedin.com/in/robert-peters-md-28b40a7) (Radiologist with expertise in calcium scans and CTA) [12:15]
- [Thomas (Tom) Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876) (MD, FACP, FNLA, lipidologist) [15:00]
- [Sheryl Sandberg](https://en.wikipedia.org/wiki/Sheryl_Sandberg) (American business executive, billionaire) [29:45]
- [Michael (Mike) Gibson](https://scai.org/c-michael-gibson-md-mscai) (CEO of the combined non-profit Baim and PERFUSE research institutes at Harvard Medical School) [36:00]
- [Sekar Kathiresan](https://www.vervetx.com/leadership-team/sekar-kathiresan-md/) (MD, co-founder of Verve Therapeutics) [57:00]
- [James O’Keefe](https://www.cardiotabs.com/james-okeefe-md) (Cardiologist and founder of cardiotabs) [59:45]
- [Rory Collins](https://www.ndph.ox.ac.uk/team/rory-collins) (Professor of Medicine and Epidemiology at the University of Oxford) [1:08:45]
- [Jean Olsen](https://www.asn-online.org/about/bio.aspx?ID=47720&title=BRCU+Faculty) (retired Nephrologist and Professor of Medicine at UCSF) [1:13:30]
- [Richard (Rick) Lifton](https://www.rockefeller.edu/our-scientists/heads-of-laboratories/1139-richard-p-lifton/) (expert in the regulation of blood pressure, member of the National Academy of Sciences, President of Rockefeller University) [1:14:00]
- [Stephen O’Rahilly](https://www.mrl.ims.cam.ac.uk/research/principal-investigators/professor-sir-stephen-orahilly/) (Professor at the University at Cambridge expert in metabolic disease) [1:53:15]
- [Gerald Schulman](https://medicine.yale.edu/profile/gerald-shulman/) (Professor of Medicine and Cellular and Molecular Physiology at Yale, expert in insulin resistance) [1:58:45]

§

##### Ethan Weiss, M.D.

Ethan Weiss got his bachelor’s degree from Vassar College. He completed his MD and residency at John Hopkins. He then went to UCSF where he completed a clinical fellowship in cardiology and postdoctoral research training. Dr. Weiss is an Associate Professor in the School of Medicine at UCSF where he practices preventive cardiology and conducts research.

In his research, Dr. Weiss uses genetic models to better understand the mechanism of metabolic disorders such as obesity, fatty liver disease, and diabetes. He also studies the blood clotting system and has interest in identifying novel ways to safely block clots associated with diseases such as heart attack and stroke without causing an increase in bleeding. He has conducted randomized clinical trials to assess the impact of nutritional interventions on weight loss, insulin sensitivity, and metabolism.

Currently, Dr. Weiss has shifted his attention to entrepreneurial work at [Third Rock Ventures](https://www.thirdrockventures.com/people/ethan-weiss).  He is working on a project related to cardiometabolic disease. He is also the Co-Founder and Medical Advisor for [Keyto](https://getkeyto.com/ethan-j-weiss/), a company that created an app and program to make it easier to follow a Mediterranean-style keto lifestyle. [[UCSF Profiles](https://profiles.ucsf.edu/ethan.weiss)]

Twitter: [@ethanjweiss](https://twitter.com/ethanjweiss)