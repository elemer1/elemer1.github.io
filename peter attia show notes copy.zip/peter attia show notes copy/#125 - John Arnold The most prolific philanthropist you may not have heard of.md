# #125 – John Arnold: The most prolific philanthropist you may not have heard of

**Source:** [https://peterattiamd.com/johnarnold/](https://peterattiamd.com/johnarnold/)

---

John Arnold is widely regarded as the greatest natural gas trader of all time, but in his late 30’s he walked away from it all and turned full-time philanthropist. He and his wife have committed to strategically give away most of their vast fortune in their lifetime and are already doing so at a staggering pace of nearly a half billion dollars a year. In this episode, John explains his quest to address the most challenging social programs plaguing the country, including criminal justice, health care policy, and K-12 education. John also shares self-identified attributes that contributed to his success in natural gas trading and how those same traits have translated to his philanthropic aspirations.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/johnarnold/the_Drive_public.png)

Play

#125 - John Arnold: The most prolific philanthropist you may not have heard of

#125 - John Arnold: The most prolific philanthropist you may not have heard of

1x15s30s

0:002:28:26

## We discuss:

- John’s background, upbringing, and early entrepreneurial tendencies [3:50];
- John’s time and rise at Enron [16:45];
- Characteristics that made John an exceptional natural gas trader and how they translate to his philanthropic work [27:30];
- The collapse of Enron [35:00];
- The success of John’s hedge fund, and his early interest in philanthropy [40:30];
- The infamous 2006 trade that brought down Amaranth Advisors [55:45];
- John’s analytical prowess and emphasis on fundamentals [1:02:15];
- The decision to become a full-time philanthropist and the founding of Arnold Ventures [1:09:00];
- Education—John’s quest to fundamentally change K-12 education [1:18:45];
- Strategic philanthropy—preventing problems by attacking root causes and creating structural change [1:24:30];
- The criminal justice system—structural changes needed to address mass incarceration, policing practices, and recidivism [1:31:45];
- Re-imagining prisons to reduce recidivism [1:49:00];
- US health care policy—John’s focus on drug prices, and the severe consequences of not making system changes [1:56:15];
- Climate change—the bipartisan role of John’s foundation [2:13:45];
- Advice for young adults interested in philanthropy [2:17:45]; and
- More

§

## Show Notes

## John’s background, upbringing, and early entrepreneurial tendencies [3:50]

**Who is John?**

- He’s an “*equal opportunity special interest pot stirrer*”

![](https://peterattiamd.com/wp-content/uploads/2020/08/pinned-tweet-johnarnold-1024x269.png)

**Figure 1. An equal opportunity special interest pot stirrer.** Image credit:  [Twitter – @JohnArnoldFndtn](https://twitter.com/JohnArnoldFndtn?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

- John and his [foundation](https://www.arnoldventures.org/) get major flack from both the left and the right politically (Therefore, the issues he attempts to zoom in to are ones where the l*eft and the right are starting to come together)*
- Prior to the foundation, John made his fortune as a natural gas trader

**Arnold Ventures**

- [Arnold Ventures](https://www.arnoldventures.org/), the foundation founded by John and his wife [Laura](https://www.arnoldventures.org/people/laura-arnold-john-arnold), is currently focusing mostly on health policy, public finance platforms, and criminal justice
- Foundation gives about 400 million away each year

> “Our philanthropic intent is to give away the vast majority of our money during our lifetime.”

**An entrepreneur from a young age**

- John was an entrepreneur and an aspiring businessman starting as a young kid
- At 12 he mowed lawns but realized not much money and too much competition
- Started selling sports cards at age 14
- With the trading card work, he basically figured out geographical areas of arbitrage within the trading card industry and created a business out of it

> “I ended up spending a couple summers just full time on this baseball card, really geographic arbitrage and information arbitrage, that I would have a sense of who the best buyer was for every product.”

*Defining arbitrage—*

- “I would describe arbitrage as taking advantage of price differences with little to no risk.”
- Today with the internet, a lot of that arbitrage and pricing inefficiencies have gone away or have been, what’s called in the trade, “Arbed out”

**What he wanted to do after college**

> “I was the guy that was trying to get out of there and into the game as quickly as possible. Every day I was at college, it was one less day that I had to be in the game.”

- From a young age, John knew he wanted to be in Wall Street
- He didn’t know much about it, but he felt like it was the “biggest game around”
- The books [Liar’s Poker](https://www.amazon.com/Liars-Poker-Mchael-Lews/dp/B003B12P62/ref=sr_1_2?dchild=1&keywords=liar%27s+poker+1989&qid=1598130318&s=books&sr=1-2) as well as [Barbarians at the Gate](https://www.amazon.com/Barbarians-Gate-Fall-RJR-Nabisco/dp/0099545837/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) intensified his interest
- During college, he was focused on getting out of there and into the game as quickly as possible
- Despite not being recruited heavily, he talked his way into an interview at Enron and was offered an analyst position

## John’s time and rise at Enron [16:45]

- John arrived at [Enron](https://en.wikipedia.org/wiki/Enron) in 1995, before it was all that well-known
- Historically, Enron was a pipeline company
- The natural gas industry was regulated heavily until 1992 when it became deregulated

*What that meant to the industry*:

- Previous to 1992, the pipeline was responsible for providing the merchant services to the buyer and seller
- So the producer of gas would sell to the pipeline
- And then the pipeline would transport the gas and sell it to the customer
- It was viewed that this was negative because pipelines are natural monopolies frequently, and so the services and the cost of those services were too high
- So in 1992, they deregulate it and here is Enron as the gas merchant

In 1995, there were 2 aspects to Enron’s business:

1 – The historical pipeline business

2 – A new “investment bank” side

- Around that time was when the decision was made to promote [Jeff Skilling](https://en.wikipedia.org/wiki/Jeffrey_Skilling) to the #2 position of the company
- This made sense because the company was looking to move towards the investment bank/trading business as, generally speaking, the return on equity is higher if you have fewer assets (sort of the direction of corporate America at the time)

**John first job at Enron**

- First job was as an analyst on the trading floor – very rare for first position
- He wasn’t trading right away, more just running spreadsheets and analytical work
- He was able to learn the business up close
- John quickly realized that a trading career was directly in line with his skillset

> “I found the perfect job for my skill set as my first job. And I think that’s pretty rare, and it happened by accident. I could have very easily ended up a mergers and acquisition investment banker at Merrill Lynch, but I ended up trading commodities at a relative upstart of a company that was just the perfect spot for my skill set.”

**How John rose so quickly through Enron**

- All new hires were supposed to do four 6-month rotations in different sides of the business then they go back to business school
- But they made an exception for John as he was really well liked in the natural gas group
- However, one of the traders made a big mistake on the trading floor and the group had to be dissolved
- John had the choice to go to the UK or go downstairs and work in the **natural gas trading grou**p
- While tempted to go overseas, *John knew the natural gas group was the future at Enron* so he chose that route

**Winter of 1996—“*****A whole new game*****”**

- This is when the natural gas prices “blew out” John says—It was an extremely cold winter and all the historical relationships that gas had just completely changed
- People who had spent their entire career in gas weren’t sure if they knew anything about gas anymore
- “***It was a whole new game.***”
- *First job within the natural gas division*: They put John as an assistant trader with a gentleman who had the expertise on the physical side of the business and they were told to “go figure this out”
- Around this time is when Enron became a “darling” in the industry
- The mid-level guys were being poached by competitive companies making Enron a unique environment for a smart and responsible young person to rise quickly
- By the time John was 25, he was the **head natural gas trader at the largest natural gas trading company in the industry**
- While John benefited greatly from this “merit-based” system of promotion, he suspects the company gave out too much responsibility and didn’t have enough control—

> “*I think it ended up being the downfall of the company as well, as there just wasn’t the controls on people who were given too much responsibility, too much of the company’s balance sheet to use without their adequate controls on it.*”

## Characteristics that made John an exceptional natural gas trader and how they translate to his philanthropic work [27:30]

> “The stress level was intense. I think I’m very good at handling stress, but the stress level was intense to a point of not being healthy.”

- In a given day, John was trading **billions of dollars** of notional value of gas
- Much of it was trying to buy at $2 and trying to sell it at $2 and a half penny for enormous volumes
- From the moment you sat down in the morning until about 4pm, it was just nonstop trading
- Food was delivered to your desk, and bathroom breaks meant running back and forth
- This non-stop stress is why traders generally have short trading careers

*How do many traders destress?*

- Destressing for traders usually meant drinking, partying, gambling, etc.
- In his 20s, he gained weight and was just not at all healthy especially compared to him now
- John gravitated away from that lifestyle in his 30s when he matured, got married, kids, etc.

*Did John experience an “addiction” to the “high” of trading?*

- It’s not uncommon for traders to be addicted to the rush, the high, the physiologic response that they get to a good trade
- John says he knows the feeling and saw many traders afflicted by this
- However, he felt like he wasn’t addicted to it

***What made John such an exceptional trader?***

- John credits his success to two traits:
  - 1-His ability to not let emotions impact his decision making process
  - 2-He fell perfectly on the confidence spectrum (confident but not too arrogant)

*Regarding* ***emotional detachmen*****t**—

- Whether he was having a great day or the worst day, you couldn’t tell by looking at him
- He instead was just “***100% focused on executing the process***”

⇒ There’s a saying in the investment world, “*Fear and greed drives a lot of price trends in financial assets.*”

- This phrase refers to the fact that many traders are either greedy or fearful and that’s driving your behavior
- The more you can eliminate those fear and greed from the trading process, the better you get

*The* ***confidence spectrum***—

- John says he fell perfectly on the confidence spectrum
- Confidence is key, but you can’t be too arrogant—arrogance has been the “*destroyer of many trading careers*”
- The right way to think is, “***I’m confident in my view on this, but I know I might be wrong.***”

***How did these traits translate into John’s philanthropy work?***

- John says these traits translated very well
- With his foundation they come up with plenty of theories on how to solve a complex issue
- You must have confidence in that theory, however, you must not be wedded to it because you know you could be wrong

> “Everything we’re doing in the foundation is evidence-based, but the evidence is never perfect.”

## The collapse of Enron [35:00]

Book about the fall of Enron: [The Smartest Guys in the Room](https://www.amazon.com/Smartest-Guys-Room-Amazing-Scandalous/dp/1591840538)

*Preceding Enron’s collapse…*

- John’s trading group was wildly successful
- Yet, Enron was soon to be bankrupt
- John was so singularly focused on his job that he didn’t have much of a sense as to what was going so wrong in other divisions
- Enron, like most companies at the time, was [disintermediating](https://en.wikipedia.org/wiki/Disintermediation) their business chain

Bad decisions—

- There were some bad decisions being made in those other sectors that were leading to the downfall
- In parallel, there was a culture of **never being able to admit failure**
- Enron had morphed into a financial business which is completely contingent upon having the faith of your creditors (i.e., Wall Street)
- Once Wall Street loses faith in you and refuses to fund you, “*the business is toast*” — And that’s what happened to Enron

*When did John realize his career at Enron was going to be cut short?*

- John was likely the most profitable person at Enron
- But it became clear that the company was in trouble
- Enron eventually reached a deal with a JV partner (a New York bank) but John had different view on how the business should proceed and he decided to leave

## The success of John’s hedge fund, and his early interest in philanthropy [40:30]

*When John was still at Enron…*

- Many people were calling John saying they wanted to invest with him if he did his “own thing”
- When John knew Enron was collapsing, he started a fund, hired people, bought equipment, etc.
- John had plans to raise $50 million for his fund and would’ve easily had the investors to do so
- But then BOOM—the investigating into Enron breaks open and nobody knows if john was a fraud or if he was going to prison
- John started [Centaurus](https://en.wikipedia.org/wiki/John_D._Arnold#Centaurus) (hedge fund) but had to settle for only $8 mil initial funding (his money plus 2 investors)

**How John grew** [**Centaurus**](https://en.wikipedia.org/wiki/John_D._Arnold#Centaurus) **so successfully**

- After Enron scandal, about half the pipeline and electric utility merchant/trading businesses were out of business because that industry fell out of favor with Wall Street
- The market became **incredibly inefficient** and there was a great need for **risk intermediation/risk warehousing**
- It was very low risk for arbitrage type trades that shouldn’t exist in a *normally* functioning market that existed for that next year just because the market players had been so decimated
- This low-risk model resulted in John’s fund making $3 million in the first month, and was up 150% in 3 months
- With that success, investors became interested again which helped increase his [AUM](https://en.wikipedia.org/wiki/Assets_under_management)

**The synergy of market arbitrage plus speculative trading**:

*The two strands of John’s hedge fund*—

 1) Providing liquidity and getting paid for the service of warehousing some risks, and

 2) Speculative trading – Trying to make a call on where natural gas prices were going next

- In the first few years, his business was mostly doing the low risk stuff to create the base and an upward trend in profitability
- But on top of that line of business, John started doing more and more speculative trading
- This worked well because if he was ever wrong on a market call, he wouldn’t be decimated since he was still making money on the arbitrage side of the business
- The inefficiency in the market, which created the low-risk arbitrage, made it the “***perfect time to be in natural gas***”

**The moment John realized he’d never have to worry about money again:**

- In 2002/2003, the demand was high and supply wasn’t keeping up
- John wasn’t the only trader that recognized this, however, the **risk/reward was being very misvalued**
- John recognized that if they were to have a very cold winter in 2002 or 2003, the gas market could experience some significant shortages and there would be corresponding price spikes
- This cold weather event was perhaps a **1 in 5 probability**, but the bets were pricing them as if it was **1 in 50**
- There ended up being a 2-day stretch in late February 2003 which sent prices to one of the three highest gas prices in the last 20 years
- The fund **more than doubled** in those two days in terms of total assets
- Afterwards, he called his mom to say, “***We’re set. We have financial security now forever regardless of what happens****.*”

**When did John first start thinking about philanthropy?**

> “I always recognized the limited social value of trading. I think there is a need for someone to provide risk warehousing and liquidity to markets, but trying to tell the story about how I was adding value or contributing to society was hard. And that always bothered me.”

- John began thinking about trading in his early Enron days (He was getting paid well — 100k bonus checks)
- His charitable interest gravitated towards **K-12 education**
- He found [KIPP Charter Schools](https://www.kipp.org/) and gave them a *5-figure donation*
- This was the start of his very long journey, thinking about K-12 education in the country
- But in 2002/2003, after his massive early success with his hedge fund, he was only thinking about philanthropy about 1% of the time.

**When John’s hedge fund started gaining major attention**:

- At some point a magazine published the top 100 traders and listed john at top 5 in making money
- This sort of broadcast to the rest of the industry that something was going on in natural gas
- This naturally brought in a bunch of new entrants in the gas market
- John made a deliberate decision keep the focus of the business narrow—Didn’t want to trade oil,  didn’t want to trade natural gas stocks or natural gas bonds, didn’t want to trade agriculture
- “***I wanted to be the best in the world at North American natural gas and power trading***.”
- This was a strategic move to put a natural limit as to the amount of assets that they could manage
- John’s assets under management (AUM) peaked around **$6 billion**—This was bordering on too big because you may be spreading yourself too thin into areas that you don’t have the deepest domain expertise

*John business was* ***all about return*** *(not fees from investors)—*

- John wasn’t in it to make fees from investors
- John was personally the largest investor in the fund
- So he was in it for the **return on the money** and that’s how he pitch it to potential investors
- It was always driven by: *How do I want my money managed?*

## The infamous 2006 trade that brought down Amaranth Advisors [55:45]

**Background**

- [Brian Hunter](https://en.wikipedia.org/wiki/Brian_Hunter_(trader)) and [Amaranth Advisors](https://en.wikipedia.org/wiki/Amaranth_Advisors) did very well in 2005 during the hurricane season
- The impact of [Hurricane Katrina](https://en.wikipedia.org/wiki/Hurricane_Katrina) created a massive shortage in gas and the price of gas had one of the greatest peaks in last ~30 years

After 2005, two things happened in the industry—

1. A belief that the increasing frequency and intensity of hurricanes would damage the structure of the energy sector and natural gas sector
2. There would be a great fear amongst any trader to be **short** during that time period (the hurricane season)

**Amaranth’s position in 2006**—

- In 2005, Brian Hunter, the head trader at [Amaranth](https://en.wikipedia.org/wiki/Amaranth_Advisors), was in the **long position** and made tons of money when gas prices spiked after Hurricane Katrina caused massive shortages in supply
- Brian thought something similar would happen (or at least a big scare would happen) in 2006 causing the same type of move in gas prices
- However, the 2005 Katrina event sent the signal to every producer to **increase supplies**
- John, who had a 25% opposite position of Brian, could see that supplies were ramping up in 2006
- Despite this increase in supply, Brian continued buying more and more—so much that he distorted the relative values in that market
- The story is often told like it was *Brian vs. John* (John had a 25% opposite position)
- Reality is that it was the *whole market (including John) versus Brian*, because Brian was such a large long position in this

*So what happened in 2006?*

- There was no hurricane in 2006, and prices collapsed
- Brian couldn’t hold up the prices any longer and it destroyed Amaranth
- The story is framed as if Brian and John had competing bets as to **what the** ***weather*** **was going to do**
- However, it was actually taking a position on the more important question–***supply***
- John felt like even if they WERE hit with a demand shock from a weather event, the market was much better prepared to absorb the hit compared to 2005

*How John thought about the situation*:

- “You had this probability distribution function of the possible outcomes. And then think about, under each outcome, ‘how would I think about what fair value is of the commodity at that time?’”
- **The mistake Brian made was**—The market was already so mispriced to expected value that even had you had the supply shock happen, what was the upside? “We’re already priced for that.”
- Peter adds, “*You realize that it was probably a bit more of an error in hubris as well, which goes back to your point about maybe being a little too confident in your ability to predict what’s going to happen.*”

## John’s analytical prowess and emphasis on fundamentals [1:02:15]

**John has a “third superpower”—an insatiable, bordering on pathological, obsession for knowing everything**

- Peter knows the feeling
- John says his appetite for knowledge has served him well in trading and philanthropy

*In his trading days…*

- By being a hedge fund and not being in the physical business (dealing with customers, etc.), John says they were at an “information disadvantage”
- So when a counterparty put up an opposite trade of John’s position, he was always thinking about:
  - *What are they thinking?*
  - *What do they know?*
  - Can I replicate as best I can, the knowledge that they have so that I can make an educated and confident decision?

- John’s team was at an information handicap (compared to say, [BP](https://en.wikipedia.org/wiki/BP))

*How did John make up for this informational disadvantage?*

- **1) Better analysis**—knowing where to get third party information, having better analysis, and crafting better models that described what the past was and thus what the future is going to be
- **2) The biggest fundamental research department**  — i.e., count the molecules, try to count as many molecules as you can—Where did it come from? Where did it travel? How was it consumed?

> “Our advantage was that we’re going to invest in the fundamentals more than anybody else is and then overlay that with some good trading.”

**3 main reasons why trading natural gas was “easier” than oil:**

 1) **It was this closed system** —the molecules, for the most part, just stayed in North America

 2) **Deregulation got the pipelines out of the business of trading**

- The pipelines, which had the most fundamental information about where the gas came from and where it was going, now had to publish all this information publicly and they couldn’t trade on it
- Compare that versus oil, Exxon can own the oil platform in the Gulf of Mexico, stick it on an Exxon ship, take it to an Exxon owned refinery and put it in Exxon gas stations. And so as an outsider, trying to figure out and track those molecules, it’s impossible.
- That’s why the best, most profitable oil traders have to be in the physical business

 3) **Twice a year, there was a mechanism to get you back close to fair value**

- Because nat. gas was a seasonal product, you store it during the summer getting ready for the peak winter demand which created a window of what it should be when you exit the winter
- Compare that to a tech stock today— there’s no forcing mechanism that necessarily has to get that tech stock back to one’s belief of fair value
- So with nat gas… while price could deviate from fundamental value for parts of the time of the year, twice a year, it kind of had to go back to that fair value, which was **great as a fundamental trader**

## The decision to become a full-time philanthropist and the founding of Arnold Ventures [1:09:00]

**Deciding to focus on philanthropy**

> “I started thinking more about giving the money away than making more of it. That was really the signal to me that I want to be spending my time on the other side of the table and I’m physically and mentally, emotionally exhausted with trading natural gas.”

- Met his wife, Laura, in early 2006 and got married not long after
- They both started to really think about ‘***what should we do with our lives now?***’
- In 2006, 3% of his focus on philanthropy
- But by 2008, John and Laura had founded [Arnold Ventures](https://en.wikipedia.org/wiki/Arnold_Ventures_LLC) and John was putting about my 10-15% of his energy into the foundation
- This became an issue because **trading takes 100% laser focus** in order stay above the competition

- In 2012, John decided it’s time to **shut down his hedge fund**
- This was more than a decade living and breathing nothing but natural gas

**A hard decision**

- It was a hard decision to make, says John, but it got easier because *things had changed in the market—*
  - The shale revolution increased supply greatly
  - The market went from being very volatile with booms and busts, to one that was in perpetual oversupply and kind of bouncing around marginal cost to produce
- John had to give billions of dollars back to investors because the market opportunity was no longer there to the same degree

> “When you’ve been playing in Vegas with the $25 table to go back down to the $5 table. It’s just not as emotionally interesting.”

*Summary of factors leading to the shutdown of his hedge fund—*

- Got married, had kids
- New regulations put into the business (largely due to the Brian Hunter/Amaranth episodes)
- Arbitrage and opportunity in the market became harder to find
- John began to lose the focus as his interest in the foundation was increasing

> “These things came together and it still took me two years to make that call, that it’s time, it’s time to close this up and go find happiness somewhere else.”

**Skills in trading that translated to philanthropy:**

  1-**Emotional temperament**—not letting your feelings get in the way of what you’re doing

  2-Having the **right amount of confidence**

- You have to be able to say, “Yeah, this is a huge and hard problem, but we should go after it.”
- But maybe not too much confidence to say, “We’re going to solve this problem no matter what.”

  3-An ability to **become an expert** in something in a relatively short period of time

- Peter compares John to Bill Gates, who is the ultimate example (check out the [Bill Gates documentary](https://www.netflix.com/title/80184771))

## Education—John’s quest to fundamentally change K-12 education [1:18:45]

**K-12 education — the first problem the foundation looked at deeply**

The questions John had about K-12 education:

- Why does one school have different results from a school down the street serving a very similar population of kids?
- How do you take what the best individual schools are doing and scale that?
- What makes a school better?
  - Is it small schools?
  - Is it better principals?
  - Is it better teachers?
  - Is it the curriculum?
  - Is it technology?
- What’s the idea that **scales** and creates **structural change**?

> “[K-12] is just the most fundamental issue facing long-term health and viability of this country.”

**The theory of change that drives John’s work in K-12:**

*The theory*: Strong and robust systems of any kind have the attributes of biological evolution

- In living organisms you have,
  - Variance amongst the organisms with the differential fitness
  - There’s a different rate of survival and reproduction
  - And then inheritability of fitness
- You need to have a **strong and robust system and that’s getting better over time**
  - Education, generally speaking, is not that (e.g., same curriculum, the same process, the same way of hiring, of training, of trying to develop teachers)

*In public education—*

- For the good ideas, there’s no natural mechanism for that to grow
- For the bad/outdated idea, there’s no mechanism for them to stop and go away
- In order to have the heritability of traits, you need the learning aspect—but public schools (or really any government monopoly) is not good at quality control and innovation in order to provide the necessary variance

Arnold Foundation’s theory is that…

- i) the school system needs to become a system of schools, and
- ii) the natural role for government is not to be the service provider, but to be the *regulator*
  - Currently, the government is filling both roles which is a problem because “***no system can regulate itself*****”**)

*If this theory works…*

- The parents and kids will have real choice in what type of model they want
- An immersion program
- High discipline or regular discipline,
- An art school or other specialty, etc.
- Giving real choice to parents/kids is the “**best quality control that can happen**”
- The government, as the regulator, needs to make sure that all kids are served, but is largely out of the business of providing the service of education

## Strategic philanthropy—preventing problems by attacking root causes and creating structural change [1:24:30]

**What’s the role of philanthropy?**

- Currently, only about 1% of the economy is philanthropy for social services or social goods
- A big question John and his foundation think about is: ***What’s the best use of that?***
- It can either—
  - 1) **Supplement government services** (typically described as charity, i.e., trying to solve today’s problems)
    - E.g., Giving money to existing programs like a food bank
  - 2) **Try to get to the root cause of problems** with *strategic* philanthropy, i.e., **prevent** those problems from developing tomorrow
- Both are important, but John gravitates towards the latter
- The latter allows for exploring…
  - *How does the philanthropic money compliment government services to make them better?*
  - *What is the market failure as to why government programs are not working as well as they should?*

**Role for “strategic” philanthropy**

- Most of the existing social non-profits are so focused on simply providing the day-to-day that they have no bandwidth for experimentation or innovation
- Strategic philanthropy can come in to explore, “How can these actors in these systems perform better?”
- Arnold Foundation spends more of it’s time looking at structural changes to the system b/c it’s scalable in a way that just providing another dollar for a program largely is not
- Strategic philanthropy requires experts and manpower to explore new ideas, old ideas, theoretical frameworks, potential second order effects of structural changes, etc.

*How challenging is doing this kind of strategic philanthropy?*

- Arnold Foundation has about 120 employees — “*We had no desire or interest to have 120 employees 10 years ago. That was not by design. We thought giving would be easy.*”
- At the beginning, John was sifting through the literature

*Example, the topic like preschool:*

- You see three papers that say preschool is amazing, it generates all these outcomes later in life
- Then you see one evaluation of the [Head Start program](https://en.wikipedia.org/wiki/Head_Start_(program)) that shows it doesn’t really have an effect
- As you dig deeper, you see **huge arguments** within this research sector about what the evidence really shows

*In every area that John has researched, he finds the same thing—*

- The first scan through it appears that everything works, it’s all great, writing checks there is a great way to invest money
- But as you dig deeper, it gets very frustrating because **the more you study, the less you know** about what worked and what didn’t

**\*One main insight from doing the deep digging:**

1. Very few new programs worked
2. And the things that DO work are generally already part of the fabric of society, e.g., K-12 education

The question for the foundation became: *What’s our role? Where could our dollars be most helpful?*

John’s frustration with trying to find the “right program” to fund really led him and the foundation down the path of—*How do you change and improve the system and the incentives and the rules of a system rather than what’s the next program we can fund?*

## The criminal justice system—structural changes needed to address mass incarceration, policing practices, and recidivism [1:31:45]

**When the criminal justice system got on John’s radar:**

- Laura had a legal background and gave her a perspective on it — one of the first organizations they gave money to was the [Innocence Project](https://www.innocenceproject.org/) by [Barry Scheck](https://en.wikipedia.org/wiki/Barry_Scheck) which got innocent men off of death row
- This got them thinking more strategically—*How do we change the system so that the wrongful convictions don’t happen in the first place?*
- They realized that **changing the system and policies** is where they wanted to spend the time—
  - Higher potential reward
  - It is harder work and the chance of success is lower
  - But the impact, if successful, is so much higher if you can improve how the system works
- The foundation spent an **entire year** just thinking about all the ways the inefficiencies in the system was leading to bad outcomes

> “There is this natural impatience. But I think we’ve been smart enough to realize that it’s smarter to invest wisely tomorrow than do something that’s unlikely to have an impact today.”

**How criminal justice system is broken:**

- Peter points out three clear issues with the criminal justice system:
  - 1-There seems to be an enormous racial disparity
  - 2-There are great difficulties in appealing, even in the presence of evidence that the first trial may not have been a great trial
  - 3-Coercion is a real problem which results in people pleading guilty to something they did not do

*John’s take on how we got to the current state of the criminal just system:*

- Increasing violent crime which peaked in the late 80s/early 90s
- This scary trend created a bipartisan response — crime was really destroying communities
- Everyone came together to start this **tough on crime** mantra
- The foundation of that was to intensify the “war on drugs” — which ended up having second and third order effects
- Crime ended up peaking in the early ’90s
- Some of it was because of some of the policies passed, but **a lot of it wasn’t**
- John says the drop in crime was relatively **independent of when communities adopted the new policies** (across America as well as globally)
- The significant drop in crime over the past 30 years is still a bit of a mystery, says John

*Fast forward to today—*

- Times have clearly changed, but we still have policies that were a reaction to an environment that was very different than today
- We’ve now seen the negative impact of those policies neighborhoods, the financial costs of those policies, and the trade offs associated with some of those policies
- We arrived at a point where both Republicans and Democrats have come together trying to rethink the right way to structure all aspects of the criminal justice system—from policing and courts and prisons and recidivism

**Speculating on what accounted for the reduction is crime starting in the mid-90s**

*What other factors could have accounted for the reduction in crime if not the increase in incarceration?*

- John says the best thing he’s seen on this is a [report from the Brennan Center](https://www.brennancenter.org/our-work/research-reports/what-caused-crime-decline)
- The summary is that it’s hard to see any one of them being really **causal** in the shifting crime
- Plus the same downward trends were happening globally (without the “tough on crime” policies)
- John says “*I’m not sure we’ll ever know*” what the main driver of reduced crime was

*Of all the mechanisms or tactics that would lead to an increase in incarceration, which of those were perhaps the* ***most responsible*** *for mass incarceration?*

- John thinks part of it has been longer sentences and part of it has been the conviction rates
- The system is built to demand a plea bargain
- The reality is that we just don’t have the court resources (the defense attorneys, the prosecutors, the judges, etc.) to hear a vast majority of cases
- In fact, [less than 5% of cases actually go in front of a judge](https://www.pewresearch.org/fact-tank/2019/06/11/only-2-of-federal-criminal-defendants-go-to-trial-and-most-who-do-are-found-guilty/), most of them just get pled out

**How do we solve this problem?**

- Incentives that have been built into the system almost coerce people to plead guilty to crimes that they may not have committed. – i.e., plea is 6 months and trial plus conviction is 20 years
- It’s really hard to see how you solve that problem without a **massive infusion of resources** into the courts, prosecutors, & defense attorneys) *which is not where we want to be spending money*
- The solution is more likely to come from spending money on **preventing crime** (such as on certain social services)
- The goal would be trying to figure out how to get rid of this culture where the system can’t handle everybody going to trial

**Is the role for philanthropy to try to address the questions of racism within law enforcement?**

For a long time, the focus has been on reducing crime rates with no regard for the **secondary effects** that the criminal justice system causes on these communities and families

- *‘Family’ example*—a disproportionate number of black men that go to prison leaving children without a father
- *Psychological effects*—Being a black man in America, especially in a low income neighborhood, comes with a psychological effect which is only worsened by an overly-aggressive police force in that community

**A big dilemma**: Minority communities have felt both **over-policed** and **under policed** at the same time.

- But violent crime is still a big problem and a huge cost to a community
- But most crime is committed within one’s own community
- So nobody in the community wants the police to leave entirely, there still has to be that function of deterrence

*Addressing the problem*:

- The problem doesn’t get solved just by passing one new policy
- This is an issue that has developed over decades of policing techniques, and centuries of disinvestment in these communities.
- The question is being considered: ***How do you both provide the public safety while not causing the damage that some policing techniques cause today?***

## Re-imagining prisons to reduce recidivism [1:49:00]

**Peter’s take on the prison system:**

- Peter had a profound experience when visiting a prison (See [episode of The Drive with former inmate Corey McCarthy](https://peterattiamd.com/coreymccarthy/))
- From that experience, Peter points out the reasons to put somebody in prison:
  - 1-To protect the public from them.
  - 2-To punish them for something they have done
  - 3-To provide them with a set of skills to reintegrate into society in a better way
    - Peter says there was virtually no effort into the rehabilitative part which virtually guarantees recidivism
- Peter wonders: *Is there an opportunity for strategic philanthropy to play a role in the rehabilitative side of incarceration?*

*John’s response*:

- It’s very hard to design effective recidivism programs AFTER someone’s come out
- The evidence is very poor that after-prison programs actually work

> “The nature of prisons has to change. If you wait until the days someone’s released, that’s way too late.”

**The foundation’s work on re-imagining prisons**

- They have a couple projects trying to reimagine prisons
- They are thinking through, *What’s the role of prisons?*
- The struggle is that states and counties that fund this are often constrained financially—
  - They are trying to figure out how to meet *today’s problem* which **too many people in prison**
  - And there’s very little bandwidth and money going towards improving outcomes over the long term when they HAVE to meet *today’s* needs
- The foundation is exploring questions like…
  - W*hat should prisoners be doing with their day*?
  - H*ow can we try to maximize the percent chance that they don’t come back here when they’re released*?

*The ROI case*

- You could certainly make an ROI case that if you invest more now you’ll save much more tomorrow
- The problem is that the pay off may not be for 5+ years
- In the private sector, they would make that investment every day
- But in the public sector, it’s on a cash accounting basis — i.e., you have to balance the books this year & you have a fixed amount of money
- That’s where the philanthropic sector can be an active player in this system is by providing the funds to experiment with different ideas and programs and then funding the high quality evaluation to see the potential ROI

*The values case*

- Another part of the foundations work is more about values
- Questions like: Should we keep someone detained in jail before they’ve gone to their court date because they don’t have the money to pay bail?
- The broader question being explored: *How do we fix it so it more closely represents American values while minimizing any potential second order effects, negative second order effects?*

## US health care policy—John’s focus on drug prices, and the severe consequences of not making system changes [1:56:15]

*How is John thinking about health policy in America?*

- John comments that this is just such a big, complex issue: “The number of things that one could work on in health policy is immense.”

**So where is John trying to apply his resources?**

The first area John wants to address is **drug prices** because it’s a topic with:

1. Very obvious flaws in the existing system
2. There were ideas that were one could conceive of being enacted on how to fix it
3. And the political window might open *in the future* such that there was demand by the public and thus by politicians to actually adopt some of this stuff

The foundation is focused on creating a more rational system to price pharmaceuticals that—

1. Balances interest and balances incentives that are necessary for the private sector to do the innovation
2. Balances the financial interests of the state and the federal government that’s largely paying for a lot of this stuff, and
3. That maximizes access for the patient

*The political window*:

- The foundation focuses on finding issues where a political window going to open up in the future
- So when the window opens, they can have evidence-based ideas that we could present to policymakers

For politicians to consider health care policies—

- You need ideas to present to them and say, “Here are the three things you need to do.”
- The reality is, the health care system is so complex, it really has 20+ problems
- But “you start to lose policymakers when you hit number four”, so you really want to narrow it down as best as you can (i.e., focusing on drug pricing)

**Peter’s rant on the US health care:**

- Our taxes disproportionately subsidize 2 things in the world, and one is military spend, and the other is healthcare spend
- For example, we pay so much more for drugs here than our neighbors do that we in effect subsidize the cost of R&D
- The United States is 3% of the world’s population, yet we pay 50% of the pharmaceutical revenues of the world
- The inflated prices that Americans are paying is helping and creating incentive for more medicines to be made here that then other countries get the benefit from.
- The NIH, for example, spends so much money on the basic science that’s required to get these drugs started, and in return, the pharmaceutical companies charge us 2x-3x the prices of other countries
- You could argue that we should be getting a discount because the United States taxpayers are funding much of the basic science and the cost of developing these drugs

⇒ For more on the health care system and issues with drugs, see Peter’s interviews with [Marty Makary](https://peterattiamd.com/martymakary/) and [Katherine Eban](https://peterattiamd.com/katherineeban/)

**Enormous health care spending—how can we change this?**

- One could argue that the US health care spending is not sustainable
- We’re currently spending 15+% of GDP per year and it’s probably increasing at 5% per year in relative growth

Without the greatest sovereign default on debt, ***what is it going to take to change this?***

- At the state level,
  - The **downsides** of the state having to balance a budget every year is that it can’t make the high ROI investments that it should
  - The **upside** is that it forces the states to consider trade offs—they have to decide where’s the highest value, and they look to save money
- The **federal government**, on the other hand, without that budgetary constraint, doesn’t have to make those trade offs
  - So what happens is that any proposed legislation where somebody gets harmed will not pass, because no hard decisions want to get made
  - The ramification of that is enormous budget deficits today and a potential default on a debt in the future
  - But perhaps the most concerning part is the possibility of severe [inflation](https://en.wikipedia.org/wiki/Inflation)

*The severe consequences of inflation*

- We seem to have a fiscal or monetary response to every problem, but the one problem you can’t solve from fiscal and monetary tools is inflation
- John is particularly concerned about inflation because that’s when you have to be **cutting fiscal spending and increasing interest rates** to try to combat inflation
- The negative repercussions of that is enormous because we are so levered with debt at household level, at the business level, at cities and states, at the federal level
- Inflation is less of a problem as long as GDP is growing faster than real inflation
- The US debt is increasing much faster than real GDP, and so the real debt is increasing and we never pay it off
- Bad things happen if interest rates rise to just 5%, much less double digits which we’ve seen before in this country

> “I want to help the world, I want to solve problems, but if the answer is just shovel more money at it, that’s not a sustainable answer in my mind.”

John’s foundation is working on: ***How do we improve the system without spending more money?***

- If you believe that there are no trade offs with how we spend our resources, then pharma prices are fine (in fact, double them, triple them)
- But that’s not what John believes, “*I believe there is a trade off and that a dollar put into pharma innovation is a dollar less for everything else*.”
- Other things like,
  - Other healthcare innovation (or health care services)
  - Education
  - Less recidivism
  - Etc.
- The pharma system has just been able to create this island where they don’t have to compete with anybody
  - They got their own rules, and it’s a messed up set of rules that incentivizes the wrong thing.
  - So even within that, we’re not getting the drugs that we should be getting
  - We’re getting things like marginal oncology drugs
  - We’re not investing in the antibiotics and vaccines, because the financial incentive isn’t there
- “*So we’re spending tons of money as a society and not even getting good returns for it.*”

**Optimistic about the future — Change happens slowly, then very quickly**

- John remains optimistic that real changing is coming
- But admits that this process is “emotionally frustrating”… to be banging on a problem for years with little perceptible progress
- Peter compares change like this to a stone mason hitting a rock over and over—
  - There’s a bunch of tiny imperceptible cracks and then there’s one hit that splits in open
  - But it wasn’t that one hit that did it, it was the many many that came before it
- Citing two real world examples –
  - The campaign against the [Don’t ask, don’t tell](https://en.wikipedia.org/wiki/Don%27t_ask,_don%27t_tell) policy seemingly went nowhere for decades until finally getting repealed (see [book by Josh Seefried](https://www.amazon.com/Our-Time-Breaking-Silence-Dont/dp/0143122193))
  - [Rick Doblin’s life-long work with psychedelics](https://peterattiamd.com/rickdoblin/) is close to coming to fruition

> “You just don’t have that feedback mechanism in this work that you had in the [natural gas] market and the complete opposite end of the spectrum”

## Climate change—the bipartisan role of John’s foundation [2:13:45]

**John’s high level thoughts on climate change**

- It’s a problem where the downside possibilities are so enormous that it makes sense as a society for us to make the investments today to try to decrease the probability of those downside scenarios.
- John admits that he does not know the probability of some of the truly catastrophic scenarios, but “it’s greater than zero. . .and less than 100%”
- John says that the downside is so great that society needs to make that investment

*How will John’s foundation work on climate change?*

- The foundation typically looks at issues and areas where there’s not much philanthropic focus
- And the climate field already has very thoughtful philanthropists who are working on this today

*Where John thinks they can add value*:

- In the climate change realm, most of the researchers, advocates, and funders come from the left (politically)
- But John believes this can only be solved with a bipartisan effort
- John says the democrats aren’t doing a very good job of bringing the republicans into the conversation when they do things like “put the whole Democratic platform into a climate change bill”
- John thinks the role of his foundation is to try to bring the both parties into the discussion by supporting organizations and politicians that are *on the right* who want to start taking steps

## Advice for young adults interested in philanthropy [2:17:45]

*Regarding his own kids—*

- He doesn’t want their lives to be defined by their parents, bur rather for them to have their own life experiences and create their own life
- He is discouraging them from working at the Arnold Foundation

> “Whenever you have that checkbook, people look at you differently, and treat you differently. . .because there is always something that they want funded. . .If somebody’s growing up in their teens and their 20s, and is looked at by the rest of the world as a checkbook first, I think that’s a very damaging way to grow up.”

**Advice to young adults with an interest in philanthropy**:

- As a society, we benefit when our community around us is stronger
- Whenever we have the needs of our family taken care of, it’s human nature to start thinking about your community
- John’s general advice about giving money is to try to do it strategically and intelligently
- And by giving to your community, you are likely making a more informed gift since you have a better sense of what the needs are of your own community

⇒ Small movement where you pledge to give everything above a relatively small salary to charity: [The Further Pledge](https://www.givingwhatwecan.org/get-involved/further-pledge/)

§

![](https://peterattiamd.com/wp-content/uploads/2020/08/1x1-johnarnold-500x500.jpeg)

##### John Arnold

John Arnold is an American billionaire, former hedge fund manager, and is widely regarded as the most successful natural gas trader of all time. Since retiring from energy trading in 2012, John now focuses on his political activism through Arnold Ventures LLC.