# #274 – Performance-enhancing drugs and hormones: risks, rewards, and broader implications for the public | Derek: More Plates, More Dates

**Source:** [https://peterattiamd.com/derekmpmd/](https://peterattiamd.com/derekmpmd/)

---

Derek is a fitness educator and the entrepreneur behind [*More Plates More Dates*](https://moreplatesmoredates.com/) and an expert in molecules commonly used and misused by bodybuilders and athletes. In this episode the conversation explores various compounds like growth hormone, testosterone, hCG, androgens, SERMs, SARMs, Clomid, estrogen, finasteride, aromatase inhibitors, peptides, and much more. Derek walks through the nuances of how these molecules are used by athletes to gain an edge while also exploring their potential side effects on disease risk, hair loss, fertility, and more. This conversation aims to reveal intricacies and provide insights into whether these compounds are uniformly harmful or if there are broader implications that could benefit the general population.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/derekmpmd/the_Drive_public.png)

Play

#274 - Performance-enhancing drugs and hormones: risks, rewards, and broader implications for the public | Derek: More Plates, More Dates

#274 - Performance-enhancing drugs and hormones: risks, rewards, and broader implications for the public | Derek: More Plates, More Dates

1x15s30s

0:003:14:31

## We discuss:

- Derek’s interest in weightlifting and experimentation with anabolic steroids at a young age [3:15];
- Derek’s experience acquiring steroids from underground labs and the potential long-term fertility concerns testosterone early in his bodybuilding career [12:00];
- The backstory on More Plates, More Dates and Derek’s unique ability to blend scientific knowledge with personal observation [17:00];
- Growth hormone—from extreme use cases to the more typical—and the misconception that it’s the “elixir of life” [21:30];
- Growth hormone 101: definition, where it comes from, and the challenges of measuring it [28:45];
- Does exogenous use of growth hormone compromise one’s ability to make endogenous growth hormone? [40:00];
- The use of growth hormone in restoration of tissue during periods of healing [42:00];
- Growth hormone-releasing peptides to increase endogenous GH: various peptides, risks, benefits, and comparison to exogenous growth hormone [48:45];
- The role of growth hormone in building muscle and burning fat, and its effects on sleep and daytime lethargy [1:02:30];
- The evolution of drug use in the sport of bodybuilding [1:10:30];
- What explains the protruding abdomens on some bodybuilders and athletes? [1:20:30];
- Death of bodybuilders [1:26:00];
- The complex interplay of hormones, and the conversion of testosterone into metabolites like DHT and estrogen [1:33:45];
- Post-finasteride syndrome, and how Derek successfully treated his hair loss [1:43:15];
- Testosterone replacement therapy: compelling use cases, side effects, and optimal dosing schedules [1:57:15];
- The use of aromatase inhibitors to suppress estrogen, and the misconceptions around estrogen in men [2:16:00];
- The use of other hormones beyond testosterone for male sex hormone replacement [2:21:00];
- The history of anabolic compounds, and the differing effects of various anabolic testosterone derivatives and related drugs [2:24:30];
- Use of SARMs by bodybuilders [2:29:45];
- Anabolic steroid and testosterone regimen of professional bodybuilders and the downstream consequences [2:36:15];
- The challenge of accurate hormone testing in the presence of anabolic steroids and supplements [2:44:45];
- The use of Clomid, hCG, and enclomiphene [2:47:15];
- Concerns about fertility: comparing the use of testosterone and hCG [3:00:30];
- The use of BPC-157 peptide for healing injuries [3:12:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Derek is from [*More Plates More Dates*](https://moreplatesmoredates.com/), he is a fitness educator and entrepreneur behind the More Plates More Dates YouTube channel, podcast, and companion website
- Peter has been following Derek for a couple of years and has always found him to be very thorough in his analysis and assessment of areas that are very difficult to get insight into from mainstream channels
  - For example, using published literature
- Derek has a lot of expertise around molecules, and the types of molecules that are both used and abused by bodybuilders and athletes
  - A lot of our discussion focuses on that
- Background: Derek is heavily into bodybuilding and fitness, and he talks openly about his past use of performance-enhancing drugs
  - And his interest in understanding the science around these things
- Why are we covering this topic?
  - Not a day goes by that Peter doesn’t get at least one patient asking him a question about one of the compounds
  - This includes things like growth hormone, testosterone, hCG, androgens, other hormones, SARMs, SERMs, peptides, Clomid, estrogen, and much more
- Throughout this conversation we look at how bodybuilders use these compounds
  - Bodybuilders use them in the highest amounts, and they talk very openly about these things
- We ask the question: what can we learn about these things for the general population
  - Are they all bad carte blanche?
  - Or is there some nuance to this that we understand?
- This interview of Derek is part 1 because we don’t get through most of what Peter wants to cover
  - Hopefully there will be a part 2 in the not too distant future

## Derek’s interest in weightlifting and experimentation with anabolic steroids at a young age [3:15]

**When did you get interested in lifting weights and nutrition?**

- Probably grade 11
- He was a rail (probably 138 lbs) and a basketball player
- A lot of his friends were getting into working out, putting on muscle, and he was the last one to get into it
- A lot of people can relate to being bit by the iron bug
  - Where you get the newbie gaines and the quick progress becomes addicting
- Then you get on a full blown routine thereafter
- He was skewed away from sports like basketball because his three-pointer and muscle memory was thrown off when he gained 30 lbs in a matter of months
  - Derek adds, “*All of a sudden your mechanics don’t feel exactly the same anymore.*”
- As you get into lifting weights, it’s hard to avoid some of the discussion around anabolic steroids, drug use, and bodybuilding
  - How are these insane brontosaurus physiques you see on stage achieved, and what goes into them?
  - You often heard it was some supplement source sold by somebody
- As Dered dug into it more and started to learn about hormones, pharmacology
  - He had hair loss caused by androgens when he was experimenting with them as a recreational bodybuilder
- He started to dig heavily into anti-androgens, 5⍺-reductase inhibitors, and he had this weird broad-spectrum pharma knowledge on weird niche stuff, but it was all overlapping with the basis of androgen therapy, synthetic derivatives

**Just for a timescale here, are you in college now or still in high school when you developed this level of interest?**

- His initial interest peaked in 12th grade
- When he gets interested in something, he completely buries himself in reading whatever he can find
  - Back then it was a lot of underground forums with gym bros going back and forth talking about their experience with fill in the blank compound
    - A lot of it was just anecdotal
    - Not that there’s a lot of good literature anyways
  - He would go on the forums, learn and dig into whatever science he could understand:  conceptualize and get a framework of understanding about how hormones impact physiology, muscle growth potential, genetic variability
- In his first and second year of university, he got pretty hardcore into bodybuilding
- He got up to 260+ lbs at his biggest, and that was when he discovered he had sleep apnea
  - His sleep apnea was severely exacerbated by getting that heavy that quickly
  - This gave him his first taste of side effects and potential downsides of bodybuilding
    - When you’re young (20, 21-years-old), you think you’re invincible and you can just blast compounds

**At 260 lbs, how lean were you, or were you relatively un-lean?**

- Relatively un-lean

**Were you using lots of anabolic steroids or just exogenous testosterone and calling it a day?**

- A lot by our standards, but by bodybuilder standards not really that much
- At peak exposure, he probably had a combined weekly dosage of 1500 mg to 2 g
- For reference, when a physician prescribes [testosterone](https://en.wikipedia.org/wiki/Testosterone) to a patient for replacement, they’re really only using testosterone (they’re not using [nandrolone](https://en.wikipedia.org/wiki/Nandrolone), [oxandrolone](https://en.wikipedia.org/wiki/Oxandrolone))
  - From a dose perspective, Peter has probably never prescribed more than 150 mg a week of [testosterone cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) for physiologic [TRT](https://en.wikipedia.org/wiki/Androgen_replacement_therapy)
    - So you’re talking 10, 12, 13x more than what we would consider physiologic level
- Derek adds, “*To conceptualize that, it does not equate to 12 to 13 x the results. That is something you learn pretty quick. There’s a severe diminishing returns as you escalate for sure, and you can even see this in the dose-response studies.*”
- This was his first taste of side effects, and that led him down the rabbit hole of:
  - Learning about the actual implication of using this stuff
  - Getting diagnosed with sleep apnea, getting a CPAP machine, correcting his sleep apnea
  - Then also realizing that was a bandaid to the problem too, that he probably shouldn’t be 260+ lbs and taking this stuff

**At this time, how sophisticated was your understanding of managing the side effects of these hormones?**

- Peter thinks this is a great into to the story of how he is learning the hard way
- His degree of sophistication was quite minimal
- Back then you were told to take X amount of drug; has to be a base of testosterone at this dosage relative to your other synthetic androgens that you’re using alongside it
  - This was based on arbitrary bro rules passed down the grapevine
  - For example, your ration of [test](https://en.wikipedia.org/wiki/Testosterone) to [deca](https://en.wikipedia.org/wiki/Dexamethasone) must be 2:1 or you’ll get “deca dick”
    - [Decadron](https://en.wikipedia.org/wiki/Dexamethasone) being a synthetic hormone
- [Nandrolone](https://en.wikipedia.org/wiki/Nandrolone) is a [progestin](https://en.wikipedia.org/wiki/Progestogen_(medication)) that is derived from testosterone, but it is quite different in how it behaves
  - Interestingly enough, it is the base for some of these synthetic progestins that women use for oral contraception
  - That compound is riddled with certain side effects for people who are prone to more the progesterone receptor interaction
  - And it has unique effects on cognitive health especially too, and even sleep quality
  - But back then he was told random things that were just passed down the grapevine based on no real science, it was just anecdote:
    - “*I tried it and this is how I felt, my penis worked or it didn’t work*”
    - Now it’s working, so this must be the correct way to do it
- There were also predetermined dosages of [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor), you have to be on a milligram of [Arimidex](https://en.wikipedia.org/wiki/Anastrozole) every day or every other day because you’re on 500 tests or more per week
  - Stuff like that was seen as acceptable and smart ‒ taking preventative health measures by doing things like that is what we thought back then
- Minor attention was paid to blood pressure
  - If you had a bloody nose in the squat rack, it was probably a sign that you should either lower the [D-Bol](https://en.wikipedia.org/wiki/Metandienone#:~:text=Metandienone%2C%20also%20known%20as%20methandienone,and%20effectiveness%20for%20bulking%20cycles.) or think about something
  - There was not much talk about [angiotensin receptor blockers](https://en.wikipedia.org/wiki/Angiotensin_II_receptor_blocker) or even how to choose a compound more intelligently
  - It was often said, “*You must have estrogen side effects or something.*”

## Derek’s experience acquiring steroids from underground labs and the potential long-term fertility concerns testosterone early in his bodybuilding career [12:00]

**What was your monthly cost of drugs at that point in time?**

- Anabolics are not that expensive, a vial of [tests](https://en.wikipedia.org/wiki/Testosterone) is $60-70

 Is *a vial of testosterone 2,000 mg (2 g)?*

- Usually underground labs dose it at 250 per mL which is interesting because in pharma it’s in 200 increments
- If it’s testosterone enanthate or testosterone cypionate, it’s almost always 250

**Tell me about underground labs**

- Peter notes that he’s not walking into the pharmacy and getting branded DEPO-Testosterone, which is the FDA-approved version of testosterone
- Literally, some buy orders raws from China and make them in what you hope to be a sterile and professional environment
  - But you have no idea if it’s his bathtub or what
  - The only motivation to do this is financial
  - Also, if he screws this up, people aren’t going to come back to him to buy the drug
- So when we talk about [GMP (good manufacturing practices)](https://en.wikipedia.org/wiki/Good_manufacturing_practice), which ensures sterility for injectable compounds, that is not the case here
- Recently Peter did a [podcast](https://peterattiamd.com/katherineeban/) on compounding pharmacies and the problems associated with them
  - Because they’re not subjected to the same GMP requirements, especially the community-based compounding pharmacies
  - They’ve had a number of awful incidents including one where literally [hundreds of people died from compounded solumedrol](https://www.ismp.org/resources/sterile-compounding-tragedy-symptom-broken-system-many-levels) because it was injected
    - Drugs were being manufactured without proper sterile technique, sent to hospital
    - This was all being done legally
    - Then the hospitals were using these to do [facet blocks](https://www.umms.org/rehab/health-services/pain-management/treatments/lumbar-facet-joint-block#:~:text=A%20lumbar%20facet%20joint%20block%20is%20an%20injection%20of%20local,how%20many%20joints%20are%20involved.) and things like that for people with back pain
    - Literally in one outbreak, more than 100 people died of [meningitis](https://en.wikipedia.org/wiki/Meningitis), a fungal meningitis due to this

> “*The stakes are very high when you’re talking about injectable compounds not being done sterilely*”‒ Peter Attia

**What the underground market looks like for these compounds**

- What they bank on is the fact people using synthetic anabolics don’t have acute health issues
  - It’s more chronic over a span of decades of abuse
- Worst case scenario, if you get a badly compounded version of whatever, you would have an elevated [CRP](https://en.wikipedia.org/wiki/C-reactive_protein) from the carrier oils or solvents
  - But most people weren’t even checking blood work
- And if you had a side effect, you assumed it’s the copious amounts of anabolics you’re on, not necessarily anything related to the manufacturing
  - As long as the reputation of the lab was maintained across the forums and the bros were happy, that meant this is high quality
- Some people would actually send it for third party testing
  - There were certain people who would come out with access to university labs and whatnot and under the table ‒ you would send a mL of your stuff in a perfume atomizer and they would test it for you and send you the HPLC results, and you would find out if the UGL (underground lab) has good stuff relative to what it says on the label
    - That was essentially it as far as quality control

**How many of the guys you were training with (and yourself) understood the impact on fertility and long-term effects on gonadal function?**

- Very few
- We were always told when you come off, you’ll restore fertility in due time
  - As long as you had good baseline function, and you weren’t primary hypogonadal to begin with
  - We were told, “*You just have to get the compound out of your system.*”
- No attention was paid to maintaining testicular volume, [Leydig cell](https://en.wikipedia.org/wiki/Leydig_cell) stimulation to maintain things, nothing
- It was just come off your stuff
- The PCT regimens (post cycle therapy) to restore fertility just made no sense when you look back on it
  - Back then it made sense, but now in hindsight the rule of thumb was literally stop your drugs, wait two weeks, start a PCT of [Nolvadex](https://en.wikipedia.org/wiki/Tamoxifen) plus [Clomid](https://en.wikipedia.org/wiki/Clomifene) for four weeks and you would recover fully
  - You just assume, you don’t actually check your blood work
  - Then after that, as long as you are healthy, the responsible thing is wait time on equals time off, and then you go time back on
    - But often it was just come off, two weeks PCT, and then get back on or wait until some arbitrary amount of time has passed regardless of health markers and then get back on

**What dose of Clomid were you guys taking in the PCT?**

- 50 mg once or twice a day
  - 25-50 mg twice a day
  - It wasn’t based on a anything scientific, you just choose
- Peter finds this to be high compared to what he would use clinically in traditional TRT (testosterone replacement therapy), “*Amazing doses*”

## The backstory on *More Plates, More Dates* and Derek’s unique ability to blend scientific knowledge with personal observation [17:00]

**What did you study in University?**

- Business at Simon Fraser University
- That was to lead him to a job as an accountant or something of that nature
- He was working as a bouncer downtown while he was getting his degree
- Then he transitioned into posting online, and he realized he could replace his income doing that rather than being a bouncer (which is not a sustainable income)
- He always felt that he should not be an accountant
  - It wasn’t something he found exciting; it’s not where his interest lies
  - He was okay with numbers
  - This path came from his high school thinking of what is a good business job ‒ go downtown Vancouver and get a job as an accountant at a big company and you’re good
- Fortunately he didn’t end up doing accounting
- He started making online content on a WordPress blog
  - It was actually on YouTube for a couple months
  - He started writing about dieting, how to bulk with not getting fat, how to cut
  - Basic stuff about diet principles, bodybuilding, talked about dating, social circle dynamics, stuff he was super interested in at the time
- It transitioned from there into discussion about his foray into anabolics, side effect management
  - Anything he could think of that was of use that he thought he could impart on the viewer, “*Hey, don’t screw yourself up. I’ve gone through this and learned the hard way*.”

**You’re in your early 20s and you’re at peak anabolic steroid use, are you using growth hormone as well?**

- He tried it periodically
- He didn’t notice a ton from it and it seems to be variable in how people respond
- Derek thinks a lot of it is conflated with the effects on fluid dynamics
  - A lot of people that get a lot of [edema](https://en.wikipedia.org/wiki/Edema) (water retention) that they perceive to be enhanced muscle, and then they say, “*Oh, my genetic ceiling is higher now*,” because of all the [satellite cell](https://en.wikipedia.org/wiki/Myosatellite_cell) proliferation and hyperplasia that’s happening
  - Or they think it makes them never get fat, which is something he would hear quite often, which is not true
- The most he used at a time is 6-8 IUs acutely (daily)
  - Peter remarks, “*That’s a huge dose*”
- It was for a span of 4 weeks, and he didn’t notice a lot from it
- He decided it wasn’t worthwhile to continue because it’s super cost prohibitive
  - That’s the thing that drives costs mostly for bodybuilders, not the anabolics
  - People have their budget for the anabolics and the food, but blood work goes out the window
- This paints a picture of Derek’s empirical curiosity in this topic
- Whenever Peter’s patients ask questions about growth hormone and the research team goes to look at answers, a lot of the times what we say both to the patients and what Peter has to remind the research team is: look, you’re going to get very limited, very narrow information from the literature
  - This is not like researching the question of what are the effects of physiologic hormone replacement of testosterone, estrogen, progesterone, things like that
    - For that we can turn to the literature and we can get a lot of information
  - But when you’re trying to ask the question, “*What happens when you take growth hormone outside of its medically intended purpose, such as low levels of growth hormone or things like that*”, Peter tells patients, “*You’re going to have to go into bodybuilding forums*.”
    - It’s not an appealing answer
    - It sounds like the most unscientific thing
    - But a bodybuilder with a good head on his/her shoulders will probably have more relevant observations about the good, the bad and the ugly with these compounds
- What Peter finds so interesting about Derek’s work is that he’s taken the best of both worlds
  - Derek has learned a lot through his own experience with these compounds, coupled with observing
  - He’s surrounded by a lot of bros who maybe don’t have Derek’s observational skills
  - He’s coupled that with his own obsession of going down the rabbit hole.

> “*And that’s why I think if anybody can extract meaning from some of this stuff, it’s you.*”‒ Peter Attia

## Growth hormone—from extreme use cases to the more typical—and the misconception that it’s the “elixir of life” [21:30]

- Peter thinks this is one topic for which we have the least insight, outside of a very narrow application of people who have growth hormone deficiencies and are replacing growth hormone (a good thing to do)
- This is a question that has been asked of Peter more than once, and the first time he was asked, he was shocked because it never occurred to him that someone would do this
  - But now he’s been asked enough times that he believes it’s a real thing

**Question Peter gets asked: “*****My son is 12 and he’s a very good athlete but I’m 5’ 9” and my wife is 5’ 5”, he’s not going to be an inch above 5’ 10”. Can we give him growth hormone to get him to be 6’ 1-2”?***

- Derek is not surprised that somebody would ask that; he’s heard much worse
- He doesn’t believe you could find any literature to suggest you’re going to surpass your genetic ceiling
- Some of the literature on idiopathic short stature is interesting, because they actually have prescription protocols that are even higher than [GH deficiency](https://en.wikipedia.org/wiki/Growth_hormone_deficiency)
  - So you have an unexplained lack of height velocity as you’re growing up, but not necessarily [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) deficiency or anything you can point to in the blood work that looks odd
    - And they are prescribed upper end range even higher than GH-deficient patients, which seems kind of odd
  - But for individuals who are not lagging behind significantly, there’s no indication for it, it’s kind of hard to justify
- Peter thinks the person asking just wanted to bounce the idea off of him, and that he would never have anything to do with this
- Peter told him that it seemed like a bad idea because you don’t know what the **risks** associated with it are
  - The risk of cancer and growth hormone in terms of propagation
  - Risks for bone health ‒ how do we know if these new elongated bones that your son is going to develop, that take him from being his natural or genetically predetermined 5’ 10” to 6’ 2”, how do we know if those bones are of the same caliber
    - And how do we know if we’re not setting him up for [osteopenia](https://en.wikipedia.org/wiki/Osteopenia) when he is 50 instead of a normal life?
  - Peter told the patient, “*Given all the unknowns, you just have to ask yourself the question, is it worth that risk?*”

**Derek notes how crazy some of the recent surgeries to enhance height in adults are**

- They put screws in their knees and then they basically increase their height by a millimeter every day
- And they crank it until they’ve got upwards of half a foot in extra height, and then that area just fills in with new bone
- They have to learn to function with these new mechanics

*How do you accommodate that from a muscle and tendon perspective?*

- That’s the question
- Proponents for it seem to assert that you eventually adjust to it with very intensive exercise routines, rehabilitation stuff, and you try and basically learn all your motor patterns again, and eventually everything adapts
- Derek would assume that your athletic capacity would be inhibited pretty dramatically
  - Permanently, potentially, and there’s huge risk there
  - But it just showcases how extreme some people are willing to go

**A more typical story: there is a belief that growth hormone is the elixir of life**

- There are longevity clinics out there whose sole intervention is giving you [growth hormone](https://en.wikipedia.org/wiki/Growth_hormone)
  - A bunch of supplements plus growth hormone
- If you look at the traditional medicine approach (what Peter calls medicine 2.0), the evidence-based medicine guidelines, those people would say, “*That’s the most dangerous, careless, unethical thing you could ever do. Those people are not doctors, shame on them*.”
- At the other end of the spectrum, you have people that embrace that point of view, which is the other people are idiots, this is modern medicine, this is the future
  - We should all be on growth hormone once we reach a certain age
- Peter finds himself on neither side of that, because he simply can’t come up with an evidence-based point of view

**Peter’s point of view**: given how many people are taking growth hormone (and it is quite ubiquitous, especially in sports), if there are really serious consequences to its use (even chronically), epidemiology would give us that answer

- It’s possible that there is a signal out there but no one’s looking
- It’s possible that not enough people take it for long enough
- There’s so many explanations for why this isn’t happening, but ***there isn’t a clear signal***
- Conversely, there are probably a lot of reasons why growth hormone given chronically, exogenously (especially if it’s super physiological) could be problematic
  - For example, if you have a tumor that is sensitive to growth hormone and it’s already initiated, are you propagating it?
    - That would be both sides of that

## Growth hormone 101: definition, where it comes from, and the challenges of measuring it [28:45]

**Tell people about what growth hormone is, where it comes from, what are the challenges of measuring it?**

- Most people know [growth hormone](https://en.wikipedia.org/wiki/Growth_hormone) as the primary hormone responsible for determining height as you grow in adolescence
- [Androgens](https://en.wikipedia.org/wiki/Androgen) are more for sexual differentiation, maturation
- Growth hormone and the subsequent growth factor production ([IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)) will be a fairly significant determinant of it you to target height
- It’s especially important during puberty for the proper development of your infrastructure, bone, etc.
- As you get into adulthood, it becomes one of those things where it drops significantly first off, as you reach adulthood and as you get older, it drops precipitously
- That kind of begs the question, *is this one of those things that you should be replacing to optimize function, fat loss, vitality, what have you?*

**Derek’s takeaway:** It’s tough because a lot of the proponents that assert such things have financial incentive, and it’s kind of hard to wade through the nonsense and figure out what is the truth here

- **HGH is often framed to be**: a fountain of youth elixir, it’s cost prohibitive, it’s what all the pro athletes are using, it’s the thing you need to be on to prevent any age-related decline in bone strength
  - Your ability to burn fats as you get older is going to go down, so you need to be on growth hormone, etc.
- At a bird’s eye view, it’s responsible for the broad spectrum growth of tissues as you grow up
- Then as you get into adulthood, it’s not irrelevant, but it’s far less important because you’re not trying to push a human from childhood into adulthood
- Even when you have this push of exogenous growth hormone to manually manipulate your levels after [epiphyseal plate](https://en.wikipedia.org/wiki/Epiphyseal_plate#) closure, there does not seem to be any benefit to be gained from enhancing the length of bones
  - For example, you could still enhance bone mineral density to some extent, and it seems to be you could enhance connective tissue integrity
  - It depends on what your situation is and how IGF-1 deficient you are, but it’s not going to impact your height in adulthood
  - It’s not going to really do anything other than regulate [lipolytic](https://en.wikipedia.org/wiki/Lipolysis) action

**How does it regulate lipolytic action?**

- Growth hormone (GH) liberates free fatty acids into circulation
- It’s seen as the opposing hormone to [insulin](https://en.wikipedia.org/wiki/Insulin)

*Does it do that through lipoprotein lipase? Is it actually acting on a substrate on the adipocyte?*

- It seems to be driven through different baseline states that you’re in
- For example, if you have [ghrelin](https://en.wikipedia.org/wiki/Ghrelin) receptor agonism from being fasted, a lot of people point to the literature on growth hormone going up if you’re deprived of calories
- There are different situations in which it’ll go up
  - Deep sleep obviously is super impactful on if you’re going to have GH release or not
  - The main actions that Derek is aware of in a state of growth hormone pulsation is the underpinnings are you were trying to liberate free fatty acids for utilization as substrate for energy or anti-catabolic action
- The actual mechanism, enzymatically and whatnot, is a bit fuzzy

**What’s the relationship then between GH and IGF in the liver?**

*We don’t measure GH in people because it’s pulsatile. So what are we stuck with as a proxy?*

- Even if you inject a large dose of GH, you will only see a spike in serum for a transient period of time
- People who are trying to assess the quality of their growth hormone with the underground stuff, they would be trying to time it very specifically down to the minute to assess the quality of their stuff
- The best proxy for GH production endogenously that seems to be widely accepted is IGF-1
  - Which is after you produce growth hormone from the pituitary, there is action in the liver, but also paracrine and autocrine action on muscle (especially if you are exercising, resistance training)
  - A lot of the serum IGF-1 is driven through liver production, and has its own implications in terms of its effects that seem to be more insulinogenic
- Peter responds, “*Which is counterintuitive, right? Because if IGF-1 has insulinogenic properties (which are promoting fat storage) and GH is promoting lipolysis, don’t those act at odds with each other? And how does one become more dominant?*”
- It’s this weird orchestrated feedback loop
  - These feedback loops are present in the body and multiple different hormone substrates will reduce in multiple different metabolites
  - You have [negative feedback](https://en.wikipedia.org/wiki/Negative_feedback) through different systems
  - ***Negative feedback will lower your production of GH while the IGF-1 is elevated***
    - And as it declines, you have this decrease in inhibitory feedback that then tells your body, okay, now the IGF-1 is not present in significant quantities, so it’s okay to release GH again
  - It’s a finely tuned balancing act in your body ‒ when one is high the other one is low to maintain balance in the body
- Peter notes, in medicine we have a real sense of how to dose testosterone (or estradiol in the case of [HRT](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) for women), because we know what physiologic normal levels are during various periods of a person’s life
  - If we replace testosterone to the level that we think is normal, we can measure the hormone, we know what we administered, and we can do the calculation to determine if the person has a lot of [sex hormone-binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) or whatever the case might be

**When people administer growth hormone, how do they know?**

- It depends largely on liver function too

***People with compromised liver function, or type 1 diabetes can have super high GH production but very low IGF-1 from a lack of insulin signaling***

- Insulin signaling has a positive relationship with IGF-1 production
- It can be difficult because you could have a person on a ketogenic, calorie-deprived diet who has an IGF-1 on the low end of the reference range, and they may be manually administering GH and using a higher dose than would otherwise be necessary to get “high normal optimal function”

***The best proxy we have for GH “optimal function” is the serum biomarker IGF-1, but there’s not really a cut and dry weight***

- Peter presumes people would use the [Z-score](https://en.wikipedia.org/wiki/Standard_score) of their IGF-1 as the output for determining how much GH to administer
- Derek’s understanding is that regardless of the problem (idiopathic short stature, GH deficiency, etc.) one would use IGF-1 as a metric to dial in the dose of GH
  - So if your IGF-1 is higher than the target, you would *dial back* the GH dose accordingly
  - Or if IGF-1 not high enough, you would *increase* the GH dose

**What did they target, a Z-score of 1 or 2?**

- Meaning, 1-2 standard deviations above the mean is therapeutic
- Or just being above zero, which means you’re above the 50th percentile
- Derek thinks the target is mainly just correcting to the middle or high end of the normal reference range (of a standard [LabCrop reference range](https://www.labcorp.com/tests/004275/growth-hormone))

**Peter’s summary so far**: you give GH and there’s a feedback signal because GH comes from the pituitary, but it’s spoken to by the hypothalamus

**What happens upstream of the pituitary?**

*What happens to the signal from the hypothalamus to the pituitary to make your own growth hormone when you take it from the outside? Does that get shut off as well?*

- Yeah
- It will give negative feedback
  - There is an elevation in [somatostatin](https://en.wikipedia.org/wiki/Somatostatin) that tells your body, “*Don’t make as much GH*”
- It gets a bit confusing as to how you produce the growth hormone upstream, there are different receptors
  - The [Ghrelin receptor](https://en.wikipedia.org/wiki/Growth_hormone_secretagogue_receptor), which is confusingly also called the GH receptor
  - The [GHRH receptor](https://en.wikipedia.org/wiki/Growth-hormone-releasing_hormone_receptor) and the production of [GHRH](https://en.wikipedia.org/wiki/Growth_hormone%E2%80%93releasing_hormone) endogenously as well as the agonism of ghrelin receptors, can both stimulate growth hormone
    - And the way by which they achieve your end output can be different, and that’s why there’s different drugs that target different receptors for actual elevation
    - Typically, GHRH drugs are coupled with GHRPs to get a 1 + 1 = 3 effect of sorts
    - But this is why also when you are fasted or malnourished, you could have significantly more output via the ghrelin receptor agonism

*This is the same ghrelin hormone that plays an important role in the management of hunger?*

- Yeah
- It’s pretty accepted that [leptin](https://en.wikipedia.org/wiki/Leptin) and [ghrelin](https://en.wikipedia.org/wiki/Ghrelin) are the signals of being full versus hungry
- So ghrelin and ghrelin receptor agonism would tell your brain that you’re hungry
- For example, if you gave somebody a really potent ghrelin receptor agonist (like [ibutamoren](https://en.wikipedia.org/wiki/Ibutamoren), which is a common orally bioavailable GHRP), even if you’re not hungry, you’ll want to eat your pantry (it’s insane)
  - So that compound plus a GHRH will seemingly have a downward pressure on somatostatin activity, and simultaneously, increase the output from the pituitary to produce more GH
- So you can essentially max out your endogenous production through these peptides

***The primary mechanisms involved in the production of GH are those three things: the ghrelin receptor, GHRH, and somatostatin as a negative feedback***

## Does exogenous use of growth hormone compromise one’s ability to make endogenous growth hormone? [40:00]

**If someone is just taking exogenous growth hormone (GH), how long would they need to take it before they would start to compromise their own ability to make endogenous growth hormone once they came off?**

- Derek thinks it would be pretty quick
- IGF-1 elevations in serum are not instant, and you would see spikes in a matter of minutes
  - It has a very short [half-life](https://en.wikipedia.org/wiki/Biological_half-life)
- But the downstream IGF-1 conversion can increase over days, and then stay elevated for days
  - And this is why IGF-1 as a biomarker has been asserted to be a potential way to catch people doping further out than the [hGH isoform differential immunoassay](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7748084/), which is the current accepted gold standard test that they use
  - Because IGF-1 will stay elevated for a relatively long period of time

**Let’s just say a person’s on GH for two years, and then they stop it. Does their pituitary go back to making GH?**

- Yeah, it seems pretty flexible in that
- Peter notes, “*In that sense, it’s different than LH and FSH, and the testes making testosterone.*”
- Yeah, Derek speculates it’s because there’s multiple actions of the pituitary, and it’s not going to atrophy in the same way
- People always want to know: *if I take anabolics or testosterone replacement for years, but I don’t take HCG (or I don’t take these fertility drugs), will I be able to restore fertility in short order?*
  - It seems to be a “use it or loose it” thing, where not necessarily, but it’s more difficult to restore fertility in somebody with severely atrophied organs that has not had stimulation directly for years versus the pituitary does multiple things
  - Derek can only imagine that the maintenance of output of other hormones and things are maintaining its flexibility to some extent

## The use of growth hormone in restoration of tissue during periods of healing [42:00]

- There’s some accepted medical use for GH in burn victims, for example
  - Recovering from a burn to a significant body surface area is one of the most [catabolic](https://en.wikipedia.org/wiki/Catabolism) activities a human can sustain, and therefore, the reversal of that is one of the most [anabolic](https://en.wikipedia.org/wiki/Anabolism) demands that a human can sustain as an adult

*What about during orthopedic injuries?*

- A person who’s having either elective or emergent surgery for an injury
- Peter has had patients who had injuries like a torn bicep
- He’s looked at the literature and found modest evidence (at best) suggesting that maybe for that person an eight-week course of anabolic steroids and growth hormone can aid in recuperation
  - The few times we’ve done this, we’ve seen great outcomes
    - But that means nothing, it’s anecdotal
    - We have no contrapositive (or opposite view) of what would’ve happened otherwise

**Do you have any insight, either from literature, or from just the underground world, as to what the use of modest amounts of growth hormone would look like in periods of rehabilitation?**

- It’s more anecdotal and unfortunately it’s not necessarily found in the literature
- It’s a mix of extrapolations, rodent studies and anecdotes in humans

***With that said, GH seems to be quite effective in rehabilitations and worthwhile in an acute time frame***

- But again, it’s not like you have a control of that same guy with the injury not taking it
- So we can only go by what you discern to be a reasonable recovery period
- Recovery with GH seems to be quicker than you would’ve expected

**Peter’s experience with shoulder surgery**

- About a year and a half ago, Peter had a shoulder operation he had been postponing for 15 years
  - He was hesitant because of the size of the tear in the labrum, but it got to the point where he had to have surgery
- It was going to be four months of recovery before he could do anything other than very light movements
- His plan was to take a cocktail of [nandrolone](https://en.wikipedia.org/wiki/Nandrolone) and growth hormone
- Derek finds it interesting that Peter didn’t use a base of testosterone with the nandrolone
  - Because you could effectively wipe out your estrogen with that combination
- Peter ended up taking this cocktail for a total of one week
  - His blood glucose went up
  - His blood pressure went up
  - His temperature was up at night
- In retrospect, he now thinks he was sick, and that he got an infection and that it didn’t’ have anything to do with the hormones
- He felt so bad on the hormones that he stopped taking them
  - So Peter is now the counterfactual, for not having done anything
  - Which means that he still knows nothing
- He finds this topic interesting and is frustrated that this question isn’t studied
- Peter understands that there isn’t a financial incentive to study this because it’s not a new drug
  - Recombinant GH has been around for over 40 years
  - It was cadaver-derived in the ‘80s and soon they went to recombinant
- It’s a shame because Peter has talked to many orthopedic surgeons who all say the same thing, “*I really wish we knew the answer to this question.*”

> “*It would really be wonderful to study this rigorously and know, could we make a difference in the outcomes of patients by using these things in a very narrow opportunity?*”‒ Peter Attia

- Circling back, Derek thinks there are certain things you can use to discern if GF is a better idea
  - Like baseline IGF-1
  - Are you on a ketogenic diet and you’re simultaneously trying to recover from an injury?
  - Are you calorie deprived
- There are certain things that could be significantly influencing your recovery capacity from a growth factor standpoint
  - You may be able to manually backfill that for another person
  - Some people naturally have IGFs that are at the top end of the reference range
  - Or if you had acromegaly, you would not use GH, obviously
  - Or if you had insulin resistance at baseline
  - So it’s definitely context dependent, if the ROI (return on investment) is worth it

**Do you have a sense of the use of growth hormone in** [**osteopenia**](https://en.wikipedia.org/wiki/Osteopenia) **or** [**osteoporosis**](https://en.wikipedia.org/wiki/Osteoporosis)**?**

- Let’s assume you’re going to do all the stuff you normally would do nutritionally with respect to vitamin D, calcium, amino acids
  - You’re going to increase load-bearing activity, particularly strength training
  - If necessary, you’re going to bring on [Fosamax](https://en.wikipedia.org/wiki/Alendronic_acid) and the types of drugs that may help

*Is there any evidence that GH administration will improve bone density?*

- Yes, Derek can say with almost near certainty that that [literature](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8884382/) exists
- Even if it didn’t, he thinks it would be worthwhile, especially in somebody with log IGF
- He’s have to circle back to the literature to make sure it was not rodent extrapolated
- There is the question: can anybody with lower IGF-1 sustain adequate bone integrity?
- Peter feels like the last time he looked, he didn’t find any literature that suggested not taking GH, but he didn’t find something that was a “slam dunk homerun” either

## Growth hormone-releasing peptides to increase endogenous GH: various peptides, risks, benefits, and comparison to exogenous growth hormone [48:45]

- The easiest way to segregate these is by GHRP (growth hormone-releasing peptide), GHRH (growth hormone-releasing hormone)
- [GHRP](https://en.wikipedia.org/wiki/GHRP-6) are the ones that act on [ghrelin receptor](https://en.wikipedia.org/wiki/Growth_hormone_secretagogue_receptor#)
- [GHRH](https://en.wikipedia.org/wiki/Growth_hormone%E2%80%93releasing_hormone) are the ones that look very similar to GHRH and act on that [receptor](https://en.wikipedia.org/wiki/Growth-hormone-releasing_hormone_receptor)
- From there, they’re pretty different in how they affect things
- For example, [ipamorelin](https://en.wikipedia.org/wiki/Ipamorelin) is often used in these anti-aging clinics and whatnot

**Are GHRP the ones that are also going to drive** [**hyperphagia**](https://en.wikipedia.org/wiki/Polyphagia)**?**

- This depends on the compound
- Even if you are stimulating the ghrelin receptor, the effects on appetite are quite different
- Take ipamorelin for example, despite the receptor it’s working through, and it is a ghrelin receptor agonist, it does not influence hunger to any reasonable magnitude within a striking distance of [MK-677 ibutamoren](https://en.wikipedia.org/wiki/Ibutamoren)
  - That difference is literally like you eating 2000 more calories a day, not by choice, but you’re just starving perpetually
  - It’s almost like it’s inducing [Prader-Willi syndrome](https://en.wikipedia.org/wiki/Prader%E2%80%93Willi_syndrome) or some condition where you have uncontrolled eating

**What’s the clinical use case for MK-677 ibutamoren?**

*Is that used in AIDS wasting, cancer wasting, and things like that?*

- It’s not FDA-approved, but it’s for GH-deficient children
- There is restoration of IGF to the top end of the reference range when using it
  - Going from maybe a low-end IGF to a 200-300
  - It’s not going to push you into super physiologic territory because it’s working through your endogenous capacity
  - But you can max out what your pituitary output potential is
  - Similar to a [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin#Anabolic_steroid_adjunct), you can manually stimulate natural production to the upper threshold of your capacity

*But it’s not going to have a high application among adults who don’t need an extra 2000 calories a day*

- No
- But it also depends on the context, because some people may have low appetite, and they want to gain weight
  - Or you’re in a state of recovery, and your appetite is suppressed from some other drug you’re using (that’s fairly common)

*What is the FDA approved indication for this drug?*

- It’s for GH-deficiency in adolescents
- Even though it’s prescribed among clinics, Derek doesn’t think it has achieved FDA approval yet (it’s in [Phase II or III](https://en.wikipedia.org/wiki/Phases_of_clinical_research))

**So how is this oral? How does this peptide survive the gastric environment?**

- Great question, but this is the only one Derek knows of that is often referred to as an efficacious option in this laundry list of GHRPs to restore IGF-1 to high-end normal
- In terms of the pharmacokinetic profile, all he knows is the half life is 24-36 hours
  - It’s not hepatotoxic

**Any other GHRPs (growth hormone-releasing peptides) that are worth discussing?**

- [Ipamorelin](https://en.wikipedia.org/wiki/Ipamorelin) is probably the one most prescribed in clinics, and that one seems to be more targeted in the outcomes you’d want to see out of a growth hormone releasing peptide
  - In that you get enhancement of sleep
  - It doesn’t make you hungry really, even though it operates for the same receptor pathway
  - It definitely increases IGF-1
- Derek thinks it might be FDA-approved for [lipodystrophy](https://en.wikipedia.org/wiki/Lipodystrophy), as might be [tesamorelin](https://en.wikipedia.org/wiki/Tesamorelin)
- Ipamorelin is the primary one that is prescribed
  - It’s a daily injectable used by athletes and bodybuilders
- Then there’s a bunch, like [GHRP-6](https://en.wikipedia.org/wiki/GHRP-6) and [GHRP-2](https://en.wikipedia.org/wiki/Pralmorelin) which significantly impactful in hunger
  - GHRP-6, probably the worst one, and that’s the one to take if you had an eating contest to win or if you’re a bodybuilder who can’t eat 5,000 calories a day

*Is Ipamorelin cheaper than growth hormone?*

- Yes, but there are generic growth hormone preparations that are pretty cheap now
  - You could get 100 IUs of pretty high quality [hGH](https://en.wikipedia.org/wiki/Growth_hormone) from China for $150
    - By comparison, that would cost thousands at a pharmacy

**On the GHRH side, who are the big players?**

- [Tesamorelin](https://en.wikipedia.org/wiki/Tesamorelin) and [sermorelin](https://en.wikipedia.org/wiki/Sermorelin)
- Tesamorelin is more common
- It seems that people just don’t get the results they want out of sermorelin
  - This is for anecdote than any kind of literature that points to it being sub-efficacious
- Tesamorelin plus [ipamorelin](https://en.wikipedia.org/wiki/Ipamorelin) is kind of the primary combo utilized in clinics
- There’s also [CJC-1295](https://en.wikipedia.org/wiki/CJC-1295) (drug affinity complex:growth hormone-releasing factor), which basically extends the half-life significantly
  - There’s a shorter version of it, [GRF 1-29](https://en.wikipedia.org/wiki/Sermorelin)

**These are literally the wild west of compounds. Are sermorelin and tesamorelin FDA-approved?**

- Some of them are FDA-approved, and one is approved for lipodystrophy and there are some other unique applications in which some have FDA approval
  - Most of them do not have FDA approval
- GHRP-6, GHRP-2, hexarelin, and a couple of the GHRHs on that list do not have FDA approval
- MK-677, as far as Derek know, is prescribed off-label
  - There’s no company making a branded FDA-approved version of it, but compounding pharmacies will still make it
  - There are a lot of question as to the standards that go into making it
    - Are you just ordering it from China, similarly to an underground lab?
    - There are no standards
    - That’s the whole point of a compounding, they can make anything
    - If something has a GRAS designation (generally regarded as safe by the FDA), you can sell it on Amazon; it’s over the counter

**What’s the most potent GRAS thing out there?**

- Peter thinks it’s probably [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone)
  - In other countries it’s appropriately treated as a hormone
  - Derek thinks it’s [schedule I](https://en.wikipedia.org/wiki/Controlled_Substances_Act#Schedule_I) in Canada
    - Actual steroids are not as regulated
  - But in the US, amazingly DHEA is over the counter, so that means it has a GRAS designation
- Peter guesses that [CJC-1295](https://en.wikipedia.org/wiki/CJC-1295) does not have a GRAS designation
  - So that means, you cannot sell it without a prescription
  - Yet it doesn’t have an IND
    - It’s not an investigational new drug; it hasn’t gone down the pathway of an approval
    - It’s just sort of in this gray area
- Some of them are drugs that were in a pipeline but were abandoned
  - Sometimes it’s financial
  - Sometimes it’s a lack of efficacy
- There was a drug called [cardarine](https://en.wikipedia.org/wiki/GW501516), it’s a PPARδ agonist which actually got good results on lipid management
  - Like one of those exercise mimetic drugs
  - The metrics look great but then there is some rodent study showing cancer
  - It was canceled after it was in Phase II in humans due to publicity and public outcry of worry about this rodent study
  - Cardarine is prescribed through clinics too
  - Peter asked, “*Did all the rodents who took it get cancer?*”
    - Yeah, every dose
    - Peter finds that disconcerting

**Through the lens of a patient**

- Peter has one patient who came to him having been prescribed [sermorelin](https://en.wikipedia.org/wiki/Sermorelin) from the outside
  - Peter asked him to stop because he wasn’t going to take over a prescription that he didn’t know anything about, and the patient did
- A year later, the patient asked to go back on it saying, “*It just gave me such a feeling of vitality*.”
- Peter wanted to think through the risks and benefits of this
  - After negotiating this back and forth for six months he told the patient if he would do a bunch of really good cancer screening to be convinced that he doesn’t have cancer
    - A [Prenuvo scan](https://prenuvo.com/prenuvo-scans/)
    - A [Galleri blood test](https://www.galleri.com/)
    - A [colonoscopy](https://en.wikipedia.org/wiki/Colonoscopy)
  - After determining to the level of detection with our modern technology that he didn’t have cancer at the moment, Peter found a great endocrinologist who prescribed it to him, and he’s as happy as can be

**Would you want to be on sermorelin or tesamorelin versus growth hormone?**

- Peter can’t make sense of it
- He never understood where you would start to stack both compounds

*Do you get a sense that hitting both targets (both receptors) is better than just using GH?*

***One thing you could say for certain, is when you push endogenous production, you are fulfilling the full production of all spectrum of variants***

- There are different kilodalton isoforms of hGH
  - These variable molecular weight growth hormone outputs that you get from the pituitary
  - They get detected in doping
  - We don’t know why they are put out in different formats
  - For all we know, they have different actions in the body that may not be facilitated by the recombinant straight like 22

**When you take a recombinant hGH, you are essentially telling your brain, “*****Don’t make more*****”**

- So you are actually losing the production of those other variants, and you are relying entirely on this one
  - What are the implications of that, from a health perspective or a performance?
- Obviously, we can manually push your IGF to super physiologic, which you will not be able to do with the endogenous kind of up regulators of sorts with the peptides, and you can manually choose where you go with it
- There’s certainly a case to be made, just like with testosterone: *why would you use a GNRH agonist when you could just take the straight hormone and manually pick where you land?*
  - Or why would you use a SARM?
  - Or why would you use an aromatase inhibitor, or what have you, and modulate these upstream pathways?
  - And oftentimes, that could be the reasonable answer, especially for somebody who wants a very targeted end goal, and knows exactly where they want to land on their IGF
  - Or potentially has worse output relative to the input of those peptides
    - Because again, it’s working off your natural capacity

**Potential pros and cons to taking recombinant hGH**

- If you have a good functioning entire hypothalamus pituitary, and all the output is satisfactory from an infrastructure standpoint to produce natural hormones at an adequate level
  - The natural peptides may be useful
  - And you know you’re getting all the variants of all the kilodalton molecular mass variants
- But with exogenous, you know exactly what you’re getting
  - You can manually choose what you’re getting out of it
  - It could be more reserved for people who don’t have the natural output that they are trying to get out of the peptides
    - People that don’t respond that well
  - Also, there’s just more data on this

**Peter’s analogy**: taking exogenous common growth hormone is like taking testosterone, whereas, taking peptides is like taking [Clomid](https://en.wikipedia.org/wiki/Clomifene#Testosterone_replacement_therapy)

- Derek agrees with the exception that you’re not blocking negative feedback, you’re positively modulating it
  - Correct, Clomid works by creating a block some of the time
  - It would probably be analogous to an [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) and recombinant [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone), or more like a [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin), or combined [HMG](https://en.wikipedia.org/wiki/Menotropin) or something

## The role of growth hormone in building muscle and burning fat, and its effects on sleep and daytime lethargy [1:02:30]

**What does the literature say, and what does the non-literature say about the role of GH alone (not in combination with anabolics) in terms of its capacity to help build muscle and oxidize fat?**

- The literature is so sparse; there are very few studies that show a clear enhancement of athletic performance
- The literature is clean on the effects of GH on body recomposition:
  - You gain lean mass
  - Part of that presumably is water retention
  - You lose fat mass
  - For lipodystrophy, you’re able to improve your utilization of free fatty acids
  - When it comes to protein synthesis and muscle accrual, it’s very wishy-washy

> “*From a muscle growth and athletic performance perspective, the jury is out, in terms of if it does anything significant enough to justify its use.*”‒ Derek

- Bodybuilders will claim to high heaven that it’s useful and they notice huge changes
  - Some think it’s an expensive fat burners
  - It very much depends on your response
- From a fluid dynamics perspective, it can definitely increase sodium retention and things that you may interpret as muscle growth
  - That may just be volume
  - With that said, at the end of the day, how much of the muscle is water?
  - From a cosmetic perspective, it certainly looks good on a bodybuilding stage
- Peter points out that the muscle might not have the function, and Derek agrees that you may not get enhanced force production outcomes like you would from a true anabolic agent
- Almost certainly it can help you improve your body composition, especially if you time it well
  - If you just use it and liberate free fatty acids, then sit around and do nothing, you could just redistribute the fat and not necessarily get the benefit you’re seeking

**Do you think that the liberation of fat is the more reproducible finding of GH use?**

- Oh, yeah
- And you’ll become acutely insulin resistant as a result of that too

**Based on that knowledge, when is the ideal time to take it? Do people take this once a day, twice a day?**

- It depends on the dose
- Because if you’re using a very high dose
- It also depends on your **lethargy** from it, it is very lethargy inducing
  - You could feel sleepy all day if you’re blasting a high dose of it
- When Derek took it, it was mostly in the 2-4 IU range
  - He only did 6-8 IU for a very short period of time
  - Even the lower level pushed him to a 500 IGF and was lethargy inducing
  - He tried it for full durations of cycles, so upwards of a few month was the longest he took it
  - He felt lethargy pretty much around the clock

**Why does GH induce a feeling of lethargy?**

- GH seems to have a very intertwined connection with sleep
- You have your biggest GH pulse when you’re getting to sleep
- People find that with aging, you have a decrease in IGF
  - Deep sleep metrics also decrease precipitously too
- Derek thinks its impact on sleep is the biggest case to be made on potential attenuation of cognitive decline
- If you have a crashed IGF and you have horrible sleep as a result of it
  - There’s clear literature to show that IGF deficiency will impair sleep
  - So if you’re able to correct that to some level, with the minimum effective dose, you don’t need to push it

**You were saying that a higher IGF dose made you more lethargic. Based on that argument, you would think that you’d be sleeping better, right?**

- Yeah, probably
- It also gets conflated with bodybuilding diets too, because typically when you’re using it, you’re in a calorie surplus trying to gain a bunch of muscles
- And it is anecdotal, but in general, people using peptides even, and growth hormone, will often find that their sleep is seemingly enhanced
  - Like it’s deeper, more restful
  - And yet, they’re more lethargic during the day

**Is it possible that GH is inducing too long a sleep? Like there’s a hangover of sleep?**

- Potentially
- It seems to be a hormone that is quite rejuvenative during your sleep, and it’s like the time you are trying to recover and rest the deepest, having the highest spike of GH
- It’s an interesting anecdote why you might be tired when the deepest point of rest is also the time that GH is simultaneously at its highest endogenous level

**Thoughts on GH dosing**

- In Derek’s opinion, logic would dictate that you would take part of your ***dose before bed***, given that you’re not going to get the same output when you’re using exogenous GH
  - So if you’re taking all of your GH in the morning, then exercise and try to use the fat (which is not a bad idea)
  - There is a justification when your IGF-1 or GH output is suppressed, that you would allocate your dose to pre-bed
  - It depends on the goal and if you notice an enhancement of sleep or not
- But you can say without a shadow of a doubt: ***that feedback loop will suppress your natural output***
- You’re not going to just get the best of both worlds

**Is it more common today that people use the two peptide receptor approach, rather than GH?**

- Yes, in the clinics for sure, because it’s less cost prohibitive
- In the underground bodybuilding world, they’re typically pushing super physiological IGF-1 levels (that’s their goal)
  - So, they typically try to find pharma grade GH, and if they can’t get it (or afford it), they will go generic

**They’re pushing IGF to 500 and more**

- Yeah, typically that would be a minimum for “performance enhancement”
- This is higher than what is naturally achievable based on a typical lab corp reference range

**Human literature on acromegaly reveals a downside to chronic elevation of IGF**

- One thing that is interesting on GH, even in [acromegalic patients](https://en.wikipedia.org/wiki/Acromegaly), the incidence of death seems to be more from cardiovascular incidents than from cancer
  - So, if there’s anything to discern from actual human literature: ***significantly chronically elevated IGFs into even 40 years old, these individuals are dying from congestive heart failure and things like that***
  - Peter thinks this is a good point and wants to looks at the acromegaly literature
- It’s interesting how much fluid retention they hold, and the stress that has on the heart
- Peter guesses they may be more prone to aortic dissection because they probably have larger connective tissue and things like that

## The evolution of drug use in the sport of bodybuilding [1:10:30]

- Peter has a lot of pictures of bodybuilders in his gym (nice black and whites), and there’s  real clear difference between [Frank Zane](https://frankzane.com/), [Arnold Schwartzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger), [Sergio Oliva](https://en.wikipedia.org/wiki/Sergio_Oliva) to [Jay Cutler](https://en.wikipedia.org/wiki/Jay_Cutler_(bodybuilder)) and [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman)
  - He doesn’t know when that jump took place, maybe [Lee Haney](https://en.wikipedia.org/wiki/Lee_Haney), maybe [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates)
  - But somewhere in there there was a real transition in physique
- If you think of the things that can impact your physique:
  - Genetics? Okay, that’s not changing
  - Nutrition and knowledge of nutrition? That’s clearly evolved
  - Training and knowledge of training? That’s clearly evolved
  - Drug use? That’s clearly evolved
  - Maybe just even injection? Peter has talked to bodybuilders today who say that they’re actually injecting compounds in their muscles to alter the shape
    - They’re injecting fats into muscles to actually create some sculpting
    - That’s probably something new
    - Let’s put that one aside

**Of the three (evolution of training, nutrition, and drugs), how would you rate the relative balance of those three for the difference of a 1970s physique versus a physique today of the best bodybuilders in the world?**

- Drugs almost certainly at the top, followed by nutrition, then training at the bottom

*How much emphasis is put on each of those? 50, 40, 10?*

- That’s tough because these get scrutinized to hell
- A lot of these things don’t live without the other
  - You could definitely say that if you eat nothing, the drugs aren’t going to do anything
- In Derek’s opinion, if you did perfect diet, perfect training with all of the modern knowledge that we have now, your ceiling for muscle growth potential could be as much as 50-100 lbs *lower* as a natural bodybuilder
  - Depending on height, depending on genetic response

**Drug use in bodybuilders**

- Peter has spoken to ‘70s bodybuilders, and he was shocked at how little drug use was going on back then among the best of the best
  - 100-200 mg testosterone a week, 8 weeks at a time (8 weeks on, and 8 weeks off)
  - In other words, they’re basically taking [TRT](https://en.wikipedia.org/wiki/Androgen_replacement_therapy)
- Derek thinks they’re not telling the truth
  - When you’re saying you’re taking a borderline female HRT dianabol dose
    - Back then that’s what it was prescribed for, or muscle wasting in old age or whatever
  - Those dosages are almost impossible to wrap your head around producing outcomes, and you might as well have stayed natural at that point
- Derek too, bought into the idea that they seem to have consistent stories
  - They seem to have all taken one shot of [primo](https://en.wikipedia.org/wiki/Metenolone_acetate) a week and 1-2 [dianabol](https://en.wikipedia.org/wiki/Metandienone#:~:text=Metandienone%2C%20also%20known%20as%20methandienone,and%20effectiveness%20for%20bulking%20cycles.)
  - It’s just not an outcome that you see as reproducible (ever) in those dosage quantities
    - Maybe on the hyper extreme outlier scenario, you might have a guy for whom a total weekly dosage of a few hundred milligrams across everything he is using, he may hyper respond and get huge
- Derek would say the majority of the guys competing at the Olympia level were still [dosing]
  - He’s heard of people slugging [D-Bol](https://en.wikipedia.org/wiki/Metandienone#:~:text=Metandienone%2C%20also%20known%20as%20methandienone,and%20effectiveness%20for%20bulking%20cycles.) by the bottles, even in the ‘70s
  - It’s just certain people are more outspoken about their abuse than others
- There’s this guy, [Pete Grymkowski](https://www.builtreport.com/pete-grymkowski-gallery/)
  - He looked incredible, but the guy used thousands and thousands and thousands of milligrams
  - Derek can understand why you would arrive at that logic to take that because there was nothing to tell you otherwise
    - If you’re competing against the guy at the highest level, and there’s relatively high stakes
    - You see a guy like Arnold getting movie roles and stuff, it was the peak of achievements as a bodybuilder back then
    - You couldn’t do social media, you couldn’t do anything
    - You would try and emulate what he was doing

**Derek’s takeaway**: “T*o think that you’re not going to escalate your dose past 1-2* [*dianabol*](https://en.wikipedia.org/wiki/Metandienone#:~:text=Metandienone%2C%20also%20known%20as%20methandienone,and%20effectiveness%20for%20bulking%20cycles.) *and a shot of* [*primo*](https://en.wikipedia.org/wiki/Metenolone_acetate) *or what have you, or a shot* [*Nandrolone*](https://en.wikipedia.org/wiki/Nandrolone) *because you didn’t want to hurt yourself? Shut up, dude*.”

- Peter feels like he saw a video recently of [Tom Platz](https://www.greatestphysiques.com/male-physiques/tom-platz/) discussing this
- Derek remarks that Tom has changed his story
  - His original breakdown was relatively conservative, he did public presentations about drug use back in the ‘80s and ‘90s, and you could tell he was picking his words carefully as he spoke
  - More recently, he came out and said his dose was a third of that
    - After 40 years, Derek doesn’t expect him to remember exactly what he took, but to say your peak dose was ⅓ of what it was is not believable
- At the other end of the spectrum, Peter has spoken to one bodybuilder and he couldn’t believe how much he was taking: 50 g of testosterone a week
- Derek’s response, “*There’s no way. You would not inject that much.*”
  - You would have to dedicate your life to injecting, putting in 5-10 cc barrels of testosterone all day
  - Peter wondered how it was possible too
- Derek thinks a lot of people just don’t know what they are taking
  - A lot of people say their doctor told them to take this much by syringe, and they just remember some rough number
  - Oftentimes, they don’t know how many mg/mL they’re using
- Peter has patients take between 100-120 mg a week
  - He fine-tunes that by 20 mg a week

**Given how remarkable the physiques were in the ’70s at the top of the food chain in the Olympia, would you agree with me that something dramatically changed in the late ’80s, early ’90s?**

- Yeah, and it seems to be the emergence of growth hormone and insulin abuse
  - As well as the escalation of drugs to an even more extreme magnitude
  - And the availability, potentially
- Granted, they were prescribed readily, but people also seemingly pushed the limit more
- And there’s the emergence of underground lab preparations and things of this nature

***From Derek’s understanding (and there’s no literature to document this), there seems to have been a dose escalation of anabolics more so than the implementation of growth hormone coupled with exogenous insulin use***

**They’re using insulin because of how anabolic it is?**

- What they believe it’s doing is shuttling a super physiologic amount of nutrients into the muscle
  - Because also when you take GH, you are acutely insulin-resistant
- They’re almost doing both things at the same time as the goal
- Often, when you’re using really high doses of GH, you could induce [diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)
  - Fortunately, this isn’t as problematic in replacement dosages, and Derek doesn’t want people to extrapolate out, “*Oh, GH equals chronic insulin resistance*,” necessarily
  - And oftentimes to relieve stress off the pancreas and the beta cells, they’ll use exogenous insulin so you don’t have to produce as much endogenously to actually accommodate the amount of carbohydrate intake (and overall nutrient intake)
    - These diets, to maintain a 300 pound physique: you’re pounding 5,000 calories a day sometimes
- Derek adds, “*It’s funny because right as we finish talking about how it’s not performance enhancing, now the thing that causes the 20 to 30 pound lean mass jump is supposedly GH and insulin. It’s interesting to say the least*.”

## What explains the protruding abdomens on some bodybuilders and athletes? [1:20:30]

- Peter used to believe that all this GH and insulin use is why we’re seeing these big abdomens on not just bodybuilders, but also on athletes
  - You’ll see track and field athletes who are insanely muscular, insanely lean, but they have huge protruding abdomens that do not appear to be fat because you still see a six-pack ripped on top of it
  - But from the side, they look pregnant
- Peter wonders, “*Is this just organomegaly? Are their organs just getting bigger?*”

**Derek has talked a little bit about an alternative hypothesis**

- Derek thinks it’s multifactorial
- 1 – The largest cause is significant distension caused by excessive food intake and the result of significant gastrointestinal issues that result from the absurd diet models
  - Because to get that many calories in, get that much protein, carbs often, and especially peri-workout when you’re using insulin and you need to make sure you don’t go hypoglycemic in your workout, they’ll be slamming 100-200 gram shakes that have hydrolyzed whey, branched cyclic dextrin, plus amino, plus creatine, plus glutamine, plus this
  - You’ve probably had a cheat day where your stomach was incomparable to days when you’re fasting ‒ it’s a massive difference
  - When you have a giant cheat day and just go off the rails, you couldn’t keep your stomach in for the life of you
    - You have to be flexing just to keep it from not looking like you have a gut when you’re sitting down
    - That is a perpetual state of reality for bodybuilders who weigh that much; to sustain that food intake and the physiques that they have because it’s not a normal amount of muscle to hold
    - It requires a not normal amount of food to accommodate the nutrients required to grow further or even sustain it
- A good example of that is [Ben Pakulski](https://www.greatestphysiques.com/male-physiques/ben-pakulski/)
  - He makes more health focused content now, but he’s a former high level IFPB pro
  - He placed second in the Arnold Classic at one point, and one of his biggest criticisms was his distended gut
  - You know for certain, the guy was using all the same drugs everyone was using at the high level
  - But he was able to reverse it [his distended gut], seemingly, in a relatively short period of time in his latter part of his career by reducing his food intake significantly
  - And he actually showed up one year later with a vacuum on stage
    - For people who don’t know: you suck your stomach in, and it it goes in (almost inverted), and you can see your rib cage and your serratus lines and stuff

**And most bodybuilders wouldn’t be able to do that nowadays?**

- No, no
- That’s a big notable differentiating factor of ’70s and ’90s bodybuilders, the amount of people that could do a vacuum dramatically
  - So many could in the ’70s, and it looked great
  - In the ’90s, you’d be hard-pressed to find somebody who has an aesthetic vacuum

**Would natural bodybuilders be more likely to?**

- Yeah
- They don’t have the food demand
- It also depends on what they’re eating because people with gut issues could have issues, too

***The distended gut is more common in people who are pushing food extremely hard, and then the drugs on top of that***

- When you have [hyperglycemia](https://en.wikipedia.org/wiki/Hyperglycemia) chronically, you might have impaired intestinal motility and all these things that could compound the issue significantly
- Derek thinks you have people with [SIBO (small intestine bacterial overgrowth)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3099351/#:~:text=Small%20intestinal%20bacterial%20overgrowth%20(SIBO)%20is%20defined%20as%20the%20presence,%2C%20nutritional%20deficiencies%2C%20and%20osteoporosis.) and all this stuff that can influence the distension that is like a congregation of bad digestion, insane amounts of food, poor choices of food that don’t agree with your body
  - Because it’s simply the only way you can get the calories in to meet the demand of the muscle, etc.
- Ben Pakulski showed up with less muscle, but he had completely reversed his gut distension
  - So, it seemed as if the food was a large dictator of: to get the biggest physique he ever got, you had to eat some diet that was not conducive to the most aesthetic nondistended appearance
  - And if he had organ growth, is it reasonable to assume that he reversed that
- This is another example of something that is frustrating to Peter ‒ this is knowable
  - Take the bodybuilders, throw them into a MRI scanner and you can get organ volumes on everybody
  - Compare that to controls
  - Also look at them off drugs and on drugs
  - It’s another example of so many of the questions that we have here that we’re not getting resolution to that are knowable
- Derek adds that you can learn things from autopsies of bodybuilders that died young
  - Sometimes now with social media, those are released publicly
  - 10 years ago, people were saying, “*Where are the bodies? No one’s dying from steroid use.*”
  - But there are guys dying with hearts three times the size of what they should be
    - So, there’s certainly organ enlargement systemically, for sure
    - We don’t know if it’s pushing on the stomach wall to cause a distended gut

## Death of bodybuilders [1:26:00]

**Who was the bodybuilder that died recently?**

- [Jo Lindner](https://barbend.com/joesthetics-jo-lindner-obituary/) ‒ he was 30-years-old and one of the biggest social media influencers, too
  - He was German
- With him, the scariest part was he was one of the guys who was doing all the right things, at least from a blood work standpoint
  - He would get blood work done literally every two months, if not more frequently, and was very, very rigorous about trying to oversee his health status in his blood work
  - He certainly wasn’t somebody who should be dying at 30 years old
    - Regardless of back in the day (or even not that long ago), it would be unheard of for somebody to be dying
- He wasn’t a massive bodybuilder by industry standards for fitness where we have this warped perception of what is big versus not
  - He was probably 50 pounds off of what you would consider a top level open class bodybuilder who would compete with [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman) or something
  - He was more of a jacked fitness model by fitness industry standards
- He had significantly less drug use, less food intake
  - He was always in a calorie deficit, shredded year round
- The guy did lots of cardio
  - At least like 10,000 plus steps a day
- He ate clean
- There was no reason, objectively at least, why he should die at 30

**What are the known circumstances of his death?**

- Apparently, he got the vaccine and two boosters on top of it
  - It might have even been more
- After he got it done, he got his blood work done just routinely, and they saw (supposedly) that the blood they pulled out was really coagulated and weird looking
  - Derek forgets exactly his terminology, but he literally did a [podcast](https://youtu.be/Aly-7QpL5NQ?si=bwAQVXQLTlvGRHd9) maybe a week or two before his death about how he got a blood test done and they were telling him that he needs to get a [plasmapheresis](https://en.wikipedia.org/wiki/Plasmapheresis) to clean his blood because it was so messed up from the vax
  - So, he did it twice, apparently, and then supposedly his [D-dimer](https://en.wikipedia.org/wiki/D-dimer) went back down (because it was super elevated in his blood work), and they said he was fine
- He made a trip to the US and Derek got to meet him for the first time a couple of weeks before his death
- Then he flew back to Thailand, which is a really long flight and there’s clotting risks associated with that on top of all the other things
  - This is speculated to be another variable
  - But he got back seemingly fine
- A few days after he got back, he was complaining of neck pain
  - His aunt supposedly died from an [aneurysm](https://en.wikipedia.org/wiki/Aneurysm) in her neck, according to his girlfriend
    - Which is unusual

***We have yet to see an autopsy report on his situation***

- Peter wouldn’t even speculate without an autopsy, and it’s not difficult to know if someone died of an aneurysm on autopsy
- Derek asks, “*Would you scope that out with a* [*Prenuvo scan*](https://prenuvo.com/prenuvo-scans/) *before you even*”
- Yeah, that’s actually one of the reasons Peter really likes whole body MRI, the incidence of aneurysms you’ll see on a whole body MRI is about 1-7 per 1,000, depending on the series
  - Now, not all of those are aneurysms that pose risk
  - Meaning, they’re not all aneurysms that, if left alone, would ultimately rupture
  - But a number of those require intervention.
  - In the last seven years, Peter has had two patients
    - If you think about how small his practice is, two patients who have had incidental captures of aneurysms that were in one case, large enough and in another case, growing quickly enough to a large enough size that they needed to be coiled preventatively
- The aneurysms that typically kill people are in the head or behind the stomach
- As far as if he had a deep vein thrombosis although the literature suggests that it’s not necessarily helpful against [deep vein thrombosis](https://en.wikipedia.org/wiki/Deep_vein_thrombosis), which would certainly be a risk factor on a long flight, that could obviously kill you with a [pulmonary embolism](https://en.wikipedia.org/wiki/Pulmonary_embolism)
  - Again, very easy to diagnose on autopsy

**Derek asks, “*****What’s your current flight stack?*****”**

- Peter doesn’t fly that much anymore
- When he does, most of his stack is around sleep
- He’s thinking about how to eliminate jet lag
  - He went to London a few months ago

*You don’t control for clotting potential anymore?*

- Peter takes a baby aspirin, although the literature suggests that it’s not necessarily helpful against [DVT](https://en.wikipedia.org/wiki/Deep_vein_thrombosis)
- He used to take [nattokinase](https://en.wikipedia.org/wiki/Nattokinase), but nowadays, he just uses [compression hose](https://en.wikipedia.org/wiki/Compression_stockings) and hydrates like crazy
  - Most of the flights, he laying down and has straight legs
- He thinks hydration probably plays a greater role than most things
- He used to be ridiculous, at one point he was taking [Lovenox](https://en.wikipedia.org/wiki/Enoxaparin_sodium) injection
  - Lovenox is an unfractionated type of [heparin](https://en.wikipedia.org/wiki/Heparin)
  - But after taking it one time where he injected it and hit a blood vessel and had the biggest bruise on his head, he decided it wasn’t worth the hassle anymore
- His efforts have really focused on how not to get jet lag, and he can go to an eight hour time zone away and be 100% functional the minute he gets off the plane
  - Get right into routine and rhythm

**Back to deaths of bodybuilders**

- In terms of traditional bodybuilder deaths, Jo Lindner’s is unique, but no one really knows until the autopsy comes out
- It might be that this is just a tragic death in someone who also happens to be a bodybuilder, and that has nothing to do with it
- From the autopsy reports Derek has seen on young bodybuilders, it’s almost always a **cardiovascular issue**
  - Not necessarily atherosclerotic, but more cardiomyopathy type deaths
  - Blood pressure left unchecked that essentially destroys heart function
  - Hearts way larger than they should be
- [Rich Piana](https://en.wikipedia.org/wiki/Rich_Piana) was a very famous and influential bodybuilder in the fitness industry, and he died in his 40s with what Derek thinks was  a 660 gram heart
- [Dallas McCarver](https://www.mensxp.com/health/body-building/42888-dallas-mccarver-s-autopsy-report-is-out-it-will-give-steroid-abusers-a-horrifying-nightmare.html) is probably the most notable one
  - He was a mass monster by IFBB Pro standards, which is one of the guys on the Olympia stage who’s actually the biggest of the guys on that stage
  - His heart was 860 grams or something
    - An athlete’s heart is ⅓ of that or something
- [Mike Menser](https://en.wikipedia.org/wiki/Mike_Mentzer#) died young [at age 50], he had known atherosclerosis
  - Derek has heard that he was pretty into amphetamines on top of anabolics
- Difficult things to ascertain with respect to bodybuilding is that there’s so much polypharmacy, and there’s the psychological component that’s difficult to disentangle

## The complex interplay of hormones, and the conversion of testosterone into metabolites like DHT and estrogen [1:33:45]

**A quick review of the relationship between the hypothalamus, the pituitary, Leydig cells, Sertoli cells**

*What’s the relationship between those hormones, testosterone production, and maybe we can even talk about DHT androgen receptors and estradiol for that matter*

- The body has a complicated, but well-regulated way to know how much hormone to produce based on needs in the tissues
- Your hypothalamus will create something called [gonadotropin releasing hormone (GnRH)](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone)
  - Just like the name suggests, this is the hormone that goes to your pituitary to actually stimulate the production and release of gonadotropins
- [Gonadotropins](https://en.wikipedia.org/wiki/Gonadotropin) are the hormones that work on your gonads to produce testosterone, as well as assist with spermatogenesis and sustain fertility
- The gonadotropins that come out of the pituitary, they *elevate* upstream (and GnRH) in response to **androgen receptor activation** and **estrogen receptor activation**
  - There’s also some stimulation of **progesterone receptors** that causes *negative feedback*, among other things
  - Primarily, to be noted for this discussion are the androgen receptors, estrogen receptors: when those are adequately stimulated, it will tell your brain, “*Okay, we have enough testosterone, as well as DHT and estrogen that we don’t need to make more*.”
    - That will give negative feedback to the [hypothalamus-pituitary-testicular axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93gonadal_axis) to not produce as much GnRH and LH and FSH until those levels fall to where there’s a need to make more hormones
    - [Summarized in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2023/10/f1-derek-1024x440.png)

**Figure 1. Hormones needed for sperm production and negative feedback that controls this system**. Image credit: [*Concepts of Biology*](https://opentextbc.ca/biology/chapter/24-4-hormonal-control-of-human-reproduction/)

- It’s this finely tuned system where your body assesses how much it needs, waits until it needs to produce more, and then it produces more
- At the top of that, GnRH stimulates pituitary output of [LH (luteinizing hormone)](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [follicle stimulating hormone (FSH)](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)
  - LH acts on [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) in the testes
  - FSH acts on [Sertoli cells](https://en.wikipedia.org/wiki/Sertoli_cell), also in the testes
  - Those hormones will go down to the testes and stimulate the production of intra-testicular testosterone, as well as assist with the production of sperm and maintenance of fertility
- That’s probably a good summation of how you end up with testosterone

**What’s the fate of testosterone, in terms of metabolites?**

*How much of it gets converted to estradiol and DHT?*

- This is where a lot of people who neglect lifestyle and diet don’t realize all of the backhanded consequences of being too **obese** or something like that
- For example, you could have [aromatase](https://en.wikipedia.org/wiki/Aromatase) strongly expressed in **adipose tissue**
  - If you are too obese this is problematic, especially in adolescence
  - If you have a disproportionate amount of aromatase expression because of how fat you are, you could otherwise be producing more **estrogen** than you would’ve if you were lean, telling your brain in an indirect way that, “*Hey, we have enough estrogen, so don’t make more testosterone.*”
    - Because testosterone is used to make estrogen
- **Testosterone converts primarily to two hormones through the 5⍺-reductase enzyme**: [DHT (dihydrotestosterone](https://en.wikipedia.org/wiki/Dihydrotestosterone) (which has a significantly greater potency for binding and transcribing activity at the androgen receptor) and estrogen ([estradiol](https://en.wikipedia.org/wiki/Estradiol) is the primary estrogen receptor agonist for estrogen receptors around the body)
  - Those two hormones regulate a balance of androgenicity and estrogenicity in the body, and it’s a finely tuned system.
- This system is also regulated by **binding proteins** produced by the liver [such as [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)]
- The differential between females versus men also works in the same way
  - The amount of these hormones produced is quite different
  - Also the binding proteins to regulate that you stay feminine versus you have a masculine profile

***Ultimately, the balance of free androgen to free estrogen in the body is what essentially dictates if you are feminine versus masculine***

- You could flip-flop back and forth almost manually if you really wanted to
- We see this in bodybuilding where females will literally masculinize themselves to hell in order to win a show by using super physiologic amounts of drugs
- And also in people are trying to transition from male to female or vice versa
- And some of these changes are permanent, on the masculinization front
  - If you have a deep voice, it’s almost certain that you’re not going to get it high after going on female hormone therapy

**Derek’s summary**

- At the end of the day, these are the primary hormones to understand as far as the spectrum of androgenic male to estrogenic feminine-like
- Estrogen is *not* a female hormone because it exists in both sexes
- DHT is the primary androgen that dictates androgenicity and sexual differentiation and maturation
- Testosterone is the main anabolic hormone and it drives a lot of the neurology, the psychoactive effects
- Then estrogen is a big balancing act, essentially

**Let’s make sure people understand the difference between androgenic and anabolic**

- The **androgenic activity** of a compound or your endogenous hormones is essentially how masculinizing it is
- So, [dihydrotestosterone (DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone), the 5⍺-reductase metabolite of testosterone) is the most androgenic hormone in the body, and it can significantly inhibit estrogen’s activity
  - Even in RNA transcription at the receptor site
  - It’s very potent in what it does
  - To frame how important it is, if you wiped out DHT before puberty in a male he would end up with a micro penis
    - If you took a male before puberty and put him on [dutasteride](https://en.wikipedia.org/wiki/Dutasteride) or [finasteride](https://en.wikipedia.org/wiki/Finasteride) [5⍺-reductase inhibitors] while making no change to his testosterone
    - Individuals will not undergo full male maturation unless you have the presence of this hormone
    - You see this in pseudo-hermaphrodites that have a [mutation](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_2_deficiency) in the gene that encodes 5⍺-reductase

***The easiest way to summarize it is DHT is the most androgenic hormone in the body, the most masculinizing testosterone, and estrogen on the opposite side of the spectrum, has zero masculinization, it’s very feminizing***

**The molecular effects of DHT**

- As DHT or testosterone makes it way into a cell, it binds to the [androgen receptor (AR)](https://en.wikipedia.org/wiki/Androgen_receptor) in the cytoplasm, and DHT does this with far greater affinity
  - DHT has maybe 20x more binding efficiency to the androgen receptor
- This new complex of testosterone (or DHT) bound to the AR makes its way into the nucleus where it acts as a [transcription factor](https://en.wikipedia.org/wiki/Transcription_factor) binding to DNA and effectively  controlling transcription [translation](https://en.wikipedia.org/wiki/Translation_(biology))
  - That’s how we make stuff
  - It’s how we make proteins
  - That’s how it impacts muscle protein synthesis

***Derek points out that androgenic is masculinizing, but does not necessarily equate to muscle***

- So you could have severe masculinization with a relative absence of actual muscle growth (or bone integrity and what have you)

**How important is DHT post-puberty?**

- You could say it’s pretty critical from a standpoint of: cognitive health, balance of estrogen, vasodilation in the penis
- You could just as easily say it’s not necessary as you will likely survive and thrive with a lack of DHT

## Post-finasteride syndrome, and how Derek successfully treated his hair loss [1:43:15]

- A lot of people demonize 5⍺-reductase inhibitors (and justifiably so in some cases), but when you look to the literature about placebo versus finasteride versus dutasteride, the side effect profiles are pretty similar
  - Finasteride and dutasteride are two drugs that block [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase), and they were used initially for reducing prostate size because DHT disproportionately drives prostate growth [[BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia)]
    - Now they are used more to prevent hair loss
- We talked about the debatable [post-finasteride syndrome](https://en.wikipedia.org/wiki/Finasteride#Post-finasteride_syndrome) on two prior podcasts: episodes [#260](https://peterattiamd.com/mohitkhera/) and [#273](https://peterattiamd.com/tedschaeffer2/)
  - There’s not a clear consensus in the urologic literature about even the existence of this, let alone the prevalence, let alone the reversibility of it
  - It’s created quite a bit of a conundrum for Peter because he has a number of patients who take finasteride or dutasteride for hair loss
- Derek asks Peter, “*What’s your stance on 5⍺-reductase inhibitors?*”
- Peter never paid attention to it until about a year ago
- Right now his stance is he probably wouldn’t start somebody on it
  - If a person has [BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia), he’s not the one to manage it anyway
    - A urologist has far better tools to manage BPH than 5⍺-reductase inhibitors

***Peter feels pretty strongly that if you have BPH, you should not be on a 5⍺-reductase inhibitor***

- It’s like if someone came to him with a high [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) and he gave them bile acid sequester in circa 1981 ‒  it’s just not necessary, there’s no upside

**Hair loss**

- From a hair loss perspective, this is not something Peter knows much about
  - Patients would go see a hair doctor who is going to try to give them 50 different proprietary compounds which Peter would encourage them not to take
    - There are enough other tools you can use to avoid the small (but not zero) risk of something going wrong in terms of sexual side effects that in the worst case might not be reversible
- Derek thinks that **topical** [dutasteride](https://en.wikipedia.org/wiki/Dutasteride) is interesting because it may have some capacity to stay local, especially if you do [mesotherapy](https://en.wikipedia.org/wiki/Mesotherapy)
  - Peter was not aware of this difference
  - It’s thought to be related to the molecular mass of the drug
- Peter doesn’t think that systemic [minoxidil](https://en.wikipedia.org/wiki/Minoxidil) is necessarily a benign drug
- The other thing nobody can really give an explanation for is what the right **dose** is
- Low-dose oral minoxidil is insane, and Peter doesn’t like being in the business of prescribing things for which he doesn’t have a great understanding
- It’s not that he doesn’t think it’s worth addressing if it bothers someone
- The bigger issue is, it would be really awful if in trying to treat a cosmetic condition like hair loss, you induced a devastating consequence on your endocrine system
- Now, it also appears that if you’ve been on finasteride for a long period of time and you’re not experiencing any of these side effects, you’re probably fine
  - Peter doesn’t want someone listening to this who’s been taking [Propecia](https://en.wikipedia.org/wiki/Finasteride) for 10 years who’s never had an issue to feel that they have to stop using it
    - The [literature](https://pubmed.ncbi.nlm.nih.gov/27475241/) would suggest that if you’re going to have these side effects, you’re going to have them in about six months
- Derek notes when it comes to hair loss, the problem with treatments is they don’t actually interact with the [AR](https://en.wikipedia.org/wiki/Androgen_receptor) (or inhibit the potential for stimulation (or antagonism) of AR through DHT reduction)
  - So if you stimulate hair growth with minoxidil, you are still not preventing further loss
  - If you get a hair transplant, you’re not preventing further loss of your existing hair
  - Oftentimes it’s like you’re trying to row against a current and you’re continuously getting pushed back
    - Eventually to the point where you have so few visible hair follicles left that are healthy that it doesn’t matter how much you’ve been on minoxidil
- Derek doesn’t want to say he’s a proponent of finasteride necessarily
  - The prevalence of side effects is not nothing, but it’s overblown by the opposite camp that wants to assert, “*Why would you ever inhibit a hormone that is the primary androgen you rely on?*”
    - Similarly, why would you inhibit apoB or something
    - There is a clear outcome whereby there is a benefit
  - When there is DHT in somebody who’s prone to hair loss, it’s hard to overlook that DHT is the thing primary dictating if you go bald or not
- Peter thinks there’s a difference because he thinks apoB serves no benefit
  - If someone created an antisense oligonucleotide that knocked out apoB, all it would do is guarantee we don’t have heart disease in our species
  - We would still be able to use all the HDLs in the world for cholesterol transport, which we currently use LDL for
- To take Derek’s analogy a step further, what you’re basically saying is if a person cares as much about hair loss as they do about heart disease, and by that logic DHT is causal
  - Peter would posit that there are lots of people who care more about hair loss than heart disease
    - Derek agrees, “*The psychological stress for some people is significant and should not be overlooked by the silliness of, ‘Oh, just shave it, bro. It’s not a big deal. There’s tons of successful people who are bald.’”*

**You mentioned that you were already starting to lose your hair in your early 20s. How did you reverse that?**

- Part of it was just dropping the dose significantly and eventually just going down to replacement therapy
- But it was the introduction of 5⍺-reductase inhibitor
  - Initially [finasteride](https://en.wikipedia.org/wiki/Finasteride)
  - Thereafter he introduced a topical anti-androgen that’s experimental and never actually received FDA approval
    - He wouldn’t necessarily recommend this blindly
- There are some anti-androgens in the FDA pipeline right now that actually look promising and have safety data behind them and whatnot
  - Derek’s watching closely and hopes one comes to fruition
  - Because these are essentially compounds that compete for the androgen receptor locally, but do not have systemic anti-androgenic activity
    - So you can maintain all systemic androgen levels with just localized activity in the scalp

***Derek uses a topical anti-androgen coupled with a 5⍺-reductase inhibitor***

- He used to take 1 mg finasteride daily and now takes 0.5 mg dutasteride a day
  - It’s a soft gel that essentially wipes out systemic DHT
    - His DHT level is worse than a teenage girl
- When he was in his early 20s he used a topical application of [RU-58841](https://en.wikipedia.org/wiki/RU-58841), it’s an experimental anti-androgen
  - He doesn’t recommend people use this when there are alternatives with human safety data on the horizon
  - But it’s also hard to wait because you only have some much time
- He is currently not using any topical application simple because of how burdensome the schedule is
- He also uses a [Ketoconazole](https://en.wikipedia.org/wiki/Ketoconazole) shampoo, but it’s like a very mild anti-androgen
  - It’s mostly just a good shampoo
- The thing with hair is that the visual representation of loss is typically not apparent until you’ve lost a lot of ground
  - You could pull a handful of  hair out of your head and see no difference whatsoever
  - Once you’ve finally noticed diffuse thinning or recession, you’ve already lost 20-30% of your hair, and there’s no guarantee that it’s coming back

**Did you regain hair that you had lost with this protocol or just completely stop the hair loss?**

- Derek had some regrowth
- But expecting yourself to get back to baseline where you had 17-year-old immaculate perfect hair is unlikely
  - If you’ve been exposed to androgens at a level where you’re visibly noticing hair loss
  - If Derek took Minoxidil, as well as microneedle, and did a bunch of other stuff, he could probably get a decent amount of the way there
- The longer you wait and let hair follicles miniaturize, the more permanency you are risking
- Hair regrowth is way harder than preventing yourself from losing in the first place
  - It’s almost analogous to building muscle when you’re younger, so then you don’t have to try and build it in old age when you have anabolic resistance or what have you

**What are the topical drugs with more safety data coming down the pipeline?**

- [Kintor](https://en.kintor.com.cn/intro/30.html) has a compound called [pyrilutamide](https://en.wikipedia.org/wiki/Pyrilutamide) that it seems to be a pretty well tolerated, and it has comparable outcomes of hair count increase to dutasteride
  - Which is pretty substantial given that there are very few things that produce outcomes that even make it worth taking another drug

***Right now, the most effective things are going to be 5⍺-reductase inhibitors and minoxidil***

- On top of that, everything else is like little sprinkles on the cake essentially

**The most crazy hair loss reversals you will see are in men who transition to women and use female hormone therapy**

- Derek never would recommend anyone to do that, but it’s an interesting data set to pull from
- Peter notes that estrogen and progesterone would promote hair growth
  - He sees it in women during HRT, progesterone especially can really thicken hair, but this is in women
- What Derek is talking about is anti-androgen plus estrogen
  - Somebody transitioning would typically use a [cyproterone acetate](https://en.wikipedia.org/wiki/Cyproterone_acetate), [bicalutamide](https://en.wikipedia.org/wiki/Bicalutamide) (something of that nature) plus exogenous [E2](https://en.wikipedia.org/wiki/Estradiol) (or a synthetic estrogen)
- Peter is not familiar with the first two, are these drugs that block androgen binding to the androgen receptor?
- Cyproterone is a very potently anti-gonadotropic
  - It will inhibit you from producing [GnRH](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone)

**Is this effectively a chemical castration?**

- Yeah
- That’s like a steroidal anti-estrogen
- There is a non-steroidal anti-estrogen ([bicalutamide](https://en.wikipedia.org/wiki/Bicalutamide)) that seems to be better tolerated
  - It’s no toxic to your liver
  - It will raise your hormone levels (your test levels go up)
  - Bicalutamide occupies the active site on the androgen receptor; it’s like a silent androgen receptor antagonist
- Derek adds, “*Those are extreme options, essentially irrelevant for anyone watching. So maybe I shouldn’t have brought it up.*”

## Testosterone replacement therapy: compelling use cases, side effects, and optimal dosing schedules [1:57:15]

- Derek asks Peter when he is starting [TRT](https://en.wikipedia.org/wiki/Androgen_replacement_therapy)
- Peter is doing his blood work again next week and will see how far his levels have continued to fall
- Peter has never found a compelling table for normal levels of free testosterone that are stratified by age
- You can find these [data](https://academic.oup.com/jcem/article/86/2/724/2841070) quite easily for total testosterone level by decade (see the figure below)
- But he’s only seen data (percentile ranks) for free testosterone in broad chunks: prepubescent, pubescent, post pubescent

![](https://peterattiamd.com/wp-content/uploads/2023/10/f2-derek.png)

**Figure 2. Total and free testosterone in men by decade of age (numbers in parenthesis indicate the number of men in each cohort)**. Image credit: [*JCEM* 2001](https://academic.oup.com/jcem/article/86/2/724/2841070)

**Total testosterone versus free testosterone**

- If a person’s total testosterone is 800 ng/dL, most of that is bound
  - [Sex hormone-binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) and [albumin](https://en.wikipedia.org/wiki/Albumin) probably do the lion’s share of binding
- If a guy’s got 2% of that as free testosterone (or unbound), that would translate to 16 ng/dL free testosterone
- That is estimated (not calculated)
- When you go to the lab and you get a test done, they’re measuring testosterone by a direct measurement
  - We should talk about [ELISA](https://en.wikipedia.org/wiki/ELISA) versus [LC-MS](https://en.wikipedia.org/wiki/Liquid_chromatography%E2%80%93mass_spectrometry) later
- They’re estimating the free testosterone based on the measurement of the binding proteins
- So that’s an introduction of **potential error #1: you don’t really know how much free testosterone you have**
- The other thing is **you don’t know how many androgen receptors you have**, so you really don’t have any idea whatever amount of testosterone you have is saturating your androgen receptors or not
  - Are you playing below your weight or above your weight?

**What do we know about the amount of total testosterone over time in a guy’s life?**

- After it peaks, you will have a steady, gradual decline
- As opposed to women, where you see a plummet [in estrogen and progesterone] after menopause
  - Change in hormones at menopause is discussed further in [episode #256](https://peterattiamd.com/endocrinesystem/)
- Testosterone decreases gradually in men, dropping about 1%  total T and 2-3% free T each year
  - It depends on age and lifestyle
  - In general, post age 30, 35, you can expect a little bit of a decline to start
- That’s not to say Derek hasn’t seen 70 year olds with 1000 total T sometimes
- So you can certainly retain high level production
- People shouldn’t think, “*Oh, now that I’m 45, my levels have probably dropped 20 plus percent at this point. I should probably get on TRT*.”
  - That might not be the case
  - It’s a matter of how well you produce gonadotropins, and how well you respond to them in your testes (because there is some level of function that declines with age too)
- That’s where you get into the nuance of: is TRT justifiable for this person based on pituitary output, lifestyle, diet, nutrient intake, sleep hygiene, is there sleep apnea, etc.
- There’s an argument to be made that if you have very good testicle response, why would you ever be on exogenous TRT because you could top-out your natural signal

**What do you think is the most compelling case for TRT, and how often are people expanding that use case?**

- The most justified use for it is people who have [primary hypogonadism](https://en.wikipedia.org/wiki/Hypergonadotropic_hypogonadism)
  - That is when you have gonadotropins going to your testes, but you’re just not responding to them
  - So you’ll see  high levels of  LH and FSH in your blood work, but your total T is still bottomed out
    - That could be somebody who should probably check if they have a [varicocele](https://en.wikipedia.org/wiki/Varicocele)
    - Do an ultrasound in your testes, see where things are at structurally, functionally, etc. before you make any rash decisions because there could be something you’re overlooking
    - A lot of people do overlook certain structural abnormalities that may otherwise be rectifiable
  - Typically testicular failure in response to adequate signaling would be the obvious, more no-brainer versus if you had low LH and FSH
  - Maybe your testicles are fine, so why are you haphazardly getting on testosterone when maybe it’s a lifestyle thing?
- [The figure below shows the prevalence of hypogonadism in men by age]

![](https://peterattiamd.com/wp-content/uploads/2023/10/f3-derek.png)

**Figure 3. Hypogonadism in men by total T and free T by decade**. Image credit: [*JCEM* 2001](https://academic.oup.com/jcem/article/86/2/724/2841070)

- When Peter sees that second pattern (of low testosterone in a setting of low LH and FSH), the most obvious things that show up are poor sleep and high glucocorticoids
  - Which can suppress the pituitary
  - [These hormones are discussed further in [episode #256](https://peterattiamd.com/endocrinesystem/)]
- Derek asks, “*You’d measure the glucocorticoids through a Dutch test?*”
- Yeah, usually a [urine Dutch test](https://dutchtest.com/info-dutch-complete/)
- Peter points out, “*These are not the easiest things to fix because people have to change behaviors, which is a lot harder than taking a medication.*”

**What do we know about the dose response of testosterone?**

*Does it make sense to use fixed dosing and increased dosing, or target to certain levels?*

- Let’s say a patient has [primary hypogonadism](https://en.wikipedia.org/wiki/Hypergonadotropic_hypogonadism) and we believe TRT is the right thing to do
- Most of the studies (we might talk about the [TRAVERSE trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025)) use fixed dosing, which is at one of the criticisms Peter has of that approach
  - Especially when you’re using something topical and you have variable absorption
- In general, Derek thinks if you’re going to be treating with exogenous testosterone, an accepted entry-level dose that is on average safe, and well tolerated, and will get you to a reasonable total T that provides symptom relief for the majority of people, a logical start point is **80-120 mg a week**
  - Then just seeing what happens to the guy’s total T, free T
  - This could also be variable based on, does he have a super high [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)?
    - Should we evaluate that because maybe he just has a low free T, but his total is fine
    - In that case, you could have brutal symptoms, but your production is still good, it’s just severely bound up
    - Why that might be the case: Do you have severe liver issues or something?

**Optimizing the dosing schedule for testosterone [2:03:15]**

***Is there any advantage to dosing it once weekly, taking that dose and dividing it by two and doing it twice a week, or taking that dose and dividing it by seven and doing it every day?***

- Derek doesn’t know
- Patients want the highest level of optimization
- Maybe it’s more reasonable to expect them to inject more frequently
- There is a half-life with the drug depending on the ester chosen
  - [Testosterone cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) is the most common one prescribed in the US, and it has a half-life of 10 days
    - This depends on the person and where it is injected
  - If you extrapolate from that, it’s going to take 50 days to achieve steady-state serum concentrations in the blood
    - You will see all of this spiking until there is the same amount of drug clearing out of your system as you’re adding in
    - There is no accumulation of drug burden after you’ve achieved steady state serum concentrations

> “*The advantage to injecting [testosterone] more frequently, this is going to be determined largely by patient adherence more than anything*”‒ Derek

- Derek has seen some insane stuff where people let themselves drop to hypogonadal territory and then remember (based on their dick not working) to inject their testosterone

***Injecting T once a week is the bare minimum, twice a week is a minimum for decent steady hormone concentrations***

- Peter has arrived at the same conclusion, that injecting T twice a week is the sweet spot
- He has a couple of patients who do daily injections, and these patients see much less [suppression] for the same dose of testosterone
  - It’s difficult to inject 15 mg a day; you have to be very thoughtful about what kind of needles you use to get such a small volume in
  - They will have much less FH, LH suppression
    - Which suggests the higher the peak, the more FSH LH suppression
- Derek points out that when you look at trough levels of T (the lowest point of hormone concentration) after an injection, more frequent injections can lower the aromatization spike and the 5⍺-reduction
  - This is what he sees in his blood work over the years (and in [Marek Health](https://marekhealth.com/)); there are diminishing returns for sure
  - Some studies assess dose response a week after injection
  - What you see in the literature isn’t necessarily reflective of what’s going to be in patients trying to optimize their levels

> “*If you have a bolus administration of 150 mg once a week, you are literally spiking your T into super physiological territory acutely, and concurrently you are getting supraphysiologic conversion to estradiol, DHT*”‒ Derek

- With a bolus administration of 150 mg once a week, you also have a a very, very aggressive spike in free androgenic signaling
  - Which can crank your sympathetic nervous system up, impair your sleep quality
  - There are so many consequences
  - Peter adds that you’ll see more [hematopoiesis](https://en.wikipedia.org/wiki/Haematopoiesis)
- Peter [talked with Mohit Khera](https://peterattiamd.com/mohitkhera/) about [Natesto](https://www.natesto.com/) (which is a nasal formulation), and it has such a short half-life that it is used on a [TID](https://www.rxlist.com/bid_on_prescription/definition.htm) dosing schedule
  - Natesto is 7 mg of testosterone administered intranasally
  - Derek wants to see somebody take that more more than a year and tell him it’s cool and fun to take; if you do that for TRT keep him posted
  - Peter probably won’t go this route
- Peter adds two interesting points with Natesto
  - 1 – They don’t have the increase in hematopoiesis, so people are not making too many red blood cells
    - Otherwise you have to be careful of this and people will have to get therapeutically phlebotomized to take blood off them as their hematocrit gets over 50
  - 2 – A woman could take one of those every other day as sort of an on-demand libido tool
    - A clinical study is ongoing where women are using one application of that intravaginally before sex to enhance orgasmic function
  - It’s Peter’s view that it’s always desirable to have an FDA formulated product and avoid the dark side of compounding

***A frequent protocol of testosterone dosing is better for getting a more stable level and will result in a lower burden of side effects***

- Natesto is in and out acutely so fast, and you’re not getting this huge spike to 1500-2000 ng/dL total T
- There is no situation where your testes would blast you once a week with a hammer of testosterone and all of the associated metabolites
- Instead, you have little pulsations over the diurnal rhythm, and this is why your blood levels of testosterone is going to ebb and flow over the day
  - Your levels in the morning might be 300 ng/dL higher than later in the day (it fluctuates)

***The more you can replicate that diurnal rhythm through the synthetic administration route, the closer you’re going to get to a lower side effect burden***

- Derek has seen some guys that get [gynecomastia](https://en.wikipedia.org/wiki/Gynecomastia) from TRT doses go to ED (everyday dosing) and get off their [AI (aromatase inhibitor)](https://en.wikipedia.org/wiki/Aromatase_inhibitor)
  - Guys who take a weekly dose of testosterone and in doing so they make so much estrogen that they have to take an aromatase inhibitor to prevent them from getting breast tissue (gynecomastia)
  - But if they take that same dose and divide it daily, they can comm of the aromatase inhibitor altogether
- When Peter got back into the practice of medicine and was learning about HRT, he couldn’t find who weren’t prescribing anything different than every two weeks
  - The standard dose was 200 mg every 2 weeks
  - Peter remembers going through Lewellyn’s *Pharmacology* and looking at the pharmacokinetics and thinking, “*This is an awful idea*”

**Are there any differences between testosterone** [**cypionate**](https://en.wikipedia.org/wiki/Testosterone_cypionate) **and** [**enanthate**](https://en.wikipedia.org/wiki/Testosterone_enanthate)**?**

- Peter recalls one advantage of enanthate is the commercial produce [XYOSTED](https://www.xyosted.com/about-xyosted?gclid=CjwKCAjw38SoBhB6EiwA8EQVLhOVnAt5vmB_PUncPpmUQNY370XArEkcVPvKPtD1dOguzbqUsJXWtRoCX80QAvD_BwE&gclsrc=aw.ds) ‒ it comes as a preloaded pen, good for people who are squeamish about injecting
- Derek explains that enanthate is thought to be a long ester, and it’s sort of in-between a cypionate and a [propionate](https://en.wikipedia.org/wiki/Testosterone_propionate)
  - It’s half-life could be as short a 4.5-5 days
  - The half-life of cypionate could be twice as long in some people [9-10 days], depending on your metabolism of the drug and how often you are dosing
  - But if you infect frequently enough, it would essentially be irrelevant
- The XYOSTED protocol from the FDA is once weekly
  - Peter recommends people do it twice a week at a lower dose
  - The preloaded dose is annoying because you can’t meter it out
- Peter explains to patients that testosterone cypionate is a fraction of the cost, you just have to be willing to meter it out
  - Testosterone enanthate only comes in 3 pre-loaded doses (of XYOSTED), so you have less wiggle-room if you’re not happy with the output
    - Derek agrees that you are not optimizing your hormone status, dialing in the stability of it, side effect profile, and potentially quality of life, as much as you could if you did a more frequent schedule
- Derek points out there is a dramatic difference in going from injecting testosterone once a week to twice a week
  - There are diminished returns when you go from injecting every-other day to every day
  - But injecting twice a week is a dramatic difference over once a week, it’s worthwhile

**Route of injection: intramuscular versus subcutaneous**

- Peter has always advised patient to inject testosterone [sub-Q](https://en.wikipedia.org/wiki/Subcutaneous_administration) for the belief that you bleed-out the effect a little bit longer
  - Though he doesn’t think he’s ever seen the data to support that
- Derek has seen the data and thinks this is an extrapolation, but he believes it to be true
  - When you look at sub-Q dosing, you’ll notice the total T levels are higher
  - People take away from that, that you’ll get more out of your test sub-Q
  - But the reality is, they often measure total test levels a week after your shot
  - Derek thinks you’re almost giving yourself a sustained release through administering it into the fat tissue rather than intramuscular (which is absorbed more quickly into the blood flow, just like if you did an IV administration, it would be in your blood immediately

***Once you get to every-other day dosing, it almost doesn’t matter; if you’re just dosing once a week then sub-Q is better***

## The use of aromatase inhibitors to suppress estrogen, and the misconceptions around estrogen in men [2:16:00]

**There was a** [**study**](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168) **published in the** ***New England Journal of Medicine*** **in 2013 that Peter thinks doesn’t get enough attention**

- It looked at 10 groups ‒ a group of chemically castrated men
  - Half got an [aromatase inhibitor](https://en.wikipedia.org/wiki/Aromatase_inhibitor#) and half did not
  - Within each group, there were four escalating doses of testosterone plus a placebo
  - For a total of 5 groups x2, as one had estrogen inhibition (via the aromatase inhibitor) and one did not
- The outputs were: body composition, mood, libido, erectile functional

***The punchline was you were better off with more estrogen and more testosterone***

- The best outcome group was the high T, high E group
- The high E group wasn’t that high [around 35 pg/mL]

> “*This was an important study because I think it suggested that estrogen is not the bad guy*”‒ Peter Attia

- Peter thinks a lot of people out there are probably thinking if you’re taking testosterone, you need to be taking an aromatase inhibitor
  - That may be true at some doses

**What are bodybuilders doing?**

- Back in the day we thought that regardless of the dose of androgen, you should lower your estradiol to 20-0 because it’s in the middle of the reference range-ish for a man, and that’s where you get the best
  - There was no thought of balance
  - It was kind like this is a bad hormone to have above the reference range, even though our androgens are literally like 10x the reference range

*What were your testosterone levels when you were back in the heyday?*

- Derek never got [LC-MS testing](https://en.wikipedia.org/wiki/Liquid_chromatography%E2%80%93mass_spectrometry) when he used his highest doses
- It would get capped at 1500 or something, but it was in the thousands for sure
- With estradiol, Derek has seen studies where it shows neurotoxic outcomes are higher when aromatase is inhibited and there is less neurotoxicity when it’s [aromatase inhibitors are] taken out on the exact same input of testosterone
- Derek thinks it’s pretty clear at this point that there is a role of estrogen in the body, from a cardiovascular and a neurological standpoint
  - Estrogen hase serotonergic activity
  - There are so many things that regulate mood as well,even temperature control too is going to be variable based on that
    - It ties into the post-menopausal stuff
  - But for men estrogen is certainly important and to crush it arbitrarily based on a reference range is old bro lore

***Nowadays most people, even in the bodybuilding space are pretty aware now that estrogen is important for cardio neuro-protection***

- Peter adds that it is also really important for bone health
- Peter is more troubled that his estradiol is low because his T is routinely between 300-400 ng/dL (which is normal), but his estradiol is never above 25 gl/mL (also normal)
  - But to him, one of the big advantages of having a T of 1000 would be that he would hopefully have an estradiol of 40
- Derek points out that using a 5⍺-reductase inhibitor (finasteride or dutasteride) would increase estradiol by 15-22%
  - When you don’t have conversion of T to DHT, you branch off more T to estradiol

> “*That’s where the unique individual variability comes into the consideration for drug implementation*”‒ Derek

- Peter is going to do both tests side-by-side next week: an enzyme-based test plus LC-MS for DHT, testosterone, and estradiol
  - Enzyme-based testing often gets estradiol wrong
    - He’s seen guys get a result of 100 estradiol using an enzyme-based system, but when you send them to LabCorp and specify LC-MS, it’s 31
  - Derek agrees, he’s seen some brutal over estimations using [ECLIA](https://en.wikipedia.org/wiki/Electrochemiluminescence#ECLIA)
    - This is especially important in hypogonadal men who have relatively low estrogen to begin with; actually identifying where it stands is pretty important

## The use of other hormones beyond testosterone for male sex hormone replacement [2:21:00]

**For most medical needs, is there any reason to be considering a hormone beyond testosterone for male sex hormone replacement?**

- It depends on the person and if you’re just talking about health benefits, and not performance benefits
- For example, Peter used to be more liberal and creative, and one of the things he used to do if a guy had normal testosterone (of 1000 ng/dL), his [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) is 100 (very high), and his % free T is 8 ng/dL
  - He has about 0.8% free T instead of 2%
  - You could use a very, very low dose of [oxandrolone](https://en.wikipedia.org/wiki/Oxandrolone) to eradicate his SHBG because it  has such a high binding affinity for oxandrolone
    - But if you give too much, you’ll inhibit testosterone production
    - It’s a very fine balance
    - You might give him 10 mg 2-3x a week of oxandrolone to knock that SHBG down and double his free testosterone, but you haven’t given him any testosterone
  - Peter doesn’t do that sort of thing anymore; it’s not worth the hassle
  - This is an example of an area where you can manipulate another part of the system without having to go beyond that

**If you take examples like that out and are just talking about the use of other steroids, what’s the case?**

- In some individuals adrenal hormone replacement ([DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone)) sometimes may be justified, but it’s going to be based on blood work
  - That might make sense if you had a bottom [DHEA-S](https://en.wikipedia.org/wiki/Dehydroepiandrosterone_sulfate) [level] or low [pregnenolone](https://en.wikipedia.org/wiki/Pregnenolone)
  - But it’s more for neurological, cognitive, perceived quality of life effects, not necessarily because there’s not any evidence to support that necessary
- In general, the main needle mover is going to be your testosterone and how much it 5⍺-reduces or aromatize into the two metabolites [DHT + estradiol]
  - And from there, you would never manually use more DHT
  - You would almost never probably manually use estradiol on top, although it’s not impossible
- Derek has seen progesterone use in men on TRT provide reasonable improvement in **sleep quality**
  - 100-200 mg, the same as you would use in women
  - You don’t have any [HPTA (hypothalamic-pituitary-testicular axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93gonadal_axis)) suppression because you’re shut down anyway
  - It can be impactful on quality of life because you get the downstream conversion to some of those neuro-steroids that may be inhibited in post-finasteride patients
  - Why wouldn’t it work if you had a reasonable low progesterone level?
    - You’re not expected to have a sky high progesterone, but it’s some of the downstream neuro-steroid metabolites that you make through 5⍺-reduction and whatnot that are very GABAergic and anxiolytic and can help certain people
  - Maybe that’s useful for a specific guy who has a low SHBG and is in a state of high sympathetic drive on his testosterone and needs to calm down

## The history of anabolic compounds, and the differing effects of various anabolic testosterone derivatives and related drugs [2:24:30]

**History of anabolics**

- Use of testosterone goes back nearly 100 years

*What was the first anabolic derivative of testosterone?*

- The first one Derek can think of is [Dianabol](https://en.wikipedia.org/wiki/Metandienone)
- There might have been methyl test or something
- Essentially what they did was they took the testosterone molecule and found they could manipulate it in ways to create testosterone derivatives like Dianabol (methandrostenolone) which is supposedly the breakfast of champions according to Arnold
- [Boldenone](https://en.wikipedia.org/wiki/Boldenone) is a very commonly used drug as well that is also a testosterone derivative
  - It was prescribed to horses for a while, no human use
- There’s other ones that came after, [Halotestin](https://en.wikipedia.org/wiki/Fluoxymesterone), famously one of the presidents of the United States was on some aggressive dose of Halotestin  for maybe fertility or androgen therapy
- Some of the protocols back then made almost no sense
- They also found that if you take [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone), you can manipulate it and create more anabolic compounds that are tissue selective
  - This was for treating muscle wasting in androgen-sensitive individuals
  - You’re not going to give a female child who is a burn patient testosterone because you might masculinize them
  - This was an anti-catabolic, novel alternative to preserve tissue
- In the arms race to create the best anabolic agent, numerous pharmaceutical companies came up with an array of compounds that came to be known as the Dianabols, the boldenones
- On the DHT derivative side, you had [Oxandrolone](https://en.wikipedia.org/wiki/Oxandrolone) (one of the more refined) and [Primobolan](https://en.wikipedia.org/wiki/Metenolone_acetate) (generic methenolone) is also a very refined one
- [Mesterolone (brand name Proviron)](https://en.wikipedia.org/wiki/Mesterolone) is still used to interact with SHBG
  - It is probably one of the most potent drugs that binds SHBG
- The ideal scenario would be you’re trying to **segregate the anabolic from androgenic activity** because testosterone is essentially equal (at least based on rodent studies)
  - You would find an equal amount of anabolic activity in muscle relative to androgen like activity and masculinization
- So you would try and manipulate a compound to give maximum anabolic outcomes with a relative lack of androgenic outcomes to create something that men, women, children, anybody could take for muscle wasting purposes and preserved tissue
  - They never successfully did it
  - But they created an array of compounds

**Rate compounds based on anabolic and androgenic properties on a scale of 1 to 10**

- Testosterone would be a 5, halfway between completely anabolic and and completely androgenic
- DHT would be closer to 1, it’s much more androgenic than it is anabolic

*What is the furthest example you have that’s closest to 10, meaning the most anabolic?*

- [Primobolan](https://en.wikipedia.org/wiki/Metenolone_acetate) probably

*Would one think that is the drug of choice if you’re a bodybuilder?*

- Often it is
- That’s not the only drug because it depends on what else you’re trying to get
- Sometimes the side effects are desired (as absurd as it sounds)
  - [Dianabol](https://en.wikipedia.org/wiki/Metandienone) causes heavy water retention, and more water around your muscle belly could help cushion your joints when you’re doing heavy lifting
  - Primobolan is extremely refined and specific in its action ‒ it’s a pure protein accretion compound with a relatively less burdensome androgenic profile
    - The side effects of it don’t interact with [aromatase](https://en.wikipedia.org/wiki/Aromatase) because it’s a DHT derivative and so it’s not a substrate for aromatase
    - It does not 5⍺-reduce into a bunch of things
    - It’s outcome is more predictable, but that’s not always the desired outcome
  - Some people want to look cosmetically inflated with water
  - Some people want to lift more weights or prevent injury, and sometimes that water can be helpful

***Anabolics that skew the furthest in the direction of anabolic relative to energetic are*** [***Primobolan***](https://en.wikipedia.org/wiki/Metenolone_acetate) ***and*** [***Anavar***](https://en.wikipedia.org/wiki/Oxandrolone)

- Peter remembers reading that Anavar is highly prized among athletes
- If Derek was to give the most extreme anabolic relative, technically [SARMs](https://en.wikipedia.org/wiki/Selective_androgen_receptor_modulator) go even further

## Use of SARMs by bodybuilders [2:29:45]

**SARMs**

- [SARMs](https://en.wikipedia.org/wiki/Selective_androgen_receptor_modulator) are selective androgen receptor modulators, and these will interact in a tissue-specific way with estrogen receptors in various areas of the body
- Take [Clomid](https://en.wikipedia.org/wiki/Clomifene#) and [Tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen) for example, these are [SERMs](https://en.wikipedia.org/wiki/Selective_estrogen_receptor_modulator) (selective estrogen receptor modulators)
  - For somebody who has breast cancer, you might have inhibition of estrogen receptor activity in the breast versus pro-estrogen activity in other areas of the body like bone
  - You can sort of choose where you get the activity you want and not impact the health of other areas of the body

***This idea [from SERMs] was adopted for SARMs ‒  they tweaked and modified anti-androgens to make these compounds that would interact with the androgen receptor in a way that was tissue specific and try and get pure anabolic activity with almost no androgenic***

- Proportionally it’s more successful probably than anabolic steroids, but the ceiling of anabolic activity seems to be lower
- When people use SARMs, they do not gain as much muscle as when they use anabolic steroids
- And oftentimes in their quest for achieving a similar muscle building outcome, the higher and higher the dosage gets, the less selective it becomes
  - It’s almost like [beta blockers](https://en.wikipedia.org/wiki/Beta_blocker#) for example, as you get higher and higher [doses], they become less receptor selective and you get more broad-spectrum [effects]

**What are the most potent or commonly used SARMs?**

- [LGD-4033 ( it’s called Ligandrol)](https://en.wikipedia.org/wiki/Ligandrol)
  - These compounds often get traded around companies so often that they have new code names every time Derek checks
  - He thinks the most recent one turned into VK-5211 by Viking Therapeutics, and it was in [phase II](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Summary) trial for hip fracture patients
- [Ostarine (also known as Enobosarm)](https://en.wikipedia.org/wiki/Enobosarm) was probably the most well-known SARM, but it has not been FDA-approved and seems to have not hit the target endpoints that they wanted, although it looked effective
  - Oftentimes women who are trying to achieve a physique to step on stage to try and bridge the gap between not using anything and using steroids, they will go for something like an Ostarine and they don’t viralize themselves when they take it

**Are these banned compounds in natural bodybuilding?**

- Yeah, and they’re super detectable because they’re not supposed to be in your body at all

**How does one get these if they are in a phase II clinical trial?**

- Some compounding pharmacies will make them
- Derek has heard some wild nutty stuff, like people being prescribed [Tren](https://en.wikipedia.org/wiki/Trenbolone)
  - How does your pharmacy make Tren?

**More about Tren**

- [Tren](https://en.wikipedia.org/wiki/Trenbolone) is classified as a steroidal [SARM](https://en.wikipedia.org/wiki/Selective_androgen_receptor_modulator)
- It was prescribed to women in the ‘80s
- It was also used to beef up cattle (might even still be)
- It’s super anabolic, but it has very odd progestogenic activity
  - It interacts with the progesterone receptor and causes severe night sweats (called “Tren sweats”)
  - It also has a weird side effect called “Tren cough,” no one can be sure of what is causing it
    - It’s one of the only drugs associated with a prevalence of a severe coughing fit, like your having an allergic reaction after you take it
    - You inject it and then feel a sudden tightness in your chest, then within about 20 seconds you’re on the floor hacking up a lung for two minutes
- Peter recently had a patient who was seeing some fancy doc in LA who had him on a high dose of Tren and GH
  - The problem is getting people off these things, and luckily he wasn’t on it for very long
- Derek points out, “*Those compounds are more suppressive too because they interact with the progesterone receptor significantly. So it’s like you get the negative feedback not just to AR- ER, but PR as well.*”

**Were you on some of those? Did you talk about Deca and Nandrolone?**

- Yeah, [Deca](https://en.wikipedia.org/wiki/Nandrolone) is close to the more pure anabolic side
  - It’s not near the selectivity of a SARM at a therapeutic dose
  - Interestingly enough, it’s the only steroid that you can probably use at a dose that will ***result in bodybuilder-level results (muscle building) without hair loss***
  - It gets so complicated when you think of the pharmacology of this stuff because it will 5⍺-reduce into a [dihydronandrolone](https://en.wikipedia.org/wiki/5%CE%B1-Dihydronandrolone), which is almost no androgenic activity
  - So in the muscle where you have a relative absence of 5⍺-reductase, you will retain the anabolic properties of Nandrolone where you want it, but then in your scalp it’ll 5⍺-reduce into this metabolite dihydronandrolone where it has almost no androgenicity

**Do bodybuilders even take testosterone at this point?**

- Almost always

*Why are they hitting testosterone when they have all of these designer anabolics that seem to have an advantage over testosterone in every way?*

- Testosterone is the base, because it provides your estrogen base layer of neuro-protection
- The only other compounds that could act as replacements for testosterone are things that are potent substrates for [aromatase](https://en.wikipedia.org/wiki/Aromatase#) too
  - But even then you get these synthetic estrogen metabolites that have less predictable activity
    - For example, [D-Bol](https://en.wikipedia.org/wiki/Metandienone) converts to [methylestradiol](https://en.wikipedia.org/wiki/Methylestradiol), which the potency of it at the estrogen receptor is not as predictable
    - It doesn’t have as predictable of outcomes in terms of providing the base layer of what you want from a broad-spectrum, perfectly balanced androgenic, that  converts to estrogen where you want in tissues, to protect the brain to some extent
    - Granted, at super physiologic dosages you’re in neurotoxic territory, and certainly you’re not going to protect yourself with a base of test, but it’s better than no test for sure or no estrogen

*When you’re saying it’s super physiologic doses, do you mean super physiologic doses of all of these other hormones?*

- Yeah, because there’s no actual physiological level of them
  - It’s just more androgen burden on your body, exceeding what it would be from a standpoint of natural testosterone production

## Anabolic steroid and testosterone regimen of professional bodybuilders and the downstream consequences [2:36:15]

**For an IFBP, top 50 in the world bodybuilder, what percentage of the year is he on some anabolic steroid?**

- An anabolic steroid including testosterone?
- 90-100%
- Peter surmises, “*They basically have accepted the fact that they’ve completely suppressed and lost any endogenous production for life. And it’s now just a question of how they cycle up the testosterone plus or minus the other anabolic?*”
- Sort of
- Derek has seen firsthand multiple bodybuilders who’ve been shut down for decades, come off and restore natural function

**Are they using** [**FSH**](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)**?**

- Some of them use [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin)
- And just coming off the drugs and waiting long enough
- But it begs the question, would they have been there had they not used the drugs until then?
  - Is that just what is representative of where they declined to naturally or is it a permanently lower ceiling potential because they’ve inhibited organ function for so long?
    - You can’t really say for certain

**Do we have data on people who have been on anabolic steroids for five years or greater and the ability to forget spermatogenesis, just regain endogenous testosterone production?**

- Yeah, it’s sparse, but it exists
- There is almost no literature on it
- Derek believes there is a study that shows the recovery capacity and there are people who recover function
- It’s just relatively arduous if you don’t know what you’re doing when it comes to post-cycle therapy
  - Because you might have clearance of hormones and go to a crashed hypogonadal level until you hopefully kick in with gonadotropins and hopefully respond to those and hopefully restore production to a level that provides symptom relief
    - And that process isn’t instant
    - You have to bleed these hormones out of your system if you’re using long-acting compounds (which most people are)
- So that requires a lot of thought around bridging into your recovery and how you go about doing that
- People have to be implementing as the androgens clear
  - They would hopefully be on hCG to begin with, to preserve testicular function

**Are these guys taking hCG the entire time they’re on these other drugs to just maintain some testicular volume?**

- Nowadays, it’s becoming more understood that it’s probably important, but back in the day it wasn’t
  - Even Derek didn’t do it
  - He was told it doesn’t matter; you will just recover fine when you want to come off
- More people are becoming aware that stimulating activity in the [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) is of reasonable importance, almost certainly to retain and ease your transition back into recovery while you’re on drugs

**At a bodybuilder’s lowest time throughout a year, how much testosterone would they be on?**

- Some people they think that they’re cleaning out by taking a month off
  - Some of them worked their way out of their system by then
  - But they’ve been on grams of stuff that’s achieved steady state and you’re just clearing 80% of it or something
  - And then you’ve never actually gotten all of that out of your system and recovered function, which could take months
  - So oftentimes they have either residual androgens in their system for the time they’re trying to clear, or most of them are staying on a base of TRT to bridge between blast phases, which are your high exposure points
- Those bridges of TRT are not actual TRT doses, it’s fitness industry TRT where everyone’s dose is 200 minimum
- Peter adds, “*They cycle up during contests. Obviously professional bodybuilding is not tested, so the understanding is you’re going to take anything and everything as often as you want.*”

**Do they take a more middle of the road set of compounds as they’re bulking up and then move to the more pure anabolic less water retention as they’re leaning out?**

- In general, in an off-season when your goal is protein accretion, building muscle… they still use a ton of stuff
- They will use less when they are preparing for a contest
- The thought is, “*When I am trying to diet it down aggressively. When I’m in a calorie deficit, I need more help on the anabolics*.”
  - Even though, at the end of the day, the threshold needed to preserve tissue is a fraction of what they’re using

***To build muscle, they will typically be using a base of testosterone plus one or two anabolic agents***

- In general, it’s going to be a [Primobolan](https://en.wikipedia.org/wiki/Metenolone_acetate) and [Nandrolone](https://en.wikipedia.org/wiki/Nandrolone) or something

**How many total mg? Are they used one-to-one?**

- No, it depends on the person and how sensitive they are to estrogen
- There’s also interaction with DHT derivatives, for example; they also compete for aromatase
- Derek has seen people on the same dose of testosterone with and without a synthetic DHT derivative have significantly lower estrogen without an aromatase inhibitor
  - So they’re actually lowering their estrogen input through competing for aromatase simply by using a synthetic anabolic on top
  - So you’ve got to modulate that accordingly too
- Oftentimes if you’re a very estrogen prone individual or you get [gynecomastia](https://en.wikipedia.org/wiki/Gynecomastia) easily (the male breast tissue development), these are things you are concerned of when you are pushing your dosages to levels that your body cannot regulate on its own to prevent tissue formation
- At TRT levels, most people will have no issues with gynecomastia development if they have a good protocol in place and they’re not obese
- But at super physiological doses of testosterone (not necessarily the case) you might be able to modulate that activity down by competing for aromatase with your Primobolan or your [Drostanolone](https://en.wikipedia.org/wiki/Drostanolone)
- And then you get to the progestins like Nandrolone, which seem to have an additive effect because progesterone receptor agonism seems to be a stimulation
  - It actually provides a stimulative input on breast tissue development too
- There’s other things besides estrogen that stimulate breast tissue
  - [GH](https://en.wikipedia.org/wiki/Growth_hormone) and [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) stimulate breast tissue development

***Estrogen, progesterone, prolactin, these are all things you have to consider when you’re using which drugs***

**How do guys navigate this?**

- Not well, typically
- Even at the pro level, they often just take random shit
- Even when you look at the guys on the Mr. Olympia stage

> “*Responding well does not equate to health often*”‒ Derek

- There’s multiple ways to skin a cat, and you can still gain similar amounts of muscle with all these compounds in general, but the way you arrive there just might be more side effect, burdensome or problematic and fill in the blank area

**How many of these guys require surgery for** [**gynecomastia**](https://en.wikipedia.org/wiki/Gynecomastia)**?**

- Most
- They proactively do it
- Guys will choose their drug protocol based on how gyno prone they are to those drugs
- Derek has seen people abuse dosages of aromatase inhibitors, serums, just to tolerate the androgen inputs
  - Some of the drugs that are substrates for aromatase
  - The thinking is they are using drugs needed to gain the muscle, but they’re also going to get gyno development
  - So then they’re going to aggressive use [Nolvadex](https://en.wikipedia.org/wiki/Tamoxifen) and aromatase inhibitors while using the androgens to prevent gyno, so they can gain the muscle without the [effects of] estrogen
    - You can imagine the androgenic signaling plus no estrogen ‒ it’s horrible constellation of negative, problematic factors
- Peter thinks this is a complicated regime and is surprised there aren’t more health consequences of this
- Derek points out, “*We see early deaths all the time in the bodybuilding world.*”
  - At least these individuals are lean; they are typically following meticulous diets and training regimens
  - Their sleep is usually dialed in too
  - When people ask, “*Where are the bodies?*” Derek thinks it hasn’t been documented as it should be
    - There are a lot of people you never hear about because they’re not a big name in the industry; they have heart failure at 27 or something

## The challenge of accurate hormone testing in the presence of anabolic steroids and supplements [2:44:45]

**How do you measure this stuff? Which other compounds show up on a testosterone check?**

- Many of them show up with [immunoassay](https://en.wikipedia.org/wiki/Immunoassay) testing
- Take for example, testosterone plus Nandrolone: it is derived from testosterone, and often you’ll see a cross detection
  - You might have an elevated testosterone level through a standard immunoassay that is not reflective of your testosterone dosage you’re using
  - And similarly, we see things like estrogen metabolites that are synthetic, artificially inflating your estradiol on [ECLIA](https://en.wikipedia.org/wiki/Electrochemiluminescence#ECLIA) as well
- Peter finds that there are a group of **supplements that seem to give artificial readings** of enzyme-based testing of estradiol, but it’s not clear which supplements are the problem
- Derek points out, “*There’s certain things that you shouldn’t take before a blood test even like Biotin*.”
- [Liquid chromatography with tandem mass spectrometry (LC-MS)](https://en.wikipedia.org/wiki/Liquid_chromatography%E2%80%93mass_spectrometry) is the highest sensitivity of testing you can get for total testosterone and free testosterone
  - Derek recalls that equilibrium dialysis was the gold standard, and if you don’t use those, you will end up with cross-detection
  - When he did Nandrolone monotherapy, he recalls seeing on immunoassay for total testosterone and then calculation for free testosterone that his numbers were in the reference range for testosterone
    - There’s no Nandrolone test, so you should have had a hypogonadal-looking testosterone profile and estradiol
    - But a cheap, entry-level immunoassay testing probably would have shown testosterone levels in the normal range still
    - People might conclude that they’re not suppressed on Nandrolone

> “*It’s very nuanced and it’s not like you’re taught to look for this stuff*”‒ Derek

- Often people aren’t prescribed this stuff to begin with
- But in the bodybuilding world, it’s pretty important to know where your **estrogen** is
  - Thinking that you’re good when you might have a DHT derivative competing for aromatase, and your [E2](https://en.wikipedia.org/wiki/Estradiol) looks in range on paper when it’s actually crashed into single digits
    - This is problematic for brain damage, cardiovascular disease, and bone loss

## The use of Clomid, hCG, and enclomiphene [2:47:15]

**Tell folds a little about Clomid and hCG: how they’re used and some of the pluses and minuses of each**

- [Human chorionic gonadotropin (hCG)](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) is present in pregnant women’s urine in significant quantities
  - As absurd as it sounds, it’s often pulled out and purified because it can be used to stimulate the [luteinizing hormone receptor](https://en.wikipedia.org/wiki/Luteinizing_hormone/choriogonadotropin_receptor) similarly to what endogenous [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) does
  - It looks similar to LH, and it mimics the effects of luteinizing hormone in the body
    - This is why it is commonly used in fertility regimens for men, because you can essentially replicate the LH signal to your testes that may be suboptimal if you have low [gonadotropin](https://en.wikipedia.org/wiki/Gonadotropin) output or non-existent if you have [HPTA](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93gonadal_axis) suppression from your exogenous testosterone you’re using
- If you use [TRT](https://en.wikipedia.org/wiki/Androgen_replacement_therapy), you can pretty reasonably expect that your LH and FSH will go down to either non-detectable or close to there depending on what you’re using and the dose
- Replacing that LH is of pretty high importance if maintaining fertility is important to you
  - You will experience testicular atrophy if you do not replace the LH somehow
    - Whether it’s through recombinant LH (which is almost never used), or [HMG](https://en.wikipedia.org/wiki/Menotropin) (which is typically not used either)
    - The cheapest, lowest barrier to entry predictable thing is hCG (which is not that cheap)
    - Clomid, the primary clinical use is in women for fertility (for IVF prep)
    - In men, Clomid is a [selective estrogen receptor modulator (SERM)](https://en.wikipedia.org/wiki/Selective_estrogen_receptor_modulator)
- [Clomid](https://en.wikipedia.org/wiki/Clomifene) interacts with the estrogen receptor in either a positive or negative way in that it could stimulate activity or prevent estrogen from binding to it, and interacting and providing estrogen related activity in certain tissues
  - It’s selective in the way it does this
  - Clomid has anti-estrogenic activity in the hypothalamus, so it tricks your brain into thinking it’s estrogen deprived
    - And the response is to make more testosterone to aromatize into estrogen
    - So you uptick your GnRH output to the pituitary, which will increase LH and FSH, which increases testosterone
    - You can intervene with that compound to trick your body to make more testosterone

**Why Peter stopped using Clomid with patients**

- About four years ago, Peter stopped using Clomid with patients because they noticed something that was very efficacious (more efficacious than hCG), easier, and cheaper
- It’s a pill; they would typically prescribe 50 mg 3x a week
- So when Derek said 50  mg 3x a day, Peter was like “*Oh, my God.*”
  - When they say the expression “on steroids,” you really understand where this is coming from
- It is oral, cheap, and works better than hCG; across the board, this was their drug of choice
- But they noticed almost without exception, that every guy that was taking this would over time develop and elevated level of a sterol called desmosterol
- [Desmosterol](https://en.wikipedia.org/wiki/Desmosterol) is the penultimate molecule of cholesterol synthesis in one of the two cholesterol pathways
  - So cholesterol has a bifurcated synthetic pathway, and on one side the penultimate molecule is called lathosterol, and on the other side, it’s desmosterol
- This level of desmosterol was going very, very high, like anywhere from 5-25 times higher than baseline
  - This was a staggering increase, not subtle
- The obvious explanation was that Clomid was inhibiting the enzyme that converts desmosterol to cholesterol, that last step
  - Now, it did not result in a reduction in cholesterol because there’s another pathway, but initially, we didn’t really think much of it.
- Then one of Peter’s colleagues pointed out that the very first drug that was ever approved for cholesterol reduction [triparanol](https://en.wikipedia.org/wiki/Triparanol) blocked that enzyme
  - Even though you had redundancy in the other pathway, it still resulted in a reduction of total cholesterol
  - Back in the ‘60s people didn’t understand LDL and simply thought that lower cholesterol is better
  - The drug got approved, but was later pulled off the market because people on the drug had a higher incidence of cardiovascular events
    - It was never clear why
    - The best explanation was that desmosterol is at least as atherogenic than cholesterol
- That’s the reason they stopped using Clomid
- For that use case, they went over to hCG
- The good news is that everybody’s desmosterol returned to normal
- It still creates a bit of trouble because there are patients who really miss being on Clomid and they hate the inconvenience of hCG, but they’re not quite ready to go onto testosterone

**This brings up the** [**enantiomer**](https://en.wikipedia.org/wiki/Enantiomer) **of Clomid (or clomiphene) called enclomiphene**

- Clomid has two [stereoisomers](https://en.wikipedia.org/wiki/Stereoisomerism): [zuclomiphene](https://en.wikipedia.org/wiki/Zuclomifene) and [enclomiphene](https://en.wikipedia.org/wiki/Enclomifene)

***Enclomiphene is seemingly the more selective and actually antagonistic in the hypothalamus***

- It’s doing the thing you want from the Clomid, whereas the zuclomiphene is providing almost an anti-androgenic type activity in a way that is not as selective as a pure serum
- When you think **serum**, you’re thinking something that antagonizes estrogen receptors purely in the hypothalamus but then leaves estrogen activity everywhere else
  - Bone integrity is maintained, cardiovascular, etc.
  - Everything is kind of backfilled accordingly except for right there in your brain where you want your brain tricked into thinking “*Make more testosterone*”
- Enclomiphene also has a shorter half-life (about 10 hours), whereas zuclomiphene is days or something
  - So if you have a bad side effect or something, you can’t get off it as easily with Clomid because a big chunk of it is zuclomiphene
- The idea of getting FDA-approval for enclomiphene was this a more pure version of the drug that does what we want
  - There’s been at least one study that showed improved outcomes in women who took enclomiphene, ***but it never made it through FDA approval***
    - But this didn’t stop people from prescribing it and using it
- Peter points out, “*It is not an FDA-approved drug, and yet compounding pharmacies are illegally making this. This is not legal.*”
- Peter has patients who come to him from other docs on this drug asking for a prescription and he won’t write it
  - Now with that said, it is legal in Europe
- Derek asked, “*Do you know why it didn’t get approved?*”
- Peter doesn’t
  - His understanding is that it has not completed a [phase III](https://en.wikipedia.org/wiki/Phases_of_clinical_research) trial
  - He doesn’t want to represent it as a bad drug
  - He wishes he could see more patients on so he could measure their desmosterol and see if it’s having the same effect
- If it’s having efficacy without that side effect, Peter would be interested, but we can’t do that without FDA approval
  - It’s still in the investigational process somewhere
- He is not sure how this is being synthesized by a compounding pharmacy; it’s not legal until it is FDA-approved

**Ads on social media**

- Derek gets hit with [V shred ads](https://vshred.com/sp/survey/survey-ga/?utm_source=google&utm_medium=search-kendago&utm_campaign=quiz&utm_content=572178748767&g_network=g&g_adid=572178748767&g_keyword=v%20shred&g_adtype=search&g_adgroupid=135258107441&adid=572178748767&g_campaign=53.+Vshred+search+-+Brand+Manual+1.2%24+US+only&g_keywordid=kwd-311433639326&g_campaignid=15731078315&g_acctid=565-438-4971&ad_channel=google&ad_id=572178748767&utm_source=google&utm_medium=g-kendago&utm_campaign=15731078315&utm_content=572178748767&ADID=mdEEEgoogleSSSntEEEgSSScidEEE15731078315SSSadidEEE572178748767SSSlocEEE9005459&gad=1&gclid=Cj0KCQjwpc-oBhCGARIsAH6ote8ppT80iu8X31VIsGe-4LzXh_n9VbhNnaTJxqNFx4qOFOP_vlUXQS0aAkDdEALw_wcB) and ads for enclomiphene and clomiphene
- There’s a prominent one that basically has a checklist of why enclomiphene is superior to testosterone injections
  - It’s easy to use
  - It’s a pill
  - It will not suppress you
  - These are all technically true, but it’s obviously a misleading way to represent it
  - And then it’s just mass cookie-cutter prescriptions of their protocol
    - They represent it like it’s a proprietary thing they made but it’s enclomiphene

> “*It seems super misleading in a way that is almost scary that they’re representing it like it is superior for all people regardless*.”‒ Derek

- We don’t know for sure that it’s a better drug, and it doesn’t mean that antagonizing estrogen receptors is a good thing
- Derek doesn’t think that’s a sustainable treatment protocol for your entire life
- The reality, and it’s not as easy to adhere to, but Derek would assert that stimulating exactly what you want to do directly with an hCG plus recombinant FSH is a superior outcome
  - Rather than perpetually inhibiting estrogen activity

***There’s no drug that’s purely selective exactly where you want and it’s perfect***

**The issue Peter has**

- If you took two guys and put one of them one exogenous testosterone and one of them on clomiphene (brand name Clomid)
  - They were identical in every way in terms of readout, equal testosterone, free testosterone, and estradiol
- Peter thinks there’s an argument to be made that the guy getting exogenous testosterone has a better outcome because he’s not getting the central inhibition of estrogen
  - His libido is better, his mood is better, his sleep is better
- Derek points out, “*Some of the mood dysregulation on Clomid, wild.*”
  - Even when the people who report that are on the precipice of hypogonadism (already with a very low quality of life as it is), for them to report a decrease in vitality and notable anti-estrogenic activity
- Peter agrees, “*As a general rule,  if you start to muck around with receptors in the brain, you should have a pretty good idea of what you’re doing.*”

## Concerns about fertility: comparing the use of testosterone and hCG [3:00:30]

**Compare a guy who’s on testosterone versus a guy who’s on hCG**

- If you’re on a high enough of hCG, you’re going to see FSH and LH suppression
- They both have a very high testosterone
- They both have completely suppressed LH and FSH
- In the case of the guy on high testosterone, his [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) are doing nothing
- The guy on the high hCG, his Leydig cells are cranking out testosterone
- But in both cases there’s enough testosterone being made that the pituitary has stopped making LH and FSH

**So what happens to these guys when you stop testosterone?**

- Let’s assume they’ve both been on their protocol for several years
- The guy who has sustained organ function is almost certainly going to have a smoother transition because he has maintained the natural function and output of the organ responsible for intratesticular testosterone the entire time versus the other guy has literally deprived the tissue so significantly that it’s a fraction of the size
- So trying to compare a guy recovering with testes half the size or less compared to a guy who has fully functioning testes that have been maintained
- That guy [on hCG] just needs to discontinue and get rid of that feedback inhibition, and he’s likely going to return to natural function within short order
  - Pending his gonadotropin output from the pituitary is satisfactory
    - It’s to be determined if that guy is going to have adequate pituitary output, given a bunch of other factors, lifestyle, etc.
  - Probably that guy is going to be okay
- The question then is, why did that guy go on HCG to begin with?
  - Presumably because he had low LH output
  - So he’s probably going to go back to low LH output unless something dramatic has changed in his baseline lifestyle, diet
    - He’s older now with less testicular function just as a result of age

***The guy on hCG has more potential to recover to whatever his baseline was than the other guy; the guy on testosterone is going to have a longer, more arduous road***

- For the guy on testosterone, you not only have to get the testosterone out of your system to stop having negative feedback, now you have to get the pituitary output back to some satisfactory amount
  - If your baseline was low (presumably this is why he began TRT)…
- The hCG guy is almost certainly going to be better off than the test guy

**Do you think that there’s a way around it on the hCG guy, if you dose him more frequently, like you take the same dose?**

- Peter typically doses hCG twice a week
- A starter dose would be 750 units twice a week (or 625 units)
  - About 8 weeks with a vial
  - Then we generally just stop
- If you’re not getting an amazing response at 2,000 units twice a week, you’re wasting your time and money
  - Peter would never go above that

**What doses are bodybuilders using?**

- Most aren’t using it, but the ones that are aren’t following the recommended doses in the literature
- To maintain intratesticular testosterone at 100% while suppressed on exogenous androgens, the dose is around ***375 IU every other day*** (not a herculean dose)
  - This is assuming that you’re starting at full function and you’re not trying to get back up from zero to 100 (that’s a big difference)
- If you pin more frequently, every day versus twice a week, you’re going to maintain more stable serum concentration
  - Derek would have to double check the half-life of hCG, but he believes it is 24-36 hours
  - With this schedule, you’re not going to get as aggressive spikes in Leydig cell activation
  - So you’re probably going to have a more natural output of testosterone
    - But at the same time, if that level of testosterone is satisfactory to achieve the hormone levels that your body needs from an androgen, then you should shut down
    - The only way would you wouldn’t is either (A) hCG was too low, (B) your response to hCG was too low, or (C) your dosage frequency was not ideal so that you had little blips of time where you were essentially deprived and your body reacted to it (which is not an ideal outcome either)

***Derek would recommend more frequent dosing probably just for stability and a better side effect profile, but how realistic is that for patient adherence?***

**One more thing about hCG**

- Because you had that specific example of FSH being suppressed, how do you know if the negative feedback is through the hCG dose amplitude versus the testosterone (that comes from it)?
- Derek found a really good [study](https://academic.oup.com/jcem/article-abstract/34/6/1080/2685832) where they used hCG at 4,000 IUs in men who had normal gonadal function and from those who are poor non-responders to hCG, you can discern from that if it’s the testosterone or the hCG
- The people who responded used Clomid after
- Interesting, it suppressed FSH in the people who responded to hCG but not those who did not
- From that, you can discern that it’s not necessarily the LH interaction, it’s more the downstream effects of androgen receptor activation subsequent to that E2 estrogen receptor activation (the negative feedback)

***That actually tells us that it’s not that hCG is mimicking too much LH, it’s that the LH receptor doesn’t tell your brain “Stop  making testosterone” ‒ it’s the testosterone output***

- To confirm that, they gave [Clomid](https://en.wikipedia.org/wiki/Clomifene#Pharmacology) to the men who responded to hCG to see if they could attenuate the FSH suppression, and they could

***From that, you can assert that estrogen is a huge negative feedback regulator***

- If you can maintain FSH at baseline with a high 4,000 IU dose of hCG with pushing your total T way up and use the serum concurrently and prevent FSH suppression, it tells you that it’s really downstream to the LH activation
  - Because it’s literally the testosterone output and the estrogen
  - Because you’re still maintaining FSH with the same androgen signal and the LH receptor signal
- Derek adds, “*One thing I can say from the literature I’ve seen, too, is intratesticular androgenic signaling seems to be the primary determinant on spermatogenesis far and above FSH receptor activation.*”
- Another way you can assess this is with [finasteride and dutasteride](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_inhibitor)
  - They reliable result in a significant decrease in sperm quality and count (all metrics of fertility regarding semen parameters)
- The intratesticular free androgen signaling seems to be the main dictating variable on spermatogenesis, and you can find even in people who have minimal or no FSH at all, getting them fertile on hCG only and maintaining it
  - Now, there are certain people who don’t seem to respond as well
- In general, you’re diminishing your possibility of fertility when on 5⍺-reductase inhibitors
- So again, it’s not just intratesticular testosterone
- This is confirmed when a 5⍺-reductase is applied, DHT goes down, and T goes up 15-22%
  - Nothing about the output of testosterone is changing other than DHT goes down when you have a 5⍺-reductase inhibitor

***Fertility goes down when DHT goes down; it’s not just the testosterone, it’s broad androgenic signaling in the testicles***

**When DHT goes down, testosterone goes up by how much?**

- With finasteride, about 15% when you’re using a 5 mg Proscar tablet for benign prostatic hyperplasia
  - You’re getting a 70% systemic DHT inhibition, which pushes your T and estrogen up by 15%
- Peter finds this interesting because regular T conversion to DHT is not that high, rarely >10%
  - It seems you disproportionately getting a bump in T to the inhibition
- Derek thinks this gets into the modulation of how much DHT occupies [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) and how much free testosterone there is relative…
  - And DHT also because the activity of it is going to be inhibited dramatically more proportionally to testosterone because its affinity for SHPG is about 5x [greater]
  - Derek would need to write it out to make more sense of it instead of just trying to think all the way upstream

***But in general, the takeaway Derek has seen is having high intratesticular androgenic signaling is the only thing that’s mandatory for spermatogenesis and FSH receptor activation***

- With some level of FSH, you can still maintain or achieve spermatogenesis with minimal to almost no FSH
- And in those individuals that still need a push, they either lack androgenic signaling or there’s too much oxidative stress, potentially
  - They need to utilize things like [ubiquinol](https://en.wikipedia.org/wiki/Ubiquinol), [NAC](https://en.wikipedia.org/wiki/Acetylcysteine), [carnitine](https://en.wikipedia.org/wiki/Carnitine), [creatine](https://en.wikipedia.org/wiki/Creatine)… sometimes supplements actually make a difference
  - Or get off their 5-alpha reductase inhibitor or a myriad of things
- A little bit of recombinant FSH on top of that base of ensuring that you have adequate intratesticular testosterone can be the differentiating factor on fertility for a minority of people, but it’s not mandatory
- At the end of the day, when Derek hears people talking about, “*Maybe we should use Clomid instead of hCG because we’re seeing FSH suppression*,” he’s thinking a little bit of FSH is probably a much better alternative (even though it’s cost prohibitive)

**What is the cost of recombinant FSH?**

- It depends on the pharmacy, but Derek heard the other day there was a pharmacy in Texas that prescribes 1,500 IU vials for a couple hundred bucks
  - Which sounds cheap
  - The cost may depend on if you’re getting [Gonal](https://www.rxlist.com/gonal-f-drug.htm) or which brand you’re getting

**What is a typical dose of FSH?**

- 50 IU every other day; you can go as  high as 75 every day
- That’s still significantly cheaper than growth hormone

## The use of BPC-157 peptide for healing injuries [3:12:00]

**Do you know anything about the peptide** [**BPC-157**](https://en.wikipedia.org/wiki/BPC-157)**?**

- This stands for body protection compound
- It’s a peptide produced endogenously in your gut
- It seems to have some angiogenic properties that can be useful for certain injuries
- Derek has seen some pretty remarkable improvements in minor tears and certain lesser injuries (not complete tears), especially in areas with low blood flow (like a tendon)
- But he also worries about cancer and cell proliferation from something that’s pro-growing blood vessels

**Let’s assume you tear your rotator cuff, does it need to be injected locally for it to have maximum efficacy?**

- This was one of the bro myths we were taught back in the day
  - That it’s injected right into the injury site
- Now, Derek doesn’t believe that to be the case
- The last he heard, that you don’t need to do that

**Do we hold out any semblance of hope that we might get a study that would shed light on this, because how could we ever possibly know the counterfactuals here, and how could we possibly disentangle the single user experience on all these things?**

- Derek doesn’t think so
- It’s something so many people use at this point
- He imagines you can’t patent anything or make any money off studying it
  - It’s at a point where so many compounding pharmacies sell it
- Derek doesn’t think it’s *not* good to use, and if he had a minor injury somewhere that needed more blood flow, he would use it
- He also thinks that a lot of people use it proactively too often
  - For something that is increasing [VEGF](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor) (that is super correlated with cancer growth), to use it preventatively would freak-out Derek
  - A lot of athletes use it as a preventative measure to avoid injury or rehabilitation when it’s not necessary
    - In Derek’s opinion, this is overkill and risky as hell

**There are so many other thing Peter wasn’t to talk about in a part-two episode**

- Nutrition, appetite, appetite suppression
- Ways that people can prevent themselves from being fooled by all the charlatans out there
  - People who are well-informed will immediately recognize the buffoonery
  - But these people wouldn’t be as popular as they are, they wouldn’t be making tens if not hundreds of millions of dollars if there weren’t people who were falling for what they’re talking about
  - Talk about what are signs that maybe what a person is telling you might be too good to be true, a bit of a buyer beware
- They just scratched the surface on fertility and could talk about what an ideal protocol might look like
  - Banking sperm
  - Concerns about getting on TRT beforehand
- How to vet if you  need TRT and criteria that are worthwhile to know
  - Often people are told in clinics, “*Oh, your T is 400. That’s low. Get on test.*”
    - But you might have high AR content and expression, you don’t know that you need more testosterone to actually achieve
- Some of the most jacked guys Derek knows have 450 total T and feel fine
- There’s a lot of nuance that goes into that, and not just identifying content charlatans, but medical providers, even your own doctor potentially
  - Knowing who is looking out for your best interests
  - Educating yourself at a base level is almost necessary nowadays to wade through the nonsense

§

## Selected Links / Related Material

**More Plates More Dates YouTube channel**: [More Plates More Dates](https://www.youtube.com/channel/UCoR7CHkMETs3ByOv74OAbFw) | YouTube | [1:15]

**More Plates More Dates podcast**: [More Plates, More Dates](https://moreplatesmoredates.com/podcasts/) | Host Derek | [1:15]

**More Plates More Dates website**: [More Plates, More Dates](https://moreplatesmoredates.com/) | [1:15]

**Episode of** ***The Drive*** **on generic drugs**: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) (September 16, 2019) | [13:15]

**Growth hormone and bone density**: [48:00]

- [Two years of treatment with recombinant human growth hormone increases bone mineral density in men with idiopathic osteoporosis](https://pubmed.ncbi.nlm.nih.gov/12414848/) | *The Journal of Clinical Endocrinology and Metabolism*(P Gillberg et al 2002)
- [Effects of growth hormone therapy on bone density and fracture risk in age-related osteoporosis in the absence of growth hormone deficiency: a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/29030774/) | *Endocrine* (M Barake et al 2018)
- [Growth Hormone in Aging](https://www.ncbi.nlm.nih.gov/books/NBK279163/) | *Endotext* (J Garcie, G Merriam, & A Kargi 2019)
- [The Long-Term Effects of Growth Hormone Replacement on Bone Mineral Density and Trabecular Bone Score: Results of the 10-Year Prospective Follow-up](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8884382/) | *Physiological Research* (P Vanuga et al 2021)

**Episodes of** ***The Drive*** **that discuss post-finasteride syndrome**: [1:43:45]

- [#260 ‒ Men’s Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.](https://peterattiamd.com/mohitkhera/) (June 26, 2023)
- [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) (October 2, 2023)

**Side effects from 5α-reductase inhibitors**: [Effect of 5α-Reductase Inhibitors on Sexual Function: A Meta-Analysis and Systematic Review of Randomized Controlled Trials](https://pubmed.ncbi.nlm.nih.gov/27475241/) | *The Journal of Sexual Medicine* (L Liu et al 2016) | [1:47:45]

**Testosterone level in men by decade**: [Longitudinal Effects of Aging on Serum Total and Free Testosterone Levels in Healthy Men](https://academic.oup.com/jcem/article/86/2/724/2841070) | *The Journal of Clinical and Endocrinology & Metabolism* (S Harman et al 2001) | [1:57:45]

**TRAVERSE trial**: [Cardiovascular Safety of Testosterone-Replacement Therapy](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025) | *NEJM* (A Lincoff et al 2023) | [2:03:00]

**Episode of** ***The Drive*** **on men’s sexual health**: [#260 ‒ Men’s Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H](https://peterattiamd.com/mohitkhera/). (June 26, 2023 | [2:07:45]

**Estrogen is not the “bad guy”**: [Gonadal Steroids and Body Composition, Strength, and Sexual Function in Men](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168) | *NEJM* (J Finkelstein et al 2013) | [2:16:00]

**hCG study**: [FSH Suppression During Short Term hCG](https://academic.oup.com/jcem/article-abstract/34/6/1080/2685832) | *The Journal of Clinical Endocrinology & Metabolism* (E Reiter, H Kulh, & L Loriaux 1972) | [3:06:30]

§

## People Mentioned

- [Jo Lindner](https://barbend.com/joesthetics-jo-lindner-obituary/) (bodybuilder who died at age 30) [1:26:15]
- [Mohit Khera](https://www.drmohitkhera.com/about/) (Professor of Urology at Baylor College of Medicine, expert in [men’s sexual health](https://peterattiamd.com/mohitkhera/)) [2:07:45]

§

![](https://peterattiamd.com/wp-content/uploads/2023/10/bio-derek.png)

##### Derek: More Plates, More Dates

Derek is a Canadian bodybuilder from Vancouver and the host of *More Plates More Dates*, a podcast, YouTube channel, and website. His YouTube channel has 1.39 subscribers, and he posts new videos almost every day. He uses these platforms to discuss men’s health, diving into the topics of bodybuilding, supplements, fitness, self-improvement, and more. [[greatestphysiques.com](https://www.greatestphysiques.com/male-physiques/derek-more-plates-more-dates/)]

Facebook: [More Plates More Dates](https://www.facebook.com/MorePlates/)

Instagram: [moreplatesmoredates](https://www.instagram.com/moreplatesmoredates/)

Snapchat: [@derek-fit](https://www.snapchat.com/add/derek-fit)

TikTok: [moreplates](https://www.tiktok.com/@moreplates?lang=en)

Twitter: [@Derek\_Fitness](https://twitter.com/derek_fitness?lang=en)

Website: [More Plates, More Dates](https://moreplatesmoredates.com/)

YouTube Channel: [More Plates More Dates](https://www.youtube.com/channel/UCoR7CHkMETs3ByOv74OAbFw)