# #332 – AMA #67: Microplastics, PFAS, and phthalates: understanding health risks and a framework for minimizing exposure and mitigating risk

**Source:** [https://peterattiamd.com/ama67/](https://peterattiamd.com/ama67/)

---

In this “Ask Me Anything” (AMA) episode, Peter tackles a topic that’s been dominating headlines and sparking widespread concern: microplastics and plastic-associated chemicals, including BPA, PFAS, and phthalates. Peter explores the science behind these substances including how and why they’ve become so prevalent, the extent of our exposure, and the potential risks to our health. Most importantly, he provides a practical framework for understanding microplastics and plastic-associated chemicals and minimizing exposure while distinguishing genuine risks from exaggerated concerns.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #67 show notes page](https://peterattiamd.com/ama67/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The complexity of the topic of microplastics and associated chemicals [1:30];
- Definitions: microplastics, BPA, PM2.5, phthalates, and more [6:30];
- The reasons behind the increase in microplastics in our environment and the surge in interest in them [12:00];
- The various ways that humans are exposed to microplastics and nanoplastics [14:00];
- Volume of plastic consumed by humans, and how the body eliminates or absorbs microplastics [16:00];
- How microplastics accumulate in the body, the variability in tissue accumulation, and the challenges in studying their long-term health effects [21:30];
- Limitations of blood tests for microplastics, and the importance of reliable biomarkers for guiding behavior and interventions [26:30];
- The speculative health risks of microplastics, the limitations of current research, and the need for more robust studies [29:15];
- The challenges of measuring microplastics in human tissues, the need for better methodologies, and the importance of critically evaluating study relevance and claims [39:45];
- If it’s unclear whether microplastics actually cause harm, should we still be concerned about exposure? [42:15];
- Strategies to minimize microplastic exposure [45:00];
- The financial cost and effort involved in various microplastic exposure mitigation strategies [51:00];
- The role of airborne microplastics in total exposure and accumulation [1:03:00];
- Chemicals associated with plastics, their role as endocrine disruptors, and the challenges in linking exposure to specific health outcomes [1:04:00];
- BPA: role in plastic production, and its potential developmental risks [1:05:45];
- BPA’s potential health risks: pregnancy, fertility, obesity, and diabetes, and the socioeconomic confounders in the data [1:08:30];
- Regulatory limits on BPA exposure, and practical considerations for reducing exposure [1:12:45];
- The prevalence of BPA in modern products and how to identify it [1:17:15];
- PFAS: chemical structure and purpose in products [1:18:30];
- Why PFAS are considered endocrine disruptors [1:19:45];
- The main sources of PFAS exposure, and practical steps to reduce exposure [1:21:30];
- The potential health risks of PFAS exposure [1:24:00];
- Phthalates: role in making plastics flexible, and presence in personal care products [1:24:45];
- Why phthalates are considered endocrine disruptors [1:25:15];
- The main sources of phthalate exposure, and how manufacturing practices are evolving to reduce exposure [1:26:45];
- Practical strategies to reduce exposure to phthalates in food, air, water, and personal care products [1:28:30];
- Navigating microplastics and associated chemicals: a framework for personalized risk reduction [1:29:30]; and
- More.

---

The Peter Attia Drive

#332 – AMA #67: Microplastics, PFAS, and phthalates: understanding health risks and a framework for minimizing exposure and mitigating risk

---

## Show Notes


---

## The complexity of the topic of microplastics and associated chemicals [1:30]

**Overview of the Episode’s Focus**:

- The AMA will focus entirely on microplastics and other chemicals such as BPAs, PFAS, and phthalates.
- Growing public interest and numerous listener questions have driven the need for this deep dive.
- The discussion aims to address:
  - Whether people should be worried about these chemicals.
  - Which chemicals pose real risks.
  - Practical steps to reduce exposure.

Challenges of researching this topic

- This AMA required the most research and effort compared to any previous episode.
- Peter and his team of analysts dedicated about a month to researching this topic.
- Preparation involved sorting through an overwhelming amount of incomplete and complex information.
- It was hard to organize the topic due to:
  - The sheer volume of conflicting data.
  - A lack of clear, definitive answers.
- Finding Clarity:
  - A night of rest provided Peter with a clearer perspective on how to “land the plane” and present the information effectively.

No Simple Answers:

- Peter emphasized that this is a nuanced and complex topic.
- Listeners should not expect a straightforward or one-word solution.
- The discussion is built on 75 pages of research notes, indicating the depth and breadth of the issue.

Purpose of the Episode:

- To help listeners navigate the uncertainty and asymmetry in available research.
- To define the boundary conditions necessary for making informed decisions.
- To provide a framework for personal risk assessment and exposure reduction strategies.

Peter intends to:

- Acknowledge the gaps in current research.
- Highlight areas where more information is needed.
- Provide guidance without pretending to have all the answers.
- Goal for Listeners:
  - Equip listeners with the tools to make risk-based decisions for themselves and their families.
  - Offer practical strategies for minimizing exposure while understanding where real risks lie.

“*The further from the shore, the deeper the water*.”

## Definitions: microplastics, BPA, PM2.5, phthalates, and more [6:30]

**Microplastics and Nanoplastics (MNPs)**

- Definitions:
  - Microplastics: Plastic particles smaller than 5 millimeters.
  - Nanoplastics: Particles smaller than 1 micrometer (µm).
    - NOTE: 1 micrometer is 1/1,000 of a millimeter (Peter misspoke and said meter instead of millimeter)
- Common Study Classifications: Current research focuses on plastics smaller than 1 millimeter.
- Abbreviation: Referred to as MNPs (Micro/Nano Particles).
- Prevalence:
  - Ubiquitous in the environment:
  - Found in water, food (fruits, vegetables, meat), and air.
  - Present on surfaces of produce and within animal products.

**Bisphenol A (BPA) and Bisphenols**

- Definition:
  - BPA is part of a family of chemicals called bisphenols.
  - Used to produce polycarbonate plastic (rigid plastics).
- Common Uses:
  - Found in products like Nalgene water bottles, epoxies, and resins.
- Current Trends:
  - BPA use has declined over the past 15 years.
  - Often replaced by other bisphenols: BPS and BPF.
  - Uncertainty remains about whether these substitutes are safer.

**Particulate Matter 2.5 (PM2.5)**

- Definition:
  - Airborne particles smaller than 2.5 micrometers in diameter.
- Health Relevance:
  - Particles this small can enter the bloodstream when inhaled.
  - They cross the alveolar air sacs in the lungs into systemic circulation.
- Sources of PM2.5:
  - Mostly from air pollution (not microplastics).
  - Burning wood and fossil fuels (especially coal) are major sources.
  - Natural gas combustion produces less PM2.5.
  - Microplastics contribute only a small percentage to PM2.5 levels.

**Phthalates**

- Definition:
  - Chemicals used to make plastics more flexible and durable.
- Common Uses:
  - Found in plastic products, shampoos, lotions, laundry detergents, and fragrances (they help scents last longer).
- Regulatory Status:
  - Still allowed in food contact materials, though some companies have voluntarily reduced usage.
  - No restrictions currently exist for phthalates in personal care products.
- Primary Exposure Sources:
  - Personal care products are likely the biggest source of exposure for most people.

## The reasons behind the increase in microplastics in our environment and the surge in interest in them [12:00]

**Increased Production and Use of Plastics**

- Historical Context:
  - Plastics are a relatively recent invention, becoming widespread only after the 1950s.
- Desirable Properties Driving Use:
  - Lightweight and durable.
  - High strength-to-weight ratio.
  - Resistant to rotting, corrosion, and shattering.
- Result:
  - The continuous growth in plastic production over the past 70 years has naturally led to more plastic waste and microplastic accumulation in the environment.

**Increased Scientific Focus and Media Coverage**

- More Research Being Conducted:
  - Scientific interest in microplastics has skyrocketed over the last 20 years.
  - Research publications on microplastics have grown exponentially, resembling the growth trend of [Bitcoin from 2010 to 2020](https://www.investopedia.com/articles/forex/121815/bitcoins-price-history.asp).
- The “Drunk Under the Streetlight” Effect:
  - Increased detection may partly result from scientists simply searching for microplastics more actively.
  - As more studies focus on the topic, more findings emerge, creating the perception that the issue is rapidly worsening.

![](https://peterattiamd.com/wp-content/uploads/2025/01/f1-ama67-1024x551.png)

**Figure 1.** Source: [Senathirajah et al. J Hazard Mater, 2021](https://pubmed.ncbi.nlm.nih.gov/33130380/)

- Unanswered Questions:
  - It’s unclear if the reported increase in microplastics over the last 5 years reflects a true rise in environmental presence or is simply due to increased observation and research focus.

Summary

- The surge in awareness about microplastics is due to both:
- Growing plastic production and use since the 1950s, leading to more environmental contamination.
- A dramatic increase in scientific research and scrutiny, amplifying the perception of the problem.

## The various ways that humans are exposed to microplastics and nanoplastics [14:00]

[**Primary Routes of Exposure**](https://www.tandfonline.com/doi/full/10.1080/10643389.2023.2195798#d1e684)

- Inhalation of Plastic Dust and Fibers
  - Airborne microplastics from dust and fibers are inhaled, especially in indoor environments.
  - Smaller particles pose a higher risk due to their ability to enter the lungs.
- Consumption of Contaminated Food and Beverages
  - Micro/nanoplastics are ingested through various foods and drinks.

**Common Sources of Microplastic Contamination**

- Seafood:
  - Fish and shellfish accumulate microplastics due to ocean pollution.
  - Plastics move up the marine food chain, increasing human exposure.
- Salt:
  - Table salt, especially sea salt, often contains microplastic particles.
- Water:
  - Found in both tap water and bottled water.
- Fruits, Vegetables, and Meat:
  - Nanoplastics in soil are absorbed by plants.
  - Livestock may ingest plastics through contaminated feed or environment.
- Beverages:
  - Microplastics are present in drinks like milk, beer, and wine, largely due to their water content.

**Role of the Epithelial Barrier in Absorption**

- External vs. Internal Barriers:
  - The body’s epithelial layers protect against microplastic absorption:
  - Skin provides an external barrier.
  - The gastrointestinal (GI) tract and lungs have internal epithelial linings.
- Size Matters for Absorption:
  - Lung absorption: Particles must be smaller than 2.5 microns (PM2.5) to cross the pulmonary epithelium.
  - Gut absorption: Particles can be absorbed if they are smaller than 150 microns.

**Key Exposure Concerns**

- Relevance of Particle Size:
  - Large plastics (e.g., 5mm pieces) are not concerning—they pass through the digestive system without harm.
  - Smaller micro- and nanoplastics are the main concern due to their ability to accumulate in tissues.
- Bioaccumulation in the Food Chain:
  - Exposure intensifies as plastics move up the food chain, impacting both seafood and land animals.

**Summary**

- Humans are mainly exposed to microplastics through inhalation and ingestion.
- Seafood, water, salt, fruits, vegetables, meat, and beverages are common sources.
- Smaller particles pose a greater health risk due to their ability to bypass the body’s barriers and accumulate in tissues.

## Volume of plastic consumed by humans, and how the body eliminates or absorbs microplastics [16:00]

**Estimated Microplastic Consumption**

- Wide Variability in Exposure
  - Exposure depends on:
    - Geography (where you live)
    - Diet (types of food consumed)
    - Water source (tap vs. bottled water)
- Consumption Estimates
  - Studies suggest humans consume between 10 and 300 micrograms of microplastics weekly.
  - A [2021 study](https://pubs.acs.org/doi/10.1021/acs.est.0c07384) estimated about 4 micrograms per week from seafood, tap water, bottled water, beer, and similar sources.
  - A [2023 study](https://www.sciencedirect.com/science/article/abs/pii/S0269749123001550) in Korea estimated between 140 and 310 micrograms per week, aligning with the upper limit of U.S. estimates.
- Limitations of Current Estimates
  - These studies likely underestimate exposure because they didn’t account for:
  - Fruits, vegetables, and meat contamination
  - Plastic residue from cutting boards and utensils
  - Plastics leached from reheating food in plastic containers

**Debunking the “Credit Card a Week” Claim**

- Media [claimed](https://awsassets.panda.org/downloads/plastic_ingestion_press_singles.pdf) humans ingest a credit card’s worth of plastic (~5 grams) weekly.
- This estimate originated from a [2019 University of Newcastle study](https://www.newcastle.edu.au/newsroom/featured/plastic-ingestion-by-people-could-be-equating-to-a-credit-card-a-week), commissioned by the WWF.
- [Scientific Rebuttal](https://www.sciencedirect.com/science/article/pii/S2666911022000247)
  - This claim has been widely debunked and lacks serious scientific backing.
  - More accurate studies suggest human intake is in the microgram range, far less than the 5 grams claimed.

> “*I don’t think any serious person believes that we’re consuming five grams of plastic a week.*” —Peter Attia

**How Microplastics Are Eliminated from the Body**

- Primary Elimination Methods
  - Coughing/Sneezing: Clears microplastics inhaled into the lungs.
  - [Stool](https://www.tandfonline.com/doi/full/10.1080/10643389.2023.2195798#d1e122): The main elimination route, removing 99% of ingested microplastics within 24–72 hours.
  - Urine: A minor pathway for excreting absorbed microplastics.
- Absorption Rates
  - Larger particles (>10 microns): Efficiently removed and rarely absorbed.
  - Smaller particles (<10 microns): Have a small chance of being absorbed, especially in the lungs or gut.
  - Animal studies suggest only 0.3% to 1.7% of ingested microplastics cross the GI epithelium.
- Size-Dependent Absorption
  - Lungs: Particles ≤2.5 microns (PM2.5) can enter systemic circulation.
  - Gut: Can theoretically absorb particles up to 100 microns, but practically more likely under 10 microns.

**Key Takeaways**

- Actual consumption of microplastics is much lower than popular media suggests.
- Most ingested microplastics are quickly eliminated, primarily through stool.
- Smaller particles are of greater concern due to their potential for systemic absorption via the lungs or gut.

## How microplastics accumulate in the body, the variability in tissue accumulation, and the challenges in studying their long-term health effects [21:30]

**Focus on Bioaccumulation Over Exposure**

- Key Concern: Retention, Not Just Exposure
  - The main health risk comes from bioaccumulation—how much plastic remains in the body after 72 hours.
  - It’s less important how much plastic is ingested or absorbed if it is eventually excreted.
- Accumulation Varies by Tissue Type
  - Different tissues accumulate micro/nanoplastics (MNPs) at varying levels.
  - Studies primarily focus on tissues that are easier to biopsy, introducing observational bias.

**Human Tissues Where MNPs Have Been Detected**

\*Bronchoalveolar lavage fluid has shown higher levels of MNPs in [smokers](https://pubmed.ncbi.nlm.nih.gov/37267095/) vs non-smokers.

![](https://peterattiamd.com/wp-content/uploads/2025/01/f2-ama67.png)

\*\* In patients without liver disease, MNPs in the liver, kidney, and spleen were below the level of detection.

BOTH OF THESE FINDINGS suggest that the health of the organ plays a significant role in the amount of accumulation.

**Figure 2. A non-exhaustive list of human tissues with detected MNPs**.

- Tissues Tested and Findings:
  - Excised [carotid](https://www.nejm.org/doi/full/10.1056/NEJMoa2309822) plaques (from patients undergoing carotid endarterectomy)
  - [Olfactory bulb](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2823787) (in the brain)
  - [Bone marrow](https://www.sciencedirect.com/science/article/abs/pii/S0304389424018454)
  - [Penile tissue](https://www.nature.com/articles/s41443-024-00930-6)
  - [Lung tissue](https://www.sciencedirect.com/science/article/pii/S0048969722020009)
  - [Cirrhotic livers](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(22)00328-0/fulltext) (diseased livers)
  - [Hip and knee joints](https://www.sciencedirect.com/science/article/abs/pii/S0304389423019234#) (post-surgery)
  - [Testes](https://pubmed.ncbi.nlm.nih.gov/38745431/)
  - [Placenta](https://pubmed.ncbi.nlm.nih.gov/38366932/)
- Diseased vs. Healthy Tissue Comparisons:
  - Lung Tissue:
    - [Smokers](https://pubmed.ncbi.nlm.nih.gov/37267095/) show higher MNP levels in bronchoalveolar lavage fluid compared to non-smokers.
    - This suggests smokers’ lungs may be more susceptible to plastic accumulation, beyond plastic in cigarettes.
  - Liver Tissue:
    - Patients with liver disease have higher MNP accumulation in the liver and adjacent organs compared to healthy individuals.
    - This may indicate that organ health impacts MNP accumulation.

**Known and Unknowns About MNP Accumulation**

- Known Facts:
  - Excretion: MNPs are eliminated through coughing, urine, and stool.
  - Non-Excretion: MNPs do not appear to be excreted through sweat.
- Particle Size Matters:
  - The liver tends to accumulate larger particles.
  - The kidney and gut accumulate smaller particles.
- Unanswered Questions:
  - Residence Time: Unknown how long MNPs remain in tissues.
  - Immune System Role: Limited understanding of how immune cells pick up or release MNPs.
  - Individual Differences: It’s unclear why some people accumulate more MNPs than others, despite similar exposure.

**Research Challenges and Future Study Ideas**

- Challenges in Human Research:
  - Difficulty in studying bioaccumulation due to limited access to internal tissues.
  - Studies are biased towards tissues that are easier to biopsy.
- Potential Research in Animals:
  - Peter suggested studying companion dogs as they share human environments but have shorter lifespans.
  - Dogs could provide insights into how environmental exposures impact organ-specific MNP accumulation.

## Limitations of blood tests for microplastics, and the importance of reliable biomarkers for guiding behavior and interventions [26:30]

**Current Limitations of Blood Tests**

- Low Utility at Present:
  - The reliability and utility of current tests for microplastics are near zero.
  - Tests provide particle counts, but not details like particle size or type of plastic, which are critical for actionable insights.
- Potential for Fear-Mongering:
  - Peter expressed concerns that current tests may generate unnecessary fear without providing meaningful guidance or behavior change.
  - Tests are not yet reliable enough to act as a biomarker or a proxy to guide interventions.

**Future Potential of Biomarkers**

- Hope for Reliable Biomarkers:
  - While the tests are not useful now, Peter is optimistic about future developments.
  - Reliable biomarkers could allow individuals to:
    - Evaluate the efficacy of interventions (e.g., lifestyle changes, mitigation strategies).
    - Determine if the inconvenience, cost, or sacrifices associated with interventions are worthwhile.
- Comparison to Mercury Testing:
  - Reliable tests exist for mercury exposure, which serve as a model for what might be achievable for microplastics:
    - Mercury Testing Details:
      - Mercury can be measured accurately in blood, hair, and saliva.
      - Elevated mercury levels can be tracked and managed with interventions like dietary changes or chelation therapy.
      - Reliable measurements allow for monitoring both symptom improvement and reduction in mercury levels.
    - Similar testing for microplastics could help determine if interventions are effective.

**Advice for Now**

- Avoid Overreliance on Current Tests:
  - Current blood tests for microplastics lack the accuracy and specificity needed to guide meaningful action.
  - Individuals should focus on behavioral strategies for reducing exposure (as discussed elsewhere) rather than relying on unproven tests.
- Peter cautioned against being “duped” by claims that current tests can provide valuable insights.

## The speculative health risks of microplastics, the limitations of current research, and the need for more robust studies [29:15]

**Overview of Microplastics and Health Concerns**

- Speculated Health Impacts:
  - Increased risk for chronic diseases, infertility, and endocrine issues.
  - Potential mechanisms include:
    - Oxidative stress.
    - Inflammatory reactions.
    - Epigenetic changes.
- State of Research:
  - Research is in its infancy despite frequent media coverage.
  - Heavy reliance on epidemiology (observational studies), which cannot establish causality.
  - Studies in humans are limited, with small sample sizes and inconsistencies.

***If the best human data we have is from prospective studies, what can they tell us so far?***

**Prospective Studies on Microplastics**

- Key Findings:
  - Few prospective studies measure microplastics in human tissue and link them to health outcomes.
  - New England Journal of Medicine [Study](https://www.nejm.org/doi/full/10.1056/NEJMoa2309822) (2024):
    - Evaluated carotid plaques from 150 participants.
    - Key Result:
      - Presence of microplastics in plaques was linked to a hazard ratio of 4.53 for major adverse cardiac events (MACE), including heart attack, stroke, or death.
    - Inflammatory Markers:
      - Participants with microplastics in plaques showed higher levels of inflammatory factors (e.g., interleukins, TNF-alpha).
    - Collagen Content in Plaques:
      - Microplastic-containing plaques had significantly lower collagen levels (~20%) compared to those without (~40%).
    - Possible Mechanisms:
      - Microplastics may destabilize plaques by reducing collagen, making them more prone to rupture.
    - Caveats:
      - Relatively small number of events (8 vs. 30) and limited follow-up period (~3 years).
      - Alternative explanation: Individuals with reduced collagen formation may accumulate more microplastics due to an unrelated defect.

![](https://peterattiamd.com/wp-content/uploads/2025/01/f3-ama67-1024x625.png)

**Figure 3.** Source: [Marfella et al. NEJM, 2024.](https://www.nejm.org/doi/full/10.1056/NEJMoa2309822)

- The figure above shows two groups based on the presence of microplastics (MMPs) in their carotid plaques:
  - Orange Group: Patients with MMPs in plaques.
  - Blue Group: Patients without MMPs in plaques.
- Measurement: Percentage of collagen content in the plaques (Y-axis of the graph).
- Results:
  - Patients with MMPs (Orange Group): Average collagen content in plaques was below 20%.
  - Patients without MMPs (Blue Group): Average collagen content in plaques was closer to 40%.
  - Clustering of Results: The data points for each group were tightly clustered, reinforcing the observed association.
- Possible Mechanisms and Explanations
  - Hypothesized Mechanism:
    - The accumulation of microplastics in plaques might destabilize them by reducing collagen formation, which is essential for plaque stability.
  - Reverse Causality:
    - An alternative explanation could be that individuals with pre-existing collagen formation defects are more likely to accumulate microplastics in their plaques.
  - This means the observed association could be driven by the underlying defect rather than by the microplastics themselves.

**Fertility and Reproductive Health**

- Male Fertility Studies:
  - Chinese [Study](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(24)00405-5/fulltext) on Semen:
    - Correlated microplastics with sperm quality but found no significant associations with motility, volume, or morphology.
    - PTFE (e.g., GORE-TEX) Plastics: Slight decline in total sperm count and concentration.
  - Other [studies](https://hsc.unm.edu/news/2024/05/hsc-newsroom-post-microplastics-testicular.html) looking at human and canine testes:
    - Microplastics were detected in all testes samples but showed no age-related trends.
    - Suggestion that release of microplastics via semen prevents accumulation.
  - Limitations:
    - Small sample sizes.
    - Results influenced by outliers, weakening statistical conclusions.

**Key Takeaways**

- Evidence of Concern:
  - Microplastics are linked to inflammatory processes and tissue changes (e.g., lower plaque collagen content).
  - Studies suggest potential impacts on fertility, but data is weak and inconsistent.
- Limitations of Current Research:
  - Lack of large-scale, randomized studies.
  - Challenges in distinguishing causality from correlation.
  - Many results are preliminary and require further validation.

**Peter’s Perspective**

- Balanced View:
  - While there is “smoke,” the evidence does not support the extreme claims seen in social media.
  - The narrative around plastics being an existential threat is overstated based on current data.
  - The risks, while real, are not as compelling as often portrayed.

## The challenges of measuring microplastics in human tissues, the need for better methodologies, and the importance of critically evaluating study relevance and claims [39:45]

**Methodological Challenges**

- Contamination Risks:
  - Plastics are ubiquitous, and contamination during testing is extremely easy, especially when working with microscopic levels of microplastics.
  - Laboratories must use clean rooms to minimize environmental contamination.
- Essential Controls:
  - Control samples and blanks are critical to account for contamination and validate the accuracy of results.
  - Even reagents used in the analysis must be free of plastic contamination.

**Evaluating Study Relevance and Methodology**

- Contextual Relevance:
  - It is essential to ask: Does this study apply to my life?
  - Example: A study about boiling water in a plastic kettle may be irrelevant if you don’t use plastic kettles. However, it could be highly relevant for individuals who do.
- Magnitude of Effect:
  - Look at the magnitude of plastic exposure relative to a meaningful standard.
  - Challenges:
    - Often, studies compare exposure to arbitrary or non-scientific upper limits, making the reported percentages misleading.
    - For example, a study might claim a BPA level is 20,000% of a “safe” threshold, but that threshold may lack scientific validity.
- Circular Reasoning in Standards:
  - Many studies lack a scientifically established baseline for harm, leading to results that may seem alarming but are not grounded in reliable reference points.
  - Example: Standards used in studies are sometimes unvalidated or arbitrary, undermining their credibility.

**Tips for Evaluating Microplastics Research**

- Be Critical of Standards:
  - Verify whether the thresholds or standards cited in a study are scientifically validated.
- Focus on Relevance:
  - Prioritize studies that explore exposure scenarios relevant to your lifestyle and behaviors.
- Magnitude Matters:
  - Assess whether the reported exposure levels are meaningful compared to realistic harm thresholds.

## If it’s unclear whether microplastics actually cause harm, should we still be concerned about exposure? [42:15]

**Uncertainty in Risk Assessment**

- Insufficient Evidence:
  - Current data does not conclusively prove that micro/nanoplastics (MNPs) are significantly hazardous to human health, nor does it confirm their harmlessness.
  - Peter emphasizes that the absence of evidence for harm does not equate to evidence of absence of harm.
  - Despite incomplete data, it is clear that plastic concentrations in human tissues are rising.
- Neutral to Negative Impact:
  - At best: Plastics offer no health benefits.
  - At worst: Plastics may pose harmful effects.
  - Given the lack of benefits and potential for harm, reducing exposure appears prudent.

**Precautionary Principle**

- Risk-Reduction Rationale:
  - Aligning with the precautionary principle, it is reasonable to take measures to minimize exposure despite incomplete knowledge.
  - This approach mirrors a non-religious Pascal’s Wager—acting conservatively to avoid potential risks.
- Focus on Accumulation:
  - Accumulation, not just exposure, is the key concern.
  - Reducing exposure is currently the best strategy to limit accumulation, as methods to increase plastic clearance from the body are not well-understood.

**Costs of Mitigation**

- Trade-Offs to Consider:
  - Financial Cost: Many exposure-reduction strategies involve purchasing alternative products or systems.
  - Effort and Inconvenience: Lifestyle adjustments, such as avoiding single-use plastics or processed foods, can require significant effort.
  - Quality of Life: Some measures, like avoiding certain conveniences, may slightly reduce day-to-day comfort or efficiency.
- Framework for Action:
  - Peter introduces a framework to help individuals balance the costs and efforts of exposure reduction with their personal risk tolerance.
  - The goal is to help each person identify their “sweet spot” for mitigating potential harm while maintaining a manageable lifestyle.

## Strategies to minimize microplastic exposure [45:00]

**The Reality of Avoiding Microplastics**

- Complete Avoidance is Impossible:
  - Microplastics (MMPs) are ubiquitous in the environment (air, water, food).
  - Even extreme measures, such as living in remote areas, will not fully eliminate exposure.
  - Focus should be on reducing exposure rather than achieving complete avoidance.

**Strategies to Reduce Microplastic Exposure**

- A) Avoid Conditions That Degrade Plastic
  - Minimize exposure to heat, freezing, UV light, acidic environments, and mechanical abrasion.
  - Practical tips:
    - Paper coffee cups: Avoid as they are lined with thin plastic.
    - Styrofoam products: Avoid as they are a form of plastic.
    - Plastic cutting boards: Limit use, though larger shards from these are unlikely to be absorbed.
    - Microwaving food in plastic: Avoid due to the risk of plastic leaching into food.
    - Dishwashing plastic items: Minimize exposure to heat and detergents that degrade plastics.
    - Plastic coffee pods (e.g., K-Cups): Avoid single-use pods often found in hotels.
- B) Transition to Safer Alternatives
  - Replace plastic food storage containers with glass alternatives.
  - Use stainless steel or glass French press or pour-over coffee makers instead of drip machines with plastic components.
    - Challenge: Difficulty finding a drip coffee machine that avoids all plastic exposure.
  - Drink from glass or stainless steel water bottles and avoid reusing plastic bottles.
    - Avoid leaving plastic bottles in hot environments, such as cars.

**Strategies for Reducing PM2.5 Exposure**

- HEPA Filters:
  - Use high-efficiency particulate air (HEPA) filters in your home and car to reduce airborne particles.
  - Some cars, like Teslas, have built-in HEPA filters.
- Vacuuming & Cleaning:
  - Regularly vacuum carpets, especially those made of synthetic fibers, to reduce particulate accumulation.

**Water Filtration**

- Reverse Osmosis Systems:
  - Install a reverse osmosis (RO) tap for drinking and cooking water.
  - Filters particles ranging from 0.1 to 1 nanometers, ensuring effective removal of microplastics.
  - High upfront cost: $500 to $1,500, but largely a one-time investment.

**Practical Mindset**

- Flexibility & Realism:
  - Peter acknowledges that occasional plastic use is inevitable (e.g., at events or when traveling).
  - Focus on consistent, manageable changes rather than striving for perfection.

**Key Takeaways**

- While avoiding microplastics entirely is impossible, practical steps can significantly reduce exposure.
- Focus efforts on reducing contact with degraded plastics, filtering water, and improving air quality.
- Evaluate cost and effort to determine which strategies are most feasible and impactful for your lifestyle.

## The financial cost and effort involved in various microplastic exposure mitigation strategies [51:00]

**Upfront Costs vs. Long-Term Benefits**

- Investment vs. Cost:
  - Many solutions have a high initial cost but pay off over time, similar to installing solar panels.
  - Example: Reverse osmosis (RO) systems and glass/metal bottle replacements offer lasting benefits after the upfront investment.

**Cost Breakdown by Mitigation Strategy**

- HEPA Filters
  - Whole-house HEPA systems:
    - Cost: $2,000–$5,000 upfront.
    - Maintenance: $100–$300 per filter replacement every 6–12 months.
  - Portable HEPA filters (room-specific):
    - Cost: $100–$800 depending on room size and filter power.
- Reverse Osmosis Filters
  - Point-of-use RO systems:
    - Cost: $1,000–$4,000.
    - Maintenance: Minimal compared to HEPA systems.
  - Whole-house RO systems:
    - Cost: $12,000–$18,000.
    - Not recommended due to limited impact (most household water, e.g., for bathing or toilets, doesn’t require such filtration).
- Lifestyle Adjustments
  - Switching materials:
    - Transition from plastic food storage to glass or ceramic containers.
    - Use stainless steel or glass water bottles instead of plastic.
    - Replace single-use plastics with sustainable alternatives (e.g., reusable coffee pods, non-plastic utensils).
    - Costs: Vary; generally one-time investments.

**Balancing Cost, Mitigation, and Inconvenience**

- Unattainability of Total Elimination:
  - It’s impossible to completely eliminate exposure to microplastics and associated chemicals.
  - Efforts should focus on practical and impactful strategies rather than achieving 100% mitigation.
- Three Key Variables in Mitigation Efforts:
  - 1—Cost: The financial investment required for solutions (e.g., reverse osmosis filters, switching to glass storage).
  - 2—Mitigation Impact: The extent to which the strategy reduces exposure.
  - 3—Inconvenience: The effort and lifestyle changes needed to implement mitigation strategies.

**Peter’s Predicted Characteristics of Mitigation Strategies**

- Non-linear Cost-Benefit Relationship:
  - Effort and cost do not scale linearly with benefit.
  - Example: Spending 50% of the maximum cost does not yield 50% of the benefit.
  - Mitigation follows a sigmoidal curve:
    - Significant benefits occur with modest investments initially.
    - Beyond a certain threshold, additional spending yields diminishing returns.
- Asymptote of Mitigation:
  - Achieving 100% mitigation is impossible regardless of effort or cost.
  - Exposure can only be reduced to approximately 75–80% at most.

**Specific Costs and Impacts of Strategies**

- Examples of Mitigation Costs:
  - Eliminating plastic water bottles.
  - Switching to glass or ceramic containers for hot, acidic, or stored foods.
  - Using reverse osmosis filters or home HEPA filters.
- Impact Quantification:
  - Analysis focuses on translating costs and efforts into exposure reductions.
  - While exact percentages may vary, the shape of the curve and general trends hold value.

**Graphical Analysis of Mitigation**

![](https://peterattiamd.com/wp-content/uploads/2025/01/f4-ama67-1024x479.png)

**Figure 4.**

- Cost vs. Reduction in Exposure:
  - X-axis: Aggregate cost (e.g., $0 to $20,000).
  - Y-axis: Percentage of exposure reduction.
- Observed trends:
  - A small initial investment results in significant reduction (up to ~50%).
  - Additional investment (e.g., $7,500) is required for moderate gains (up to ~75%).
  - Spending an additional $10,000–$20,000 yields negligible benefits beyond this point.
- Key Insight:
  - The focus should be on impactful, cost-effective strategies rather than excessive spending with limited returns.

**A Pragmatic Approach**

- Useful Framework:
  - “All models are wrong, some are useful”: While not perfect, the analysis provides valuable insights into prioritizing mitigation efforts.
  - Emphasis on practicality over perfection ensures a balanced approach to reducing microplastic exposure.

**Effort and Convenience Considerations**

![](https://peterattiamd.com/wp-content/uploads/2025/04/Screenshot-2025-04-22-at-1.05.38 PM-1024x493.png)

**Figure 5.**

- Examples of High-Inconvenience Measures
  - Avoid environments without HEPA filtration: 9/10 effort.
  - Boiling and filtering all water before drinking: 6/10 effort.
  - Avoid synthetic fiber clothing: 5/10 effort.
- Low-Inconvenience Adjustments
  - Avoid heating or storing food in plastic: 3/10 effort.
  - Eliminate seafood/seaweed consumption:
    - Effort depends on dietary preference (e.g., 1/10 for non-seafood eaters, 9/10 for pescatarians).

![](https://peterattiamd.com/wp-content/uploads/2025/01/f6-ama67-1024x608.png)

**Figure 6.**

**The Cost-Benefit Curve**

- Key Insights from the Data:
  - Non-linear cost-benefit relationship:
    - Significant reduction (~50%) in exposure can be achieved with modest costs and effort.
    - Diminishing returns: Spending significantly more money or effort only marginally improves mitigation (plateaus at ~75%).
  - Effort vs. Cost Trade-Offs:
    - Example: Installing a HEPA filter is costly but requires minimal ongoing effort.

**Individualized Mitigation Framework**

- Tailor to Your Priorities:
  - Combine financial capacity, effort tolerance, and exposure preferences.
  - Focus on the “low-hanging fruit” for high-impact, low-cost changes (e.g., replacing plastics at home).
- Personal Examples:
  - Peter’s approach:
    - Switched to glass/ceramic food storage and stainless-steel coffee makers but hasn’t found an all-metal drip coffee machine.
    - Still uses plastic water bottles while biking but minimizes their use in other settings.

**Key Takeaways**

- Significant risk reduction is achievable without excessive cost or effort:
  - Example: Replacing plastic with glass for food storage and water bottles is affordable and convenient.
- Some exposure is inevitable:
  - Focus on impactful strategies within your lifestyle rather than striving for perfection.

![](https://peterattiamd.com/wp-content/uploads/2025/01/f7-ama67-1024x981.png)

**Figure 7.** The generalized trend of reducing exposure, with shaded uncertainty. Note that the curve is not necessarily smooth – nor is the variation representative of each reduction strategy.

- Analyze individual habits and exposures:
  - Customize mitigation strategies based on personal preferences, dietary habits, and daily routines.

## The role of airborne microplastics in total exposure and accumulation [1:03:00]

Air Exposure’s Contribution to MNP Exposure:

- Overall Contribution:
  - Air exposure accounts for approximately 15% of total micro-nanoplastic (MNP) exposure by particle count.
  - By weight, air exposure contributes less than 0.1% of MNPs.
- Reason for Disparity Between Count and Weight:
  - Airborne particles must be extremely small to enter the body, resulting in a high particle count but minimal weight.

Challenges with Airborne MNPs:

- Smaller Particles, Bigger Problem:
  - Tiny particles are more likely to enter systemic circulation.
  - They can potentially infiltrate immune cells and tissues, posing a higher health risk.
- Comparison to Other Sources:
  - Efforts to reduce MNP exposure from food and water likely have a more significant impact on reducing total daily exposure.
  - However, the health impact per particle from air exposure may be greater due to their smaller size and ability to penetrate deeper into the body.

Key Takeaway:

- Focus Areas for Reduction:
  - Reducing MNPs from food and water remains the priority for lowering overall exposure.
  - Airborne MNPs, while a smaller contributor in volume, may have disproportionate health effects and require targeted attention.

## Chemicals associated with plastics, their role as endocrine disruptors, and the challenges in linking exposure to specific health outcomes [1:04:00]

**Overview of Chemicals in Plastics:**

- Purpose of Added Chemicals:
  - Enhance desired properties in plastics:
    - Hardness (rigid plastics).
    - Softness and malleability (flexible plastics).
    - Resistance to water or creation of slick surfaces.
  - Examples include PFASs and BPAs, often referred to as forever chemicals.
- Endocrine Disruption:
  - Commonly linked to sex hormones (e.g., estrogen and testosterone).
  - Less commonly linked to thyroid hormones, adrenal hormones, or fuel-partitioning hormones.
  - Disruption of hormonal balance can potentially lead to adverse health outcomes.
- Reported Health Risks:
  - Associations with:
    - Cancer.
    - Obesity.
    - Infertility.
  - Research mainly observes correlations, making it difficult to establish causation.

**Challenges in Research:**

- Limitations:
  - Most studies report associations rather than proving a direct cause-effect relationship.
  - Observational data is common, but rigorous causal evidence is lacking.

**Key Takeaway:**

- Chemicals like PFASs and BPAs in plastics warrant concern, especially regarding their potential endocrine-disrupting effects. However, causality is challenging to establish, and findings are often limited to associations.

## BPA: role in plastic production, and its potential developmental risks [1:05:45]

**Quick Recap: What is BPA and Why is it Used?**

- Definition:
  - BPA (Bisphenol A) is a chemical used to create polycarbonate plastics, making them hard and durable.
  - Historically found in products like Nalgene bottles, though now largely replaced with BPA-free alternatives using other bisphenols.

**BPA’s Mechanism of Action:**

- Routes of Entry:
  - BPA can enter the body via:
    - Respiratory tracts.
    - Dermal exposure, if particles are small enough.
    - Gastrointestinal pathways.
- Clearance:
  - BPA has a [short half-life](https://pmc.ncbi.nlm.nih.gov/articles/PMC9671506/) (~2 hours) and is detectable in the urine of [90%](https://www.sciencedirect.com/science/article/abs/pii/S0048969721008226) of adults, indicating widespread exposure and clearance.
- Impact on Estrogen Receptors:
  - Binds to estrogen receptor alpha (more strongly) and beta subunits.
- Binding affinity:
  - 1,000 to 2,000 times weaker than natural estradiol.
  - This weaker binding is good news, reducing its potential impact compared to estradiol.
- Potential Mechanism of Disruption:
  - BPA may mimic estrogen, disrupting the negative feedback loop in hormone production:
    - Signals the hypothalamus to reduce production of FSH (follicle-stimulating hormone) and LH (luteinizing hormone).
    - Results in reduced production of steroid hormones, including testosterone (in males) and estrogen (in females).

Health Concerns and Evidence:

- Population Exposure:
  - BPA is ubiquitous, present in trace amounts in most individuals.
- Most Vulnerable Groups:
  - Pregnant women and young children are believed to face the highest risks.
    - Evidence suggests developmental exposure could lead to long-term effects.
  - Adults and older children:
    - Impacts are less clear, and the evidence is more limited.
- Animal Studies:
  - Provide much of the current understanding but are difficult to translate to human health outcomes.

**Key Takeaways:**

- BPA exposure is common, but its weaker binding affinity to estrogen receptors offers some reassurance.
- Developmental exposure (e.g., during pregnancy or early childhood) poses the greatest concern.
- Effects on adults remain unclear and require further investigation.

## BPA’s potential health risks: pregnancy, fertility, obesity, and diabetes, and the socioeconomic confounders in the data [1:08:30]

**Vulnerable Groups and Developmental Concerns**

- Greatest Risks:
  - In utero exposure and exposure during infancy and early childhood.
  - Fertility in women:
    - Aberrant estrogen signaling plausibly contributes to fertility issues.
- [Meta-Analysis](https://www.sciencedirect.com/science/article/pii/S0147651321005121#:~:text=%E2%80%A2,susceptible%20period%20of%20preterm%20birth.) on Preterm Birth (2021):
  - Found a 36% increased odds ratio for preterm birth with maternal urinary BPA exposure during pregnancy.
  - Strongest association seen in third trimester.
  - Confounding Factors:
    - Possible link to lower socioeconomic status:
      - Women in this category may have higher BPA exposure due to limited ability to avoid BPA-containing products.
      - Other factors (e.g., diet, access to healthcare) could contribute to preterm birth.
    - BPA might play a role, but it’s not clear if it’s the dominant contributor.

**BPA and Fertility**

- IVF [Study](https://pmc.ncbi.nlm.nih.gov/articles/PMC3501244/):
  - Women in the highest quartile of urinary BPA levels showed:
    - Worse ovarian response during hormone treatment for egg production.
    - Produced fewer eggs (9 vs. 12 eggs).
  - Possible explanation:
    - Reduced estrogen signaling due to BPA exposure.

**Broader Health Associations**

- Conditions [Linked](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2769313?utm_source=For_The_Media&utm_medium=referral&utm_campaign=ftm_links&utm_term=081720#google_vignette) to BPA:
  - Obesity.
  - Diabetes.
  - Cancer.
  - All-cause mortality.
- Challenges in Interpreting Data:
  - BPA exposure often correlates with processed, energy-dense diets, which are common in lower socioeconomic groups.
  - Difficult to disentangle the impact of dietary patterns and socioeconomic factors from BPA exposure.

**Study on Bottled Water and Phthalates**

- Unexpected Findings:
  - No significant difference in phthalate concentration between bottled water in glass and plastic containers at the point of sale.
- Possible Explanation:
  - Processing methods (rather than container type) appear to be the largest determinant of phthalate content.
- Additional Considerations:
  - Over time, glass may outperform plastic in reducing phthalate leaching, especially under adverse storage conditions (e.g., heat exposure).
  - Highlights processing and packaging as key factors in contamination, not just the material of the container.

**Key Takeaways**

- Developmental Risks:
  - Strongest evidence for pregnant women and infants.
- Socioeconomic Confounding:
  - Higher BPA exposure linked to processed foods and lower socioeconomic conditions, both of which contribute to poorer health outcomes.
- Practical Insights:
  - Avoiding BPA exposure may benefit specific groups, but it’s difficult to isolate its effects from broader lifestyle and dietary patterns.

## Regulatory limits on BPA exposure, and practical considerations for reducing exposure [1:12:45]

**Safe BPA Exposure Limits**

- Challenges in Establishing “Safe Limits”:
  - Research Limitations: Studies often define “low dose” as levels much higher than actual human exposure.
  - Regulatory Standards: FDA limit: 50 micrograms per kilogram per day—far above typical US exposure levels.
  - Current BPA Exposure:
    - Exposure in the US [decreased by 50%](https://www.sciencedirect.com/science/article/pii/S0013935115001887) (2003-2012).
    - By 2012, exposure was down to 25 nanograms per kilogram per day.
- Infant Exposure:
  - Plastic bottles, especially when heated, may still pose a risk to infants due to BPA leaching.
  - Potential impact on sexual development is more significant in utero than postnatally.

**Practical Recommendations**

- Plastic vs. Glass Bottles:
  - Glass bottles are recommended for milk, especially when heating, to reduce BPA exposure.
- Considerations for parents:
  - Effort and Safety:
    - Glass bottles are prone to breaking, posing a physical safety risk (e.g., cuts or injuries from shattered glass).
    - Decision should balance potential BPA exposure risks against practicality and injury risk from glass.
- Personal Perspective:
  - Peter acknowledges his children used plastic bottles but suggests that, knowing what he does now, he would opt for glass if parenting infants today.

**BPA in Receipts**

- Thermal Paper as a BPA Source:
  - BPA levels measured in cashiers:
    - [2x higher](https://pmc.ncbi.nlm.nih.gov/articles/PMC4927604/) urinary concentrations compared to controls, likely due to frequent handling of thermal paper.
  - Mechanism:
    - BPA can transfer from thermal paper to skin and potentially be absorbed or ingested if hands are not washed.
  - Risk Assessment:
    - For cashiers: Elevated BPA levels are measurable but not alarming.
  - For general individuals:
    - Limited handling of receipts unlikely to pose a significant risk.
    - Peter expresses skepticism about the need to avoid receipts entirely.

**Key Takeaways**

- BPA Exposure Trends:
  - Levels have declined significantly over the years due to regulatory changes and voluntary reductions.
- Practical Mitigation Strategies:
  - Consider glass bottles for infants but weigh the practicality and risks.
  - Handling receipts is likely low-risk for most people, though prolonged exposure (e.g., cashiers) could lead to higher levels.
- Unanswered Questions:
  - The safety and impact of BPA replacements (e.g., other bisphenols) remain uncertain.

## The prevalence of BPA in modern products and how to identify it [1:17:15]

**BPA Usage Decline**

- BPA usage has significantly decreased over time:
  - 95% of canned goods no longer contain BPA, whereas it was once prevalent in them.
  - Most hard plastic products today are BPA-free but are not universally so.

Identifying BPA in Products

- Labeling:
  - If a product is not labeled “BPA-free”, it’s safest to assume it contains BPA, particularly if it’s made of hard plastic.
- Recycling Codes:
  - Products with recycling codes 3 or 7 may indicate BPA presence.
  - These codes primarily relate to recycling categorization but can also serve as a rough indicator of BPA content.
- Current BPA-Free Landscape
  - Non-BPA plastics make up 97% of all plastic, indicating that most plastic products today do not contain BPA.

Key Insights

- BPA-free labels are the most reliable indicator of absence.
- Awareness of recycling codes (3 or 7) may provide additional context for identifying potential BPA presence.

## PFAS: chemical structure and purpose in products [1:18:30]

**What Are PFAS?**

- Definition:
  - Synthetic chemical compounds with multiple fluorine atoms attached to a hydrocarbon chain.
  - Known as “forever chemicals” because they do not break down easily in the environment or the human body.

How PFAS Are Structured

- Hydrocarbon chains where all hydrogen atoms are replaced by fluorine atoms.
- The strong carbon-fluorine bond makes these compounds incredibly resilient and non-biodegradable.

Uses of PFAS

- Primary Function: Coatings and products designed to resist heat, oil, stains, grease, and water.
- Common Applications:
  - Non-stick cookware (e.g., Teflon pans, though less common today).
  - Stain-resistant carpets and furniture.
  - Waterproof clothing (e.g., Gore-Tex).
  - Grease-resistant food packaging:
  - Fast food wrappers.
  - Coatings on boxes.
  - Firefighter uniforms (for heat and water resistance).

Key Insights

- PFAS are persistent and challenging to eliminate due to their chemical stability.
- Found in everyday items, they have historically been associated with convenience and durability (e.g., non-stick cookware, waterproof materials).

## Why PFAS are considered endocrine disruptors [1:19:45]

**PFAS as Fatty Acid Mimics**

- Chemical Mimicry:
  - PFAS molecules resemble fatty acids in their structure.
  - A fatty acid is a long-chain carbon with hydrogen atoms; PFAS is a long-chain carbon with fluorine atoms.
  - This mimicry allows PFAS to interact with receptors in the body, including:
    - Nuclear receptors that regulate gene expression.
    - Receptors involved in glucose and lipid metabolism.

Impact on Thyroid Hormones

- Competition with Thyroxine ([T4](https://pubmed.ncbi.nlm.nih.gov/28622647/)):
  - PFAS can bind to thyroid transporter protein (TTR), competing with thyroxine (T-IV).
  - This competition can reduce thyroid hormone levels, leading to potential hypothyroidism.
  - Mechanism parallels BPA’s effect on estrogen receptors:
    - Both disrupt normal feedback loops by mimicking natural hormones and altering production.

Elimination and Persistence in the Body

- Excretion Pathways:
  - PFAS are primarily [eliminated](https://pmc.ncbi.nlm.nih.gov/articles/PMC7926449/) through bile and urine.
- Half-Life of PFAS:
  - Excretion times range widely, from days to decades.
  - The strong carbon-fluorine (C-F) bond prevents breakdown in the body, making PFAS highly persistent.
  - This long residence time means exposure could result in long-term effects.

**Key Insights**

- PFAS disrupt endocrine processes by mimicking fatty acids and interfering with critical hormone transporters.
- Their resistance to breakdown and extended half-life make them a significant concern for potential long-term health effects.

## The main sources of PFAS exposure, and practical steps to reduce exposure [1:21:30]

**Primary Routes of Exposure**

- Ingestion as the Main Exposure Pathway:
  - Drinking Water:
    - PFAS can enter homes through tap water, as groundwater and municipal sources may already be contaminated.
    - Many people rely on groundwater or aquifers that are already affected by PFAS, which persist for decades or even centuries.
  - Contaminated Food:
    - Food exposed to PFAS-containing surfaces, such as non-stick cookware, is a significant source.
- Environmental Contamination:
  - Soil, rainwater, and aquifer contamination:
    - PFAS are often referred to as “forever chemicals” due to their resistance to degradation.
    - Even if PFAS use stopped completely today, existing contamination would remain for generations.

**Practical Steps to Reduce Exposure**

- Use of Reverse Osmosis (RO) Filters:
  - Peter installed an RO filter at home to address PFAS in drinking water.
  - This approach filters the majority of the household water used for drinking and cooking.
  - Example of Selective Risk Mitigation:
    - While most of Peter’s water consumption is from the RO system, some situations (e.g., brushing teeth, taking pills) involve unfiltered tap water.
    - Ice cubes are also made with unfiltered water, but Peter considers this negligible in overall exposure.

Emphasis on Practicality

- Balance Between Effort and Exposure Reduction:
  - Avoid over-complicating daily routines; focus on high-impact measures like filtering most drinking water.
  - Accept minor, low-impact exposures (e.g., occasional unfiltered water usage) without excessive worry.

## The potential health risks of PFAS exposure [1:24:00]

**Epidemiologic Associations with PFAS**

- Health Issues Potentially Linked to PFAS:
  - Immune System: Altered immune function.
  - Endocrine and Metabolic Function:
    - Altered thyroid function.
    - Lipid dysregulation.
    - Insulin dysregulation.
  - Organ Health:
    - Potential liver disease.
    - Potential kidney disease.
  - Developmental and Cancer Risks:
    - Possible developmental outcomes.
    - Associations with certain cancers.
- Confounding Variables:
  - These associations may be influenced by other factors and not necessarily causal.

Mechanistic Evidence

- Phased-Out PFAS Compounds:
  - Most of the studies showing mechanistic plausibility for PFAS effects focus on compounds already [phased out](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(23)00372-9/fulltext) in the United States, including:
    - PFOA (Perfluorooctanoic acid).
    - PFOS (Perfluorooctane sulfonate).
    - PFHXS (Perfluorohexane sulfonic acid).
  - Reduction in these specific PFAS compounds is a positive trend.
- Half-Life Challenge:
  - PFAS compounds have an exceptionally long half-life, making them persist in the environment and the human body for decades, presenting ongoing challenges despite reduced use.

## Phthalates: role in making plastics flexible, and presence in personal care products [1:24:45]

Definition and Use

- Purpose in Plastics:
  - Phthalates are chemicals used to make plastics more flexible, transparent, and durable.
  - Serve as the opposite of BPA, which is used to make plastics hard and rigid.
- Prevalence:
  - Ubiquitous in the environment and everyday products.

Common Sources

- Personal Care Products:
  - Found in fragrances, scent stabilizers, and similar products.
  - Highlighted as a more significant source of interaction compared to flexible plastics.
  - Examples: lotions, shampoos, and perfumes.
- Flexible Plastics:
  - Present in items such as food packaging or plastic wrap, though people may interact less with these sources in some contexts.

## Why phthalates are considered endocrine disruptors [1:25:15]

Mechanisms of Disruption

- Estrogenic Activity:
  - Phthalates act as weak estrogen mimetics:
    - Bind to estrogen receptors and mimic estrogen activity.
    - Induce phosphorylation and degradation of estrogen receptors upon binding.
- Anti-Androgenic Activity:
  - Shown in rodent [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC3987027/):
    - Higher doses (than typical human exposure) reduce testosterone levels.
    - Associated with deterioration of semen quality and male reproductive outcomes.
  - Inconsistent Findings:
    - Studies on humans show mixed results:
      - Some report reduced testosterone levels and fertility due to phthalate exposure.
      - Others find no significant association.

Comparison to Other Endocrine Disruptors

- Similar to BPA and DDT:
  - All are grouped as endocrine disruptors.
  - Share overlapping mechanisms of disrupting hormone signaling.
  - DDT is less relevant today due to its minimal modern exposure.

Concerns and Context

- Uncertainty of Impact:
  - There is likely some effect, but questions remain about:
    - Level of exposure required to cause harm.
    - Consistency of effects across different studies and populations.
- Practical Considerations:
  - Importance of assessing:
    - Effort and cost required to minimize exposure.
    - Magnitude of risk based on exposure levels.
  - Recommends applying the micro-nanoplastic framework to phthalates:
    - Focus on cost-effective and reasonable exposure reduction strategies.

## The main sources of phthalate exposure, and how manufacturing practices are evolving to reduce exposure [1:26:45]

**Primary Routes of Exposure**

- Food Exposure (most common):
  - Ingestion through contaminated food sources.
  - [2013 Study](https://pmc.ncbi.nlm.nih.gov/articles/PMC3620091/) Findings:
    - Measured phthalates in various foods.
    - Total intake of the nine most common phthalates estimated at ~1 microgram per kilogram per day.
    - Foods with the highest phthalate concentration:
      - Dairy products
      - Grains
      - Pork
    - Contextual Note:
      - Study was conducted in Albany, New York.
      - Results may vary based on location and sampling.
- Skin Absorption:
  - Phthalates can be absorbed through the skin, unlike microplastics.

**Changes in Manufacturing and Food Contact Materials**

- Since [2018](https://pubmed.ncbi.nlm.nih.gov/29510083/), manufacturers have been [reducing](https://pubmed.ncbi.nlm.nih.gov/33493086/) phthalates in:
  - [Food contact materials](https://pubmed.ncbi.nlm.nih.gov/35107413/), such as serving containers.
  - Milk collection tubing:
    - A significant source of contamination, especially with warm milk.
    - Replacing flexible plastic tubing with alternatives presents practical challenges for farmers.

**Airborne Phthalates**

- Phthalates can also be present in the air, though concentrations vary widely:
  - Ranges in the United States:
    - 0.2 nanograms per cubic meter (almost unmeasurable) to 50 nanograms per cubic meter.
  - Example from New York City:
    - Typical range: 3 to 6 nanograms per cubic meter.

## Practical strategies to reduce exposure to phthalates in food, air, water, and personal care products [1:28:30]

**Dietary Adjustments**

- Minimize Processed Foods:
  - Processed and packaged foods are significant sources of phthalate exposure.
  - Switch to Fresh Foods:
    - Fresh foods typically contain fewer phthalates compared to fast foods.
  - Avoid Plastic Contact During Heating:
    - Heating food in plastic containers increases phthalate leaching.

**Water Filtration**

- Use water filtration systems to reduce phthalates in drinking water:
  - Activated Carbon Filters
  - Reverse Osmosis Filters

**Air Quality**

- Reduce airborne phthalates through:
  - HEPA Filtration:
    - Air filters that trap fine particles, including phthalates.
  - Vacuuming and Dusting:
    - Regular cleaning to minimize phthalate-laden dust.

**Personal Care Products**

- Choose fragrance-free or phthalate-free products:
  - Many scented products use phthalates as stabilizers.
  - Important Note:
    - Even “unscented” products may contain phthalates unless labeled as phthalate-free.
  - Look for phthalate-free labels on products to ensure safety.

## Navigating microplastics and associated chemicals: a framework for personalized risk reduction [1:29:30]

**Summary of Evidence and Current Understanding**

- Insufficient Evidence for Harm:
  - Current exposure levels to MNPs, BPA, and phthalates cannot be definitively linked to harm due to:
    - Lack of prospective and randomized data in humans.
    - Variability in biological responses and measurement inconsistencies.
- Bioaccumulation is Key:
  - The concern is not exposure volume but the potential for particles to accumulate in tissues.
  - Associations (e.g., smokers with higher lung MNPs) could reflect covariates (e.g., impaired expulsion mechanisms) rather than causality.
- Assumption of Risk:
  - While definitive proof of harm is lacking, it’s hard to imagine these particles are entirely inert.
  - Precautionary measures are warranted without extreme effort or cost.

**Nuances to Consider**

- Exposure Volume vs. Bioaccumulation:
  - High exposure to large particles poses minimal risk if they are quickly cleared (e.g., via GI tract).
  - Small, aerosolized particles (e.g., PM2.5) are more likely to accumulate and present greater risk.
- Particle Size and Source Matter:
  - Non-acidic, refrigerated food stored in durable plastic leaches negligible MNPs.
  - Conversely, processed foods and food/beverage stored in heated or acidic plastic environments are riskier.
- Opportunity Cost:
  - Example: Abstaining from seafood could reduce MNP exposure but forfeits the known health benefits of lean protein, EPA, and DHA.
- Lifestyle and Individualization:
  - Strategies must be tailored to personal circumstances, including willingness to spend money, endure inconvenience, or make lifestyle changes.

**Key Recommendations**

- 1) Focus on Mitigation, Not Elimination:
  - Complete avoidance of MNPs, BPA, and phthalates is impossible. Efforts should aim for meaningful reductions without extreme costs or inconvenience.
- 2) Prioritize Based on Risk:
  - Airborne MNPs (e.g., PM2.5 particles) are more concerning than larger food-based particles.
  - Use HEPA filters and minimize exposure to airborne particulates where feasible.
- 3) Reduce Contact with Plastics:
  - Avoid heating or storing food in plastic, especially acidic foods.
  - Transition to glass or ceramic for food and drink storage when practical.
- 4) Assess Processed Food Choices:
  - Limit consumption of highly processed foods and beverages.
  - Be mindful of fast-food packaging, which may contain harmful chemicals.
- 5) Weigh Lifestyle Factors:
  - Decide on interventions based on individual preferences, spending limits, and tolerance for inconvenience.

**Framework for Decision-Making**

- Non-Linear and Asymptotic Reduction:
  - Effort, cost, and inconvenience yield diminishing returns at higher levels of mitigation.
  - Example: Spending a small amount of money can achieve ~50% reduction, but achieving more than ~75% reduction requires significant investment and effort.
- Evaluate Trade-offs:
  - Use a personal framework to decide which mitigation strategies align with your resources and priorities.
  - Avoid obsessing over small, residual risks.

**Final Thoughts**

- Balance is Key:
  - Efforts should be practical, cost-effective, and not disruptive to quality of life.
  - Avoid overconfidence in alternatives, as substitutes for BPA or phthalates may also carry risks.
- Framework Use:
  - The podcast provides a method to evaluate risks, costs, and benefits, enabling individuals to make informed decisions and move on confidently.

---

## Selected Links / Related Material

**A 2021 study estimating human consumption of microplastic estimated about 4 micrograms per week from seafood, tap water, bottled water, beer, and similar sources**: [Lifetime Accumulation of Microplastic in Children and Adults](https://pubs.acs.org/doi/10.1021/acs.est.0c07384) (Nor et al., 2021) [17:00]

**A 2023 study in Korea estimated between 140 and 310 micrograms per week, aligning with the upper limit of U.S. estimates**: [Analysis of microplastics in various foods and assessment of aggregate human exposure via food consumption in korea](https://www.sciencedirect.com/science/article/abs/pii/S0269749123001550) (Pham et al., 2023) [17:00]

**Claims that humans ingest a credit card’s worth of plastic (~5 grams) weekly**: [No Plastics in Nature: Assessing Plastic Ingestion from Nature to People](https://awsassets.panda.org/downloads/plastic_ingestion_press_singles.pdf) (University of Newcastle, 2019) [18:30]

- This estimate originated from a 2019 University of Newcastle study, commissioned by the WWF: [Plastic ingestion by people could be equating to a credit card a week](https://www.newcastle.edu.au/newsroom/featured/plastic-ingestion-by-people-could-be-equating-to-a-credit-card-a-week) (newcastle.edu) [18:30]
- **Scientific rebuttal of the “credit card” claim**: [Ingested microplastics: Do humans eat one credit card per week?](https://www.sciencedirect.com/science/article/pii/S2666911022000247) (Martin Pletz, 2022) [18:30]

**NEJM study on microplastics linked to health outcomes which evaluated carotid plaques from 150 participants**: [Microplastics and Nanoplastics in Atheromas and Cardiovascular Events](https://www.nejm.org/doi/full/10.1056/NEJMoa2309822) (Marfella et al., 2024) [32:15]

**Study in China that correlated MNP concentration in semen with sperm quality and quantity**: [Association of mixed exposure to microplastics with sperm dysfunction: a multi-site study in China](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(24)00405-5/fulltext) (Zhang et al., 2024)[37:30]

**BPA is detectable in the urine of 90% of adults, indicating widespread exposure and clearance**: [Concentrations of bisphenol-A in adults from the general population: A systematic review and meta-analysis](https://www.sciencedirect.com/science/article/abs/pii/S0048969721008226) (Colorado-Yohar et al., 2021) [1:06:00]

**Meta-Analysis on preterm birth found a 36% increased odds ratio for preterm birth with maternal urinary BPA exposure during pregnancy**: [Association of BPA exposure during pregnancy with risk of preterm birth and changes in gestational age: A meta-analysis and systematic review](https://www.sciencedirect.com/science/article/pii/S0147651321005121#:~:text=%E2%80%A2,susceptible%20period%20of%20preterm%20birth.) [1:08:30]

**BPA and Fertility — IVF Study**: [Urinary bisphenol A concentrations and early reproductive health outcomes among women undergoing IVF](https://pmc.ncbi.nlm.nih.gov/articles/PMC3501244/) (Ehrlich et al., 2012)[1:09:00]

**BPA has been associated with obesity, diabetes, cancer, and even all-cause mortality**: [Association Between Bisphenol A Exposure and Risk of All-Cause and Cause-Specific Mortality in US Adults](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2769313?utm_source=For_The_Media&utm_medium=referral&utm_campaign=ftm_links&utm_term=081720#google_vignette) (Bao et al., 2020) [1:10:00]

**BPA exposure from 2003-2012 went down by ~50% to an average of 25 ng/kg/day**: [Temporal trends in bisphenol A exposure in the United States from 2003–2012 and factors associated with BPA exposure: Spot samples and urine dilution complicate data interpretation](https://www.sciencedirect.com/science/article/pii/S0013935115001887) (LaKind et al., 2015) [1:13:00]**2013 study of the main sources of phthalates**: [Phthalate Concentrations and Dietary Exposure from Food Purchased in New York State](https://pmc.ncbi.nlm.nih.gov/articles/PMC3620091/) (Schecter et al., 2013) [1:26:45]

---