# #30 – Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease?

**Source:** [https://peterattiamd.com/tomseyfried/](https://peterattiamd.com/tomseyfried/)

---

In this episode, Thomas Seyfried, a cancer researcher and professor of biology at Boston College, discusses a controversial view of cancer as a mitochondrial metabolic disease. Many topics related to the causes, treatments, and prevention of cancer are covered in this in-depth conversation.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomseyfried/the_Drive_public.png)

Play

#30 - Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease?

#30 - Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease?

1x15s30s

0:002:48:06

## We discuss:

- How Tom got interested in cancer research [9:00];
- Calorie-restricted ketogenic diets, fasting, and epileptic seizures [18:30];
- Otto Warburg and the Warburg effect [30:45];
- Germline mutations, somatic mutations, and no mutations [42:00];
- Mitochondrial substrate level phosphorylation: Warburg’s missing link [51:30];
- What is the structural defect in the mitochondria in cancer? [1:02:00];
- Peter’s near-death experience with the insulin suppression test while in ketosis [1:06:30];
- Insulin potentiation therapy and glutamine inhibition [1:13:15];
- The macrophage fusion-hybrid theory of metastasis [1:39:30];
- How are cancer cells growth dysregulated without a mutation? [1:47:00];
- What is the dream clinical trial to test the hypothesis that we can reduce the death rates of cancer by 50%? [2:03:15];
- How can the hypothesis be tested rigorously that structural abnormalities in the mitochondria impair respiration and lead to compensatory fermentation? [2:26:30];
- Case studies of GBM survivors [2:32:45]; and
- More.

§

## Show Notes

## How Tom got interested in cancer research [9:00]

- Started at Yale University, working with lipid storage diseases and gangliosides
- His mentor at the time was working on ganglioside changes in tumors
- Looking at comparative biochemical profiles between human tumors and mouse tumors
- Also working on epilepsy around 1980
- Tom had an inkling that a ketogenic diet (KD) would be interested to study on epilepsy
- His grant was denied
- 10-15 years later, Tom is at Boston College and a Ph.D. student suggested they work on a KD
- Tom looked at a drug intended to reduce gangliosides and tumors
- They gave Tom $200,000 to look at how the drug was working
- They pair-weighted mice and found that the reduction in weight was likely the mechanism for the drug

## Calorie-restricted ketogenic diets, fasting, and epileptic seizures [18:30]

- Tom’s group published a paper on calorie restriction (CR) and the KD arguing the KD was working largely through CR and maintaining low blood sugar levels was the key to maintaining control of epileptic seizures
- They were trying to figure out the mechanisms and develop a diet that was therapeutic
- Cahill was looking at the Irish hunger strike
- Cahill starved patients for six months
- Postal worker who lost 250 pounds that Cahill studied
- A similar case of a patient that did a 382 fast
- In epilepsy, you have immediate feedback of increases in blood sugar and breakthrough seizures (invariably the seizure is related to a spike in blood glucose)
- In cancer, you don’t see immediate effects, so it’s more difficult to know when and if you’re in a therapeutic range
- Found out that calorie-restricted ketogenic diets (KD-R) seemed to be working for managing epilepsy and for managing cancer
- The mechanism for how a KD-R manages epileptic seizures is still not clear

## Otto Warburg and the Warburg effect [30:45]

- The mechanism for how a KD-R manages cancer is clear to Tom, and it’s based on Otto Warburg’s theory
- How was CR shrinking tumors? It was lowering blood sugar
- Warburg looked at the metabolism of tumors
- Found that cancer cells continue to ferment even in the presence of oxygen
- The Pasteur effect: the termination (or significant reduction) of fermentation in the presence of oxygen
- Warburg saw that cancer cells continued to produce lactic acid (a byproduct of fermentation) even in the presence of 100% oxygen — so the Pasteur effect was not in effect in this case
- Warburg looked at the mitochondria and noticed some defects
- Warburg concluded after a variety of experiments that in tumor cells, their respiratory (i.e., the mitochondrial machinery that undergoes cellular respiration — the lungs take in oxygen and get rid of CO2 that enables the majority of the cells in our body to perform cellular respiration) system was defective

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-50.png)

**Figure 1. Warburg theory of cancer.** Image credit: Tom Seyfried

Warburg’s seminal article in 1956: [On the origin of cancer cells](https://matveynator.ru/f/79d34fe7164d95daf0e041e94a738ac3.pdf)

- Later, Pete Pedersen from Johns Hopkins collated information and found that in every cancer cell, no matter what kind it was, there was some defect in the number, structure, and/or function of the mitochondria

**Evidence of mitochondrial damage**: [Tumor mitochondria and the bioenergetics of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/149996) (Pedersen, 1978)

- If the cell can’t generate enough energy through normal respiration, then it has to ferment
- Warburg stated that aerobic glycolysis (i.e., aerobic fermentation — fermenting in the presence of oxygen) is a secondary problem to the many different insults in the environment that damages respiration
- People focus on the Warburg effect — fermentation in the presence of oxygen — but the damage to respiration is the cause of the Warburg effect, according to Warburg
- Many people argue that respiration is normal in cancer cells
- They started looking at cells in cultures instead of looking at the tissues themselves
- Often what happens in a culture dish does not happen in the real world
- Many cells in culture look like they’re consuming a lot of oxygen and making lactic acid, they appear to be doing both
- Sidney Winehouse argued that the cancer cell needs so much energy that respiration by itself cannot be sufficient, and therefore the cancer cell both ferments and respires
- The mitochondria, the organelle that is needed to carry out efficient OXPHOS, is defective in some way, as Pedersen pointed out

**Evidence of mitochondrial damage**: [Tumor mitochondria and the bioenergetics of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/149996) (Pedersen, 1978)

- How the defect originated can vary from one type of cancer to another
- Not every cancer cell will have the exact same defect and respiration in the mitochondria some will have very few mitochondria

## Germline mutations, somatic mutations, and no mutations [42:00]

- Tom’s group sequenced the entire genome of five different independently derived cancers from mice, all derived from different origins, and didn’t find a single genetic pathogenic abnormality in mitochondrial DNA

**No pathogenic mutations found in mitochondrial DNA in Tom’s study**: [Absence of pathogenic mitochondrial DNA mutations in mouse brain tumors](https://bmccancer.biomedcentral.com/articles/10.1186/1471-2407-5-102) (Kiebish and Seyfried, 2005)

- [According to the National Cancer Institute](https://www.cancer.gov/about-cancer/causes-prevention/genetics), inherited genetic mutations play a major role in about 5 to 10 percent of all cancers
- Germline mutations in *TP53* can cause Li-Fraumeni syndrome, a rare, inherited disorder that leads to a higher risk of developing certain cancers
- Inherited mutations in the *BRCA1* and *BRCA2* genes are associated with hereditary breast and ovarian cancer syndrome, which is a disorder marked by an increased lifetime risk of breast and ovarian cancers in women
- However, none of these gene mutations are 100% penetrant, they are not deterministic genetic mutations, they are inherited risk factors
- If the inherited mutation damages the respiratory system of the cell, the probability of cancer increases
- Tumors associated with *BRCA1*, *BRCA2*, *P53* mutations are fermenters

> “Cancer, above all other diseases, has countless secondary causes. But, even for cancer, there is only one prime cause. Summarized in a few words, the prime cause of cancer is the replacement of the respiration of oxygen in normal body cells by a fermentation of sugar. All normal body cells meet their energy needs by respiration of oxygen, whereas cancer cells meet their energy needs in great part by fermentation. All normal body cells are thus obligate aerobes, whereas all cancer cells are partial anaerobes. From the standpoint of the physics and chemistry of life this difference between normal and cancer cells is so great that one can scarcely picture a greater difference. Oxygen gas, the donor of energy in plants and animals is dethroned in the cancer cells and replaced by an energy yielding reaction of the lowest living forms, namely, a fermentation of glucose”.

**—OTTO WARBURG, *The Prime Cause and Prevention of Cancer*, 1966 lecture to the meeting of Nobel Laureates at Lindau on Lake Constance**

- But there are some people with the exact same mutation but don’t get cancer (about 60% of women with the *BRCA1* mutation get breast cancer, leaving 40% of women with the mutation who don’t)
- You don’t get cancer if your mitochondria remain healthy, so cancer becomes a prevention issue
- If you can avoid the environmental risk factors that can damage respiration, you can reduce your risk of cancer

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-51.png)

**Figure 2. The oncogenic paradox and cancer as a metabolic disease**. Image credit: Tom Seyfried

> “The malignant transformation of tissues involves a paradox which, to my knowledge, has not been pointed out before. This transformation is a very specific process, which must involve very specific changes in a very specific chemical machinery. Accordingly, one would expect that such transformation can be brought about only by a very specific process, as locks can be opened only by their own keys. Contrary to this, a malignant transformation can be brought about by an infinite number of unspecific influences, such as pieces of asbestos, high-energy radiation, irritation, chemicals, viruses, etc. It is getting more and more difficult to find something that is not carcinogenic. That a very specific process should be elicited in such an unspecific way is very unexpected.”

**—ALBERT SZENT-GYORGYI, *The Living State and Cancer*, 1977**

- Tom believes we know of no living cancer that has normal respiration
- But when you grow tumors in culture, people think they have normal respiration because they take in oxygen
- But when you look at the structure and architecture of the tissue in vivo, invariably you find damage to the structure and function of mitochondria
- The field has put more credibility into the results from cell culture work than the actual tissues
- The Warburg effect was largely forgotten for many years after his initial observation was right
- After Watson and Crick discovered the DNA as the origin of the genetic material, the field shifted away from traditional biochemical analysis to molecular biology, and therefore more and more mutations and genetic defects are found, leading people to believe these are the causes of cancer
- Experiments done in viruses appeared to show a cause-and-effect relationship when you introduce viral particles into cells and they would integrate into the nuclear genome, and then cells became transformed into neoplastic cells
- What they didn’t realize was that those same viruses went into the mitochondria and damaged respiration
- Sometimes the viruses can infect directly into the mitochondria and produce proteins that damage the electron transport chain
- Other times viruses integrate into the nuclear genome, producing a protein product that then disrupts the mitochondria
- Similar to viruses, when you look at inherited mutations, they can disrupt mitochondrial function
- If they disrupt mitochondrial function, you are at risk for developing a neoplasm in that particular population of cells
- Even in the slowest growing tumors, they are fermenting: Dean Burk looked at hepatomas that supposedly did not ferment, and he found that they did in fact have a significant elevation of lactic acid production over a normal cell

**The Warburg effect as need for cellular building blocks**

- Vander Heiden, Thompson, and Cantley proposed that the Warburg effect is not about the need for energy, but for building blocks of the cell
- In the process of upregulating the Embden-Meyerhof pathway, you are going to get the carbons for building blocks
- At the same time, you’re going to get some energy through the pyruvate kinase system
- This group has said there’s nothing wrong with the mitochondria
- You have to ignore a massive amount of evidence to make those kinds of statements, Tom says, and ignore everything that Pete Pedersen has done

**Evidence of mitochondrial damage**: [Tumor mitochondria and the bioenergetics of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/149996) (Pedersen, 1978)

- But in order for a cell to grow you need a lot of building blocks
- The building blocks are coming from the pentose phosphate pathway, the glycolytic pathway, and also from glutamine
- Cancer cells are sucking down glutamine, you’re getting the amide nitrogen to form the nucleotides, you’re getting the glutamate for anaplerosis in the TCA cycle (i.e., the act of replenishing TCA cycle intermediates that have been extracted for biosynthesis)
- Between glucose and glutamine, you’re getting all of the building blocks you need for rapid cell division
- Where is the energy coming from?

## Mitochondrial substrate level phosphorylation: Warburg’s missing link [51:30]

- Tom proposed years ago that glucose fermentation was only part of the puzzle of the Warburg effect
- Cancer cells can ferment both glucose and glutamine
- Glutamine is fermented via mitochondrial substrate level phosphorylation (mSLP) in the TCA cycle of the mitochondria
- mSLP: the production of ATP when you move a phosphate group from an organic substrate onto an ADP molecule: an ancient way of generating energy
- An organic molecule that is an electron acceptor instead of oxygen
- Succinyl CoA has a phosphate group on a serine inside the protein itself, and that phosphate group is then donated to ADP (sometimes GDP to make GTP, depending on the situation) to make ATP
- You’re moving phosphate groups from an organic substrate onto the ADP as the acceptor, and you can generate massive amounts of energy from this process which can replace the level of lost energy from the damaged mitochondria
- In the normal cell you’re making most of your ATP from oxidative phosphorylation (OXPHOS), in the cancer cell you’re making most of it from mSLP inside the same organelle (i.e., the mitochondria)
- Hochachka did experiments trying to hold various aquatic animals on the water and looking at the metabolic changes that occurred.
- Succinic acid is part of the in the electron in the TCA cycle is a powerful stimulatory towards oxidative phosphorylation and it was being dumped out into the into the circulation.
- It wasn’t being oxidized. He claimed that it was amino acid fermentation that was doing this.
- The body was grabbing amino acids and metabolizing them and generating energy through substrate level phosphorylation.
- Substrate level phosphorylation in the mitochondria may be far greater than the amount of ATP produced in the cytoplasm of tumor cells

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-52.png)

**Figure 3. Energy metabolism in normal cells.** Image credit: Tom Seyfried

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-53.png)

**Figure 4. Energy metabolism in normal cells.** Image credit: Tom Seyfried

## What is the structural defect in the mitochondria in cancer? [1:02:00]

- The mitochondrial damage or defect can happen in a number of different ways
- A carcinogen enters into the mitochondria and causes oxidative stress
- Tom’s group found no mutations in mtDNA, and they knew the cells were fermenting, they started looking at the lipidome (i.e., the lipids inside the mitochondria)
- Cardiolipin, the signature lipid in the mitochondrial inner membrane, is defective in all tumor cells they’ve looked at

**Cardiolipin and mitochondrial abnormalities**: [Cardiolipin and electron transport chain abnormalities in mouse brain tumor mitochondria: lipidomic evidence supporting the Warburg theory of cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2582368/) (Kiebish et al., 2008)

- Abnormal lipids affect the function of the proteins of the ETC
- Not going to generate the amount of ATP through OXPHOS because the very lipid and protein structures are abnormal
- The problems in mitochondrial function force the cells into fermentation
- They ferment lactic acid and succinic acid, byproducts of glucose and glutamine metabolism, respectively
- Glucose and glutamine drive cancer through substrate level phosphorylation occurring in the cytoplasm where they can build a lot of metabolites for growth and also through the pathway called glutaminolysis

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-54.png)

**Figure 5. Abnormal mitochondria.** Image credit: Tom Seyfried

**How low can glucose and glutamine go?**

- Through therapeutic fasting and insulin injections, glucose levels can go remarkably low
- Using calorie-restricted ketogenic diets, transition normal cells to ketones for fuel, while also keeping them hungry for glucose, and now normal cells are competing with tumor cells for glucose

## Peter’s near-death experience with the insulin suppression test while in ketosis [1:06:30]

Excerpt from the [Episode 65](https://tim.blog/2015/03/18/mark-hart-raoul-pal-peter-attia/) of the Tim Ferriss Show ([transcript](https://www.transcripts.io/pdfs/tim_ferriss_show/2015-03-11-peter-attia.pdf)):

- Insulin suppression test at Stanford. It was administered by the team of Jerry Reaven.
- So the way the test works is you show up in the morning, overnight fast, they hook you up to two huge IVs. So 14 or 16 gauge IVs, one in each arm, and they give you insulin in one and glucose in the other.
- And the dose of glucose and the dose of insulin is determined by your body weight and your surface area. And they’ve done this in thousands of patients for about 35 years now, so they have this pretty well dialed in.
- And let’s say your starting glucose was 90, which I think mine was. What they’re going to do is follow you for the next six hours with this constant infusion of glucose and insulin, and they check you every 30 minutes, and where you end up when you hit a steady state of glucose determines how good you are at glucose disposal, which is really the best metric we have for insulin sensitivity. So the higher your glucose at the end of that test, the less able you are to dispose of glucose, the more insulin resistant you are. And they had just published a series looking at 440 or so non-diabetic patients undergoing this test, and I believe that the range of glucose levels at steady state varied between as low as 75 to 80 and as high as 400. So obviously that person at 400 is basically prediabetic, and that person at 75 is very insulin sensitive.
- So I had a very bizarre experience there, which is my glucose started to go down very quickly. So the post-doc who was running my test quickly realized that I was very insulin sensitive, or to be more specific, I was very able to dispose of glucose, and so they actually broke protocol and lowered my insulin level.
- And my glucose level kept falling, and by the way, so did my ketone levels. So I walked into the test with a glucose of, I don’t know, 90, and a ketone level of like two and a half millimolar, and I very quickly started to go down in glucose, down in ketones, and the test ended pretty badly.
- Basically at about 90 minutes, my glucose was in the 40s, I was starting to become symptomatic, they stopped the insulin, gave me more glucose, but then I really fell off a cliff. My glucose got down to 32, ketones were near zero, now I was profoundly symptomatic.
- That’s actually the closest I’ve ever come to biting the big one doing one of my goofy self-experiments. Because they had to bolus me with pure dextrose, it’s called D50, the IV infiltrated, the whole thing was a total disaster, but luckily in the end, they rescued me, and the punchline is I guess I’m the most insulin sensitive person they’d ever measured.
- As part of that, I also did an oral glucose tolerance test a couple of weeks later, and the results there were quite similar. So I started out at a glucose of, I don’t know, 90, or maybe 89 I think, and an insulin level of maybe four and at one hour the glucose was up to maybe 105 and the insulin was up to like 15, and at two hours glucose was in the 70s and insulin was maybe down to six. So again, that would be a great example of glucose disposal.

## Insulin potentiation therapy and glutamine inhibition [1:13:15]

- Insulin potentiation, giving insulin to lower blood sugar in ketosis, can push glucose levels down really low
- However, insulin is also considered pro-tumorigenic and facilitates the uptake of glucose
- But if you have very little glucose around, there’s very little glucose to push into cells
- if you have very little glucose, give insulin, it does not stimulate tumor growth – we have data to support that

**Insulin infusions on metabolically supported chemotherapy**: [Long-Term Outcomes of the Treatment of Unresectable (Stage III-IV) Ductal Pancreatic Adenocarcinoma Using Metabolically Supported Chemotherapy (MSCT): A Retrospective Study](https://pancreas.imedpub.com/longterm-outcomes-of-the-treatment-of-unresectable-stage-iii--ivductal-pancreatic-adenocarcinoma-using-metabolically-supported-chemotherapy-msct-a-retrospective-study.php?aid=7498) (Iyikesici et al., 2015)

**Insulin infusions on metabolically supported chemotherapy**: [Complete Response of Locally Advanced (stage III) Rectal Cancer to Metabolically Supported Chemoradiotherapy with Hyperthermia](https://sciforschenonline.org/journals/cancer-research/IJCRMM-2-120.php) (Iyikesici et al., 2016)

**Insulin infusions on metabolically supported chemotherapy**: [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/) (Iyikesici et al., 2017)

- So, in fact, the Germans used to do that they used to put people into insulin comas
- If they were in ketosis, you can give a lot of insulin and they’re not going to die

**Insulin infusions in subject pushed down to less than 1 mmol/L**: referenced in Cahill and Aoki, 1980 — Infused insulin to push glucose to ~ 1 mmol (like less than 20 mg/dl) which is basically FATAL in most cases (2 mmol puts you in a coma normally)

See the [podcast with Dom D’Agostino](https://peterattiamd.com/domdagostino/) for more on this Cahill experiment

Seyfried paper: [Iyikesici et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/):

> “In practice, MSCT initiates with a 12-hour fast, the application of pharmacological doses of regular insulin, and the development of mild hypoglycemia prior to the administration of chemotherapy. As was previously demonstrated in a case report of rectal cancer and a case series in pancreatic cancer, MSCT may enhance the cytotoxic effects of chemotherapy.
>
> [. . .]
>
> “An MSCT protocol designed for the patient consisted of docetaxel (30 mg/m2), doxorubicin (20 mg/m2), and cyclophosphamide (250 mg/m2). This drug combination was administered following a 12-hour fast and the introduction of 5 to 10 units of regular insulin (Humulin R). Chemotherapy delivery was initiated at blood glucose levels of 50 to 60 mg/dL. With the patient’s written and informed consent, this therapy was delivered on the first and eighth day of a 21-day cycle for a total of four months. Insulin delivery and chemotherapy infusions were delivered after assessing blood glucose levels upon arrival at the clinic, and the insulin dosage was sufficient to lower her blood glucose to approximately 50 mg/dL prior to delivery of the chemotherapy drugs.”

**Reference to patients put in insulin comas**: [Wilhelm Brünings’ forgotten contribution to the metabolic treatment of cancer utilizing hypoglycemia and a very low carbohydrate (ketogenic) diet](https://www.sciencedirect.com/science/article/pii/S2225411018301743) (Klement, 2018)

> “Proof-of-principle that hypoglycemia itself can induce tumor regression was provided in 1962 by Koroljow who reported the achievement of a one-year complete remission in two metastasized cancer patients who were put into an insulin coma (lowest blood glucose reading 22 mg/dl). A multitude of recent in vitro experiments have shown that in contrast to normal cells, many tumor cells are very vulnerable to glucose withdrawal by mechanisms involving both energy stress and oxidative stress. Again, this confirms the metabolic inflexibility of tumor cells arising from their dysfunctional mitochondria as described above.”

**Reference to patients put in insulin comas**: [Two cases of malignant tumors with metastases apparently treated successfully with hypoglycemic coma](https://link.springer.com/article/10.1007%2FBF01586115) (Koroljow, 1962)

**Glutamine inhibition**

- Glutamine inhibition using **“DON,” a glutamine antagonist**: [6-Diazo-5-oxo-L-norleucine (DON)](https://en.wikipedia.org/wiki/6-Diazo-5-oxo-L-norleucine)
- They used to use it on cancer patients previously, but they never targeted glucose at the same time so the tumor cells were sucking down the glucose

**DON previously used in cancer**: [6-Diazo-5-oxo-L-norleucine, A New Tumor-inhibitory Substance. II.1 Isolation and Characterization](https://pubs.acs.org/doi/abs/10.1021/ja01594a036?journalCode=jacsat) (Dion et al., 1956)

**DON previously used in cancer**: [The Rediscovery of DON (6-Diazo-5-oxo-L-norleucine)](https://link.springer.com/chapter/10.1007/978-3-642-81488-4_30) (Kisner et al., 1980)

**DON prodrugs**: [Abstract 3524: Novel prodrugs of the glutamine antagonist 6-diazo-5-oxo-norleucine (DON) as treatment for malignant peripheral nerve sheath tumor](https://cancerres.aacrjournals.org/content/78/13_Supplement/3524.short) (Lemberg et al., 2018)

- You can even make the tumor cells more glucose sensitive if you take glutamine away
- Cellular immune cells are glutamine dependent
- If you kill too many of the tumor cells too quickly you’ve got to have a cell system to remove the corpses. You’ve got to have some immune cells
- That’s what the macrophages do.
- And some of these other immune cells will come in and remove the corpse the dead cells
- Otherwise you get infections you die from the indirect effects of these things.
- So you have to know how to strategically target glutamine without compromising the normal physiological systems that we have

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-55.png)

**Figure 6. Glutamine targeting using DON.** Image credit: Tom Seyfried

**The Press-Pulse concept**

**Press-pulse**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Seyfried et al., 2017) [01:17:00]

- You press the glucose hard with diets and drugs and then you pulse the glutamine
- The hypothesis is that you target the glutamine with a drug that will selectively kill tumor cells — paralyze the immune system — but then immediately give large amounts of glutamine back
- You’re going to restore your gut and immune system because they’re only paralyzed, they’re not killed

**The chasm in belief systems regarding respiration**

- What set of experiments can resolve this debate?
- Tom is working on a strategy to test the hypothesis and question of whether fermentation is a compensatory response to impaired respiration (Figure 7)

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-8.jpeg)

**Figure 7. Tom’s whiteboard.**

- Bottom line: where are tumor cells getting their energy from?
- Without energy, there is no life

> “I read massive amounts of literature and looked carefully at everything: the structure and function of the mitochondria of tumor cells are compromised. In my mind that is a solid fact, and to deny that, one would have to ignore the evidence that I’ve looked at. You have to look at the mitochondria and say, ‘No that mitochondria that have no cristae and have very few in number, there’s nothing wrong with it.’ OK, let’s call white black and black white.”

- Why don’t we look at the activity of the proteins in the electron transport chain?
- The mitochondria have turned over all of their DNA except for 13 critical genes that control the life of the cell
- The mitochondria gave up most of their ~1,000 genes but still hold the keys to the kingdom
- Anything goes wrong with these genes and you’re dead
- Why don’t cancer cells die through the apoptotic mechanism?
- Because the very organelle that controls the kill-switch doesn’t work
- The cell bypasses the normal control of life and death — apoptosis in the cell — because the very organelle that dictates that is now defective
- Consequently, this cell now is reverting back to the way it existed before oxygen came into the atmosphere on the planet
- They were all fermenters: they grew up with unbridled proliferation until the fermentable fuel in the environment disappeared
- We found a lot of substrate level phosphorylation in the mitochondria the TCA cycle was discovered in stressed hearts

**Substrate level phosphorylation**: [Accumulation of Succinate in Cardiac Ischemia Primarily Occurs via Canonical Krebs Cycle Activity](https://www.ncbi.nlm.nih.gov/pubmed/29847793) (Zhang et al., 2018)

**Substrate level phosphorylation**: [The role of matrix substrate-level phosphorylation during anoxia](https://repo.lib.semmelweis.hu/bitstream/handle/123456789/2195/kissgergely.d_DOIs.pdf?sequence=1) (Kiss, 2014)

**Substrate level phosphorylation**: [Succinate, an intermediate in metabolism, signal transduction, ROS, hypoxia, and tumorigenesis](https://www.sciencedirect.com/science/article/pii/S0005272816300597) (Tretter et al., 2016)

**Substrate level phosphorylation**: [Mitochondrial diaphorases as NAD+ donors to segments of the citric acid cycle that support substrate-level phosphorylation yielding ATP during respiratory inhibition](https://www.fasebj.org/doi/abs/10.1096/fj.13-243030?journalCode=fasebj) (Kiss et al., 2014)

- Their heart should be dead. Why is it still functioning: where’s the ATP coming from?
- They found that most of the energy in the heart is coming from mSLP for short periods of time
- The heart and brain are remarkably dependent on oxidative phosphorylation for function and disruption of oxidative phosphorylation are usually catastrophic for those cells
- What happens is the mitochondrial stress response or retrograde signaling, and this is where the oncogenes come in
- The oncogenes are transcription factors that upregulate fermentation pathways
- When you damage the respiratory system of a cell, HIF-1 alpha becomes stabilized and now you can up regulate glucose transporters into the cell, Myc for example
- There are all the overlap each other
- Lactic acid dehydrogenase (LDH), all these enzymes that are geared for maintaining a fermentation metabolism
- The transcription factors that make those pathways upregulated are the oncogenes
- If you’re not going to get the same level of energy out of your OXPHOS, you’ve got to compensate to get it because the singular most largest consumer of energy in any cell is the pumps
- These pumps that are on the surface of the cells that maintain the ionic gradients that allow what we call life
- Because once you reach equilibrium you’re dead
- So most of the energy in any cell: cancer cell, heart cell: it’s the proton motive gradient across the membrane that determines whether or not that cell is going to be alive or not

**States of equilibrium**: [Origin of Cancer: An Information, Energy, and Matter Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5112236/) (Hanselmann and Welter, 2016)

> “In physics, a stable state of a system is an equilibrium state (Wolfe, 2015). When a process reaches equilibrium, reactivity stops because all driving forces are weakened. All systems follow this basic rule. However, because of its high degree of order, a cell is far away from equilibrium. This is possible because cells are open thermodynamic systems, which gives them the opportunity to permanently ingest matter and energy and to release waste, and thereby to preserve order (low entropy). Moreover, during evolution, the cell has gained a set of information molecules (e.g., DNA, RNA, and proteins) that guarantees self-preservation by self-organized processes and autonomous reproduction, and the transfer of that information from generation to generation (Alberts et al., 2011). A cell is a thermodynamic, open system that is far away from equilibrium.”

- You need any ATP for that
- If the ATP dissipates, you swell and die
- So you have to then determine: where is my ATP coming from? How am I going to keep those pumps going?
- If fermentation becomes a replacement, I’m going to need a lot of extra fermentable fuels to make up the loss of the energy that I’m getting out of OXPHOS
- Oncogenes have to turn on because they are the transcription factors that upregulate the transporters for glucose and glutamine
- You’re bringing into alternative fuels to make up the difference and therefore the genetic behaviour of the cell begins to change
- And because the cell is now using damaged respiration you throw out a lot of reactive oxygen species (ROS)from the damaged respiratory system and ROS are mutagenic and carcinogenic
- The nuclear genome gradually collects all these different mutations and defects coming from the ROS of the mitochondria
- But at the same time the cell is not dying from this ROS because it’s being protected by the fermentation pathways of glucose and glutamine

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-56.png)

**Figure 8. Glucose and glutamine drive tumor growth and energy metabolism.** Image credit: Tom Seyfried

**Press-Pulse**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Seyfried et al., 2017) [01:17:00]

There are a few papers reporting on lactic acidosis from massive leukemias

**Lactic acidosis and leukemia**: [A Case of Type B Lactic Acidosis in Acute Leukemia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2852807/) (Lee et al., 2010)

**Lactic acidosis and leukemia**: [Chronic Lactic Acidosis and Acute Leukemia](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/576471) (Roth and Porte, 1970)

**Lactic acidosis and leukemia**: [Lactic acidosis in a patient with acute leukemia](https://www.ncbi.nlm.nih.gov/pubmed/6576875) (Grossman et al., 1983)

**Lactic acidosis and leukemia**: [A case of type B lactic acidosis as a complication of chronic myelomonocytic leukaemia: a case report and review of the literature](https://jmedicalcasereports.biomedcentral.com/articles/10.1186/1752-1947-9-16) (Gardner and Griffiths, 2015)

**Lactic acidosis and leukemia**: [Lactic acidosis: A metabolic complication of hematologic malignancies](https://onlinelibrary.wiley.com/doi/full/10.1002/1097-0142%2820011101%2992%3A9%3C2237%3A%3AAID-CNCR1569%3E3.0.CO%3B2-9) (Sillos et al., 2001)

**Angiogenesis**

- Some of the lactic acid is persisting, the hydrogen ions are persisting until they can ooze out into the local bloodstream and get back to the liver
- But otherwise it’s going to be a real acidic mess which then contributes further to the fermentation behaviour of the cells which then are resistant
- They don’t need blood blood vessels.
- This is why the anti-angiogenic field has failed because they said, “Well, we’ll target the blood vessels and therefore the cells will die because they can’t get the oxygen”
- But the cancer cell doesn’t need the blood vessels, it can ferment

## The macrophage fusion-hybrid theory of metastasis [1:39:30]

- This is a concept that goes all the way back to Aichel from the early 1900s in Germany
- He was observing fusion behavior between the neoplastic cells and the cells of our immune system
- And then claimed that he thinks after this fusion event, that these cells become much more aggressive and much more dispersive than before these fusion events

**Otto Aichel paper on tumor cell fusion (in German)**: [XIII. Geschwülste und Zellverschmelzung mit qualitativ abnormer und qualitativ normaler Chromosomenverteilung](https://books.google.com/books?id=hWggAQAAIAAJ&pg=PA92&lpg=PA92&dq=XIII.+Geschwu%CC%88lste+und+Zellverschmelzung+mit+qualitativ+abnormer+und+qualitativ+normaler+Chromosomenverteilung&source=bl&ots=KYFjdFe4uo&sig=5eQa8mzsG5-i6ac025SIN5XMLz8&hl=en&sa=X&ved=2ahUKEwjurtf9g-jeAhXMnuAKHULZB5UQ6AEwCHoECAcQAQ#v=onepage&q=XIII.%20Geschwu%CC%88lste%20und%20Zellverschmelzung%20mit%20qualitativ%20abnormer%20und%20qualitativ%20normaler%20Chromosomenverteilung&f=false) (Aichel, 1911) [1:40:00]

**Otto Aichel (Bob Kaplan’s rough translation in English)**: [XIII. Tumors and cell fusion with quality of abnormal and qualitatively normal chromosomes distribution](https://www.dropbox.com/s/lxcravmgx7xdyxn/%23aichel%20%231911.pdf?dl=0) (Aichel, 1911) [1:40:00]

- This was then solidified by the work of John Pawelek at Yale University where he did some experiments showing that malignant melanoma is actually a macrophage disease
- The resultn of fusion hybridization

**Pawelek on tumor cell hybrids**: [Fusion of bone marrow-derived cells with cancer cells: metastasis as a secondary disease in cancer](https://www.ncbi.nlm.nih.gov/pubmed/24589183) (Pawelek, 2014) [1:40:15]

**Pawelek on tumor cell hybrids**: [Cancer-cell fusion with migratory bone-marrow-derived cells as an explanation for metastasis: new therapeutic paradigms](https://www.ncbi.nlm.nih.gov/pubmed/18684055) (Pawelek, 2008) [1:40:15]

**Pawelek on tumor cell hybrids**: [Leukocyte-cancer cell fusion: initiator of the warburg effect in malignancy?](https://www.ncbi.nlm.nih.gov/pubmed/21506013) (Lazova et al., 2007) [1:40:15]

**Pawelek on tumor cell hybrids**: [Tumour-cell fusion as a source of myeloid traits in cancer](https://www.ncbi.nlm.nih.gov/pubmed/16321767) (Pawelek, 2005) [1:40:15]

**Pawelek on tumor cell hybrids**: [Tumor cell hybridization and metastasis revisited](https://www.ncbi.nlm.nih.gov/pubmed/11198471) (Pawelek, 2000) [1:40:15]

**Pawelek on tumor cell hybrids**: [The cancer cell—leukocyte fusion theory of metastasis](https://www.ncbi.nlm.nih.gov/pubmed/19055949/) (Pawelek and Chakraborty, 2008)

- This was then further established by Melissa Wong
- Showing in the colon how macrophages are fusing with neoplastic stem cells

**Wong on tumor cell fusion**: [Cell fusion potentiates tumor heterogeneity and reveals circulating hybrid cells that correlate with stage and survival](https://www.ncbi.nlm.nih.gov/pubmed/30214939) (Gast et al., 2018)

**Wong on tumor cell fusion**: [Bone marrow-derived cells fuse with normal and transformed intestinal stem cells](https://www.ncbi.nlm.nih.gov/pubmed/16606845) (Rizvi et al., 2006)

**Wong on tumor cell fusion**: [Fusion between Intestinal epithelial cells and macrophages in a cancer context results in nuclear reprogramming](https://www.ncbi.nlm.nih.gov/pubmed/21303980) (Powell et al., 2011)

**Wong on tumor cell fusion**: [Characterization of the intestinal cancer stem cell marker CD166 in the human and mouse gastrointestinal tract](https://www.ncbi.nlm.nih.gov/pubmed/20826154) (Levin et al., 2010)

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-57.png)

**Figure 9. The macrophage fusion hybrid hypothesis of metastatic cancer.** Image credit: Tom Seyfried

Seyfried and Huysentruyt, 2015: [On the origin of cancer metastasis](https://www.ncbi.nlm.nih.gov/pubmed/23237552)

- Macrophages, the cells of our immune system, are extremely extremely fusogenic
- They do this for wound healing
- You’ll see multinucleated giant cells in a lot of parts of our bodies during wound healing
- And with cancer cells, you also find a lot of these multinucleated kinds of cells
- Our body recognizes wounding as an acute problem
- The immune system will come into that local area to facilitate wound healing
- And when the wound persists sometimes these cells will fuse with each other and fuse with other cells in the microenvironment to facilitate wound healing
- The problem is if you have an epithelial cell like a breast cell or a colon cell that is becoming neoplastic, becoming dysmorphic in its growth
- And it’s fermenting ,but it doesn’t have the capacity to grow anywhere outside of that local area, it doesn’t have have the capacity.
- So our immune cells come into this lesion that’s persisting
- The immune cell throws out growth factors and cytokines to facilitate the wound healing.
- The problem is those factors are also facilitating the growth of the neoplastic cells
- So the neoplastic cell is dysregulated, but the very cell that’s coming in to try to correct the wound is now provoking the cell to grow even more
- Their cytoplasms are becoming diluted with the abnormal mitochondria from the stem cells.
- The stem cells cannot metastasize because they’re not genetically programmed to do that
- We end up with hybrid macrophages, fused hybrids, which are now genetically programmed to enter and exit the circulation, survive immune attack
- It’s one of the most powerful cells that we have in our bodies
- What we have now are rogue macrophages
- Macrophages live in hypoxic environments: anti-angiogenic therapies are not going to work on those kinds of cells
- The other thing is macrophages love glutamine
- We’re dealing with one of the toughest cells: this is the origin of metastasis, according to Tom

## How are cancer cells growth dysregulated without a mutation? [1:47:00]

- You have cells that are carcinogenic, that are tumorigenic, that have no mutations
- Baker was on person who pointed this out

**Stuart Baker on tumors with zero mutation**s: [A Cancer Theory Kerfuffle Can Lead to New Lines of Research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4326310/) (Baker, 2014)

- On the other hand we have skin cells loaded with so-called driver mutations
- But they never form a tumor

**Skin cells have many so-called driver mutations that never form a tumor**: [High burden and pervasive positive selection of somatic mutations in normal human skin](https://www.ncbi.nlm.nih.gov/pubmed/25999502) (Martincorena et al., 2015) [1:47:30]

**Normal esophageal tissue with so-called driver mutations**: [Somatic mutant clones colonize the human esophagus with age](https://www.ncbi.nlm.nih.gov/pubmed/30337457) (Martincorena et al., 2018) [1:47:30]

- So this linkage between the number of mutations and the type of cancer is just there’s so many flaws in this.
- So there are there are cancer cells that have been looked at that have highly invasive metastatic and they can’t find the mutations in there, not common but it happens.
- It’s a violation to the whole concept in glioblastoma. There are some tumours that have been found that have none of the driver mutations, none of the abnormalities that you would have expected that are found in others. So there’s a break linkage between.
- You don’t need new mutations to cause a metastatic lesion.

**One sample (Br20P) in GBM showed zero driver mutations**: [Cancer Genome Landscapes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3749880/) [[supplement](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3749880/bin/NIHMS496129-supplement-Supplementary_Material.xlsx)] (Vogelstein et al., 2013) [1:47:00]

**Br20P sample in GBM**: [An Integrated Genomic Analysis of Human Glioblastoma Multiforme](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2820389/) (Parsons et al., 2008)

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-58.png)

**Figure 10. Problems with the somatic mutation theory of cancer.** Image credit: [Travis Christofferson](https://www.youtube.com/watch?v=ownKQ6xjeg0&t=1142s)

- 100 articles in the literature with medicine that GBM to various organs for people dying
- Studies that have looked for metastasis in GBM have found them — problem is patients aren’t living long enough to worry about metastasis in GBM — in 12 months most people are dead: over 100 studies of extracranial metastasis in glioblastoma

**Extracranial metastases of GBM**: [Extracranial metastases of high-grade glioma: the clinical characteristics and mechanism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5639596/) (Sun et al., 2017)

**Extracranial metastases of GBM**: [The natural history of extracranial metastasis from glioblastoma multiforme](https://www.ncbi.nlm.nih.gov/pubmed/21512826) (Lun et al., 2011)

- There was a paper looking at survival for GBM and they said it’s woefully similar to the 1926 Bailey and Cushing paper from 1926.

**GBM survival today similar to 1926 survival rates**: [Persistent Disparities in Survival for Patients with Glioblastoma](https://www.sciencedirect.com/science/article/pii/S1878875018318977) (Fatehi et al., 2018) [1:58:00, 2:35:00]

> “Recent clinical trials report median overall survival (OS) of 14-20 months, with significant improvements for patients with certain genetic characteristics. However, population-level studies find median OS to be 8-14 months in North America, which are woefully similar to numbers reported by Cushing a century ago.”

**Cancer death rates**

Cancer deaths in the last 5 years in the US: 3.5% increase in deaths

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-59.png)

**Figure 11. Percentage increase in cancer deaths.** Image credit: Tom Seyfried

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-60.png)

**Figure 12. Age-adjusted death rates as reported in various governmental sources.** Image credit: [Clifton Leaf](https://www.amazon.com/Truth-Small-Doses-Losing-Cancer/dp/1476739994)

The issue between crude death rates age-adjusted death rates: from [The Truth in Small Doses](https://www.amazon.com/Truth-Small-Doses-Losing-Cancer/dp/1476739994) by Clifton Leaf:

> If nonexperts are unaware of the distinction between crude rates and their standardized counterparts, it is perhaps surprising how many experts are as well. Alas, **the tendency among veteran researchers and policymakers to conflate age-adjusted rates with the true burden of disease is so common that the National Center for Health Statistics has issued one caveat after another telling people not to do so**. Warns one of the agency’s instructional guides:
>
> “The age-adjusted death rate does not reflect the mortality risk of a “real” population. The average risk of mortality of a real population is represented by the crude death rate. The numerical value of an age-adjusted death rate depends on the standard used and, therefore, is not meaningful by itself.”
>
> Cautions another:
>
> “It is very important to realize that the age-adjusted death rate (ADR) is an artificial measure whose absolute value has no intrinsic meaning. The ADR is useful for comparison purposes only, not to measure absolute magnitude. (To compare absolute magnitude, crude rates are used.)”
>
> If nothing else, this mouthful of a term—age-adjusted death rate—ought to signal its own modest warning, suggesting that the meaning may not be quite so obvious. But then, much of the time, the ungainly modifier is dropped like a dinner jacket, and by the time the news is passed along to the public, death rate has often settled into deaths. As a result, millions of people miss the enormous hypothetical that follows each report of victory in the war on cancer. Even the experts breeze by this elephant of an “if”:
>
> Yes, cancer deaths have been falling . . . but only if the United States is a living wax museum where each inhabitant’s age is fixed for eternity. Only if real life is a still life.
>
> It isn’t, of course. The country’s population grew from 1990 to 2009—not only much bigger (adding 58 million residents), but older, too. The nation’s median age jumped by nearly four years, to 36.7.
>
> Moreover, it aged in a nonobvious way. America, it turned out, began to bulge in the midriff, like a caricature of a prosperous middle-aged burgher. Over this brief span of time, for instance, the cohort of 45-to-64-year-olds surged by more than 33 million people—increasing its representation in the overall population by 7.3 percentage points as the proportions of younger groups, in turn, declined.
>
> This is exactly what real populations do—they swell and shrink in often sweeping ways. America in 2009 looked no more like the 2000 standard than a distant cousin, and it resembled even less the America of 1990. The cohort of 45- to-64-year-olds in 2009 accounted for nearly 26 percent of the US population, far above the share reserved in the 2000 template (22 percent), and in 1990 (19 percent). And by 2020, this crop of baby boomers will constitute a still larger share of the country.
>
> The point is important. For here, i**n this group of middle-aged Americans, can be found more than a third of all new cancer cases and more than a quarter of all deaths. Each year, the disease kills more people in this otherwise vital age group than the next three leading causes of death (heart disease, accidents, and chronic lower respiratory disease) combined**.
>
> So if for no other reason than the group’s surging numbers, **there were more cancer fatalities in 2009 among 45-to-64-year-olds—some twenty-three thousand more, in fact—than there had been nineteen years earlier. The group’s share of overall cancer mortality, moreover, had gone up, not down since 1990. Yet by the time the raw mortality figures for 2009 emerged from the standardization model, most of these additional deaths had vanished from the accounting**. Scaled out of the age-distribution model, they simply did not exist. Gone were thousands of people, relegated to a statistical potter’s field.
>
> By the NCI’s accounting, the “death rate” for this ample slice of the population fell an incredible 31 percent over the period.
>
> As great as the undercounting has been, the more profound concern is not what has already happened, but what will.
>
> A demographic storm is coming to the United States. According to the Census Bureau, the number of Americans age sixty-five through eighty-four will soar in the coming decades. And as high as the actual cancer death rates are in the great swath of middle age (where much of the boomer generation now sits), they are over three times higher in the age group above.
>
> Already, according to the 2010 census, nearly 35 million people between the ages of sixty-five and eighty-four reside in the United States. By 2025, this age group is projected to number 57 million, representing roughly 16 percent of the nation.
>
> The shift in the population pyramid will be as consequential for America as it is colossal. Legions of social scientists and think-tankers have already spun one scary scenario after the next on the fates of Social Security and Medicare. But the sheer scale of the country’s expanding cancer burden has yet to be recognized by those entrusted with measuring it. Nor is this fast-rising burden likely to be acknowledged in the NCI’s annual progress reports anytime soon.
>
> After all, in the official playbook, the proportion of people age sixty-five through eighty-four stands at a mere 11 percent . . . and that figure is not due for a revision until 2030.
>
> Eventually, of course, the cancer leadership’s own assessment will have to catch up with reality. America’s aging population cannot be filtered out of the question “How many people are dying of cancer?” It is not a confounding artifact in the cancer burden. It is the main driver.

## What is the dream clinical trial to test the hypothesis that we can reduce the death rates of cancer by 50%? [2:03:15]

- Integrate standard of care the way we use the chemo
- And we would have people on metabolic therapy which would be lower
- And you would do those in parallel.
- You would have some patients that would be treated only with the standard of care which would be our front row
- And then we would have people treated with the standard of care plus reducing blood sugar elevating ketones and targeting the energy metabolism which we include things like metformin, HBOT, and other things
- And now your metabolic therapy alone
- That group would be The Press-Pulse concept

Press-Pulse:

> “This general concept can be applied to the management of cancer by creating chronic metabolic stresses on tumor cell energy metabolism (press disturbance) that are coupled to a series of acute metabolic stressors that restrict glucose and glutamine availability while also stimulating cancer-specific oxidative stress (pulse disturbances). The elevation of non-fermentable ketone bodies protect normal cells from energy stress while further enhancing energy stress in tumor cells that lack the metabolic flexibility to use ketones as an efficient energy source. Mitochondrial abnormalities and genetic mutations make tumor cells vulnerable metabolic stress.”

**—**[[Seyfried et al., 2017](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2)]

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-61.png)

**Figure 13. The glucose ketone index for the metabolic management of cancer.** Image credit. Tom Seyfried

**Glucose ketone index**: [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2) (Meidenbauer et al., 2015) [2:05:45] — Therapeutic efficacy is considered best with glucose ketone index values approaching 1.0 or below

- This not only includes diet, but can also include:
  - stress management;
  - Yoga;
  - Meditation;
  - adequate sleep.
- We can put them at the hyperbaric oxygen which creates oxidative stress predominantly in the tumor cell and not in the normal cells than normal cells or burning ketones that reduces oxidative stress.
- You don’t want to use insulin therapy unless you’re in therapeutic ketosis
- You don’t want to go into a hyperbaric chamber unless you’re in therapeutic ketosis
- And then we would pulse with drugs that target glutamine and together you’re removing the antioxidant capacity of the tumor, making it vulnerable
- Doing HBOT for 90 minutes every day
- It’s designed to put oxidative stress killing the tumor cells by oxidative stress the same way radiation therapy would work.

**The clinical trial in Turkey**

**Patient with TNBC on metabolic therapy**: [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.cureus.com/articles/7528-efficacy-of-metabolically-supported-chemotherapy-combined-with-ketogenic-diet-hyperthermia-and-hyperbaric-oxygen-therapy-for-stage-iv-triple-negative-breast-cancer#.WWL9HXdXYJN.twitter) (Iyikesici et al., 2017)

- They use chemo but they use the lowest possible dose for breast cancer
- Usong the Press-Pulse concept
- We can press things constantly without harming the body, but we have to pulse the glutamine because we don’t want to deprive our normal immune system and gut systems of the very fuel needed to provide normal physiology in those tissues

**Clinical trials in the US?**

- Are there any that are in clinical trials in the United States?
- There’s a couple: they’re targeting certain aspects of the glutaminolysis pathway

**DON**

**“DON” glutamine antagonist**: [6-Diazo-5-oxo-L-norleucine (DON)](https://en.wikipedia.org/wiki/6-Diazo-5-oxo-L-norleucine)

- If you don’t do all the parts of the problem, the horse is going to get out
- It’s still not going to be effective, and today, no one anywhere on the planet is doing the kind of a therapy that we think need to do to make to make this all work
- There’s bits and pieces of the drugs that are in current clinical trials that are targeting glutamine
- There’s BPTES trial
- Also making DON analogs that are supposedly less toxic
- What we find is with the KD, DOM becomes far less toxic, so you can use far lower doses

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-62.png)

**Figure 14. The restricted ketogenic diet increases DON content in VM-M3 mouse tumor tissues.** Image credit: Tom Seyfried

- How many clinics in the country in the world are treating cancer as a metabolic disease using a strategy that will take away the two prime fermentable fuels for the disorder?
- The answer is zero

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-63.png)

**Figure 15. Hypothesis: KD-R + DON should eliminate VM-M3 GBM cells.** Image credit: Tom Seyfried

- But this trial in Turkey are not targeting the glutamine
- In our Egyptian patient that we published recently, we use chloroquine and we used EGCG. which is a green tea extract, but they are not they’re not as powerful in the clinic

**Patient with GBM on metabolic therapy**: [Management of Glioblastoma Multiforme in a Patient Treated With Ketogenic Metabolic Therapy and Modified Standard of Care: A 24-Month Follow-Up](https://www.frontiersin.org/articles/10.3389/fnut.2018.00020/full) (Elsakka et al., 2018)]

- Now that poor guy, he just passed away, we were devastated by this.
- We published the paper, he lived 30 months which is far longer than most people with a glioblastoma
- He was doing really well on metabolic therapy
- We pushed off the standard of care for three months
- So we did surgery after three weeks of therapeutic ketosis, debulked most of the tumor most of it, because you never get all GBM
- We were forced into the radiation therapy after three months even though the guy was doing remarkably well
- It’s part of the standard of care in Alexandria, Egypt, and then a year later he starts developing a headache, his head starts to swell
- And they did a compression debulking, and they looked at the tissue, looked at the tumor cells, he was dying from radiation necrosis that he took from the radiation
- So when I say we can drop death rates by 50 percent in 10 years we’re not only drop in death rates we’re massively increasing overall survival and quality of life
- You also have to put it into perspective what effect does the treatments have on your overall long term survival as well
- Dana Farber just opened up a branch of medicine called Cancer Survivor medicine

**Cancer Survivor medicine**: [Adult Survivorship Program](https://www.dana-farber.org/adult-survivorship-program/) | Dana-Farber Cancer Institute (dana-farber.org) [2:19:30]

- It appears that many people treated with standards of care are suffering from perfectly from all these other kinds of diseases. They never had. But for the fact that they were treated with all this toxics. So we would eliminate that.
- Why would you if you’re in therapeutic ketosis and you’re unlikely but I’m still like what’s the proof of concept that the metabolic therapy can lead to a cure.
- The problem clinically right is that the mass effect doesn’t give you a lot of flexibility to delay surgery.
- So between corticosteroids and radiation when a patient or most patients present with GTM not at GBM not as incidental findings they have symptoms from the mass effect.

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-64.png)

**Figure 16. How the standard of care can provoke GBM growth and recurrence.** Image credit: Tom Seyfried

**Tom’s 2010 paper in Lancet Oncology**: [Does the existing standard of care increase glioblastoma energy metabolism?](https://www.thelancet.com/journals/lanonc/article/PIIS1470-2045(10)70166-2/fulltext) (Seyfried et al., 2010) [2:24:00]

With metabolic therapy you can double-triple the amount of survival, Tom believes

Pablo Kelly | [YouTube](https://www.youtube.com/watch?v=n8BpHd0Mc_Q)

[Says](https://www.youtube.com/watch?v=n8BpHd0Mc_Q) he was diagnosed with terminal, inoperable, malignant brain tumor (GBM) in August of 2014

Gave him 6-9 months, without chemotherapy, to live

If you do chemotherapy:

- 6 weeks of radiotherapy
- Every Saturday you do chemotherapy
- Every Sunday you get a day of rest
- For six weeks, you’re basically not living. You’re traveling to and from the hospital.
- Wouldn’t be able to have children because of the effects on your sperm.

Refused chemotherapy and started the ketogenic diet.

- Lots of supplements. Immune support. Anti-inflammatories. Curcumin (which is turmeric).
- Coconut oil, MCTs, pass the BBB, suppress the tumor

Five stable scans since January of 2015 (up to ~ June of 2016 in the video)

Usually, people die within the first 15 months, and/or they degrade over time, with chemotherapy.

The video is from 2016. So it was two years from diagnosis where Pablo is still living.

“Quality of life is better than having no life.”

**Pablo Kelly’s lecture in the UK**: [Pablo’s story](https://www.youtube.com/watch?v=CI1vqCN2jBQ&t=14595s&fbclid=IwAR2O9wjEutgSGPyg34d88OGBdcueasnKXFy1HolaAhH97OSah5pW-JNFGWU) | Children with Cancer UK (YouTube) [2:24:15]

**Pablo Kelly article in the Daily Mail**: [Quitting carbs has saved my life’: Cancer victim given months to live refuses chemo and claims diet of meat and dairy is why he’s still alive two years later](https://www.dailymail.co.uk/health/article-3691808/Quitting-carbs-saved-life-Cancer-victim-given-months-live-refuses-chemo-claims-diet-meat-dairy-s-alive-two-years-later.html) | Daily Mail (dailymail.co.uk) [2:24:15]

**Pablo Kelly article**: [Good news for Pablo in unconventional brain tumour battle | South Hams Gazette](https://www.southhams-today.co.uk/article.cfm?id=110163&headline=Good%20news%20for%20Pablo%20in%20unconventional%20brain%20tumour%20battle&sectionIs=news&searchyear=2017) (southams-today.co.uk) [2:24:15]

## How can the hypothesis be tested rigorously that structural abnormalities in the mitochondria impair respiration and lead to compensatory fermentation? [2:26:30]

- How can this hypothesis be refuted?
- If you deprive the tumor cells of their fermentable fuels and you essentially eliminate the cancer in your body, that’s based on the biology of what the problem is
- So the dream experiments are to ferret that out mechanistically, in vitro
- To demonstrate that this is the case
- Tom’s group is doing this now: when they target these things, the cells die
- It was shown in many papers in fact that back in the 30s and 40s, papers showing that the respiratory system of tumor cells is massively compromised

**Respiration compromised in cancer cells**: [STUDIES IN CANCER. VII. ENZYME DEFICIENCY IN HUMAN AND EXPERIMENTAL CANCER](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC435291/) (Roskelley et al., 1943)

**Respiration compromised in cancer cells**: [Studies in Cancer: X. Oxidative Capacity of Tumors](https://cancerres.aacrjournals.org/content/canres/4/6/345.full.pdf) (Mayer, 1944)

- If that’s the case then they are surviving on fermentation there’s no other known biological system in the world that can provide alternative ATP
- It’s one thing to say OK I had a review on a paper that we know there’s a massive biology on the role of cardiolipin in controlling the electron transport chain

**Cardiolipin and mitochondrial abnormalities**: [Cardiolipin and electron transport chain abnormalities in mouse brain tumor mitochondria: lipidomic evidence supporting the Warburg theory of cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2582368/) (Kiebish et al., 2008)

## Case studies of GBM survivors [2:32:45]

Pablo Kelly (see above)

[Andrew Scarborough’s story](https://mybraincancerstory.blogspot.com/), took no radiation no chemo.

- In 2013 he was diagnosed with an incurable malignant brain tumor
- Andrew was [inspired](https://denversdietdoctor.com/ancestral-ketogenic-diets-and-brain-cancer-the-scarborough-protocol/) by many including researchers Dominic D’Agostino, Ph.D., Thomas Seyfried, Ph.D., and Adrienne Scheck, Ph.D. who have all been seeking treatments for aggressive, rapidly growing and metabolically active cancers

[Alison Gannett](https://twitter.com/alisongannett?lang=en): she survived late-stage brain cancer

- In 2013 she was diagnosed with terminal malignant brain cancer
- Had surgery, went on a ketogenic diet and did not do chemo and radiation

Tom has an anecdotal account of a patient that only did surgery and a ketogenic diet and he’s still alive 16 years

> “The standard of care should never have been written in granite. It should be flexible. If you have something else that comes along that might be better you’d think there would be an enthusiasm. We have not seen that.”

**Peter’s advice**

- Do something different
  - Tom’s abutting a resistance and he’s got to go around it
  - Getting case reports published becomes very difficult to ignore
- Tom’s fighting an uphill battle he doesn’t need to
  - Not worth arguing about whether it’s a genetic disease or metabolic disease: we need every therapy imaginable and sometimes that we’ll be doing things that are completely new as Tom’s proposed

**Where you can support Tom’s work**

**Travis Christofferson’s foundation**: [Foundation for Metabolic Cancer Therapies](https://foundationformetaboliccancertherapies.com/) [2:43:15]

“If you would like to show your support for the research Dr. Seyfried and his lab undertake, you can easily contribute a donation through the [Boston College page](https://www.bc.edu/content/bc/giving/schools/as_biology.html). Please make sure that you specify ‘Dr. Seyfried and his lab’ under the ‘I wish to make my gift to’ section by selecting the ‘other’ category and filling in this information. Please specify that your gift is to be considered “very exclusive” and that the entire gift is to be used only for Dr. Seyfried’s cancer research. Contributions of any size are welcome.”

§

§

## Selected Links / Related Material

**Charlie Founda****tion**: [The Charlie Foundation](https://charliefoundation.org/) | (charliefoundation.org) [11:45]

**Calorie restriction and the ketogenic diet**: [The calorically restricted ketogenic diet, an effective alternative therapy for malignant brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/1743-7075-4-5) (Zhou et al., 2007) [19:00]

**Irish hunger strike**: [1981 Irish hunger strike](https://en.wikipedia.org/wiki/1981_Irish_hunger_strike) | (wikipedia.org) [22:04]

**382-day fast**: [Features of a successful therapeutic fast of 382 days’ duration](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2495396/) (Stewart and Fleming, 1973) [24:00]

**No pathogenic mutations found in mitochondrial DNA in Tom’s study**: [Absence of pathogenic mitochondrial DNA mutations in mouse brain tumors](https://bmccancer.biomedcentral.com/articles/10.1186/1471-2407-5-102) (Kiebish and Seyfried, 2005) [42:15]

**Vogelstein’s analysis of The Cancer Genome Atlas Project**: [Cancer Genome Landscapes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3749880/) (Vogelstein et al., 2013) [42:15]

**TCGA analysis**: [The genomic landscapes of human breast and colorectal cancers](https://www.ncbi.nlm.nih.gov/pubmed/17932254) (Wood et al., 2007)

**TCGA analysis**: [The consensus coding sequences of human breast and colorectal cancers](https://www.ncbi.nlm.nih.gov/pubmed/16959974) (Sjoblom et al., 2006)

**TCGA analysis**: [Core signaling pathways in human pancreatic cancers revealed by global genomic analyses](https://www.ncbi.nlm.nih.gov/pubmed/18772397) (Jones et al., 2008)

**TCGA analysis**: [An Integrated Genomic Analysis of Human Glioblastoma Multiforme](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2820389/) (Parsons et al., 2008)

**Analysis of The Cancer Genome Atlas Project by Loeb**: [Mutational heterogeneity in human cancers: origin and consequences](https://www.ncbi.nlm.nih.gov/pubmed/19743960) (Salk et al., 2010) [42:15]

> “Thus, if cancer requires as many as 12 different rate limiting mutations to arise, and the normal per-division mutation rate of human stem cells is as low as calculated, and the number of long-lived stem cell divisions limited, how can a cancer possibly occur within the human lifetime?”

**Dean Burk on slow-growing hepatomas**: [On the Significance of Glucolysis for Cancer Growth, With Special Reference to Morris Rat Hepatomas](https://academic.oup.com/jnci/article-abstract/38/6/839/920705) (Burk et al., 1967) [00:47:45]

**Crown-gall tumors — they get cancer but don’t metastasize**: [On the Origin of Cancer Metastasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3597235/) (Seyfried and Huysentruyt, 2013) [48:00]

**Vander Heiden, Cantley, and Thomson paper**: [Understanding the Warburg effect: the metabolic requirements of cell proliferation](https://www.ncbi.nlm.nih.gov/pubmed/19460998) (Vander Heiden et al., 2009) [50:15]

**Evidence of mitochondrial damage**: [Tumor mitochondria and the bioenergetics of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/149996) (Pedersen, 1978) [51:15]

**Christos Chinpoulos on mSLP**: [Christos Chinopoulos, M.D., Ph.D.: Mitochondrial SLP as an Energetic Bail-In Mechanism in Cancer](https://www.youtube.com/watch?v=rsrnlqWqhxg) | Epigenix Foundation (youtube.com) [52:00]

**Discussion of glutamine and mSLP in Press-Pulse paper**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Seyfried et al., 2017) [52:00]

**Hochachka paper on succinate and aquatic animals**: [Multiple end products of anaerobiosis in diving vertebrates](https://www.ncbi.nlm.nih.gov/pubmed/1122711) (Hochachka et al., 1975) [54:45]

**Warburg on tumor cells and normal cells**: [On the origin of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/13298683) (Warburg, 1956) [58:15]

**Vander Heiden on PKM2**: [PKM2, cancer metabolism, and the road ahead](https://www.ncbi.nlm.nih.gov/pubmed/27856534) (Dayton et al., 2016) [1:01:15]

**Seyfried on cardiolipin**: [Cardiolipin and electron transport chain abnormalities in mouse brain tumor mitochondria: lipidomic evidence supporting the Warburg theory of cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2582368/) (Kiebish et al., 2008) [1:03:00]

**Seyfried on cardiolipin**: [Cancer as a Metabolic Disease](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920/ref=asc_df_0470584920/?tag=hyprod-20&linkCode=df0&hvadid=312045581420&hvpos=1o1&hvnetw=g&hvrand=11834352262140209673&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9001879&hvtargid=pla-434882603255&psc=1&tag=&ref=&adgrpid=62837065180&hvpone=&hvptwo=&hvadid=312045581420&hvpos=1o1&hvnetw=g&hvrand=11834352262140209673&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9001879&hvtargid=pla-434882603255) by Thomas Seyfried — [Chapter 5: Respiratory Dysfunction in Cancer Cells](https://onlinelibrary.wiley.com/doi/10.1002/9781118310311.ch5) [1:03:00]

**Reference to patients put in insulin comas**: [Wilhelm Brünings’ forgotten contribution to the metabolic treatment of cancer utilizing hypoglycemia and a very low carbohydrate (ketogenic) diet](https://www.sciencedirect.com/science/article/pii/S2225411018301743) (Klement, 2018) [1:14:45]

**Reference to patients put in insulin comas**: [Two cases of malignant tumors with metastases apparently treated successfully with hypoglycemic coma](https://link.springer.com/article/10.1007%2FBF01586115) (Koroljow, 1962) [1:14:45]

**“DON” glutamine antagonist**: [6-Diazo-5-oxo-L-norleucine (DON)](https://en.wikipedia.org/wiki/6-Diazo-5-oxo-L-norleucine) | (wikipedia.org) [1:15:15]

**Press-pulse**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Seyfried et al., 2017) [01:17:00]

**Retrograde response**: [Respiratory Insufficiency, the Retrograde Response, and the Origin of Cancer](https://onlinelibrary.wiley.com/doi/10.1002/9781118310311.ch10) (Seyfried, 2012) [1:31:00]

**States of equilibrium**: [Origin of Cancer: An Information, Energy, and Matter Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5112236/) (Hanselmann and Welter, 2016) [1:32:15]

**Otto Aichel paper on tumor cell fusion (in German)**: [XIII. Geschwülste und Zellverschmelzung mit qualitativ abnormer und qualitativ normaler Chromosomenverteilung](https://books.google.com/books?id=hWggAQAAIAAJ&pg=PA92&lpg=PA92&dq=XIII.+Geschwu%CC%88lste+und+Zellverschmelzung+mit+qualitativ+abnormer+und+qualitativ+normaler+Chromosomenverteilung&source=bl&ots=KYFjdFe4uo&sig=5eQa8mzsG5-i6ac025SIN5XMLz8&hl=en&sa=X&ved=2ahUKEwjurtf9g-jeAhXMnuAKHULZB5UQ6AEwCHoECAcQAQ#v=onepage&q=XIII.%20Geschwu%CC%88lste%20und%20Zellverschmelzung%20mit%20qualitativ%20abnormer%20und%20qualitativ%20normaler%20Chromosomenverteilung&f=false) (Aichel, 1911) [1:40:00]

**Otto Aichel (Bob Kaplan’s rough translation in English)**: [XIII. Tumors and cell fusion with quality of abnormal and qualitatively normal chromosomes distribution](https://www.dropbox.com/s/lxcravmgx7xdyxn/%23aichel%20%231911.pdf?dl=0) (Aichel, 1911) [1:40:00]

**Pawelek on tumor cell hybrids**: [Fusion of bone marrow-derived cells with cancer cells: metastasis as a secondary disease in cancer](https://www.ncbi.nlm.nih.gov/pubmed/24589183) (Pawelek, 2014) [1:40:15]

**Pawelek on tumor cell hybrids**: [Cancer-cell fusion with migratory bone-marrow-derived cells as an explanation for metastasis: new therapeutic paradigms](https://www.ncbi.nlm.nih.gov/pubmed/18684055) (Pawelek, 2008) [1:40:15]

**Pawelek on tumor cell hybrids**: [Leukocyte-cancer cell fusion: initiator of the Warburg effect in malignancy?](https://www.ncbi.nlm.nih.gov/pubmed/21506013) (Lazova et al., 2007) [1:40:15]

**Pawelek on tumor cell hybrids**: [Tumour-cell fusion as a source of myeloid traits in cancer](https://www.ncbi.nlm.nih.gov/pubmed/16321767) (Pawelek, 2005) [1:40:15]

**Pawelek on tumor cell hybrids**: [Tumor cell hybridization and metastasis revisited](https://www.ncbi.nlm.nih.gov/pubmed/11198471) (Pawelek, 2000) [1:40:15]

**Pawelek on tumor cell hybrids**: [The cancer cell—leukocyte fusion theory of metastasis](https://www.ncbi.nlm.nih.gov/pubmed/19055949/) (Pawelek and Chakraborty, 2008)

**Wong on tumor cell fusion**: [Cell fusion potentiates tumor heterogeneity and reveals circulating hybrid cells that correlate with stage and survival](https://www.ncbi.nlm.nih.gov/pubmed/30214939) (Gast et al., 2018)

**Wong on tumor cell fusion**: [Bone marrow-derived cells fuse with normal and transformed intestinal stem cells](https://www.ncbi.nlm.nih.gov/pubmed/16606845) (Rizvi et al., 2006)

**Wong on tumor cell fusion**: [Fusion between Intestinal epithelial cells and macrophages in a cancer context results in nuclear reprogramming](https://www.ncbi.nlm.nih.gov/pubmed/21303980) (Powell et al., 2011)

**Wong on tumor cell fusion**: [Characterization of the intestinal cancer stem cell marker CD166 in the human and mouse gastrointestinal tract](https://www.ncbi.nlm.nih.gov/pubmed/20826154) (Levin et al., 2010)

**Tom’s paper on metastasis**: [On the Origin of Cancer Metastasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3597235/) (Seyfried and Huysentruyt, 2013) [1:41:30]

**Cancer of unknown primary (CUP)**: [On the Origin of Cancer Metastasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3597235/) (Seyfried and Huysentruyt, 2013) [1:45:45]

**Nuclear transfer experiments**: [Cancer as a mitochondrial metabolic disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4493566/) (Seyfried, 2015)

**Vogelstein and “dark matter”**: [The dark matter of the cancer genome: aberrations in regulatory elements, untranslated regions, splice sites, non‐coding RNA and synonymous mutations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5126213/) (Diedrichs et al., 2016)

> “In pediatric tumors such as medulloblastomas, the number of driver gene mutations is low (zero to two). In common adult tumors—such as pancreatic, colorectal, breast, and brain cancers—the number of mutated driver genes is often three to six, but several tumors have only one or two driver mutations. How can this be explained, given the widely accepted notion that tumor development and progression require multiple, sequential genetic alterations acquired over decades? Where are these missing mutations?”

**Vogelstein and “bad luck”**: [Variation in cancer risk among tissues can be explained by the number of stem cell divisions](https://science.sciencemag.org/content/347/6217/78) (Tomasetti and Vogelstein, 2015)

**One sample (Br20P) in GBM showed zero driver mutations**: [Cancer Genome Landscapes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3749880/) [[supplement](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3749880/bin/NIHMS496129-supplement-Supplementary_Material.xlsx)] (Vogelstein et al., 2013) [1:47:00]

**Br20P sample in GBM**: [An Integrated Genomic Analysis of Human Glioblastoma Multiforme](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2820389/) (Parsons et al., 2008)

**Stuart Baker on tumors with zero mutation**s: [A Cancer Theory Kerfuffle Can Lead to New Lines of Research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4326310/) (Baker, 2014)

**Travis Christofferson on The Cancer Genome Atlas (TCGA**): [What Is The Origin of Cancer?](https://robbwolf.com/2013/09/19/origin-cancer/) (Christofferson, 2013) | (robbwolf.com)

> “Despite the confusion, the TCGA soldiered on. Glioblastoma Multiforme was next – brain cancer. Glioblastoma is a mean aggressive-cancer; most will succumb to it within a year even with treatment. Again, teams of researchers sequenced over 20,000 genes from 22 tumor samples. This time a novel gene was found to be mutated in 12% of the samples – a big accomplishment. Its discovery was cited as a validation of the utility of genome-wide genetic analysis of tumors. The authors concluded that GBM was caused by mutations that rendered 3 important biological processes dysfunctional. However, as with pancreatic cancer, a close look at the data revealed something else. The disturbing trend continued – none of these studies were able to validate the somatic mutation theory of cancer, not even the new modified version. None of these studies were able to conclude that mutations were even the cause of the disease at all. Of the 22 samples only 4 had mutations involving all 3 systems implicated as necessary for GBM to occur. Nine samples had mutations in 2 of the 3 systems, 5 had mutations in 1 of the 3, and most significant, one sample (sample labeled Br20P) had no mutations in any of the 3 systems yet was a living, growing, aggressive case of GBM. The profound silence with regard to these inconsistencies in the new and modified somatic theory of cancer speaks volumes. For the theory to work, the original theory, or the new modified theory, samples like Br20P simply cannot exist.”

**Skin cells have many so-called driver mutations that never form a tumor**: [High burden and pervasive positive selection of somatic mutations in normal human skin](https://www.ncbi.nlm.nih.gov/pubmed/25999502) (Martincorena et al., 2015) [1:47:30]

**Normal esophageal tissue with so-called driver mutations**: [Somatic mutant clones colonize the human esophagus with age](https://www.ncbi.nlm.nih.gov/pubmed/30337457) (Martincorena et al., 2018) [1:47:30]

**Inflammatory oncotaxis**: [Wound healing after trauma may predispose to lung cancer metastasis: review of potential mechanisms](https://www.ncbi.nlm.nih.gov/pubmed/21177982/) (Walter et al., 2011)

**Metastatic cancer cells from lung and breast can appear in the mouth following recent tooth extraction or along needle tracts following biopsy**: [On the Origin of Cancer Metastasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3597235/) (Seyfried and Huysentruyt, 2013) [1:49:30]

**Metastatic cancer cells from lung and breast can appear in the mouth following recent tooth extraction or along needle tracts following biopsy**: [Metastatic tumors to postextraction sites](https://www.ncbi.nlm.nih.gov/pubmed/8229413/) (Hirshberg et al., 1993) [1:49:30]

**Metastatic cancer cells from lung and breast can appear in the mouth following recent tooth extraction or along needle tracts following biopsy**: [Metastases to the oral mucosa: analysis of 157 cases](https://www.ncbi.nlm.nih.gov/pubmed/8301602) (Hirshberg et al., 1993) [1:49:30]

**Metastatic cancer cells from lung and breast can appear in the mouth following recent tooth extraction or along needle tracts following biopsy**: [Breast Cancer Cutaneous Metastasis at Core Needle Biopsy Site](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2883438/) (Cho et al., 2010) [1:49:30]

**Needle biopsy**: [Human breast cancer biopsies induce eosinophil recruitment and enhance adjacent cancer cell proliferation](https://www.ncbi.nlm.nih.gov/pubmed/27249999) (Szalayova et al., 2016) [1:49:30]

**Needle biopsy**: [Tumor seeding occurring after fine-needle biopsy of abdominal malignancies](https://www.ncbi.nlm.nih.gov/pubmed/1742134) (Lundstedt et al., 1991) [1:49:30]

**Morcellation procedure**: [Controversial morcellation procedure to remove fibroids can spread undiagnosed cancer](https://www.fredhutch.org/en/news/center-news/2014/07/Controversial-morcellation-procedure-fibroids-spread-cancer.html) | (fredhutch.org) [01:51:00]

**Morcellation procedure**: [Amy Reed, Doctor Who Fought a Risky Medical Procedure, Dies at 44](https://www.nytimes.com/2017/05/24/us/amy-reed-died-cancer-patient-who-fought-morcellation-procedure.html) | (nytimes.com) [1:51:00]

**Over half a million people dying per year (609,640), over 1,600 people a day (1,670)**: [Cancer Stat Facts: Cancer of Any Site](https://seer.cancer.gov/statfacts/html/all.html) | National Cancer Institute (seer.cancer.gov) [1:59:15]

**Glucose ketone index**: [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2) (Meidenbauer et al., 2015) [2:05:45]

**Patient with GBM on metabolic therapy**: [Management of Glioblastoma Multiforme in a Patient Treated With Ketogenic Metabolic Therapy and Modified Standard of Care: A 24-Month Follow-Up](https://www.frontiersin.org/articles/10.3389/fnut.2018.00020/full) (Elsakka et al., 2018)]

**Patient with TNBC on metabolic therapy**: [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.cureus.com/articles/7528-efficacy-of-metabolically-supported-chemotherapy-combined-with-ketogenic-diet-hyperthermia-and-hyperbaric-oxygen-therapy-for-stage-iv-triple-negative-breast-cancer#.WWL9HXdXYJN.twitter) (Iyikesici et al., 2017)

**Clinical trial in Turkey**: [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.cureus.com/articles/7528-efficacy-of-metabolically-supported-chemotherapy-combined-with-ketogenic-diet-hyperthermia-and-hyperbaric-oxygen-therapy-for-stage-iv-triple-negative-breast-cancer#.WWL9HXdXYJN.twitter) (Iyikesici et al., 2017) [2:13:15]

**Cancer Survivor medicine**: [Adult Survivorship Program](https://www.dana-farber.org/adult-survivorship-program/) | Dana-Farber Cancer Institute (dana-farber.org) [2:19:30]

**Tom’s 2010 paper in Lancet Oncology**: [Does the existing standard of care increase glioblastoma energy metabolism?](https://www.thelancet.com/journals/lanonc/article/PIIS1470-2045(10)70166-2/fulltext) (Seyfried et al., 2010) [2:24:00]

**Tom Seyfried’s lecture in the UK**: [Cancer as a Metabolic Disease: Implications for Novel, Non-Toxic Therapies](https://www.dana-farber.org/adult-survivorship-program/) | Children with Cancer UK (YouTube) [2:24:15]

**Pablo Kelly’s lecture in the UK**: [Pablo’s story](https://www.youtube.com/watch?v=CI1vqCN2jBQ&t=14595s&fbclid=IwAR2O9wjEutgSGPyg34d88OGBdcueasnKXFy1HolaAhH97OSah5pW-JNFGWU) | Children with Cancer UK (YouTube) [2:24:15]

**Pablo Kelly article in the Daily Mail**: [Quitting carbs has saved my life’: Cancer victim given months to live refuses chemo and claims diet of meat and dairy is why he’s still alive two years later](https://www.dailymail.co.uk/health/article-3691808/Quitting-carbs-saved-life-Cancer-victim-given-months-live-refuses-chemo-claims-diet-meat-dairy-s-alive-two-years-later.html) | Daily Mail (dailymail.co.uk) [2:24:15]

**Pablo Kelly article**: [Good news for Pablo in unconventional brain tumour battle | South Hams Gazette](https://www.southhams-today.co.uk/article.cfm?id=110163&headline=Good%20news%20for%20Pablo%20in%20unconventional%20brain%20tumour%20battle&sectionIs=news&searchyear=2017) (southams-today.co.uk) [2:24:15]

**Travis Christofferson’s foundation**: [Foundation for Metabolic Cancer Therapies](https://foundationformetaboliccancertherapies.com/) [2:43:15]

§

§

## People Mentioned

- [Dom D’Agostino](https://peterattiamd.com/domdagostino/) (cancer metabolism research) [1:00, 56:30, 2:42:45]
- [Bob Kaplan](https://twitter.com/bobkaplan) (Attia Medical analyst, show notes contributor) [1:15, 2:42:45]
- [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) (Nobel Laureate, cancer metabolism research) [2:45, 31:00, 38:00, 50:00, 52:30, 57:45, 1:00:00, 1:02:30]
- [John McCain](https://en.wikipedia.org/wiki/John_McCain) (US Senator, died of glioblastoma) [6:00, 1:57:00]
- [Sid Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) [6:56, 50:15]
- [Lewis “Lew” Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (cancer metabolism) [7:00, 1:01:15]
- [Robert Yu](https://www.augusta.edu/mcg/dnrm/faculty/yu.php) (cancer research) [9:15]
- [Dennis Spencer](https://medicine.yale.edu/neurosurgery/faculty/dennis_spencer.profile) (neurosurgeon, epilepsy) [9:30]
- [Harry Zimmerman](https://www.nytimes.com/1995/07/31/obituaries/dr-harry-zimmerman-93-dies-founded-albert-einstein-college.html) (studied diseases of the nervous system) [10:15]
- [John Freeman](https://en.wikipedia.org/wiki/John_M._Freeman) (epilepsy neurologist, brought back the ketogenic diet) [11:30, 16:30, 28:00]
- [Jim Abrahams](https://en.wikipedia.org/wiki/Jim_Abrahams) (movie director, started the Charlie Foundation) [11:45, 13:15]
- [Meryl Streep](https://en.wikipedia.org/wiki/Meryl_Streep) (actor, starred in …First Do No Harm) [11:45]
- [Mariana Todorova Tran](https://www.researchgate.net/scientific-contributions/7672422_Mariana_T_Todorova) (epilepsy research) [12:45]
- [Purna Mukherjee](https://www.linkedin.com/in/purna-mukherjee-4837bb3/) (Tom’s colleague, cancer metabolism) [15:15]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (metabolism research) [20:45, 21:30, 24:00]
- [Richard “Bud” Veech](https://irp.nih.gov/pi/richard-veech) (metabolism research) [21:00]
- [Bobby Sands](https://en.wikipedia.org/wiki/Bobby_Sands) (hunger strike) [22:00]
- [Louis Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur) (Pasteur effect) [32:00]
- [Otto Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) (Nobel Laureate, Embden-Meyerhof pathway) [35:00]
- [Gustav Embden](https://en.wikipedia.org/wiki/Gustav_Embden) (Embden-Meyerhof pathway) [35:00]
- [Peter “Pete” Pedersen](https://www.hopkinsmedicine.org/profiles/results/directory/profile/7111656/peter-pedersen) (cancer metabolism research) [37:45, 41:00, 45:15, 51:15, 2:29:30]
- [Sidney Weinhouse](https://www.nytimes.com/2001/02/28/us/sidney-weinhouse-91-expert-on-the-metabolism-of-cancer.html) (cancer metabolism) [40:45]
- [James Watson](https://en.wikipedia.org/wiki/James_Watson) (Nobel Laureate, DNA) [45:15]
- [Francis Crick](https://en.wikipedia.org/wiki/Francis_Crick) (Nobel Laureate, DNA) [45:15]
- [Dean Burk](https://en.wikipedia.org/wiki/Dean_Burk) (cancer metabolism, co-author with Warburg) [47:30]
- [Matthew Vander Heiden](https://biology.mit.edu/profile/matthew-vander-heiden/) (cancer metabolism research) [50:15]
- [Craig Thomson](https://en.wikipedia.org/wiki/Craig_B._Thompson) (cancer metabolism research) [50:15]
- [Peter William Hochachka](https://jeb.biologists.org/content/205/24/3767) (comparative physiologist) [54:45]
- [Christos Chinopoulos](https://scholar.google.com/citations?user=_h4N6KEAAAAJ&hl=en) (cancer metabolism research) [52:00]
- [Gerald “Jerry” Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (metabolic syndrome) [1:06:45]
- [Albert Szent-Gyorgyi](https://en.wikipedia.org/wiki/Albert_Szent-Gy%C3%B6rgyi) (Nobel Laureate, oncogenic paradox, cancer research) [1:23:30]
- [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) (angiogenesis, cancer research) [1:37:00]
- [Napoleone Ferrara](https://en.wikipedia.org/wiki/Napoleone_Ferrara) (VEGF discovery, angiogenesis, cancer research) [1:37:00]
- [Otto Aichel](https://www.the-scientist.com/news-opinion/cancer-cells-fuse-with-immune-cells-in-human-patients-64792) (German pathologist, fusion behavior between neoplastic cells and immune cells) [1:39:45]
- [John Pawelek](https://medicine.yale.edu/dermatology/education/fellowships/john_pawelek.profile) (fusion-hybrid metastasis) [1:40:15]
- [Melissa Wong](https://www.ohsu.edu/xd/research/centers-institutes/stem-cell-center/faculty/melissa-wong.cfm) (fusion hybrid metastasis)[1:40:30]
- [Stuart G. Baker](https://prevention.cancer.gov/research-groups/biometry/staff/stuart-g-baker-scd) (cancer research) [1:47:15]
- [Bert Vogelstein](https://en.wikipedia.org/wiki/Bert_Vogelstein) (cancer research) [2:12:30]
- [Pablo Kelly](https://twitter.com/pkellysjourney) (GBM survivor, metabolic approach) [2:23:45]
- [Joseph “Joe” Maroon](https://en.wikipedia.org/wiki/Joseph_Maroon) [2:27:00]
- [George Yu](https://yufoundation.org/about-us) (cancer metabolism and metabolic therapy) [2:27:15]
- [Andrew Scarborough](https://twitter.com/ascarbs?lang=en) (GBM survivor, metabolic approach) [2:33:00]
- [Alison Gannett](https://twitter.com/alisongannett?lang=en) (GBM survivor, metabolic approach) [2:33:15]
- [Travis Christofferson](https://www.linkedin.com/in/travis-christofferson-476485a3/) (author of [Tripping Over the Truth](https://www.amazon.com/Tripping-over-Truth-Overturning-Entrenched/dp/1603587292) and founder of the [Foundation for Metabolic Cancer Therapies](https://foundationformetaboliccancertherapies.com/)) [2:43:15]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/11/tom-seyfried-profile-300x300.jpg)

##### Thomas Seyfried, Ph.D.

Thomas N. Seyfried received his Ph.D. in Genetics and Biochemistry from the University of Illinois, Urbana, in 1976. He did his undergraduate work at the University of New England, where he recently received the distinguished Alumni Achievement Award. He also holds a Master’s degree in Genetics from Illinois State University. Thomas Seyfried served with distinction in the United States Army’s First Cavalry Division during the Vietnam War and received numerous medals and commendations. He was a Postdoctoral Fellow in the Department of Neurology at the Yale University School of Medicine and then served on the faculty as an Assistant Professor in Neurology.

Other awards and honors have come from such diverse organizations as the American Oil Chemists Society, the National Institutes of Health, The American Society for Neurochemistry, the Ketogenic Diet Special Interest Group of the American Epilepsy Society, the Academy of Comprehensive and Complementary Medicine, and the American College of Nutrition.

Dr. Seyfried previously served as Chair, Scientific Advisory Committee for the National Tay-Sachs and Allied Diseases Association and presently serves on several editorial boards, including those for Nutrition & Metabolism, Neurochemical Research, the Journal of Lipid Research, and ASN Neuro, where he is a Senior Editor.

Dr. Seyfried has over 150 peer-reviewed [publications](https://tomseyfried.com/2018/05/05/publications/) and is the author of the book, [Cancer as a Metabolic Disease: On the Origin, Management, and Prevention of Cancer](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920) (Wiley, 1st ed., 2012). [[tomseyfried.com](https://tomseyfried.com/)]

Tom’s website: [Thomas Seyfried](https://tomseyfried.com/)

Tom on Twitter: [@tnseyfried](https://twitter.com/tnseyfried?lang=en)