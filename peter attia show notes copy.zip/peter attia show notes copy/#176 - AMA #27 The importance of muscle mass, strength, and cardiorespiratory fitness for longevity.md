# #176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity

**Source:** [https://peterattiamd.com/ama27/](https://peterattiamd.com/ama27/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob discuss the longevity benefits from greater cardiorespiratory fitness (CRF) and greater muscle mass and strength. Conversely, they dive deep into the literature showing a rapid increase in morbidity and mortality risk as fitness levels decline with age. They also try to tease out the relative contributions of CRF, muscle mass, and strength. Additionally, they discuss the impact of fasting on muscle mass, the potential tradeoffs to consider, and finish by discussing why it’s critical to maximize your fitness level.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #27 show notes page](https://peterattiamd.com/ama27/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- VO2 max and its association with cardiorespiratory fitness [2:45];
- Changing mortality risk based on VO2 max and cardiorespiratory fitness [7:45];
- The profound impact of improving cardiorespiratory fitness [15:15];
- Muscle mass, function, and loss with aging: how it’s defined, measured, and the cutoff points for sarcopenia [25:00];
- Increasing mortality risk associated with declining muscle mass and strength [40:00];
- Muscle size vs. strength—which has the bigger impact on mortality risk? [58:00];
- Evaluating the cumulative impact of cardiorespiratory fitness and muscular strength on mortality risk when put together [1:03:30];
- Investigating the rising incidence in deaths from falls, and what role Alzheimer’s disease might play [1:09:00];
- The impact of fasting on muscle mass and the potential tradeoffs to consider [1:14:30];
- The critical importance of working to maintain muscle mass and strength as we age [1:20:30]; and
- More.

§

The Peter Attia Drive

The importance of muscle mass, strength, and cardiorespiratory fitness for longevity

§

## Show Notes

§

## VO2 max and its association with cardiorespiratory fitness [2:45]

**Overview of question being asked today**: *Does better cardiorespiratory fitness lead to less mortality and does lower cardiorespiratory fitness lead to higher mortality? Or is it at least associated?*

**Common terms**:

- Most common thing in the literature is either METs, metabolic equivalents or VO2 max
- For a VO2 max test…
  - You are hooked up to an indirect calorimeter—a device that provides complete occlusion around your mouth and your nose so you’re only breathing through your mouth
  - The device has two sensors on it
    - One sensor measures the concentration of oxygen that is being expelled
    - The other one is also measuring the concentration of carbon dioxide that’s expelled.
  - Because we know the concentration of oxygen and CO2 on the way in, by knowing what comes out and obviously oxygen will be lower, CO2 will be higher, **we know how much carbon dioxide was produced and how much oxygen was consumed**
  - Knowing those two things gives you a “flow rate” — VO2 and a VCO2
  - This can tell you how much energy you’re utilizing via something called the [Fick principle](https://en.wikipedia.org/wiki/Fick_principle)
    - Total energy consumption is ~3.94 times VO2, and ~1.11 times VCO2 at any point in time
- For instance, for this minute VO2 was X, VCO2 was Y, then you apply it to that equation and it will tell you that you were utilizing, say, 10 kilocalories per minute which would be 600 kilocalories per hour
- During Peter’s zone 2 exercise, it tends to be about 780 kilocalories per hour
- But now what we’re talking about is something different which is… *what is the maximum utilization of oxygen?*
- If you make somebody work harder and harder and harder, at some point they will reach a maximum at which point, they can no longer utilize more oxygen

*⇒ As to the “why” they can’t utilize more oxygen, see the* [*Alex Hutchinson podcast*](https://peterattiamd.com/alexhutchinson/)

- We talked about some of the alveolar limitations, how much of that is being limited at the gas exchange surface versus
- How much of that is being limited in the muscle.
- But regardless of which of those it is—and it’s possible it’s a combination or it’s possible that at low levels of fitness it’s more in the muscle, and at high levels of fitness, it might be more in the lung—but that number is the VO2 max

When you’re doing the test, it’s measured typically in liters per minute

- then we normalize it by body weight to get milliliters per kilogram per minute
- The fittest of the fit are going to be north of 80
- B*ut what does that mean*?
  - It means they are north of 80 milliliters of oxygen per kilogram per minute
- The [highest ever recorded VO2 max](https://www.outsideonline.com/outdoor-adventure/biking/highest-ever-vo2max-cyclist-oskar-svendsen/) was a cyclist named [Oskar Svendsen](https://en.wikipedia.org/wiki/Oskar_Svendsen) who measured about 96
- Any sort of elite cardiac type athlete, a runner, cyclist, rower, those sorts of athletes, they’re generally going to be above 70

## Changing mortality risk based on VO2 max and cardiorespiratory fitness [7:45]

![](https://peterattiamd.com/wp-content/uploads/2021/09/f1-ama27-1024x678.png)

**Figure 1.** Patient survival by performance group. ([Mandsager et al., 2018](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428))

Overview of the experiment:

- A group of people that were 53 years old on average
- Ran them through a VO2 max test and then it ranked them
- Low were people who scored in the bottom 25th percentile
- Below average was the 25th to 50 percentile
- 50 to 75th percentile was above average
- High was 75th to maybe 95th
- Elite was just that top 5%.
- NOTE: Each of these levels do NOT represents 20% of the population

- A total of 122,000 patients
- The low, below average, above average, and high have about 30,000 participants in each one of those groups
- And then the elite group has a little over 3,500

Results:

- Looking at all-cause mortality there’s a pretty clear trend
- The two things that stand out are,
  - i) there’s kind of a monotonic relationship between fitness and mortality
  - ii) By far the biggest gap is between the people in the bottom 25%. Which are categorized as low fitness, and basically everyone above them.

![](https://peterattiamd.com/wp-content/uploads/2021/09/f2-ama27-1024x896.png)

**Figure 2.** Risk-adjusted all-cause mortality. ([Mandsager et al., 2018](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428)).

When sort of lumping everyone in together, male and female, if you have low fitness and then comparing it to everybody else, *what’s the risk reduction?*

If you go from low to below average, to above average, to high to elite, you can see what is the hazard ratio

**Important stats**

- Going from just being low to being below average is a 50% reduction in mortality over a decade
- If you then go from low to above average, it’s about a 60% or 70% reduction in mortality
- Then it just continues monotonically to increase
- The lowest improvement is going from high to elite—”*That doesn’t buy you a whole heck of a lot. It is still statistically significant.*”
- To see that you have to look at Table C
- remember, the hazard ratio for mortality is the reciprocal of the hazard ratio of risk reduction
- Tables A and C are basically showing you similar things in the group comparison

*Here’s what’s interesting…*

- If you compare someone of low fitness to elite, it is a five fold difference in mortality over a decade
- They put this in the context of other things that we commonly understand as being problematic for mortality… Namely, smoking, coronary artery disease, Type 2 diabetes, hypertension, and end-stage renal disease
  - That’s a 41% increase in mortality over the decade
  - Coronary artery disease, 29%.
  - Diabetes, 40%.
  - High blood pressure, 21%.
  - End-stage renal disease, about 180% increase in mortality
- But now when you compare that to the differences in these fitness levels, it gives you a greater appreciation for **how much improvement in mortality comes from improving your fitness**
- If you look at the biggest driver of mortality, which would be end-stage renal disease in this cohort, it’s the same as going from low cardiorespiratory fitness to above average cardiorespiratory fitness
- So going from the bottom 25th percentile to being in the 50th to 75th percentile… “*which is a totally achievable feat*”

## The profound impact of improving cardiorespiratory fitness [15:15]

![](https://peterattiamd.com/wp-content/uploads/2021/09/f3-ama27-1024x663.png)

**Figure 3.** Classification of Cardiorespiratory Fitness by Age and Sex\* — reproduced from [Mandsager et al., 2018](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428)

- Peter uses this chart a lot with his patients
- He wants everybody to have a VO2 max test so that he can benchmark them on their way to their “[Centenarian Decathlon](https://peterattiamd.com/ama05/)”
- For each age, gender combo, we’re showing two pieces of information – i)  METs and ii) VO2 max There is a linear relationship between those two and an exact multiple 3.5
- If you know how many METs you can hold for three minutes, then you multiply that by 3.5 and that’s your VO2 max
- Peter tends to just rely on the VO2 max because it’s just more objective

**How does this work?**

- Example: A female who’s 55 years old and her VO2 max is 32 milliliters per kilogram per minute.
- That puts her in the above average category
- *Are we happy with that?* ⇒ We’re not
- Peter’s aspiration is for people to be in the “elite” category for someone a decade younger
- In other words, if you’re 55 and you’re female, we are looking to have you be greater than 47, because that’s what would be elite for someone in their 40s to 50s

**Peter on his VO2 max goals and his training protocol**

- For me, and I actually I’m going to hold myself to a higher standard, I want to be two decades younger. I want to make sure my VO2 max is, at my age now in my late 40s, I want to make sure it’s above 56, which puts me in my 20s
- I’m probably just about 57, 58
- what’s the minimum effective way to train for this type of thing if you’re not doing what people who are really fit do
- for someone looking at this through a longevity lens, you’re not going to want to do what I used to do or what somebody who’s training for a specific sport
- I am now only doing VO2 max training from the standpoint of longevity benefit, not because I’m trying to do well in a Masters race
- I basically only train this energy system directly once a week and then probably indirectly another once or twice a week
- As we’ve talked about the Zone 2 protocol (see [AMA #19](https://peterattiamd.com/ama19/))
- Once a week, I will do a VO2 max sort of specific ride—typically something where you’re doing two to four minute intervals that are at the highest level that you can go for two to four minutes
- That’s not all out because of course all out you would not be able to hold for more than about 10 or 20 seconds
- You have to learn what that sweet spot is of discomfort, which is in that two to four minute range
- It’s typically done at about a one-to-one ratio of work to recovery
- You don’t need to do a whole heck of a lot of it. I might do this for only 20 minutes…I typically pair it with a Zone 2 day
- I might do a Zone 2 on the bike, and then I go on the stair climber and I’ll do two minutes of whatever is approaching failure
- Then two minutes of basically just a trivial effort. Then just repeat that five times. that would be an example

**The dramatic drop off with age**

- Take a look at the elite column and look at the VO2 max in the elite column, and look at how precipitously it falls
- Going from the second decade of life to the third, the third to the fourth, the fourth to the fifth, the fifth to the sixth, very little fall
- Then look what happens, big fall, bigger fall, bigger fall
- We know this based on the difference between how people perform in endurance activities versus explosive strength activities as they age
- We see a greater ability to maintain cardiorespiratory fitness at a Masters level as you age and a lower level to maintain explosivity and strength as you age due really to the shift from Type II to Type I fibers

*“Elite” doesn’t mean “elite athlete”*

- Don’t confuse this for elite *athlete* — This is just the characteristic that was given to a general population that fall in the top ~2.5% of the population
- Each time you move from one of these groups to the next, you get a statistically significant benefit
- But the benefit gets less with each bump—You’re always going to want to go to the right and up, meaning increase your fitness and mimic that of somebody younger

**\*The most important point of this topic\***

- The most important thing is getting out of that low and/or below average group
- you get such an advantage of getting out of that group—**it’s more beneficial than if a smoker quit smoking**

> “If you knew somebody who had low cardiorespiratory fitness and didn’t want to take the steps that were necessary to get into even average or above average fitness, you would be able to say to them, ‘*Do you realize the choice you’re making is more illogical than a smoker who continues to smoke?*’…And it’s no comparison. It’s no comparison in terms of the hazard ratio of death.” —Peter Attia

## Muscle mass, function, and loss with aging: how it’s defined, measured, and the cutoff points for sarcopenia [25:00]

**Two variables**

- muscle size
- muscle strength

[**Sarcopenia**](https://en.wikipedia.org/wiki/Sarcopenia)

- Does it specifically refer to a reduction in one or the other?
- The first working group called Consensus, they looked at to [define sarcopenia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4066461/)
- First they would look at low muscle mass, and we can talk about what that actually means and what’s the cutoff
- Then some combination of either low muscle strength or low physical performance
- That’s how they first defined it
- Recently they swapped out strength and size and put an emphasis on low muscle strength.
- That’s the first criteria: If you have low muscle strength, then you have probable sarcopenia
- After that, when you look at low muscle quantity or a quality, which is more or less looking at muscle mass, then that’s a confirmed diagnosis of sarcopenia
- Then they use that third category of physical performance, that if you’re also low in physical performance, if you’re low in strength, low in quality and quantity of the muscle and low in physical performance, then they consider it more **severe sarcopenia**

Sarcopenia is one of the more inevitable aspects of aging—”probably the worst gravity of aging”

- Basically, as a result of aging, we’re seeing more low grade inflammation, more oxidative stress, impaired regenerative capacity, impaired muscle protein synthesis
- We replace our Type II muscle fibers—more contractile function—with fat and connective tissue
- The net result is we are losing two things, i) the structural component of the muscle—the loss of the actual contractile function, and ii) the metabolic myocyte function
- That’s why it’s accompanied by more insulin resistance, less glucose disposal, greater tendency to diabetes

*But how do you measure muscle mass?*

- You could get an accurate measure by using a CT scan or an MRI to do that, but they are not good options practically speaking
  - A whole body CT scan to elucidate muscle mass wouldn’t make any sense because the risk of radiation far outweighs the benefit
  - Whole body MRI, for the sake of getting muscle mass also wouldn’t make a lot of sense for reasons that are technical not withstanding costs
- Gold standard today is **Dual X-ray absorptiometry (DXA or DEXA)**
  - While it’s not quite as accurate as CT and MRI, it does allow you to come up with an approximation of total muscle mass by just looking at the appendices (or appendicular lean mass (ALM))
  - The reason you have to look at just the arms and the legs is because if you try to get the muscle of the torso, you’re confused by the amount of fat that’s there as well
  - studies seem to typically just look at what’s called appendicular limb mass. Although I’m not sure why they don’t look at total lean mass and subtract out bone mineral content and fat mass
- Another common way—which probably is less accurate—is Bioelectrical Impedance Analysis, BIA
  - It’s a two compartment models: They’re looking at basically how much fat mass you have and how much fat free mass you have and also considering bone, connective tissue and the organs
- With DEXA, however, you get a third compartment — It picks up the bone mineral density, and that’s why a lot of people get DEXA scans
  - On top of that, when they look at the appendicular lean mass, “I think what they’re doing in a way, is they’re probably trying to take most of the organs out of the equation”
  - It’s not necessarily an additional compartment, but I think it helps probably with the accuracy.
  - It’s less confusing if you just look at limbs because you don’t have to worry about how much fat is in the liver or whatever other organs

![](https://peterattiamd.com/wp-content/uploads/2021/09/f4-ama27-1024x639.png)

**Figure 4.** DEXA scan example.

- In this individual’s case, you have 17.4 kilograms of appendicular lean mass
- You then normalize that by height and you get a number in kilograms per meter squared
- In this case, 6.24
- This is a 49 year old female and she’s right above the cut point so she wouldn’t be considered sarcopenic

![](https://peterattiamd.com/wp-content/uploads/2021/09/f5-ama27-1024x483.png)

**Figure 5.** Appendicular lean mass/height2 (kg/m2) vs age. Lines indicate 3rd, 10th, 50th, 90th, and 97th percentile. Age in years, LMI and appendicular LMI in kg/m2. ([Ofenheimer et al., 2020](https://www.nature.com/articles/s41430-020-0596-5))

- The woman in figure 4 above is right at the 50th percentile
- Notice there’s a pretty wide range in the population
- For example, a 50 year old woman in the bottom 3% would have an ALMI of five kilograms per meter squared
- other end of the spectrum, the most muscular, the top 3% would be probably 8.5
- For males at 50, we’re going to say the bottom 3% would be just below 7.0
- At the opposite end of spectrum for men, the top 3% are probably 10.5

**More on men vs. women**

- First, There is a relative stability for women as they age; whereas men experience more of a decline
- Secondly, women tend to hold a higher percentage of their muscle mass below their waist

**Peter’s discusses his personal DEXA score**:

- By the way, I ran my numbers yesterday. On my last DEXA, I was just below nine.
- not too happy about that in the spirit of needing more muscle. I want to have my ALMI be as good as my cardiorespiratory fitness. I need to bulk up my arms and legs more
- a previous DEXA, which was 9.5
- Interestingly, both of them, even though I was more muscular on the last one, which was years ago, it was exactly 70% lower body muscle mass
- Whereas when I did it on my wife, she was 78% of her limb muscle mass was in the lower extremities

***This is a great overview of where the population sits, but where do we actually define sarcopenia based on these nomograms?***

![](https://peterattiamd.com/wp-content/uploads/2021/09/f6-ama27-1024x392.png)

**Figure 6.** EWGSOP2 sarcopenia cut-off points ([Cruz-Jentoft et al., 2019](https://academic.oup.com/ageing/article/48/1/16/5126243?login=true))

**The sarcopenia cutoff points**:

- Muscle quantity section in this table, which is abbreviated as ASM (stands for appendicular skeletal muscle mass or appendicular skeletal mass–It’s the same thing as ALM)
- We look at below the ASM, it’s divided by height in meters squared, which is the same thing as that appendicular lean mass index
- For men, the cut off point is ASM divided by height or ALMI of **below 7.0 kilograms per meter squared**
- For women, the cutoff is lower, at less than **5.5 kilograms per meters squared**
- If you’re looking at this, you’re looking at both a quantitative and a functional definition of sarcopenia
- So total muscle mass in men, less than 20 kilograms in the arms and legs, or normalizing it to less than 7.0 kilograms per meter squared
- **Functional deficits**
  - If you go to the top of the table, they have cutoff points for low strength by “chair stand” and “grip strength”
  - For grip strength… the cutoff points for men is less than 27 kilograms and for women it’s 16 kilograms
  - For the chair stand…the cutoff points for men and women is greater than 15 seconds for five rises
    - You’ve got a person standing there with a stopwatch. You’ve got the subject, the person that’s being tested. That person is sitting in a chair and they can’t use their arms
    - You cross your hands to your shoulders. You’re taking your arms out of the equation, and the person will say, “Ready, set, go.” you get up from out of the chair, standing upright, back down into the chair. You repeat that five times as quickly as you can. If that takes longer than 15 seconds, then you would have low strength by this criteria
- For the record, most of the research focuses on grip strength, quadricep strength, and volume and muscle mass

## Increasing mortality risk associated with declining muscle mass and strength [40:00]

***Once you now define a group as having low muscle mass or low muscle strength, what is the implication in terms of mortality?***

A [meta analysis](https://www.sciencedirect.com/science/article/abs/pii/S0378512216304029) looked at this in 2017

![](https://peterattiamd.com/wp-content/uploads/2021/09/f7-ama27-1024x757.png)

**Figure 7.** Adjusted HRs for the association between sarcopenia and ACM. ([Liu et al., 2017](https://bmjopen.bmj.com/content/8/11/e021252))

They stratified the meta analysis studies—

- So you’ll see two studies at the top where it’s follow up is less than or equal to five years
- Then the majority of the study, another five studies, are greater than or equal to five years
- In red font, it tells you how they were actually measuring muscle mass, because it’s not consistent across the board based on that criteria that we just saw.
- Here you can look at the effect sizes of each individual study
- These diamond shapes that you can see below the followup at the top of less than five years, below the followup of greater than five years
- Then they have an overall diamond at the bottom, which is basically the results of their meta analysis

*Results:*

- They found for people with sarcopenia defined this way, a 60% increase in the relative risk of death compared to people without
- The shaded box is a metric of the weighting given to the individual study and the overall meta analysis
- *Why is that brown study worth 47% of this analysis?* ⇒ population size
- *What’s the difference between the two Kim studies in the above figure?* ⇒ Different genders
- The top one, which is showing effect size of 3.89, that was in men
- Then the other one that’s showing, an effect size of 1.25 was women,  and you’ll see that that actually crosses the one threshold, which is not statistically significant

*Implications:*

- If you take it on face value, the implication is that low muscle mass is a risk to men but not to women as they age
- The weight of the studies is based on how many people were in the study and there weren’t a lot of women
- The females is weighted lower because it’s a lower sample size, which I think played a role here as far as how it was weighted.
- M*ethods of measuring*:
  - The stuff in red, just for reference, the top one versus calf circumference or **calf circ**, these are the different ways that they’re measuring the lean mass
  - The **BIA** or the skeletal muscle, the SMI, BIA is SMI, you’ll see next to Bianchi study for example, that’s the skeletal mass index—which is more or less what they’re trying to do is getting an appendicular score. But you can’t really get an appendicular score from BI analysis. They have equations where they try to basically validate and test those things compared to a DEXA to try to get an estimate for the appendicular lean mass
  - **MAMC** it’s short for mid-arm muscle circumference.
    - In that case … They don’t do this with the calf, I don’t think. Which is probably a lot leaner. They take the circumference with a tape measure and then they also will get your tricep skinfold thickness. There’s a little bit of an adjustment there for fat mass when they’re looking at that.

**Another** [**study**](https://journals.lww.com/acsm-msse/Fulltext/2018/03000/Associations_of_Muscle_Mass_and_Strength_with.8.aspx) **looked at muscle mass and muscle strength and the relationship between the two and whether you can tease anything out between them**

![](https://peterattiamd.com/wp-content/uploads/2021/09/f8-ama27-1024x831.png)

**Figure 8.** Associations of LMM and LMS with ACM. ([Li et al., 2018](https://journals.lww.com/acsm-msse/Fulltext/2018/03000/Associations_of_Muscle_Mass_and_Strength_with.8.aspx)).

In upper figure,

- LMM
  - they’re showing us low muscle mass (LMM) by two methods i) absolute appendicular lean mass and ii) normalized appendicular lean mass by BMI
  - The white bar is the reference, so those that **do not** possess low muscle mass
  - Remember, men less than 20 kilos in total or 7.5 kilos per meter squared for low muscle mass
- LMS
  - Then low muscle strength (LMS) is the third piece using
  - They used a knee extension dynamometer for testing leg strength (instead of grip strength in this case)
- Takeaway of this top figure
  - For LMM,
    - Takeaway is that the appendicular lean mass in an absolute term was not a predictor of mortality, though there was a trend towards it
    - And when you normalize by BMI, there was a 47% increase in all-cause mortality
    - But  but it was not statistically significant
  - For LMS
    - Figures B and C that are the really interesting ones here
    - This is where you now get the two by two and you try to infer what’s happening in the context of low muscle mass and/or low muscle strength
    - The double negative, meaning not having low muscle mass and not having low muscle strength is the white bar and that’s unity risk
    - Here’s what’s interesting:
      - If you **do not have low muscle strength**, but you’re deficient in muscle mass, there’s no statistically significant change
      - Now, if you **don’t have adequate strength**, it turns out even muscle mass doesn’t rescue you
      - It quite eloquently answers the question of whether mass or strength matters more… and it would appear the answer is **strength matters more than mass**

**Important points from this** [**study**](https://journals.lww.com/acsm-msse/Fulltext/2018/03000/Associations_of_Muscle_Mass_and_Strength_with.8.aspx)

- The way they put it was that low muscle strength was independently associated with increased risk for mortality
- **The takeaway** would be, that if you have low muscle mass, provided you have adequate strength, you’re okay
- And this is good news because people come in all shapes and sizes—You have mesomorphs, ectomorphs, endomorphs, etc.
- Good news is that you can be one of those wiry strong people and you get all the benefits
- Having big muscles is great for show but it turns out that it’s what those muscles can do that probably matters more, at least in this analysis

> “*The way I interpret this clinically is, be less concerned with the size of your muscles and be more concerned with how strong you are. But know that these two track very closely. The bigger your muscles get, all things equal, the stronger you’re probably getting as well*.” —Peter Attia

*A note about the studies that show “mixed” results in terms of muscle mass/strength and mortality risk*

- Bob points out that many of them try to “adjust” for “confounders” and what they end up doing is removing diabetic people or people with renal disease
- But those conditions are often entangled together and correlate with low muscle mass/function
- Bob says,
  - “*At least the literature says that one of the drivers, one of the causes of end-stage renal disease is diabetes. I think that that paper adjusted for diabetes. If you do that, that end-stage renal disease, you’re blocking the potential effect or at least from a hazard ratio perspective.”*
  - “*What was their absolute risk of death when they’re in one bucket versus the other? Because when you start adjusting for all these variables, I think it can get a little bit hazy sometimes*.”

## Muscle size vs. strength—which has the bigger impact on mortality risk? [58:00]

**How much lean mass and strength are people losing by time?**

Peter is constantly communicating to his patients about the gravity of aging — just think about what  aging is robbing you of as time goes on? “*You have got to fight like hell to avoid it*”

![](https://peterattiamd.com/wp-content/uploads/2021/09/f9.-Strength-loss-with-aging-in-literature-ama27-1024x417.png)

**Figure 9.** Strength loss with aging in literature ([Keller and Engelhardt, 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3940510/)).

- The lowest rate of decline that Peter could see is 1% per year
- Another study showed 1.3% per year
- Others are sort of putting it at one to 2% per year after 50
- Loss of 35 to 40% between age 20 and 80
- And the strength losses might even be greater
- Some studies even showing 4% strength loss per year

**\*Peter’s important message\***

- It’s very difficult to put that in context when you understand what compounding does
- It gives you a sense of what it means to sort of be average when you’re 50.

> “If you have the aspiration of kicking ass when you’re 85, you can’t afford to be average when you’re 50.” —Peter Attia

- Either through cardiorespiratory fitness, strength, or probably even muscle mass, to some extent, given its association with strength
- You’ve got to be strong. You’ve got to have muscle mass to accompany that strength.
- You’ve got to have the cardiorespiratory fitness

**Another** [**study**](https://academic.oup.com/biomedgerontology/article/61/1/72/549632) **that went out 10 years on the Kaplan–Meier curves**

![](https://peterattiamd.com/wp-content/uploads/2021/09/f10-ama27-1024x552.png)

**Figure 10.** Muscle strength and mortality risk per SD of quadriceps or grip strength. ([Newman et al., 2006](https://academic.oup.com/biomedgerontology/article/61/1/72/549632))

- They looked at men and women leg strength versus grip strength (a leg extension and a grip exercise)
- The leg strength, they did it in newton meters
- The grip strength is in kilograms
- Average age about 54 for men and women—essentially evaluating people in their sixth decade of life
- They were followed prospectively for five to six years and looked at all-cause mortality

**Results when looking at men’s leg strength…**

- “it’s definitely not subtle”
- Generally with time, every Kaplan-Meier curve moves down as you go to the right
- But the weaker you are, the quicker it goes down
- Important to point that out that they took their strength metric and they normalized it by muscle size
- They used actually CT cross-sectional area and then they used DEXA
- But when you take that normalized unit of strength per CT area and you reduce that by 0.2 units, or DEXA reduced by 0.34 units, you are seeing an increase of 26% or a 39% increase in mortality, respectively
- With reduction in grip strength, which was normalized by DEXA arm measurement, it’s at 23%
- And all of these were statistically significant

**For women…**

- It’s worth noting that they were statistically significant, but they had basically a higher confidence interval or a larger confidence interval. Meaning they came close to crossing unity.
- It’s probably worth including table four in the show notes because frankly I find the table to be an easier way to appreciate these statistical relevance of this

![](https://peterattiamd.com/wp-content/uploads/2021/09/f11-ama27-1024x671.png)

**Figure 11.** Specific Torque–Mortality Risk per Standard Deviation in Men and Women. ([Newman et al., 2006](https://academic.oup.com/biomedgerontology/article/61/1/72/549632))

**The main point**:

- Using a pretty rigorous way to quantify strength and normalizing strength by size of muscle
- And then prospectively following people, we again see this trend
- This goes hand in hand with the previous analysis which showed us that **strength is the more important parameter**

## Evaluating the cumulative impact of cardiorespiratory fitness and muscular strength on mortality risk when put together [1:03:30]

**What does it mean to be both fit from a cardiorespiratory standpoint and a strength standpoint?**

- - A lot of people who enjoy doing one type of exercise at the expense of the other

- I*s there a case to be made for doing both*?

![](https://peterattiamd.com/wp-content/uploads/2021/09/f12-ama27-1024x692.png)

**Figure 12.** Joint associations of CRF and grip strength with all-cause mortality ([Kim et al., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6153509/))

- You’re basically looking at three groups, each of which has three sub groups in it
- Major groups are by strength, low, medium, and high strength
- within each of them, is low, medium and high cardiorespiratory fitness
- You have the double negative is at the very top number
- The double positive is the very bottom number
- We choose to make the double negative the unity reference—so we’re saying, someone with low strength and low fitness has the hazard ratio of one
- They’re running these as risk **reduction** hazard ratios, as opposed to the opposite

Peter looks at this and says, “*Wow, if you have low strength, improving your cardiorespiratory fitness gives you a really big bang for your buck*.”

- If you go from ‘low strength, low cardiorespiratory’ up to ‘middle respiratory fitness’, that gives you a whopping 34% risk reduction
  - If you take it all the way up to high, it takes you to 42% risk reduction
- Just by comparison, what happens if you are in the double positive group, you have high strength and high respiratory fitness
  - you’re at a 47% risk reduction
  - That’s not very accretive; Meaning, that’s not a huge bang for your buck there if you’re looking for the minimum effective dose
- Conversely, now take someone who has low cardiorespiratory fitness and ask what happens as they march up the strength curve
  - They go from one to 0.78, to 0.71
  - If you’re low cardiorespiratory fitness, you’re going to go to a 22% and a 29% improvement in mortality as you move up the strength curve
  - It’s not as much of a bang for your buck
- a bit of an oversimplified analysis, but the eyeball analysis is you probably get more bang for your buck on cardiorespiratory fitness, but doing both is better than doing one or the other

***\*What do these data points not capture?***

- They don’t capture quality of life
  - None of this speaks to, can you play with your grandkids?
  - Can you still enjoy the things that you really love doing when you’re in your 80s that you enjoy doing in your 50s?
  - I think the more of those things that you want to enjoy later in life, the more you want to be in that highest group of both strength and cardiorespiratory fitness
  - Those things are harder to quantify, but they matter quite a bit

## Investigating the rising incidence in deaths from falls, and what role Alzheimer’s disease might play [1:09:00]

Peter says it’s “stunning” when you look at the increase in mortality we’ve seen over the past decade basically with respect to falls

![](https://peterattiamd.com/wp-content/uploads/2021/09/f13-ama27-1024x861.png)

**Figure 13.** Fall death rates in the U.S. from 2007 to 2016 for adults aged 65 and older. ([CDC](https://www.cdc.gov/homeandrecreationalsafety/falls/adultfalls.html))

- From 2007 to 2016, a 10 year period, we saw the deaths per 100,000 in the United States as a result of falls go from about 46 to 60 (That’s a **30% increase**)
- At this rate, by 2030, we’re going to see seven fall deaths every hour

*Death from fall stats:*

- Looking at some of the death rates from 2016, the death from fall is 61.6 per 100,000
- To put that in perspective, in adults age 65 and older the #10 cause of death is Septicemia (Sepsis) at 61.7 per 100,000
- If you take all accidental deaths, they lump in falling, motor vehicle accident and unintentional poisoning—those three make up 80% of accidental deaths (about the 5th leading cause of death)

*What’s driving this increase in the falling death rate?*

- First, a [paper](https://www.cdc.gov/mmwr/volumes/67/wr/mm6718a1.htm) speculated that this rate increase in deaths from falls might be because of longer survival after the onset of common diseases like heart disease, stroke and cancer, for example
  - In other words, people are getting longer survival but maybe not necessarily healthier survival
- Another thing worth considering…Alzheimer’s disease:
  - Alzheimer’s disease deaths in adults over the age of 65 over the same period, from 2007 to 2016, there’s a similar rate increase (26%) to the increase in fall deaths (30%)
  - There’s probably quite an overlap between those two groups, says Peter
  - Sarcopenia is a risk factor for Alzheimer’s disease
  - And if you have Alzheimer’s disease, that’s also a risk factor for sarcopenia
  - This might be a “vicious cycle situation”

![](https://peterattiamd.com/wp-content/uploads/2021/09/f14-ama27-1024x715.png)

**Figure 14.** Number and rate of TBI-related deaths by age group and mechanism of injury. ([CDC](https://www.cdc.gov/traumaticbraininjury/pdf/TBI-surveillance-report-2016-2017-508.pdf))

- Peter was shocked to see that the leading cause of traumatic brain injury is unintentional falling, which exceeds that of even motor vehicle accidents
- That means that these unintentional falls are not just the leading cause of mortality, but now morbidity from TBI

## The impact of fasting on muscle mass and the potential tradeoffs to consider [1:14:30]

**Strength training in the context of fasting**

- People look at fasting and actually caloric restriction and say, “*Is there a trade off here that I’m making between building muscle and preserving muscle and potentially fasting*?”
  - ⇒ Peter talked about this a little bit with [Steve Austad on the The Drive](https://peterattiamd.com/steveaustad/) podcast
- In the laboratory animals, they seem to do well with caloric restriction, but it’s not clear if animals in the wild do
- It’s certainly not clear that humans who are calorically restricted live a longer life
- It’s probably likely that they are going to be less likely to get cancer, heart disease and certainly diabetes.
- They’re clearly less likely to die from the common diseases of the developed world, but they might be more likely to die of infections, falls and other things
- It’s not really clear that extreme caloric restriction would provide a mortality benefit

***Fasting and muscle mass: What is the tradeoff?***

- You are making a trade off
- Anytime you are doing a prolonged fast, probably anything over a couple of days, you’re taking a catabolic hit
- Now the question is, *how much of a hit are you taking to muscle size versus muscle strength?*
- Peter says, “I can say anecdotally from when I was doing a lot of long fasting, I didn’t really lose strength, but I did lose size”
- “It wouldn’t surprise me if, when I come here for myself today to myself 10 years ago, that might be one of the greatest drivers of that loss in size”
- Everyone needs to be thoughtful about how they use fasting as a tool
- Some patients should never be fasting
- It’s not because fasting isn’t valuable, but it’s because in some cases, the trade off is probably not worth it
- Such as patients which need to be more anabolic for purposes getting them built up and getting them bigger and stronger
- Other people really need the metabolic benefits of fasting, the improvements in insulin sensitivity, glucose regulation, all those other things, all the cardio-metabolic parameters, and getting those things better with fasting is worth the reduction in some muscle mass

*For instance, if you took somebody who weighs 300 pounds, who’s 50% fat by DEXA…*

- Fasting is a wonderful tool in that person
- But you have to understand that to get that person from 50% body fat to 30% body fat, you’re going to give up muscle as well
- But the good news is you’re starting with quite a bit

*No one-size fits all*

- You can’t take a one size fits all to this problem. You have to evaluate it in the context of where you are.
- That’s why a lot of the nomograms and standardized data that we’ve presented in this podcast are valuable—it is important that you can put yourself on those nomograms and say “*Where am I on this ALMI index? Where am I on this sarcopenia reference slide?”*
- Anybody who is in “shouting distance” of sarcopenia should not be fasting or in a calorie-restricted state
- In that case, you will want to come up with other ways nutritionally to get all of the metabolic benefits

## The critical importance of working to maintain muscle mass and strength as we age [1:20:30]

![](https://peterattiamd.com/wp-content/uploads/2021/09/f15-ama27-1024x736.png)

**Figure 15.** Paddon-Jones Curve.

Looking at the Paddon-Jones curve:

- A lot of people think that there’s a linear or gradual decline in muscle mass or muscle size as we age
- The reality is that it’s a lot more staggered as you get into older age… if you’re injured or if you’re bedridden, for example, that accelerates the decline

[Art De Vany](https://en.wikipedia.org/wiki/Arthur_De_Vany) often talks about “physiological headroom” which is basically just having a muscle reserve so that on a rainy day—which might mean you might get a disease or you might have an injury where you are going be incapacitated—that to have that muscle and reserve is really important

> “You can wait until you’re older to start building muscle. . .that could be potentially disastrous.” —Peter Attia

**Effects of COVID**

- Contemplating the effect that COVID had on people, it’s easy to just think about COVID in terms of life versus death
- For the people that did end up in the hospital, there’s this enormous deconditioning problem
- In the [podcast with Layne Norton](https://peterattiamd.com/laynenorton/), he mentioned a study that took a group of older subjects and trained them heavily for a year resulting in an additional 5 lbs of muscle mass
- But after just a few weeks of inactivity took it all away
- “I*t’s like if training or exercise is a pill, it’s one that you can’t afford to skip it too often or consistently*.”

> “*My final point here is, find a way to love this thing. Because if this is like swallowing Cod liver oil for you, I think you’re in for a tough life. Whatever you need to do to maximize your cardiorespiratory fitness, your strength, come up with a way to enjoy it because you’re going to need to do it every day*.” —Peter Attia

§

## Selected Links / Related Material

**The Drive episode with Alex Hutchinson where they discussed why at a certain point you can’t utilize more oxygen exercising all out**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) | Peter Attia (peterattiamd.com) [6:15]

**The highest ever recorded VO2 max**: [The Story of the Cyclist with the Highest-Ever VO2 Max](https://www.outsideonline.com/outdoor-adventure/biking/highest-ever-vo2max-cyclist-oskar-svendsen/) | Alex Hutchinson (outsideonline.com) [7:15]

**AMA where Peter dives deep into his zone 2 protocol**: [#145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/)| Peter Attia (peterattiamd.com) [20:00]

**Definition of sarcopenia by the European Working Group on Sarcopenia for Older People (EWGSOP)**: [Sarcopenia: European consensus on definition and diagnosis: Report of the European Working Group on Sarcopenia in Older People](https://academic.oup.com/ageing/article/39/4/412/8732) (Cruz-Jentoft et al., 2010) [25:45]

**Meta analysis that looked at sarcopenia and mortality risk**: [Sarcopenia as a predictor of all-cause mortality among older nursing home residents: a systematic review and meta-analysis](https://bmjopen.bmj.com/content/8/11/e021252) (Zhang et al., 2018) [40:30]

**Study looking at muscle mass and muscle strength and the relationship between the two and whether you can tease anything out between them**: [Associations of Muscle Mass and Strength with All-Cause Mortality among US Older Adults](https://journals.lww.com/acsm-msse/Fulltext/2018/03000/Associations_of_Muscle_Mass_and_Strength_with.8.aspx) (Li et al., 2018)

**Framingham Heart Study**: [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study) | (wikipedia.org) [53:45]

**Study concluding that strength of muscle may be more important than muscle mass**: [Strength, But Not Muscle Mass, Is Associated With Mortality in the Health, Aging and Body Composition Study Cohort](https://academic.oup.com/biomedgerontology/article/61/1/72/549632) (Newman et al., 2006) [1:00:00]

**CDC paper that speculated that rate increase in deaths from falls might be because of longer survival after the onset of common diseases**: [Deaths from Falls Among Persons Ages greater than 65 years — United States, 207-2016](https://www.cdc.gov/mmwr/volumes/67/wr/mm6718a1.htm) | (cdc.gov) [1:12:00]

**Episode of The Drive which touched on fasting/calorie restriction and its impact on muscle mass**: [#171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules](https://peterattiamd.com/steveaustad/) | Peter Attia (peterattiamd.com) [1:15:15]

**Episode of The Drive with Layne Norton**: [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) | Peter Attia (peterattiamd.com) [1:23:00]

§

## People Mentioned

- [Alex Hutchinson](https://alexhutchinson.net/about.htm) [6:15]
- [Oskar Svendsen](https://en.wikipedia.org/wiki/Oskar_Svendsen) (person with highest recorded VO2 max) [7:15]
- [Art De Vany](https://en.wikipedia.org/wiki/Arthur_De_Vany) [1:22:00]
- [Steven Austad](https://www.uab.edu/cas/biology/people/faculty/steven-n-austad) [1:15:15]
- [Layne Norton](https://twitter.com/BioLayne?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:23:00]

§