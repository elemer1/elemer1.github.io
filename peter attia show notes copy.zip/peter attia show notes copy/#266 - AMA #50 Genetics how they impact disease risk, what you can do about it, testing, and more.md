# #266 – AMA #50: Genetics: how they impact disease risk, what you can do about it, testing, and more

**Source:** [https://peterattiamd.com/ama50/](https://peterattiamd.com/ama50/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into the realm of genetics, unraveling its connection to disease and emphasizing the value of understanding one’s genetic risks. He elucidates essential background knowledge on genetics before delving into the myriad reasons why individuals might consider genetic testing. Peter differentiates scenarios where genetic testing provides genuine insights from those where it may not be as useful. From there, Peter explores a comprehensive comparison of commercial direct-to-consumer genetic tests, providing insights on interpreting results and identifying the standout options for gaining insights into personal health.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #50 show notes page](https://peterattiamd.com/ama50). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Defining the term “genetics” and why it’s important [2:15];
- What is DNA, and how does it impact our biology and traits? [5:45];
- How are genetics passed down from parent to child? [8:45];
- How much do genes vary across individuals? [13:00];
- Which traits are determined by genetics versus experience or environmental factors? [17:00];
- Reasons for genetic testing [22:30];
- What exactly is being measured by a genetic test? [29:15];
- Testing for monogenic disorders [35:15];
- Understanding polygenic risk [39:30];
- Is genetic testing more important for someone who doesn’t know their family history? [40:45];
- What does it mean to be positive for a particular variant? [43:00];
- What does it mean to be negative for a particular variant? [45:45];
- How does someone get genetic testing through their healthcare provider, and how are these tests performed? [48:15];
- The financial cost of various genetic tests [54:30];
- Could having a risk allele for a disease result in an increase in one’s insurance premium? [57:15];
- Other risks associated with genetic testing [59:00];
- How do commercial, direct-to-consumer genetic tests compare to the information one might receive from clinical genetic testing? [1:01:45];
- Are certain direct-to-consumer tests better than others? [1:03:45];
- How long until whole genome sequencing becomes genuinely useful? [1:16:00];
- How useful are personalized dietary recommendations based on genetics? [1:18:15];
- Final thoughts and advice regarding genetic testing [1:20:00]; and
- More.

§

The Peter Attia Drive

Genetics: how they impact disease risk, what you can do about it, testing, and more

§

## Show Notes

§

## Defining the term “genetics” and why it’s important [2:15]

**Today’s focus**:

- To understand genetics at a basic level, reasons for genetic testing, types of tests available, how to interpret the results, and more
- Understanding the above will help frame the conversation about specific commercial/direct to consumer DNA tests and where are they useful, where are they not, how should someone think about them

⇒ Previous AMA that touched on genetic testing: [AMA #8](https://peterattiamd.com/ama08/)

**What is meant by the term “genetics”?**

- When you hear people talk about nature versus nurture, this is what we mean by the “nature” part of it
- When we’re talking about genetics, we’re talking about the part of a person that has been passed down from the parents
- We differentiate this from the stuff that we talk about that’s nurture related—these are non-genetic traits that could be passed down through cultural, socioeconomic traits, etc.
- Genetics obviously play a very important role in understanding physical, psychological, social factors
- But what we really want to talk today are about these genetic pieces
- Genetics can’t be changed (shy of genetic engineering/gene therapy, etc.)
- What we are exploring today is understanding how genes shape and predispose us to various conditions
- Or how perhaps having certain genetic conditions might make us choose certain lifestyle modifications as a result of that to modify risk
  - For example, there are some genes that are completely deterministic—meaning if you have the gene, it’s going to produce a trait regardless
  - Then there are many more genes for which if you have a certain gene, you might not necessarily get the trait
- T*his is not a particularly well understood field once you get beyond the surface level*, says Peter

## What is DNA, and how does it impact our biology and traits? [5:45]

- A lot of times when you think of genes, you think of DNA as well
- But DNA is just a code of instructions that tell a cell how to function

**Analogy: Thinking of it as a cookbook**

- A cookbook will have discreet sets of instructions in the form of individual recipes
- And DNA also has a discrete set of instructions in the form of individual genes
- A recipe is just a recipe, but for it to become a meal someone needs to do something about it, someone needs to read it and then follow it and actually do the cooking
- And genes are sort of the same way, they only work by being expressed
- When you hear gene expression, that means making a copy of that DNA into something called RNA, that process is called **transcription**
- And then turning that RNA into a protein, and that process is called **translation**
- Proteins are more than just muscles—Proteins are enzymes and other cofactors and things of that nature
- Basically, everything that needs to get carried out in a cell is being done via this process

> “One of the biggest surprises of the genetic revolution was the relatively small number of genes that humans have.” —Peter Attia

- Humans only have about 20,000 protein coding genes in total
- While that sounds like a lot, if you consider the fact that lab mice on average have about 23,000-25,000 genes
- Krill have 29,000 genes
- Rice and mushrooms have about 50,000 genes
- So when you think about things that are far simpler than we are and they have far more protein coding genes, you realize that that’s just part of the story
- It had been long assumed that one gene led to one function
- Yet, a single gene can often be read in many different ways, giving rise to many different strands of RNA (and by extension, proteins) which can then be modified post translation to create even greater functional heterogeneity

## How are genetics passed down from parent to child? [8:45]

- When we talked in the past about the APOE4, you get two copies of APOE
- And for someone to have an e4, one of their parents must have a e4 as well

**Peter will now walk through how genetics are just passed down in general**:

![](https://peterattiamd.com/wp-content/uploads/2023/08/f1-ama50.png)

**Figure 1: DNA Structure.** Source: [National Cancer Institute](https://visualsonline.cancer.gov/details.cfm?imageid=10062)

Let’s start from the simplest and go to the more complex

- Going to go all the way from a base pair to a chromosome, there are four base pairs in DNA—these are called nucleotides
- Nucleotides are abbreviated by their letters G, C, A and T (guanine, cytosine, adenine and thymine)
- The Gs and the Cs can only be paired together, and the As and the Ts can only be paired together
  - In other words, if you know what one strand is, you automatically know the other because each nucleotide can only be paired with one other nucleotide
  - And that has to do with the way that they fit and the type of hydrogen bonds across them
- The string of nucleotides is the genetic sequence and a certain number of them create a gene (it’s usually thousands of them to make up a gene)
- Looking at the figure above, you have a long string of nucleotides
- Remember, the whole thing with DNA is that it creates that double helix
- That lengthy string of DNA are divided into segments known as genes
- These long strands of DNA as genes wrap around other proteins called histones
- Those histones further organize and wrap up around really, really large things that you can actually see under a microscope called chromosomes

**Chromosomes**

- Humans have 23 pairs of chromosomes
- For each pair, what that means is we get one chromosome from the mother, one chromosome from the father
- The only thing that is a bit wonky here, of course, is that there are two of those that are sex specific
- We have 22 pairs that would look identical from a mother or father, and then you have your sex chromosomes, which if you are in most cases phenotypically female, you would have an X and an X
- If you are phenotypically male, you would have an X and a Y
- There are very rare exceptions to this rule
  - if you have an XXY, you’re sort of phenotypically male, but you have these other characteristics ([Klinefelter syndrome](https://www.nhs.uk/conditions/klinefelters-syndrome/#:~:text=Klinefelter%20syndrome%20(sometimes%20called%20Klinefelter's,genetic%20sex%20of%20a%20baby.))
  - If you’re X and no Y, that’s [Turner syndrome](https://www.mayoclinic.org/diseases-conditions/turner-syndrome/symptoms-causes/syc-20360782), which is sort of phenotypically female, but has different characteristics
- But for the most part, it’s going to be 22 pairs plus an XX or an XY
- What that means, by the way, is you are getting basically two sets of every gene
- Those two copies could be identical or they could be different, and the different versions are referred to as alleles
  - Some traits result from a combination of the effect of both copies (e.g., hair texture)
  - Other traits tend to follow a dominance pattern—meaning one of the parents’ alleles tends to be dominant (e.g., hair color … brown is dominant over blonde/red)
    - All things considered equal, if somebody with black hair, somebody with blonde hair have a kid, there’s a more likely chance that that child is going to have darker hair
  - For most genes, roughly 90% of the time having one functional copy is typically enough to produce a normal phenotype

## How much do genes vary across individuals? [13:00]

***How much do genes vary across individuals?***

- This gets a little complicated
- Everyone has the same set of genes, but different individuals have small variations in the sequence of those genes or in the surrounding DNA—these are called SNPs (single nucleotide polymorphisms)
  - These influence the genes level of expression or even the level of function of the genes’ protein product

To put this in perspective, think about how distinct two individuals can be…

- Nick probably descended from Vikings in Northern Europe
- Peter clearly descended from people in the middle of Africa
- That said, Nick and Peter are still 99.5% (or more) genetically identical
- In fact, all humans are at least 99.5% genetically identical to each other
- It’s pretty remarkable that SNPs are only present in less than 0.5% of all base pairs for the entire human genome, and yet, that small, small variation accounts for all the genetically attributable differences and variability across humans in height, hair, skin color, susceptibility to diseases, everything

> “All the things about us that are genetically different are contained within less than 0.5% of our genome.” —Peter Attia

*How we compare to other species*:

- We share 99% of our DNA with chimpanzees
- We share about 90% of it with cats
- We’re about 50 to 60% genetically identical to bananas and basically any other plant for that matter

**More about genetic variation**:

- Genetic variation is not necessarily a bad thing
- When you do have genetic variation for humans, it can exist on a spectrum
- There are certain changes that can be completely benign
- And many of them are unknown significance
- People who are used to going through their own genetic material using third party applications like [Promethease](https://promethease.com/), what you’ll notice is they have a lot of things that exist in the “unknown significance” category
  - We categorize it as: benign, likely benign, unknown, possibly pathogenic, and pathogenic
- The reason for this is that a number of changes don’t really affect the way DNA is read and transcribed into RNA and protein
- Remember, the purpose of DNA is to create the template that gets transcribed into RNA
- And RNA gets translated into protein

**Fantastic analogy here using the cookbook metaphor**

- Imagine you have a recipe and it calls for two eggs
- The cookbook originally reads “two eggs”
- But pretend that somewhere in the process of retranslating that book, it gets turned into “two egss”
  - Is the person who looks at that cookbook going to know what to do? ⇒ Yeah, they will — so there is a mutation there, there’s a polymorphism, but it doesn’t change the overall food product, it doesn’t change the translation
- But what if the typo instead was changed from “2 eggs” to “5 eggs”?
  - That’s a material change and that’s likely going to result in pathology
- This example really illustrates why there are a lot of different ways you can re-translate “2 eggs” in ways that would NOT result in a different outcome, but there’s also a lot of ways you can mess it up

## Which traits are determined by genetics versus experience or environmental factors? [17:00]

*Which traits are determined by genetics versus experience, or environmental factors?*

- The degree to which a given trait or a health characteristic is determined by genetics is known as the “heritability” of a trait
- Heritability describes the amount of phenotypic variation in a given trait in a population that can be attributed to the genetic variation in that trait
- Most traits are influenced by a combination of genetics, environment, experience and through a number of influencer factors
- Some traits are entirely determined by genetics—your blood type, eye color—these are 100% heritable
- Others are basically completely determined by your environment and your experiences—your native language, your religion—those are 0% heritable
- But most things that we talk about fall somewhere in the middle
- Therefore, genes and the environment and experience interact to determine many outward characteristics of appearance and personality and susceptibility to disease, but not all.

**Now let’s talk about the things that people tend to care about**:

- Height, for example, is about 80% heritable
  - But 20% of that can be determined by things such as childhood and gestational nutrition, hazard exposures like if the mom was smoking during pregnancy, those can contribute to the other 20%.

**Types of studies are what allow us to understand how heritable certain traits are**

*This can be best studied looking at basically mono and dizygotic twins*:

- Monozygotic twins are identical twins, and that arises when an egg and a sperm are fertilized, and after fertilization they split so then you get two new cell growths that ultimately each become fetus, but they’re genetically identical
- Dizygotic twins are when two different eggs are either inserted via IVF or ovulated through natural conception, and then obviously they’re fertilized with two different sperms
  - Dizygotic twins are effectively just normal siblings that happen to be born or carried at the same time
- The study of dizygotic versus monozygotic twins is a really interesting way to study certain diseases

*For example, consider schizophrenia or autism*

- When you look at the occurrence of schizophrenia or autism in monozygotic twins versus dizygotic twins, what are you controlling for?
- In the monozygotic, you are able to look at what happens in the same genes, in the same in utero experience
- In dizygotic, you have different genes, same in utero experience
- Then you also have other experiments where you have monozygotic twins raised apart—so same genes, same in utero experience, different environmental triggers
- These types of studies are what allow us to understand how heritable certain traits are
- It’s doing studies like this that we see that there is reasonable concordance for schizophrenia and even more concordance for autism

*For example, looking in the particular case of schizophrenia*

- [Studies](https://www.sciencedirect.com/science/article/abs/pii/S0006322317319054) have shown about a 7% concordance between dizygotic twins while a 33% concordance in monozygotic twins, which suggests about a 79-80% heritability for the condition
- This is kind of more real world stuff where it’s not black and white and it’s not entirely heritable and it’s not completely environmental

*Using twins in studies: pros and cons*

- Studies that are trying to really understand mechanism of action, to be able to have twins is a very powerful tool
- To put it in perspective, think about how much animal research is done in effectively twins
  - Most animal studies are done in the equivalent of identical twin mice because they’re just genetically bred to be identical
  - They’re monozygotic at all loci throughout their entire genome
  - You might be doing an experiment on 300 mice, but they’re all exactly the same
- While there is great advantage to that, there’s also a disadvantage to that as you move further down the study from efficacy to effectiveness
- At some point you want to know what works for everybody

## Reasons for genetic testing [22:30]

**Types of screening:**

- Broadly speaking, genetic testing is used for either diagnostic purposes or to assess risk
- We’re seeing a significant expansion of this over time
- 20 years ago nobody was doing anything, and today the sky is sort of the limit

**Newborn screening**

- One type of very popular screening that most people now have exposure to is newborn screening
- This is done in a number of ways, but it’s basically one way to look for genetic diseases in children right away when they’re born
  - E.g., sickle cell disease, PKU, cystic fibrosis, things like that

**Carrier testing**

- As an extension of newborn testing… a lot of times people are doing what’s called carrier testing before they conceive to just look for copies of these genes
- A really common scenario here is when a couple decides they want to have kids, they want to conceive, and they know for example, based on ethnic susceptibility, that one of them might be a risk for something else
- For example, one person might be a risk for cystic fibrosis, either because there’s somebody in their family that has cystic fibrosis or they’ve had a genetic test previously that’s shown them that
  - Of course, cystic fibrosis is it’s one of those diseases where you need both copies of a gene to get it
  - Peter said earlier that if you have one good copy of a gene, you’re usually okay? ⇒ Well, CF is an example of that
  - If one of your parents is a carrier for the disease, but the other one is not, you’re going to be okay except for the fact that you might inherit the gene that makes you a carrier
- In Peter’s case, he has something called the beta thalassemia trait
  - So he just had to make sure that his wife didn’t have beta thalassemia trait
  - If she did, there’s a 25% chance any of their offspring would’ve had the actual disease because they would’ve had the two copies

**Prenatal or preimplantation testing [22:45]**

For people who are using in vitro fertilization/pre-implantation…

- They have the opportunity to actually genetically sample the embryo and do a much more elaborate screening and chromosomal analysis
- Basically each egg has half its copy of chromosomes
- An egg will have 22 chromosomes plus an X
- A sperm will have 22 chromosomes plus an X or a Y
- But you end up getting these things sometimes called monosomy or trisomies
- If there’s an unequal splitting, sometimes one of the parents will contribute two chromosomes
- For example, if there’s two contributions of chromosome 21 from one parent and one from the other, you end up with three chromosome 21s—that’s called trisomy 21, also known as down syndrome
- You also get a lot of monosomies where one parent just doesn’t contribute any chromosome there, so they’re deficient in that chromosome
- Again, a lot of these end up terminating as a pregnancy spontaneously usually in the first trimester
- This is a reason that parents want to know this sometimes before they implant

**Genetic tests, deterministic genes vs. predictive genes [24:30]**

- There are certain diseases for which we can genetically test for a disease

*Diagnostic testing for* ***deterministic*** *genes*

- Example: Familial hypercholesterolemia (FH) is a very heterogeneous disease
  - This means there are on the order of 3,000 different genetic permutations that produce that phenotype
  - We talked about on the [podcast with John Kastelein](https://peterattiamd.com/johnkastelein/)
  - So LDL cholesterol above 190 milligrams per deciliter
  - And some of those are known so you can directly test for that
- Example: Huntington’s disease
  - There’s a known gene that produces that phenotype
  - Many of the motor neuron pathway or what are called motor neuron neuropathies, these are basically things for which we just know that there are genes that go awry and you can test for those
  - Genes where if you have the gene, you get the disease – “*that’s why I kind of refer to that as diagnostic*”

***Predictive*** *testing for genes that predict odds of getting certain diseases*

- These are genes where if you have the gene, you’re at *increased risk* for something
- And depending on the gene, that risk might be a little bit higher or a lot higher
- Example, APOE4
  - If you have the e4 allele and you have one copy of it, yeah, you have a little bit of an increase in the risk of Alzheimer’s disease
  - If you have two copies of that allele, your risk is significantly higher
- Examply: Lynch syndrome
  - If you have what are called DNA mismatch repair genes
  - there’s a certain condition called lynch syndrome
    - Peter writes about his friend with Lynch Syndrome in his [book](https://peterattiamd.com/outlive)
  - If you have Lynch syndrome, your risk of colorectal cancer and other forms of cancer goes up dramatically
  - It doesn’t mean you’re going to get cancer, but it means that you’re basically on a totally different path for cancer screening

**Forensic testing**

- We can use DNA to now basically identify an individual uniquely
- In the past 30 years or so, this has totally revolutionized how law enforcement handles material at a crime scene to identify people

## What exactly is being measured by a genetic test? [29:15]

**Categories of genetic tests**

There are three categories of genetic tests, with our focus in this AMA being on **molecular** tests, and these tests vary in scope depending on the amount of DNA tested

**1) Molecular tests**: look at the genetic sequence to determine which SNPs (i.e., variants) we have

**2) Cytogenetic tests** (aka chromosomal tests): look for chromosomal abnormalities (chromosomes that are broken, missing, rearranged, or in excess)

**3) Biochemical**: measure the protein product of a particular gene rather than the genetic material itself.

- A clinical example of that is looking at ApoB
  - If you measure ApoB and it’s really, really high, you have a pretty good chance that this person has FH
  - So you’ve imputed that there’s a genetic problem by measuring the protein, but you don’t necessarily know what the genes are
  - By the way, you may never find the genes
  - Peter says: “*In fact, we were reviewing the blood of a new patient yesterday*”
    - His ApoB was probably 170 milligrams per deciliter, LDL cholesterol over 200 milligrams per deciliter
    - Going through his medical history, it’s pretty clear he has FH
    - But if we genetically test him, we might not demonstrate that because he might not have one of the genes that is a known gene, but he clearly has it and we’re imputing that from the protein.

**Molecular tests**

When we say “genetic testing,” we’re usually referring to **molecular tests** and these tests vary in their scope

- **Targeted single variant**: look exclusively for the presence or absence of one specific variant of a single gene.
- **Single gene**: look for any version of a single gene.
- **Gene panel**: look for variants in more than one gene.
- **Whole-exome sequencing**: analyze variations across all protein-coding DNA
  - Remember how we only have 20,000 protein coding genes?
  - Well that only represents ~1.5% of the whole genome, or roughly 40 million base pairs
  - So 40 million base pairs, which make up about 1.5% of our whole genome is the part that codes for protein
  - This was actually really surprising to the pioneers of this space: *How is it that 98.5% of our genome (3 billion base pairs) doesn’t even code*?
  - The truth of it is we still to this day don’t really have a clear sense of what’s going on there, but we know it matters
  - In other words, we know that mutations in the non-coding region lead to changes in the coding region, i.e., they alter expression of the genes
  - Nevertheless, if you want to sequence everything, that’s called a whole genome sequence, and that’s looking at the entire human genome
- **Whole-genome sequencing**: analyze variations across the majority of genetic material, including non-coding DNA. (~3 billion base pairs)

***Are there certain reasons you would do whole exome versus whole genome?***

- Yeah, says Peter, nowadays with the cost coming down so much in whole genome sequencing, many people are just doing whole genome sequencing
- There was a day when the difference between those was so cost prohibitive that you just wouldn’t do it
- The other issue with whole genome sequencing frankly, is just so much data and most of it we don’t know what it means
- So sometimes our patients will go out on their own and get these whole genome sequences
- These are not things that we recommend people just doing with no reason
- It’s very difficult to find anybody who’s going to interpret that with any clarity

**The bigger picture is here,** ***why would you do genetic testing in the first place?***

- It comes down to be understanding the information you can get from diseases that are caused by a single gene
  - That’s where we have the most luck, is understanding these monogenic disorders or risk factors
- Of course, the truth of it is that that’s the *exception* and not the rule
- Most things that you think about—cancer, neurodegenerative disease, cardiovascular disease— are caused often by multiple genes (polygenic risk)
- Again, it’s easy to think of the exceptions
  - Lp(a), the Lp(a) gene, which codes for LP little a, that’s a single gene that dramatically increases risk
  - And that could be, depending on the data, maybe up to 8, 10, 12% of people might have that
- And so there’s a monogenic risk, however, the average person who has a family history of cardiovascular disease, it’s being transmitted through **polygenic risk**

## Testing for monogenic disorders [35:15]

Genetic testing can provide information regarding risk for any disease known to be influenced by genetics, but we have the best understanding of information we get from looking at diseases that are caused by a single gene **(monogenic disorders)**

- A couple ways to think about diseases caused by a single gene:
  - 1) Disorders that are only caused by a given genetic variant (e.g., sickle cell anemia, cystic fibrosis, beta thalassemia, etc.)
  - 2) Diseases for which there’s a single gene that can significantly increase risk, but where the disease can also arise other ways
    - An example would be the BRCA mutation which increases the risk of in breast cancer
    - But you can obviously get breast cancer without the BRCA mutation

**Mendelian inheritance** means you have two copies of a gene coming from the mother, two copies of the gene coming from the father

- If it is a recessive trait, you need to get a copy of the gene from each parent (sickle cell anemia, cystic fibrosis is, beta thalassemia)
- If you get two copies, you’re going to have the condition
- This only occurs if each parent is a carrier and that would mean the child has a 25% chance to get two copies of the gene
- Of course, if one of the parents has the actual condition, then they’re guaranteed to pass you one of those genes

There are also **autosomal dominant conditions** where you only need one copy of the disease producing gene

- Huntington’s disease, a devastating neurodegenerative disease, requires that you only get **one** copy of the disease protein
- And you might ask, “Well, how the heck does that disease even exist if by definition the parent giving it to you has the disease?”
- That’s the tragedy of the diseases like these that do persist, which is they don’t present until after the age of reproduction
- So a parent doesn’t know they have this disease at the time that they’re reproducing.

**More about BRCA**

- BRCA is a gene that is associated with a high risk of breast cancer
- There are several variants of this, but BRCA1 and BRCA2 are the most common
- If a woman has the BRCA1 mutation, there’s an almost 70% chance she’s going to have breast cancer by the age of 70
- If it’s BRCA2, it’s closer to 75%.
- That has to do with a feature called penetrance—so *what is the probability, if you have the gene, that you’re going to get the condition (in this case, breast cancer)?*
- Those are the types of genes people really want to understand and study, because in the case of sickle cell and cystic fibrosis, knowing you have the gene has enormous implications for reproduction strategy
- In the case of BRCA1, BRCA2, knowing you have the gene has enormous implications for behaviors you might take
- Which on the one end of the spectrum could be how you choose to screen
- And at the other end of the spectrum might mean action that you take, such as having a prophylactic mastectomy

One of the reasons genetic testing can be very helpful is it really allows your health insurance company to be paying the bill for a lot of this stuff

- if a woman has a family history of breast cancer and she does NOT have a gene associated with that risk, she might be out of pocket if she wants to do really, really aggressive screening that goes beyond standard screening
- If a woman has a BRCA mutation, her health insurance is going to pay for that much, much more aggressive screening

## Understanding polygenic risk [39:30]

**Polygenic risk**

Going back to this thing about the polygenic risk: It may be “way less sexy”, but it’s actually the dominant thing

- Tests for monogenic disorders or risk factors account for most standard clinical genetic tests, but most cases of chronic diseases (e.g., cancer, neurodegenerative disease) are caused instead by the *cumulative effect of multiple genes*
- In these cases, genetic testing can help generate a polygenic risk score based on the summed effects of all gene variants known to be related to a disease
- When you talk about type 2 diabetes, obesity, cardiovascular disease, or cancer in general…there are certain families that just seem to have these disease more in the family than others
- In the case of cancer being common in a particular family, many times it’s not attributable to something obvious like smoking, they don’t have Lynch syndrome where it’s really clear what the cancer pattern is, and they don’t have BRCA or something like that
- This is really where it just becomes a bit of a “death by a thousand cuts” where there are just a lot of yet to be identified or loosely identified risk alleles, and they basically start to add up
- The more of them you have, the greater your probability of developing a disease
- You can sort of think of people existing on a bell curve where there are just some people who have accumulated enough of these small risks that are polygenic in nature

![](https://peterattiamd.com/wp-content/uploads/2023/08/f2-bell-curve-ama50.png)

**Figure 2. Distribution of polygenic risk scores in a population, as determined by number of risk alleles for a given disease.** [[source](https://www.genome.gov/Health/Genomics-and-Medicine/Polygenic-risk-scores)]

- Obesity is a great example
  - We know from looking at the types of studies we talked about earlier, using monozygotic and dizygotic twins, that there are people that are more or less genetically predisposed to obesity
  - In fact, body habitus in general is highly heritable

## Is genetic testing more important for someone who doesn’t know their family history? [40:45]

*What if you have a patient who’s adopted or is estranged from their family where they really know nothing about their family history?*

*In those cases, do you treat those patients almost as they have a family history of this?*

*Are you more apt that they get genetic testing to maybe look at a BRCA mutation or Lynch syndrome because they’re really kind of flying blind?*

*How do you advise patients in those situations?*

- The thinking has evolved over several years on this
- The deeper you get into the family history, the more you can generally identify those patterns
- As a general rule, Peter doesn’t recommend broad genetic screening without a reason to do so in a person for whom he has a very good family history
- In other words, he just hasn’t seen examples of where that’s changing one’s behavior
- There are targeted genes that he looks at: Lp(a), APOE, MTHFR, etc.
- If you have somebody with zero information about their family, it makes sense to do genetic screening but most times you’ll come up with nothing particularly exciting
- Most of what you’re going to get is in the totally middle of that ground, which is indeterminate or maybe harmful, maybe not

**Peter’s overall thoughts**:

- “*But it’s very non-deterministic, and therefore we just don’t get a lot of huge insight out of it beyond that use case of, ‘Hey, we know nothing else about you, but our view is that you can take maximum action to minimize risk on diabetes, heart disease, cancer, neurodegenerative disease, screen aggressively do all of those things’*”
- “*I don’t know how the screening is going to make you back off that*”
- “*I haven’t met too many people, at least the narrow orbit that I’m in, where someone comes in and says, ‘Oh, well, my genetic test says I’m low risk for everything,’ which by the way, it never does, ‘and therefore we don’t have to do anything’*”

## What does it mean to be positive for a particular variant? [43:00]

***If someone takes a genetic test and they are “positive” for a particular variant, what does that mean?***

***That can cause anxiety with people and they’re naturally kind of thinking, “Okay, what does that mean for me? How should I think about it?”***

- It depends entirely on the gene we’re talking about
- A “positive” result just means the lab has detected a particular variant that’s associated with a particular disease or trait
- It doesn’t mean that you have it or will have it or anything like that because it heavily depends on what’s called penetrance and expressivity

**Penetrance** is the proportion of individuals with a given risk associated variant who are going to get the disease

- This can change with age, so there are certain diseases where the progression changes as you age
- If you have a variant that’s 100% penetrant, then a positive test is diagnostic
  - Familial hypercholesterolemia, Huntington’s disease, Marfan’s disease, hypertrophic cardiomyopathy
- Juxtapose that with what we think of as risk variants (which is more what we see)
- The risk variants are the other things that we’ve talked about
  - BRCA
  - APOE
  - Lp(a)
  - Mature onset diabetes of the young (MODY) which is kind of an interesting thing where we see people getting type 1 diabetes late in life
  - Again, these have various degrees of penetrance—the penetrance for certain strains of genes that result in MODY can be as high as 80% or 90%

**Expressivity** refers to the intensity of the given trait or disease for a given genotype

- You can have two people that have the exact same disease associated variant, but can show different levels of symptom severity due to other environmental or lifestyle factors
- So Marfan syndrome and sickle cell disease, which is a hemoglobin beta gene, are two diseases with complete penetrance
- If you have the gene, you get the condition, but they have *variable expressivity*
- The phenotype will exist on a spectrum of severity despite the patients having the exact same genetic mutations

![](https://peterattiamd.com/wp-content/uploads/2023/08/f3-penetrance-vs-expressivity-ama50.png)

**Figure 3. Penetrance vs. Expressivity.** Source: [MedSchoolCoach](https://www.medschoolcoach.com/dominance-penetrance-expressivity-hybrid-viability-and-gene-pool-mcat-biology/)

## What does it mean to be negative for a particular variant? [45:45]

- A negative result has to be sort of handled carefully
- A negative result means the lab didn’t find a particular variant or set of variants known to affect the condition
- But you got to remember, the lab can’t test for every possible disease causing variant in every gene
- If a single gene test reveals only wild type, meaning normal alleles at the causative gene locus, the test can rule out Mendelian disorders caused by the gene, but not more complex inheritance patterns
- For example, even if a gene of interest is normal, a disease may still arise due to environmental or lifestyle factors or the influence of other genes
- Labs only test for variants that have already been documented and researched and have shown clear links to a disease
- And often they’re limited to only one or two variants associated with the highest risk and it’s possible that new or previously undocumented variants can also increase risk

**Why genetic testing isn’t the “end-all be-all”**

> “That’s part of the reason why I just don’t think genetic testing is the be-all, end-all, because at the end of the day, it’s not changing your behavior.” —Peter Attia

- Most genetic test results are changing someone’s behaviors
  - There are lots of examples where it does, but for the majority of people getting a “negative” genetic test would not mean that Peter would suggest backing off important behavioral or pharmaceutical interventions
  - And a “positive” result is a very murky thing in many of the cases

A couple examples of blind spots in testing where you end up with a “negative” result

- BRCA testing
  - BRCA testing only looks at the most common mutations in BRCA1 and BRCA2 genes, but there’s over 20,000 unique mutations that have been documented in those genes
  - Now it’s not clear which of those increase the risk of breast cancer, to what extent they do so, which ones have no bearing
  - But the point is you can test “negative” for BRCA1, BRCA2, and still be genetically predisposed to breast cancer even through BRCA mutations that are not otherwise documented there.
- APOE testing
  - About 75% of the population does not have an APOE4 gene, but they can still get Alzheimer’s disease
  - So yeah, you’re negative for APOE4. But does that mean you’re free and clear? ⇒ Not necessarily
  - Just as having APOE4 doesn’t mean you’re going to get it, it just increases your risk

## How does someone get genetic testing through their healthcare provider, and how are these tests performed? [48:15]

**Genetic counselors**

- It’s Peter’s preference to basically utilize **genetic counselors** for genetic testing that goes beyond our scope of understanding
- There are certain alleles that Peter is comfortable testing for because he really understands what’s going on—cardiovascular disease, APOE, things of that nature
- But once you start getting patients who show up who have really odd histories of cancer in their family and you suspect that there’s something genetic going on, that’s when Peter typically will refer to a genetic counselor
- These are people who are just far more specialized—they’ll know which test to order, they’ll have a much better sense of how to interpret the results than we will
- Peter wants to be a part of that process to learn what’s being done and understand and provide other insights, but he’s not going to be leading that due to his lack of expertise

**OTC tests**

- Peter says he’s “fond” of the OTC genetic test but they come with a real risk on the genetic side in that if you’re not doing it with somebody who kind of understands what the implications are, it can produce a lot of confusion
- So when doing OTC genetic testing, it’s at least a discussion worth having with your doctor

What if someone is going to go to their doctor and brings up this idea of, “*Hey, can you refer me to a genetics counselor?*”

- Is that the best way to recommend to do that to just provide some of that family history information and just say, “Hey, we have some questions here that I would love to know more about. I know it’s a really complex issue,” would you be willing to provide a referral?
- Yeah, if that’s the use case, answers Peter
- The other use case is in people who want to conceive, who want to do a different type of genetic counseling, which is prenatal
- Those would be two great ways to sort of say, “*Hey, I want to go about doing this thing. Who do you recommend?*“

***And how are these tests performed? [48:30]***

- Genetic tests are performed on a sample of tissue: a drop of blood, a hair, a cheek swab, amniotic fluid if you’re testing for genetics on a fetus
- The tissue is then sent to a laboratory and the technicians can use various methods to sequence the DNA
- You’ll either sequence the DNA or you’ll probe for particular gene variant
- The lab usually reports the results to the physician or genetic counselor who ordered the test, and then they’ll typically discuss them with you
- (But again, there are a lot of these that are over the counter where they come to you)

**How this is done**:

- Whether you’re looking at a specific gene variant or you’re sequencing the entire genome, genetic testing relies on a technique known as the polymerase chain reaction (PCR)
  - There’s a awesome book written by [Kary Mullis](https://en.wikipedia.org/wiki/Kary_Mullis), the guy who developed PCR, and it’s called [Dancing Naked in the Mind Field](https://www.amazon.com/Dancing-Naked-Mind-Field-Mullis/dp/0679774009)
- Briefly, this process involves separating the two strands of the DNA molecule and using short DNA fragments called “primers” that recognize and bind to a specific segment on each strand of the DNA to be sequenced.
- An enzyme called DNA polymerase can then construct the rest of the complementary DNA strand. The process is repeated over several cycles such that the DNA segment of interest is amplified exponentially.
- This process creates millions of copies which can then be genotyped with DNA probes/microarrays or sequenced and aligned with a reference genome.

![](https://peterattiamd.com/wp-content/uploads/2023/08/f4.-PCR-ama50-1024x579.png)

**Figure 4. PCR.** Source: [National Human Genome Research Institute](https://www.genome.gov/genetics-glossary/Polymerase-Chain-Reaction)

NOTE: The difference between genotyping and sequencing

- Genotyping determines whether certain genetic variants are present and usually involves probes, which combine to the variant of interest
- For example, when we’re doing a genetic test on our patient to look for APOE, it’s genotyping
  - We know what we’re looking for and we go and look for it
  - it’s fast, it’s cheap, but it’s only looking for the presence or absence of the variants of interest
  - They have to be pre-selected for this to work because you have the corresponding probes that have to be pre-made, et cetera
- Sequencing, on the other hand, provides the full DNA sequence for a given DNA segment
  - This can be accompanied against a reference sequence to identified known variants regardless of rarity or significance
  - But it can also look at de novo mutation
  - So this is way slower and way more expensive than genotyping, but obviously provides much more information
    - Remember the caveat earlier, a lot of that information means we don’t know what it means yet.

## The financial cost of various genetic tests [54:30]

*What’s even the range that someone would have to spend to get one of these tests done?*

- It depends on what you’re doing
- Looking for one gene, if you’re doing a targeted look, it can be $10 or something like that
- It sort of varies from tens of dollars to a couple thousand dollars
- Whole genome sequencing is the most expensive test, but that has come down significantly
- The cost the very first time the human genome was sequenced in 1999 or 2000, it’s reported to have cost $300 million the first time the human genome was sequenced
- That cost is today can be less than a thousand dollars

![](https://peterattiamd.com/wp-content/uploads/2023/08/f5-moores-law-ama50-1024x562.png)

**Figure 5. Cost per Human Genome Over Time.** Source: [National Human Genome Research Institute](https://www.genome.gov/about-genomics/fact-sheets/Sequencing-Human-Genome-cost)

- If you look at this graph, notice the line for Moore’s Law
- Let’s just say it’s starting at 100 million (So it’s not even the very first sequence)
- This thing went down from $100 million to $10 million in about five years
- Then look at what happens between about 2006, 2007 and 2011—you now fall way, way, way faster than Moore’s Law
- We are sort of back to Moore’s law right now, but we had that huge drop in cost in basically between ’07 and ’11
- The word step function is used a bit loosely here, but that’s about as big an example of a step function as you’re ever going to see, where the cost goes from 10 million to $10,000
- That’s attributable to what’s called “next-generation” sequencing, also known as massively parallel sequencing that was introduced for commercial use in ’05 and earlier methods
- It allows for sequencing of millions of strands of DNA in parallel instead of just one
- And that’s really completely changed the game and you could also argue biotechnology has changed as a result of that

## Could having a risk allele for a disease result in an increase in one’s insurance premium? [57:15]

*If I do my genetic testing and I find out I have a risk for a disease, can my insurance company raise my premium?*

*Are there issues with life insurance?*

*Is there anything on that angle that people should be aware of before doing this?*

- Yeah, very important question
- So there is something called the Genetic Information or Nondiscrimination Act ([GINA](https://www.genome.gov/about-genomics/policy-issues/Genetic-Discrimination))
  - It’s a federal law which prohibits genetic discrimination by health insurance companies or employers because remember, you’re either covered by your employer through a company or the insurance company themselves
- But there are a couple of exceptions:
  - In general, what GINA says is, “No, your health insurance company cannot discriminate against you regardless of what is discovered”
  - But if you work at a company of 15 or fewer employees, they can—presumably the reason there is a company that is that small can’t afford it
- But the more important point is that other forms of insurance that are not health insurance, but life insurance, disability insurance, long-term care insurance, those are absolutely permitted to adjust your premium

> “*So this is a bit of a buyer beware thing, which is maybe this is another reason not to just go out willy-nilly in getting genetic testing at least until you have these other affairs in order*.” —Peter Attia

## Other risks associated with genetic testing [59:00]

**Other risks**

- The emotional risks can be significant, not unlike what we talk about when we talk about the risks of cancer screening
  - Cancer screening has a financial risk
  - In some cases, such as the case of a colonoscopy, there’s even a physical risk of the procedure
- But far in away the greatest risk here is the emotional toll this stuff can take on you

> “*With how much uncertainty there is in genetic testing, I just think everybody needs to be thoughtful about it before they do it*.” —Peter Attia

- Peter likes to believe that the more he knows, the more he can do and the more he can act to circumvent
- Peter actually HAS done a whole genome sequence on himself but it was only because of an issue that had to do with the health of one of his kids — if not for that, he would NOT have done a WGS on himself
- This might be surprising for people to hear since Peter loves information
  - E.g., DEXA scans – [AMA #44](https://peterattiamd.com/ama44/)
- So for Peter to say this level of information is something he would not be interested in for himself, that kind of puts it into perspective
- To be clear, Peter thinks certain targeted genes do make sense (e.g., APOE)
- Peter is also fortunate enough to know my family history
- He also knows what is and what isn’t a risk factor so he knows what he doesn’t need to probe for
- He hasn’t tested for Huntington’s disease, for instance, because his parents are alive in their 70s and 80s without Huntington’s disease, so he clearly won’t have it

“*I don’t want to create any sort of blanket statements around this. I just want people to be very thoughtful about this, which is of course why we’re sitting down and doing this*.” says Peter

## How do commercial, direct-to-consumer genetic tests compare to the information one might receive from clinical genetic testing? [1:01:45]

***We’ve talked about clinical genetic testing as well as the direct to consumer genetic testing, how do those two compare to each other?***

The direct-to-consumer tests (aka commercial test, aka OTC)

- These tend to evaluate certain risk variants for disease, but the number of variants that’s tested is often limited
- The accuracy also tends to be a little bit lower than in clinical labs
- Most of these DTC tests are intended for entertainment, for identifying family genetic relationships, but they can also offer really potentially meaningful information as well
- That said, Peter’s view is a bit of “buyer beware”
- You wouldn’t want to do these without knowing that you could call somebody if something came up that you were concerned with—so you want to be thoughtful about, “How do I interpret this?”
- One of Peter’s biggest frustrations with most DTC tests is the lack of services available to help explain what’s going on
- So these DTC tests can produce anxiety with the findings so you should think about having a doctor help interpret the results

**Privacy**

- Another important distinction that people need to think about is the level of privacy
- Clinical tests, for instance, are subject to [HIPAA](https://en.wikipedia.org/wiki/Health_Insurance_Portability_and_Accountability_Act)
- HIPAA is basically “God of all things” that pertain to privacy and data sharing policies
- Some of the DTC providers have voluntarily subjected themselves to adhere to HIPAA guidelines
  - But companies will give you a chance to opt out of data sharing for research or other purposes so you should read the privacy policies of these things really closely (don’t skip over the fine print)

## Are certain direct-to-consumer tests better than others? [1:03:45]

**The most common question(s) from listeners is**: *Which test should I do? Are there certain direct to consumer tests that are “better” than others?*

- It would be difficult to just sort of rank them in an absolute term
- Better way would be to talk about the big five or six of them, show the basic parameters, how are they similar, how are they different or how do they compare to each other, some pros and cons, etc.

![](https://peterattiamd.com/wp-content/uploads/2023/08/f6-DNA-Test-Comparison-ama50.png)

**Figure 6. DNA Test Comparison.** Source: Internal Analysis

***Taking a look at cost***

- [23andMe](https://www.23andme.com/): $200 for 650,000 SNPs
- [Inside Tracker](https://www.insidetracker.com/): $250 bucks and only giving you 261 SNPs
- [Nebula Genomics](https://nebula.org/whole-genome-sequencing-dna-test/): Range from $100 to $1,000, you could wait 12 weeks, but you’ll get the whole genome sequence
- [SelfDecode](https://selfdecode.com/): $200-300 will give you 83 million SNPs
- [Sequencing.com](https://sequencing.com/): $400 and you get the whole genome sequence (that’s quite inexpensive)
- [Toolbox Genomics](https://www.toolboxgenomics.com/): $200-300 for 1000 SNPs
- But just to be clear, all the costs that we’re listing here are just the cost of the DNA testing kit as a one-time payment of the analysis, but it doesn’t include a lot of the other stuff that typically gets bolted onto this, such as subscriptions, uploading DNA data for evaluation in other arenas, etc.

*What is Peter’s broad recommendation here?*

- If Peter was forced to give a recommendation considering cost, privacy, quality, and amount of information given… he’d probably say:
  - [SelfDecode](https://selfdecode.com/) and [Toolbox Genomics](https://www.toolboxgenomics.com/) are probably the best ones
- He just doesn’t think the whole genome sequencing is worth it right now at the cost
  - The data you get with the whole genome sequence can overwhelm you and produce some anxiety
  - Additionally, we don’t even know what every SNP or gene does in the small fraction of coding, let alone what’s going on in that 98.5% of DNA that doesn’t code for protein and it’s going to be decades before we do
  - “*That doesn’t mean at one point in the future it won’t make sense for everybody to have a whole genome sequence, but you’re not missing anything by not doing it today*.” says Peter

**23andMe**

- Well-known company that’s probably been around the longest
- Pros:
  - Relatively large number of SNPs tested
  - They don’t report on how many of these are being analyzed for health information as opposed to ancestry, but research is continuously revealing previously unknown associations between SNPs and other health conditions
  - Covers a pretty wide variety of health and wellness areas—typically more than 150 reports on carrier tests and things of that nature
  - Very good user interface and information’s pretty easy to find
  - It’s the only FDA-approved at-home test
- Cons
  - One of the knocks on this is that it requires a premium subscription for access to all reports
  - And some have definitely raised concerns over their privacy policy, but again, you can mitigate some of those things

**InsideTracker**

- Pros
  - Allows uploads of DNA data from a few leading competitor companies
  - Easy user platform
  - Also offers blood tests for lipids and other biomarkers of disease risk
- Cons
  - Very few SNPs tested. This company’s emphasis is not its DNA tests, but rather its tests for blood-based biomarkers for disease risk, which are sold separately.
  - Only provides health recommendations based on blood tests, not DNA tests

**Nebula Genomics**

- Pros
  - Provides whole-genome sequencing, which in the future might provide more valuable health information without the need for retesting
  - Strong emphasis on privacy
- Cons
  - Cost of individual kits is high, and a subscription is required
  - Despite doing WGS, they provide only marginally more (~200) reports on specific traits/diseases than companies relying on DNA genotyping
  - Reports are often criticized for using jargon and being incomprehensible for non-scientists
  - No personalized health recommendations

*\*Side note about sequencing depth*:

- Sequencing depth is the number of times that a given nucleotide is red during the sequencing. So the higher the number, the more certainty we have the base pair that was detected is the correct one
- So for a whole genome sequence, the goal is broad picture of health rather than diagnostic testing
- So 100X depth is really deep and excessively costly
- The clinical standard for whole genome sequencing is like 30X
- And going from 30X to 100X isn’t really needed for an exploration
- If you look at the *pricing for Nebula*:
  - they offer a 0.4X, which is like dirt cheap, a 30X and 100X
  - If you want to do that for a whole genome sequence, Peter says to **select the middle option, which is the 30X**

**SelfDecode**

- Pros
  - Very large number of SNPs tested
  - Note: unlike most companies, SelfDecode uses imputation (i.e., using statistical analysis of haplotypes – areas of the genome that tend to be inherited as whole chunks), so most SNPs are inferred rather than directly observed, but the method is still highly accurate (99.7%)
  - Allows uploads of DNA data from a few leading competitor companies
  - Very strong privacy policy: a HIPAA-compliant genetic testing company that allows you to permanently delete your data at any time
  - Health recommendations based on results include estimates of the predicted impact of a given recommendation and the amount of evidence supporting it
  - Offers 1:1 consultations with health coaches to aid in interpreting results (for a fee)
  - Results reports include a summary of both the
- Cons
  - Requires an annual or lifetime subscription to access results reports
  - Tests not available in all states (unavailable in Arizona, New Jersey, New York, and Rhode Island)
  - Health coach consultations are not available with uploads of DNA data from competitors

**Sequencing.com**

- Pros
  - Provides whole-genome sequencing, which in the future might provide more valuable health information without the need for retesting
  - Allows free uploads of DNA test results from most other companies
  - Very strong privacy policy: a HIPAA-compliant genetic testing company that allows you to permanently delete your data at any time
- Cons
  - The basic package is sequencing only. Most reports on specific traits or diseases require a subscription or additional fees, which are often expensive (from free up to ~$200)
  - Many of the tests for specific traits/diseases involve third-party test facilities and apps, which may not have such strict privacy policies as Sequencing.com

**Toolbox Genomics**

- Pros
  - Also offers epigenetic testing
    - Epigenetic is not a change to the coding segment of the gene. It’s a methylation that goes on the backbone of the DNA and it certainly impacts gene expression
  - Easy-to-follow summary reports, as well as more detailed data appendices for practitioners
  - Personalized health recommendations based on results and adjusted based on follow-up epigenetic tests
  - Though most companies offer “personalized” health recommendations, most are in fact quite generic (e.g., exercise to prevent heart disease). Toolbox has the advantage of feedback and revision based on repeated epigenetic tests.
- Cons
  - Some of the health scores/metrics reported (especially those based on epigenetic data) are based on shaky and debated science (e.g., “biological age,” “memory age,” and “inflammation status” based on methylation status)
  - To receive updates to health recommendations based on epigenetics, tests must be repeated regularly (they recommend every 3 months).

[**Promethease**](https://promethease.com/)

- This is an online genetic analysis tool rather than a testing service, but it accepts DNA test data from other services
- This is something Peter will do in his practice—if a patient shows up with genetic testing results, he will usually import all that data into Prometheus
- Basically put your 23andMe data/Toolbox Genomics data/ or your whole genome data into it and you can then look at kind of a filtered set of data
- It allows you to evaluate DNA data for associations with specific traits and medical conditions and filter by the magnitude of the alleged effect, the number of research publications reporting an association, the allele frequency, and ethnicity of the reference populations

*How to use it:*

- Peter pulled up Prometheus on his computer to give listeners a sense of what he does with it
- He will first look at results with a negative connotation
  - Then he filters for magnitude:
    - He’s going to raise the magnitude threshold to 1.5 to 2 or something like that, maybe 1.8
  - Filter for publications:
    - It ranges from zero to 127 on this particular set Peter is viewing so he’s going to set it at 10—he wants to see at least 10 publications before he pays attention.
  - Filter for Frequency: He wants to look at something that has a frequency of more than 10 to 20.
  - Looking at the filtered data now:
    - This sample report now says, “You have 2X the risk of Alzheimer’s disease. You carry one copy of E3, one copy of E4.”
      - That comes with a bad magnitude of 3.5
      - It has lots of publications on that
    - But then there are some other things in here that “kind of ridiculous”, for instance, the “lack empathy” SNP which is rs53576
      - Magnitude 2.8
      - 53 publications on this
      - It’s a silencing of a G to an A in the oxytocin receptor
      - Kind of interesting, but it’s not really going to change anything you do
    - Diabetes risk: Here’s another one that’s a magnitude 2.7 that increases your risk of gestational diabetes or type 2 diabetes
  - Peter will typically go through the same exercise on the good side
    - The first thing that pops up is a magnitude 2.1
    - If you have this gene, you’ve got a 60% reduction in HIV viral load
- In short, if you do a genetic test, Peter thinks it’s worth the extra cost to analyze your data on the Prometheus website (but still recommends talking with a doctor about your results)

## How long until whole genome sequencing becomes genuinely useful? [1:16:00]

**Whole genome sequencing**

We looked at the cost and how that has dramatically decreased in the past 25 years

But it seems like it’s still not quite at the place where even cost aside we know exactly what to do with the results

*How long until WGS is actually very useful? Is that 5 years, 10 years, 20 years more away?*

- There were kind of two issues or questions that are embedded in that question
- The first is, how deterministic is the genome?
  - Meaning the entire genome, so not just the coding region—So those billions of base pairs that we have, how deterministic are they in terms of what matters to our healthspan and lifespan?
    - We don’t know the answer to that question yet
    - If you believe the answer is very much, i.e. much more than we believe it is today, then the answer is in 10 years this looks a lot more interesting
    - Because in the next 10 years, in terms of computing power and AI, we’re going to learn a lot more.
    - But it’s possible that we’re here in 10 years and despite all of the computing power that we have, the biology is still such that the environment makes a bigger impact on expression
    - And knowing more about that increases our understanding of our interaction with the environment a little bit more, but not necessarily so much.

One example:

- Right now we don’t have any meaningful way to do a genetic test and impute dietary wisdom about a person
- The question is: Is it not there yet because the biology isn’t correct or is it not there yet because the biology is correct but we haven’t explored or probed deep enough?

## How useful are personalized dietary recommendations based on genetics? [1:18:15]

***How do you think about these genetic based personalized diets that are kind of making their way out there more and more?***

- Theoretically, it should make sense that you could look at a person’s genome and make some dietary recommendations
- To some extent you can, for example, we know that certain variants in CYP1A2 bear on caffeine metabolism
  - So we know that there are fast and slow metabolizers of caffeine and we know that that has a bearing on how much coffee you should have or when you should have it
  - This is a great example of a win
  - You could also argue you didn’t need a genetic test to tell you that—people have known forever if caffeine has a strong or low impact on them
- So when you look at the companies that are out there kind of doing personalized nutrition based on genes, Peter just wonders: *Did you need the genetic test to tell you that or would you have known by all the other metrics that one would typically use to determine the efficacy of meals and nutrition?*
- Peter is just skeptical that genetic testing can add much value to nutritional guidance in its current state

## Final thoughts and advice regarding genetic testing [1:20:00]

*Any last piece of advice you would have for people as they just listen to all this?*

*Maybe they’re thinking about genetic testing, whether they’ve done it before, whether they should do it again?*

*Any last piece of advice or wrap up you would give people?*

- Peter says “definitely don’t think they should do it again [if they’ve done it before]…the good news is once you’ve done it, you’ve done it”
- Having a really good family history matters a lot for the stuff that we care about, which is often polygenic

Regarding the prenatal family planning stuff:

- That type of genetic testing can be really important, especially by the way, as people are getting older and older when they conceive
- You’re seeing more and more aneuploidy, meaning irregular chromosomal splitting, and therefore as people get older and older, that makes a ton of sense

Overall:

- Peter wouldn’t value broad genetic testing (i.e., WGS) at the level that he would value some of the other types of testing that he does when thinking about risk assessment
- “*Some of the targeted gene stuff is [genuinely useful], but just doing a shotgun sequence to know all sorts of susceptibilities, like your likelihood of being more empathetic or not. . .I just don’t see the value in a lot of this stuff.*”

§

## Selected Links / Related Material

**AMA episode of The Drive that touched on genetic testing**: [#67 – AMA #8: DNA tests, longevity genes, metformin, fasting markers, salt, inflammation, and more](https://peterattiamd.com/ama08/) | Peter Attia (peterattiamd.com) [2:30]

**Study looking at the heritability of schizophrenia using twins**:  [Heritability of Schizophrenia and Schizophrenia Spectrum Based on the Nationwide Danish Twin Register](https://www.sciencedirect.com/science/article/abs/pii/S0006322317319054) (Hilker et al., 2017) [20:45]

**Episode of The Drive where familial hypercholesterolemia was discussed**: [#255 ‒ Latest therapeutics in CVD, APOE’s role in Alzheimer’s disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.](https://peterattiamd.com/johnkastelein/) | Peter Attia (peterattiamd.com) [27:15]

**Peter mentions he wrote about his friend with Lynch syndrome in his book**: [OUTLIVE: The Science & Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia | (peterattiamd.com) [28:30]

**Book written by the man who invented PCR**: [Dancing Naked in the Mind Field](https://www.amazon.com/Dancing-Naked-Mind-Field-Mullis/dp/0679774009) by Kary Mullis | (amazon.com) [51:30]

**AMA episode of The Drive where Peter goes through his historical DEXA scans**: [#242 – AMA #44: Peter’s historical changes in body composition with his evolving dietary, fasting, and training protocols](https://peterattiamd.com/ama44/) | Peter Attia (peterattiamd.com) [1:00:30]

**The online tool Peter recommends for deciphering the results of a genetic test**: [Promethease](https://promethease.com/) | (promethease.com) [1:13:15]

§

## People Mentioned

- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [2:30]
- [Kathryn Birkenbach](https://www.linkedin.com/in/kathryn-birkenbach-03563315/) [15:45]
- [John Kastelein](https://twitter.com/JohnKastelein) [27:15]
- [Kary Mullis](https://en.wikipedia.org/wiki/Kary_Mullis) [51:30]

§