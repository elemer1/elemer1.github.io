# Special episode with Dax Shepard: F1 and the 30th anniversary of Ayrton Senna’s death

**Source:** [https://peterattiamd.com/daxshepard/](https://peterattiamd.com/daxshepard/)

---

This is a special episode of The Drive with Peter’s friend and fellow car enthusiast Dax Shepard. In this podcast, which commemorates the 30th anniversary of the death of Brazilian Formula One legend Ayrton Senna, Dax sits down with Peter to better understand what made Senna so special and why Peter remains an enormous fan. This conversation focuses on Senna’s life, the circumstances of his death, and his lasting impact and legacy on the sport of F1.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/daxshepard/the_Drive_public.png)

Play

Special episode with Dax Shepard: F1 and the 30th anniversary of Ayrton Senna's death

Special episode with Dax Shepard: F1 and the 30th anniversary of Ayrton Senna's death

1x15s30s

0:002:28:38

## We discuss:

- Peter’s interest in motorsports began as a child [2:30];
- The drama and dangers of F1 [6:00];
- What made Senna special [13:00];
- What Senna meant to Brazilians [24:00];
- The cause of the fatal crash [28:15];
- Why Peter is obsessed with Senna [40:30];
- Being the best versus having the best record [43:30];
- Senna’s unique driving style and incredible intuition about automotive engineering [46:30];
- Back to the day of the dreadful race [53:00];
- What Peter believes caused the crash [1:02:45];
- Views on dying young, in the prime of life [1:13:00;
- Senna lives on in his foundation and in safety changes adopted by F1 [1:21:00];
- Statistics aren’t enough for fandom, and why people like who they do [1:24:15];
- The biggest difference between F1 today and F1 in the 80s [1:28:30];
- Senna’s driving superpower [1:30:30];
- The fastest drivers currently in F1 [1:38:30];
- Current F1 obsessions [1:45:00];
- How hard it is to do what the top F1 drivers do [1:50:15];
- Dax’s love of motorcycles and his AMG E63 station wagon [1:52:15];
- Awesome Senna mementos from Etsy [2:01:15];
- What makes Specialists interesting, and Max’s devotion to F1 [2:10:15];
- What Senna might have done if he had not died that day [2:14:00];
- Michael Schumacher and Max Verstappen are also top F1 drivers [2:17:30];
- Interlagos in Sao Paulo Brazil is always an incredible experience [2:18:45]; and
- More.

[fusebox\_full\_player social\_twitter=”true” social\_facebook=”true” social\_linkedin=”true” social\_pinterest=”true” social\_email=”true” ]

§

## Show Notes

\***Notes from intro**:

- Welcome to a bonus episode of *The Drive* with Dax Shepard, Peter’s friend and fellow car enthusiast
- The purpose of this podcast is to commemorate the 30th anniversary of [Ayrton Senna’s](https://en.wikipedia.org/wiki/Ayrton_Senna) death, May 1st, 1994
- Dax was not a fan of [F1](https://en.wikipedia.org/wiki/Formula_One) at the time of Senna’s death, but in the last 5-6 years he’s become a fan of F1
- Dax has a fascination with Peter’s obsession with Senna, and he want to sit down with Peter to better understand why he remains an enormous fan of Senna all these years after his death
- This episode focuses on a lot of things that have to do with F1 racing, some of it in the modern era
- But it mostly focuses on Senna’s life, his death, the circumstances of his death, and his lasting impact and legacy on the sport

## Peter’s interest in motorsports began as a child [2:30]

- Growing up in Canada, IndyCar was incredibly popular and F1 was incredibly popular
- You have Montreal for F1
- You always had the IndyCar in Toronto race
- And because Peter’s dad was in the restaurant business, he was buying beer by the truckload and Molson was the beer in Canada, and they would give you tickets
  - They went to races
- When Peter came of age in the 80s he was really into cars
  - He had posters of cars and boxers on his wall
- Dax was also obsessed with cars, but never overly obsessed with racing
- He would go to Belle Isle to see Indy car because his family worked in the automotive business
  - There was not RV coverage, and you just got to watch the profile of a car for 1/10th of a second
    - He couldn’t buy in
- Today F1 is one of the sports that is infinitely better on television, from a total experience in terms of understanding what’s going on
- That said, Peter probably goes to 3 races a year
- The sound though is nowhere near as good in the 80s
  - Once the  hybrid era cam in 2014
- Dax is late to the F1 obsession
- The first racing he loved was MotoGP 20 years ago

## The drama and dangers of F1 [6:00]

- Max is a [*Drive to Survive*](https://en.wikipedia.org/wiki/Formula_1:_Drive_to_Survive) convert
  - Peter loves it
- Dax loves finding out about how relevant the aerodynamics are and how high-tech it is
- The show does a great job shing the drama that exists between 14th and 8th place
  - How important it is that these teams finish in the points or to get one point
- The [Max/ Lewis season of 2021 was exceptional](https://en.wikipedia.org/wiki/Formula_1:_Drive_to_Survive_season_4)
- The last 2 episodes of the [prior season](https://en.wikipedia.org/wiki/Formula_1:_Drive_to_Survive_season_3) were 2 of the finest: “Man on Fire” & “Guenther’s Choice”

***This highlighted: when you’re watching a sport like F1 or MotoGP or anything for that matter, there is a real chance a person could die, and it’s really frightening when you see some of these accidents***

- Dax points out they’re going 205 mph
- There was a day when most of these accidents were fatal
  - Until the early 80s 2-4 F1 drivers died a year
- Dax and Peter have been talking all week about the many thing that have changed so dramatically
- They’re both watching the series [*Turning Point*](https://www.imdb.com/title/tt26227818/?ref_=fn_al_tt_1)
  - To learn that in 1 night of bombing of Tokyo, 87,000 people died
    - That’s more than all of Vietnam, by a factor of 30,000
- We don’t have the appetite for any of that stuff anymore
- Peter started watching F1 religiously in the late 80s when he was a kid, but his obsession was much more boxing
- F1 would come on on bizarre hours
- When he got into med school and became friend switch [Paul Conti](https://drpaulconti.com/), and they immediately connected over their shared obsession for F1 and for Senna

***The late 80s-early 90s was the golden era of F1, there was an insane depth of talent***

- You had Niki Lauda at the end of his career, still winning a championship in the mid 80s. And then the arrival of Alain Prost, Nigel Mansell, of course, Nelson Piquet and Senna
- Dax walked through [McLaren](https://www.mclaren.com/racing/formula-1/) through the boulevard and noted how small the F1 cars are (like Go-Karts)
- They were 500 kilo cars back then but could still make >1000 hp

## What made Senna special [13:00]

**His qualifying is remarkable**

- By today’s standards, Senna wasn’t around very long ‒  he died in his 161st race
  - [Max](https://en.wikipedia.org/wiki/Max_Verstappen) is only 26 years old and he’s long past that number of races
  - [Lewis](https://en.wikipedia.org/wiki/Lewis_Hamilton) is at more than 2 X that number of races

***Senna’s qualifying percentage to how many times he was on*** [***pole position***](https://en.wikipedia.org/wiki/Pole_position) ***‒ nobody’s within a country mile***

- 65 poles in 161 races

**He won 3 titles (technically 4)**

- Peter will explain later why he had one stolen from him

*Looking at other titles, it begs the question: why is everyone so obsessed with him?*

- He only raced for 10 years
- The 65 pole stat says a lot
- Dax explains, “*This is another thing I’ve come to love about F1 is P1 in qualifying to P20 is often three tenths of a second*… *and within the top five, the first three are often in the hundreds of seconds.*”
  - The margin is so unfathomable

**One of the most epic, legendary stories of Senna: qualifying for the 1988 Monaco race**

- Senna is the rookie on the team
- The car (the [MP4/4](https://en.wikipedia.org/wiki/McLaren_MP4/4)) is still to this day regarded as the greatest car ever in F1

![](https://peterattiamd.com/wp-content/uploads/2024/04/f1-daxshepard.png)

**Figure 1. The McLaren-Honda MP4/4 F1 car**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/McLaren_MP4/4)

- That car won 15 of 16 races between Senna and [Prost](https://en.wikipedia.org/wiki/Alain_Prost)
  - The time it didn’t win; Senna got taken out by a back marker
  - The closest we’ve seen to that is last year’s [Red Bull](https://en.wikipedia.org/wiki/Red_Bull_Racing#), which won all but one race
- Prost is the 2-time world champion, the reigning world champion
- They’re at Monaco, which is generally regarded as the most difficult circuit
  - The margin for error is non-existent
  - Senna has won Monaco 6x
- You’ve got a field of world champions in superior cars in front of him as a rookie
  - His F1 rookie year, 1984, he’s in the Toleman
- He’s driving a garbage truck back there, but it starts raining cats and dogs
- ⅔ through the race, he is closing in on Alain Prost
- And in the final lap of what would become the final lap, he passes him
- But race stewards decide to halt the race at the preceding lap
- He is still awarded second place, which is unfathomable as his first podium
- Dax points out, “*The first major fucking he receives from the FIA*”
- We should add that Monaco is the hardest track to pass on in the whole calendar
  - Today it’s impossible to pass on
  - Back in the day, cars were smaller
- To this day, Monaco is still one of the most exciting qualifying, because the stakes are so high

**1988, Senna not only qualifies on pole, something he would do repeatedly, he does so by a margin that is deemed impossible to comprehend**

- His teammate is arguable arguably one of the greatest drivers of all time, [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost), driving the same car, and he out qualifies him by 1.47 seconds
- Senna was already on pole when he decided he wanted to go out and do one more lap
  - It’s the stuff of F1 lore because the lap was not captured on camera
  - All you have is the time sheet
- He was out of this world
- The next day in the race, he is leading by so much that the team is telling him to slow down
- There might’ve been 8 laps to go, and he’s ahead by 30 seconds
  - Dax recently rewatched the thing and that the point he crashed, he was 56 seconds ahead of Prost
- Senna lost concentration for a nanosecond, a very rare event in his life, and crashed
- He’s so angry that he literally got out of the car, through his stuff and went to his apartment

**The cars in that era ran a much higher horsepower during qualifying**

- They dialed them way up in a way that they don’t do today
- Today you’re playing with tires, fuel load, and battery pack
- You couldn’t race at that horsepower because you didn’t have the reliability (it was too dangerous)
  - They’re in the 12-1400 hp range
- These are naturally aspirated V10s, V12s
  - The compression must have been ear-splitting
- Dax summarizes the elements that bolster people’s fascination with Senna, “*There’s the record, there’s the dying early, that’s very James Dean… For me, I like him because he seemed like an outsider. The Brazilianess of it all makes me like him more. But also… he’s very sexy*.”

**After Senna’s death, Peter learned much more about him**

- He died in 1994 when Peter was in college
  - He didn’t have an internet to read more about it
- Much of what Peter knows about him today is based on things he can read today
- He’s met Senna’s family and knows his niece

## What Senna meant to Brazilians [24:00]

- An example of this is when a person from Brazil discovers that Peter named his son Ayrton after Senna, everything changes
  - Come into my house for food
- For someone in Brazil, if you’re over the age of 35 today, you take JFK, 9-11, the Challenger
  - That’s what May 1st, 1994 was
- The entire country, every Sunday would stop to watch this
  - It’s not like the NFL here where a lot of people watch it

**Japan is a close second**

- All 3 of his titles were in Honda powered cars, and the engineers at Honda loved him

**Dax asks, “*****how did their salaries back then compare to current salaries?*****”**

- When you adjust for inflation, if you were at the very, very top ‒ Senna was making a million dollars a race
  - Doing 16 races a year
- [Max](https://en.wikipedia.org/wiki/Max_Verstappen) is the highest paid guy in F1 today, and he’s making 50 million euros

**Dax imagines there’s some archetype about Senna that Peter likes beyond the racing**

*Is it the outsider-ness?*

- He was flawed
- He’s not a perfect perfect person, nor did he try to represent himself as that
- He could be overly emotional

## The cause of the fatal crash [28:15]

**Peter doesn’t believe his fatal crash resulted from the steering column failure**

- Which is the most commonly held view of his death
- For many years after the crash, Peter believed that he he died because the steering column failed
- What actually killed him is not in dispute: an aileron, a piece on the suspension that came off

*But why did he crash to begin with?*

- The conventional view is that the steering column failed

*The horrible circumstances of the weekend of Senna’s death*

- April 29th, April 30th, and May 1st 1994: he was in a race called [Imola](https://en.wikipedia.org/wiki/Imola_Circuit)
- On that Friday during the first practice, another Brazilian driver ([Rubens Barrichello](https://en.wikipedia.org/wiki/Rubens_Barrichello)) has a brutal crash
  - What’s amazing is he was only concussed and split open, but actually survived
  - Senna was shaken up
    - This was a kid he was mentoring
- The next day, an Austrian rookie ([Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger)) who Senna also had taken under his wing was killed in practice
  - This was the first death in F1 in 12 years
- The race should have been canceled after Roland’s death
- Roland died on the track, but the organizers of the race wanted the race to go on, so they airlifted him out of there to pronounce him dead at a hospital
- They were doing cardiac massage on him at the track
- Senna, against the instructions of the marshals, got into a car, drove to where he died, and was reprimanded terribly for doing so
- Senna’s trainer Josef Leberer told Peter that he’d never seen Senna more angry in the entire time he knew him than that evening because of how pissed he was at how the marshals had been so angry at him for going to see Roland at the site of the accident
- Dax adds, “*Which is a pattern of his right? He also had gone out on P1 and stood where that had happened. And that’s kind of a thing he did, right?*”

> “*This is the thing about Senna that’s also kind of an interesting paradox. On the one hand, he was the most competitive… and yet he would be the first person to stop and rescue you, and help you if you were hurt*.”‒ Peter Attia

- At times he did things where he literally put other drivers and his own lives in danger out of pure competitive drive

**Other details about the circumstances of that weekend**

- This is race #3 of the season
- Senna hates his car
  - He had gone to Williams thinking he was going to get the electronically adjusted suspension
  - Senna in 1980 arrives at McLaren, and he’s driving for the best team
  - Senna was only in the best car 4 out of the 10 years he raced (‘88-91)
    - You always have to look at how many years was a driver in the best car

*There’s a regulation change and a power shift happens*

- The power shifts from McLaren to [Williams](https://en.wikipedia.org/wiki/Williams_Grand_Prix_Engineering)
- In ’92 and ’93, Williams was so technically superior to not just McLaren, but everyone else on the field.
- Senna wanted to join the Williams team, but there wasn’t a seat at the time
  - [Prost](https://en.wikipedia.org/wiki/Alain_Prost) specifically said, “*I won’t race with him*.”
  - So Senna spends 1 more year at McLaren

**Funny story**

- Senna was having a contract holdup with McLaren, and to sort of flex his muscles a little bit, he came to the US, did a day of testing in IndyCar
- By the end of his first day of testing, he was driving faster than any of the IndyCar drivers
- Dax points out, “*That transference hasn’t gone as well in the last 20 years when F1 drivers have gone to Indy.*” (it’s hard)

**Back to the lead-up to that weekend**

- Prost retires at the end of ’93, and Senna finally gets to go to Williams
  - The team that’s won the last 2 titles, and they will be the most dominant car for the next 4 years (though nobody knows it at the time)

**Rule change to remove active suspension**

- Unbeknownst to Senna, because of this rule change, the car for the beginning of the ’94 season was an undrivable technical debacle
- They’re scrambling to reinvent their entire suspension at that point

- Peter has become good friends with [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) (Senna’s teammate that year)
  - Damon was on the podcast 5 years ago [[episode #86](https://peterattiamd.com/damonhill/)]
  - Damon’s one of the most underrated world champions in F1
  - He won the World Championship in 1995
  - He’s the son of Graham Hill, a two-time world champion, making him one of only 2 father son F1 champions
- Damon drove the car in ‘93 when it was the best car ever, and then he knew what it was later
- Damon basically said, “*Look, the car was God damn undrivable. It was so scary. It was like being on a knife’s edge every minute of every lap of every drive.*”

“*For people watching us who don’t understand what it’s like to drive a race car, the goal of driving a race car is to be at the limit of the car. You’re always at the limit of what the car can do*.”‒ Peter Attia

- But you couldn’t drive that care near the limit
- Yet Senna still managed to drive it close to the limit

**Races earlier in that season**

- The first race of that year was in Brazil and Senna gets on pole

- Hard to imaging in that car

- Then with a few laps to go, he actually spins out on a corner
  - He just couldn’t control this thing
- Next race, he again gets it on pole
- BTW, he’s got a young [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) biting at his heels
  - He is in the Benetton: the best car that year
    - A lot of controversy about whether that car was cheating that year with traction control
- In that race, he’s on pole, but he gets hit from behind in the first corner
  - He’s out of that race

**Now we go into Imola**

- Remember, this is a 16-race season, and 2 races are down
- Senna has zero points
- Schumacher has won both of those races (he’s got 20 points)
- So Senna’s feeling the weight of the world on his shoulders

***He has to be perfect for the rest of the season, and certainly he has to win this race in Imola***

- Up until that point in time, Senna already has the record for most wins at Imola
  - This is a circuit he knows well
  - It’s a very hard circuit
- Aside: Peter just started driving it in the simulator a few months ago, getting ready for his trip out there; and it’s tough

- Peter explains, “*Everything goes wrong. So you start out with what we talked about on Friday. You’ve got Barrichello nearly dies on Saturday, Ratzenberger dies. Senna is in no mood to drive on Sunday*.”

**That Saturday night**

- It’s Josef Leberer’s birthday and they’re out at a pizza place celebrating, but the mood is somber
- Senna is incredibly angry about the scolding he took for going to see Ratzenberger
- He is very unhappy with the car, doesn’t feel that the car is safe
- That day he had spoken with [Niki Lauda](https://en.wikipedia.org/wiki/Niki_Lauda) who encouraged him to bring back the [driver’s association for safety](https://en.wikipedia.org/wiki/Grand_Prix_Drivers%27_Association)
  - Niki was now the most senior driver in F1, now that Prost had retired
  - This association had fallen by the wayside
- Senna agreed that the next race at Monaco, they would reinitiate the driver’s safety group

***Senna said to Josef that night that he didn’t want to really race the next day (for the first time ever). Yet Senna said, “There’s no way I can’t race. The people of Brazil need this, and they’re hurting way more than I am.”***

## Why Peter is obsessed with Senna [40:30]

- It’s kind of like the death wish, in a way, but also realizing it’s bigger than him
- Senna really felt like, “*I don’t want to do this. I don’t feel safe doing this, but there’s a hundred million people who need me to do this, and they’re in worse shape than I am*.”
- Dax compares it to the lead character in [*The Fountainhead*](https://www.amazon.com/Fountainhead-Centennial-HC-Ayn-Rand/dp/0452286751/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.98ohXabWcRSSkLc6GvVqsdquPIe6yKqQRxMIOriHPDTypQA2AfBqKtxIV_Uqr-1kCZ1DJuZtAwLke6SM9G8rOgLtyJf6HNvbEhQiD5xPPWIVK43yTLxUBnrSTzezKgVfxSgQyb9bWcubT29kyFKiXWe0-jy_LDT_PW8gU7fI5G3cyO4vRgGh2rjdJh5HxUSoue67U6Ps-mNzoYKbKhZVJqkpvzbXE9Aj81hnmIMxGhE.1Pm4GwiCEt20Hp4LHuTGakIy1Tz3vcdwfzEhOIhBb3U&qid=1713969624&sr=8-1)
  - The lead character (Howard Roark) is roughly based on the architect, Frank Lloyd Wright
  - He is a man who always knew what he wanted, always had a vision, never compromised, pissed a lot of people off, but ultimately was always right
- Dax thinks that archetype, when you’re a young man, is incredibly appealing
- He explains it was like, “*Yeah, maybe I know what’s right. I don’t have to listen to anyone else, and then I’ll be proven I’m right at the end of it*.”
  - Dax wonders how much of his high level of disagreeability

**Senna versus Prost**

- Prost was great at playing the political game
- The head of the FIA was also French, and was clearly was helping him the whole, with every dispute between Prost and Senna
- Senna was just so disagreeable and outspoken, and didn’t give a shit if anyone liked him

**Dax asks, “*****Is that part of his personality?*****”**

- Yes
- But also there was, “*I’m going to win or it doesn’t matter*.”
- Prost’s nickname was “The Professor”
  - The reason for that was among other things, he was very smart, and very strategic, and very calculating
  - If he was in a race and he was in 3rd place, he would think to himself, logically, “*I am playing the long game here,*” which is, “*I’m better off coming in third and getting my six or seven or eight points here if I don’t think I can win.*”

***Senna only wanted to win. He would crash out of a race to take a shot at winning. He just didn’t care for second, third, or fourth.***

> “*[Senna] He wasn’t competing against anybody else. He was competing against what perfection could be.*”‒ Peter Attia

- Dax explains Senna’s appeal, “*To see that someone is in pursuit of something that’s even higher than first place is appealing as a character type. But there’s some punk rockness to him*.”

## Being the best versus having the best record [43:30]

- If you’re a record junkie your favorite driver would have to be [Lewis](https://en.wikipedia.org/wiki/Lewis_Hamilton) or [Schumacker](https://en.wikipedia.org/wiki/Michael_Schumacher)

**Football analogy**

- [Barry Sanders](https://en.wikipedia.org/wiki/Barry_Sanders) doesn’t have the records
  - He’s not the leading rusher
  - He doesn’t have the most yards
  - He doesn’t have the most touchdowns
  - He has no Super Bowls
- By any statistic Barry Sanders is not actually the best, but he was the greatest running back of all time
  - Because there are intangible fact

***With Senna, there’s a characteristic of his driving, and Peter thinks most drivers would agree he’s the greatest of all time***

**Other great drivers**

- We might be getting to the point where we can start to say [Max](https://en.wikipedia.org/wiki/Max_Verstappen) is in the top 3
  - This is a kid who won a race at 17
- Peter asks, “*Where does* [*Fangio*](https://en.wikipedia.org/wiki/Juan_Manuel_Fangio) *belong in all of this?*”
  - It’s not just that he won five titles
  - It’s are you judging a driver against his peers?
  - He won 5 titles in 4 cars

*This becomes the same challenge as evaluating boxers because you really have to look at who they were fighting*

## Senna’s unique driving style and incredible intuition about automotive engineering [46:30]

- Dax has come across videos where people are pointing out that Senna had this very unique habit of stabbing the gas, which to me seems completely counterintuitive to what you’d want to do

**What was his rationale and how unique was that?**

- It was very unique
- Senna had a habit of when he was coming out of a corner of stabbing the gas
  - Stab, stab, stab, and then on full
- Regular mortals come back onto the throttle gradually
  - If you come on too much, you’re going to lose the rear of the car
  - So you’re coming off the brake, you’re coming onto the throttle
    - The mantra is: smooth is fast
- Senna did something very different

***It was hypothesized this was done to get rid of the turbo lag and he would get back to full power quicker than everybody else***

- He was keeping the RPMs as high as possible, such that when he got back to full power, there was no lag and he was gone
- People actually hypothesized that he would struggle when they went back to naturally aspirated cars
  - Here’s the weird thing: he kept doing it and he didn’t struggle
- Peter adds, “*That’s one of the things I don’t think I have a great explanation for why he was doing it other than he had clearly always been doing it. Like this is how he drove karts*.”

> “*His car control really was remarkable. And that’s one of the beautiful things about that era of F1 is the cars were so much harder to drive*.”‒ Peter Attia

**Cars in that era of F1 and Senna’s amazing abilities**

- The cars were much harder to drive
- There was less downforce, no power steering, a manual gearbox
- Look at an onboard Senna drives in places like Monaco where you have to be able to drive the car
  - Most people would take it within a foot of a wall
  - He would take it within 3 inches of the wall to maximize the size of the track for him
    - And he’s doing this one-handed with no power steering while shifting
    - They have to use a clutch

**Onboard of Senna at Monaco 1990**. Credit: [FORMULA 1](https://youtu.be/auXfAHHNSFo?si=PcW40n2rbJmCjMRk)

**Onboard of Senna’s pole position lap at Monaco 1990** Credit: [alvrub2011](https://youtu.be/d3_FCglY1vk?si=Sa6Dia1epLp1RuJH)

- Dax recently saw a great video of Senna driving an NSX in loafers, and he’s just sideways on the pedals
  - He’s so busy

**Video of Senna driving a NSX in loafers**. Credit: [MaxxUK](https://youtu.be/kzLjZWrpzmQ?si=Ikq0qTz3Gra73OJ_)

**The Honda engineers loved him**

- Senna helped develop the NSX
- Peter has actually sat in his NSX
  - It still sits at his brother’s home in Sao Paulo

*Dax asks, “Where was Senna’s technical aptitude for actually developing the car?”*

- To Dax’s knowledge, Schumacher had an incredible engineering mind (very mechanical)
  - He could help them develop the car in a way that most drivers couldn’t
- Senna was very similar
- And he was very committed to giving feedback
- This is difficult, Peter explains, “*As someone who drives a car myself, it’s hard to put in words like how dumb I am. I’ll go out in a car and I’ll know that it’s not right. But I can’t tell you why*.”
- Dax agrees
  - He aced for a season in the Super Trofeo series in Lamborghinis
  - He has rebuilt engines and cars
  - He is really mechanical, but actually articulating what he thinks needs to happen, is an entirely different knowledge that he doesn’t have currently

***In current F1 drivers, Dax thinks there are very few that can give them super specific feedback the way that Schumacher can (or Senna could)***

## Back to the day of the dreadful race [53:00]

- Senna manages to somehow wrangle pole for the third consecutive race of that season in an undrivable car that’s on a knife’s edge
- He has to win this race
- On  the first lap, he gets away clean, and 7 cars behind him, 1 of the cars stalls on the grid, gets plowed by another car, immediate safety car
  - This was back in a day when the safety cars were insanely slow
    - Today, most people would notice that they have the fastest street cars available as the safety cars, and the reason for that is these cars have to be kept moving quickly to keep the tire temperature high

**The temperature of the tires is everything**

- If the tires are cool, they are bricks
  - It’s like driving ice bricks under the car
- When you’re watching F1, you may notice during a formation lap or during a safety car, the cars will weave side to side
  - That’s to put friction in the tire, you have to keep the tire warm
- So you want a safety car to be able to go as fast as possible

*The teams in F1 have the best aerodynamicists on the planet*

- Some teams have $400 million at their disposal
- [Adrian Newey](https://en.wikipedia.org/wiki/Adrian_Newey) is better than anyone at NASA
- Dax explains, “*If you sit up next to, close to a car, it’s boggling how advanced and technological this thing is.*”

***But then you have to remember all of it has to transfer through four rubber tires***

- This is a great neutralizing fact about Formula One
- It’s like it doesn’t really matter what you do to that car because at the end of the day, you will have the built-in limits of a piece of rubber touching asphalt

*They all have the same tires*

- They all use the same rubber compound
- The difference between drivers is that one is way better at getting more pace out of a tire for longer
- And that’s why head to head, there’s no comparison between [Max](https://en.wikipedia.org/wiki/Max_Verstappen) and [Charles](https://en.wikipedia.org/wiki/Charles_Leclerc), because one guy always knows how to maximize the life of his tire
- Dax points out, “*They generally give credit to the car design in that situation*.”
  - It’s hard to parse out what is driver
    - But then you can watch their teammates and figure that out
- Peter explains this is something [Lewis](https://en.wikipedia.org/wiki/Lewis_Hamilton) did when he was at his prime

**6th lap of the race**

- The safety car comes out and they spend through lap 5 cleaning up

- The 6th lap is the first flying lap of the race ‒ on cold tires

*The fastest lap of the race is always documented, and today a point is given for it*

- In lap #6, Senna is off like a dart

*Tamburello*

- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) explained this to Peter in great detail
- The curve where ultimately Senna would die on the 7th lap is called Tamburello
  - It’s a very high speed, left-hander
  - It’s a curve that no longer exists at Imola
  - It’s deemed too dangerous
  - There were too many bad accidents there
  - Senna’s being the final and most deadly
- As Damon explained it, nobody took the driving line at Tamburello because it was too bumpy
  - And to be on a bumpy line, when you’re going a 100, and probably 205 miles per hour, you would just choose to go a little slower and drive on a smoother part of the track, even though it’s a longer distance
- Tamburello is near the beginning of the lap; it’s the first big curve of the lap
- As they come past the start finish line to lap six, Damon notices that even though they’re on really cold tires, Senna takes the racing line through Tamburello
  - He’s thinking to himself, “*What in the hell is he doing? Why would you take this risk?*”
  - Senna’s car is bottoming out; it is sparking like crazy
- Peter explains, “*We will never know if indeed Senna had a slow puncture in his tires, meaning did he run over some debris during the four laps when they were going over where the crash was, that was leading to a slow loss of pressure in his tires? Or was it just that his car, the tires didn’t have enough temperature in them?*”
- Right behind Senna is [Schumacker](https://en.wikipedia.org/wiki/Michael_Schumacher), and right behind him is [Hill](https://en.wikipedia.org/wiki/Damon_Hill)
  - They’re not taking the racing line; they’re taking the smoother part of the curve
- At the end of the 6th lap, Senna has driven what will be the 2nd or 3rd fastest lap of that race
  - On a full tank of fuel and ice-cold tires
  - That just gives you a sense of how hard he was pushing
- When he died they found an Austrian flag in his car
  - He always carried a Brazilian fal in his car, but that day he wanted to wave an Austrian flag for [Roland](https://en.wikipedia.org/wiki/Roland_Ratzenberger)

> “*This is a guy who’s normally possessed to win every race. So you just take that up a notch*.”‒ Peter Attia

- As they finish lap 6, Senna is pulling out from everybody
- They enter lap 7, and as they’re entering Tamburello, he drives straight off the track

[1:02:20] video entering lap 7, entering Tamburello, and Senna drives straight off the track

**Senna’s fatal crash as seen from the onboard cameras of Hill and Schumacher, and an overview**. Credit: [iLOVEtheseVINYLS](https://youtu.be/8qYXVfY_9IE?si=PAdUEPntqF55d8jV&t=30)

## What Peter believes caused the crash [1:02:45]

- Peter has watched this a hundred thousand times and will tell you what he thinks is happening
  - And what Damon believes is happening
  - Damon’s view is now Peter’s view; it’s also [Adrian Newey’s](https://en.wikipedia.org/wiki/Adrian_Newey) view
- Adrian wrote the definitive book on car design: [*How To Build A Car*](https://www.amazon.com/How-Build-Car-Autobiography-Greatest/dp/000819680X/ref=sr_1_1?crid=1IFKIWX39SSHR&dib=eyJ2IjoiMSJ9.V6R4qmJf-xYAKNXeLA_tsCwYeaCit0Jo2lN-bUbpSbtOTA4FVfetRBF9MuDYusB99s_JuXoiJyfTnqLXWgiiaFeXEW1W0c2xV-3_7CsEvUeOui07JmtFpUsGK6NNMJVAZEOZ52hpEUIUSFv3f4Ze29yRPcJ6ABbb7D8qKX5OP28GlggvH2Apvotu5CJpu5o30riBsKItj3bMgq6B3rQNuDYIWMXwzei9ZXcqNg2gzoQ.BRevNEJK2S63w1KQUr0-PxJ9FM-iHgjzKqmn0TIqvG8&dib_tag=se&keywords=adrian+newey+how+to+build+a+car&qid=1713975100&sprefix=Adrian+Newey%2Caps%2C94&sr=8-1)
- When you read the chapter on the FW16, which was the car that Senna died in
- Adrian has talked at length about how difficult it was
- The Italian courts found him liable for the crash, but by the time they got to that decision,t he statute of limitations had expired for that charge

**When Senna got to Williams, he hated the car**

- How it handled
- He didn’t like how he fit in the cockpit
- All these things he took for granted at McLaren (where he had a car built around him)
- He doesn’t like where the wheel fits

***So they actually have to extend the steering column by some six inches to put it where he wants it***

- In doing so, they had to make the steering shaft narrower than what the spec was called for

**Adrian writes about what happened in that crash, and Peter has spend hours discussing this with Damon**

- The best onboard footage is from the car behind him (Schumacher’s)

***As Senna entered Tamburello (which is a left-hander), he lost rear grip of the car when it bounced***

- The way these cars work, they have a huge [Venturi effect](https://en.wikipedia.org/wiki/Venturi_effect)
  - There’s a perfect amount of air that must be between the floorboard and the ground
- And when you bottom out, you momentarily lose all of that aerodynamics
- He’s going into Tamburello and because the car is bottoming out, either just because of how bumpy on the line that he is and/or because his tires are cold and/or because he has a small slow leak of air due to running over debris,

***As he is bottoming out, the bottom of the car slides out***

- Peter admits, “*It’s possible I am convincing myself I can see this on the Schumacher on board, because I now am believing this. But I really believe there’s a split second where you can see the rear move.*”

**That is called oversteer**

- Oversteer is when the rear wheels of a car are moving or turning faster than the front wheels of the car
- Oversteer is a phenomenon that a driver will feel long before you see it
- You will see oversteer because you’re spinning this way, but you feel it in your butt before that and you can almost hear it in the tires
- You hear the loss of traction
- So it’s not surprising to Peter that you don’t have to see much oversteer for Senna to have felt it

***When a car is oversteering this way, you course correct by countersteering into it***

- So if the car is oversteering to the left, you countersteer right, and that snaps the back of the car in direction
  - And then you’re backing a little bit off throttle and then you’re coming back to throttle and you’re going
- You don’t have to be doing the throttle correction if you catch it quick enough
  - So you could stay full throttle and countersteer back

***Peter believes the car oversteered due to a loss of rear traction, Senna countersteered, and it immediately regained grip and shot him straight off the track***

- What the telemetry shows is that he went on max brake and hit the wall

**The steering column was broken when the car was recovered**

- The question is, did the steering column break from the collision or did it break beforehand?
- It’s very hard to know
- But if you look at the lights, if you look at the video of the lights, you can see that he was countersteering before he left the road
- Peter has heard very confusing reports: some say that the wheel had no torque in it when he left the track
  - And that would certainly suggest that the steering column was broken
- But what you don’t see is you don’t see him turning the wheel
- Dax doesn’t think Senna could turn the wheel hard enough to snap
  - Even though it was a smaller diameter than it was supposed to be, the notion of torque breaking through steering a steel rod seems really unique and weird
- Peter explains, “*It’s a delicate move when you’re countersteering. It’s not hugely abrupt. But again, if it were the wheel breaking, you would see his hands doing this as he’s going straight off and you do not.*”
- Senna hits the wall in the ballpark of 150 mph; he’s in full brake

**Seeing Tamburello in person**

- Peter didn’t see Tamburello for the first time in person until 5 years ago
- To see the wall that he hit , he was blown away how much closer it was than he would’ve expected

*Senna had many times petitioned for the wall of Tamburello to be moved out*

- But there was a ravine just behind it and they couldn’t move the wall
- There was nothing there to absorb a crash, just a concrete wall

***As Senna hits the concrete wall, the right front wheel comes off, and it’s actually the suspension rod of that wheel that punctures his helmet***

- He died a brain death on the track
  - Not a scratch on his body other than head trauma
- [Sid Watkins](https://en.wikipedia.org/wiki/Sid_Watkins) was the medical physician of F1 at the time and was part of making F1 safer
- Legend has it, the night before the race, Sid told Senna, “*You should just retire. You got nothing left to prove.*”
  - He could tell Senna was distraught after Ratzenberger died

## Views on dying young, in the prime of life [1:13:00]

**Dax asks, “*****I can tell it’s heartbreaking to you that happened. What is your overall assessment of athletes dying? What is your relationship with that?*****”**

- Dax has a very specific compartmentalized view of all that, and it may seem sociopathic on some level
- In Peter’s view, there’s something about James Dean and Marilyn Monroe and JFK that creates a legend status in them
  - Part of it is they died in their prime and they were at the peak
  - We never saw them get old and decline
- Dax adds, “*They didn’t have to adjust to a non-exciting life.*”

**Senna was truly at this best**

- Most would say that he peaked in ‘93
  - Even though he didn’t win the championship in ’93, he was in a very inferior car, he still managed to win 5 races and give us some of the most heroic performances we’ve ever seen (including Donington)
- He died at the 3rd race into the ‘94 season

***When you have a person who dies at their prime doing the thing they love, there’s a part of you that says, “There are worse ways to go.”***

**The measure of life**

- For many people, the singular measure of life is longevity (duration)
- Dax remembers when [Paul Walker](https://en.wikipedia.org/wiki/Paul_Walker#) died, and he thought, “*If you were to have measured somehow the amount of experience he had had on planet Earth in that period, I would argue very, very few people had lived a bigger life or more of a life, or had traveled more and met more people and had more experiences and had more heightened everything*.”

***Dax would not want is a very boring, subtle existence with no mountains and valleys for 130 years***

- A lot of people end up living 10X the life of someone who lives to be 110
- Dax adds, “*If you presented me with the options, if I live Senna to 34 or I live like some of my neighbors growing up to 105, I would pick Senna.*”
- Dax engages in a lot of behaviors that are dangerous and people scratch their head at
  - He feel like this is the only version he wants
  - Obviously a family complicates that
- Peter relates, the legend has it that Enzo Ferrari used to keep tabs on his drivers based on different milestones in life, and he would discount their lap times based on that
  - Once a driver had a girlfriend, 2/10ths slower
  - Once he got married, 5/10ths slower
  - Once he had a kid, 1 second slower.

***It’s just as the stakes get higher, you naturally just can’t be all out anymore***

> “*Senna lived 10 lives in his 34 years. And not only that, he’s one of the few people who still matters in his death.*”‒ Peter Attia

## Senna lives on in his foundation and in safety changes adopted by F1 [1:21:00]

- Before he died, Senna had spoken to his older sister about getting more formal with his giving
  - Up until then he had been quietly giving mostly to education
  - Poverty in Brazil was so significant at that time
- His sister [Viviane](https://en.wikipedia.org/wiki/Viviane_Senna) created a [foundation](https://en.wikipedia.org/wiki/Instituto_Ayrton_Senna) to do this right [[Instituto Ayrton Senna](https://institutoayrtonsenna.org.br/en/)]

***This foundation has probably given over half a billion dollars to education in Brazil, and so in that sense, Senna does live on***

> “*His death did change the sport forever, in the sense that it changed safety instantaneously.*”‒ Peter Attia

- It’s not that he was the first driver to die
- You could even argue that there was a comparable death in the 1960s when [Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark) died
  - He was a world champion
  - He died in a Formula Two race ‒ back then drivers would drive F2 to pay the bills
  - But his death wasn’t seen by the world
- By the time Senna died, the sport was much bigger and it completely changed everything, meaning the sport got so serious
- It was like [Earnhardt](https://en.wikipedia.org/wiki/Dale_Earnhardt) dying in [NASCAR](https://en.wikipedia.org/wiki/NASCAR)

- You got a [HANS device](https://en.wikipedia.org/wiki/HANS_device) immediately
- There’s a really [eerie interview](https://youtu.be/iq6mVAXegyw?si=xAI0pYFIWdSVVHFp&t=61) of Dale Earnhardt the day Senna died, he said a lot of nice things

## Statistics aren’t enough for fandom, and why people like who they do [1:24:15]

**Why Dax and Peter aren’t drawn to Lewis**

- It would be incomplete to say it’s all statistics based because it’s not
- Peter has a close personal connection to [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel)

**Peter stopped paying attention to F1 after 1997**

- In 1997, [Jacques Villeneuve](https://en.wikipedia.org/wiki/Jacques_Villeneuve) won the F1 World Championship
- Peter was in medical school and decided to start paying more attention to school than sports
- In ‘98 and ‘99 it was won by [Hakkinen](https://en.wikipedia.org/wiki/Mika_H%C3%A4kkinen)
- The next 5 victories went to [Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher)
- Peter shares, “*Deep down, there was a tiny, tiny part of me that didn’t like Schumacher and held him, and this is going to sound ridiculous, partially responsible for Senna’s death.*”
  - He was the one applying the pressure, and he was driving what Peter felt was an illegal car
  - Senna also believed he was outrunning a car that had traction control when his car was undrivable

*Tangent on the best F1 cars*

- The active suspension of Senna’s car in ’93 was probably just as good as the Williams
- The reason the Williams car was so dominant was it had the Renault engine that was incredible
  - And the Honda engine in ’93, the Ford Cosworth engine, were nowhere near as good that year

***Senna, again, he still managed to win 5 races in a season where his car was clearly outclassed***

*But the point is, everybody could have active [suspension]*

- It’s just McLaren and Williams had a better active suspension  than everybody else
- Williams also happened to have the best engine by far; so it was hands down the best car
- The detuning of the active was hardest on them to recover

**Peter didn’t come back to F1 until** [**Vettel’s**](https://en.wikipedia.org/wiki/Sebastian_Vettel) **years**

- Vettel won his first title in 2010
- He won four in a row

**Every time there was a rule change in F1, that created a new dominance**

- That’s when the dominance shifted from [Red Bull](https://en.wikipedia.org/wiki/Red_Bull_Racing) to [Mercedes](https://en.wikipedia.org/wiki/Mercedes-Benz_in_Formula_One#Mercedes-AMG_Petronas_Formula_One_Team_(2010%E2%80%93present)) before it’s now coming back to Red Bull
- Red Bull nailed the engine
- By 2021, Max wins, even though Lewis actually has a better car in ’21

**What Dax likes about Lewis is something he liked about Senna**

- This is an outsider
- He brings a rock star quality to it
- He’s fashionable, he transcends the sport
- It’s awesome that there’s a black Formula One … he can’t help but love that

**By the time Dax started watching F1, Mercedes was just so dominant**

- [Alonso](https://en.wikipedia.org/wiki/Fernando_Alonso) was someone who came out last year and said this publicly: you have to evaluate these people by did they win first against their teammate or did they win first against another team?
  - For Alonso, it’s more significant if you win against another team
- All those years, it was Mercedes was finishing one, two, one, two, one, two
- Lewis was complaining last year that Red Bull was so dominant when in fact there’s just reams of data of him qualifying 1.4 seconds ahead, certain times of second place
- Max was the underdog
- When Dax started watching, it was just very easy: this dude’s won 7 years in a row and he explains, “*I don’t want to see that again. And the car is so significantly better. It’s not even remotely fair.*”
- He would come to learn it’s never remotely fair
- But at that time, he was shocked

## The biggest difference between F1 today and F1 in the 80s [1:28:30]

- In the 80s-mid 90s the **balance between driver and car** was about 50/50
  - Meaning it was 50% the car and 50% the driver
- That’s unimaginable now
- Today it’s probably 75/25, maybe 80/20
- In other words, if you put Max into the Williams/ European car today, he wouldn’t win a race
- You go back into the 80s, Senna’s in a Toleman that first year and he basically wins Monaco
- Schumacher is originally right in the Benetton car, which is not competitive, and he’s podium
- you just go back and look at how much Senna was able to do before he got into the McLaren (the perfect car)
  - He was still clobbering it

**Dax explains, “*****Another set of variables which I think made the racing back then more fun too, is that reliability was an enormous factor too*****.”**

- You could have the best car, but every car is going to DNF two races a season because the reliability just wasn’t there
- It was much more unpredictable
- People didn’t retire or get fired because of a mechanical failure
- Every 3 races, you lost a handful of cars

## Senna’s driving superpower [1:30:30]

**Senna’s ability to drive in the rain was so magical**

- Dax knows a few dudes in MotoGP that are that way (Jack Miller)
- Angelo Parrilla was the team principal for DAP, which was the premier karting team of the ’70s and ’80s
  - Senna and another guy, Fullerton, were the 2 biggest names in European karting in the late ’70s and early ’80s
- Peter remembers Angelo saying that as good as you think Senna was in an F1 car, he was even better in Kart
- And so good in the rain that when it was raining, he would usually try to petition the marshals to cancel the race and just give Senna the trophy
  - Of course they would say no
  - Senna would double lap everybody
- Peter explains, “*As a really, really lousy driver, it’s hard to put in words how much more difficult it gets in the rain.*”
- Dax immediately goes to motorcycles: watching MotoGP in the rain and admitting to myself they’re turning faster lap times at that track than I can on dry is so humbling
- When Senna wins his first race in Portugal in ‘85, it is pissing rain his car is hydroplaning when driving down the straights, and other drivers are spinning everywhere
  - He’s driving the John Player Special [shown in the video below]

**Senna wins in the rain | 1985 Portuguese Grand Prix highlights** . Credit: [FORMULA 1](https://youtu.be/7VbTC5I-7Rk?si=BrTXmL_Y1SpORLrU)

[**Lewis Hamilton**](https://en.wikipedia.org/wiki/Lewis_Hamilton) **is brilliant but he doesn’t fight to win like Senna**

[**Max Verstappen**](https://en.wikipedia.org/wiki/Max_Verstappen) **and Sergio Michel “**[**Checo**](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez)**” Pérez Mendoza**

- Dax has defended Max but it was a bummer when he would not help Checo at all
- Because Checo fell on his sword in 2021 over and over again to help him beat Lewis
- Dax’s take is that for Max, nothing else in the world matters [except winning}
  - He is a cyborg
  - He gets in the car and he’s got to get the very best outcome that’s possible, period

*It’s like the story of the scorpion and turtle*

- A scorpion and a turtle are on one side of the river and the scorpion says, “*Hey, can you help me get to the other side of the river?*”
- The turtle’s like, “*Are you kidding me? You’re a scorpion. You’re going to kill me*.”
- Scorpion is like, “*Why would I do that? You’re going to help me to the other side of the river.*” And
- Turtle thinks to himself, “*Well, it’s true. He can’t kill me because we’ll both drown*.”
- Sure enough, the scorpion hops on the turtle’s back
- They’re going across the river and halfway across the turtle is like, “*Oh, what the hell is that?*”
- He turns and he says, “*You stung me*.”
- Scorpion says, “*I’m sorry. It’s my nature*.”

***Max’s singular focus is what Dax loves about him***

**Many people fought over the last race in the 2021 season**

- It’s ridiculous, we always unlap cars
- People refer to that as the greatest injustice in F1 ‒ it shows how shallow their history is of F1
- Dax finds it reminiscent of the Prost-Senna battles where Prost got the call every time
  - It seems that Lewis had gotten every call that year
- Peter adds, “*To me, that’s the most interesting season because the better driver beat the better car. That’s the first time you really saw that in a decade*.”

## The fastest drivers currently in F1 [1:38:30]

**Dax asks, “*****If you had to order, who do you think the fastest drivers are right now?*****”**

- Not taking into consideration their cars
- Peter thinks [Max](https://en.wikipedia.org/wiki/Max_Verstappen) is the fastest by quite a bit
- [Fernando](https://en.wikipedia.org/wiki/Fernando_Alonso) is the second fastest
- Peter adds, “*That’s even a difficult question for the following reason, which is different cars have different styles. The Red Bull is really built around Max’s style.*”
- The way Max drives, again, this is another reason why Peter thinks Max is so good, is he drives a car that has a couple of features
  - It’s a car that can be driven very fast, but has a very narrow operating window to be driven fast
  - It’s very hard to drive it fast
- It’s a testament to how far [Checo](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez) has come, now that he’s 3 races into this season
  - He deserves credit because a lot of other drivers got spit out

## Current F1 obsessions [1:45:00]

- In Peter’s  F1 WhatsApp group, the thing that gives that group the most joy is watching how bad [Alpine](https://en.wikipedia.org/wiki/Alpine_F1_Team) is doing right now
  - That’s the biggest drop in performance he’s seen
- It’s confusing shy Alpine would do so poorly
  - They do well in other series
- Peter’s wife is obsessed with [Pierre](https://en.wikipedia.org/wiki/Pierre_Gasly)
- His daughter loves [Danny](https://en.wikipedia.org/wiki/Daniel_Ricciardo)
  - Peter bumped into him and chatted with him last year and he asked how his daughter was doing
  - A year earlier he had met Olivia, taken a picture with her, a nd signed a hat for her
  - It’s freakish that he remembers details
- Dax [interviewed Danny](https://armchairexpertpod.com/pods/daniel-ricciardo) and they got along really well
  - They set up a hang
  - He loves motocross, so every time he’s in LA, Dax takes him to ride
  - They’ve developed a friendship and it’s been lovely
- Dax’s take on Danny, “*He’s a really fucking good dude. Impossibly good dude.*”

*More F1 drivers are good than not*

**Dax enjoyed finding out that** [**Max**](https://en.wikipedia.org/wiki/Max_Verstappen) **has a persona which is very different from who he actually is**

- He’s a shy introvert, the sweetest guy
- It’s hard to imagine

**Dax is obsessed with** [**Jos**](https://en.wikipedia.org/wiki/Jos_Verstappen) [Max’s father]

- The amount of criminal activity he’s been a part of is impossible, convicted for fracturing a guy’s skull at the go-kart track with his own father
- He was momentarily arrested for attempted murder. T-boning an ex-girlfriend in an intersection at full speed and claiming that it was just an accident
- The hostility that’s just burbling out, it makes Dax really compassionate to Max
  - That this kid survived this and adores him

## How hard it is to do what the top F1 drivers do [1:50:15]

[**Max’s**](https://en.wikipedia.org/wiki/Max_Verstappen) **superpower is he’s so good in a car**

- Nothing phases him
- That’s hard to put in words how big a deal that is in driving

## Dax’s love of motorcycles and his AMG E63 station wagon [1:52:15]

- Dax tried to get Peter to start riding motorcycles
- Dax drove his AMG E63 station wagon on the track at Laguna after being on the track for 2.5 days on his motorcycle
  - He explains, “*That’s a great fucking car. That’s not a boring car to drive on the track. It’s 600 horsepower and dual clutch trans. It’s awesome.*”

***But after 3 laps he found it so boring compared to riding a motorcycle***

**What Peter learned about driving at the** [**Texas Drift Academy**](https://texasdriftacademy.com/)

- [Josh Robinson](https://texasdriftacademy.com/driftschoolcoaches/) leads the Drift Academy, he’s a professional Formula driver
  - It’s this awesome school
- Peter came across it on an add on YouTube, now he’s a Drift-aholic

*The holy grail of drifting is doing tandems*

- One guy’s drifting in front and the other guy behind him is doing everything
- They’re 2 feet off eachother
- It might take a year to get to the point where you can do a lead-follow tandem

[***Seb***](https://en.wikipedia.org/wiki/Sebastian_Vettel#) ***was doing it within 3 hours***

- Then the funniest thing Seb goes, “*Is it okay if I give you a pointer?*”
  - Peter’s like, “*Dude, are you kidding me?*”
  - From a 4-time F1 world champion
- Seb explained, “*Lay off the throttle a little bit more here and just do this and then counter steer a little bit more this way.*”
- The fact that he could figure this out in 3 hours and it’s taken Peter 3 years and he’s still not that good

***You also realize there are people that are just so much better***

- Peter explains, “*It’s actually part of why I enjoy my hobbies is I actually really enjoy being so lousy at these things*.”
  - It’s frustrating, but you’re constantly in a state of, the learning curve is still so steep for me
- Peter realizes he has too much built-in self-preservation to ever be a good driver

**Dax is often does the driving in movies he directs**

- He did all the driving in [*Hit and Run*](https://en.wikipedia.org/wiki/Hit_and_Run_(2012_film))
  - The stunt guys threw away 4 cars
  - He was proud that he didn’t’ throw any cars away, he never threw away the Lamborghini

**Dax wants to do a TV show with** [**Daniel**](https://en.wikipedia.org/wiki/Daniel_Ricciardo) **where they go and drive everything**

- They would race
- Snowmobiles are fun and the learning curve is very quick

## Awesome Senna mementos from Etsy [2:01:15]

- Dax’s wife was perusing Etsy and found these Senna cups
  - He insisted she get them so he could give them to Peter
  - So cool
- Then he bought a shirt for himself, but his arms are too long so he decided to pass it on to Peter
  - It’s from the season he died

Names with special meaning

- Peter tells the story of how he got his wife to agree to name their son Ayrton
- He had a harder time with their previous son whose middle name is Feynman
- At the point when they named Ayrton, Jill had only seen the documentary [*Senna*](https://en.wikipedia.org/wiki/Senna_(film))
- It’s a very good documentary
  - You should go and see it now
  - You’ll fall very head over heels in love with Senna
- Her biggest concern was, will people know how to pronounce his name?

**Other names with a special meaning**

- Dax pitched Lincoln for his first daughter after his Lincoln Continental
- The name Delta (for his second daughter) came out of a joke
- Peter has a friend whose kids are named Lincoln, Kennedy, Reagan, and one other president

## What makes specialists interesting, and Max’s devotion to F1 [2:10:15]

- President Grant is super fascinating because he’s an abject failure at everything in life except for war and his presidency
  - Terrible with money, insolvent, duped many times
  - But he had a genius and it was just so specific and it was unrivaled
  - It’s such a good book [[*Grant*](https://www.amazon.com/Grant-Ron-Chernow/dp/159420487X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.EPfv5fqLzEIFgDngKEcoLeoimGi_wlUrZsdQLmDMQJC4BfE_CCDj3EPxINddDSke_3Zr9G57GY9p2bUZpdhnfUlLy6oSNccv5BmqvpD2tw4MAfkdDmvZ2s4yRmezjnb0XCAsn1wyMuX7yHcc0WLZSGYaRfO270H94Fk7McM3nbZBB_m6lKJdiWFiA62Y7q1KjR1kALeV3hvaEDCR0BjylzWnHHBJGeCEfS2uW54cI5E.ov3EJfv61vkc-FKA_TeLjZ5BV0FdPorqykCiiq-WOik&qid=1713985359&sr=8-2)].
- Dax thinks he and Peter are similar in, they want to be kind of good at everything

***The notions of specialists really interest Dax, because he’s not that way at all***

- He doubts Max can balance a checkbook or go grocery shopping
  - He’s probably not a great boyfriend, but boy, he can do that thing
- Peter points out that [Max](https://en.wikipedia.org/wiki/Max_Verstappen) spends a lot of time in simulators
  - Not many drivers do that
  - Literally after he wins a race in the highest division of the highest sport, when anybody else would be out partying, he’s on a sim race competing against the sim racers around the world
    - He’ll spend 3 hours doing it
- Peter doesn’t think think anyone on that grid spends as much time thinking about racing

**Peter would love to know what Max thinks of Senna**

- Max is only 26 and could race another 10 years and eclipse every record if he chooses to

***Max and*** [***Alonso***](https://en.wikipedia.org/wiki/Fernando_Alonso) ***are probably the two people Peter thinks will drive forever***

- Alonso makes Dax think of [Valentino Rossi](https://en.wikipedia.org/wiki/Valentino_Rossi)
  - In his last season racing, he was like Alonso
  - He was maybe 44 still racing against these 19-year-old kids
  - He was going through a turn and a guy had crashed just before the turn and came off the bike and the bike was just flying unmanned, and then another guy crashed
    - So 2 bikes, he’s in the turn already committed
    - 1 bike goes right in front of him and 1 goes behind him at the same time
  - It’s the most impossible moment in all of racing motorcycles
  - He’s a foot away from the 1 in front of him and a foot in front of the 1 behind him, both of them flying with a T-bone and would’ve killed him
  - Normal people are asking why he was even there (and not retired)
    - He’d won 9 championships already
    - He’s not competitive
  - Everyone was like, “*Oh my god. He just barely avoided death.*” And for him, he’s like, “*Yeah, this is what I’ll be doing until I’m dead. I’ll be in some situation that scares the shit out of me.*”

## What Senna might have done if he had not died that day [2:14:00]

- Most observers believe he would’ve driven another four years until the next regulation change and at the end of Williams dominance
- Williams ended up being the most dominant car the year he died
  - Despite the fact that it was an impossible to drive vehicle for those first 3 races, the brilliance of that team did figure it out
- Senna’s his teammate ([Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill)) almost won the championship that year
  - He was, he was 1 point behind Schumacher going into the final race of the year
  - Damon looked like he was going to win the race but his suspension rod broke
- Schumacher won the next year, it was close
- Damon Hill won the next year in the Williams and Jacques Villeneuve won the next year in the Williams
- Peter doesn’t think it’s an enormous stretch to say Senna probably would’ve won 4 consecutive championships in ’94, ’95, ’96, and ’97
- There’s talk that he always had a soft spot for Ferrari (like every driver), and would’ve maybe gone to Ferrari
- Peter could have seen him retiring

**Would he have gone into politics?**

- Would it have made a difference in the presence of Brazil?
- This is a guy that was so loved
  - There’s no example we can point to of someone who turns to politics with that much of the support of a nation

**Would he have been an ambassador of the sport?**

**Ad Dax was prepping for this and stumbling upon the pole record, that elevated his assessment of him**

> “*I will concede that I think it’s very difficult to compare drivers across eras.*”‒ Dax Shepard

- If you ask Senna, who was the greatest, he would’ve said it was [Fullerton](https://en.wikipedia.org/wiki/Terry_Fullerton) was the greatest guy he ever raced against in karting
- If you asked him in F1, he would’ve said [Fangio](https://en.wikipedia.org/wiki/Juan_Manuel_Fangio)
  - That was his hero

## Michael Schumacher and Max Verstappen are also top F1 drivers [2:17:30]

- We have to give [Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) a lot of credit
  - The fact that he goes to Ferrari, which is a shitty team, and just sticks it out and develops that car
- Peter ranks Schumacher as second best
- But that could be [Max](https://en.wikipedia.org/wiki/Max_Verstappen)
  - Give Max another 5 years, and maybe he’s going to be #2
  - Maybe one day he will be the greatest of all time
- Dax is most excited about seeing Max driving the second fast car once again, because that was the most exciting thing ever, that he had to out drive Lewis and did consistently

> “*There’s an artistry to him [Max] that Schumacher doesn’t have. There’s some kind of artistry for sure to Senna that captivates the emotions a lot more.*”‒ Dax Shepard

## Interlagos in Sao Paulo Brazil is always an incredible experience [2:18:45]

**Peter asks, “*****Have you ever been to Sao Paulo?*****”**

- No, Dax has not been to anywhere in South America
- Peter invites him to come to [Interlagos](https://en.wikipedia.org/wiki/Interlagos) with him one year
- Peter will go to the cemetery where Senna is buried
  - It’s a beautiful cemetery in the middle of Sao Paulo
  - It’s the most unassuming thing, just a plaque in the ground

**Dax asks, “*****Where  do you place all his religious stuff? You can’t find audio of him not talking about God at some point.*****”**

- Peter thinks he drew strength from it

> “*[Senna] He really believed in his God-given right to win every race*.”‒ Peter Attia

- For Dax, “*There’s a duality to it. On one hand, it presents as humility. Which is, he’s regularly thanking God for this gift. That’s humble. But then for me as the cynical atheist, I’m like, ‘But you’re also saying God cares more about you than anyone else.’ There is also a deep arrogance to it that, ‘God has picked me to win a race.*’”
  - He has a hard time figuring out if that’s humility to believe in God and you feel chosen by God
- Peter points out that Senna did not have a view of immortality
  - It’s amazing how often you hear him talk about mortality (in interviews)
  - He always knew that he was on the limit and his time could come, and he spoke very modestly about that

Senna died 30 years ago and Peter explains, “*I think another example of feeling old is, I still remember the day he died very clearly. I remember every detail of the room. I remember hearing it on the radio. I remember what my radio looked like. I remember everything. That’s a little odd.*”

§

![](https://peterattiamd.com/wp-content/uploads/2024/04/bio-daxshepard-500x500.png)

##### Dax Shepard

Dax Shepard is an actor, comedian, filmmaker, and host of the podcast [*Armchair Expert*](https://armchairexpertpod.com/). Dax races motorcycles at Buttonwillow Raceway. He is also an avid car enthusiast, and owns the 1967 Lincoln Continental that was featured in the movie *Hit and Run*.

Instagram: [@daxshepard](https://www.instagram.com/daxshepard/?hl=en)

Podcast: [Armchair Expert](https://armchairexpertpod.com/)