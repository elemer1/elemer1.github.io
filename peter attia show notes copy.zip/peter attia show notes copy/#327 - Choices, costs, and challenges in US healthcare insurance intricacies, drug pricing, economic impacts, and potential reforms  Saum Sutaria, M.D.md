# #327 – Choices, costs, and challenges in US healthcare: insurance intricacies, drug pricing, economic impacts, and potential reforms | Saum Sutaria, M.D.

**Source:** [https://peterattiamd.com/saumsutaria/](https://peterattiamd.com/saumsutaria/)

---

Dr. Saum Sutaria is the Chairman and CEO of Tenet Healthcare and a former leader in McKinsey & Company’s Healthcare and Private Equity Practices, where he spent almost two decades shaping the field. In this episode, Saum unpacks the complexities of the U.S. healthcare system, providing a detailed overview of its structure, financial flows, and historical evolution. They delve into topics such as private insurance, Medicare, Medicaid, employer-sponsored coverage, drug pricing, PBMs and the administrative burdens impacting the system. Saum’s insights help connect healthcare spending to broader economic issues while exploring potential reforms and the role of technology in improving efficiency. Saum highlights how choice and innovation distinguish the U.S. healthcare system, explores the reasons behind exorbitant drug prices, and examines the potential solutions, challenges, and trade-offs involved in lowering costs while striving to improve access, quality, and affordability. The opinions expressed by Saum in this episode are his own and do not represent the views of his employer.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/saumsutaria/the_Drive_public.png)

Play

#327 - Choices, costs, and challenges in US healthcare: insurance intricacies, drug pricing, economic impacts, and potential reforms | Saum Sutaria, M.D.

#327 - Choices, costs, and challenges in US healthcare: insurance intricacies, drug pricing, economic impacts, and potential reforms | Saum Sutaria, M.D.

1x15s30s

0:002:32:46

## We discuss:

- The US healthcare system: financial scale, integration with economy, and unique challenges [5:00];
- Overview of how the US healthcare system currently works and how we got here [9:45];
- The huge growth and price impact due to the transition from out-of-pocket payments in the 1950s to the modern, third-party payer model [18:30];
- The unique structure and challenges of the US healthcare system compared to other developed nations [22:00];
- Overview of Medicare and Medicaid: who they cover, purpose, and impact on healthcare spending [27:45];
- Why the US kept a employer-sponsored insurance system rather than pursue  universal healthcare [32:00];
- The evolution of healthcare insurance: from catastrophic coverage to chronic disease management [36:00];
- The challenge of managing healthcare costs while expanding access and meeting increased demand for chronic illness care [44:15];
- Balancing cost, choice, and access: how the US healthcare system compares to Canada [48:45];
- The role of the US in pharmaceutical innovation, it’s impact on drug pricing, and the potential effects of price controls on innovation and healthcare costs [56:15];
- How misaligned incentives have driven up drug prices in the US [1:05:00];
- The cost of innovation and choice, and the sustainability of the current healthcare cost expenditures in the US in the face of a shrinking workforce and aging population [1:11:30];
- Health outcomes: why life expectancy is lower in the US despite excelling at extending lifespan beyond 70 [1:18:45];
- Potential solutions and challenges to controlling drugs costs in the US while balancing choice and access and preserving innovation [1:26:15];
- Balancing GLP-1 drug innovation with affordability and healthcare spending sustainability [1:40:00];
- Reducing healthcare spending: complexities, trade offs, and implications of making needed cuts to healthcare expenditures [1:46:45];
- The role of government regulation, opportunities for cost savings, and more [1:56:15];
- Hospital billing: costs, charges, complexities, and paths to simplification [2:01:15];
- How prioritizing access and choice increased expenditures: reviewing the impact of healthcare exchanges and the Affordable Care Act [2:08:00];
- Feasibility of a universal Medicare program, and what a real path to sustainable healthcare looks like [2:15:45];
- The challenge of long-term care and the potential of innovation, like device-based therapies and AI, to improve health [2:23:15]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Saum Sutaria is the CEO of Tenet Health, a healthcare service company that owns and operates hospitals, ambulatory surgery centers, diagnostic imaging centers, and other healthcare facilities
- Saum joined Tenet in 2019 after working for 2 decades at McKinsey & Company, where he was the leader of the Healthcare and Private Equity Practice
- Saum was also one of Peter’s most important mentors at McKinsey ‒ Saum recruited him out of his residency at Hopkins to join McKinsey in 2006
- Saum previously held an associate clinical and faculty position at the University of California, San Francisco
  - Where he also engaged in post-graduate training with a focus on internal medicine and cardiology
- Peter wanted to have Saum on this podcast to discuss the US healthcare system for a long time
  - This is one of the most complicated systems in the US
- It’s a system that Peter didn’t feel he had a great understanding of
  - He certainly understood parts of it, but he couldn’t put it all together
- Part of this is that Peter didn’t spend a great amount of time working on healthcare while he was at McKinsey
  - He spent more of his time in financial services and banking
- Peter never got the education he wished he did
- More importantly, enough has changed since he’s left that it was time to have this discussion from scratch
- Going into this podcast, Peter’s hypothesis was that if you understood all the dollars that flowed into the system and all the dollars that flowed out of the system, you would understand the system
  - That is exactly what happened
- Peter came away from this discussion with a really thorough understanding of this, and it has made it much easier for him to engage in the subsequent discussions that he’s had with leaders in this field
- It’s made it easier for him to digest information he’s reading in this field
- And this has become a real obsession of his: truly understanding US healthcare from a cost perspective, a quality perspective, an access perspective, and trying to understand what it would take to make this better
- In this discussion we begin with an overview of how the US healthcare system currently works
  - How it is structured and how these costs flow
- We also do a little bit of a comparison to how the US compares to other developed nations
- We talk a little about the history of how we got here, going back to the 1950s
  - Until Peter understood the history, it was impossible for him to understand some of the “baggage” that we have in the current system
- We looked at the intricacies of insurance
  - Private insurance, Medicare, and Medicaid
  - And the challenges of employer-sponsored coverage in the US
- We speak about drug pricing
  - This is one of the major areas where the US is at a supreme disadvantage compared to other countries
- We talk about the impact drug pricing has on pharmaceutical innovation and the role of [PBMs](https://en.wikipedia.org/wiki/Pharmacy_benefit_management)
- We talk about the administrative burdens and what role technology may play in these areas going forward
- We connect healthcare spending to the broader topic of economic issues and discuss potential reforms to the system, considering what might be possible in the future
- Peter came away from this podcast with his objectives being met, and that is entirely a credit to Saum’s ability to understand and deconstruct all components of the system
  - Peter wanted to be able to sit down with anybody (regardless of their level of sophistication) and explain what is going on with the US healthcare system economically
  - Saum’s breadth of knowledge is virtually unparalleled in this regard

## The US healthcare system: financial scale, integration with economy, and unique challenges [5:00]

- Peter hopes this conversation serves as the masterclass on the United States Healthcare System
- He thinks of himself as someone who tends to get deep into things and then quickly come to an understanding of them
- But he has been rather unsuccessful in understanding healthcare, and he’s looking forward to how much he’s going to learn in the next few hours
- We are going to talk about things that people care about
  - Why is it so expensive?
  - Why isn’t everybody covered?
  - Why do we not have the best life expectancy?
  - On average, why do we have horrible life expectancy despite spending twice as much as anybody else?
- We can’t have that discussion if people don’t understand the system, and it’s a really complicated system
- Saum is one of the most structured thinkers Peter knows

**Saum’s framework for understanding healthcare in the US and why we are different than every other country on the planet**

*From a finance perspective*

- Healthcare comprises close to 20% of the US economy
- The US economy gross domestic product that’s probably $28 trillion
  - That’s 25% of the world’s economy
  - Another way to think about it, that’s almost $90,000 per person in the US
- We spend $11 to $12,000 per person in the US on total healthcare expenditure
- $4 trillion of expenditure in the healthcare sector
- If you added up all of the exports that the United States sends out across all industries, you’re talking about $3 trillion
- We import more than we export
  - A consumer culture, that’s close to but not quite $4 trillion today

***Put that in context in terms of how much we spend in healthcare in the US, it’s a huge number***

> “*Any discussion about the economy, about inflation, about jobs, you’re really talking about healthcare in many ways… given that it’s almost 20% of the economy*.”‒ Saum Sutaria

Peter asks, “*Do we know that it represents roughly 20% of the workforce as well?*”

- In terms of **wages**, it probably represents a little bit more than that because the average wage in healthcare is higher than in other areas
- As healthcare as a percentage of the US economy grows, you can’t have that happen without considering what it does to the rest of the economy
  - That’s going to be an important discussion around US competitiveness, US affordability, US coverage, etc. given the nature of healthcare and healthcare issues today

**Does it make sense to go back to the 1950s to start with Hill-Burton to start with, and then progress into Medicare and Medicaid?**

*Does historical context give people a sense of what happened after World War II?*

## Overview of how the US healthcare system currently works and how we got here [9:45]

**Let’s start with painting the picture of where we are today, and then let’s back up and say how did we get here?**

- $4 trillion (just to keep this simple)
- About $1 trillion of that (1/4th) comes from **consumers**
  - Some of that is spent on what people contribute to the insurance they procure
  - Some of that we’re spending directly on consuming healthcare, out of our pockets
- **Employers** put another $1 trillion into the system
  - Largely through employer-sponsored insurance
  - So that’s the second trillion, and now you’ve accounted only for half of it.
- The other half [$2 trillion] is coming from **government** (federal and state)
- These days a lot of it is federal government, and the federal government contributes in 2 different ways
  - 1 – Direct expenditures
  - 2 – employer-sponsored coverage being the dominant source of coverage in the US
    - Which is unique to the United States
    - Where your employer procures health insurance for employees, which then provides a form of coverage

Peter wants to make sure that people appreciate that because someone listening to this might say, “*I have a health insurance card and it says Blue Shield on it, so doesn’t Blue Shield provide my insurance?*”

- That’s correct, but it’s coming through your employer
  - Most people would recognize that because of their annual enrollment
- The point is that the Humana, the Aetna, the whoever is on the card is usually providing an administrative service only if the employer is large enough that the employer is bearing the risk (we’ll get into that later)

**⇒** You’ve got ¼ that people are spending out of pocket in one form or another

- Some of it is to subsidize their ability to buy insurance

**⇒** ¼ is coming from employers, directly out of their profits

- Think about that $1 trillion for a second
- Total US corporate profits are about, interestingly, coincidentally, just south of $4 trillion
  - Corporate profits, post-tax
  - Off of total revenues, it’s a lot lower as a percentage
- But if you think about it from the perspective of total corporate profits, that’s a big, big number

***The expenditure in healthcare is pretty significant when you think about it that way***

- For the $1 trillion, think of it this way: if you have $20, $1 is going into direct healthcare expenditure
  - That’s 5% of someone’s expenditure on an annual average basis
- Then you’ve got government spending of about $2 trillion
  - Direct spending plus a tax subsidy for employer-sponsored insurance
- Back to the $1 trillion that employers are spending, that is a pre-tax benefit to employees
  - That’s the incentive that started back in 1954

**When you talk about 1950s (1954), the tax benefits for providing employer-sponsored insurance were codified into law**

- That incentive, giving people healthcare coverage through group purchase insurance by your employer is a pre-tax benefit rather than a post-tax benefit
- It created an incentive for employer-sponsored insurance to grow, and ultimately become the dominant form of which people procure insurance today outside of government

Peter asks, “*What’s the approximate cutoff in company size at which point it makes sense to self-insure, which is what you’re describing?*”

- Mostly larger companies do that, but the definition isn’t that large
- There are entities with less than 500 employees that self-insure at times (not that common)

*Put the federal spending in context*

- With the direct and the tax in-kind contribution to healthcare the federal government is making, you’re getting close to $2 trillion ($1.82 trillion)
- Defense spending is about $1 trillion
- Social Security is $1.2 trillion today
  - Social security doesn’t come out of tax revenue directly

***The number Peter keeps thinking of is the government collects $5 trillion a year in taxes, and we’re putting 40% of it back into healthcare***

- $5 trillion may be what we collect, but the government is spending closer to 6.8 trillion (there’s a deficit)
- This is the other thing that blows Peter’s mind
  - We collect $5 trillion a year
  - We spend $7 trillion a year
  - We have a deficit of $2 trillion a year in perpetuity
  - And we’re sitting on $35 trillion of total debt

**Ultimately, the question is: when healthcare is such a large part of the economy, how sustainable is what we’re doing in healthcare expenditure?**

- You’ve got $4 trillion of spending and ½ of that from the government
- In our system, about $2.5 trillion of that plus some from the government is flowing into private insurance
  - They’re covering what we would traditionally call commercial insurance
  - The private insurance community is also covering a bit of Medicare and Medicaid, increasingly large proportions of that
    - Through programs like Medicare Advantage or Managed Medicaid or other things that all for theoretically better choice and maybe even cost control
- Then there is the retail component, and the government pays directly to providers through Medicare and Medicaid some amount of money
  - That’s about $1 trillion

**Administrative costs of healthcare in the US**

Saum explains “*When I look at how the money’s spent in a way that people can understand, I think of very simple rules… which is administrative costs in the US is probably one of the biggest gaps to what we see in the rest of the world, and that can be good or bad.*”

- You have to make a judgment about whether all that administrative spending is creating a better system with more choice and better outcomes or not

**⇒** What we spend takes up close to 10-15% of the total pool of dollars

- When you think about that number ($4 trillion), that’s a huge amount of money going into administration (we’ll talk about that later)
- For the remaining dollars, about ***⅓*** goes into hospitals and infrastructure-based care
- About ***⅓*** goes into physician’s offices and other clinic-type activities
- And about ***⅓*** goes into drugs and devices
- Again, a simplification from that perspective
- Saum is including the cost of pharmaceuticals that might be administered in a doctor’s office or a hospital

***How people can think about where their money is spent in the healthcare system: ⅓ on hospitals, ⅓ on office visits, and ⅓ on drugs and devices***

- Obviously some people never end up in the hospital
- A small proportion of people end up costing us a lot
  - In hospitals
  - Or for example some people are not on any drugs, and some people may be on 5 or 6 drugs
  - The system has a variety of what Saum calls “cross-subsidies” in it

*Peter points out other ways people may have heard this*

- ½ of the healthcare dollars are flowing into facilities
- ⅓ is going into payroll and physicians
- ⅙ is going into drugs
- Peter likes Saum’s ⅓, ⅓, ⅓ better because it’s more transparent
  - In the previous world where we say ½ goes into facilities, we’re discounting how much of that contains physician salary and how much of that contains pharma
  - So when you strip that out, this is more elegant

*The delivery industry is a pass-through to other things in some ways*

- The 3:2:1 framework was probably an older framework
- If you look at the rise of total drug costs, the ⅓, ⅓, ⅓  is a more transparent and simplified way of looking at how we’re spending our dollars

## The huge growth and price impact due to the transition from out-of-pocket payments in the 1950s to the modern, third-party payer model [18:30]

- It’s the late ‘40s, early ‘50s, and the US is on top of the world
- Our GDP as a % of global GDP has never been higher and may never be higher again
  - Peter was so interested that he looked it up, if you look at the % of global GDP that is the US’s today, it’s “only” 20 to 25%, which is still staggering
  - It was close to 40% post-World War II
- What’s happened over the last 20 years is China’s GDP has expanded so much that as much as we continue to grow, our relative share has gone down
- Economically, we’ve never been more dominant than we were post-World War II
- Saum adds that the US economy has grown robustly since then, and he thinks that’s an important factor in affordability
- Had the US economy stagnated and others grown, this affordability question would be a very different question than what we’ve seen happen
  - Which is the US economy has grown incredibly robustly

**Back in the late ‘40s to early ‘50s, there was a global phenomenon where many places made significant investments in social welfare programs in healthcare**

- The [NHS](https://en.wikipedia.org/wiki/National_Health_Service) in the UK was created in 1948
- Systems that were designed to increase coverage originated in that timeframe (roughly)
- For us, it was 1965 when [Medicare](https://en.wikipedia.org/wiki/Medicare_(United_States)) and [Medicaid](https://en.wikipedia.org/wiki/Medicaid) came into being

**⇒** In the 1950s we were spending <5% of GDP on healthcare, versus 17.5% today

- We’re almost at 20% [of GDP]
- In the ‘50s, more than half of those dollars were spent out of pocket
  - Meaning you went to the doctor and you paid your bill
  - Today, that’s 25%, and if you look at direct expenditures where some of the dollars you’re putting in are going to cover your insurance premium, it’s really 15%

***Today, your direct exposure, what you see and feel in terms of what you’re spending on healthcare is down to 15%***

- That’s because the **socialization of coverage of costs** has made the American consumer less sensitive to the price points that they’re seeing for everything, for drugs, for doctor’s offices, for hospitalizations, etc.

**⇒** The other thing that’s interesting is today that means 85% of healthcare expenditures are covered by a third party, whereas it used to be about 50%

**That sensitization phenomenon is real**

- Back then, the federal government contributed about 12.5% to expenditures
- Today, it’s north of 35%
  - When you add direct spending plus tax benefits and other things (lost taxes for the federal government, etc.) you’re about 1/3 of the expenditure being the federal government

> “*The rise of the federal government’s role in healthcare has been material and almost as rapid as the rise in healthcare costs from that perspective. So it’s a very different system of consumption.*”‒ Saum Sutaria

## The unique structure and challenges of the US healthcare system compared to other developed nations [22:00]

**Do we have a sense historically why, as the NHS is coming into its existence in the UK and as most developed nations are developing systems that look far more like the NHS than what we’ve done?**

*Was there something about our geography being much more vast than say England was in the 1940s that led itself to this?*

*Was it this nature of states rights versus federal power?*

- There are all kinds of things in the ecosystem, including geographic diversity, state versus federal rights, and even, fundamentally, the drive that the American consumer has in determining their own outcome
- If you look at our system today, much of its construct is based on a desire for **consumer choice**
- Many of these coverage programs (or some would say welfare programs, that evolve like Medicare and Medicaid) were designed to solve some substantial problems

*If you go back, 2 things happened in the 1950s*

- 1 – There was a significant commitment to investment in hospital capacity at the time
- There were people in America (not just rural but suburban) that did not have easy access to acute hospitalization
  - And the technology and ability to intervene and save lives in that setting was improving significantly
- At the time, there was a belief that some people wouldn’t have equitable access
- That’s called the [Hill-Burton Act](https://en.wikipedia.org/wiki/Hill%E2%80%93Burton_Act): in simple terms, it guaranteed a hospital within every 10-15 miles of every American
- And that’s what happened
- Legislation drove our thinking in terms of access all the way until it expired in 1997

***We made a massive investment in infrastructure from that perspective to provide people access***

- 2 – We developed a coverage mechanism for seniors, what we today call Medicaid
- Before the 1960s, there wasn’t a coverage mechanism for seniors with less means
  - There was patchwork stuff
  - It got to the point where on average seniors were spending ¼ of their retirement income from Social Security on healthcare, and that’s wasn’t sustainable
- Why Medicare, and ultimately Medicaid associated with it was you had a country whose economy was growing rapidly, we could afford to take care of our seniors
- That decision was met with great support

***You created a system that covered seniors, and therefore the federal government’s expenditure jumped up significantly***

**Why did we not do with Medicare what was done with Social Security?**

- It’s Peter’s understanding (and he’s a little embarrassed at how little he understands this) that Social Security is funded directly, it’s not a budget line item
  - When he pays his Social Security on his paycheck, it’s directly going to pay somebody, correct?
- But Medicare doesn’t work the same way Social Security does, but he still makes a Medicare payment every month

***There are special taxes to help fund Medicare, but it’s really a solvency issue***

- Peter thinks it’s a fundability issue too ‒ you can use a Medicare tax to do something else

**In hindsight, it’s 100% clear**

- In the 1950s, 4.5% of GDP was spent on healthcare
- At the time Medicare came about (in 1965), that number was in the mid 6’s to upper 7’s at best
- Who would’ve guessed that it would rise to 17, 18% in the future

> “*The US healthcare system in many ways is a story, an optimistic story of well-intended policies that now are questioned based upon the way the expenditures have increased.*”‒ Saum Sutaria

**It’s also important to understand that as the US healthcare expenditures increased as a % of GDP, so did the rest of the developed world**

- Every developed nation that put in place programs (their version of Medicare or Medicaid, more state-run than privately run), their expenditures increased
- They started like us in the 4’, and they’ve landed in the 11 to 12% range
- We’ve just accelerated up to 17, 18%

*Put it in perspective: from that time forward, the the healthcare economy has grown roughly 2% per year faster than the US economy*

- And the US economy has grown robustly, better than the rest of the world
- So that’s why the expenditures have gotten so high
- There have been periods where that’s been slower, and there have been periods where that’s been faster

**⇒** Every time there’s a new coverage event, that rate of increase for healthcare expenditures relative to GDP growth has widened

- Medicare or Medicaid
- Some of what happened with the Medicare Modernization Act in 2000 (we’ll get into that when we talk about drug costs)
- Then obviously the Affordable Care Act, which created significantly more coverage

## Overview of Medicare and Medicaid: who they cover, purpose, and impact on healthcare spending [27:45]

**Tell people what CMS is, what Medicare and Medicaid actually do. Who do they cover?**

- [CMS](https://en.wikipedia.org/wiki/Centers_for_Medicare_%26_Medicaid_Services)  is the Center for Medicare and Medicaid Services
- Medicare covers people over the age of 65 and a bunch of special categories of people with severe chronic illness (dialysis as an example) that it might be hard to find coverage on the private market over a long period of time given their needs
  - It’s more of a safety net program
  - It’s a coverage program for people over the age of 65

Peter asks, “*How long does one have to have paid into it to qualify for it?*”

- Everybody qualifies for Medicare at the age of 65
- It’s not like Social Security; the benefit doesn’t vary

**Another interesting piece of context to think about is life expectancy**

- Saum doesn’t know what the exact number was in 1950 or ‘65, but it wasn’t what it is today

![](https://peterattiamd.com/wp-content/uploads/2024/11/f1-saum.png)

**Figure 1. Life expectancy trend of men in the US (red line) compared to highest recorded life expectancy**. Image credit: [National Academies Press 2011](https://nap.nationalacademies.org/read/13089/chapter/3)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f2-saum.png)

**Figure 2. Life expectancy trend of women in the US (red line) compared to highest recorded life expectancy**. Image credit: [National Academies Press 2011](https://nap.nationalacademies.org/read/13089/chapter/3)

***In the broad context and scheme of things, over the last 100 years, life expectancy in the developed world has improved remarkably (2x)***

- Yes, there are now differences at the top of the spectrum between the US and others (which we’ll get into)
- Health status may be a different thing [depicted in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f3-saum.png)

**Figure 3. Life expectancy and healthy life expectancy (HALE) at age 60**. Image Credit: [US Census 2021](https://www.census.gov/content/dam/Census/library/visualizations/2021/comm/healthy-life-expectancy.pdf)

**Tell people what Medicaid is**

- Medicaid is a safety net program designed for individuals below certain measures of the federal poverty level
  - There are different definitions state by state of
  - The cutoff ranges somewhere between 100-200%+ of the federal poverty level
- The idea behind the coverage is that for those people, not only are their needs unique, but their ability to access healthcare services can be challenged
- Programs like Medicaid is it increases their ability to access the healthcare system in a reasonable manner with a coverage system that avoids taking those least fortunate down a path of severe medical debt that would be overwhelming to their personal financial situation

**⇒** Medicaid covers a lot of people: today it covers 90 million people in the US

- More than Medicare
- Almost ⅓ of those covered in the Rust Belt states are covered by Medicaid today

**⇒** Medicare covers maybe 65 million or so

- It will become close to 90 million at the peak of the baby boomer aging (around 2032)

Peter asks, “*What is the federal poverty level today?*”

- Saum doesn’t know

![](https://peterattiamd.com/wp-content/uploads/2024/11/f4-saum.png)

**Figure 4. Federal poverty level in 2024**. Image credit: [Office of the Assistant Secretary for Planning and Evaluation](https://aspe.hhs.gov/topics/poverty-economic-mobility/poverty-guidelines)

- He can tell you that the income level that defines federal poverty is pretty low

Saum adds, “*You or I would not consider that to be a reasonable living wage or income for a family in this environment with the cost of goods being what they are today.*”

- There are people who will not meet the criteria for poverty who maybe should based on purchasing power, and who will be underinsured
- That’s where things like the exchanges from the [Affordable Care Act](https://en.wikipedia.org/wiki/Affordable_Care_Act) have stepped in to provide at least options for additional coverage so that people’s healthcare costs can be offset

## Why the US kept a employer-sponsored insurance system rather than pursue  universal healthcare [32:00]

**We went to great lengths in the 1960s to create Medicare and Medicaid. Why didn’t we just roll this out for everybody as the NHS has done?**

*Why did we instead continue to keep 2 completely different worlds: a government funded system for people over 65 or with chronic conditions or of low socioeconomic status, but for everybody else, we do this crazy thing where your employer takes care of you?*

***The employer-sponsored insurance system was already entrenched because of the tax benefits that existed***

*This is an important point about our belief in consumerism and choice*

- The marketplace provides choice in a way that many of the nationalized healthcare systems that exist in other countries don’t
- If you really look at many of those other countries, while they have a nationalized healthcare system that purportedly has universal coverage, they also have a private system no differently than ours where people with more means can procure better insurance and better access and a private healthcare system, etc.
  - It’s just not as widespread as it is here
- In this country, there was a belief that was institutionalized by incentives that employer-sponsored insurance was working
- Remember at that time, it wasn’t that expensive
  - Meaning employers often covered 100% of the premium
  - The employee did not end up having to contribute like they do today to the cost of their insurance as an employee that they’re receiving from their employer
- It was a comfortable system at the time
- And based upon the system, you got choice
  - Which product do I want? What kind of network do I want? etc.

**What happened as a result of that expanding, is that insurance moved from being an individual product based upon your individual risk to group insurance**

- Especially expansion of employer-sponsored insurance
- With employer-sponsored insurance, you’re aggregating all the employees and all their risk, and you’re **socializing that risk** among the whole group
  - In order to protect each individual, we’re going to share the risk as a group ‒ buy the insurance collectively, and it’ll spread the risk among us
  - To avoid individual catastrophic loss from a healthcare expenditure perspective
- That was a big move in the insurance industry as employer-sponsored insurance took off
- Of course, the concept of Medicare itself by bringing all seniors together was also socialization of healthcare costs across all seniors
- Not all seniors spend equivalently, as you can imagine

**What happened on the other side is absolutely a story of incredible innovation over the last 50 to 75 years in healthcare**

- We can debate what’s resulted from that
- Development and maturity of the pharmaceutical industry, development and maturity of the medical device industry, innovation in procedures and services that have allowed people to have invasive procedures in manners that used to hospitalize people for 3 weeks and now it could be 3 days
  - And in some cases if you’re having a knee or hip replaced, it’s at best 3 hours in and out the door (amazing)

***The impact of that, along with the socialization of healthcare costs and therefore removing the individual from understanding or feeling that cost directly because they’re insured together was a virtuous cycle that just drove up consumption***

## The evolution of healthcare insurance: from catastrophic coverage to chronic disease management [36:00]

Saum explains, “*I’m not an economist, but people would look at this and say, ‘Okay, there’s moral hazard and concepts like that that exist with an insurance system like that,’ and we should spend a minute on what was insurance designed for back then and what is it now.*”

**Peter loves this analogy and has told this story before on the podcast [about socialization of costs]**

- He had a friend who is American, but he lived and worked most of the year in Riyadh, Saudi Arabia
- Peter was visiting him in Saudi Arabia 15 years ago, and they were at his flat, and it was in the spring and he was just getting ready to head back to DC where he lived
- Peter remarked to him, “*God, I can only imagine how hot it gets in Riyadh in the summer, so if you leave here in May, you come back in September, how hot is your apartment when you get back? Just out of curiosity. Is it a sauna?*”
- And he goes, “*No, 70 degrees… I leave the air conditioning on [for] the whole summer*.”
- He explained that he’s not paying for it, the government subsidizes all of the energy costs
  - He pays a few dollars over the summer to air condition his place

***This is the exact point: when you don’t have skin in the game, you can’t make decisions that are wise in the context of resources***

**Look at the concept of insurance**

**⇒** Insurance is for random, infrequent, and unpredictable events

- When the primary role of insurance was to prevent catastrophic loss, if you had a heart attack or you had an accident, or you had an appendicitis, or you had a cancer (which back in those days was less of a chronic disease), the concept of insurance made some sense
- Now, if you look at what drives expenditures from a health status standpoint: it’s multiple **chronic illnesses**
  - Obesity, diabetes, heart disease, lung disease
  - Even the innovation in HIV/AIDS care in this country
  - Cancer is becoming more of a chronic disease

***We try to ensure somewhat uninsurable events***

- Analogy: you don’t try to figure out how to use your car insurance to get an oil change
- But when we think about going to the doctor to get a preventative checkup or to refill regular diabetes medicine (which is taken for the rest of your life), we think insurance
  - But it’s not really an insurable event

> “*Insurance today is a discount card. It’s not insurance in healthcare. Insurance traditionally would be in other parts of your life where you procure insurance for random, infrequent and unpredictable events.*”‒ Saum Sutaria

**Is this manifested in the financial part of their business where they bear the risk? Do health insurance companies look like Travelers or Geico because of float, or do they function totally differently?**

- They function differently from that perspective
- Obviously they have a tremendous amount of expertise in managing risk

**⇒** But the nature of that risk, they understand isn’t random, infrequent, and unpredictable events

*The fundamental understanding that the insurance companies have to be successful in their risk business is understanding their risk pool*

- You’re going to have 1000 people in insurance
  - 5% may cost you 50% of your total spend
  - 20% may be 85% of your total spend
  - Then you’ll have a large group of people that really on a unit basis don’t spend very much
- And they have to understand that risk pool

*If we were going to start an insurance company tomorrow, what would it take for us to be successful?*

- It’s very hard because the number one thing that would create the foundation beyond all of the infrastructure and systems and other things required to function in a complex ecosystem would be **a large enough population of patients with a risk pool that you can understand**
- Look at all of the folks who’ve gotten into the newest exchange products that offered an opportunity to do that are the exchanges that have come out of the Affordable Care Act
- There have been insurance companies that have popped up and have failed
- There have been some that have struggled but still exist
- There have been some that have been gobbled up
- The vast majority of **success** on the exchanges has been through traditional insurers who have the foundation of the systems to do so
- The **innovation** in that space has come from the Medicaid insurers who adapted their processes and systems to be able to come onto the exchanges at a lower cost point

***It would be very hard to do that***

- Remember the other thing you’d have to have if you had an insurance pool given that you have to make payments timely is you’ve got to have enough capital backing the insurance risk

***Where do you raise all that capital?***

**Saum’s summary**

- We have a $4 trillion system
- It’s almost 20% of our GDP
- It was not anything like that in the 1950s
- There are a number of coverage welfare programs that have been put into place
  - Many of them done in that time, not only with good intention, but reasonable projections that things would not have grown like this
- Medical innovation (just look at the number of patents) has grown
- The combination of medical innovation, drugs, devices, service innovation, procedures, along with coverage (coverage that was disconnected from individual accountability) created a virtuous cycle of spending increase that has gotten us to this place
- And it has been faster than GDP
- At the same time it hasn’t broken the system because the US economy has been thriving

*The arguments about affordability*

- The argument would be that at this level of expenditure, it’s draining the US economy from being competitive
- Saum isn’t sure that that’s actually true yet
- All of the dollars and benefits that have gone into creating a healthcare system have created millions and millions of jobs

**⇒** If you look back over the last 20 years, healthcare has probably created more jobs as a sector than in any other sector in the United States

- The only 2 things Peter could even put alongside that as huge sectors would be energy and agriculture
  - They probably still don’t create as many jobs
- Saum points out that energy, agriculture, and healthcare are the 3 most **subsidized industries** by the government
  - Putting aside the defense industry
  - Energy is very much so today, not just from a national security perspective, but in terms of the innovation needed there
  - Healthcare has been so certainly since 1965 when you had Medicare and Medicaid come about; the expenditures have just grown
- Aging contributes a bit to the expenditures in healthcare
- The value of this pre-tax benefit (as more and more people are employed) has grown to continue employer-sponsored insurance as a vehicle of private insurance to match the public programs (Medicare, Medicaid and otherwise)

***Healthcare expenditures have grown significantly***

## The challenge of managing healthcare costs while expanding access and meeting increased demand for chronic illness care [44:15]

**What have industry participants done to help with healthcare expenditures?**

- The argument will always get made, “*Well, it’s grown so quickly, they’ve done nothing.*”
- Saum doesn’t think that’s even remotely true

*You could be in a situation where expenditures would’ve grown even faster*

- Think about this from a hospitalization perspective, the number of bed days per thousand: how many hospital days per thousand population have fallen by a half since 1980?
- The number of physicians per thousand people has more than doubled
- The industry has added significant physician capacity in order to help with access
- Do we still have shortages in certain areas? Of course we do
- But the number of physicians has doubled from about 1.5 per thousand to 2.8 per thousand

***The industry has expanded its capacity***

*Managing cost*

- The insurance companies, through their **managed care programs**, have demonstrated the ability to manage cost
- If the consumer were accepting of some of that management
  - Which is how to do managed care in a way where it doesn’t reduce and frustrate consumers or physicians with respect to choice and professional freedom

***Make no mistake about it, tight managed care has controlled costs for a short period of time until there’s been a bit of a revolt in terms of that***

- And product choice within insurance companies has created choice
- If you go back, you had Medicare for a very long time, sometime around the late ’90s, 2000, Medicare Advantage really took off
  - [Medicare Advantage](https://en.wikipedia.org/wiki/Medicare_Advantage) was a way to create product and benefit choice for seniors that wasn’t just traditional Medicare
  - Peter compares it to the equivalent of private insurance in the NHS system where you get the state-sponsored thing, but you want more choice
  - And the government gave an incentive: payments to private insurers who get into the Medicare space were almost 115% of the regular Medicare expenditures
    - They were trying to incentivize bringing people into the system, privatizing part of the system, providing better benefits, giving them choice, and ultimately have that managed care, hopefully reduce cost

***The jury is out in terms of if Medicare Advantage really reduced cost or shifted cost or whatever***

Saum explains, “*It is a highly functional private system built on government dollars called Medicare Advantage, and increasingly, managed Medicaid is doing the same thing*.”

***The industry participants have done a lot in many ways over the last 30 years in this space to try to curb costs without reducing immediate access and choice***

**⇒** That desire for immediate access and choice defines our system

- Peter adds that while the number of physicians has doubled over the last 40 years, the number of hospital beds has fallen by half
  - And the number of hospitals has declined

**Physician salaries**

- Physicians in this country spend infinitely more than in any other country to become educated, and therefore the debt that they assume upon completion is also a big part of what drives cost (physician salaries)
  - Presumably, the US must have the highest physician salaries
- Saum agrees, the US has the highest physician salaries relative to other countries

**⇒** Stunning fact: physician compensation on a real basis since the 1990s has been flat or declining

- It grew rapidly from the 1950s roughly until the early ’90s, but since then it has been flat or in many cases, declining
- That has a lot of implications (given the medical training debt) about our ability to continue to grow the pool of physicians to meet the **growing demand of healthcare services as the population is still aging**
  - The population is also aging with chronic illness so that their needs are more intensive rather than not.
  - We’re not even yet getting into mental health
    - Which has been an area that’s been under-invested in for the better part of 3 or 4 generations
    - Which as we now realize actually costs a lot, not just for mental health, but the impact on physical health, which drives our healthcare costs, especially in the context of chronic illness

## Balancing cost, choice, and access: how the US healthcare system compares to Canada [48:45]

**What’s a PPO? What’s an HMO? What’s value-based care? How does Kaiser work?**

*Can you explain what those things are so that people understand when they’re making their selection at open enrollment, they get a sense of what those things are?*

- A **PPO plan** is one in which you’re procuring insurance where you have relatively open network choice
  - There may be a preferred network where you get somewhat of a discount, but you have the choice to go wherever you want, however you want
- A **HMO (**Health Management Organization) is one in which that choice is narrowed
  - You are making a choice upfront to come into a program with less options such that the penalty for going out of that set of options is high
  - Theoretically it comes at a lower cost
- And then you have systems within those that kind of operate in the frame of one of those 2 models
- In the US, the PPO business has been growing significantly faster than the HMO business

**⇒** Choice is more important than cost right now to consumers

- That’s not to say that people aren’t feeling the costs of healthcare increasing and the burden of healthcare costs increasing
- People are choosing PPO more than not

**Kaiser, for example**

- Kaiser is largely a closed network health management organization where what you’re doing is you’re buying an insurance product through Kaiser
- It’s a not-for-profit that you’re buying an insurance product through Kaiser and you’re agreeing to stay within their network of hospitals, doctors, etc.
- They have a physician group that is largely bilaterally aligned to them on an exclusive basis
  - That’s a for-profit entity, the physician group
- And the two of them together produce a product that ought to cover the vast majority of your healthcare needs

***In theory, based upon that integration of care, you either get lower cost or better outcomes or both***

Saum adds, “*I think the jury from a long-term perspective relative to other models, is out, but it’s innovative and it’s worked in some places really, really well.”*

*Kaiser doesn’t cover everything*

- If you have a child that’s born with the most obscure congenital cardiovascular malformation, they might just send you up to UCSF
- Saum’s personal example: his mother had a rare form of brain cancer
  - They had terrific oncologists at Kaiser who were incredibly dedicated and knowledgeable about oncologic care, who, without hesitation, sought expertise from UCSF when they needed it for the more sophisticated parts of her care
    - Including letting her go there

Saum shares, “*My personal belief from personal experience is that clinicians do make a lot of the choices at Kaiser.*”

- They get knocked sometimes that somehow there’s a corporation sitting there telling them what to do
- Yes, it is managed care, and yes, there are restrictions on, in some ways, how they construct their system
- But when you have an esoteric problem, no one stops a physician from sending you to the right place there in my experience

**⇒** All systems that are in managed care have out of network expenditure for rare things

- The vast majority of the country today (from an employer-sponsored standpoint) is working in some form or another of a PPO system where people have choice because that’s what they want

***That choice comes with a cost, and that maybe explains some of the differences between us and other countries***

**Peter’s anecdotal experience with the Canadian healthcare system**

- Peter grew up in Canada and still has experience with the Canadian healthcare system because his entire family is there
- If you needed heart surgery, if you need an aortic valve replacement, a root repair, a [CABG](https://en.wikipedia.org/wiki/Coronary_artery_bypass_surgery), there is a surgeon in Canada that’s just as good as the surgeon in the US
  - Meaning the top 10% of the surgeons in Canada and the top 10% of the surgeons in the US are going to be indistinguishable in that regard
  - You’re really going to get great care in that regard
- The difference is you’re going to wait a heck of a lot longer
- The hospital experience could be entirely different
- Obviously, you’re not paying for it

Saum cautions, “*You’re paying for it with taxes.*”

- You’re more shielded from the cost
- But if you’re dealing with something like you’ve injured your knee and you need an MRI, the difference in how long you will wait to get that, it’s immense

***The speed, the choice, the access is really what goes down; the quality has not been degraded in a system like Canada***

- Saum agrees with Peter’s description of top physicians in both places
- There are excellent physicians around the world, in developed countries

**One distinction around the world is emergency care**

- Emergency care is accessible on an emergent immediate basis in most developed countries
- Now, the interventions that they may take, how interventional it may be, how aggressive they may be using the most modern technologies or modern devices or whatever, may be different, but emergency care is available
- If you had a heart attack immediately in Canada, went to the emergency room, you’re going to get treated very well

**Where things change is in elective care**

- Heart surgery can be an elective
- You might think of elective as cosmetic surgery
- A hip replacement, a knee replacement when you can’t walk, a cataract replacement when you’re half blind, or heart surgery can be elective
- You’re just scheduling it in advance
- In many parts of the world, the wait times for those things are much longer

*The cynical view of that is of course, that it’s a cost management system, but what Saum would say is they’ve made a choice ‒ it’s an infrastructure choice*

- The way you would describe this in economic terms is that you have universal coverage, which creates the same **moral hazard problem**
  - People would consume infinitely, but they choose to cap it with supply-side interventions: constricting the supply or available supply of services in order to manage the demand
  - That creates wait times or accessibility problems
- You have a lot of Canadians who come into the US for healthcare on a more immediate basis, or they buy private insurance (if they can afford it), which can reduce the wait times

> “*For better or for worse, right or wrong, nowhere in the world, no matter what healthcare system you’re in in a developed country do you have fully equitable access*.”‒ Saum Sutaria

- For those with means, there’s always a system to procure better access from that perspective

## The role of the US in pharmaceutical innovation, it’s impact on drug pricing, and the potential effects of price controls on innovation and healthcare costs [56:15]

**What’s different in the US at scale**

- It’s not just the focus on consumer choice

*The US has become comfortable in healthcare being the driver and leader of innovation*

- In healthcare services, that is [reflected in] the proliferation of academic health science centers that conduct research, much of which used to be supported exclusively by the NIH and increasingly funded through private industry
  - The [NIH](https://en.wikipedia.org/wiki/National_Institutes_of_Health) is a brilliant construct over the history of the United States, to really fund basic research and innovation, now clinical research and innovation
- And that has driven a large proportion of the innovation in the world
- For example, the science that supports pharmaceutical development comes out of US academic health science centers, largely speaking
- Then you have US-based pharmaceutical companies that develop 75, 80% of the world’s pharmaceuticals

***It is a unique feature of this country that we have chosen to make that investment for the rest of the world***

- It’s no different than the choice we seem to have made in defense

**Comparing the US investment in healthcare innovation to its investment in defense**

*An example of how we greatly subsidize defense for the world, but we got something out of it*

- Post-World War II, the [Bretton Woods Accord](https://en.wikipedia.org/wiki/Bretton_Woods_system): the US makes a deal with the rest of the world which effectively says

“*There’s a Cold War coming, and if you choose to be our ally, we will provide you security. Specifically through our navy, we will ensure that your ships can pass freely throughout this entire world. We will not plant a flag on your soil. We might use a military base. We’re not here to be conquerors. We’re not here to be emperors, but if you pick our side, we will assure your security*.”

- Now we are subsidizing drug costs for the rest of the world because we develop all the drugs
  - It’s not like we get different drugs than everybody else
  - Everybody else in the world gets the same drugs we developed
- Everywhere else in the world has price controls that lower the cost of that
- Peter’s analogy: in true economic fashion, it’s sort of like somebody is squeezing down on the tube of toothpaste
  - All that toothpaste is exploding in the United States with drug costs

**The question becomes, what are we getting for subsidizing the rest of the world’s drug price?**

*Look at this in the context of when it developed*

- You’re back to the question of: could anybody have predicted that we were going to go from 4%, 5% of GDP to 17?
- Could anybody have predicted that the drugs that were going to be developed and the advances in science would result in multiple therapies for common diseases and orphan diseases (which are rare diseases that might cost over a million dollars a year)
- When the system was set up, drug development at that time was new
  - In particular small molecule development
  - Then somewhere in the late ‘70s, early ‘80s, you had the advent of biologics
  - Which then grew into commercial products, especially in the mid ‘90s
  - It raised the bar on innovation pretty significantly
- Also everything that happened with respect to genetics opened up a whole broad range of therapeutics that didn’t really exist before
  - When you were just taking small molecules and, at scale, testing them against targets

***The cost of drug development went way up. Therefore, the price of drugs went way up (at least in the United States where you have a market)***

*Fast-forward to what people are thinking about today*

- You got [GLP drugs](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) that may have broad benefit for the population in one form or another
  - Why? Fundamentally, the drugs may be effective, but it’s because our health status is poor
  - In a country where the **health status** wasn’t so poor as it is in the United States (with chronic illness), the cost of those GLP drugs might not be projected to be so high, because less people would need them

**⇒** You have common drugs now for common conditions that are extraordinarily expensive

- There are alternatives that are much cheaper that might do a significant fraction (if not for many people, all of the job)
- [Metformin](https://en.wikipedia.org/wiki/Metformin) would be a simple generic example that might take care of many of those things for people at a price point that’s a thousandth of what…
- But nevertheless, you have this **innovation** and you have also a **culture** that’s obsessed with things like medical approaches to weight loss that has proven to be difficult to achieve through other means

**What’s the closest the US has come to trying to enforce some measure of price control in pharma in the US?**

- It’s important to understand that the [Medicare Modernization Act](https://en.wikipedia.org/wiki/Medicare_Prescription_Drug,_Improvement,_and_Modernization_Act) that was passed in circa 2000
- It forbade [HHS](https://en.wikipedia.org/wiki/United_States_Department_of_Health_and_Human_Services) from negotiating for drugs an entity as [CMS](https://en.wikipedia.org/wiki/Centers_for_Medicare_%26_Medicaid_Services) ‒ we legislated that
  - We gave away negotiating power
- The [Inflation Reduction Act](https://en.wikipedia.org/wiki/Inflation_Reduction_Act) (which was passed in the Biden administration) has cracked that door open a bit for negotiation because the dynamics of drug pricing

Peter asks, “*Just go back to 2000. Did the US government, at least for Medicare, say, ‘We will resign the right to ever negotiate’?*”

- Explicitly

*Was that a concession to pharma to get something else?*

- It came about in the lobby
- Saum doesn’t know the details
- It was an absolute direct concession that forbade HHS from negotiating
- There were a whole set of other things that were part of the Medicare Modernization Act
  - Like Medicare Advantage was created and scaled up, which created a way to potentially have managed care maybe manage the utilization of drugs and therefore maybe curb the expenditures
  - Create formularies that might encourage people to use generics rather than branded drugs if they were equivalent
  - There were other mechanisms put in place to try to control what people did understand as rising drug costs
- Drug costs have just risen more substantially since then
- Again, Saum goes back to context **at the time**, what should have been well-intended
  - What were the unpredictable consequences in some ways?

Peter points out that the cynic is going to say, “*Saum, that sounds to me like pharma had better lobbyists than anybody else.*”

- We live in a political system in which our representatives that we elect vote for us, and they’re subject to lobbying (that’s the nature)
- You would hope that that would be superseded by good policy decisions at some point in time
- Saum is not saying the Medicare Modernization Act wasn’t a good policy decision, but he doesn’t think what would happen was a predicted effect

*Cracking that door open is good*

- We get into these philosophical debates about we’re a free market economy
- The government should not be engaged in price controls
- Think about this: **doctors are price takers** from Medicare
  - Medicare sets their reimbursement, it’s **price control**
  - Peter adds that they’re price takers from private insurance for the most part
- Hospitals take Medicare prices as they’re given

*So Medicare is a* [*monopsonist*](https://www.investopedia.com/terms/m/monopsony.asp) *at the end of the day*

- They’ve applied it to doctors and to hospitals and other infrastructure-based care where they set the prices based upon their purchasing power

***It just hasn’t happened yet on the drug side***

**The debate is how do you do that in a way that doesn’t deter innovation?**

- Is there a sharing with the rest of the world that needs to happen?
- How do you do it in a way where if it’s just the US, it doesn’t deter innovation?
- Because that innovation has been incredibly beneficial to us in a number of different ways

***We want to leave enough of a return that actually the innovation won’t stop and start to take advantage of some of that purchasing power***

- That’s going to be an ongoing policy debate now that that door has been cracked open
- Drug prices are on the radar screens across both sides of the political aisle
- The industry will evolve and we’ll see how that goes

## How misaligned incentives have driven up drug prices in the US [1:05:00]

- We’re spending $4 trillion a year on healthcare, and ***15% of that is administration*** [that’s $600 billion]
- That’s something that exists virtually nowhere else
- Of the 85% of that $4 trillion that’s not administration, roughly a ⅓ of that is drugs and devices [$1.1 trillion]
  - More drugs than devices

***Drugs are a really, really, really expensive part of the US healthcare system***

**⇒** It also should be patently clear to anybody listening to us right now that we in this country are singularly paying infinitely more for every given drug than our peers are elsewhere for the exact same drug

**Let us now talk about the elephant in the room, the blessed** [**PBM**](https://en.wikipedia.org/wiki/Pharmacy_benefit_management)

- There are 2 issues: what do they do, and how effective are they?
- Is that vertical integration helpful or not helpful to the system?
- PBMs in essence are organizations that formed as intermediaries between pharma companies, insurers and pharmacies (where you get much of your medication) in order to help manage an increasingly large complexity of drugs
- Today there are probably 15,000 pharmaceuticals available

*The PBMs were designed to do a few things*

- Understand the market for those drugs
- Make formularies that were either broad or restrictive
- Manage benefit plans for employers who were looking to have preferred pricing on certain drugs versus other drugs

***They were created to manage expenditures on drugs and choice***

- We’ve got a lot of expenditure here in the drug arena
- The choices are complex
- The number of drugs has gone up, 15,000 or 16,000
- We need entities that help people make more informed decisions
  - At scale through employers or insurers
  - At the retail pharmacy level when individuals are going to fill prescriptions
  - Which includes things like generic substitution and things of that nature, when that’s appropriate and is allowed

*It created a complex payment system*

- It used to be that you buy a drug and the money goes to the pharma company from the pharmacy/ hospital (a direct interaction)
- The PBMs came in the middle

*When did they show up?*

- Forms of PBMs showed up in the ‘80s
- The growth of PBMs ahs been in the last 20, 25 years

*That has really has taken off recently for reasons that we’ll get into about their ownership structure*

- Which has brought more scrutiny to them than used to be there
- You’ve created a system in which now money is flowing less directly in many cases through the PBMs
- The pharma companies may sell product, but depending on what the PBM is doing in terms of committing market share to the pharma company, the PBM may earn a rebate
  - So you have a rebate that the PBM can earn
- The PBM may share that rebate with the insurance company or the employer who’s signing up for that PBM service

***So you have this new flow of dollars***

- Again, the idea behind this was to have better formularies, better understanding, allow people to have choice
  - Do you want a broad formulary?
  - Do you want a narrow formulary?
- Of course, incentives are incentives and part of what’s happened is that with a **rebate structure**, you can imagine incentives can exist for higher price product to move through a PBM and pass through, and some of that being offset with rebates on both ends

Peter adds, “*This is the classic example of…’Show me how a man gets paid and I’ll tell you exactly how he’s going to act.’”*

- The CEO of a major pharma company shared with Peter that he wanted to price one of his drugs at a low level
  - He wanted to undercut similar products on the market and come in at a lower price
- The PBMs flatly told him, “*We will not put your drug on the formulary until you triple the price. Don’t worry, we will make it up to you with a rebate.*”

**How is this legal? How do these things exist?**

- Well-intended, reasonably constructed structures that might’ve been effective in one setting but as things have changed, become less successful in this setting
- And economic incentives can sometimes change to drive behaviors like what Peter described
  - Saum hopes that’s not the norm

Peter continues, “*Even if it’s not as overt as a situation like that, subconsciously what we’ve done is removed any incentive for a drug company to be concerned with the sticker value of the price of their drug.*”

- The sticker price of their drug is a meaningless entity because of these machinations and payments that you’ve outlined where rebates and kickbacks completely change the economics
- Again, the system was so opaque to begin with
- Earlier Saum outlined this idea where we’re so uncoupled from our decisions
  - Not just as patients, as doctors, we have no earthly clue what a drug costs when we prescribe it
  - If Peter is trying to decide to write somebody for [rosuvastatin](https://en.wikipedia.org/wiki/Rosuvastatin) versus [atorvastatin](https://en.wikipedia.org/wiki/Atorvastatin), it couldn’t possibly enter his stream of consciousness why one of those might be 10x more than the other
- And yet we continue to just add unnecessary cost to a system

## The cost of innovation and choice, and the sustainability of the current healthcare cost expenditures in the US in the face of a shrinking workforce and aging population [1:11:30]

**Fundamental questions around innovation**

- Do we reward the innovation of a statin itself as the innovation, or do we reward the “me too’s” that come after it?
  - Which sometimes grow to be larger than the original statin
- Sometimes they’re better: [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) is better than [semaglutide](https://en.wikipedia.org/wiki/Semaglutide)
- They could be better, but how do we reward that innovation?
- What happens oftentimes is a floor is set in terms of the reward for the initial innovation
- As things get better, rather than competition with more molecules driving price down, it often drives price up because the market moves to the better and better product
- This gets back to supply-side intervention in other countries

***Peter never thought of it that way, which is how much they throttle supply in a system where demand could be unlimited and they have no control over demand***

- In some countries, because 90% of the benefit is accrued with [simvastatin](https://en.wikipedia.org/wiki/Simvastatin) (one of the original drugs), they’re not going to prescribe [atorvastatin](https://en.wikipedia.org/wiki/Atorvastatin) or [rosuvastatin](https://en.wikipedia.org/wiki/Rosuvastatin)
- So there’s a limit and you have to qualify with certain criteria that are stringent to get to that more expensive [drug] for the incremental 10% benefit

*We don’t work that way in this country*

- Physician choice around physician decision-making around those choices
- ***We’ve made the decision that we want to be able to afford that type of choice for the incrementally better drugs***
  - Sometimes better from a side effect profile standpoint
  - It can drive some of these decisions
- We’ve made that decision on an individual basis rather than a population basis

**⇒** The point that we’re talking about today is: it’s getting expensive

Saum explains, “*It’s getting expensive to the point where 17%, 18%, approaching 20% of the GDP may be okay, but the next 50 to 75 years, if that grows to 35% of the US economy, I think then you have some very serious arguments about how sustainable is that if the US economy doesn’t grow as rapidly as it has been growing*.”

**Peter heard recently** [**Paul Tudor Jones**](https://en.wikipedia.org/wiki/Paul_Tudor_Jones)[**speaking**](https://www.cnbc.com/2024/10/22/paul-tudor-jones-says-market-reckoning-coming-after-election-on-spending-we-are-going-to-be-broke.html) **with** [**Andrew Ross Sorkin**](https://en.wikipedia.org/wiki/Andrew_Ross_Sorkin) **put it into simple terms for why there was no rational argument why anybody should buy a US Treasury**

- Imagine I have $700,000 of debt
- You’ve lent me $700,000
- My income is $100,000 a year
- So what does that mean?
- He’s taking that from $35 trillion of debt currently and $5 trillion of tax revenue
- So my income is one-seventh my debt
- I’m going to continue to assume $2 trillion of debt a year in perpetuity
- And I’m saying to you (the US bond holder), the person who’s going to buy a 30 year treasury:
  - I have $700,000 of debt; I make a hundred grand a year
  - I want you to lend me $40 grand a year for the next 30 years and I promise you at the end of 30 years I’m going to pay it all back
- What do you have to believe for that to be true?
  - You really have to believe I’m going to have a remarkable growth of income or a remarkable reduction of cost somewhere along the lines
  - Or a devaluation of the currency
    - To inflate my way out of this thing
- None of  those things are desirable

**When you say healthcare costs over the next 2 decades could potentially go from 20% [of GDP] to a third, how in the world could we imagine that the other costs contract to accommodate that?**

- That’s the issue, which is that ultimately that’s a very difficult proposition to actually get your head around and believe
- In particular, we should get into the outcomes in the US to explain what we’re getting for all those dollars
- It’s very difficult to fathom expenditures getting to that level
- Now, one optimistic point of view on healthcare expenditure growth out there is that if you just look at the aging curve of the population, in particular the boomers and how they’re growing and even with increasing lifespan, the aging of the population in the US peaks at about 2032-ish timeframe
- You can look at different projections.

**⇒** In the next 8 years, we’re going to reach the peak of aging

- Aging meaning the number of people will grow every year that enter the above 65 Medicare world, and that number will peak and then will start to come down

**Optimism and challenges**

- If at the same time the consciousness and awareness of just basic interventions in health status can improve health status even a little bit from a chronic condition standpoint
  - That’s not going to be a one year or two year phenomenon, it takes a decade

***Those 2 could together make a big difference in US healthcare cost expenditures***

- The challenge in terms of what’s happening on the other side, especially in this context of debate around immigration, is we’re not **growing the population of people under 65** who generate the economic productivity to fund the system to get to 2032
- If you go back a number of years like the ‘80s and you look at the number of people pre-Medicare (40 to 65 years old) to Medicare: it was 2x the population (2x paying into)
  - Roughly the highest economic productivity is [from age] 40-65
- That number (the generators of economic activity) is trending towards 1.0 by the time we hit 2032
- Economists will get into this discussion of one of the reasons the US can afford to spend more on healthcare is we tend to work longer than much of the rest of the developed world
  - People working into their low 70s
  - So we generate more economic wealth to subsidize this healthcare system and other things that we may want to subsidize in the country

***That drop from 2 to 1 is significant and that’s happening at the same time that we continue to have this aging. So while it’s interesting to think 20 years out, Saum thinks for the next 10 years, we’ve got a problem***

- We’ve got expenditures that we know will grow because of the continued aging
  - The demographics are clear
- And we have a reduction
- The only way to fill that is of course to have the US economy still be an attractive place for immigrants to come and work of all types at all levels of work in order to fill that demographic hole

***We’ve got to get our head around that problem: who would’ve thought immigration is related to healthcare?***

**In this election, people are talking more about immigration than healthcare**

- Actually, it’s relevant to healthcare because healthcare is such a large part of the economy
- Everything comes back to it in the end when you think about it at a macroeconomic level

## Health outcomes: why life expectancy is lower in the US despite excelling at extending lifespan beyond 70 [1:18:45]

**Life expectancy**

- The most important context to consider here is that whether you look over the last 50 to 75 years, we’ve used 1950 as a marker or 100 years

**⇒** Life expectancy has improved remarkably

- A lot of that has to do with infectious disease and other things
- So when we say our **life expectancies in the US are paltry**, what we’re really asking is, “*Why are we 3 years behind everybody else?*”
  - Especially when we’re spending 60-100% more

> “*Spending the most, we’re not getting the best out. And I think you make a really good point… somewhere between 60 and 75, the equations slip.*”‒ Saum Sutaria

*Somewhere between age 60 and 75, we go from dead last to first (and the lifespan is the best in the developed world)*

- Because the medical system we’ve created that optimizes for access, quality, sophistication, technology, the best drugs, flips
- It’s actually quite effective at creating longevity from that standpoint
- We can discuss whether the lifespan is improving with or without the healthspan

*What’s going on in the younger population?*

- 1 – **Infant mortality** is 2-3x times the rate that we see in the rest of the world
- Why? We have a higher rate of teen pregnancies
- There’s a higher rate of sexually transmitted diseases
- Drug and substance abuse issues that play into that
- And some of it goes back to this notion of access for care in the prenatal window (that’s really important)
- 2 – **Injuries and homicides**
- Broadly speaking, the rate of those in the US is significantly higher
- Homicides is 7x the rest of the developed world
- Some of that goes back to gun violence, that’s unique in the United States versus others
- If you look at this over a long period of time, some of the mortality in the younger generations had to do with wars
  - Put that aside is not something as relevant today
- **Drug and substance abuse issues** and just the flow of things like fentanyl and others that are creating a different generational impact of mortality is quite significant
- The penetration of things like **HIV and AIDS**, and even though that’s become a chronic disease over the last 25 years, it’s been a significant driver of mortality

***These features create excess mortality in the US, especially under the age of 65***

- When you combine that with the fact that our rates of **obesity** leading to things like **diabetes** and **heart disease** when you’re older are ***higher than the rest of the developed world***, you have these unique issues
- Plus you have a fundamental **health status issue** that we’re now recognizing costs the healthcare system money

Saum makes the point, “*Obesity and its consequences don’t just emerge when you have out of control diabetes 15, 20 years later. The expenditures, the lost productivity in the workplace, all of those things happen earlier.*”

***So when you put those two together, you have a health status problem, and they overcome and overwhelm the things we’re better at***

- Oddly enough, we’re better at getting our vaccinations, we’re better at cancer screening, we’re better at treating blood pressure and cholesterol in this country
  - Back to the pharmaceutical culture
- We smoke less significantly than other parts of the developed world

***But guess what? That’s being overwhelmed by these other factors in particular under the age of 65 or 70***

- The public health model has been effective in reducing mortality from infectious disease over the last 100 years

*For other conditions [obesity leading to things like diabetes and heart disease], public health and nutrition science has been ineffective*

- This isn’t an insurance coverage problem
  - We pretty much cover everybody other than undocumented today in the US
    - And in some states we’re even covering undocumented
  - Or people that choose not to get covered because there are options now for everybody
- This isn’t a system problem in many ways: the healthcare system can accommodate the illness

***It’s the question of what led up to the illness that we haven’t really fully dealt with in the country***

- There’s 2 societal issues, whether that be gun violence or poverty leading to bad access to prenatal care, injuries, etc., or the chronic diseases that seem to be more prevalent here

**How you fix that**

- It’s hard to change behavior

> “*If you really want to change trajectory, you really want to improve healthspan, it’s hard to change behavior*.”‒ Saum Sutaria

- More of that can get built into the background to **change the way people eat or change the way people engage in physical activity**
- This could mean designing cities where you have to walk to work the vast majority of time rather than drive like many European nations have done
  - Those interventions themselves must have some benefit because you’re seeing different outcomes between the countries and it overwhelms all these other factors

Saum reasons, “*I don’t know that the healthcare system as it stands today is going to solve our cost problem that’s driven by the factors I just described.*”

***Tinkering with the different parts of the system we might be able to affect cost is certainly not going to change materially our outcome problem***

- The outcome problem is a more fundamental problem

Peter remarks, “*There’s so much you’ve said there is pretty typical of your brilliance, which is you’ll say something for 10 straight minutes and at the end I’ll be like, ‘That’s a thesis that might’ve taken me a year to come up with.’*”

**Peter’s takeaway**

- The reason we’re in last place [for life expectancy] is because of the population under the age of 65
- Access to guns, a culture of violence
- Poor access to prenatal care relative to other developed nations is leading to a far higher degree of infant mortality
- Drugs
  - We have a fentanyl pipeline coming into this country, that’s an embarrassment
  - As a result, 100,000+ people a year are overdosing
- Other things not mentioned: greater mental health crises go hand in hand with all these things

Saum adds, “*The border is a healthcare issue. It just is. You can’t escape it. Everything ties back in one form or another to healthcare*.”

## Potential solutions and challenges to controlling drugs costs in the US while balancing choice and access and preserving innovation [1:26:15]

**What Peter really found interesting**

- Peter has talked about how our system is really good **medicine 2.0**
  - It’s really good at treating chronic problems and grinding out incremental years of life when you’re chronically ill
  - And that shines so much when you become a senior citizen

**⇒** Medicine 2.0 is how we leapfrog every other country between ages 60 to 75

*It begs the question, why can’t we have the best of both worlds?*

- These don’t have to be mutually exclusive
- You can preserve the latter, which is we have all of these remarkable pieces of technology and innovation and access and infrastructure and quality that give us that boost of life expectancy at the end

Peter proposes, “*Why don’t we increase the number of people that enter that seventh decade of life? Let’s increase that by 10% by applying better medicine 3.0 and access early in life.*”

- Peter thinks you would increase it by more than 10%

*Peter has always talked about 3 variables: quality, cost, and access*

**⇒** Saum made Peter realize that **choice** is a part of that as well, and that’s the part that is very American

- We shouldn’t be apologetic for it; it’s our culture
- We want the best and we want to be able to pick what we want

***That 4th variable puts even more pressure on the one that is unconstrained (cost)***

**We have said we want maximum quality, we want access, meaning when I want it, I want it now, and I want to choose where I go**

Peter explains, “*If I control those and I leave one to balloon, and that one is cost, away it goes.*”

- The other systems (discussed earlier) constrain costs as a capped resource
- Now you see what’s going to happen to the others, and that’s where we get into the supply-side throttle to lower access

***The choice the rest of the world has made: let’s eliminate choice and you’ll still get decent quality***

- Saum thinks choice fits in a broad framework of access
- If you have enough access points and they’re differentiated, that allows choice
- For example, there are probably 15,000 pharmaceuticals available today in one form or another ‒ there’s a lot of choice
  - We’ll do meniscectomies, we’ll do meniscus repair surgeries, we’ll do hip resurfacing, we’ll do hip replacements, we’ll do [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma), we’ll do anything and everything
- You can’t underestimate the power of choice

> “*This is the biggest buffet on the planet when it comes to healthcare.*”‒ Peter Attia

**Why is that?**

- We learned [the power of choice] in the ‘90s with **managed care** when it was quite constraining
- That system lowered healthcare inflation
- It only proved it for a short time because the backlash was so vicious against it
- Saum doesn’t think we can go back there ‒ they system has evolved to create more options and more choice
- Limited **supply-side constraints** at this stage are becoming part of the dialog
- Medicare sets prices for doctors and hospitals, and they will probably start doing so for certain drugs
- It’s purchasing power
- One can argue that in some ways is a form of supply-side constraint

**Moving forward, also consider the null choice**

- Which is to do nothing
- We now understand the system better but still choose to change nothing
- We want maximum choice, maximum access, maximum quality ‒ let cost be damned
- We can choose to revisit it in 5 years or once expenditures hits 25% of GDP

**Let’s put that aside and say that most people think we should have some ideas for how we can manage this**

- Medicare has made the hospital and the physician a price taker
- Shouldn’t it be able to do that to pharma

Peter adds, “*Let’s talk about what’s going to happen because now you just added one more squeeze on the toothpaste tube while you’re taking the cap off*.”

**If Europe and Canada and CMS force pharma to be price takers, what’s going to happen to drug prices that are outside of CMS and the US?**

- Saum advises that we avoid looking at extremes
- He doesn’t think the people who are talking about this in a rational way in terms of actual pricing are saying, “*Let’s bring it down to the average of the* [*OECD*](https://www.oecd.org/en.html#:~:text=The%20OECD%20(-,Organisation%20for%20Economic%20Co%2Doperation%20and%20Development,-)%20is%20a%20forum)*, etc. from where drugs are priced.*”

*The question is: are there ways to start to curb the inflation rate of price and actually rationalize some group purchasing capability?*

- The challenge with accepting the extremes is it will only fuel the discussion of innovation will stop, nothing will happen any further
  - And that’s not going to happen
- Peter agrees that someone will have to make a concession
  - And that somebody is the shareholder
- Innovation isn’t even happening at those companies anymore anyway
- Innovation is the biotech’s job at this point

Saum explains, “*That may be true in the short term, but the hallmark of American ingenuity is to take externalities.*”

- This is an externality that might be relevant
- Take that pressure, in that ecosystem, better models emerge
  - More efficient drug development will emerge
  - More efficient distribution mechanisms
  - More efficient sales and marketing, etc. will emerge

Peter asks, “*You’re saying the shareholders shouldn’t actually even be forced to suffer here?*”

- It’s always the case as companies have life cycles that shareholders succeed and at times suffer
- But the innovators come out the back end stronger and sometimes there are new entrants which change the game
- That’s the hallmark of the free market economy

**How do we reconcile that?**

- On the one hand, if drug development and distribution had to become more economical (we’re innovative enough to do that)
- At the same time, the whole reason we’re saying that has to happen is we must have some measure of price control in drugs
  - Which feels like a very anti-American thing

*Saum points out 2 issues*

- Remember we took all the time to describe the entire **complex pharma ecosystem**
  - It’s not just the Pharmacos
  - There are companies that do basic research
  - There are Pharmacos, there are PBMs, there are pharmacies, there’s insurance
  - By the way, the insurance companies own the biggest PBMs, so there’s a vertical integration point there that is important to understand
- 1 – When you talk about this in terms of Medicare purchasing drugs with their scale, it is absolutely the case that that can be done in a market-based way
- Walmart is one of the biggest retailers in the country
- Arguably, they have one of the best procurement functions based upon the scale of what they’re purchasing that gets them better pricing from their suppliers
- Auto manufacturers manage this in auto supplier parts suppliers

***It’s not un-American to use scale to drive better pricing in what you purchase, as long as that scale is not anti-competitive***

- It creates innovation across the entire value chain
- **Medicare** in this case, because it has become such a large source of expenditure in a private healthcare marketplace, behaving more like a primary buyer at scale is not anti-American
- How it gets implemented and how they do it could turn anti-American (or free market versus not)

***2 – Purchasing at scale is not an anti-American or anti-competitive concept***

**Do you think it is reasonable that Americans could expect to pay for drugs what their European and Canadian counterparts pay?**

- It would be very difficult to move in 1 move to that level of purchasing price given what the starting point is in the marketplace
- Saum doesn’t see how you could do that without really having a shock to the industry
- Let’s remember, around 80% of the pharmaceutical industry resides and generates profits in the U.S. as large employers
  - But not just large employers, large magnets for talent coming out of our universities
- We have to remember between them and their supply chain, they create a tremendous amount of innovation in this country that has advanced Health 2.0 because that’s the construct we have

***This has to be balanced ‒ the concept that a purchaser at scale can achieve better pricing***

Saum argues, “*The time for that legislation from the 2000s to be revisited is here*.”

- The [Inflation Reduction Act](https://en.wikipedia.org/wiki/Inflation_Reduction_Act) cracked the door on that for certain drugs, and we’ll see how that goes
- This is going to get mired in politics and lobbying and all kinds of things

**If you step back and look at the big picture of where healthcare expenditures are going**

- Look at just **pharmaceutical expenditures** rather than healthcare expenditures
- In addition to extraordinarily expensive drugs that have broad application like the [GLPs](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist), you have a broad range of orphan drugs that have been developed that
  - Orphan drugs, meaning for rare diseases for very few people, sometimes miraculous benefit for them at extraordinarily high price

Saum explains, “*It goes back to what you said about we want choice and access, and we value saving, as Americans, that life (more than what other countries may do in not saving that life) and looking at it societally*.”

**3 – Look at the pipeline of drugs for the next 10 years**

- Look at the [PDUFA](https://www.fda.gov/about-fda/fda-track-agency-wide-program-performance/fda-track-prescription-drug-user-fee-act-pdufa-performance) list at the FDA
- The number of unique, biologic, infusible drugs in particular for autoimmune disease and cancer that are slated to go through the process and get approved
  - Not having seen the data, it’s hard to know whether they’ll transform the care of those diseases or marginally improve them
  - But if they get approved, they’ll be doing some benefit

***This will create another massive explosion of drug costs here***

Saum explains, “*The proportion [of healthcare expenditure] that’s going to hospitals and doctors relative to drugs if you look out over the next decade is poised to change again based upon the pipelines*.”

- Meaning the ⅓ that’s currently drugs is going to go up relative to the rest of the pie
- That’s also going to widen the gap between us and the rest of the world

**⇒** The current insurance model may not be designed to accommodate that cost without passing it back to employers and Medicare

> “*There’s going to be a question again, what are we going to cover, what are we not going to cover?*”‒ Saum Sutaria

**The economics of rising healthcare costs**

- The way that healthcare costs are rising, we’re being pushed to ask the supply-side questions that the rest of the world has already asked and answered
- It’s hard because of what we’ve talked about
  - We don’t want to give up choice and access in the process of grappling with those decisions
- For other countries, when new drugs come online, it’s easy for them: they have an established framework.
  - They have a dollar amount
  - The citizens are used to that established framework
- Here, we haven’t established the framework

Saum points out, “*This goes to the point of it’s not obvious that we have national health goals. A different topic, and I know that gets a little bit up in the sky a bit*.”

- We’re at a point where what we spend and what we get for what we spend is really, really good in some ways
- Obviously, not so good in other ways when you look at some of the outcomes
- But many of those outcomes are not driven by the healthcare system as we’ve talked about

*The question is, where are we going to put our incremental dollars?*

- Because the incremental dollars going straight into the current system, which everybody’s a participant in, that’s going to be necessary just because the population’s aging

**⇒** Fact of life, we’re going to have more demand for roughly the next decade

- Are we going to do that at the exclusion of resources into these other things?
- In Peter’s language, this impacts healthspan
- In Saum’s language, it impacts the 2 things which sit in the background that seem to be different than the rest of the world
  - Which is just basic nutrition and basic physical activity
  - That seems to be the major differences in how the U.S. works versus others
  - Some of it because of geography, some of it because of our obsession with driving cars, and whatever the case may be
- It’s not clear how we’re going to approach that over the next decade because we don’t have a choice but to spend for the people that are going to continue aging in

***After 2032, 2033, if the pressure on the aging portion reduces, we may have some choices, but we’ve got to get there first***

## Balancing GLP-1 drug innovation with affordability and healthcare spending sustainability [1:40:00]

**The impact and rising prevalence of obesity and type 2 diabetes**

Peter adds, “*While the aging pressure might be taking a little bit of air out of the balloon, it’s hard for me to imagine that it’s taking more air out of the balloon than that which is being put in with the rising burden of obesity and type 2 diabetes.*”

- Since the 70’s, the prevalence of diabetes or obesity is up 3, 4-fold
  - Obesity maybe
  - In the early 70s, type 2 diabetes was 1% and today it’s 12-15% (conservatively, a log-fold increase over the last 50 years)
- We’ve talked about it’s a generational failure of nutritional science to really understand what creates obesity in its sequelae

**We have** [**GLP-1 agonists**](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) **now that seem pretty remarkable**

- They are doing something we’ve never seen before: simultaneously delivering the best efficacy we’ve ever seen coupled with what appears to be remarkable safety
- The problem is they cost so much money
- Peter is reading on the one hand, the “bull case” that says this is going to change the world
  - We’re finally going to address the burden of obesity and type 2 diabetes and metabolic disease with these drugs
- Now all we got to do is give these drugs to everybody
- The “bear case” says that might be medically true, but economically if you run the math, we’re going to take a system on the verge of bankruptcy and bankrupt it if we have to rely on those drugs
- Saum agrees that these drugs are very effective
- He is concerned about muscle loss, particularly for elderly
  - A hip fracture has a very high degree of mortality

*If you look at this from a crass economic point of view*

- Remember, what’s the fundamental problem we have in terms of generating the wealth to pay for the system is that we’ve moved from a period where we had twice the number of economically productive people from 40 to 65 and above to now the ratio approaching one-to-one?
- If the idea is to improve health status, the best application of these drugs would be to improve economic productivity to support the system

***Applying them to people who could still work, not the people over age 65***

- Not that people can’t work over 65, but generally if you take that as a mindset of a period of retirement
- Peter doesn’t know the $ numbers, but let’s assume the drug costs $15,000 a year
- You’re saying you have to get a multiple of $15,000 a year of productivity out of it from the individual who’s now more able to work because their knee doesn’t hurt as much, their back doesn’t hurt as much due to the sequelae of obesity
- The math is looking at it from the perspective of today’s conversation around the cost of the U.S. healthcare system and how it interacts with the rest of the U.S. healthcare economy
- Over 65, arguably you may reduce the burden of disease, but you may increase longevity, which as we know, creates additional costs over time because it’s unknown whether you can stay on these drugs or whether people will stay on the drugs above 70, 80, into their 90s
  - Are you just delaying spending?
  - We don’t know
- When you withdraw these drugs, there is a negative effect
  - How persistent that is and how it will change over time (with new drugs), we’ll find out

**Saum goes back to the notion that it’s fundamentally not the right answer to wish that nobody innovated these drugs**

- That’s crazy
- Again, you can get into what it costs, and who paid for it, and who is paying for it, given the price differences between here and the rest of the world
- Saum’s personal view is that the prices for these drugs are too high
- He also believes that they won’t stay this high as the penetration grows across newer and newer indications in the population

**Will market forces act on the price of GLP-1 drugs?**

Peter asks, “*Even though, as you pointed out earlier, the ‘me-too train’ on this class of drugs is so long I can’t see the caboose at this point.*”

- When you actually look at the pipeline of GLP, GIP, glucagon, and other incretins out there, we’ve got 25 of these things in the pipeline, and will it simply be, if we go back into the American ethos of choice, quality, best, best, best, are they just always going to be priced so high?
- Maybe you’re right. Maybe semaglutide trades at a discount, and nobody wants it because that’s so 2020

Saum thinks, “*The reality is that because they’re so visible, they have ended up generating a lot of political attention.  I think this goes back to a lot of things in the free market culture that we live in, which is we have wide operating parameters in a free market, but at times when things go outside of those parameters, it’s not entirely a free market.*”

- It’s a wide, parameter-free market
- When things go outside of those parameters, people take notice, and that leaves organizations with the choice
- Do they proactively move themselves back into some acceptable parameters, or do they wait for somebody to do it to them?
- The U.S. government, like any government, does have a history of moving things back into reasonable parameters
- There’s no such thing as a 100% free market economy from that standpoint, especially when we’ve described our own healthcare system as being somewhat free market and choice-driven

***But the economic flows essentially shield the consumer from the actual cost of the care that they’re consuming, meaning the insurance scheme and other things***

- This is a difficult problem to solve
- Saum suspects this will come back into some reasonable parameters

## Reducing healthcare spending: complexities, trade offs, and implications of making needed cuts to healthcare expenditures [1:46:45]

**Peter lists out the players in the system**

- The government, the employers, the payers ‒ he lumps them together as “the consumer”
- The medical system includes: hospital ambulatory center, physicians, the staff, the delivery system of healthcare
- Pharma
- He doesn’t really know where to put [PBM](https://en.wikipedia.org/wiki/Pharmacy_benefit_management)
  - They’re owned by the payers

*If we were somehow given the ability to do anything we wanted, and we said we want to keep quality essentially where it is, maybe restrict choice a tiny bit, leave access where it is, but we want to shrink cost by 25%, is that metaphysically possible?*

*If so, how does that list of participants play a role in that?*

- Saum thinks 25% is a big number (Peter agrees, it’s a huge contraction)
- It’s not going to be an overnight 25% reduction, which by the way
- Let’s just make sure people understand this: a 25% reduction in our healthcare spend would still have us being the most expensive country of healthcare in the world
  - We’re not even getting to cost parity with other developed nations
- Peter is just thinking he’s like to get it closer to $3 trillion than $4 trillion

Saum points out, “*The concept of absolute, absolute cost reduction is very different than bending the trend.*”

- The other way to ask the question longer term is: **can healthcare inflation mimic GDP inflation as opposed to being 2% faster, or could it fall below it?**
- Just getting it to that level of being at the same level of GDP inflation would be an enormous move and curbing of the healthcare expenditures

**Downsides to cutting 25%**

- The first thing is the #1 deterrent to an absolute cut of 25% out of the system is the extraordinarily negative shock on the economy of that type of job loss

**⇒** You cannot do this without cutting jobs

- The U.S. actually spends less on infrastructure (buildings and whatnot) as a proportion in healthcare services than many other countries
- The people aspect of this, both the number of jobs and also the fact that our doctors, nurses, etc. are on a real wage basis paid higher than in other countries
- The 2 of those together and other healthcare workers, they contribute to the gap

*The administrative side is the biggest gap*

- To adjudicate claims and all that is mostly a people-based system

Peter asks, “*Why isn’t AI doing that some?*”

- Increasingly it is doing that
- It’s being used by those who have more exposure to sophisticated scale businesses that work in the revenue cycle or the insurers
- It’s the poster child indication for more automation that requires controls
- AI is new, and usually government regulation doesn’t catch up as quickly as the technology moves
- Look at the last just 7 days
  - You have an article in [ProPublica](https://www.propublica.org/article/evicore-health-insurance-denials-cigna-unitedhealthcare-aetna-prior-authorizations) that talked about a business that is using AI and denying claims at an extraordinary rate because of the AI algorithms that are built in

**Are problems using AI just due to bad training?**

- It’s a question of how the system is being used today
- Saum doesn’t think the system was originally created to do that most likely
- There is a balance between cost management and denying people what they need on an indications basis
- He thinks about the organizations in the ecosystem as starting with good intentions, but things can get away from people
- If you read what’s in there and it’s true, it’s gotten out of hand

***Many doctors might feel that issues with pre-authorization and denials have gotten out of hand***

*On the flip side*

- You had a major insurance company come out and say that coding is getting aggressive
- That’s the provider side that maybe is pushing the envelope in a way that they see all the data and all the systems, and they’re seeing something
- Saum doesn’t know how true it is any more than he knows how true this other one is

**⇒** Checks and balances in the system when you have a private system are required

***AI can either be an accelerant to reducing cost and being more efficient and effective or if not controlled, could take one side or the other and move them in a direction that actually have negative consequences, over-coding or under-authorization of what people need as an example***

- We have to work better as an industry to actually get the right balance here, and that’s why there’s a lot of attention to this right now because the balance is off, and you can’t unilaterally blame one side or the other from that perspective

**On the administrative cost side, it’s all people**

- It’s built on a system that has gotten infinitely more complex in terms of paying and submitting and getting paid for claims
  - Both with government and with private insurance and a whole bunch of other administrivia
  - That does have an opportunity to be fixed
- At this point, collaboration between the 2 sides doesn’t seem as high

***Technology has the potential of reducing that cost, but it is at the expense of job loss if it happens***

**Peter’s takeaway ‒** ***we always hear administration and think that’s garbage that we can cut, but the truth of it is that administration is the price we pay to have the choice we have***

- We couldn’t have the environment of choice if we didn’t have the administration to adjudicate
- Saum thinks it doesn’t have to be as large, but there would have to be some administration
- Everybody else has administration, it’s just sitting in their government
  - And it’s 1 entity rather than 50 entities
  - It also limits choice by just saying there’s not going to be a line-by-line adjudication of this
    - It is what it is
    - Here are your 3 drugs

**The other 3 components of spending are all somewhat people-based**

- The profits of the 3 businesses are very different

**How to cut costs**

> “*If you wanted to absolutely cut costs, you’re talking about supply-side intervention and price restriction or caps*.”‒ Saum Sutaria

- Some states have tried inflation caps: we are not going to go up more than 3-4% per year
- There has been no discussion of cutting 25% out of the healthcare system, again because it would be catastrophic in terms of access and other things
- That’s not to say that we didn’t wish we ended up at $3 trillion rather than $4 trillion if you look back 50 to 75 years, but we’re not there

**Why hasn’t this been a higher priority?**

- Because the economy has done so well

**⇒** One of the important things that’s critical is the U.S. economy has outperformed the rest of the world and the rest of developed countries

- And we’ve done it despite the more rapid expansion of healthcare costs than any other country
- Arguably, an economist would say that as healthcare as a percentage of GDP and as a percent of expenditures … would’ve materially suppressed wages
  - Remember we talked at the very beginning about how much the consumer spends, employer spends …
- If it has suppressed wages because money has gone into that with this tax incentive, has that actually made in some ways the U.S. economy more competitive with wages that have been somewhat suppressed
  - Which makes the American worker more competitive for various types of things that have a global labor footprint rather than just domestic?
- Saum doesn’t think it’s a given yet that healthcare costs on a net basis are increasing to where they have have been a negative for the U.S. economy

**Facts are hard to escape from**

- Fact: the U.S. economy is stronger and has grown more than other developed countries
- Fact: the expenditure rate in healthcare is higher
- Put aside outcomes for a second
- Our access and choice (which we prioritize) are better
- In fact, the diversity of what the U.S. workforce is doing today is probably more than it was a decade ago
  - There’s more manufacturing return, things like that
  - Saum thinks wage suppression may play a role in that
  - Again, you’d have to talk to an economist to really understand the quantitative effects there

Saum explains, “*I don’t think we’ve reached the point yet where these healthcare expenditures at a macroeconomic level have deterred the U.S. economy. I think we’re in this conversation because the question is, will it?*”

- Peter feels like it’s important to have these discussions before we’re driving off the cliff because nothing that we’re talking about can be fixed quickly
- He’s having this discussion because he wants to understand it, and he really hopes that people far smarter who are far more influential and far more important perches are putting as much thought into this as they are into whatever other important policy decisions are out there
- Because it’s very difficult to imagine that the private sector alone would solve this

## The role of government regulation, opportunities for cost savings, and more [1:56:15]

**The role of government in controlling healthcare costs**

- Saum would argue from his experience, healthcare is over-regulated by a lot
- But you have to give the government credit
  - When they work to create quality standards that people had to meet around things like sepsis
  - And to create safety standards around basic problems that you see in healthcare
  - ***Those regulations have improved the consistency of performance of the U.S. healthcare system***

Peter adds, “*If you have a* [*CMS*](https://en.wikipedia.org/wiki/Centers_for_Medicare_%26_Medicaid_Services)*-regulated operating room, you have a great operating room.*”

- Some fraction of what they’ve done has really, really helped, and you can’t argue with that

***Regulations that have been placed in other parts of the industry may be over-regulated, but you can’t discount the value of some of that regulation***

Peter asks, “*Where do you think the over-regulation is being counterproductive in healthcare?*”

**To Peter’s earlier question about what is value-based care**

- One of the things we get caught up in is the concept that our system, which is more of a **fee-for-service system** versus some kind of **value-based population health system**
- The interpretation is always that these other countries who spend less, they must be a population health system or a value-based care system because everybody’s in one insurance pool

Saum explains, “*What we’ve said in our discussion is, no, it’s a supply-side intervention. They just constrain and limit cost and infrastructure, whatever. They just decide what’s going to be accessible. That’s what drives the difference in their cost*.”

- There was a massive increase in healthcare expenditures in all of these countries too
  - They went from 4 to 11,12
  - Just not as big as ours
- The interventions that have fundamentally tried to change the workflow in healthcare, value-based care, most of them haven’t succeeded
- Saum argues that [Medicare Advantage](https://en.wikipedia.org/wiki/Medicare_Advantage) is the most important at-scale, value-based construct that has been somewhat successful
- But most of the innovation in and around that has not been very successful
- That doesn’t mean it’s not going to get there at some point

**⇒** Part of American ingenuity is trying and failing and trying and failing and trying and failing until you find a model that works

- And credit to those that are trying to do that, but it hasn’t succeeded

**Modernizing where we perform healthcare services into a lower-cost setting**

- That is direct cost savings
- With the [Hill-Burton Act](https://en.wikipedia.org/wiki/Hill%E2%80%93Burton_Act), we built all this infrastructure that is hospitals

***Some of that work is and could come out of hospitals into a lower-cost setting***

*The biggest example that has probably had the most impact on health status and colorectal cancer*

- If you go back 20 years, most **colonoscopies** were done in a hospital setting
- Sometimes people stayed overnight for them
- They moved into an outpatient setting: you’re in and out in 45 minutes plus recovery time from whatever anesthesia you have
- What happened is when it got into a more convenient, quick, high-service, manageable setting, more people in the U.S. started getting colonoscopies
  - Because it was easy and it had a screening benefit that’s enormous
- Saum credits the ambulatory surgery industry with preventing more colon cancers than any innovation in gastroenterology over the last 10-20 years because it’s now normal to get these

**Peter’s takeaway** ***‒ the implication is 2-fold, we’ve lowered the cost of each colonoscopy, but we’ve probably flattened or even raised the total cost because now more people are doing it***

- The total cost is probably much higher
- But the per-unit cost went way down, and more people got access
- And it prevented more cancers, which have lots of downstream costs

***The idea of moving things into lower-cost setting as appropriate is something we generally have to embrace as a way to manage the total cost, especially if the demand on hospitals is going to go up with the aging***

*The next version of that: knee and hip replacement surgery*

- It used to be a 4-day hospital stay
- Now, a lot of it is done on a same-day basis in the hospital, but you can also do it in an ambulatory surgery center in an hour
- You recover, and you walk out the same day, and you go home, and you do your PT at home, and other things

Peter asks, “*What is the difference there in the payer rate for those 2?*”

- The cost is about half (it’s significantly different)
- One of the interesting questions is why does the device not cost less in one setting or another, but the total payment is half?

## Hospital billing: costs, charges, complexities, and paths to simplification [2:01:15]

**Peter points out that this is another one of those great, great opacities in the healthcare system**

- I need a coronary artery bypass, and maybe throw in an aortic valve replacement
  - I’ve got aortic stenosis
- I go to the hospital that is within my PPO network to get that procedure done

*How do the economics of that work?*

- Does the hospital act as the single entity that bills the insurance company for everything, the surgeon’s professional fee, the hospital fee, the device fee for the valve, the drugs, the ICU stay? Is it bundled?

> “*Sometimes with choice comes complexity.*”‒ Saum Sutaria

- You’re getting into medical billing, which has some complexity
- At the simplest level, we break things into professional and technical expenses (he’ll define in a moment)
  - **Professional expenses** may be easier to understand: the surgeon who operates on you gets paid a fee to operate on you for their skill and training and other things, and that is their professional fee

Peter asks, “*Does the anesthesiologist also have a pro-fee in there?*”

- There are others involved in the surgery
- The anesthesiologist is trained to provide incredibly sophisticated anesthesia to go on heart bypass etc. gets paid a professional fee for that service, their personal fee for their time
- The **technical fee** is the fee for having the surgery in the building and setting called the hospital in an operating room
  - And in that setting, you may use the operating room
  - You may stay in a hospital bed for 3 days
  - You may be in the ICU for a day
  - You may be given a bunch of drugs and medications that are important for that
  - All of that cost goes into 1 bundle called the **hospital DRG**
- In general, the reimbursement system, which used to fragment all that stuff, has moved into an element of single reimbursement called a [DRG (diagnosis-related group)](https://en.wikipedia.org/wiki/Diagnosis-related_group)
  - This is a government innovation for Medicare that applies in much of the commercial world today
  - And you get paid a fee for all that stuff
  - We make our lives a little bit complex because we often send patients confusing bills that list everything that they had in that DRG and an individual price for each one of those things, even though at the end of the day, what’s going to get adjudicated is one payment very simple and 1 copay (if it even exists)
    - Which you can imagine as a patient who’s just coming out of and recovering from heart surgery, the last thing you want to see is a line item of 60 different things that you had done and what the cost of those were, especially when those costs bear no connection to what your insurance company or Medicare may have actually paid
  - It’s a complicated system

**What would be the single reimbursement on the three-vessel CABG AVR, aortic valve replacement?**

- It’s highly variable
- Medicare or somebody’s going to reimburse, let’s say, $20,000-something for that hospitalization

*How much of that is pro-fee? How much of that is technical fee?*

- The pro-fee is the hospital fee, and it could be $750 or $1,000, let’s say
  - What a physician gets paid to do that may be separate

Peter remarks, “*Isn’t that kind of amazing when people think about how low that is?*”

- The number could be higher with other insurance companies and whatnot, but the point is, it’s a big difference
- Peter thinks what people can’t fathom is that the cardiac surgeon who is operating on your heart might have a pro-fee of $2,000 (how low that is)
- It may or may not bundle seeing you in clinic
  - They’re taking care of you for 5 days in the hospital when you’re in the ICU and they’re on the floor
- Medicare might be below $2,000
- To use an economic term, the **utility** that people gain from interactions with different parts of the healthcare system vary greatly relative to the actual payments that are made
  - Another way to say this: this is why the American consumer trusts their doctor
  - Much more than the hospital or anybody else in the system
  - The least would be the insurance company
  - That doesn’t mean the economics flow that way within that, but ***the utility is somewhat disconnected from those payments***

*If we look at that $25,000 of technical fee to the hospital*

- Peter has seen some of these bills and he doesn’t know what to make of them because it seems like, the hospital collected a lot, but they’re getting ripped off on paying things
  - This is where you hear the stories of the little piece of 4 x 4 gauze costs $16
  - Tens of those that you’re going to go through in the case
  - It’s almost like you’re back in PBM land

***Saum thinks that’s a bit of a red herring and explains that you have cost and you have charge; further, he thinks this has almost no bearing on macro healthcare costs***

- The cost of the gauze is what the manufacturer who makes gauze charges the hospital to buy it
- It is not $16 for a piece of gauze
  - Of course it’s super cheap, as is a Tylenol pill or whatever
- The price is bundled into that group payment that Saum mentioned earlier
- So you’re not really getting paid that much more than cost for the thing

Saum explains, “*The charge is this artificial construct created by the way in which we bill, because of the way insurance billing is constructed, that results in the perennial $16 gauze or $4 Tylenol pill or whatever the case may be.*”

- Nobody’s being paid that amount
- It exists because every hospital by federal regulation is required to have a [chargemaster](https://en.wikipedia.org/wiki/Chargemaster)
  - So is every doctor’s office that has charges off of which the free market negotiates contracted rates and brings that $4 Tylenol down to 20 cents, or the $16 gauze down to whatever it is, cents

***This gets administrative costs: the system has evolved certain ways in which the administrative costs support nonsense like this, at the end of the day***

- Remember what Saum said about insurance, “*It’s not insurance in healthcare, it’s a discount card.*”
  - Meaning you’re getting the value of group purchasing so you buy things at a lower cost
- If you apply that in this setting, if you come into the hospital without insurance, you’re not getting that group discount
  - That’s the bargain made between insurers and providers, that you’re going to get a better deal (a discount card)

## How prioritizing access and choice increased expenditures: reviewing the impact of healthcare exchanges and the Affordable Care Act [2:08:00]

Saum explains, “*If you come in without insurance, you’re going to be exposed to the $4 Tylenol or the $16 gauze*.”

- The reality is, that’s what turns into something that we never really talked about: bad debt

**⇒** There’s a lot of healthcare that’s provided that has a charge associated with it, nobody ever pays: billions and billions of dollars

- Saum thinks it’s about $40 billion a year or more
- There’s also under-insurance where people don’t pay their portion of what they owe
- And again, with those kind of prices, you can understand some of that

**When Peter last looked at this** [**statistic**](https://www.businessinsider.com/personal-finance/credit-score/medical-bankruptcies)**, medical expenses were the leading cause of personal bankruptcy**

- Saum doesn’t know that for a fact, but the concept that medical expenses lead to medical debt and personal bankruptcy is another difficult topic within this area

**Why is anybody uninsured in 2024, 2025?**

- Thinking back to the [ACA](https://en.wikipedia.org/wiki/Affordable_Care_Act), maybe you’re uninsured because you made the risk calculation which is, “*Hey, insurance is going to cost me this many thousands of dollars a year. I’m young, I’m healthy. I don’t need it. In an ideal world, I wish I had some catastrophic coverage. Now lo and behold, I’m in the hospital… I’m getting charged four bucks for Tylenol, 16 bucks for gauze, and all of a sudden I’ve got a $250,000 bill, that if we weren’t playing with stupid Monopoly money would be $14,000 and I could manage that.*”
- That’s the problem
- What happens as a result is that it either goes to nothing because people don’t pay
- Or most organized healthcare systems have the equivalent of a compact with the uninsured that rapidly discounts that price often by 10-fold in order to adjudicate that
  - Saum thinks that’s very appropriate
- Yet you still have these unfortunate cases

> “*The healthcare system today, the insurance system today, the cost of drugs today, and the structure that’s been created works a lot better if you’re in the system, not out of the system.*”‒ Saum Sutaria

- Out of the system is uninsured

**With the Affordable Care Act, the uninsured rates have come way down because it expanded Medicaid**

- So the people who could qualify due to whatever percentage of the federal poverty level, employment has expanded, the job market’s been good, so more people have insurance through that
- We’ve already talked about Medicare is growing rapidly because of aging
- Medicaid has already hit 90 million people with that expansion

***Then there’s this gap where people don’t have insurance because their employers may be too small to offer insurance, or they don’t qualify for Medicaid because they make too much money***

**We created these things called the exchanges**

- What that is, is the way to take that market and socialize the risk away from individual risk to group risk and make it more affordable

**⇒** A lot of people have been covered through that

*Now, we had a bunch of legal debate*

- The idea was you would do that, and then you’d have this thing called the **individual mandate**, which meant you’re going to be forced to get into something, and that got legally challenged

Peter reasons, “*We can talk about whether or not that’s a fair thing… if you’re just putting on your risk hat, an individual mandate is essential because you cannot have adverse selection into your risk pool.*”

***And that requires an acceptance that there are many, many people who will sign up for insurance that won’t need it, and they’re subsidizing those that need it***

- The argument can be made, that’s true in Medicare already

Peter asks , “*Why do people not fight about individual mandates in car insurance?*”

- That’s Saum’s point: from the perspective of what we were trying to do as a society, the legal challenges that occurred to individual mandate (and ultimately disabled it) didn’t help the system
- Nevertheless, the exchanges have grown, and they’ve been more expensive than people thought

Peter asks, “*Because of the risk?*”

- A little bit because of the risk pool
- Some of it because of the pricing of those insurance products
- Some of it because of whether they look a little bit more like commercial insurance versus Medicaid

***There’s 2 flavors [of insurance] out there, a lot of complexity; but the fact is, they’ve created coverage and access for a lot of people***

- More importantly, they have created coverage and access for working class, generally voting American citizens
- And that means it’s a powerful group that has access to this insurance coverage
- For them, losing their subsidies becomes a real issue for everybody who’s in the environment that has to make decisions on this
- The uninsured are
  - 1  – Undocumented people that don’t have US citizenship or some legal ability to work here
  - 2 – People who just decide, “*Hey, I’m young and healthy. I don’t want to buy on this thing.*”
- Saum doesn’t know how many people fall into #2
  - It’s not a large number; probably somewhere in the millions

**Was the view that the ACA was not only going to address the problem of access, but that in doing so, it would reduce cost?**

- First of all, it’s a political name
- Peter would call it the “Access Care Act”
- Saum suggest the “Coverage Care Act”
- There were a lot of big ideas thrown about (mostly by academics and others) that some of the policies within the Affordable Care Act would include affordability and lower cost

*It didn’t end up happening that way, for a few reasons*

- People will point at each other about, “*Well, the legal challenges affected this*.”

***The reality is that it has increased expenditures because we know coverage at a group level that removes you from the direct exposure to the cost of care creates demand and higher expenditures***

- We saw that with Medicare
- It comes back to the American thing [discussed earlier]
- Most of these exchange products have generally good physicians and other choice associated with them
- Some are narrow networks
- Again, [when] you prioritize choice and access, the costs could be higher than one may have guessed

***On the other hand, they have been incredibly powerful tools to provide coverage***

- Because that was the purported goal of the act for those that didn’t have it when combined with Medicaid expansion
- Not all states have expanded Medicaid

**⇒** In aggregate, more people have been covered after the Affordable Care Act, and therefore expenditures also went up, which is what you would expect at a simple level

**We also talked about the fact that some of the value-based care constructs that they had haven’t been successful**

- CMS has spent more money in their Medicare innovation arm ([CMMI](https://en.wikipedia.org/wiki/Center_for_Medicare_and_Medicaid_Innovation)) in creating the constructs of innovation than they actually saved in the programs they launched
  - So it hasn’t really worked yet
- Again, American ingenuity, right ‒ you keep trying and failing, trying and failing, and maybe one day you’ll get it right

## Feasibility of a universal Medicare program, and what a real path to sustainable healthcare looks like [2:15:45]

**Has there been any credible proposal put forth to create a Medicare program that covers everyone?**

*What would be required to make that happen?*

- The 1st question would be: do you want the federal government covering everybody when the whole purpose of the employer-sponsored system is to have choice and to have access to different networks that you can pick from?
- Saum doesn’t know if a one-size-fits-all model would work
- 2nd is that if what we’ve talked about here today bears some degree of accuracy around what the drivers of healthcare costs are now and are going to be
  - It’s really about health status, chronic disease, aging, drug costs related to the chronic disease
  - Models of coverage is not what’s lacking today
  - From Saum’s perspective, this is the more important thing

***So Medicare for everybody is solving a problem we don’t have that much of anymore***

**What you would rather call that would be price controls**

- If your argument is you want to put them on Medicare because Medicare reimburses less than everybody else, then you should just call it a price control
- But then we’re moving to a **supply-side intervention**
  - We’re going to constrain everybody’s access and choice
  - The reimbursement is going to come down and the infrastructure will survive or not survive, and what’s left will be what you can access
- That’s a different choice because that’s what it would do: it would be a buy-down

**One thing that Saum hasn’t really talked about it that much is this system is built on a lot of cross subsidies**

- Healthy people in our model of insurance cross subsidize our fellow citizens who happen to be ill in some period of time
- In the same way, employer-sponsored insurance (which reimburses healthcare at a higher level than Medicare or Medicaid) overcomes the unit cost under reimbursement of government healthcare
- This goes back to the concept, the government already behaves as a monopsony here
- They under-reimburse
- What you get paid from Medicaid if you’re a doctor or Medicare may be below your cost, relative, it’s cross subsidized

Peter asks, “*So corporate profitability is subsidizing the government?*”

- 100%

***That cross subsidy creates this dynamic where you can’t have one go away without the other***

- That’s why Saum is so concerned about the notion that our number of 40 to 65-year-olds, relative to the people that are getting the benefit from government, that somewhat under-reimburses unit care of cost is going down
- The people generating the economic rents to cross subsidize the other side is going down

**⇒** What does that mean for our economy if healthcare expenditures are growing this quickly?

- That’s the essence of this discussion

**Saum points out that he hasn’t answered Peter’s question with any reasonable solution to how to cut 25%**

- You probably need somebody from totally outside the system to come up with an idea for that kind of cut

> “*I am much more optimistic about the notion that healthcare expenditure inflation could be reduced to a level that is somewhat closer to GDP growth.*”‒ Saum Sutaria

**Peter’s takeaway**

- We’ve made it this far
- If healthcare is 18% of GDP, as long as we make sure it never exceeds 18% of GDP
- Even though the absolute dollars will go from $4 to $4.5 to $5 trillion, we’re going to tolerate that because our economy is going to grow proportionately (not less)
- And that’s the price that the United States is willing to pay to be 1st in class for choice, access and quality

*Saum thinks that sounds a little fatalistic*

- His framing would be that we value quality, access, choice and innovation, and we’re willing to pay for it
- It has not deterred the US economy to date in terms of being not only the leading but the fastest growing economy

**In the US, we need to solve 2 things as a society**

- 1 – The burden of chronic illness and aging, and all of these factors that drive worse outcomes that really aren’t healthcare factors
- 2 – The infant mortality issues (discussed earlier
- 3 – The drug and drug access issues and the mortality associated with that
- 4 – Homicides, violence
- 5 – Injuries, etc.

***Working on those things, plus the chronic illness side from the medical perspective are not anymore about insurance or coverage or whatever. They’re about addressing those issues directly.***

Peter points out, “*Public health has been an abject failure when it comes to dealing with these things*.”

- Saum is not saying the solution is public health
- He thinks the success that the current model in public health had in infectious disease over the last 75 to 100 years hasn’t worked in this setting
- Even COVID is a good example of that
  - So much debate exists about what happened there
  - Why was the US mortality higher than most other developed countries in COVID?
- The most effective thing that happened during COVID was the development of the vaccines,
  - Which was again, US ingenuity, innovation and spread around the world in many, many ways

Saum explains, “*I think we have to rethink these models, and before we give them more funding, we need to make sure that they’re doing the right thing for us*.”

**If we can bring those things in line, I think we can make a difference**

- Saum comes back to something he learned from Peter: the background nutritional environment, if it changed, could make a big difference over a 10-year period
  - And if you add to that, incorporating a degree of physical activity
  - This isn’t about going from being sedentary to running marathons
  - It’s about [going from] being sedentary to some physical activity

***Improving nutrition and physical activity has a huge potential benefit on the types of healthcare costs that come from chronic illness***

- Those 2 things together, and addressing some of the US unique issues could bring healthcare expenditures in line with GDP growth pretty quickly
- But you have to have that goal over a 10-year period, and Saum is optimistic about that
  - If it’s a one or two or three-year goal, we will fail and give up before we try

*Anything that’s going to be done over a 10-year period has to be government-run*

- There’s no employer or individual who can subsidize something where the remuneration is that far out

Saum suggests, “*I think you have to start by having a discussion around, what’s our national health objective?*”

- We don’t have a national health objective right now
- Unless you just say by default, “*The national health objective is the ultimate in access and choice.*”
- And if that continues to be our objective, the system is designed to produce that

> “*We can have access and choice, and incrementally put dollars into these other things and make a difference to both, without radically cutting access and choice*.”‒ Saum Sutaria

- Short-term interest from all kinds of industry participants and public participants may run counter to that 10-year goal
- Go back to your point around what we did after World War II: it was a national goal to have an ecosystem of countries that stood for democracy and protected security around the world, and we were willing to invest in it
- This is a national problem, and so we got to rally around that

## The challenge of long-term care and the potential of innovation, like device-based therapies and AI, to improve health [2:23:15]

- In Peter’s preparation for this podcast, 1 of the things that stood out to him is 1 area where we actually spend less than the other developed nations
  - We’re spending about 2x what they are on everything else
- We spend less on long-term care

**Why are we spending less on long-term care?**

- Secondly, we haven’t talked about one specific disease that is also increasing in prevalence, which is [dementia](https://en.wikipedia.org/wiki/Dementia)
- Those two are pretty linked

*What do you have to say about that with respect to future costs?*

- Our biggest challenge in innovation for the next 20 years is the management and care of neurocognitive decline, whether you formally have dementia or not

**⇒** 1 thing is true, when you age, people live longer, they inevitably have neurocognitive decline and they require more care

- There are many positive aspects of the **culture** of family taking care of generations, and that being something that’s passed from generation to generation

***We spend less in institutionalized long-term care because a lot of that work is done by families***

- That’s also a burden
- As people live longer and the cost and complexity of their care as they decline gets higher, the cost of providing that care is not just the direct cost, but it’s lost wages and productivity in the economy as people
  - Often women come out of the workforce to take care of the elderly from that perspective

***This problem is not just a healthcare problem, it could become a macroeconomic problem based upon feeding the workforce and lost productivity***

*The 2nd reason this is a huge problem*

- Without getting too technical, it’s the issue of the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier)
- The traditional pharmaceutical model to care for these diseases may not work once there’s onset of disease because of the blood-brain barrier
- The concept there is that drugs which go into the body don’t get through effectively the barrier between the blood and the brain, to be able to treat brain diseases

***We need new forms of innovation, and this is where Saum thinks you will see the prominence of engineering-based solutions, rather than drug discovery-based solutions grow materially to help with these diseases***

- Think about what we do today with stimulation and neurostimulation in [Parkinson’s](https://en.wikipedia.org/wiki/Parkinson%27s_disease)
- That’s a device-based therapy
- The role of engineers in healthcare has an infinite future and upside for us because of neurological diseases

**We’ve got to pivot our model, our research, our funding to deal with this issue because we’re going to go from 65 million-ish people in Medicare today, to 90 million by the mid-2030s**

- Saum’s earlier point about the number of people pre-Medicare declining: that’s going to help finance the care for those people

*We need models for custodial care*

- Meaning where to take care of them and how, that isn’t a nursing home or long-term care (which is too expensive)
- You’ve got to make that job easier in the household
- And we need innovative engineering-based solutions that help improve their cognitive function to make them more self-sufficient
  - To deal with their dementia for a longer period of time so that they’re more self-sufficient and less dependent
- Solving that problem, is one of the grand frontiers in medicine over the next 10 to 20 years given the aging of the population

**⇒** Remember, we’re going to age up through 2032, 2033, but those people are then going to live 10, 15 years. This is a 25-year problem.

**On that thread of technology, how can AI help?**

*What are your broad-stroke thoughts on the role of technology in any of the variables we’ve talked about, with cost reduction being the elephant in the room?*

- If we look at the system today and what’s being developed in AI, **administrative cost** is the easiest and 1st application where you can actually see real cost reduction potential
- In the clinical realm, the **electronic medical record** has created a much more organized system of record
  - Which has been a massive industry expense
- But it hasn’t really fully translated to a system of engagement for all the stakeholders
- Saum argues that what it has created hasn’t really been transformative in improving the quality of care relative to other things
- And it certainly hasn’t improved access or choice

***Taking the foundation of the electronic medial record and building in the potential benefits of AI in better clinical care, better understanding of evidence-based medicine, that has potential***

*What Saum thinks will be interesting (and it remains to be seen) is do the traditional EMR participants or do new entrants build the AI that does that?*

- There’s a lot of work to be done in this area and it’s early
- The hype around the value it will have is seriously overblown in the near term
- But from a long-term perspective, conceptually, Saum is optimistic about the power of that tool to really improve care, not just administrative cost

**Closing thoughts and gratitude**

- **3 hours ago, they started talking and Peter honestly thinks he understands this better, and that’s a clear testament to Saum**
- Peter has talked a lot about his time at [McKinsey](https://www.mckinsey.com/) as a great chapter of his life
- When he left medicine, he didn’t know what he wanted to do
  - But he knew he didn’t want to do clinical medicine at the time
- What many probably don’t know is, Saum was single-handedly the person that plucked Peter out of Johns Hopkins and brought him out to San Francisco
- Saum along with [Hamid Samandari](https://biography.omicsonline.org/united-states-of-america/mckinsey-company/hamid-samandari-239037) were the 2 single most important mentors he had there
- Peter shares, “*I owe you such a debt, Saum, and it is such a pleasure to be sitting down with you today. I wouldn’t be where I am today without you. Your influence on me is hard to overstate.*”

Saum observes, “*The thing about you, from my perspective that I can’t say about virtually anybody else, is that what you have built has been purely based upon your intellectual curiosity, creativity, and drive to know the truth, as opposed to anything to do with your personal gain.*”

- He has known Peter from day 1 as always being driven by that intellectual curiosity, and that’s something he wishes more people had
- If there’s any benefit of this conversation somewhere out there in the audience, there’s another person like Peter who will hopefully solve these problems because they’re just as intellectually curious

Peter concludes, “*The single most optimistic thing I take away from this is, we might not have to slash the cost by something dramatic (like 25%) if we can enact the right combination of policies, technologies, perturbations, and behaviors and incentives that simply bend the cost curve towards GDP growth, we might actually be fine in the long run*.”

---

## Selected Links / Related Material

**News article about health insurance companies using AI to deny claims**: [Not Medically Necessary: Inside the Company Helping America’s Biggest Health Insurers Deny Coverage for Care](https://www.propublica.org/article/evicore-health-insurance-denials-cigna-unitedhealthcare-aetna-prior-authorizations) | T. Miller, P Rucker, D Armstrong, *ProPublica* (October 23, 2024) | [1:50:15]

---

## People Mentioned

- [Paul Tudor Jones](https://en.wikipedia.org/wiki/Paul_Tudor_Jones) (American billionaire hedge fund manager, conservationist, and philanthropist) [1:13:30]
- [Andrew Ross Sorkin](https://en.wikipedia.org/wiki/Andrew_Ross_Sorkin) (Financial columnist for *The New York Times* and a co-anchor of CNBC’s *Squawk Box*) [1:13:30]

---

![](https://peterattiamd.com/wp-content/uploads/2024/11/SaumSutaria.jpg)

##### Saum Sutaria, M.D.

Saum Sutaria earned a Bachelor’s degree in Molecular and Cellular Biology and also in Economics from the University of California, Berkeley. He earned a medical degree from the University of California, San Diego. He then completed postgraduate training in internal medicine, and had a focus in cardiovascular medicine at the University of California, San Francisco. Dr. Sutaria worked for nearly two decades at McKinsey & Company where he was a leader in healthcare and private equity practices, advising clients on strategic operational and financial matters. Currently, Dr. Sutaria is the Chairman of the Board and CEO of Tenet Healthcare. [[Tenet Health](https://investor.tenethealth.com/governance/person-details/default.aspx?ItemId=30f3fc46-815b-4e2b-9f36-9534f4cc5f28)]