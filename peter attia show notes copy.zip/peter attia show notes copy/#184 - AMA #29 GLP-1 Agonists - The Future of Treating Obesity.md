# #184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?

**Source:** [https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob discuss all things related to GLP-1 agonists—a class of drugs that are gaining popularity for the treatment of obesity. They cover the discovery of these peptides, their physiology, and what it is they do in their natural state. Next, Peter and Bob break down a recently published study which showed remarkable results for weight loss and other metabolic parameters using a once-weekly injection of the GLP-1 agonist drug semaglutide, also known as Ozempic, in overweight and obese patients. Finally, they compare results from the semaglutide study to results from various lifestyle interventions and give their take on the potential future of GLP-1 agonists.

Below is a sneak peek of the episode. If you’re a member, you can listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website [here](#fullnotes). If you are not a member, [subscribe now](https://peterattiamd.com/subscribe/) to gain immediate access to this full episode, our entire back catalog of AMA episodes, plus more great benefits!

## We discuss:

- Remarkable results of a recent study in overweight adults [2:15];
- Key background on insulin, glucagon and the incretin effect to appreciate the effects of semaglutide [4:00];
- What is GLP-1 and how does it work? [16:30];
- 2021 semaglutide study: remarkable results, side effects, and open questions [30:00];
- Semaglutide vs. lifestyle interventions: comparing results with semaglutide vs. lifestyle interventions alone [44:00];
- Closing thoughts and open questions on the therapeutic potential of semaglutide [47:30]; and
- More.

§

The Peter Attia Drive

GLP-1 Agonists - The Future of Treating Obesity?

§

## Show Notes

§

## Remarkable results of a recent study in overweight adults [2:15]

**This AMA centers around this paper**: [Once-Weekly Semaglutide in Adults with Overweight or Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183)

- The results in terms of weight reduction were “freaking remarkable”
- Questions were around this study:
  - Can you go over the findings of the study?
  - What are the implications?
  - Do we need a drug for obesity?
  - What the heck is semaglutide?
  - How does it compare to other drugs and diets?
    - For example, there are other drugs in this class, [liraglutide](https://www.drugs.com/mtm/liraglutide.html), that about six years ago showed also very promising results
- But you can’t really go deep on this paper without doing a little bit of background on what [GLP-1](https://www.drugs.com/mcf/glp-1-agonists-diabetes-drugs-and-weight-loss) is because this drug ([semaglutide](https://www.drugs.com/mtm/semaglutide.html)) is effectively just an analog of GLP-1

## Key background on insulin, glucagon and the incretin effect to appreciate the effects of semaglutide [4:00]

**This first discussion is a prologue to make sure that we understand** ***how semaglutide works***

- Looking through the lens of ‘what is an incretin?’, or ‘what is the incretin effect?’
- Only when you can measure insulin can you understand what the incretin effect is
- Effectively, it comes down to a bit of a mismatch between how oral and intravenous glucose are processed

*Taking a step back…***Insulin** and **glucagon** are two hormones that you have to really understand to get what incretins are and then by extension to appreciate what semaglutide is doing

*-What is insulin?*

- Insulin is secreted by beta cells in the pancreas
  - The pancreas has two broad functions: i) an endocrine function and ii) an exocrine function
    - Exocrine function is kind of the local digestive function
    - The endocrine function is the more systemic function
      - The release of insulin and glucagon from beta and alpha cells respectively fit into the endocrine portion of this
      - By mass, only 5% of the pancreas is really endocrine function is alpha and beta cells
    - The majority of the pancreatic mass is for the exocrine, the local digestive function.
- Beta cells secrete insulin
- Insulin really has pretty significant effects on muscle cells, fat cells and liver cells
  - Signals all of these tissues to take up glucose
  - Also tells the liver to stop making glucose
- The purpose of insulin is a signal of the fed state and it’s particularly sensitive of course to carbohydrate
  - So it’s saying when carbohydrates are abundant, we need to take glucose up into cells and we need to stop making more glucose
- One of the most important functions of the liver, in fact you could argue the function with which we would die the quickest is its ability to make glucose and put it into circulation
- It also regulates the output of glucagon

*-What is glucagon?*

- Glucagon is produced by alpha cells of the pancreas and it increases blood glucose via hepatic glucose production by stimulating glycogenolysis, so breaking glycogen into glucose and gluconeogenesis
- it also increases lipolysis and ketone production
- There’s a bit of an antagonistic relationship between these hormones and therefore when one goes up, it would regulate the other.

***How does all this fit into the incretin effect?***

![](https://peterattiamd.com/wp-content/uploads/2021/11/f1.-ama29-887x1024.png)

**Figure 1.** Contribution of the incretin hormones GIP and GLP-1 to the stimulation of insulin secretion. ([Nauck and Meier, 2018](https://pubmed.ncbi.nlm.nih.gov/29364588/))

*The upper graph:*

- The X axis show time in minutes—as all 3 graphs do
- On the Y axis, you’re seeing plasma glucose
- This is in response to both an oral and intravenous glucose load
- in the solid gray circles is the measured plasma glucose level following a glucose load
- This is done in picomole per liter which is equivalent to milligrams per deciliter
- So you’re looking at a normal glucose say in the 90s
- Following the ingestion of oral glucose, you see it goes up, but it peaks at about 60 minutes and then by three hours it’s effectively back to baseline.
- The intravenous glucose dose is delivered in what’s called an iso-glycaemic manner—meaning the IV of glucose is titrated to match the glycemic response

*The second figure (green figure),*

- This shows what happens to insulin under these two conditions
- Again, we’re sampling peripheral insulin
- In the first example, you see insulin goes up
  - This would be sort of what you would expect from an oral glucose tolerance test—so insulin peaks at about 90 minutes, returns to baseline in about three to four hours.
- But what’s really interesting here is when you look at the insulin response under the intravenous glucose administration, it’s a fraction of what is delivered or appreciated in the oral glucose administration
  - In fact, it almost looks like a flat line
- What explains that difference?
  - That difference, which is basically the shaded green area, is referred to as the **incretin effect**

*Looking at the red graph*

- You’re going to appreciate this same difference with respect to glucagon.
- In the case of the oral glucose administration, you’re seeing the solid dots—glucagon levels go down because as glucose becomes more available in the periphery, the pancreas will make less glucagon for the liver to respond to make less glucose
- Remember, glucagon is secreted by the pancreas as well and it acts primarily on the liver to regulate glucose output, glycogen breakdown, and glucose production
- And you can see with the oral glucose administration, the attenuation of glucagon is less than with the intravenous administration
- Again, that delta is referred to here as the **incretin effect**

***So, why does this happen? [10:45]***

- The study said that up to 70% of the insulin response after a meal can be due to the incretin effect
- The word incretin originally came from the pancreas secreting insulin—they called it secretin, which is secreting factor of the pancreas secreting something that’s lowering blood glucose
- Later they found these intestinal hormones that were playing a role in insulin secretion
- And so incretin is by definition the need in response to glucose—these incretin hormones actually stimulate insulin secretion
- As the oral glucose (or the food) goes through the stomach and then into the intestines, the intestines have cells that can essentially sense these incoming nutrients and responds to those incoming nutrients
- Not only is the pancreas responding, but the gut or the intestine is responding to the challenge in the case of the oral glucose
- If you didn’t know anything and you had to ask the question, how could this phenomenon be explained, **it would have to point to something happening in the gut**, presumably because that’s the obvious difference between something being delivered orally versus not

***What are these gut-driven hormones that could be playing a role?***

- One is called GIP, glucose-dependent insulinotropic polypeptide
  - They are secreted from cells in the gut called **K cells**
  - These are not cells that make up the majority of the gut, these are actually endocrine cells and they’re referred to as enteroendocrine cells
  - They’re very specialized epithelial cells that probably represent less than 1% of the entire gut epithelial track
  - A subset of these are called K cells, and it’s from these K cells that we see the release of GIP.
- There is another type of cell called the **L cell**
  - The L cells secrete something called glucagon-like peptide 1, or GLP-1
  - the K and L cells have a distribution that is not identical
  - the easiest way to think about this is that the K cells are more proximal in the gut, proximal meaning closer to the mouth
- The K cells are disproportionately found in the duodenum and the proximal jejunum, whereas the L cells are more in the distal jejunum and probably into the ileum

![](https://peterattiamd.com/wp-content/uploads/2021/11/f2.-ama29-1024x799.png)

**Figure 2.** Enteroendocrine cells, anatomical features, hormone secretion. ([Huang et al., 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7366065/))

- Your esophagus empties into your stomach
- The stomach empties into the duodenum
  - The duodenum is actually quite small and you can think of it as this little sort of C shaped thing and it’s fixed in place in the retroperitoneum
  - it’s approximately 25 centimeters long
- Duodenum empties into the jejunum, which then goes into the ileum
  - you can see the respective lengths of both of those, like 140 to 160 centimeters for jejunum, 180 to 240 centimeters for ileum
- The terminal ileum enters into the cecum, which is where the colon begins, and that’s about 150 centimeters in length
- On the right-hand side of this, you actually get a sense of where gut hormones are secreted
- focusing on two here
  - We’re really looking at GIP and you can see that that’s basically an upper gut phenomenon, so duodenum and jejunum
  - When you look at GLP-1, you can see that that’s a relatively low secretion in the proximal gut but it really kind of picks up in the latter part of the jejunum and the ileum
  - It actually is secreted also in the colon—that’s the main take home there
  - This is going to become relevant later on in our discussion when discussing the effect of gastric bypass surgery and gastric banding and other procedures for obesity and see if part of this can explain the phenomenon that we see there

## What is GLP-1 and how does it work? [16:30]

**Comparing & contrasting GIP to GLP-1**

![](https://peterattiamd.com/wp-content/uploads/2021/11/f3.-ama29-1024x506.png)

**Figure 3.** GIP & GLP-1 actions in peripheral tissues. ([Baggio and Drucker, 2007](https://pubmed.ncbi.nlm.nih.gov/17498508/))

*Similarities*:

- Both of these hormones increase insulin secretion.
- Both of these hormones tell the pancreas to make more insulin
- They both increase progenitor cell proliferation in the brain
- They increase neuro-protection

*Differences:*

- They differ in that GLP-1 decreases glucagon secretion
- Another fundamental difference is that GIP increases lipogenesis whereas GLP-1 is neutral on adipose tissues
- It means that GIP promotes fat storage whereas GLP-1 is neutral to fat storage. You could argue it would be negative to fat storage because it’s really promoting glucose uptake and storage in the muscle specifically.
- An important distinction here is that we know that GLP-1 delays gastric emptying
- Regarding appetite—which is going to play a very important role in why this drug may have some benefits in obesity—GIP did not impair or reduce appetite in obese human volunteers while GLP-1 does reduce appetite
  - There’s at least two reasons why that might be the case…
    - one could be delayed gastric emptying; and
    - There could also be a sort of central regulation of that—In other words, that GLP-1 is also acting in the brain to reduce appetite and not just by doing things in the periphery
- The net of all of this has been that the focus has been on GLP-1 and not GIP

**How does GLP-1 work?**

- First, it is secreted into the hepatic portal system
  - You’ve got cells that are basically endocrine cells within the gut and they secrete GLP-1 directly
  - They’re not secreting it into the lumen, they’re secreting it into the fat, into the venous system of the gut, which drains into what’s called the portal system

*Deeper dive into the liver/portal system:*

- The liver is a very unique organ in that it has two different circulation systems and it has two blood sources that come into it
- Like every organ, it has an arterial system of blood that brings nutrients and oxygen into the system
- And then you have a venous that is the outflow
- So you have renal arteries and renal veins
- The hepatic system is unique in that it has two incoming sources of blood
  - 1) The arterial system—hepatic arteries that flow into the liver
  - 2) The portal system
    - portal vein is formed by the confluence of the splenic vein and a mesenteric vein
    - in other words, this is bringing all of the blood from the intestines, all of the venous blood from the intestines into the liver, along with, separately, its arterial supply
  - Obviously the purpose of this is to ensure that the liver has a “front row seat” to all of the nutritional status of the gut
  - You’ve also got the L cells, which increase in their density as you go farther in the intestine, they’re responding to nutrients in general, not just glucose, and they’re secreting GLP-1 directly into the hepatic portal system

*The biphasic response:*

- You get a pulse of GLP-1 secreted about 10 to 15 minutes after eating
- Then you get a second bolus about 30 to 60 minutes
  - That second phase is the one that’s in response to nutrients
- But that first one is not–it seems to be independent of nutrient entry into the intestine
  - In other words, it’s anticipatory
  - When people talk about a cephalic phase response, this is what they’re referring to.

*The impact of GLP-1 on satiety*

- GLP-1 has significant impacts on satiety likely mediated through two mechanisms
- 1) It delays gastric emptying —
  - it slows the flow of nutrients out of the stomach (likely vaguely mediated) and therefore, the longer it takes for things to leave the stomach, presumably the more of an inhibition there is on appetite
  - There’s even experiments that have demonstrated that if you inject GLP-1 directly into the brain, it will reduce gastric emptying and appetite
- 2) GLP-1 might increase insulin sensitivity
  - It seems that it probably increases insulin sensitivity by suppressing glucagon, which again, distinguishes it from GIP-1.
  - If you’re suppressing glucagon, the net effect is that the liver will make less glucose
  - It can’t be overstated how important that is in insulin sensitivity given how much of the time the liver is making glucose and putting it into circulation
  - Outside of those moments in which you’re eating where your glucose is basically in your bloodstream because of what you’ve eaten, it’s the liver that’s regulating how much glucose is in your bloodstream

*Looking at the metformin example*:

- Metformin, although we don’t know exactly how it’s working, we know that the net effect is also suppressing hepatic glucose output

*Another overly simplistic analogy*:

- Say you’ve got a sink and you’ve got the faucet and the drain
- In our example the faucet is letting out glucose (instead of water), and glucagon is essentially that faucet
- If glucagon is increased, there’s more glucose coming out of the faucet
- More insulin is opening up the drain more so you’re going to suck glucose away into peripheral tissues
- So if you’re suppressing glucagon, you would be basically turning the faucet down or turning it almost all the way off, so less glucose is coming out of the faucet
- Whereas with insulin, the more insulin, the more you might be opening up that drain; and the less insulin, that the drain is closed

*When you look at insulin sensitivity…*

- You’re looking at the insulin response to the glucose
- If there’s lower glucose, you may get a lower insulin response
- The late [Roger Unger](https://www.utsouthwestern.edu/ctplus/stories/2020/unger-obit.html)—whose done a bunch of work on diabetes and looking at glucagon—makes the point that he thinks that the central role of insulin is actually to *suppress glucagon*

*GIP/GLP-1 and insulin*

- With GIP and GLP-1 increasing insulin secretion, a big spike of insulin also is going to suppress that glucagon…it’s like a counterregulatory role of these two super important hormones in terms of insulin sensitivity.
- It’s pretty clear GLP-1 is an interesting hormone
- It also seems, based on all of this, that if you could give GLP-1, there might be some benefits
- Part of the problem, however, is that GLP-1 is rapidly degraded by an enzyme called [DPP-4](https://en.wikipedia.org/wiki/Dipeptidyl_peptidase-4) giving GLP-1 a half-life of about two minutes so very little GLP-1 is sticking around
- Just as an aside, [DPP-4 inhibitors](https://care.diabetesjournals.org/content/34/Supplement_2/S276) are another class of medication used to treat type 2 diabetes
- This at least partially explains why there would be a benefit to a DPP-4 inhibitor because if you’re inhibiting DPP-4, you’re reducing the rate at which GLP-1 is degraded

**Origins of GLP-1 agonists—The Gila monster**

- In the late ’80s, early ’90s, a couple of individuals identified some biologically active peptides in the [Gila monster’s venom](https://pubmed.ncbi.nlm.nih.gov/16321550/)
- They identified or isolated something called [Exendin-4](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2925424/)
- basically a GLP-1 agonist that seems more resistant to being degraded DPP-4
- Liraglutide and semaglutide, all of these GLP-1 agonists, are basically modifications of Exendin-4
- And when they’re tweaking these drugs, part of it is they’re trying to tweak it so that it’s less susceptible to that degradation of that DPP-4
- So the discovery of Exendin-4 was a pretty big breakthrough because what it basically demonstrated was you could have the effect of GLP-1, but it could stick around longer

## 2021 semaglutide study: remarkable results, side effects, and open questions [30:00]

**Consistent results of semaglutide in diabetic patients**

- Semaglutide is often studied in type 2 diabetics
- We really don’t have any great FDA approved drugs for obesity as evidenced by the fact that obesity rates are continuing to climb in the presence of these treatments
- As is often the case, a lot of these drugs start out but getting tested on the treatment for type 2 diabetes
- Semaglutide got people a bit excited in terms of being a slightly better version of a GLP-1 agonist based on the work that came out of the [SUSTAIN trials](https://diabetes.medicinematters.com/semaglutide/type-2-diabetes/a-quick-guide-to-the-sustain-trials/12206922) (11 SUSTAIN trials in the US and several more in other countries)
- The SUSTAIN trials were remarkably consistent in their findings

![](https://peterattiamd.com/wp-content/uploads/2021/11/f4.-sustain-trials-ama29-1024x503.png)

**Figure 4.** SUSTAIN trials. >10,000 ptns across the spectrum of T2D. Greater reduction in HbA1c and weight across trials.

- More than 10,000 patients across a broad spectrum of T1D were given semaglutide and paired against against placebo, other T2D drugs like SGLT-2 inhibitors, and even to other GLP-1 agonists in the case of liraglutide
- Without exception, semaglutide just seems better; better in terms of A1C reduction and better in terms of weight loss

**2021 Semaglutide study**: [Once-Weekly Semaglutide in Adults with Overweight or Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183)

Subjects:

- 2,000 patients with a BMI of 30 or greater (technically obese) who **did not** have type 2 diabetes

Design:

- They were randomized to a 68 week treatment
- Two-thirds of the subjects are in the treatment group and one-third of the subjects are in a placebo group

Lifestyle intervention:

- Counseling sessions every four weeks to help people reduce their calories by 500 per day from their baseline
- Counseled on how to exercise 150 minutes per week

Two primary end points:

- 1 the percent in body weight change
- 2 the fraction of weight loss of at least 5%—i.e., what fraction of people in each group lost at least 5% of their body weight?

Drugs: They took [Ozempic](https://www.drugs.com/ozempic.html), which is the brand name for the semaglutide

- Started semaglutide with a low dose (to avoid nausea) of 0.25 milligrams once weekly for the first 4 weeks
- then increase the dose every four weeks to reach that 2.4 milligrams by the end of about four months

Notes:

- This is a study of a little over a year, but they spent four months at the “sub therapeutic” dose
- The reason that this was done at 2.4 milligrams was it was basically determined that this would have the same pharmacokinetic effect of using 0.4 milligrams daily, and that was kind of the dose that was used in the phase two trial

Results:

![](https://peterattiamd.com/wp-content/uploads/2021/11/f5.-ama29-1024x387.png)

**Figure 5.** Effect of Once-Weekly Semaglutide, as Compared with Placebo, on Body Weight. ([Wilding et al., 2021](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183))

- This figure is looking at is the body weight change from baseline by week for “in trial data”
- F*irst, a note about what “in trial” data means*:
  - In trial data shows the results for all people in the trial whether they completed the assigned treatment or not
  - So it could mean that some people, if they discontinued use, they’re still included in the data
  - Whereas “on treatment” data is where you look at only the people who took the treatment and stayed on the treatment for the duration of the study
  - This figure is the “in trial data”
  - They also have the “on treatment” data (not shown)
  - Typically, “on treatment” data will look better than “in trial” data, but in this case the numbers are actually really close
  - This separation into “in trial” and “on treatment” is really meant to highlight the difference between efficacy and effectiveness
  - As those data converge, it tells you that you have a very effective treatment—meaning something that works well in the real world because people can do it
  - Peter says that this is “such an important thing to pay attention to in clinical trials” and that “the data here are pretty remarkable if you take a look at what the difference is in weight loss”

*Observations about the weight loss results*:

- Note the placebo people did lose a little over 2% of their body weight and managed to keep it off
- In the semaglutide group…
  - It’s amazing when you see not just the magnitude of their weight loss but that it matured at about 60 weeks—”this just kept going and going and going”
  - You can see based on the numbers below that this was a two to one randomization and you can see how tight the error bars are on these figures—”they’re so tight they don’t even look like error bars actually. It’s kind of amazing”
  - What’s really amazing is that **50% of people on semaglutide lost more than 15%** of their body weight
  - and **a third of people lost more than 20%** of their body weight

*Other markers/secondary end points*:

![](https://peterattiamd.com/wp-content/uploads/2021/11/f6.-ama29-1024x530.png)

**Figure 6.** Selected Supportive Secondary and Exploratory Endpoints for the Treatment Policy Estimand. ETR: estimated treatment ratio. ([Wilding et al., 2021](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183))

- So fasting serum insulin,
  - an easy way to look at this is take the ratio of week 68 to baseline.
  - And so in the placebo group, they had about a 7% reduction in fasting insulin,
  - whereas they had a 26% reduction in the semaglutide group
- When you look at their liver function tests…
  - the ALT and AST had slight reductions in the placebo group and had dramatic reductions here, 24% and 11% respectively
  - probably a safe assumption here that weight loss was accompanied by a reduction in NAFLD.

![](https://peterattiamd.com/wp-content/uploads/2021/11/f7.-ama29-1024x702.png)

**Figure 7..** Supportive Secondary Endpoints Assessed in the DEXA Subpopulation for the Treatment Policy Estimand. ETD: estimated treatment difference. ([Wilding et al., 2021](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183))

- Keep in mind this was only in a subset of patients—they did this for 95 people in the semaglutide group and 45 in the placebo group
- Total change in fat mass
  - About 19 pounds of fat mass in the treatment group,
  - and about 4 pounds of fat mass in the placebo group
- Change in lean mass
  - The semaglutide group lost about 11 pounds (5.25 kilos)
  - Placebo group only lost about 1.83 kilos
  - Not surprising give the treatment group lost more weight overall
  - It’s interesting to note that the placebo group lost more lean mass than they did fat mass, and the reverse was true in the semaglutide group
- Change in visceral fat mass
  - For treatment group, the baseline was 1.3 kilograms, and then they lost 0.36 kilo… “*That’s actually pretty significant*”
  - “They’re still finishing higher than I would consider optimal, but that’s pretty good”
  - Placebo only lost .10 kilo by comparison

*Safety and side effects:*

![](https://peterattiamd.com/wp-content/uploads/2021/11/f8.-ama29-1024x463.png)

**Figure 8.** Prevalence and duration of GI events by severity. ([Wilding et al., 2021](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183))

- Peter says not all his patients can tolerate Ozempic (semaglutide) due to the nausea
- Looking at the figure above, Peter really likes how the data are demonstrated by time — “*it’s actually a very elegant way to demonstrate this because it shows it temporarily as well…this is important because if you just look at what fraction had side effects, you don’t realize, well, does it matter if most of these side effects were at the beginning but you get over them versus you don’t, etc.*”
- The top is showing you on the X axis what the time is since the randomization in the study,
- And the Y axis is showing you the percentage of people experiencing the side effects
- Nausea—
  - Nausea is the side effect that jumps out in the data
  - Overall, it was about 44% of the participants, which was 577 in the treatment group reported nausea events
  - we had 577 reporting nausea events, and there were over 1,000 nausea events total. So there must be some people having repeated reporting of nausea
- Clinically, Peter also sees Lightheadedness (not in data) with his patients
  - Peter sees this reported by patients and it’s probably a by-product of weight loss
  - and reduction in exercise tolerance
    - “We’re seeing patients who are losing weight so quickly that they’re having to reduce exercise intensity”
  - Peter points out that in his practice they haven’t gone much above one milligram which is less than the dose used in this study
  - The patients in the study got up to 2.4 milligrams by 20 weeks, and you can see that the effect of that titration wasn’t shown in the side effects—In other words, they didn’t have a second wave of side effects once they hit max dose
- *Overall observations about side-effects*:
  - from 20 weeks out, you can see the side effects are generally diminishing even though that’s the point at which they start the highest dose
  - in other words, there really is a benefit to ramping this drug up very slowly
  - But again, we’ve typically seen such good results at one milligram that we generally stopped there

## Semaglutide vs. lifestyle interventions: comparing results with semaglutide vs. lifestyle interventions alone [44:00]

![](https://peterattiamd.com/wp-content/uploads/2021/11/f9.-ama29-1024x827.png)

**Figure 9.** Comparison of semaglutide to lifestyle-intervention-alone.

- In the table above, the comparison groups included—
  - [Virta Health](https://www.virtahealth.com/)
    - Peter discloses that he’s an investor in Virta
    - But they are using that data because it’s probably the best example of a lifestyle intervention
  - [PREDIMED-Plus](https://jamanetwork.com/journals/jama/fullarticle/2752925)
    - They had a longer trial just called PREDIMED, but this PREDIMED-Plus looked at overweight and/or obese with metabolic syndrome and they followed them for a year and looked at weight loss and some of the metabolic biomarkers in the study

*Observations about the comparison in the figure above:*

- Comparing semaglutide to Virta
  - It’s pretty interesting that at 52 weeks (1 year), at 104 weeks (2 years), the Virta study and the semaglutide study are kind of comparable in terms of weight reduction and hemoglobin A1C reduction
  - In the semaglutide group, fasting glucose reduction is significantly greater, insulin reduction is greater,
  - And the reduction in LFTs is comparable, presumably again, reflecting an improvement in NAFLD
  - It’s worth pointing out these are not apples to apples—The Virta population is a population with type 2 diabetes (you can see the baseline hemoglobin A1C is 7.7%) whereas in the semaglutide paper, these are people coming in with a lower hemoglobin A1C at 5.7%
    - So the reduction is probably not apples to apples
  - Weight loss stats:
    - Baseline weight was…
      - ~105 kilos in semaglutide group
      - ~115 kilos in Virta group
      - ~85 kilos in PREDIMED-Plus
    - The takeaway here is that first of all, Virta from a lifestyle standpoint is a pretty remarkable intervention
    - The question is, *what’s easier to do?*
      - Well, the cost effectiveness of Virta is probably better than the cost effectiveness of semaglutide (which can be $30,000 per year if not covered by insurance even with coupons for [GoodRx](https://www.goodrx.com/))

## Closing thoughts and open questions on the therapeutic potential of semaglutide [47:30]

> “Getting deeper into how this drug works has certainly made me appreciate its power.” —Peter Attia

- Peter says that having seen semaglutide work in patients who have otherwise struggled after pulling every lever as hard as they can with respect to all of the other behaviors that can be manipulated specifically around exercise and their nutrition—his conclusion is that **this drug works**
- Peter has yet to see a person fail to lose weight on semaglutide provided they can tolerate it (which a big percentage of people can’t)
- The other question is whether patients can afford the drug—if it’s not covered by insurance it is very pricey

**Open questions**

- One thing that is unknown is once patients come off semaglutide, *how quickly do they regain the weight?*
- For example, in a [2017 follow up paper](https://pubmed.ncbi.nlm.nih.gov/28237263/) in [liraglutide](https://medlineplus.gov/druginfo/meds/a611003.html)—most of the metabolic parameters reverted right back to baseline within about four weeks of them being off the medication
- So an important open question here is: *Is this a drug that you will need to be on for the rest of your life?*

*Drug cycling*

- Peter has been experimenting with cycling the drug in his patients —8 eight weeks on, 8 weeks off
- While it’s a small sample size, not everybody seems to be regaining the weight in the time that they’re off
- But it does give them a break from some of the side effects and reduces the economic burden of the drug

§

## Selected Links / Related Material

**The 2021 semaglutide paper showing remarkable results**: [Once-Weekly Semaglutide in Adults with Overweight or Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183) (Wilding et al., 2021) [2:30, 32:25]

**Origin of exendin-4 found in the venom of the Gila monster**: [Bioactive peptides from lizard venoms](https://pubmed.ncbi.nlm.nih.gov/8701022/) (J P Raufman, 1996) [27:15]

**SUSTAIN trials looking at diabetic patients who were given semaglutide and paired against against placebo, other T2D drugs like SGLT-2 inhibitors, and even to other GLP-1 agonists in the case of liraglutide**: [A quick guide to the SUSTAIN trials](https://diabetes.medicinematters.com/semaglutide/type-2-diabetes/a-quick-guide-to-the-sustain-trials/12206922) (diabetes.medicinematters.com) [31:00]

**PREDIMED-Plus looking at lifestyle interventions for weight loss**: [Effect of a Nutritional and Behavioral Intervention on Energy-Reduced Mediterranean Diet Adherence Among Patients With Metabolic Syndrome](https://jamanetwork.com/journals/jama/fullarticle/2752925) (Sayón-Orea et al., 2019) [44:15]

**2017 liraglutide paper**: [3 years of liraglutide versus placebo for type 2 diabetes risk reduction and weight management in individuals with prediabetes: a randomised, double-blind trial](https://pubmed.ncbi.nlm.nih.gov/28237263/) (le Roux et al., 2017) [48:15]

§

## People Mentioned

- [Roger Unger](https://www.utsouthwestern.edu/ctplus/stories/2020/unger-obit.html) [25:30]

§