# #358 ‒  Peter’s takeaways on navigating HRT, rejuvenating the face, understanding the biology of aging, optimizing fertility, and learning to live well from the dying | Podcast Summary #6

**Source:** [https://peterattiamd.com/qps6/](https://peterattiamd.com/qps6/)

---

In this podcast summary episode, Peter summarizes his biggest takeaways from the last three months of guest interviews on the podcast. Peter shares key insights from his discussions with Paul Turek and Paula Amato on male and female fertility; Rachel Rubin on menopause and hormone replacement therapy; Brian Kennedy on the biology of aging; Tanuj Nakra and Suzan Obagi on facial aging and skin rejuvenation; and BJ Miller and Bridget Sumser on lessons we can learn from the dying about how to live. Peter highlights the most important insights from each episode and any behavioral changes he’s made for himself or his patients as a result of these fascinating discussions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [episode #358 show notes page](https://peterattiamd.com/qps6). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Summary of episode topics [1:15];
- Episodes on fertility with Paul Turek and Paula Amato: insights on all things male and female fertility [4:45];
- How men can optimize fertility [20:15];
- How women can optimize fertility [26:00];
- Rachel Rubin episode: insights on women’s sexual health, menopause, and HRT [31:45];
- How women can prepare for menopause: proactive care, evidence-based HRT, and more [41:45];
- Brian Kennedy episode: understanding aging, role of inflammation and mTOR, and current limitations of aging clocks and biomarkers [46:30];
- Advice from Brian Kennedy on testing longevity interventions [56:45];
- Tanuj Nakra/Suzan Obagi episode: causes of facial aging and practical strategies for prevention and treatment [57:30];
- Skincare: making sense of the wide range of skin resurfacing treatments [1:06:45];
- How to create a realistic, sustainable skincare routine [1:12:30];
- The dangers of following unqualified aesthetic advice online and the importance of getting professional medical guidance for cosmetic treatments [1:18:00];
- BJ Miller/Bridget Sumser episode: lessons about living from the dying [1:21:45]; and
- More.

---

The Peter Attia Drive

#358 ‒  Peter’s takeaways on navigating HRT, rejuvenating the face, understanding the biology of aging, optimizing fertility, and learning to live well from the dying | Podcast Summary #6

---

## Show Notes


---

\***Notes from intro**:

- Welcome to a special episode of *The Drive*, in today’s debrief, Peter focuses on what he considers the most important learnings and insights from the past quarters of interviews as well as any behavioral changes he’s applied as a result

**Topics covered in the past quarter**

- Male and female infertility ‒ [Paule Turek](https://peterattiamd.com/paulturek/) and [Paula Amato](https://peterattiamd.com/paulaamato/)
- Women’s sexual health, menopause, and hormone replacement therapy ‒ [Rachel Rubin](https://peterattiamd.com/rachelrubin/)
- The biology of aging ‒ [Brian Kennedy](https://peterattiamd.com/briankennedy/)
- Skincare, facial aging, and rejuvenation strategies ‒ [Tanuj Nakra and Suzan Obagi](https://peterattiamd.com/tanujnakraandsuzanobagi/)
- Lessons we can learn about living from the dying ‒ [BJ Miller and Bridget Sumser](https://peterattiamd.com/bjmillerandbridgetsumser/)

## Summary of episode topics [1:15]

**REMINDER**: These podcast summaries are a way listeners can hear from Peter about insights he took from guest episodes such as where Peter’s behaviors have changed and how his thinking may have changed, but these episodes are not necessarily a replacement for listening to the full episodes.

**Overview of Episodes to be Discussed**

- [Paul Turek](https://peterattiamd.com/paulturek/) ‒ male fertility
- [Paula Amato](https://peterattiamd.com/paulaamato/) ‒ female fertility
- [Rachel Rubin](https://peterattiamd.com/rachelrubin/) ‒ women’s sexual healthy, menopause, HRT
- [Brian Kennedy](https://peterattiamd.com/briankennedy/) ‒  biology of aging
- [Tanuj Nakra and Suzan Obagi](https://peterattiamd.com/tanujnakraandsuzanobagi/) ‒ all things skincare, facial aging, rejuvenation strategies
  - It is now 2.5 months since this episode and Peter is looking forward to discussing exactly what he has done
  - Of all of the episodes, this would be the one where he’s had the greatest change in his personal behavior
- [BJ Miller and Bridget Sumser](https://peterattiamd.com/bjmillerandbridgetsumser/) ‒  all around death and dying
  - What you can learn from people on their death bead
- The last 2 episodes could not be more apart in terms of relevance and superficiality
  - Not to bring any sort of judgment against aesthetics
  - Ultimately talking about end of life and lessons about life through death versus how to make your skin look better are about two opposite ends of the spectrum
  - Nevertheless, it is a spectrum and we can find value in talking about everything along it
- We try not to do too much summary in these episodes because the show notes do such a great job of that

## Episodes on fertility with Paul Turek and Paula Amato: insights on all things male and female fertility [4:45]

[#351 ‒ Male fertility: optimizing reproductive health, diagnosing and treating infertility, and navigating testosterone replacement therapy | Paul Turek, M.D.](https://peterattiamd.com/paulturek/) (June 2, 2025)

[#352 ‒ Female fertility: optimizing reproductive health, diagnosing and treating infertility and PCOS, and understanding the IVF process | Paula Amato, M.D.](https://peterattiamd.com/paulaamato/) (June 9, 2025)

\*\*\*

**From a story standpoint, the idea that conception is difficult is an understatement**

- A single ejaculation releases about a 100 million sperm
- Fewer than 5 million of them even make their way past the cervical mucus
- Ultimately only somewhere between 100 and 500 reach the fallopian tube
- Then only 1 goes on to fertilize the egg
- Now, there might be 20 that reach the egg, but there’s this really cool force field that comes up the minute the first sperm touches the egg
  - It creates a chemical barrier that prevents any others from fertilizing, otherwise you’d have this devastating situation of too much genetic material being brought in

**A couple of interesting things that made Peter go “Wow!”**

*Sperm are chemotactic*

- They’re basically chemical guided missiles that make their way to the egg, and they can traverse 15 centimeters of distance within the vagina to the fallopian tube within minutes
- It’s important to understand, given how small a sperm is, that is the analog of a human swimming 20 miles in the ocean in that same period of a few minutes
- By the way, even though we didn’t go into this in the podcast, think about the energy requirement to do that and you kind of understand what the motor and the ATP generation is like in one of those things

*Testes, like the brain, have kind of a specialized blood tissue barrier*

- It’s very immune privileged and it protects developing sperm from antibodies
- It also means that drugs or toxins that can cross it such as certain types of chemotherapies can actually be disproportionately damaging
- It’s for that reason that a lot of men who are undergoing chemotherapy will choose to do a sperm donation prior

*Spermatogenesis (or the generation of sperm) follows a clock of about 74 days*

- If a guy gets his sperm tested and it comes back that something’s not right, and if you’re trying to make interventions around sperm health
- You’re going to need 2-3 months of trying a corrective intervention before you can determine if it’s worked
  - That’s how long it takes to go through the cycle

**On that intervention piece, one of the things that was talked about was bike seats. As someone who spent a lot of time on a bike, did that surprise you?**

- Yeah
- Peter has always been pretty mindful of bike seats, and he’s been very fortunate despite how much time he used to spend on a bike that he’s never had any issues

***Paul points out in the podcast that it’s not really a big concern for fertility, but it is much more a concern around erectile function, based on your anatomy and based on the type of seat you use***

- You can really traumatize the arteries and nerves that impact erections

**⇒** What we tell all of our patients, if they’re spending a lot of time on a bike, we have recommendations on bike seats that they should be using

- Peter has 2 bikes: one for inside, one for outside
- He has different bike seats on them because he got them at different times, but they’re basically the identical type of seat

***A seat that has the middle of the saddle is largely absent so the ischial tuberosities (your sit bones) are doing the supporting but nothing else***

*A couple brands of bike seats Peter recommends*

- [Top USA](https://www.top5-usa.com/saddle-for-perineal-numbness?targetid=dsa-41066162664&matchtype=&device=c&campaignid=19691655358&creative=648221012362&adgroupid=145513486265&feeditemid=&loc_physical_ms=9028299&loc_interest_ms=&network=g&devicemodel=&placement=&keyword=$&target=&aceid=&adposition=&trackid=us_all_top5_1_1&mId=895-263-6903&gad_source=1&gad_campaignid=19691655358&gbraid=0AAAAAoKwm5SkO-i455SfazulMNf7wlCIo&gclid=CjwKCAjwi-DBBhA5EiwAXOHsGSTwIy6EU85wmPUr6Fl2IAitNqAxFPGpYLs7lHvyZ60VKS2hEOEWVxoCLjEQAvD_BwE)
- [Ism](https://shop-us.ismseat.com/collections/performance-saddles/products/pn-3-1) [shown below]
- As silly as it sounds, Peter recommends people buy 3 and try them out and figure out the one that’s most comfortable
  - Buy from somebody who will let you return them

![](https://peterattiamd.com/wp-content/uploads/2025/07/f1-qps6.png)

**Figure 1. Bike seat where the middle of the saddle is largely absent**. Image credit: [ism](https://shop-us.ismseat.com/collections/performance-saddles/products/pn-3-1)

**Back to fertility, Paul talked a lot about what his workup is for patients. Remind people of that and how you apply that to your patients**

- This is not something Peter considers his practice remotely sophisticated in
- We refer out for fertility issues to people like Paul or Paula
- What we learned here is really valuable for everybody listening because you can certainly do a lot on your own to force the issue

> “*If you remember nothing else from Paul’s podcast, you know what you should remember is that males are often the driver of fertility issues*.”‒ Peter Attia

- So when a couple is struggling with fertility, it’s very common to just assume that the issue lies with the woman, and that’s not the case
- In fact, Paul mentioned that only 23% of males are even evaluated for fertility prior to moving to IVF
- When you consider the cost, the economics of IVF, to think that 3/4s of men are not even evaluated for fertility issues before proceeding to that is crazy
- Especially when you consider that 40% of male infertility is driven by one thing: a [varicocele](https://en.wikipedia.org/wiki/Varicocele)

**⇒** A varicocele is a very easy thing to correct with a very minor procedure in a male

- To think that 40% of male infertility alone is driven by a varicocele, you realize that there’s an enormous opportunity here

*Paul’s workup for male infertility*

- Involves a very thorough patient history and physical exam
  - A varicocele is something that any urologist will be able to pick up on a physical exam
- Semen analysis, which he typically repeats twice across 3 weeks along with hormone levels, and by looking at [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone), [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone), and [testosterone](https://en.wikipedia.org/wiki/Testosterone)
  - You can figure out if a guy is taking exogenous testosterone
  - Sometimes a guy will just fail to mention that he’s taking exogenous testosterone, that he’s been on it for years and years and years
  - It just doesn’t cross his mind what the impact of that could be on his fertility

**Exogenous testosterone is effectively male birth control**

- Within 2-3 months of taking 200 mg testosterone per week, 95% of men will effectively be [azoospermatic](https://www.ncbi.nlm.nih.gov/books/NBK578191/) or [oligospermatic](https://en.wikipedia.org/wiki/Oligospermia)
  - It means they basically can’t reproduce
- Peter doesn’t know what that would be at a 100 mg per week
  - He doesn’t know how much longer it would take
- 200 milligrams a week is a really big dose ‒ we’ve never had a patient take that much testosterone
- Typically we’re sort of in the 80-120 milligram per week
  - So if it takes you 8-12 weeks to become azoospermic or oligospermic, at 200 milligrams per week, it might take twice that long

***The point is in relatively short order, exogenous testosterone will render you unable to reproduce***

*The reversibility of the effects of exogenous testosterone on sperm production*

- Basically within 3-6 months of testosterone cessation within the first year, you will resume sperm production
- There are of course other ways around it
  - We have men in our practice who are taking testosterone exogenously, but who also want to continue with their reproductive potential, and so we’ll typically add [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) (somewhere between 250 and 500 IU twice weekly) to maintain sperm count

**⇒** We prefer using just hCG at a higher dose as opposed to exogenous testosterone if we can in younger men

- Peter clarifies: if you’re a man who still wants to reproduce but your testosterone is very low and we want to increase your testosterone level, our first choice is actually just using hCG by itself
  - That would be done at a dose of anywhere from 750 to up to 1500 IU twice a week, and if that corrects the testosterone level, great, we’re done
  - If it doesn’t and we need to use exogenous testosterone, we will still bake in a low dose of hCG

*Paul talked about intranasal* [*Natesto*](https://www.natesto.com/)

- We’ve talked about that with [Mo Khera](https://drmohitkhera.com/about/) [episode [#260](https://peterattiamd.com/mohitkhera/#:~:text=intranasal%20testosterone) after 1:38:45]
  - [and also in episode [#291](https://peterattiamd.com/derekmpmd2/#:~:text=Have%20you%20been%20following%20the%20Natesto%20product%3F%C2%A0) after 9:00]
- In Peter’s experience, he hasn’t found anybody (male or female) that’s willing to use intranasal Natesto
  - The compliance is nonexistent
  - It needs to be used 3x a day and that’s messy
- Peter thinks that until there are formulations that are a little bit easier, it might be tough

**You mentioned IVF earlier, remind people what the different options are**

*Intrauterine insemination (IUI)*

- Ovulation is stimulated using a medication like [letrozole](https://en.wikipedia.org/wiki/Letrozole) or [clomiphene](https://en.wikipedia.org/wiki/Clomifene) and then the sperm are mechanically placed in the uterus
  - Or sometimes intercourse is just timed

**⇒** This works best in younger women where no major male factors have been identified

- The success drops pretty notably after about the age of 35 and is quite low after 40
- The biggest drawback here is that the fertility drugs are going to raise the chances of twins or higher order multiples, because again, you’re forcing ovulation
  - This is especially true with the injectables and obviously the success rate is lower
- The advantage of IUI is that it’s much less expensive

*In vitro fertilization (IVF)*

- In contrast to IUI, IVF uses injectable hormones because the goal is to trigger massive numbers of eggs and follicles which are now harvested mechanically
- The physician harvests eggs using a needle into the ovary, getting as many as possible, and then *in vitro* (meaning out of the body) these are inseminated with sperm and then the zygotes are grown and you can genetically test them
- You can examine them for morphology before you re-implant them one at a time
- The big drawback here is the cost
- Paula said this is approximately $20,000 per cycle
  - That may not include the cost of genetic testing which is commonly done today
- The advantage is your per unit success rate is much higher than IUI
  - It’s so high that virtually nobody is implanting multiples anymore
  - 10, 15 years ago that it was not uncommon to implant 2 embryos, and the chances of having twins were not that high if you did it
  - Now, success rates are so high that implanting more than 1 embryo would be deemed an unnecessary risk
  - The success is maybe 80, 85% depending on morphology
    - And this assumes chromosomal normality (no aneuploidy) ‒ meaning you have one and only one copy of the full female and one and only one copy of the full male chromosome (exactly 23 pairs of chromosomes)

Other advantages of IVF is that you can really go to next level technology

- **Intracytoplasmic sperm injection** can be used when the male sperm are highly, highly dysfunctional
  - That means you inject a single morphologically or mechanically dysfunctional sperm (but chromosomally normal) directly into the egg
- At the other end of the spectrum, if maternal egg quality is insufficient, and what that usually means is you cannot get a high enough number of chromosomally normal eggs
  - As maternal age increases, this becomes the dominant problem
- Then **egg donation** works, because the age of the uterus doesn’t really seem to matter that much
  - If you have a woman who’s say 40, 50 years old but for whatever reason isn’t able to generate eggs without aneuploidy, the fact that her uterus is well outside of her reproductive age doesn’t seem to matter and she can have a totally healthy pregnancy using the egg of a much younger woman

**Take-home point for anybody going through this process**

- The embryology lab is as important as the reproductive doctor
- The embryologists who are the people that run that lab and the physician are really a team that one without the other is suboptimal

*Important questions that are reasonable to ask*

- It is important when you’re speaking to an IVF doctor to inquire about their embryologists, their lab: What gives them a competitive advantage in that area?
- How long has their embryologist been with them?

**The differences in the risks for male and female age as it relates to fertility**

- This is a very important point, and Peter was much more aware of the risk on the maternal side than he was on the paternal side
- We hear more about chromosomal abnormalities that occur as maternal age increases
  - The most obvious of these being [trisomy 21 or Down syndrome](https://en.wikipedia.org/wiki/Down_syndrome)
  - Everybody is well aware that as the mom gets older, the risk of this goes up
- The [amniocentesis](https://en.wikipedia.org/wiki/Amniocentesis) is a less sophisticated of evaluating this, although it’s probably still done actually
- Now with ultrasound, people are getting a better and better sense of that without having to do something as invasive as amniocentesis

*The interesting thing was that paternal age is also driving genetic abnormality, but it’s at the genetic level, not the chromosomal level*

- Chromosomes are huge
- Remember you’ve got these 23 pairs of enormous chromosomes

***As the egg gets older, the mistakes are that you’re getting either zero or two copies from the mother (that’s what we mean by aneuploidy), and those typically result in very significant phenotypes***

- In some cases they’re compatible with life, such as trisomy 21 or Down syndrome
- In many cases they’re not compatible with life and this leads to miscarriages
- Or they are compatible with life but the life can be truncated pretty early, such as [trisomy 13](https://en.wikipedia.org/wiki/Patau_syndrome)
  - These children don’t typically live very long

*On the male side, we’re looking at alterations that occur at the level of different genes, not chromosomes*

- That means you’re not really going to screen for them through the typical genetic screening you would do even with IVF
- The broader point here is that these children phenotypically are much more subtly impacted and here
- They tend to be neurologic impacts, specifically autism, ADHD, and psychiatric disorders
  - These are highly [polygenic](https://en.wikipedia.org/wiki/Polygene)
  - There’s not a gene that’s going to lead to any of this stuff, and in most cases we don’t actually know what the cluster of genes are

***The point here is as paternal age increases, we’re going to see more of these subtle neurologic signs. As maternal age increases, we see much more of these obvious things. It’s much easier to screen for the maternal ones than the paternal ones.***

## How men can optimize fertility [20:15]

**Behavior to optimize sperm motility and sperm count**

- If you think about an optimization graph where you’re trying to optimize for sperm motility and sperm count, in an ideal world you want the highest count and the maximum motility
- Those two move in opposite orders
- So the longer the time between [ejaculations], the worse the motility because the sperm are basically staying in storage longer

***Oversimplifying a little bit: older sperm, longer time in storage, worse motility; and as the number of ejaculations or frequency of ejaculations goes up, motility gets better, but sperm count goes down***

- This is a classic min-max problem
- According to Paul, 48 hours is the optimal frequency [of ejaculation] if you’re trying to conceive

**⇒** Takeaway #1: if a couple is trying to conceive intercourse should be timed about every other day in the week leading up to ovulation

**The impact of hot tubs and hot baths**

- This is another very interesting point that Peter was not aware of how significant it is

***Paul said that 20 minutes 3x a week at 104 degrees F (which is hot but not unbearable, that’s a standard hot tub) will induce reversible azoospermia ‒ it’s effectively birth control***

- You have your hot tub cranked to 104; you’re in there 3x a week at least at 20 minutes a pop; That’s basically birth control
- The good news is that’s reversible

**⇒** Stop hot tubbing before you’re ready to conceive

- The reason for that is that the testes are outside the body and therefore it’s very difficult to protect them from high temperature of liquid because of the thermal coefficient of liquid
- The **sauna**, even though we run saunas to a much higher temperature (it’s not uncommon to be in a sauna that’s 200 degrees F) because of the thermal coefficients in conductivity of air, has much less of an effect
  - Typically 25-30% of the effect

***Hot showers don’t seem to matter if they’re under 20 minutes, because again, the testes aren’t being fully submerged***

**Peter asked Paul about cold plunging**

- He was less concerned for 2 reasons
- 1 – People are typically in a cold exposure for much less time
- 2 – More importantly, the testes actually basically brought up into the body during incredible cold and therefore the body is able to mitigate cold much better than it is hot

**Effects of alcohol, metabolic health, etc***.*

- Nothing too surprising, but it was interesting to hear

**⇒** Alcohol should be limited to no more than 2 drinks in a day and ideally none

- BMI and metabolic health matter
- Again, the data are all based on BMI
  - Peter always thinks that BMI is just a proxy for metabolic health

**⇒** Avoid vaping and smoking nicotine, and he regards daily cannabis as a sperm depressant

***Ultra endurance exercise is going to suppress testosterone and can reduce sperm coun***t

- That is anytime you’re doing up to 80% of VO2 max
  - By the way, this is not that much
  - That sounds like a lot, but 80% of VO2 max is Zone 3 for up to 2 hours a day

**⇒** Paul recommends to periodize heavy blocks of training away from conception attempts

**Was there recommendations for people thinking about fertility as it relates to TRT that they could employ?**

- Peter’s practice users [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) in monotherapy instead of [TRT](https://en.wikipedia.org/wiki/Androgen_replacement_therapy)
- You can also use [clomiphene](https://en.wikipedia.org/wiki/Clomifene) or [enclomiphene](https://en.wikipedia.org/wiki/Enclomifene)
  - We don’t use either of those in our practice
  - There are some edge cases, but we think that hCG is a far better work around than clomiphene and enclomiphene
- If you’re on TRT, adding hCG is probably your best way around it

**⇒** If you’re willing to stop TRT and taper it down over 4-8 weeks and then start either clomiphene and/or hCG (frankly we would just prefer hCG), retest, testosterone, retest sperm ‒ they’re usually going to bounce back within 3-6 months

***Between 2-5 years of continuous TRT is going to be very difficult to recover from***

**⇒** If a guy is young and wanting to go on continuous TRT, Peter recommends banking sperm

- If a guy is 40 and he still thinks he wants to have kids at some point, we would really recommend **banking sperm** as well, just given how much the risk profile starts to go up for the genetic issues that we talked about

> “*It’s very important for guys to assume… it’s 50% in your wheelhouse, 50% in your partner’s wheelhouse and you should take a fertility workup*.”‒ Peter Attia

## How women can optimize fertility [26:00]

**Women should get to know their cycle**

- A consistent cycle can be as low as 21 days, as high as 35 days, and you can still have regular ovulation within that period
  - That was kind of news to Peter, that it could be that much of a range

***A red flag for her is a cycle more than 35 days, skipped months, severe cramps, heavy bleeding***

**⇒** If things like that are happening, it warrants a workup with your GYN

- Really look for things like PCOS, thyroid issues, endometriosis

[***PCOS***](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome) ***is a pretty significant cause of infertility for women, and it’s easily treated***

- The problem with PCOS is women just aren’t ovulating
- 80% of those people will get pregnant with just ovulation induction and IUI

**Another really important point from Paula was to protect the fallopian tubes**

**⇒** She really encourages women to do annual sexually transmitted disease screening (especially for [chlamydia](https://en.wikipedia.org/wiki/Chlamydia)) and prompt treatment, which will cut in half the risk of tubal scarring

**⇒**  If you’ve had [pelvic inflammatory disease](https://en.wikipedia.org/wiki/Pelvic_inflammatory_disease) or severe [endometriosis](https://en.wikipedia.org/wiki/Endometrosis) or abdominal surgery, ask for a test called an [HSG](https://en.wikipedia.org/wiki/Hysterosalpingography) upfront when starting a fertility workup

- This is a test that basically uses dye in the fallopian tubes and will evaluate the integrity of the tube and make sure that they’re not being occluded or scarred or anything like that

**Not unlike men, to maximize fertility, health matters dramatically**

- Metabolic health, sleep, exercise
- Extreme exercise: when we talk about a woman who’s going to be exercising 2 hours a day, she’s going to experience the same sort of challenges that the male will and probably to a greater extent, so at that point it can interfere with ovulation and things of that nature
  - That’s not an excuse to not exercise
  - Very few people would exercise to the point where it would impact fertility, but it’s absolutely possible

***So outside of those extreme factors, it’s pretty unusual that lifestyle by itself is the cause [of infertility]***

**⇒** The other thing to keep in mind is it’s very important to use a **prenatal vitamin** like folic acid, etc., to correct any even mild deficiencies

**Rapamycin is being investigated as a potential drug to extend the fertility years in a woman**

- If it’s slowing the aging process of the human, is there a chance it’s slowing the aging process of the egg?
- Short answer is it’s too soon to tell
- Paula’s view was not to do that
  - She felt that off-label use of rapa in women trying to conceive didn’t make sense

**Paula recommends that women in their mid-30s freeze eggs if they’re not yet ready to have a family**

- We’re seeing a lot more of that now that women are coming to appreciate the importance of egg age and the supply of eggs is finite but also front-loaded
- Women are born with about 2 million eggs
- Only 400,000, 20% of them remain when she gets her first period, and they go into basically a quantity and quality freefall at about the age of 35
- For some women that means they get another 5 years
- For some women it means they only get another year

***To be safe, 35 is what she uses as that cutoff***

**Wrapping up this, what are the final recommendations for male, females as a couple together?**

*Both partners need to be tested very early in this process*

- In fact, both partners should be tested right away
- Roughly a third of the time it is exclusively a female problem
- A third of the time it is exclusively a male problem
- And a third of the time it is a combined or otherwise unexplained problem
- Those numbers just speak for themselves

*Timing of intercourse around ovulation*

- This is the other thing that Peter found incredibly interesting
- Let’s just say ovulation is on day 14
- He would’ve assumed that it was more important to have intercourse at and after ovulation ‒ that’s completely wrong

**⇒** The really valuable window is before and up to ovulation because the egg only survives about 8 hours and sperm can survive for 3-5 days

- So if you think about that asymmetry, it means in the 3-5 days leading up to ovulation is when you want to have as many sperm as possible in the vicinity such that at ovulation you have your maximum odds because you only get about 8 hours post ovulation

***Peter puts that in the list of very important takeaways from these podcasts as a reason to front load intercourse when you’re trying to naturally conceive***

*It’s important for couples that are going through challenges to reframe miscarriages*

- When Peter and his wife were going through this, she had some really horrible miscarriages
- One thing that is very helpful is to reframe them as sort of a chromosomal self-selection
- You don’t want to get into sort of a blame game
  - Or say, “*If only I had done this.*”
  - Or, “*Was I eating the right amount of this?*”
  - Or, “*Did I work out too hard or too soft?*”
  - It’s virtually never any of those things

***It is virtually always: this was an embryo that was missing a chromosome or had two of an extra chromosome, and that’s why at about week 11 or 12 it became incompatible with life***

- That’s why it’s very stressful for any couple, and they typically will not talk about a pregnancy until they’re into the second trimester because most of that selection occurs in the first trimester

## Rachel Rubin episode: insights on women’s sexual health, menopause, and HRT [31:45]

[#348 ‒ Women’s sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.](https://peterattiamd.com/rachelrubin/) (May 12, 2025)

\*\*\*

- Peter has stated on other podcasts (not just this one) that the work of the [WHI](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) and resulting demonization of [HRT](https://en.wikipedia.org/wiki/Hormone_replacement_therap) is one of the biggest missteps in modern medical history

**Is that still your thinking?**

- Yeah, it really is
- It’s definitely one of the things that frustrates him more than anything else in the last 50 years as it pertains to medical research

*Do you think the tide’s starting to turn, or do you think it’s still even early in that process and that people are just starting to talk about treating it in a different way?*

**⇒** In doing research for this podcast, we learned that as of 2020 only 4.7% of women in the United States who were eligible to receive hormone replacement therapy were receiving hormone replacement therapy

- That tells Peter how much of a bubble Peter’s living in
  - He hates that sort of language of “*You live in a bubble and you’re out of touch with reality.*”
  - But that was a stark wake-up call to him, which is like, “*Wow, I live in a world where every one of my female patients who’s eligible for HRT and wants it, gets it.*”
  - The woman he knows have the means to find the doctors that can do this
  - He doesn’t know women who are eligible for HRT, who want HRT, who can’t access it somehow
  - Now he realizes, wow, that means every one of them is in that 4.7%
    - 95.3% of women [eligible for HRT) in this country [are unable to access it]
    - If you had asked Peter that question before, he would’ve said it was probably 25% of eligible women

***Peter doesn’t know if that means the tide is turning***

- These numbers were from 5 years ago and he doesn’t know what the numbers are today
- If those numbers today are 10% of 15%, then the answer is yes, the tide is turning
  - And Peter would feel a bit like a clown getting on this soap box because the world doesn’t need another person on a soap box
- But until that number is 100%, what are we doing?
- Having seen his mom and my mother-in-law go through this with nobody to help them
- Because his mother lives in Canada, there’s nothing he can do about it
  - There’s no doctor up there that’s going to treat her
  - Even 10 years ago when he wanted her to be treated, there was no one willing to do it
  - And there’s certainly nobody willing to do it now at her age

**For women listening who are in this category, is there something  you would recommend if they are having trouble trying to understand the data so they can really push their doctor and/or try to find a doctor who will help them with this?**

- This is a push-pull problem

**⇒** One of the insights from this discussion with Rachel was that very, very few doctors know what to do

- This is another example of the bubble Peter is living in, which is he doesn’t appreciate how much he’s learned over the past 12 years of doing this
  - And now he takes it for granted that he understands this, that his team understands this, and that we can do this
- Rachel points out how she was speaking at a conference of internists and a shockingly low number of doctors in that audience that felt even remotely comfortable prescribing hormones
  - These are doctors that are on the front lines of taking care of women
  - Peter forgets what the number was exactly, but that’s a huge problem

> “*That’s the collateral damage of this women’s health initiative, is we now have not just a generation of women who have not been treated, but the corollary of that is we have a generation of doctors who have never been trained to do it.*”‒ Peter Attia

- Peter would argue hormone replacement therapy is more nuanced than treating blood pressure or cholesterol
  - It’s not as simple as treating cholesterol, which is not that simple (you really have to know what you’re doing there)
- Imagine an entire generation of physicians that have no idea how to do it

***It’s one thing that you could say, yes, women have to be able to advocate for themselves, but we just need doctors who know how to do this, and we also need to make sure that the women are getting HRT from responsible doctors and not quacks***

- Because there are also a lot of HRT quacks out there who are filling a void, with good intentions
  - Peter doesn’t think these are bad, nefarious people, but he thinks they’ve gone way overboard on what they do
  - And they’re prescribing at best unhelpful hormones, and at worst, probably things that could be dangerous and overdoing it and things like that

***There’s a lot of work that needs to be done over the next decade to undo the “cluster” of the WHI***

**Peter’s insights and takeaways from Rachel’s episode**

*For both women and men, it’s important to understand what menopause is*

- It is not a gentle taper like a man’s experience
- A man will experience a slow downward androgen drift, and over a period of a decade, you can look back and go, “*God, it was really amazing when my testosterone was 900 and now that it’s 450, I sure don’t feel as good.*”
  - But that took a decade
- Now that’s very different than if you castrate a man
  - Obviously we don’t castrate men literally anymore, but we chemically castrate them when they have, for example, metastatic prostate cancer
    - Or prostate cancer that is so aggressive that maybe they’re not candidates for surgical treatment, but they are candidates for radiation and what’s called androgen deprivation therapy
  - If you talk to those men (which Peter has) they will tell you how catastrophic chemical castration feels because now it’s a very sudden and dramatic shift

***If you can understand it through that lens, then you have a better understanding of what menopause is, which is: it is indeed a castration event for women***

- It’s a period of time when their ovarian hormone gas tank goes from normal to highly erratic (which is perimenopause), to completely empty (which is postmenopause)

**⇒** And their estradiol, their progesterone, and their testosterone fall to near zero ‒ and this can happen in a year

- So it’s hard for guys to appreciate that, because outside of these unusual circumstances, we don’t go through that
- For women, they can feel some sense of an appreciation for why it can be so difficult
- To be clear, it’s not that difficult for every woman
  - Peter also knows many women who say, “*Yeah, I had some hot flashes and some night sweats for a year, but it really wasn’t that bad.*”
- One thing Peter doesn’t have a great answer to yet is why some women sail through menopause with mild side effects and other women are really hammered about it
  - Maybe we can have Rachel back on the podcast to better understand that

*What happens during menopause: 3 basic categories of symptoms*

1 – The classic neurocognitive vasomotor symptoms

- Brain fog, mood issues such as irritability and depression, obviously hot flashes and night sweats and sleep problems

2 – Symptoms around [genitourinary syndrome of menopause (GSM)](https://www.auanet.org/guidelines-and-quality/guidelines/genitourinary-syndrome-of-menopause)

- This would include vaginal atrophy, vaginal dryness, pain with intercourse, urinary urgency and leakage
- A lot of women experience these things and they’re not tying them to what’s happening [menopause]

3 – [Musculoskeletal conditions](https://pubmed.ncbi.nlm.nih.gov/39077777/)

- The most obvious of this being [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis) is estrogen levels go to zero, bone health deteriorates
- Also joint pain and things that you don’t necessarily expect: [frozen shoulder](https://en.wikipedia.org/wiki/Adhesive_capsulitis_of_the_shoulder), [planter fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis), decline in balance

**⇒** All of these are tied to a hormone vacuum and inflammation

**Are there any lingering myths, things that WHI got wrong that you want to touch on?**

- You have a group of people who have come to the idea that the WHI was incredibly flawed, highly misinterpreted, and didn’t actually suggest that estrogen caused cancer

***In other words, if you actually read the*** [***paper***](https://pubmed.ncbi.nlm.nih.gov/12117397/)***, it’s pretty clear estrogen is not causing cancer***

- But because our cognitive dissonance runs so deep, we still have to say things like, “*Well, you got to use the minimum effective dose for the shortest period of time possible. You could never use it for more than 10 years. The age of 60 is a cutoff, and if you haven’t started it for 5 or 7 years, you can never start it again.*”
- There’s no basis or substance to any of these myths

***The data do not support the ten-year rule, the sixty-age cutoff, and too often the benefits of bone health cognition, cardiovascular benefits are not really taken in the context of what is the risk of not doing something***

## How women can prepare for menopause: proactive care, evidence-based HRT, and more [41:45]

**What are the things that women of this age should be cognizant of as it relates to applying these insights from the episode to their life?**

> “*The most important thing would be if I’m talking to you now and you are still pre-menopausal, my advice would be it’s not too soon to be thinking about this.*”‒ Peter Attia

- Obviously if you’re 20 years old, don’t worry about it
- Peter is hopeful that by the time a 20-year-old is ready for menopause, that the world is an entirely different place
- But if you’re a 40-year-old woman and there’s no sign that you’re in perimenopause yet, make sure that you’re seeing a doctor who is going to be comfortable navigating you through that journey

***Don’t wait until you’re in the throes of perimenopause to sort of hit the panic button and try to find that doctor***

- Make sure that your internist and or your GYN are fully competent in the ability to treat you, and if you don’t need that help for 5 more years, no problem
  - You’ve done the work already
  - You know that this person is ready
- If you’re being taken care of by someone who is completely incapable of this, then you’ve got the time to find somebody who’s going to be capable

> “*Rachel argues, and I completely agree, that any physician who sees women over the age of 40 in some capacity other than being a total specialist should certainly manage the basics of HRT.*”‒ Peter Attia

- Any physician, even as a specialist, should certainly understand
- For example, if you are a cardiologist who only deals with lipids, or pick some other issue that a cardiologist might deal with, even someone who’s dealing with arrhythmias, you should still understand the difference between a premenopausal woman and a postmenopausal woman and what the effective hormones can be in those things

***As physicians, that means: you’ve got to learn the toolbox***

There are a lot of FDA-approved products

- Patches, gels, rings, oral agents, IUDs (that are coated with progesterone), vaginal estrogen, testosterone gel
  - You do need to understand these things
- And you need to understand what labs to order and how to interpret them
- We talk about a lot of this in the podcast, so Peter is not going to rehash all of that
  - And this’ll be stuff that he covers in subsequent podcasts

Peter adds, “*I think it’s so important… as physicians, you’ve got to be able to screen aggressively for* [*GSM*](https://www.auanet.org/guidelines-and-quality/guidelines/genitourinary-syndrome-of-menopause) *and know how to prescribe local estrogen and DHA early to prevent UTIs, pelvic pain and sexual dysfunction.*”

*Benefits of local vaginal hormones*

**⇒** We’ve known for 30 years that you can reduce the risk of UTIs by over 50% with just vaginal estriol or estradiol or DHEA

***Local vaginal hormones ‒ Rachel described as Viagra for women***

- Vaginal estradiol, estriol, or DHEA cream reverses GSM and cuts UTI risk by more than 50%, and is safe in everyone, even with a prior history of venous thromboses or breast cancer
  - Because these are not systemic
  - This is insanely cheap ([$13 a tube](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/)), and yet they have these black box warnings on them that mirror systemic risk to deter use

**⇒** Rachel made a statement that was incredible: Medicare could save between $6 and $22 billion a year on treating UTIs by simply managing this better

**A consolidated version of Rachel’s playbook on HRT**

*The algorithm around how to optimize estrogen, progesterone and testosterone using FDA-approved products*

1 – Systemic estrogen

- Estradiol is available in several formats: topical cream, transdermal patch, vaginal ring, oral, injection (there’s a large tool box because no one choice is best for everyone)
- [Transdermal estrogen](https://www.rxlist.com/esclim-drug.htm) (twice-weekly patch) is a little better for sexual function & this is what Rachel usually starts with
  - Start with a low dose and increase as needed to alleviate symptoms (hot flashes, etc.)
  - HRT is dosed based on symptoms as hormone levels can vary dramatically in perimenopause
- Adding a on a [vaginal estrogen cream](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/) (in addition to systemic estrogen) improves vaginal symptoms and reduces the risk of UTI
  - This is safe for everyone
- Get the estrogen dose right, then add on progesterone

2 – Progesterone is needed in women with a uterus to protect the endometrial lining from cancer

- 100-200 mg [micronized progesterone](https://www.rxlist.com/prometrium-drug.htm#description) (oral capsule) daily
  - Taken with dinner for maximum absorption
  - Can use 200 mg for 12-14 days a month
- Synthetic progesterones are another option: [Slynd](https://www.rxlist.com/slynd-drug.htm) (which is a progestin-only birth control pill)
- Avoid using [Duavee](https://www.rxlist.com/duavee-drug.htm) (oral estrogen with [bazedoxifene](https://en.wikipedia.org/wiki/Bazedoxifene#), which protects the uterus but is not a progesterone-based medicine)

3 – Sometimes adding testosterone to the mix is needed to make women “feel like themselves” again

- Rachel likes [testim](https://www.rxlist.com/testim-drug.htm), a 1% generic testosterone gel, and she has women rub 0.5 mL on their calf every day
- You need to use this regularly and it will be 3-5 months before you’re going to notice its effects

*Problems with compounded formulations*

- One of the things Peter took away from this episode: we shouldn’t be using these compounded biased formulations where they’re using 80% estriol, 20% estradiol in a compounded formulation
- First and foremost, you have all the issues you do with compounded formulations where there’s a bit of a buyer beware situation
  - [Peter shares tips for finding a reputable compounding pharmacy in [AMA #52](https://peterattiamd.com/ama52/)]
- Some compounding pharmacies are high integrity, but some are not
  - You don’t always know what you’re getting

*Estradiol is the estrogen hormone that should be used*

- Beside that, there’s no reason to believe that [estriol](https://en.wikipedia.org/wiki/Estriol) is a better version of estrogen than [estradiol](https://en.wikipedia.org/wiki/Estradiol) (which is the one that we should be using)
  - There are reasons we could argue why people have chosen to use it, but if you look at the data, it’s not clear that that makes any sense
  - [there is no FDA-approved product for estriol and Rachel doesn’t see any reason to use Bi-Est (which is an 80:20 mixture of estriol and estradiol)]

## Brian Kennedy episode: understanding aging, role of inflammation and mTOR, and current limitations of aging clocks and biomarkers [46:30]

[#357 ‒ A new era of longevity science: models of aging, human trials of rapamycin, biological clocks, promising compounds, and lifestyle interventions | Brian Kennedy, Ph.D.](https://peterattiamd.com/briankennedy/) (July 21, 2025)

\*\*\*

- The episode with Brian Kennedy was an old-school deep dive into the biology of aging

**Explain what Brian meant with his analogy about a ball in a valley** **and some of the insights from this episode**

- The ball in a valley model serves to explain 2 observations that don’t necessarily make sense
- 1 – As one ages, cell damage goes up, but it does so sort of linearly
  - [“damage” here is used as a loose term]
  - The relationship between cell damage and aging is approximately linear (the data suggests it’s a little more than linear)
  - You’ve got a positive first derivative, zeroed-out second derivative
- 2 – If you look at mortality, everybody understands that that goes up exponentially with age
  - The shape of that curve is very sharp and you have a very positive second derivative, not just a positive first derivative
  - This is a positive first derivative and a positive second derivative
- Analogy: think of a bowl maybe with a ball that rotates or oscillates up and down and rolls in and out of that bowl [shown in the figure below]
  - Or picture one of those old skateboarding pools where you guys get running up and down throughout the pool

![](https://peterattiamd.com/wp-content/uploads/2025/07/f2-qps6.png)

**Figure 2. Brian’s analogy to visualize the loss of resilience that occurs with aging**.

- As time progresses, as the the individual ages, the sides of the pool come down linearly (or near linearly), and that’s the cellular damage that’s occurring
  - [described above as observation 1]
- What happens to the ball?
- The probability that the ball escapes goes up exponentially
  - [described above as observation 2]
- You can think about this through the lens of the energy it requires the ball to get up over is coming down at a much higher rate than the linear rate at which the wall is coming down
  - It’s escaping with an energy at about the square of that
- [So the linear decrease in wall height (increase in damage, observation 1) leads to an exponential increase in the probability that the ball escapes (exponential increase in mortality, observation 2)]

***That’s a conceptual model to explain why you can see a reduction in cellular health that doesn’t seem like it’s happening that fast, but it can start to really snowball in terms of lifespan***

**⇒** In this model, once the ball gets out, that’s basically the death of the animal

*How Peter would explain this linear and non-linear component of aging to a 5-year-old*

- Think about this through the lens of resilience
- The idea should be how do you prevent the fall of the wall in total?
- If the ball exits at one part of the valley, it’s like heart disease
  - If it exits at another part of the valley, it’s cancer
  - At another part of the valley, it’s dementia

***Trying to raise the wall in one area will buy you some reduction in mortality because you at least shored that one-off, but you’re going to eventually die of one of the other ones***

- You’ve heard Peter argue that nobody should ever die of ASCVD (full stop, no chance)
- If you were walking around with an apoB of 30 and normal blood pressure and you weren’t smoking, it’s almost impossible to die of a heart attack, but how much longer will you live as a result of that?
- Maybe only a few years, because if you’re not shoring up the other ones, there’s an issue

*What we really want to think about is: What are the drivers of the wall height?*

- Brian’s argument is that chronic low-grade inflammation might be one of the most important drivers of wall height
  - Therefore things that can reverse chronic low-grade inflammation can reduce the rate at which the wall is falling, and therefore reduce the probability that the ball gets out in any direction
  - And that would be a lifespan extending maneuver

**Calorie restriction**

- Even though we don’t necessarily think that caloric restriction works in the wild, clearly in the lab with animals, it does work
- Why is that the case?

***Brian argues that calorie restriction through mTOR inhibition is lowering low-grade inflammation and therefore lowering the rate at which the wall goes down***

- He points to the principal component analyses of some of the more elaborate aging clocks that are not just looking at epigenetics, but also metabolomics and proteomics, and they all seem to put inflammatory markers at their top with age

**With aging we see resting mTOR drift upward**

- It’s very important to point out that we’re talking about resting [mTOR](https://en.wikipedia.org/wiki/MTOR) here
- It doesn’t matter that mTOR shoots up after you have a high protein meal
- It doesn’t matter that short-term interventions can lead to more mTOR during muscle protein synthesis or things like that
- What we’re talking about is resting mTOR activation
  - Just like we don’t care if your glucose level skyrockets when you’re doing high intensity intervals, we care about what your glucose levels look like when you’re doing nothing, when you’re sleeping, what your average is

**⇒** As resting mTOR activation goes up, we see persistent inflammatory tone

- This might be an argument why [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) works

***It might be that rapamycin is lowering that [resting mTOR activation] which is lowering persistent inflammatory tone, which again is slowing the rate of [decline of] that wall [in Brian’s analogy]***

**Does** [**NAD**](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#) **fit in anywhere in that conversation?**

- It’s tough to say
- We certainly know that NAD levels decline with aging
- Back to the analogy: as that wall is coming down, we know that NAD levels are coming down

**⇒** This is a topic that we’ll probably talk about in more detail in another [upcoming] podcast with [Eric Verdin](https://www.buckinstitute.org/lab/verdin-lab/)

***Direct oral supplementation with NAD or its precursors*** [***NR***](https://en.wikipedia.org/wiki/Nicotinamide_riboside) ***or*** [***NMN***](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide) ***is going to show very limited efficacy due to poor stability and digestion***

- [IV](https://en.wikipedia.org/wiki/Intravenous_therapy) NAD will work, but it’s very impractical for routine use
- People who go and get an NAD IV drip every few weeks are getting a huge dose that doesn’t stick around long enough to matter
  - You’d probably have to be on more of a continuous drip to get the benefits, if we believe in indeed there are benefits

*How* [*CD38*](https://en.wikipedia.org/wiki/CD38) *fits into this*

- CD38 is an enzyme that accelerates the degradation of NAD
- The activity of CD38 goes up when you age, which by the way may be the reason NAD levels are going down
  - It’s not clear
  - It could be that there’s two things going on there, but at a minimum you have this depleting pool of NAD

*Brian talked about other ways to potentially get NAD*

- Using [sublingual](https://en.wikipedia.org/wiki/Sublingual_administration) NAD combined with a CD38 inhibitor
- By taking it under the tongue, you bypass the digestive system, and that might make it more effective
  - There’s no data to say this is the case, but an interesting idea

**We pivoted to talk about epigenetic clocks**

- At some point you just want to believe that these things are going to be good enough that they can provide at a minimum some insights around aging interventions

***It’s so hard for Peter to buy the idea that some aging clock spits out a number that represents your biologic age and therefore is predictive of future years of life***

- People have heard him harp on this all the time
- If a 60-year-old takes one of these tests and it spits out that they are “30 years old,” does that realistically mean they’re going to live another 60 years?
  - Which would be a thirty-year-old biologically living to 90, which means in practical terms they’re going to live to be 120
- The answer is no; there’s no chance that that is the case
- So what good is that number?
- And that says nothing about the fact that we had this discussion with [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) previously, which is he bought the 4 top commercial clocks, and used them in duplicate simultaneously (so took 8 tests simultaneously)
  - [discussed in [episode #333](https://peterattiamd.com/longevityroundtable/#:~:text=Matt%20tested%204%20different%20direct%2Dto%2Dconsumer%20biological%20age%20kits) after 35:00]
  - The intra-test variability was significant
  - And the tests themselves spit out values all over the place

***It’s just not clear that these tests mean anything***

- Where Peter hopes we get to is that we can get tests that combine proteome, metabolome, epigenome, and they tell us directionally if interventions are moving in the right direction or not
  - That should be the way to go
- Brian’s got a group that’s leaning on a [clinical chemistry clock](https://pubmed.ncbi.nlm.nih.gov/40268972/)
  - It’s got about 50 blood biomarkers in it, and many of these are very standard things like lipids, blood pressure (which is not a blood marker)
    - [see the [supplementary information](https://pmc.ncbi.nlm.nih.gov/articles/instance/12019333/bin/41514_2025_221_MOESM2_ESM.pdf), tables 2 and 3]
    - All are things that are clinically measurable
    - Inflammatory proteins

***It’s not clear to Peter that it’s providing more value above what you could measure through these things and if it’s combining it in a way that’s more predictive, but we’re still at the point where methylation doesn’t provide treatable insights***

- Peter just has to believe this is going to get better
- He has to believe we’re going to get to the point where we can do tests in clinical trials that will allow us to predict much earlier if something is geroprotective
- If we don’t go in that direction, we’re never going to kind of make headway in this problem

## Advice from Brian Kennedy on testing longevity interventions [56:45]

**Brian shared his personal experience in taking things**

- Brian himself is very experimental in taking things, but he had caution for the “biohacker community”
- He said he has nothing but respect for people who are putting enormous effort into understanding how different interventions can physiologically impact them

***Brian said the biggest mistake he sees people making is they’re combining so many interventions at once***

- They’re taking these 6 supplements at once and then trying these 5 with them or after them

**⇒** If there’s a chance you’re going to measure anything, you’ve really got to do it one thing at a time

***He also said don’t waste your money on any of the commercially available biologic age tests ‒ there’s no validity in those at the moment (and Peter agrees)***

## Tanuj Nakra/Suzan Obagi episode: causes of facial aging and practical strategies for prevention and treatment [57:30]

[#355 – Skincare strategies, the science of facial aging, and cosmetic-intervention guidance | Tanuj Nakra, M.D. & Suzan Obagi, M.D.](https://peterattiamd.com/tanujnakraandsuzanobagi/) (June 30, 2025)

\*\*\*

- Peter really wanted to understand this topic for himself
  - There’s no aspect of his life in which you could accuse him of being lazy except this one
  - For years, his wife has begged him to wash his face before going to bed or put on some sunscreen (just do something to not destroy your skin)
- It’s not that he doesn’t want to have better skin, he’s just so overwhelmed with all this stuff
  - If his wife drags him to a spa, they’re trying to sell you 57 things
- He found this podcast incredibly helpful
- What Peter really liked about it is they both had a different framework for how they thought about it, and yet it gets you to a very similar place

**Tanuj frames facial aging as 4 parallel processes**

- Skin deterioration, fat pad, volume loss, bony recession, and then gravity-driven tissue descent

> “*I was familiar with three of these, but the one I was not familiar with was the bony recession, and I must say that was such an eye-opener to me.*”‒ Peter Attia

One example of that in Peter’s face

- Something he didn’t even notice until the episode was that he’s got this little bit of skin here, underneath his neck
- His assumption is that’s just happening because of skin deterioration and the gravity-driven descent of this tissue
- Those are true, but what’s also true is his jaw is actually receding

**⇒** This is more prominent in women, especially postmenopause if they’re not on [HRT](https://en.wikipedia.org/wiki/Hormone_replacement_therapy), because what happens when you lose estrogen, your bones get weaker and your bones start to regress

- Anything that would shorten the mandible will decrease the tension on this tissue here
- That’s why if a woman is 60 years old, she’s not on HRT, she has one more thing that’s working against her, which is the speed with which her jaw is recessing is going to increase the amount of tissue here that’s able to be pulled down by gravity, etc.

**You mentioned before the podcast you didn’t recognize that in yourself after the podcast. Did you see that every time you looked in a mirror?**

- Peter has never *not* been able to see it since

Peter adds, “*I owe Tanuj and Suzan a great deal of gratitude for educating me, and they’ve also ruined my ability to look at myself in the mirror without just seeing all of the artifacts of my old face.*”

- He jokes with his wife about this all the time now
  - If they’re going out for dinner or something, she asks, “*How do I look?*”
  - He’ll say, “*Oh, I mean you look good. I mean, except for your face. Other than your face, you look good.*”
  - She’ll be like, “*Your shirt is awesome. The face part I could do without right now, but everything else looks great.*”
  - If you have a spouse where you guys can embrace your aging faces together and joke about how hideous you look, it’s all good
- This weekend, Peter was driving his daughter with two of her closest friends back from a place, and he was giving them all a lecture (in a nice way), “*Girls, I noticed you guys were tanning a lot this weekend. I just got to tell you, I think it’s a strategic error. You guys look amazing. What are you doing? Why would you do that? Why would you go out in the sun? Do you realize one day you’re going to be 30 and you’re going to start to wrinkle a little bit and you’re going to regret the day that you were out there tanning as a sixteen-year-old? It’s just not worth it. Stay out of the sun*.”
  - He can’t imagine what he came across sounding like to them, but we’ll see
  - He did it over an In-N-Out Burger, so it was a pretty chill environment
  - His guess is they’ve probably forgotten the discussion by now
  - Nick suggests this means he’ll have to have the lecture again
    - Every time Peter sees them, he should just pop quiz on what they learned from that conversation
  - Maybe Peter should ask his daughter to have skin parties where they just come over and he talks for an hour about skin
- Peter jokes, “*I think I’m going to change my entire life’s work to just talking to teenage girls about skin health and just warning them of not wanting to look like me and my wife.*”
- His wife (Jill) takes great care of her skin, but we’re laughing about how we have old skin

*Changes that occur as skin ages*

- As you lose collagen and elastin, the skin actually gets thinner
- And UV exposure, even chronic stress (which unfortunately can’t seem to get rid of) seems to accelerate this.

**⇒** Skin is tethered to the bone by these osteocutaneous ligaments and as the fat recedes and the bone recedes, these ligaments obviously are less able to tether the skin

- Peter talked a little bit about the bone loss in the jaw
- The other area where we see this is the **orbital rims**
- If you put your finger around your eye, you feel these very prominent bones

**⇒** The orbital rims are getting wider as we age and so to it does the scaffolding that holds the face forward

***The result is you’re getting these bags under the eyes, which are themselves exacerbated by the volume loss as the fat pads go down***

- The other thing to keep in mind is these things are happening, but each of them is ganging up on things that you see

Peter explains, “*Everything that you notice in your aging face, whether it be these bags under my eyes, this business under my chin, it’s multiple factors that are going on.*”

Other things that can exacerbate these are

- **Weight loss and weight gain cycles**, which again disproportionately affect women, especially during **pregnancy**
  - Even something that’s not pathologic, like obesity and things like that
  - Just gaining weight for pregnancy, losing weight
- Imagine the impact of having 3 children and how that could change the tone of fat in the face.

**⇒** Typically the earliest places these show up are going to be around the eyes

- Peter would say in himself, that was probably the first thing he noticed was these **bags under his eyes** (when he’s not tired)

**Suzan’s framework talked about the 5 R’s**

- Relax, refill, resurface, redrape, and renew
- She comes at this through the lens of what can you do to address the problem

***Tanuj’s framework is these are the things that are happening, and Suzan’s framework is this is what you want to do***

Relaxing means you want to relax overactive muscles with neuromodulators

- The most obvious example of this is Botox
- You have muscles that are overactive typically because they’re trying to hold something in place

**⇒** For example, as eyelids are drooping down, what’s going to happen is that the muscles in the forehead are going to be overactive to try to lift that up

Refill means restoring volume lost in fat or bone

- This is typically done with fillers or grafts

Resurfacing is what you want to do with respect to skin quality

- Peter will talk about this a little bit more because this was definitely the biggest black box to him (all the ways that you resurface skin)
  - He keeps hearing people talk about lasers and peels and things like that

Redrape is when you lift tissue that has sagged by gravity

- This is typically done surgically in using a deep plane of the face or neck

Renew is your daily program

- The daily thing that you do to maintain this
- Peter will go into in much more detail later on, because that was one of the things he wanted to get out this program

## Skincare: making sense of the wide range of skin resurfacing treatments [1:06:45]

**From the frameworks, let’s go into treatments. Talk a little bit more about the resurfacing aspect of it**

*The 2 most interesting things Peter gained from this podcast*

- 1 – He gained a clear sense of what a daily routine could look like that he could be compliant with (he’ll come back to this)
- 2 – He finally was able to make sense of all these treatments
  - Part of the problem was he was often confusing the commercial name of a treatment with what it is actually doing and therefore I couldn’t create a framework

*The framework they proposed is to break these treatments down to ablative and non-ablative*

- Ablative means it removes the surface layer of the skin
- A non-ablative treatment does not; it leaves the surface layer intact

**⇒** The thing you need to know is: an ablative treatment is more aggressive than a non-ablative treatment

- But even within non-ablative and ablative, there are varying degrees of intensity

***The more aggressive you treat, the more destructive it will be, the longer the downtime will be, but the more durable the result will be and the better the result will be and the less frequently you will need to do it***

- This becomes a really interesting trade-off
- Even after the podcast, Peter was talking with Tanuj and Suzan about things that they would like to do for his face, but it was a total non-starter because you looked like you were burnt to a crisp for 3 or 4 weeks
  - He’s not going to do that
  - So even though you might only have to do something like that once a year, that’s just more than someone like Peter is willing to do, but maybe for some people it’s not

**Non-ablative treatments**

- Really **light chemical peels** use mild acids to exfoliate the topmost layer of the skin
- You can go down a little bit more with [intense pulse (IPL)](https://en.wikipedia.org/wiki/Intense_pulsed_light) or [broadband light (BBL)](https://www.dukehealth.org/blog/considering-broadband-light-therapy-heres-what-you-need-know)
  - IPLs or BBLs, these deliver light energy to reduce blotchy pigments and small blood vessels
  - It’s a pretty gentle option
- Pros: virtually no downtime: most patients resume normal activity within a day
- Cons: your results are not going to be over the moon and they’re not going to be as durable
- Then you have superficial non-ablative fractional lasers, such as [Clear + Brilliant](https://www.clearandbrilliant.com/) (which is just a particular brand)
  - These create micro-thermal injuries to stimulate skin remodeling
  - It results in a more even texture and tone
  - Skin feels mildly sandpapered and peels
  - Resolves in about 2 days
- Then you go into higher energy, non-ablative still, [fractional lasers](https://www.asds.net/skin-experts/skin-treatments/non-ablative-laser-rejuvenation)
- [Fraxel](https://www.fraxel.com/) is one of these
  - It delivers a deeper injury, yields a more visible collagen bump, but adds several days of bronzing and flaking

**Some treatments are semi-ablative**

- One example is radio frequency microneedling
  - This consists of insulated needles that pierce the dermis and then deliver heat that contracts collagen and shrinks oil glands
  - It’s considered semi-ablative because there’s no epidermal removal, but now you’re getting pretty intense [effects]: 2-4 days of redness and swelling

**Ablative treatments**

- You start with medium-depth chemical peels such as [modified TCA](https://www.asds.net/skin-experts/skin-treatments/chemical-peels)
  - This will chemically ablate the dermis and the superficial dermis
  - It requires about a week of downtime
  - They’re useful to even out skin tone and texture irregularities, potentially scars and hyperpigmentations
- Then you have a [fractional ablative lasers](https://www.ncbi.nlm.nih.gov/books/NBK557474/)
  - These create microscopic columns of ablation through the skin and these columns are why it’s called fractional
  - They can also erase wrinkles, but the downtime is also here about a week

**Really intense stuff: ablative CO****2** **laser resurfacing and deep chemical peels**

*CO**2* *laser resurfacing*

- This is the harshest but most powerful laser intervention
- It removes the entire superficial epidermis, delivers the largest single-session reduction in deep wrinkles, and it demands a week of open wound care followed by about 3 weeks of persistent redness before the skin settles
- You might only do this once a year, but you basically have a burn to your face that requires wound care for a week with another 3 weeks of downtime
- Peter got the impression that maybe if you did enough of these, you could stretch it out to be more than a year, especially if you were treating a bunch of sun damage
  - If you eventually modified your behavior such that you were protecting your skin, then maybe you get to the point where you don’t have to do it as frequently
  - That seems pretty extreme

*Deep chemical peels:* [*phenol peel*](https://www.plasticsurgery.org/cosmetic-procedures/chemical-peel/deep)

- Peels that contain a high concentration of phenol produce similar results and downtime to the CO₂ laser resurfacing
- It’s just using a chemical rather than a laser

**The other thing Peter took away was you could use multiple different therapies**

- You could stack therapies
- For example, you could use some mild ablative with a non-ablative or multiple non-ablative options to tweak the results
- Obviously there’s many ways to do it

> “*My takeaway from this is make sure whoever is doing this to you understands how all of these things work and can personalize it to you through the lens of your skin*.”‒ Peter Attia

- If you’re using lasers on darker skin or people with [melasma](https://en.wikipedia.org/wiki/Melasma), you can run into some difficulties
  - They might have to be prepped with hydroquinone
  - There just might be certain things that you can’t do.

***Bottom line is make sure you’re doing this with a person who knows all of these things and understands the risks of each of them in someone like you with your skin with skin history***

## How to create a realistic, sustainable skincare routine [1:12:30]

**Walk through different skin maintenance programs people can use and what you’ve settled on**

- One of the things Peter was hoping to do after this was come up with a skin care maintenance program that he could stick to
- Not unlike a diet, which is he doesn’t want to hear about the perfect diet that he’ll never be able to stick to for more than a week
  - He wants to know a diet that is good that he could follow indefinitely and be as compliant with as possible
- Peter came away with something pretty easy, which is an A.M. and a P.M. protocol

*A.M. protocol*

- 1 – The A.M. protocol uses a glycerol-based, non-frothy cleaner
- Honestly, Peter doesn’t often do that because he just uses a good cleaner in the shower and he’s doing this right after he showers
- But let’s just say you’re not going to shower until later in the day

***Use a glycerol-based, non-foamy cleaners followed by a serum***

- 2 – Use a serum that contains vitamin C
- Peter had tried a serum in the past, but he couldn’t stand the smell of it and so he just could never stay with it
- One of the cool things about this podcast was they recommended he try this brand, and all of a sudden he was like, “*Ah, it doesn’t smell bad at all. I can use it*.”
- Peter now uses a serum

**⇒** A serum has to have vitamin C in it because it’s a precursor for collagen synthesis, it’s an antioxidant, and it evens out skin tone

- 3 – Use a sunscreen
- Every single day Peter puts on a sunscreen

Peter adds, “*What’s really cool is they’ve shared with me these brands of pure mineral sunscreens, but they are tinted. So it’s not like I look white when I put it on. In fact, I’ve got it on right now and you wouldn’t really know it because it’s just the same color as my skin*.”

- A **tinted sunscreen** really increases compliance because historically Peter would only wear sunscreen on his face if he was going to be outside for a long period of time
- But if you think about it, there’s so much time that he’s out in the sun where he’s not wearing sunscreen
  - If his boys get home from school and they want to go play soccer or baseball downstairs, he doesn’t remember to go and put sunscreen on and they run out in the backyard to play for an hour in the sun
- Whereas if he goes out on his bike for a ride or if he goes out for a long ruck or something, yes, he’ll remember to put sunscreen on
- But by doing this thing [as part of the A.M. routine], now he’s always got it on
- 4 – Finally thing that you can use is a moisturizer if needed
- Peter doesn’t tend to need it
  - His face tends to be oily enough without it

Tanuj and Suzan were very resistant to talk about their products on the podcast

> “*To be clear, I have bought both of their products and I just love them, and frankly, if you trust somebody, I’m going to buy their product.*”‒ Peter Attia

Peter adds, “*Lots of different products exist out there, so I’m not here to say that theirs are the best, but those are the ones I’ve been using and I’m very happy with them.*”

**Products that Tanuj and Suzan recommended**

*Disclaimer*: Tanuj and Suzan each have their own line of skincare products ([AVYA Skincare](https://www.avyaskincare.com/pages/the-founders), [SUZANOBAGIMD™](https://www.obagi.com/collections/suzanobagimd-skin-care), and [Veea Face](https://veeaface.com/collections/dr-suzan-obagis-essentials)) and have curated a “perfect list” of skincare products (below) which includes products from their own lines as well as other highly effective products they are not affiliated with.

**Cleansers**

- AVYA Skincare – [Gentle Cleanser](https://www.avyaskincare.com/collections/skincare-bestseller-sets/products/gentle-cleanser)
- La Roche-Posay – [Toleriane Hydrating Gentle Facial Cleanser](https://www.laroche-posay.us/our-products/face/face-wash/toleriane-hydrating-gentle-facial-cleanser-tolerianehydratinggentlefacialcleanser.html)
- Veea Face – By Dr. Suzan Obagi- [Clarifying Gel Cleanser](https://veeaface.com/products/clarifying-gel-cleanser)

**Eye creams**

- AVYA Skincare – [Eye Bright Cream](https://www.avyaskincare.com/collections/dark-circles-or-puffy-eyes/products/eye-bright-cream)
- Neocutis – [Lumiere Firm Riche Eye Cream](https://www.neocutis.com/product/lumiere-firm-riche/)
- Skinmedica – [Instant Bright Eye Cream](https://www.skinmedica.com/us/skin-concern/aging/96379.html)
- Veea Face – By Dr. Suzan Obagi- [Revitalizing Eye Gel Crème](https://veeaface.com/products/revitalizing-eye-gel-creme)

**Serums**

- AVYA Skincare – [Power Serum](https://www.avyaskincare.com/products/anti-aging-power-serum)
- Obagi Medical – [Suzan Obagi MD – Super Antioxidant Serum](https://www.obagi.com/products/suzanobagimd-super-antioxidant-face-brightening-serum)
- Skinceuticals – [CE Ferulic](https://www.skinceuticals.com/skincare/vitamin-c-serums/c-e-ferulic-with-15-l-ascorbic-acid/S17.html)
- Veea Face- By Dr. Suzan Obagi – [Brightening Serum](https://veeaface.com/products/brightening-serum)

**SPF Moisturizers**

- AVYA Skincare – [Tinted Sunscreen SPF 40](https://www.avyaskincare.com/collections/skincare-bestseller-sets/products/hydroveda-sheer-tinted-moisturizer-spf40-1-and-2)
- Colorescience – [Total Protection No Show Mineral Sunscreen SPF 50](https://www.colorescience.com/products/total-protection-no-show-mineral-sunscreen-spf-50)
- EltaMD – [UV Physical Sunscreen Broad-Spectrum SPF40](https://eltamd.com/products/eltamd-uv-physical-broad-spectrum-spf-40-rosy-tint)
- Obagi Medical – Suzan Obagi MD – [Tinted Physical Defense SPF 50](https://www.obagi.com/products/suzaneobagi-md-tinted-physical-defense-spf-50)

**Retinol**

- La Roche-Posay – [Redermic R Retinol Cream](https://www.laroche-posay.us/our-products/face/face-serum/redermic-r-retinol-cream-3337872413063.html)
- Obagi Medical – Suzan Obagi, MD – [Retivance Skin Rejuvenating Complex](https://www.obagi.com/products/suzanobagi-md-retivance-skin-rejuvenating-complex)
- SkinBetter Science – [AlphaRet Overnight Cream](https://www.skinbetter.com/shop-skincare/product-category/anti-aging/alpharet-overnight-cream-865800000250.html)

**Deep Moisturizers**

- AVYA Skincare – [Hydroveda Moisturizer](https://www.avyaskincare.com/collections/skincare-bestseller-sets/products/hydroveda-moisturizer)
- Obagi Medical – Suzan Obagi MD – [Moisture Restore](https://www.obagi.com/products/suzanobagimd-moisture-restore-hydrating-face-moisturizer)
- Skinceuticals – [Triple Lipid Restore](https://www.skinceuticals.com/skincare/anti-aging-creams/triple-lipid-restore-2-4-2/S09.html)

**P.M. skincare routine**

- 1 – Peter definitely uses a glycerol-based cleaner
- Why? Because it’s the end of the day, he’s got the sunscreen on, he’s been out sweating
- 2 – He uses the vitamin C serum again
- 3 – He uses [retinol](https://en.wikipedia.org/wiki/Retinol)
- He mentioned on the podcast that he had tried retinol in the past and  hated it
  - It just made his face super red
  - He was using a 0.05%
- Tanuj prescribed for him a 0.025% retinol, and the first couple of weeks he just did it 3x a week, and he did get red
- It actually almost felt like it had burned him in certain areas of his face
- But then just as he predicted, he got used to it
- Now, Peter uses 0.025% retinol every single night, no issues whatsoever
- 4 – He follows that up with a moisturizer
- He was recently thinking he would increase the retinol to 0.05% or maybe use 0.05% every other day or something like that

***They mentioned that you would choose your retinoid by age and tolerance, so they actually recommended starting in your late teens to early twenties***

**⇒** It could prevent acne, and then you could sort of upgrade it to a stronger formulation in late twenties and early forties

- So again, Peter missed that whole boat altogether, but in some way he found something that he can do

***This routine really only adds a few minutes to his day and it’s not interfering with anything ‒ now he’s able to do it and he’s pretty confident he will be able to stick with this***

**An important point about product choice: vitamin C serums and sunscreen**

- Vitamin C only works if the formula stays active, so these less expensive water-based serums oxidize before you even open the bottle

**⇒** Look for products that are using stabilizers such as ferulic acid, nitrogen filling or encapsulation

- The serums are not cheap
  - Peter can’t remember what he’s paying because he’s buying everything all at once, but they also last a heck of a long time
  - He’s still on my first bottle of this stuff
  - The cost is not as prohibitive as it looks because you’re using such small amounts of this stuff
- Peter still uses an Elta MD sunscreen when he’s going to be outside
  - He doesn’t care if he’s all white and mineraled up, he’s using a less expensive sunscreen
  - Not that the Eltas are cheap ‒ they’re probably still like $60 a bottle, but it’s a big bottle, and it’s a slightly higher SPF
  - It’s probably like a 40 SPF instead of a 30
  - He’s just going to put it on in excess and cover his head and ears and neck and face
    - And he doesn’t care if he looks white

## The dangers of following unqualified aesthetic advice online and the importance of getting professional medical guidance for cosmetic treatments [1:18:00]

**The importance of working with a physician for aesthetic procedures**

- The other thing that Tanuj and Suzan talked about was don’t get your advice on this stuff from influencers
- Tanuj is an oculoplastic surgeon and Suzan is a dermatologist ‒ they both specialize in face and skin

> “*Don’t get your advice from people who are telling you what to do on Instagram. Go and seek professional help when it comes to this stuff*.”‒ Peter Attia

**They commented on a bunch of things they see that are very distressing**

- Overfilling lips, early use of Botox
- Especially young women doing this kind of stuff in their late teens and early twenties
  - Their view is that you just couldn’t think of a reason why that would be necessary, and these things can come back to haunt you

***Both Tanuj and Susan argued that a really good doctor should say “No,” to trendy or excessive requests, and you should judge the expertise by the restraint just as much as you should by the before and after photos that they show you***

- Persistent [fillers](https://www.cosmeticsurgery.org/page/DermalFillers) are a long-term liability
- During surgery, they routinely find hyaluronic fillers that have remained for 8-10 years stretching out ligaments, complicating later lifts

***Be conservative in anything you’re doing with fillers***

**They advocate for treating acne early**

- Treat acne before it scars

**⇒** The more inflammatory and cystic the acne is, the more likelihood that it will scar

- If you have cystic acne, [Accutane](https://en.wikipedia.org/wiki/Isotretinoin) really is the way to go
- The downsides are
  - You’re going to be very dry while you’re on it
  - You can’t drink alcohol
  - You can’t get pregnant [it’s [teratogenic](https://en.wikipedia.org/wiki/Teratology)]
- This treatment can be short
  - You’re on it for a few months and you can prevent long-term scarring

Nick jokes, “*I was going to say it’s kind of a bummer that they told people not to get advice from influencers on Instagram because my next question was going to be, when are we going to see your skincare routine in video on Instagram? But it sounds like that might not be coming now.*”

**Do you think if you would’ve leaned into the conversation with your daughter and her friends on cleansers and moisturizers instead of a lecture on skin aging, that conversation might’ve gone smoother?**

- You’ll have to ask Olivia how that went

Peter adds, “*For the record, I’m the coolest dad there is. It’s not coming across as a lecture. It’s just cool dad vibe. That’s all. It was not lecture-y.*”

**Suzan also made a big plug for** [**HRT**](https://en.wikipedia.org/wiki/Hormone_replacement_therapy)

- This was not a surprise after everything they talked about

***She said that the estrogen drop during menopause is a major accelerator of facial bone and fat loss, and that women should really be talking about HRT early if they want to slow what she calls the “20-year aging jump” that women experience during the menopause transition***

**⇒** The point can’t be overstated about the role estrogen plays in skin health and bone health

## BJ Miller/Bridget Sumser episode: lessons about living from the dying [1:21:45]

[#354 – What the dying can teach us about living well: lessons on life and reflections on mortality | BJ Miller, M.D. and Bridget Sumser, L.C.S.W.](https://peterattiamd.com/bjmillerandbridgetsumser/) (June 23, 2025)

\*\*\*

- BJ Miller was a past guest, very early on in the podcast [[episode #135](https://peterattiamd.com/bjmiller/)]
  - This was one of the very first remote guests we had because it was during COVID where we had a switch from in-person to remote
  - If anyone hasn’t listened to that, it’s an awesome podcast
  - BJ has a crazy story
  - BJ is an insanely cool dude, and so we were excited to have him back, and he brought along Bridget, his coworker
- In this episode we talked around not dying in the sense of what happens when you die, but more so as people who have worked with so many people on their deathbed, what are those insights that we can learn now that apply to us on how we live based on the lessons from what they’ve learned on people who have died?

**Really valuable insights around end of life and the difficult decisions that have to be made then**

- Even though BJ had spoken to Peter about this roughly 5 years earlier, just based on the circumstances in Peter’s own life, this was a very powerful thing to be discussing

*We shouldn’t confuse palliative care and hospice care*

- Palliative care is about comfort
- Hospice is really a subset of palliative care that is geared around the final month or so of life
  - Maybe final even 3 months of life

***BJ pointed out that too often people are coming to hospice too late, when patients are only spending days in hospice***

- Usually it suggests that they could have been spending longer in hospice

**⇒** Hospice is just as much for the family as it is for the patient

- Being able to untether a patient from a hospital where you’ve got checking of vitals and giving meds and the beeping and the noises and the smells and all of this stuff
  - It’s all worth it if it’s in service of trying to save life, but if the disease course has taken hold and those things can’t happen

> “*I can’t say enough about how much easier it is for the family and for the patient to be in a hospice setting*.”‒ Peter Attia

***Coming to that decision to enter hospice care earlier rather than later is really valuable***

*In this episode, BJ and Bridget talked a lot about what the final weeks and days of life are like for individuals*

- 1 – Just how much the dying process converges onto a series of somewhat predictable steps and how the final days really become clear in terms of what’s happening as the body is shutting down
  - The patient’s inability or complete lack of desire to eat or even drink and their level of arousal
- BJ said, “*Look, you’re rarely going to see these last words of a person being the most profound thing*.”
  - There’s an occasional moment of that, but for the most part in a person’s final days, their level of arousal is quite low, and as such, ***you don’t want to wait too long to have discussions that are hard discussions***
- This also really ties into something that [Walter Green](https://justsayitnow.org/about/) talked about on a podcast about a year and a half ago
  - [[episode #288](https://peterattiamd.com/waltergreen/)]
  - Peter would really recommend everybody go back and listen to it

**⇒** Walter’s idea around “Say It Now” was when you have something to say to somebody, you want to say it to them certainly not at their eulogy (when they’re not there), but you *don’t* want to say it to them in the last week of their life

- They’re not necessarily able to internalize it the same way as they might be able to internalize it while they’re alive and well
- There’s a lot more there to talk about, which maybe Peter will talk about in the future
- A lot of those points really hit home

*The most profound thing that Peter took away from this episode*

- A very simple response that BJ had to what was a very complicated question: Look, BJ, you’ve been around so many people who have died and you’ve probably seen really bad deaths and really good deaths. **What makes a good death?**
- BJ thought for a moment, and he said, “*Honestly, I think a good life is what makes a good death.*”
- It’s very difficult for a person to have a good death
  - And the way we were both speaking about it, we were using good as shorthand for surrounded by family, surrounded by loved ones, at peace with the life that has transpired

***What Peter took away from that discussion is that’s a lifetime of work to make that happen***

- It’s obviously very sad for the number of people who maybe come to that realization at the end of life and realize that they haven’t had the relationships with their family or they haven’t been the person they wanted to be

**⇒** Anybody who is listening to this by definition is still alive and therefore still has something that they can do about it to make sure that they are living the best life

- And that in and of itself along some very important steps:
- 1 – Having a very clear, [advanced directive](https://prepareforyourcare.org/en/prepare-for-your-care/advance-directive/advance-directive-welcome)
- 2 – Having frequent and clear discussions with family members about what your wishes are at the end of your life
- That’s the most that a person can ask for
- It’s not a subject people like to think about, but it is unfortunately the only inevitability of our species
  - People always talk about death and taxes
  - There’s lots of people that don’t pay taxes

> “*There’s only one inevitability, and this is it, so it’s worth thinking about.*”‒ Peter Attia

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Paul Turek**: [#351 ‒ Male fertility: optimizing reproductive health, diagnosing and treating infertility, and navigating testosterone replacement therapy | Paul Turek, M.D.](https://peterattiamd.com/paulturek/) (June 2, 2025) | [4:30]

**Episode of** ***The Drive*** **with Paula Amato**: [#352 ‒ Female fertility: optimizing reproductive health, diagnosing and treating infertility and PCOS, and understanding the IVF process | Paula Amato, M.D.](https://peterattiamd.com/paulaamato/) (June 9, 2025) | [4:30]

**Episode of** ***The Drive*** **with**: [#348 ‒ Women’s sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.](https://peterattiamd.com/rachelrubin/) (May 12, 2025) | [31:45]

**Episode of** ***The Drive*** **with Brian Kennedy**: [#357 ‒ A new era of longevity science: models of aging, human trials of rapamycin, biological clocks, promising compounds, and lifestyle interventions | Brian Kennedy, Ph.D.](https://peterattiamd.com/briankennedy/) (July 21, 2025) | [46:15]

**Episode of** ***The Drive*** **with Tanuj Nakra and Suzan Obagi**: [#355 – Skincare strategies, the science of facial aging, and cosmetic-intervention guidance | Tanuj Nakra, M.D. & Suzan Obagi, M.D.](https://peterattiamd.com/tanujnakraandsuzanobagi/) (June 30, 2025) | [57:30]

**Episode of** ***The Drive*** **with BJ Miller and Bridget Sumser**: [#354 – What the dying can teach us about living well: lessons on life and reflections on mortality | BJ Miller, M.D. and Bridget Sumser, L.C.S.W.](https://peterattiamd.com/bjmillerandbridgetsumser/) (June 23, 2025) | [1:21:30]

\*\*\*

**Bike seat recommendations**: [8:15]

- [Best Saddle for Perineal Numbnesses – July 2025](https://www.top5-usa.com/saddle-for-perineal-numbness?targetid=dsa-41066162664&matchtype=&device=c&campaignid=19691655358&creative=648221012362&adgroupid=145513486265&feeditemid=&loc_physical_ms=9028299&loc_interest_ms=&network=g&devicemodel=&placement=&keyword=$&target=&aceid=&adposition=&trackid=us_all_top5_1_1&mId=895-263-6903&gad_source=1&gad_campaignid=19691655358&gbraid=0AAAAAoKwm5SkO-i455SfazulMNf7wlCIo&gclid=CjwKCAjwi-DBBhA5EiwAXOHsGSTwIy6EU85wmPUr6Fl2IAitNqAxFPGpYLs7lHvyZ60VKS2hEOEWVxoCLjEQAvD_BwE) | Top USA (2025)
- [PN 3.1](https://shop-us.ismseat.com/collections/performance-saddles/products/pn-3-1) | ism (2025)

**Discussion of intranasal testosterone**: [12:45]

- [#260 ‒ Men’s Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.](https://peterattiamd.com/mohitkhera/) (June 26, 2023)
- [#291 ‒ The role of testosterone in males and females, performance-enhancing drugs, sustainable fat loss, supplements, and more | Derek, More Plates More Dates Pt.2](https://peterattiamd.com/derekmpmd2/) (February 26, 2024)

**Episode of *The Drive* with BJ Miller**: [#135 – BJ Miller, M.D.: How understanding death leads to a better life](https://peterattiamd.com/bjmiller/) (November 2, 2020) | [1:21:45]

**Episode of *The Drive* with Walter Green**: [#288 ‒ The impact of gratitude, serving others, embracing mortality, and living intentionally | Walter Green](https://peterattiamd.com/waltergreen/) (February 5, 2025) | [1:25:15]

---

## People Mentioned

- [Mohit Khera](https://drmohitkhera.com/about/) (Urologist, Professor of Urology and the F. Brantley Scott Chair in Urology at Baylor College of Medicine where he is also the Director of the Laboratory for Andrology Research at the McNair Medical Institute and the Medical Director of the Executive Health Program) [13:00]
- [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) (CEO of Optispan, Affiliate Professor and Co-Director of the Dog Aging Project at at the University of Washington, expert on interventions to promote healthspan) [55:15]
- [Walter Green](https://justsayitnow.org/about/) (Chairman of the Board and CEO of Harrison Conference Services for 25 years; author of [*This Is The Moment*](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1) and the “Say It Now” movement) [1:25:15]