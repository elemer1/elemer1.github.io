# #186 – Patrick Radden Keefe: The opioid crisis—origin, guilty parties, and the difficult path forward

**Source:** [https://peterattiamd.com/patrickraddenkeefe/](https://peterattiamd.com/patrickraddenkeefe/)

---

Patrick Radden Keefe is an award-winning staff writer at The New Yorker and the bestselling author of *Empire of Pain: The Secret History of the Sackler Dynasty*. In this episode, Patrick tells the story of the Sackler family and Purdue Pharma – makers of the pain management drug OxyContin, providing the backdrop for the ensuing opioid epidemic and public health crisis. He reveals the implicit and sometimes explicit corruption of all parties involved in the development, approval, and marketing of OxyContin, leading to a cascade of unintended consequences including addiction and death. He explains the unfortunate lack of accountability for the current crisis, as well as what it all means for those with legitimate pain management needs. Finally, he examines the difficult path ahead towards finding a solution.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/patrickraddenkeefe/the_Drive_public.png)

Play

#186 - Patrick Radden Keefe: The opioid crisis—origin, guilty parties, and the difficult path forward

#186 - Patrick Radden Keefe: The opioid crisis—origin, guilty parties, and the difficult path forward

1x15s30s

0:001:55:56

## We discuss:

- Patrick’s investigation into distribution and use of drugs in our society [3:55];
- The scale of of the opioid crisis [9:15];
- The Sackler brothers: family life, career in the pharmaceutical industry, and role in the current crisis [11:45];
- Purdue Pharma: origins, early years, and move towards pain management drugs [17:30];
- The development of OxyContin: its conception, marketing, and the controversy around the FDA approval process [25:30];
- Early reports of OxyContin addiction and unintended consequences and how Purdue Pharma sidestepped responsibility [40:45];
- The many paths to addiction and abuse of OxyContin and the ensuing downfall of Purdue Pharma [47:15];
- Peter’s personal experience with OxyContin [57:00];
- Pain—the “fifth vital sign,” how doctors are trained in pain management, and the influence of money [1:08:00];
- Other players that helped facilitate the eventual opioid crisis [1:16:15];
- Lack of accountability following the investigation and prosecution of Purdue and the Sackler family [1:23:30];
- Legacy of the Sackler family and their disconnect from reality [1:34:45];
- Patrick’s views on the regulation and use of pain management drugs [1:42:15];
- The difficult path forward [1:44:45]; and
- More.

§

## Show Notes

**\*Intro notes\***

- The guest this week is Patrick Radden Keefe, an award-winning staff writer at *The New Yorker* magazine and a *New York Times* bestselling author
- His most recent book is about the opioid epidemic
  - It’s a New York Times bestseller, [Empire of Pain: The Secret History of the Sackler Dynasty](https://www.amazon.com/Empire-Pain-History-Sackler-Dynasty/dp/0385545681/ref=sr_1_1?keywords=Empire+of+Pain%3A+The+Secret+History+of+the+Sackler+Dynasty%3B&qid=1636118088&qsid=130-9088744-0739012&sr=8-1&sres=0385545681%2CB09HCDWY14%2CB09HG6WMQC%2CB092RNV8YK%2CB09H7Q8M4X%2CB098RY9D6X%2C0674399684%2CB09K4KQCTP%2CB0782X9R1W%2C1480748978%2CB000JMKNFQ%2CB002IN7PM8%2C0976309637%2C0987342665%2CB08RR5ZFKQ%2CB09HGQ81JY&srpt=ABIS_BOOK)

![](https://peterattiamd.com/wp-content/uploads/2021/12/f1.-keefe.png)

**Figure 1. Patrick’s book about the opioid epidemic.**  Image credit: [Amazon.com](https://www.amazon.com/Empire-Pain-History-Sackler-Dynasty/dp/0385545681/ref=sr_1_1?keywords=Empire+of+Pain%3A+The+Secret+History+of+the+Sackler+Dynasty%3B&qid=1636118088&qsid=130-9088744-0739012&sr=8-1&sres=0385545681%2CB09HCDWY14%2CB09HG6WMQC%2CB092RNV8YK%2CB09H7Q8M4X%2CB098RY9D6X%2C0674399684%2CB09K4KQCTP%2CB0782X9R1W%2C1480748978%2CB000JMKNFQ%2CB002IN7PM8%2C0976309637%2C0987342665%2CB08RR5ZFKQ%2CB09HGQ81JY&srpt=ABIS_BOOK)

- Peter has been wanting to do a podcast on the opioid epidemic for some time, and he’s been trying to think of the right way to do it
- Recently, he saw the HBO documentary, [*The Crime of the Century*](https://en.wikipedia.org/wiki/The_Crime_of_the_Century_(2021_film)), and thought it was a really good and thorough overview of the problem

![](https://peterattiamd.com/wp-content/uploads/2021/12/f2.-keefe.png)

**Figure 2. Movie Poster.**  Image credit: [by Studio and or Graphic Artist](https://en.wikipedia.org/w/index.php?curid=67628839)

- This is a problem that has many layers to it, right?
  - It has the organizations that actually make these drugs, so the producers and the pharma companies
  - It has the organizations that distribute these drugs between the producers and the end-stage or end-use retailers, so the intermediaries
  - It has the retail side of things, where these drugs are purchased
  - The physicians who prescribe these drugs
  - The patients who use these drugs
  - The enforcement agencies that regulate them
  - The FDA that approves these drugs
  - The medical advocacy groups that provide guidance to physicians about them
- Consider the landscape of this problem and all of the actors just listed, each one of them plays some role in the current situation
  - Half a million people have died in the past 25 years from opioid overdose
  - Opioid overdose now represents the leading cause of accidental death in the United States
    - Ahead of car accidents, gunshots, and things like that
- Patrick’s book goes straight to the heart of the matter to explain:
  - How did this begin?
  - What was the thin end of the wedge that created this epidemic?
  - He makes a very compelling case that it was the company, Purdue Pharma, a privately held company run by the Sackler family
- This episode will discuss at great length the history of the Purdue Pharma Company and its management team
  - About the implicit and sometimes explicit corruption that existed
  - About the other players in this channel, the physicians, the regulators, the politicians
    - none of whom really get off scot-free in this assessment
- This is a bit of a depressing episode
  - There is not much optimism that a solution is in hand and that 5 years from now, one will look back at this and marvel at how easily it was able to be solved
- Peter feels it is important to expose and shed some light on how the opioid crisis came to be

## Patrick’s investigation into distribution and use of drugs in our society [3:55]

- Patrick has always been interested in drugs as a subject
  - The way in which drugs fit into our society
  - How we feel about them
  - Which drugs are licit, which drugs are illicit
- He wrote a big piece a number of years ago about the legalization of cannabis in Washington State
  - In *The New Yorker* in 2013, [Buzzkill: Washington State discovers that it’s not so easy to create a legal marijuana economy](https://www.newyorker.com/magazine/2013/11/18/buzzkill)
- He is very interested in this idea that you have this existing industry, this pot industry that’s been around for decades, and with the stroke of a pen at midnight it’s legalized
  - What does that look like?
  - How does it turn into a taxed and regulated economy?

**Mexican drug cartels**

- He had done a lot of writing on Mexican drug cartels
  - Before he was full-time at *The New Yorker*, he did a cover story for *The New York Times Magazine* in 2012 about the Sinaloa drug cartel, [Cocaine Incorporated](https://www.nytimes.com/2012/06/17/magazine/how-a-mexican-drug-cartel-makes-its-billions.html)
    - To put this in context, at the time he had to explain to the editors of *The New York Times Magazine* who [Chapo Guzmán](https://en.wikipedia.org/wiki/Joaqu%C3%ADn_%22El_Chapo%22_Guzm%C3%A1n) was
- He wanted to do sort of a Harvard Business School case study of a cartel
  - He wanted to look at it as a multi-billion dollar transnational commodities enterprise
  - He was really interested in how they diversified and how vertically integrated they were
- The [Sinaloa cartel](https://en.wikipedia.org/wiki/Sinaloa_Cartel) dealt in cocaine, marijuana, heroin, and methamphetamine
- One of the questions that grew out of that research had to do with the surge in heroin
  - After 2010, huge volumes of Mexican heroin started coming across the border in ways that hadn’t been seen before in the US; this was the riddle he started with
  - He started with this question of why is there a sudden uptick in heroin trafficking in the US
    - The answer was the opioid crisis

**Complex web of entities involved in the opioid crisis**

- He started out with an inquiry that was solidly grounded in the realm of the illicit drug trade and found his way into the world of the FDA regulated legal drug trade with [OxyContin](https://en.wikipedia.org/wiki/Oxycodone) and [Purdue Pharma](https://en.wikipedia.org/wiki/Purdue_Pharma)
  - So he started looking into the origins of the opioid crisis
  - He then discovered that this company (Purdue) was owned by the [Sackler family](https://en.wikipedia.org/wiki/Sackler_family)
    - This blew his mind, the idea that this family that’s quite well known for philanthropy had made such a huge fortune on a drug with such a controversial legacy
- A long time ago when Peter was trying to get his mind around how many actors there were in the opioid crisis, he drew on a piece of paper
  - It started on the left with the producers
    - Not illicit chains but pharma companies of which Purdue was the champion of them
  - Then there were the distributors or intermediaries
    - The [McKessons](https://en.wikipedia.org/wiki/McKesson_Corporation) and the [Cardinals](https://en.wikipedia.org/wiki/Cardinal_Health) of the world
      - He actually knew a lot about McKesson through a previous life
      - He was intimately familiar with what companies like McKesson did and how they were able to distribute products from the producers to the retail, the pharmacy, the CVSs of the world, so that became the third actor
  - The 4th actors were the [FDA](https://en.wikipedia.org/wiki/Food_and_Drug_Administration) (the approval process of the drug) and the [DEA](https://en.wikipedia.org/wiki/Drug_Enforcement_Administration) (enforcement)
  - There are policymakers that create the policies that allow these entities to exist
  - There are the providers, people that write the prescriptions for these things
  - And ultimately there are the patients
- The study of Purdue Pharma and the Sacklers, more than any other single entity in this entire chain he just explained, can provide a greater context of what we’re up against
- Patrick notes that the nuance of all the actors in this crisis often gets lost
- He writes stories where his interests lead him, stories he thinks are interesting and important and that will be interesting to readers
- He doesn’t claim his work is the be-all and end-all in understanding the opioid crisis
  - This is an incredibly complex public health crisis that has unfolded over the course of a quarter of a century

## The scale of of the opioid crisis [9:15]

- At  least a half a million people who’ve died from opioid overdoses since the mid to late 1990s
- By some estimates, there are two plus million Americans today struggling with an opioid use disorder of one sort or another
- [Opioids](https://en.wikipedia.org/wiki/Opioid) are a pretty capacious category
  - This includes regulated drugs like [OxyContin](https://en.wikipedia.org/wiki/Oxycodone) and [fentanyl](https://en.wikipedia.org/wiki/Fentanyl) that comes in from China or Mexico
  - It’s also [heroin](https://en.wikipedia.org/wiki/Heroin)
- Think about the death toll today, the Sacklers would be quick to say, today, people are dying in very large numbers from heroin and fentanyl overdoses, not from OxyContin or from most prescription painkillers
- This problem has transitioned into an illicit drug problem
- So why did Patrick pick OxyContin? Why pick the Sacklers?
  - Because it’s an interesting story
- He’s interested in the fact that this was a family, and the family dynamics are interesting in part because of the philanthropic legacy
  - There’s this kind of disconnect (or there was until recent years) between the reputation that the family had and what I would argue as the reality of their business
- Most importantly, he thinks OxyContin was sort of the tip of the spear, the kind of nuance that often gets lost
- It can be possible to stipulate that today the opioid crisis is a heroin and fentanyl crisis
- Keep in mind the idea that absent OxyContin, the opioid crisis might not be what it is today
  - OxyContin was the kind of first-mover in terms of changing prescribing habits in the United States in a way that had really fundamental consequences and ultimately built up a market for these drugs
  - This market eventually migrated to illicit sources of supply
    - This is the reason he thinks there is a special role that Purdue and the Sacklers played in the crisis
    - But this doesn’t suggest that there isn’t blame with all those different buckets mentioned earlier

## The Sackler brothers: family life, career in the pharmaceutical industry, and role in the current crisis [11:45]

- The 3 Sackler brothers are [Arthur](https://en.wikipedia.org/wiki/Arthur_M._Sackler), [Raymond](https://en.wikipedia.org/wiki/Raymond_Sackler), and [Mortimer](https://en.wikipedia.org/wiki/Mortimer_Sackler)
- They were the children of immigrants; their parents had come over from Europe at the turn of the last century and settled in Brooklyn
  - They were Jewish
  - The parents didn’t speak English well; they spoke Yiddish in the home
  - They valued education and meritocracy
- There are these kinds of very American mythical contours to the early parts of this story, where there’s a family that came with nothing and had an expectation that within the span of one generation, they would build an empire and make their mark on the country and the world
- Arthur later said that from the age of four, he knew he would be a doctor
  - There was a sense that there was kind of nothing as prestigious and virtuous as being a doctor
  - There was a real veneration in this family for the role of the physician in society
- They grew up against the backdrop of the Great Depression
  - There’s a period where their father loses everything
  - And so there was an expectation that the brothers have to go out there and hustle and make money and have jobs
    - All three brothers worked multiple jobs
    - For Arthur Sackler, it’s like he squeezed four or five lifetimes into one lifetime in terms of everything that he did
- They end up eventually in the pharmaceutical business
- But the way they get there is through pharmaceutical advertising and marketing
  - This starts when Arthur Sackler is in high school, he gets jobs on the student publications
    - He is at a huge high school, [Erasmus Hall High School](https://en.wikipedia.org/wiki/Erasmus_Hall_High_School)
    - There are 6,000-7,000 students in Brooklyn, in [Flatbush](https://en.wikipedia.org/wiki/Flatbush,_Brooklyn)
  - He gets jobs on the student magazine and the student newspaper, but he becomes the advertising manager
    - Think about it, there are 6 or 7,000 students that he can reach; this was a real job
    - This is where the hustle starts with Arthur
- All 3 brothers end up becoming psychiatrists, practicing as psychiatrists
  - But they pretty quickly pivot into commerce
- There is this amazing moment early on, a pattern that Arthur goes and he does something, and then he brings his brothers in with them
  - This starts in high school
  - He’s got more jobs than he can handle so he starts handing them off to the brothers

**Creedmoor Psychiatric Hospital**

- Arthur and his brothers ends up at the [Creedmoor Psychiatric Hospital](https://en.wikipedia.org/wiki/Creedmoor_Psychiatric_Center)
  - This is a huge asylum, a vast kind of industrial asylum in Queens, New York, a public state mental hospital
  - It was a facility designed for 4,000 beds
- It’s interesting because, this is pre-[Thorazine](https://en.wikipedia.org/wiki/Chlorpromazine)
- It’s one of the last maximalist phase of big state mental hospitals
- People were basically being warehoused for life in these facilities
- It’s just prior to the deinstitutionalization that happens in the decades that follow
- The brothers get there and they’re shocked by the conditions
  - Arthur, in particular, was trained as a [Freudian](https://en.wikipedia.org/wiki/Sigmund_Freud)
  - There’s not a lot of talk therapy happening at a 6,000-bed hospital
  - Lobotomies, electroshock treatment, and things like that were still being done
- The brothers are administering electroshock treatments thousands of times
  - It probably became more and more demoralizing for them because they just felt as though, “*how can we as physicians not have developed some more humane way of administering to our patients?*”
- At this early point, they develop this theory, that a lot of the afflictions they’re seeing probably have some basis that is fundamentally chemical
  - Therefore there is probably a chemical solution
  - The brothers don’t have anything to do with Thorazine, but when it comes along, they see that as a glimpse of the future they had envisioned

**The context of the pharmaceutical business when the Sackler brothers come of age**

- Generally speaking, it was an exciting time in the pharma business
- [Penicillin](https://en.wikipedia.org/wiki/Penicillin#History) was a huge game-change in the Second World War
- A lot of these companies that today we think of as big pharma, prior to the Second World War, they didn’t really look like they do now
  - They were producing chemicals, but they weren’t really producing branded drugs in quite the same way
  - And then it becomes this go-go period where they’re all competing, and they’re developing new antibiotics, and they’re coming out with new products every few weeks, and suddenly they need to differentiate themselves
  - Consumers are no longer going to the pharmacy and having the pharmacist mix whatever it is that their doctor has prescribed; they’re going in and requesting drugs by their brand name
  - The Sackler brothers come of age in this exciting, idealistic, whirlwind climate

## Purdue Pharma: origins, early years, and move towards pain management drugs [17:30]

- The origins of [Purdue Pharma](https://en.wikipedia.org/wiki/Purdue_Pharma) date back to the 19th century
  - It was a little patent medicine company based Christopher Street in [Greenwich Village](https://en.wikipedia.org/wiki/Greenwich_Village)
    - One can go to the building that it once occupied
    - It’s funny that what had once been the humble Purdue Frederick factory is today somebody’s $18 million townhouse
- In 1952, Arthur Sackler had already achieved a great deal of financial success
  - Not in the drug business per se, but in pharmaceutical advertising
  - Arthur really makes his name by joining and then taking over a pharmaceutical advertising firm
  - He’s a genius for advertising drugs
  - This is a point where all these drug companies need to figure out ways to differentiate their products and reach doctors and persuade them to prescribe
- With some of the money he’s made, Arthur purchases this company, Purdue Frederick
  - He basically gives it to his brothers
  - He’s a stakeholder in the company; he owns a third of it, but he’s a silent partner basically
  - The brothers run the company starting in ’52
- Purdue Frederick is a very successful company
  - The brothers get rich
  - But they’re getting rich in a way that even Arthur would probably have sniffed at
- Arthur focuses on the marketing of pharmaceuticals
  - His biggest success (he had many successes) is the way he designs the marketing and advertising strategy for the minor tranquilizer, [Librium](https://en.wikipedia.org/wiki/Chlordiazepoxide), and then for [Valium](https://en.wikipedia.org/wiki/Diazepam) (both of which [Roche](https://en.wikipedia.org/wiki/Roche) develops)
    - Librium becomes the biggest selling drug in the history of the pharmaceutical industry
    - And then it’s surpassed only by Valium
    - And then for years, the two of them are in the top five drugs nationwide
- Arthur designed all the advertising and the marketing for that
- He devised this interesting compensation scheme where basically he said, “*I’m going to get an escalating series of bonuses, depending on how many pills you sell and there’s no ceiling.*”
  - So he becomes vastly wealthy on the basis of these drugs
- Meanwhile, the work of his brothers is less cutting edge
  - They basically license over-the-counter products and then sell them
  - They were really smart about it
  - They had an antiseptic solution, [betadine](https://en.wikipedia.org/wiki/Povidone-iodine), which is still out there, and they got the rights to that just before the Vietnam War; it had battlefield applications
  - They had a laxative, [Senokot](https://en.wikipedia.org/wiki/Senna_glycoside), very successful
    - These are the kinds of cash crop products
    - They’re very unglamorous; but they’re staples, over-the-counter stuff; but year in year out, they’re very, very successful

**Purdue Pharma’s early interest in pain management [20:15]**

> “The irony… of the company that would create the opioid boom having a laxative… to address one of the most painful, short-term consequences of opioid use being constipation” – Peter Attia

- Patrick agrees and adds that sales reps for Purdue would go out and market OxyContin and laxatives together
- It’s only in the late ’70s, early ’80s, that the company starts getting aggressive about investing in R & D developing its own prescription drugs
  - It’s at that point that they move into pain management

*Why Purdue Pharma remains a private company when others go public*

- Many of the large pharma companies go public, any inclination why the brothers decided to keep Purdue private?
- Patrick speculates that the Sacklers had a real sense that this was a old-world enterprise
  - This was a family-owned, physician-owned business
  - There was a sense that they controlled it and they thought of the people who worked for them as family
  - It’s really only with the advent of OxyContin in the ’90s that it becomes this multi-billion dollar company; up to that point, it was a pretty modest outfit
  - The brothers were very wealthy, but it was a kind of manageable, family firm
- He doesn’t know what it would’ve looked like if it went public
- However, getting into the later stages, post the introduction of OxyContin, there’s a lot of stuff that happens in this story that would never happen in a public company
  - How do they handle it when they start getting calls saying that the product they sell is killing people?
  - Patrick thinks there probably would have been a different response in a public company
  - Then the really crazy thing is eventually, there is a guilty plea in a federal criminal case in 2007 (he’ll come back to this)
  - He thinks if this had happened at a public company, heads would have rolled
    - There would have been a total change of personnel, a big shakeup on the board
    - At a privately held family company, what happened was pretty much nothing

**Doctors view of pain changes**

- Dating back to the ’70s, there is a kind of revisionist school of physicians (in the UK and in the US and in other parts of the world) who felt that the medical establishment had been not taking pain seriously enough as a problem, that doctors weren’t treating pain aggressively
  - They felt doctors were treating pain just merely as a symptom and not as a problem in and of itself
  - That there wasn’t enough medical education for physicians in terms of identifying pain and responding to it
  - Going along with this was a sense that many physicians had, that there was a resistance to prescribing opioids out of a fear of addiction
    - A feeling that doctors had been too stingy in prescribing opioids for pain because of concerns about abuse and addiction

**MS Contin, the precursor to OxyContin [23:00]**

- This is the context that the drug [MS Contin](https://www.rxlist.com/ms-contin-drug.htm) is developed
  - It’s a drug for cancer pain
  - It’s basically just morphine
- The real innovation was the contin part; contin is short for continuous
  - It’s essentially just the coating on the pill
  - The idea is that this will regulate the flow of the drug into the bloodstream over the course of hours
- MS Contin was developed in the UK and then rolled out in the US
  - It was a groundbreaking drug in its way; very successful for the company
  - Patrick doesn’t remember exactly what it was generating in terms of revenue at its height, but $300 or $400 million a year, which was a lot for Purdue at the time
- The family was proud of this drug; there was a sense that they were doing a good thing
  - They were relieving terrible pain for people suffering from cancer
  - They were doing very well financially
  - In this world of doctors who were thinking about pain and wanting to kind of reevaluate the way in which pain is treated, they were heroes
- There was an interesting, and not necessarily cynical confluence of interests in which Purdue starts sponsoring academic conferences on the treatment of pain and medical conferences and seminars
- They’re sort of out there with an obvious commercial interest, but also with a sense that they are part of a revolution, thinking “*we’re going to revolutionize the way in which pain is treated.*”

## The development of OxyContin: its conception, marketing, and the controversy around the FDA approval process [25:30]

- Peter notes that in some sense OxyContin is an obvious leap because if MS Contin is simply morphine sulfate formulated in a continuous fashion, there are other narcotics out there
  - [Percocet](https://www.rxlist.com/percocet-drug.htm) already existed; it was simply [hydrocodone](https://en.wikipedia.org/wiki/Hydrocodone) with [Acetaminophen](https://en.wikipedia.org/wiki/Paracetamol)
  - Hydrocodone existed by itself in a non-time-release format
  - So was their great innovation basically saying, we’re just going to make a time-release version of hydrocodone, just as it had been done with morphine?

**Patents and profitability**

- When Patrick began researching this topic he was really startled to discover the importance of the life cycle of a patent to a drug company
  - He notes, “*I don’t think I fully appreciated the degree to which it is the sun and the stars and it’s everything*”
  - There were so many points in the course of his reporting for this story where there’d be some sort of mystery about motivation, a weird thing they did, and he couldn’t figure out why
    - It always turned out to be something having to do with a patent
- The pediatric indication is a good example
  - At a point where OxyContin was hugely controversial already and causing all kinds of problems, they applied for the pediatric indication for the drug
  - It turned out it was because they thought they would get an additional six months of patent exclusivity if they got it
- In the case of MS Contin, the patent is running out at a certain point, and they realized that it’s going to decimate their profits
  - They just start talking about, hey, what else could we put with the contin system?
  - The family dynamics here are a little humorous; according to Kathy Sackler (who’s one of the second generation Sacklers who was involved in the company and is a medical doctor), she has dinner with [Richard Sackler](https://en.wikipedia.org/wiki/Richard_Sackler) (her cousin and kind of rival within the company at a certain point) and she suggests, what about oxycodone?
    - And according to her, Richard didn’t know what oxycodone was and she had to explain it

**Marketing to increase drug sales**

- [Oxycodone](https://en.wikipedia.org/wiki/Oxycodone) stronger than both [hydrocodone](https://en.wikipedia.org/wiki/Hydrocodone) and [Morphine](https://en.wikipedia.org/wiki/Morphine)
- Patrick notes what’s interesting about oxycodone is when the company makes their decision to use oxycodone to develop OxyContin, there are these conversations that happen and they happen over email,
  - Patrick has emails where these senior executives at the company and Richard Sackler are talking about the market, and the idea that MS Contin was a drug for cancer pain, and the stigma associated with morphine
  - This notion that if you’re a regular person and not a doctor, and your doctor tells you that your mother’s going on morphine, that means your mother is going to die
    - What they realize is that oxycodone didn’t have those same associations, even though it’s stronger than morphine.
- They did focus groups about [oxycodone](https://en.wikipedia.org/wiki/Oxycodone), [Percocet](https://www.rxlist.com/percocet-drug.htm), and [Percodan](https://www.rxlist.com/percodan-drug.htm); and that was the primary way in which physicians were encountering those drugs
  - And when they’re cut with aspirin or acetaminophen, it’s a relatively small dose, there’s only so much one can take
  - What they noticed in these focus groups is that physicians had a sort of a sense of oxycodone as more benign, less threatening, there was less stigma, but also they saw it as weaker
- There are these incredible emails where they say, well, listen, there’s only so many people who have cancer pain, “*we did great with our cancer drug, but there’s a much bigger market out there of people suffering not just from severe pain, but moderate pain, chronic pain, back pain, sports injuries*”
  - The marketing of oxycodone ended up creating the need for this drug
- The first third of Patrick’s book is devoted to Arthur Sackler in those early years; he dies in ‘87 before the introduction of OxyContin
- Patrick thinks there are all of these things that happen earlier that are kind of the seeds for what comes later
- So the analogy he always thinks of is [Thorazine](https://www.rxlist.com/thorazine-drug.htm), which the original Sackler brothers see in action; and Thorazine is a major tranquilizer for people who are psychotic
  - It emptied out the asylums pretty quickly; it was a real game-changer; but there’s only so many people who actually require that kind of heavy-duty solution
  - Arthur Sackler made his fortune on the minor tranquilizers, Librium and Valium
    - And who among us doesn’t feel a little stressed at the end of the day; who couldn’t benefit from something to make them relax a little bit
    - This is was what turned Librium and Valium into these huge blockbusters
- It’s kind of a similar thing here where there’s this sense that MS Contin is a drug for this subset of people who are experiencing terrible cancer pain
  - There’s a much bigger community of people who have moderate pain, but the weirdness of it is that they then take a drug that is stronger, not weaker and market it that way
- These emails show the way in which these executives say “*in our focus groups, doctors erroneously think that oxycodone is weaker than morphine. Let’s not do anything to make them realize that they’re wrong about the product that we’re selling them, because if we did, it could constrain our market.*”

**FDA approval**

- There’s a guy named Curtis Wright, who was the medical examiner at FDA who was kind of the grand inquisitor; he was the one they had to satisfy in order to get the drug approved
  - He also was the one they had to satisfy in order to get the marketing claims
- Richard Sackler, the second generation Sackler is probably the, the most intimately acquainted with or involved with OxyContin
- There’s a point where he talks about how the package insert in a bottle of pills is our most potent selling instrument
  - Patrick finds this strange, because for the average consumer, the dense wording of the package insert, the fine print, it feels like something that doctors read; it doesn’t feel like marketing
  - For the drug company, it’s all about the indication
    - It’s all about the claims they can make for what kinds of ailments this medication might alleviate

**Competitive positioning**

- An extreme example in the case of OxyContin, they didn’t do any tests on the addictiveness of the drug
  - They didn’t do any tests on the abuse liability of the drug
- There was a kind of hypothesis that they had at Purdue, which was because of the contin system, there wouldn’t be the kind of peaks and troughs – a sort of wave of euphoria when a big dose of the drug hits the bloodstream, followed by diminution and then withdrawal
  - Instead, it’s this steady regulated, continuous flow
  - Their hypothesis was that because of that, it wouldn’t be addictive and it wouldn’t be subject to abuse
  - That was a competitive advantage vis-a-vis other opioid products that were out there on the market

**Unusual actions during the FDA approval process**

- There was a crazy stretch where they start working very closely with Curtis Wright on the approval process; some strange stuff happens
- The company sends  Curtis Wright a webcam in ‘95 (Patrick doesn’t even think this is in the book)
- This is a very early webcam where he can talk directly with folks in Stanford
- Curtis Wright starts requesting that they send things, not to his FDA office, but to his house
- At a certain point, a team of people from Purdue travel to Maryland and get a hotel room and they spend three days with Curtis Wright, helping him write his reviews of their studies
- Peter comments, “*It’s almost impossible to imagine that happening. I’m not saying it didn’t because you’ve got email proof that it happened. I’m just saying from a matter of process, that statement is so difficult to comprehend. How do we put that in perspective? What did other people at the FDA know at this point in time?*”
- Patrick got Curtis Wright on the phone but he very quickly hung up; he didn’t want to talk about any of this
- Patrick filed a freedom of information act request with the FDA; they dragged their feet in the way that federal bureaucracy’s always do
  - So he sued them in federal court to compel them to turn over documents
- He got a New York federal judge to order them to do document production for him, thousands and thousands of pages of documents
  - His first request was for all the emails of Curtis Wright
  - This is a guy who had been investigated by Department of Justice starting in 2002, 2003; this was somebody who was red flagged early by other federal agencies
  - The FDA came back and told me that all of his correspondence and emails have either been lost or destroyed
    - It was a sort of a document retention thing where after a certain number of years, they eliminate stuff
  - Their response was pretty shocking to Patrick
- Some of this email has come out, not through the FDA, but through federal investigations of Purdue
- There’s an interesting moment where one of the Purdue officials says that he happened to bump into Curtis Wright at a conference
  - As all of this approval stuff’s happening, they talked informally, in a kind of a sidebar way
  - There’s this interesting memo that the Purdue guy sends back to headquarters where he says, “*I got talking with Curtis Wright, it was great. We talked about the whole OxyContin thing. He indicated that he would be open to other such informal exchanges in the future or something to that effect.*”
    - Patrick doesn’t know what this means
- Peter notes that a year after leaving the FDA, Curtis Wright becomes employed by Purdue Pharma
  - He asks the question, “*isn’t the only obvious explanation here that there was a quid pro quo, a very clear and direct quid pro quo made between Purdue and Curtis Wright?*”
- The former federal prosecutor, longtime federal prosecutor from the Western district of Virginia who prepared the biggest case against Purdue and spent years pouring over millions of pages of documents and looked really hard at Curtis Wright, he told Patrick on the record (and this is a guy who was pretty careful about what he says), “*I think a deal was made. He said, I can’t prove it. Just my opinion. But I think a deal was made.*”
  - Patrick doesn’t even think Purdue had to say, “*hey, make this work for us; and there might be a job for you on the other side*”

**Soft corruption**

- From a policy point of view, this gets really hard to regulate, right?
  - The FDA is full of overeducated, really smart people who are making government salaries
  - They have the unglamorous task of working on these approvals
  - And on the other side of the table is this huge multi-billion dollar industry where one can make a lot of money and where there’s a great deal of interest in former FDA officials, both in having them come and work at the pharmaceutical firm because it’s useful in a whole bunch of ways
- He would argue, there’s probably a great deal of interest in having the FDA officials that you’re talking to know that someday there might be a job for them
  - This is a hard thing because it’s not corruption in an explicit quid pro quo sense
  - It’s not corruption in a way that’s actually all that easy to police
    - What should the FDA do?
    - Have a cooling off period when someone leaves the agency. How long? A year? Three years?
      - At what point do they start losing talent?

> “I don’t mean to suggest for a second that these are easy questions, but I also think there’s what I would call a kind of soft corruption that pervades this whole process.” – Patrick Radden Keefe

- This is not unique to Curtis Wright; he’s a very extreme example
  - He continues to work at the FDA for a year after OxyContin is approved; then he goes and works at Purdue for three times his government salary

**The odd label on the packaging**

- To the point about the marketing claims, there’s a line in the original package insert for OxyContin that says the content seal is believed to reduce the abuse liability of the drug
  - This is a weird thing to have in a package insert in general
  - It’s a great marketing claim, but if believed it doesn’t seem very scientific necessarily
- No studies were done to back up this claim
  - In this case, it was conjecture
  - They reasoned that because someone taking this drug doesn’t get the high highs and low lows, therefore, it would make it less prone to abuse than other drugs

> “The real measure of how compromised this line was is that to this day, nobody will admit writing that line.” – Patrick Radden Keefe

- Curtis Wright has been asked about this and he said, “*oh yeah, it wasn’t the FDA, it was Purdue pharma*” and the Purdue pharma officials who were there say, “*oh, it wasn’t us, it was Curtis Wright*”
  - Patrick feels that the FDA worked so closely with the drug company, that literally he don’t know where one ends and the other begins

> “There’s a line that ends up in the package insert, claiming that this drug is safer than other alternatives, and nobody can tell you who wrote it” – Patrick Radden Keefe

## Early reports of OxyContin addiction and unintended consequences and how Purdue Pharma sidestepped responsibility [40:45]

**Timeline from release to reports of addiction**

- OxyContin become available in ‘96
- What are the unintended consequences of this drug?
  - 1) People use this drug who would probably be better served using another drug
  - 2) People taking the drug become addicted and some die
- What were the canaries in the coal mine that drew attention to any unintended consequences
- The official story is the drug’s released in early ’96 and according to sworn testimony by several senior executives at the company and by Richard Sackler, they had no inkling that there was any kind of a major problem for 4 years
- Patrick relates, “*there were four blissful years where they got lots of letters from pain patients saying, you’ve given me my life back*”
- In early 2000 the United States attorney for the state of Maine wrote a letter to thousands of physicians saying this drug OxyContin is really dangerous
  - It’s killing people
  - People are overdosing
  - Further, there is a crime problem associated with it
- A bit later, the chief medical officer, Paul Goldenheim, the chief medical officer of Purdue Pharma is brought in front of Congress
  - He says the company had no inkling that there was any kind of big problem until this hinge point, which is when this US attorney wrote this letter in 2000
  - There is one caveat Patrick points out, “*the other thing they say is that they say, oh, we read about it in the press*”

> “For me as a journalist, this was funny because I’ve written about a lot of companies doing bad things, and reporters like to take credit where they can get it. But generally speaking, if a company is doing a bad thing, they don’t find out about it because they read about it in your article. They usually know a long time before the rest of the world does.”  – Patrick Radden Keefe

- When Patrick dug into this statement, he found documentation to show this was a lie
  - They knew about the problem really early on

- Emails from the late 1990’s contain all kinds of back and forth about these drugs
  - Very senior people, including Goldenheim emailed about the fact that there’s an abuse problem
  - Pharmacies were getting robbed
  - People talked about the street value of the drug
  - There was a media advisory group that was brought in to do interviews with these senior officials
  - There are literally emails in which some of these senior officials who later claimed that nothing was said, will be emailing about it, and then they’ll say, “s*hould we have all this chat on email? It’s maybe not a good idea for us to be having these conversations on email*”
- There’s another sort of associated lie that they told, which is that there had never been a problem with MS Contin
  - This was a lie that was told under oath
- Patrick found the company had a very clear awareness of the problem
- He argues that OxyContin changed the way in which these drugs are prescribed as a category of drugs
  - They had one of the biggest marketing forces ever
  - They sent out hundreds of sales reps (700) to fan out across the country and meet with thousands and thousands of physicians
    - That was how they kind of got the message of OxyContin out there

**Canaries in the coal mine**

- A story Patrick tells in his book is about a guy named Steve May, who was a Purdue sales rep in West Virginia in’99
  - So this is before, according to Goldenheim they didn’t know anything at this point.
  - In ’99 Steve May had this one doctor, a big prescriber
    - They would call them whales, to use the vernacular of a Vegas casino for a big gambler
    - As a sales rep, this was great for your bonus to have a big prescriber
    - So Steve May had this whale; he went to call on her, which he would do from time to time;  and she was upset when he showed up
      - He asked her what the problem was; and she said she had a young relative, a young girl who had just died of an OxyContin overdose
  - All the reps write up these encounters in notes and send them back to headquarters

> “So I think what I was able to substantiate in the book at some length is that it’s clear really early on there’s a problem… from as early as ’97. So that’s just a year after the drug is released”  – Patrick Radden Keefe

- These discussions are not just happening at low levels; they’re happening at high levels
- Patrick thinks what happens in 2000 is it just becomes impossible for them to deny it anymore

**Company spin to avoid responsibility**

- The spin they put on it was a bunch of things
  - Peter summarized the company spin as, “*We’ve created a miracle breakthrough product that helps millions of people, but there are these derelicts who abused this product and are jeopardizing it for everybody else. We really need to ramp up the enforcement of those people*”
- Patrick explains the stance of Purdue Pharma
  - They suggest there’s nothing intrinsically dangerous about the drug
  - The level of denial here is pretty impressive
  - The Sacklers even today argue that instances of [Iatrogenic](https://en.wikipedia.org/wiki/Iatrogenesis) addiction to OxyContin is rare
    - Where it’s prescribed to a patient by a doctor for a legitimate condition, and the patient takes it as instructed by the physician and then becomes addicted

## The many paths to addiction and abuse of OxyContin and the ensuing downfall of Purdue Pharma [47:15]

**Divide users into 3 buckets**

- Peter asks about patients who are prescribed OxyContin; to be overly simplistic, let’s say there are 3 buckets in which a patient comes across this drug (other than terminally ill cancer patients):
  - 1) A patient recovering from surgery; they get a legitimate prescription to get them through the perioperative period
  - 2) The sham doctor who’s prescribing this stuff from one state when you’re in another state doing it online or running basically the revolving door clinic
    - The patient will get the prescription and go out the door, provided they fill it at a pharmacy, a couple of hundred miles away
  - 3) Illicit acquisition of OxyContin through a stolen channel
  - What is the relative distribution of patients among these 3 paths?
    - Patrick notes it’s impossible to parse this out
    - It also fluctuates a lot over time
    - He has found a few data points
- Patrick found 2 examples (numbered below) in his research related to this distribution of patients in these 3 buckets are some of the more shocking things he discovered in his research
  - It’s hard though because it is complex

> “ And so sometimes I think from the cheap seats, it’s hard to appreciate the gravity of this.” – Patrick Radden Keefe

- Purdue sells OxyContin; they release it in ’96
- Right away people realize that that content seal can be overridden just by crushing the pills
  - People can chew the pill, grind the pill, dissolve it in water after it has been ground and shoot it intravenously
  - There’s actually a warning on the bottle advising not to crush the pills because if this could lead to a potentially toxic dose of oxycodone
    - In a weird way, this functions as a kind of inadvertent, how to
    - Patrick thinks this is significant for maybe for all three of the buckets Peter mentioned because there are people who are just opportunistic drug users looking to get high
- Patrick interviewed a lot of people who said that heroin was scary
  - Heroin had to be bought on the street
  - One had to shoot it with a needle
  - These were people looking to get high
- 1) OxyContin was a party drug in high school, but there was something reassuring about the fact that it had been approved by the FDA
  - Even if they bought it from a dealer, at some point there was a doctor writing a prescription
- 2) There are also people who are prescribed the drug by a doctor, and it doesn’t work for as long as they think it will, or they find themselves just kind of in its grip, they want more
  - Some of those people actually convert to the immediate release thing
  - What they find is they don’t want to wait, and so they’ll end up chewing the pills because it relieves their pain faster; this is what they say
- So there are different ways of getting addicted

**Maximizing profits at Purdue**

- In 2010, Purdue rolls out a reformulated version of OxyContin that they’ve worked on for years
  - It can’t be crushed
  - It’s like a gummy bear; if one tries to break it up, it just kind of goes chewy and gummy
  - There’s an interesting backstory here, questions about why it took so long to roll this out
    - There’s an interesting aspect of the timing, the original patent on OxyContin was about to run out
    - So just in the nick of time, they have this line extension basically in the form of the reformulated drug
- Peter skeptically notes, “*at the time they even basically declare that their old formulation is probably unsafe, which is really a great dig at the competition, which is as we’re about to roll this thing off its patent life, we want to make sure that nobody else uses it either as we reignite a new patent on a new drug, which is infinitely safer in the presence of our old dangerous drug*”
- Patrick agrees and explains there are emails going back years and years and years talking about how, if they came up with a kind of abuse-proof/tamper-proof formulation that would function as a line extension
  - This was the reason they were doing it, primarily was to extend the patent life

> “The surpassing cynicism of the idea that having at that point 14 years said, oh, it’s perfectly safe… the original formulation. They develop a new formulation, and then they turn around and say, well, we wouldn’t want to see any generic versions of the original formulation because in fact it’s not so safe after all, it’s amazing.” – Patrick Radden Keefe

- This worked; the FDA was obliged to extend their patent
- In 2010 the reformulated version is rolled out, and the old pills, they kind of disappear from the shelves and the new ones take their place
- He found an internal study that showed when this happened for the 80 milligram pills in 2010 sales nationwide fell 25%
  - This statistic that really blows Patrick’s mind
  - The 80 mg pills were the biggest and most profitable pills on the market
    - They were also the most popular on the black market
- He can’t tell you proportionately who’s in what bucket
  - What he can tell you is that up to 2010, I think it’s safe to intuit 25% of the sales of 80 milligram OxyContin were going to people who were abusing those pills in one way or another
  - This is astonishing to Patrick, “*because I mean, that’s a non-trivial part of the company’s profits. So on the one hand it’s they don’t want their patients, their customers to die. On the other hand, there is a sense in which even as they were decrying the black market, the black market was helping to pay the bills at the company.*”
- It’s impossible to know how many people left bucket 1 (who were originally prescribed OxyContin legitimately for non-cancer pain by a caring, understanding physician) and went to bucket 2 or 3 as their appetite for this drug grew versus how many people came [*de novo*](https://en.wikipedia.org/wiki/De_novo) to bucket 2 or 3 simply seeking to get high

**Overdose deaths and opioid use disorders**

- Patrick notes, “when you look at toxicity reports on people who die, people who overdose, it’s often not just OxyContin in the bloodstream, right? It’s often mixed with other things”
- So there’s this whole exercise of parsing, moral and legal parsing that Purdue Pharma does that is amazing

> “At a certain point, so many people have died from your product. It’s this kind of incredible symphony of rationalization that happens.” – Patrick Radden Keefe

- Purdue pharma is now in bankruptcy, and in the context of the bankruptcy, there are many, many, many creditors who have a claim that they’d like to exert against what’s left of the company
  - One of them is United Health
  - United Health had this fascinating filing where they were talking about the idea that they should have a piece of the pie such as it is
    - He will leave aside for a second, whether a big insurer should be there in line along with all these people whose lives have been ruined by the drug
- What was interesting is that United Health said they ran a study over 7 or 8 years and looked at people who had United Health plans and who were prescribed OxyContin or another Purdue opioid, and subsequently diagnosed with an opioid use disorder (OUD); *they said the number was in the hundreds of thousands*
  - Patrick thinks that would actually be a kind of a smaller subset because there needed to be a diagnosis of an OUD
  - He doesn’t know what percentage of people initially given a prescription later had a diagnosis of an OUD
    - This would be interesting but it was not revealed in the filing to the bankruptcy court

## Peter’s personal experience with OxyContin [57:00]

**Back injury and complications from a botched surgery**

- Peter relates a personal history with OxyContin
- When he was in his last year of medical school, a little over 20 years ago, he had a really bad back injury
- For 2 weeks or so he just ignored it, but he pain grew more and more debilitating
- He remembers doing a rotation and he couldn’t even sleep
  - He had to get the residents to inject [Toradol](https://en.wikipedia.org/wiki/Ketorolac) into his thighs just to allow him to be able to sleep for a while
- Finally he got a MRI
  - It revealed  a really bad herniation in his lower back
  - And also a 5 cm fragment of disc had broken off on the left side, and it floated down the canal and it was sitting on the S one nerve root, which is what was causing this indescribable amount of pain
- He underwent surgery the next day, but it didn’t go well for a number of reasons
  - The surgeon operated on the wrong side
  - He awoke from surgery in terrible pain
  - He also had a new complication on the other side
- This resulted in a number of followup procedures initially aimed at correcting the first problem
- Before he knew it, even once the structural problem had been fixed, the pain was so bad that he finally relented and agreed to take pain medicine
  - He had been horribly petrified of taking anything beyond [NSAIDs](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug)
- This is the year 2000; the first prescription he gets is 20 milligrams of OxyContin to be taken, probably twice a day
  - Within 4 months he was taking almost 400 mg a day
    - For the listener who doesn’t know what that means in context, that would be enough to kill an entire family of drug naive people
    - 400 milligrams would kill Mom, Dad, Susie, Bobby, Sally; they would just stopped breathing
    - So it didn’t take long for Peter to go from 40 milligrams a day to 400 milligrams a day
    - And this was all prescribed by a legitimate doctor who was not at all an expert in pain management

> “No one was monitoring how much of this drug I needed.  The dose just kept going up and up and up.” – Peter Attia

**Quitting OxyContin**

- Peter feels very fortunate to have been dating an anesthesiology resident
  - She was about three or four years older than him; probably in her last year of anesthesia
  - She herself was actually interested in pain management
  - She would go on to do a fellowship in pain management
  - She was a bit troubled by how much of this drug that he was on
  - This got Peter thinking, “*how the hell did I get here? Because it happened so quickly. One minute you’re like I never, ever, ever want to take one of these drugs; and then the next minute, you’re basically in a constant haze.*”
- There was no moment when Peter wasn’t high
- The turning point came when he couldn’t differentiate pain relief and being high
- At the time, he was convinced that he would never walk again; it was a 1-year recovery process; but he couldn’t walk in the first 3 months
  - It shattered all of his dreams of becoming a surgeon, let alone an active, healthy person
  - He was taking the drug just as much to blunt that grief as he was to blunt the pain
- He finally decided he didn’t want to take the drug anymore
  - He never imagined he would overdose
  - It never crossed his mind that he could get ot a point where he would stop breathing
- He told his girlfriend,  “*I’m going to stop this cold turkey.*”
  - She replied, “*You absolutely can’t do that. The withdrawal from this will kill you just as much as this drug will kill you. You need to be on* [*nortriptyline*](https://en.wikipedia.org/wiki/Nortriptyline)*,* [*morphine*](https://en.wikipedia.org/wiki/Morphine)*.*”
    - She rattled off all the drugs he would need to take to taper off
  - But he was a stubborn kid and he just stopped cold turkey

> “And the next three weeks of my life would be about the most miserable three weeks of my existence” – Peter Attia

**What Peter learned about addiction**

- What he has learned since suggests he is biologically lucky
- He truly believes that the neuro-transmitters in his brain are not wired the way that someone who, in that exact situation, would have become a lifelong addict
  - He’s lucky because that chemical didn’t put a hook in him the way it would in others
  - He had become physiologically dependent on it, and that’s why he went through withdrawal, just as anybody would
- He feels very lucky that he managed to escape this drug
  - He’s still afraid of the drug after the fact
- Only 7 years later, when he had a really, really bad dental issue would he ever touch another [Percocet](https://en.wikipedia.org/wiki/Oxycodone/paracetamol) in his life
  - Which of course, is a fraction of the drug
  - He remembers being really worried about what was going to happen
    - Worried about the risk of it escalating into massive use
  - Fortunately it didn’t; he only needed Percocet for a week until he had a tooth extracted
    - Then he simply stopped taking it and was fine
- This experience gave him more empathy with people who become addicted
- Patrick has talked to so many people whose lives have been upended by this drug and other opioids
  - It’s often like there’s a kind of undertow; there’s just this sense for them that they’re suddenly in the grip of something

> “You managed to get out of the grip, but it sounds like… you were titrating up so fast.” – Patrick Radden Keefe

- Peter agrees, “*that upward speed was unbelievable, Patrick. Unbelievable, how quickly a tolerance developed*”

> “By the way, it’s total bullshit to say you don’t get high from a time release drug” – Peter Attia

- He doesn’t know what it’s like to take heroin, but this is blunt; he thinks it would compare to heroin
- There is an absolute blast-off high that came from those mega doses of OxyContin

**Doctors who prescribe OxyContin**

- What’s fascinating to Patrick about Peter’s story is the doctor, that the surgeon writes this prescription
  - Purdue and other drug companies argued from the beginning that doctors don’t know enough about pain management, they haven’t gotten the training
    - There was some truth to that
  - The weirdness of it is, they then rush into the vacuum and they say, “*We’ll provide that training. We’ll do that education.*”
- The catchphrase for OxyContin early on was that “*it’s the drug to start with and to stay with*”
  - This first part of this says “*This isn’t some nuclear solution you keep on the top shelf, or you would try other courses of therapy and only when those fail, do you resort to it*“; it’s the first thing that should be administered
  - Then it’s the one to stay with, meaning, one can just keep taking it for chronic pain conditions year in, year out, even if one has to keep titrating up
- It was a core belief at the company, Richard Sackler felt very strongly about this, that there was no ceiling effect with OxyContin
  - Patients could keep taking greater and greater doses, which they would need as [tolerance](https://en.wikipedia.org/wiki/Drug_tolerance) develops
  - This message is delivered by pharmaceutical reps, who are meeting with doctors like Peter’s surgeon, and who are heavily incentivized to get those docs to titrate up
- Profits and even the bonuses for the pharma reps are all based on volume of the drug that’s sold and prescribed
- Hearing Peter’s anecdote, Patrick sees the other side, this sort of perfect storm of scenarios where, when Peter’s discussing with his girlfriend, “*Do I go cold turkey? Do I taper off? Should I be taking morphine?*”
  - Because the guy who prescribed Peter the drug, probably doesn’t know how to explain to people how to get them off
- This is a crazy situation in which there are a generation of doctors who learn how to on-ramp their patients with these drugs and never learn how to off-ramp them
  - Further, they don’t necessarily have any interest or inclination to do so
  - Patrick has talked to people who’ve had these experiences, they’ll say, “*I went back to the surgeon who wrote me the original script and said I’m having problems here*”
    - Then the doctor replied, “*Whoa, whoa, whoa. I’m not an addiction specialist*”
    - When he looks at all those circumstances and extrapolates from that story Peter just told, it’s not surprising to him to think that there are many, many, many people who had a similar situation and ended up in very dire straits

**Help Peter received to treat his pain and stay off OxyContin**

- Peter remembers another reason why he was very fortunate to have a girlfriend who was an anesthesiologist and also a year away from doing a pain fellowship; she got him in to see a pain expert at Stanford, [Sean Mackey](https://profiles.stanford.edu/sean-mackey)
  - He thinks this guy really saved him
  - It was one thing to quit OxyContin cold turkey, but he still had pain

> “Getting off the drug was one problem, but addressing the pain was another” – Peter Attia

- To begin with he did a lot of injections
- He cooled off things that flared up using a drug called [Neurontin](https://en.wikipedia.org/wiki/Gabapentin)
  - It’s not addictive; it’s incredibly benign
  - It is sedating, so that’s a drawback to dealing with neuropathic pain
- He also used [Vioxx](https://en.wikipedia.org/wiki/Rofecoxib), a very strong [NSAID](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug)
  - This drug saved him
- These drugs allowed him to break the cycle of pain and do enough PT, such that a year from when that whole thing began, he was actually in his surgical residency and free of all pain medication
  - Free of Neurontin and free of Vioxx
- His story could have had a different ending without these people in his life
- After going off OxyContin cold turkey, he could have gone back to the drug because there was no other alternative to treat the pain

## Pain—the “fifth vital sign,” how doctors are trained in pain management, and the influence of money [1:08:00]

**What surgeons learn about pain management in residency**

- Peter is amazed at how ignorant he and other surgical residents were of pain management

> “There was absolutely no teaching of this subject matter” – Peter Attia

- Something very simple he learned, studies had demonstrated that before the surgeon makes an incision on a patient, if they inject Marcaineat the incision site and then immediately following surgery, you put the patient on a pretty aggressive dose of inseds. Many patients can actually avoid narcotics post-operatively for the incisional pain
  - The incisional pain is the dominant source of pain
  - [Marcaine](https://en.wikipedia.org/wiki/Bupivacaine) is a sodium channel blocker, like [Novocaine](https://en.wikipedia.org/wiki/Procaine) that the dentist would use
  - Marcaine long acting and similar to [lidocaine](https://en.wikipedia.org/wiki/Lidocaine), which is short acting
  - Peter remembers thinking, “*Why aren’t we doing this with every patient?*”

**The pressure on doctors to save time**

- He got into an argument with one of the attendings because I was about to do an operation and I went to do this; the attending was complaining that it was going to take 5 minutes and they didn’t have time for that
  - Peter remembers thinking, “*Really? We don’t have five minutes?*” It was shocking
- Patrick remarks that from the outside, he thinks that one of the ingredients that created the opioid crisis is actually that idea of, “*We don’t want to waste five minutes. We need to get our patients in and out. Time is money.*”
- He’s interviewed doctors who talk about ‘how they felt duped,’ how, when the Purdue sales reps started flogging OxyContin and when doctors encounter patients who were in pain, they want to relieve that pain
  - Suddenly there is this medical innovation, which they are told is like a panacea;  it can relieve that pain and has virtually no side effects and people can take it forever, and there’s no dosage ceiling
  - He’s talked to people who’ve said this was a siren song they were all too ready to listen to because it filled a need in their therapeutic arsenal
    - Of course it ended up being more complicated
- When Patrick thinks about how American medicine is structured, the idea that doctors have a patient who’s in pain, and they say, “*I’m going to write you a prescription for 20 milligrams of OxyContin.*”
  - Then the patient will be on their way and they never have to see them again
  - The doctor doesn’t give any thought to how this is working out for them two weeks from now or two months from now or two years from now
  - It’s that notion that ‘five minutes is money.’
  - That five minutes is five minutes, they’re not spending with the next patient; it’s a longer line in the waiting room
  - He thinks those kinds of structural considerations are part of what allowed Purdue and other opioid makers to snow the medical establishment as effectively as they did
- Take a look at the prescribing levels for these drugs; with the introduction of OxyContin, they just suddenly start climbing in this really dramatic way
  - He would have thought there would have been more skepticism, that it would have been slower growth
  - He does think there was a sense in which it sort of filled a number of needs and that allowed it to take off the way it did

**Pain, the fifth vital sign**

- One of the other memories Peter has from the early day of his residence is how all of a sudden a new vital sign emerged
  - [Vital signs](https://en.wikipedia.org/wiki/Vital_signs) are, by definition, objective; they are things that can be measured for which there is no ambiguity: temperature, pulse, respiratory rate, blood pressure
  - But then a fifth vital sign was introduced, which was pain
    - Pain is a subjective measurement on a scale of one to 10
    - There were laminated posters on every corner of the hospital, “*Don’t forget the fifth vital sign. Don’t forget the fifth vital sign. What is the fifth vital sign? What is your patient’s pain?*“
    - And this really came from the medical community; this was a form of self policing
- How involved was Purdue in driving this agenda?
  - Patrick says, “‘*very’ would be the short answer*”
- Patrick wants to be careful about how he puts this; it’s a tricky thing; it’s a little like when he was talking about Curtis Wright and the FDA
  - There’s a kind of soft corruption that happens, which is not as glaring as the caricature is corruption that one would think of
- There is the American Medical Association and all kinds of groups: groups of doctors, groups representing patients, patients’ rights, pain advocacy groups
- Then there is the industry underwriting a lot of this stuff
  - There was quite a good piece in Mother Jones just recently about the AMA and Richard Sackler was on one of these boards and there was a lot of money going to sponsor education
    - [The Untold Story of Purdue Pharma’s Cozy Relationship With the American Medical Association: The prestigious doctor’s group has made it virtually impossible to discern where public health guidance ends and industry interests begin.](https://www.motherjones.com/politics/2021/08/purdue-pharma-american-medical-association-relationship-opioid-crisis-public-health/)
    - Peter just read this article and he couldn’t believe that the AMA, both as an organization and its foundation, separately, are receiving money from the Sacklers
- What often happens is that industry groups end up distributing an educational pamphlet or something
  - There’s a kind of institutional laundering that happens, where industry comes up with these educational brochures or they sponsor research etc.
  - The example Patrick loves from the Mother Jones story was that, there was one handy guide to pain and the fifth vital sign, and the idea of how do you talk to a child about the pain they’re feeling; and there was an admonition to the doctors to remember to tell the child that no pain is not an acceptable answer
    - There’s a continuum, but the end of the continuum where there’s no pain, that’s not an option
- He thinks it’s more a coincidence of interests, in which there are people who earnestly believe these things and then are underwritten by industry
  - That kind of turbocharges the arguments they’re making, more than it is a situation of docs being paid off to tell what they know to be lies
- Back to the idea of the fifth vital sign, even just that phrase, on the one hand, Patrick thinks there was some truth to the critique that there hadn’t been enough education in pain management and enough consideration given to how doctors can relieve patients’ pain
  - On the other hand, when he hears the phrase ‘the fifth vital sign’, that sounds more than anything like a great marketing slogan

**Studies of pain perception**

- There was a study, Patrick doesn’t recall the citation, but he remembers reading this great study whereon a scale of 1 to 10, what might be a seven for one person could be a nine for another person
  - Rating of pain actually varies regionally
    - They found that people in Northern Europe, when exposed to some sort of standard amount of pain,  they would say, “*Oh, that’s a four*”
    - And then people in Southern Europe, exposed to the same amount of pain, they would say, “*It’s a 10, it’s a 10*”
    - They reported these cultural, regional differences in terms of people’s pain thresholds
- It’s hard, because he does think it’s a legitimate thing that people should be looking at and inquiring about, but at the same time, it’s totally subjective
- And he thinks that again and again, “*you see just the money pollute everything*”

## Other players that helped facilitate the eventual opioid crisis [1:16:15]

**Soft corruption in many levels of government**

- Peter notes that Patrick mentioned earlier that Curtis Wright, effectively (whether in a direct quid pro quo or more of just a confluence of interests) approves this drug single handedly for the FDA, and then ultimately, winds up working for this entity
- The other story in this one  that really blew his mind was that of Linden Barber, at the DEA
  - On the one hand, he seems by all accounts to be one of the most credible voices within the DEA standing up to the unmanaged distribution of these drugs
  - Then he does an about-face and becomes one of the most powerful lobbying entities for these very companies
    - Peter believes [Cardinal](https://en.wikipedia.org/wiki/Cardinal_Health) was one of his largest clients, [McKesson](https://en.wikipedia.org/wiki/McKesson_Corporation) being another; these were 2 of the largest distributors.
    - It’s kind of hard to believe
    - I guess it’s like Patrick said earlier, “*Look, how long can you work for nothing as a government employee?*” And at some point, he has a choice, which is he’s going to go make a living, harnessing his existing skills
      - But it just doesn’t feel right
- Patrick notes that he has written a fair amount about crime where it’s just kind of baked-in, that he’s writing about a bad person doing a bad thing, but this has been one of the more dispiriting things, working on this project
  - Usually there’s a sort of moral clarity there, they kind of know they’re bad
  - What was so fascinating to him about this story is, he thinks the Sacklers are bad actors
  - He thinks they did really bad things and they’re the focus of the story
  - But then around them are all of these facilitators
    - Former prosecutors who go and work as private defense attorneys for the family or for the company
    - Former DEA officials who go and work as lobbyists for the industry
    - Former FDA officials who go and work at the company
    - Folks at McKinsey
    - It’s this whole kind of amazing, entrenched machine of people who, in many instances, don’t think of themselves as the bad guys
    - And in some cases, society doesn’t think of them as the bad guys
  - One of the characters in his book is [Mary Jo White](https://en.wikipedia.org/wiki/Mary_Jo_White), former US attorney for the Southern district of New York
    - She was Obama’s head of the SEC; a woman who broke the glass ceiling
    - She has represented Purdue and the Sacklers for years, and is totally a handmaiden to them
- This is a thing that he’s wrestled with personally, he’s a lawyer by training, and he knows that it’s fundamental to the ethos of the profession that one shouldn’t necessarily transpose the moral stink of the client onto the lawyer
  - But it’s hard for him when he hears the Linden Barber story
  - There’s a hundred people like that in the book, who play that kind of role again and again, and again
  - Further, there are these people who were supposed to be the cops, they’re supposed to be law and order and they get co-opted by the money and it’s really discouraging
- Peter notes that sometimes it isn’t even that much money involved
  - Look at [Chris Dodd](https://en.wikipedia.org/wiki/Chris_Dodd) and [Marsha Blackburn](https://en.wikipedia.org/wiki/Marsha_Blackburn) and [Tom Marino](https://en.wikipedia.org/wiki/Tom_Marino) and [Orrin Hatch](https://en.wikipedia.org/wiki/Orrin_Hatch); it’s just hard to look at these people and think of them as reasonable or respectable, truthfully, when he knows their involvement in this, and the bills that they sponsored, and the positions that they took in all of this; and to know they were bought so cheaply

> “US senators for sale for hundreds of thousands of dollars? I don’t understand it.” – Peter Attia

- Patrick thinks money donations are part of it; but it is more about the revolving door
  - Lobbyist are often people they know
  - An example is the way in which Purdue and the Salkers would use lawyers like Mary Jo White
  - Similarly, they hired Rudy Giuliani for years; he was kind of their hatchet man
  - Think of it as if “*you were a federal prosecutor and you’re investigating me, the real move is not to sort of fight it out with you on the merits in court, the way most people would, it’s for me to go to your boss, but not for me personally to go to your boss, for me to find somebody who your boss knows and respects, and that’s the person I buy off and I send them to go and kind of make the overture*”
- When one looks at these people, it’s the sort of soft corruption
  - It’s not campaign contributions
  - It’s that scene in [*The Godfather*](https://en.wikipedia.org/wiki/The_Godfather) where the guy’s supposed to testify in court, and they get the old guy from Sicily to come and just sit in the courtroom and it happens to be his uncle or whatever, and he sees the guy in the courtroom and he suddenly sort of loses all his moral conviction and decides he’s not going to testify
  - It’s being really smart and strategic about who’s the right messenger
  - Who would be sent to make the case to Chris Dodd, about why he shouldn’t come after Purdue, or why he should help them in this or that
    - And Purdue and the Sacklers are really, really good at that
- Peter wonders how bipartisan this ‘corruption’ was
  - Was it the bill H.R.4709?
  - This was a sleeper bill, right?
  - It was maybe three pages, a “nothing burger” that basically opened the pipelines to move these drugs and put the DA’s hands behind its back
    - It’s amazing how unopposed that bill went
  - Patrick thinks the fact is that nobody’s really reading the bill
    - The bill was carefully designed to look like it was doing the opposite of what it was doing
    - It has the appearance of fighting the opioid crisis
    - Obama signed it and who knows how closely he looked at it
    - There’s enough business that goes on in Washington,  particularly when it comes to lawmaking, there are these members of the house and senators who spend all their time raising money and if they can make what they’re doing,look like business as usual, they can pull it off
    - It’s super dispiriting
- The opioid painkiller industry spends something like seven or eight times what the gun lobby spends on lobbying in Washington
  - Just imagine the kind of impact they can have on the legislative picture
- An example involving Purdue involves a long period of time where all these states were trying to respond at a state level to the opioid crisis
  - States were trying to introduce new legislation to shut down pill mills or go after bad docs and what have you
  - There were these legislative initiatives at a state level that got set up and Purdue found the right state lobbyists to go to the state Capitol and help neuter those bills as best they can
    - And they were very successful at doing that

> “When you have a drug that’s generated $35 billion in revenue, the amount of influence you can buy is just awesome” – Patrick Radden Keefe

## Lack of accountability following the investigation and prosecution of Purdue and the Sackler family [1:23:30]

**Initial attempt to prosecute were foiled by company influence**

- There were a couple of investigators, at a small federal prosecutor’s office in the Western district of Virginia
  - Their community had been appended by OxyContin, specifically
  - They started realizing, “*all this pharmacy theft and crime is going up and you get people out DIYing when they started investigating*” and to them, it was this kind of weird thing where they felt a hurricane had just hit their town
  - They wondered where it came from it came from Connecticut
  - They did this really amazing investigation
    - They spent 5 years investigating Purdue
    - They subpoenaed millions of documents
    - They did huge amounts of grand jury testimony and wanted to charge three senior executives at the company with felonies
    - The idea was that faced with jail time, these executives would flip on the Sacklers
  - One of those federal prosecutors has said this on the record that the plan was actually to target the Sacklers, if they could flip these guys; and this was confirmed by another
  - What ended up happening was that the company sent [Rudy Giuliani](https://en.wikipedia.org/wiki/Rudy_Giuliani) and [Mary Jo White](https://en.wikipedia.org/wiki/Mary_Jo_White) to go over the heads of those federal prosecutors, to go to the [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) justice department in Washington and say, “*You can’t go after these guys for felonies. We need to take felonies off the table, take jail time off the table.*”
  - The prosecutors got overruled by their own bosses
    - This was [Alice Fisher](https://en.wikipedia.org/wiki/Alice_S._Fisher) and [Paul McNulty](https://en.wikipedia.org/wiki/Paul_McNulty)
    - Patrick talked to them and asked, *“Who made that decision to tell these prosecutors in the Western district of Virginia?*“
    - They just pointed at each other; nobody would own it

> “You would think, all these years on a pretty consequential decision, you would think that somebody might take responsibility for it.” – Patrick Radden Keefe

- What that meant was that, because they couldn’t charge Purdue executives with felonies, these guys weren’t going to flip
  - They pled to misdemeanors
  - Prosecutors couldn’t go after the Sacklers
  - The company paid a $600 million fine and pled guilty to felony charges of misbranding
  - Then it was pretty much business as usual; they didn’t even slow down their marketing a job

**Guilty pleas and bankruptcy**

- But in the last couple years, Purdue went into bankruptcy and more importantly this third party release
  - This seems to be a very important granting on the part of a one White Plains bankruptcy judge
- In 2007, the company pleaded guilty
- The official line after that was, “*Oh, we cleaned up our act. We had a few bad apples, but everything’s okay now.*”
  - But they didn’t really change a whole lot
  - Really all the senior folks, the three guys who pled guilty to misdemeanors had to leave; they couldn’t keep working at the company
  - But other than that, all the senior folks who were involved in this stuff stayed on; heads did not roll
- Purdue kind of kept doing what it was doing
- In 2020, the company pled guilty to a new set of federal criminal charges and the conduct that it pled to, dated back 10 years
  - They  pleaded guilty in 2007, and then in theory, there was a couple of years of good behavior, but then starting in about 2010, they were back to committing crimes and kept at it through 2020, when they pled guilty again
- In between those two guilty pleas there are lots of lawsuits
  - Some of these are private, class action lawsuits, lawsuits brought by: hospitals, school districts, cities, states
  - Eventually every state in the union pretty much, is suing Purdue over its role in the opioid crisis
- What’s happening in parallel to that, which we didn’t know about until fairly recently, is that starting in 2007 after that guilty plea, the Sacklers start quietly taking money out of the company
  - They’re just sort of siphoning money out a hundred million here, a hundred million there; over the course of about a decade, they take more than $10 billion out of the company
- In 2018-2019, there are thousands of lawsuits against the company
- The companies is on the ropes, and the family kicks the company into bankruptcy

> “They say the company doesn’t have any money anymore, which is only the case because they took $10 billion out of it” – Patrick Radden Keefe

**The Sacklers seek immunity**

- Since the company is bankrupt now, all these lawsuits against them are suspended
- They ended up in this bankruptcy court in [White Plains, New York](https://en.wikipedia.org/wiki/White_Plains,_New_York), because this is the way bankruptcy law works
  - They got to pick their judge
  - One can decide where to declare bankruptcy, corporate bankruptcy
  - They picked this judge who they thought would be sympathetic
- This is where it gets really interesting, by this point, roughly half of the states were not just suing the company, they were suing individual members of the family, who had sat on the company’s board
- There’s a move by the company and the family to say, “*Okay, so you’ve suspended all these lawsuits against the company, because it’s in bankruptcy, but we want you to suspend the lawsuits against the family too, even though they haven’t declared bankruptcy.*”
- And the judge did that temporarily, which is pretty controversial
  - There are states in which one is able to do that
  - They are not able to say to the attorney general of half of the states, “*No, you cannot bring your lawsuit*“; but a federal bankruptcy judge in New York says to the state attorney general of Idaho, “*No, you cannot bring your state based claim*.”
    - It’s pretty exotic, but he did.
- Now it’s in sort of an end game, where the Sacklers have made this bid to permanently immunize them from any litigation (and they want the judge to make this permanent)
  - The phrase for this,is [nonconsensual third-party releases](https://www.jdsupra.com/legalnews/proposed-legislation-may-limit-chapter-8356376/)
  - This is happening in real time, now; there’s a bankruptcy trial going on with testimony, but I think everybody knows how it’s going to end
  - The judge has kind of telegraphed where he’s going with this

**Proposed settlement**

- There are some states that continue to fight effectively
- Basically, this is a situation in which the Sacklers have made a proposal to, in one fell swoop, deal with all this litigation once and for all
  - And they’re doing it in the context of this bankruptcy proceeding, where they say, “*We will pay $4.5 billion of our money to remediate the opioid crisis. We’ll pay it out over nine years and we’ll make no admission of wrongdoing, we’ll give up our interest in Purdue, we’ll be granted one of these nonconsensual third-party releases,*” where basically, this judge gets to waive his wand and say, “*Nobody can ever sue you again. No state prosecutor, no private plaintiff, nobody can sue you ever again over anything having to do with OxyContin or the opioid crisis.*”
- Patrick thinks there are a lot of states that are desperate and fighting, dealing with the trillions of dollars in public costs that this crisis has generated
  - They’re reeling; they see $4.5 billion, and they think, “*I could use one 50th of that.*”
  - So they’re inclined to take the deal, even if they don’t like it

> “To put that $4.5 billion number in perspective, the Sacklers still having an $11 billion fortune, and they’re going to pay out the $4.5 over nine years.” – Patrick Radden Keefe

- A lot of people look at this and feel this isn’t justice
  - The payment is actually not linearly weighted; the majority of it comes at the end of the 9 years, so in theory, they could come out ahead if they invest reasonably well
  - Patrick had some conversations with people who advise high-net-worth families and invest their fortunes, and conservatively, between interests and a very conservative portfolio, they can probably expect a 5% return on that $11 billion fortune
    - If that’s the case, they would never have to touch their principal
    - In absolute terms, it’s a lot of money, but it doesn’t commensurate to the damage
    - Ultimately, it’ll be a pretty good deal for the Sacklers
    - And this is how he thinks it’s going to shake out
- What else will this accomplish?
- No amount of money is going to bring back a loved one
- Peter has several patients whose lives have been directly impacted by this, whose children have overdosed, kids that became addicted to prescription pain pills.
  - In one situation, one of the kids was clean for a number of months, then was at a party where someone suggested he try a pill
  - It turned out to be laced with fentanyl; this story ends tragically
  - No amount of money is going to fix that
- So whether the Sacklers have to give $4.5 billion or forfeit every dollar they’ve ever made and will make in perpetuity, that never brings back a life

**Justice and trends in corporate accountability**

- Justice is about 3 things
  - 1) It’s about how much can be fixed today with money because maybe some things can be fixed with money, some things can’t
  - 2) Is justice being served?
  - 3) Is this creating a deterrent for another entity in the future to be a little more careful with what they do?
    - Is this a sufficient deterrent for the foreseeable future, to put the legal/illicit drug market on notice?
    - [Insys Therapeutics](https://en.wikipedia.org/wiki/Insys_Therapeutics) was different because their people went to jail
- Patrick sees this as part of a larger trend that’s been happening over the last 10 or 15 years, since the days of [Enron](https://en.wikipedia.org/wiki/Enron) and [WorldCom](https://en.wikipedia.org/wiki/MCI_Inc.), which is that there’s a pronounced disinclination – this is across political parties – to bring criminal charges and jail time into the equation when it comes to corporate executives acting within their role, even if the conduct is criminal
- It is bizarre that Purdue Pharma pled guilty for a second time in 2020, and there were no individual executives, even names.; it’s like it’s a driverless car

> “How is it that the company could commit federal crimes if there’s no individuals who can be identified as having committed crimes? It doesn’t make any sense.”  – Patrick Radden Keefe

- It’s reflective of the general posture of the Justice Department and our whole system of justice, broadly speaking, which is, it’s really the exception when a corporate executive ends up doing jail time, as happened with Insys
  - The Insys case is particularly extreme
  - Insys is everything seen in the Purdue story, but dialed up to 11
  - There were a bunch of reasons why jail time was handed out in the Insys case and not in the context of Purdue or J&J
- [John Kapoor](https://en.wikipedia.org/wiki/John_Kapoor) was the CEO of Insys Therapeutics who was convicted and sentenced to 5.5 years of prison
  - Patrick comments that Insys was such a scam; they had strippers working as sales reps and fairly bald bribery schemes, not the soft corruption he’s been talking about, but the hardest of hard corruption
    - This is why there was jail time
- In Patrick’s view, jail time is the only thing that really is a deterrent
- Otherwise, when it comes to money, people think about risk; they evaluate risk

## Legacy of the Sackler family and their disconnect from reality [1:34:45]

**Costs to the Sacklers**

- Look at the Sacklers; they take $10 billion out of a company during a period of time when it’s committing crimes
  - To have to give back $4.5 billion… should they do it?
  - Look at that fact pattern; the company commits crimes, and the owners and board of the company are never going to go to jail; they’ll never get charged with any crimes
  - To give back 4.5 billion over nine years; this is their risk
- For the Sacklers,the real costs are going to be reputational, and it’s hard to measure that
- Peter asks if they are any different from [OJ Simpson](https://en.wikipedia.org/wiki/O._J._Simpson)
  - It’s hard to say
- If one considers just those who have OD’ed on OxyContin, they would say, “*Ah, yes, but there were other drugs in their systems.*”
- But, of the half a million people who have died in the last two decades, probably some subset, maybe a small subset, of those people, the blood is on the hands of this family
- Peter notes that work like Patrick’s has really brought that to light
  - He wonders what the rest of their lives will look like
  - Will this be basically forgotten about?
  - Will the next generation of Sacklers carry no shame for this?
  - Or will this be something that forever makes people in polite company a bit embarrassed to be around them?
- Patrick thinks these last 2 things are going to be the case; people will forever be embarrassed to be around them
  - He thinks the name is toxic; it’s coming down off of institutions, and he thinks it’ll come down off of more institutions
  - He thinks that the family isn’t happy about that
  - But he also doesn’t know that any of them feel any shame

**The family’s disconnect from reality**

- Patrick thought one analogy a lot while writing this book in the last years of the Trump presidency
  - The Sackler situation is a little similar to Trump’s
  - In both cases there is a billionaire surrounded by advisors, lawyers, and PR people; all these people whose livelihood depends on keeping them happy
  - Patric thinks for both there is a heightened danger of delusion, of them getting out of touch with reality
    - And it probably starts in small ways; they tell a joke, and everybody in the room laughs
    - So initially, they’re just a millimeter or two off track, in terms of the fidelity of their perceptions of the world
    - The longer they go, the further off course they get, and what everyone saw with Trump, it’s also seen with the Sacklers
- Patrick talked to people who, a decade ago, said to the family, “*What if you took some of this philanthropic money that you give to art museums and started a foundation, dedicated to the study of addiction, redressing the opioid crisis?*”
  - These people were making a cynical argument, but saying, “*Just purely in terms of the optics here, you should make some gesture recognizing that there’s a problem and that people think that you’re responsible for it.*”
  - And those people were always sidelined and fired
  - The people who end up in the inner circle are the ones who say, “*You are just terribly misunderstood. All these people don’t understand you, the press, the public, the people making jokes on the late show, the Attorneys General of every single state, all these members of Congress who keep condemning you, all these studies that are done about OxyContin and its legacy. It’s all just a big misunderstanding. You never did anything wrong*.”
- It’s astonishing to Patrick, but the family members tend to pretty uniformly feel that way, that they did nothing wrong
- Peter is amazed that with the size of the Sackler family, when he thinks about how many children the three Sackler brothers had, and how many children they had, and how many spouses they have, that’s a pretty good list of people who could have come forth and said something to you, even off the record or on background; and yet this didn’t happen
- Patrick’s assumption from the beginning had been that there must be some apostate, third-generation Sackler who looks around, and never mind his writing, they read the *New York Times*, they read the *LA Times*, they read [Sam Quinones](https://en.wikipedia.org/wiki/Sam_Quinones)‘ book [*Dreamland*](https://www.amazon.com/Dreamland-True-Americas-Opiate-Epidemic/dp/1620402505/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1636576347&sr=8-1), and they say, “*My trust fund is blood money; I don’t need this; I’m going to turn my back on it*”
  - But he couldn’t find one
- One of the more revealing documents is a [WhatsApp](https://www.whatsapp.com/) log
  - It’s a chat log from the heirs of Mortimer Sackler
  - This came out in the context of the bankruptcy proceeding, where they all talk over the course of a couple of years, all these different family members, siblings, cousins
  - They’re talking about their problems, and how to deal with it, and the litigation and the bad PR, and what’s the right strategy?
  - It’s this private channel, and there’s nobody, nobody, who at any point says, “*Geez, maybe our critics have a point*” Or “*Maybe we should ask some tough questions*”
  - Instead, it’s this pretty lockstep feeling among family members of persecution
  - Even more, the way they talk amongst themselves, at times, it feels as though, in their minds, the real victims of the opioid crisis are the Sackler family
- For the Sackler family, there’s no awareness, not a shred of introspection
- Instead they have a profound sense of grievance, a sense that they’ve been persecuted
- There’s this amazing email that Patrick quotes in the book, where Jacqueline Sackler (married to Mortimer Jr., a second-generation member who was on the board of the company) is talking about how all this press coverage and this stigma for the family
  - She’s worried about her children applying to elite private schools in Manhattan in the fall and their chances; and in the context of griping about this, she says, “C*hildren’s lives are being destroyed*“
  - Not to pivot from the comic to the tragic, but he gets emails every week from people who lost children
  - When one hears from as many bereaved parents as he does, it’s just amazing to read an email like that and consider the level of disconnection that it betrays

## Patrick’s views on the regulation and use of pain management drugs [1:42:15]

**The legacy of Patrick’s book** ***Empire of Pain***

- Patrick hears from basically 2 groups of people:
  - 1) People who have become addicted or family members and friends of people who have become addicted or tragically died
  - 2) People using these pain medications who say, “Y*our work is potentially threatening to the supply of pain medication to people like me, who genuinely and legitimately need it*”
- There’s a fine line here, an overreaction or an overcorrection would limit the supply of or access to for patients who do need pain medication
  - There is a definite sense in which the pendulum has swung back and many doctors are less likely to prescribe these drugs in the first place; they’re more likely to prescribe shorter courses at lower doses
    - He thinks a lot of that is a good thing, ultimately
- He gets emails from many chronic pain patients who are fearful that ther supply of prescription opioid painkillers, that they probably count on in order to function in life, is really jeopardized by these changing currents in terms of the way in which people perceive these drugs
  - This is an incredibly difficult thing
  - He is very sympathetic to this; he certainly doesn’t want to see people who use these drugs stigmatized, whether they use them legally or illegally
- He’s also not a prohibitionist
  - Given all his work on illegal drugs, he tends to think that drug prohibition is not the way to go
  - People make argument that if policies cut off pain patients, forcing them to do a rapid taper, that this might actually drive people onto the black market and become more unsafe; that this might be part of what’s driving the opioid crisis
- He balks at the suggestion that he shouldn’t write about the Sacklers and their culpability, because there might be some second- or third-order consequences of that, or that his focus is in the wrong place
  - He’s going to write the books (and articles) that he wants to write a
  - It’s very often the case that people who are telling him that he shouldn’t be doing these things, generally speaking, haven’t read the book, haven’t really engaged with the particulars all that much

## The difficult path forward [1:44:45]

- Patrick thinks this has been an agonizing period for pain patients because the problem was not that a drug like OxyContin shouldn’t have been produced or made available to them; the problem was the decision in the medical community to do 2 things:
  - 1) Dramatically expand the universe of people who should be taking these drugs
  - 2) Play down the risks, pretty systematically, so that there’s a dishonesty with the consumer and with physicians about what the dangers are
- He doesn’t think that these drugs should not be available at all
  - There are some who do, some doctors do
  - He is pretty squarely focused on the origins of the crisis and some pretty unambiguous wrongs perpetrated by Purdue and the Sacklers
- If the Sacklers represent a cancer, that cancer has largely been excised
  - The Sacklers themselves are no longer going to be a part of this dilemma
  - But unfortunately, the cancer metastasized before it was excised; there is still an opioid crisis

**Scale of the current opioid crisis**

- The opioid crisis doesn’t show any signs of abatement; in fact, last year more people died of opioid overdose than any other cause of accidental death
  - This is a staggering statistic when one considers how many people die in car accidents or how many people die of gunshot wounds
- The question of what is the path forward, what is the path to address this crisis is one that overwhelms Patrick
  - He has simply taken a small piece of the opioid crisis to focus on it and understand it
  - For him, it was looking at the origin story of the crisis more than where the crisis is now
- The numbers are staggering and getting worse
- Patrick feels that the Sacklers are not absolved by the fact that the crisis today is a heroin and fentanyl crisis
  - He has the sense in which there are many, many people who would never have taken heroin or fentanyl in the first instance, that started on prescription opioids like OxyContin
  - But, from the vantage point of today, he’d rather people be abusing OxyContin than abusing fentanyl or heroin that’s laced with who knows what
  - It is a very, very scary situation

**Resources to address this crisis**

- He feels that more resources are needed than are currently available
  - This is a problem that needs to be resources
  - Treatment is often not available to people
  - There is still a huge amount of stigma associated with the abuse of and addiction, when it comes to these types of drugs
    - Anything that can be done to diminish that stigma would help
    - Medically assisted treatment would help, which, he thinks there are still some for whom that’s a scary concept
      - This should be adopted and embraced and not cause the consternation that it does for some
- This is a huge national crisis
- Prior to COVID there was a recognition that a major national strategy was needed to deal with this
  - That it’s out of control and killing people in vast numbers
  - That the country needs to have all ideas on the table and be strategic and resource the solution
- Then COVID came along, and there just wasn’t really the bandwidth or the oxygen in the room to have this conversation

> “But when we neglect the problem, as we have during COVID, purely in terms of the triage over the last 18 months, you see what happens” – Patrick Radden Keefe

- He is optimistic that things will be different 10 years from now
  - He is fundamentally an optimist about a lot of things and has to believe we will learn and will find a way out of this

**Risk of relapse**

- One of the hardest thing is conversations with patients or family members who actually managed to stop using and seemed as though they’d moved on, and then went to a party
- Relapse is such an issue with these drugs
- When he talks to people who’ve achieved and found their way out of the woods, often the thing that’s so striking to is the sense of fragility to it
  - They’re always talking in the present tense
  - There’s the sense that every day is a battle
- This worries him, the idea of 10 years from now, on a very micro level, the individual who is struggling with addiction

> “There’s that sense in which it’s each tentative step, you just never know when you’re going to get pulled back in. On a macro level, nationally, I worry that there may be a similar danger.” – Patrick Radden Keefe

- Similarly, Peter worries about what it takes to escape the gravitational pull of an environment that facilitated use of this drug
- He recalls during heroin use in inner city Baltimore 20 years ago, when he was in his residency at Hopkins
  - This was probably a leading indicator for how bad heroin use could get
  - The hospital he was at would take care of a lot of patients who had abscesses and all sorts of infections and cellulitis and things like that from IV drug use
  - Sometimes these infections themselves were life-threatening
  - It wasn’t just the overdose on the drug; it was the repeated use of a dirty needle, or a needle that gets broken inside the arm and gets infected
  - He would take care of these patients, and he always wished them the best when they left, but in the back of his mind, he knew he was going to see them again
    - Even though for the 5 days that they were in the hospital, they were not using any drug, and they realized how lucky they were to get this second chance, they were still going back into the same environment that brought them into the hospital in the first place.
  - Peter and his colleagues used to say to themselves, “*The only way this person’s not coming back is if they get a whole new group of friends. In fact, the best thing you could do for this person is get them out of inner city Baltimore. They can’t go back to the row home they came from.*“
- Now inner city Baltimore might sound like a very extreme example, with crack houses etc.
- But is it really any different for a college kid, who’s trying to, desperately, get off the transition from oxycodone to fentanyl?
  - This is being done in a dorm room or at a party or something like that; and it’s their friends, and they managed to pull out of the grip of that, but they find themselves at another party in three months
  - It’s really difficult; that’s the part that is concerning
- It’s hard to do this one person at a time
- Patrick comes back to the idea of undertow, even as Peter was telling his own story of his experience with OxyContin

> “I think the big thing that comes home to me is just that these substances, they have an awesome power, and that’s compounded by all of the atmospheric, social, situational things you’re talking about” – Patrick Radden Keefe

- He’s talked to a lot of families through the years, who’ve dealt with this, and they thought they were out of the woods, and then they weren’t
- He thinks Peter is right; in any one individual life, and even somebody who actually has a whole support system there, and there are resources to treat the problem, it’s not enough; it’s not adequate
  - On the flip side, in many instances, there are people who don’t have the resources for the appropriate treatment
- He just thinks we should all be humble and mindful in the face of the tremendous potency and power that’s on the other side of this problem
- Peter is thankful for Patrick’s book
  - It  has brought to light a lot of things that probably could have easily gotten ignored or swept away
  - It’s true that during these proceedings, a lot of documents are brought into the public light, but that’s only half the battle; that’s the easy half
  - The hard part is actually going through them and extracting what the story is, and Patrick has done a better job of that, with respect to this important part of the story, than anybody else

§

## Selected Links / Related Material

**Patrick’s recent book on the opioid epidemic**: [Empire of Pain: The Secret History of the Sackler Dynasty](https://www.amazon.com/Empire-Pain-History-Sackler-Dynasty/dp/0385545681/ref=sr_1_1?keywords=Empire+of+Pain%3A+The+Secret+History+of+the+Sackler+Dynasty%3B&qid=1636118088&qsid=130-9088744-0739012&sr=8-1&sres=0385545681%2CB09HCDWY14%2CB09HG6WMQC%2CB092RNV8YK%2CB09H7Q8M4X%2CB098RY9D6X%2C0674399684%2CB09K4KQCTP%2CB0782X9R1W%2C1480748978%2CB000JMKNFQ%2CB002IN7PM8%2C0976309637%2C0987342665%2CB08RR5ZFKQ%2CB09HGQ81JY&srpt=ABIS_BOOK) by Patrick Radden Keefe (2021)

**HBO documentary on the opioid epidemic**: [The Crime of the Century](https://en.wikipedia.org/wiki/The_Crime_of_the_Century_(2021_film)) | [hbo.com](https://www.hbo.com/documentaries/the-crime-of-the-century) | [1:15]

**Patrick’s article about legalization of cannabis in Washington state**: [Buzzkill: Washington State discovers that it’s not so easy to create a legal marijuana economy](https://www.newyorker.com/magazine/2013/11/18/buzzkill) | Patrick Radden Keefe, *The New Yorker* (Nov. 18, 2013) | [4:30]

**Patrick’s article about the Sinaloa drug cartel**: [Cocaine Incorporated](https://www.nytimes.com/2012/06/17/magazine/how-a-mexican-drug-cartel-makes-its-billions.html) | Patrick Radden Keefe, *The New York Times Magazine* (June 15, 2012) | [5:00]

**Recent article in Mother Jones about the AMA and Richard Sackler**: [The Untold Story of Purdue Pharma’s Cozy Relationship With the American Medical Association: The prestigious doctor’s group has made it virtually impossible to discern where public health guidance ends and industry interests begin.](https://www.motherjones.com/politics/2021/08/purdue-pharma-american-medical-association-relationship-opioid-crisis-public-health/) | Julia Lurie, *Mother Jones* (August 5, 2021) | [1:13:45]

**Sam Quinones’ book about the Opiate epidemic: Dreamland**: [The True Tale of America’s Opiate Epidemic](https://www.amazon.com/Dreamland-True-Americas-Opiate-Epidemic/dp/1620402505/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1636576347&sr=8-1) | by Sam Quinones (April 21, 2015) | [1:40:00]

**Patrick’s podcast about the strange convergence of espionage and pop music during the Cold War**: [*WIND OF CHANGE*](https://www.patrickraddenkeefe.com/podcast) | host Patrick Radden Keefe, [patrickraddenkeefe.com](https://www.patrickraddenkeefe.com/)

**Patrick’s website**: [Patrick Radden Keefe](https://www.patrickraddenkeefe.com/)

§

## People Mentioned

- [Chapo Guzmán](https://en.wikipedia.org/wiki/Joaqu%C3%ADn_%22El_Chapo%22_Guzm%C3%A1n) (former leader of the Sinaloa drug cartel) [5:15]
- [Arthur Sackler](https://en.wikipedia.org/wiki/Arthur_M._Sackler)  (eldest of 3 brothers) [11:45;  18:00; 29:30; 1:10:00]
- [Raymond Saclker](https://en.wikipedia.org/wiki/Raymond_Sackler) (one of 3 brothers) [11:45]
- [Mortimer Sackler](https://en.wikipedia.org/wiki/Mortimer_Sackler) (one of 3 brothers) [11:45; 1:40:15]
- [Richard Sackler](https://en.wikipedia.org/wiki/Richard_Sackler) (son of Raymond Sackler and Purdue Pharma executive) [27:15; 32:00; 41:45; 1:05:15; 1:13:45]
- [Sean Mackey](https://profiles.stanford.edu/sean-mackey) (doctor at Stanford who helped Peter with pain when he quit taking OxyContin) [1:07:15]
- [Mary Jo White](https://en.wikipedia.org/wiki/Mary_Jo_White) (former US attorney for the Southern district of New York) [1:18:45; 1:20:30; 1:24:45]
- Senators and congressman involved in bills that supported OxyContin [1:19:30]
  - [Chris Dodd](https://en.wikipedia.org/wiki/Chris_Dodd), [Marsha Blackburn](https://en.wikipedia.org/wiki/Marsha_Blackburn), [Tom Marino](https://en.wikipedia.org/wiki/Tom_Marino), and [Orrin Hatch](https://en.wikipedia.org/wiki/Orrin_Hatch)
- [Rudy Giuliani](https://en.wikipedia.org/wiki/Rudy_Giuliani) (previous US Associate Attorney General) [1:20:30; 1:24:45]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) (43rd US President) [1:24:45]
- [Alice Fisher](https://en.wikipedia.org/wiki/Alice_S._Fisher) (former Assistant Attorney General in the Department of Justice Criminal Division) [1:25:00]
- [Paul McNulty](https://en.wikipedia.org/wiki/Paul_McNulty) (former  Deputy Attorney General) [1:25:00]
- [John Kapoor](https://en.wikipedia.org/wiki/John_Kapoor) (CEO of Insys Therapeutics who was sentenced to prison) [1:34:15]
- [OJ Simpson](https://en.wikipedia.org/wiki/O._J._Simpson) (former football player tried for the murder of his wife Nicole Brown Simpson) [1:35:30]
- [Sam Quinones](https://en.wikipedia.org/wiki/Sam_Quinones) (Author of *Dreamland*)  [1:40:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/12/1x1-keefe-500x500.png)

##### Patrick Radden Keefe

Patrick grew up in Dorchester, Massachusetts and went to college at Columbia. He received masters degrees from Cambridge University and the London School of Economics, and a JD from Yale Law School.  He is the recipient of a Guggenheim fellowship, and fellowships from the Rockefeller Foundation, the New America Foundation, the Woodrow Wilson International Center for Scholars, and the Cullman Center for Scholars and Writers at the New York Public Library.

Patrick is an investigative journalist and has written extensively for many publications.  He is an award-winning staff writer at *The New Yorker* magazine.  His work has appeared in *The New York Review of Books*, *The New York Times Magazine*, *Slate*, and other publications.  He received the National Magazine Award for Feature Writing in 2014, and was a finalist for the National Magazine Award for Reporting in 2015 and 2016.

He is the author of four books: *Chatter*, *The Snakehead*, *Say Nothing*, and *Empire of Pain*.  *Say Nothing* received the National Book Critics Circle Award for Nonfiction, the Orwell Prize for Political Writing, and was selected by Entertainment Weekly as one of the “10 Best Nonfiction Books of the Decade.” The *Rolling Stone* describes Keefe as “*an obsessive reporter and researcher, a master of narrative nonfiction*”.

Patrick is also the writer and host of [*WIND OF CHANGE*](https://www.patrickraddenkeefe.com/podcast), an 8-part podcast series from Pineapple Street Studios, Crooked Media and Spotify, which investigates the strange convergence of espionage and pop music during the Cold War and was named the #1 podcast of 2020 by *The Guardian*.  [[patrickraddenkeefe.com](https://www.patrickraddenkeefe.com/bio-new)]