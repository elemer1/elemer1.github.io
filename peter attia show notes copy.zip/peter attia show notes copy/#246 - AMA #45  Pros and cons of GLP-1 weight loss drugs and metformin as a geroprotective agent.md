# #246 – AMA #45:  Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent

**Source:** [https://peterattiamd.com/ama45/](https://peterattiamd.com/ama45/)

---

In this “Ask Me Anything” (AMA) episode, Peter focuses the discussion on two topics getting a lot of attention recently. He first dives deep into GLP-1 agonists, most notably semaglutide and tirzepatide, which originally came to market as diabetes drugs but are now being studied and prescribed for weight loss. He walks through the data and compares the effectiveness of the two drugs, the side effects, and perhaps more importantly, his reservations around wide use of these drugs and who he would consider to be a candidate for them. Next, Peter discusses how metformin, another drug originally brought to market for diabetes management, gained popularity as a potential longevity drug even for non-diabetics. Peter gives his take on this possibility and reviews data from a more recent study investigating the question of whether metformin should be used for general “geroprotection.”

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #45 show notes page](https://peterattiamd.com/ama45). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The hype around semaglutide, tirzepatide, and other GLP-1 agonists for weight loss [2:30];
- Overview of GLP-1 agonists and why these drugs are getting so much attention [6:15];
- Defining the term “geroprotective” [11:30];
- Semaglutide: background, brand names, indications, and more [15:15];
- Tirzepatide: background, brand names, indications, and more [19:15];
- How semaglutide and tirzepatide compare in their efficacy in terms of weight loss and other metabolic health metrics [23:45];
- Data showing sustained weight loss and improved metabolic metrics with after more than a year of using semaglutide and tirzepatide [29:00];
- What happens to body weight when a patient discontinues the medication? [34:45];
- Noteworthy side effects of GLP-1 agonists and similar classes of drugs [40:45];
- Increased resting heart rate and other concerning trends in patients using GLP-1 agonists [45:15];
- Changes in body composition (body fat and lean muscle) in patients on GLP-1 agonists [50:45];
- Possible reasons for the loss of lean muscle mass and tips for protecting lean mass [59:00];
- GLP-1 agonists and thyroid cancer [1:01:30];
- Who might be a candidate for GLP-1 agonists? [1:03:45];
- The large financial cost of this class of drugs [1:08:30];
- Metformin as a geroprotective drug: origin of the idea that metformin could be a longevity agent even for non-diabetic patients [1:11:30];
- A 2022 study on metformin sheds more light on the question of whether metformin should be used for “geroprotection” in non-diabetics [1:21:00];
- Peter’s current approach with metformin for his patients [1:25:15]; and
- More.

§

The Peter Attia Drive

Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent

§

## Show Notes

§

## The hype around semaglutide, tirzepatide, and other GLP-1 agonists for weight loss [2:30]

- Peter’s book is now available for pre-order: [Outlive: The Science & Art of Longevity](https://peterattiamd.com/outlive/)
- Stay tuned for a dedicated AMA episode about the book

\*\*\*

**Today’s discussion**

- Two different subject both of which have been covered before but new data and insights have come to light

**Topic 1: GLP-1 agonists**

- GLP-1 agonists were covered in [AMA #29](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)
- When that episode came out, these “weight loss” drugs weren’t yet being covered as much as they are now
- In some way, they were “too far ahead of the curve” when having that discussion
- The first real discussion about semaglutide and other similar drugs amongst Peter and the team was in the spring of 2020
- By the fall of 2020, they were putting patients on one of the drugs (semaglutide)
- A year later after that, they did [AMA #29](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) on that subject but it was still very under the radar
- And today, semaglutide (and similar drugs like tirzepatide) might be the single most talked about drug
  - Semaglutide is branded as Ozempic and Wegovy
  - Tirzepatide is branded as Mounjaro
- Peter has a much stronger view about these drugs than he did a couple years ago and he will share that today

**Topic #2: Metformin**

- They will be looking at some new data on metformin
- Peter will provide his updated view on metformin as a potential geroprotective agent more so for those who are in the camp of taking it as a longevity agent (rather than a diabetic patient)

## Overview of GLP-1 agonists and why these drugs are getting so much attention [6:15]

Listen to [AMA #29](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) and if anyone wants to get deep into the science of these drugs

\*\*\*

**Overview of the GLP-1 drugs and why people are so excited about them**

- We’re really going to be talking about two hormones today, GLP-1, or glucagon-like peptide 1, and GIP, glucose-dependent insulinotropic polypeptide
  - Both of these are hormones that are released from the gut
  - One is released from one part of the gut, one is released from the other
  - But the net-net is their effect on insulin
- You got to understand that these drugs really started as drugs to take care of patients with type 2 diabetes

*What is type 2 diabetes?*

- It’s a disorder of carbohydrate metabolism
- Blood glucose gets too high and that is the defining feature of it
- Now, you could argue that might not be the right defining feature and maybe we should be defining it earlier on, but it’s basically a very extreme state of insulin resistance
- In a person who is developing type 2 diabetes, their cells, most notably their muscle cells, but also other cells in the body such as the liver, are becoming resistant to the effects of insulin
- And as such, their blood glucose levels are rising
- The reason for that, of course, is that the muscle is the most important storage depot for glucose and so if the muscles are resistant to the effect of insulin, glucose will accumulate in the bloodstream.

*So what are we to do about this?*

![](https://peterattiamd.com/wp-content/uploads/2023/03/f1-ama45-1024x585.png)

**Figure 1.** Source: [Wikipedia DPP-4 inhibitors](https://en.wikipedia.org/wiki/Dipeptidyl_peptidase-4_inhibitor)

- There are lots of things to do about it
- But what this figure shows is that an important strategic plan is using things that either stimulate insulin to be released and/or inhibit glucagon release
- Both of those things will have the same net increase, which is to lower blood glucose, because if you stimulate insulin release, you’re going to put more insulin into circulation
- That’s going to overcome, at least transiently, the insulin resistance in the muscle
  - That turns into a very slippery slope because you can only play this game for so long before you basically exhaust the pancreas’s capacity to produce more and more insulin and, at some point, you just end up having to use exogenous insulin
- The inhibition of glucagon release conversely changes the way that the liver puts glucose into circulation
- As you can see in this figure above, GLP-1 and GIP act through both of these arms—
  - They stimulate insulin release (endogenously)
  - And they inhibit glucagon release
  - The net effect of both of these is a reduction of blood glucose

So we have this observation that people who were taking GLP-1 agonists were not only improving glycemic control, which you would expect, but were also losing weight

- The question was, “Well, why are they losing weight?”
- Today, we don’t have a really clear explanation for why
- Virtually everybody who’s had any clinical experience with these and who has looked at the literature agrees that it’s clearly a central effect, meaning there is something about these hormones that is reducing our appetite
- So when you take these hormones, your appetite goes down, you eat less, you lose weight
- It’s relatively straightforward, but the exact why is not clear, meaning it’s not exactly clear why GLP-1 is acting centrally in reducing appetite

![](https://peterattiamd.com/wp-content/uploads/2023/03/f2-ama45-1024x733.png)

**Figure 2.** Source: [Tyagi and Pugazhenthi Mol Neurobiol, June 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9196144/)

- This figure is through the lens of type 2 diabetes
- The goal in type 2 diabetes is to lower blood glucose
  - Peter would argue that the goal should be to increase insulin sensitivity, which will result in a reduction in blood glucose, but let’s put that aside for a moment
- What you see here is lots of different drugs, two of which we’re going to talk about today
- Metformin really acts primarily to reduce glucose production (hepatic glucose output)
  - Metformin might also increase glucose utilization in the muscles (that’s far less of an effect)
- If you look at a figure like Figure 2, you might come to the conclusion that those are equal – but that’s not the case
- There’s another class of drug we’re not going to talk about today, but it’s a very important class of drug: SGLT2 inhibitors
  - See [episode #148 with Rich Miller](https://peterattiamd.com/richardmiller/) where they discuss an SGLT2 inhibitor called canagliflozin
  - These are drugs that act in the kidneys and they impair glucose reabsorption, so you end up peeing out more glucose
  - That episode speaks about canagliflozin in the context of the benefits on longevity as a result of that
- So metformin we’re going to talk about today less because of its diabetic effects, but more to talk about it through its geroprotective effects
- But just so you can see it in figure 2, this is how they’re acting in the diabetes space
  - You have sulfonylureas and you have these incretin therapies that we’re going to talk about today
  - So in a rather large nutshell, that’s the backdrop to what we’re talking about here

**GLP-1 agonists for weight loss**

- Just to be clear, 100% of the inquires Peter is getting from people about GLP-1 agonists is in the context of weight loss and NOT for diabetes treatment
- These are people that are asking the question solely through the lens of weight loss
- To be clear, some of these people are in genuine need of weight loss—people with 40-50% of their body weight in body fat
- But, perhaps more disturbing to Peter is the people who are reaching out who are frankly not overweight remotely, but are saying, “*I really want to lose 10 pounds to look good on my vacation and I should be taking this, right*?”

## Defining the term “geroprotective” [13:30]

Geroprotective

- Gero- meaning aging
- And protective
- It’s a term we use to describe drugs whose exact mechanisms of aging might not be known, but they appear to act broadly across various different hallmarks of aging

For instance, lipid-lowering drugs improve longevity, but we wouldn’t call them “geroprotective” because they’re acting on one very specific element, which is lipoproteins

- But contrast that with, rapamycin or SGLT2 inhibitors or potentially, metformin, where they’re probably doing a lot of things that overall improve lifespan and healthspan beyond just a “one disease at a time” approach

## Semaglutide: background, brand names, indications, and more [15:15]

**Background on semaglutide**

- Semaglutide is a pure GLP-1 agonist
- it has a comparable affinity to pure GLP-1
- there’s a chemical way that you can look at the concentration of semaglutide and ask the question, “How much of it do you need to replicate the effect of pure GLP-1?”
- In the case of semaglutide, it’s on the order of half as potent, but nevertheless, it’s a pure GLP-1 agonist, meaning it’s replicating as opposed to antagonist
  - Antagonists block the effect of hormone

**Ozmepic**

- The branded name for semaglutide in the use for type 2 diabetes is called [Ozempic](https://www.ozempic.com/)
- It comes in three doses: 0.5, 1.0, and 2.0 milligrams
- It comes with an autoinjector pen that needs to be refrigerated and they’re very expensive
- A patient who’s historically been getting this treatment of their type 2 diabetes is either giving themselves 0.5 or 1 or 2 milligrams of this drug once per week

**More info**

- Semaglutide is not quite as potent as the actual GLP-1 and you might ask “why didn’t they make it that way?” … And the reason is it was designed that way
- It was designed to have a much longer half-life
- If you’re thinking about drug delivery, how long the drug stays in circulation is really important
- if you could make native GLP-1, but it only stuck around your system for six hours and you had to inject yourself four times a day, that’s a much worse trade-off than, say, being able to have it slightly less potent and just use a greater dose of it, but only inject yourself once a week
- Basically, Ozempic (semaglutide) was approved in late 2017 for treating T2D

**Wegovy**

- In the spring of 2021, a [study](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183) was published that at semaglutide (using Ozempic) as an indication for treating obesity without diabetes
  - See [AMA #29](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) for more
- That study led to the approval of a new drug called [Wegovy](https://www.wegovy.com/) which is the exact same drug (semaglutide is Ozempic is Wegovy)
- The difference is basically branding and dosing
- Wegovy is dosed up to 2.4 milligrams per week
- It was just [recently approved](https://diatribe.org/fda-approves-weight-loss-drug-wegovy-teens) for kids age 12 and up

## Tirzepatide: background, brand names, indications, and more [19:15]

**Background**

- Tirzepatide is not the same as semaglutide
- It is, in fact, a drug that is known as a co-agonist
- So it is both GIP and GLP-1
- Semaglutide is, directionally speaking, about half as potent as native GLP-1
- Whereas tirzepatide is even less than that—a quarter as potent as native GLP-1
- However, when you compare the GIP activity, it’s virtually identical to native GIP
- So if you think of semaglutide as a slightly weaker version of GLP-1, you would think of tirzepatide as a much weaker version of GLP-1, but a very potent GIP
- It’s basically equivalent biologically to GIP

**Brand**

- Tirzepatide is branded as a drug called [Mounjaro](https://www.mounjaro.com/)
- It’s a preloaded pen that you inject
- It comes in increments. I believe it’s 2.50, 5.00, 7.50, 10.00, 12.5, all the way up to 15.00 milligrams
- It was approved relatively recently for type 2 diabetes
- that approval took place like a year ago
- It has not yet gained FDA approval for obesity

**For weight loss**

- The New England Journal of Medicine published a [study](https://www.nejm.org/doi/full/10.1056/NEJMoa2107519), which is where a lot of the hype came from, that demonstrated that this is even a better drug than semaglutide for weight loss
- Presumably, they’re in the process of now gaining approval for obesity use
- And when a drug is approved by the FDA, you can basically use it for anything you want—it’s just considered off-label, and it would never be approved by insurance companies
- For people who are willing to pay out of pocket, there are lots of people who are both being prescribed and using tirzepatide (Mounjaro) for the purposes of obesity
  - And to be clear, whatever approval comes for obesity, it’s going to have a new name

***Will either of these drugs ever be non-injectable? Will there ever be a day in which you can take a pill?***

- There is an oral semaglutide as well branded as Rybelsus
- It’s also very expensive, and Peter’s not exactly sure what the differences are and why one would prefer it over the injectable (other than not liking needles)

## How semaglutide and tirzepatide compare in their efficacy in terms of weight loss and other metabolic health metrics [23:45]

***How do those two drugs, semaglutide tirzepatide, compare in their effectiveness? In looking at weight loss, HbA1c, those other things that they’re measuring, do we see a difference in the results?***

- It’s hard to do a direct head-to-head, because they’re being studied in different studies and therefore you have to be able to look at that and tease it out
- Top line is that tirzepatide is a better drug all round, meaning it produces more weight loss and a greater reduction in hemoglobin A1C

![](https://peterattiamd.com/wp-content/uploads/2023/03/f3.-summary-of-studies-ama45-1024x969.png)

**Figure 3.**

For the purpose of this discussion we’re going to focus on comparing [STEP 1](https://www.nejm.org/doi/10.1056/NEJMoa2032183) with [SURMOUNT-1](https://www.nejm.org/doi/full/10.1056/NEJMoa2206038)

- STEP-1 was 2.4 milligram versus placebo obesity study of semaglutide
- SURMOUNT-1 was the 5, 10, 15 milligrams versus placebo for obesity study of tirzepatide
- Why is that the only comparison we’re going to talk about today?
  - Same amount of patients (2,000)
  - They’re both a little over a year
  - They’re both just for obesity
  - and they’re both at the doses that people are using to treat obesity

When you look at those two studies at the **40 week mark** …

- Those taking 2 mgs of Ozempic aka semaglutide (see [SUSTAIN-FORTE trial](https://pubmed.ncbi.nlm.nih.gov/34293304/)) had lost 6.9 kilograms of weight (6.9% of body weight lost)
- Those taking 5, 10, or 15 mg of tirzepatide (see [SURPASS-2 trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2107519)) had lost 7.8, 10.3, or 12.4 kilograms of weight, respectively ( in percent that would be 8.5%, 11%, or 13.1%, respectively)
- There’s no ambiguity that those on tirzepatide lost more weight

## Data showing sustained weight loss and improved metabolic metrics with after more than a year of using semaglutide and tirzepatide [29:00]

- The hardest part with weight loss isn’t losing the weight, it’s keeping it off
- Peter and Stephan Guyenet talked about that in [episode #212](https://peterattiamd.com/stephanguyenet/)

***What do we know as it relates to the GLP-1s? Can the weight loss be sustained indefinitely?***

- We looked at 40 weeks and it is sustained
- But does it continue if you go to 50, 60 weeks? Does it plateau?
  - We do know that over a period of about two years, the maximum amount of weight loss is sustained by about the end of year one
  - And it appears to be dose dependent
  - Here’s the thing, at least **the weight loss did remain throughout the second year**

**Tizepatide:**

![](https://peterattiamd.com/wp-content/uploads/2023/03/f4-ama45-1024x433.png)

**Figure 4.** Source: [Del Prato et al. The Lancet Nov 2021](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02188-7/fulltext)

Looking on the left hand side of this figure you see changes in total body weight in kilograms over 104 weeks for tirzepatide

- You have three doses, plus the use of insulin (the insulin here is the placebo)
- These people are being targeted to have the same extent of glycemic control, but different amounts obviously, of weight loss
- There’s no confusion as to what the answer was here
- The people who were given insulin gained weight—about two and a half kilos over the two year period of time, pretty steadily
- Conversely, the people on 5, 10 and 15 milligrams of tirzepatide lost weight
- They basically all hit their nadir at about 52 weeks, so it was either the -5.8 kilos, the -10.4 kilos, the -11.1 kilos.
- As you can see, they just kept that weight off for the next year

If you look at the right hand side of this figure, you’re seeing the change in hemoglobin A1C levels

- “For what it’s worth, this is pretty freaking impressive.”
- These people were starting out with an average hemoglobin A1C of a little over 8.5% (the cutoff for type two diabetes is 6.5%)
- These people weren’t slightly diabetic, they were full fledged diabetic
- At a hemoglobin A1C of 8.5%, your average blood glucose is over 200 milligrams per deciliter: “*You are well into the territory of absolute destruction of your microvasculature, your kidneys, your brain, to some extent your heart, and probably your penis, if erectile function matters to you*.”
- Notice that within six months, every one of the people on tirzepatide is below a hemoglobin A1C of 6.5% and they all stay there

Overall:

- These drugs are really special in certain ways, and we should applaud them (but Peter does have reservations which he will speak on later)
- So if you’re looking at this through the lens of this patient population with type two diabetes, this is really impressive stuff
- These data are from the [SURPASS-4 trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02188-7/fulltext), which was a trial of patients with type two diabetes, and this got everybody excited, as both a diabetes drug, but also a weight loss drug

**Semaglutide**:

![](https://peterattiamd.com/wp-content/uploads/2023/03/f5-ama45-1024x331.png)

**Figure 5.** Source: [Marso et al. NEJM Nov 2016](https://www.nejm.org/doi/full/10.1056/nejmoa1607141)

Starting on the right side you’ll see changes in body weight

- Here you’re looking at placebo versus semaglutide at 0.5 milligrams or 1 milligram
- You actually see a very similar shape as tirzepatide
- Notice by about somewhere between 45 and 56 weeks, both groups hit their nadir, and their nadir is a function of dose
- Then, they go on to spend the next year at the exact same spot
- The weight loss here is not as great as tirzepatide, but the same shape of the curve exists

If you go to the left, you’re going to look at their hemoglobin A1C

- These patients were also basically identical—They’re starting out at about 8.7% hemoglobin A1C, but notice that the reduction here was not as great, nor did it appear as durable, meaning they all bought them out at 16 weeks, so four months in
- Then, they continue to creep back up, though obviously never getting anywhere near where they started

***So how durable is this indefinitely?***

“*I don’t know. We don’t know what we don’t know*.” says Peter

- It’s possible that those hemoglobin A1C numbers are going to keep creeping back up, and back up, and back up and eventually get to where they were
- It’s also possible that weight set point reaches some new spot and after three years or after four years, weight starts to drift back up
- Those are going to be the things that are very interesting to follow as time goes on

## What happens to body weight when a patient discontinues the medication? [34:45]

***What happens to body weight if you stop taking one of these drugs?***

- We have pretty clear data on this question
- Let’s look at the [semaglutide trial](https://www.nejm.org/doi/10.1056/NEJMoa2032183) that led to the approval of semaglutide for obesity

![](https://peterattiamd.com/wp-content/uploads/2023/03/f6-ama45-1024x470.png)

**Figure 6.** Source: [Wilding et al. Diabetes Obes Metab. May 2022](https://dom-pubs.onlinelibrary.wiley.com/doi/10.1111/dom.14725)

On the left side you’re looking at body weight change:

- In the little gray triangles, you have the placebo—Basically no weight loss with some slight fluctuation
- Conversely, when you look at the semaglutide arm—it’s pretty dramatic weight loss
- The weight loss phase:
  - From when you started until you hit your bottom at 68 weeks, we would agree that the first derivative is negative, meaning weight is going down
  - But the second derivative of the weight loss phase is positive
  - What that means is, the rate at which the weight is going down is decreasing (so you’re still losing weight, just not at the speed you were initially)
- After stopping the drug:
  - When you look at what happens the minute they hit 68 weeks and you take the drug away, they start gaining weight
  - The first derivative is positive (increasing rate of weight gain)
  - But the second derivative now is negative (They’re gaining weight at a lower and lower rate)
- In both cases, the **most extreme changes physiologically occur at both the initiation and removal of drug**
- It is a bit of an extrapolation to come to the conclusion that you, “Only regain two-thirds of your body weight,” because at 120 weeks they were back to two-thirds of their body weight
- And based on the concavity of the figure, it does look like they’re stabilizing
- Maybe it takes another year, but it’s entirely possible you’re going to regain every ounce you lost.
- By the way, it’s possible you’re going to regain more of that weight
- None of these data are dispositive for the fact that that’s not going to happen

Just to round this out…

- If you look at the right side figure, you’re basically going to see the data that was just explained, but not for everyone
- On the left, it’s showing that for everybody blended
- On the right, it’s showing those data as a percentage of weight loss change
- On the right side, you to have five lines of people who:
  - Lost less than 5% of their weight
  - lost between 5% and 10%,
  - Lost between 10% to 15%,
  - Lost between 15% to 20%,
  - Lost more than 20%.
- It’s super interesting that regardless of how much weight you lost, it’s always the same—It’s always this positive second derivative on weight loss, negative second derivative on weight gain, meaning most rapid initially and constantly getting less rapid in that direction
- Not surprisingly, the more weight you lose, the lower your weight is off drug 120 weeks after you initiated this study, or basically a year off drug
- For those people who lost more than 20% of their body weight, they were still minus 12% a year out off drug, and they averaged about minus 27% of their body weight, which is just a staggering number
- Conversely, the people who only lost about 5% of their body weight or less, were actually heavier a year off
- The people who lost between 5% and 10%, which averaged about 7%, were right back to baseline weight
- The people who were between 10% and 15%, which averaged about 12% weight loss, were also just a touch under baseline a year later

The other thing worth noting:

- When you look at that figure on the left and you see that “Two-thirds of the weight gets regained”…
- Well, let’s be clear, that’s virtually a**ll happening through the lens of people who didn’t lose up to 20% of their body weight**

## Noteworthy side effects GLP-1 agonists and similar classes of drugs [40:45]

**Side effects of semaglutide vs. tirezpatide**

- They’re similar, but pretty much across the board, semaglutide is worse
- there’s no question that people are experiencing greater side effects, both in duration and severity, with semaglutide

Nausea and appetite suppression

- It suppresses your appetite so much that you don’t want to eat, and you feel nauseous
- When you do eat, you fill up really quickly
- In the step one trial, 44% of patients experience nausea with semaglutide
- In the SURMOUNT-1 trial, again, these are the most recent studies, we’re talking 30% basically

Diarrhea

- 30% diarrhea with semaglutide versus 23% with tirzepatide

\**Note that these side effects are quite transient so they don’t last forever*

- The speed at which you ramp up the drug can dramatically lessen the severity of these as well
- In the clinical trials, they take about 12 or maybe even 16 weeks to get patients to full dose

Vomiting

- It’s is about a 2x difference in favor of semaglutide— 25% versus 12% for tirzepatide
- This speaks to the nature of these hormones—wen you start mucking around with GLP-1 and GIP, you are going to have some serious GI side effects

Nasopharyngitis

- About 20% of people get irritation/runny nose

Headaches

- 15% with semaglutide versus 6% with tirzepatide
- Peter suspects that might be due to dehydration

Abdominal pain

- About 10% of people on semaglutide will complain of abdominal pain, and about half that, about 5% on tirzepatide

Overall

- It’s funny that “You got people just clamoring to be on these drugs…and you’re pretty much guaranteed to have miserable side effects” says Peter
- Clinically, Peter says that he will titrate the dose very slowly, and that does make it a bit more manageable

## Increased resting heart rate and other concerning trends in patients using GLP-1 agonists [45:15]

**Clinically, Peter is seeing some concerning trends and metrics in patients who are using these drugs…** ***What is he seeing?***

Heart rate

- Peter had his team pull the heart rate trend data for every single patient we have put on one of these drugs in the past two years
- 100% of the time he saw that his patients had somewhere between about an 8-15 beat-per-minute increase in heart rate overnight
  - If you’re a person whose normal resting heart rate was 65 beats per minute overnight, it just went to 75
- That also seems to translate into exercise metrics
  - if your zone 2 heart rate was 130 beats per minute, it just went up to 135 with no increase in power output.
- We don’t see this in the literature, but they’re not measuring this
- There could be a completely benign explanation for this: which is, “Yeah, heart rate goes up because of some central governing or regulatory process, meaning central, meaning CNS. But it’s totally fine because of reasons X, Y and Z.”
- But as a general rule, things that raise your resting heart rate are not good
- D*oes that mean we should never be taking these drugs*?
  - Of course not
  - It just means we have to think about the trade-offs, the cost versus the benefit. And I think this has to be clearly in the column of costs of taking this drug.

Insulin

- It seems to be transient, but at least in the short run, fasting insulin rises when you take these drugs
- This happens in about ⅔ of patients
  - Not surprising given the mechanism of how these things work, and we’ve focused really heavily on the central mechanisms around eating less
- But remember, the original reason that these drugs were brought to market to treat patients with type 2 diabetes was less about the eating less part in losing weight, and more about the increasing the production of insulin
- It’s very interesting that people will forever associate Peter with low-carbohydrate diets, and the belief that insulin is solely responsible for weight gain
  - At one point in time, Peter very much favored the hypothesis that insulin was one of the most important factors in weight gain, however, his thoughts on that have changed so much over the past 10 years
  - The GLP-1 agonists almost single-handedly disproved the idea that insulin can be the sole driver of weight gain, because even in the presence of an increase in insulin, which you get with these drugs, people are still losing weight because they’re eating so much less
- So yeah, maybe they have transient hyperinsulinemia, but their energy intake is falling, and they are losing weight
- This is a very important observation

Heart rate variability

- Heart rate variability goes down, although that is less consistent
- some people, we see a big reduction
- when they’re on the drug, and then it rebounds when they’re off
- In others, we don’t see any change
- Whereas heart rate always appears to be negative (meaning it goes up)
- heart rate variability, about half the time it appears to be negative; half the time it appears to be neutral

## Changes in body composition (body fat and lean muscle) in patients on GLP-1 agonists [50:45]

**Body comp changes**

- With these drugs, we know that weight loss and weight can go down
- But what has Peter seen before and after DEXAs to see what you’re learning about that weight loss?
- This is the most important thing we will discuss today related to these weight loss drugs

**Studies not tracking body comp — why that is not good:**

- All of the studies that we’ve talked about, the FDA has forced the primary outcome to be weight loss, when weight loss is the variable of interest
- Once we pivoted over to FDA approval for obesity, the primary metric that the FDA cares about is weight loss. They don’t care about body composition
- But you should really concern yourself with body composition
- For instance:
  - Because if you take a person who weighs 200 pounds and they lose 20 pounds, that sounds great. They lost 10% of their body weight; they’re down to 180 pounds
  - But there isn’t a single physician out there worth his or her salt that would say, “If 18 of that was muscle and two of that was fat, that would be a good thing
  - Versus if 15 of that was fat or 16 of that was fat, and four of it was muscle.
  - Those people both lost 20 pounds, and they both lost 10% of their body weight
  - But one of them decimated their lean body weight, and the other had a dramatic improvement in body composition
  - They’re not even remotely similar. And yet the FDA is arguing they are indeed the same

**Testing body comp in a very small subset of patients in the** [**STEP 1 trial**](https://www.nejm.org/doi/10.1056/NEJMoa2032183)

- The STEP 1 trial is the 2.4 milligram semaglutide study for obesity published in the spring of ’21
- A tiny subset of that, like 140 patients, were also surveyed via DEXA—they had DEXA before and after
- If you’re taking an overweight person and you want to take 10 kilos off them, in an ideal world, you would only want 2.5 of that or less to be lean tissue, 7.5 of that to be fat.
- In those 140 patients that they studied, there was a mean loss of 8.36 kilograms of total body fat and 5.26 kilograms of total body lean mass
- In other words, for every kilogram that you’re losing lean, instead of losing 3 kilograms of fat, they were losing only 1.6 kilograms of fat

*For Peter’s patients, he is seen an even worse loss of lean vs fat mass*

- It is as bad as one-to-one: meaning you lose a kilogram lean, you’re losing a kilogram of fat
- Unfortunately, when Peter first started prescribing these drugs, he wasn’t insisting on a DEXA immediately, pre-drug
- But now, he will not put a patient on either semaglutide or tirzepatide without getting a DEXA scan first

> “The thing that concerns me the most with these drugs, even more than the increase in resting heart rate, certainly more than the transient increase in hyperinsulinemia, is this basically drive towards sarcopenia.” —Peter Attia

*Patient case study*

- Peter just looked at a DEXA scan of a patient yesterday who’s had a remarkable weight loss
- unfortunately did not have a pre-DEXA on her
- She was probably in the neighborhood of 35% body fat at the outset
- probably in the 80th percentile for her body fat for sex and age
- She’s now just below the 50th percentile for body fat. She’s at about 25% body fat
- But her ALMI, her Apendicular Lean Mass Index, is below the 10th percentile.
- she went from actually having quite a bit of muscle mass to being emaciated-looking
- for reference, you want ALMI to be 75% and over (At a minimum, 50th percentile)
- the data shows an enormous step up in longevity at the 75th percentile, in terms of reduction in mortality once you are over the age of 70

Remember, we’re all training to be centenarian decathletes. We all want to have the best marginal decade. You really want your muscle mass to be above the 75th percentile by the time you’re in your 70s, for your age.

- The woman in the case study above is now staring down the barrel of being below the 10th percentile
- It’s really hard, because she’s delighted with how much weight she’s lost
- But “I’m not convinced we’ve made you any healthier. I really am not convinced we have increased the likelihood that you are going to live longer.” says Peter
- Not seeing this in everybody, but seeing this in a lot of people
- “*That’s why it just really troubles me with how casually people are approaching these drugs*.” says Peter

Another story worth mentioning…

- Peter was asked by someone who was inquiring about whether her 15 year old daughter should take these drugs to lose weight
- The parent asked Peter a wise question, “If we put my daughter on this, will she be on it forever?”
- The honest answer from Peter was “*I don’t know*”
- However, if the answer to that question turns out to be yes, “*I’d be uncomfortable with that. I would be really uncomfortable saying, “You’re going to be on a GLP-1 agonist and/or a co-agonist for the rest of your life if you’re 15 years old*.””
- “*Maybe I’m wrong on that. Maybe there’s nothing wrong with that. If there is any harm in that, I hope we don’t look back and think, ‘Oh God, we were a little premature on the use of those drugs’*.”

## Possible reasons for the loss of lean muscle mass and tips for protecting lean mass [59:00]

***What do you think drives the loss of lean mass in such high percentage?***

*Is it they’re not exercising enough? Is it through the lack of calories? They’re just not getting enough protein? Do you have any insight into maybe what’s driving that, more so than in traditional weight loss?*

It’s worth stating that a lot of what I said is not unique to GLP-1 agonists or co-agonists—Meaning anytime you’re losing weight, it’s really hard to not lose lean tissue

if you’re just trying to do this with exercise and nutrition, it’s a hard game regardless.

the simplest explanation is, these drugs are so potent at reducing your appetite; and in particular, protein

protein is just very satiating

think your appetite for protein just goes into the toilet when you’re on these drugs

It’s hard to eat a gram of protein per pound of body weight every day, spread out over three or four servings. That takes work

now all of a sudden you nuke their appetite, and you doubly nuke it for protein

I think people simply can’t come close to hitting their protein targets.

Therefore, when we put patients on these drugs now, we’re not only getting that DEXA scan in advance, we’re also saying, “Look, we’re going to force you to track your protein intake. And we’re going to want to see you hit your protein targets

## GLP-1 agonists and thyroid cancer [1:01:30]

*Another question that we saw come through pretty frequently was around a study on GLP-1 agonists, and potentially an increase in thyroid cancer*

- There was a [French study](https://diabetesjournals.org/care/article-abstract/46/2/384/147888/GLP-1-Receptor-Agonists-and-the-Risk-of-Thyroid?redirectedFrom=fulltext) that looked at liraglutide
- Remember, there was a version of these drugs, even before semaglutide and certainly before tirzepatide, called liraglutide
- This one study that suggested maybe a small increase in the incidence of thyroid cancer
- So the FDA has now said, “Look, we’re going to indicate that GLP-1 agonists are not to be used in people with either a direct history or family history of one type of thyroid cancer called medullary thyroid cancer, or a pretty unusual and rare genetic condition called Multiple Endocrine Neoplasias (MENs)
- Peter has also read alternative views of that, which is that, “No, there was no increase. You were just observing the baseline change.”
- So this is still kind of a relatively undecided thing
- Peter says to heed the advice of the FDA on this if someone has thyroid cancer, a family history of thyroid cancer or MENs, don’t use these drugs

In Peter’s patient population, he tends to worry about this a little bit less, because we are very aggressive with cancer screening

- The problem with thyroid cancer, by the way, is screening for cancer is almost impossible in the thyroid
- You’re going to get all-day false positives
- The nature of that glandular tissue is such that it’s very difficult to screen for cancer.

## Who might be a candidate for GLP-1 agonists? [1:03:45]

Hypothetically speaking, if two patients came to Peter thinking about taking one of these…

- One patient who is 75-100 pounds overweight
- Another patient who wants to lose 10 pounds before summer vacation
- What is Peter saying to them as they think through this?

There is a huge difference between how Peter would speak to these 2 patients

- To the patient who wants the beach bod and they’re 10 pounds overweight, I’m just outright saying, “No.”
  - “*I’ve upset some patients. I’ve even had patients go to other doctors, who will write these prescriptions for them in that setting…I’m not convinced there’s much of a benefit in a normal-weight person losing 10 pounds.*”
  - There’s a potential harm in a normal-weight person losing 10 pounds, because they’re likely going to disproportionately lose muscle—the lower your weight at the beginning, the more you’re susceptible to losing muscle
  - If a person loses 10 lbs, 7 of which is muscle, “*there’s no scenario under which that person got healthier or got better in any way, shape or form, other than maybe their pants are a bit looser*”
  - There is downside in terms of the side effects (e.g., HR increase) and furthermore, we don’t even know if this stuff lasts
    - According to the published data, the minute you come off that drug, you can expect to start regaining that weight — And within a year, you’re going to have it all back or even be heavier

To the patient who is overnourished (and maybe have diabetes or pre-diabetes)…

- It could be that this person is having orthopedic issues because of weight, or having sleep apnea because of weight, and they are 50 pounds overweight
- In that situation, all those costs are still there, but the benefits might actually outweigh them
- In those patients, Peter is willing to do this
- However, he wants to ensure guardrails are in place to make this more successful
  - Can we at least continue to track protein?
  - Can we at least continue to push training?
  - Can we at least continue to minimize alcohol consumption?

More about alcohol

- Empirically, as much as these drugs suppress appetite, they don’t seem to do it much for alcohol
- You can drink your way through these drugs. And then you’re adding another layer of downside
- They’re losing weight and they’re getting a greater proportion of their calories from ethanol—so now they’re actually losing nutrients as well
- Related info: people who get bariatric surgery tend to keep the weight off well, however, for those that don’t it’s typically due to drinking calories (alcohol or sugary drinks)

## The large financial cost of this class of drugs [1:08:30]

Peter is super-frustrated about the costs of the US healthcare system— “*One of the things that still just makes me sick to my stomach is the price gouging that goes on here*”

- The annual cost of Wegovy is $16,000
- Now you might say, “Well, hey, but if I’m obese and I qualify for it, I don’t have to pay for it.”
- “Yeah, that’s true, but society’s paying for it. Make no mistake about it. Somebody is paying $16,000 a year for Wegovy”
- What does a gastric bypass cost?
  - About $24,000 and you only get that done once
- Peter says “I find it a little bit confusing why people are so excited about these drugs if you have any semblance of concern for the state of healthcare, because I don’t see the scenario under which we’re going to spend $16,000 a year in perpetuity on a drug when in fact we have a surgery that’s more effective at basically time and a half the cost of the drug for one annual charge.”
- Of course surgery comes with far more risks, so it’s not a pure equivalency here
- But given the magnitude of obesity in this country, you’d bankrupt the country doing this
- For a little bit of perspective, the per capita cost of healthcare in every other developed nation in the world is less than $10,000 per year
- And yet we’re talking about a drug that we’re trying to get insurance companies to pay $16,000 a year for to treat obesity
- “*Something doesn’t make sense in that equation to me*.” says Peter

## Metformin as a geroprotective drug: origin of the idea that metformin could be a longevity agent even for non-diabetic patients [1:11:30]

Metformin has been discussed on a number of episodes, a few of them being:

- [Episode #204](https://peterattiamd.com/nirbarzilai2/) with Nir Barzilai
- [AMA #35](https://peterattiamd.com/ama35/) with Matt Kaeberlein

\*\*\*

- Since those conversations, there was kind of a new study that came out which contradicts one of the major pieces of supporting information for metformin’s efficacy and lifespan (discussed below)
- But in this conversation, we’re going to focus on metformin as it relates to the geroprotective side as opposed to the diabetic side
- Ultimately where we’re going to get to is what is Peter’s updated view on how he looks at metformin as a geroprotective drug for himself and for patients who don’t have diabetes

**Background on metformin and why metformin is looked at, by some, as a geroprotective drug**:

- For Peter, he was interested in metformin circa 2010 for insulin sensitivity benefits, a low physiologic cost for improving insulin sensitivity
- In 2014, there was a [paper](https://pubmed.ncbi.nlm.nih.gov/25041462/) that came out that got people really excited and pushed the boundaries of this idea of metformin being truly geroprotective—meaning metformin not as a diabetes drug, but giving metformin to everybody or people who don’t have diabetes within a certain age group perhaps, and talking about how that might extend life

![](https://peterattiamd.com/wp-content/uploads/2023/03/f7-ama45-1024x573.png)

**Figure 7.** Source: [Kulkarni et al. Cell Metab. July 2020](https://www.sciencedirect.com/science/article/pii/S1550413120301832)

- This is a nice schematic that aims to offer sort of a theoretical argument for why metformin touches every element of the nine hallmarks of aging
  - deregulated nutrient sensing, loss of proteostasis, mitochondrial dysfunction, telomere attrition, epigenetic alterations, genomic instability, cellular senescence, stem cell exhaustion and altered intracellular communications
  - As we age, these things all seem to be happening
- Peter has strong feelings on which of these matter the most, which of these matter the least, and he also believes firmly that these are not independent
  - “*It may be a controversial thing to say, I don’t think we should be talking about these nine hallmarks of aging this way because when people talk about them in this way, they almost lend an assumption to them, which is these are nine independent vectors and I really don’t think they are*.”
  - What would be really nice would be to find the eigenvectors of this and talk about what those are

About the figure above:

- The figure show that metformin reduces all nine of hallmarks
  - Metformin reduces insulin signaling
  - Metformin activates AMP kinase, which weekly inhibits mTOR, which reduces AGEs
- You can just go through your pathway after pathway after pathway and lo and behold, all nine of these things are inhibited
- Therefore, based on this figure, “metformin really ought to be in the drinking water” at least for people over the age of about 50

The good news is regardless of everything Peter is about to say, we’re going to get an answer to this one way or the other because fortunately there’s going to be a randomized placebo controlled blinded trial that’s going to answer this question called [TAME](https://www.afar.org/tame-trial)

- “*In some ways all the pontificating I’m about to do is sort of just to hold us over and help people think about this problem until we have kind of a definitive answer*”

[**2014 study**](https://pubmed.ncbi.nlm.nih.gov/25041462/)

*When the study came out, how did you initially think about it and then has that changed or evolve over time?*

- This was a retrospective case control study. *So what does that mean?*
- First to be clear, that’s an observational study, but it’s a study where they really attempt to find controls
- They say, “Look, case control means we’re going to go back and look at cases, but we’re going to do an amazing job of identifying people who match our cases in every way except the variable of interest. And then we’re going to see what happened to them over time.”
- In this situation, they wanted the variable of interest to be the use of metformin and the presence of type 2 diabetes
- So their cases were 78,000 some odd people who had type 2 diabetes who were being treated only with metformin

Subjects:

- 78,000 of Metformin
- 12,000 sulfonylureas
- 90,000 matched controls taking neither of those drugs who also didn’t have type 2 diabetes

They followed these folks for a little under three years and the question then became, *well, what happened?*

![](https://peterattiamd.com/wp-content/uploads/2023/03/f8-ama45-1024x457.png)

**Figure 8.** Source: [Bannister et al. Diabetes Obes Metab. Nov 2014](https://dom-pubs.onlinelibrary.wiley.com/doi/10.1111/dom.12354)

- In the metformin group, there were 2,663 deaths
- In the sulfonylurea group, 1418 deaths
- And in the control group, 2669 deaths
- In the control group matched to these sulfonylureas 748 deaths
- So in the control group, and these were literally the same number of people, there were slightly more deaths, there were six more deaths in the control group than in the metformin group

The crude rate translated to a higher number: *Why?*

- Why? ⇒ Because it was a function of follow up years
  - Every year that one of those patients is followed is a patient year of follow up
  - So if you had 10 patients followed for three years, that’s 30 patient years
  - you can see in this table that even though they picked the exact same number of patients at the beginning, a certain number of them are going to die and you have no control over when they die, but that’s when you stop following them up
- So the variable here that you don’t get to control is not only the death rate or the number of deaths, but the follow-up period
  - so in the Metformin group, you had more follow-up. You had 184,700 follow up years, patient years versus 175,600
  - so the crude event rate was higher in the control group
  - In the control group you had 15,200 person year all cause mortality versus 14.4
  - That got people all excited because if you think about it, how in the world are people who don’t have diabetes, who don’t take Metformin dying at a slightly higher rate than people with diabetes taking metformin
- For people under 60, that turned out to not be the case
  - if you were under 60, the death rate, of course all cause was much lower, but it was slightly higher for metformin than non metformin
  - And if you went over 70, that spread was even greater
  - So the number Peter mentioned earlier, the 14.4 and the 15.2 was all-comers
  - And then you parse it out by age.
- The long and short of it is that is what led to all of the excitement around metformin for longevity

**Peter’s personal experience taking metformin**

- Peter thought this paper was quite compelling — Peter was personally taking metformin from 2010-2018
- As we’ve talked about on another podcasts, including the follow up [podcast](https://peterattiamd.com/nirbarzilai2/) with Nir and the [subsequent podcast](https://peterattiamd.com/ama35/) with Matt, Peter started to see other changes in biomarkers and became less convinced of these data as time went on and therefore decided to stop taking metformin roughly five years ago
- “*We still use metformin occasionally in patients, but I will wait to see the results of TAME before I consider broader use of metformin as a geroprotective agent*.”

## A 2022 study on metformin sheds more light on the question of whether metformin should be used for “geroprotection” in non-diabetics [1:21:00]

Recent study: [Reassessing the evidence of a survival advantage in Type 2 diabetes treated with metformin compared with controls without diabetes: a retrospective cohort study (Keys et al., 2022)](https://academic.oup.com/ije/article-abstract/51/6/1886/6775037?redirectedFrom=fulltext&login=false)

- The Keys study did the same type of analysis, but just picked a totally different cohort
- The 2014 study was a UK cohort. Keys study used a cohort in Denmark
- The Keys study contradicts the findings of banister
  - They found no survival advantage or equalization for diabetics on metformin
- This was a slightly longer follow up
- They also did something very elegant, which is they used same sex twin analysis as well, but here you had a carve out that creates what we would call an even better natural experiment, so to speak

![](https://peterattiamd.com/wp-content/uploads/2023/03/f9-ama45-1024x534.png)

**Figure 9.** Source: [Keys et al.  Int J Epidemiol. Dec 2022](https://academic.oup.com/ije/article-abstract/51/6/1886/6775037?redirectedFrom=fulltext&login=false)

- It’s a very similar analysis to what we saw before but a larger population
- What’s showing is the mortality rate for:
  - The cohort that was taking metformin
  - and for the matched individuals, genetically heterozygous, not with type 2 diabetes and not taking metformin
  - The metformin group here had a much higher mortality rate—25 per thousand person years versus a little under 17 for the matched group
- They also had a separate cohort that they carved out where they compared a group on metformin to a co twin that didn’t take metformin, didn’t have diabetes
  - In the total crude group we’re talking about just under 22 deaths per thousand person years versus 10 deaths per thousand person years
- By the way, it’s worth pointing out here, these data are not surprising, this is exactly what you would expect to see
  - You would absolutely expect to see that the people taking metformin, as beneficial as metformin might be, would have a much higher mortality than people not taking metformin because they’re not diabetic
  - Peter doesn’t find this data especially surprising, but it’s just elegant in that they used a similar analysis but larger, longer and with the twin cohort
- In some ways, this now makes us think that the 2014 Banister analysis was kind of an outlier:
  - 1 – It was very small to begin with in terms of its effect
  - 2 – It’s not intuitive
  - 2 – And there’s been a lot of animal data that disagree with it – most notably the [Interventions Testing Program study](https://peterattiamd.com/richardmiller/) which [did not find](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) that monotherapy of metformin increased lifespan of the mice in that study

Another way to look at these data is to look at the Kaplan-Meier or the survival curves:

![](https://peterattiamd.com/wp-content/uploads/2023/03/f10-ama45-1024x462.png)

**Figure 10.** Source: [Keys et al.  Int J Epidemiol. Dec 2022](https://academic.oup.com/ije/article-abstract/51/6/1886/6775037?redirectedFrom=fulltext&login=false)

- On the left you’re looking at the matched singletons
  - You’re seeing with 95% confidence, the clear difference between those on metformin and those that are not on metformin
  - The lighter ones are those on metformin, the darker ones are not
- Then on the right, you’re seeing the discordant twin group, and again, you’re seeing a very clear and unambiguous difference between these two
- It’s very difficult to make the case here that metformin is geroprotective based on this argument
- All that said, it *could* be that without metformin, those people with diabetes would be dying even more
- In other words, what you really are missing is a third group here, which is people who would be identical in terms of diabetes but not taking metformin
  - “I would expect those people are doing worse off”
  - “So in that sense, I’m sure the metformin is helping the diabetics”
  - But again, the argument that was being made by Banister was it’s really helping because it’s turning diabetics into even healthier people than non-diabetics if they’re taking metformin

## Peter’s current approach with metformin for his patients [1:25:15]

***How are you thinking about and how are you employing metformin clinically as it relates to maybe separating two people, which is those with diabetes looking to control it, and then those without it looking for the geroprotective benefit?***

- Peter does not use metformin in anybody for whom the indication is “geroprotection”
- “*I can’t make a case for that at all, and therefore it doesn’t make sense for me to do that*.”

*What about for pre-diabetic and diabetic patients?*

- He still uses metformin quite liberally in people who are pre-diabetic in whom we’re getting the diabetes benefit or the pre-diabetes or insulin resistance benefit

Trade offs

- Metformin definitely is increasing lactic acid
- When you put a person on metformin, their resting and fasting lactate levels are 2x-3x higher
- And as a result, at least in as much as we believe lactate levels play some role in giving us a proxy for mitochondrial function, it would appear that metformin is suggestive of reduced mitochondrial function
- One of the mechanisms of action is metformin blocks complex I of the electron transport chain so that’s probably not surprising that lactate is going up when you’re using it
- But in the same way that Peter is not excited about the fact that GLP-1 agonists are raising heart rate at night, he doesn’t like that metformin is raising lactate and therefore it becomes a question of cost versus benefit
- In a person with type 2 diabetes that might be worthwhile, especially in a person who’s not able to or willing to exercise much
- If Peter had a patient with T2D who’s willing to change their diet and willing to exercise like crazy, he wold be happy to have them stay off metformin or use metformin for a period of time and then take it off

**Using all the tools for health**

- It’s not that these drugs are good, and it’s not that these drugs are bad — if you’re a physician or a patient who’s looking to use them, you have to have a slightly more sophisticated view of the use case for them and what downside is
- You just don’t want to be in a situation where you’re using something where your upside isn’t significantly higher than your potential downside.
- Again, there’s no drug that compares to exercise
- Peter loves using exogenous molecules whenever he can get an edge from them

“*But to be doing any of those things without utilizing the full force and weight of the capacity of exercise is definitely trading short and leaving a lot of money on the table*”

§

## Selected Links / Related Material

**Previous AMA episode discussing GLP-1 agonists**: [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) | Peter Attia (peterattiamd.com) [3:30]

**Episode of The Drive with Rich Miller where they discussed an SGLT2 inhibitor called canagliflozin**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Peter Attia (peterattiamd.com) [11:30]

**Semaglutide (Ozempic) study from spring of 2021 testing the treatment of obesity in patients without diabetes**: [Once-Weekly Semaglutide in Adults with Overweight or Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183) (Wilding et al., 2021) [18:00]

**Semaglutide (Wegovy) recently approved for kids age 12 and up**: [FDA Approves Weight Loss Drug Wegovy for Teens](https://diatribe.org/fda-approves-weight-loss-drug-wegovy-teens) | Andrew Briskin (diatribe.org) [18:30]

**The study that suggested tirzepatide was superior to semaglutide for weight loss**: [Tirzepatide versus Semaglutide Once Weekly in Patients with Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa2107519) (Frías et al., 2021) [21:45]

**List of semaglutide studies**: [24:15]

- SUSTAIN-1, a phase 3 looking at relatively low dose versus placebo in type 2 diabetes: [Efficacy and safety of once-weekly semaglutide monotherapy versus placebo in patients with type 2 diabetes (SUSTAIN 1): a double-blind, randomised, placebo-controlled, parallel-group, multinational, multicentre phase 3a trial](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(17)30013-X/fulltext) (Sorli et al., 2017)
- SUSTAIN-6, basically the same as SUSTAIN-1 but it was looking at both T2D and CVD: [Semaglutide and Cardiovascular Outcomes in Patients with Type 2 Diabetes](https://pubmed.ncbi.nlm.nih.gov/27633186/) (Marso et al., 2016)
- SUSTAIN-9, a phase 3 dosing 1 milligrams looking at T2D plus SGLT2 inhibitor: [Semaglutide once weekly as add-on to SGLT-2 inhibitor therapy in type 2 diabetes (SUSTAIN 9): a randomised, placebo-controlled trial](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(19)30066-X/fulltext) (Zinman et al., 2019)
- STEP-1, a phase 3 study looking at semaglutide for obesity: [Once-Weekly Semaglutide in Adults with Overweight or Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2032183) (Wilding et al., 2021)
- SUSTAIN-FORTE trial, 1mg vs 2mg for T2D patients: [Efficacy and safety of once-weekly semaglutide 2·0 mg versus 1·0 mg in patients with type 2 diabetes (SUSTAIN FORTE): a double-blind, randomised, phase 3B trial](https://pubmed.ncbi.nlm.nih.gov/34293304/) (Frías et al., 2021)

**List of tirzepatide studies**: [25:15]

- SURPASS-2, patients with type 2 diabetes: [Tirzepatide versus Semaglutide Once Weekly in Patients with Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa2107519) (Frías et al., 2021)
- SURPASS-4, patients with type 2 diabetes: [Purchase Subscribe Save Share Reprints Request Tirzepatide versus insulin glargine in type 2 diabetes and increased cardiovascular risk (SURPASS-4): a randomised, open-label, parallel-group, multicentre, phase 3 trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02188-7/fulltext) (Del Prato et al., 2021)
- SURMOUNT-1, looking at tirzepatide for obesity: [Tirzepatide Once Weekly for the Treatment of Obesity](https://www.nejm.org/doi/full/10.1056/NEJMoa2206038) (Jastreboff et al., 2022)

**Episode of The Drive discussing the challenge of sustaining weight loss**: [#212 – The neuroscience of obesity | Stephan Guyenet, Ph.D.](https://peterattiamd.com/stephanguyenet/) | Peter Attia (peterattiamd.com) [29:00]

**Study looking at whether use of GLP-1 receptor agonists  is associated with increased risk of thyroid cancer**: [GLP-1 Receptor Agonists and the Risk of Thyroid Cancer](https://diabetesjournals.org/care/article-abstract/46/2/384/147888/GLP-1-Receptor-Agonists-and-the-Risk-of-Thyroid?redirectedFrom=fulltext)  (Bezin et al., 2022) [1:01:45]

**Previous episodes of The Drive discussing metformin**: [1:11:30]

- [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](https://peterattiamd.com/joanmannick-nirbarzilai/) | Peter Attia (peterattiamd.com)
- [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) | Peter Attia (peterattiamd.com)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) | Peter Attia (peterattiamd.com)

**The 2014 metformin paper that pushed forward the idea of metformin being geroprotective**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls](https://pubmed.ncbi.nlm.nih.gov/25041462/) (Bannister et al., 2014) [1:12:30]

**First episode of The Drive with Nir Barzilai**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [1:13:15]

**Upcoming metformin study which should provide a definitive answer on whether it is truly geroprotective for non-diabetic people**: [The TAME Trial](https://www.afar.org/tame-trial) | (afar.org) [1:15:15]

**Recent metformin study casts doubts on longevity indications**: [Reassessing the evidence of a survival advantage in Type 2 diabetes treated with metformin compared with controls without diabetes: a retrospective cohort study](https://academic.oup.com/ije/article-abstract/51/6/1886/6775037?redirectedFrom=fulltext&login=false) (Keys et al., 2022) [1:21:00]

**The Interventions Testing Program study did not find that monotherapy of metformin increased lifespan of the mice**: [Longer lifespan in male mice treated with a weakly estrogenic agonist, an antioxidant, an α‐glucosidase inhibitor or a Nrf2‐inducer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) (Strong et al., 2016) [1:24:00]

§

## People Mentioned

- [Rich Miller](https://www.pathology.med.umich.edu/faculty/millerr) [11:30]
- [Stephan Guyenet](https://www.stephanguyenet.com/about-stephan-guyenet/) [29:00]
- [Nir Barzilai](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) [1:11:30]
- [Matt Kaeberlein](https://dlmp.uw.edu/faculty/kaeberlein) [1:11:30]

§