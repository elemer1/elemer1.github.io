# #35 – Nir Barzilai, M.D.: How to tame aging

**Source:** [https://peterattiamd.com/nirbarzilai/](https://peterattiamd.com/nirbarzilai/)

---

##### Check out more content from Nir Barzilai, M.D:

- *(Jan 7, 2019)* [#35 – Nir Barzilai, M.D.: How to tame aging](/nirbarzilai/)
- *(August 10, 2020)* [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](/joanmannick-nirbarzilai/)
- *(April 25, 2022)* [#204 – Centenarians, metformin, and longevity](/nirbarzilai2/)

In this episode, Nir Barzilai, director of the Institute for Aging Research and expert in the genetics of longevity, discusses the evidence that metformin and rapamycin have anti-aging properties and how his TAME study aims to support this hypothesis in humans. Additionally, he describes the role of genetics in lifespan/healthspan and how it might affect important pathways such as IGF and insulin sensitivity.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/nirbarzilai/the_Drive_public.png)

Play

#35 - Nir Barzilai, M.D.: How to tame aging

1x15s30s

0:002:47:30

## We discuss:

- Nir’s background and interest in aging and endocrinology [3:30];
- History of metformin, and understanding the mechanism [11:15];
- Attempting to define insulin resistance [21:15];
- Metformin as a possible anti-aging drug [48:45];
- The TAME trial: Targeting Aging with metformin [57:45];
- Why Nir believes metformin can slow aging [1:16:30];
- The genetic gift of centenarians [1:28:00];
- IGF/GH and its impact on aging and chronic diseases [1:34:15];
- Genetics/epigenetics of centenarians, gene sequencing, CETP-VV, Lp(a) [1:49:15];
- Should you be taking HGH? [2:05:30];
- NAD and NAD precursors (NR and [NMN](/does-nmn-improve-metabolic-health-in-humans/)) [2:30:00];
- Parting thoughts on metformin [2:36:15];
- Possible blind spots in Nir and Peter’s thinking? [2:43:00]; and
- More.

§

## Show Notes

## Nir’s background and interest in aging and endocrinology [3:30]

- Grew up in Israel, served in military
- Nurse and med student at Hadassah Hospital before coming to US
- Started looking at mechanism of action for metformin back in 1987
- Became interested in aging at age 13 when looking at his 68 year old grandfather who looked too old for his age
- Always interested in how old a person appeared compared to their actual age
- Changing hormones seemed to play a role in aging so Nir decided to focus on endocrinology

Criticisms of the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative)

- From a hormone (estrogen) replacement perspective, the study was a failure for many reasons
- Estrogen supplements have different effects depending on the age of the person as well as the other age-related complications they may have
- Great book that goes through the history of the WHI: [*Estrogen Matters*](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Well-Being/dp/0316481203) by Avrum Bluming and Carol Tavris

## History of metformin, and understanding the mechanism [11:15]

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-02-at-10.21.32-AM.png)

**Figure 1. Metformin Attenuates Biological Hallmarks of Aging.** Image credit: Nir’s TAME presentation

- Metformin used in Europe since ~1950
- What took so long for it to come to the US?
- “Terrible story” … FDA said not sure it would work in US population
- Nir says he’s not sure if it would be approved today as a new drug
- *Why?* “the inability to elucidate the mechanism”
- [Nir’s work](https://www.ncbi.nlm.nih.gov/pubmed/1955512) has shown that metformin targets hepatic glucose production, or the insulin sensitivity of the liver.

Peter asks, “So at the time [1987], was it understood what metformin’s activity was on complex 1 of the mitochondria?”

- “No, not really. . .it came later when the seahorse assay were developed”
- Seahorse assay
  - Allows you to look at some of the effects of drugs that are interfering with mitochondria action, or decrease mitochondrial activity
  - “It’s almost like the [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry) of the mitochondria”

Discovery of metformin

- Comes from a plant, the French Lily
- First discovered in 1922 and was first studied in humans in the 1950s [credit: [wikipedia](https://en.wikipedia.org/wiki/Metformin)]

Metformin and lactic acidosis

- Before metformin, there was Phenformin, a much more potent version and was known to cause lactic acidosis
- Today, there is the stigma with metformin that you have to worry about it causing lactic acidosis
- That said, Peter says he’s never seen a case of it with metformin
- Nir says metformin does, indeed, increase lactic acid but in the normal range (increase possibly due to the metabolic effect when you inhibit complex 1)
- Eventually, it became clear that lactic acidosis was associated with metformin but not necessarily *caused* by metformin which led to the acronym, MALA (metformin-associated lactic acidosis) due to other issues people who were prescribed metformin already had

Two macro strategies to control blood glucose to improve Type 2 diabetes

1. **Increase insulin** either exogenously, or through increased insulin production pharmacologically
2. **Reduce glucose** (i.e. metformin), or increasing muscle insulin sensitivity to enhance glucose disposal

- It’s generally regarded that both strategies will have an equal benefit on the microvasculature (diabetic nephropathy, neuropathy, and retinopathy)
- But the glucose lowering by insulin lowering strategy has a superior effect on the macrovasculature (coronary artery disease, peripheral arterial disease, and stroke)
- Therefore, metformin would be a better alternative to, for example, a drug that’s going to increase insulin production of the pancreas

*⇒ Here’s a helpful explanation of macrovasculature vs microvasculature:* [*Microvascular and Macrovascular Complications of Diabetes*](https://clinical.diabetesjournals.org/content/26/2/77)

Was it appreciated in the late 80s how potentially beneficial metformin could be?

- Bias was that Type 2 diabetes was all about insulin resistance (but we now know it’s a collaboration)
- With that in mind, metformin was a good place to start
- “It affects mainly the hepatic glucose production rather than the muscle, although, I have to tell you, in vitro on muscle specimens, it’s insulin-sensitizing the muscle too.”

## Attempting to define insulin resistance [21:20]

Phenotype of someone with IR

- Elevated glucose
- Some degree of obesity of adiposity (confusing because this means that clearly, their fat cells are NOT resistant to insulin)
- Muscle IS resistant to insulin (meaning the muscle has a hard time uptaking glucose)

Ways we dispose of glucose

- We can do so in both insulin-*dependent* and insulin-*independent*
- Metformin participates in the AMPK-driven, insulin-*independent* modality of glucose disposal
- Liver is most complicated, “What is meant by insulin resistance in the liver?”, asks Peter

**Paradox of insulin resistance:**

A [1997 paper in Science by Gary Ruvkun](https://www.ncbi.nlm.nih.gov/pubmed/9252323) complicated Nir’s understanding of insulin resistance

- Reading this paper “made it the best day and worst day of his life” says Nir
- The *Science* paper showed that if you made a worm less insulin sensitive (aka more insulin resistant), it would accumulate visceral fat and it would live longer
- This was contrary to Nir’s belief, and what his work in rats was showing

Nir’s 2 experiments in rats with results that contradicted the 1997 paper in Science

⇒ First experiment: [Surgical removal of visceral fat reverses hepatic insulin resistance](https://www.ncbi.nlm.nih.gov/pubmed/9892227).

- 150 rats, all of which had surgery after puberty
  - Half of them had their visceral fat removed
  - Other half had a [sham surgery](https://en.wikipedia.org/wiki/Sham_surgery)
- The rats were then separated into 3 groups
  - Group 1: Rats with sham surgery got fed ad libitum
  - Group 2: Rats with sham surgery had their calories restricted
  - Group 3: Rats with visceral fat removed were fed ad libitum
- Results:
  - Group 2 lived 40% longer than Group 1. Group 3 lived 20% longer than Group 1
  - There was also an increase in healthspan in Groups 2 and 3.
  - In other words, it was clear that the *removal of visceral fat was beneficial*, all things equal, and that *caloric restriction was found to be the most beneficial* in terms of lifespan in rats.
- Other findings:
  - Visceral fat never came back in the rats who had it removed
  - All rats who had visceral fat removed died from kidney disease and/or cancer

⇒ Second experiment, [Nir’s Zucker rat experiment](https://www.ncbi.nlm.nih.gov/pubmed/12351432)

- Zucker rats are very obese and have a condition called hyperphagia, meaning they can’t stop eating, due to the lack of a leptin receptor
- The relevant finding in this experiment was that when you remove the visceral fat from Zucker rats they do not get diabetes, however, Zucker rats regrew 80% of their visceral fat and then they would succumb to diabetes
- For more on Zucker rats and leptin, see a previous episode of [The Drive with Rudy Leibel](https://peterattiamd.com/rudyleibel/)

**The apparent paradox**: The Science paper showed that nematodes [worms] with the insulin-resistant, visceral fat live longer. But Nir showed that mammalians live longer if you surgically remove the visceral fat and make them insulin sensitive.

How Nir made sense of this paradox:

- - Only so much glucose can be stored in the muscle so the muscle becomes IR as a protective mechanism, and so the excess glucose goes to the liver (because it at least has the capacity to turn glucose into fat) and to the fat cells
- *“So what am I telling you? I’m saying that insulin resistance is a protective mechanism. It’s a modulator, it’s a stress response. . .So now, I understand why a stress response mechanism in one animal causes them to live longer and in another animal, it’s a pain in the butt.”*
- Nir wrote a [review](https://academic.oup.com/biomedgerontology/article/67/12/1329/606523) with [Luigi Ferrucci](https://irp.nih.gov/pi/luigi-ferrucci) looking at all the animals with IR who live longer, and all the animals who were IS but lived shorter, that tries to explain this paradox

Making sense of the term “insulin resistance”

- Peter asks Nir what he means when he says insulin resistant/insulin sensitive
- Always referring to the muscle? Are you referring to the liver?
- Generally, he’s referring to everything, [IRS1](https://en.wikipedia.org/wiki/IRS1) (insulin receptor substrate) and [IRS2](https://en.wikipedia.org/wiki/IRS2)
- IRS1 and IRS2 are everywhere, but IRS2 is more in the liver and brain

**How does the muscle take in glucose?**

*Peter’s hypothetical*: A person gets a bolus of glucose which doubles blood glucose from 90 to 180 mg/dl, what is the chain of events that leads to insulin being secreted, and the *muscle* ultimately disposing of that glucose, both actively or passively?

- Secretion of insulin relative to the glucose bolus
- The [GLUT4 transporter](https://en.wikipedia.org/wiki/GLUT4) is moved from an intracellular pool to the plasma membrane
- The GLUT4 transporter then tells the cell to uptake glucose
- This happens quite passively meaning it doesn’t require ATP to bring it in was the translocation has occurred
- And it has its own intrinsic activity that’s not yet energy dependent, so it can go faster or slower by different ways

Can we get glucose into muscle *without insulin*?

⇒ Exercise enhances non-insulin glucose uptake

- Peter has a fascinating patient with Type 1 diabetes
  - Incredibly strict diet and a huge appetite for exercise
  - “Never seen a higher level [adiponectin](https://en.wikipedia.org/wiki/Adiponectin) or [sex-hormone binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)”
  - He only injects 6-8 units of insulin (very little)
  - Yet his [hemoglobin A1C](https://www.webmd.com/diabetes/guide/glycated-hemoglobin-test-hba1c) is below 6 (very low)

⇒ Brain can take over the whole insulin process

- “We can do things to the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus) and take over this insulin and muscle and fat and liver, we can do it all from the brain.”
- Note: one of the main functions of the hypothalamus is to link the nervous system to the endocrine system via the pituitary system
- The liver provides another example. . .
- You can do a [hepatic vagotomy](https://en.wikipedia.org/wiki/Vagotomy), which means you are severing the nerve that connects the CNS with the periphery,  and everything that you did through the brain doesn’t work anymore because it needs the nerves . . . “it’s through the nerves and not through a chemical reaction on the liver”
- Peter laments, “You see, this is the problem with metabolism, Nir. The more I go into it, the less I know. It drives me nuts. My absolute knowledge increases incrementally and my relative knowledge falls precipitously.”

**Attempting to define insulin resistance**

- Peter defines IR in the muscle: “So we will define insulin resistance at the muscle, whether it be from an aged phenotype or a diabetic phenotype, as a scenario under which a fixed amount of insulin hitting the insulin receptor produces fewer GLUT4 transporters, is that a fair definition?”
- Nir rebuts by explaining that the simple, clinical definition of IR is all about the ability of insulin to clear glucose, but admits that it “totally misses the point because those insulin levels have different effects on different tissue”

*The following is a hypothetical example comparing two patient’s response to an oral glucose tolerance test. . .*

Peter’s OGTT protocol with his patients

- Takes baseline glucose and insulin levels
- Gives patient 75 g of Glucola
- Measures glucose and insulin (and FFA and c-peptide) at 30, 90, 60, 120 minutes

Hypothetical, let’s say they both start with 90 mg/dl of glucose and insulin of 6 IU

- Both at 1 hour have a rise in glucose from 90 to 130
- But one of them did it with a rise in insulin from 6 to 20
- And the other one with a rise of 6 to 90

Would Nir describe them at both as equally insulin sensitive?

- “It’s complicated. . .the rise in insulin is changing throughout normally physiology and throughout individuals. And you might’ve missed some of the insulin peaks earlier on, or later on.”
- Peter’s hypothesis in this hypothetical is that the one who needed 90 units of insulin to dispose of glucose with the same efficacy as the person who needed 30, is sooner, rather than later, going to have a harder time disposing of glucose
- Nir says that there’s another possibility:
  - It’s possible that the people who are more insulin sensitive will be first to get other macrovascular diseases, like heart attacks or stroke
  - So the IR people may get diabetes first, but the insulin sensitive people may get macrovascular diseases first
- Peter says, “Which brings it right back to the observation of glucose versus insulin, [micro versus macrovasculature](https://clinical.diabetesjournals.org/content/26/2/77)…”

**How does insulin signaling work to get glucose into the liver?**

- Liver uses GLUT2 to get glucose into liver
- This transporter is always on the membrane and it doesn’t require insulin to move it there
- Important in evolution because if the liver is denied glucose you only have a few minutes to live
- Nir says that the main role of the liver is to produce glucose
- “That would be my answer, too,” says Peter
- But this is further complicated when you consider the following example:
  - Elderly people in certain cases have enough insulin to suppress glucose production, but not enough insulin to increase glucose uptake
  - So when you look at baseline glucose, they will look healthy
  - But when they are fed, they fail and become glucose intolerant and diabetic
  - And this is because the liver is more sensitive to insulin than the muscle.

## Metformin as a possible anti-aging drug [48:45]

**When did Nir first realize metformin could be an anti-aging drug?**

[Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3006019/) by [Vladimir N Anisimov](https://www.omicsonline.org/editor-profile/Vladimir_Anisimov/) showing an increase in lifespan and healthspan with metformin in animals

- Anisimov also showed that there’s a significant effect on insulin (10% effect in animals, rapamycin has a 24% effect by comparison)
- So there’s a milder effect than rapamycin, but in every study, they show that healthspan is improved by 50% (so the effect on longevity was less than the effect on health)
- Three studies that gave it also to nematodes and they also lived longer

**The moment that Nir knew he had to do a study of his own (his TAME study):**

After reading this [U.K. study Bannister et al. in Diabetes, Obesity and Metabolism from 2014](https://www.ncbi.nlm.nih.gov/pubmed/25041462)

- Compared 78,000 newly-diagnosed, diabetic people on metformin to 78,000 people non-diabetic people not taking metformin
- The diabetic patients on metformin were more obese than the control
- They also had more disease than the control
- But there was **17% less mortality in the metformin group**
- “When you get less mortality with metformin when the setup is diabetes, that really shows that metformin has a very important effect in humans as far as aging”
- Peter says, “that’s a pretty god damn staggering result”

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-02-at-10.08.22-AM.png)

**Figure 2. Metformin associated with reduced mortality in T2DM compared with non-diabetics.** Image credit: Nir’s TAME presentation

Peter’s aha moment with metformin

- A research project with 2 analysts that looked at the question: Is there a relationship between hyperinsulinemia and breast cancer?
- The research showed that people taking metformin (whether they had diabetes or not) got much less cancer
- Nir agrees and points out that hundreds of studies show the association between metformin and less cancer, *except prostate cancer* ⇒ See this [Meta-analysis looking at metformin and cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4154969/)

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-02-at-10.03.59-AM.png)

**Figure 3. Metformin and cancer risk.** Image credit: Nir’s TAME presentation

## The TAME trial: Targeting Aging with MEtformin [57:45]

[**TAME**](https://www.afar.org/natgeo/) **stands for Targeting Aging with Metformin**

*Goal of the study*: To prove the concept that aging can be targeted which hopefully will lead to the FDA giving approval to an indication for aging

Peter wonders why the study focuses on metformin instead of [rapamycin](https://en.wikipedia.org/wiki/Sirolimus):

- Nir says that metformin has a lot of preliminary data showing some ability to prevent cancer, diabetes, heart disease and dementia
- With rapamycin, there is less data, and there is some safety concerns like diabetes causing, and cataracts, etc.
- Peter points out that the safety concerns with rapamycin is only with constitutive dosing
- “So my view on rapamycin is it should not be dosed every day. It should be selectively dosed to target complex 1 [[mTORC1](https://en.wikipedia.org/wiki/MTORC1)], leave complex 2 [[mTORC2](https://en.wikipedia.org/wiki/MTORC2)] alone.” says Peter

**Nir and his TAME study was featured on an [episode of Ron Howard’s show, BREAKTHROUGH, called The Age of Aging](https://www.einstein.yu.edu/news/releases/1132/nir-barzilai-featured-in-breakthrough-a-new-series-on-the-national-geographic-channel/)**

**Challenges of getting TAME started [1:01:00]**

The FDA’s lack of interest in diabetes

- Nir approached them about a study to determine metformin’s effect on cardiovascular disease, cancer, Alzheimer’s, and diabetes
- But FDA said they’re not interested in diabetes
- Peter is stunned, and says that the FDA is taking a short view of diabetes, “The short-term cost burden of diabetes is relatively trivial, but it’s that long-term cost burden that becomes quite elaborate.”

So the major challenge is: *How do we define aging in a clinical study?*

- No biomarkers, and with all the diseases the major risk is aging
- We’re all going to succumb to chronic disease, our genetics and environment will just determine *which one we get first*
- We age biologically in different ways so we don’t know what the next disease an individual is going to get, but the point is that they are trying to prevent that next disease

Bias against [composite outcomes](https://www.ncbi.nlm.nih.gov/pubmed/12759327)

- Nir says, “I’m agnostic. It doesn’t matter what you come and what you’re going to have, I’m going to prevent whatever it is. That’s why we have a composite.”
- Peter rants: “This pisses me off to no end when people get all bent out of shape about how you can’t have a composite outcome. And this is the bias against aging, really. Because in the end, what matters is how long are you alive, and how long is your healthspan optimized.”

The NIH wants Nir to study the chronic diseases separately

- NIH thinks Nir is crazy to think that one drug can target aging
- Their main concern seems to be cancer
- They suggest that Nir do three studies looking at cardiovascular, cancer, and dementia separately
- But Nir takes issue with that approach, “The significance is for the cluster [of diseases], not for the individual disease, and if you tell me to do individual disease, I need triple the budgets, and I’m not going to get to the FDA with the indication for aging.”
- Peter says, “The biggest challenge here is not the funding. It’s not the study design, it’s the conceptual leap. It’s a completely different paradigm of how we think about delaying death.”

**Where does the TAME study stand today? [1:09:28]**

Nir’s team asked themselves the question: *What do we have to do to open the field for aging to allow us to get to treatments?* They decided several things, but one of them is to go ahead with TAME.

- Need 70 million dollars for study, but [NIA](https://en.wikipedia.org/wiki/National_Institute_on_Aging) is too small for all that
- But Nir is going to raise half of it through [AFAR](https://www.afar.org/)
- Has approached NCI, NHLBI, NIDDK about helping with funding and it seems promising

**Details of the TAME study**

- Could start enrolling in early 2019
- 14 centers in the US, all ready to go
- 3000 subjects
- Age 65-80
- Nobody with active cancer (but okay if they are in remission)
- ~ Five-year study
- Randomized one to one
- Placebo vs metformin (1,500 mg)
- Peter points out that his first reaction is that Nir would need an N > 1,500 because of the non-linearity and complexity of estimating power
- What percent power are you using?
- 90 percent
- For every disease, they have almost a 30% effect in the preliminary data, but they chose 22% effect
- Peter says, “So you’ve got a buffer, both on your power and effect size”
- Nir: “And again, we don’t want to stop this study early either for one effect. So we carefully thought about it. We asked for a grant for six years because we don’t want to overdo it. So it might finish in four or in six, but we have the flexibility to look at that.”

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-02-at-10.16.31-AM.png)

**Figure 4. TAME study criteria and outcomes.** Image credit: Nir’s TAME presentation

## Why Nir believes metformin can slow aging [1:16:30]

Why does Nir believe, at the cellular, mechanistic level, metformin is an anti-aging drug?

- Metformin seems to fix the aging on a cellular level so the cells are younger
- So then a lot of things start correcting themselves
- In the end, the lower insulin levels, the lower inflammation are not necessarily a direct effect
- So that’s why we’re fighting all the time about what metformin is doing because you can measure lots of things, but the things you are measuring are because aging was fixed

Peter’s take:

- - Metformin is almost like an amazing “B-student”
  - *Are there better ways to inhibit ROS if you want to hammer the ROS chain?* Probably.
  - There’s clearly better ways to inhibit mTOR if that’s all you want to do
  - *Are there better ways to modulate* [*HDAC*](https://en.wikipedia.org/wiki/Histone_deacetylase)*?* Yes
- *“. . .part of metformin’s beauty is that it does so many things at a B-plus level, it’s never an A-student, but it’s not D-student. . .it seems to do so many things reasonably well.”*

## The genetic gift of centenarians [1:28:00]

*“Their genetic gift was a phase shift in when they got chronic diseases. They still died of heart disease. They still died of cancer. They still died of Alzheimer’s disease. They simply got a 20-year bonus”*

- It’s not that centenarians don’t get the same diseases we all get, it’s just that they get them 20 to 30 years later
- Additionally, they live healthier for longer, and when they die, they die much quicker (i.e. compression of morbidity)
- This is despite the fact that they actually engage in the same, if not more, harmful behaviors (i.e. smoking) as the general public

The Longevity Dividend

- CDC, the Center for Disease Control, have looked at the last two years cost of life and found that the cost of dying after 100 was a third of that of dying at 70
- “What will happen to society if we will actually be healthier for two and a half years? The benefits are immense. . .there are several trillions of dollars just in saving of medical cost if you could just live healthier.”
- Note: Nir was just awarded the [IPSEN Longevity Prize](https://academic.oup.com/innovateage/article/2/suppl_1/759/5170507) partially for his work in centenarians

Nir’s LonGenity Study

- [LonGenity](https://www.einstein.yu.edu/centers/aging/research/longenity-longevity-genes-projects/longenity.aspx) is a longitudinal study of 1400 subjects, half offspring of parents with exceptional longevity, validating and following their aging in relationship to their genome [credit: [einstein.edu](https://www.einstein.yu.edu/faculty/484/nir-barzilai/)]
- 10 years into the study and the offspring of centenarians are aging slower
- Nir says it’s better to study offspring of centenarians rather than the centenarians themselves because you don’t know if their phenotype is what protected them or if it is a marker of their impending death (since statistically, they will die within a couple years)

## IGF/GH and its impact on aging and chronic diseases [1:34:15]

What are the most important genetic differences between centenarians and the rest of us?

- Growth Hormone/IGF Axis, says Nir
- More than 60% of centenarians have genomic differences that affect IGF

A quick primer on the typical GH/IGF pathway

- So the pituitary gland makes GH
- It tells the liver, primarily, to make IGF
- Some of the effects of the growth hormone system are through GH itself, and
- Some of it is through IGF-1 level
- Both of them are *decreasing* with aging

The human data is really confusing

- Data appears to show that when you have a high IGF…
- you have more cancers
- but you have less cognitive issues like Alzheimer’s disease
- less heart disease
- less diabetes
- Peter says there is a U-shaped, all-mortality curve with a nadir being between 60th and 80th percentile of all-cause mortality

![](https://peterattiamd.com/wp-content/uploads/2019/01/u-shape-IGF.png)

**Figure 5. Predicted HR for the association between IGF-I and all-cause mortality.** Image credit: [Meta-analysis and dose-response metaregression: circulating insulin-like growth factor I (IGF-I) and mortality (Burgers et al., 2011)](https://academic.oup.com/jcem/article/96/9/2912/2834729) [Burgers et al., 2011]

![](https://peterattiamd.com/wp-content/uploads/2019/01/A.png)

**Figure 6. Relationship between serum IGF-1 levels and risk of (A) all-cause mortality (B) cancer mortality and (C) cardiovascular disease (CVD) mortality.** Image credit: [Both Low and High Serum IGF-I Levels Associate with Cancer Mortality in Older Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4258605/) (Svensson et al., 2012)

The problem with the “low IGF is good” association

- On one hand, an individual that ages quickly, their GH/IGF goes down quickly
- So you would measure falsely low IGF-1 level
- But that wouldn’t fit our theory that low IGF is good because that’s just a byproduct of their accelerated aging

The male/female disconnect with IGF

- In Nir’s experiments, those with the lowest IGF-1 level live twice as long, but **only women**
- Men do not
- In every example, there’s a sex difference
- The GH/IGF is very sensitive for females
- Also showed that those women with the lowest IGF-1 level have a third of the cognitive deficiencies of those with the highest IGF

But is low IGF-1 bad for muscles?

- One of the worries about low GH and IGF is the effect on the muscle because people think that GH affects muscle function, muscle size
- Nir found that in females and males, the IGF-1 level is *not* associated with better or worse function
- So perhaps the effect of low IGF in aging are just as good as having a higher effect of IGF on muscle
- “It just weighs itself out”

**Mutations at the IGF receptor**

- Nir found clusters of mutations at the IGF reception in several centenarians, and that was proof of concept that the GH/IGF axis could be relevant to human aging
- They were resistant to IGF, so their level was a little bit higher, but they were significantly shorter than others (example, Laron Dwarfs)

⇒ Laron Dwarfs

- How can someone be short stature with high IGF? ⇒ the IGF isn’t as effective at the receptor
- Most people with low IGF have less age-related diseases
- Valter Longo studied Laron Dwarfs and found they have significantly less cancer and less diabetes: [Growth Hormone Receptor Deficiency is Associated With a Major Reduction in Pro-aging Signaling, Cancer and Diabetes in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/) (Guevara-Aguirre et al., 2011)
- Defect is in the GH receptor
- They make a normal amount of growth hormone, but their liver doesn’t acknowledge it meaning they have lots of growth hormone but it’s not being expressed through the liver into IGF

⇒ Exon 3 deletion

*Nir published a paper that “took us 10 years to write”:* [The GH receptor exon 3 deletion is a marker of male-specific exceptional longevity associated with increased GH sensitivity and taller stature](https://advances.sciencemag.org/content/3/6/e1602025) (Ben-Avraham et al., 2017)

- 3-4% of the general population has a mutation where they have a complete deletion of [exon 3](https://en.wikipedia.org/wiki/Exon) in the growth hormone receptor, but it is 12% in centenarians
- So they had lower than normal IGF
- But they had a normal height, which is odd, so Nir thought “I cannot do anything with this study. It makes no sense. I don’t know how to write it.”
- After almost 10 years, they replicated the data in centenarians three populations (Amish, French, United States) and all the people that lived the longest had much more of those homozygotes in the growth hormone receptor
- They then took [lymphoblasts](https://en.wikipedia.org/wiki/Lymphoblast) and incubated them in high GH and found that something changed in the activation and it went from low activation and jumped to high activation
- This suggests that in the presence of high GH (i.e. puberty) they would have grown to their normal height but when they got older the receptor shut off for the rest of their life

## Genetics/epigenetics of centenarians, gene sequencing, CETP-VV, Lp(a) [1:49:15]

Overexpression of [microRNA](https://en.wikipedia.org/wiki/MicroRNA)

- 30% of centenarians in Nir’s studies have clusters of microRNA that are overexpressed by 40 times
- For example, [microRNA 142](https://www.ncbi.nlm.nih.gov/gene/406934), that’s increased by 35 fold when you incubate it with cells, it prevents the phosphorylation of the IGF receptor and decreases some other signaling as well
- So there’s a microRNA targeting of the growth hormone IGF receptor in about 30% of our centenarians

[FOXO3A](https://en.wikipedia.org/wiki/FOXO3)

- Then 22% of our centenarians have a mutation in FOXO3A, a very important transcription factor at regulating cellular homeostasis
- This is one of *the most prevalent* mutation in centenarians

Difficulty in interpreting gene sequences

- Trying to interpret things is nearly impossible given how multifactorial these issues are
- We have 20,000 genes and only a handful have a deterministic relationship with a disease
- And even if you have some of the “bad” ones, it doesn’t always mean you’re doomed
- Do centenarians have “perfect” genomes? ⇒ not exactly
  - Many of them have mutations that should cause diseases but none actually had any of the expected diseases in Nir’s studies
  - Example, some centenarians had [APOE4](https://en.wikipedia.org/wiki/Apolipoprotein_E), textbook says they should be demented by 70, and dead at 80
- Nir actually did gene sequencing of 44 centenarians to see if they all had “perfect genomes”: [Disease variants in genomes of 44 centenarians](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4190879/) (Yun Freudenberg-Hua et al., 2014)

**High Lp(a) in centenarians**

Lp(a) actually increases in centenarians (which would be a bad thing in the gen. pop)

Peter says, “This is the most confusing of them all, because I don’t see any compelling evidence that Lp(a) is anything other than atherogenic. And so it begs the question, why would it concentrate in centenarians as opposed to just rise commensurate with the population?”

- We show cross-sectionally that Lp(a) drops until the age of 80 (by half)
- “It’s killing you, until it’s not”
- It should be flat, so why is it increasing? ⇒ “Because it’s a protected aging gene”

CETP VV mutation

- Most of the people with high Lp(a) that are centenarians are also CETP VV mutations
- What does the lipid panel look like for someone who is CETP VV plus or minus LP(a)?
  - Higher HDL levels
  - Larger lipoprotein particle size
  - And they have lower CETP levels (Low CETP has been protective against several age-related diseases, the most dramatic is cognitive decline)
- Prevalence of the CETP VV mutation: At 55 [years old] it’s 8% of the population and at 100 it’s 20% of the population

Different Lp(a) phenotypes? ⇒ Peter’s hypothesis

- Peter asks, “Why wouldn’t Lp(a) flatline after age 80? In other words, I understand why CETP VV is protective. I don’t understand why Lp(a) should concentrate.”
- Perhaps there are different phenotypes of the Lp(a)
- Most people with high Lp(a) die of premature heart disease, but a significant number do not
- This makes Peter wonder, “are there virulent and nonvirulent phenotypes that at the level of expression by number, or molecular weight, that are not captured?”
- If so, the next question becomes…
- “Is the nonvirulent one the one that is concentrating in the centenarians?”
- If so, we should understand the Lp(a) phenotype in centenarians so that we can better risk-stratify the rest of the population
- 10% of the general population has elevated Lp(a), “but we don’t know how aggressively to treat them”

## Should you be taking HGH? [2:05:30]

Peter is often asked by patients, “Should I be on growth hormone?”

- His answer is “I don’t think so, but if I’m gonna be brutally honest, I really don’t know.”
- Because the clinical data certainly don’t give us the answer
- So the epidemiology, if you’re in [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo)’s camp, says taking GH would be the worst thing you could ever do because “growth hormone is bad because IGF is bad.”

how can you manipulate IGF?

- Manipulate growth hormone exogenously,
- manipulate IGF dietarily predominantly through amino acids,
- and manipulate insulin to indirectly impair or enhance IGF binding proteins.

Nir just [published a paper](https://www.nature.com/articles/s41467-018-04805-5) in *Nature* a month ago

Nir’s been trying to develop antibodies against the IGF receptor (IGF-1R) because IGF-1R is expressed in many cancers

**Nir’s hypothesis about IGF: you need to decrease IGF action in the periphery, but increase it in the brain**

Nir did a longevity study:

- Gave the IGF-1R antibody to 22-month-old female mice that are 70, 75 years of age equivalent
- They increased their health span dramatically and increased their lifespan by 9%

**Male and female difference**: “The interesting thing between male and female, the difference, is that the female mice that were treated with the IGF receptor antibody had a lot of inflammatory markers when we started. They were 22 months. And those inflammatory markers were really decreased with aging. In males, we had a little bit more inflammatory markers, but they increased with the IGF treatment.”

**Nir’s final take on giving GH to patients**: “So I’m telling you from human studies, from genetic studies, I’m telling you growth hormone treatment is not beneficial. It should be dangerous for elderly people. For elderly women. With men, I’m ready to say that I’m not sure. It’s not that I’ve shown that low IGF or growth hormone is better in males. Not in my rodent studies and not in my human studies. But it’s hard to say that giving growth hormone is bad.

Peter thinks the most obvious way to manipulate IGF is through fasting

About once a quarter, doing a one-week water-only fast:

- Peter goes from about 180-200 at baseline
- At the end of the fast, it’s 80-90
- Six weeks later, it’s 140-150
- A cyclic approach may be better than a chronic calorically restricted approach

The CALERIE study appeared to show that CR didn’t decrease IGF levels

- Nir also realized that in his rats, he was actually intermittently fasting them because the rats would eat all of their allotted food
- So they would eat every 23 hours
- In the CALERIE study, human subjects ate throughout the day and didn’t have any large periods of fasting

Back to metformin:

Nir’s [small clinical study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5847877/) trying to tie the animal data to the biology of humans

- They studied 14 ~70-year-olds in a randomized, double-blind, placebo-controlled, crossover trial where they were treated with metformin and placebo for six weeks each
- Metformin lowered 2‐hour glucose, insulin AUC, and insulin secretion compared to placebo
- 647 genes were differentially expressed in muscle and 146 genes were differentially expressed in adipose tissue

“While each tissue had a signature reflecting its own function, we identified a cascade of predictive upstream transcriptional regulators, including mTORC1, MYC, TNF, TGFß1, and miRNA‐29b that may explain tissue‐specific transcriptomic changes in response to metformin treatment. This study provides the first evidence that, in older adults, metformin has metabolic and nonmetabolic effects linked to aging. These data can inform the development of biomarkers for the effects of metformin, and potentially other drugs, on key aging pathways.”

## NAD and NAD precursors (NR and NMN) [2:30:00]

What is your belief that orally administered [nicotinamide riboside](https://en.wikipedia.org/wiki/Nicotinamide_riboside) (NR), which is a precursor to [nicotinamide adenine dinucleotide](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (NAD+), can actually make it into a cell?

- [Josh Rabinowitz’s paper](https://www.ncbi.nlm.nih.gov/pubmed/29685734) would suggest, “No, most of this is going to the liver.”
- Nir says it’s unclear but does have personal experience taking NMN (another precursor of NAD similar to NR)

Improvements in sleep?

- Since taking [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide), Nir says his sleep has improved but he doesn’t believe it necessarily because [correlation doesn’t necessarily mean causation](https://peterattiamd.com/nerd-safari/ns002/)
- Nir is measuring sleep with [fitbit](https://www.fitbit.com/), Peter measures sleep with the [Oura Ring](https://ouraring.com/))
- There is also some preliminary data by Shin Imai suggesting that subjects are getting deeper sleep and more REM by taking NAD precursors
- However… “It’s very hard to measure that and without clinical studies that are really well-controlled, I think it’s going to be hard to just support that.”

What about intravenous administration of NAD?

- Peter says also not particularly helpful
- Nir says they need to make a drug that gets into the blood outside the liver
- A study on IV NAD would be much more interesting

For more on NAD see the following episodes of The Drive:

- [David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging (EP.27)](https://peterattiamd.com/davidsinclair/)
- [AMA #3: supplements, women’s health, patient care, and more (EP.26)](https://peterattiamd.com/ama03/)
- [Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more (EP.02)](https://peterattiamd.com/rhondapatrick/)

## Parting thoughts on metformin [2:36:15]

A word of caution:

- Nir recently gave a talk to 300 “laypeople” and he asked the following question: Who here in the audience is non-diabetic and is on metformin?
- Half the people raised their hand
- So the word is getting out about the possible benefits of metformin
- But Nir cautions that they haven’t done the study yet, so it is still possible that they are yet to uncover some safety issues, especially since it hasn’t been studied yet in older individuals

A bright future:

- Nir also recently spoke at the Vatican (and followed a speech by Joe Biden and The Pope)
- During the Pope’s speech, he says “I still hope there’ll be one, little pill, cheap, for everyone in the world that will cure whatever cancer they have.”
- Nir gets up and is like, “Well, there is actually a cheap pill like that and I don’t know if it cures any cancer in the world but it can prevent a lot of the cancers in the world. Actually, it has a side effect that it also can prevent a lot of other diseases in the world.”

*“I think the prevention of aging is really a good place to be and I think because we went from hope to promise and we have to realize the promise. I think life is going to be very different in the next decade with our advances.”*

## Possible blind spots in Nir and Peter’s thinking? [2:43:00]

- There are several interconnected pillars of aging
- When you start to fix or improve any of those pillars, it starts to improve the others as well
- But where they could be wrong is that most of the data is animal data so “we don’t know what is the impact of each of those pathways in humans”
- But the advantage of aging is that it is universal
- When you give metformin or rapamycin to any animal, it almost always delays the aging

*“So I don’t think we’re going to be wrong. . .some [pathways] will be harder to treat, but I think we have to affect three, four and we’re right on our way. . .and that’s just the beginning.”*

§

§

## Selected Links / Related Material

**Nir directs this program at Albert Einstein College of Medicine**: [Institute for Aging Research](https://www.einstein.yu.edu/centers/aging/) | ([einstein.yu.edu](https://einstein.yu.edu/)) [1:00]

**The IAR is one of the nation’s NIA-funded Nathan Shock Centers of Excellence in the Basic Biology of Aging**: [Nathan Shock Center of Excellence and basic biology at Albert Einstein](https://www.nia.nih.gov/research/dab/nathan-shock-centers-excellence) ([nia.nih.gov](https://www.nia.nih.gov/)) [1:00]

**Nir’s project looking to identify longevity genes in centenarians**: [Longevity Genes Project](https://www.einstein.yu.edu/centers/aging/longevity-genes-project/) | ([einstein.yu.edu](https://einstein.yu.edu/)) [1:00]

**Nir’s TAME study, a prospective clinical trial for non-diabetics with respect to aging:** [Targeting Aging with Metformin](https://www.afar.org/natgeo/) | ([afar.org](https://www.afar.org/)) [1:30, 49:00, 57:45, 2:45:00]

**Where Nir did medical residency before coming to the US:** [Hadassah Hospital](https://www.hadassah-med.com/) | ([hadassah-med.com](https://www.hadassah-med.com/)) [4:15]

**Study looking at the effect of hormones on aging**: [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) | ([wikipedia.org](https://www.wikipedia.org/)) [8:45]

**Book that goes over hormone therapy and the WHI**: [Estrogen Matters: Why Taking Hormones in Menopause Can Improve Women’s Well-Being and Lengthen Their Lives — Without Raising the Risk of Breast Cancer](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Well-Being/dp/0316481203) by Avrum Bluming and Carol Tavris | (amazon.com) [11:15]

**Bristol Myers study with metformin as an effective indication for T2D**: [New Phase III Data Showed Dapagliflozin Significantly Reduced HbA1c Compared to Placebo at 24 Weeks in Patients with Type 2 Diabetes Inadequately Controlled with the Combination of Metformin Plus Sulfonylurea](https://news.bms.com/press-release/rd-news/new-phase-iii-data-showed-dapagliflozin-significantly-reduced-hba1c-compared-p) | ([bms.org](https://www.bms.com/)) [12:00]

**Nir’s showed that Metformin targets hepatic glucose production aka the insulin sensitivity of the liver**: [Mechanism of metformin action in obese and lean noninsulin-dependent diabetic subjects.](https://www.ncbi.nlm.nih.gov/pubmed/1955512) (DeFronzo et al., 1991) [13:30]

**A 1997 paper in Science paper that complicated Nir’s understanding of insulin resistance**: [daf-2, an Insulin Receptor-Like Gene That Regulates Longevity and Diapause in Caenorhabditis elegans](https://www.ncbi.nlm.nih.gov/pubmed/9252323) (Kimura et al., 1997) [23:15]

**Cynthia Kenyon’s daf-16 pape**r: [daf-16: An HNF-3/forkhead family member that can function to double the life-span of Caenorhabditis elegans.](https://www.ncbi.nlm.nih.gov/pubmed/9360933) (Lin et al., 1997) [24:15]

**Tom Johnson’s age-1 model with C. elegans**: [25 Years after age-1: Genes, Interventions and the Revolution in Aging Research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3686982/) (Thomas E. Johnson, 2014) [24:15]

**Rats live longer after having their visceral fat removed**: [Surgical removal of visceral fat reverses hepatic insulin resistance.](https://www.ncbi.nlm.nih.gov/pubmed/9892227) (Barzilai et al., 1999) [26:15]

**Nir’s experiment in Zucker rats**: [Removal of visceral fat prevents insulin resistance and glucose intolerance of aging: an adipokine-mediated process?](https://www.ncbi.nlm.nih.gov/pubmed/12351432) (Gabriely et al., 2002) [29:30]

**I wrote this review with Luigi Ferrucci**: [Insulin Resistance and Aging: A Cause or a Protective Response?](https://academic.oup.com/biomedgerontology/article/67/12/1329/606523) (Barzilai and Ferucci, 2012) [33:00]

**There are several studies, three studies, that gave it also to nematodes. They also lived longer. And there’s several effects on health-span in the biology of aging —** ***see***: [Metformin Do we finally have an anti-aging drug?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3906334/) (Anisimov, 2013) [51:30]

**Study that convinced Nir he had to do the TAME study**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls.](https://www.ncbi.nlm.nih.gov/pubmed/25041462) (Bannister et al., 2014) [51:45]

**Meta-Analysis looking at metformin and cancer**: [Metformin and Cancer Risk and Mortality: A Systematic Review and Meta-Analysis taking into account Biases and Confounders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4154969/) (Gandini et al., 2014) [57:15]

**Studies to suggest that in mild cognitive impairment, it improves some domain**: [Metformin in Amnestic Mild Cognitive Impairment: Results of a Pilot Randomized Placebo Controlled Clinical Trial](https://www.ncbi.nlm.nih.gov/pubmed/26890736) (Luchsinger et al., 2016) [59:30]

**Recent rapamycin studies by Joan Mannick**: [1:00:30]

- [TORC1 inhibition enhances immune function and reduces infections in the elderly.](https://www.ncbi.nlm.nih.gov/pubmed/29997249) (Mannick et al., 2018)
- [Short-term Low-Dose mTORC1 Inhibition in Aged Rats Counter-Regulates Age-Related Gene Changes and Blocks Age-Related Kidney Pathology.](https://www.ncbi.nlm.nih.gov/pubmed/29304191) (Shavlakadze et al., 2018)

**Nat Geo documentary series, Breakthrough with Ron Howard, featuring Nir and his TAME study**: [The Age of Aging](https://www.einstein.yu.edu/news/releases/1132/nir-barzilai-featured-in-breakthrough-a-new-series-on-the-national-geographic-channel/)  [1:01:00]

**Rapamycin discussed on a previous episode of The Drive**: [David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity? (EP.09)](https://peterattiamd.com/davidsabatini/) | Peter Attia (peterattiamd.com) [1:20:00]

**Bioavailability of resveratrol discussed on a previous episode of The Drive**: [David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging (EP.27)](https://peterattiamd.com/davidsinclair/) | Peter Attia (peterattiamd.com) [1:25:30]

**Nir wins award for his work in aging and longevity**: [IPSEN Longevity Prize 2018](https://academic.oup.com/innovateage/article/2/suppl_1/759/5170507) | ([academic.oup.com](https://academic.oup.com/journals)) [1:31:15]

**Nir’s LonGenity study on the genetics of longevity by focusing on the offspring of centenarians**: [LonGenity](https://www.einstein.yu.edu/centers/aging/research/longenity-longevity-genes-projects/longenity.aspx) ([einstein.yu.edu](https://einstein.yu.edu/)) [1:33:45]

**Peter’s favorite beverage**: [Topo Chico](https://www.topochicousa.net/) | ([topochicousa.net](https://www.topochicousa.net/)) [1:39:15]

**Laron Dwarfs**: [Growth Hormone Receptor Deficiency is Associated With a Major Reduction in Pro-aging Signaling, Cancer and Diabetes in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/) (Guevara-Aguirre et al., 2011) [1:43:00]

**Published a paper that took us 10 years to write**: [The GH receptor exon 3 deletion is a marker of male-specific exceptional longevity associated with increased GH sensitivity and taller stature](https://advances.sciencemag.org/content/3/6/e1602025) (Ben-Avraham et al., 2017) [1:44:30, 2:06:30]

**So we did several years ago because of funding we did our 44 best first centenarians**: [Disease variants in genomes of 44 centenarians](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4190879/) (Freudenberg-Hua et al., 2014) [1:53:30]

**So what we did, and it’s all published in Computational Biology journals, we took every one of the longevity genes that we have. And we did gene to gene interaction. In other words, we tried to see if there’s interaction between the bad genotype and the good genotype, the good longevity genotype**: [Buffering mechanisms in aging: a systems approach toward uncovering the genetic component of aging](https://www.ncbi.nlm.nih.gov/pubmed/17784782) (Bergman et al., 2007) [1:58:00]

**CETP and its role in reverse cholesterol transport**: [Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins (EP.22)](https://peterattiamd.com/tomdayspring3/) | Peter Attia (peterattiamd.com) [1:59:00]

**Try to develop antibodies against IGF receptor because IGF receptor is expressed in many cancers**: [The GH receptor exon 3 deletion is a marker of male-specific exceptional longevity associated with increased GH sensitivity and taller stature](https://advances.sciencemag.org/content/3/6/e1602025) (Ben-Avraham et al., 2017) [1:44:30, 2:06:30]

**You know about the calorie or the caloric restriction that the NIA funded in three centers by Eric Ravussin**: [A 2-Year Randomized Controlled Trial of Human Caloric Restriction: Feasibility and Effects on Predictors of Health Span and Longevity](https://www.ncbi.nlm.nih.gov/pubmed/26187233) (Ravussin et al., 2015)  [2:17:00]

**Study showing metformin has positive effects on metabolic parameters in humans**: [Metformin regulates metabolic and nonmetabolic pathways in skeletal muscle and subcutaneous adipose tissues of older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5847877/) (Kulkarni et al., 2018) [2:21:45]

**Rabinowitz paper on NAD and getting into the body**: [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.ncbi.nlm.nih.gov/pubmed/29685734) (Liu et al., 2018) [2:30:30]

**Peter’s sleep tracker**: [Oura Ring](https://ouraring.com/) | ([ouraring.com](https://ouraring.com/)) [2:32:30]

*The following links are provided by Nir:*

**From Nir’s presentation about multimorbidity composite**: [Risk of developing multimorbidity across all ages in an historical cohort study: differences by sex and ethnicity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4322195/) (St. Sauver et al., 2015)

**From Nir’s presentation showing that metformin targets biological aging in model systems**: [Metformin improves healthspan and lifespan in mice.](https://www.ncbi.nlm.nih.gov/pubmed/23900241) (Martin-Montalvo et al., 2013)

**One of Nir’ publications from Cell Metabolism that he referenced in his presentation with the fancy chart showing the mechanism of metformin**: [Metformin as a Tool to Target Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5943638/) (Barzilai et al., 2018)

**From Nir’s presentation talking about Aging-relevant genes regulated by metformin in a tissue-specific manner**: [Human Ageing Genomic Resources: Integrated databases and tools for the biology and genetics of ageing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3531213/) (Tacutu et al., 2013)

**Mentioned in Nir’s presentation talking about mitochondrially localized genes enriched within Adipose DEG**: [MitoCarta2.0: an updated inventory of mammalian mitochondrial proteins.](https://www.ncbi.nlm.nih.gov/pubmed/26450961) (Calvo et al., 2016)

§

§

## People Mentioned

- [Ralph DeFronzo](https://gsbs.uthscsa.edu/faculty/ralph-defronzo) (studied metabolism at Yale with Nir) [4:15, 20:00]
- [Steven Austad](https://en.wikipedia.org/wiki/Steven_N._Austad) (important mentor for Peter in the field of aging) [58:00, 1:10:45]
- [Gerald “Jerry” Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (discovering insulin receptor) [20:00]
- [Ron Kahn](https://en.wikipedia.org/wiki/C._Ronald_Kahn)(discovering insulin receptor) [20:00]
- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) (DAF-16) [24:15]
- [Gary Ruvkun](https://en.wikipedia.org/wiki/Gary_Ruvkun) (wrote science paper that complicated Nir’s understanding of insulin resistance) [24:15]
- [Tom Johnson](https://www.colorado.edu/iphy/people/professors/thomas-e-johnson) (age-1 model) [24:15]
- [Luigi Ferrucci](https://irp.nih.gov/pi/luigi-ferrucci) (wrote [review paper](https://academic.oup.com/biomedgerontology/article/67/12/1329/606523) with Nir looking at insulin resistance paradox) [33:30]
- [Joseph Kraft](https://www.amazon.com/Diabetes-Epidemic-You-Joseph-Kraft/dp/1425168094) (pathologist, OGTT and insulin) [43:00]
- [Sheila Sherlock](https://en.wikipedia.org/wiki/Sheila_Sherlock) (hepatologist, Nir interned for her) [46:00]
- [Vladimir N Anisimov](https://www.omicsonline.org/editor-profile/Vladimir_Anisimov/) (did first rodent studies showing life extension with metformin that got Nir interested in metformin) [49:15]
- [Joan Mannick](https://www.restorbio.com/our-team/joan-mannick/) (rapamycin studies) [1:00:30]
- [Ron Howard](https://twitter.com/RealRonHoward?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (directed “Age of Aging” on Nat Geo channel featuring Nir and TAME) [1:01:00]
- [David Sabatini](https://en.wikipedia.org/wiki/David_M._Sabatini) (mTOR, previous guest on The Drive) [1:20:00]
- [David Sinclair](https://twitter.com/davidasinclair?lang=en) (resveratrol, previous guest on The Drive) [1:25:30]
- [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) [1:43:00, 2:21:00]
- [Gil Atzmon](https://www.einstein.yu.edu/faculty/8649/gil-atzmon/) (Nir’s colleague) [1:45:15]
- [Pinchas “Hassy” Cohen](https://gero.usc.edu/faculty/cohen/) (partner in USC) [1:45:15]
- [Yousin Suh](https://www.einstein.yu.edu/faculty/10886/yousin-suh/) (endocrinology and genetics) [1:49:15]
- [Eric Ravussin](https://en.wikipedia.org/wiki/Eric_Ravussin) (caloric restriction) [2:17:00]
- [Ana Maria Cuervo](https://en.wikipedia.org/wiki/Ana_Maria_Cuervo) (autophagy) [2:18:30, 2:21:30, 2:43:30]
- [Satchin Panda](https://twitter.com/satchinpanda?lang=en) [2:20:30]
- [Shin Imai](https://devbio.wustl.edu/faculty/faculty-members/shin-ichiro-imai) (studies NAD precursors) [2:33:30]
- [Lewis Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (says metformin saves more people from cancer than all other cancer drugs combined) [2:36:30]
- [James Watson](https://en.wikipedia.org/wiki/James_Watson) (says metformin saves more people from cancer than all other cancer drugs combined) [2:36:30]
- [Cardinal Ravasi](https://en.wikipedia.org/wiki/Gianfranco_Ravasi) [2:40:30]
- [Pope Francis](https://en.wikipedia.org/wiki/Pope_Francis) [2:41:15]
- [Joe Biden](https://en.wikipedia.org/wiki/Joe_Biden) (cancer initiative) [2:41:15]

§

§

![](https://peterattiamd.com/wp-content/uploads/2019/01/Barzilai_Expertlist-500x500.jpg)

##### Nir Barzilai, M.D.

Dr. Nir Barzilai is the director of the Institute for Aging Research at the Albert Einstein College of Medicine and the Director of the Paul F. Glenn Center for the Biology of Human Aging Research and of the National Institutes of Health’s (NIH) Nathan Shock Centers of Excellence in the Basic Biology of Aging. He is the Ingeborg and Ira Leon Rennert Chair of Aging Research, professor in the Departments of Medicine and Genetics, and member of the Diabetes Research Center and of the Divisions of Endocrinology & Diabetes and Geriatrics. Nir is also the Chief Medical Advisor of LifeBiosciences.

Dr. Barzilai’s research interests are in the biology and genetics of aging. One focuses on the genetic of exceptional longevity, where we hypothesize and demonstrated that centenarians have protective genes, which allows the delay of aging or for the protection against age-related diseases. In a Program he is leading we take full advantage of phenotypes, DNA, and cells from the Ashkenazi Jewish families with exceptional longevity and the appropriate controls and his group have established at Einstein (over 2600 samples of which ~670 are centenarians) and discovered underling genomic differences associated with longevity. Longevity Genes Project (LGP) is a cross-sectional, on-going collection of blood and phenotype from families with centenarian proband. LonGenity is a longitudinal study of 1400 subjects, half offspring of parents with exceptional longevity, validating and following their aging in relationship to their genome. The second direction, for which Dr. Barzilai is holding an NIH Merit award that focuses on the metabolic decline of aging, and his team hypothesize that the brain leads this decline. His lab has identified several central pathways that specifically alter body fat distribution and insulin action and secretion by intraventricular or hypothalamic administration of several peptides that are modulated by aging including: Leptin, IGF-1, IGFBP3 and resveratrol.

He has received numerous grants, among them ones from the National Institute on Aging (NIA), American Federation for Aging Research, the Ellison Medical Foundation and The Glenn Medical foundation. He has published over 230 peer-reviewed papers, reviews, and textbook chapters. He is an advisor to the NIH on several projects and serves on several editorial boards and is a reviewer for numerous other journals. Dr. Barzilai is in the board of the American Federation for Aging Research, is its co-scientific director, and has served on several NIA study section. He is also a founder of CohBar Inc., a biotech that develops mitochondrial derived peptides as therapy for aging and its diseases. He is co-PI on the R24 Geroscience (Apollo) grant that is an effort to move the field of aging to translation. Dr. Barzilai has been the recipient of numerous prestigious awards, including the Beeson Fellow for Aging Research, the Ellison Medical Foundation Senior Scholar in Aging Award, the Paul F. Glenn Foundation Award, the NIA Nathan Shock Award, and the 2010 Irving S. Wright Award of Distinction in Aging Research.

He is currently leading an international effort to approve drugs that can target aging. Targeting Aging with METformin (TAME) is a specific study designed to prove the concept that multi-morbidities of aging can be delayed by metformin, working with the FDA to approve this approach which will serve as a template for future efforts to delay aging and its diseases in humans.

Born in Israel, Dr. Barzilai served as chief medic and physician in the Israel Defense Forces. He graduated from The Ruth and Bruce Rappaport Faculty of Medicine at the Technion-Israel Institute of Technology in Haifa and completed his residency in internal medicine at Hadassah Medical Center in Jerusalem. He served in a refugee camp during the war in Cambodia (1979-1980) and built a nutritional village in the homeland of the Zulu (1983 – Kwazulu). He has completed 2 fellowships at Yale (metabolism) and Corenell (Endocrinoology and molecular Medicine). He was an invited speaker to the 4th Israeli President Conference (2012) and a Vatican conference on efforts to enhance cures (2013, 2016). He has also taken part in Global initiatives and spoke at The Milken Global Institute, Asian Megatrends and is an advisor for the Prime Minister of Singapore on Aging. Dr. Barzilai has been on the ‘Forward 50, top 50 influence Jews in the US (2011). His work has been profiled by major outlets, including the New York Times, the BBC and PBS’ NOVA science now, TEDx talk Science and is the leading feature on the Ron Howard/Jonathan Silberberg/National Geographic film about the Age of Aging. [[einstein.yu.edu](https://www.einstein.yu.edu/faculty/484/nir-barzilai/)]