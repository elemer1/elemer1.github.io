# #370 – AMA #76: Peter evaluates longevity drugs, aspirin for CVD, and strategies to improve muscle mass — proven, promising, fuzzy, noise, or nonsense?

**Source:** [https://peterattiamd.com/ama76/](https://peterattiamd.com/ama76/)

---

In this “Ask Me Anything” (AMA) episode, Peter revisits the “proven, promising, fuzzy, noise, nonsense” scale and applies it to a variety of popular topics. He begins with a refresher on what each category represents before classifying a range of interventions based on the strength of their supporting evidence. The conversation spans three main areas: drugs for geroprotection (including GLP-1 receptor agonists, SGLT2 inhibitors, methylene blue, and telomere-lengthening supplements), the use of low-dose aspirin for cardiovascular disease prevention, and strategies to improve muscle mass through optimal protein intake and follistatin gene therapy. This episode provides a clear, evidence-based overview for listeners seeking to understand where these popular health and longevity interventions stand on the spectrum of scientific credibility.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #76 show notes page](https://peterattiamd.com/ama76). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- A framework for evaluating scientific claims: proven, promising, fuzzy, noise, or nonsense [A: 1:30, V: 0:10];
- Strong convictions, loosely held: the mindset that separates great scientists from the rest [A: 7:30, V: 6:30];
- GLP-1 agonists: are there benefits beyond improving metabolic health and promoting weight loss? [A: 12:45, V: 12:25];
- GLP-1 drugs and the brain: exploring the potential cognitive benefits [A: 18:45, V: 18:55];
- GLP-1 drugs and lifespan: examining the evidence for potential geroprotective effects [A: 23:00, V: 23:45];
- Rapamycin and geroprotection: why it remains in the “promising” category [A: 25:45, V: 26:50];
- SGLT2 inhibitors and their potential geroprotective effect [A: 27:30, V: 28:40];
- Methylene blue: examining the evidence of an anti-aging effect [A: 34:45, V: 37:00];
- Methylene blue’s potential neuroprotective effects: limited and inconsistent evidence in humans, and the challenges of dosing and safety [A: 41:15, V: 43:45];
- Telomeres: what they are, how they relate to aging, and why telomere-lengthening supplements lack credible scientific evidence [A: 43:45, V: 47:26];
- Does the idea of targeting telomere length to extend lifespan have scientific merit? [A: 50:15, V: 54:45];
- Low-dose aspirin for cardiovascular disease prevention: weighing its clot-prevention benefits against bleeding risks across different populations [A: 55:00, V: 1:00:05];
- Rethinking the protein RDA: why most people need twice the recommended amount for muscle health [A: 1:00:45, V: 1:06:40];
- Debunking the protein–cancer myth: why higher protein intake doesn’t promote tumor growth [A: 1:06:15, V: 1:12:40];
- The biology of follistatin and myostatin, and why follistatin gene therapy has become an emerging topic of interest for muscle growth [A: 1:13:15, V: 1:20:50];
- Follistatin gene therapy for muscle growth: state of the evidence in animals and humans, and the technical challenges and regulatory barriers [A: 1:17:00, V: 1:25:05];
- Why injectable follistatin is theoretically possible but impractical for real-world use [A: 1:23:15, V: 1:32:30]; and
- More.

---

The Peter Attia Drive

#370 – AMA #76: Peter evaluates longevity drugs, aspirin for CVD, and strategies to improve muscle mass — proven, promising, fuzzy, noise, or nonsense?

---

## Show Notes


---

## A framework for evaluating scientific claims: proven, promising, fuzzy, noise, or nonsense [A: 1:30, V: 0:10]

**Overview & Structure of the Episode**

- This AMA (Ask Me Anything) departs from typical deep-dive topics.
- Goal: summarize multiple health- and longevity-related interventions through a unified evaluative lens rather than exploring each in isolation.
- Framework: the “Five-Category Scale” — Proven, Promising, Fuzzy, Noise, Nonsense — first introduced in [Episode 300](https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/) (May 2024).
- Purpose:
  - Compare diverse claims apples-to-apples by level of evidentiary support.
  - Give listeners quick, clear takeaways grounded in data strength.
  - Revisit familiar concepts and introduce new ones under this schema.

Topics to Be Evaluated

- Geroprotective / Longevity-Linked Drugs
  - GLP-1 receptor agonists (e.g., Ozempic).
  - SGLT2 inhibitors
- Emerging or Popularized Agents
  - Methylene blue.
  - Telomere-lengthening supplements.
- Preventive Pharmacology
  - Low-dose aspirin and its evidence in cardiovascular-disease prevention.
- Muscle-Preserving / Building Interventions
  - Protein intake optimization.
  - Follistatin gene therapy and other muscle-mass-enhancing concepts.

**The Five-Category Evidence Scale**

- Proven – “As close to truth as biology allows.”
  - Supported by high-quality, consistent data replicated across studies.
  - Comparable to well-established scientific claims.
  - Note: in biology, nothing is ever literally proven (not like math with Q.E.D.).
- Promising –
  - Data trend in a positive direction but may lack replication or completeness.
  - “Looks good but not fully confirmed.”
- Fuzzy –
  - Limited or inconsistent evidence.
  - Some possible signal but weak or incomplete data quality.
- Noise –
  - Essentially no meaningful or reproducible results.
  - Not necessarily dismissible forever — could move up if stronger data emerge.
- Nonsense –
  - Existing data refute the claim.
  - As close to disproven as a biological hypothesis gets.

Key Conceptual Notes

- These categories are fluid; interventions can migrate up or down with new evidence.
- The framework encourages critical thinking and ongoing reevaluation rather than fixed judgments.
- Intended outcome: help listeners allocate attention toward interventions most supported by evidence and away from distraction.

## Strong convictions, loosely held: the mindset that separates great scientists from the rest [A: 7:30, V: 6:30]

**“strong convictions, loosely held”**

- In today’s culture—especially in fields like nutrition—people often anchor themselves to rigid beliefs (“camps”) and resist updating them despite new evidence
- This prompts Peter to elaborate on the idea of having “strong convictions, loosely held”
  - See episode [#103](https://peterattiamd.com/strong-convictions-loosely-held/) and [#202](https://peterattiamd.com/strong-convictions-loosely-held-2/)
- Foundational Principle:
  - “Strong convictions, loosely held” = maintain confidence in well-reasoned positions but stay willing to revise them when credible new evidence arises.
- Attribute of Great Scientists:
  - Great scientists differ from good ones because they are not “married to being right”; they are “married to knowing what is right.”
  - Their allegiance lies with truth, not ego or past beliefs.
  - Willingness to evolve with data is the mark of intellectual integrity.

Origin of the Phrase

- Peter first heard the expression from a friend who managed a hedge fund (now retired).
- The friend applied the principle in investing:
  - You must hold strong convictions to justify putting real capital at risk.
  - But convictions must be loosely held so you can pivot quickly when new information invalidates your thesis.
  - In investing, rigidity is financially fatal—when you double down on wrong positions, you lose money and clients (“LPs”).

Parallel Between Science and Investing

- In Science:
  - Being wrong doesn’t have severe personal consequences (beyond reputation).
  - Many scientists continue defending outdated or disproven ideas for decades—“can’t kill their babies”—making “fools out of themselves.”
  - There’s minimal accountability outside peer ridicule.
- In Investing:
  - Reality enforces humility—bad positions cost real money.
  - “The dollars talk louder than anything else.”
  - This creates built-in feedback and incentivizes updating beliefs rapidly.

Emotional Detachment

- Meaning: Letting go of cherished hypotheses or theories when evidence contradicts them.
- Peter’s Anecdote:
  - When working in a lab setting early-on, he was told “It’s hard to kill your babies,” referring to discarding favorite hypotheses.
- Supporting Quote (paraphrase of a famous scientific maxim):
  - “You can have the most beautiful hypothesis ever, and it can be categorically slain by ugly facts.”
    - Coined by the 19th-century biologist [Thomas Henry Huxley](https://www.npr.org/sections/13.7/2014/01/26/266784786/must-science-murder-its-darlings)

## GLP-1 agonists: are there benefits beyond improving metabolic health and promoting weight loss? [A: 12:45, V: 12:25]

**Opening and framing of the discussion**

- The first major topic is geroprotective drugs—medications that may slow or counteract biological aging rather than simply treat disease.
- The central question is whether drugs that improve metabolic health might also have direct anti-aging or lifespan-extending effects.
- The conversation focuses on the class of drugs currently dominating the medical news cycle: the GLP-1 receptor agonists, including Ozempic, tirzepatide, and Wegovy.
- The key question posed: *Do these drugs improve lifespan through mechanisms beyond metabolic health and weight loss?*

**GLP-1 receptor agonists and their established benefits**

- GLP-1s are described as one of the most significant pharmaceutical advances in modern medicine.
- They have proven benefits for both weight loss and metabolic health, landing them firmly in the “proven” category.
- Earlier generations of weight-loss drugs often caused serious or fatal side effects; GLP-1s are the first to combine strong efficacy with long-term safety and tolerability.
- Their effectiveness was first seen in patients with type 2 diabetes, where improvements in metabolic control were dramatic.
- Listeners who want a deeper dive into GLP-1 drugs, check out:
  - [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/)
  - [#320 – AMA 64: New insights on GLP-1 agonists (Ozempic, Wegovy, Mounjaro) – efficacy, benefits, risks, and considerations in the rapidly evolving weight-loss drug landscape](https://peterattiamd.com/ama64/)
  - Or try [searching for “GLP-1” on the website](https://peterattiamd.com/?s=GLP-1)

***What makes a drug “geroprotective”?***

- A geroprotective drug targets the biological hallmarks of aging—core mechanisms that influence longevity and resilience across multiple systems.
- Unlike disease-specific drugs, which reduce risk within one category (for example, statins lowering cardiovascular mortality), geroprotective drugs should reduce all-cause mortality or slow aging at the cellular and systemic level.
- The [Interventions Testing Program](https://peterattiamd.com/richardmiller/) ([ITP](https://peterattiamd.com/richardmiller2/)) is cited as the benchmark model for identifying such drugs, as it tests compounds in mice for broad lifespan benefits.

–*Why the question matters*

- If GLP-1s were proven to be geroprotective, the implications would be profound, suggesting possible benefits even for healthy, non-obese individuals.
- Practical application would require nuance, as weight loss in already lean individuals could be harmful.
- Potential future exploration could include microdosing to capture the drug’s benefits without unwanted metabolic effects.

**Evidence so far: the SELECT trial**

- The [SELECT trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2307563#:~:text=In%20patients%20with%20preexisting%20cardiovascular,mean%20follow%2Dup%20of%2039.8) on semaglutide (Ozempic/Wegovy) studied approximately 18,000 obese adults with cardiovascular disease but no diabetes.
- Results showed a 20% reduction in major adverse cardiovascular events (MACE), including cardiac death.
- This finding sparked discussion about whether GLP-1s might have protective effects beyond weight loss.
- However, because participants lost weight, it remains unclear whether the reduction in events was due to weight loss itself or a direct action of the drug on aging or cardiovascular function.

–*Potential mechanisms beyond metabolic control*

- GLP-1 receptors exist in multiple tissues, including pacemaker cells in the heart, which helps explain why these drugs can slightly increase heart rate.
- This receptor activity suggests a possible direct cardiovascular mechanism independent of metabolic improvements.
- Such findings open the door to the idea that GLP-1s could exert protective effects through pathways unrelated to glucose control.

**Emerging interest in cognitive effects**

- Research attention has recently shifted toward the cognitive and neuroprotective effects of GLP-1s.
- Data are mixed—some studies show no effect, while others indicate [improved brain connectivity, memory, and cognitive performance](https://pmc.ncbi.nlm.nih.gov/articles/PMC12075970/).
- These benefits appear greater than those seen in individuals who lose weight or improve glycemic control by other means, hinting at an independent mechanism.
- Since the brain is the body’s largest consumer of glucose, any improvement in fuel partitioning or insulin sensitivity can enhance brain function.
- Preliminary non-randomized data suggest GLP-1s may go further, possibly improving cognition through mechanisms not fully understood.
- Because mild cognitive impairment (MCI) has so few effective treatments, this represents an especially important research frontier.

## GLP-1 drugs and the brain: exploring the potential cognitive benefits [A: 18:45, V: 18:55]

Given the scarcity of effective neuroprotective drugs, many people are actively seeking ways to protect brain health, so ***what do we actually know about GLP-1s and their potential cognitive benefits?***

*Caveats and framing before discussing mechanisms*

- Peter emphasizes that everything he’s about to describe is speculative and mechanistic, not proven.
- Mechanistic explanations can sound convincing but often fail when tested experimentally.
  - Example: much of the anti-protein argument in nutrition stems from untested mechanistic claims that collapse under real data.
  - Listeners are cautioned to take mechanistic reasoning “with a wedge of salt.”

**Possible mechanisms behind cognitive effects**

- GLP-1 receptors exist throughout the brain, and many GLP-1 drugs can cross the blood–brain barrier, giving biological plausibility for direct neurological effects.
  - These brain interactions are partly why GLP-1s suppress appetite and support weight loss.
  - However, it’s less clear how this translates to measurable improvements in cognition.
- [Animal studies](https://pubmed.ncbi.nlm.nih.gov/29412810/) show that GLP-1 drugs can reduce neuroinflammation and oxidative stress, both linked to brain aging and cognitive decline.
  - This could imply neuroprotection, but it’s difficult to separate these effects from general improvements in metabolic health, which also reduce inflammation and oxidative stress.
  - In short, GLP-1s might be helping indirectly through better metabolic regulation rather than through a unique brain mechanism.

**Human evidence suggesting independent cognitive benefits**

- The strongest evidence so far comes from a [2021 prospective study](https://pmc.ncbi.nlm.nih.gov/articles/PMC8483500/) in 50 diabetic patients.
  - Participants taking liraglutide (a second-generation GLP-1 drug, older and less potent than semaglutide) showed significant improvements in cognitive testing after 12 weeks.
  - The control group, treated with insulin, metformin, or sulfonylureas, achieved similar glucose control but no comparable cognitive gains.
  - Importantly, these improvements did not correlate with body weight, blood glucose, or blood pressure, suggesting a metabolism-independent effect.
  - This supports the idea that GLP-1s may directly influence neuronal signaling or brain health beyond their effects on metabolism.

**Ongoing clinical trials to watch**

- Two phase 3 clinical trials—[EVOKE](https://clinicaltrials.gov/study/NCT04777396) and [EVOKE+](https://clinicaltrials.gov/study/NCT04777409)—are currently investigating semaglutide for cognitive effects in humans.
  - These studies test an oral formulation rather than the standard subcutaneous (injection) version.
  - Peter expresses skepticism about the design:
    - The oral version may not have the same pharmacokinetic properties.
    - The chosen outcomes may not fully capture relevant brain effects.
  - Despite these concerns, he remains hopeful the data will provide new insights.
- Timing note: the AMA was recorded in August, with the trials expected to finish in September, so preliminary results might appear before the episode’s release in October.

Planned updates

- Once results from these trials are available, The Drive’s [weekly newsletter](https://peterattiamd.com/category/weekly-newsletter/) will likely cover them in detail to keep listeners informed.

## GLP-1 drugs and lifespan: examining the evidence for potential geroprotective effects [A: 23:00, V: 23:45]

**Current state of evidence for GLP-1s and aging**

- There is very little direct evidence that GLP-1 receptor agonists extend lifespan or directly impact the biology of aging.
- Some evidence suggests reduced all-cause mortality (ACM) in specific high-risk populations:
  - A [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/38779187/) of 13 cardiovascular outcome trials reported a 13% reduction in ACM among non-diabetic patients, with or without cardiovascular disease.
  - However, many of these participants were overweight, and the studies didn’t clearly separate the effects of weight loss from other mechanisms.
  - The simplest explanation (“Occam’s Razor”) is that the mortality reduction was driven by weight loss, not by a geroprotective mechanism.

**Challenges in testing geroprotection directly**

- To truly test for geroprotective effects, GLP-1s would need to be studied in Interventions Testing Program (ITP)–style lifespan trials (as mentioned in the [Longevity roundtable episode](https://peterattiamd.com/longevityroundtable/))
  - Such studies are difficult, particularly with injectable drugs, which complicate long-term administration in animal models.
  - As oral formulations of GLP-1s improve, lifespan studies of this kind may become feasible.
- Peter suggests an ITP study design using “pair feeding”, where both treated and control group animals eat identical amounts of food.
  - This would help isolate effects beyond calorie restriction or weight loss.
  - However, differences in energy expenditure (e.g., treated animals running more or being more active) could still confound results.

**Summary and overall interpretation**

- Current evidence does not support a direct geroprotective effect of GLP-1s, but their strong benefits in metabolic and cardiovascular health are well-established.
- Data show consistent reductions in cardiovascular disease and ACM in high-risk patients, though likely secondary to improved metabolic status.
- Peter categorizes GLP-1s as “north of fuzzy, south of promising” for geroprotection—showing early hints of potential but lacking convincing evidence for lifespan extension.
- For metabolic and cardiovascular outcomes, they remain firmly in the “proven” category.

## Rapamycin and geroprotection: why it remains in the “promising” category [A: 25:45, V: 26:50]

**Positioning rapamycin on the geroprotection scale**

- Rapamycin remains in the “promising” category for geroprotective potential.
- Although it lacks robust human data, it has exceptionally strong animal data supporting lifespan extension.
- Some might argue it should rank slightly below GLP-1s due to limited human studies, but the breadth of animal evidence makes a strong case for its placement.

*Evidence base across species*

- Rapamycin shows [consistent lifespan extension](https://peterattiamd.com/davidsabatini-mattkaeberlein/) across the four key model organisms in aging research:
  - Yeast, worms, fruit flies, and mammals.
  - These species together represent roughly a billion years of evolutionary diversity, suggesting a deeply conserved mechanism.
- The mechanism centers on transient inhibition of mTOR (mechanistic target of rapamycin), a pathway that regulates growth, metabolism, and cellular stress resistance.
  - Temporarily dampening mTOR activity appears to slow aging processes across species.

*Human data and interpretation*

- Human evidence is much more limited, but early findings suggest rapamycin is not simply an immunosuppressant, as long assumed.
- Instead, it may act as an immune modulator, potentially enhancing immune resilience when dosed properly.
- This dual effect—targeting one of the hallmarks of aging (dysregulated nutrient sensing) while improving immune function—underpins its promise as a geroprotective agent.
- Despite optimism, Peter emphasizes there’s room for debate on exactly how high rapamycin should be ranked relative to other interventions like GLP-1s.

## SGLT2 inhibitors and their potential geroprotective effect [A: 27:30, V: 28:40]

**Introduction to SGLT2 inhibitors and their growing attention**

- Discussion shifts to SGLT2 inhibitors, a class of drugs receiving increasing interest for potential geroprotective benefits.
- Public awareness has grown, with recent mainstream coverage such as a [Wall Street Journal article](https://www.wsj.com/health/wellness/diabetes-drugs-jardiance-anti-aging-6cc91047?gaa_at=eafs&gaa_n=AWEtsqewngYziDFUSDVT5B0kStKHDtOFa08-l0FG8P2YT_NXw4wLQC6OeiE4WnM1udM%3D&gaa_ts=68fd2eb1&gaa_sig=J9IHnNjtqsVLljk-kjXkTaXDfEBh0fCu7n1mAXU2l_pRTiXIT6KxbidVMVwL-2JniSNqYKJHjKTDJK7dqnmXCQ%3D%3D) highlighting their potential beyond diabetes.
- The key question: ***can these drugs extend lifespan or improve aging outcomes independent of their metabolic effects?***

Established benefits for diabetes treatment

- In the context of diabetes management, SGLT2 inhibitors are in the proven category.
  - They lower blood glucose effectively by promoting urinary glucose excretion.
  - This mechanism reduces blood sugar by preventing glucose reabsorption in the kidneys.
- The SGLT transporters and these drugs’ mechanisms were discovered with contributions from [Dr. Ralph DeFronzo, previously featured on The Drive](https://peterattiamd.com/ralphdefronzo/).
- The drugs’ success also highlights how insulin resistance affects kidney function, providing a strong rationale for their use in diabetic patients.

Potential benefits beyond glucose control

- SGLT2 inhibitors appear to provide cardiovascular and renal benefits that extend beyond their glucose-lowering effect.
  - When glucose reabsorption is reduced, sodium excretion increases as each glucose molecule is normally reabsorbed with one sodium ion.
  - This leads to reduced plasma volume and lower blood pressure, mechanisms that may explain cardiovascular improvements.
- These effects suggest broader metabolic and circulatory benefits, not solely tied to diabetes control.

Key evidence from clinical trials and meta-analyses

- A [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/37344038/) of 13 randomized controlled trials found significant risk reductions across several conditions:
  - 24% reduction in cardiovascular mortality among patients with heart failure.
  - 23% reduction in mortality among diabetic patients.
  - 23% reduction in mortality among those with chronic kidney disease (CKD), even with mild impairment (GFR <60 mL/min).
  - Significant reduction in MACE (major adverse cardiac events) for patients with heart failure or CKD, regardless of diabetes status.
- Collectively, this shows strong evidence that SGLT2 inhibitors improve cardiac, renal, and metabolic health outcomes in high-risk populations.

Limitations and unanswered questions

- Despite compelling evidence in disease contexts, the central question remains unanswered:
  - W*ould a metabolically healthy, disease-free person derive any benefit from SGLT2 inhibitors*?
- Current data show clear mortality and morbidity reductions **only in high-risk groups**, not the general population.
- Therefore, while the results are “insanely promising”, they stop short of proving geroprotective or lifespan-extending effects in healthy individuals.

**Connection between cardiovascular and all-cause mortality**

- Since cardiovascular disease (CVD) is the leading global cause of death, reducing cardiovascular mortality almost inevitably reduces all-cause mortality (ACM), especially in high-risk populations.
- This overlap makes it challenging to disentangle whether observed ACM reductions reflect true geroprotection or simply the downstream effect of improving cardiac health.

Supporting evidence from meta-analyses and clinical trials

- A [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34418562/) comparing SGLT2 inhibitors to other diabetes medications (sulfonylureas and DPP-4 inhibitors) found:
  - 29% relative reduction in cardiovascular events despite similar glucose control.
  - 47% lower risk of all-cause mortality, further underscoring benefits beyond glycemic management.
- Another [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/39566582/) of 14 randomized controlled trials in chronic kidney disease (CKD) patients found an 11% reduction in ACM, largely driven by cardiovascular improvements (MACE reduction).
- Together, these data show strong evidence that SGLT2 inhibitors reduce ACM in individuals with cardiac or renal risk factors, primarily through cardioprotective mechanisms.

Limitations and unanswered questions

- These mortality benefits are disease-context specific; they do not yet establish SGLT2 inhibitors as geroprotective for healthy individuals.
- The Interventions Testing Program (ITP) directly [examined the lifespan effects of canagliflozin](https://pmc.ncbi.nlm.nih.gov/articles/PMC7710304/), an SGLT2 inhibitor:
  - Found a 14% increase in median lifespan, but only in male mice.
  - Both sexes experienced improved metabolic health, glucose tolerance, and weight control, suggesting lifespan effects were independent of metabolic benefits.
  - The sex-specific outcome remains unexplained, highlighting biological variability in drug response.
- Other examples of sex-differentiated results in ITP studies include:
  - 17α-estradiol, beneficial in males but not females (explained by estrogen differences).
  - Rapamycin, which also shows variable lifespan effects between sexes due to metabolic differences.

Overall interpretation and classification

- The consistency of cardiovascular and renal benefits, combined with ITP lifespan findings, justify placing SGLT2 inhibitors in the “promising” category for geroprotection.
- GLP-1 agonists remain slightly lower, between “fuzzy” and “promising”, due to less comprehensive evidence.
- However, neither drug class has yet demonstrated proven geroprotective effects in disease-free humans—a key gap for future research.
- Peter reiterates that both drugs are scientifically compelling, but determining whether they help healthy individuals live longer remains the central question.

## Methylene blue: examining the evidence of an anti-aging effect [A: 34:45, V: 37:00]

**Overview of methylene blue and its rising interest**

- Methylene blue has gained renewed public and scientific attention as a potential geroprotective compound, though the evidence remains weak.
- Peter jokes that he receives many samples, noting that the topic has been on his radar for about a decade.
- It was [discussed previously on The Drive with Dr. Francisco González-Lima](https://peterattiamd.com/franciscogonzalezlima/), focusing on possible cognitive health benefits.
- **Overall assessment**: the evidence for longevity or geroprotection is far less compelling than for drugs like GLP-1s or SGLT2 inhibitors.

Background and pharmacological profile

- Methylene blue is the first fully synthetic drug in medical history, discovered roughly 150 years ago.
- It has broad industrial and medical uses due to its redox capacity—the ability to donate or accept electrons.
  - This property makes it useful in industrial processes and in treating methemoglobinemia, a rare blood disorder that prevents hemoglobin from effectively binding oxygen.
- The current aging-related interest stems from its potential to improve mitochondrial function and reduce oxidative stress, both of which are hallmarks of aging.

Mechanistic rationale and in vitro findings

- Methylene blue’s proposed mechanism centers on its impact on mitochondrial electron transport:
  - It can serve as an alternative electron carrier between complex III and complex IV, allowing ATP production to continue even if one complex is damaged.
  - This could hypothetically preserve cellular energy metabolism under stress.
- In vitro (cell culture) [studies](https://pubmed.ncbi.nlm.nih.gov/17928358/) show:
  - Up to a 70% increase in oxygen consumption and NAD levels.
  - Enhanced mitochondrial complex activity (III and IV).
  - Reduced oxidative radicals and potentially less cellular senescence.
- These results are mechanistically appealing but entirely preclinical, and Peter emphasizes caution against overinterpreting mechanistic data without in vivo evidence.

Animal data and limitations

- The Interventions Testing Program (ITP) conducted a lifespan [study](https://pubmed.ncbi.nlm.nih.gov/24245565/) in mice, the gold standard for evaluating geroprotective potential.
  - Results were largely negative: no significant increase in lifespan for either sex.
  - A minor (~6%) non-significant increase was seen in females only.
- The small effect might reflect dose-related issues, but overall, evidence for lifespan extension is absent.
- While the theory of mitochondrial support remains interesting, current data don’t justify claims of geroprotection.

Categorization and outlook

- Peter classifies methylene blue in the “noise” category on the proven–promising–fuzzy–noise–nonsense scale.
- It represents a mechanistically plausible but experimentally unproven intervention.
- More robust animal replication studies could upgrade it to “fuzzy” or “promising,” but if future trials confirm no benefit, it may fall to “nonsense.”

## Methylene blue’s potential neuroprotective effects: limited and inconsistent evidence in humans, and the challenges of dosing and safety [A: 41:15, V: 43:45]

**Overview and transition from geroprotection to chronic disease prevention**

- Peter clarifies that while his prior comments focused on geroprotection, the conversation can shift toward chronic disease prevention and treatment.
- Evidence for mitochondrial support from methylene blue is relatively strong in animal models, especially regarding brain and nervous system health.
- Because methylene blue crosses the blood–brain barrier, most research has centered on its neuroprotective potential.

Neuroprotective effects in animal models

- Multiple rodent studies have shown that methylene blue can:
  - Preserve neurons and cognitive function following traumatic brain injury (TBI).
  - Offer protection during chronic cerebral hypoperfusion—a condition mimicking reduced blood flow seen in stroke or vascular dementia.
    - [Stelmashook et al., 2023](https://pubmed.ncbi.nlm.nih.gov/36804486/)
    - [Auchter et al., 2020](https://pubmed.ncbi.nlm.nih.gov/32508596/)
    - [Bachurin et al., 2019](https://www.nature.com/articles/s41598-019-41272-4)
- These findings suggest potential neuroprotective properties, though the evidence remains largely preclinical.

Human research and mixed results

- Peter references his earlier Drive [episode](https://peterattiamd.com/franciscogonzalezlima/) with Dr. Francisco González-Lima, which explored methylene blue’s cognitive applications.
- Human data are limited and inconsistent:
  - A [small trial](https://pubmed.ncbi.nlm.nih.gov/33091706/#:~:text=Conclusion%3A%20We%20conclude%20that%20intraoperative,safe%20for%20prevention%20of%20early) tested methylene blue for post-operative delirium in older adults, aligning with the animal neuroprotection hypothesis.
  - Two additional trials examined methylene blue for Alzheimer’s disease and cognitive impairment:
    - One found modest cognitive improvements.
    - The other showed no benefit.
- Overall, the clinical translation of animal findings remains uncertain.

Dosing challenges and safety concerns

- Methylene blue has a narrow therapeutic window and a nonlinear dose-response relationship, making it difficult to dose safely.
  - At high doses (>6–7 mg/kg), it can become pro-oxidative, impairing rather than supporting mitochondrial function.
- Typical dosing ranges:
  - 0.3–4 mg/kg of body weight, depending on use case.
  - The only established medical use—treatment for methemoglobinemia—uses ~1 mg/kg, considered safe.
  - Some studies exploring cognitive benefits used 4 mg/kg, but dosing beyond that may increase risk.
- One human [study](https://pubmed.ncbi.nlm.nih.gov/36803299/) reported reduced cerebral blood flow and oxygen consumption at doses between 0.5–1 mg/kg, suggesting potential for complex, unpredictable brain effects.

Drug interactions and contraindications

- Methylene blue is a potent monoamine oxidase A (MAO-A) inhibitor.
  - When combined with MAO-A inhibitors or serotonergic medications, it can cause serotonin toxicity.
  - Cases of serotonin syndrome have been reported at doses above 5 mg/kg.
- Peter emphasizes that this safety profile makes the drug unappealing for use in either patients or himself.

Overall assessment and categorization

- Evidence supports some neuroprotective benefits in animals and limited human trials, but dosing and safety issues constrain practical application.
- Peter upgrades methylene blue from “noise” (in the geroprotective context) to “fuzzy” for neuroprotection and chronic disease prevention.
- However, he personally avoids the drug due to its dose volatility, safety risks, and inconsistent human outcomes.

## Telomeres: what they are, how they relate to aging, and why telomere-lengthening supplements lack credible scientific evidence [A: 43:45, V: 47:26]

***What are telomeres and what do they even have to do with aging where people care about it?***

- Telomeres are DNA sequences at the ends of chromosomes that act as protective caps, preventing chromosomal degradation during cell division.
- Each time a cell divides, a portion of the telomere shortens, which functions as a buffer zone to safeguard vital genetic material.
- When telomeres become too short, the cell can no longer divide safely and enters senescence, contributing to aging.
- Telomere shortening is associated with aging and age-related diseases such as cancer and heart disease, and this process is accelerated by oxidative stress.
- This understanding led to the hypothesis that drugs or supplements that preserve or lengthen telomeres could improve lifespan or healthspan.

Overview of telomere-lengthening supplements

- Supplements marketed for telomere lengthening typically contain extracts from the astragalus plant (Astragalus membranaceus).
- They are claimed to enhance telomerase activity, an enzyme that maintains telomere length by adding DNA sequences to chromosomal ends.
- One well-known commercial product is TA-65, which is promoted as a telomerase activator and anti-aging supplement.

Peter’s lab experience with telomerase activation

- Early in his career, Peter worked in an immunotherapy lab exploring telomerase enhancement in T cells to prolong their lifespan and improve immune responses.
- The goal was to combine the recognition ability of mature T cells with the functionality of younger ones—essentially creating “rejuvenated” T cells.
- Despite extensive experiments, all efforts failed to produce a youthful phenotype, suggesting that artificially manipulating telomerase did not rejuvenate cells as hypothesized.

Evaluation of the evidence for commercial supplements

- There is no credible evidence—in humans or animals—that astragalus-derived supplements reduce disease risk or extend lifespan.
- Even the claim that they slow telomere degradation is highly questionable and based on methodologically weak studies.
- The main cited evidence comes from a [2016 study](https://pubmed.ncbi.nlm.nih.gov/26950204/) of CMV-positive patients given TA-65 or placebo:
  - The 250-unit dose group showed a modest increase in mean telomere length in white blood cells after one year.
  - The 1,000-unit group (four times the dose) showed no effect or slight telomere shortening.
  - Intermediate time points revealed fluctuating telomere lengths in both treatment and placebo groups—suggesting random variability, not real biological change.
  - The measurement method (Q-FISH) has an error margin of ~450 base pairs, while observed differences were only ~300 base pairs—within the noise range.

Conflict of interest and credibility issues

- The study was funded by TA Sciences, the same company that sells TA-65—creating a clear conflict of interest.
- The FTC censured TA Sciences in 2018 for false advertising related to anti-aging and DNA repair claims.
- These factors undermine the reliability of the evidence and highlight commercial bias in the telomere supplement space.

Overall interpretation and classification

- Although telomere biology is fundamental to cellular aging, there is no convincing data that telomere-lengthening supplements improve healthspan or longevity.
- Measured effects are within experimental noise, and no meaningful clinical endpoints (like reduced disease or mortality) have been demonstrated.
- Peter advises all patients to discontinue TA-65 or similar supplements.
- He categorizes telomere-lengthening supplements as “nonsense”, not merely “noise,” given the lack of mechanistic, experimental, and ethical credibility.

## Does the idea of targeting telomere length to extend lifespan have scientific merit? [A: 50:15, V: 54:45]

**Peter’s overall stance on telomere lengthening as a longevity strategy**

- Peter expresses strong skepticism toward telomere lengthening as a viable path to extending lifespan.
- Even beyond supplements, he considers the entire research direction weak and not worth funding compared to other geroscience priorities.
- If he were “czar” allocating research resources, telomere-targeting therapies would not receive funding, as the underlying mechanistic premise is flimsy.

Problems with the telomere hypothesis

- While repeated cell divisions shorten telomeres, and telomerase partially offsets this, the relationship between telomere length and actual organismal lifespan is unsupported by data.
- Many confuse cellular senescence (a cell-level process) with organismal aging, but these are distinct phenomena.
- Simply having shorter telomeres in individual cells does not predict how long an organism will live.

Evidence against telomere length as a meaningful biomarker

- A 2021 [meta-analysis](https://onlinelibrary.wiley.com/doi/abs/10.1111/mec.16145) across 98 species found only a very weak inverse correlation between telomere length and age (r = –0.16).
  - A much stronger correlation (e.g., –0.8 or –0.9) would be expected if telomere attrition truly governed lifespan.
  - Therefore, the data suggest that telomere shortening plays, at best, a minor role in aging.
- The correlation existed only in adult animals, not juveniles, implying that telomere dynamics may not follow a consistent biological pattern.
- The meta-analysis also revealed publication bias, suggesting that studies showing stronger correlations were more likely to be published, further weakening confidence in the evidence base.

Peter’s conclusion on telomere-focused research

- He finds the concept outdated and unconvincing, noting it has persisted in the longevity conversation for over a decade despite lack of proof.
- From his view:
  - The mechanism lacks merit.
  - The supplements marketed to target it are unscientific.
  - The combination of both (“a bad mechanism plus bad products”) makes it “a double whammy.”
- Bottom line: **telomere length is not a meaningful target for aging interventions**, and ongoing hype around it misleads consumers and wastes scientific resources.
- He firmly places telomere lengthening in the “nonsense” category of his evaluation scale.

## Low-dose aspirin for cardiovascular disease prevention: weighing its clot-prevention benefits against bleeding risks across different populations [A: 55:00, V: 1:00:05]

**Overview of topic and clinical relevance**

- The discussion shifts to low-dose aspirin as a tool for cardiovascular disease (CVD) prevention, especially given CVD’s status as the leading global cause of death.
- Aspirin has long been used for secondary prevention of heart attacks and strokes, but its role in primary prevention has become more controversial.
- Peter frames the discussion within his categorical framework (“proven, promising, fuzzy, noise, nonsense”) to assess where aspirin belongs for CVD outcomes.

Mechanism of action and rationale for use

- Aspirin inhibits platelet aggregation, reducing the formation of blood clots that can block arteries and trigger heart attacks (myocardial infarction) or ischemic strokes.
- These effects lower cardiovascular event risk but come with a major trade-off:
  - Reduced ability to stop bleeding when it’s needed.
  - Increased risk of both internal (e.g., gastrointestinal) and external bleeding.
- The challenge in medicine is to balance this risk–reward equation—maximizing cardiovascular protection while minimizing the danger of major bleeding.

Clinical trade-offs and population-specific considerations

- Aspirin’s benefit–risk profile varies dramatically by population:
  - In elderly individuals (≥70 years) or those with high bleeding risk, the harms outweigh the benefits.
  - In younger individuals (50–60 years) with elevated CVD risk but low bleeding risk, there might be some potential upside.
- Peter stresses that this gray zone—where benefits and risks nearly cancel—is where most patients fall.

Key trial evidence and numerical findings

- In a major [trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1805819) of adults aged 70+, aspirin did not significantly prevent cardiovascular events, but did increase major bleeding.
  - Major bleeding risk: +0.47% (≈1 in 200 people).
  - MACE reduction: –0.41%.
  - Result: Net harm, as bleeding outweighed cardiovascular protection.
- In a [trial](https://pubmed.ncbi.nlm.nih.gov/30158069/) with non-diabetic high-risk patients (e.g., high LDL cholesterol), there was no reduction in risk of CV event, but an elevation of risk in major bleeds.
  - Minor reductions in events were offset by more bleeding, yielding a net negative outcome.
- In another [trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1804988) with diabetic patients, aspirin did reduce MACE, but the benefit was completely nullified by the higher rate of bleeding.
- Across trials, aspirin’s absolute benefit is small, and bleeding risk is substantial, leading Peter to view most uses as “noise to nonsense.”

Potential precision-medicine approach (platelet phenotype testing)

- Peter notes a future opportunity: stratifying patients by platelet reactivity biomarkers.
  - Historical example: the “AspirinWorks” test, which measured platelet activity via urine-based markers.
  - In theory, identifying hyper-aggregating phenotypes could help isolate those who benefit most from aspirin while avoiding unnecessary exposure for others.
- However, no major outcome trials have yet selected participants based on platelet biomarker data, leaving this an untested idea.

Categorization and recommendations

- For older adults (≥70 years) or those with high bleeding risk:
  - Category: Noise to nonsense.
  - Reason: Minimal MACE reduction overshadowed by bleeding risk.
- For middle-aged individuals (≈50–60 years) with high CVD risk and low bleeding risk:
  - Category: Fuzzy to promising.
  - Reason: Some potential net benefit, though not well quantified.
- Peter’s overarching guidance:
  - Avoid broad recommendations for aspirin as a preventive therapy.
  - Consider use only in select cases, ideally guided by personalized risk assessment.

## Rethinking the protein RDA: why most people need twice the recommended amount for muscle health [A: 1:00:45, V: 1:06:40]

Since protein intake is central to muscle growth… ***Is the U.S. Recommended Dietary Allowance (RDA) sufficient for maximizing muscle mass, or should people aim higher?***

- The current RDA (0.8 g/kg/day) was set 45 years ago and represents only the minimum amount needed to prevent deficiency, not to promote optimal health or performance.
- This level is adequate for small, inactive individuals, but insufficient for most adults who want to optimize muscle health, body composition, or aging resilience.
- The RDA’s purpose is deficiency prevention, not functional optimization—a key distinction that often gets overlooked.

Evidence for higher optimal intake

- Muscle protein synthesis (MPS), the process by which the body builds new muscle tissue, continues to rise with protein intakes well above the RDA.
- Multiple RCTs and meta-analyses converge on an optimal intake range of 1.6–2.2 g/kg/day (≈0.8–1.0 g/lb/day).
  - [Morton et al., 2018](https://bjsm.bmj.com/content/52/6/376); [Nunes et al., 2022](https://pubmed.ncbi.nlm.nih.gov/35187864/); [Stokes et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29414855/);
  - This range maximizes MPS and supports muscle hypertrophy (growth).
  - It reflects more than twice the RDA, which Peter argues should be viewed as a minimum threshold rather than a target.
- [Meta-analyses](https://bjsm.bmj.com/content/52/6/376) covering over 80 trials show MPS doesn’t plateau until at least 1.6 g/kg/day, reinforcing that higher intake is necessary for muscle optimization.

Groups that benefit from even higher protein intake

- Older adults — experience anabolic resistance, meaning they require more protein to achieve the same MPS response as younger individuals.
- People consuming low-quality proteins — those who rely on plant-based or incomplete amino acid sources (lower PDCAAS scores) need higher total intake to achieve equivalent effects.
- High-training or caloric-deficit individuals — such as athletes or those cutting fat while maintaining muscle, may need to exceed 2.2 g/kg/day to offset the catabolic effects of energy restriction.

Protein quality and essential amino acids

- Not all proteins are equal in quality or digestibility. (see [AMA #68](https://peterattiamd.com/ama68/))
- The best sources for supporting MPS are:
  - Beef-derived proteins
  - Dairy-derived proteins (e.g., whey, casein)
  - Egg-derived proteins
- These sources provide the complete amino acid profile, including essential amino acids like leucine, which is critical for triggering MPS.
- Individuals avoiding these foods may require greater total intake or supplementation (e.g., with essential amino acids or whey isolates).

Key takeaway and Peter’s position

- Resistance training + adequate protein are the two critical pillars of maintaining and increasing muscle mass.
- The RDA is far too low for optimizing muscle health, especially in aging populations.
- Peter is frustrated by ongoing public controversy over this issue, noting that the science has been settled for decades and the debate has become politicized rather than evidence-based.
- He categorizes the RDA level as insufficient for health optimization and emphasizes the higher, evidence-supported intake range for anyone serious about strength, performance, or longevity.

## Debunking the protein–cancer myth: why higher protein intake doesn’t promote tumor growth [A: 1:06:15, V: 1:12:40]

**Framing of the question**

- The discussion turns to one of the most persistent myths in nutrition science — the idea that high protein intake increases cancer risk or accelerates tumor progression.
- Nick notes that this concern is frequently raised by listeners and patients, often grounded in mechanistic fears rather than real-world evidence.
- Peter uses an extended “spoiled milk in the car” analogy to illustrate how bad scientific ideas can linger in public discourse long after being disproven.

⇒ Check out a premium article by Peter on the protein-cancer question: [Do high protein diets increase cancer risk?](https://peterattiamd.com/high-protein-diets-and-cancer-risk/)

**Origin of the protein–cancer hypothesis**

- The claim stems from mechanistic reasoning rather than experimental evidence.
  - The argument: Amino acids activate mTOR, a signaling pathway involved in cell growth and proliferation.
  - Since uncontrolled cell proliferation characterizes cancer, some have hypothesized that more protein → more mTOR activation → more cancer.
- This chain of reasoning is overly simplistic and unsupported:
  - mTOR activation is a normal, regulated physiological process required for muscle growth and repair.
  - Cancer develops not from normal signaling but from loss of regulation within these pathways.
  - There is zero experimental evidence that dietary protein causes this breakdown in regulation or initiates cancer.

*Evaluation of the evidence*

- No randomized controlled trials (RCTs) show that higher protein intake increases cancer incidence.
- Epidemiologic studies (large population-based observational data):
  - Consistently show no link between protein intake and cancer risk.
  - If anything, these studies are biased against protein, since high protein intake often correlates with higher total calories, lower fiber, and poorer diet quality, yet no signal of harm emerges.
- Interventional data in cancer patients suggest the opposite trend:
  - Protein supplementation appears to have [neutral or slightly beneficial effects](https://pubmed.ncbi.nlm.nih.gov/39631998/) on survival and treatment outcomes.
  - High-protein intake during cancer treatment reduces muscle wasting (sarcopenia) and lowers hospitalization rates.
  - Thus, in real-world settings, protein helps maintain strength and quality of life, not cancer progression.

*Historical and contextual background*

- Peter points out that negative perceptions of high-protein diets have persisted for over a century, often originating from poorly controlled or anecdotal reports.
- Many of these early claims likely stemmed from confounding factors — low fiber intake, contamination, or unrelated lifestyle variables.
- The persistence of this belief exemplifies a broader problem: the endurance of unfounded nutritional dogma in public and medical conversations despite contradictory data.

**Peter’s conclusion and classification**

- The notion that protein increases cancer risk is scientifically baseless.
- Mechanistic arguments (like mTOR activation) have been experimentally refuted, and empirical studies show no harm and possible benefit.
- Peter places this idea firmly in the “nonsense” category of his evidence scale.
- His analogy (“rotten milk in the car”) underscores his view that this claim is so entrenched and stale that the only solution is to discard it entirely—akin to scrapping the car rather than trying to clean it.

## The biology of follistatin and myostatin, and why follistatin gene therapy has become an emerging topic of interest for muscle growth [A: 1:13:15, V: 1:20:50]

**Introduction and context**

- The final topic transitions from general muscle building to follistatin gene therapy, a rapidly emerging and highly discussed intervention.
- The topic gained attention through Peter’s previous [podcast with Derek from “More Plates, More Dates,”](https://peterattiamd.com/derekmpmd/) and online fascination with myostatin knockout animals—the famously “double-muscled” cows, chickens, and mice.

![](https://peterattiamd.com/wp-content/uploads/2025/10/f1-ama76-1024x743.png)

**Figure 1. A jacked cow.** Source: [listarfish.it](https://www.listarfish.it/en/news-en/myostatin-elisa-eia-kit/)

**Background: myostatin and its biological role**

- Myostatin is a naturally occurring protein that acts as a limiter (“governor”) of muscle development.
- Its key function occurs embryonically, determining the number of muscle fibers an organism develops.
- In animals where the myostatin gene is knocked out, the result is massively increased muscle fiber count, leading to the striking “double-muscled” phenotype.
  - Examples: myostatin knockout mice, cows, and chickens.
  - These models became legendary in biology classrooms for demonstrating genetic control over muscle development.

*Key limitation: myostatin’s relevance to adults*

- The muscle-fiber–multiplying effect of myostatin inhibition occurs only during embryonic development.
- In adult animals, blocking myostatin does not substantially increase muscle fiber number or strength, since the body loses the capacity to create new fibers after development.
- This raises an important question: how can follistatin, which inhibits myostatin, produce measurable effects in adult muscle growth?

*Follistatin’s dual mechanisms and surprising effects*

- Follistatin is a protein expressed in muscle and other tissues that regulates gene expression and interacts with myostatin.
- Initially, researchers assumed its only function was blocking myostatin activity.
- However, more recent findings reveal a dual mechanism:
  - It inhibits myostatin (which limits muscle development).
  - It independently increases muscle protein synthesis (MPS)—the process responsible for muscle growth.
- Unlike myostatin knockout during development, follistatin in adults appears to increase muscle size (hypertrophy) rather than fiber count (hyperplasia).
  - This mirrors the physiological effects of resistance training, which enlarges existing fibers rather than creating new ones.
- Peter admits he was initially dismissive of follistatin due to his strong familiarity with myostatin’s limited adult effects, but later changed his view after reviewing the emerging evidence.

*Potential for gene therapy*

- The promising discovery that follistatin can stimulate muscle growth in adults has led scientists to explore gene therapy approaches:
  - The idea is to overexpress follistatin in skeletal muscle using a viral vector, leading to sustained increases in local follistatin production.
  - This could theoretically boost muscle mass and strength while avoiding the systemic side effects of anabolic steroids, such as hormonal disruption or organ stress.
- Researchers envision that, if effective and safe, follistatin gene therapy could have broad applications for muscle wasting diseases, aging-related sarcopenia, and performance enhancement.

Peter’s summary and tone

- This section serves as the setup for the next part of the discussion, which examines what current data actually show about follistatin gene therapy’s efficacy in animals and humans.
- Peter is both scientifically intrigued and cautiously skeptical, balancing enthusiasm for the mechanistic promise with awareness of the limited human evidence.
- He describes the concept as “setting the stage” for deeper exploration—acknowledging that follistatin is scientifically compelling but still under investigation.

## Follistatin gene therapy for muscle growth: state of the evidence in animals and humans, and the technical challenges and regulatory barriers [A: 1:17:00, V: 1:25:05]

***With that stage set, where do things stand with follistatin gene therapy as a way to increase muscle mass currently?***

*Follistatin gene therapy: animal studies*

- In animal models, the evidence for follistatin gene therapy is clear and compelling — it significantly increases muscle mass and strength.
- Studies in young adult mice used viral vectors (either direct muscle injection or IV infusion) to elevate follistatin expression in skeletal muscle.
  - Both delivery methods were effective, though local muscle injection produced slightly stronger results.
- [Outcomes in mice](https://pubmed.ncbi.nlm.nih.gov/22711699/):
  - ~100% increase (doubling) in skeletal muscle mass.
  - ~40% increase in muscle force.
  - The mechanism of action was myofiber hypertrophy (enlarging existing muscle fibers), not hyperplasia (increasing fiber count).
  - This hypertrophic effect mirrors resistance training, where fibers grow in size rather than number.

*Mechanistic insight: role of mTOR*

- The hypertrophy effect of follistatin was partially blocked by rapamycin, a known mTOR inhibitor.
  - This indicates that follistatin’s muscle-building effects depend in part on mTOR activation, independent from its inhibition of myostatin.
  - It suggests multiple overlapping mechanisms: one related to myostatin inhibition, and one via mTOR-driven protein synthesis.

*Results in primate models*

- Macaque monkeys—a closer model to humans—showed promising [results](https://pubmed.ncbi.nlm.nih.gov/20368179/) as well:
  - After follistatin adenoviral vector injection into the quadriceps, follistatin expression rose 10–12×.
  - This led to ~15% increases in muscle strength and quadriceps circumference within 16 weeks after a single injection.
  - The hypertrophy was predominantly in type II (fast-twitch) fibers, which are most responsible for strength and power.
  - Importantly, no adverse effects were seen in other organs or muscle types (e.g., cardiac or smooth muscle).
- Peter summarizes these results as “pretty promising in animals”, noting the strong signal and safety profile in preclinical models.

*Human trials: limited and inconclusive*

- Despite promising animal data, human evidence is extremely limited — only three small preliminary trials exist.
- All three were conducted in patients with muscular dystrophy (particularly Becker muscular dystrophy).
- The largest [trial](https://pubmed.ncbi.nlm.nih.gov/25322757/) included only six adult male participants, each receiving follistatin adenoviral vector injections in the quadriceps. Results were mixed and inconsistent:
  - Three patients improved on a 6-minute walk test (gains of 12–43%).
  - Three showed minimal or no improvement.
  - Some evidence of slight increases in muscle fiber size, but no measurable gain in quadriceps strength or muscle mass.
- Peter notes that muscular dystrophy may be the wrong model for assessing this therapy:
  - The disease involves structural muscle destruction — the fibers literally tear apart under normal tension.
  - This makes it unlikely that follistatin could repair such extensive damage.
  - He compares it to “putting a Band-Aid on a severed femoral artery” — meaning the tissue is too damaged for such a therapy to have effect.

*Barriers to testing in healthy humans*

- Peter argues that the real test would be gene therapy trials in healthy individuals, but this presents serious ethical and regulatory hurdles.
  - Gene therapy is typically reserved for life-threatening or severe genetic diseases (e.g., sickle cell anemia, metabolic disorders).
  - It would be very difficult to justify testing gene therapy solely for muscle enhancement in healthy subjects.
- There are also technical challenges:
  - Different studies have used different viral vectors (delivery systems), and it’s unclear which is optimal for human skeletal muscle.
  - This variability adds another layer of uncertainty about how to design a standardized human trial.

*Unregulated treatments and anecdotal claims*

- Peter mentions a growing number of individuals who travel abroad (e.g., Costa Rica) to receive unverified follistatin gene therapy treatments.
  - He emphasizes that these are not legitimate clinical trials and that anecdotes do not count as data.
  - While some claim dramatic muscle gains, these reports cannot be verified and should be viewed skeptically.

*Peter’s current classification and outlook*

- Based on current evidence, Peter places follistatin gene therapy in the “fuzzy” category of his evidence scale:
  - Strong preclinical data (mice and primates) suggest real potential.
  - Human evidence is too limited, poorly designed, and inconclusive to draw conclusions.
  - Regulatory and ethical constraints make it unlikely we’ll get robust human data soon.
- He admits he finds the topic fascinating, saying in a “parallel universe” he would love to run the trial himself to see what’s possible.
- **Final takeaway**: follistatin gene therapy remains promising but unproven, stalled at the intersection of biological plausibility and practical limitations.

## Why injectable follistatin is theoretically possible but impractical for real-world use [A: 1:23:15, V: 1:32:30]

**Question context**

- Nick asks whether follistatin could ever be used without gene therapy, given the complexity, cost, and regulatory barriers of gene-based delivery.
- Peter explains that while it’s theoretically possible, in practice it’s not viable due to biochemical and financial limitations.

*Biological limitation: protein instability*

- Follistatin is a protein, and proteins can’t be taken orally because:
  - They are broken down by digestive enzymes before absorption.
  - As a result, oral supplementation wouldn’t survive digestion or reach the bloodstream intact.
- The only realistic delivery methods are injections, typically subcutaneous (sub-Q) or intramuscular, similar to how peptide hormones like insulin are administered.

*Recombinant follistatin: available but impractical*

- Recombinant follistatin (synthetic lab-produced protein) does exist and has shown some efficacy in animal studies.
- However, several major issues make this approach impractical for human use:
  - 1) Short half-life:
    - Follistatin breaks down very quickly in the body, requiring frequent and large doses to maintain therapeutic levels.
  - 2) Extreme cost:
    - Commercial price: $125 per milligram of follistatin 344 peptide.
    - Effective daily doses would require hundreds of milligrams, depending on body weight.
    - Estimated daily cost:
      - $11,000 per day for smaller individuals.
      - Up to $35,000 per day for larger individuals.
  - 3) Limited availability:
    - Even if one could afford it, sourcing the required quantities would be nearly impossible due to production limitations.

**Peter’s conclusion**

- Although technically feasible in concept, recombinant follistatin is not a realistic therapeutic option for increasing muscle mass.
- Between its rapid degradation, unmanageable cost, and supply constraints, it remains a theoretical curiosity, not a practical intervention.
- Peter summarizes it bluntly: “*In theory, yes. In practice, no.*”
- His final point underscores that anyone claiming to use recombinant follistatin effectively is almost certainly overstating results—or spending a fortune for negligible benefit.

---

## Selected Links / Related Material

**Video of NFL player, Damar Hamlin, having a cardiac arrest on the field**: [Damar Hamlin Collapses After Hit vs Bengals](https://www.youtube.com/watch?v=r1Z9Vd53yhI) | Swift Highlights (youtube.com) [2:15]

**Previous episode of The Drive with the “Proven, Promising, Fuzzy, Noise, Nonsense” scale**: [#300 – Special episode: Peter on exercise, fasting, nutrition, stem cells, geroprotective drugs, and more — promising interventions or just noise?](https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/) | Peter Attia (peterattiamd.com) [4:00]

**Previous episodes of The Drive discussing the concept of “strong convictions, loosely held”**: [7:30]

- [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/)  | Peter Attia (peterattiamd.com)
- [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/) | Peter Attia (peterattiamd.com)

**Seinfeld episode where George thinks of a “great” comeback he wish he would have said**: [The Jerk Store Called | The Comeback](https://www.youtube.com/watch?v=OfxEvW3jihI) | Seinfeld (youtube.com) [12:15]

Episodes of The Drive discussing GLP-1 agonists: [14:30]

- [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/) | Peter Attia (peterattiamd.com)
- [#320 – AMA 64: New insights on GLP-1 agonists (Ozempic, Wegovy, Mounjaro) – efficacy, benefits, risks, and considerations in the rapidly evolving weight-loss drug landscape](https://peterattiamd.com/ama64/) | Peter Attia (peterattiamd.com)
- Or try [searching for “GLP-1” on the website](https://peterattiamd.com/?s=GLP-1)

**Episode of The Drive all about the Interventions Testing Program (ITP)**:  [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Peter Attia (peterattiamd.com) [15:15]

**SELECT trial using semaglutide (Ozempic/Wegovy) which showed a 20% reduction in major adverse cardiovascular events (MACE), including cardiac death in people with cardiovascular disease, but no diabetes**: [Semaglutide and Cardiovascular Outcomes in Obesity without Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa2307563#:~:text=In%20patients%20with%20preexisting%20cardiovascular,mean%20follow%2Dup%20of%2039.8) (Lincoff et al., 2023) [16:00]

**Evidence that patients who take GLP-1 drugs have an improvement in brain connectivity and cognitive performance, especially in memory tests**: [Exploring the link between GLP-1 receptor agonists and dementia: A comprehensive review](https://pmc.ncbi.nlm.nih.gov/articles/PMC12075970/) (Chuansangeam et al., 2025) [17:15]

**Animal studies have indicated that GLP-1 drugs reduce neuroinflammation and oxidative stress which could certainly contribute to neuroprotective benefits**: [GLP-1 receptor agonists show neuroprotective effects in animal models of diabetes](https://pubmed.ncbi.nlm.nih.gov/29412810/) (Gault and Hölscher, 2018)  [20:00]

The best evidence that cognitive effects might be independent of metabolic effects comes from the few studies that have directly compared GLP-1 drugs against other anti-diabetic or weight loss interventions. So

**The most robust study suggesting that cognitive effects of GLP-1 drugs might be independent of metabolic effects**: [Activation of Glucagon‐Like Peptide‐1 Receptor Ameliorates Cognitive Decline in Type 2 Diabetes Mellitus Through a Metabolism‐Independent Pathway](https://pmc.ncbi.nlm.nih.gov/articles/PMC8483500/) (Li et al., 2021) [20:15]

**Two phase-three clinical trials that are testing semaglutide**: [21:30]

- EVOKE: [A Research Study Investigating Semaglutide in People With Early Alzheimer’s Disease (EVOKE) (EVOKE)](https://clinicaltrials.gov/study/NCT04777396)
- EVOKE+: [Active, not recruiting A Research Study Investigating Semaglutide in People With Early Alzheimer’s Disease (EVOKE Plus) (EVOKE Plus)](https://clinicaltrials.gov/study/NCT04777409)

**Meta-analysis that looked at 13 studies involving GLP-1 receptor agonists looking at the trials that had cardiovascular outcomes in which they reported a 13% reduction in all-cause mortality across the non-diabetic patients with and without a history of cardiovascular disease**: [Cardiovascular and renal outcomes of glucagon-like peptide 1 receptor agonists among patients with and without type 2 diabetes mellitus: A meta-analysis of randomized placebo-controlled trials](https://pubmed.ncbi.nlm.nih.gov/38779187/) (Rivera et al., 2024) [23:00]

**Episode of The Drive which Peter refers to as a “geroscience roundtable”**: [#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Ph.D., Matt Kaeberlein, Ph.D., Richard Miller, M.D., Ph.D.](https://peterattiamd.com/longevityroundtable/) | Peter Attia (peterattiamd.com) [24:00]

**Previous episode of The Drive about rapamycin**: [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [25:45]

**The Wall Street Journal article about SGLT2 inhibitors**: [These Diabetes Drugs Are Finding New Life as an Antiaging Hack](https://www.wsj.com/health/wellness/diabetes-drugs-jardiance-anti-aging-6cc91047?gaa_at=eafs&gaa_n=AWEtsqewngYziDFUSDVT5B0kStKHDtOFa08-l0FG8P2YT_NXw4wLQC6OeiE4WnM1udM%3D&gaa_ts=68fd2eb1&gaa_sig=J9IHnNjtqsVLljk-kjXkTaXDfEBh0fCu7n1mAXU2l_pRTiXIT6KxbidVMVwL-2JniSNqYKJHjKTDJK7dqnmXCQ%3D%3D) | Alex Janin (wsj.com) [27:15]

**Episode of The Drive with Ralph Defronzo about SGLT2 inhibitors**: [#337 – Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.](https://peterattiamd.com/ralphdefronzo/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [27:45]

**Meta-analysis looking at 13 RCTs of SGLT2 inhibitors demonstrated a 24% reduction in cardiovascular mortality in patients with heart failure, a 23% reduction in mortality in patients who were diabetic, a 23% reduction in mortality in patients with chronic kidney disease**: [Effect of SGLT2 Inhibitors on Cardiovascular Outcomes Across Various Patient Populations](https://pubmed.ncbi.nlm.nih.gov/37344038/) (Usman et al., 2023) [28:30]

**Meta-analysis that compared SGLT2 inhibitors to other classes of diabetes drugs, namely sulfonylureas and DPP-4 inhibitors**: [SGLT-2 inhibitors reduce the risk of cerebrovascular/cardiovascular outcomes and mortality: A systematic review and meta-analysis of retrospective cohort studies](https://pubmed.ncbi.nlm.nih.gov/34418562/) (Mascolo et al., 2021) [30:30]

**Meta-analysis of 14 RCTs in patients with chronic kidney disease found that SGLT2 inhibitors were associated with an 11% reduction in all-cause mortality**: [SGLT2 inhibitors, cardiovascular outcomes, and mortality across the spectrum of kidney disease: A systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/39566582/) (Spiazzi et al., 2021) [30:45]

**The ITP study on canagliflozin, an SGLT2 inhibitor, which found a 14% extension of median lifespan in male mice**: [Canagliflozin extends life span in genetically heterogeneous male but not female mice](https://pmc.ncbi.nlm.nih.gov/articles/PMC7710304/) (Miller et al., 2020) [32:00]

**Episode of The Drive with Francisco Gonzalez-Lima where they discussed methylene blue**: [#38 – Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer’s disease treatment and prevention – is AD actually a vascular and metabolic disease?](https://peterattiamd.com/franciscogonzalezlima/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [35:15]

**In vitro studies with methylene blue have shown a pretty increase in mitochondrial complex III and IV activity, and that’s 70% more oxygen consumption and NAD concentration**: [Methylene blue delays cellular senescence and enhances key mitochondrial biochemical pathways](https://pubmed.ncbi.nlm.nih.gov/17928358/) (Atamna et al., 2008) [38:00]

**ITP study of methylene blue which show no difference in median lifespan**: [Acarbose, 17-α-estradiol, and nordihydroguaiaretic acid extend mouse lifespan preferentially in males](https://pubmed.ncbi.nlm.nih.gov/24245565/) (Harrison et al., 2014) [38:45]

**Several studies in rodents have shown that methylene blue can help preserve neurons and cognitive functioning following TBIs or in response to chronically-reduced blood flow to the brain, such as you might see in a stroke**: [40:30]

- [Stelmashook et al., 2023](https://pubmed.ncbi.nlm.nih.gov/36804486/)
- [Auchter et al., 2020](https://pubmed.ncbi.nlm.nih.gov/32508596/)
- [Bachurin et al., 2019](https://www.nature.com/articles/s41598-019-41272-4)

**A small methylene blue trial investigating post-operative delirium in older adults**: [Methylene blue reduces incidence of early postoperative cognitive disorders in elderly patients undergoing major non-cardiac surgery: An open-label randomized controlled clinical trial](https://pubmed.ncbi.nlm.nih.gov/33091706/#:~:text=Conclusion%3A%20We%20conclude%20that%20intraoperative,safe%20for%20prevention%20of%20early) (Deng et al., 2021) [41:00]

**A study demonstrated a reduction in cerebral blood flow and oxygen consumption in humans dosed between 0.5 and 1 milligram per kilogram of methylene blue**: [The effects of acute Methylene Blue administration on cerebral blood flow and metabolism in humans and rats](https://pubmed.ncbi.nlm.nih.gov/36803299/) (Singh et al., 2023) [42:45]

**Main cited evidence that telomere-lengthening supplements slow telomere degradation is highly questionable and based on methodologically weak studies**: [A Natural Product Telomerase Activator Lengthens Telomeres in Humans: A Randomized, Double Blind, and Placebo Controlled Study](https://pubmed.ncbi.nlm.nih.gov/26950204/) (Salvador et al., 2016) [47:30]

**A 2021 meta-analysis in 98 species found only a very weak inverse correlation between telomere length and age**: [Decline in telomere length with increasing age across nonhuman vertebrates: A meta-analysis](https://onlinelibrary.wiley.com/doi/abs/10.1111/mec.16145) (Remot et al., 2021) [51:15]

**In a trial in 70+ year old patients, aspirin did not significantly protect against cardiovascular events, but it did significantly increase the risk of major bleeding events**: [Effect of Aspirin on Cardiovascular Events and Bleeding in the Healthy Elderly](https://www.nejm.org/doi/full/10.1056/NEJMoa1805819) (McNeil et al., 2018) [58:18]

**A trial that looked at non-diabetic patients with high-risk cardiovascular disease factors found minimal reduction in cardiovascular events, but an increase in bleeding events**: [Use of aspirin to reduce risk of initial vascular events in patients at moderate risk of cardiovascular disease (ARRIVE): a randomised, double-blind, placebo-controlled trial](https://pubmed.ncbi.nlm.nih.gov/30158069/) (Gaziano et al., 2018) [59:00]

**Trial in patients with diabetes showed that aspirin did significantly reduce MACE, but the benefit was fully offset by the increase in bleeding risks so there was actually no net protection**: [Effects of Aspirin for Primary Prevention in Persons with Diabetes Mellitus](https://www.nejm.org/doi/full/10.1056/NEJMoa1804988) (The ASCEND Study Collaborative Group, 2018) [59:15]

**Several well-designed RCTs and meta-analyses have converged on protein intake of approximately 1.6 to 2.2 grams per kilogram per day (or 0.8 to 1 gram per pound per day), which is more than 2X the RDA as the optimal level to maximize MPS and muscle hypertrophy**: [1:02:45]

- [Morton et al., 2018](https://bjsm.bmj.com/content/52/6/376)
- [Nunes et al., 2022](https://pubmed.ncbi.nlm.nih.gov/35187864/)
- [Stokes et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29414855/)

**Meta-analyses, including more than 80 RCTs have consistently indicated that muscle protein synthesis doesn’t even begin to plateau until at least 1.6 grams per kilogram per day of daily protein intake**: [A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults](https://bjsm.bmj.com/content/52/6/376) (Morton et al., 2020) [1:03:30]

**Episode of The Drive discussing how not all protein sources are created equal**: [#336 – AMA #68: Fasting, well-balanced diets, alcohol, exercise for busy people, wearables, emotional health, assessing cardiovascular health, and more](https://peterattiamd.com/ama68/) | Peter Attia (peterattiamd.com) [1:04:15]

**Premium article by Peter on the protein-cancer question**: [Do high protein diets increase cancer risk?](https://peterattiamd.com/high-protein-diets-and-cancer-risk/) | Peter Attia (peterattiamd.com) [1:07:30]

**RCTs on dietary protein and cancer progression and survival generally indicate that protein supplementation has a neutral to slightly beneficial effect on survival in addition to clear benefits in mitigating muscle loss and lowering hospitalization rates in patients undergoing cancer treatment**: [Effects of high-protein supplementation during cancer therapy: a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/39631998/) (Orsso et al., 2024) [1:10:00]

**Episode of The Drive with Derek, More Plates, More Dates where they discussed follistatin gene therapy**: [#274 – Performance-enhancing drugs and hormones: risks, rewards, and broader implications for the public | Derek: More Plates, More Dates](https://peterattiamd.com/derekmpmd/) | Peter Attia (peterattiamd.com) [1:13:15]

**Follistatin gene therapy study in mice**: [Follistatin-mediated skeletal muscle hypertrophy is regulated by Smad3 and mTOR independently of myostatin](https://pubmed.ncbi.nlm.nih.gov/22711699/) (Winbanks et al., 2012) [1:17:15]

**Follistatin gene therapy study in macaque monkeys**: [Follistatin gene delivery enhances muscle growth and strength in nonhuman primates](https://pubmed.ncbi.nlm.nih.gov/20368179/) (Kota el al., 2009) [1:18:30]

**Human study of follistatin gene therapy for people with Becker muscular dystrophy, all of whom were treated with that similar follistatin adenovirus vector in the quadricep showing mixed and inconsistent results**: [A phase 1/2a follistatin gene therapy trial for becker muscular dystrophy](https://pubmed.ncbi.nlm.nih.gov/25322757/) (Mendell et al., 2015) [1:20:00]

---

## People Mentioned

- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) [2:15]
- [Damar Hamlin](https://en.wikipedia.org/wiki/Damar_Hamlin) [2:15]
- [Ralph Defronzo](https://directory.uthscsa.edu/academics/profile/defronzo) [27:45]
- [Francisco Gonzalez-Lima](https://liberalarts.utexas.edu/psychology/faculty/fg) [35:15]
- [Magnus Carlsen](https://en.wikipedia.org/wiki/Magnus_Carlsen) [52:45]
- [Derek: More Plates More Dates](https://x.com/Derek_Fitness) [1:13:15]