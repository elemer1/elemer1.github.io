# #227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more

**Source:** [https://peterattiamd.com/ama40/](https://peterattiamd.com/ama40/)

---

In this “Ask Me Anything” (AMA) episode, Peter discusses the importance of understanding body composition and explains how to interpret the most important metrics revealed by a DEXA scan, such as lean muscle tissue mass, visceral adiposity tissue mass, bone mineral density, and more. He discusses common concerning trends in these metrics as well as strategies to address them. He goes through DEXA scan results of both male and female patient case studies and explains the prescribed intervention for each patient. Additionally, Peter answers numerous questions about dietary protein including how much we need, when we need it, and how intake should be divided throughout the day to optimize muscle protein synthesis. Finally, Peter provides his updated point of view on time-restricted feeding and fasting and how his personal approach and recommendations for patients has evolved.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #40 show notes page](https://peterattiamd.com/ama40). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Interpreting DEXA scans: important metrics, radiation levels, and more [2:15];
- DEXA metrics: Bone mineral density (BMD) [12:00];
- DEXA metrics: Visceral adipose tissue (VAT) [14:30];
- DEXA metrics on lean tissue: appendicular lean mass index (ALMI) and fat-free mass index (FFMI) [20:45];
- Concerning trends in BMD, VAT, & muscle mass revealed through DEXA scans [24:15];
- Muscle and lean tissue loss with age and how to overcome anabolic resistance [29:15];
- Female patient case studies: DEXA scan results and prescribed interventions [35:00];
- Male patient case studies: DEXA scan results and prescribed interventions [42:45];
- Protein consumption: recommended daily intake, Peter’s personal approach, timing around workouts, and more [48:15];
- What to look for with protein supplements [53:15];
- Protein intake: optimal timing and how it should be divided throughout the day [55:30];
- Time-restricted feeding (TRF): Peter’s updated perspective [57:45];
- Three strategies for reducing energy intake in over-nourished patients [1:03:15];
- Prolonged fasting: potential benefits and tradeoffs [1:07:15];
- A protein-supplemented version of time-restricted feeding (TRF) [1:09:30];
- Theories about time-restricted feeding (TRF) and its positive influence on sleep and circadian rhythm [1:12:00]; and
- More.

§

The Peter Attia Drive

Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more

§

## Show Notes

§

## Interpreting DEXA scans: important metrics, radiation levels, and more [2:15]

***What is a DEXA scan?***

- DEXA scan is sort of a moving X-ray
- You lay on a table and get a really low-powered X-ray—meaning very little ionizing radiation
- There’s a plate behind the object or the person being X-rayed, and it’s effectively looking at what’s hitting the plate
- The more dense something is in front of the plate, the less electrons that are going to hit the back of the plate

***Is radiation a concern?***

- There’s a unit in radiation that we talk about, and it’s usually millisieverts of radiation, and the more radiation to some extent is harmful
- So the U.S. Nuclear Regulatory Commission (NRC) recommends that a person receive no more of 50 millisieverts in a year,
- To put that in context, just living at sea level is something to the tune of one to two millisieverts per year—maybe 4% of your annual allotment
  - So if you lived in Colorado, where you’re basically a mile above sea level, it’s about twice that amount that you’re getting
- If you look at something like an East Coast to West Coast flight — it would be about 40 microsieverts
- And again, a microsievert is 1/1000th of a millisievert
- A mammogram would be about 400 microsieverts or a 0.4 millisieverts
- Chest X-ray, depending on the size of the individual, maybe 25 to 50 microsieverts
- Conversely, a CT scan of the chest, abdomen, and pelvis could be up to 20 millisieverts, which would be about 40% of your annual allotment
- All that just to put DEXA in context because it is a virtually radiation-free technology comparatively—it’s typically less than 20 microsieverts
- So a DEXA has no more radiation than even the lowest end of a chest X-ray
  - It has 1/20th of the radiation of a mammogram
  - And it has about half the radiation of a cross-country flight

*How often should someone do a DEXA scan? ⇒* This is a type of scan that you would do once, maybe twice per year

***What is DEXA looking at?***

- It has the capacity to distinguish effectively three things: i) bone ii) fat, and iii) other
- Those are basically the three buckets that DEXA is distinguishing based on the density of what the electrons are going through

**DEXA gives you four broad pieces of information**

1 – Body fat

- calculated in two ways, but probably the best way to do it is to take the total amount of fat and divide it by the total mass of the individual. And that gives you percent body fat
- Technically, you can subtract out bone mass when you do that and get tissue fat percent. And by the way, that doesn’t differ very much because bones don’t weigh that much, just in case you’re wondering where that discrepancy can be.

2 – BMD, bone mineral density

- That is both reported in an absolute amount in grams centimeter squared
- And it’s also reported in a z-score
- ⇒ Check out the previous [AMA on bone health](https://peterattiamd.com/ama37/)

3 – An estimate of VAT or visceral adipose tissue

- It’s just an estimate based on looking at the amount of fat that is in the torso, above the anterior superior iliac crest, and the ribs, and kind of trying to subtract out what it believes is in the subcutaneous space, and therefore looking at the difference
- visceral fat is a relatively small fraction of total body fat, but it’s important to get that right because it’s so much more indicative of risk

4 – Appendicular lean mass index (ALMI) and fat-free mass index (FFMI)

- Sometimes it does this directly, it just tells you the appendicular lean mass index, but sometimes you just have to calculate it
- And you can always calculate the fat-free mass index, both of which we’ll talk about
- These are measures of how much lean mass you have or muscle mass in the extremities
- This is always reported as total amount of lean tissue divided by height in kilograms per meter squared
- Both appendicular lean mass index and fat-free mass index, which is just total mass that is not fat, divided by height in kilograms per meter squared
- They’re both reported therefore in kilograms per meter squared

Summary:

- You essentially get those four things from DEXA and you want to see how you stack up against a population
- The population is typically stratified by your sex and by your age, therefore, we have nomograms for each of these things,
- And that’s how we present the data to a patient and that’s how we therefore make decisions about where you rank and what you need to do

**\*Point of clarification when choosing a place to get a DEXA scan**:

- Not every place you get a DEXA scan will give you those exact metrics (BMD, VAT, ALMI and FFMI), but every place will provide the metrics you need to come to the conclusion of that for yourself
- There is one important exception:
  - There are some DEXA places that only give total body z-score for bone, and they don’t break it out individually by hip and lumbar spine
  - You can’t make a diagnosis of osteopenia or osteoporosis, or frankly assess BMD clinically without that feature
  - In other words, if you just look at total body BMD, the z-score for the total body is too easy to mask what’s going on in those areas
  - So if there’s any concern about BMD, you’re going to have to go to a place that is able to give the segmented information

## DEXA metrics: Bone mineral density (BMD) [12:00]

**Overview of BMD**

![](https://peterattiamd.com/wp-content/uploads/2022/10/f1-ama40-1024x547.png)

**Figure 1.** Bone mineral density – male vs. female.

- When you compare male to female side by side, there are differences in what’s considered normal in terms of absolute BMD, which is shown on the left y-axis
  - It’s shown as the actual grams per centimeter squared
- On the right side, you’re seeing the z-score
  - a z-score is your BMD value, subtracting the population mean, divided by the standard deviation
  - A z-score of zero means you’re right at the population mean
  - A z-score of 1.0 means you’re one standard deviation above the mean
  - A z-score of -2.0 means you’re two standard deviations below the mean (and so on)
- The diagnosis of osteopenia and osteoporosis are actually typically made off a t-score
  - The only difference between a z-score and a t-score is, the t-score is made off a younger reference age
- When we get these scores, we pay very close attention to lumbar spine, left hip, and right hip
- We really want to see z-scores above zero.
- For somebody with a z-score below zero (say -0.5), is not necessarily in trouble, but you want to be really aware of that because depending on the age of that person, it’s probably going to be difficult to increase BMD
  - You’ll now really want to make sure you’re in a situation where you’re *preventing* any further decline.

⇒ For more, see [AMA #37](https://peterattiamd.com/ama37/) on BMD

## DEXA metrics: Visceral adipose tissue (VAT) [14:30]

**The difference between visceral adipose tissue (VAT) and total body fat**

- VAT is included within total body fat
- Total body fat is the sum total of all adipose tissue in the entire body (most of which is subcutaneous fat)
- Subcutaneous fat is the place where you want to be storing excess energy—that’s how we evolved and effectively what allowed our species to exist
  - We wouldn’t be here actually if it weren’t for our enormous capacity to store energy in the form of subcutaneous fat
  - we wouldn’t have the brain size that we do if we didn’t have that amount of energy reservoir to allow us to have such a high energy consumption
- However, everybody has a somewhat genetically predetermined capacity for how much energy they can store (everybody has a particular size “bathtub”)
  - And at some point, in the case of excess energy, there’s going to be spillage of water out of the bathtub
  - So if you are net accumulating energy, at some point your bathtub overflows
  - When that subcutaneous area overflows and this excess energy that is the most harmful form of excess energy
- So ***where does that excess energy go***?
  - One of the places it goes is into the viscera, the organs in your abdomen (fat surrounding your organs in the abdomen)
  - Specifically, you also get fat around the pericardium, the heart
  - You get peripancreatic fat within the muscle itself – the droplets of fat that exist NOT between muscle cells but directly in the muscle cells that contributes to insulin resistance
    - Peter [talked about this with Gerald Shulman](https://peterattiamd.com/geraldshulman/)

For the purposes of what the DEXA can tell us…

- It’s really important to get a measurement on VAT because that’s the one that we can capture
- It’s really helpful to understand how little fat you need in that visceral area to start to run into trouble (see figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/10/f2-ama40-1024x712.png)

**Figure 2.**

- Male on the left, female on the right
- On the top of this, you have the nomograms for total body fat, and this is done by percent
- On the bottom, you have the nomograms for visceral adipose tissue
- On the y-axis here, you have total grams

Looking at female lower right

- If a female has 1,000 grams, i.e., 2.2 pounds of visceral fat at the age of 30, she is at the 97th percentile, meaning she has more visceral fat than 97% of the population.
  - she’s therefore at very high risk
- *Why high risk?* ⇒ Well, these extra subcutaneous fat depots are highly inflammatory
  - So when you think about all of the cardiometabolic consequences of adiposity, they are not the result of subcutaneous fat, they are the result of these *extra sources of fat*
  - In other words, it’s not the water in the bathtub that’s killing you, it’s the water that’s leaking out of the bathtub that’s killing you

If you look at the nomogram above…

- Let’s assume a woman who weighs 120 pounds
- Let’s say she’s at the 50th percentile for leanness, she would be about 28% body fat
- So 28% body fat at 120 pounds is about 35 pounds of fat
- So a woman at 30 would be at the 50th percentile for body fat with 35 pounds of fat
- But if just two of those were in her viscera, she’d be at the 97th percentile
- A tiny fraction of what’s in the total pool, **if it’s outside of the actual tub**, *is devastating*

**Is Peter ever surprised by a patient’s VAT?**

Nick asks, “*Are you sometimes seeing a patient male or female who maybe has low body fat, but when you get their VAT back, you’re kind of surprised by how high it is?*”

- “*Yes. And vice versa.*” Says Peter
- An astute practitioner can pretty much eyeball a person’s body fat to probably within 5%, but that’s certainly not true with VAT
- Patients who are relatively thin, i.e., “skinny fat”, their total body fat might only be at the 30th percentile, but their VAT would be at the 90th
- Conversely, Peter has had patients whose total body fat is at the 60th percentile and VAT is at the 10th percentile
  - So that’s an individual where from the standpoint of cosmetics, you want to be leaner perhaps
  - And there might be a lot of other reasons to lose weight such as the orthopedic benefits of weight loss, e.g., less impact on the knee
  - But from a metabolic health standpoint, their obesity is not really contributing to metabolic ill health
- And you can see that one of the metrics is going to be that really low fat

“*So when we roll the results out for patients, without exception, the first thing people want to see is, ‘What’s my total body fat and what percentile does that put me at?’, but we’re much more interested in what the VAT is, and that’s where we tend to draw their attention to*.” says Peter

## DEXA metrics on lean tissue: appendicular lean mass index (ALMI) and fat-free mass index (FFMI) [20:45]

![](https://peterattiamd.com/wp-content/uploads/2022/10/f3-ama40-1024x753.png)

**Figure 3. Appendicular lean mass (ALMI) and fat-free mass index (FFMI).**

- Here we’re looking at both the male and female nomograms for appendicular lean mass index (ALMI) and fat-free mass index (FFMI)
- These are very similar concepts, it’s mass divided by height in kilograms per meter squared
- The ALMI is a more accurate representation of muscle mass because basically it’s saying…
  - how much muscle do you have in your arms and your legs?
  - What’s the mass of that?
  - Divide it by the height in kilograms per meter squared
- FFMI is used equally, but truthfully has some confounders in there because you’re looking at the entire mass of the individual, which includes organs.
  - Therefore, you’re getting a lot of other mass in there that isn’t directly muscle mass.
- There’s a quite strong correlation between FFMI and ALMI, but we do see discordance
  - When we do see discordance, we tend to favor the ALMI
  - In other words, if you see ALMI at the 80th percentile and an FFMI at the 50th percentile, we tend to think that the person is closer to the 80th percentile.
  - The only drawback of the AMLI is you’re not including the muscles of the torso.

When looking at the ALMI and the FFMI, *what percent do you like to see are patients at?*

- Percentiles are percentiles, so they’re all adjusted for age as it is
- It basically comes down to what are their genetics
- There are some people who are never going to be at the 97th percentile for lean mass index
- You can’t really answer that question in a blanket statement because it really depends on the patient’s makeup and obviously on what their goals are
- For Peter personally, he aspires to be at, or above, the 97th percentile at all times

*Are these two metrics typically spit out? Or sometimes, are you having to do a calculation to get these?*

- They are sometimes spit out, but they’re quite easy to do yourself
- Then the ALMI is a little bit more work, but you basically you add up the sum total of lean mass in the extremities and you divide that by the height in kilograms per meter squared
- As long as you get your units right, you’re going to be in the right ballpark

**\*See bottom of Show Notes page for blank DEXA nomograms\***

## Concerning trends in BMD, VAT, & muscle mass revealed through DEXA scans [24:15]

Based on us understanding these metrics and what you think are important, ***what trends are you seeing in your male and female patients on their DEXA scans?***

- An obvious trend is that people tend to lose muscle as they age
- They add fat mass as they age
- And BMD goes down as you age
- So everything’s going in the wrong direction as you age

Therefore, the objective becomes: *During what window of time can we actually increase these things before we get to the point where it becomes very difficult to make increases?*

- Another way to state that is, there’s a point at which decline becomes almost inevitable
- So you want to be as high as you can, going into that phase
- And that’s particularly relevant for BMD

**When it comes to muscle mass…**

“*Find me one example in history where a 90-year-old said, ‘God, I wish I had less muscle. I just wish I wasn’t so strong.’*” says Peter

- So **you simply can’t enter your eighth decade over muscled**
- And therefore, that’s really what we need to do: Add and protect muscle
- Peter says a patient who’s 50 years old, who’s at the 50th percentile for one of the muscle metrics, he’s not “losing sleep” over that
- If they’re at the 30th percentile, he’s not losing sleep over that either because we’re playing a long game
- If you are at that 30th percentile now, *there is a path in five years to get you to the 80th percentile, but you’re not going to get there in a year*
- But this really allows Peter to frame things for patients in the direction of the centenarian decathlon
- Just know that it can take years to see full scale changes on DEXA scans

**Expectations and limitations for DEXA scans**

- Peter discourages patients from ever doing DEXA scans more than twice a year
- You have to accept that there’s noise in this system and if you do DEXA scans on two consecutive days, you’re not going to get the same thing
- Even though DEXA is still what we consider the gold standard, it’s quite dependent on hydration because remember, it’s differentiating bone, fat, and “other” (and water counts as other)
  - It’s important to be cognizant of these things when you do this type of testing.

*Is Peter telling patients to monitor their water intake?*

- We have patients do it first thing in the morning
- And each place will have their own protocol
  - They want you to have not eaten.
  - Don’t have something to drink
  - And don’t exercise because exercise dehydrates you a little, so that would artificially make you look less lean because you would’ve expended water.
- The best you can do here is just try to standardize these things

**Other trends Peter sees in DEXA metrics**

- Other trends really just come down to a person’s athletic history
- People who have a history of resistance training tend to have a higher ALMI and FFMI
- Another thing Peter sees is that people who have restrictive diets tend to be lower in lean mass
  - That’s even true if they’re resistance training
  - The fact is that if you’re really, really restrictive, you’re going to lose lean mass
- Peter does have patients that show up and, by any sort of metric, they’re in a caloric deficit
  - These are people who tend to end up being quite under muscled, and they’re not always that lean either in terms of low body fat
  - The first order term is just calorie restriction, and obviously protein restriction would probably play a disproportionate role there

## Muscle and lean tissue loss with age and how to overcome anabolic resistance [29:15]

In [AMA #39](https://peterattiamd.com/ama39/), they looked at a graph showing how VO₂ max kind of falls off a cliff at a certain point which really spoke to the importance of being as high as possible earlier in life

*What do we know about muscle mass as it kind of relates to that same type of thing? How much does it fall off?*

*Is it something that people do want to be extra cautious about to build muscle while they can*?

“It’s slightly different,” says Peter, “in some ways, it’s better. In some ways, it’s worse.”

![](https://peterattiamd.com/wp-content/uploads/2022/10/f4-ama40-1024x835.png)

**Figure 4.** Source: [Westerterp et al. 2021](https://academic.oup.com/ajcn/article/114/5/1583/6363723)

- The left-hand side is women and the right-hand side is men
- The top is fat-free mass in kilograms
- The bottom is physical activity level
- On the top, fat-free mass, what you notice is between ages 0 and 25, it’s increasing precipitously no matter whether you’re a man or a woman
  - The difference is the peaks—you get much higher as a man
- Regardless, we’re basically on a straight shot up from age 0 to 25
- We kind of stay there till we’re 30 or 35
- Then we begin a slow downward trend from about age 35 to 75
- At age 75, it just drops like crazy
- Here’s what’s interesting…If you look at physical activity level, it also rises significantly to the age of 25, but here it actually stays really flat through 75
- But then at 75, it does the exact same thing as the fat mass does, physical activity just falls off a cliff
- This does beg the question, which one is driving which? Is the decrease in fat mass driving the reduction in physical activity level? Is the reduction in physical activity level driving the loss in fat-free mass?
  - Peter thinks these are bidirectional, meaning they’re both impacting each other, and it becomes a vicious cycle
  - There’s no age at which we wouldn’t still put a lot of resources into this, says Peter

**Anabolic resistance**

- Peter has this sense this urgency because he is aware of this concept of anabolic resistance
- It’s a very important idea, which is, what are the factors?
- Nutritionally, from an energy signaling standpoint, inflammatory-wise, what are these figures that are contributing to the huge difficulty at anabolic gains?
- By anabolic gains, he means putting on muscle mass once you reach a certain age

*How do you overcome this anabolic resistance before time makes it a very difficult problem to solve?*

*Is there a rough age that you see with patients where if they haven’t taken putting muscle on seriously, you really put fuel to that fire because their window to do it is shorter?*

- The reality is if you’re a 30-year-old woman in Peter’s practice, he’s grinding you to put on muscle mass
- Now, the difference is that a 30-year-old woman or as a 30-year-old man might not perceive the urgency that Peter is trying to give you because the reality of it is that things are fine at the current moment
- Analogy: It’s sort of like telling the 30-year-old, “Come on, you got to be saving 15% of your paycheck for retirement.” And they’re kind of like, “Ah, how about I save 5%? This extra 10%, I’d rather spend it now.”

Whereas if someone’s 65 and they can sort of do the math and say, “I’m not on pace for retirement. Yes, I will happily save 15 to 20% of everything I’m making for the next 10 years.”

- Therein lies the challenge of helping people at different ages
- Young people have so much more time to make the difference, to make the changes but so much less urgency
- The older person doesn’t have the runway, but they have the drive and the purpose
- The sweet spot for urgency and runway is probably people in their late 40s and 50s—that’s where you get the confluence of those two curves

## Female patient case studies: DEXA scan results and prescribed interventions [35:00]

**Patient 1:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/f5-ama40-1024x558.png)

**Figure 5.** Patient 1 (31 year-old female).

*Details about this patient*:

- 31-year-old female
- Z-score of -0.8 and it’s about the same in the right femur and in the lumbar spine
  - This z-score is a “red flag” for Peter, because if they continue at this pace as they age, if they don’t move their bones in the right direction, they’re going to be osteopenic
  - Fortunately, she is young enough that she actually has some malleability left in her bones (probably got another 15 to 20 years of endogenous estrogen production)
  - And given that she’s not really doing any strength training, there’s an opportunity here
- Overall: This is a patient who is relatively fit, but she only does “non-specific training”
  - Her body fat is about 32% (60th percentile)
  - Her VAT is also around 32% which is about the 80th percentile (much more important to Peter than body fat)
    - This is roughly 400 to 450 grams of visceral fat — so about 1 lb
  - Her ALMI is quite low (40th percentile) so it’s about six kilograms per meter squared
  - Her FFMI is slightly better than that (65th percentile)
  - But remember, when these are ALMI and FFMI are discordant, Peter puts more weight on ALMI
- The implication in this patient’s case is that she is **overnourished but under muscled**
  - That means she needs energy restriction but protein advancement and strengths training

*The program for patient 1*: To **reduce intake** but **increase protein** and **increase resistance training**

- This is a more difficult dietary intervention compared to increasing energy intake and increasing protein
  - The intervention that’s in between those two in terms of difficulty would be just energy restriction in a person who has lots of muscle mass to spare, and you’re okay if they give up a bit
- Patient 1 is a case where trainers/doctors often miss the subtlety of that fact that if you just go energy restriction on this person, you’re going to lose muscle mass
  - And in a year, she’ll have lost total body fat, but her percent body fat will be about the same.
  - In other words, she’ll still be about 30% body fat, but she’ll be lighter and she’ll have lost lean tissue at about the same rate that she lost fat

> “Every time I look at a DEXA scan, I’m asking that question: ‘Are you overnourished, undernourished, adequately muscled, under muscled?’” —Peter Attia

- You can think of the DEXA results putting patients into a 2×2 matrix
- Where they fall dictates the training/eating strategy.

—

**Patient 2:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/f6-ama40-1024x579.png)

**Figure 6.** Patient 2 (45 year-old female).

*Details about this patient*:

- 45-year-old woman
- Z-scores:
  - -1.2 in her left femur
  - L spine is -0.6
  - So she’s already got osteopenia
  - A very important question is, what’s the family history? ⇒ Because “If I know that her mom has osteoporosis, I mean, that’s a four alarm fire at this point, even though she’s only 45”
  - So this patient is on a trajectory we want to be able to correct
  - She’s also coming up to the end of her endogenous estrogen production, so this is when we have to start having a discussion about HRT
- Other stats:
  - When you look at the rest of her DEXA, it’s crystal clear that this is a woman who’s never lifted anything heavy in her life
  - Her total body fat is 19% (about the fifth percentile)
  - Her VAT is barely measurable, it’s below the 10th percentile
  - But here’s the problem: Her appendicular lean mass index (ALMI) is at the third percentile and her fat-free mass index is at the 10th percentile
  - She’s clearly **undernourished** and **under muscled**
- The program:
  - Here we have a slightly easier problem to solve conceptually, though operationally and psychologically, it can be difficult
  - This is an individual who is probably consuming less than she ought to be—”it wouldn’t surprise me if this person weighs 110 pounds and eats 40 grams or 50 grams of protein a day”
  - So they’re simply not coming close to their nutritional requirements
  - This is a person who’s doing lots of yoga and some cardio, but they’ve never done any form of resistance training

## Male patient case studies: DEXA scan results and prescribed interventions [42:45]

**Patient 3:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/f7-ama40-1024x553.png)

**Figure 7.** Patient 3 (42 year-old male).

*Details about this patient*:

- 42-year-old male
- overweight, kind of stocky
- BMD is not an issue
- Body fat is 30% (awfully high for his age—puts him at about the 90th percentile)
- So he’s clearly overnourished
- His VAT is also at the 50th percentile—so it’s not as high as his body fat percentile is, but it’s still much higher than we want
- This is just another great example of how you don’t need that much fat in this area to start to cause trouble
- He’s only got 2.2 pounds of fat in his viscera, whereas on his 200-pound frame, he’s got 60 pounds of fat
- So he’s got 60 pounds of total fat in his body of which two pounds is visceral
- And both his ALMI and FFMI are in the 90th percentile or above
- He was a high school/college athlete, but he’s not really exercising that much today

**The situation**: he’s overnourished but he’s adequately muscled

**The intervention/treatment**: Here the treatment is energy restriction without protein restriction

- He’s going to implement lots of training
- The training is going to be the right balance of both cardio and strength training
- We’re going to be less concerned with a little bit of a loss of lean tissue and would expect a bit of lean tissue loss in this individual
- He’ll be able to stay above the 75th percentile in lean muscle mass while he loses significant adipose tissue and visceral adipose tissue
- Once he gets to a new baseline, he can slowly work to rebuild lean tissue
- Note that muscle mass and body fat can move independently, but it does take some time to do it especially in the case of adding lean muscle without adding too much fat

—

**Patient 4:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/f8-ama40-1024x546.png)

**Figure 8.** Patient 4 (55 year-old male).

*Details about this patient*:

- 55-year-old male
- Visibly lean
- Good bone mineral density
- Body fat’s about 18%, which for his age puts him at about the 15th or 20th percentile
- His VAT is also very low at about the third percentile
- His ALMI is at the 12th percentile and his FFMI might be at the 30th percentile.

**The situation**: This is a guy who I don’t feel like we need to add energy to, he’s just under muscled

**The intervention/treatment**: Increase his protein to probably a gram per pound of body weight, and not pay much attention to what else happens with it, and train

- Again, there’s a whole separate discussion about how you would do this without just completely adding too many calories
  - In other words, if you’re trying to add 80 grams of protein, that’s only 300 calories
  - But you could very easily add another 500 calories to his intake, if you’re not thoughtful about where that protein comes from in terms of its sources
- The biggest issue here though is going to be adding muscle mass
- The crux is *how do you add muscle mass without adding extra fat?*
  - It’s going to really come down to the training and the sources of protein.

## Protein consumption: recommended daily intake, Peter’s personal approach, timing around workouts, and more [48:15]

**Protein intake needs**

- What’s been clearly established is that the RDA recommendation, the 0.8 grams per kilogram of body weight, is completely incorrect
  - That’s sort of the minimum dose to not wither away, but there’s nothing optimal about that
- The correct answer is somewhere from **1.6 to 2.0 grams per kilogram of body weight**
  - Over time, that need can increase
  - Kids can get away with less than that
  - For someone who’s really obese and has a really high amount of body fat, someone with 35-40% body fat, Peter might modify the recommendation to either two grams per kilogram of *lean weight* or two grams per kilogram of *target weight*

***So how does Peter go about eating that much protein in a day?***

- First of all, Peter is trying to divide it into four portions
- Those four portions work out to be a minimum of 160 grams per day for Peter
- Ideally, he eats closer to 180 grams

*Protein should be spread out throughout the day*

- The evidence is pretty reasonable that you cannot assimilate that much protein into lean tissue if you consume it all at once
- Peter’s interpretation of the literature is that 40, 50, maybe up to 60 grams of protein in one sitting can be put to non-metabolic use, meaning non-energy use
- Therefore, he strives to hit 40 to 50 grams four times a day

*How he actually gets that in*:

- First serving is a protein shake using super high-quality whey protein (50 g) mixed with almond milk or cashew milk and frozen berries
- Second serving is typically a wrap or a sandwich ensuring to consume 40 grams of protein in the form of turkey or black forest ham or something like that.
- The first two servings he tries to get in before 1pm
- The third serving is usually a pre-dinner snack of venison or elk jerky
  - [Maui Nui Venison](https://mauinuivenison.com/) makes those bars that are basically pure venison
  - Another company called [Carnivore Crisps](https://carnivorecrisps.com/) makes exceptional quality jerky
  - Alternatively, he might make scrambled eggs or an omelet (or leftovers from the night before)
- His final serving is the easiest one because it’s dinner which usually consists of elk or salmon or venison

Notes and tips:

- You can’t discount the importance of that first one of the day
- That first one is a really important one in terms of appetite regulation
- And that one right after the workout is also pretty important, especially if you’re untrained

Nick asks *whether the first protein serving is pre-workout and whether the second one post-workout?*

- Depends on the workout, says Peter
- If he’s doing an early morning cardio workout, he won’t consume protein prior
- What about if he’s doing strength training early in the morning?
  - Having his first protein prior to lifting weights is “not necessary for the lift” because “there is no nutritional state you can put yourself in to prevent the catabolism during a hard lifting session”
  - It’s probably more the meal after that’s going to help
- Think overall protein vs. timing
  - Think more about the day at the macro level as opposed to, *how do I eat enough protein directly before or after a workout*?
  - The more experienced you are in training, the more you can undergo muscle protein synthesis in a longer window post-training event.
    - In other words, you have less urgency around the timing of your protein

## What to look for with protein supplements [53:15]

***How do you think about sugar in protein supplements?***

*If a patient has a diagnosis of diabetes or prediabetes, do they look at it different?*

- It’s just not necessary to have sugar in protein supplements
- Peter uses four different types of whey protein (none with sugar) to make his shakes and he always uses two at a time
- He’s usually combining a flavorless one with a flavored one (which uses a small amount of sucralose)  — he’ll do 25 grams of flavorless with 25 grams of flavored
- He does this to dilute the taste because he doesn’t like it to be very sweet

> “*We want to strip out everything gratuitous. We want our protein sources to be as lean as possible and as free from unnecessary refined sugars as possible too*.” —Peter Attia

**Nutrient labels**

- The nutrient label tells you all you need to know both in terms of protein quality (See [convo with Layne Norton](https://peterattiamd.com/laynenorton2/))
- Layne talked about how you don’t want proprietary blends
- You don’t want nitrogen spiking, meaning you don’t want individual amino acids being the ingredients
- You want a high-quality whey isolate
- And basically, you don’t want it to have a whole bunch of fat and carbohydrates in them
  - For Peter’s whey protein supplements, for example, for every scoop of 25 grams of protein, there might be one to two grams of fat and four to five grams of carbs with it

## Protein intake: optimal timing and how it should be divided throughout the day [55:30]

***How many different meals throughout the day it should protein be broken up to get the needed daily amount?***

Peter does it over four sessions throughout the day, but *is it possible and/or okay to get that over 8 meals or 2 meals?*

- In the [podcast with Don Layman](https://peterattiamd.com/donlayman/), we learned that there’s a “Goldilocks area” here
- If you consume too little protein, say 10 grams in a serving, you’re probably not putting that protein to use the way you want it to—it’s probably going more towards gluconeogenic substrate to make glucose

> “We don’t want to be consuming protein for energy purposes at all. We want to be consuming protein for muscle protein synthesis.” —Peter Attia

- So eating ten 10-gram servings a day of protein is not optimal
- Similarly, eating one mega dose is also not optimal
- If the data suggests 40 to 60 grams is the most you can put to use, then consume 40 to 60 grams
- For some people, they only need about three servings a day
- For others, it might be five servings a day, depending on the size of the individual

**CGM and protein**

*Is there anything you’re looking at around CGM use with you or your patients when consuming protein to see?*

*Are you monitoring spikes?*

*Do you care if there’s spikes? Or is it more so you’re optimizing just purely to get the protein in?*

- You might see a little bit of a spike, but it’s just not really a concern
- Yes, if your shakes don’t have a lot of other stuff in them, this isn’t really going to be a problem for glucose homeostasis

## Time-restricted feeding (TRF): Peter’s updated perspective [57:45]

**Peter’s evolving opinion on time-restricted feeding**

One of the questions that came through was regarding whether time-restricted feeding has benefits beyond caloric restriction:

*Do we have any new studies that have talked about time-restricted feeding that have investigated this, that you’re looking at or that you’ve been monitoring?*

**The** [**recent study**](https://www.nejm.org/doi/full/10.1056/NEJMoa2114833) **that came out this year in the New England Journal of Medicine**

- It looked at caloric restriction with or without time restriction in weight loss
- This was done in a Chinese population
- Both groups are obese, their BMIs were about 31%
- They were both put on a 25% caloric restriction
- Effectively, these patients were eating the same macros and the same total number of calories
- One group was given very explicit instructions to only consume the food between 8:00 and 4:00 PM (an 8-hour feeding window)
- Both of these groups were given the same energy intake, and it was relatively hypocaloric
  - 1,500 to 1,800 calories a day for the men
  - 1,200 to 1,500 kcal for women, similar distribution of macros, et cetera
- The only difference between the groups now was that the controls could eat whenever they wanted, and the time-restricted group was eating in an eight-hour window from 8:00 AM to 4:00 PM.

The question was, *what was the change in weight loss at 12 months?*

**Results**: There was no statistical significant difference

- The TRF group lost 8 kilos
- The calorie restriction group was 6.3 kilos
- But there was no statistical significant in the difference between those two
- Admittedly, that’s because this was powered to 90%, and it was expecting to see a 2.5 kilogram difference
- So the study was powered to look for a two and a half kilo difference.
- So it’s possible that had this study been powered to 80% or had this study had a greater sample size, that it would’ve hit statistical significance
- But based on how this study was done, it does not appear that there really was a difference

![](https://peterattiamd.com/wp-content/uploads/2022/10/F9-ama40-1024x445.png)

**Figure 9.** Weight loss stats from Chinese study. Source: [Liu et al., 2002](https://www.nejm.org/doi/full/10.1056/NEJMoa2114833)

- On the left is the absolute change in body weight, as measured by kilograms, over this 12-month study
- And then on the right, you’re looking at the relative change in body weight as a percent of body weight
- The dark blue line is the time-restricted eating group
- The gray line is the direct caloric restriction group
- For all intents and purposes, they are consuming the same amount of energy, just one group is consuming it in an eight-hour window
- To the naked eye, there really doesn’t appear to be any difference here

**Plateau in weight loss**

It’s also interesting when you look at this to see the amount of weight loss that happened in the first four, five months, and then the level off. And then in the 11th and 12th month, even in both groups, you saw kind of a slight uptick again in weight

*Why does that happen? Why is it that weight loss is initially very rapid and then tends to plateau?*

- A lot of this has to do with the compensation to lower body weight
- Our energy expenditure goes down as our intake goes down
- That’s why losing weight is not the hardest problem in the world, but keeping weight off is a challenging problem

One of the things that you want to look at when you look at this study is, what was the feeding window for the ad lib group?

- The people who were able to eat whenever they could eat, what was going on?
- In this study, they were eating over about 11 hours (plus or minus one hour) for the ad lib feeding window for the control group versus the strict eight hours that was the feeding for the other group
- Some opponents of this study have suggested that, “Hey, that’s not really indicative of American behavior because Americans are probably eating over a much broader feeding window”
- In other words, maybe there wasn’t as much discrimination between the two groups in this study

***Is there something special about a reduced eating window?***

“*You can tell, I just am not particularly sold on this idea that time-restricted feeding under isocaloric conditions is magical*.” says Peter

- In other words, Peter ponders whether
  - A) there is something magical about isocaloric time-restricted feeding that results in weight loss or improvement in metabolic parameters? Or
  - B) is it simply one of three tools, as I describe them, to achieve an energy deficit?
- Peter currently believes it’s the latter (B)

## Three strategies for reducing energy intake in over-nourished patients [1:03:15]

If you’re in the over-nourished camp, we have to reduce energy intake and there are **three broad ways to do that:**

1 – The first way is direct caloric restriction

- Which means if you’re consuming 3,000 calories a day right now, we’re going to cut that down to 2,500 calories per day. We’re not going to pay attention to when you eat those calorie
- We’re not even really paying attention to what those calories are, but there’s going to be an energy deficit.
- So that has the advantage of being agnostic to when you eat and agnostic to what you eat
- It has the challenge of being more complicated with monitoring all your intake

2 – The second strategy to reduce intake is dietary restriction

- This basically means “make something a bogeyman, and never eat it”
- The more ubiquitous the bogeyman, the more you’re going to be restricting energy on the basis of fewer and fewer food choices
- “*I’ve yet to meet a person who went on a carnivore diet who didn’t lose a ton of weight. And I have to believe that, ultimately, they’re just eating less because you can only eat so much meat*.” says Peter
- What all these diets (carnivore, paleo, vegan, etc.) have in common is they’re restricting something
- The dietary restriction approach effectively means: we’re going to restrict something but we’re not going to limit when you eat or even explicitly talk about how much you can eat
- But by restricting something that you can eat, you’re going to default in to eating less.

3 – The final way is time restricted feeding (TRF)

- - This means we’re not going to ask you to count how many calories you’re eating and we’re not even going to tell you what not to eat
  - We’re just going make the window in which you eat narrower and narrower
  - And if we make that window small enough for most people, they will probably eat less
  - Important points about TRF:
    - It’s not clear that an eight-hour window is really sufficient to achieve that a deficit
    - And while something like a one-hour window is likely to achieve a deficit, the big trade off is protein—it’s very difficult to get your total amount of protein in one meal And even if you do, you likely can’t put it all to use

- But, *is there an autophagy benefit to TRF*?

- - we have zero evidence that avoiding food 16 hours a day induces autophagy
  - you’d need to go with at least three days without eating to see biologically and clinically relevant amount of autophagy

> “*I will really steer people away from time-restricted feeding unless two things are true: They’re heavily over nourished and they’re adequately muscled. Other than that, I think it’s a fraught strategy.*” —Peter Attia

## Prolonged fasting: potential benefits and tradeoffs [1:07:15]

In the past Peter has talked about his three-day and seven-day fasts — *Is he currently doing any of these types of prolonged fasts?*

- He’s not.
- He is focused on lean mass and strength at the moment
- It’s probably been 18 months since he did a prolonged fast
- Peter is hoping/assuming that the rapamycin he takes is achieving some of those benefits

*If you have a patient who is over nourished and adequately muscled, would you be looking at fast differently for them, like the three or seven-day fast? Or is it still you’re equally worried about the amount of protein they could get?*

- Peter says he doesn’t view fasting as a weight loss strategy because you’re going to gain the weight back once you stop
- If you don’t eat for three days, within two days after, you have all that weight back
- There’s some exceptions to that…maybe there’s a few patients where doing a three-day fast once a month, coupled with enormous TRF and caloric restriction on the other 27 days, was part of the overall strategy
- “*But for the most part, I don’t really want people to think about fasting as a weight loss strategy*” says Peter

If we’re going to make the case to do a fast, the case based on purging senescent cells, autophagy, all sorts of things…

- Then we have to acknowledge, we’re taking a bit of a leap of faith. We don’t really have biomarkers for any of these things. So it’s hard to make a great case for them.
- A lot of biomarkers get better when you fast, but you don’t need to be fasting to get those benefits.
- Your triglycerides, glucose, insulin, they all get better during a fast, but you don’t have to do something as extreme as fasting to make those things happen
- The biomarkers (or the biological measurements) that really matter, we can’t measure yet. Hence, this leap of faith is necessary.

*Do you think we’ll ever get to a point where we can measure those things through biomarkers?*

- I do. Yeah, for sure.
- the field of metabolomics will be able to unlock a lot of this stuff, combined with proteomics as well
- proteomics and metabolomics will, with a reasonable amount of computing power which already exists, it’s really just a question of doing the studies. So yeah, I see this happening in the coming decade for sure.

## A protein-supplemented version of time-restricted feeding (TRF) [1:09:30]

***What about the people who are having great success with TRF? Should they stop?***

- Peter says: “*I don’t want to be the anti-TRF guy anymore than I would want to be the pro-TRF guy.* ***You got to be agnostic to this stuff.***”
- Analogy: You want to be the contractor who’s got every single tool. You don’t want to be the guy who’s just got the hammer. Even if you’re the best guy with a hammer, you don’t want to be that guy. You can’t build a house with just a hammer.
- That said, if TRF is working for you according to all metrics that we have available, by all means, stay with it.
- Worth noting that there are ways to do TRF a little more intelligently, such as using protein outside of the feeding window
  - For instance, if you really want to do an 18/6 feeding window where you’re just committed to eating two big meals between noon and 6:00 PM…
  - Peter would still encourage you to consume a protein shake that is otherwise relatively low calorie outside of that window
  - “*I just don’t see that that is impairing the purpose of the fast, which again is really energy restriction. That’s really why we should be thinking about TRF*.”

## Theories about time-restricted feeding (TRF) and its positive influence on sleep and circadian rhythm [1:12:00]

*What about the theories around time-restricted feeding and what they can do to influence circadian rhythms?*

- We have to acknowledge the limitations of this research
- A lot of the research on circadian rhythms comes from studying rodents, and there’s a number of things about that that are very problematic when we try to extrapolate to studying us
- 1 – Not eating for a given period of time for a rodent is completely different than a human
  - Most mice would be dead in two days without any nutrition but here’s not a human on the planet outside of maybe an infant who wouldn’t survive just fine without food for two days
  - When we start to think about time-restricted feeding studies on mice that are going 16 hours without eating and then eating for eight hours, that tells me nothing about a human
- 2 – Mice and rodents in general are nocturnal so they have a different sleep cycle than we do

**Food and sleep**

- All that said, Peter does think there’s something to be acknowledged between the relationship between food and sleep
- “*There’s no circumstance under which I think it makes sense to be eating right before bed*” says Peter

If you go back to that [New England Journal of Medicine paper](https://www.nejm.org/doi/full/10.1056/NEJMoa2114833)…

- The feeding window of 8:00 to 4:00 PM is pretty good eating window
- That window was picked because it was done in a Chinese population who traditionally have their largest meal in the middle of the day
- Frankly, says Peter, that’s a healthier way to eat, if we could socially bring ourselves to do it
- There’s no upside to eating your biggest meal at 9:00 PM and then going to bed at 10:00 or 11:00 because you’re then going to see higher glucose levels at night, higher cortisol levels at night, and you’re going to see less regulated sleep

There’s some [animal data](https://pubmed.ncbi.nlm.nih.gov/29238290/) in mice looking at the glymphatic system

- The glymphatic system removes metabolic waste (which includes glucose and advanced glycation end products)
- This is a system that’s very active at night when you’re sleeping and animal models suggest that the lower the glucose concentration in the CSF, the more effectively this system works
- Translated, the less glucose in your blood, the less glucose in your CSF, the less glucose in your CSF, the more effectively the glymphatic system will remove metabolic waste products
- You could make an argument that you’re better off having lower (normal) blood glucose at night than having very high blood glucose at night
- Therefore, that’s another argument that says, “***look, regardless of how we’re telling a patient to eat, sleep is very important. And we really would like to see people not eating within ideally three hours before bed***.”

*What about alcohol close to bedtime?*

- the bigger issue with the alcohol, it’s not really going to be contributing much to glucose levels, but it’s certainly going to be contributing to aldehydes and things that are going to be highly disruptive for sleep
- there’s no upside to consuming anything than a little bit of water in that three-hour window before bed

§

## DEXA Nomograms (blank)

**Total Body Fat:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/Fa-ama40-1024x370.png)

**Visceral Adipose Tissue:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/Fb-ama40-1024x353.png)

**Appendicular Lean Mass Index**:

![](https://peterattiamd.com/wp-content/uploads/2022/10/Fc-ama40-1024x433.png)

**Fat-free Mass Index:**

![](https://peterattiamd.com/wp-content/uploads/2022/10/Fd-ama40-1024x428.png)

**Bone Mineral Density (Lumbar spine)**:

![](https://peterattiamd.com/wp-content/uploads/2022/10/Fe-ama40-1024x289.png)

**Bone Mineral Density (Femur)**:

![](https://peterattiamd.com/wp-content/uploads/2022/10/Ff-ama40-1024x284.png)

**Z-score (Normal Distribution Curve):**

![](https://peterattiamd.com/wp-content/uploads/2022/10/Fg-ama40.png)

§

## Selected Links / Related Material

**Previous podcasts that discussed DEXA scans:**

- [AMA #17](https://peterattiamd.com/ama17/)
- [AMA #27](https://peterattiamd.com/ama27/)
- [AMA #37](https://peterattiamd.com/ama37/)

**The Drive episode: First edition of the “Strong Convictions, Loosely Held” episodes**: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/) | Peter Attia (peterattiamd.com) [3:30]

**AMA #37 on bone health**: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/) | Peter Attia (peterattiamd.com) [8:45, 12:15, 25:15]

**Episode of The Drive with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [16:15]

**AMA #39 which focused on exercise**: [#223 – AMA #39: The Centenarian Decathlon, zone 2, VO2 max, and more](https://peterattiamd.com/ama39/) | Peter Attia (peterattiamd.com) [29:15]

**Peter likes jerky from Maui Nui as a high protein snack**: [Maui Nui Venison](https://mauinuivenison.com/) [51:00]

**Another high protein snack Peter likes**: [Carnivore Crisps](https://carnivorecrisps.com/) [51:00]

**Episode of The Drive with Layne Norton (Part 2)**: [#205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)](https://peterattiamd.com/laynenorton2/) | Peter Attia (peterattiamd.com) [53:00, 55:00]

**Episode of The Drive with Don Layman**: [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) [53:00, 56:00]

**The Drive episode: Second edition of the “Strong Convictions, Loosely Held” episodes**: [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/) | Peter Attia (peterattiamd.com) [57:45, 1:12:00]

**Chinese study looking at weight loss in humans doing calorie restriction with or without time restriction**: [Calorie Restriction with or without Time-Restricted Eating in Weight Loss](https://www.nejm.org/doi/full/10.1056/NEJMoa2114833) (Liu et al., 2022) [58:15, 1:13:15]

**Animal data that looked at intermittent fasting and the glymphatic system**: [Intermittent Fasting Protects against Alzheimer’s Disease Possible through Restoring Aquaporin-4 Polarity](https://pubmed.ncbi.nlm.nih.gov/29238290/) (Zhang et al., 2017)[1:13:45]

§

## People Mentioned

- [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/) [16:15]
- [Layne Norton](https://twitter.com/BioLayne) [53:00]
- [Don Layman](https://fshn.illinois.edu/directory/dlayman) [53:00]

§