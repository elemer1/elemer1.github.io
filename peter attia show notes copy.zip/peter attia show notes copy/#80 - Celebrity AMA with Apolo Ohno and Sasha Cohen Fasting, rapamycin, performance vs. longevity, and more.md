# #80 – Celebrity AMA with Apolo Ohno and Sasha Cohen: Fasting, rapamycin, performance vs. longevity, and more

**Source:** [https://peterattiamd.com/celebrityama01/](https://peterattiamd.com/celebrityama01/)

---

In this special celebrity AMA episode, Peter answers questions from former Olympians and past guests, Apolo Ohno and Sasha Cohen, on a wide range of subjects including fasting, learning, training for performance versus longevity, and much more. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

We discuss:

- Apolo’s questions begin [1:45];
- Why women may have a harder time fasting, and tips for those who are struggling [2:10];
- Is there any place for fasting as part of a nutritional strategy in adolescents? [6:15];
- Tips for learning and retaining large amounts of new information (and the best nutritional approach) [9:15];
- Must read books of 2019 [14:45];
- If you could only keep a few watches for the rest of your life which would they be? [16:45];
- What workout would Peter do inside a hotel room? [22:15];
- What is Peter’s ultimate gorge meal? [23:45];
- How do you foresee fasting as a mechanism for performance in athletes? [25:30];
- What is driving Peter to strive for excellence? [33:30];
- Sasha’s questions begin [38:40];
- What are you most excited about in the longevity space? [38:45];
- At what point do you see enough data or proof that a new drug, or type of fasting is worth trying it out for yourself? [41:30];
- Is it possible to obsess so much about your health that it becomes a negative stressor? [46:45];
- Which tests are worth doing if you want to be proactive about your health? [48:15];
- Are there any supplements Peter things are beneficial to be taking? [55:15];
- How does Peter’s training differ when optimizing for performance versus longevity? [56:30];
- How does taking testosterone and growth hormone affect performance versus longevity? [59:15]; and
- More.

§

The Peter Attia Drive

Fasting, rapamycin, performance vs. longevity, and more

§

## Show Notes

# APOLO’S QUESTIONS BEGIN

## Why women may have a harder time fasting, and tips for those who are struggling [2:10]

Apolo’s wife

- Apolo and his wife practicing fasting
- Apolo can go up to 7 days pretty easily
- His wife really struggles after 72 hours
- At that point she basically has no energy to even leave the house
- She has no ability to do anything even remotely mentally strenuous

Peter’s thoughts:

- Peter has noticed that his female patients have a tougher time with fasting (and even time restricted feeding)
- He’s not sure why (maybe some evolutionary reasons)

–For people who struggle, Peter progress his patients as follows:

- Once someone is able to consistently do 18 hr fasts with 6 hr eating window
- He then moves them to 1 meal per day
- Next will be a 36 hour fast

Fasting tips from Peter:

- Peter suggests checking glucose levels to get some insight into why he energy might be so low
- Peter says when you feel this crappy, it’s important to not push through
- You also need MORE water than you think
  - When you fast you excrete sodium at a higher rate
  - Secondly, food has water in it so you need to compensate for that
- Don’t cut caffeine for a long fast if you are a big caffeine person

## Is there any place for fasting as part of a nutritional strategy in adolescents? [6:15]

- There may be certain situations where it might make sense
- Such as obese kids, T2 diabetes, NAFLD

But at the same time, one has to be very careful…

- Adolescents are still growing (anabolic mode)
- There is a critical window during which deprivation of food can be potentially harmful
- I’ve certainly seen a subset of people who have eating disorders during adolescence and it sort of imprinted their endocrine system in a way that’s come back to haunt them as an adult

> “My view is that unless you’re an adult, really this isn’t something that should be considered as a regular part of how you eat.”

## Tips for learning and retaining large amounts of new information (and the best nutritional approach) [9:15]

- Apolo is doing an intensive MBA program at Wharton
- He is going to be consuming large amounts of information
- More importantly he needs to retain the information

**What tips does Peter have?**

  **1** Write it down with a pen

- Peter retains info MUCH better when he writes it down on paper with a pen (i.e., not typed)
- He tries to condense and synthesize the information down
- He personally likes paper with no lines (Apolo needs graph paper)

  **2** Small groups where you can quiz each other on conceptual info

- Find good study partners but only 2-4 people
- Peter is particular about his pens (he likes fountain pens, fine liners, certain types of roller balls, and different colors)

  **3** Sleep is crucial for retaining info (so time management is key)

- Hippocampus is sensitive to sleep deprivation
- Cramming might help on a test, but for long-term consolidation of memories you need sleep

**What is your preferred diet for consuming large amounts of information?**

- **Simple answer**: Anything that is going to minimize swings in glucose
- Is fasting helpful?
  - Peter says it’s unclear
  - The literature about fasting and cognitive performance is not that great
  - However, there is tons of anecdotal stuff (e.g., more mental clarity)
  - Peter personally has felt remarkably sharp while in ketosis
- Exogenous ketones
  - Peter says taking a ketone ester could help (as it seems to have helped him in the past)
  - Peter suggests that as something Apolo could try out

**In summary**:

“*If I were in that situation, I don’t think I would fast during that window necessarily. I’d probably do some time restriction and eat a really clean diet that, even if it wasn’t fully ketogenic, it would probably be relatively low carb.*”

## Must read books of 2019 [14:45]

[Am I Being Too Subtle?: Straight Talk From a Business Rebel](https://www.amazon.com/Am-Being-Too-Subtle-Straight/dp/1591848237) by Sam Zell

[Lifespan: Why We Age―and Why We Don’t Have To](https://www.amazon.com/Lifespan-Why-Age_and-Dont-Have/dp/1501191977/ref=sr_1_1?keywords=david+sinclair&qid=1572889003&s=books&sr=1-1) by David Sinclair

[Infinite Jest](https://www.amazon.com/Infinite-Jest-David-Foster-Wallace/dp/0316066524) by David Foster Wallace

## If you could only keep a few watches for the rest of your life which would they be? [16:45]

**Peter’s picks**:

- [Speedmaster Omega 321](https://www.omegawatches.com/en-us/stories/321-is-back)
- [Rolex Daytona](https://en.wikipedia.org/wiki/Rolex_Daytona)
  - Either the 6263 “non Newman”
  - Or the 6240 “non Newman”
- Probably a [Richard Mille watch](https://www.richardmille.com/collections)… one of these:
  - [11-03](https://www.richardmille.com/collections/rm-11-03-automatic-chronograph)
  - [50-03](https://www.richardmille.com/collections/rm-50-03-tourbillon-chronograph-mclaren-f1) (“McLaren”)
  - [53-01](https://www.richardmille.com/collections/rm-53-01-tourbillon-pablo-mac-donough)
- Athletes you have an RM watch:
  - [Odell Beckham Jr.](https://pbs.twimg.com/media/ED9qlQCWsAErLiT.jpg)
  - [Rafael Nadal](https://image.businessinsider.com/5b1d48271ae66218008b4b15?width=1100&format=jpeg&auto=webp)
  - [Bubba Watson](https://amp.businessinsider.com/images/5aca6785f41c7831008b4bb9-750-448.jpg)

**Apolo’s picks**:

- [Patek Nautilus](https://www.patek.com/en/collection/nautilus)
- An [“anniversary” Rolex](https://www.bobswatches.com/rolex-blog/resources/anniversary-rolex-watches.html)
- [Richard Mille watch](https://www.richardmille.com/collections)

## What workout would Peter do inside a hotel room? [22:15]

First, would make sure to have a stability exercise

- [Dynamic neuromuscular stabilization](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3578435/) (DNS) exercises
- On your back, or front, or side working on core activation
- Intra abdominal pressure (IAP)
- “Symmetric cylindrical activation”
- There’s a whole bunch of exercises there, but Peter makes a hybrid one of those

Secondly, a single leg lunge

- So the single leg step back (or step up) lunge
- Or perhaps a single leg “get up” off a low surface

Finally, he’d to handstand push ups

- Put legs up on a wall, but not in a “full stand” position (you don’t need to be under that much stress)
- Peter’s doing this as a scapular exercise (good way to train serratus strength and shoulder stabilizers)

## What is Peter’s ultimate gorge meal? [23:45]

- Peter loves sushi but would find that hard to “gorge” on
- Probably would be a multiple-course italian meal
  - E.g., salad, pasta, meat dish, gelato
- [Curry stir fry](https://www.instagram.com/p/BlgsT4rB0Gr/)
  - “I can seem to eat it in infinite volumes probably because it feels so healthy.”
  - Check out [AMA #5](https://peterattiamd.com/ama05/) for the complete recipe

## How do you foresee fasting as a mechanism for performance in athletes? [25:30]

**Apolo wants to know specifically how fasting might be used in the following manners**:

1. For manipulating testosterone levels
2. For injury recovery/regeneration

Peter’s thoughts on manipulation testosterone:

- In Peter’s experience, his testosterone levels plummets after a 7 day fast
- 95+% percent of the population exists between 5 and 25
- After a fast, Peter is at 4
- He would need to do daily checks to see if there’s a **pulse spike** that you could exploit
- But even if there was… the question is, *would it be clinically significant?*
- Peter thinks testosterone levels have a bigger impact with training (and recovery and growth) versus how much it would matter on the day of a race (outside of very extreme levels)
- **In summary**, he would need to see something more compelling before believing that you could manipulate testosterone spikes to enhance performance in a clinically significant way

Peter’s thoughts on testosterone for recovery and inflammation:

- The literature on inflammation and fasting clearly shows a reduction in inflammation
- Additionally, everybody almost without exception notices that little aches and pains just vanish
- *Is that the autophagy we’re experiencing?* .. “Possibly.”
- So Peter sees fasting as a powerful tool for an athlete (Not unlike the way you probably use an ice bath)

⇒ Now the question is *how do you incorporate it with volume of training?*

- When fasting, Peter notices that i) his top end endurance is lower and ii) he needs more recovery time in between sets and iii) it hurts a lot more to really push himself during those fasts
- Does Apolo think he could have incorporated fasting into his training in his Olympic days?
  - He thinks he could have… he’d probably have done it like so:
    - Do one fast in the preseason
    - Do one or two during the season
    - And do one immediately post-season
- “From an *injury prevention and injury recovery lense*, I think that would’ve **helped immensely**.”

Many Olympians are reluctant to use fasting because they don’t want to mess up their training

- Peter thinks most athletes are over-training in volume and intensity and under training and specificity
- But if people start to realize you don’t need that much volume with better neuromuscular training and less actual stress, you could achieve the same benefits and **therefore you might actually be able to go through better periods of fasting**

**An alternative strategy for athletes**: Hypocaloric feeding with creatine supplementation

- Hypocaloric feeding is where you’re eating 750 to a 1,000 calories per day
- You still could get enough glycogen replacement which is good because that’s probably where the athletes are hurt the most with a water-only fast combined with training volume
- Additionally, Peter would overcompensate with creatine

- If a normal creatine cycle is 5 grams per day, you do 10 grams per day
- So if you’re keeping creatine stores full and getting 100 grams of carbohydrates a day…
- That might be able to ward off a lot of the sort of extreme performance deterioration
- While still getting the benefits of the injury restoration or healing

## What is driving Peter to strive for excellence? [33:30]

**Apolo wants to know what drives Peter do work so hard, to get out of bed in the morning, and to strive for excellence**:

- Paradoxically, Peter considers himself a very lazy person innately
- And this is a tough question because sometimes you don’t really know what’s driving you
- Perhaps you’re just doing something because you’ve always done it and you don’t know the alternative
- One hypothesis Peter has about himself is that he might be striving so hard because he’s worried about the alternative which is hin innately lazy personality might take over so he’s sort of overcompensating

**A love for learning and for teaching**:

> “I am obsessed with knowing stuff. There’s just no denying it.”

- Anytime Peter reads something or is asked a question he doesn’t know the answer to… it is really hard for him to let it go
- Not that this personality trait is great… it’s neither good nor bad, “it just is”
- And so there is probably a whole bunch of neurotransmitters that are involved in the satisfaction he gets from learning something new ⇒ some amount of dopamine that’s making him feel better
- Teaching:  he also enjoys teaching but he doesn’t necessarily know why
- Peter strongly relates to a book by Richard Feynman called [The Pleasure of Finding Things Out](https://www.amazon.com/Pleasure-Finding-Things-Out-Richard/dp/0465023959)

§

# SASHA’S QUESTIONS BEGIN

## What are you most excited about in the longevity space? [38:45]

**Anything that involves mTOR**

*–Why?*

- The [mechanistic target of rapamycin](https://en.wikipedia.org/wiki/MTOR) is a very potent nutrient sensing protein aggregate within cells
- and like all things in biology too much and too little of it can be a bad thing
- But one thing that seems really clear is at least transient inhibition of this nutrient sensing machinery seems to produce a really impressive longevity phenotype

–Rapamycin

- The easiest way to demonstrate the longevity benefits of inhibiting mTOR is with the drug called [rapamycin](https://en.wikipedia.org/wiki/Sirolimus)
- In 2009, the [first study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) unequivocally showed the power of this drug rapamycin in treating normal mice was published
- They were given rapamycin to mice late enough in life that normally you wouldn’t see much of an effect with other types of interventions
- That effect has been demonstrated repeatedly across multiple strains of other mice and all sorts of different animals

–Other ways to target mTOR:

- Fasting is another way to transiently turn down mTOR
- And more drugs are in development for mTOR inhibition

**–In summary**: Peter calls it “the most important target of a longevity strategy”

*Do Peter take rapamycin himself?*

- Yes, for about a year
- Peter, however, doesn’t see anything noticeably improving in his blood work
- Many patients on the other hand see huge improvements such as…
  - Lipids get better
  - Their triglycerides go down
  - Their glycemic stuff gets better
- Dosing:
  - Must be taken intermittently (Peter takes it once per week)
  - Doing it daily doesn’t have the same positive benefits and comes with more negative side effects

–Peter on why he doesn’t see the same list of benefits in his own blood work:

- “*I suspect that people who are metabolically well enough and I probably fit into that category, the benefits it’s having are well beneath the surface of things that we can measure with our current toolkit, which is pretty limited.*”

## At what point do you see enough data or proof that a new drug, or type of fasting is worth trying it out for yourself? [41:30]

**The few things that Peter wants to see**:

**–First**, really convincing animal data

- Across enough animals that it’s not easy to chalk up as just sort of an artifact of one particular species

**–Secondly**, some sort of human clinical evidence of the manifestation

- One end of the spectrum might be…
  - Humans that have a genetic mutation that does something similar to the effect of this intervention have this sort of phenotype and that’s favorable
- On the other end of the spectrum…
  - It could be humans who take a drug for a different reason but have changes in a different area which are intriguing
  - So for example, an SGLT2 inhibitor is used to treat and lower blood sugar in patients with type 2 diabetes but maybe you can see what that drug is doing with respect to this other thing that’s sort of interesting

**–Thirdly**, you’d like to really understand the mechanistic reason this effect is happening

**–Final principle**: *Can I bracket my risk?*

- If you can identify the range of risk and make sure it’s not too high where the benefit may be significant than you can feel better about doing it
- **Example, fasting**… “*with fasting, I don’t think we’re ever going to see a study that will demonstrate the benefits of in terms of longevity of long-term periodic fasting, it’s just too hard to do. . .But again, the risks of these things are incredibly low and we have so much biologic basis to fall back on that I feel more confident doing it. Other things, however, I’d want to see a bit more data before I would sort of decide, oh yeah, well that’s definitely worth doing.*”

***And how do you ensure you aren’t conflating variables?***

- It’s very hard, says Peter
- He will try to reduce confounders when doing self experimenting by making sure the conditions are consistent

**We need better assays to measure nuanced cellular responses to drugs**

- To really get insights into longevity benefits, we need better testings
- “I really wish we would spend a lot more time and resources developing the types of assays that could measure the more nuanced cellular responses of these types of drugs.
- We already have amazingly potent treatments (fasting, exercise, metformin, rapamycin, etc.)
- What we don’t have is tools to really measure how well they work on healthy people in terms of producing longevity
- Why don’t we?
  - The diagnostics business is a really bad business to be in
  - It would require creating a new business model.
  - The business works around creating molecules, not creating tests to measure things like what fasting protocol is best, for example

> “The deeper I get into the science of longevity, the more I am absolutely convinced that nutrition and exercise … are such incredible drugs. They’re so ubiquitous. Like you can do them so often, you can spread that dose across so much.”

## Is it possible to obsess so much about your health that it becomes a negative stressor? [46:45]

**How do people find the happy medium where they are not stressing about their health but also not being totally negligent?**

–Warren Buffet is an example of someone who seems supremely happy emotionally despite apparently eating McDonalds daily and probably not exercising

—*Is it possible that if Buffet ate well and took care of himself, he could be even healthier and more robust?* **Maybe.**

—*Is it possible that if he spent time stressing about how healthy he was, he’d be less healthy?* **It’s possible because certainly one can go too far.**

“*One can absolutely spend too much time obsessing over this stuff [to the point where it becomes an added stressor in their life]*”

## Which tests are worth doing if you want to be proactive about your health? [48:15]

Peter is not particularly interested in measuring things for which he can’t do anything about it

–Example of something he IS interested in:

- There are a handful of genes that pose a risk for disease later in life that I know can’t be changed
- But to know your [APOE genotype](https://peterattiamd.com/ama08/) is in fact useful
- You can’t change it, but you can get insight into your risk of developing Alzheimer’s disease (AD)
- And there are certain things you can do to reduce your risk and/or delay the possible onset of AD
- Exercise plays an incredible role in:
  - [maintaining hippocampal volume](https://www.sciencedirect.com/science/article/pii/S1053811917309138)
  - [maintaining blood flow to the brain](https://www.nhlbi.nih.gov/news/2017/vascular-dementia-exercise-blood-flow-and-aging-brain)
  - controlling metabolic circulating factors that play an important role in the preservation of cognition (like in [this paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5934999/), and [this paper](https://www.alzheimersanddementia.com/article/S1552-5260(18)32980-7/abstract))
- “*So my view is, by knowing that I’m much more empowered to do something about it.*”

–Conversely. . .

- Peter’s not a huge fan of doing mass sequencing of the gut biome because “I don’t know what to do with the information”

> “I think one just has to know in advance before you do a test…’What are the possible outcomes here and how will that affect what I do?’ . . .If you can’t answer that question, I think you’d probably better off not doing the test.”

**Which tests would Peter recommend for someone wanting to be proactive about their health?**

**1 Lp(a) levels**

- Somewhere between 1-8 and 1-12 people have [elevated Lp(a)](https://peterattiamd.com/lpa/)
- It’s the leading cause of *inherited* risk for cardiovascular disease

**2 APOE test**

- To know that you’re in a higher risk version I think should motivate you to work that much harder
- That said, even the lowest risk category doesn’t mean you won’t get it
- See Peter’s [podcast with Richard Isaacson](https://peterattiamd.com/richardisaacson/) for more on APOE

\**A note about cancer screening with a* [*liquid biopsy*](https://en.wikipedia.org/wiki/Liquid_biopsy)

- Only about a year away from liquid biopsies really becoming commercially viable which is a blood test where it’s going to look for circulating DNA or RNA
- It will tell you if you have circulating cancer cells including the cell of origin
- So this comes with some responsibility:
  - Imagine you’ve got a blood test and it came back and said you’ve got circulating breast cancer cells,
  - but your mammogram is normal with no lump in your breast
  - ***What do you do with that information?***

- - - *Would you be able to do molecular imaging?*

- - - *Would you be able to start targeted therapies?*

- - - *Or would it just create a sense of stress and anxiety while you sit there and wait for the next year or two for something to show up on an x ray or a physical exam?*

**How Peter would like to see the future in terms of these types of tests**:

- Rather than a bunch of standalone tests…
- There will be a bunch of stacking tests that will allow us to compensate for false positives and false negatives
- And be coupled also with a very aggressive front line of treatments in the presence of things that are positive

**One other important measurement**: [Continuous Glucose Monitoring](https://peterattiamd.com/kevinsayer/)

- Peter would put a continuous glucose monitor on everybody for at least three months
- It would be incredibly instructive for people to walk around and understand how their glucose levels change with respect to what they eat, how poorly they sleep, when they sleep poorly, and how much their cortisol levels go up, etc.
- For Peter, he sees his glucose spike with stress
- How does that change his behavior?
  - It informs him the need for meditation

> “*That is part of my motivation for learning to detach myself from my thoughts when my thoughts become troubling.*”

## Are there any supplements Peter things are beneficial to be taking? [55:15]

- Peter says about 80% of the population is probably very deficient in EPA and DHA
- These are two very important [omega-3 fatty acids](https://en.wikipedia.org/wiki/Omega-3_fatty_acid) that we get from fish
- So there are certainly some people who eat enough fish that they don’t need to supplement that.
- Data are reasonably compelling that having [high levels of EPA and DHA in your tissue membranes is beneficial](https://www.ncbi.nlm.nih.gov/pubmed/29494205) when supplemented to the right level

## How does Peter’s training differ when optimizing for performance versus longevity? [56:30]

Peter says optimizing for longevity (i.e., being a kickass 90-year-old) compared to being the best at something (i.e., performance) changes how he does things

⇒ *Using bench pressing as an example*:

- If one decided they wanted to maximize the weight they could bench, it probably puts them at undue risk
- Not only potentially dropping the bar on themselves
- But also in terms of how you have to position your serratus, your lats, your hips . . . it puts a bit of undue stress on the body
- And if you’re goal is to extend healthspan, it’s probably not worth the effort/risk

–How Peter does pressing:

- It’s optimized around stability and long-term strength and pliability and very little to do with how much weight he’s moving
- He does single arm isolated floor presses
- He uses a bamboo pole with big springy rubber things on the end and it’s hanging kettlebells off it
- Maybe a total of 80 to 90 pounds
- Given how unstable it is and how much it’s bouncing, it’s a far better exercise because
  - i) it’s not putting a fraction of the stress on my joints
  - ii) And it’s forcing stabilizing muscles to do their work

## How does taking testosterone and growth hormone affect performance versus longevity? [59:15]

**Testosterone**

- Most hormones (e.g., cortisol, thyroid hormone) exist mostly in a U-shaped relationship, but testosterone doesn’t.
- Testosterone is in some ways the easiest drug to give somebody because more is always better **in terms of performance**
- You can’t have too much testosterone in your body if your goal is to do anything that requires strength or speed
- And truthfully, despite all of the fear mongering around drugs, testosterone is a staggeringly safe drug
- Peter has seen athletes who have 10 times the normal level of testosterone floating around in their body and it absolutely helps them perform better, “*but I don’t think it’s helping them live one day longer and frankly at that level it’s probably counterproductive*”

**Growth hormone**

- I view growth hormone as a much more frightening drug than testosterone.
- And while I think growth hormone in the short term probably has enormous performance benefits…
- …I’m not convinced growth hormone has any role in the treatment of longevity
- It might be “anti-aging” in terms of how you look and feel, but it probably comes with a bit more risk than we want (except for a subset of patients who have really low growth hormone to begin with)

> “Growth hormone is probably a great example of how it’s almost always going to improve your performance, I just don’t think of it as a great tool for longevity.”

§

## Selected Links / Related Material

**Must read books of 2019**: [18:15]

- [Am I Being Too Subtle?: Straight Talk From a Business Rebel](https://www.amazon.com/Am-Being-Too-Subtle-Straight/dp/1591848237) by Sam Zell | (amazon.com)
- [Lifespan: Why We Age―and Why We Don’t Have To](https://www.amazon.com/Lifespan-Why-Age_and-Dont-Have/dp/1501191977/ref=sr_1_1?keywords=david+sinclair&qid=1572889003&s=books&sr=1-1) by David Sinclair | (amazon.com)
- [Infinite Jest](https://www.amazon.com/Infinite-Jest-David-Foster-Wallace/dp/0316066524) by David Foster Wallace | (amazon.com)

**Watches Peter likes**: [21:15]

- [Speedmaster Omega 321](https://www.omegawatches.com/en-us/stories/321-is-back) | (omegawatches.com)
- [Rolex Daytona](https://en.wikipedia.org/wiki/Rolex_Daytona) | (wikipedia.org)
  - Either the 6263 “non Newman”
  - Or the 6240 “non Newman”
- Probably a [Richard Mille watch](https://www.richardmille.com/collections) | (richardmille.com)
  - [11-03](https://www.richardmille.com/collections/rm-11-03-automatic-chronograph)
  - [50-03](https://www.richardmille.com/collections/rm-50-03-tourbillon-chronograph-mclaren-f1) (“McLaren”)
  - [53-01](https://www.richardmille.com/collections/rm-53-01-tourbillon-pablo-mac-donough)

**Watches Apolo likes**: [23:00]

- [Patek Nautilus](https://www.patek.com/en/collection/nautilus) | (patek.com)
- An [“anniversary” Rolex](https://www.bobswatches.com/rolex-blog/resources/anniversary-rolex-watches.html) | (bobswatches.com)
- [Richard Mille watch](https://www.richardmille.com/collections) | (richardmille.com)

**Book about the joy of learning**: [The Pleasure of Finding Things Out: The Best Short Works of Richard P. Feynman (Helix Books)](https://www.amazon.com/Pleasure-Finding-Things-Out-Richard/dp/0465023959) by Richard P. Feynman | (amazon.com) [40:30]

**First publication that unequivocally showed the power of rapamycin**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009) [43:00]

**Exercise plays an incredible role brain health**: [53:00]

- *Maintaining hippocampal volume*: [Effect of aerobic exercise on hippocampal volume in humans: A systematic review and meta-analysis](https://www.sciencedirect.com/science/article/pii/S1053811917309138) | (Firth et al., 2018)
- *Maintaining blood flow to the brain*: [Vascular dementia: Exercise, blood flow and the aging brain](https://www.nhlbi.nih.gov/news/2017/vascular-dementia-exercise-blood-flow-and-aging-brain) | (nhlbi.nih.gov)
- *Controlling metabolic circulating factors that play an important role in the preservation of cognition*:
  - [Effects of Physical Exercise on Cognitive Functioning and Wellbeing: Biological and Psychological Benefits](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5934999/) (Mandolesi et al., 2018)
  - [A LINK BETWEEN COGNITIVE FUNCTION AND PHYSICAL ACTIVITY: THE IMPACT OF AEROBIC-STRENGTH EXERCISE IN SENIORS WITH MILD COGNITIVE IMPAIRMENT AND/OR IMPAIRED GLUCOSE METABOLISM](https://www.alzheimersanddementia.com/article/S1552-5260(18)32980-7/abstract) (Schon et al., 2018)

**Lp(a) is the leading cause of inherited risk for cardiovascular disease**: [Understand Inherited Lipoprotein(a)](https://www.lipoproteinafoundation.org/page/UnderstandLpa) | (lipoproteinafoundation.org) [55:15]

**EPA and DHA supplementation can be beneficial to health**: [How does high DHA fish oil affect health? A systematic review of evidence.](https://www.ncbi.nlm.nih.gov/pubmed/29494205) (Ghasemi Fard et al., 2019) [59:00]

§

## People Mentioned

- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) (an extension of Peter’s brain) [4:15, 33:00, 39:00]
- [Apolo Ohno](https://en.wikipedia.org/wiki/Apolo_Ohno) [4:15]
- [Sasha Cohen](https://en.wikipedia.org/wiki/Sasha_Cohen) [4:15]
- [Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [13:00]
- [Sam Zell](https://en.wikipedia.org/wiki/Sam_Zell) [18:15]
- [David Sinclair](https://twitter.com/davidasinclair?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [18:15]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [18:15]
- [Odell Beckham Jr.](https://en.wikipedia.org/wiki/Odell_Beckham_Jr.) (wears an RM watch) [22:15]
- [Rafael Nadal](https://en.wikipedia.org/wiki/Rafael_Nadal) (wears an RM watch) [22:15]
- [Bubba Watson](https://en.wikipedia.org/wiki/Bubba_Watson) (wears an RM watch) [22:15]
- [Richard Mille](https://www.thegentlemansjournal.com/article/richard-mille-story-behind-man-brand/) (watch company called Richard Mille) [23:15]
- [John Dudley](https://twitter.com/nockontv?lang=en) (Peter’s archery coach) [24:45]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [40:30]
- [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett) [50:15]
- [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger) [50:15]

§