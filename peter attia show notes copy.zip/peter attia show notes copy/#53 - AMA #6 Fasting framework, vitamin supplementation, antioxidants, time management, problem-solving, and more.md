# #53 – AMA #6: Fasting framework, vitamin supplementation, antioxidants, time management, problem-solving, and more

**Source:** [https://peterattiamd.com/ama06/](https://peterattiamd.com/ama06/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from readers and podcast listeners. Bob Kaplan, Peter’s head of research, asks the questions. If you’re listening on a podcast player, you’ll be able to hear a preview of the AMA.  If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Vitamin supplementation: Is it necessary if you eat a balanced diet? [2:00];
- Antioxidants: What does current science have to say about antioxidants in food and supplements? [9:00];
- How do you break a fast of more than three days? [17:15];
- Does a morning black coffee break a fast? In other words, does black coffee raise insulin levels? [22:15];
- When intermittent fasting, does the placement of the “feeding window” matter? [25:30];
- Is it better to fast before or after a planned food binge (e.g., Thanksgiving)? [28:30];
- Fasting protocol: Do you have a specific protocol to recommend? [31:30];
- Time management: How do you manage your time between work, family, and your many personal interests? [35:45];
- Problem solving: Can you breakdown your process of problem-solving? [46:45];
- For those looking to gain a better understanding of biochemistry, pharmacology, etc., do you have any good textbooks or (online) resources to recommend? [49:00];
- What are some of your favorite podcasts that you listen to? [51:15];
- What is your favorite animal? [54:45]; and
- More.

§

The Peter Attia Drive

Fasting framework, vitamin supplementation, antioxidants, time management, problem-solving, and more

§

## Show Notes

## Vitamin supplementation: Is it necessary if you eat a balanced diet? [2:00]

- It is tricky, as supplementation is a broad concept:
  - For instance, it would not be required to take vitamins A,C,E under balanced diet circumstances
  - Certain fat-soluble vitamins such as A,E,D,K would not be excreted (in urine) as they are fat soluble
- That’s not to say someone would NEVER benefit from vitamin supplementation
  - In a [previous episode with Chris Masterjohn](https://peterattiamd.com/chrismasterjohn/), Peter and Chris looked at the role of B-vitamins in people that have a variant responsible for [methylation](https://chrismasterjohnphd.com/2019/03/01/start-here-for-mthfr-and-methylation/)
  - In an example using vitamin B6, if high [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) goes away with B6 supplementation, the person likely needed high B6
- There is an issue in saying, “supplementation is a scam if one eats a balanced diet,” and likewise, extreme supplementation (or supplementing biotin levels, for example) is also unnecessary

> “If you’re really eating an awesome diet…exercising really well… sleeping really well… getting lots of outdoor exposure to sunlight…making your own vitamin D, etc.; what’s the difference between you being on theoretically the most optimized supplement regimen versus not? It might be so small that it’s sort of like we’re picking the wrong thing to discuss.” – Peter Attia

- Differentiate deficiency versus supraphysiological doses: Adding up all the foods one should include in an everyday diet, you would turn into the [Stay Puft Marshmallow Man](https://en.wikipedia.org/wiki/Stay_Puft_Marshmallow_Man)
- However, superfoods are ‘super’ if you are deficient in what said food provides:
  - Having zero vitamin C or D is bad
  - But having more vitamin C than needed to produce proline to make enough collagen, or to not get scurvy, is superfluous

**Intravenous (IV) supraphysiological dose of vitamin C for viral and cancer treatments**

- That being said, IV supraphysiological doses of vitamin C (gastric acid in the small intestines does not permit vitamin C absorption in excess) has been used in the treatment of viral infection and cancer
  - In a [previous podcast episode with Dom D’Agostino](https://peterattiamd.com/domdagostino/), he discusses vitamin C use to drive oxidative stress on a tumor as vitamin C is both an antioxidant and a prooxidant, promoting a [Fenton Reaction](https://en.wikipedia.org/wiki/Fenton%27s_reagent#Overview)
- Linus Pauling was a huge supporter of vitamin C megadosing
  - Although based on  a single, placebo control trial, [Pauling’s 1970 study](https://openlibrary.org/books/OL4914696M/Vitamin_C_and_the_common_cold) was one of the first to conclude that megadose vitamin C supplementation addressed viral infection, such as the common cold
  - In a [written correspondence](https://www.science20.com/adaptive_complexity/suck_it_linus_pauling) made public in Richard [Feynman’s book of letters](https://cds.cern.ch/record/1486906?ln=en), Pauling urged his fellow Nobel prize-winning scientist Feynman to megadose vitamin C following an esophageal cancer diagnosis and the malignant tumor removal
  - In a [1970 consolidation of his observational findings](https://www.mv.helsinki.fi/home/hemila/N2017/Ch22_Klenner1971JApplNutr.pdf), Dr. [Fred Klenner](https://de.wikipedia.org/wiki/Frederick_Klenner) records the curative ability of ascorbic acid intravenous megadose treatment for viral and bacterial-infected patients

**Bob’s “supplement adoption lifecycle” theory with regards to observational epidemiology and many vitamins and supplements, using an example of “vitamin X”**:

1. **Early adoption**: A small number of people who are very health-conscious and engage in many behaviors associated with good health — for example, they may far less likely to smoke, more likely to exercise, more likely to have access healthcare, more likely to eat fruits, vegetables, spices, expensive vitamins, avoid soft drinks, eat wild-caught over farmed raised, eat grass-fed over grain-fed, eat organic over conventional foods, prioritize sleep, meditate, and so on —  learn that there’s potentially some health benefit of a substance that can be consumed in the diet or by supplementation — start taking “vitamin X” after learning about some supposed benefits in an online group that shares findings on how to optimize peak performance, health, and longevity (this is a perfect recipe for a healthy user bias)
2. **Strong association**: A prospective and/or retrospective observational epidemiological study reports an inverse association between vitamin X and adverse endpoints (e.g., greater intake of vitamin X is associated with lower all-cause mortality after 10 years of follow-up). This is often reported in a prestigious journal and subsequently reported by the mainstream media, often implying causality (e.g., taking vitamin “X” lowers risk of death)
3. **Widespread adoption**: after learning about the alleged benefits of vitamin X from the news, friends, family, etc., a greater number of people start taking vitamin X, as it is not only reported to be healthy, it’s inexpensive and convenient. These people differ in many ways from the early adopters.
4. **Weak association**: Over time, the newer observational epidemiological studies find that the association between vitamin X and all-cause mortality is not as strong as the earlier studies. Sometimes, the association disappears and/or the results are no longer statistically significant. These newer studies capture more “unhealthy” users (or not just the very health conscious people).
5. **Null (or even negative) finding**: When the observational claims that vitamin X is associated with lower all-cause mortality is tested in a randomized controlled trial (thus, the healthy user bias is controlled for, and confounding and other biases are reduced) it turns out that vitamin X does not lower the risk of death

⇒ A possible [real-life example](https://www.nejm.org/doi/10.1056/NEJMoa1809944)…  recent RCT published in the NEJM reports no significant association between vitamin D supplementation and reduced risk of cancer and cardiovascular disease

- “*It is tempting to dismiss observational epidemiology but it may not necessarily be wrong, or unhelpful, across the board*.”
- “*Sometimes you could argue time of exposure matters, and sometimes observational epidemiology is better at capturing time of exposure [rather] than RCTs [randomized control trials…I wish we could understand these things better.*”

## Antioxidants: What does current science have to say about antioxidants in food and supplements? [9:00]

- The world of antioxidants is complicated
- If ROS were only toxic, then antioxidants (to protect against oxidative-stress-induced cell death) would be solely positive
- However, free radical cellular leakage is a two-sided story

For more on the interplay between reactive oxygen species (ROS) and antioxidants check out a [previous episode of The Drive with Nav Chandel](https://peterattiamd.com/navchandel/) (specifically starting at 20:00)

**Reactive Oxygen Species (ROS) as signaling molecules: The good and the bad**

*The dark side*

- Excessive ROS formation can induce oxidative stress leading to cell damage and death
- Tumor cells generate higher levels of ROS, which can be used for growth and proliferation

*The Bright Side*

- Activation of the innate immune system requires ROS signaling
- Recognized patterns associated with pathogens and cell damage activate receptors which increase ROS via NOX enzymes and mitochondria
- Decreasing ROS would inhibit activation of proper immune system responses => immunosuppression
- Elevated ROS levels promotes autoimmunity via the increased release of proinflammatory cytokines and subsets of adaptive immune cells

**ROS Conclusion**

- It has become clear that ROS causing oxidative stress is not merely pathological but ROS leak serves as signals in many diverse circumstances (cellular energy supply v. demand, for example)
- And if ROS have historically been viewed as bad actors for their ability to “wreak havoc” on DNA, ROS amplification would be encouraged in the presence of susceptible, cancerous tumors
  - In fact, approximately 80% of the tumor-killing effect of radiation therapy is by the generation of ROS

For more on tumor cells and their susceptibility to high levels of ROS during radiation therapy (as well as hyperbaric oxygen therapy, dichloroacetate, and IV vitamin C), check out a [previous episode of The Drive with Dom D’Agostino](https://peterattiamd.com/domdagostino/)

**Taking antioxidants in the context of ROS functioning**

- We do not necessarily want to interfere with ROS immune response signaling
- There is not a clear-cut answer with respect to antioxidant supplementation (avoid inhibiting ROS signaling while don’t avoid antioxidant consumption)
  - Peter’s null hypothesis: Given the optimization of evolution, we have presumably evolved to consume, through food, the antioxidant “sweet spot,” but it is not clear
  - It could be situation specific

![](https://peterattiamd.com/wp-content/uploads/2019/05/inverted-U-curve-1024x771.png)

**Figure 1. The Inverted U Curve.** Image credit: [dayonewellness.co.uk](https://www.dayonewellness.co.uk/year3/the-inverted-u-curve-e1399908780470/)

**What about** [**endogenous**](https://en.wikipedia.org/wiki/Endogeny_(biology)) **antioxidants?**

- We produce endogenous antioxidant [Glutathione](https://en.wikipedia.org/wiki/Glutathione), known as the master antioxidant (AO), or redox-regulator, that controls inflammatory processes.
  - There is no shortage of Glutathione supplements on the market (liposomal glutathione, precursor NAC (N-acetyl cysteine) but it remains unclear which compound is best absorbed.
- One of the reasons we may be so concerned with antioxidant supplementation to combat aging is due to the [free radical theory of aging](https://cloudfront.escholarship.org/dist/prd/content/qt3w86c4g7/qt3w86c4g7.pdf) which posits that organisms age because they accumulate oxidative stress (However, animal model studies have not supported this conclusion)
- D. Harman et al. did not know about [apoptosis](https://en.wikipedia.org/wiki/Apoptosis) and ROS signaling

**To reconcile the free radical theory with the observations that contradict it, researchers have proposed that ROS may serve signaling functions, thereby activating protective and adaptive programs**

ROS as a central part of cellular homeostasis, a critical regulator that can elicit a shift in patterns of gene expression

- [Nick Lane](https://nick-lane.net/about/) discusses the evolution of cellular energy demands in his book [The Vital Question](https://www.amazon.com/Vital-Question-Evolution-Origins-Complex/dp/0393088812/ref=sr_1_1?keywords=the+vital+question&qid=1557331087&s=books&sr=1-1)
- In one [animal model study](https://www.ncbi.nlm.nih.gov/pubmed/17013393), using cell lines with four mice mtDNA haplotypes with the same nuclear DNA background, different mtDNA haplotypes can support equal rates of DNA synthesis but differ in ROS leak and mtDNA density
  - ROS leak seems to stimulate mitochondrial biogenesis, optimizing ATP synthesis to meet cellular energy requirements
  - The introduction of antioxidants lower mtDNA biogenesis and thus ATP synthesis leading to a bioenergetic deficit and possibly apoptosis (cell death)

![](https://peterattiamd.com/wp-content/uploads/2019/05/antioxidants-can-be-dangerous-1024x806.png)

**Figure 2. “Antioxidants can be dangerous. Cartoon depicting the results of an experiment using hybrid cells, or cybrids. In each case the genes in the nucleus are nearly identical; the main difference lies in the mitochondrial DNA. There are two types of mitochondrial DNA: one from the same strain of mice as the nuclear genes (top, ‘low ROS’), and the other from a related strain with a number of differences in its mitochondrial DNA (middle, ‘high ROS’). ROS stands for reactive oxygen species and equates to the rate of free-radical leak from the mitochondria. The rate of ATP synthesis is depicted by the large arrows, and is equivalent in the low ROS and high ROS cybrids. However, the low ROS cybrid generates this ATP comfortably, with low free-radical leak (denoted by little ‘explosions’ in the mitochondria) and a low copy number of mitochondrial DNA (squiggles). In contrast, the high-ROS cybrid has more than double the rate of free-radical leak, and double the copy number of mitochondrial DNA. Free-radical leak appears to power-up respiration. That interpretation is supported by the bottom panel: antioxidants lower the rate of free-radical leak, but also reduce the copy number of mitochondrial DNA and, critically, the rate of ATP synthesis. So antioxidants disrupt the free-radical signal that optimises respiration.”** Image credit: [The Vital Question by Nick Lane](https://www.amazon.com/Vital-Question-Evolution-Origins-Complex/dp/0393088812/ref=sr_1_1?keywords=the+vital+question&qid=1557331087&s=books&sr=1-1)

> “[W]e’ve seen that higher rates of free-radical leak, above the death threshold, trigger apoptosis. So are free radicals optimising respiration or eliminating cells by apoptosis? Actually, that’s not as contradictory as it sounds. Free radicals signal the problem that respiratory capacity is low, relative to demand. If the problem can be fixed by making more respiratory complexes, raising respiratory capacity, then all is well and good. If that does not fix the problem, the cell kills itself, removing its presumably defective DNA from the mix. If the damaged cell is replaced by a nice new cell (from a stem cell), then the problem has been fixed, or rather, eradicated.
>
> This central role of free-radical signalling in optimising respiration explains why antioxidants do not prolong life. They can suppress respiration in cell culture because the normal safeguards imposed by the body are not present in cell culture. In the body, massive doses of antioxidants such as vitamin C are barely absorbed; they tend to cause diarrhoea. Any excess that does get into the blood is swiftly excreted in the urine. Blood levels are stable. . . . If the body allowed high levels of antioxidants into cells, they would cause havoc and potentially kill us through an energy deficiency. So the body doesn’t let them in. Their levels are carefully regulated both inside and outside cells.
>
> And apoptosis, by eradicating damaged cells, eliminates the evidence of damage. The combination of free-radical signals and apoptosis together confound most of the predictions of the original free-radical theory of ageing, which was formulated long before either process was known. We don’t see a sustained increase in free-radical leak, or a large number of mitochondrial mutations, or an accumulation of oxidative damage, or any benefit to antioxidants, or an error catastrophe, for these reasons. It all makes perfectly reasonable sense, explaining why the predictions of the original free-radical theory of ageing are mostly wrong. But it doesn’t give any indication of why the free-radical theory might still be right.”
>
> — NICK LANE, The Vital Question, 2016

Antioxidant supplementation: There is a lot we still don’t know

## How do you break a fast of more than three days? [17:15]

*What are you optimizing for in the refeed? (i.e What is the objective?)*

In Peter’s personal experience:

- Fasts are between 5-7 days and breaking the fast he optimizes for:
  - Minimizing discomfort (easy to overdue intake quantity in first meal)
  - Minimizing behavioral response to a craving
    - He goes for salad with a bit of chili (could be [Pavlovian](https://en.wikipedia.org/wiki/Classical_conditioning) at this point, as the meal he wants the most at the end of a fast)
    - Volume matters: Breaking his fast with his favorite — [curry stir fry](https://www.instagram.com/p/BehEXLnBj7b/) — was a mistake (leading to prolonged hiccups, likely due to gastric stretching and diaphragmatic irritation)
  - Balance nutrients — If done correctly:
    - Plenty of magnesium, potassium, sodium
    - In a water-only fast, Peter drinks bouillon in order to sodium titrate
    - Uses [slow-mag](https://www.slowmag.com/why-slowmag-mg/?gclid=EAIaIQobChMIhdrg4Pr14QIVgoWzCh0D6Q3MEAAYAiAAEgJ-3_D_BwE) magnesium (i.e., magnesium chloride, 4-6 per day) to avoid cramps (but does not take magnesium oxide)
    - So for 3-7 day fasts all you really need is water, sodium and magnesium chloride
  - Preserve the “ketone high”: Avoids consuming high glycemic carbohydrates (like apple juice) during caloric reintroduction

For people who do a prolonged fast, there can be [refeeding syndrome](https://en.wikipedia.org/wiki/Refeeding_syndrome):

- One type of refeeding for post-hepatectomy patients: [Phosphorus repletion](https://www.ncbi.nlm.nih.gov/pubmed/1311873)
  - Patient phosphorus levels dropped due to DNA synthesis
  - Peter attests to the rapid rate of tissue regeneration after patients underwent liver resections
- A longer fast under medical supervision will require vitamin and mineral supplementation like phosphorus and magnesium
  - [Cahill’s research](https://www.researchgate.net/scientific-contributions/39305681_G_F_Cahill) discusses hormone serum levels in patients engaged in a prolonged period of fasting (~30 days)
  - [Angus Barbieri](https://en.wikipedia.org/wiki/Angus_Barbieri%27s_fast) completed a [382-day supervised fast](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2495396/pdf/postmedj00315-0056.pdf) which included supplementation of…
    - A daily multivitamin, vitamin C and yeast for the first 10 months and the last 3 months, potassium from day 93-162, and sodium from day 345 to 355
    - Non-caloric fluids were permitted ad-libitum

![](https://peterattiamd.com/wp-content/uploads/2019/05/Angus-Barbieri-before-after-1024x661.png)

**Figure 3. Angus Barbieri before and after his 382-day fast.** Image credit: [diabetes.co.uk](https://www.diabetes.co.uk/blog/2018/02/story-angus-barbieri-went-382-days-without-eating/)

## Does a morning black coffee break a fast? In other words, does black coffee raise insulin levels? [22:15]

For a similar question, check out [AMA #2](https://peterattiamd.com/ama02/)

- Breaking a fast and raising insulin levels are mutually exclusive and they are not the same thing
  - For example, you will see an insulin response after completing a [Tabata workout](https://en.wikipedia.org/wiki/High-intensity_interval_training) in the middle of a fast with the increase of [hepatic glucose output](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-ii/) but calories were not consumed to break a fast
  - Peter is not convinced that insulin should be the metric by which a fast is measured
- The purpose (“X”) of the fast needs to be identified in order to determine if an insulin spike detracts from the fast or not.
  - If the purpose of the fast is to be in a caloric deficit, then an insulin spike response does not detract from caloric deficit
  - If the purpose of the fast is to maximize AMPK and minimize [mTOR](https://peterattiamd.com/davidsabatini/) activity, we don’t currently have a good way to asses insulin spike impact
  - If the purpose is to provide complete gut rest or relief from gastroesophageal reflux ([GERD](https://en.wikipedia.org/wiki/Gastroesophageal_reflux_disease)), then a black coffee is breaking the fast (stimulating digestive enzymes)
- Peter does not consume black coffee or caffeinated tea when fasting (no reason beyond preference)

## When intermittent fasting, does the placement of the “feeding window” matter? [25:30]

- Animal model studies like that done by [Valter Longo and Satchi Panda](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5388543/) suggests that it is optimal to eat early in the morning (around 5 am) and then again in the afternoon (2 pm), fasting thereafter until the next morning.
  - The intermittent fasting cycle that follows a natural circadian rhythm optimizes for insulin sensitivity, which should decrease over the course of the day and improves sleep quality
- Peter has a patient who follows a 16/8 fasting window where he eats breakfast at 8 am and dinner at 4 pm and asleep by 10 pm
  - **The social challenge**: intermittent fasting following a natural circadian rhythm, which seems to be physiologically preferred, *is socially difficult*

The liver uses food intake to set its circadian rhythm

- [Satchi Panda](https://www.salk.edu/scientist/satchidananda-panda/) discovered blue light sensors in the retina, which signals when to wake up and go to sleep (The sensors serve as timekeeper inputs to the body’s internal “master clock”)
- In a similar way, you can think of food as the “blue light” seen by the liver to set its own circadian rhythm
  - With this in mind, the [liver’s rhythm can benefit from time-restricted feeding](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5388543/) (TRF)
- Eating your one meal per day late at night (as is what happens when Peter travels) affects hepatic glucose output
- If doing one meal a day… **that single meal should be** ***as early as possible***

> “Eat like a king in the morning, a prince at noon, and a peasant at dinner”
>
> – MOSES BEN MAIMON OR MAIMONIDES, 1135-1404

## Is it better to fast before or after a planned food binge (e.g., Thanksgiving)? [28:30]

*Peter’s Thanksgiving hacks:*

- ‘Dial down’ caloric consumption the week leading into Thanksgiving weekend
- Complete a [glycogen depleting workout](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/) morning of Thanksgiving to **maximize insulin sensitivity** by ensuring glycogen dependent and independent transport into muscle is at maximum capacity

**⇒ Counterintuitive fact**: Fasting decreases muscle insulin sensitivity: glucose entering the system is prioritized in the liver for [brain energy metabolism](https://peterattiamd.com/domdagostino/) (People on ketogenic diets can “fail” oral glucose tolerance tests because they become physiologically insulin resistant)

For more on muscle glycogen, check out [AMA #5](https://peterattiamd.com/ama05/)

The importance of nutritional content (choice) in a meal as a determinant for intermittent hunger

- [Gary Taubes](https://twitter.com/garytaubes?lang=en) discusses hunger and the role of dietary sugar
- [Shawn Baker](https://www.shawn-baker.com/), for example, follows a carnivore, one-meal-a-day diet and does not experience hunger outside of his feeding window – referring to his meals as [intermittent feasting](https://twitter.com/SBakerMD/status/932025677867397121) (play on between caloric consumption time-window fasting).

In his book called [Hunger](https://www.thriftbooks.com/w/hunger_jacques-le-magnen/1770018/#isbn=0521311225&idiq=10641694), Jacques Le Magnen wrote:

> “A meal is initiated after a time which is proportional to the caloric load achieved in the previous meal. This suggests that the triggering mechanism for the start of a meal or stimulation to eat involves an all-or-none signal resulting from the rate of metabolic utilization of the amount of food ingested in the preceding meal.”

## Fasting protocol: Do you have a specific protocol to recommend? [31:30]

If you have never fasted before…

- Consider time restricted feeding (TRF) first almost as a “gateway drug” to prolonged fasting
- Fasting as a function of X, Y, Z
  - X=how much are you reducing intake from baseline (caloric intake variable)
  - Y=duration
  - Z=frequency
- Note: A first-time fast *does not have to be water only* (i.e. just try a 50% reduction in calories)

*What kind of fast has the most benefit?*

- That is unknown, however…
  - Caloric reduction by only 10% probably not beneficial (relative to a total, 100% fast)
  - But a 90% reduction almost assuredly gives benefit

*Hunger during fasting*

- Even in a week-long water-only fast, hunger will ebb and flow
- You will feel hunger that will then pass (as if you had a meal)
- This experience is likely related to (aforementioned) circadian rhythm
- Peter notices his hunger most when fasting between 11am and 3pm

## Time management: How do you manage your time between work, family, and your many personal interests? [35:45]

There are 168 hours in a week:

- Sleep comes first for Peter
  - There isn’t one aspect that is “most important” (e.g. nutrition, exercise, sleep), but forgoing all of them, lack of sleep will kill you first
  - So take away 56 hours (8 hours per night), leaving 112 left in the week

Peter travels a lot so the way he manages his time in NYC is different than how he manages his time in San Diego (family, kids, archery, drive simulator)…

- On the west coast:
  - Wake up between 4:30-5:00 am
  - Meditate
  - Coffee time with his wife
  - Tries to adhere to only 2x daily email check (This comes as a result of “feeling tethered” to keeping on top of/responding to emails) ⇒ \*This means: 30-minute morning email check
  - Make breakfast for kids
  - Exercise
  - Workday starts around 10 am
  - Post-dinner email check and early to bed
- Always tries to do one personal interest/extracurricular activity per day (archery, driving simulator)
- Enjoys some kind of fun/interactive workout with his children
- Activities are “blocked-out” on the calendar like a non-negotiable appointment

⇒ Analogy of portfolio theory (asset management):

> “We are all asset allocators…allocating an asset much more valuable than money. And that is, of course, time. It is the only…truly finite resource that we have. It is also the only unifying, equalizing resource. Meaning, no matter how much wealth or smarts or whatever you have, we are all stuck with the same disappearing thing.” – Peter Attia

- For a given patient, Peter tallied how time was spent versus what he thought was optimal for said patient
- The delta was time that needed to be recouped and redistributed for best overall health and performance
- Ask questions like: *What do I need to give up? How can I be more productive?*
  - For example, a commute can be used to be more productive (e.g., driving meditation, or informative podcasts)
  - There will be things that you need to give up (e.g., Peter does not swim anymore which used to be his top priority ⇒ [he used to only travel to places that had a pool](https://www.swimmersguide.com/))

See what [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) has to say on time allocation [here](https://www.businessinsider.com/warren-buffetts-not-to-do-list-2016-10?r=US&IR=T)

## Problem solving: Can you breakdown your process of problem-solving? [46:45]

- [Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) problem-solving technique: write down the problem, think very hard, write down the answer
  - A perhaps more user-friendly adapted version: choose a concept, teach it to a toddler, identify the gaps, review and simplify — repeat this process until it’s crystal clear to the student (or toddler)

For more on the Feynman technique, check out this blog post at Farnam Street: [The Feynman Technique: The Best Way to Learn Anything](https://fs.blog/2012/04/feynman-technique/)

**How to Learn Faster with the Feynman Technique (Example Included)**

**Peter on frameworks**:

> “*I am maniacal about frameworks. I can’t solve problems without a framework.*”

- Questions can seem impossible to answer without a “framework” (i.e. scaffolding on which to build a solution/response)
- *Peter’s preferred framework*: [MECE](https://en.wikipedia.org/wiki/MECE_principle) (mutually exclusive and collectively exhaustive)
- Framing the problem (in steps towards a solution) does not mean that the answers for each step are known but it is a roadmap in order to “tackle” the solution

[Quote](https://quoteinvestigator.com/2012/04/28/shorter-letter/) about succinct simplicity:

> “If I had more time, I would have written a shorter letter.” — Mark Twain, George Bernard Shaw, Voltaire, Blaise Pascal, Johann Wolfgang von Goethe, Winston Churchill, Pliny the Younger, Cato, Cicero, Bill Clinton, or Benjamin Franklin??

## For those looking to gain a better understanding of biochemistry, pharmacology, etc., do you have any good textbooks or (online) resources to recommend? [49:00]

- [Nav Chandel](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=11123)’s work
  - Nav’s book from 2015: [Navigating Metabolism](https://www.amazon.com/Navigating-Metabolism-Navdeep-Chandel/dp/1621821293) (pun intended)
  - Previously mentioned in [podcast with Nav [1:15, 59:00]](https://peterattiamd.com/navchandel/)
  - Free excerpts from the book can be found [here](https://cshlpress.com/default.tpl?action=full&--eqskudatarq=1037)
- [Peter Dobromylskyj](https://high-fat-nutrition.blogspot.com/) (and Bob) recommends [Crash Course: Metabolism and Nutrition](https://www.amazon.co.uk/Crash-Course-Metabolism-Nutrition-4e/dp/0723436266)
- [Khan Academy](https://www.khanacademy.org/science/high-school-biology/hs-biology-foundations/hs-biological-macromolecules/v/introduction-to-proteins-and-amino-acids) has open source foundational course on molecules
- [Coursera](https://www.coursera.org/learn/energy-metabolism) offers online courses in biochemistry, energy metabolism, etc.
- [Edx](https://www.edx.org/learn/biochemistry) also offers online biochemistry courses
- [Chem330](https://www.rose-hulman.edu/~brandt/Chem330/) provides open-source lecture notes with supplementary handouts and materials
- Youtube channel: [AK lectures](https://www.youtube.com/user/mathdude2012/playlists?view=50&sort=dd&shelf_id=16)
- Youtube channel: [Leah4sci](https://www.youtube.com/results?search_query=leah4sci+biochemisty) and website link [here](https://leah4sci.com/tag/biochemistry/)
- Youtube channel: [Armando Hasudungan](https://www.youtube.com/user/armandohasudungan/featured)
  - Here’s his [biochemistry playlist](https://www.youtube.com/playlist?list=PLqTetbgey0afLVPJ3QPWV_yN7c1VRqDxQ)
  - Here’s his [pharmacology playlist](https://www.youtube.com/playlist?list=PL601B2E69B03FAB9D) (good for diagrams)
- In terms of textbooks:
  - [Voet](https://www.amazon.com/Biochemistry-4th-Donald-Voet/dp/0470570954/ref=sr_1_1?ie=UTF8&keywords=voet+biochemistry+5th+edition&qid=1462040812&s=books&sr=1-1) published an in-depth text (fairly advanced) with an emphasis on structural biology
  - [Lehninger Principles](https://www.amazon.com/Lehninger-Principles-Biochemistry-David-Nelson/dp/071677108X) is often a popular go-to with an emphasis on physiology
  - [Garrett](https://www.amazon.com/Biochemistry-Reginald-H-Garrett/dp/1133106293) uses an “essential questions” framework to guide through the text concepts.

## What are some of your favorite podcasts that you listen to? [51:15]

Peter only listens to podcasts during his [zone 2 workouts](https://www.livestrong.com/article/378483-cardio-heart-rate-zones/) (which is about 3 hours per week)

- [The Tim Ferriss Show](https://tim.blog/podcast/)
- [Making Sense with Sam Harris](https://samharris.org/podcast/)
- [Found My Fitness with Rhonda Patrick](https://www.foundmyfitness.com/episodes)
- [The Forward Podcast with Lance Armstrong](https://theforwardpodcast.libsyn.com/)
- [The Knowledge Project Podcast with Shane Parrish](https://fs.blog/the-knowledge-project/)
- [EconTalk Podcast](https://www.econtalk.org/)

## What is your favorite animal? [54:45]

Introducing special guest appearance: [Silk Ears](https://www.amazon.com/Fisher-Price-Laugh-Learn-Smart-Stages/dp/B01NCUPCD4/ref=sr_1_1?keywords=fisher+price+smart+stages+puppy&qid=1556460531&s=gateway&sr=8-1)

> “My ears are silky, my ears are blue. I love my ears. How about you?” —Silky Ears

§

## Selected Links / Related Material

**Vitamin supplementation and the role of B-vitamins in methylation**: [#46: navigating the many pathways to health and disease with Chris Masterjohn](https://peterattiamd.com/chrismasterjohn/) | Peter Attia (peterattiamd.com) [3:00]

**Chris Masterjohn on methylation**: [Start Here for MTHFR and Methylation](https://chrismasterjohnphd.com/2019/03/01/start-here-for-mthfr-and-methylation/) | Chris Masterjohn (chrismasterjohnphd.com) [3:00]

**Nick Lane’s book**: [The Vital Question](https://www.amazon.com/Vital-Question-Evolution-Origins-Complex/dp/1511366540) by Nick Lane | (amazon.com) [12:45]

**Vitamin C to drive oxidative stress on a tumor**: [#05: Dom D’Agostino on ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](https://peterattiamd.com/domdagostino/) | Peter Attia (peterattiamd.com) [3:45, 9:00]

**Book containing the results of a study about vitamin C megadosing for the common cold**: [Vitamin C and the Common Cold](https://openlibrary.org/books/OL4914696M/Vitamin_C_and_the_common_cold) by Linus Pauling | (openlibrary.org) [5:30]

**Linus Pauling’s written correspondence to Richard Feynman**: [Perfectly Reasonable Deviations From The Beaten Track: The Letters of Richard Feynman](https://cds.cern.ch/record/1486906?ln=en) | ([cds.cern.ch](https://cds.cern.ch/)) [6:00]

**Fred Klenner’s paper on the curative ability of IV vitamin C megadosing**: [Observations on the Dose and Administration of Ascorbic Acid When Employed Beyond the Range of a Vitamin in Human Pathology](https://www.mv.helsinki.fi/home/hemila/N2017/Ch22_Klenner1971JApplNutr.pdf) (Klenner, 1971) [6:00]

**Paper about vitamin D supplementation to reduce cancer and cardiovascular disease risk which concluded no significant association**: [Vitamin D Supplements and Prevention of Cancer and Cardiovascular Disease](https://www.nejm.org/doi/10.1056/NEJMoa1809944) (Manson et al., 2019) [7:45]

**The Drive episode which discussed whether antioxidants are helpful or harmful**: [#31 – Navdeep Chandel: metabolism, mitochondria, and metformin in health and disease](https://peterattiamd.com/navchandel/) | Peter Attia (peterattiamd.com) [9:00]

Elevated ROS levels promotes autoimmunity via the increased release of proinflammatory cytokines and subsets of adaptive immune cells

**The Free Radical Theory of Aging**: [Aging: A Theory Based On Free Radical and Radiation Chemistry](https://cloudfront.escholarship.org/dist/prd/content/qt3w86c4g7/qt3w86c4g7.pdf) (D. Harman, 1955)  [12:00]

**ROS as a central part of cellular homeostasis**: [Differences in Reactive Oxygen Species Production Explain the Phenotypes Associated with Common Mouse Mitochondrial DNA Variants](https://www.ncbi.nlm.nih.gov/pubmed/17013393) (R. Moreno-Loshuertos et al., 2006) [12:30]

**Case study of a 382-day supervised fast**: [Features of a Successful Therapeutic Fast of 382 Days’ Duration](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2495396/pdf/postmedj00315-0056.pdf) (Stewart et al., 1973) [21:45]

**Peter’s hepatic glucose output in response to a hard workout (Tabata)**: [The interplay of exercise and ketosis – Part II](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-ii/) | Peter Attia (peterattiamd.com) [22:45]

**Time-restricted feeding and the liver’s circadian rhythm**: [Fasting, circadian rhythms, and time restricted feeding in healthy lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5388543/) (Longo et al., 2017) [25:30]

**AMA episode which discussed muscle glycogen and exercise on a low-carb diet**: [#50 – AMA #5: calcium scores, centenarian Olympics, exercise, muscle glycogen, keto and more](https://peterattiamd.com/ama05/) | Peter Attia (peterattiamd.com) [28:30]

**Jacques Le Magnen’s book**: [Hunger](https://www.thriftbooks.com/w/hunger_jacques-le-magnen/1770018/#isbn=0521311225&idiq=10641694) by Jacques Le Magnen | (thriftbooks.com) [31:00]

**The Feynman Technique**: [The Feynman Technique: The Best Way to Learn Anything](https://fs.blog/2012/04/feynman-technique/) | (Farnam Street) [47:00]

**Nav’s book from 2015**: [Navigating Metabolism](https://www.amazon.com/Navigating-Metabolism-Navdeep-Chandel/dp/1621821293) by Navdeep Chandel | (amazon.com)| ([Excerpts Here](https://cshlpress.com/default.tpl?action=full&--eqskudatarq=1037)) [49:00]

**Reading for biochemical fundamentals**: [Crash Course: Metabolism and Nutrition](https://www.amazon.co.uk/Crash-Course-Metabolism-Nutrition-4e/dp/0723436266) by Olivia Vandergen et al. | (amazon.com) [50:45]

**Online resource for biochemical fundamentals**: [Khan Academy](https://www.khanacademy.org/science/high-school-biology/hs-biology-foundations/hs-biological-macromolecules/v/introduction-to-proteins-and-amino-acids) | (khanacademy.org) [50:45]

**Some of Peter’s favorite podcasts**:

- [The Tim Feriss Show](https://tim.blog/podcast/) | Tim Ferris (tim.blog/podcast) [51:45]
- [Making Sense](https://samharris.org/podcast/) | Sam Harris (samharris.org/podcast) [51:45]
- [Found My Fitness](https://www.foundmyfitness.com/episodes) | Rhonda Patrick (foundmyfitness.com) [51:45]
- [The Forward](https://theforwardpodcast.libsyn.com/) | Lance Armstrong (theforwardpodcast.libsyn.com) [51:45]
- [The Knowledge Project](https://fs.blog/the-knowledge-project/) | Farnam Street (fs.blog/the-knowledge-project) [51:45]
- [EconTalk](https://www.econtalk.org/) | The Library of Economics and Liberty (econtalk.org) [51:45]

§

## People Mentioned

- [Chris Masterjohn](https://chrismasterjohnphd.com/) (previous guest on [The Drive](https://peterattiamd.com/chrismasterjohn/)) [3:00]
- [Dom D’Agostino](https://www.ketonutrition.org/) (previous guest on [The Drive](https://peterattiamd.com/domdagostino/)) [3:45, 9:00]
- [Nick Lane](https://nick-lane.net/) (biochemist and writer) [12:45]
- [Linus Pauling](https://www.nobelprize.org/prizes/chemistry/1954/pauling/biographical/) (Nobel Prize in chemistry, 1954) [5:30, 6:00]
- [Richard Feynman](https://www.nobelprize.org/prizes/physics/1965/feynman/biographical/) (Nobel Prize in Physics, 1965) [6:00,47:00]
- [Fred Klenner](https://de.wikipedia.org/wiki/Frederick_Klenner) (Physician) [6:00]
- [Navdeep Chandel](https://www.chandellab.com/) (previous guest on The Drive, metabolism, mitochondria, and metformin in health and disease) [9:00, 49:15]
- [Denham Harman](https://en.wikipedia.org/wiki/Denham_Harman) (father of the free radical theory of gaining) [12:00]
- [G.F. Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (prolonged fasting research) [21:45]
- [Angus Barbieri](https://en.wikipedia.org/wiki/Angus_Barbieri%27s_fast) (382-day supervised fast) [21:45]
- [Valter Longo](https://prolonfmd.com/fasting-mimicking-diet/) (Fast Mimicking Diet) [25:45]
- [Satchi Panda](https://www.salk.edu/scientist/satchidananda-panda/) (Circadian Rhythm and Fasting) [25:45]
- [Gary Taubes](https://garytaubes.com/) (hunger and the role of dietary sugar) [30:15]
- [Shawn Baker](https://www.shawn-baker.com/) (carnivore, one-meal-a-day diet) [31:00]
- [Jacques Le Magnen](https://academic.oup.com/chemse/article/28/2/85/318852) (author of Hunger, neurobiology of feeding and nutrition) [31:00]
- [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett)  [time allocation](https://www.businessinsider.com/warren-buffetts-not-to-do-list-2016-10?r=US&IR=T)) [44:15]
- [Peter Dobromylskyj](https://high-fat-nutrition.blogspot.com/) (suggested literature on metabolism and nutrition) [50:45]
- [Bob Kaplan](https://peterattiamd.com/?s=bob+kaplan) (Attia Medical Lead Researcher – suggested literature on metabolism and nutrition) [50:45]
- [Tim Ferriss](https://tim.blog/about/) (The Tim Ferriss Show Podcast) [15:45, 51:45]
- [Sam Harris](https://samharris.org/about/) (Making Sense Podcast) [51:45]
- [Rhonda Patrick](https://www.foundmyfitness.com/about-dr-rhonda-patrick) (Found My Fitness Podcast) [51:45]
- [Lance Armstrong](https://lancearmstrong.com/) (The Forward Podcast) [51:45]
- [Shane Parrish](https://www.nytimes.com/2018/11/11/business/intelligence-expert-wall-street.html) (Farnam Street – The Knowledge Project Podcast) [51:45]
- [Russ Roberts](https://www.econlib.org/library/About.html#roberts) (EconTalk Podcast Host) [51:45]

§