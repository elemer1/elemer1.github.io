# #285 – AMA #55: Exercise: longevity-focused training, goal setting, improving deficiencies, managing emotional stress, and more

**Source:** [https://peterattiamd.com/ama55/](https://peterattiamd.com/ama55/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into the crucial topic of exercise, starting with the importance of having a goal in training, including how and why Peter uses the goal of training for the “Centenarian Decathlon” when structuring his training plans. Peter elaborates on how to identify deficient areas within the four pillars of exercise and guides listeners on incorporating periodization training for optimal improvement and training variety. The episode explores diverse case studies, offering insights into tailored workouts for individuals of various training backgrounds, from seasoned enthusiasts to complete beginners. Additionally, Peter tackles the universal issue of emotional stress and its impact on training, as well as how exercise can help manage stress and how to determine when training should be adjusted during a high-stress period.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #55 show notes page](https://peterattiamd.com/ama55). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of exercise topics [2:15];
- Importance of training with a goal in mind, the Centenarian Decathlon, and the natural decline of fitness with age [4:00];
- The four pillars of exercise [12:15];
- Measuring peak aerobic output with VO2max, and the importance of VO2max as a predictor of longevity [16:45];
- Measuring aerobic efficiency with zone 2 [25:45];
- Measuring and tracking muscle mass and strength [27:30];
- Case study of a fit person with a neglected pillar: why adding more training volume may not the best strategy [30:30];
- Periodization training: what it is and why it is beneficial [36:15];
- Periodization case study: high cardio fitness, lacking muscle and strength [40:00];
- Periodization case study: adequate muscle, low cardio fitness [44:45];
- Case study: significant improvement needed across all exercise pillars [48:45];
- Best ways to do zone 2 exercise and how to use relative perceived exertion (RPE) to find your zone 2 level [56:30];
- How the body responds to physical and emotional stress, its impact on training, and the consequences of chronic stress [1:01:00];
- The difference between “good” stress and “bad” or chronic stress [1:10:30];
- The complex relationship between exercise and stress, and the importance of adjusting exercise goals during high-stress periods [1:13:30];
- Clues that stress may be impacting your training [1:19:15];
- The use of wearables and devices for tracking trends and making decisions related to training [1:21:00];
- Parting thoughts regarding the importance of exercise for longevity and stress management [1:32:00]; and
- More.

§

The Peter Attia Drive

Exercise: longevity-focused training, goal setting, improving deficiencies, managing emotional stress, and more

§

## Show Notes

§

## Overview of exercise topics [2:15]

- A lot of questions come in regarding how to improve cardiorespiratory fitness, how to increase muscle mass, and increase strength
- Peter will discuss this and how we approaches this with patients in his practice
- First is really identifying and clearly defining what the goal of training is
- From there, helping people understand how they can identify the area in their life that they need the most help in when it comes to exercise
- On a more technical front, how people can use periodization training to facilitate improvements in areas that are most needed
- Peter will use case studies of what a different weekly workout could look like for a few different types of people
- Additionally, Peter also look at some training questions that apply to everyone no matter what level of expertise they’re at
- To conclude, Peter will discuss how stress can impact a workout and what to do about it as well as how people should look at wearables and the data from wearables as it relates to making decisions on training

## Importance of training with a goal in mind, the Centenarian Decathlon, and the natural decline of fitness with age [4:00]

**Importance of training with a goal in mind**

- Like most people, Peter is no longer an athlete training for a specific athletic event
- Peter has made the [Centenarian Decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/) his goal

*More context from Peter*

- Recently, Peter saw picture of himself from 2014 and it was after a training session
- Fiesta Island is where we used to train for the time trials and it was a picture of me and [Meb](https://en.wikipedia.org/wiki/Meb_Keflezighi) after a training session.
- At that time, Peter was 168 pounds, 25 pounds less than today
- And there’s just no comparison to what he was then versus what he is today
- Peter’s training at that time was 3x more than nowadays in volume, and it was *very specific*
- When Peter stopped competing, and he was done with cycling, swimming, and just done with being competitive at some level, he needed to find another goal — “*It’s very difficult to train without a purpose*.”

Peter had an epiphany in the summer of 2018 (discussed in his [book](https://peterattiamd.com/outlive/))

- He had an aimless three years where he was exercising and he was reasonably fit, but there was no purpose — “it wasn’t anchored to anything”
- This all came in a flash of inspiration when he was sitting at the funeral of the parent of a close friend, realizing that in the last decade of this person’s life that person was largely debilitated, physically
- That tragic to Peter because he had seen them be healthy in their 60s and 70s
- But that’s what gave Peter this idea: we need a goal and we need to treat life just as we would treat an athletic event
- This idea of a centenarian decathlon came to his mind in part because decathletes are generally regarded as the best overall athletes, despite not being the best in any one of the 10 things that they do
- Of course, centenarian decathlon is not an actual event, but even becoming a centenarian is not necessarily the objective — we don’t have that much control over how we stretch our genes

What we really need to say to ourselves is…

- In the last decade of my life, what do I want to be able to do and how do I begin to train for that now?
- When you take that look at the future and you say, “Look, these are the things I want to be able to do,” you can apply metrics to those activities.
- You can say, “Hey, if I want to be able to hike on uneven surfaces to the tune of two mile round trip in an hour, that requires this much cardio respiratory fitness, this much strength, this much balance
- And I know how much each of those things will decline over the next decades. So how much stronger do I need to be at 50 than I would expect to be at 85 or 90?”

![](https://peterattiamd.com/wp-content/uploads/2024/01/f1-ama55.png)

**Figure 1.** Source: [Westerterp et al.  Am J Clin Nutr. Nov 2021](https://www.sciencedirect.com/science/article/pii/S0002916522004907?via%3Dihub)

Overview of the figure:

- On the left, it shows women and on the right it shows men
- The bottom two figures show physical activity level over time.
- Age is always shown on the X axis
- And the upper figure shows fat-free mass in kilograms on the Y axis versus again age on the X axis
- So fat-free mass of course is a very good proxy for lean mass or muscle mass
- And you can see that these have data collected all the way from when people are teenagers up until the end of life

Observations:

- Remarkable trends here
- There’s some obvious differences between men and women—the most notable one of just the difference in lean mass, men have significantly more lean mass than women—but if you put that aside, you’ll realize two things:
  - The first is that we have a steady increase in muscle mass and lean mass that occurs from birth right up until about the age of 25
  - And then you have a relatively minor decline in lean mass from 25 to 75
  - Then at age 75, it literally falls off a cliff
- Now looking at physical activity, we see that from the ages of 25 to 75, physical activity level is even more consistent and conserved than lean mass in both men and women
  - And yet what happens at the age of 75 for both men and women? It just falls off a cliff
- Of course, this figure cannot give us causality—you can’t look at this figure and tell you that the reason physical activity level falls off a cliff at 75 is because muscle mass does the same
  - Nor can you say that muscle mass is declining because physical activity goes down
- Peter believes, however, that it is bi-directional
  - “*In other words, I suspect that what’s happening is that at 75 or thereabouts for the average person, activity declines and as activity declines, muscle mass declines, and as muscle mass declines, activity declines further and these things spiral out of control*.”
- The average life expectancy is about 80
  - So that means that for people who are living to average life expectancy and slightly beyond, they’re basically going to spend the last 5 to 10 years of their life in a very poor physical state
- **Key point**: you must focus on **healthspan** at least as much as you focus on lifespan
  - And if there’s an enormous failure in medicine 2.0, it’s the myopic focus on lifespan at the complete exclusion of health span

Therein lies the why:

- It really doesn’t matter what your athletic background is.
- Maybe you were a stud athlete growing up, maybe you’ve never played a sport in your life and you’ve never done so much as run a local 5K
- None of that matters
- “*Everyone needs to be an athlete for life and therefore everyone needs to think about becoming the best version of their centenarian decathlete*.”

## The four pillars of exercise [12:15]

**Overview of the four pillars of exercise and why it’s relevant to the centenarian decathlon**

- For the centenarian decathlon, we’re really thinking about things that are activities of daily living and beyond (e.g., activities of leisure, pleasure, and sport, etc.) that they want to do
- Peter encourages people to go through this exercise and make sure they have both of those in there

*Broadly speaking, the four pillars would be*:

- 1 – Stability
- 2 – Strength
- 3 – Aerobic performance
- 4 – Anaerobic output

Two cardio pillars and two strength-related pillars

- Cardio pillars are i) Maximum aerobic efficiency measured by zone 2 output and ii) Peak aerobic output measured by VO2 max
- On the other side we have **stability** and **strength**, and within strength there’s a lot
  - And that’s because strength involves both muscle quality and motor control
  - And you have eccentric strength and you have concentric strength and all those things
- Then you have this other idea that wraps around strength called **stability**
  - Stability speaks about the safety with which you can apply that strength, i.e. exert force on the outside world, and the safety with which the outside world can exert force on you
  - Inherent with instability are other issues that we think about, especially things that decline as we age, such as mobility, balance, flexibility

***What are people able to track and kind of identify further to know where they’re at?***

There are so many, so let’s take strength as an example:

- Within strength, we want to think about peak strength (i.e., your maximum one rep max for something)
- We would want to think about muscular endurance—the ability to move something that’s much lighter, but for many, many reps
  - It’s important to point out that you don’t have to train at a one rep max to increase your strength and you don’t have to actually measure at that level
  - In other words, you could see how much you could do something for five reps and that would allow you to impute or estimate what you could do for one rep
- We then talk about various things like motor control
  - So again, this is sort of a hybrid of the strength, stability piece
  - Earlier Peter gave the example of hiking over an uneven surface
  - Peter just got back from a hunting trip a little while ago and you’re walking around in the dark, carrying heavy stuff, walking on uneven surfaces, and that’s a much more complicated and dynamic situation than riding a stationary bike, for example.
  - So we want to be able to train in both of those ranges
    - You want to be able to train under perfect conditions such as using a machine or being on a bike or something like that.
    - And then you also want to be able to train on variable surfaces and in situations where you have less control.
- When we talked about cardiorespiratory fitness, lots of things that we measure here
- But again, thinking of these in the two extremes, which is:
  - What is the maximum output you can sustain while still exclusively utilizing your aerobic system? Or, what’s the maximum output you can sustain without accumulating net lactate?
  - And at the other end of that spectrum, what is the maximum utilization you have of oxygen which corresponds not to your maximum output, but more importantly your maximum aerobic output
- These are very quantifiable and these are numbers that Peter has for all his patients

## Measuring peak aerobic output with VO2max, and the importance of VO2max as a predictor of longevity [16:45]

**Measuring peak aerobic output with VO2max**

- We have the best data regarding VO2 max
- Peter says that one area where he feels like his book fell short is that he didn’t do a good enough job of explaining ***why*** VO2 max is so important
- But the data are unambiguous
- The association between high VO2 max and longevity is so clear, and conversely, the association between low VO2 max and mortality is so clear, that the idea that *VO2 max is the single greatest predictor of lifespan of any measurable number we have* is quite remarkable

***So why is that the case?***

- VO2 max is a remarkable integrator of the work you have done to get fit, and that’s why strength is a very close second
- If we’re going to tally all the possible biomarkers that would predict how long you’re going to live, we could look at your ApoB, we could look at whether you have diabetes or not, we could look at your testosterone level, your cholesterol level, how much muscle mass you have, what your BMI is, and so on
- If we rank ordered them in terms of how well do they predict the probability you’re going to die this year…the very, very top of that list is VO2 max and directly under it is strength
- Why? ⇒ Because you can’t fake those metrics and you can’t “cram for the test”
  - You take a person with a low VO2 max and you send them to the gym for a month, they’re not going to show up with a high VO2 max on the test
  - But there is nobody who can’t get into the top 25% for their age and sex with a long enough training history
- And the benefits of exercise are best tabulated and measured via the accrual of the intensity duration, specificity of training and measured in this single number
- So in that sense, for math geeks out there, VO2 max is the integral from T1 to T2 of work as a function of time DT
  - And that’s a big DT to get a high VO2 max

The same is true with strength

- When we talk about how grip strength and leg extension strength and all of these metrics of strength are so highly correlated, it’s the same thing
- You can’t take someone who’s not strong and make them strong in a month
- And yet think about how easy it is to tweak your vitamin D level in a month, it’s trivial

> “So that’s why I look at all of these bio aging clocks that have all these goofy little biomarkers that are so easy to manipulate, and I think, ‘This stuff’s categorically useless.’ A real demonstration of your longevity prowess is going to be far more likely found in variables that can’t change readily.” —Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2024/01/f2-ama55.png)

**Figure 2**. Source: [Mandsager et al.  JAMA Netw Open. Oct 2018](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428)

- Peter believes this is a fantastic benchmark for a person who wants to understand where they stack up
- This figure divides men and women by decade of life into five categories: low, below average, above average, high, and elite (which is the ranking assigned to their VO2 max)
- Low is the bottom 25%
- below average is the second quartile
- above average is the third quartile
- and high and elite together form the top quartile, where elite just carves out the top 2.3%.

Peter encourages everybody to know where their VO2 max is and also to understand where they stack up relative to people in the age and sex

- But you want to hold yourself to a higher standard
- Peter just “aged up” when he turned 50
- And you’ll notice that at 49 when he was at the top of his age range, an elite VO2 max was above 52, whereas at the age of 50 and from age 50 to 59, it’s greater than 50.
- “As a 50-year-old, knowing that I need to be in this age bracket for another decade, I am not holding myself to the standard of just being at 50. I want to be a couple decades beyond that. I want to be in the elite level for someone in their 30s, which would be north of 53.”
- While that doesn’t sound like much, that’s a pretty big difference when you consider that this number’s going down at about 8% to 10% per decade depending on your training volume
- “It’s probably a little less important where you are in the moment and more important in terms of the trajectory you’re heading in.”

*Some clarifying points*:

- Your goal, being elite in an age bracket below you isn’t a situation where you’re just “trying to be the absolute best you can be to be the best you can be”
- It’s because you know **the fall off that’s coming** and you know, depending on how high you are to start, that fall off is going to be a lot easier or a lot harder
- And so that goal looks more at the long-term than it does the short term of, “Okay, my VO2 max is on par with a 30-year-old today.”
- You care less about what it means today and more about what it means for your future.

Pulling from an example from his book:

- “It’s really hard for me to make the case that your life is not profoundly compromised when your VO2 max gets into the low 20s or high teens”
- People listening to this right now who have a VO2 max of 18 or 16 or 20, their quality of life is compromised. There are many things that they are simply not capable of doing.
  - If they go on vacation and they’ve got to drag their luggage through the airport, it’s really, really taxing
  - If they want to take their grandkids to the fair and they’ve got to move quickly from one end to the other
  - Or they have to climb a flight of stairs just under the weight of their own body, it’s really, really challenging

Recapping Peter’s personal goal:

- “Truthfully, my goal is to never have a VO2 max below 20. Then ideally I’d like to be in the mid to high 20s in the final years of my life if possible”
- “That’s why I have to be doing what we’re talking about. That’s why I have to hold myself to such a high standard in my 50s because of what I know is coming.”

## Measuring aerobic efficiency with zone 2 [25:45]

- On the zone 2 stuff, we have probably less data to compare to because the analyses haven’t been done
- When showing Peter’s patients where they stack up, he uses data that comes out of a [paper](https://pubmed.ncbi.nlm.nih.gov/28623613/) that [Iñigo San-Millán](https://twitter.com/doctorinigo?lang=en) published a while ago showing the zone 2 thresholds for different types of athletes, such as:
  - Elite cyclists, masters athletes, relatively fit people, unfit people, etc.
- Of course, this is all measured in watts per kilogram because all of those measurements are easiest done on a bike where you’re measuring watts
  - You would take the number of watts that you can hold if you’re riding your Peloton or your stationary bike, you then normalize that to your weight in kilos
- If you’re doing this in other manners, like a treadmill, or if you’re jogging or walking briskly uphill, your best bet is to probably convert it to METs, metabolic equivalents
  - Then use a METs to watts converter, and you can get it down

But here’s some numbers just to give people a sense of things:

- Just as we would say, the best VO₂ maxes in the world (e.g., professional cyclists) would have VO₂ maxes in the high 70s and in the 80s
- And similarly, the absolute best zone 2 output are going to be kind of in the 4-watt per kilo range
  - But anything above 3 is exceptional
  - For Peter’s patients, he wants to see them at least at 2 watts per kilo

## Measuring and tracking muscle mass and strength [27:30]

For more on this topic, check out [AMA #40](https://peterattiamd.com/ama40/)

\*\*\*

- Appendicular lean mass index (ALMI) is probably the best pure indicator of muscle mass because the DEXA doesn’t have to figure much out other than lean mass and bone in the extremities
- So knowing what your ALMI is, which again is the total amount of lean mass, muscle mass in arms and legs in kilograms divided by your height per meters squared
- You go to the nomogram, and that shows you what your percentile is:

![](https://peterattiamd.com/wp-content/uploads/2024/01/f3-ama55-ALMI-1024x431.png)

**Figure 3.** ALMI nomogram. Source: [AMA #40](https://peterattiamd.com/ama40/)

- The data here are pretty clear that people in the top 25% of ALMI have a distinct survival advantage over others
- People in the bottom 25% have an enormous survival disadvantage compared to everybody else, including those in the second quartile
- “*So you really don’t want to be in that bottom quartile of muscle mass*.”

**Strength [28:45]**

- We have far fewer, really clear metrics that we can point to on strength
- But internally at the practice, they have many, it’s just Peter can’t give the same sort of percentiles to the population

Here are a couple of really good examples of strength metrics:

- A wall sit is a pretty good marker of leg strength
- A dead hang is a pretty good marker of grip strength
- A farmer’s carry is also a pretty good marker of grip strength and overall strength

Some pretty extreme tests would be:

- Can you carry your body weight?
  - Let’s say you weigh 180 pounds. Could you carry 180 pounds for at least a minute?
  - That’s a pretty good marker of strength
  - If you haven’t done that before, you might start at half your body weight
- With a wall sit, two minutes is a pretty good test of leg strength

All of this is to say this information can really help you decide a couple of things

- When you take stock of where you are, you’ll be able to create a little two by two:
  - Are you adequately muscled or under muscled?
  - Are you low in cardio, or are you adequately cardio?

We can now talk about how people in each of those boxes should think about training in the section below

## Case study of a fit person with a neglected pillar: why adding more training volume may not the best strategy [30:30]

Hypothetical person who is already training six or seven days a week but they are primarily a runner

- Now let’s say that person realizes they need to increase their muscle and strength
- That person might think that they should just add strength training on top of their current volume of cardio training

Peter is now going to explain why simply adding more training isn’t necessarily the best strategy if you have a neglected pillar

- Reason number 1: Time
  - The first is just the practical one, which is time
  - If you’re listening to this, you’re already making a huge sacrifice in time, you probably have a career, a family, and so you want to make the most use of your time
  - And for someone who’s already doing a lot of training but is *imbalanced* in that training, that’s one reason not to just add more but instead to substitute for a different type of training
- Reason number 2 is a physiologic one
  - And it really comes down to understanding where you are relative to the **hormetic zone**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f4-ama55.png)

**Figure 4.** Adapted from Source: [Kincaid and Bossy-Wetzel Front Aging Neurosci. Sept 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3764375/#:~:text=The%20antioxidant%20and%20metabolic%20effects,survival%20and%20reduced%20aging%20effects.)

- The X-axis show increasing stimulus—the stimulus can be anything here, but for the purpose of this discussion, it’s exercise
- The Y-axis is the response
  - The further up on the Y axis you go, the more favorable the response, the lower you go, the less favorable the response is
- This shows a dotted line running horizontally across the middle
- The more exercise you add (on the x-axis), the more the response goes up
- And exercise is a stress, and the body has to respond to that stress, and it’s the body’s response to that stress that is invoking the benefit
- At some point, you reach a maximum benefit
- But what happens if you keep going to the right (adding more and more exercise)?
  - At some point, you actually exit the hormetic zone and you have no more benefit
  - And if you go even further to the right, you actually start to reduce the benefit (negative effect)
  - “*You’re exercising now so much and so hard that you’re actually getting no benefit from it despite putting in all of this effort*.”

*Using Peter’s wife as an example*:

- She’s a lifelong runner and she would have no problem running 10 miles a day
- But she came to realize that while she’s a natural runner, strength has not come naturally to her
- Therefore, as she ages, she wants to think about how can she put on muscle mass
- And that means three days a week, she’s lifting weights
- The time she dedicates to strength training comes out of her run time
- That’s one example of a person who’s very fit but imbalanced now making that tweak

***For the hormetic zone, is that something that is set for someone’s life, or is that variable?***

- It changes
- Firstly, it changes acutely due to other stressors
  - When you’re under other forms of stress, either other physiologic stresses or emotional stresses, that’s going to impact the width of your hormetic zone
  - Therefore, your ability or propensity to overtrain might actually go up just on the basis of what’s happening outside of your training
- Secondly, as we age, that window shrinks
  - Your capacity for volume when young is higher
  - All of these things are moving us down a path where we have a narrower, narrower window in which to get the optimal benefit
- Tip from Peter: “*If you’re still in your 20s or 30s…really take advantage of the fact that you are still at a point in your life when you can build up an enormous physiologic reservoir of training and take advantage of this very wide hormetic window*.”

## Periodization training: what it is and why it is beneficial [36:15]

*Let’s say you have someone with low capacity in one area of training and you want to bolster that area*

**Periodization**

- This is a strategy of shifting the focus of training for a finite period of time to make improvements in other areas
- The goal is to spend more time and focus in the areas with greatest opportunity without minimizing or without losing the areas that you’re already optimal in
- Peter will have patients do this in 6 to 12 week blocks, and at the end of the period, they will do something to test and then change if necessary
- Remember, the body is constantly adapting and so if you’re doing the same workout all the time without making a change, your body’s going to get less of a response from it at some point
- That said, it’s possible to do the exact same exercises every time and still make great gains.
  - How do they do it? ⇒ Because they’re challenging themselves in other ways: changing the weight, reducing the rest, increasing the sets, increasing the reps, etc.
  - So there are lots of ways to progressively overload in strength training and cardio training
- But for many people, an easier way to progressively overload is to *change the exercises that you’re doing at these regular periods*
  - Nick points out that it’s important for people to just recognize some of this may be a little uncomfortable at first
  - For example, if you take someone like your wife, who’s a really good runner, and that aspect comes naturally, and then put her in a weight room, there’s going to be new learning and a bit of a struggle

**Brain health benefits of learning a new skill (like strength training)**:

- If you’re listening to this and you’re the **cardio person who’s never lifted weights**, here’s some good news…
- Not only are you going to go into that weight room and struggle, you’re going to get benefit from that that transcends the improvement in your strength and muscle mass
- Your brain is also getting better from the complexity of the movement
  - You’re learning a new skill, and we know that that’s one of the most important things you can do for brain health
- So not only are you going to add muscle, gain strength (which translates to a better runner), but you’ll also improve cognition
- Your brain is actually going to get better because you still have plasticity, and as you are learning a new skill, whether it be how to do a curtsy lunge loaded or how to do a box step up, that’s kind of like learning another language or learning how to play a musical instrument
- And these are the things that we have to maintain for brain health as we age
- Peter says we don’t see as much of an advantage in the other direction (going from strength only to adding cardio)
  - “*Adding in cardio, there’s lots of benefits. But I don’t think you get quite the same neurologic benefits of the learning because of the lower complexity of cardio training in terms of the cognitive load as a skill*.”

## Periodization case study: high cardio fitness, lacking muscle and strength [40:00]

Nick suggests discussing a hypothetical person who does a lot of cardio, has a good VO₂ max, a good zone 2, but they find themselves really low on a [DEXA scan](https://peterattiamd.com/ama44/) as it relates to muscle mass and strength

*What does training periodization look for them to try and start to make progress on those strength pillars that they’re lacking on?*

- Peter first sets up the background on a hypothetical person:
- Peter’s wife would be an example of one of these people before she made recent changes
- Five to six days a week of cardio, tend to be relatively lean, not a huge amount of muscle mass, not necessarily that strong either
- A lot of times, these types of people tend to get nagging little injuries
  - We think of cardio as not requiring strength, but if you use running, for example, running requires a lot of strength.
  - And when you don’t have as much strength as you should, your dynamics and your gait tend to be somewhat compromised
  - And so it’s not uncommon for these people to kind of have nagging little injuries in their hamstrings, calves, knees, and feet
- So these people are going to show up with a relatively low *training age*
  - Your “training age” is how long you have been training, not your actual age, but it’s the duration of years of training

**Training plan for a hypothetical patient**

Peter is going to explain what he would prescribe for a patient whose cardio goals are no longer competitive—someone who has basically been a cardio junkie their whole life because they think they should be and they really don’t need to be doing as much:

- Monday and Tuesday is strength training focused on getting stronger
  - Monday is lower body strength in a lower rep range, higher load
  - Tuesday, upper body strength, lower rep range, higher load
- Wednesday is going to be zone 2 cardio, followed by some short VO₂ max intervals
- Thursday and Friday will be strength training focused more on muscular endurance
  - Thursday is going to be lower body strength but at moderate rep range, moderate load
  - Friday, also strength training, upper body, moderate rep range, and moderate load
- Saturday would be a zone 2 cardio with VO₂ max intervals
- Sunday would be either a rest day or just a zone 2

“*That’s a big shock to somebody’s system, but the person I’m doing this to has probably an ALMI in the bottom 10% of the population and a very high VO₂ max*.” says Peter

**How often should you check and recheck numbers on DEXA scans?**

- Peter says he would recommend waiting at least 6 month in between DEXA scans
- He would also encourage people to only have repeat DEXA scans on the exact same machines
  - The machine-to-machine variability is big enough that it’s very easy to miss the type of changes that a person could gain in six months
- Peter notes that this person will see quite a bit of changes in six months, especially if their nutrition matches the change in their training

## Periodization case study: adequate muscle, low cardio fitness [44:45]

Let’s say we have a person who has always done strength training

- They do a DEXA scan and have really good [ALMI and FFMI](https://peterattiamd.com/ama40/)
- But they really struggle with cardio and they don’t do much cardio training

*What could that 6 to 12-week periodization training look like for them?*

- This person is more often than not a male
- It’s usually a younger guy who loves lifting, has tons of muscle mass, and when he gets on the bike to do a VO₂ max test, he’s really suboptimal
  - By the way, not in absolute terms, but for his age, he’s really, really bad
  - Peter has seen guys in their 30s whose VO₂ max is in the 30s (really low)
- The idea here is to do basically the reverse of what we did in the previous case

What would that look like?

- Peter does not want them to lose much muscle mass or strength, but they need to make time for cardio
- The easiest way to do this is to keep the intensity of their workouts comparable but dial back on the overall volume
  - For example, if they’re previously doing 5×5 on deadlifts, change that to 2×5
  - If they’re doing 3×12 squat, we might take that down to 2×12
- Again, this strategy will allow for less tissue stress, systemic stress from their strength training and allow them to have more linear progress with their cardio workouts
- For this person out of the gate, Peter is not going to have them do any VO₂ max training (note: this is an extreme example and there are clearly some people who we will do some VO₂ max training from the start)
- But for this very extreme example, it’s all going to be zone 2 in this first 12-week cycle

Program:

- **Monday, Wednesday, Friday**, would be zone 2 for 45 minutes each day
- **Tuesday, Thursday**, would be full body strength training
- **Saturday**, a bit of high-intensity cardio, but wouldn’t push him to VO₂ max-level intervals: something like 30 second bursts to wake up the anaerobic system
- \*Side note regarding VO₂ max intervals:
  - VO₂ max intervals are best done between three and eight minutes of maximal intensity
  - In other words, you can train VO₂ max at shorter intervals, 30 second high intensity-interval, but it’s not as efficient
  - If you really want to hit VO₂ max, you got to be between about three and eight minutes
  - Personally, Peter does about 4 to 5 minutes with a one-to-one recovery (e.g., 1 min all out, and 1 min rest, repeat)
  - Before doing this, you need to have a broad base of aerobic power
- **Sunday** for this person could be rest or could be another zone 2 if they’re ambitious
- So this person could be up to 5 days a week of doing something cardio, but at a minimum Peter says do 3

## Case study: significant improvement needed across all exercise pillars [48:45]

The last case study example is the person who likely represents a large percentage of folks

- Someone who hasn’t been exercising, or they have been exercising but without a clear goal in mind, and so they find themselves deficient in all four pillars of exercise
- This is probably the largest bucket of people in absolute terms
- There’s going to be a lot of people listening to this, who when they put their metrics to the paper, they’re going to be deficient in cardio output, muscle mass, and strength

The good news: This is a very malleable system, but it requires the most work and the most time

- And this is the two-edged sword of exercise:
  - Nothing comes close to having a greater impact on the length and quality of your life than your training
  - But you have to do the work, there’s no easy way around it

> “Nothing comes close to having a greater impact on the length and quality of your life than your training. And unfortunately, we can’t put it in a pill. You’ve got to be able to do it. There’s no biohack for it.” —Peter Attia

**Training plan for this hypothetical person**:

- **Monday, Wednesday, Friday** is strength training
  - Each strength training day will be a full body workout with medium to higher rep ranges
- **Tuesday and Thursday** would be zone 2 cardio
- \*Side note
  - By the way, for these patients Peter says we’re just using RPE to gauge zones
  - They are not testing lactate in these people because they’re often very deconditioned and at rest their lactate is usually already 1 or even 2 millimole
  - He usually isn’t having them use heart rate either
  - In some cases, he’ll have them use the [Maffetone formula](https://philmaffetone.com/180-formula/), 180 minus your age and then maybe throw another discount on that
    - Check out [episode #144 with Phil Maffetone](https://peterattiamd.com/philmaffetone/)
  - But RPE is usually ideal for getting someone started
- **Saturday**: If this person’s feeling ambitious, Peter might throw in a high intensity cardio interval day on Saturday, but usually not if it’s their first time doing this and instead he’d have them do some activity
  - Go hike or do something enjoyable, go for a lightweight ruck, etc.
  - “*I want them to start to experience the benefits of their newfound superpower.*”
- **Sunday** could be a rest day or an optional zone 2 cardio

**For these people, let’s say they’re in the category of just starting to work out.**

*What advice would you give to people on how hard they push it if they haven’t been training?*

*Is it okay to take it slow to start to build up as opposed to just hitting it really hard if you’re in this bucket?*

- It is absolutely okay to take it easy
- The objective is to do the workout and there’s no metric we care about
- Here we’re building muscle memory and we’re building habit
- Honestly, the success for this patient or any of these patients is getting to the end of that 12-week cycle and having some affection for the new thing they’ve done
- If we’ve done that, great, we can dial up the intensity in the following cycles

**Why training both zone 2 and VO2 max is crucial**: [53:30]

*If someone came to you and said, “Look, I need to work on my cardio respiratory, I need to build that, but I’m only going to focus on VO2 max because that’s where we have the data and I really want to increase the category and I’m not really going to focus on zone two.” What would your response be to that person?*

- Peter explains the cardiorespiratory system as an isosceles triangle, emphasizing the importance of maximizing both the width (zone 2) and the peak height (VO2 max) to achieve the largest area.
- He dismisses the idea of exclusively training VO2 max, citing the Tour de France athletes who dedicate 80% of their training volume to zone 2, showcasing the significance of a comprehensive approach to cardio training for optimal efficiency

## Best ways to do zone 2 exercise and how to use relative perceived exertion (RPE) to find your zone 2 level [56:30]

***If someone’s going to start doing zone 2, what are some of the devices they can do zone two on?***

- You can really do zone two on anything that demands METs of you
- The key is that you just have to **be able to sustain it without much interruption**
- Again, the easiest way to do this is on a bike or on a treadmill because you have complete control of the activity
- A bike is great, you dial in how many watts you want to be able to experience and away you go
- For most people on a treadmill, walking on an incline is the best
- Most people aren’t really fit enough to run in zone 2 unless they’re really, really running slowly, at which point it’s just more efficient to walk uphill
  - However, a good runner could easily run slowly in zone 2
- But when people are generally starting out, best to have them start out on a bike or have them start walking on an incline
- Peter will tell people to set the treadmill to a pace that is a brisk but manageable walk (typically between 3-3.5)
- From there, they’re going to dial up the incline until they reach that RPE
  - For some people that’s at 6 degrees, for others its 12-15
  - Whatever the number is, that’s going to be a very predictable way to do it
- StairMaster is another great way to do it
- Rowing machine, very difficult for most people because they lack the rowing mechanics
- You can definitely do it with a ruck sack outside but you’ve got to find ground that’s consistent enough that you can set the pace

**Relative perceived exertion (RPE):**

*Can you just give an example of if you were talking how it would sound if you’re hitting that zone 2?*

- Talking during zone 2 should be doable but a little uncomfortable
- Another litmus test for Peter is he’s at the limit of his capacity to exercise with his mouth shut (i.e., breathing from his nose)
- If you can’t hold your pace for an hour without stopping then you are not in zone 2

**A comprehensive graphic that looks at all three of the case studies discussed above**:

![](https://peterattiamd.com/wp-content/uploads/2024/01/f5-ama55.png)

**Figure 5.**

## How the body responds to physical and emotional stress, its impact on training, and the consequences of chronic stress [1:01:00]

*How does that stress potentially affect their exercise, because a lot of times people will exercise to de-stress in a way?*

*Help people understand when someone feels stress, how does the body respond to that automatically?*

- Exercise a tool that we use to help us manage stress
- But then how does stress negatively impact exercise?
- Both of those things can be simultaneously true, so we should be able to think through those things

How the body responds to stress:

- Any sort of physical or psychological stimulus or set of stimuli that disrupt homeostasis are considered stressors
- The body is remarkable at maintaining homeostasis in so many areas that we all just kind of take for granted
- Peter says that pH being the most remarkable homeostatic driver of the body—how perfectly we can keep our pH at exactly 7.4
- Temperature is a remarkable homeostatic point
- Osmolality and concentration of potassium are other examples
- Everything in the body is geared towards regulating glucose levels—even somebody with type 2 diabetes, still in the grand scheme of things, has relatively clear levels in which glucose resides

> “But just understand that as physical and psychological or emotional stresses are introduced to the system, the ability to maintain homeostasis goes down and as it goes down, things go wrong in the body.” —Peter Attia

- Now, if those things are out of whack for short periods of time, it doesn’t really matter
- The body was designed to handle that and it will revert to normal very quickly

First, we will discuss the fast response to stress, the “fight or flight” response, which comes from the activation of the sympathetic adrenal medullary axis

![](https://peterattiamd.com/wp-content/uploads/2024/01/f6-ama55.png)

**Figure 6.** Source: [Carlton et al. Burns Trauma. Feb 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7901707/)

- The adrenal glands are so small, but really important
- It has two components: the cortex and the medulla and here we’re talking about the medulla
- This is really the fastest form of response to a stressor that is a real threat to your life
  - Think about all the evolutionary things that could have done that
- You basically have sympathetic neurons that fire from the brainstem, telling the adrenal medulla to release adrenaline and noradrenaline also known as epinephrine and norepinephrine.
- And these result in massive physiologic changes, literally within seconds
- So the process of these messages being sent from the brain to the adrenal glands take less than a second
- And in as little as 3-10 seconds, the adrenaline and the noradrenaline reach their systemic targets, raising blood pressure, raising glucose levels, increasing hepatic glucose output, breaking down fats for lipolysis
  - So basically creating a flood of energy into the body and a flood of cardiovascular tools that are ready to use it
- Why does this happen?
- Well, let’s use the classic example of encountering a lion:
  - This is a life or death situation, so it’s a maximum flood of resources to make this happen
  - This lasts for a very short period of time, and within as little as 20 minutes, epinephrine and norepinephrine levels will return to normal
  - This is a very healthy adapted response to stress

**Cortisol**

*And so where does cortisol fit with everything just stated?*

- Cortisol is basically the other side of this
- There are really two halves to this whole stress response:
- 1) The system Peter just described, which goes from the locus coeruleus down to the release of epinephrine and norepinephrine, that is this sympathetic adrenal medullary axis
  - That is very, very fast and profound physiologic changes that vanish within minutes.
- 2) The other side of that, the hypothalamic pituitary adrenal access is much slower, relatively speaking, and can stick around for a very long period of time
  - This originates in the hypothalamus and the hypothalamus releases cortisol releasing hormone to the pituitary, which then tells the pituitary secrete ACTH, which then tells a different part of the adrenal gland, the cortex, to release cortisol
- Now what does all of that do?
  - So cortisol will be elevated within 10 minutes from the onset of that stressor
  - Relatively speaking, that’s much longer than what we were talking about with the first response, which can be seconds

*What benefit is there to have something that doesn’t kick in for 10 minutes?*

- You just got attacked by another person, which again would be a very common scenario, but for our ancestors, in 10 minutes the thing could be over.
- But it turns out that there are a lot of things where you still want to be able to preserve a stress response for more than just the acute insult of the lion chasing you or scratching you, because now you might be having to cope with a hostile environment
  - You might need to be able to avoid dehydration.
  - You might need to stay vasoconstrictive for a longer period of time to prevent blood loss.
- So there are clearly evolutionary important reasons why this slower, more chronic stress axis would be important.
- But the point is it should go back to baseline once the threat is gone
- Where we get into real challenges as humans in the modern environment is for many of us, the adaptive stress response never fully normalizes
- Chronic stress, stress from our lives that doesn’t actually have to do with a threat to our lives, can become the new baseline of stress
- Paradoxically, many of the things that were hugely valuable to us 10,000 years ago become a detriment today
- For example, when you look at energy conservation
  - One of the responses of cortisol would be anabolism towards the fat cell for energy conservation.
  - That of course speaks to obesity and metabolic syndrome today,
  - ways that we would retain fluid and electrolytes to address dehydration. Of course that leads to hypertension today.
  - The way we would combat injuries by having a heightened sense of an immune response, of course today would be autoimmunity.
- So it goes on and on and on, where the same appropriate level of arousal and fear might produce anxiety or insomnia today.
- So all of the things that were selective advantages under the scenarios where we didn’t live in a modern world can often become deleterious in the world today with the chronic elevation of stress.

In summary, you have these two parallel stress systems:

- One that functions mostly through adrenaline and noradrenaline
- And one that functions through cortisol
- The first one is much quicker—it basically goes straight from the brain to the adrenal gland
- The second one has to go through the pituitary first and it takes a little bit longer, but it’s also the one that sticks around longer
  - And frankly, it’s the one that’s causing us much more trouble in the modern world.

## The difference between “good” stress and “bad” or chronic stress [1:10:30]

***What is the body’s actual difference in response from the “good stress” to what can be the result of chronic stress?***

Three stages of chronic stress

1 – the alarm reaction stage

2 – the resistance stage

3 – the exhaustion stage

- The alarm reaction stage is the initial symptoms of the body under the acute stress
- So that’s the one that runs in parallel, that fight or flight response.
- And that has kind of a recovery that’s going to run with it.
- But again, the body’s going to continue to secrete stress hormones, primarily glucocorticoids such as cortisol to keep the body’s physical response elevated to cope with the fallout of whatever the acute response was.
- Initially, these glucocorticoids cause the release of stored lipids and amino acids and flood glucose into the system—they’re very pro-energetic
- But prolonged exposure to cortisol, what we call **hypercortisolemia**, that which many of us are suffering from today, can actually have the exact opposite response
- It can lead to muscle wasting, which is probably thought to occur because of the decreased rate of muscle protein synthesis and the induction of muscle protein catabolism to basically try to get more amino acids
- We also see the increase in lipogenesis
- That all means that in the long run, high levels of cortisol are doing exactly what we don’t want to do.
- They are anabolic tissues we don’t want to make bigger, our fat tissue
- And they are catabolic to tissues that we want to make bigger and not smaller, namely our muscles.
- We did not evolve to have cortisol levels stay this high for this long

> “So high levels of cortisol, over a long enough period of time, make your fat cells fatter and your muscle cells smaller.” —Peter Attia

**Four endocrine systems and ability to treat them**

- There is no more endocrine condition that is difficult to treat than this one
- There’s basically four big endocrine systems
  - Sex hormone system ([male](https://www.youtube.com/watch?v=K63K8F39Z4M) and [female](https://www.youtube.com/watch?v=NTBkJzSPDCA))
  - Thyroid system ([video](https://www.youtube.com/watch?v=DHM5X9Tqjuw&t=647s))
  - Fuel partitioning system, so the insulin glucagon, GLP one, that whole system,
  - Then you have these stress hormone systems
- The hardest system by far to manipulate is the hypercortisolemic system because we don’t have a really good drug to turn that off
  - We have things that we can use—ashwagandha, phosphatidylserine, etc.
- But at the end of the day, this is primarily an emotional state
- And this gets to: *how can we use exercise to help manage that without hurting ourselves more by exercising?*

## The complex relationship between exercise and stress, and the importance of adjusting exercise goals during high-stress periods [1:13:30]

Many people think of exercise as a way to cope with stress and a way to de-stress and a way to kind of feel better about the stresses in their life

But other life stresses we talked about can affect training exercise decisions

How can someone know which side they’re on a given day: *Could exercise help with stress that day? Or could exercise be adding to it and negatively affecting them?*

- Below is a great to illustrate what’s happening with the additive loads of chronic stress over time:

![](https://peterattiamd.com/wp-content/uploads/2024/01/f7-ama-55-stress-.png)

**Figure 7**. Source: [Lee et al. BMB Rep. Apr 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4436856/)

- This shows time on the horizontal axis and stress on the vertical axis
- Imagine a sign curve, but it’s not horizontal, it keeps undulating up into the right
- the curve represents the level of stress, but what you’re looking at is peaks and valleys that are net accumulating, so the peaks are getting higher as are the valleys
- what this figure is basically showing you is that with acute stressors, you have ups and downs, but with chronic stressors, you’re raising the set point
- That’s a process known as allostasis
- Allostasis refers to an adaptive process that is used to maintain homeostasis using basically mediators of chronic stress
- This is the real problem for most of us
- Stress is the killer and this is how it’s doing it…it’s basically raising your set point higher and higher and higher over time

Thinking back to the Figure 4 about the hormetic zone

- You have that window in which you can get benefit versus harm from exercise
- Well that window is not just shrinking because our physiologic body is changing, but because most of us are accumulating allostatic load of stress as we age
- you have two reasons why we can tolerate less and less exercise as we age
  - 1) we’re accumulating stress
  - 2) we’re physiologically not as robust as we were when we were young

**Rucking for de-stressing**

- Peter shares his experience with rucking and the initial temptation to focus on performance metrics like heart rate and pace
- However, he realized that this approach conflicted with the stress-relieving purpose of the activity
- To combat this, he decided to ditch the watch and any form of technology, creating an environment solely focused on being in nature and relieving stress

**Exercise as a net benefit to stress but know when to dial it back**

- Overall, there are net benefits of exercise for stress
- But Peter advises adjusting exercise goals during high-stress periods, shifting the focus from performance to persistence and consistency and just think about preserving performance during that time of high stress
- This is especially important for people who are overwhelmed with the sense that they need improvement on every aspect
- Peter also emphasizes the importance of not getting injured which would add significantly to stress

## Clues that stress may be impacting your training [1:19:15]

*When trying to understand if one’s stress from life is impacting their training, what are some clues that they could be looking for in the gym that would help them understand that?*

- It’s important to understand that the body is not particularly well tuned to differentiate between whether the allostatic training ceiling that is going up or the floor that’s going up is in response to physical overtraining or psychological stress
- So everything Peter is about to say applies to both and it basically says you’re “overtrained”
  - Are you overtrained because you’ve been training too much or are you overtrained because your hormetic window is now so small that even a modest amount of training is pushing you out of it?
  - That requires more inquiry, but the signs are actually the same
- Basically it’s going to come to a reduction in performance, and it usually shows up as not being able to get into the zone
  - Like a reduction in wattage on the bike which is, of course, power and a reduction in cadence and heart rate
  - It might feel like…  “Can’t turn the pedals over on the bike, can’t get my cadence high enough, can’t get my heart rate high enough, can’t hit the wattage I’m used to hitting.”
- In strength training, it’s a 10% drop off in speed or a reduction in velocity in training, which is really a reduction in power

“*When those things occur, I’m under too much stress, which either means I’m over-training or I have too much psychological stress in my life*.” says Peter

## The use of wearables and devices for tracking trends and making decisions related to training [1:21:00]

*Are wearables helpful for making training decisions, and how should individuals consider the data from wearables in their training routines?*

- Peter admits this is a bit of a complicated question
- Peter has recently been using [Morpheus](https://trainwithmorpheus.com/) to assist with understanding recovery
- Every single morning before he gets out of bed, he puts on the heart rate monitor and he’ll lay still for 3 minutes as it measures his heart rate and his heart rate variability
- He then answers a few questions
  - How long did I sleep?
  - Sleep quality?
  - And he then puts in a subjective score from 1 to 5 about his sleep
    - (his sleep data comes from his [Eight Sleep](https://www.eightsleep.com/))
  - He also inputs how sore he is
  - And how good do he feels with respect to his desire to exercise that day
- With that info, Morpheus app spits out a recovery score and more importantly, it spits out heart rate zones
- One of the numbers corresponds to what Peter believes is probably about the zone 2 ceiling
- Peter has noticed over the last 9 months or so that any time he does a zone 2 workout, he’s noted what the app told him his zone 2 HR would be and then compared it to he own RPE number and/or his lactate numbers
- Peter’s feeling is that the Morpheus zone 2 HR is a pretty good tool at predicting his heart rate for zone 2, though it doesn’t appear to be as good as RPE
- That being said, of all the wearable devices Peter’s seen, he thinks Morpheus is in a league of its own in terms of having the most actionable, predictable and valuable information
- “When you look at other devices that just spit out recovery scores, I don’t find those useful in the least” says Peter
- The raw data from most devices can be pretty useful, however, especially if you are focused on the trends
  - What are the trends in your morning resting heart rate?
  - What are the trends in your heart rate variability?

Trends are what matters, not the absolute numbers

- If your lowest resting heart rate overnight is consistently elevated and, or your heart rate variability is consistently depressed, that is more interesting than what the recovery score is on any given day as just an abstract number
- You don’t need a wearable to tell you that—anybody can just check their heart rate in the morning
- If it’s persistently elevated, you can then ask the question, “Hey, are there other reasons why this might be the case? Did I not sleep well? Did I drink too much alcohol last night? What’s the issue going on?”
- But as a general rule, these become really simple and yet valuable tools to help you understand how hard or not hard you might want to push for a given day

**More about trends**

*So when you look at trends, are you looking at is that trends for the week? Is it trends for the month? Is it trends for a few days?*

- Peter provides an example related to his elevated heart rate after hunting elk at high elevations, noting that it takes two weeks for his heart rate to return to normal.
  - His normal resting heart rate in the morning is in the mid to high 40s, but when he came back from Colorado, it was in the mid to high 50s for about 2 weeks
  - Peter says he training performance wasn’t impacted much during this period, however, he did notice his heart rate was a little lower than what he would expect at a given RPE
- Peter mentions past use of technical metrics like [Training Stress Score (TSS)](https://help.trainingpeaks.com/hc/en-us/articles/204071944-Training-Stress-Scores-TSS-Explained) based on power meter data, which offers nuanced insights into training intensity and duration. TSS is used by serious athletes
  - It’s a really detailed way to take power, normalized power, training intensity, training duration and accumulate that over the course of a week and give you much, much more nuanced insight into how hard to push and when to back off
- More technical metrics include:
  - The most general way to calculate your current training load is the sum of all your training sessions over a week with the load of each sessions calculated as: Training Load (TL) = subjective RPE x duration (mins) of the session
  - TSS also extends to running and swimming which you can learn about [here](https://help.trainingpeaks.com/hc/en-us/articles/204071944-Training-Stress-Scores-TSS-Explained)

Simple clues to monitor

- Despite these available technical metrics, Peter suggests simpler tools like monitoring morning heart rate, assessing personal training goals, and observing physical responses during activities to gauge stress levels.
  - What’s your heart rate in the morning?
  - How much do you want to train?
  - And more than anything else, what happens to you when you are doing your activity?
  - Are you having a hard time turning the pedals over?
  - Are you having a hard time getting your heart rate to respond?
- If you are having a hard time getting your heart rate to respond, you’re probably overstressed, where stress can be physical or psychological.

**When to make the decision to stop the workout**

- Peter had a recent personal experience with this
- He hopped on a bike on a Tuesday morning to do a zone 2 and was having a hard time turning the pedals over at 70 RPM when he’s typically between 80 and 95 RPM
- 10 minutes into the warmup and he was struggling—heart rate was very low (~100 beats per min), felt like he was pushing bricks, and he just aborted the workout
- Peter says he has a day like this once every 2 or 3 months
- After the fact, he attributed this recent experience to the fact that he did exceptionally challenging lower body workouts on Sunday and Monday
- In retrospect, it’s really not that surprising that on Tuesday his legs just weren’t going to do anything—”*The body made it crystal clear*”
- Interestingly, his heart rate that morning was not any higher than it was in the other couple of days in relation to it
- So Peter wishes there was a more scientific way to do this, but this is where the art comes in

> “The more you train, the more you get to learn your body and you become the expert in the one thing that means the most, which is how you are going to respond to stress.” —Peter Attia

## Parting thoughts regarding the importance of exercise for longevity and stress management [1:32:00]

***Any last bits of advice you would have for people based on what we discussed so far today?***

- The big picture here is, *why do so many of our podcasts touch on so many various themes of exercise*?
- Because ultimately, there’s simply nothing that we can muster up doing or taking as a species that impacts length and quality of life more. Nothing comes close
- Specificity really matters and that no one is too old or too unfamiliar with training to start training
- There’s an on-ramp for everyone, but you have to know where you are in the mix to know how to go about kicking this thing off

**Regarding stress**

- As far as stress, Peter can’t overstate this enough
- It’s such a cliche, but [Robert Sapolsky](https://en.wikipedia.org/wiki/Robert_Sapolsky) was really onto something saying that [stress is a killer](https://peterattiamd.com/robertsapolsky/)
- It may seem like a bit of a soft science since we don’t have the same biomarkers
- Measuring total cortisol levels in the blood is useless because it’s really the free cortisol that matters
- And even cortisol by itself is not sufficiently alone to help you understand the negative impacts of stress
- With that said, just acknowledging that and acknowledging how that factors into our training and how hard we push ourselves and how that needs to be part of the training equation is important
- At the same time, using exercise can be one of the most important tools we have to mitigate and buffer the negative effects of that stress
- “To me, it’s like the holy grail of how we can get even more benefit out of exercise beyond the obvious benefits that come from the recovery, from the hormetic stress.”

**Overtraining/stressed and data from wearables**

- As far as when you’re overtrained, the body doesn’t know the difference between you’re overtraining because you’re running 20 miles a day or you’re overtraining because you’re under so much stress
  - Your performance, your heart rate, maybe to some extent, your heart rate variability are probably the most important tools
- Peter doesn’t know if he’s seen much value in a lot of the wearables (other than [Morpheus](https://trainwithmorpheus.com/)), especially in their subjective assessments of recovery
  - “I haven’t found those to be helpful though I think the raw data of resting heart rate can be helpful.”

§

## Selected Links / Related Material

**Peter’s book**: [OUTLIVE: The Science and Art of Longevity by Peter Attia](https://peterattiamd.com/outlive/) (peterattiamd.com) [6:00]

**One of the two largest papers that has ever looked at the relationship between VO2 max and mortality**: [Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) (Mandsager et al., 2018) [18:00]

**Episode of The Drive that discusses body composition and ALMI**: [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com) [27:45]

**Iñigo’s indirect method to assess metabolic flexibility and oxidative capacity**: [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://pubmed.ncbi.nlm.nih.gov/28623613/) | Sports Medicine (I San-Millan and GA Brooks 2018) | [26:00]

**Formula created by Phil Maffetone that helps determine heart rate zones such as zone 2**: [The MAF 180 Formula](https://philmaffetone.com/180-formula/) | (philmaffetone.com) [51:15]

**Episode of The Drive about HRT**: [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.](https://peterattiamd.com/joannmanson/) | (peterattiamd.com) [1:13:00]

**Peter’s videos about the sex hormone system**: [1:13:00]

- [Male sex hormone system: how it works, testosterone, low T symptoms, TRT, and more](https://www.youtube.com/watch?v=K63K8F39Z4M) | Peter Attia M.D. (youtube.com) [1:13:00]
- [Female sex hormone system: PMS, menopause, hormone replacement therapy, and more](https://www.youtube.com/watch?v=NTBkJzSPDCA) | Peter Attia M.D. (youtube.com)

**Peter’s videos about the thyroid system**: [The thyroid system: how it works, common problems, hypothyroidism, T3, T4, TSH, & more](https://www.youtube.com/watch?v=DHM5X9Tqjuw&t=647s) | Peter Attia M.D. (youtube.com)[1:13:00]

**The app Peter uses for monitoring heart rate and HR variability, and more**: [Morpheus](https://trainwithmorpheus.com/) | (trainwithmorpheus.com) [1:22:15]

**The tool uses to monitor his sleep**: [Eight Sleep](https://www.eightsleep.com/) | (eightsleep.com) [1:22:30]

**Episode of The Drive about stress with Robert Sapolsky**: [#51 – Robert Sapolsky, Ph.D.: The pervasive effect of stress – is it killing you?](https://peterattiamd.com/robertsapolsky/) | Peter Attia (peterattiamd.com) [1:33:00]

§

## People Mentioned

- [Meb Keflezighi](https://en.wikipedia.org/wiki/Meb_Keflezighi) [5:00]
- [Iñigo San-Millán](https://peterattiamd.com/inigosanmillan2/) [26:00]
- [Robert Sapolsky](https://en.wikipedia.org/wiki/Robert_Sapolsky) [1:33:00]

§