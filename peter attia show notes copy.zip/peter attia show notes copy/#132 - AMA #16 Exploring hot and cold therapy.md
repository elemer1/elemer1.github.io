# #132 – AMA #16: Exploring hot and cold therapy

**Source:** [https://peterattiamd.com/ama16/](https://peterattiamd.com/ama16/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob explore the quality of evidence for hot and cold therapy. In the discussion, they evaluate the safety, efficacy, and opportunity costs of various hot and cold therapy protocols, and Peter ultimately considers the addition of dry sauna to his longevity toolkit. Once again, Bob Kaplan, Peter’s head of research, will be asking the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA.

If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #16 show notes page](https://peterattiamd.com/ama16/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- How stress can show up as physical pain, and tips for changing time zones [1:45];
- Literature overview of heat and cold therapy [7:15];
- Cold therapy for delayed onset muscle soreness (DOMS) [12:00];
- Quality of evidence for cold therapy for depression or immune enhancement [19:30];
- Cold therapy and brown adipose tissue (BAT) [21:15];
- Weighing the safety, efficacy, and opportunity cost of cold therapy [28:45];
- An overview of heat therapy benefits [40:00];
- Longevity benefits of sauna—reviewing the studies [41:30];
- Limitations in the sauna literature—Where might we be fooled? [54:30];
- Possible mechanisms conferring the longevity benefits of sauna, and how it compares to exercise [1:02:15];
- Parting thoughts on sauna, opportunity costs, and Bob’s personal regimen [1:06:30]; and
- More.

§

The Peter Attia Drive

Exploring hot and cold therapy

§

## Show Notes

## How stress can show up as physical pain, and tips for changing time zones [1:45]

**Peter’s recent move to Texas**

- Peter recently finished moving his family from California to Texas
- All things considered, it went well, but he did experience some added stress
- In fact, his therapist told him, “Just to set your expectations, a move of this nature is among the three most stressful events to your marriage. . .on par with divorce and death.”

**How stress can show up as physical pain**

- In the weeks leading up to the move, Peter was experiencing some physical pain in his body
- Amazingly, the pain dissipated once the move was complete
- He calls it an “aha moment”
- Mechanistically, it’s hard to explain “why higher levels of cortisol. . .would actually lead to physical pain in my body. But there’s no question about it.”

**Tips for adjusting to a new time zone**

- Prior to making the move, Peter’s family slowly adjusted their bedtime and wake schedule over the course of 10 days
- By the time they made the move, their internal clocks had already adjusted

**Jet lag protocol**

Example:

- Say you are going to London where it’s 5 hours ahead
- On the day of departure, the idea would be to wake up super early to match London time (e.g., 3am)
- That will allow you to be sleepy at a normal time once in London

⇒ See [AMA #4](https://peterattiamd.com/ama04/) for the complete jet lag protocol

## Literature overview of heat and cold therapy [7:15]

**Peter and team’s research project**:

- Peter’s research team has put extensive effort into understanding the current literature on heat and cold therapy
- The idea was to see if there was any reliable evidence that showed either heat or cold therapy to impact lifespan or healthspan
- Often, heat and cold therapy studies are lumped together when they are really separate topics

An example of “lumping” is clearly seen in a large [editorial paper](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/EP087450) that claimed heat and cold could positively impact in several ways:

1-A wide range of physiological responses including:

- resistance to cardiovascular disease and mortality
- endothelial function and arterial stiffness
- walking ability and lower limb perfusion; shear pattern, blood pressure and circulating endothelin‐1 concentrations
- glucose metabolism
- autonomic nervous activity
- cerebral protection
- stress resistance

\*NOTE: all the references cited for these benefit listed above were related to HEAT therapy

2-Another claim was an improvement of **mental health** (the only place where they cited a paper looking at cold therapy)

- The supporting evidence for those were lackluster to say the least
- And the only cold [paper](https://pubmed.ncbi.nlm.nih.gov/30131418/) referenced was an n=1 using cold water swimming which had confounding variables

## Cold therapy for delayed onset muscle soreness (DOMS) [12:00]

**Cold therapy for DOMS (delayed onset muscle soreness)**

- In their research, Peter’s team found that there was evidence that ice baths could help reduce DOMS ([Stacey et al., 2010](https://pubmed.ncbi.nlm.nih.gov/20479533/); [Montgomery et al., 2008](https://pubmed.ncbi.nlm.nih.gov/18608847/); [Bleakley et al., 2012](https://pubmed.ncbi.nlm.nih.gov/22336838/); [Leeder et al., 2011](https://pubmed.ncbi.nlm.nih.gov/21947816/); [Burgess and Lambert, 2010](https://journals.co.za/content/ismj/11/2/EJC48394?fromSearch=true))
- But it will depend of how and when you do it
- The greatest benefits to reducing DOMS occurred when treated 24 to 72 hours post exercise
- Treatment should not be administered in the first hour post exercise.

*Peter’s anecdotal experience*: Peter found ice baths to be extremely helpful following his long bike rides in the heat (but admits it could have been placebo)

⇒ See Jens Voigt: “[Shut up, legs.](https://www.youtube.com/watch?v=cFbhBjalpN8)”

***Reducing DOMS related to strength training***

- The greatest benefits to reducing DOMS occurred when treated **24 to 72 hours post exercise**
- However, when strength training, there is an inflammatory response post-exercise that is beneficial
- And since the cold therapy could reduce inflammation, you have to think about that **tradeoff**

*The tradeoff*: If you overly suppress the inflammation, you could **blunt some muscle hypertrophy**

- Some recommendations found in the literature say you should not administer cold therapy in the first hour post-exercise
- Most of the studies showed actually that no benefit for performance
- While other studies suggested that it might even be detrimental to strength (due to the blunting of the inflammatory response from exercise)

**Speaking of inflammation — Does taking** [**ibuprofen**](https://en.wikipedia.org/wiki/Ibuprofen) **post-exercise blunt hypertrophy?**

- It may have a positive effect on reducing pain, but a negative effect in terms of the training response
  - Here’s a [piece](https://www.nytimes.com/2017/07/05/well/move/bring-on-the-exercise-hold-the-painkillers.html) on this topic in the New York Times
- [Michael Ristow](https://en.wikipedia.org/wiki/Michael_Ristow)’s group [found](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2680430/) that taking antioxidants after exercise—which people thought would be a good idea because you would lower the inflammatory response—prevents health-promoting effects of physical exercise in humans

[**Acetaminophen**](https://www.drugs.com/acetaminophen.html) **(Tylenol) for improving performance exercise**

- Acetaminophen, on the other hand, actually [improves performance](https://pubmed.ncbi.nlm.nih.gov/19910336/) (especially endurance exercise)
- The mechanism of action is not clear—but there are 2 plausible explanations:
  - 1-The reduction in temperature
    - A person who’s running a marathon or doing a really exhaustive kind of thorough endurance event of any nature, their body temperature’s going up
    - And if the TYLENOL offsets that, it speaks to a larger thesis, which is part of our fatigue is in response to thermogenesis
  - 2-The reduction of pain
    - is it’s reducing your perception of pain in the muscle as you exercise. And by reducing that slightly, your brain’s desire to slow you down or stop you is blunted somewhat

**\*The upshot on cold therapy for DOMS**

- It reduces delayed onset muscle soreness, but the timing of when you administer cold matters
- The closer you administer cold therapy to the bout of exercise, the more you may actually blunt the benefits of exercise

## Quality of evidence for cold therapy for depression or immune enhancement [19:30]

**For depression**:

- Pretty clear that we don’t really know if there’s a benefit based on the [2008 study](https://pubmed.ncbi.nlm.nih.gov/30131418/)
- It is possible, but far from established, that cryotherapy could alleviate the symptoms of depression. ([Rymaszewska et al., 2008](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2734249/))

**Cold therapy for immune enhancement:**

The immune system’s response to cold stress is not yet fully understood.

- Some studies have shown that cryotherapy decreases inflammation ([Pongor et al., 2011](https://pubmed.ncbi.nlm.nih.gov/21829501/); [Shephard & Shek, 1998](https://pubmed.ncbi.nlm.nih.gov/10066131/))
- Although, not all results agree. ([Peake et al. 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7339943/))
- Even if it does lower inflammation… we get back to the issue of whether that process is blunting the beneficial inflammation post-exercise
- If cryotherapy is addressing chronic inflammation, that’s one thing, but from the acute perspective, that inflammation might be doing something that’s ultimately beneficial

***Cold therapy summary***: There’s just not a lot of data, and so far it appears to be an “absence of evidence” with cold therapy

## Cold therapy and brown adipose tissue (BAT) [21:15]

**What is BAT?**

- Brown adipose tissue (BAT) derives its name from the obvious fact that it looks different
- It’s fat with little organelles inside of each adipose cell, such as mitochondria, that would change the color a little bit darker

*Why do we care?*

- The mitochondria and other things in it make it more metabolically active and therefore it becomes another energy consumer suggesting that having more BAT may increase the calories you’re burning
- There may be other health benefits of BAT due to “[batokines](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed)”—bioactive peptides and proteins secreted by BAT

*Observations:*

- First, metabolically healthy people have more BAT (and less [white adipose tissue](https://en.wikipedia.org/wiki/White_adipose_tissue)) than less metabolically healthy people
- Secondly, cold exposure activates brown adipose tissue
  - Peter [tested this on himself](https://www.instagram.com/p/B9F0B2vAqr2/) while in extreme temperatures in Norway

**The literature generally explores two things**:

1—Whether increasing BAT increases energy expenditure—which therefore could help with obesity, insulin sensitivity, metabolic health, etc.

- [Ruiz et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29981351/)
- [Betz & Enerbäck, 2015](https://pubmed.ncbi.nlm.nih.gov/26050667/)
- Insulin sensitivity: [Lee et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4207391/); [Chondronikola et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4238005/);

2—The impact of “[batokines](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed)”—bioactive peptides and proteins secreted by BAT

- Possible benefits of batokines:
  - [Heart](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed)—cardioprotection via FGF21 and IL-6
  - [Pancreas](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed)—preservation of beta cells
  - [Liver](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed)—fatty acid oxidation, so presumably it might lower fatty liver, lower white adipose tissue, so you have more lipolysis and more glucose uptake
  - [Inhibition of myostatin](https://joe.bioscientifica.com/view/journals/joe/243/2/JOE-19-0295.xml)—potentially the increase in brown adipose tissue activity inhibits myostatin

![](https://peterattiamd.com/wp-content/uploads/2020/10/batokines-1-1024x736.jpg)

**Figure 1. Schematic representation of the hypothetical role of endocrine factors released by brown adipose tissue (BAT) in interorgan cross-talk. (FGF21: fibroblast growth factor-21; IL6: interleukin-6; T3: triiodothyronine).** Image credit: [Villarroya et al., 2013](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed)

![](https://peterattiamd.com/wp-content/uploads/2020/10/batokines-2-1024x725.jpg)

**Figure 2. Representation of novel brown adipokines and their tissue targets. (BMP8b; Bone morphogenetic protein-8b; NRG4: neuregulin-4; NGF: nerve growth factor; S100b: S100b; FGF21: fibroblast growth factor-21; IL6: interleukin-6; CXCL14: C-X-C motif chemokine-14; GDF15: growth-and-differentiation factor-15).** Image credit: [Villarroya et al., 2019](https://joe.bioscientifica.com/view/journals/joe/243/2/JOE-19-0295.xml)

- BMP8b: adaptive remodelling of brown & beige adipose tissues to thermogenic demands
- NRG4: promotes sympathetic neurite outgrowth
- NGF & S100b: target sympathetic nervous endings promoting innervation
- Myostatin: controls the performance of skeletal muscles
- FGF21: targets the heart, favouring cardioprotective effects
- CXCL14 & IL6: promotes the recruitment of M2 macrophages
- GDF15: inhibits the pro-inflammatory activity of M1 macrophages

![](https://peterattiamd.com/wp-content/uploads/2020/10/wendy-the-bully-whippit-701x1024.png)

**Figure 3. Wendy the bully whippet has a mutation in the myostatin gene.** Image credit: [popsci.com](https://www.popsci.com/muscular-animals-babies-myostatin/)

\*\*\*

**In summary as it relates to BAT and cold exposure:**

- Having more brown adipose tissue appears to play a positive role in health in the ways mentioned above
- But not much evidence that BAT **volume** increases with cold exposure
  - BAT volume actually [changes more so with an improvement in metabolic health via exercise](https://journals.physiology.org/doi/full/10.1152/ajpregu.00021.2014)
- Cold exposure does seem to **activate** the BAT, but it’s unclear whether or not that actually makes a difference
  - Especially when you look exclusively through the lens of energy balance, “*From a caloric expenditure basis, the numbers are not that impressive.*”

## Weighing the safety, efficacy, and opportunity cost of cold therapy [28:45]

**Are there any tangible benefits of cold therapy?**

- From a big picture perspective, there isn’t much evidence that cold exposure increases longevity in one way or another
- If the cold does have a benefit, it might be similar effects to that of exercise
  - For example, [cold exposure activates sirtuins](https://pubmed.ncbi.nlm.nih.gov/15653680/) in brown adipose tissue
    - Similarly, exercise activates sirtuins in skeletal muscles
  - [Cold exposure activates heat shock proteins](https://www.biomed.cas.cz/physiolres/pdf/68/68_419.pdf) as does exercise
- This leads to the question: *Would simply doing more exercise—in place of the time you would otherwise dedicate towards cold exposure—have the same net benefit*?

**Opportunity cost**

- Peter call this “*the single most important point made during the podcast today*”
- What gets overlooked in these discussions is \***opportunity cost\***
- Our order in thinking should be as follows:
  - 1-Safety
  - 2-Efficacy
  - 3-Effectiveness

*Opportunity cost*

- After answering the safety question, you look at benefits—and as we’re seeing with cold therapy, *it’s pretty hard to find real, tangible benefits to cold therapy when you hold the therapy up to the same sort of standard* that we hold other therapies like exercise or heat therapy.
- What about the fact that you just spent an hour doing effectively nothing when that hour could have been spent doing something with a known benefit?

**Any harm in cold therapy?**

Cold therapy is a broad term

- The buckets of cold therapy generally include: [cryotherapy](https://en.wikipedia.org/wiki/Cryotherapy), plunging (ice bath), and cold exposure (mild, prolonged cold exposure)
- Not too much risk in cryotherapy (some blisters and pain during treatment) and mild cold exposure

Cold water immersion has the most risk associated with it, mostly due to [afterdrop](https://en.wikipedia.org/wiki/Afterdrop)

- Under cold conditions, your body tries to keep the core temp as warm as possible but it order to do so your peripheral temperature is colder
- at some point this cold blood in my periphery is going to dump into the warmer core blood
- Afterdrop occurs when your core temperature drops from something safe, like 96-97, to 92-93
- Which could result in an [ventricular arrhythmia](https://stanfordhealthcare.org/medical-conditions/blood-heart-circulation/ventricular-arrhythmia/types.html#:~:text=Ventricular%20arrhythmias%20are%20abnormal%20heartbeats,may%20result%20in%20cardiac%20arrest.)

Peter once experienced afterdrop due to cold water swimming where the water temp was ~53 degrees

- After he came out of the water it was so windy that he lost the coordination in his hands to hold the towel and he couldn’t warm himself up
- He literally had to go find a stranger to dry him off

With cold water plunging…

- sitting in a ~38 degree ice bath
- They’re doing selective elongation of time exposure—Maybe 4-6 minutes
- After getting out of the bath you need to warm yourself up **immediately** because that afterdrop can be devastating
- Basically what happens is in a moment your central temperature can go from being something safe, 96, 97, to something very unsafe, like 92, 93.
- And at that point, you’re very likely to start throwing off [ventricular arrhythmias](https://stanfordhealthcare.org/medical-conditions/blood-heart-circulation/ventricular-arrhythmia/types.html#:~:text=Ventricular%20arrhythmias%20are%20abnormal%20heartbeats,may%20result%20in%20cardiac%20arrest.).

## An overview of heat therapy benefits [40:00]

**Overall**: Peter and Bob are more optimistic on heat therapy versus cold therapy as a potential tool to enhance longevity

**Heat therapy enhances sleep**

- Sauna before bed is one of the best tools to sleep especially if you follow it with an immediate cold dunk just or got into a cold bed
- The reason why is that sleep is so facilitated by the time derivative of temperature—So the change in temperature over time, the steeper you can make that a negative number, the better you’re going to sleep
- And there’s no better way to do that than to ratchet up your temperature in a sauna and then drop it down quickly
- Here’s one [meta-analysis](https://www.sciencedirect.com/science/article/abs/pii/S1087079218301552?via%3Dihub) looking at heating the body before bed for better sleep

**Other purported clinical benefits of heat therapy**:

- **Decreased pain, including DOMS**.  Heat therapy appears to offer analgesic benefits with no risk of detrimental effects. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x); [Hausswirth et al., 2011](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0027749); [Viitasalo et al., 1995](https://link.springer.com/article/10.1007/BF00635877))
- **(Associated) Decreased risk of cardiovascular disease.**  A series of Finnish studies that are some of the largest heat therapy trials found that increasing frequency of sauna usage is associated with a decreasing risk of sudden cardiac death (SCD), fatal coronary heart disease, CVD, and stroke. ([Laukkanen et al., 2015](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2130724); [Laukkanen et al., 2018)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6262976/#CR19)
- **Improved endurance and performance.**  Data on the effects of heat therapy on muscle strength is inconclusive, but heat therapy appears to improve jump height, power, and endurance. Heat therapy may offer performance benefits with a low risk of detrimental effects. ([Mero et al., 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4493260/); [Scoon et al., 2007](https://pubmed.ncbi.nlm.nih.gov/16877041/); [Viitasalo et al., 1995](https://link.springer.com/article/10.1007/BF00635877); [Hausswirth et al., 2011](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0027749))
- **(Associated) Decreased risk of dementia and Alzheimer’s Disease** with more frequent sauna visits associated with a larger decrease. ([Laukkanen et al. 2017](https://www.researchgate.net/publication/311561077_Sauna_bathing_is_inversely_associated_with_dementia_and_Alzheimer's_disease_in_middle-aged_Finnish_men#:~:text=Thos%20who%20engaged%20in%204,et%20al.%2C%202017)%20.))
- **(Associated) Decreased risk of respiratory disease**, including chronic obstructive pulmonary disease, asthma, pneumonia, and the common cold.  Heat therapy can also improve the symptoms of asthma, bronchitis, and pneumonia. ([Kunutsor et al., 2017](https://pubmed.ncbi.nlm.nih.gov/28905164/); [Laitinen et al., 1988](https://pubmed.ncbi.nlm.nih.gov/3218895/); [Cox et al., 1989](https://pubmed.ncbi.nlm.nih.gov/2596966/); [Ernst et al., 1990](https://pubmed.ncbi.nlm.nih.gov/2248758/))
- **Improved Insulin sensitivity and glucose control**.  Heat therapy may reduce fasting glucose, body weight, and adiposity. ([Krause et al., 2015](https://pubmed.ncbi.nlm.nih.gov/26049635/))

**The physiological effects of heat therapy include:**

- **Increased GH levels** ([Hannuksela and Ellahham, 2001](https://pubmed.ncbi.nlm.nih.gov/11165553/)), though possibly only in those under age 49. ([Lammintausta et al., 1976](https://pubmed.ncbi.nlm.nih.gov/999213/)) The frequency of sauna use seems to determine the duration of raised GH levels. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x))
- **Increased prolactin** in both sexes, but especially in women. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x))
- **Increased cortisol** immediately after heat therapy ([Ježová et al., 1985](https://pubmed.ncbi.nlm.nih.gov/3002937/); [Pilch et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3916915/)) which drops to baseline by 1-2 days after and decreases from 3-7 days. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x))
- **A likely increase in other biomarkers**, including hormones like norepinephrine ([Hannuksela and Ellahham, 2001](https://pubmed.ncbi.nlm.nih.gov/11165553/)) and others ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x)), plasma renin activity ([Lammintausta et al., 1976](https://pubmed.ncbi.nlm.nih.gov/999213/)), heat shock protein ([Iguchi et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3418130/)), and white blood cell count. ([Pilch et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3916915/))

## Longevity benefits of sauna—reviewing the studies [41:30]

***Finland sauna study***: The most impressive sauna literature is an [observational study out of Finland](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2130724) comparing different frequencies of sauna use led by [Jari A. Laukkanen](https://twitter.com/laukkanenjari?lang=en)

**Design**:

- 2,327 men participated and fill out a survey of their sauna use
- They have been followed for 20+ years
- Since all participants used sauna, the “control group”—aka reference group— were those who used the sauna once a week
  - Because presumably it controls for one of the biggest biases, which would be socioeconomic, presumably all of those people have saunas or access to saunas — If it hadn’t tried to extract that piece of information, you’d have probably one of the biggest confounders possible in that study
  - It’s still not randomized — therefore it’s going to be subject to limitations
- **Details about sauna use**—
  - *Type of sauna*: It was dry sauna (i.e., not [infrared sauna](https://en.wikipedia.org/wiki/Infrared_sauna))
  - *Temperature*: Avg. temp was 170 degrees Fahrenheit/78.9 degrees Celsius
  - *Duration*:
    - Avg. duration per session was 14.2 minutes
    - A big range, 2 minutes to 90 minutes
    - A session was typically **over 20 minutes** — Note: few studies that it was at least 20 minutes in duration and it was an average of 170 degrees Fahrenheit
  - *Frequency*:
    - Group 1 (Reference Group): At least once per week
    - Group 2: 2-3 times per week
    - Group 3: 4-7 times per week

**Results—**The following are the results comparing the Reference Group (at least once per week) to Group 3 (4-7 sessions per week)

- *All-cause mortality*: 40% lower relative risk and 18% lower absolute risk (after 21 years, the Ref. Group had 49.1% mortality and Group 3 had 30.8% mortality)
- *Fatal cardiovascular disease*: 50% lower relative risks (hazard ratio of 0.5), and 10% lower absolute risk
- *Sudden cardiac death*: 63% lower relative risk, and 5% lower absolute risk
- *Fatal coronary heart disease*: 48% lower relative risk, and 6% lower absolute risk
- *Stroke*: 62% lower relative risk, and about an 8% lower absolute risk
- *Alzheimer’s disease*: 65% lower relative risk, and about a 3% lower absolute risk

**Key takeaways related to the Finland sauna cohort:**

- *What conferred the most benefit?*
  - At least **20 minutes**
  - At least **172 to 174 Fahrenheit/80 degrees Celsius**
  - And at least **four times a week**
- *In all-cause mortality*: An 18% absolute risk reduction — “*I’m not aware of a single [positive] intervention that leads to an 18% absolute reduction in all-cause mortality*.”
- *For MACE (major adverse cardiac event)*: 6-7% absolute risk reduction over 20 years
- *Risk profile of patients*: Important to note that these are NOT really high risk people, increasing the impressiveness of the numbers
- *Stroke reduction*: 8% absolute risk reduction
- *Alzheimer’s disease reduction*: 3% absolute risk reduction — Note: Given avg. age starting age was 53 and followed for 21 years makes them 74—which means this is probably undercounting what the potential is for Alzheimer’s risk reduction—so as this cohort gets older you could see more data related to Alzheimer’s disease

## Limitations in the sauna literature—Where might we be fooled? [54:30]

**Healthy user bias**

- In this cohort of sauna users, you’re dealing with a highly privileged group of individuals
  - Can afford your own sauna
  - Have access to leisure
  - Have resources to buy healthier, more expensive food
- This is considered a healthy user bias—one of the biggest challenges that epidemiologists face when they try to make associations into causations

⇒ Another example of healthy-user bias: Vegetarian epidemiology studies

- Eating a vegetarian diet requires a lot of effort
- So by definition, a person who could put that much effort into what they ate and didn’t eat could put a lot of effort into other things that could positively influence their health
- In other words, being a vegetarian was a proxy for being conscientious, for being obsessed with many layers of your health that went probably beyond what you ate.
- Therefore, it’s hard to infer health benefits associated with the absence of meat as opposed to the presence of these other things

**What else needs to be considered about these sauna studies?**

- *Heart rate increase could possibly just be a marker, not a “maker”, of health*:
  - Heart rate may increase up to a hundred beats a minute during moderate sauna bathing sessions and up to 150 beats per minute during more intense, warm sauna bathing
  - That sounds very similar to what happens when a 50-year-old engages in endurance exercise
- *The heavy sauna users were 2 years younger*: The 4 to 7 times per week sauna group was 2 years younger than the reference group (51.5 vs. 53.5)
- *More smokers in the reference group*: 36% of the reference group are smokers and only 20% of the four to seven times per week were smokers — and in “pack years” the 4 to 7 sauna group was about half the amount as the reference group

**In the multivariate adjustment, they adjusted for the following covariates**: Age, BMI, systolic blood pressure, LDL cholesterol, smoking, alcohol consumption, previous MI, type two diabetes, cardiorespiratory fitness, resting heart rate, physical activity, and socioeconomic status

- They provided detail on a few of those covariates:
  - For previous myocardial infarction—9% in the reference group, 6% in the four to seven times per week.
  - For Type 2 diabetes—7% in the reference group and 2% in the four to seven times per week.
  - One theory could be that they just started picking them up at baseline at age 53—i.e., Maybe they’ve been doing sauna at this rate before, and that’s part of why they have lower rates of diabetes.
    - This could indicate that there might be a “there there” with healthy user bias

Table showing the Age-adjusted and Multivariate adjusted hazard ratios:

![](https://peterattiamd.com/wp-content/uploads/2020/10/hazard-ratios-Laukkanen-et-al.-2015-1024x549.png)

**Figure 4****. Age-adjusted and Multivariate adjusted hazard ratios.** Image credit: [Laukkanen et al., 2015](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2130724)

- For all-cause mortality—after they adjusted for everything, the hazard ratio went from 0.61 to 0.60 meaning the association got stronger
- For sudden cardiac death—.49 in hazard ratio, drops to .37 the association gets stronger after they control for everything
- This is a bit vexing considering it implies that some of those covariates are working in opposition to each other, yet when you look at each of them, most should move in the same direction with the exception of two:
  - 1-body mass index, the body mass index in the reference group was 26.9, and in the four to seven times per week was 27.7.
  - 2-Alcohol consumption, 83% in the reference group (one time a week), the four to seven times per week was 95% (no measure of total alcohol consumed)

## Possible mechanisms conferring the longevity benefits of sauna, and how it compares to exercise [1:02:15]

**Overall, the data is robust in support of heat therapy in the following manner**:

- Dry sauna
- 20 minutes or more each session
- Four times a week or more
- At about 170 degrees Fahrenheit/80 degrees Celsius

**Possible mechanisms conferring benefit**:

Mimics exercise—

- This type of sauna activity seems to mimic cardiovascular exercise
- E.g., Heart rate gets up to 150 beats per minute in a sauna

*What about other things such as growth hormone and heat shock proteins?*

- There are increased growth hormone levels
- Increased prolactin
- Increased cortisol,
- And other hormones likely increase: norepinephrine, renin activity, white blood cell count, and heat shock proteins

**Theoretical experiment**:

- Randomize people to four hours a week of sauna under these above listed conditions
- Match them with another group that does four hours a week of exercise at the same heart rate as in the sauna conditions
- And have a third group do neither (control group)
- Follow them for 20 years

*What would Peter and Bob predict the outcome to be?*

- Bob: “*I think that you would see a lot of similarities in the outcome*”
- Peter thinks an experiment like this could be done in animals and would predict both the sauna group and exercise group would do significantly better
- Peter: “*But is there a difference between those two? That’s the question that’s interesting*.”

## Parting thoughts on sauna, opportunity costs, and Bob’s personal regimen [1:06:30]

**Bob’s personal sauna regimen**

- Five times per week
- 60 minute sessions
- He personally really enjoys it
- He feels mentally and intellectually stimulated (almost like a “runner’s high”) — He brings papers and articles inside the sauna

![](https://peterattiamd.com/wp-content/uploads/2020/10/Salem-wglass_door-800x800jpg-1024x1024.jpg)

**Figure 5. Barrel sauna similar to what Bob has at his home.** Image credit: [almostheaven.com](https://almostheaven.com/product/salem-barrel-sauna/)

**The question of ‘*****opportunity cost’***

*Does Bob think there’s an opportunity cost of spending so much time in the sauna when he could be exercising?*

- Bob personally does not feel there to be an opportunity cost
- In fact, he finds it a tad challenging to engage in a similar amount time in **zone 2 exercise** (which presumably is the closest type of exercise to dry sauna)
- As a bonus, he can be more “productive” in the sauna (e.g., reading papers) as compared to during exercise

**Zone 2 training**

Peter is planning to have another discussion with [Iñigo San Millán](https://twitter.com/doctorinigo?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) to zoom in on the proper zone 2 (and zone 5) protocol and minimum effective dose in metabolically healthy versus metabolically unhealthy people

⇒ see the [previous episode of The Drive with Iñigo San Millán](https://peterattiamd.com/inigosanmillan/) for more on the different training zones

**\*Peter’s final takeaways on sauna**

- Prior to this big analysis done by Peter and his team, Peter never really viewed sauna as having any longevity benefit
- But now, Peter is ready to add sauna into his tool kit for longevity
- That said, exercise is probably giving you many of the same benefits
- In fact, Peter would place exercise above sauna as exercise comes with a number of benefits that sauna doesn’t including (but not limited to) stability and structural benefits and some of the mitochondrial fuel partitioning benefits

In short, the order of operations would be:

- Fulfill your exercise quota first
- And if there’s an ability to do dry sauna, there *is* value in doing it

§

## Selected Links / Related Material

**Episode where Peter discusses his jet lag protocol**: [#45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more](https://peterattiamd.com/ama04/) | Peter Attia (peterattiamd.com) [6:00]

**A large** **editorial paper** **that claimed heat and cold could positively impact health in several ways despite only referencing one cold study**: [Humans: A homeothermic animal that needs perturbation?](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/EP087450) (Mike Tipton, 2018) [9:00]

**The one “cold” citation mentioned in the editorial paper—an n=1 case report of one 24-year-old woman who had major depressive symptoms and anxiety who did open water swimming**: [Open water swimming as a treatment for major depressive disorder](https://pubmed.ncbi.nlm.nih.gov/30131418/) (Tulleken et al., 2018) [10:45, 19:30]

**Evidence that cold therapy may reduce delayed onset muscle soreness**: [12:00]

- [Effects of recovery method after exercise on performance, immune changes, and psychological outcomes](https://pubmed.ncbi.nlm.nih.gov/20479533/) (Stacey et al., 2010)
- [The effect of recovery strategies on physical performance and cumulative fatigue in competitive basketball](https://pubmed.ncbi.nlm.nih.gov/18608847/) (Montgomery et al., 2008)
- [Cold-water immersion (cryotherapy) for preventing and treating muscle soreness after exercise](https://pubmed.ncbi.nlm.nih.gov/22336838/) (Bleakley et al., 2012)
- [Cold water immersion and recovery from strenuous exercise: a meta-analysis](https://pubmed.ncbi.nlm.nih.gov/21947816/) (Leeder et al., 2011)
- [The efficacy of cryotherapy on recovery following exercise-induced muscle damage](https://journals.co.za/content/ismj/11/2/EJC48394?fromSearch=true) (Burgess and Lambert, 2010)

**Cyclist Jens Voigt saying “Shut up, legs.”**: [Jens Voigt – Shut Up](https://www.youtube.com/watch?v=RahvWjoU9Xc) | Scott Kemp (youtube.com) [14:15]

**New York Times piece discussing ibuprofen and its impact on recovery and performance**: [Bring On the Exercise, Hold the Painkillers](https://www.nytimes.com/2017/07/05/well/move/bring-on-the-exercise-hold-the-painkillers.html) | Gretchen Reynolds (nytimes.com) [16:15]

**In one study, taking antioxidants after exercise essentially blunted the effects of the exercise**: [Antioxidants prevent health-promoting effects of physical exercise in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2680430/) (Ristow et al., 2009) [16:15]

**Acetaminophen actually improves performance though the mechanism of action is not entirely clear:** [Influence of acetaminophen on performance during time trial cycling](https://pubmed.ncbi.nlm.nih.gov/19910336/) (Mauger et al., 2009) [17:15]

**It is possible, but far from established, that cryotherapy could alleviate the symptoms of depression**: [Whole-body cryotherapy as adjunct treatment of depressive and anxiety disorders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2734249/) (Rymaszewska et al., 2008) [19:30]

**Some studies have shown that cryotherapy decreases inflammation**: [20:00]

- [Pongor et al., 2011](https://pubmed.ncbi.nlm.nih.gov/21829501/)
- [Shephard & Shek, 1998](https://pubmed.ncbi.nlm.nih.gov/10066131/)

**Not all study results agree that cold therapy decreases inflammation**: [Peake et al. 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7339943/) [20:00]

**The discovery of the hormone called irisin garnered excitement around the idea that more irisin could increase brown fat**: [Newly Discovered Hormone Boosts Effects of Exercise, Could Help Fend Off Diabetes](https://blogs.scientificamerican.com/observations/newly-discovered-hormone-boosts-effects-of-exercise-could-help-fend-off-diabetes/) | Katherine Harmon (scientificamerican.com) [21:15]

**Review paper on brown adipose tissue**: [Human Brown Adipose Tissue: What We Have Learned So Far](https://pubmed.ncbi.nlm.nih.gov/26050667/) (Betz & Enerbäck, 2015) [21:15]

**Peter’s trip to Norway to measure the effect of cold temperature on BAT activity**: [@peterattiamd – 2/27/20](https://www.instagram.com/p/B9F0B2vAqr2/) | (instagram.com) [24:15]

**The idea the increasing and activating BAT with cold can increase energy expenditure, burn more calories, and help with obesity**: [Role of Human Brown Fat in Obesity, Metabolism and Cardiovascular Disease: Strategies to Turn Up the Heat](https://pubmed.ncbi.nlm.nih.gov/29981351/) (Ruiz et al., 2018) [25:15]

**Literature exploring the endocrine role of BAT and the benefit of “batokines”**: [25:45]

- [An endocrine role for brown adipose tissue?](https://journals.physiology.org/doi/full/10.1152/ajpendo.00250.2013?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dpubmed) (Villarroya et al., 2013)
- [New insights into the secretory functions of brown adipose tissue](https://joe.bioscientifica.com/view/journals/joe/243/2/JOE-19-0295.xml) (Villarroya et al., 2019)

**No evidence that BAT volume was increasing with cold exposure, BAT volume was changing more so with exercise and metabolic health**: [Cold-activated brown adipose tissue in human adults: methodological issues](https://journals.physiology.org/doi/full/10.1152/ajpregu.00021.2014) (van der Lans et al., 2014)  [27:30]

**Cold exposure activates sirtuins in brown adipose tissue**: [29:15]

- [Sirtuins in mammals: insights into their biological function](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2753453/pdf/nihms-134884.pdf) (Shaday MICHAN and David SINCLAIR, 2007)
- [SIRT3, a mitochondrial sirtuin deacetylase, regulates mitochondrial function and thermogenesis in brown adipocytes](https://pubmed.ncbi.nlm.nih.gov/15653680/) (Shi et al., 2005)
- [Mammalian sirtuins—emerging roles in physiology, aging, and calorie restriction](https://www.rand.org/content/dam/rand/www/external/labor/aging/rsi/rsi_papers/2008/haigis2.pdf) (Haigis and Guarente, 2008)
- [Cold acclimation increases levels of some heat shock protein and sirtuin isoforms in threespine stickleback](https://pubmed.ncbi.nlm.nih.gov/26123780/) (Teigen et al., 2015)

**Cold exposure activates heat shock proteins**: [29:30]

- [The Effect of Repeated Whole-Body Cryostimulation on the HSP-70 and Lipid Metabolisms in Healthy Subjects](https://www.biomed.cas.cz/physiolres/pdf/68/68_419.pdf)  (Lubkowska et al., 2019)
- [Characterization of cold-induced heat shock protein expression in neonatal rat cardiomyocytes](https://pubmed.ncbi.nlm.nih.gov/9278266/) (Laios et al., 1997)

**Activation of brown adipose tissue are in cold immersion of 67 degrees**: [34:30]

- [Temperature-Acclimated Brown Adipose Tissue Modulates Insulin Sensitivity in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4207391/) (Lee et al., 2014)
- [Brown Adipose Tissue Improves Whole-Body Glucose Homeostasis and Insulin Sensitivity in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4238005/) (Chondronikola et al., 2014)

**Heat therapy before bed may enhance sleep**: [Before-bedtime passive body heating by warm shower or bath to improve sleep: A systematic review and meta-analysis](https://www.sciencedirect.com/science/article/abs/pii/S1087079218301552?via%3Dihub) (Haghayegha et al., 2019) [40:30]

**Purported clinical benefits of heat therapy**: [40:30]

- **Decreased pain, including DOMS**.  Heat therapy appears to offer analgesic benefits with no risk of detrimental effects. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x); [Hausswirth et al., 2011](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0027749); [Viitasalo et al., 1995](https://link.springer.com/article/10.1007/BF00635877))
- **(Associated) Decreased risk of cardiovascular disease.**  A series of Finnish studies that are some of the largest heat therapy trials found that increasing frequency of sauna usage is associated with a decreasing risk of sudden cardiac death (SCD), fatal coronary heart disease, CVD, and stroke. ([Laukkanen et al., 2015](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2130724); [Laukkanen et al., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6262976/#CR19))
- **Improved endurance and performance.**  Data on the effects of heat therapy on muscle strength is inconclusive, but heat therapy appears to improve jump height, power, and endurance. Heat therapy may offer performance benefits with a low risk of detrimental effects. ([Mero et al., 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4493260/); [Scoon et al., 2007](https://pubmed.ncbi.nlm.nih.gov/16877041/); [Viitasalo et al., 1995](https://link.springer.com/article/10.1007/BF00635877); [Hausswirth et al., 2011](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0027749))
- **(Associated) Decreased risk of dementia and Alzheimer’s Disease** with more frequent sauna visits associated with a larger decrease. ([Laukkanen et al. 2017](https://www.researchgate.net/publication/311561077_Sauna_bathing_is_inversely_associated_with_dementia_and_Alzheimer's_disease_in_middle-aged_Finnish_men#:~:text=Thos%20who%20engaged%20in%204,et%20al.%2C%202017)%20.))
- **(Associated) Decreased risk of respiratory disease**, including chronic obstructive pulmonary disease, asthma, pneumonia, and the common cold.  Heat therapy can also improve the symptoms of asthma, bronchitis, and pneumonia. ([Kunutsor et al., 2017](https://pubmed.ncbi.nlm.nih.gov/28905164/); [Laitinen et al., 1988](https://pubmed.ncbi.nlm.nih.gov/3218895/); [Cox et al., 1989](https://pubmed.ncbi.nlm.nih.gov/2596966/); [Ernst et al., 1990](https://pubmed.ncbi.nlm.nih.gov/2248758/))
- **Improved Insulin sensitivity and glucose control**.  Heat therapy may reduce fasting glucose, body weight, and adiposity. ([Krause et al., 2015](https://pubmed.ncbi.nlm.nih.gov/26049635/))

**The physiological effects of heat therapy include:**

- **Increased GH levels** ([Hannuksela and Ellahham, 2001](https://pubmed.ncbi.nlm.nih.gov/11165553/)), though possibly only in those under age 49. ([Lammintausta et al., 1976](https://pubmed.ncbi.nlm.nih.gov/999213/)) The frequency of sauna use seems to determine the duration of raised GH levels. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x))
- **Increased prolactin** in both sexes, but especially in women. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x))
- **Increased cortisol** immediately after heat therapy ([Ježová et al., 1985](https://pubmed.ncbi.nlm.nih.gov/3002937/); [Pilch et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3916915/)) which drops to baseline by 1-2 days after and decreases from 3-7 days. ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x))
- **A likely increase in other biomarkers**, including hormones like norepinephrine ([Hannuksela and Ellahham, 2001](https://pubmed.ncbi.nlm.nih.gov/11165553/)) and others ([Leppäluoto et al., 1986](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.1986.tb08000.x)), plasma renin activity ([Lammintausta et al., 1976](https://pubmed.ncbi.nlm.nih.gov/999213/)), heat shock protein ([Iguchi et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3418130/)), and white blood cell count. ([Pilch et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3916915/))

**Tim Ferriss interviewed Rick Rubin while inside a sauna**: [Rick Rubin on Cultivating World-Class Artists (Jay Z, Johnny Cash, etc.), Losing 100+ Pounds, and Breaking Down The Complex (#76)](https://tim.blog/2015/05/15/rick-rubin/) | Tim Ferriss (tim.blog). [41:15]

**Sauna study from Finland**: [Association Between Sauna Bathing and Fatal Cardiovascular and All-Cause Mortality Events](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2130724) (Laukkanen et al., 2015) [42:00]

§

## People Mentioned

- [Dan Palenchar](https://www.linkedin.com/in/danielpalenchar/) [8:00]
- [Jens Voigt](https://en.wikipedia.org/wiki/Jens_Voigt) [14:00]
- [Michael Ristow](https://en.wikipedia.org/wiki/Michael_Ristow) [16:15]
- [Tim Ferriss](https://twitter.com/tferriss?lang=en) [41:15]
- [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) [41:15]
- [Jari A. Laukkanen](https://twitter.com/laukkanenjari?lang=en) [42:30]
- [Iñigo San Millán](https://twitter.com/doctorinigo?lang=en) [1:08:30]

§