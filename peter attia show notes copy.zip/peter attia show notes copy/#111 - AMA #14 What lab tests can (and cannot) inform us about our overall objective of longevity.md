# #111 – AMA #14: What lab tests can (and cannot) inform us about our overall objective of longevity

**Source:** [https://peterattiamd.com/ama14/](https://peterattiamd.com/ama14/)

---

In this “Ask Me Anything” (AMA) episode, Peter explains his framework for understanding what lab tests can (and cannot) inform us as it pertains to overall longevity, with a specific focus on atherosclerosis, cancer, Alzheimer’s disease, and the physical body. Additionally, Peter shares details into two patient case studies around cardiovascular disease, including how the lab results influenced his diagnosis and treatment plan for the patients. Once again, Bob Kaplan, Peter’s head of research, will be asking the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #14 show notes page](https://peterattiamd.com/ama14). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Important lab tests and reference ranges [2:35];
- How lab testing fits into the overall objective of longevity [4:25];
- A healthcare system set up to react to a disease rather than prevent it [8:00];
- The four pillars of chronic disease, and the three components of healthspan [14:30];
- Atherosclerosis—How much can labs tell us about risk? [18:00];
- Coronary calcium score (CAC)—interpreting results based on your age [24:15];
- Cancer—what lab work can tell you, and the future of liquid biopsies [28:00];
- Alzheimer’s disease—what’s driving Alzheimer’s disease, and what labs can tell you about your risk [33:15];
- Healthspan and the physical body—where lab testing fits, the endocrine system, and zone 2 testing [39:00];
- Summarizing the usefulness of lab testing—where it gives great, reasonable, or lousy insight [43:15];
- Patient case study—elevated Lp(a): Understanding ApoB, and how cholesterol levels get reduced [45:30];
- Patient case study—familial hypercholesterolemia [59:30];
- Coming up on a future AMA [1:10:30]; and
- More.

§

The Peter Attia Drive

What lab tests can (and cannot) inform us about our overall objective of longevity

§

## Show Notes

## Important lab tests and reference ranges [2:35]

The following is from [AMA #1](https://peterattiamd.com/ama01)…

**Peter’s top five lab tests**:

1. Lp(a)-P (or Lp[a] mass is a reasonable approximation).
2. APOE genotype.
3. LDL-P (or ApoB).
4. OGTT with insulin measurements.
5. ALT.

–*Honorable mentions*: Hcy, hs-CRP, oxLDL, and oxPL, fibrinogen, Lp-PLA2, ADMA and SDMA are also really helpful to know. Estradiol (E2) as well. Knowing your family history can also tell you something about risk.

**Peter’s preferred lab results ranges** *(which may differ from the “standard” ranges)*

![](https://peterattiamd.com/wp-content/uploads/2020/05/standard-panel-ama14-1-1024x410.png)

![](https://peterattiamd.com/wp-content/uploads/2020/05/glucose-and-ketones-ama14-1-1024x494.png)

![](https://peterattiamd.com/wp-content/uploads/2020/05/NMR-inflammation-metabolic-ama14-1-1024x598.png)

![](https://peterattiamd.com/wp-content/uploads/2020/05/hormones-iron-thyroid-sex-hormones-ama14-1-1024x827.png)

![](https://peterattiamd.com/wp-content/uploads/2020/05/liver-function-and-omega-3-index-ama14-1-1024x216.png)

## How lab testing fits into the overall objective of longevity [4:25]

**The two components of longevity—Lifespan and healthspan**

- *Lifespan*=How long you live
- *Healthspan*=How well you live

–**Lifespan**:

Living longer is effectively going to boil down to **how long can you delay the onset of chronic disease**

*Looking at centenarians*:

- They don’t live longer once they get a disease, they just take longer to get a disease.
- Their superpower is how long they can go before they get the first chink in their armor
- But once that disease sets in, they’ve basically been exposed to kryptonite and they are now just mere mortals like the rest of us.
- In other words, they simply have a “phase shift” of about 20 years before they get chronic disease compared to the average person

> “So if you want to live longer, the mathematical equivalent function is to delay the onset of chronic disease, not figure out ways to live longer once you have chronic disease.”

## A healthcare system set up to react to a disease rather than prevent it [8:00]

- The entire healthcare system is mostly geared towards helping you live longer once you acquire disease
  - This is the opposite approach to what Peter described above
- Prevention is not really the mainstay of medicine.
- Medicine has had its greatest impact or its greatest efforts basically on what to do once you have a disease

*With Alzheimer’s disease…*

- We have no drugs that can reverse the dementia or even slow its progression once it sets in

*With cancer…*

- We’ve made very little progress in 50 years in regards to the long-term survival rate
- With metastatic cancer, it’s about a 5% improvement we’ve made in 50 years

*With cardiovascular disease…*

- It’s the one place where we’ve seen the most progress on managing a disease once it sets in
- Why?
  - Atherosclerosis is much more of a continuum than dementia and cancer
  - And it’s less complicated

[New England Centenarian Study](https://www.bumc.bu.edu/centenarian/) (Thomas Perls)

[The Longevity Genes Project](https://www.einstein.yu.edu/centers/aging/longevity-genes-project/) (Nir Barzilai)

**Centenarians put into 3 categories—The delayers, escapers, and survivors article**: [Morbidity Profiles of Centenarians: Survivors, Delayers, and Escapers](https://academic.oup.com/biomedgerontology/article/58/3/M232/684123) (Evert, et al., 2003) [10:45]

> “We don’t really function in a system of health care. We function in a system of ‘sick care’, meaning we interact with our healthcare system in a manner that is—once there is a problem, we seek help.”

## The four pillars of chronic disease, and the three components of healthspan [14:30]

**The Four Horsemen of Chronic Disease**

-The following amounts over 80% of deaths in people over 50 who do not smoke…

1. Atherosclerotic disease (comprised of cardiovascular disease and cerebrovascular disease)
2. Cancer
3. Neurodegenerative disease (Alzheimer’s disease being the most common)
4. “Foundational disease” ⇒ a spectrum of everything hyperinsulinemia to insulin resistance to fatty liver disease to type 2 diabetes

**3 Components of Healthspan**

1. Cognitive
2. Physical/structural
3. Emotional

*-With the cognitive piece*…

- Most of the efforts we put into preserving cognition are basically directly in line with the efforts we will make to reduce the risk of dementia

–*With the physical component…*

- This is really the first thing that starts to compromise quality of life (knee pain, back pain, etc.)
- It occurs decades before someone dies
- “*There’s no time that’s too soon to start caring about [physical/structural health]*.”

*-With the emotional piece…*

- By far least tethered to age
- The labs are not as relevant with this piece so it won’t be the focus of this episode

## Atherosclerosis—How much can labs tell us about risk? [18:00]

> “If I’m going to give an overall grade to how well we can use blood tests to handicap a person’s risk of atherosclerosis, it’s going to get a pretty good grade.”

**1 | Lipids**

- Atherosclerosis is driven first and foremost by lipid proteins
- The main lipoproteins we care about:
  - [ApoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) – can be measured directly
  - [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) – can be measured directly
  - [VLDL remnants](https://en.wikipedia.org/wiki/Remnant_cholesterol) – can’t measure directly but can measure VLDL cholesterol which is a reasonable proxy

**2 | Inflammation**

- The disease requires **inflammation**
- There are lots of inflammation markers but not all of these are specific to cardiac inflammation
  - Non-specific ones: [C-reactive protein](https://en.wikipedia.org/wiki/C-reactive_protein), [fibrinogen](https://en.wikipedia.org/wiki/Fibrinogen), [interleukins](https://en.wikipedia.org/wiki/Interleukin)
  - More specific to cardiac: [Oxidized LDL](https://en.wikipedia.org/wiki/Low-density_lipoprotein#Oxidized_LDL), [myeloperoxidase](https://en.wikipedia.org/wiki/Myeloperoxidase), [Lp-PLA2](https://en.wikipedia.org/wiki/Lipoprotein-associated_phospholipase_A2)
- “*We sort of look at C-reactive protein, fibrinogen, Lp-PLA2 usually just one time. I don’t think it provides much ongoing support. I think that’s a reasonable area of insight, but one for which I think we still don’t have the greatest biomarkers there.*”

**3 | Endothelial health**

- Impaired endothelial function and health plays a role in the disease
- In terms of labs… “*this is probably an area where we don’t have the most insight*”
- Things that irritate the endothelial:
  - Hyperinsulinemia
  - Elevated homocysteine
  - Elevated uric acid
  - Impaired kidney function
- We can also measure some other indirect proxies:
  - [ADMA](https://en.wikipedia.org/wiki/Asymmetric_dimethylarginine)
  - [SDMA](https://jasn.asnjournals.org/content/17/4/1128)
  - These are arginine derivatives that impair nitric oxide formation and their clearance is impaired by elevated homocysteine

**4 | Metabolic health**

- The metabolic component is enormous
  - glucose levels
  - insulin levels
  - Triglyceride levels
- All these (and much more) can be measured with blood testing

**What the average doctor is doing in terms of assessing risk:**

- Unfortunately, many doctors are assessing risk for cardiovascular disease in their patients predicated mostly on their LDL cholesterol rather than ApoB
- Even looking at non HDL cholesterol is far superior than looking at LDL cholesterol

**⇒ Peter’s article about heart disease and prevention**: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/)

> “It is obviously upsetting to me that a disease that’s as prevalent as cardiovascular disease is still kind of underperforming in terms of how seriously we treat prevention.”

## Coronary calcium score (CAC)—interpreting results based on your age [24:15]

**Coronary artery calcium scoring**

⇒ CAC was discussed in detail on [AMA #5](https://peterattiamd.com/ama05/)

- Age matters big time when interpreting the CAC scores
- A young patient…
  - they shouldn’t have any calcification
  - So a calcium score of zero in somebody below 50 doesn’t really help us much
- In an older person…
  - somebody who’s over 75 that has significant calcification doesn’t tell us much either
- But the flip sides of those help a lot…
  - Someone below 50 that has even a speck of calcium immediately has an increase in risk
  - And conversely, somebody who’s 80 who has not a speck of calcium is immediately in a lower category of risk regardless of what their biomarkers say
- There’s virtually no downside to doing this test, and yet it adds information.
- But don’t over-interpret what it tells you
- You should also know what its blind spots are
  - 1) it has an enormous blind spot for young people because they haven’t lived long enough to accumulate calcification even if they already have raging disease going on
  - 2) not everyone who has advanced disease has calcification
  - 3) it’s not the calcified lesions that kill people

> “You can be fooled by these tests by seeing a negative burden of calcium. You might think, ‘well this person is free and clear’, but in reality they have tons of soft plaque that is not yet calcified.”

⇒ The Drive episode with Ethan Weiss discussing CAC among other CVD topics: [#52 – Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone – two topics that are surprising interrelated](https://peterattiamd.com/ethanweiss/)

## Cancer—what lab work can tell you, and the future of liquid biopsies [28:00]

We start with the question: **What drives cancer?**

- Cancer is both a genetic and metabolic disease
- So by definition cancer cells have mutated and they sort of have this trait that is common to all cancers.
- The essential condition of cancer is unregulated/dysregulated cell growth ⇒ cells that grow without responding to normal cell cycle signaling
- There’s a strong immune component to cancer because our immune system is almost always keeping cancer at check and keeping it at bay … So at some point when our immune system starts to lose that battle, that’s when cancer starts to win

Metabolism of cancer

- After smoking, [obesity is the next leading predictor of cancer](https://peterattiamd.com/sidmukherjee/)
- **Why?** Peter thinks it’s less about the obesity and more about the metabolic environment that accompanies obesity, i.e. **hyperinsulinemia**
- There’s no question that this is a disease that’s heavily impacted by
  - the underlying metabolic health of the individual
  - the immune function of the individual, and
  - the ability to acquire mutations and repair them
- However, the metabolic piece is pretty much the only one we can glean anything about from a standard blood test

Labs:

- Glucose and insulin
- Insulin primarily being the biggest because it’s a very potent and anabolic growth factor
  - Insulin, IGF, IGF binding proteins, all of these things factor into cancer
- Glucose is the **preferred fuel of cancer**

**Liquid biopsies**

- Most cancers do not arise from inherited genes (maybe 5% do)
- The majority of cancer result from [somatic mutations](https://en.wikipedia.org/wiki/Mutation#Somatic_mutation) (mutations that occur to your genes but they’re not necessarily the genes you pass on)
- The only way to test for that is using these novel technologies that are emerging called [liquid biopsies](https://en.wikipedia.org/wiki/Liquid_biopsy)
- Liquid biopsies are blood tests that look for circulating tumor DNA and can tell you how many circulating cancer cells you have and also the tissue of origin (e.g., these are breast cancer tumor cells)
- These are in the process of some very late stage FDA trials that will likely be available for use in the next year in some sort of investigative capacity
- So that would mean you’d see breast cancer in the blood long before it’s showing up on any test.

⇒ Previous episodes of The Drive discussing liquid biopsies:

- [#06 – D.A. Wallach: music, medicine, longevity, and disruptive technologies](https://peterattiamd.com/dawallach/)
- [#62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/)

> “The long and short of it is there’s very little in a blood test that’s gonna tell you if you have cancer. What we instead rely on a blood test to do is at least tell us what your metabolic environment is and how much that’s predisposing you to cancer.”

## Alzheimer’s disease—what’s driving Alzheimer’s disease, and what labs can tell you about your risk [33:15]

**What’s driving Alzheimer’s disease?**

1. Genetics
2. Metabolic health
3. Vascular health
4. Inflammation
5. Toxins

**1 | The genetic component**:

- It has a strong genetic component
- *Not an acquired* set of mutations, but rather an *inherited* set of alleles that puts you at higher risk or lower risk

*-Relevant genes*

- [ApoE4](https://en.wikipedia.org/wiki/Apolipoprotein_E#Alzheimer's_disease) is most important in terms of understanding risk
- Next most relevant is [TOMM40](https://en.wikipedia.org/wiki/TOMM40) – but this may not be an independent risk factor

–[*Allen Roses*](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(16)32081-5/fulltext)

- In 1993, Allen Roses [discovered](https://www.ncbi.nlm.nih.gov/pubmed/8346443) the risk increase for Alzheimer’s in people with the ApoE4 gene
- He later alerted people to the TOMM40 gene

*-Deterministic genes*

- ApoE4 does raise risk but it is not considered a “deterministic gene”
- However, a small percentage of AD cases (about 1%) are due to “deterministic” genes
- The following genes may be “fully penetrant” and therefore “deterministic” which means if you have a mutation in them you WILL get AD:
  - Amyloid precursor protein (APP)
  - PSEN1, and
  - PSEN2
- In cancer, *for example…*
  - There are a couple things that are CLOSE to being deterministic such as:
    - [APC](https://en.wikipedia.org/wiki/Adenomatous_polyposis_coli) with colon cancer
    - [Lynch syndrome](https://www.cancer.net/cancer-types/lynch-syndrome)
    - And about 60-70% of women with [BRCA1](https://en.wikipedia.org/wiki/BRCA1) get breast cancer

**2 | Metabolic Health component of Alzheimer’s disease**

- “Metabolic health really matters. It is the common thread that links all of these chronic diseases.”
- However, on mortality tables, it doesn’t really show up *individually* as a huge source of death.

**3 | Vascular component to Alzheimer’s disease**

- This is a huge component
- See [podcast with Francisco Gonzalez-Lima](https://peterattiamd.com/franciscogonzalezlima/) for more on this

**4 | Inflammatory component to Alzheimer’s disease**

- Enormous component, says Peter

**5 | Toxins related to Alzheimer’s disease**

- “*There’s almost assuredly a component that revolves around toxins and other things like that.*”

**Blood tests for the deterministic genes:**

- You can test for the deterministic genes pretty easily (PSEN1, PSEN2, and APP)
- However, that’s usually just to confirm a strong suspicion after seeing a strong family history of getting AD
- History of AD:
  - [Alois Alzheimer](https://en.wikipedia.org/wiki/Alois_Alzheimer) diagnosed the first patient
  - It was a [woman in her 50s](https://en.wikipedia.org/wiki/Auguste_Deter) that had early onset AD and she most likely had one of the deterministic genes
  - “*And this could be a real tragic case of medical history that our entire understanding of a disease, which is predicated on this incident case, has nothing to do with 99% of the diseases that people actually get.*”

**The punchline when it comes to Alzheimer’s disease**:

- We get pretty darn good information from the blood
- We get the relevant genes
- We get all the vascular stuff
- We get all the metabolic stuff
- We can’t get as much good info about the inflammatory stuff
- And we’re pretty bad at getting the toxins because truthfully we just don’t know

“*But overall we get a pretty darn good way to handicap someone’s risk of Alzheimer’s disease.*”

## Healthspan and the physical body—where lab testing fits, the endocrine system, and zone 2 testing [39:00]

**Important components of the physical body for healthspan**:

- Muscle mass
- Stability
- Strength
- Aerobic function
- Anaerobic function
- Freedom from pain

*Where does lab testing fit into all of that?*

- Mostly on the [endocrine](https://en.wikipedia.org/wiki/Endocrine_system) side
  - Best example would be testing for [hypogonadism](https://en.wikipedia.org/wiki/Hypogonadism)
    - People who have low testosterone, for both male or female, AND they have impaired ability to put on muscle mass …  “*That becomes diagnostically interesting.*”
- Hypercortisolemia factors into body composition and other things
- Metabolic stuff that factors into that, but the reality of it is that’s much more of a functional thing than a really a laboratory thing.
- But… **Outside of understanding hypogonadism, there’s not a huge amount that we glean in terms of risk stratification there**.

**Lactate testing to find zone 2**

⇒ Previous episodes of The Drive with info about Zone 2 exercise

- [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/)
- [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/)
- [#73 – AMA #9: NAD & metformin, fat-burning zone, creatine, estrogenization of men, emergency kit for cold & flu, and more](https://peterattiamd.com/ama09/)

–*What is zone 2?*

- Zone 2 is basically the highest level of exertion that is effectively pure mitochondrial oxidative phosphorylation before you start to net accumulate lactate

–*Testing for zone 2*

- Peter has a lactate testing protocol for his patients which involves testing lactate in your blood while exercising
- Being at ~2.0 mM (or probably just below it at 1.8, 1.9) means you are in zone 2

–*Zone 2 is NOT a static thing*

- Peter notes it’s interesting that his zone 2 on a bike is different than on a rowing machine
- At the exact same wattage, Peter’s zone 2 watt on the bike produced a lactate of 1.9-2.0 millimolar
- An hour later he did the same wattage on the rowing machine and his lactate was between 3.4 and 4.1
- Your lactate levels at a given intensity depends on things like how recovered you are, how hydrated you are, whether or not you sick, etc.

⇒ Example…

- Today Peter’s bike was 182 Watts at a heart rate of 134 and that was his zone 2
- Days when he’s feeling really good that wattage will be 190 at a heart rate of 135 and that’ll produce the same amount of lactate
- Sometimes I’ll be like heart rate 128 and 192 watts will still be the zone 2 of that day
- Days when he’s been sick, even 160 Watts is above zone 2 and his heart rate is through the roof

> “So you’re basically using heart rate and wattage to predict where you need to be and then using lactate to confirm it after the fact. . .It’s good for people not to think of zone 2 as static, but something that’s sort of always in flux with respect to where you are physiologically.”

## Summarizing the usefulness of lab testing—where it gives great, reasonable, or lousy insight [43:15]

*When you get a blood test, you’re going to get a great insight into…*

- Blood chemistry
- Liver function tests
- Kidney function

**Endocrine system testing**

1 | Thyroid function

- You can also get good insight into thyroid function **if you test appropriately**
- Meaning… looking at all the thyroid functions, not just TSH but looking at i) free T3  ii) free T4 and iii) reverse T3

**⇒ Peter’s thyroid hormones** [**whiteboard video**](https://vimeo.com/337835256/765434e953)

2 | Sex hormones

–*Hormones there that we care about*:

- [Estradiol](https://en.wikipedia.org/wiki/Estradiol)
- [Testosterone](https://en.wikipedia.org/wiki/Testosterone)
- [Free testosterone](https://gainswave.com/blog/total-testosterone-vs-free-testosterone/) (Typically 97-99% of T is bound meaning only 1-3% is free)
- [Sex hormone binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)
- [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone)
- [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)
- [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone)
- [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)
- [Progesterone](https://en.wikipedia.org/wiki/Progesterone)

3 | Adrenal function

- You get pretty much nothing out of a blood test on adrenal
- All you’re getting is total cortisol at one point in time
- You really want *free cortisol* and to be able to sample it over a time series

4 | Fuel partitioning system

- The fuel partitioning system is …
  - W*hat do you do with the nutrients you take in*?
  - H*ow do you store them*?
  - H*ow do you access them*?
- We get some of that from blood testing, but I think much of that comes from metabolic testing such as zone 2 testing than other tests that mimic that sort of protocol.

**IN SUMMARY**

-We have **really good** insight into…

- Atherosclerotic disease
- Dementia risk
- Sex hormones
- Thyroid hormones
- Metabolism

We have **reasonable** resolution into…

- Fuel partitioning
- Blood chemistry

We have pretty **lousy** resolution into…

- Cancer
- Adrenal function

## Patient case study—elevated Lp(a): Understanding ApoB, and how cholesterol levels get reduced [45:30]

⇒ Check out this episode of The Drive for more on Lp(a): [#07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know](https://peterattiamd.com/lpa/)

\*\*\*\*\*

**Patient 1**

- 37, Male
- Indian descent (Southeast Asian)
- Body type: Normal BMI

*-Meds while on a labs (pertinent)*

- Atorvastatin 10 mg

*-Fam Hx: Remarkable family history of CVD, T2DM, HTN.*

- Father: HTN, hyperlipidemia
- Paternal grandfather: Fatal MI (44 YO) – non-smoker
- Paternal uncles/aunts: MI, Stroke, HTN, T2DM.
- Maternal Grandfather: MI
- Maternal uncle/aunts: CABG, stroke.

⇒ A note on the importance of knowing family history: “*it really is one of the best things that you can look at in terms of determining risk*”

*-Med Hx*:

- OSA – treated with CPAP
- ApoE 3/4
- Heterozygous for MTHFR – 677C/C, 1298 A/C

–*Imaging*:

- No CAC done.

*-Other testing*:

- Omega-3 Index: 4.6%

–*Nutrition*:

- TRF 16/8
- 42% CHO, 36% FAT, 22% PRO

**Lab test results for Patient 1**:

![](https://peterattiamd.com/wp-content/uploads/2020/05/patient-1-labs-A-ama14-821x1024.png)

![](https://peterattiamd.com/wp-content/uploads/2020/05/patient-1-labs-B-ama14-1024x752.png)

\*\*\*\*\*

**CONCLUSIONS AND TREATMENT**:

- Looking at this patient’s family history… Peter’s initial thought even BEFORE seeing his labs was “*this is* [*Lp(a)*](https://en.wikipedia.org/wiki/Lipoprotein(a)) *until proven otherwise and/or FH,* [*familial hypercholesterolemia*](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia)*.*”
- The first thing that jumps out is that he does indeed have an elevated Lp(a)
- An Lp(a) test is one of the five most important blood tests you should ever do, says Peter, and you only need to do it one time
- About 1 in 12 people in the population have elevated Lp(a)

**The patient’s LDL-C**:

- The LDL cholesterol is elevated at 149 (60th or 70th percentile)
- And his primary care physician likely put him on Lipitor specifically because of this finding
- Although 10 milligrams is the lowest end of the typically range (10 and 80 milligrams)

**ApoB**

- ApoB is a far better proxy for risk than LDL-C
- LDL-C is measuring the cholesterol concentration carried within all of the low density lipoproteins
- And there’s no question that that’s correlated with outcomes, but not as strongly as either:
  - non HDL cholesterol, because that includes the cholesterol of not just the LDL but the VLDL
  - But even more importantly as ApoB
    - And the reason is because ApoB is a marker of all atherogenic particles
    - Anything that causes atherosclerosis by definition has an ApoB100 on it ⇒ So that’s an LDL, a VLDL, an IDL, and an Lp(a)
- If someone has high VLDL remnants, for example, they will have high ApoB
- For this patient, his high Lp(a) means he’ll have a high ApoB

**Coronary artery score?**

- Patient 1 did NOT have a coronary artery score
- At age 37, he should have a score of zero
- Peter says he would NOT do a test for this on this patient: “*It’s not going to change my management. I have a general principle in life which is ‘****don’t do diagnostic tests if you can’t explain how the outcome is going to change your management****’*.”
- Based on his family history and his own lipid history, this guy already needs maximum lipid lowering therapy

**What determines ApoB levels?**

==> Suggested reading on this topic: [Measuring cardiovascular disease risk and the importance of apoB](https://peterattiamd.com/measuring-cardiovascular-disease-risk-and-the-importance-of-apob-part-1/)

–*Basically four things determine ApoB levels:*

- First, it’s how well you’re able to **clear the ApoB out of circulation**
- Next, the other three of the four things are determined by **how much cargo needs to be trafficked in the lipoprotein**. And those are:
  - 1) How much cholesterol you synthesize
  - 2) How much cholesterol (or sterol) you reabsorb
  - 3) The amount of triglycerides (TGs) you have to carry around
- Cholesterol and triglyceride can’t just be carried around in the bloodstream by themselves because they are too hydrophobic
- So they have to be packaged into things that are water soluble… and those things are called [lipoproteins](https://en.wikipedia.org/wiki/Lipoprotein)
- “If you want to lower the amount of lipoprotein, **the first, second, third strategy is to lower the amount of cargo they have to carry**.”
  - So that means lowering triglycerides and lowering cholesterol.

**How cholesterol gets lowered**:

1. Reducing the synthesis of cholesterol, or
2. Reducing the reabsorption of cholesterol

- NOTE: It does **NOT** include reducing the *intake of dietary cholesterol* since that features very little into how much cholesterol you have since most of that is not absorbed

**Cholesterol synthesis—how it works and how to measure it:**

- There are two pathways to make cholesterol
  - 1) One of those paths you have a marker, a molecule called [desmosterol](https://en.wikipedia.org/wiki/Desmosterol), which is the last molecule before you make cholesterol.
  - 2) And in the other pathway it’s called [lathosterol](https://en.wikipedia.org/wiki/Lathosterol)
- And so by measuring lathosterol and desmosterol, you get a sense of how much cholesterol a person makes.

–*So looking at this Patient 1…*

- He has normal levels of lathosterol and desmosterol
- So we know he is not a hyper synthesizer of cholesterol

*-What statins do and how it impacts this patient…*

- Statins work by
  - 1) inhibiting cholesterol synthesis, and
  - 2) the liver, in response to that reduction of synthesis, makes more LDL receptors which **pulls more of the ApoB particles out of circulation**
- \*Since statins work by inhibiting cholesterol synthesis, this patient is NOT going to be a super responder to a statin

**Cholesterol reabsorption—how it works and how to measure it:**

- Once a patient makes cholesterol, it gets trafficked and moved all around the body
- But a lot of it ends up back in the liver
- It gets taken out of circulation and
- then gets put into bile
- It then comes to a checkpoint in the gut to see if it needs to be **reabsorbed**
  - We have a transporter called the [Niemann-Pick C1-Like 1 transporter](https://en.wikipedia.org/wiki/NPC1L1) that brings cholesterol into the [enterocyte](https://en.wikipedia.org/wiki/Enterocyte)
  - There’s a checkpoint inside that enterocyte that determines if they should keep the cholesterol or excrete it
- If it’s excreted, it goes out through something called an [ATP binding cassette](https://en.wikipedia.org/wiki/ATP-binding_cassette_transporter) (G5G8 transporter) and it goes out in the GI tract.

-How to measure this process?

- We look at 2 phytosterols (plant cholesterol)  which we *do not make*:
  - [beta-Sitosterol](https://en.wikipedia.org/wiki/Beta-Sitosterol)
  - [campesterol](https://en.wikipedia.org/wiki/Campesterol)
- I*n this patient*…
  - they’re actually quite elevated… **So what does that tell us?**
  - It says that this person is reabsorbing a lot of their own cholesterol
  - A patient like this is a poster child for a drug called Zetia ([Ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe)) because Zetia targets that process

**Treatment plan for Patient 1**

- First thing Peter did in this patient was actually increase his atorvastatin to 20 milligrams
- And more importantly, Peter added ezetimibe
- “*What I suspect will happen is he will have a significant reduction in ApoB as a result of that.*”
- Target for this patient is going to be an ApoB of about 40
  - This is a very aggressive target because i)  family history, and ii) the Lp(a) and the fact that I know that this is a very bad actor of Lp(a)
- NOTE: Not everybody that has elevated Lp(a) is it very high risk, but his family history tells me that this is a bad version of Lp(a)

⇒ \*ADVICE: Anybody that has an elevated Lp(a) must immediately be screened for aortic stenosis, which is about a 2-4x increase in said patients

**More resources from Peter on this topic:**

- Peter’s series of cholesterol articles: [The straight dope on cholesterol](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-i/)
- 5-part podcast about lipids with Tom Dayspring, M.D., FACP, FNLA:
  - Part I of V: [An introduction to lipidology (EP.20)](https://peterattiamd.com/tomdayspring1/)
  - Part II of V: [Lipid metrics, lipid measurements, and cholesterol regulation (EP.21)](https://peterattiamd.com/tomdayspring2/)
  - Part III of V: [HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins (EP.22)](https://peterattiamd.com/tomdayspring3/)
  - Part IV of V: [Statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain (EP.23)](https://peterattiamd.com/tomdayspring4/)
  - Part V of V: [Lp(a), inflammation, oxLDL, remnants, and more (EP.24)](https://peterattiamd.com/tomdayspring5/)

> “To me, that’s the fun of medicine, right? It’s like you’re a detective and you never get the full facts. You’re never going to know everything. You’re always dealing with incomplete information. You always have to use converging, triangulating pieces of data to sort of update and refine your estimates of risk.”

## Patient case study—familial hypercholesterolemia [59:30]

\*\*\*\*\*

**Patient 2:**

- 38, Male
- Indian descent (Southeast Asian)
- Body type: Normal BMI.

–*Meds while on a labs (pertinent)*

- Fish oil – dose n/a

–*Fam Hx:* ***Remarkable family history of CVD, T2DM, HTN.***

- Father: Hyperlipidemia
- Paternal grandfather: Fatal MI (78 YO), T2DM.
- Paternal uncles/aunts: Fatal MI (uncle 65 YO).
- Mother: HTN, T2DM, hyperlipidemia
- Maternal Grandmother: Fatal MI (83 YO), T2DM
- Maternal Grandfather: Fatal MI (50 YO), T2DM.
- Maternal uncle/aunts: CABG, stroke.

⇒ Question: *Who is important when looking at family history?*

- Parents, aunts, uncles, grandparents, and siblings
- Focus on quality over quantity

–*Med Hx:*

- ApoE 3/3
- Heterozygous for MTHFR – 677C/C, 1298 A/C

–*Imaging*

- No CAC done.

–*Nutrition:*

- TRF 18/6
- Low carb, keto.

*-Other Testing:*

- Omega-3 Index: 11.1%

**Lab test results for Patient 2**:

![](https://peterattiamd.com/wp-content/uploads/2020/05/patient-2-labs-A-ama14--831x1024.png)

![](https://peterattiamd.com/wp-content/uploads/2020/05/patient-2-labs-B-ama14-1024x846.png)

\*\*\*\*\*

**Observations from Patient 2’s labs**:

- High total cholesterol at 356 milligrams per deciliter
- High LDL cholesterol at 268 milligrams per deciliter
- High non HDL cholesterol is 285 milligrams per deciliter (that’s all because of their LDL — their VLDL is normal)
- High ApoB at 204 milligrams per deciliter
- 95th to 99th percentile of LDL-C and ApoB (they are concordant in his case)
- Lp(a) and VLDL is completely normal

**First hypothesis**: *He has* [*familial hypercholesterolemia*](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia) *(FH) until proven otherwise*

- FH is a phenotypic diagnosis
- There is a very, very heterogeneous set of genes that predisposes to it

*-How did Peter make this early FH diagnosis?*

- Normal triglycerides
- HDL-C is slightly elevated
- Total cholesterol is elevated
- LDL cholesterol is elevated

⇒ Quick plug for the ApoB app by Allan Sniderman

**The bottom line is this**:

- FH is the phenotype (primary elevation of LDL and by extension then total cholesterol)
- But the question is, **Why?**
- Many cases of FH are due to a defect on the LDL receptor so the patients don’t clear LDL well
- But when you look at Patient 2…
- Peter sees the **highest level of beta-Sitosterol and campesterol** he’s ever seen
- Indicating that the FH diagnosis is probably due to a **defective ATP binding cassette**
- In other words, **the primary driver of this patient’s phenotype is that they’re enterocyte is not able to regulate how much cholesterol they absorb**.
- That means this patient absorbs cholesterol through that Niemann-Pick C1-Like 1 transporter and they can’t get any of it out … they just accumulate all of the cholesterol they synthesize.

**What does this mean for Patient 2’s treatment?**

- This is a patient that **needs** to be treated
- But if you didn’t see the **cholesterol/sterol ratios**, you would “*hit this patient over ahead with enough statin to kill a horse*”
- This patient needs to be on a statin, BUT… what they need more than anything is to be on [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe)
- This patient’s functional defect is on the reabsorption of cholesterol, and that has to be the primary target of therapy
- This patient will do very well on a **medium dose of a statin combined with ezetimibe**

**Do all physicians do these types of labs from** [**Boston Heart Diagnostics**](https://bostonheartdiagnostics.com/)**?**

- Unfortunately, it’s actually pretty rare that a non-lipidologist would do this lab work for a patient
- And the reason is probably because they don’t know what to do with the information
- But Peter cannot recommend it strongly enough because it helps you to see the primary issue:
  - Triglyceride synthesis or accumulation?
  - cholesterol synthesis?
  - cholesterol reabsorption?
  - LDL clearance?
- “*If you can’t have a sense of which of those things is out of whack, how can you treat this?*”

**Another quick example**:

-A patient with:

- High ApoB
- low synthesis
- low absorption
- high triglycerides

“*This is a patient for whom your* ***first, second, third line of defense is diet.*****”**

-Example of high triglycerides

- Somebody with a triglyceride of 500 in that situation has a genetic defect on the triglyceride side
- And that person needs to be on a [fibrate](https://en.wikipedia.org/wiki/Fibrate), a type of drug that lowers triglycerides
- But again, if you don’t have that information because you didn’t do the necessary lab work… *how is one able to put the best thoughts forward in terms of the clinical management of these cases*?

**\*More about ezetimibe courtesy of Tom Dayspring:**

It is not (and never has been from the day it came on the market) off FDA label to prescribe ezetimibe monotherapy to lower LDL-C. Of course lacking an outcome trial, guidelines (being evidence based) do not recommend ezetimibe as a starter monotherapy for LDL.  There have been zero ezetimibe vs placebo or vs statin monotherapy primary, or secondary, prevention trials (other than a very recent geriatric one in Japan in 2019 which still has not been published yet).

That trial is “The Ezetimibe Lipid Lowering Trial on Prevention of Atherosclerosis in 75 or Older ([EWTOPIA](https://www.acc.org/latest-in-cardiology/clinical-trials/2018/11/08/22/56/ewtopia75)) trial”  It was the first trial to look at ezetimibe alone vs diet to reduce cardiovascular events.  **Conclusion**: compared with dietary counseling alone, the use of additional ezetimibe for primary prevention among elderly Japanese patients with LDL ≥140 mg/dl and ≥1 high-risk feature reduced CV events, primarily cardiac events, with no difference in all-cause mortality. None of these patients were on statin therapy.   Thus it is incorrect to state ezetimibe monotherapy trials failed or were null (as aside from the Japan trial none were done).

I think the trials Peter was alluding to were early CIMT trials (such as ENHANCE) where ezetimibe had little effect on IMT progression (an endpoint we now recognize as useless) . The closest monotherapy outcome trial was SHARP – which was a trial of people with significant renal impairment—For year one, it was simvastatin + ezetimibe vs ezetimibe monotherapy vs placebo and starting at year 2 and thereafter it was simvastatin + ezetimibe vs placebo. The reason why it was ethical to use a placebo is that stain monotherapy trials had previously failed to impact outcomes in CKD.  In the SEAS trial (to see effect on aortic stenosis outcomes) it was simvastatin + ezetimibe vs placebo. In post-hoc analysis, the statin + ezetimibe vs placebo did reduce events of atherosclerotic cardiovascular disease (ASCVD) but not atherosclerotic-related events.

## Coming up on a future AMA [1:10:30]

More case studies that touch on other lab results such as…

- Oral glucose tolerance test (OGTT)
- Unique metabolic cases that go beyond the obvious but into the subtle stuff like:
  - Homocysteine
  - Uric acid
  - Liver function tests, and
  - More
- Peter has some really interesting endocrine cases around testosterone
- Additionally, we’ve got some male and female hormone questions
- And plenty more metabolic stuff and some glucose stuff

§

## Selected Links / Related Material

**Previous AMA episodes that discussed lab tests and reference ranges**:  [2:45]

- [#04 – AMA #1: alcohol, best lab tests, wearables, finding the right doc, racing, and more](https://peterattiamd.com/ama01/) | Peter Attia (peterattiamd.com)
- [#11 – AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting](https://peterattiamd.com/ama02/) | Peter Attia (peterattiamd.com)
- [#26 – AMA #3: supplements, women’s health, patient care, and more](https://peterattiamd.com/ama03/) | Peter Attia (peterattiamd.com)

**Centenarian studies mentioned**: [10:45]

- By Thomas Perls: [New England Centenarian Study](https://www.bumc.bu.edu/centenarian/) | (bumc.bu.edu)
- *By Nir Barzilai*: [The Longevity Genes Project](https://www.einstein.yu.edu/centers/aging/longevity-genes-project/) | (einstein.yu.edu)

**Centenarians put into 3 categories—The delayers, escapers, and survivors article**: [Morbidity Profiles of Centenarians: Survivors, Delayers, and Escapers](https://academic.oup.com/biomedgerontology/article/58/3/M232/684123) (Evert, et al., 2003) [10:45]

**Peter’s article about heart disease and prevention**: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | Peter Attia (peterattiamd.com) [23:20]

**Coronary artery calcium scoring was discussed in detail on AMA #5**: [#50 – AMA #5: calcium scores, centenarian olympics, exercise, muscle glycogen, keto, and more](https://peterattiamd.com/ama05/) | Peter Attia (peterattiamd.com) [24:30]

**The Drive episode with Ethan Weiss discussing CAC among other CVD topics**: [#52 – Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone – two topics that are surprising interrelated](https://peterattiamd.com/ethanweiss/)  | Peter Attia (peterattiamd.com) [27:30]

**After smoking, obesity is the next leading predictor of cancer**: [#32 – Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process](https://peterattiamd.com/sidmukherjee/) | Peter Attia (peterattiamd.com) [29:00]

**Episodes of The Drive discussing liquid biopsies**: [32:00]

- [#06 – D.A. Wallach: music, medicine, longevity, and disruptive technologies](https://peterattiamd.com/dawallach/) | Peter Attia (peterattiamd.com)
- [#62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/) | Peter Attia (peterattiamd.com)

**Allen Roses discovering the impact of ApoE4 in Alzheimer’s disease**: [Gene dose of apolipoprotein E type 4 allele and the risk of Alzheimer’s disease in late onset families.](https://www.ncbi.nlm.nih.gov/pubmed/8346443) (Corder et al., 1993) [34:15]

**Episode of The Drive discussing Alzheimer’s disease having a huge vascular component**: [#38 – Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer’s disease treatment and prevention – is AD actually a vascular and metabolic disease?](https://peterattiamd.com/franciscogonzalezlima/) | Peter Attia (peterattiamd.com) [36:15]

**Previous episodes of The Drive with info about Zone 2 exercise**: [40:00]

- [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com)
- [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/) | Peter Attia (peterattiamd.com)
- [#73 – AMA #9: NAD & metformin, fat-burning zone, creatine, estrogenization of men, emergency kit for cold & flu, and more](https://peterattiamd.com/ama09/) | Peter Attia (peterattiamd.com)

**Peter’s thyroid hormones whiteboard video**: [Thyroid hormones](https://vimeo.com/337835256/765434e953) | A|M (vimeo.com) [43:15]

**Episode of The Drive all about Lp(a)**: [#07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know](https://peterattiamd.com/lpa/) | Peter Attia (peterattiamd.com) [45:30]

**Peter’s weekly emailing explaining ApoB**: [Measuring cardiovascular disease risk and the importance of apoB](https://peterattiamd.com/measuring-cardiovascular-disease-risk-and-the-importance-of-apob-part-1/) | Peter Attia (peterattiamd.com) [50:00]

**Resources from Peter about ATP cassettes and all things lipids and heart disease**: [58:00]

- *Peter’s series of cholesterol articles*: [The straight dope on cholesterol](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-i/) | Peter Attia (peterattiamd.com)
- *5-part podcast about lipids with Tom Dayspring, M.D., FACP, FNLA*:
  - Part I of V: [An introduction to lipidology (EP.20)](https://peterattiamd.com/tomdayspring1/)
  - Part II of V: [Lipid metrics, lipid measurements, and cholesterol regulation (EP.21)](https://peterattiamd.com/tomdayspring2/)
  - Part III of V: [HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins (EP.22)](https://peterattiamd.com/tomdayspring3/)
  - Part IV of V: [Statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain (EP.23)](https://peterattiamd.com/tomdayspring4/)
  - Part V of V: [Lp(a), inflammation, oxLDL, remnants, and more (EP.24)](https://peterattiamd.com/tomdayspring5/)

**Peter’s favorite company to order labs from**: [Boston Heart Diagnostics](https://bostonheartdiagnostics.com/) | (bostonheartdiagnostics.com) [1:06:15]

**Clinical trial, which Peter criticizes as being done incorrectly since they didn’t stratify by the types of patients who would likely most benefit, looking at ezetimibe showing no improvement in overall mortality**: [Ezetimibe for the prevention of cardiovascular disease and all-cause mortality events.](https://www.ncbi.nlm.nih.gov/pubmed/30480766) (Zhan et al., 2018) [1:08:15]

§

## People Mentioned

- [Thomas Perls](https://www.bumc.bu.edu/busm/profile/thomas-perls/) [10:45]
- [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/) [10:45]
- [Ethan Weiss](https://profiles.ucsf.edu/ethan.weiss) [27:30]
- [Keith Flaherty](https://www.dfhcc.harvard.edu/insider/member-detail/member/keith-t-flaherty-md/) [32:00]
- [Allen Roses](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(16)32081-5/fulltext) [34:15]
- [Travis Denson](https://instagram.com/superserioushealth) (show notes contributor) [36:30, 53:00]
- [Francisco Gonzalez-Lima](https://dellmed.utexas.edu/directory/francisco-gonzalez-lima) [36:15]
- [Alois Alzheimer](https://en.wikipedia.org/wiki/Alois_Alzheimer) [37:30]
- [Auguste Deter](https://en.wikipedia.org/wiki/Auguste_Deter) (first person diagnosed with Alzheimer’s disease) [37:30]
- [Iñigo San Millán](https://twitter.com/doctorinigo?lang=en) [40:00]
- [Tom Dayspring](https://twitter.com/Drlipid?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [58:00]
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman) [1:03:00]

§