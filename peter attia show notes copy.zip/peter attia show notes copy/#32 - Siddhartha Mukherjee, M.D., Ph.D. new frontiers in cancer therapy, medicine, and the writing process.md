# #32 – Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process

**Source:** [https://peterattiamd.com/sidmukherjee/](https://peterattiamd.com/sidmukherjee/)

---

In this episode, Siddhartha Mukherjee, oncologist, researcher, and author of the Pulitzer Prize-winning book, *The Emperor of All Maladies: A Biography of Cancer*, discusses his writing process, his thoughts about medicine, cancer, immunotherapy, and his recent collaboration on a study combining a ketogenic diet with a drug in mice that provided remarkable and encouraging results.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sidmukherjee/the_Drive_public.png)

Play

#32 - Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process

#32 - Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process

1x15s30s

0:001:05:11

## We discuss:

- Sid’s background [5:00];
- How Sid and Peter met [6:00];
- Sid’s Pulitzer Prize-winning book: The Emperor of All Maladies [8:00];
- Sid’s writing process: the tenets of writing [12:30];
- Our struggle to find preventable, human, chemical carcinogens of substantial impact [23:30];
- The three laws of medicine — Law #1: A strong intuition is much more powerful than a weak test [26:30];
- Law #2 of medicine: “Normals” teach us rules; “outliers” teach us laws [32:00];
- Law #3 of medicine: For every perfect medical experiment, there is a perfect human bias [35:00];
- The excitement around immunotherapy [38:15];
- The story of Gleevec [46:00];
- How does the body’s metabolic state affect cancer? [49:30];
- Can a nutritional state be exploited and/or a drug sensitivity be exploited through a nutritional intervention? [52:00];
- How does Sid balance his family, writing, research, laboratory, and patients? [1:00:30]; and
- More.

Featured image source: [Nanotech Magazine](https://www.nanotechmag.com/wp-content/uploads/2015/01/Pancreatic-cancer-cells-014.jpg)

§

## Show Notes

## Intro

Peter Attia: I met Sid five years ago at a dinner that was set up by Lew Cantley, someone I’ll be interviewing very shortly, who will be a guest obviously soon. And while I remember that dinner very well, I was surprised to learn that it left such an impression on Sid, and he described it as something to the effect of one of the most interesting and perhaps important scientific collaborations in his life that stemmed from it as we kind of jotted out a napkin experiment that went on to become a paper that was published by a group led by Lew and Sid.

**Sid’s recent article in the *New York Times Magazine* about the collaboration with Lew Cantley**: [It’s Time to Study Whether Eating Particular Diets Can Help Heal Us](https://www.nytimes.com/2018/12/05/magazine/its-time-to-study-whether-eating-particular-diets-can-help-heal-us.html) | Siddhartha Mukherjee (nytimes.com)

**Sid and Lew Cantley’s important paper studying ketogenic diets in combination with PI3 kinase inhibitors**: [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.nature.com/articles/s41586-018-0343-4) (Hopkins et al., 2018) [2:00, 46:00, 49:45, 52:00]

Peter Attia: And that paper was published this past summer and we talk about that in detail. That paper involved the use of ketogenic diets in combination with a class of drugs called PI3 kinase inhibitors. We’re going to go into great detail on that so I obviously don’t want to repeat any of that stuff here. But I think for those that are interested in cancer, you’re obviously going to find this episode very interesting. But the other thing with Sid is it doesn’t matter if you have no interest in cancer, I think you’ll find this discussion interesting because Sid has a way of making everything interesting and that, to me, is part of Sid’s gift.

Peter Attia: When I got his book *The Gene* in the summer of 2016 when it came out, it’s one of probably only six books in my life that I was not able to stop reading from the moment I started. So it’s one of those things where everything else I was doing had to be put aside for a few days until I could finish that book. That’s just the way Sid writes. And it’s also the way he speaks. He is a unique human being and I think that will come across in this interview.

**Sid’s most recent book**: [The Gene: An Intimate History](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1432837818) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [2:40, 7:30]

Peter Attia: The other thing that was a total pleasant surprise to me in doing the research for this podcast was coming across a book that I was ashamed to admit I didn’t even know he’d written, I believe it’s called *The Laws of Medicine*. And we talk about these three laws and rather than even stating them now I just think this podcast is worth the price of admission just on the basis of understanding those three laws.

**Sid’s TED Book which Peter says is a “great way of teaching people how to think”**: [The Laws of Medicine: Field Notes from an Uncertain Science (TED Books)](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [3:15, 26:30]

Peter Attia: So with that, I hope you will welcome Sid to the show. And I do want to just remind folks to please sign up for the email list. I’ve been putting a lot of effort into those emails, every Sunday morning they go out, and I hope that they’re at least worth some value, I think they are. And I like to be able to kind of share things with folks that I’m reading or seeing along the way. And they don’t always have to do with longevity.

Peter Attia: Keep in mind, one of the things that I think takes up more actual time than anything else with respect to this podcast is putting together the show notes. So Bob and Travis work really hard on those and the feedback we’ve been getting is incredible. People keep saying, “My God! How do you make these things?” And the short answer is I don’t, I don’t do any of it. But Bob and Travis do, especially Travis, and I think that if you spend a few minutes looking at that stuff, especially if you find some of the content challenging and when we get into technical terms, which we do on some of the podcasts, you’re pretty much going to find everything in the show notes.

Peter Attia: Lastly, if you’re enjoying this it would be an honor if you would head on over to Apple Podcasts reviews and leave us a review, especially if it’s a positive one. But we’ll take a negative one too as long as you can be constructive in your feedback.

## Sid’s background [5:00]

Peter Attia: Hey Sid, thanks for making time.

Sid Mukherjee: My pleasure, thanks for being here.

Peter Attia: Yeah, I don’t get up to this part of the city very often, it’s a bit of a hike.

Sid Mukherjee: Well, it’s a massive medical school and it’s hard to imagine it anywhere else except for uptown in this way. We go right all the way to the river.

Peter Attia: It’s amazing. And the last time I was up here was to see another one of your colleagues on the other side of the street, Rudy Leibel, he is a good friend. And I used to be up here a lot more often, so it’s nice to come back.

Peter Attia: Most of our podcasts go really, really long. This one, I don’t think we have that luxury of time, so I kind of want to get right into things. But before we do, I certainly think for the listener who doesn’t know your background, which I’ll allude to a lot in the introduction so we don’t spend too much time on it, but you grew up in India, came to the US. Did you do college here?

Sid Mukherjee: I went to college at Stanford, yeah.

Peter Attia: Oh that’s right, you went to undergrad at Stanford, okay. Then medical school at Harvard.

Sid Mukherjee: Actually then in the middle, I was away for three years, I did-

Peter Attia: You did a Rhodes Scholarship. Are you a Rhodes scholar?

Sid Mukherjee: I was a Rhodes scholar and that’s where I got my PhD, and my Ph.D. is in immunology, which is a subject that I left behind, went to medical school at Harvard Medical School, then did my fellowship and my internship, my residency at Mass General Hospital, a fellowship at the Dana-Farber Cancer Institute, and then started my own lab and clinical practice at Columbia University and have come back to immunology in a strange widening circle of a way.

## How Sid and Peter met [6:00]

Peter Attia: Yeah, the first time we met was a dinner that Lew Cantley had planned for us, this is about three or four years ago. And I remember at the time the topic that Lew is passionate about, that I’m passionate about, was sort of metabolism of cancer. And at the time it wasn’t something that seemed as interesting to you as it is today, and I know today I want to talk so much more about that because the work you guys have done in the last few years is in many ways what I think as the most interesting stuff to talk about.

Sid Mukherjee: It was also a tough dinner because you don’t eat most things. It’s hard to have dinner with someone when half the menu is off the menu. So anyway, we somehow managed and scraped by and it was a wonderful evening. It actually led to, what was that, five years ago? Led to one of the most interesting and perhaps important scientific collaborations in my life-

Peter Attia: With Lew.

**Sid’s recent article in the *New York Times Magazine* about the collaboration with Lew Cantley**: [It’s Time to Study Whether Eating Particular Diets Can Help Heal Us](https://www.nytimes.com/2018/12/05/magazine/its-time-to-study-whether-eating-particular-diets-can-help-heal-us.html) | Siddhartha Mukherjee (nytimes.com)

Sid Mukherjee: With Lew. But it was that dinner in a Japanese restaurant on the Upper East Side in a tiny little place.

Peter Attia: You remember? I know exactly where we were at.

Sid Mukherjee: I know exactly where it was. Well, because it was a little bit like one of these napkin experiments where you write on a napkin an idea and that idea takes five years to come alive, this thing that was sketched on a napkin that evening, and is now leading to actually kind of a massive clinical trial across multiple sites, very energetic teams coming into all of this out of that little napkin in a Japanese restaurant.

**Sid and Lew Cantley’s important paper studying ketogenic diets in combination PI3 kinase inhibitors**: [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.nature.com/articles/s41586-018-0343-4) (Hopkins et al., 2018) [2:00, 46:00, 49:45, 52:00]

Peter Attia: Yeah, that was a really fun night. Prior to that, I had read *The Emperor of All Maladies*. I don’t think *The Gene* was out yet.

Sid Mukherjee: *The Gene* was not out yet.

**Sid’s most recent book**: [The Gene: An Intimate History](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1432837818) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [2:40, 7:30]

**Sid’s Pulitzer Prize Winning book on the history of cancer**: [The Emperor of All Maladies: A Biography of Cancer](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [7:30]

**Sid wins a Pulitzer Prize**:: [The Emperor of All Maladies: A Biography of Cancer, by Siddhartha Mukherjee (Scribner)](https://www.pulitzer.org/winners/siddhartha-mukherjee) | ([pulitzer.org](https://www.pulitzer.org/)) [7:30]

Peter Attia: I want to spend just a couple of minutes on *The Emperor of All Maladies* because if there’s anybody listening to this who hasn’t read it … You won the Pulitzer Prize for that book, I believe.

Sid Mukherjee: I did, yes.

## Sid’s Pulitzer Prize-winning book: The Emperor of All Maladies [8:00]

Peter Attia: Yeah, so it’s a must-read. Having myself studied in oncology, there was so much that I learned. I trained at Hopkins which is … So we were in the Halsted school where the mastectomy was created, where many of these things were created, but to really understand the history of Bernard Fisher’s role in the mastectomy, it’s just an unbelievable story. My only criticism was at the time: quite a depressing story. I mean I’m not saying that to be critical, it’s less a criticism of you than the field.

Sid Mukherjee: Interestingly, people often bring this idea up. For me, actually, it’s far from a depressing story, it’s just the opposite. In fact, if we don’t contend with the question of how … I mean *The Emperor of All Maladies* is, just for people who don’t know, there’s a history of cancer starting from its first description in Egypt right down to my own patients. Thousands of years of a journey against a disease that seems to morph and change over time. Every time we look at it it has a new form. It reflects our own diversity to some extent, our own wiliness, our own imagination as humans.

Sid Mukherjee: So to me, not a depressing book because it is a way to look directly at the face of the enemy, and I don’t find that depressing, I find that clarifying. And there are many, many high points in this journey. There is the invention of the great surgeries that save tens of thousands, hundreds of thousands of lives around the world, the dramatic advances against breast cancer and, most importantly, against some variants of leukemia where the mortality was a 100% in 1950 and is 5 or 10% now. A 95% change in mortality is a huge difference, must rank as one of the great medical inventions of our time. So for me far from a depressing book but to me a clarifying book that tries to clarify why we’re here today, where we’re going, what happens next, why we’re not doing certain things, why we are doing certain things. So that’s my impression of what happened at the end of that book.

Peter Attia: When did the idea to write as it’s really referred to the biography of cancer, when did that idea come to? Was it in your fellowship, in your training at some point?

Sid Mukherjee: Yeah, I was training and it was a very simple moment, actually. I remember a woman who I was treating for cancer came to me and I was giving her yet another trial of targeted therapy, a new kind of therapy, and she finally set down one afternoon and she said, “Where are we going with all of this? Why are we here? How did we get here?”

10:00

And she was, of course, asking in a very personal level, but you could take that question and make it a much, much larger question: where are we going in this battle against cancer? Why are we here today? What happens next? Why aren’t we elsewhere? How much of this is the wiliness of this family of diseases? How much of this is the capacity to use the greatest skills of our imagination against this illness?

Sid Mukherjee: In the 1930s, 1940s, 1950s, when you asked a child what the outer limit of their scientific imagination was they would say, “I want to be a rocket scientist and I want to send a rocket to the moon.” By the 1950s, ’60s, ’70s, if you asked that same child what the outer limits of their scientific imagination would bring to the world they would say, “I want to cure cancer.” It began to define the limits of our scientific prowess, the limits of our imagination – a world without cancer. So there is a sense in which this is such an elemental illness. So much of our culture is now defined through the lens of cancer.

> To accept one opinion survey, most Americans believe the same. Or did. On December 23, 1949. Gallup asked Americans to consider the limits of what they thought achievable by the end of the twentieth century.
>
> Question 14(c) went like this: **Do you think that men in rockets will be able to reach the moon within the next 50 years?**
>
> Seventy-seven percent of those asked said, “No.”
>
> [. . . ]
>
> In the same poll, though, was Question 14(a): **Do you think that a cure for cancer will be found within the next 50 years?**
>
> This time, 88 percent said, “Yes.”

—CLIFTON LEAF, *The Truth in Small Doses*

Sid Mukherjee: And what was shocking as a Fellow when I started encountering cancer in the clinical sense, what was shocking was that there was no such history, that it was all ad hoc and we knew little bits and pieces of it. It was like looking at the enemy through a patchwork quilt with little holes in it. And the attempt here was to say, “Well, what is the full story? What does the story look like? When did it start? Why did we end up here? What happens tomorrow? What happens way into the future a 100 years? What will cancer look like?” And then a lot of thought experiments go into the book.

Sid Mukherjee: So that’s sort of the genesis of the book and that’s how it came about.

Peter Attia: The research is also remarkable for a book like that. Anyone who’s read it will appreciate it. And again, I think what’s nice is this is one of those books where you can be an oncologist and read it and find it staggering, and you can be someone who has lost a loved one to cancer but wouldn’t know the difference between a sarcoma and a leiomyosarcoma. It doesn’t matter, the book resonates. Which obviously speaks to your ability to tell a story. And that’s, to me, what’s mind-boggling about that book, is the way … And it’s the same in *The Gene*, by the way, is that you weave in and out of a personal story and then something that’s very dense scientifically. And on the personal level this is challenging because I’m in the process, as you know, of writing a book and doing a pretty lousy job of it, I think. But it’s this challenge of, you want to be able to do the science justice, but you need to be able to tell a story.

How does the scientist Sid Mukherjee get along with the writer Sid Mukherjee?

## Sid’s writing process: the tenets of writing [12:30]

Sid Mukherjee: I don’t think they’re two separate people, I think they’re integrated into one person, and that’s very important. There are many people in my world, they wrote as a process of thinking. Stephen Jay Gould comes to mind. Not to draw a ludicrous comparison, Charles Darwin wrote to think. Oliver Sacks wrote to think. I would suspect that Atul Gawande writes to think, I mean I know Atul. So the two people are fundamentally not different people in my brain. In order to do the scientific work that I do, I need to think it often through the essays that I work on and they inspire, in a kind of Yin-Yang or roundabout circular way, ways to find new ways of thinking about the cancer world. So there isn’t a conflict, I don’t feel a conflict.

Sid Mukherjee: The process is probably of interest. I mean the processes that … When I started writing *Emperor* I sort of made a personal vow or a strategy in writing. This was my first book, I had never written a book before. I wrote down some principle or tenets that I would follow, and I’ve kept to them in every book since.

Sid Mukherjee: **The first one was that there will be no scientific abstraction. At no place or point shall you go through five pages or three pages without there being a human being in the middle of this**. I’m a translational researcher, I’m a human scientist, and that meant that I made a personal promise that you wouldn’t go through five pages without understanding what the payoff of these pages that you’ve really worked your way through, often as a reader, what the payoff is. So if you look carefully through that book, every five to seven pages the story comes alive in a human story, in a scientific story, and in a scientist’s story. They all intersect. And sometimes through my stories.

Sid Mukherjee: There are times that are tough when I’m writing about the description of the first cancer-causing genes, oncogenes, and their mutations, it’s tough to say, “Well, what’s the human being?” This is a laboratory experiment in which you sprinkle tens of thousands of bits of genetic material onto cells and ask the question “Which cells turn from normal to cancers?” And that’s the way you trap one of these cancer-causing oncogenes.

Sid Mukherjee: But what’s the human story behind it? Well, there are two stories. One story is quite lovely, it’s a story of Bob Weinberg, the scientist who you know, walking through Boston in a snowstorm and suddenly realizing, not in a one-to-one manner, but this idea of sprinkling tens of thousands of genes onto pieces of genetic material, onto cells like a snowstorm of genes. There’s a kind of congruence to that story. It’s not like Bob Weinberg woke up one morning and saw a snowstorm and said, “That’s the experiment I should do,” but there’s a kind of emotional congruence to the backstory of a scientist.

> Clarity came to him one morning in the midst of one of Boston’s infamously blinding blizzards. On a February day in 1978, walking to work, Weinberg was caught in an epic snowstorm. Public transportation had ground to a halt, and Weinberg, in a rubber hat and galoshes, had chosen to plod across the blustering Longfellow Bridge from his home to his lab, slowly planting his feet through the slush. The snow blotted out the landscape and absorbed all sounds, creating a silent, hypnotic interior. And as Weinberg crossed the frozen river, he thought about retroviruses, cancer, and human cancer genes.
>
> *Src* had been so easy to isolate and identify as a cancer-causing gene, Weinberg knew, because Rous sarcoma virus possesses a measly four genes. One could scarcely turn around in the retroviral genome without bumping into an oncogene. A cancer cell, in contrast, has about twenty thousand genes. Searching for a cancer-causing gene in that blizzard of genes was virtually hopeless.
>
> But an oncogene, by definition, has a special property: it provokes unbridled cellular proliferation in a normal cell. Temin had used this property in his cancer-in-a-dish experiment to induce cells to form “foci.” And as Weinberg thought about oncogenes, he kept returning to this essential property.
>
> Of the twenty thousand genes in a cancer cell, Weinberg reasoned the vast majority were likely normal and only a small minority were mutated proto-oncogenes. Now imagine, for a moment, being able to take all twenty thousand genes in the cancer cell, the good, the bad, the ugly, and transferring them into twenty thousand normal cells, such that each cell receives one of the genes. The normal, unmutated genes will have little effect on the cells. But an occasional cell will receive an oncogene, and, goaded by that signal, it will begin to grow and reproduce insatiably. Reproduced ten times, these cells will form a little clump on a petri dish; at twelve cell divisions, that clump will form a visible “focus”—cancer distilled into its primordial, elemental form.
>
> The snowstorm was Weinberg’s catharsis; he had rid himself of retro-viruses. If activated oncogenes existed within cancer cells, then transferring these genes into normal cells should induce these normal cells to divide and proliferate. For decades, cancer biologists had relied on Rous sarcoma virus to introduce activated src into cells and thereby incite cell division. But Weinberg would bypass Rous’s virus; he would determine if cancer-causing genes could be transferred directly from cancer cells to normal cells. At the end of the bridge, with snow still swirling around him, he found himself at an empty intersection with lights still flashing. He crossed it, heading to the cancer center.

—SIDDHARTHA MUKHERJEE, *The Emperor of All Maladies*

Sid Mukherjee: But then, the second story that illustrates this point is to walk through a patient, telescoping down or, rather, microscoping downwards from their outer cancer, a tumor, a lump, a mass that is about to kill them, a real patient of mine, a man with lung cancer, and slowly in that same story of this man’s illness, begin to microscope down to the fact that he actually has, in his cells, this mutant gene, that Bob Weinberg once caught in this snowstorm of sprinkling genes on cells. And all of a sudden, this man’s cancer is sitting in a room in Boston, surrounded by his family, dying of metastatic lung cancer. But at the heart, at the root of that lung cancer, is that very same gene, that very same oncogene, that was discovered, described 10, 20 years before in a paper, in a kind of dry, abstract scientific paper and all of a sudden, that gene, the genetic material that can drive the growth of a normal cell and make it malignant, make it metastatic, so metastatic, so malignant, that our best medicine, our best minds can’t stop the growth of this aberrant cell, all being driven in part by that very same gene that was trapped 20 years ago in a laboratory experiment on rat cells.

Sid Mukherjee: So all of a sudden this thing comes alive to you in a way that it becomes consequential. If you didn’t know the identity of the gene you would not understand why on earth this 78-year-old man in perfectly good health is all of a sudden decimated by one or two or four or eight mutant genes in his cells that suddenly take over and drive the growth of these cells.

Sid Mukherjee: Anyway, that’s one example, it comes up over and over again.

Peter Attia: That was the first tenet.

Sid Mukherjee: That was the first tenet, yes.

Peter Attia: So what was the second one?

Sid Mukherjee: There are many, so I’m not going to go through all the tenets. But **the second one was that this book, all these books should be fundamentally readable by everyone**. You talked about this already. It should be like a kaleidoscope that if you turn the book leftwards and you see it as an oncologist it’s still interesting, the pattern changes if you turn the book rightwards and, say, you’re an anthropologist, it still is interesting. If you turn the kaleidoscope upside down and shake it and there’s a new pattern that’s formed, it’s because you’re reading the book now as a clinical scientist or you’re reading the book because your daughter has leukemia and you’re the father of a patient with leukemia. Or you’re reading it because you yourself have been diagnosed with breast cancer or your mother has, and all of a sudden the kaleidoscope changes. But the point is that the object remains the same, it’s the same book, but you can read the book in various different ways, that you can come into it in different ways.

Sid Mukherjee: Often when I’m in … This sounds like a strange statement. Often when I come back from the words I reread my own writing to figure out sort of what was I thinking then in 2008 when I wrote those sentences and how does that change now.

Peter Attia: Has it really been 10 years?

Sid Mukherjee: It’s been 10 years. So I should tell you that **there will be a 10-year update to the *Emperor*. There will be three additional chapters**.

Peter Attia: I assume one of them will be immunotherapy as an update.

Sid Mukherjee: That’s right. So there are, very broadly, three sections that are updated and I’ve thought about it for a long time. So **there will be an updated section on prevention, there will be an updated section on early detection, and an updated section on treatment**. So that’s the three big, broad chapters. But in every chapter there will be deeper dives into what’s happened now since the last 10 years. And within the treatment section and potentially within the prevention section there will be a huge role of the immune system which was not fully appreciated in 2010.

Peter Attia: I thought that was the biggest distinction between the book when I read it and then the PBS special, the Ken Burns special which, of course, again, we’ll link to all of these things in the show notes here. But one, you got to read the book, but two, I can’t recommend enough the Ken Burns special. They did an unbelievable job, I think, sharing your voice and that was the biggest … I remember watching it thinking, “Oh wow, there’s a big difference here.” Because was it three installments or five? I can’t remember.

**PBS special by Ken Burns on The Emperor of All Maladies**: [Cancer: The Emperor of All Maladies](https://www.pbs.org/show/story-cancer-emperor-all-maladies/) | ([pbs.org](https://www.pbs.org/)) [19:00, 21:15]

Sid Mukherjee: Three.

1. [Magic Bullets](https://cancerfilms.org/episodes/magic-bullets/): The search for a “cure” for cancer is the greatest epic in the history of science. It spans centuries and continents, and is full of its share of heroes, villains and sudden vertiginous twists. This episode follows that centuries-long search, but centers on the story of Sidney Farber, who, defying conventional wisdom in the late 1940s, introduces the modern era of chemotherapy, eventually galvanizing a full-scale national “war on cancer.” Interwoven with Farber’s narrative are the contemporary stories of two very brave young patients.
2. [The Blind Men and the Elephant](https://cancerfilms.org/episodes/the-blind-men-the-elephant/): This episode picks up the story in the wake of the declaration of a “war on cancer” by Richard Nixon in 1971. In the lab, rapid progress is made in understanding the essential nature of the cancer cell, leading to the revolutionary discovery of the genetic basis of cancer. However, it is not until the late 1990s that the advances in research begin to translate into more precise targeted therapies. The episode intertwines the contemporary story of Dr. Lori Wilson, a surgical oncologist who is diagnosed with invasive breast cancer in both breasts.
3. [Finding an Achilles Heel](https://cancerfilms.org/episodes/finding-an-achilles-heel/): This episode picks up the story at another moment of buoyant optimism in the cancer world: Scientists believe they have cracked the essential mystery of the malignant cell and the first targeted therapies have been developed. But, very quickly, cancer reveals new layers of complexity. By the second decade of the 2000s the cancer cell yields to a more ordered picture, revealing new vulnerabilities and avenues of attack. This episode includes patients Doug Rogers, a 60-year-old NASCAR mechanic with melanoma, and Emily Whitehead, a six-year-old child afflicted with leukemia. Each is a pioneer in new immunotherapy treatments, which the documentary follows as their stories unfold.

Peter Attia: Yeah, the third installment felt like it was half immunotherapy.

Sid Mukherjee: It was half immunotherapy. Well, because part of the reason was that … Again, this brings me to the next tenet in writing the book. The next tenet was that there is so much cancer research in laboratories going on everywhere, and **the tenet or the principle was that unless that research has manifested itself in a human drug, in a human medicine, in a reconception of how we think about preventing, treating, or detecting cancer, in a fundamental reconception of those ideas, it won’t get into the book**.

20:00

Sid Mukherjee: So tumor immunology, of course, had been around for a very long time. [Coley’s toxins](https://en.wikipedia.org/wiki/Coley%27s_toxins) famously, and other such efforts very, very early on. But in 2010 we were at the edge of that moment in which we began to use tumor immunology in human beings as powerful medicines to change the course of the disease, it was just the first trials that had come out. And in fact, the book was completed in 2009 and the first trials had not even come out then.

Peter Attia: This is a little funny, trivia story that I had almost forgotten about this until somebody mentioned it to me a year ago. I think the first real paper that I wrote as a fellow was on CTLA-4. It was looking back at this series at NCI of patients who had been given CTLA-4 and responded, and this paper basically identified the strong association between autoimmunity and the response to it. Of course, this will be interesting later in our discussion because I want to, of course, talk about James Allison, so we’ll come back to that. But you’re right, that was sort of when it went from … You had interleukin-2 that worked in maybe 10%, 15% of patients, but you couldn’t predict why. That was the bigger question. You didn’t know why were some responding and why were they only responding with certain cancers. To where we are today where it’s really been a transformation in the last 15 years.

**Peter’s paper on CTLA-4**: [Autoimmunity correlates with tumor regression in patients with metastatic melanoma treated with anti-cytotoxic T-lymphocyte antigen-4](https://www.ncbi.nlm.nih.gov/pubmed/16087944) (Attia et al., 2005) [20:30]

Sid Mukherjee: Absolutely. And so when we started the film version of *Emperor* with Ken Burns, which I obviously was very close, I worked very closely with Ken … I should say that *The Gene* is also being made into a film by Ken Burns.

**PBS is making a special on Sid’s latest book, The Gene**: [PBS Announces KEN BURNS PRESENTS THE GENE: AN INTIMATE HISTORY, New Collaboration with Siddhartha Mukherjee, M.D. Three-Hour Documentary to Premiere Spring 2020 on PBS](https://www.pbs.org/about/blogs/news/pbs-announces-ken-burns-presents-the-gene-an-intimate-history/) | ([pbs.org](https://www.pbs.org/)) [21:15]

Peter Attia: Oh my God, it’s like Christmas all over again.

Sid Mukherjee: It’s almost completely shot, we are sort of moving towards editing phases and so forth.

Peter Attia: When can people expect that?

Sid Mukherjee: Oh, it’s already been scheduled, I think it’s winter or fall 2019. So it’s on the-

Peter Attia: It’s about a year from now?

Sid Mukherjee: Yeah, about a year from now, yeah. We’re working through footage and historical footage and archival footage and so forth.

Sid Mukherjee: But to wind backward, the crucial piece that had been added since the book was, of course, immunological therapy. So much of what the last episode was around this new burgeoning field. I mean, in the first meeting that we had around the transformation of the book into the documentary film, the first thing that was raised is what’s changed? The answer was very obvious what’s changed is immunological therapy.

Peter Attia: It might have been emphasized as much in the book, and I may have just missed it, or it’s possible you also observed this as a change, but I believe it will factor into the new edition, which I can’t wait to get my hands on, is the role of obesity in cancer-

Sid Mukherjee: Yes.

![](https://peterattiamd.com/wp-content/uploads/2018/12/obesity-and-cancer-248x300.gif)

**Figure 1. Cancers associated with overweight and obesity**. Image credit: National Cancer Institute

Peter Attia: If I recall, in the documentary, you said, “Look, this is now becoming basically the second leading preventable cause of cancer after smoking.” Which was, again, I was aware of that at that point in time because of the work that I’d been doing, and my little echo chamber. But, I thought this is a PBS … This is not something that I think most people would appreciate. This is becoming a first for many people to hear.

Sid Mukherjee: That’s right, and the one thing that we should make clear is that every word in that PBS document was vetted by some of the most important and thoughtful scientists and cancer biologists, and physicians, and physician-scientists, and cancer advocates across the world. There’s a backstory. In other words, the script was vetted over and over again so that we wouldn’t say things that were misinforming the public. Because this documentary is for all time. Ken Burns’ work is evergreen. Hopefully, my work is evergreen. So, it was very, very carefully vetted, and it was quite clear by the time the documentary came out that the signals that we were picking up around obesity and cancer were becoming extraordinarily clear for some cancers, obviously, not for other cancers.

## Our struggle to find preventable, human, chemical carcinogens of substantial impact [23:30]

Sid Mukherjee: The provocative statement that sits behind all of this is that, really, since the last 20-odd years, maybe even 30-odd years, **we have been struggling to find preventable, human chemical carcinogens of substantial impact**. Every word in that sentence is important. We have certainly found new chemical carcinogens in humans, but often that affects small pockets of people who are exposed to those carcinogens.

Sid Mukherjee: We have found lots and lots of chemical carcinogens which have moderate to very small impact if you look at populations overall. The bar might be smoking. So, smoking is a good bar. This is smoking or tobacco smoke is a chemical carcinogen, which is removable or preventable, and it has substantial human impact across populations. Changing smoking behavior can change fundamentally the epidemiology of cancers across nations.

![](https://peterattiamd.com/wp-content/uploads/2018/12/null.png)

**Figure 2. Tobacco use in the US and lung cancer rates.**

Sid Mukherjee: If that bar is smoking, we have struggled for the last 20-odd years to find things of that magnitude and effect. The direct impact of that is when people come to me and they say, “Well, what do you do to prevent cancer in yourself and your family?” Obviously, I don’t smoke. But, it’s not like I’m eating goji berries, or avoiding some fundamental thing that everyone else is not in the know about, because there aren’t any. I mean, I’m obviously not exposing myself to these rare, unusual occupational cancer carcinogenic agents. But I’m not doing something fundamentally changed that’s different from you, or anyone else to prevent cancer.

Sid Mukherjee: The exception to this rule of the 20-odd years of the hunt for chemical carcinogens is obesity. Now, you and I can have a debate. Is obesity a chemical carcinogen? No, not in the traditional sense. Is it even preventable? Maybe, but we have to think twice or three times about it, there’s a role of genetics and environment in all of this.

Peter Attia: And, even, do we with its obesity per se, or hyperinsulinemia, or any other endocrine?

Sid Mukherjee: Exactly. First of all, is it an endocrine problem? Is it an inflammatory problem? Or is a metabolic problem? At least three parts.

Peter Attia: Obesity is such a crude phenotype-

Sid Mukherjee: That’s right.

Peter Attia: … that to your point, has at least three, if not six underlying phenotypes that each of which, mechanistically would make a lot of sense for accelerating cancer.

Sid Mukherjee: This is an immunological phenomenon-

Peter Attia: The cytokines, the inflammatory, yeah, all these things.

Sid Mukherjee: Going back to your general point that obesity was becoming identified more and more clearly as one of the potential causes of cancer, or I should say, strongly correlated with the development of cancer so strongly, that we think that there’s a causal link based on everything that we know about epidemiology, some cancers, that we began to take this seriously, and we’re still taking it seriously. But, as you were pointing out, there are several horns underneath that blanket of obesity that we understand very crudely, and we have to figure out which of these is driving the cancer risk.

## The three laws of medicine — Law #1: A strong intuition is much more powerful than a weak test [26:30]

Peter Attia: I would like to spend the next six hours discussing with you the tenants of writing for selfish reasons, but instead, I’ll punt that to a … We’ll have dinner in a couple of weeks, and we’ll finish that discussion.

Peter Attia: I want to talk about another book you wrote that doesn’t get as much attention, which is *The Laws of Medicine*. You wrote that after *Emperor,* before *The Gene*, correct?

**Sid’s TED Book**: [The Laws of Medicine: Field Notes from an Uncertain Science (TED Books)](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [3:15, 26:30]

Sid Mukherjee: That’s right. So, *Laws of Medicine* has a very different mandate, as it were, and that’s because what came out in association with TED, that commissioned ten books by ten thinkers around the world, and they asked me to write a book on that. It’s necessarily a small book. It’s really a … The mandate was to write basically a 75-page book expanding on a single, very, very incisive idea, so that’s the *Laws of Medicine*, yes.

Peter Attia: If I got them correctly, the three laws are **a strong intuition is much more powerful than a weak test**.

Sid Mukherjee: Mm-hmm (affirmative).

Peter Attia: How did you think of that, and what is the most important application of that law to the way you think about medicine, or specifically, oncology today?

Sid Mukherjee: This, to me, is one of the great neglected ideas in medicine. Perhaps one of the great neglected ideas in the world. This idea initially comes from [Thomas Bayes](https://en.wikipedia.org/wiki/Thomas_Bayes). This is a Bayesian idea. Thomas Bayes was a cleric, but by evening, he was a mathematician and an economist. He let his work leads to one of the seminal and funny thought experiments that I’ve ever encountered, which is the following. I sometimes quiz my daughters with it. It’s just a following, this is not Thomas Bayes’s own example, but it arises out of Thomas Bayes’s work, and he … One might imagine going to a street fair and encountering a man who’s tossing coins. He tosses coins and your job is to predict whether the next coin flip is going to be heads or tails. So, he tosses the coin 20 times, and all 20 times it’s tails. So, then, he turns to the crowd and he says, “What’s the next coin flip going to be? Heads or tails?” Now, the mathematician in the crowd, who’s the professor of mathematics-

Peter Attia: Says, “50%.”

Sid Mukherjee: Says, “50%.” Everyone says, “Absolutely right.” But the child in the crowd says, “No, no. You don’t understand, this is a stupid problem. The coin’s rigged. The coin only has two heads,” or two tails as the case may be. The child’s right. What’s important about that insight, is that the mathematician imagines the world, in this case, this is not a stab at mathematicians in general, that the professor of mathematics thinks of the world as having no history, as having no *a priories*. It’s a world that’s created over every time. The coin is flipped and it’s heads and tails equal every time.

Sid Mukherjee: But, the child knows, and humans know, that in fact, the world doesn’t behave like that. Everything has priors, and you need to understand those priors before you can understand the posteriors. There’s wisdom in that idea. It took someone like Thomas Bayes to figure that out, that most of our lives, we aren’t living our lives like the crazy mathematician professor. We are living our lives like the child. We’re thinking to ourselves, “What was the prior antecedent?” Imagine this is true for any corner of your life. The first question you ask yourself when you’re trying to solve a problem, trying to understand the cosmos, trying to understand something, you ask yourself, “What was the prior like? Did the sun set in the West last night? And how about the night before? Maybe, I don’t need to create a formula to figure out whether the sun is gonna set on the West or the East tomorrow. It’s because it’s set in the West every time.” There are obviously loopholes and gaps to this kind of thinking, there are surprises that you can miss.

30:00

Sid Mukherjee: So, Bayes’s fundamental idea was that you can only interpret a test in the light of what that test has predicted in the past. It’s an extraordinarily important idea in the way we think about the universe. That the past performance of a test tells you something, not everything, but tells you something about the future performance of a test. You can apply it to many, many things in the world. You can apply it to any kind of thinking. Economic, economic thinking, climate change oriented thinking, that the past is a guide to the future, not only in a kind of loose way, but you’re really using a rheostat, weighted strongly by the past. This of course, applies to medicine. It’s a forgotten rule in medicine.

Peter Attia: Although, it does seem like one of the things that I’ve always felt physicians innately do well, without realizing it, which is the opposite of where I want to be. Not to take the potshots, but I think where we do very poorly is understanding asymmetric risk. So, Nassim Taleb has written a lot about asymmetric risk. I think he’s absolutely right to be critical of, not just physicians, but basically most people.

Peter Attia: So, my argument is we are innately wired to be Bayesian, we are absolutely not innately wired to appreciate risk.

Sid Mukherjee: Both of these are important.

Peter Attia: That’s right. So, one of them we have to hone so much more, because I think it just doesn’t come naturally.

Peter Attia: I played a funny experiment, which you’ll appreciate. I’ll send you the list and you’ll have a field day with it. It’s 20 questions, and each one is a quantitative question with an answer, but they’re not obvious. You would never … It’s not like, “How many presidents were there?” Or something where you might know the answer.

Peter Attia: You ask the group, “We’re gonna give you these 20 questions. I want you to answer each question, not with a number, but with a 95% confidence involved.”

Sid Mukherjee: I see.

Peter Attia: You know the game?

Sid Mukherjee: No, I don’t know the game. An interesting game.

Peter Attia: So, an interesting game. So, at the end of 20 questions, if you’ve done it correctly, you should have 19 out of 20 of those ranges correct. I’ve never met a person who could come close. You almost, without exception, get seven of the 20 right. You can’t even contemplate what that variability is.

## Law #2 of medicine: “Normals” teach us rules; “outliers” teach us laws [32:00]

Peter Attia: So, the second law was that **normals teach us rules, outliers teach us laws**.

Sid Mukherjee: So, this of course, these were very carefully … I thought I spent a lot of time thinking about them. Of course this is the anti-Bayesian law. This is exactly what you’re talking about. This is the idea that simultaneously in the medical brain has to live the idea that the Bayesian idea, that when you hear hooves think horses, not zebras, famous medical tenant. Hoofbeats outside your window are likely to be horses, they’re very unlikely to be zebras.

Sid Mukherjee: The second law is once and a while, they are zebras, and you need tools. You need special ideas, special tools to figure out what these outliers look like, who they are, how to find them, and how to quickly find them, so that you can identify them and triage them differently.

Sid Mukherjee: So, in some ways, these two laws are Yin-Yang. They polarize against each other. And what’s interesting about them is that they both, in medicine, can both be simultaneously true in the same way as our assumption of asymmetric risk is simultaneously true with the idea that our understanding of the base of a word, and the Bayesian way is helpful and important.

Sid Mukherjee: The second law is about how to identify outliers, how outliers tell us about the nature of normalcy, how they tell us about how complex interactions can produce occasional, far outsiders, and how those outsiders really challenge us to define what these interactions look like in real life.

Sid Mukherjee: A simple example is it’s very, very hard to figure out the genetics of any disease without finding the rare people who have the disease as a consequence of a mutation. A classic example, of course, is that we would not have an idea how to regulate our body, or to prevent heart attacks. If we hadn’t paid extraordinarily close attention to a small family, small groups of families that had a mutation in the gene that controls cholesterol metabolism. Most people don’t have this mutation because those families are quickly extinguished, we think, because they die of heart attacks. They have all sorts of problems, they die of heart attacks. But, by paying extreme attention to this one family that has a mutation, they’re rare, scientists all the sudden uncovered a whole cosmos in which we understand now, cholesterol metabolism, and because of that cholesterol metabolism, other scientists eventually developed the first statins.

Sid Mukherjee: So, all of this, the fact that hundreds of thousands of people in the world are taking this medicine to prevent heart attacks, tracks back to a rare family where, because of a genetic mutation they had, and very, very high risk of cardiac disease.

Peter Attia: And, of course, now, we know there’s a whole family of those people.

Sid Mukherjee: Yes.

Peter Attia: There’s at least 2,000 of those mutations that produce that phenotype and these natural experiments are actually a remarkable thing, and of course, bringing it back to the gene, to now have a tool, a probe, to be able to explore that is amazing.

## Law #3 of medicine: For every perfect medical experiment, there is a perfect human bias [35:00]

Peter Attia: The third law, **for every perfect or exceptional medical experiment, there’s a human bias that goes along with it**.

Sid Mukherjee: Again, these are unique to medicine. What’s interesting about them is that they are unique to me, at least it’s interesting, is that they’re unique to the day-to-day practice of medicine, but they apply for every … I think they apply to every corner of life.

Sid Mukherjee: You don’t have to be a doctor to realize that for every time we think of something, if you’re really skeptical thinkers, we have to think about the bias that comes intrinsically with that thought. In other words, every single declarative claim about the universe that we’re making must have necessarily a declarative bias that comes with it, they’re matched. If you want to be a scientist, you want to be a skeptic. Your real job, aside from being creative, and designing experiments, is defined for every single declarative claim that you’re making. The bias that’s derived by sitting like a little devil, buried inside that declarative thing. I promise you, everyone has one. Each one of these claims has one.

Peter Attia: Richard Feynman who, listeners of this podcast know is one of my heroes, one of my kids is named after him.

Sid Mukherjee: Is he named Feynman or Richard.

Peter Attia: His middle name is Feynman.

Sid Mukherjee: I see.

Peter Attia: Any my wife at first, was like, “Why would we do that?” But then, once she had read Surely, You’re Joking Mr. Feynman a couple of times, because she read it once before, she realized why. But, Feynman said, eloquently right, “The job in science is not to fool yourself, and you’re the easiest person to fool.”

Sid Mukherjee: That’s right.

Peter Attia: So, to your point, the only thing I would disagree with what you’ve said, Sid, is I don’t think these are unique to medicine. I think these are laws of science. Maybe laws of life, on some dimension.

Sid Mukherjee: So, the mandate here really was to use this book as a kind of springboard to challenge the way we think about virtually all aspects of how we live. You’re gonna read an article in the *New York Times* tomorrow that will make some claims about some politician somewhere in Oklahoma. Or you’re gonna read about an economic paper that is now being presented to the Feds, and your job is to be adequately skeptical about it, and understand, what are the priors? How do we explain this particular fact based on the priors? Do the priors matter?

Sid Mukherjee: To use a very topical example, does someone’s past behavior in college or in high school tell us about he or she is going to be a judicial candidate?

Peter Attia: Or does their behavior under scrutiny in any way predict their behavior when no one’s looking.

Sid Mukherjee: That’s right. That’s another question. The second question that you might ask here is, again, it’s an outlier question. Right? Scrutiny versus not scrutiny. Are they … Do they become outliers to themselves if they’re scrutinized, versus when they’re not scrutinized.

Sid Mukherjee: The third question is when I read this story, what are my biases? Am I reading it because I’m a man? Am I reading it because I have a particular experience in my lifetime, myself, my sister, my daughter, my friend, my colleague? Is that coloring the way that I read this particular story?

Sid Mukherjee: So, absolutely. This thinking goes on over and over again. These are circular processes. Do those biases have priors? Do the priors have biases? And so forth. So, you can use these … I mean I certainly use these tools in clinical practice.

Peter Attia: Yeah, it’s a beautiful … As you said, it’s a very short book, but again, we’ll certainly make sure people have this link to it. Because I think it’s a great way of teaching people how to think, and that’s, again, I just don’t think we’re innately wired for every facet of thinking.

## The excitement around immunotherapy [38:15]

Peter Attia: Now, going back to your background in immunology, very recently, we had a very exciting, for those of us in this space, very exciting Nobel Prize awarded. It was, as we were discussing before we started recording, it wasn’t so much around immunotherapy, but a very specific element of it, which are the development of check-point inhibitors. Two of them, in particular, were basically acknowledged here. The CTLA-4 which I mentioned earlier, and PD-1.

**James Allison’s Nobel Lecture**: [Immune Checkpoint Blockade in Cancer Therapy: New insights, opportunities, and prospects for cures](https://www.nobelprize.org/prizes/medicine/2018/allison/lecture/) | The Nobel Prize (nobelprize.org)

Peter Attia: Tell me why these are so exciting.

Sid Mukherjee: They’re exciting for many reasons. They are exciting for again, some history and some background, the story, as it were, is exciting because if you ask the question, in the 1990s, what’s the relationship between cancer and the immune system? You get a kind of diffused answer. You get an answer which could be very unclear, because there were all sorts of complicated lines of evidence.

Sid Mukherjee: One line of evidence was that in patients with a complete collapse of the immune system, such as patients with HIV, or a complete collapse of at least one wing of the immune system-

Peter Attia: They would get these cancers nobody else could get.

Sid Mukherjee: But, what’s interesting about them, and this is where the thought experience at least with the brain cells start ticking and ordering, they would typically get viro-cancers. Viruses that would now get unleashed, we now know many of them. Viruses like human papillomavirus, the would get cervical cancers, they would get anal cancers. So, a lot of viral cancer, but patients with HIV did not generally get lung cancer.

Peter Attia: I never even thought of that. So, we have enough data to know that they either at no greater prevalence, or even at a lower prevalence when you start to talk about, for example, lung cancer, or GBM, or pancreatic cancer, I never thought of that.

40:00

Sid Mukherjee: It’s very important. So the data are mixed, because, of course, in the 1980s they weren’t living long enough. So, all that we know is that the first groups of cancers that cropped up in these men and women were no lung cancers, they were not pancreatic cancer. So, at the first pass, with that cut-short data set, we might begin to imagine then if that’s the case, the immune system completely collapses. You only get a certain kind of cancer.

Sid Mukherjee: Then, what is the possible role of the immune system in cancer control? If you were a nihilist, you might have given up in the 1990s and said, “Well, you know, you take the whole immune system away, and nothing really happens.” Even with this cut-short data set, so maybe there isn’t such a complex interaction.

Sid Mukherjee: Well, it turns out that people like Jim Allison, and his Japanese colleague, did not put the immune system away. They put that data aside, said, “This goes back to Laws of Medicine.” Sure, it tells you a little bit, but it doesn’t tell you the full story.

Sid Mukherjee: The full story, turns out there’s one layer deeper. The full story turns out that in people who don’t have a collapse of the immune system, whose immune system is otherwise intact, cancer cells, not all cancers, but some cancers make specific factors. In fact they evolve, the word “make” is the wrong word here, they evolve, so that they put up specific factors, put up specific signals that inactivate the immune system, or that make the immune system no longer able to kill, or recognize the cancer cell.

Sid Mukherjee: The identification of these specific pathways, these specific factors was what led to the Nobel Prize because in further work, Jim Allison, and again his colleagues, this is a big, wide field, showed that if you inactivate these specific factors, if you drive nails through them using a variety of methods, then all of the sudden, the cancers become re-visible to the immune system, and the immune system can attack and kill the cancer cells.

Sid Mukherjee: Now, why is it exciting? It’s exciting for many reasons. First of all, it’s important to realize that not all cancers respond. We don’t know why some do and some don’t. Melanoma is highly responsive. It’s an immunologically engaged tumor. Is it because the melanoma has so many antigens that it will suddenly be more recognizable? Is it because the skin is such a lymphoid organ? Is it the right environment? We don’t know all of these questions.

Sid Mukherjee: The other thing to realize is that people have responses, and some people continue to respond, some other people, sadly, will relapse, and the cancers will start growing back in the context of their re-educated immune system.

Sid Mukherjee: That leads to the second question, which is what happens then? Is there a second pathway? This is an important idea, I think that goes back to your first question, which is about whether this is depressing or not.

Sid Mukherjee: The important thing is once you drive a single stake through cancer’s heart it’s like placing the first crampon on a climb. You see, if there’s no crampon that’s placed on the climb, you can’t climb a mountain. It seems like a wall, it’s a blank wall, and you don’t know whether to go left, or whether to go right, or what to do. Once you plant that first crampon-

Peter Attia: And it sticks.

Sid Mukherjee: … and it sticks, you all of the sudden, the whole face of the mountain becomes-

Peter Attia: It’s a different mountain now.

Sid Mukherjee: …it’s a different mountain now. Because, now you can ask the question, because the first crampon was planted in that particular place-

Peter Attia: And it stuck.

Sid Mukherjee: … and it stuck.

Peter Attia: I have a new vantage point-

Sid Mukherjee: Exactly.

Peter Attia: the perspective has changed.

Sid Mukherjee: That’s right. So, this is the important piece to realize about cancer research, and perhaps about all research, is that the first crampon, or the first stake through cancer’s heart, is an incredibly important stake, because then you can ask what I call linear questions. Before that first one is placed, the questions are non-linear. You don’t know where to place it. The whole map is open.

Sid Mukherjee: Once you drive a stake through the first question, the world becomes more linear. You can now ask the question, “What’s the mechanism of resistance to that?” When you find out, then what’s the mechanism of resistance to *that*, so, all of the sudden, the perspective is different because you’ve climbed through that first. That’s usually where the Nobel Prizes are given. The Nobel Prizes are given often for planting the first stake through the heart of the disease, through the heart of the problem and that’s why this Nobel Prize is important. It’s not, of course, as you’re saying, this does not encapsulate the field of tumor immunology in general. It’s a wide field. Our own lab does a whole bunch of work in tumor immunology but we’re on the shoulders of those prior giants as it were and so that’s the recognition that’s been given.

Peter Attia: You said something I think is so important and worth reiterating. There’s also something about immunology and immunotherapy that’s quite interesting as far as planting that stake, which is the durability of response. It is often the case that when you have an immunologic remission it is a durable remission but it’s not always the case but it is much more likely the case than when you say for example say a chemotherapeutic remission or even a surgical remission.

Peter Attia: On a personal level, I have a very close friend who was diagnosed with colon cancer 10 years ago at a very young age. He might have been 40 and that was unusual in and of itself. I remember talking, I went to the hospital when he had his colectomy, spoke with the surgeon after. It sounded like a horrible case, huge tumor, the mesentery was full of nodes, which I assumed would be positive. 26 nodes sampled, all came back negative.

Peter Attia: My friend was adopted. We later realized he had Lynch syndrome. Eight years later he goes on to develop pancreatic adenocarcinoma, unresectable, so it’s encased, the mesenteric vessels, he cannot have a Whipple procedure and as you know and unfortunately many people listen to this one though that is a death sentence. It’s a non-negotiable, you will not be alive in nine months. He was put on an anti-PD-1 therapy because he happened to have, as you would know, patients with Lynch are going to be much more likely to be susceptible to checkpoint inhibitors. Two years later, he’s disease-free.

Peter Attia: Just unbelievable stories and I think your point is an elegant one and I’d never really thought of before which is focused less on the fact that we haven’t solved the problem and more on the fact that we have made a finite and real step towards establishing a new place, a new location for which to view this disease.

## The story of Gleevec [46:00]

Sid Mukherjee: That’s right. I described this as taking a nonlinear problem into a linear problem. Now, of course, the answers and are often not linear per se but it gives you a route. We’ll come back to the metabolism study that we did with Lew Cantley. That is a great example of taking a nonlinear problem and converting to a linear problem. Now, I’ll tell you about that and in a second but any time, this was the case with Gleevec too.

Peter Attia: Let’s tell people what Gleevec is. Tell the story.

Sid Mukherjee: Gleevec is a good example of a drug where we learned to target a mutant cancer gene, and actually the gene product so, in that case, the cancer, it’s a blood cancer called chronic myelogenous leukemia was also a death sentence.

Peter Attia: Also GI stromal tumors.

Sid Mukherjee: GI stromal tumors. Yeah. Chronic myelogenous leukemia was a death sentence. People had to go through transplants. I’ve watched probably a dozen in the pre-Gleevec era a dozen patients die of chronic myelogenous leukemia or the complications of transplant. I trained briefly as a transplantor, and then, all of a sudden through the work of many people including Brian Druker, a drug was discovered.

Sid Mukherjee: Before that, scientists figured out based on very careful genetic analysis that the tumor was being driven by really the work of one gene and the gene was called BCR-ABL. It’s an oncogene. It’s not found in normal cells but found in these cancer cells and the product of that gene became like an engine, like a manic engine that was driving these blood cells to go crazy and make more blood cells and proliferate and proliferate and proliferate. It was this engine gone wild inside the cell, and every time the cell ask the question should I divide, rather than looking at its normal state or nutrients, metabolic state, et cetera, the only answer it would ever get was from this engine saying, yes, go ahead, make another cell, divide, et cetera, et cetera, et cetera.

Sid Mukherjee: This was identified but except the gene product was added by the protein product that the gene was identified, and then, through an elaborate series of experiments and circumstances, chemists found a way to actually jam the engine of one molecule, human beings and we stitched this molecule together. It’s a remarkable achievement. Once the engine is jammed, it suddenly turns out that the disease goes into remission.

Sid Mukherjee: This was one of the first examples of others of so-called targeted therapy where you take and you synthesize a chemical to jam cancer’s engines in a cancer-specific way that doesn’t affect normal cells. But what’s interesting about that is that some people develop resistance because the engine, cancer cells evolve and they find a way of resisting but that resistance it becomes a linear problem, you figure out what the mechanism of resistance is and you drive a second stake through cancer’s heart and when it becomes resistant to that, you drive a third stake and so forth.

Sid Mukherjee: All of a sudden the problem would seem like a big blank rock became a linear problem so that goes back to another example of how that first stake or the first crampon really helps with the problem. Now, for immunotherapy, immunological therapy, the roadmap is much clearer. Why do some tumors respond and why some don’t respond? Is it a question of the environment that the tumor is sitting in? Is it blood vessels? Is it the tumor cells? Is it immune cells?

Sid Mukherjee: These are answerable questions. These are so-called linear questions, but the first big step here was to define the problem.

## How does the body’s metabolic state affect cancer? [49:30]

Peter Attia: This is really a nice step up to exactly where I know we want to go, which is we’ve got surgical oncologists, medical oncologists, radiation oncologists in many ways a subset now of medical oncology is immuno-based oncology. The work that you Lew and many others are now doing is potentially another branch of oncology called metabolic oncology. You’re beyond gracious in your suggesting I have even something to do with helping that evening turn into, what sounds like a very productive collaboration between you and Lew, and I’ll be talking with Lew as well in the next month I’m sure but let’s talk a little bit about what came out of that collaboration and certainly bring it back to Ben Hopkins paper, was in *Nature* I believe.

50:00

Sid Mukherjee: Was in *Nature* two, three weeks ago.

**Sid and Lew Cantley’s important paper studying ketogenic diets in combination with PI3 kinase inhibitors**: [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.nature.com/articles/s41586-018-0343-4) (Hopkins et al., 2018) [2:00, 46:00, 49:45, 52:00]

Peter Attia: Yeah. Let’s talk a little bit about the question. What were you trying to understand?

Sid Mukherjee: The question is, there’s a very wide question, and then, there’s a very narrow question. The wide question is how does the body’s metabolic state affect cancer? It’s a very big question because cancers like all cells are eating nutrients as well in order to grow, and the question, therefore, is the cancer eating a different set of nutrients than normal cells?

**Sid’s recent article in the *New York Times Magazine* about the collaboration with Lew Cantley**: [It’s Time to Study Whether Eating Particular Diets Can Help Heal Us](https://www.nytimes.com/2018/12/05/magazine/its-time-to-study-whether-eating-particular-diets-can-help-heal-us.html) | Siddhartha Mukherjee (nytimes.com)

Sid Mukherjee: This work goes back to a famous work by Otto Warburg done in the early 1900s.

Peter Attia: 20s, yeah.

Sid Mukherjee: … where Otto Warburg was one of the first people to make the hypothesis that there’s something fundamentally different about … I mean, we won’t go into great details but fundamentally different in which the cancer cells metabolize compared to normal cells. They use fundamentally different pathways to metabolize and if you could find a way to target these metabolic alterations in cancer cells, you’d find an anti-cancer drug.

**The Warburg effect and the Warburg hypothesis**: [On the origin of cancer cells](https://www.ncbi.nlm.nih.gov/pubmed/13298683) (Warburg, 1956)

Sid Mukherjee: But that question has been hanging around our field for a long time and as our understanding of normal metabolism has changed, we’ve begun to identify not just one but dozens of nutrient pathways that cancers use that may or may not be different from normal cells, maybe slightly different from normal cells, maybe a lot different from normal cells. That’s one big question.

Sid Mukherjee: The second question, which is a slightly narrower question is that when you give a drug, whatever drug it might be, your favorite chemotherapy, your favorite drug, any drug, does it change the metabolism of the cancer cell and does it change the metabolism of the body and could this be a mechanism by which cancer cells become sensitive or resistance to chemotherapy?

Sid Mukherjee: These are two related questions. Again, to reiterate one question is how’s the cancer cells metabolism different from the normal cell in normal circumstances? The second question is how is a cancer cell’s metabolism differ from a normal cell in the context of human and drug?

## Can a nutritional state be exploited and/or a drug sensitivity be exploited through a nutritional intervention? [52:00]

Peter Attia: In other words, can a nutritional state be exploited and/or a drug sensitivity be exploited through a nutrition paradigm shift?

Sid Mukherjee: Exactly right. Those are the two questions. We focused in this particular study, but interested in both. I’m interested in both. But we focus on the second question and the second question in this particular case was that there was a very promising group of medicines that were being used in the clinic. In fact, I had used them as a triallist. They had come really out of Lew Cantley’s path defining work.

Sid Mukherjee: He had defined the pathway or the signals that these medicines attack and there was an enormous amount of optimism because this was considered a fundamental pathway.

Peter Attia: This is the beauty by the way of being in a place like New York or Boston. It’s you can talk about someone doing this … I mean, Lew was in Boston when much of this work is done. He’s now here in New York and you don’t have to collaborate with a guy across the world. You collaborate with the guys on the Upper East side instead of Chelsea.

Sid Mukherjee: That’s right. Lew’s work over the last decades had been to define this pathway and ultimately led to the formation or the creation of these new medicines. They’re called PI3-Kinase Inhibitors and they go by fancy names like Duvelisib and things like that but, anyway, when they came to clinic, surprisingly, there were some responses but there was a lot of resistance in patients, tumors were resistant to the drugs and didn’t respond.

Sid Mukherjee: That was a puzzle that Lew had come up in his own work, and then, separately, seven miles uptown, I was scratching my head about the same puzzle because I had been using these same drugs in cancer patients and finding that patients became resistant or were resistant to start, and so, what was struck out of that on a napkin that evening was, we had thought of lots of ways that these patients had, could become resistant. We had thought, “Oh, maybe the tumor had a mutation.”

Peter Attia: Well, and there’s one other point I guess to add just that we remember but maybe it’s worth reiterating is a lot of the patients that were on these began to develop phenotype. They look like they were diabetic.

Sid Mukherjee: That’s the point I was coming to in a second.

Peter Attia: We didn’t know if that meant that that was the source of the resistance-

Sid Mukherjee: That’s right.

Peter Attia: … was it true, true, and unrelated?

Sid Mukherjee: Yeah. The question was, was it true, true, and unrelated? I mean, you can think of many other mechanisms of resistance. You can say the tumors became or a mutation, you could say the host had some problem, you could write down on a piece of paper a thousand ways. Those were the traditional ways that one would explain resistance. The traditional ways of thinking about tumor resistance is mutation.

Sid Mukherjee: The host eats up the drug. The non-traditional way and this is what the innovation in the study was that what if this diabetes that we were observing, the high levels of sugar and the high levels of insulin, insulin being the most important piece of this. What if the drug was causing diabetes separately from the tumor, given to normal people that the drug would cause diabetes, in some people worse than others, and that diabetic phenotype, the diabetic state, the hyperinsulinemic state was being used or exploited by the tumor to essentially become resistant to the drug?

Sid Mukherjee: It’s a little bit like in the analogy that I drew I remember on the napkin-

Peter Attia: It’s funny, I still remember the table we sat.

Sid Mukherjee: I remember the table.

Peter Attia: Isn’t that funny?

Sid Mukherjee: Yeah. Exactly right. The drawing, so Lew and I, we’re betting this idea back and forth while you were eating nothing, and the idea was that to me, it reminded me of the famous story of the woodcutter who’s sitting on a tree limb and chops of his own limb and falls down, and I drew this picture, I remember of the woodcutter on a tree limb because what happens is that the body mounts an insulinemic response to the drug.

Sid Mukherjee: That insulinemic response goes to the cancer and starts feeding the cancer, and then, the cancer becomes resistant so you essentially undo all the good that you’ve done with the drug by cutting off your own limb because of this intrinsic circuit. The long and short of it is that that’s basically in animal models that happens to be true, so we showed it using a formal system and formal methods that this insulinemia is a consequence of the drug, it has nothing to do with the tumor, it has nothing to do with anything else.

Sid Mukherjee: If you give the drug, the drug goes into the liver and the pancreas and causes sort of a pre-diabetic state that’s often worse than if you’re already in a pre-diabetic state. This hyperinsulinemia is used then by the tumor to become resistant even while the drug is present. It becomes a pathway by which the tumor becomes resistant and most interestingly, that you can paralyze this resistance by putting animals on a ketogenic diet.

Sid Mukherjee: Basically, there’s never any sugar source to drive the incident. You blunt the incident response so acutely that you can no longer get the insulin hike, and this is not to be confused with the idea that this is a sugar-feeding tumor idea. This is not a sugar-feeding tumor paradigm.

Peter Attia: Because to be clear, on a ketogenic diet, your glucose levels might go down from normal but it’s not an enormous reduction even in a complete fast, you’ll still maintain at least 3 mmol of glucose. It’s the insulin that becomes virtually unmeasurable.

Sid Mukherjee: That’s right, and so, this is an insulin feeding the tumor question, and so, I think the three points that need to be made about the study to be very clear, first of all, it’s an animal study. We’re now launching a human study that we’ll launch in November with patients with lymphomas, endometrial cancer, and breast cancer particularly triple negative breast cancer, I’m very keen on studying.

**Sid’s human study**: [Top oncologist to study effect of diet on cancer drugs](https://www.theguardian.com/science/2018/jul/06/top-oncologist-to-study-effect-of-diet-on-cancer-drugs) | The Guardian ([theguardian.com](https://www.theguardian.com/us)) [56:45]

Peter Attia: Because these are the sort of cancers that have so few options?

Sid Mukherjee: That’s right. There are very, very few options so that’s the human study. The second point that is worthwhile making is that, it’s sort of like folks don’t try this at home. This is a very particular study with a very particular drug on cancers combined with the diet. The study only worked when the drug and the diet were combined. It does not mean that the ketogenic diet is going to prevent cancer. We don’t know this. It’s an open question. We’re actually studying that separately.

Peter Attia: Yeah and I want to talk just a little bit about the paper because that’s, boy, I sure want everyone to make sure they hear that loud and clear because few things upset me more than, when I spent a little too much time on Twitter and I come across people who seem to want to claim that if you’re on a ketogenic diet you can’t get cancer or if you have cancer just go on a ketogenic diet, you’re going to be fine.

Sid Mukherjee: [inaudible] in fact, to be very clear-

Peter Attia: Well, the study, in fact, demonstrated that that was not the case.

Sid Mukherjee: Not only that, the study also demonstrates that some cancer models, including leukemia, is accelerated on the keto diet. In fact, we have a big follow-up study to try to figure out why some cancers are accelerated by keto alone but when you combine it with the drug it actually goes back down to a deep remission.

Sid Mukherjee: The third point to make is that it seems to be mutation agnostic and that by that I mean this is a very important idea, which is that 12 tumor models responded, 12.

Peter Attia: I was not aware that it was that high.

Sid Mukherjee: Yeah, 12, and actually all 12 that we tested responded. Every one of them responded, and it didn’t matter what oncogenes you had or what tumor suppressor genes were mutated, they all responded to different levels. Leukemia is responding they become, then they relapse, at least, in the models. Endometrial cancers, we can’t get them to grow. Pancreatic cancers respond extremely strongly, so it’s another example where you’re not targeting it seems the mutation.

Sid Mukherjee: This is not like Gleevec, in which you’re driving a stake into the engine of the cancer, or that engine.

Peter Attia: This is a much more global assault.

Sid Mukherjee: Yeah. It’s a much more global assault. In fact, in some ways, it’s parallel or akin to this immunotherapy, in the sense that the immune system doesn’t care if you have RAS, it doesn’t seem to care at the first approximation whether you have a mutation in one gene or another gene, RAS or not RAS, it will kill the tumor cells based on its characteristics of what it sees in the tumor.

Sid Mukherjee: Similarly, here, the metabolism seems to be tumor wide but not single kinds of cancer-specific. We don’t know this to be the case. The 13th model that we tried will, maybe this is the one that won’t work but this has generated a lot of excitement for this reason.

Peter Attia: I have a friend who has definitely HER2 new positive, maybe ER positive, PR negative but has Stage-4 breast cancer, is in a PI3K inhibitor trial out of Dana-Farber has been on the trial for probably five years. She’s the only survivor. Here’s the interesting thing. She’s been on a ketogenic, low carbohydrate diet the entire time.

Sid Mukherjee: While she was taking inhibitor?

Peter Attia: Yes.

Sid Mukherjee: Okay.

Peter Attia: She’s still on the inhibitor.

Sid Mukherjee: Encouraging story.

Peter Attia: What’s interesting is I’ve told Lew about her case because she’s fastidious in this and she’s able to get her hemoglobin A1C now under six, which for many of those patients is very difficult-

Sid Mukherjee: Very hard to do, yeah.

1:00:00

Peter Attia: When you, me and Sid had lunch once about two years ago, this was the very first time you ever showed me the data.

Sid Mukherjee: Yeah. That’s right. We brought a computer.

Peter Attia: We were at that Indian place or the Chinese place on Second Avenue.

Sid Mukherjee: That’s right.

Peter Attia: When you showed me those data, I just immediately thought of her. It’s actually been on my list to introduce Lew because she doesn’t live in New York but-

Sid Mukherjee: No. I would love to meet her-

Peter Attia: … I want to bring her out and I want you guys to meet her because the combination of this PI3K inhibitor and this dietary choice she has made, going back to your second rule, right? She’s the outlier-

Sid Mukherjee: That’s right.

Peter Attia: … that is giving you something to probe.

Sid Mukherjee: Yeah. We hopefully will have many such patients. I don’t know. This is why we’re running the study.

## How does Sid balance his family, writing, research, laboratory, and patients? [1:00:30]

Peter Attia: Sid, as you can probably imagine, I could spend another 12 hours speaking with you but I want to be respectful of your time. I know we’re a little late in the day. We got a later start than we wanted and you’ve got a long trip home and I want you to get to see your family. The last question I want to ask you really is one that I need you to be a little bit immodest with, which is how you do what you do?

Peter Attia: I don’t meet a lot of people that I look at and realize that on every level of their life, they are better than me. Usually, I meet people and it’s like, “Yeah, they’re better at me at those three things but I can do this one thing better.” I’m sure I can think of something I do better than you but it’s-

Peter Attia: I can probably shoot a bow and arrow better than you but when I think about how you balance the devotion you have to your patients, to your family, to your research, to your writing, it humbles me. I don’t know, have you put any thought into that? The fact that you’ve created these tenets around writing is very interesting to me. It says that you weren’t just a natural gifted guy that fell out of the sky who figured out how to write.

Peter Attia: You had to work at your craft. How do you work at this craft of just excellence in general?

Sid Mukherjee: The simple rules that I have is I’m very question and project driven person. If I set projects, I usually fulfill them. Again, it’s the same set of cramp-on in the mountains rule, which is that in order to write a book, you have to write the first line of the book, and inevitably that’s not going to be the first line that survives. In order to do research, you have to do one experiment and inevitably that experiment is not going to work out. You’re going to 10, 15 iterations of it, et cetera.

Sid Mukherjee: To me, the fundamental rule that works for me is just to throw something at the world. The first line, the first experiment, the first idea, and then, keep at it. I keep at it over and over again. I come back to it. I come back to it over and over again and I keep asking questions. Then, at some point of time, and that’s another moment of sensitivity is to figure out when the work speaks back to you, the experiment starts talking back to you. You have to be really open. Your ears have to be really open and that’s really the skill of a scientist I think.

Sid Mukherjee: The scientist I think has or even a writer, they have really two skills that they mixed together. The first one is the creative step. Putting out the first line, thinking of the idea. I’m going to write a biography of cancer. I’m going to write the history of genetics, et cetera, but the second one is to be open enough to realize when the work starts speaking back to you and let that happen. Let the experiment start talking back to you, be skeptical, have a conversation with it.

Sid Mukherjee: Those I think are the two skills that I bring to my puzzle. The rest of it is just like everyone else trying to balance eating a meal versus writing two more lines, stopping, starting, sleeping, the usual.

Peter Attia: Well, Sid, I don’t expect this will be the last time we sit down and do this-

Sid Mukherjee: I hope not.

Peter Attia: … there’s going to be a lot more stuff to talk about. I can’t thank you enough. I consider you, Lew, I mean some of the other folks we talk about real mentors of mine and it’s a privilege. It’s a real privilege to call you a friend and to be able to sit down with you and just get the tiniest insight into your work.

Sid Mukherjee: Yeah. Pleasure.

§

§

## Selected Links / Related Material

**Sid and Lew Cantley’s important paper studying ketogenic diets in combination with PI3 kinase inhibitors**: [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.nature.com/articles/s41586-018-0343-4) (Hopkins et al., 2018) [2:00, 46:00, 49:45, 52:00]

**Here is a good article about the study**: [Low-Carb, High-Fat Diet May Boost Targeted Cancer Therapy](https://news.weill.cornell.edu/news/2018/07/low-carb-high-fat-diet-may-boost-targeted-cancer-therapy) | Weill Cornell (weill.cornell.edu)

**Sid’s most recent book**: [The Gene: An Intimate History](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1432837818) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [2:40, 7:30]

**Sid’s TED Book which Peter says is a “great way of teaching people how to think”**: [The Laws of Medicine: Field Notes from an Uncertain Science (TED Books)](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [3:15, 26:30]

**Sid’s lab**: [Mukherhee Lab](https://mukherjeelab.com/) | ([mukherjeelab.com](https://mukherjeelab.com/)) [6:00]

**Sid’s recent article in the *New York Times Magazine* about the collaboration with Lew Cantley**: [It’s Time to Study Whether Eating Particular Diets Can Help Heal Us](https://www.nytimes.com/2018/12/05/magazine/its-time-to-study-whether-eating-particular-diets-can-help-heal-us.html) | Siddhartha Mukherjee (nytimes.com)

**Sid’s Pulitzer Prize Winning book on the history of cancer**: [The Emperor of All Maladies: A Biography of Cancer](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916) by Siddhartha Mukherjee | ([amazon.com](https://www.amazon.com/)) [7:30]

**Sid wins a Pulitzer prize**:: [The Emperor of All Maladies: A Biography of Cancer, by Siddhartha Mukherjee (Scribner)](https://www.pulitzer.org/winners/siddhartha-mukherjee) | ([pulitzer.org](https://www.pulitzer.org/)) [7:30]

**PBS special by Ken Burns on The Emperor of All Maladies**: [Cancer: The Emperor of All Maladies](https://www.pbs.org/show/story-cancer-emperor-all-maladies/) | ([pbs.org](https://www.pbs.org/)) [19:00, 21:15]

**Late 19th century cancer treatment**: [Coley’s toxins](https://en.wikipedia.org/wiki/Coley%27s_toxins) | ([wikipedia.org](https://www.wikipedia.org/)) [20:00]

**Peter’s paper on CTLA-4**: [Autoimmunity correlates with tumor regression in patients with metastatic melanoma treated with anti-cytotoxic T-lymphocyte antigen-4](https://www.ncbi.nlm.nih.gov/pubmed/16087944) (Attia et al., 2005) [20:30]

**PBS is making a special on Sid’s latest book, The Gene**: [PBS Announces KEN BURNS PRESENTS THE GENE: AN INTIMATE HISTORY, New Collaboration with Siddhartha Mukherjee, M.D. Three-Hour Documentary to Premiere Spring 2020 on PBS](https://www.pbs.org/about/blogs/news/pbs-announces-ken-burns-presents-the-gene-an-intimate-history/) | ([pbs.org](https://www.pbs.org/)) [21:15]

**Peter’s favorite book by Richard Feynman**: [“Surely You’re Joking, Mr. Feynman!”: Adventures of a Curious Character](https://www.amazon.com/Surely-Youre-Joking-Mr-Feynman/dp/0393355624/ref=mt_paperback?_encoding=UTF8&me=&qid=) by Richard P. Feynman | ([amazon.com](https://www.amazon.com/)) [36:00]

**Nobel Prize to James Allison for the discovery of cancer therapy by inhibition of negative immune regulation**: [The Nobel Prize in Physiology or Medicine 2018](https://www.nobelprize.org/prizes/medicine/2018/allison/facts/) | ([nobelprize.org](https://www.nobelprize.org/)) [38:15]

**Gleevec, a drug that targets mutant cancer genes such as chronic myeloid leukemia**: [Imatinib](https://en.wikipedia.org/wiki/Imatinib) | ([wikipedia.org](https://www.wikipedia.org/)) [46:15, 58:00]

**Other episodes of [The Drive](https://peterattiamd.com/podcast/) that mention Otto Warburg**:

- [Navdeep Chandel, Ph.D.: metabolism, mitochondria, and metformin in health and disease (EP.31)](https://peterattiamd.com/navchandel/)
- [Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease? (EP.30)](https://peterattiamd.com/tomseyfried/)
- [Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer (EP.05)](https://peterattiamd.com/domdagostino/)

**Sid’s human study**: [Top oncologist to study effect of diet on cancer drugs](https://www.theguardian.com/science/2018/jul/06/top-oncologist-to-study-effect-of-diet-on-cancer-drugs) | The Guardian ([theguardian.com](https://www.theguardian.com/us)) [56:45]

§

§

## People Mentioned

- [Lewis Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (introduced Peter and Sid, collaborated with Sid on metabolism study, working on metabolic oncology) [1:40, 6:00, 46:00, 49:15, 52:15, 59:45]
- [Bob Kaplan](https://twitter.com/bobkaplan) (show notes contributor) [4:00]
- [Travis Denson](https://twitter.com/tden185) (show notes contributor) [4:00]
- [Rudy Leibel](https://www.ihn.cumc.columbia.edu/profile/rudolph-l-leibel-md) (mutual friend of Sid and Peter, genetics expert) [5:00]
- [Bernard Fisher](https://en.wikipedia.org/wiki/Bernard_Fisher_(scientist)) (pioneer in breast cancer treatment) [7:45]
- [Stephen Jay Gould](https://en.wikipedia.org/wiki/Stephen_Jay_Gould) (writes as a process of thinking) [12:30]
- [Charles Darwin](https://en.wikipedia.org/wiki/Charles_Darwin) (writes as a process of thinking) [12:30]
- [Oliver Sacks](https://en.wikipedia.org/wiki/Oliver_Sacks) (writes as a process of thinking) [12:30]
- [Atul Gawande](https://twitter.com/Atul_Gawande?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (writes as a process of thinking) [12:30]
- [Bob Weinberg](https://en.wikipedia.org/wiki/Robert_Weinberg) (oncogenes, “idea of sprinkling tens of thousands of genes onto pieces of genetic material onto cells like a snowstorm of genes”) [14:45]
- [Ken Burns](https://en.wikipedia.org/wiki/Ken_Burns) (PBS special called [Cancer: The Emperor of All Maladies](https://www.pbs.org/show/story-cancer-emperor-all-maladies/)) [19:00, 21:15]
- [James Allison](https://en.wikipedia.org/wiki/James_P._Allison) ([2018 Nobel Prize](https://www.nobelprize.org/prizes/medicine/2018/allison/facts/) for the discovery of cancer therapy by inhibition of negative immune regulation) [21:00, 40:30]
- [Thomas Bayes](https://en.wikipedia.org/wiki/Thomas_Bayes) (worked shaped Sid’s first law of medicine “strong intuition is more powerful than a weak test”) [27:30]
- [Nassim Taleb](https://twitter.com/nntaleb?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (asymmetric risk) [30:30]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (“The first principle is that you must not fool yourself — and you are the easiest person to fool”) [35:45]
- [Tasuku Honjo](https://en.wikipedia.org/wiki/Tasuku_Honjo) (shared 2018 Nobel Prize with James Allison for cancer immunotherapy discoveries) [40:30]
- [Brian Druker](https://en.wikipedia.org/wiki/Brian_Druker) (helped develop Gleevec for treating chronic myeloid leukemia) [47:00]
- [Benjamin D. Hopkins](https://vivo.med.cornell.edu/display/cwid-beh2020) (Lead author on the Nature [paper](https://www.nature.com/articles/s41586-018-0343-4)) [49:45]
- [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) (cancer metabolism) [50:15]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/12/SiddharthaMukherjee-e1544211605504-300x300.jpeg)

##### Siddhartha Mukherjee, M.D., Ph.D.

Siddhartha Mukherjee is the author of [*The Emperor of All Maladies: A Biography of Cancer*](https://siddharthamukherjee.com/the-emperor-of-all-maladies), winner of the 2011 Pulitzer Prize in general nonfiction, and [*The Laws of Medicine*](https://siddharthamukherjee.com/the-laws-of-medecine). He is the editor of Best Science Writing 2013.

Siddhartha Mukherjee’s [*THE GENE: An Intimate History*](https://siddharthamukherjee.com/the-gene-an-intimate-history) is his latest work – the story of the quest to decipher the master-code of instructions that makes and defines humans, that governs our form, function, and fate and determines the future of our children.

Mukherjee is an assistant professor of medicine at Columbia University and a [cancer physician and researcher](https://mukherjeelab.com/). A Rhodes scholar, he graduated from Stanford University, University of Oxford, and Harvard Medical School. He has published articles in Nature, The New England Journal of Medicine, The New York Times, and Cell. He lives in New York with his wife and daughters.

Sid on Twitter: [@DrSidMukherjee](https://twitter.com/DrSidMukherjee)