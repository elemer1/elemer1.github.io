# #152 – Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization (DNS)

**Source:** [https://peterattiamd.com/michaelrintala/](https://peterattiamd.com/michaelrintala/)

---

Michael Rintala is a sports medicine chiropractor and one of only 18 international instructors teaching dynamic neuromuscular stabilization (DNS) for the Prague School of Rehabilitation. This episode focuses on understanding DNS, including the foundational principles and how it relates to human motor development. Michael also shares the most common injuries and issues he sees in patients in his practice, such as postural problems and back pain, and how the movements of a DNS program are used to avoid injury, maintain longevity, and improve sports performance.

**Note:** In addition to the extensive show notes, for this episode [*Drive* members](https://peterattiamd.com/subscribe/) also get a collection of **8 instructive exercise videos**. If you’re a subscriber, you can now view these videos at the bottom of this page (make sure you are logged in). If you are not a member, you can [learn more about the member benefits here](https://peterattiamd.com/subscribe/).

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/michaelrintala/the_Drive_public.png)

Play

#152 - Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization (DNS)

#152 - Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization (DNS)

1x15s30s

0:001:35:34

## We discuss:

- Michael’s background in chiropractic sports medicine and rehabilitation (3:15);
- The Prague School of Rehabilitation, and functional rehabilitation as the foundation of the dynamic neuromuscular stabilization (DNS) program (5:00);
- Foundational principles of DNS, and the role of the diaphragm in muscular stability (19:00);
- Types of muscle contractions (28:15);
- Human motor development through the lens of DNS, and when issues begin to arise (32:30);
- Common postural syndromes (50:00);
- Increasing functional threshold to minimize time in the functional gap (56:45);
- DNS for injuries, pain, pre-habilitation, and performance enhancement (1:03:45);
- Etiology of back pain (1:10:00);
- How a stress fracture in his back led Michael to the Prague School (1:16:00);
- The Prague School curriculum: 3 tracks for certification in DNS (1:20:45); and
- More.

§

## Show Notes

## Michael’s background in chiropractic sports medicine and rehabilitation [3:15]

- Grew up in Northern CA
- Went to UC San Diego
- Played multiple sports but was particularly interested in tennis
  - Played lots of junior tennis tournaments
  - Also played in college
- Today he is a chiropractor based in San Diego
  - Specializes in rehabilitation sports medicine
  - Part of sports medicine team for PGA Tour and the World Surf League Tour
  - On USA Surfing Performance Committee

## The Prague School of Rehabilitation, and functional rehabilitation as the foundation of the dynamic neuromuscular stabilization (DNS) program [5:00]

- Peter practices dynamic neuromuscular stabilization (DNS) and works with Michael, [Beth Lewis](https://bodyevolvednyc.com/us/), and [Michael Stromsness](https://www.instagram.com/enlightened_savage_101/)
- [Prague School of Rehabilitation](https://www.rehabps.com/REHABILITATION/Home.html) founded in 1950s at Charles University in Prague in the Czech Republic (formerly Czechoslovakia)
- DNS is based on **functional rehabilitation**
- [Pavel Kolář](https://www.rehabps.com/REHABILITATION/Kolar.html) currently runs the rehabilitation department at Prague School
- Behind the Iron Curtain during Cold War, doctors tended towards observation and palpation for diagnosis and treatment
- DNS was pioneered by three Prague School neurologists, [Vladimir Janda](https://pubmed.ncbi.nlm.nih.gov/16641785/), [Karel Lewit](https://www.rehabps.com/REHABILITATION/LEWIT.html), and [Václav Vojta](https://en.wikipedia.org/wiki/V%c3%a1clav_Vojta)

**Postural habituation**

- Prague’s Vladimir Janda described postural habituation, when a specific musculature tends towards tightness while other musculature tends towards weakness
- **Upper cross syndrome**: neck and shoulder region

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-1-rintala-1024x663.png)

**Figure 1. Upper cross syndrome.** Image credit: [Rise Beyond Fitness](https://www.risebeyondfitness.com/single-post/2016/04/27/walking-tall-correcting-upper-extremity-impairment-syndrome)

- When spend a lot of time sitting, the neck muscles would tend towards a tightening / over-activation / hypertonicity
- occipital muscles, the sternocleidomastoid (also attaches to the skull and down to the sternoclavicular joint), the pectoralis, the upper trapezius

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-2-rintala-1024x474.png)

**Figure 2. Muscles of the neck.** Image credits: [Britannica](https://www.britannica.com/science/human-muscle-system) (front), [Anatomy, Head and Neck, Posterior Cervical Region](https://www.ncbi.nlm.nih.gov/books/NBK551521/) (back)

- Other musculature in the upper extremity would tend towards under-utilization and weakness
- Serratus (attaches to the ribs and the back of the scapula), the deep neck flexors, the middle and lower trapezius muscles

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-3-rintala-1024x467.png)

**Figure 3. Muscles of the upper extremity.** Image credit: [Lumen Learning](https://courses.lumenlearning.com/suny-ap1/chapter/muscles-of-the-pectoral-girdle-and-upper-limbs/)

- Janda recognized that that this would affect the quality of movement throughout the [kinematic chain](https://physio-pedia.com/Kinetic_Chain)
  - would lead to overload in specific areas of the chain
  - big contribution on his part
- See a tendency to overload in the transitional areas throughout the spine and throughout the extremity

- **Lower cross syndrome**: lower back and hip region

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-4-rintala-1024x828.png)

**Figure 4. Lower cross syndrome.** Image credit: [Parisa Ricciardelli](https://www.linkedin.com/in/dr-parisa-ricciardelli-540040122/)

- tendency for the hip flexor complex to be overactive and tightened: the iliopsoas, rectus femoris, the back extensor musculature also tight
- lower abdominal region and the gluteal region would be weak / inhibited

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-5-rintala-1024x485.png)

**Figure 5. Hip and upper leg muscles.** Image credit: [Hip Pain professionals](https://hippainhelp.com/hip-flexor-pain-and-iliopsoas-pain-hip-and-or-groin-pain/)

- So get overload in the hip joint, the knee joint, and certain spinal regions where you see the transition of the curvatures, lordosis and kyphosis (thoracic lumbar region, cervical thoracic region, etc.)
- The overload causes repetitive stresses on the passive structures within the kinematic chain
- If you image the spine can see degenerative changes or the most disc pathology in these areas
- Changes are aren’t usually traumatic or acute; accumulated over time
- Janda developed specific treatments involving both exercise and manual maneuvers

**Prague school doctors**

- Janda had post-polio type syndrome, which was likely a motivation for his passion for observing movement and rehabilitation
- Karel Lewit
  - specifically focused on joint and soft tissue dysfunction in relation to upper and lower cross syndromes
  - developed specific mobilization techniques for both the joint and the soft tissues
- Pediatric neurologist Vaclav Vojta
  - Observed the development of motor function after birth during the first 12 months when the postural foundations are established neurologically
  - Developed postural reactions test to determine the quality and maturation of the central nervous system
    - developed seven specific postural reaction tests
    - developed and modified some other ones
    - utilized primitive reflexes
    - assessed maturation of the central nervous system as compared to the chronological age
  - Focus was on treatment of cerebral palsy
    - do assessment of primitive reflexes to recognize issues before they would manifest clinically
    - interventions could be performed early enough to take advantage of the neuroplasticity
    - brain’s ability to “work around” central lesions seen in CP
- These 3 were founders of Prague School of Rehabilitation
  - Colleagues, mentors, instructors of Pavel Kolář
  - Kolář developed all of this knowledge and experience into what we call dynamic neuromuscular stabilization today
  - In the early 90s, Prague School focus was primarily on rehabilitation for cerebral palsy and the general population
- Pavel Kolář
  - Head of the Prague School of Rehabilitation
  - Head clinician for the Czech Olympic Teams and Czech National Sports Teams (hockey, soccer, men’s and women’s tennis)
  - He himself was a high-level Olympic level gymnast
  - Also a pediatric physiotherapist
  - Idea is that the central nervous system is key to facilitating the efficiency of transfer of load throughout that kinematic chain
    - Started to apply that base of knowledge to injured athletes around late 90s /early 2000s
      - [Jan Železný](https://en.wikipedia.org/wiki/Jan_%C5%BDelezn%C3%BD): Olympic javelin thrower, three-time gold medal winner, Rintala thinks he still holds the record for javelin 98.48 meters
      - [Jaromír Jágr](https://en.wikipedia.org/wiki/Jarom%C3%ADr_J%C3%A1gr): Czech hockey player
    - Pavel helped rehabilitate them from injuries
  - Integrated the concepts and principles of dynamic neuromuscular stabilization to
    - 1) decrease the risk of reinjury
    - 2) provide the potential for better performance

## Foundational principles of DNS, and the role of the diaphragm in muscular stability [19:00]

**DNS definitions:**

- **Dynamic**: movement
- **Neuromuscular**
  - connection between the nervous system (primarily central) and the muscular system
  - Many assume that acts of strength are purely muscular and they don’t realize the neurologic component
- **Stabilization**
  - Using developmental kinesiology as a way to explain posture and dynamic stabilization
    - Newborns are functionally and structurally immature; central nervous system still maturing
    - Bones are still forming
    - For the first 4-6 weeks of life the primitive reflexes (lower CNS at brainstem level) are dominant: suck reflex, gag reflex, grasping reflex, blink reflex
  - At about 8 weeks old, synergy, coordination, and timing of the deep stabilizing group of musculature (the diaphragm, pelvic floor, the entire abdominal wall, and the inner segmental spinal musculature that runs throughout the entire spine) begins

**Muscular stability and the diaphragm:**

*The* [*diaphragm*](https://en.wikipedia.org/wiki/Thoracic_diaphragm)

- a dome-shaped striated muscle with a non-muscular component
- a sheath that separates the abdominal cavity from the heart and lungs
- Has attachments (where muscles attach an anchor) on the lower six ribs on the back of the xiphoid process (bone at the end of the sternum) and on the L1, L2 vertebra

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-6-rintala-1024x686.png)

**Figure 6. Attachments of the diaphragm.** Image credit: [Doctor Lib](https://doctorlib.info/anatomy/yoga-anatomy/2.html)

- Also a central tendon
- One of the primary functions is respiration
  - When you take a breath in, the diaphragm descends, the central tendon drops, and the lungs are able to expand due to the change in pressure
  - When breathe out, diaphragm recoils

*Foundations of muscular stability*

- Ontogenesis: the study of motor development after birth
  - CNS has not matured enough to create a fixed point through the trunk and the pelvis
  - Around 3 months, hard-wired, genetically-ingrained motor functions kick in and start to see this coordinated activity of that deep group of muscles
- Peter suggests thinking of the diaphragm like a cylinder
  - The strongest cylinder would have a big top, a big bottom, and symmetrical sides
  - The diaphragm is like the top of that cylinder
  - The bottom of the cylinder is the pelvic floor, whose musculature will coordinate the regulation of intra-abdominal pressure that is created with the descending of the diaphragm
- Besides respiration, the diaphragm has a postural function
  - creates intra-abdominal pressure and the pelvic floor is active and stretches ([eccentric loading](https://courses.lumenlearning.com/fitness/chapter/types-of-muscle-contractions-isotonic-and-isometric/#:~:text=Eccentric%20contractions%20cause%20muscles%20to,the%20length%20of%20the%20muscle.))
  - Like wind blowing into a sail: wind makes sail open and then maintains pressure
- Abdominal wall musculature:
  - rectus abdominis (six-pack muscles)
  - oblique musculature that crosses the body, comes up and attaches to the rib cage
  - Transverse abdominis: wraps around from the back

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-7-rintala-1024x802.png)

**Figure 7. Abdominal wall musculature.** Image credit: Christy Krames for the [American Academy of Family Physicians](https://www.aafp.org/afp/2018/1001/p429.html)

- Diaphragm descends
  - performs a stabilization function, creates intra-abdominal pressure that musculature reacts to
  - Eccentric contraction followed by an [isometric contraction](https://courses.lumenlearning.com/fitness/chapter/types-of-muscle-contractions-isotonic-and-isometric/#:~:text=Eccentric%20contractions%20cause%20muscles%20to,the%20length%20of%20the%20muscle.)
- But body must coordinate between the respiratory and postural functions
  - CNS needs to generate enough pressure to maintain stability but also allow the diaphragm to descend enough for lungs to expand
  - If this coordination is not working well, see overutilization / lower crossed syndrome and lose deep stabilization
  - Brain uses compensatory pattern to maintain stability
- Around 3 months, infant will develop synergy coordination to create a fixed point through the trunk and the pelvis
  - As maintain intra-abdominal pressure, a loading on the front of the spine and uprighting effect throughout the spine
  - Inner segmental spinal musculature is eccentrically loading and managing that pressure against the spine

## Types of muscle contractions [28:15]

- **Concentrically** loaded: when a muscle getting shorter as it’s being loaded
- **Eccentrically** loaded: when a muscle is getting longer as it’s being loaded
- For example, a bicep curl – see the figure below:

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-8-rintala-713x1024.png)

**Figure 8. Isometric, concentric, and eccentric muscle contractions.** Image credit: [vickphysiotherapy.com](https://vickphysiotherapy.com/2018/11/06/isometric-concentric-and-eccentric-muscle-contractions-whats-the-difference/)

- When training, most people tend to emphasize the concentric and don’t realize the eccentric
- Peter heard a story from Michael Stromsness (or maybe Rintala himself) that Americans and Eastern Europeans were counting reps differently
  - American: a rep one is up and down (putting all their effort into the concentric, not really focusing on the effort to put the weight down)
  - Eastern European: up one, down two, so it was just as much effort into that eccentric
  - It’s not to say one is right or wrong because they serve different purposes
- Too much emphasis on the eccentric will create more hypertrophy
- But with, for example, hip abduction, eccentric control is a very important part of injury prevention
- What these pioneers (Vojta, Janda, Lewit, Kolář) noticed was the importance of training that central nervous system to optimize stabilization, stereotype, and synergy
- Then get what Kolář calls centration throughout that chain of movement / kinematic chain
  - For example, good hip joint stability requires a nice interplay between agonist and antagonist, between concentric and eccentric activity
  - Need to maintain an ideal position of the [femur](https://en.wikipedia.org/wiki/Femur) and the [acetabulum](https://en.wikipedia.org/wiki/Acetabulum) for full range of motion
  - If that is compromised throughout any part of that kinematic chain, it’s going to affect the quality of centration (transfer of force) and load above and below that region
- Prague School’s assessment and treatment is focused on the quality of synergy, coordination and timing of deep stabilization
- Based on developmental kinesiology, which is the neurophysiological aspects of the maturing locomotor system

## Human motor development through the lens of DNS, and when issues begin to arise [32:30]

- 3 months
  - can create fixed point so now the larger muscle groups have something to anchor off of; can turn head and fix gaze
  - Can lift legs out of base of support
  - triple flexion: 90 degrees at the hip, 90 degrees at the knee, neutral position of the ankle joint or subtalar joint
  - can bring their hands together and bring their hands to their mouth
- Neurologically, the coordination and timing of that deep stabilization group of musculature needs to be able to create a fixed point so that the muscles can anchor off it to bring the legs up
- Comparing an infant to an adult, in relation to the body, the infant’s head is bigger, their limbs are longer and their bones are still forming, so that’s much different than a 50 year old
  - But we all went through these developmental milestones, so we still have those same motor patterns
  - stereotypical motor patterns can be compromised due to soft tissue dysfunction, rigidity, lack of range of motion throughout our joints, and postural habituation
- Prague School approach
  - tries to assess the efficiency of that deep stabilization system
  - uses specific active exercises which are based off of the developmental milestones
- At 3 months, start to have the ability to stabilize along the sagittal plane (straight ahead) – see figure below

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-9-rintala-1024x1024.png)

**Figure 9. Anatomical planes.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Anatomical_plane)

- By 4 months, fixed point coordination is usually complete
- 4-4.5 months
  - start to be able to utilize the oblique slings
  - start to see some differentiation in the pelvis and in the limbs
- As management of intra-abdominal pressure improves:
  - hips and legs into higher position
  - range of reach improves
  - can reach the groin area
- 5 months: reach their knees
- 6 months: reach feet
- 7 months: bring foot to mouth
- Peter points out that’s it’s not just increasing flexibility
  - babies are very flexible at birth
  - but it takes increased motor control and stability to coordinate shoulder/hand to foot movement
- Infant possibly rolls over on stomach at 3 months, but lacks coordination and efficiency of force and load transfer
- With both newborns and adults with poor coordination and deep stabilization timing”
  - anterior pelvic tilt
  - flaring of rib cage
  - elevation of shoulders and protraction
  - reclination or extension through the cervical spine
- Babies want to explore, so they’ll find a way to move without creating the ideal centration and stabilization
- Lots of trial and error as CNS matures, forming brain mapping and motor [engrams](https://en.wikipedia.org/wiki/Engram_(neuropsychology))
  - In newborns, lower central nervous system structures are maturing
  - 3 months, maturation in the subcortical region of the central nervous system, postural foundations begin
  - 3-7 months
    - higher, more, and more stable positions
    - verticalization process: start from either supine on the back or prone
  - 7 months: can come to their side
  - 8 months: high oblique sit position
  - 9 months: crawl
  - 10-11 months: kneeling
  - 12 months: squatting
  - 13-14 months: standing
  - 14-15 months: walking
- These are variable over a 15-16 month period; Michael’s son walked at 10 months
- Peter points out that most neurotypical children have good dynamics and movement; haven’t started to get into the bad habituated movement patterns
- Vojta said that about 70% of infants are going to have healthy central nervous system maturation
  - 3-12 months: postural foundations, subcortical maturation
  - 2-6 years: cortical maturation (fine motor dexterity and movement, ability to write, language development, and motor learning)
  - The 70% figure likely comes from their observation
  - other 30% is a spectrum: on one end CP, on other end minimal brain dysfunction / central coordination disorder
- Prague School curriculum goes deeper into specific utilization of treatment options
- May be issues that compromise healthy maturation in modern society
  - too much time in car seat
  - not in an environment where they can explore
  - Peter’s example: baby chairs that prop kids into a seated position too soon (e.g., Bumbo, Boppy, and Jumpy chairs)
    - Peter did with his first two kids, by the third he was interested in DNS
    - Can’t support their own weight at that stage, slouched (Peter and his wife called it the “circle of neglect”)
    - Things like this can interfere with the normal neuromuscular development
  - Putting kids in shoes too early probably does a tremendous disservice to them
  - Another example is baby walkers
  - Peter notes that kids are then sitting in chairs 6-7 hours a day when they go to school
  - This is where you see the beginning of postural syndromes

## Common postural syndromes [50:00]

- Ideally, keep alignment of the pelvic floor and thoracic diaphragm
- The more efficiently we keep this alignment, the more efficiently we manage intra-abdominal pressure and uprighting throughout the spine, and the transfer of force and load

> “*If we fall into repetitive posturals or postural habituation, which [in our] society is kind of a bit prevalent, gravity is going to win*.” —Michael Rintala

- Start to fall into slumping posture
  - shoulders come forward
  - inhibit diaphragm descending that we need for respiration and stabilization
  - accessory breathing musculature kicks in (sternocleidomastoid, upper trapezius, scalenes – which attach to your cervical spine and the upper two ribs – and pectoralis minor) (see figure TK above)
  - If we do it often enough, it becomes our default pattern to decrease utilization of full expansion of the diaphragm and over-utilize the accessory breathing musculature
- With DNS, regain intra-abdominal pressure through eccentric loading of the “cylinder” rather than concentric loading
- If you want to pick up something that weighs 300 lbs, you have to generate abdominal pressure, but how you do that matters
- Kids develop via an “inside out” strategy
  - intra-abdominal pressure to load abdominal wall
  - interplay of concentric, eccentric, isometric activity to manage that pressure
- Examples
  - To pick up a pen, need function of stabilization to move arm and provide a fixed point so the shoulder girdle can be synergistic throughout the kinematic chain
  - If pick up something heavier like a chair, need a lot more generation and coordination of intra-abdominal pressure to create the fixed point and transfer the ground reactive forces through lower extremities, trunk, and pelvis to arms
- Increasing quality of dynamic stabilization is what happens developmentally

## Increasing functional threshold to minimize time in the functional gap [56:45]

- Top athletes have full extension, rotation, and flexion
- Bracing also provides stability
- Athletes have strong postural foundations, cortical function, and body awareness; can both relax and stabilize in different areas
- **Functional gap**: when go beyond the functional threshold to maintain quality of stabilization
- Athletes train for this because always pushing the threshold
  - High threshold compensatory pattern starts to become the norm with training
  - One goal is to help people improve quality of stabilization so they can increase ability to stay within functional threshold

**Elite athletes**

- Peter thinks many elite athletes don’t have to formally train in DNS because they do it naturally

> “*One of the hallmarks of [athletic] greatness is injury prevention. It’s not just the greatness at what they do, it’s the longevity with which they can do it.*” —Peter Attia

- Examples
  - [Roger Federer](https://en.wikipedia.org/wiki/Roger_Federer) is an example of an athlete with longevity and quick recovery from injuries
  - Železný had a 20 year career in javelin
  - Jágr still playing hockey at 48
- Focus on ideal stabilizing pattern, timing of movement, centration throughout the kinematic chain: quality over quantity
  - Federer creates a point of support, has great positioning and alignment
  - naturally has a huge capacity where he can maintain being in the functional gap
- Athletes with good training programs and coaches tend to stay within functional capacity

> “*If you have good programming, dosing, loading, timing, recovery, and on top of that, you have amazing body awareness and cortical function, you’re going to see longevity and you’re going to see nice quality of movement.*” –Michael Rintala

- With poor training, they spend too much time in the functional gap
- Extensor compression syndrome:
  - Michael’s colleague [Richard Ulm](https://www.rehabps.com/REHABILITATION/Richard_Ulm.html) works with lifting and power athletes
  - When they rely on higher threshold, get more injuries and longer recovery time
- Jágr and Železný were like test subjects for Prague school pioneers to develop their ideas over 20 years
- Prague School and DNS practitioners are now working with both athletes and the general population to teach them these concepts

## DNS for injuries, pain, pre-habilitation, and performance enhancement [1:03:45]

- Peter imagines two ends of the spectrum with patients:
  - Have injury and go back to figure out what they were doing wrong to teach them how to stabilize muscles correctly
  - Seeking performance enhancement
- Michael says most of his patients come for pain and injury
- Integrating exercises based off of developmental milestones
  - Once they have improved, work with trainer or coach for strength training and specific technique
  - once they’re out of pain, focus on quality of stabilization, movement, and transfer of force and load
- Only 10-20% of Michael’s patients end up following DNS rehab plan long term
- DNS is starting to be used in some places, like in major league baseball
- In the west, we are focused on stats (lift, strength capacity, etc.)
  - but also need to integrate the quality of movement and stability and then strength thresholds
  - Hard to get patients to stick with program once they are pain free – go back to old patterns
- After pain improves, use prehabilitation program
- Have them practice certain sequences of movements and exercises to improve stability
- Most common complaint in his office is low back pain
  - Often due to inefficient activation of the deep stabilizing system
  - extension compression activation (over-activation of flexor extensor)

## Etiology of back pain [1:10:00]

- Peter says 80% of people experience back pain at some point, so very important to understand the etiology
- Unless caused by an injury like an accident or fall, it’s mostly chronic overload over time
  - too much flexor extensor activity
  - positioning of the intersegmental and joints and the transfer of force and load are off
  - compensate with “hinging” through the lumbar sacral region
  - over time, you weaken the structure
- Skeletal anatomy
  - The sacrum is a single bone (other bones fused over time)
  - Five lumbar discs numbered one through five
  - disc between each of those lumbar vertebral bodies (for example, L4 is the disc between vertebrae three and four)
  - disc between the L5 and the sacrum is S1
  - vertebral bodies held in place by the discs, the facet joints that run behind them
  - the lamina, which are longer bones, hold it together but don’t provide support like the facet joints and at the disc interface

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-10-rintala-1024x910.png)

**Figure 10. Anatomy of lower spine.** Image credit: [American Academy of Orthopedic Surgeons](https://orthoinfo.aaos.org/en/diseases--conditions/spondylolysis-and-spondylolisthesis/)

Also musculature scaffolding that provides stabilization and uprighting effect

- muscles attached to the anterior (front) of vertebral bodies:
  - psoas, which attaches to those transverse (side) processes of the lumbar spine
  - quadratus lumborum is also attached to those processes
- both also attach at same point as crura of the diaphragm

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-11-rintala-1024x757.png)

**Figure 11. Musculature of lumbar spine.** Image credit: [Teach Me Anatomy](https://teachmeanatomy.info/abdomen/muscles/posterior-wall/)

- When diaphragm descends, intraconal pressure produced, loads abdominal wall and creates fixed point that anchors psoas and the quadratus
- if this doesn’t happen correctly, no anchor and get excessive extension and overload of facet joints (1:13:51)
  - tiling pelvis and hips forward, rib cage comes forward, spine bends excessively,
  - with oblique position of the diaphragm and pelvic floor
  - now a mechanical disadvantage of the abdominal wall
- Tendency for overactivation of extensor and flexor (psoas)
  - repetitive compression on those facet joints
  - repetitive hinging flexion of disc
- fluid in discs into annular fibers as they weaken
  - get the disc protrusions
  - body goes into a protective spasm
- See disc injury, then facet hypertrophy
- degenerative changes and the accumulation of bony material for stabilization

## How a stress fracture in his back led Michael to the Prague School [1:16:00]

- Michael developed spondylolysis, a stress fracture in the pars, which is the arch that attaches the vertebra to the facet joints

![](https://peterattiamd.com/wp-content/uploads/2021/03/fig-12-rintala-1024x663.png)

**Figure 12. Spondylosis.** Image credit: [American Academy of Orthopedic Surgeons](https://orthoinfo.aaos.org/en/diseases--conditions/spondylolysis-and-spondylolisthesis/)

- Led him to DNS and the Prague School
- Poor postural foundations, over-training, poor recovery
  - Can see the compensatory pattern in old pictures of himself
  - Caught up with him in college when he got stress fracture

> “*I was … the poster boy of upper and lower cross syndrome and lack of efficient stabilizing strategy.*” – Michael Rintala

- Had chronic pain cycle
- went to an orthopedist, physical therapists, chiropractor, all helped in some way, but he felt something was missing
- became a chiropractor in part to aid his own recovery

> *“It wasn’t until the second year [of chiropractic school] where I was introduced to Prague School, Janda and Levit, and what they were teaching. It was like oh, finally, something made sense*” —Michael Rintala

- Tried it on his own and helped with pain
- Was able to go to Prague with [Craig Liebenson](https://www.lasportsandspine.com/about-dr-liebenson) for 8 days of intensive lectures and workshops in early 2000s

> “*It was like another light bulb and another piece of that puzzle for me to work my way out of … my own situation*”  —Michael Rintala

- Since 2003, the concepts and principles have evolved to become DNS and the current curriculum
- Now Michael is one of only 18 international DNS instructors

## The Prague School curriculum: 3 tracks for certification in DNS [1:20:45]

- Three tracks of the DNS curriculum
  - Clinical track: Courses A, B and C
  - D course: an intensive with the Prague therapists
    - One course is for clinicians
    - Another for both trainers and clinicians, is less manual and more how to integrate principles into a training programs
    - Third is on how to use DNS handling skills with infants
- Curriculum started around 2009
- Also have specialty courses

> “*One thing I love about [DNS] is you can easily integrate it into the good work that you’re already doing, whether you’re a trainer [or] whether you’re a clinician and you do a specific technique.*” —Michael Rintala

- Visceral and soft tissue mobilization techniques
- Constantly exploring and trying to improve teaching and integration
- “It’s not just specific exercises, but it’s facilitating the awareness of the ideal stabilization, and the support. … I want my patients … to feel that synergy and feel that ability to stabilize where they need to, but then also relax where they need to.”

> “*There’s a little bit of a process. [DNS] is not a cookie cutter thing, like just do this, this, this. You have to put some work into it, you have to practice it, both as a patient and as a clinician or a trainer.*” —Michael Rintala

**Challenges for patients**

- Peter thinks the people DNS works for are those who buy into the philosophy rather than needing quick results because “it feels a lot of the time like you’re not doing much”
  - If need a dopamine surge, this is a hard program
  - In this system you do things like practice learning how to breathe the right way, and you never stop practicing
- Peter says the important factors are efficacy (how well it works if it’s adhered to correctly) and effectiveness (how well it works out in the real world)

> “*To me DNS might be the single most efficacious thing I have ever come across as far as healing injury and preventing injury*.” —Peter Attia

- But may be less effective because people don’t stay with it once out of pain – need to increase numbers of people who can stick with the program once they start

- For clinicians and trainers, develop a good eye to recognize where the insufficiencies are (1:28:06)
  - Can give patients /clients specific ideas to increase efficiency
  - But an athlete might not want to go back to master fundamental movements
- Train staff that’s working full-time with athletes

**Expertise within Prague School**

- Expertise within Prague school for:
  - running, dance, golf, baseball, hockey
  - Richard Ulm focuses on lifting and strength
- Standard course tends to be clinical, but specialty courses really help with integration
- Can communicate more easily about a sport they are familiar with

Peter says you don’t fully understand things like DNS, [PRI](https://www.posturalrestoration.com/), and [FRC](https://functionalanatomyseminars.com/) until you feel them

§

# EXERCISE VIDEOS

## Lesson 1: Diaphragmatic breathing

- Ensure full expansion of diaphragm and inflation of the lungs
  - Line up head with thoracic diaphragm and pelvic floor
  - Put hands on the body to monitor muscle movement
  - Breathe down towards pelvic floor
- Expand at belt line, lower ribs, and upper thoracic cage
- Diaphragm controls sphincter function where esophagus passes through
- Avoid abdominal “ballooning” – want to see expansion all the way down, 360 degrees around
- Karel Lewit said, “If breathing is not normalized, nothing else can be”

## Lesson 2: Postural function of the diaphragm

- Lie on back with knees bent, feet on ground
- Can facilitate this function by:
  - breathing in, feeling diaphragm descending and abdominal wall expansion
  - Load pelvic floor, responds eccentrically
  - then see management of eccentric, concentric, and isometric contraction
- Maintain this stabilization and fixed point while also breathing
  - Not sticking out belly, muscles should lift: eccentric loading of entire abdominal wall
  - Feel activation on sides and back as well as front
  - Thoracic-lumbar junction is key
- Challenge coordination of respiratory and postural function:
  - Lift ball overhead without scissoring of thoracic cage and pelvic floor
  - Hold ball while also lifting and then and lowering leg, maintaining connection
  - Lift ball overhead while keeping both legs up

## Lesson 3: Activation of stabilizing function

- 3 month developmental position
  - Start getting sagittal stability
  - Infant can prop up on elbows, look from side to side
  - But CNS not yet developed enough to be able to lift the arm out of support
- Face down with elbows in line with ear canal
  - Cue stabilizing function with breath
  - Expansion of abdominal wall
  - Uprighting through cervical spine
  - Fixed point through shoulder girdle, trunk and pelvis
- By 4.5-5 months, can use leg as contralateral support
- This contralateral pattern is what you see with runners
  - If runner can’t find stability, start here
  - Issues around the thoracic-abdominal junction are common
  - If one area is not efficient, it affects whole chain

## Lesson 4: Five-month developmental position

- Infant can turn to side at 5 months
- If line up properly:
  - Get stable point for [oblique slings](https://www.advancedhumanperformance.com/blog/oblique-slings-functional-training)
  - Centrated position in shoulder girdle
  - Facilitates uprighting through cervical spine
- By 6 months, turn onto belly
- 7 months, low oblique sitting position (first time trunk of out of support position in frontal plane)
- Integration of stabilization and transfer force/load into daily life
- Can get impingement syndrome if lack stability

## Lesson 5: Developmental flow in prone position

- Month-by-month development
- Show how to work through sequences of developmental positions maintaining stabilizing function and finding ideal points of support
- “Postural tai chi”
- Centration, stabilization, and differentiation of extremities
- Training CNS to get better stability and can then integrate into any activity

## Lesson 6: Bear flow progression

- Higher developmental sequence
  - Hands-and-knee position
  - Bring hips above shoulder (about 12 months)
  - Infants now have hand and foot support
- Use [Core 360 belt](https://core360belt.com/)
  - can put in nubs areas where seeing inefficient facilitation of eccentric loading
  - gives proprioceptive feedback (not weight belt or support belt)
- Lower knees to mat (and then come up) without losing stabilizing function
- Challenges:
  - lift one leg
  - raise one arm to the ceiling while maintaining stabilizing function
- Even very strong people might have trouble
  - Shows that their connection may not be efficient
  - Can’t transfer power well without overloading transitional areas throughout kinematic chain

## Lesson 7: Hip mobility stability flow

- Progression from 7.5-8 months (high oblique sit) to 10-11 months and then a standing position
- Oblique sit to single-leg lunge to standing without needing arm support
  - Stability of trunk and pelvis, positioning force and load through lower extremity, need acetabulum to be able to more the right way around the head of the femur
  - If don’t do it the right way, knees and lower back will be overloaded
- One of Peter’s “Centenarian Decathlon” points is being able to get off the ground without using his hands
- Can be modified if have pain or need to gradually work up to it
- With consistency and repetition, develop a motor engram and becomes the default
- In reverse it’s eccentric stretching of glutes and leg muscles
- Not the same as a “[shin box](https://www.menshealth.com/fitness/a19517725/shin-box-switch/)” stretch – it’s not “crunching your cylinder” but instead bending and folding at the waist

## Lesson 8: Developmental sequence under load

- Weight helps you feel the stabilizing function as go through the developmental sequences
- Good for athletes – combines stability, mobility, and load
- Only use as much weight as allows you to still maintain your functional threshold, ideal centration and stabilization
- Provides a challenge which reinforces the pattern
- Can then integrate it into other sports

§

## Selected Links / Related Material

**Prague School of Rehabilitation website**: [www.rehabps.com](https://www.rehabps.com/)

**Prague School’s DNS App**: <https://www.rehabps.com/REHABILITATION/App.html>

**Václav** **Vojta’s website**: <https://www.vojta.com/en/>

§

## People Mentioned

- [Beth Lewis](https://bodyevolvednyc.com/us/) (Fitness coach and Peter’s colleague at Attia Medical) [Intro, 5:03]
- [Michael Stromsness](https://www.instagram.com/enlightened_savage_101/) (Training coach who has worked with Peter) [5:03, 28:21]
- [Pavel Kolář](https://www.rehabps.com/REHABILITATION/Kolar.html) (Head of Rehabilitation department at the Prague School) [6:06, 14:00, 16:02, 29:44, 30:11]
- [Vladimir Janda](https://pubmed.ncbi.nlm.nih.gov/16641785/) (Prague School neurologist and DNS pioneer who developed specific treatments for postural habituation) [7:28, 8:42, 10:49, 30:11, 1:18:40]
- [Karel Lewit](https://www.rehabps.com/REHABILITATION/LEWIT.html) (Prague School neurologist and DNS pioneer who developed mobilization techniques for joints and soft tissues) [7:28, 11:50, 30:11]
- [Václav Vojta](https://en.wikipedia.org/wiki/V%c3%a1clav_Vojta) (Prague School pediatric neurologist and DNS pioneer who focused on CP and developed postural reactions test) [7:28, 12:53, 30:11, 44:39]
- [Jan Železný](https://en.wikipedia.org/wiki/Jan_%C5%BDelezn%C3%BD) (Czech Olympic javelin thrower who worked with Pavel Kolář) [17:55, 59:24, 1:03:08]
- [Jaromír Jágr](https://en.wikipedia.org/wiki/Jarom%C3%ADr_J%C3%A1gr) (Czech hockey player who worked with Pavel Kolář) [17:55, 59:24, 1:03:08]
- [Roger Federer](https://en.wikipedia.org/wiki/Roger_Federer) (Swiss tennis player considered to be among the best of all time) [59:24, 1:00:42]
- [Richard Ulm](https://www.rehabps.com/REHABILITATION/Richard_Ulm.html) (Prague School practitioner who specializes in working with weight lifters) [1:02:25, 1:30:25]
- [Craig Liebenson](https://www.lasportsandspine.com/about-dr-liebenson) (California-based practitioner who took Michael to on-site training in Prague) [1:19:30]

§

![](https://peterattiamd.com/wp-content/uploads/2021/03/bio-image-rintala-500x500.png)

##### Michael Rintala, D.C.

Michael Rintala is a San Diego-based chiropractor who specializes in rehabilitation and sports medicine. He is one of only 18 international instructors for the Prague School of Rehabilitation, teaching dynamic neuromuscular stabilization (DNS).  He is also a certified Strength and Conditioning Specialist (CSCS) and certified in full body Active Release Technique.  In addition, he serves on the PGA Tour Sports Medicine Team and the USA Surfing High Performance Committee.

**Instagram:** [@rintala\_movementflow](https://www.instagram.com/rintala_movementflow/)

**Facebook:** [Michael Rintala DC](https://www.facebook.com/michael.rintala.7DNS)

**Youtube Channel:** [Michael Rintala, DC](https://www.youtube.com/user/rintala67/videos)

**Websites:** [rintalachiro.com](https://www.rintalachiro.com/) and [rintalamovementdesigns.com](https://www.rintalamovementdesigns.com/)