# #61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology

**Source:** [https://peterattiamd.com/rajpaulattariwala/](https://peterattiamd.com/rajpaulattariwala/)

---

In this episode, radiologist/engineer, Raj Attariwala, explains how he was able to apply his engineering background to create a unique MRI scanner that is capable of constructing whole-body images with a resolution that is unmatched in the industry. Peter and Raj discuss the implications of such a robust, radiation-free imaging tool on the early detection of cancer. They dive deep into cancer screening and define terms such as sensitivity and specificity that are necessary to really understand this complex space. They then describe the biggest risks involved in this type of screening (false positives) and how Raj’s unique technology and process might drive down this risk substantially. But before that, they discuss all the common imaging technology from X-ray, to CT scan, to PET scans, to ultrasound, to MRI, and more. They touch on the history of each, how they work, the usefulness and limitations of each of them, as well as the varying risks involved such as radiation exposure. If you are interested in cancer screening and/or you’ve ever wondered how any radiology tool works, this episode is for you.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rajpaulattariwala/the_Drive_public.png)

Play

#61 - Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology

#61 - Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology

1x15s30s

0:002:13:15

## We discuss:

- Raj’s road from engineering to radiology [7:45];
- How X-ray works, the risk of radiation exposure, and the varying amounts of radiation associated with the different imaging technologies [18:00];
- Computed tomography scans (CT scans): The history of CT, how it works, and why we use contrast [27:45];
- Ultrasound: Benefits and limitations, and a special use for the heart [40:45];
- Detecting breast cancer with mammography: When is works, when you need more testing, and defining ‘sensitivity’ and ‘specificity’ [51:15];
- Magnetic resonance imaging (MRI): How it works, defining terms, and looking at the most common types of MRI [1:03:45];
- Brain aneurysms: Using MRI to find them and save lives [1:23:45];
- Raj’s unique MRI technology [1:30:00];
- The risk of false positives in cancer detection, and how Raj’s MRI can reduce the number of false positives (i.e., increase specificity) [1:43:40];
- The unique software Raj created to pair with his MRI machine [1:51:15];
- Comparing the radiation exposure of a whole-body PET-CT to Raj’s equipment (DWIBS-MRI) [1:53:40];
- How diffusion-weighted magnetic resonance imaging (DW-MRI) has revolutionized cancer screening [1:55:15];
- Why a DW-MRI is still not a perfect test [1:59:00];
- The potential for advancing MRI technology: Where does Raj think it could improve in the next 5-10 years? [2:03:00];
- Are there any commercially available scanners that can match the resolution of Raj’s images? [2:06:00];
- Machine learning: When and where might machine learning/AI impact the field of radiology? [2:08:40]; and
- More.

§

## Show Notes

## Raj’s road from engineering to radiology [7:45]

How they met

- Peter and Raj met through a mutual friend that told Peter he had to go and check out Raj’s fancy MRI machine
- Peter flew to Raj’s clinic in Vancouver and got a full-body MRI in 2015 for the first time

\*[See Peter’s instagram post showing video of the scan](https://www.instagram.com/p/BwVyo4ZgpRA/)\*

![](https://peterattiamd.com/wp-content/uploads/2019/07/Peter-entering-the-MRI-machine-1024x960.png)

**Figure 1. Peter going into Raj’s Prenuvo MRI machine.**

Raj’s business

- [AIM Medical Imaging](https://aimmedicalimaging.com/) is a private scanning company which Raj started to be able to “play” with his MRI technology
- His clinic is called **Prenuvo** which was started in order to “put the power of preventive medicine into a patient’s hands”

Raj’s road to radiology

- Raj got a chemical engineering degree
- during that period of time I realized that I actually like the body and physiology and how that works
- Then decided to get a master’s and PhD in biomedical engineering at Northwestern
- During that time, he and his team built a robot that could do [keyhole surgery](https://www.nhs.uk/conditions/laparoscopy/) in the eye that wound up attracting a lot of attention from physicians from top-tier universities
- The desire to be able to speak the language of doctors, Raj decided to go to medical school

Med school

- “Hated every minute of it”
- Raj likes answers to questions and soon realized that there’s a lot of things in the body, and physiology, and pathophysiology that we just don’t fully understand

> “What I would actually start to boil it down to is that I would actually go back to my engineering pathophysiology texts, and I would actually read them and talk to the PhD guys, and they would actually give me the theories on what they thought was happening. When you actually got that theory, it was almost like planting a seed, and then you actually understood how the entire tree would look.”

**Technology in medicine**

- Raj’s first love was technology so he decided to put those things together
- Worked on some of the very first surgical robotic machines ever built
- But in that process, Raj realized that the best place to focus on technology in medicine was radiology (imaging technology)

*Radiology*

- Started in an area called [nuclear medicine](https://en.wikipedia.org/wiki/Nuclear_medicine), which is a small specialty within radiology where you’re actually looking at functional imaging, how things work, how do things change, what happens over time
- Really liked nuclear medicine because it was showing you what’s happening when things are normal and then when things become abnormal (Raj particularly loved how the answer was black and white which is rare in medicine)

**Analogy**

- *Radiology is like anatomy*, *a blueprint*… where you actually see what’s going on, you actually see the changes, and you see the shapes of things, and you use that very much as a blueprint for a building to actually see what it does
- *Whereas nuclear medicine*, instead of the blueprint, you actually know there’s all these people carrying letters, moving in and out of this building (We don’t really know where the building walls are, but we know that there must be something happening there)
- When you put the blueprint together with the movement inside the area of interest, you start to realize “oh, these are postal workers carrying things, and here’s the geometry of the building. That power really is actually quite useful.”

*1 +1 = 3*

- The first device to combine functional imaging with nuclear medicine imaging was the [positron-emission tomography-computed tomography](https://en.wikipedia.org/wiki/PET-CT) (PET-CT)
- These two separate modalities of functional imaging and anatomic imaging come together to actually make something better than each part individually (i.e., 1+1=3)

Advice Peter got from radiology people while in med school:

“Anytime you order a test, in the back of your mind you have to be asking yourself, ‘Do you want anatomical information, or functional information or both?’”

![](https://peterattiamd.com/wp-content/uploads/2019/07/anatomical-images-of-the-brain-ct-and-mri-1024x542.png)

**Figure 2. An example of an anatomical image of the brain with CT scan and with an MRI.** Image credit: [regencymedicalcentre.com](https://www.regencymedicalcentre.com/wp-content/uploads/2018/06/Upper-endoscopy-Risk-4.png)

![](https://peterattiamd.com/wp-content/uploads/2019/07/PET-scan-of-the-brain-1024x669.png)

**Figure 3. An example of a brain PET scan showing which shows glucose uptake.** Image credit: [bachlab.pitt.edu](https://bachlab.pitt.edu/facilities/pet-imaging)

![](https://peterattiamd.com/wp-content/uploads/2019/07/Brain-MRI-and18F-FDG-PET-scan-of-the-proband-in-the-transverse-plane-A-The-MRI-scan.jpg)

**Figure 4. DW-MRI (A) and PET/CT of the brain (B). “Brain MRI and18 F-FDG-PET-scan of the proband in the transverse plane. A: The MRI scan included a diffusion weighted sequence (DWI) and a T2\* weighted sequence. No focal lesions were observed; however, the cerebellar hemispheres and vermis appeared atrophic (arrow heads). B: 18 F-FDG-PET-scan showing strikingly reduced metabolism in the cerebellum suggesting pathology primarily localized to the cerebellum.”** Image credit: [Nielsen et al., 2012](https://www.ncbi.nlm.nih.gov/pubmed/22889412)

## How X-ray works, the risk of radiation exposure, and the varying amounts of radiation associated with the different imaging technologies [18:00]

*At the highest level, how do we take an X-ray? How does it produce that image?*

- Effectively, X-ray is taking these high energy wavelength, and it actually penetrates right through the body
- Anywhere where there’s something dense, very hard like bone, the X-ray beam can’t make it through
- Contrarily, the X-ray penetrates right through it and shines through soft tissue
- And that’s what gives us the white pictures of the bone because the film that’s exposed on the other side, the soft tissues, the X-rays have gone through
- Therefore, on the film on the other side it stays white

![](https://peterattiamd.com/wp-content/uploads/2019/07/chest-x-ray.jpg)

**Figure 5. Chest x-ray image of a 50 year old male. “There is a degree of hyperinflation as evidenced by both increased retrosternal airspace and somewhat flattened and depressed diaphragms.”** Image credit: [radiopaedia.org](https://radiopaedia.org/cases/normal-chest-x-ray)

*In the early days, were they aware of the damage of ionizing radiation?*

- Unfortunately, there were [lots of casualties due to radiation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3520298/)
- Our understanding of radiation has actually been moved by really traumatic events such as [Hiroshima and Nagasaki](https://en.wikipedia.org/wiki/Atomic_bombings_of_Hiroshima_and_Nagasaki) where we’ve actually been able to watch people over time

*What can happen with radiation exposure?*

- DNA of the cells get damaged and there’s a risk of inducing cancers with that

*Different types of x-rays and scans have differing amounts of radiation*:

- Peter has a graph for his patients that lists a number of different technologies and their associated radiation amounts
- At the top end of that spectrum you’d have a whole body PET-CT
- We measure radiation in [millisieverts](https://www.radioactivity.eu.com/site/pages/MilliSievert.htm)

*What is a millisievert?*

- A millisievert is the unit of measurement of radiation
- It’s set by the standards group [Système Internationale](https://en.wikipedia.org/wiki/International_System_of_Units) in France
- It actually sets what a standard dose of radiation is

*Understanding radiation*:

- There’s good radiation, and there’s bad radiation
- Anytime you actually have any ion that’s actually releasing a component of its energy, that energy has to get deposited somewhere…
- It comes off as a photon of energy
- It’s never created, it’s never destroyed, so that the energy if it doesn’t go through you, it’s *going to deposit in you (bad)*
- If it actually deposits in you, that’s where it can actually cause the damage

*Different types of imaging*:

-On one end you have the [mammogram](https://en.wikipedia.org/wiki/Mammography)

- Very low amount of radiation in millisieverts, **about 0.05**)

-On the other end of the scale you’ll have the [PET-CT](https://en.wikipedia.org/wiki/PET-CT)

- The PET-CT couples the radiation from CT and from PET
- CT is a powerful X-ray that’s spinning around the body and creating a three-dimensional view of you
- PET is a positron-emission tomography which is using  radioactive glucose known as radioactive fluorine-18 which gives off a tremendous amount of energy (It’s the highest energy that you can have in imaging for radiation at 511 kiloelectron volts)
- So a person could easily get 30 or 40 millisieverts in total in that scan if they were doing chest, abdomen and pelvis, for example.

**Nuclear medicine by contrast…**

- Whereas with nuclear medicine what we typically do is take pictures of everything from head to foot
- Since we’re actually going to inject somebody with the radioactive material, as a result, we’ve exposed them to that radiation to all parts of the body, we want to maximize the amount of data that we’re going to extract from that exposure.

**Recommended upper limit of millisieverts**

- In the United States the NRC recommends that no one receives [more than 50 millisieverts in a year](https://hps.org/documents/radiation_and_risk.pdf)
- That said, not all millisieverts come from imaging

⇒ Places that contribute to radiation other than imaging

- The higher altitude you live at, the more cosmic radiation you are exposed to (at sea level it’s about 2-3 per year)
  - People in Denver are getting probably ~6 or 7 millisieverts a year
  - Altitude in planes, can also contribute to radiation exposure
    - Fortunately, not very much exposure (like less than 0.1 millisievert per round trip from coast to coast)
    - But if you do L.A. over the North Pole, due to the ozone which absorbs radiation, your [radiation exposure goes in exponentially](https://www.nasa.gov/centers/langley/science/polar-radiation.html) (i.e., more than just the extra distance you travel) and that’s because of the ozone which absorbs radiation
- Certain geographies will actually have [radon](https://en.wikipedia.org/wiki/Radon), which is another exposure to the millisieverts

\*[Online calculator](https://jag.cami.jccbi.gov/cariprofile.asp) to determine radiation exposure from air travel\*

- In summary, just because the NRC says 50 as the limit, Peter doesn’t take that to mean we *should* go up to 50

**Do we have a sense of what the implication of that is in terms of normal physiology?**

“*We do, and we don’t.*” … Much of our understanding comes from Hiroshima and Nagasaki, as well as other people like in [Fuji reactor](https://en.wikipedia.org/wiki/Fuji_Molten_Salt_Reactor) where people actually got exposed

[Landmark paper out of Columbia](https://www.columbia.edu/~djb3/papers/jama1.pdf) forced radiology as a field to actually look at the potential damaging effect of X-ray radiation

- Looked at the amount of radiation that people actually receive from CT scanners
- Found that the younger you are, the greater the risk of cancer induction from CT scanners
- Also, females are actually more sensitive to radiation than men

*Why are females more at risk than males?*

- It has to do with the fact that the egg is actually produced during embryonic stage
- As a result, that DNA is effectively frozen in time
- As women are getting older and older, they’re releasing these DNA in the eggs
- Therefore, the younger you are, the fresher the DNA
- Around age 12 is when this DNA comes out of the “frozen” state during the beginning of menstruation and that’s when these eggs start to be released.
- So **age 12 is the worst time for females to be exposed to radiation**
  - Very sad fact considering there are plenty of younger cancer patients that have no choice but to be exposed

## Computed tomography scans (CT scans): The history of CT, how it works, and why we use contrast [27:45]

- If you truly understand how an X-ray works, then you understand what a [computed tomography scan](https://en.wikipedia.org/wiki/CT_scan) (CT scan) is doing because it’s just doing it in a three dimensional spiral
- The amount of information in an X-ray is phenomenal but it is a 2D picture
- The biggest problem with x-ray is that sometimes you’re actually overlapping different things, and you just can’t see

When CT came around…

- That’s when it actually really allowed us to look at things in 3D
- Surgeons could look at these and actually start to imagine what they’re going to be operating on… *that is the power 3D imaging*

A simple way to think about it…

- An X-ray is like a single flash… you get a picture
- A CT scan is really *like a searchlight in a boat going around an island* to actually get all the images the whole way around… it’s triangulation effective by spinning around in multiple different cycles by going around in 360 degrees

CAT vs CT

- We use the term CT very loosely, but it stands for [computed tomography](https://en.wikipedia.org/wiki/CT_scan)
- Sometimes people back in the old days used to refer to it as CAT scanner where the “A” was for axial

*When was the first CT scan put into clinical practice?*

- In the 1970s, a phonographic company called [EMI built the very first CT scanner](https://www.imaginis.com/ct-scan/brief-history-of-ct)
- Two bit scanner (Two bit means you really only have one “flashlight” and one detector)
- Originally used for the brain

**Anatomy of a CT scanner**

- Basically, 180 degrees apart you have the X-ray and the detector,
- Then it actually starts to spin around in rapid revolution.
- When you actually look at a machine,
  - there’s the donut hole in the middle,
  - But around it there’s actually the casing

![](https://peterattiamd.com/wp-content/uploads/2019/07/ct-with-cover-off-1024x891.jpg)

**Figure 6****. A CT scanner with the cover off.** Image credit: [Reddit user: craftymethod](https://www.reddit.com/r/pics/comments/ugimw/what_does_a_ct_scanner_look_like_with_its_cover/)

**Explaining bits**

- First scanner was a two-bit (Two bit scanners only have one “flashlight” and one detector)
- When Peter was in residency, they were using 16 and 32 bit scanners (16 bit means you’ve got eight units spaced out equally and then you’ve got eight detecting surfaces)

Example…

- Let’s say you start at the top of your head and move down to you toes
- An eight “slice” means you take  one slice, then you’re measuring immediately below for another “slice”, and immediately below that again
- As a result, as you’re circulating around the person or the patient, you’re actually doing 8 slices at a time, or 16 slices at a time, or 32 slices at a time, and so on.
- The higher the number of slices, the more coverage you get

Thinner slices

- The more thin you get, the more detail you can get from an imaging perspective
- BUT, the thinner you go, the more radiation required to overcome the signal and the noise background

\**You are trading off is an optimization problem*: **which is speed, resolution, radiation**\*

*What bit are we using today?*

- 256 is one of the common one
- And it’s mostly used for things that are rapidly moving, **typically the heart**

*Do we have a 512?*

- In research, yes.
- You can actually make them as high as you want ⇒ *The problem is you eventually get to diminishing returns of how thin the slices are and how many images you need*

*What bit is needed to scan a body part that is NOT moving (e.g., the pancreas)? Is 128 or 64 enough? Does 256 offer an advantage?*

- 256 doesn’t really offer an advantage
- Eight slices work quite well

Remembering back to residency, Peter says that having a good radiologist was just *as important* as having a good surgeon

- Take pancreatic cancer, for example…
  - Many patients with pancreatic cancer technically shouldn’t be operated on
  - And you’d really like to know that *before you enter the patient’s abdomen*, which is not always possible
  - But the better the radiologist, the more information that can tell you prior to surgery

⇒ [Elliot Fishman’s 3D renderings of the pancreas](https://www.researchgate.net/publication/323832990_Cinematic_rendering_of_pancreatic_neoplasms_preliminary_observations_and_opportunities)

> “The whole power of this. . .is that our brain thinks in 3D. So, instead of looking slice by slice at a 2D image (like an X-ray), it became what our eyes could see, what our brains could see, and it actually really helped everybody plan their surgery. So, it really was revolutionary to actually start to look at things in three dimensions.”

**What is contrast and why do we use it?**

- For the CT world it’s actually an iodinated material
- What iodine does is it actually absorbs the photons and therefore makes things look white on a CT scan
- It’s like having liquid bone in your blood stream or a liquid photon absorber

*How it’s used*

- It’s injected it into the vein
- Then the heart pumps it around
- That means we’re actually able to time when we actually take the CT image in order to be able to see what type of organ we’re looking for
  - If you get the arterial phase, you’ll actually see where the arteries are connecting to the organ
  - Or you can wait for the venous phase, when the veins are returning blood flow from that organ, and you can actually see the entire detail of the organ

In summary…

- it’s a way to light up the blood vessels and light up the capillary net and everything in between. . .between the artery and the vein, to allow us to see the anatomic detail from the perspective of adding blood to it
- In the absence of contrast,  blood looks functionally like water

***What are Hounsfield units?***

- [Godfrey Hounsfield](https://en.wikipedia.org/wiki/Godfrey_Hounsfield) came along and said, “How do we calibrate this?”
- The scale has to do with **density**
- There’s a range of Hounsfield units, from -1,000, 0, to 2,000
  - 0 is defined as water
  - 1,000 is basically air
  - As a result, we can actually see the difference between the density of bone and air, with water effectively in the middle
  - At +1,000, it is black
  - At -1,000, it is pure white

The biggest problem is that the eye actually can’t see that range…

- So on our computers we actually will narrow down
- At the higher Hounsfield units we can see lung
- Then we go down to look at the denser material (e.g., bone)
- But we can’t see the whole thing

You can specify multiple parameters:

- You could specify the width of your window
- And where it is centered

⇒ For example, if you wanted to look at lung, you would center it much closer to positive numbers, and you don’t need a very wide range, do you? ⇒ “*No. Not at all.”*

RECAP so far:

- X-ray is a purely anatomic study… there’s nothing functional about it
- CT by itself is also a very anatomic study
  - But you can add contrast to get even better information about the vasculature
  - You now have so much information that you can basically titrate or calibrate the window in which you look into that collection of radiation and specify your tissues
- CT are also very fast
  - “*The real power of CT is the speed.*”
  - In trauma, you want to put them through the CT scanner as fast as possible in order to get the information out as fast as possible

## Ultrasound: Benefits and limitations, and a special use for the heart [40:45]

- Ultrasound is even faster than CT
- It also doesn’t come with radiation

*How does ultrasound work? And what are its limitations?*

- It’s basically it’s a high frequency, higher than what our ears can hear, and it’s penetrating solid tissue
- So, it’s a high frequency sound wave (ultrasound) versus an ionizing wave of energy (radiation)
- At every tissue interface it actually reflects back, like an echo
- The time it takes for the sound to reflect back tells you how deep that tissue is

⇒ Animals can actually do this…

- Bats use this for sight
- [Whales and dolphins are incredibly good at this](https://www.sciencedaily.com/releases/2011/06/110607112338.htm)… their sonography rivaled that of our finest medical equipment
  - In part that’s because the medium through which they travel is water, as opposed to what the bat has to do, which is go through this poorly, poorly dense air.

*⇒ In the air*: ultrasound doesn’t penetrate very far, because it’s a high frequency, and you lose it because there’s no reflection coming back

*⇒ In the water*, or even dense material *like organs in the bod*y, it actually reflects back easier

- It’s that reflection that actually allows you to discern the different tissue types based on how quickly it reflects back

*Can ultrasound harm you in any way?*

- You could ultrasound yourself all day every day for the rest of your life, and you’re not increasing your risk of cancer
- Whereas if you did a CT scan of yourself every month, you’re going to be in trouble after several months

*What are the limitations of ultrasound?*

- The resolution isn’t as high as CT
  - With ultrasound you’re only looking at one slice in time
  - With ultrasound as you sweep through you get one layer. Then you get another layer. Then you get another layer. Then eventually that’s composited together to see what’s going on.
- Ultrasound really struggles when it encounters air inside the body
  - For example, you look at a female pelvis, you want their bladder to be full, because then their bladder being full of fluid, it actually acts as a nice window to allow the ultrasound beam to pass right through to be able to see the uterus behind it.

**Ultrasound for the heart**

- There’s a special subset of ultrasound that we do on the heart

*⇒ Where did that idea come about? Who figured that idea out?*

- We discovered there was a nice window that would actually allow you to miss the air in the lungs and look at the heart quite well
- As a result, you can actually see where things were moving, such as the valves of the heart or the walls of the heart
- Then as well you actually add something called [doppler](https://www.mayoclinic.org/doppler-ultrasound/expert-answers/faq-20058452), which is basically the frequency bouncing off of a blood vessel (If it’s going vs. coming, the frequency is going to be different)
- Now you can actually now start to see how blood is moving
- There’s very thin window, usually underneath the chest and around the lung

⇒ Echocardiogram

Youtube: [Echocardiogram: An ultrasound for your heart](https://www.youtube.com/watch?v=8N6flQ7r5BI)

- [Transthoracic echo](https://radiopaedia.org/articles/transthoracic-echocardiography-views?lang=us) is over the chest
  - The technician is really pressing quite hard on the chest and it’s somewhat uncomfortable for the person getting the echo done
  - The jelly is doing everything to eliminate even a drop of air between the interface
- [Transesophageal echocardiogram](https://radiopaedia.org/articles/transesophageal-echocardiography?lang=us) in the esophagus
  - Usually during surgery
  - you get an even better view of the heart

More about ultrasound

- The deeper you go with an ultrasound, the beam effectively fans out and gets thinner and thinner
- You actually get less detail on the edges, whereas right in the center, right underneath the probe, is where your maximum amount of detail is going to be
- By having it right in the esophagus, which is right beside the heart, you’re going to get fantastic detail

Importance for trauma situations

- As important as the CT scanner was in trauma, the ultrasound was actually the most important radiographic tool we had in trauma
- It was called a [fast ultrasound](https://en.wikipedia.org/wiki/Focused_assessment_with_sonography_for_trauma) in residency
- Penetrating trauma in particular, where you have to know, does this person need to go up to surgery? Is there fluid in the abdominal cavity? Fluid around the pericardium? These are surgical emergencies
- If people weren’t 100% confident that there’s a problem, or not a problem, they’d go straight to CT scan, because you just couldn’t make that error

*A story from Peter’s personal experience in residency…*

- Patient had the tiniest, tiniest stab wound, so less than a centimeter wide under the xiphoid
- It could have been a shaving cut
- Vital signs are more or less what you would expect
- Peter did ultrasound of his heart, it really looks like there’s something there, but I can’t quite figure it out
- So took him to CT scanner
- The danger of the CT scanner is it is not nearly as fast as a fast ultrasound
- So if there is a major issue, the person could die while waiting for the CT scan
- Peter was once told by a junior resident, “Beware of the patient who gets wildly anxious when you lay them down.”
- Sure enough, the guy freaked out when he laid down for the CT scan
- We took him to the OR, opened him up immediately, and sure enough that knife had actually hit his pulmonary vein, and so that pulmonary vein was bleeding into his pericardium.
- He would have had a [cardiac tamponade](https://emedicine.medscape.com/article/152083-overview) if we had left him on that table.
- Amazingly, that patient went home three days later.
- Raj’s comment on Peter story: “*You can see like the power of the clinical skill, as well as just the basic imaging. Right? The power of imaging plus clinical is pretty much where medicine is right now and how we actually are able to diagnose things quickly and efficiently.*”

## Detecting breast cancer with mammography: When is works, when you need more testing, and defining ‘sensitivity’ and ‘specificity’ [51:15]

*What is a mammogram? Why is it sometimes sufficient and other times not and you need an ultrasound?*

- Mammography is a lower attenuation x-ray (aka a weaker strength x-ray) since we never have to penetrate bone, and actually now it shines through the breast tissue, which is all soft tissue

Composition of breast tissue

- Breast tissue is composed
  - normal subcutaneous tissue, mainly fat
  - As well as glandular tissue
  - Women are in their childbearing age… it’s *almost all glandular tissue* to produce milk for eventually feeding a baby
  - As women go through menopause… that glandular tissue can invariably involute (gets replaced with fat)
  - BUT… in some women, it actually doesn’t get replaced with fat, and that is what we call the “dense breast tissue”

⇒ **Mammogram are good at**: shining through fat which allows you to see very simple things, like calcification in fat

⇒ **Not so good at**: Seeing through glandular tissue… sometimes that photon of low energy x-ray doesn’t make it through

![](https://peterattiamd.com/wp-content/uploads/2019/07/mammogram-fatty-vs-dense-1024x678.png)

**Figure 7. Mammogram showing the difficulty of seeing cancer in dense breast tissue.** Image credit: [today.com](https://www.today.com/health/do-you-have-dense-breasts-you-may-need-more-mammogram-t104102)

*Why do some women retain extra glandular tissue*?

- Nobody really knows why some women retain that extra glandular tissue and in other women it turns to fat
- So for women who are post menopausal, or if they’re pre-menopausal in their childbearing age, and they still have a lot of glandular tissue… that means **a mammogram might not be enough**
- Therefore they need another second imagine modality to look through the tissue such as ultrasound and/or MRI

[**Sensitivity and specificity of a mammogram**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4537675/)

Peter estimates from his memory that…

- A mammogram had a sensitivity of about 80, (call it ~84%)
- And a specificity of about 90% or 91%

*⇒ Does that sound about right?*

- It depends actually, says Raj
- It actually becomes really critical in the fact that depending on the breast density, you’re going to know how helpful a mammogram may or may not be

Comparison over time:

- One of the other things that becomes actually very, very powerful in the mammogram is to actually use comparison over time
- That’s why they recommend **screening intervals** of either one or two years
- That’s a matter of academic debate, however…
  - If you have a mammogram taken, and then let’s say two years later you do another one, it’s actually **far more sensitive to see that subtle change over time** than it is to actually look at an individual mammogram all on its own
  - A single mammogram on a dense woman, its sensitivity is about 55%
  - It’s actually quite poor, whereas on a woman who actually has fatty tissue… *it’s very high (***up to 95%***)*

**Explaining sensitivity and specificity**

*When we say a mammogram has an 80%* ***sensitivity****, here’s what we mean:*

- If there are 100 women who have breast cancer
- And we subject them to a mammogram
  - 80 of them will test positive (correctly)
  - But 20 of them will test negative **(incorrectly)**
- The sensitivity is the true positive rate over the true positives plus the false negatives
- The higher the sensitivity, the less likely you are to take someone who has the cancer and miss them.

*What does it mean to have 90%* ***specificity****?*

- Take 100 women who we absolutely know DO NOT have breast cancer
- After you do a mammogram on all of them…
  - 90 of them will correctly identify as NOT having breast cancer
  - But 10 of them will be found to have breast cancer (**incorrectly** positive)
- So, the specificity is the number of true negatives over the true negatives plus the false positives.

⇒ *A woman whose breasts are very fatty* (i.e., not glandular)… you’re driving that specificity up (i.e., *reducing* the number of false positives)

*⇒ A woman who might have very, very dense breast tissue*… you may drive your sensitivity down to 50%.

- That means on a given day half the women that walk into your clinic who have breast cancer are going to be told they don’t have it
- “It’s like flipping a coin.”

> “It makes you realize you can’t just rely on one test, especially when that one test has such low sensitivity and specificity, depending on the individual.”

**How close are we to having artificial intelligence in mammography?**

- Many people think machine learning and AI will invariably infiltrate medicine
- It seems to me that one of the best places for it to do so is in comparative radiology
- How close are we to using AI to help perform and read mammograms?
  - Many companies are trying
  - It’s more used as a “second look” in combo with a person

*Can we get north of 97/98% on specificity and sensitivity?*

- “I think that’s a pretty high target to achieve.”
- The biggest problem is because we’re so unique
  - The way the breast is compressed
  - The way everything is done when a mammogram is taken is somewhat different each time
  - The amount of coverage is a little bit different each time.
- “It’s possible, but are we there yet? No…but we’re getting better.”

**What is** [**molecular breast imaging**](https://www.mayoclinic.org/tests-procedures/molecular-breast-imaging/about/pac-20394710) **(MBI)?**

- A lot of radiation, close to 20 millisieverts, which is about 40% of your annual radiation limit
- It’s a functional test in the realm of nuclear medicine
- We’re actually taking radioactive material, and then we’re actually injecting it into the body
- Tissues that actually have increased mitochondria (like in breast cancer), will concentrate a radiotracer called [sestamibi](https://en.wikipedia.org/wiki/Technetium_(99mTc)_sestamibi)

*⇒ Is that test still done?*

- Rarely, but it can be done in women who actually have very, very dense breast tissue, and you actually need to see what’s going on. It can be done, but a lot of it’s actually been replaced with [positron emission tomography](https://en.wikipedia.org/wiki/Positron_emission_tomography) scans

## Magnetic resonance imaging (MRI): How it works, defining terms, and looking at the most common types of MRI [1:03:45]

- “*It doesn’t get a lot more complicated than an MRI.*”
- “*It’s really an engineer’s dream.*”

*Who the heck thought of this?*

- [Peter Mansfield](https://en.wikipedia.org/wiki/Peter_Mansfield) is actually one of the main creators
- The MRI machine really it’s actually quite the amazing tool
- It actually wasn’t initially developed for imaging. It was actually just developed on a bench top where they’re actually kind of looking to see what the effect of electromagnetic waves does to anything.
- Somebody will wind up sticking tissue in it and said…
- What goes in one side comes out a little bit differently on the other side. As a result we can actually determine what that composition and material was.

*Does that mean the NMR was really the precursor to the MRI?*

- It’s the exact same device, the [NMR](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy) basically is just a *two dimensional* version of the MRI which is three dimensions

![](https://peterattiamd.com/wp-content/uploads/2019/07/NMR-spec-768x1024.jpg)

**Figure 8. Image of an [NMR spec](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy)** **that is a 900 MHz NMR instrument with a 21.1 Tesla magnet at HWB-NMR, Birmingham, UK.** Image credit: [faulresearchgroup.com](https://faulresearchgroup.com/2012/03/08/emily-visits-birminghams-biomolecular-nmr-facility/)

**Physics to understand how an MRI works**:

You take a molecule like alcohol…

- It’s got these two carbons that are joined
  - The first carbon has three hydrogens around it
  - The next carbon has a hydrogen and a hydrogen, but then instead of the third hydrogen, it gets an oxygen which is bound to a hydrogen (That is the stuff that people drink and get drunk on)
- Put that into a nuclear magnetic resonance machine (MRI), and you’re going to see different peaks
  - It’s going to show you that there is a methyl group somewhere
  - It can’t tell you what it sees, but it tells you that there’s a carbon bound to three hydrogens

*⇒ How does it do that?*

\*NOTE: Raj is going to use the term hydrogen and proton interchangeably\*

First, when we look at the [NMR spectroscopy](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy) …

- It’s basically a magnet that’s creating a field and somehow through that we can see how the hydrogen is bonded to either the oxygen or the carbon in the ethanol molecule
- The [NMR](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance) is really just a hydrogen/proton detector
- The way the magnetic field of hydrogen behaves is completely different depending on if it’s attached to either the oxygen and OH of alcohol, or the CH3 of carbon
- It actually gives off a different wavelength
- As a result, that’s how we’re actually able to get this, what we call NMR Spectra.

Next…

- [Raymond Damadian](https://en.wikipedia.org/wiki/Raymond_Damadian) is considered to be the father of MRI
- He realized that we can we actually put a human in to see the soft tissue
- Our body is composed of roughly 70% water
- So here’s a lot of hydrogen on fats, so can we see that frequency difference
- If we’re 70% water, that’s 2:1 hydrogen over oxygen there, and then all the fat that’s in us is all the hydrogen to the carbon there.
- There’s basically hydrogen in protein as well.

MRI is a hydrogen imager

- An MRI is a hydrogen imager
- Basically, we’re looking at hydrogen nuclei, which is a proton
- People actually talk about proton spectroscopy, which is NMR, and MRI is just basically a simple hydrogen imager

**Magnets of the MRI**

How it is measured:

- Typically, it’s regarded as a [tesla](https://en.wikipedia.org/wiki/Tesla_(unit))
- A tesla is roughly 10,000 [gauss](https://en.wikipedia.org/wiki/Gauss_(unit))
- A gauss is effectively what the North Pole can produce
- When we actually get into the MRI field, it becomes so much stronger

*How strong is the magnet and why does it need to be so strong?*

- The reason we actually need that high tesla field strength is because…
  - We’re actually taking hydrogen (which is typically not that magnetic compared to like a magnet that we think about)
  - And we’re trying to orient that little dipole of the water molecule or fat molecule, a certain direction
  - That’s what the static field does, and that’s why it has to be so strong.

*MRI machines have different levels*:

- 1.5 Tesla
- 3 Tesla, which is double the strength,
- 7 Tesla
- And so on.
- The higher the Tesla they go, the more it’s actually able to pull all of the hydrogens and orient them in one direction

*Normal position of our body’s hydrogen molecules*:

- Normally our hydrogen molecules are bouncing around randomly, pointed at any which direction, and that there is no kind of magnetic component to us
- When you go into a strong magnetic field, these hydrogens basically kind of turn and orient themselves in that direction
- And so that’s what actually provides the initial basis for an MRI

*How the MRI is actually working*:

- The way it works is you actually have a superconducting wire that’s actually running just above absolute zero degrees Kelvin
- You can never turn that off.
- Pumps are constantly on to keep it cold so that when you actually put an electric field in like a loop of wire, that electric field is what actually generates the magnetic field in a perpendicular direction

*What is the direction right now that that magnet is being oriented?*

- Now, if we were to walk in the scanner today, there’s a bed running through a donut
- The donut is where that loop of superconducting wire is sitting in,
- Most of the time the north will actually face away from the control center, and that’s the direction of north

*What is the right hand rule on this*?

- It can tell you which way the power and the coil is going
- If you’re looking from the foot of the bed, it’s actually going in a clockwise circle, and that’s the right hand rule.

*If you walked into a room where there was a 10 or a 20 Tesla magnet, what do you feel anything, and would it do anything to you that is harmful*?

- The actual magnetic field won’t do that much
- When you get very, very strong to a moving magnetic field, you can actually start to feel it because it can actually trigger your *nerve impulses* to start moving
- Sometimes people actually get twitching
- Sometimes people describe getting temporary headaches, and as soon as they step away from the field, it all goes away

**Why does an MRI take so long?**

*If you just wanted to get an MRI of the abdomen, that could easily take 40 minutes. Whereas, a CT scan of the abdomen can take two minutes. What’s the deal?*

- It’s the way the images are acquired, they’re a completely different mechanism
- If you go back and talk about the X-ray, it’s basically like a single flash where you’re actually looking through everything
- CT is basically this X-ray that’s constantly on, spinning around and basically sort of circulating around you.
- Whereas, the MRI behaves completely differently
  - During the period of time of that acquisition, what it’s doing is, everything that’s inside the center of that donut is being pulled in a certain direction, all the hydrogens on your water and fat.
  - The loud part of the MRI is actually a temporary magnetic field, which is countering that static field, and so it’s actually now pulling all the hydrogens in the opposite direction.
  - And then in that opposite direction, it actually turns off, and then the hydrogens reorient to where they were in that static field.
  - As they reorient, they actually give off a different frequency, and that different frequency takes a while to gather, and that’s what we call the TR, or repetition time, or the TE of the echo time, and that you can’t speed up.

**MRI terms**

- [TR](https://mriquestions.com/tr-and-te.html) is the repetition pulse time
- [TE](https://mriquestions.com/tr-and-te.html) is the time it takes to relax back to its original position
- [T1 weighted image](https://radiopaedia.org/articles/t1-weighted-image?lang=us) is the one that’s really anatomically beautiful where you know what you are looking at
- The [T2 weighted image](https://radiopaedia.org/articles/t2-weighted-image?lang=us) seems to highlight water more… so things that are water look more white, but it doesn’t have the anatomic resolution

*How do you differentiate those T1 vs T2 images*?

- On the T1 image
  - we actually see nothing but fat
  - Fat gives a lot of signal, which is what makes a nice and bright
  - We see a single element that the hydrogen would be bonded to that we’re looking at.
- Whereas, a T2,
  - we’re actually now seeing two elements.
- We’re seeing fat and water,
  - and so those two elements are actually coming off at different frequencies from the MRI machine and you have to wait a longer echo time to be able to pick up the water, because it returns back to normal, much more slowly than the fat does.
  - T2 weighted images take longer to acquire, because the TE is long, because you have to wait to get both fat and water.

*What’s the difference in the TR between the T1 and T2?*

- It’s all going to be entirely dependent on the machine,
- so you actually have to customize those parameters for every single machine.
- And so, that actually kind of takes a while to actually kind of go and calibrate and kind of get used to what your eyes’ used to seeing,
- and it’s also going to be dependent on the signal, the overall magnetic field,
- and there’s overall signal to noise for that coil set that you’re using.
- Each one has to be effectively tuned.

![](https://peterattiamd.com/wp-content/uploads/2019/07/T1-vs.-T2-933x1024.png)

**Figure 9. T1 vs. T2 images. Brain (top), spine (bottom).** Image credit: [casemed.case.edu](https://casemed.case.edu/clerkships/neurology/Web%20Neurorad/MRI%20Basics.htm)

**Three main categories of MRI sequencing**

1. Conventional spin echo
2. Gradient imaging
3. Echo planar imaging (EPI)

*Conventional spin echo*

- Basically just waiting as long as you can for the hydrogen to completely relax and give off both its water and fat signal

*Gradient imaging*

- You’re not waiting for it to completely return back to normal, but somewhere in the middle, you’re actually kind of repulsing again
- You’re basically hearing that noise of the machine turning back on and saying, “We’re not going to wait until it completely relaxes, we’re going to fire up again.”
- H*ow many milliseconds, if you’re trying to get a T2 signal, and you’re waiting for that full relaxation, how many milliseconds is that, directionally*?
  - Up as high as 60 milliseconds, or even longer for some of them
- W*hen you do these gradient-based tests where you’re going to repulse, how quickly are you repulsing*?
  - You can actually repulse in two milliseconds, or even faster

*Echo planar imaging (EPI)*

- “This is actually amazing.”
- Instead of just looking at a single slice of a person, you’re actually now running multiple slices simultaneously where you’re actually putting two different fields on the person at the same time

⇒ *Raj explaining* ***gradient***: “What a gradient basically means, it’s effectively like a ramp from a low number to a high number. If I was looking at you, and I said, ‘We’re going to start the image from your top down, first we’re going to put a gradient on from top to bottom, so it’s going to be a little bit of a higher frequency at the top, a little bit of a lower frequency lower down, and then we’re actually also going to look at phase from right to left. Depending on how your body’s oriented and where the blood flow is going to be, we’re going to look at phase and frequency, which now will bring us into the realm of a Fourier transform’. With the pulses, we’re effectively looking at all these repetitive sign waves, and we’re actually plotting that in frequency and phase domain.”

***The Fourier transform***

*How does one get into MRI radiology without a background in mathematics and physics?*

- “It seems it would be impossible”, says Peter
- “It’s a struggle” says Raj

“The difference with the MRI is that you start in this Fourier domain, and because we’re a three dimensional object, when you’re looking at a two dimensional plane, that’s the [Fourier transform](https://en.wikipedia.org/wiki/Fourier_transform). When you’re now at that third dimension, it becomes what we call k-space, so it’s effectively a two dimensional Fourier transform, which is what the MRI world operates on. It’s called k-space.”

**What types of MRIs are the most common?**

The most common ones that people have:

- [MRI of the knee](https://www.radiologyinfo.org/en/info.cfm?pg=kneemr)
- [MRI of your back](https://www.healthline.com/health/lumbar-mri-scan)
- [MRI of the head](https://www.webmd.com/migraines-headaches/making-diagnosis-mri)

**ACL injury**

*What sequences would be run today, if you wanted to evaluate someone’s ACL?*

- First, you’ll want the anatomy image, so that’s our plain T1 because “fat is beautiful, and it actually allows us to see everything really well, and it looks like what we’re actually accustomed to seeing.”
- Secondly, we’d do a T2 fat sat sequence (fat saturation)
  - A T2 image looks at fat and water, and then we actually *suppress the fat*, so really all we’re seeing is water
    - *Why?* ⇒ because of [edema](https://www.mayoclinic.org/diseases-conditions/edema/symptoms-causes/syc-20366493)
      - Edema, when there’s something going wrong in the body, almost anywhere, edema happens
        - You bang your hand and it swells up, that swelling is edema.
        - You injure your knee, it swells up, that’s edema
    - That’s kind of a simple concept in MRI that is quite often lost, but it’s very, very important.

![](https://peterattiamd.com/wp-content/uploads/2019/07/ACL-tear-T2-MRI-1024x1019.png)

**Figure 10. ACL tear: “Non-visualization of the ACL fibers indicative of complete tear. Posterior horn medial meniscus tear is seen as well.”** Image credit: [radiopaedia.org](https://radiopaedia.org/cases/anterior-cruciate-ligament-tear-complete-3?lang=us)

## Brain aneurysms: Using MRI to find them and save lives [1:23:45]

\*[See video of Peter’s brain imaging](https://www.instagram.com/peterattiamd/p/BwVyo4ZgpRA/?hl=en)\*

**Brain scans:**

- One thing that stands out is the *exquisite anatomic detail* you’re getting (far better than a CT scan)
- Secondly, it’s the fact that **without any contrast**, you’re able to see as though you did an [angiogram](https://en.wikipedia.org/wiki/Angiography) on all the vessels in my brain

*⇒ How is this happening*?

- MRI is a hydrogen imager, but it’s also a big powerful magnet
- What makes our blood red is actually the iron that’s contained within it
- So what you can do is take all the blood that’s flowing to a particular organ like the head
- And you can actually “excite” anything going up north to the brain (and so therefore that’s arteries)
- So you get to see all the exquisite arteries in your brain just by exciting that blood
- Directionall,y it’s so clear, you know which way your magnet is oriented, you know which way blood flow away from the heart, and you’ve got this beautiful iron floating around in water

That’s one of the beauties of MRI…

- You can actually excite anything flowing in one direction
- But you can actually also pick off the frequency that’s different between oxygenated arterial blood and deoxygenated venous blood
- A different sequence called SWI or [susceptibility weighted imaging](https://en.wikipedia.org/wiki/Susceptibility_weighted_imaging), where you can actually look at the deoxygenated status of venous blood and you can get *spectacular contrast to the small blood vessels in the brain using that sequenc*e

![](https://peterattiamd.com/wp-content/uploads/2019/07/swi-brain.png)

**Figure 11. SWI Image acquired at 4 Tesla showing the veins in the brain.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Susceptibility_weighted_imaging#/media/File:SWI_4Tesla.png)

**Brain aneurysm**

- You can treat brain aneurysm electively quite easily, however… once they rupture, the mortality’s incredibly high
- The [**mortality of a ruptured aneurysm is 93-95%**](https://bafound.org/about-brain-aneurysms/brain-aneurysm-basics/brain-aneurysm-statistics-and-facts/)

*Treatments:*

- When you do find them earlier, there are life-saving treatment options, such as:

1. [Coiling](https://www.hopkinsmedicine.org/neurology_neurosurgery/centers_clinics/aneurysm/treatment/aneurysm_endovascular_coiling.html)
2. [Clipping](https://mayfieldclinic.com/pe-clipping.htm)

*What is the frequency of aneurysm in the brain?*

- Raj scanned about a thousand people and found *8 intercranial brain aneurysms*, **so 0.8%**
- The literature is actually a little bit less… likely because when the elderly pass away it’s “natural causes” and we don’t do autopsies

*Less lethal than cerebral aneurysms (but still deadly)*:

- Splenic artery aneurysms
- Popliteal artery aneurysms

⇒ *Do you see those, and if so, at what frequency*?

- [Splenic artery aneurysms](https://wikem.org/wiki/Splenic_artery_aneurysm)
  - Found 2 of them
  - But *they actually are* particularly deadly
- [Popliteal arteries aneurysm](https://en.wikipedia.org/wiki/Popliteal_artery_aneurysm)
  - Haven’t seen many of those
  - Those are actually easier to feel and to see and to look at (You can palpate those on a thin enough individual)

*Genetic component of aneurysm*

- This may be showing the genetic component to it, says Raj
- When you find it in one person in the family, next thing you know all of their extended family may need to be checked

*⇒ Peter’s patient*:

- A young woman, mid- to late-thirties, whose mother died very young from an aneurysm
- Dug into her family history further, we found another person who had died of an aneurysm in yet a different part of the body
- Peter petitioned her insurance company to pay for an MRA, a [magnetic resonance angiography](https://www.radiologyinfo.org/en/info.cfm?pg=angiomr), but they declined it
- Finally, the woman just paid out of pocket for it ($9,000!)
- Results were negative, so we were happy, but she’s lucky she could afford this whereas most people cannot which is unfortunate especially if you have a family history

![](https://peterattiamd.com/wp-content/uploads/2019/07/modality-comparison-screenshot-1024x927.png)

**Figure 12. Comparison of imaging modalities for detection of general findings in the body.**

## Raj’s unique MRI technology [1:30:00]

The following video is, admittedly, \***promotional**\* in nature for the company Prenuvo, but we felt it necessary to include here as it does allow the viewer to get an understanding of the robust capability and usefulness of Raj’s MRI technology *without any radiation exposure* to the patient:

*Why does Raj use a smaller magnet with his MRI equipment*?

1. Many hospitals “brag” about the size of their MRI magnet (usually a 3 or 4 Tesla magnet)
2. But Raj uses just a 1.5 Tesla magnet

*⇒ Why?* ⇒ He wants to maximize the **“signal to noise”** ratio

- It really depends on how you **tune a magnet** because we are dealing with wavelengths  from an electromagnetic field
- The 3 Tesla wavelength is roughly 15 centimeters (the width of your head)
- 1.5 is roughly 30 centimeters (the width of most people’s shoulders)
  - As a result, you get a lot more penetration with a lower field magnet
  - So you’re able to see things quite well when everything is tuned to that particular wavelength
- There are about 150 parameters per T1, T2 fat saturation sequence that you can actually adjust to make it work the way you need it
- Most of the time, they will set the standard parameters and from there on you push one button
- *In contrast, Raj wants to maximize the **“signal to noise”***
  - In other words, Raj wants to understand how it all works, how it can be optimized to the person that’s coming in, and how the entire system from front to back is optimized
- “When you maximize your signal to noise, that’s when you actually really get a lot of speed and detail.”

*⇒ Analogy*

- Peter, of course, compares Raj’s dialed in machine to the best F1 cars in history
- The [McLarenMP4/4](https://en.wikipedia.org/wiki/McLaren_MP4/4), for example, is regarded as either the greatest or second greatest Formula One car in history, yet it only had a 1.5-liter engine (probably smaller than a Prius)
- Yet it produced 1200 horsepower red lining at something like 15,000 rpm
- How? Well, the engineering technique makes the difference
- “*But, most people don’t think that way. They think bigger is better.*”

*How did Raj manage to tinker with 150 variables to produce such a uniquely powerful machine?*

- Raj is an engineer at heart who works in medicine
- He worked backwards, starting with the questions, “What do I want to know? What do I want to see? How do I make it work?”
- From there he spoke to the MRI physicists who really know this equipment
- Many times the physicists would write up a new sequence and ask Raj to test it out so Raj would scan himself and then look at the results from a functional point of view, as well as an imaging perspective

*When creating this machine, what were you optimizing for?*

**1 The first thing** I wanted to do is to optimize the dose or radioactivity in order to cover everything from head to foot ⇒ In radiology, typically we’re just doing a snapshot of an individual part (like a head or a neck or a torso)… but Raj wanted to see **how it ALL works**

**2 Secondly**, Raj wanted to customize his hardware to allow him to move people around while they’re on the table while they’re laying there to be able to connect the head with the neck, with the chest, with the abdomen…

- Once the hardware was pieced together, he started to test and test while talking to more physicists

**3 Third**, he thought about the patient’s point of view…

- Raj thought about… “If I’m a patient, what would I want to know?”
  - **Number 1**: I’d want to know that my brain’s okay (arteries in my brain are okay, they’re not going to rupture)
  - **Number 2**: “Do I have cancer? Yes or no?”
    - In nuclear medicine, most of the tests are binary, we can actually answer that with a yes or a no.
    - In radiology, it’s not so clear, it’s kind of like maybe (playing more statistics and probability)

*⇒ So the question was… “How do I marry these two together?”*

- Raj decided to combine the following:
  - MRI… which actually allows you to take that “yes or no” binary answer of functional nuclear medicine in terms of cancer
  - Combined with…
  - The anatomic localization, and understanding of tissue types that radiology has

> “I merged those two together onto one machine.”

**What is the functional arm that you’ve brought into it?**

[Diffusion weighted imaging with background subtraction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2516183/) (DWIBS)

- DWIBS is looking at water at two points in time… within about 60 microseconds of water motion
- If the water hasn’t moved between the two points in time, it’s because it’s effectively trapped between walls
  - *Why?* ⇒ i) There’s a tight cell membrane or ii) components of a cell are preventing that water from moving

*What do you infer clinically about that tissue?*

- When water isn’t moving, that means that there’s going to be a **high density of cells** there
- Raj calls it the lump detector
  - E.g., with breast cancer, women are able to feel a lump themselves quite easily and what they are feeling is a dense cluster of cells

Peter: “It’s actually unmistakable what cancer feels like to the touch because it is so in contrast to what normal tissue feels like … it’s entirely obvious just based on the **firmness of the tissue.”**

**Summarizing Raj’s unique equipment**:

> “We’re actually combining the anatomic and functional. Just like that on the PET-CT where that famous ‘one plus one equals three’… that is exactly what we were doing. And the beauty of it is there’s absolutely no radiation, so there’s no risk.”

![](https://peterattiamd.com/wp-content/uploads/2019/07/Sample-of-the-high-resolution-anatomic-and-functional-images-taken-during-a-Prenuvo-scan-1024x661.png)

**Figure 13. Sample of the high resolution anatomic and functional images taken during an MRI scan with Raj’s Prenuvo scanner. The multiple sequences, tissue planes and high signal to noise functional DWI images allows for precise tissue characterization and anatomic localization.**

## The risk of false positives in cancer detection, and how Raj’s MRI can reduce the number of false positives (i.e., increase specificity) [1:43:40]

**The risk of cancer screening**

Since there is no radiation with an MRI, the real risk is that of a false positive, says Peter

- The harm can manifest in 2 ways:
  - 1) Physical harm
    - Meaning by something we do subsequently, for example, another biopsy or a biopsy or a subsequent biopsy that was unnecessary
  - 2) Emotional harm
    - E.g., The toll it takes on you to see a shadow in a part of your body and have to sit there and have a discussion about what it could be… “it’s probably a cyst, but it might be a tumor, we probably need to do X,Y,Z.”

*What is the sensitivity and specificity of Raj’s equipment?*

- Raj looks at the sensitivity and specificity organ by organ
- For example, in the liver, the simple thing we want to kind of note, “Is there a problem? Yes or no?”
  - By combining this functional as well as an anatomic imaging together, we’re actually really able to nail that down

**Raj had two cases of a false positive in 1,000 cases**

*1 Male with false positive for breast cancer*

- The DWI showed a difference in density between one breast and the other
- He then got an ultrasound which also showed something but weren’t sure what it was
- He then got a biopsy and it came back as normal (he had breast glandular tissue)
- *⇒ So let’s talk just about the harm there…*
  - Emotionally, that man probably a ton of time being stressed out about this
  - Secondly, he had to get a procedure, he had to get a needle stuck into his breast tissue

*2 Woman in her late fifties with a false positive for breast cancer*

- Turned out that she had an unusual scar on her breast from a bad car accident that trapped fluid in it

**What is the scariest false positive?**

- Most concerning are the false positives that occur *deeper in the body*
- Peter says the little shadow in the pancreas, where you just don’t know it was this in [Adenocarcinoma](https://www.cancercenter.com/adenocarcinoma) (fatal) or something that isn’t cancer at all

*⇒ Famous cautionary tale of a false positive:*

- At Stanford several years ago where a woman who got a CT scan which showed something in the pancreas
- Got an ERCP guided biopsy
- One complication led to another, led to another and she died of sepsis
- And it turned out she didn’t have pancreatic cancer

> “That’s kind of where the real value of actually having MRI’s as opposed to CT comes in. The fact that when we’re looking at organs, in particular like the pancreas or any of the visceral solid organs, we’re looking about seven different filters, looking at it different ways, top to bottom, front to back to really be able to see what’s going on. That’s where what we call ‘contrast density’ becomes really important . . . we can actually pick out the pancreatic duct as well as a bile duct and be able to see that just standing out against the rest of the organ.”

## The unique software Raj created to pair with his MRI machine [1:51:15]

Raj created software to show a rotating diffusion weighted image map

- The display tool is effectively taking a page out of the nuclear medicine, positron emission tomography or PET-CT handbook
- Allows you to view everything going on through the entire body (like making it transparent person where any of the black spots that stand out would be the hard spots or the firm areas)

Some advantages of using a “low power magnet”:

- Zero gaps in the spine
- You had the dark brain (obviously full of firm fluid)
- Then you have this dark beautiful tail coming out of it, which is the spinal fluid, but it was perfectly smooth
- That’s actually one of the important things because magnets actually have a lot of “homogeneity problems”
- The fact that you want it to be perfect so that the field in between the top and the bottom and the left and the right are identical
- As soon as you put a person in there, that comes in various sizes and shapes, they actually distort that magnetic field… we actually built it so we can actually **go and tune it for all these body shapes**

“*It looks just like you’re looking at the FDG-PET juxtaposed with the CT*” says Peter

![](https://peterattiamd.com/wp-content/uploads/2019/07/Coronal-Prenuvo-sequences-compared-with-the-fragmented-low-resolution-images--1024x686.png)

**Figure 14. On the left is a sample of 2 coronal sequences with Raj’s Prenuvo scanner compared with the 2 images on the right of fragmented low resolution images from another ‘whole body imaging facility’ in USA.**

![](https://peterattiamd.com/wp-content/uploads/2019/07/detail-of-the-kidney-and-liver-1024x685.png)

**Figure 15. On the left is zoomed in images showing the detail of the kidney and liver taken during a scan using Raj’s Prenuvo compared with another ‘whole body’ MRI facility.**

## Comparing the radiation exposure of a whole-body PET-CT to Raj’s equipment (DWIBS-MRI) [1:53:40]

- A whole body PET-CT is close to 80% of your annual allotment of radiation
- But putting aside that issue (which is not trivial)…

*What advantage do you think that the MRI with DWIBS has over the PET-CT?*

- The PET-CT uses radioactive glucose and so it makes the following difficult
  - Brain imaging: You can actually miss things in the brain because of what you’re looking for with the radioactive glucose is areas of increased glucose utilization but glucose is it can use (other than ketones)
  - Kidney imaging: Glucose is excreted by the kidneys so the kidneys now become difficult to see because they’re actually full of glucose
  - The bladder: You can’t see a thing in the bladder because it’s full of the accumulated glucose
  - The prostate: The prostate is very poorly perfused and as a result it doesn’t get a lot of glucose coming to it… so PET is actually almost entirely useless with FDG and looking at the prostate

## How diffusion-weighted magnetic resonance imaging (DW-MRI) has revolutionized cancer screening [1:55:15]

**Prostate cancer screening**

Peter says that DWI of the prostate coupled with the more advanced molecular tests (e.g., the 4K as an example of a blood test) has **totally revolutionized the way we think about prostate cancer**

⇒ The power of MRI

- Peter has had two patients for whom PSA was high, and 4K was high
- This means they now have a 20% chance of having cancer in their prostate…  OR having metastatic cancer over the next two decades
- In the old days… we would’ve just *biopsied them*
- But nowadays… we run them through MRI and the answer many times is “nope, it’s totally fine.”

**The ubiquity of prostate cancer**

- One of the things that people are actually finding with the screening for the prostate is that **all men are either going to die with or from prostate cancer** …
- … so you really want to be able to separate those out
- Prior to MRI with DWI, there was no real way to figure that out…  We’d be doing PSA or 4K and all that would do is say there is an increased risk of something going on… *But is it going on??*
  - For example, the PSA can be elevated for three reasons:
    - 1) Prostate cancer
    - 2) Inflammation or prostatitis
    - 3) An enlarged prostate

*MRI can prevent unnecessary biopsies*

- In the past, if PSA was high, you would go immediately to biopsy
- Today we can first use an MRI to look and see if something’s growing in the prostate at an accelerated rate (and that’s when you might want to address it)
- Whereas if it’s actually just there and holding still and not changing much, I’m not going to worry about it because something else may take me first

**Is DWI going to have the same effect on breast cancer?**

*Resources aside, if a woman combined a mammography with a DWI MRI, are you going to miss any breast cancer in those situations?*

- “Pretty unlikely”
- [Big study out of Memorial Sloan Kettering in New York](https://www.ncbi.nlm.nih.gov/pubmed/31136044) found that if you actually use DWI with MRI, you actually are as sensitive as giving a contrast injection breast MRI
- \*But that’s diffusion done right, and the problem is in many cases it’s NOT done right

![](https://peterattiamd.com/wp-content/uploads/2019/07/solid-8mm-breast-cancer-lesion--1024x387.png)

**Figure 16. Using Raj’s unique MRI machine, this is a combination of detailed anatomic images with the functional image (white background) which demonstrates a solid 8mm breast cancer lesion (in red circle) which cannot be readily delineated on other sequences.**

## Why a DW-MRI is still not a perfect test [1:59:00]

- The biggest problem with MRI is that it has no standardization whatsoever
- There’s actually a movement called [Quantitative Imaging Biomarkers Alliance](https://www.rsna.org/en/research/quantitative-imaging-biomarkers-alliance) (QIBA) trying to push to standardize the amount of signal to noise coming off of MRI machines with the goal that if you get a scan at one site or another site, the image quality is the same

*What is standing in the way?*

- It actually relies on the vendors coming together
- This is fortunately starting to move forward with this organization, [QIBA](https://www.rsna.org/en/research/quantitative-imaging-biomarkers-alliance) of [RSNA](https://www.rsna.org/en) and they’re doing it organ by organ (e.g., for standardizing breast MRI screening)

It’s really unfortunate…

- …Because this is of all the imaging tools, MRI is the most powerful
- But it really does need the stability for standardization.
- In order to make it standardized, you need to get the physicist together with the radiologists
- But quite often that doesn’t happen because of the language barrier, the **language of physics**

## The potential for advancing MRI technology: Where does Raj think it could improve in the next 5-10 years? [2:03:00]

*What does Raj want to see in the next 5 or 10 years that would improve the technology?*

- More speed!
- “What I’d actually like to do, and when you see sort of what we’re doing, the speed with which we do and that the detail and resolution that we’re able to acquire and about 55 minutes is really unprecedented anywhere, but I know from a physics point of view that I could speed this up further.”
- **GOAL**:  To have these scans that under half an hour, or even faster,

> “*It can be done from a physics point of view. It’s not a technological barrier.*”

***What makes it so uncomfortable by the end of the scan in terms of body temperature*****?**

Part of the reason for speeding up the MRI is because of the heat that is produced making it uncomfortable for the patient

- The heat is due to the amount of energy that’s being absorbed
- The radio frequency is the same thing as a cell phone called SAR or a Specific Absorption Ratio
- The hydrogen ions are basically moving around and that’s basically effectively heating you up
- So it’s not quite like a microwave, but you can actually think about it as a microwave

Head to toe

- We do the head first and that’s not nearly as much as doing mid and lower body
- The thighs, for example, are probably where a ton of that heat gets generated right
- When you look at basically the overall blood flow, which is what cools your body, the brain takes 20% of your cardiac output (it’s this big heat sink…it’s a just cools everything away)
- Whereas when you get down and lower to the legs, which you’re all muscle, it’s going to heat that up, and so that’s why we figured out how to orient these in what organization to make or what plan of sequences to make it not as uncomfortable

## Are there any commercially available scanners that can match the resolution of Raj’s images? [2:06:00]

*Are you scans fully isotropic?*

- “It’s isotropic in the brain, but in the rest of the body we’re actually doing more conventional clinical images.”

*What does isotropic mean?*

- What isotropic basically means is that we’re slicing you in cubes
- So one by one by one millimeter cube, for example
- The power of actually doing that one by one by one, is that you can now look at things again in three dimensions in any direction you want
- The detail and resolution is perfect

*MRI*

- \*Whereas MRI typically can’t be done isotopically just because of time\*
- You want to cover as much as possible, but you want what we call, “in plain resolution”, which is how you orient the first gradient to have the highest amount of detail
- Then you typically will take a perpendicular view
- Peter: “*And that’s why when you do these rotations off your sagittal plane, the resolution deteriorates wildly in conventional scans, right?*”
- Raj: “Right, exactly. And so the diffusion that we’re doing are done isotropic, but unconventional, not often.”

The following video is showing Raj’s cancer detection technique at work. Per Raj, “*This set of videos illustrates the power of functional imaging with MRI, and the utility of isotropic imaging wherein we are maximizing signal to noise to make tumor masses (which are more solid than normal tissue stand out). The way this sequence works is as a lump=hardness detector, thus for cancer detection think of the adage given to women: ‘breast cancer feel for lumps’.*”

*So is there a commercially available scanner that can do that?*

- “Not yet. Someday.”

⇒ For example, the figure below is from a German study which used ‘whole body’ imaging that fragmented the body parts in a way that made insufficient for adequate diagnosis

![](https://peterattiamd.com/wp-content/uploads/2019/07/fragmented-whole-body-images-from-a-german-company-698x1024.png)

**Figure 17. Images from a whole body study which shows fragmented images which do NOT  encompass sufficient detail for adequate diagnosis (from Germany).**

*Raj seems so far ahead of the curve, how is that the case?*

- Well it comes down to basic engineering of signal to noise ⇒ If you can make all the hardware that you have really sing, our signal to noise is so much better.
- Then you can basically dial it to effectively where you want
- So if you need more and more signal depending on your machines. I guess horsepower and coil configuration just takes time. It’s always a balance between time and signal to noise.

![](https://peterattiamd.com/wp-content/uploads/2019/07/Prenuvo-detects-vs-cause-of-death-1024x768.jpeg)

**Figure 18. What Raj’s  Prenuvo MRI can detect for comparison of all causes of death.**

## Machine learning: When and where might machine learning/AI impact the field of radiology? [2:08:40]

- It’s really hard to throw a whole body image at a machine and have it solve even the simplest problem such as differentiating between each organ
- Whereas if you weren’t doing a whole body, if you were just doing a liver image, that’s an easier problem to hand the machine cause it already knows it’s looking at liver

*⇒ How far are we away from a machine being able to help you do this?*

- The goal is to have machines make radiologists more efficient and never miss anything
- We can’t have a second reader all the time, but if you have a machine being a second reader, you wind up actually training that machine as you go along

⇒ Mammography: There are machines assisting radiologists in mammography

*Final thoughts on machine learning:*

- It seems that where the machine might first be able to make a dent in what you’re doing is not the patient who gets their first scan, but the one who gets the repeat scan
- Specifically, the paired t-test seems to be an easier problem to solve but an important problem to solve
- When you actually go and you take a paired of t-test, and you actually do a subtraction of where you’re looking for the difference or that delta, it can actually stand out and become very, very simple and very obvious.
- Once that’s subtraction is done, I think that’s where machine learning will actually really help make us more efficient and at the end of the day, we just don’t want to miss anything.

§

## Selected Links / Related Material

## Links provided by Raj:

**Spreadsheet showing the full list of conditions that Raj’s** [**Prenuvo MRI**](https://aimmedicalimaging.com/mri-vancouver/prenuvo-body-scans-at-aim/) **can detect versus other comprehensive ‘whole body’ scans found at a premier clinic in San Diego (“we have lots of patients who have done both”)**: [Comparison of conditions](https://docs.google.com/spreadsheets/d/1tWhfAwSraBOo3LR-rZWpN-IRNkl29t85KboxIfX6OG0/edit?usp=sharing)

**Overview of radiation from health physics society:** [Radiation and Risk: Expert Perspectives](https://hps.org/documents/radiation_and_risk.pdf) | Health Physics Society (hps.org)

**A nice table of all radiation procedures**: [Doses from Medical Radiation Sources](https://hps.org/hpspublications/articles/dosesfrommedicalradiation.html) | Michael G. Stabin, PhD, CHP (hps.org)

**Radiology Society of North America, Image Wisely, campaign to reduce radiation doses with CT (target CT dosage included in this PDF)**: [U.S. Diagnostic Reference Levels and Achievable Doses for 10 Adult CT Examinations](https://www.imagewisely.org/-/media/Image-Wisely/Files/CT/IW-Kanal-CTDRLs.pdf?la=en) | (imagewisely.org)

- Note from Raj: “*To convert from DLP to radiation dose in mSv, you can use the rule of thumb for body imaging and multiply DLP by 0.017 and you get mSV  ie for chest abdo pelvis with contrast, the achievable dose is 779×0.017 which gives 13mSv. (NB most CT exposures are way higher than this due to SNR issues). All CT studies output a DLP value which can be converted to mSV effective dose by multiplying by an estimator factor which for chest is 0.014, abdo/pelvis 0.020, which gives the average of 0.017 for body  Note that these multiplier estimator factors are stupidly hard to find in the literature, but very valuable for all patients to know in my opinion.*”

**Calculator to determine radiation exposure from air travel (need airport IATA codes, flight time at altitude, ascent and descent)**: [FEDERAL AVIATION ADMINISTRATION OFFICE OF AEROSPACE MEDICINE CIVIL AEROSPACE MEDICAL INSTITUTE](https://jag.cami.jccbi.gov/cariprofile.asp)  | (jag.cami.jccbi.gov)

## Links & Resources mentioned in the podcast interview:

**Raj’s imaging company:** [AIM Medical Imaging](https://aimmedicalimaging.com/) | (aimmedicalimaging.com) [9:30]

**More info about Raj’s Prenuvo MRI scanner**:

- [Full Body Imaging](https://aimmedicalimaging.com/mri-services/full-body-imaging/)
- [Prenuvo Body Scans at AIM-Why full body MRI?](https://aimmedicalimaging.com/mri-vancouver/prenuvo-body-scans-at-aim/)

**Peter’s instagram post about his whole-body scan**: [@peterattiamd 4/16/2019](https://www.instagram.com/peterattiamd/p/BwVyo4ZgpRA/?hl=en) | (instagram.com)

**First telerobotics, telepresence conference ever held in the United States**: [THE FIRST EXPLORATION TELEROBOTICS SYMPOSIUM – TELEPRESENCE: A NEW PARADIGM FOR HUMAN-ROBOTIC COOPERATION.](https://www.lpi.usra.edu/meetings/leag2012/pdf/3012.pdf) (Lester et al., 2012) [13:45]

**da Vinci Surgical System made by** [**Intuitive Surgical**](https://en.wikipedia.org/wiki/Intuitive_Surgical): [da Vinci Surgical System](https://en.wikipedia.org/wiki/Da_Vinci_Surgical_System) | (wikipedia.org) [13:45]

**Anatomic imaging**: [Review of Functional/ Anatomic Imaging in Oncology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3295905/) (Histed et al., 2012) [16:45]

**Cases of death due to radiation from X-ray**: [Early victims of X-rays: a tribute and current perception](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3520298/) (Sansare et al., 2011) [19:45]

**Bombing of Hiroshima and Nagasaki informed us a lot about the dangers of radiation overexposure**: [Atomic bombings of Hiroshima and Nagasaki](https://en.wikipedia.org/wiki/Atomic_bombings_of_Hiroshima_and_Nagasaki) | (wikipedia.org) [19:45]

**The group that sets what a standard dose of radiation is**: [Système Internationale in France](https://en.wikipedia.org/wiki/International_System_of_Units) | (wikipedia.org) [21:00]

**NRC recommends that no one receives more than 50 millisieverts of radiation in a year:** [PART 20—STANDARDS FOR PROTECTION AGAINST RADIATION](https://www.nrc.gov/reading-rm/doc-collections/cfr/part020/full-text.html) | (nrc.gov) [23:30]

**Flying over the poles increases radiation exposure exponentially**: [Thousand-fold Rise in Polar Flights Hikes Radiation Risk](https://www.nasa.gov/centers/langley/science/polar-radiation.html) | (nasa.gov) [24:30]

**Online** [**calculator**](https://jag.cami.jccbi.gov/cariprofile.asp) **for determining how much radiation they’re getting from air travel:** [FEDERAL AVIATION ADMINISTRATION OFFICE OF AEROSPACE MEDICINE CIVIL AEROSPACE MEDICAL INSTITUTE](https://jag.cami.jccbi.gov/cariprofile.asp) | (jag.cami.jccbi.gov) [25:00]

**Incident that exposure many people to radiation that helped us understand the dangers**: [Fuji Molten Salt Reactor](https://en.wikipedia.org/wiki/Fuji_Molten_Salt_Reactor) | (wikipedia.org) [25:45]

**Landmark paper out of Columbia that looked at the amount of radiation that people actually receive from CT scanners which forced radiology as a field to look at the potential damaging effect of X-ray radiation**:  [Radiation Exposure From Medical Imaging: Time to Regulate?](https://www.columbia.edu/~djb3/papers/jama1.pdf) (Brenner et al., 2010) [25:45]

**Even if somebody lost an eye, they can still see in 3D**: [3-D effects may require one eye only](https://www.sciencenews.org/article/3-d-effects-may-require-one-eye-only) | Jessica Shugart (sciencenews.org) [29:00]

**The first CT scanner ever by a company called EMI**: [EMI: Computer and CT scanner](https://en.wikipedia.org/wiki/EMI#Computers_and_CT_scanner) | (wikipedia.org) [31:00]

**Video of how a CT scan works:** [How Does a CT Scan Work?](https://www.youtube.com/watch?v=l9swbAtRRbg) | NIBIB gov (youtube.com) [31:45]

**Elliot Fishman’s 3D images of the pancreas**: [Cinematic rendering of pancreatic neoplasms: preliminary observations and opportunities](https://www.researchgate.net/publication/323832990_Cinematic_rendering_of_pancreatic_neoplasms_preliminary_observations_and_opportunities) (Yang et al., 2018) [35:15]

**How dolphins used sonography that rival that of our finest medical equipment**: [Dolphins use double sonar: Researchers discover that dolphins can generate two sound beam projections simultaneously](https://www.sciencedaily.com/releases/2011/06/110607112338.htm) | (sciencedaily.com) [42:00]

**Type of ultrasound used to see how blood is moving by observing the frequency bouncing off of a blood vessel**: [Doppler ultrasound: What is it used for?](https://www.mayoclinic.org/doppler-ultrasound/expert-answers/faq-20058452) | Sheldon G. Sheps, M.D. (mayoclinic.org) [45:15]

**A type of “fast” ultrasound used in trauma situations**: [Focused assessment with sonography for trauma](https://en.wikipedia.org/wiki/Focused_assessment_with_sonography_for_trauma) | (wikipedia.org) [47:15]

**Mammogram sensitivity and specificity**: [Comparing sensitivity and specificity of screening mammography in the United States and Denmark](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4537675/) (Jacobsen et al., 2015) [53:45]

**History and advancement of mammography and breast cancer screening**: [Advances in Breast Imaging: Evolution & History of Mammography](https://radiology.ucsf.edu/blog/advances-breast-imaging-evolution-history-mammography) | (radiology.ucsf.edu) [1:00:30]

**The radio tracer used in nuclear medicine**: [Technetium (99mTc) sestamibi](https://en.wikipedia.org/wiki/Technetium_(99mTc)_sestamibi) | (wikipedia.org) [1:02:00]

**MRI technology was first developed for looking to see if the effect of electromagnetic waves does anything**: [History of magnetic resonance imaging](https://en.wikipedia.org/wiki/History_of_magnetic_resonance_imaging) | (wikipedia.org) [1:04:30]

**Video of how an MRI machine works**: [How Does an MRI Scan Work?](https://www.youtube.com/watch?v=1CGzk-nV06g) | NIBIB gov (youtube.com) [1:11:00]

**Definition of T1 and T2 weighted images**: [1:16:00]

- *T1 weighted image, “the one that’s really anatomically beautiful*: [T1 weighted image](https://radiopaedia.org/articles/t1-weighted-image?lang=us) | (radiopaedia.org)
- *T2 weighted image, seems to highlight water more, so things that are water look more white, but it doesn’t have the anatomic resolution as the T1*: [T2 weighted image](https://radiopaedia.org/articles/t2-weighted-image?lang=us) (radiopaedia.org)

**A sequence of MRI to look at deoxygenated status of venous blood and you can get spectacular contrast to the small blood vessels in the brain**: [Susceptibility weighted imaging (SWI)](https://en.wikipedia.org/wiki/Susceptibility_weighted_imaging) | (wikipedia.org) [1:25:15]

**Prevalence of brain aneurysm per Brain Aneurysm Foundation**: [Statistics and Facts](https://bafound.org/about-brain-aneurysms/brain-aneurysm-basics/brain-aneurysm-statistics-and-facts/) | (bafound.org)  [1:27:30]

**Peter compared Raj’s MRI equipment (with is “small” 1.5 tesla magnet) to the**: [1:33:15]

- [McLaren mp44](https://en.wikipedia.org/wiki/McLaren_MP4/4) | (wikipedia.org)
- *And the 1993 Williams car*: [Williams FW15C](https://en.wikipedia.org/wiki/Williams_FW15C) (wikipedia.org)

**The “functional” arm of Raj’s hardware**: [Diffusion-weighted whole-body imaging with background body signal suppression (DWIBS): features and potential applications in oncology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2516183/) (Kwee et al., 2008) [1:40:15]

**Big studies by Memorial Sloan Kettering in NY showing that if you use DWI with MRI, you actually are as sensitive as giving a contrast injection breast MRI**: [Diffusion-Weighted MRI of Breast Cancer: Improved Lesion Visibility and Image Quality Using Synthetic b-Values.](https://www.ncbi.nlm.nih.gov/pubmed/31136044) (Bickel et al., 2019) [1:58:30]

**A component of the** [**Radiology Society of North America**](https://www.rsna.org/) **that’s actually really trying to push to standardize the amount of signal to noise coming off of MRI machines with the goal that if you actually get a scan at one site or another site, the image quality is the same**: [Quantitative Imaging Biomarkers Alliance](https://www.rsna.org/en/research/quantitative-imaging-biomarkers-alliance) | (rsna.org) [1:59:45]

**Law that suggests the rate of technology advancement increases exponentially**: [Moore’s law](https://en.wikipedia.org/wiki/Moore%27s_law) | (wikipedia.org) [2:03:30]

§

## People Mentioned

- [Leonardo da Vinci](https://en.wikipedia.org/wiki/Leonardo_da_Vinci) (group named machined after this historic artist and scientist)  [13:45]
- [Wilhelm Röntgen](https://en.wikipedia.org/wiki/Wilhelm_R%C3%B6ntgen) (German mechanical engineer)[19:30]
- [Elliot Fishman](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0000652/elliot-fishman) (radiologist Peter remembers from Hopkins) [34:30]
- [John Cameron](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0001321/john-cameron) (Hopkins Professor of Surgery) [34:30]
- [Charlie Yeo](https://hospitals.jefferson.edu/find-a-doctor/y/yeo-charles-j.html) (Samuel D. Gross Professor and Chair of Surgery) [34:30]
- [Eddy Cornwell](https://huhealthcare.com/find-a-doctor/edward-cornwell-iii) (previous Chairman of surgery at Hopkins and current chairman of surgery at Howard) [50:15]
- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en)  (Attia Medical Research Director) [57:30]
- [Peter Mansfield](https://en.wikipedia.org/wiki/Peter_Mansfield) (one of the main creators for the MRI in the UK) [1:04:30]
- [Raymond Damadian](https://en.wikipedia.org/wiki/Raymond_Damadian) (considered by many as the father of the MRI) [1:08:00]
- [Paul Lauterbur](https://en.wikipedia.org/wiki/Paul_Lauterbur) (chemist who shared Nobel Prize with Mansfield for his work on the MRI [1:08:00]
- [Joseph Fourier](https://en.wikipedia.org/wiki/Joseph_Fourier) (French mathematician and physicist) [1:19:45]
- [Pierre-Simon Laplace](https://en.wikipedia.org/wiki/Pierre-Simon_Laplace) (dorky math joke) [1:20:30]
- [Gordon Moore](https://en.wikipedia.org/wiki/Gordon_Moore) (author of Moore’s law) [2:03:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/07/20190707_000906-500x500.jpg)

##### Rajpaul Attariwala, M.D., Ph.D.

Raj is the Medical Director at [AIM Medical Imaging](https://aimmedicalimaging.com/) in Vancouver.

Over the past decade, he has been effectively creating a new way of doing MRI by fine-tuning the hardware and building unique software to create a completely revolutionary product and process by which to look at the body using the technology of magnetic resonance.

He is a dual board certified Radiologist and Nuclear Medicine physician certified in both Canada and the United States. He received his formal training at UBC with periods of specialized medical training at Memorial Sloan Kettering Cancer Centre (New York), UCLA, and USC.

Raj completed a Ph.D. in biomedical engineering at Northwestern.