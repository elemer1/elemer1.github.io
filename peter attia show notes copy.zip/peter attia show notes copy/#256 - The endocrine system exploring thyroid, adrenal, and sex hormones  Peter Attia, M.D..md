# #256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones | Peter Attia, M.D.

**Source:** [https://peterattiamd.com/endocrinesystem/](https://peterattiamd.com/endocrinesystem/)

---

In this special episode of The Drive, Peter provides a comprehensive overview of the various endocrine systems: the thyroid system, the adrenal system, and the sex hormone system (for both men and women). He walks through the basic biology and the feedback cycles that regulate the production of these hormones and discusses the various options for the treatment of hormone deficiencies. In addition, Peter delves into hormone replacement therapy (HRT), providing nuanced insights into its appropriate usage and the clinical approach he adopts when working with patients.

Peter supplements these explanations with whiteboard illustrations. For a more complete understanding, we highly recommend watching these videos over just listening. The videos can be found on our [YouTube channel](https://www.youtube.com/channel/UC8kGsMa0LygSX9nkBcBH1Sg) or on the [show notes page](https://peterattiamd.com/endocrinesystem).

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/endocrinesystem/the_Drive_public.png)

Play

#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones | Peter Attia, M.D.

#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones | Peter Attia, M.D.

1x15s30s

0:0057:03

## We discuss:

- The thyroid system [2:15];
- The adrenal system [15:45];
- The female sex hormone system [27:00];
- The male sex hormone system [40:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- This is a special episode, in many previous podcasts as well as upcoming podcasts we speak about various hormones
- In these conversations we get into a lot of details, but a lot of times we skip some of the basic biology and treatment implications around these hormones
- As such, this episode will answer a lot of questions we get around the various hormones
- In this video series, Peter uses a whiteboard to draw sketches as he walks through the various [endocrine systems](https://en.wikipedia.org/wiki/Endocrine_system): the thyroid system, the adrenal system, and the sex hormone system (for both men and women)
  - Peter explains how these hormones are regulated, what their feedback cycles are
  - He will talk a little about the treatment of deficiencies of these hormones
- While this episode will be released in audio format (with all the videos combined into one audio), Peter can’t recommend highly enough watching these videos
  - The videos will provide much more understanding around the topics, and as the cliché goes, “*A picture is worth a thousand words*”   ‘

## The thyroid system [2:15]

\*\*\*

![](https://peterattiamd.com/wp-content/uploads/2023/05/f1-hormonewhiteboard.png)

**Figure 1. Hormones that stimulate the thyroid, hormones produced by the thyroid and their inhibitory effects**.

- The [thyroid gland](https://en.wikipedia.org/wiki/Thyroid) sits in front of your larynx
  - You can actually feel it
  - It’s shaped like a shield
- The thyroid is regulated directly via a hormone called [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone)
- TSH is produced by the anterior portion of the [pituitary gland](https://en.wikipedia.org/wiki/Pituitary_gland)
- TSH tells the thyroid gland to make [T4](https://en.wikipedia.org/wiki/Thyroid_hormones) and [T3](https://en.wikipedia.org/wiki/Triiodothyronine)
- The pituitary gland is regulated upstream by the hypothalamus, which stimulates it via a hormone called [TRH](https://en.wikipedia.org/wiki/Thyrotropin-releasing_hormone) (we’ll come back to this)
- The thyroid gland makes mostly T4 and a little bit of T3
- The numbers 3 and 4 refer to the number of iodines in the molecule
  - T4 has 4 iodines
  - T3 has 3 iodines
  - The difference has to do with their biologic activity

***All of the thyroid-promoting functions are controlled by the active version, which is T3***

- T3 keeps you warm, aids in metabolism, controls things like the brittleness of your nails, your hair, bowel function, all sorts of things
- T4 is the inactive version of the hormone

***Most of what comes out of the thyroid is T4, inactive***

- It’s not entirely clear what the ratio is between these, but it’s directionally about 4:1 or 5:1 [T4:T3]
  - Peter imagines that virtually everything the thyroid is producing is T4

**T4 needs to be converted into an active hormone in the body, and that’s where the enzymes called** [**deiodinases**](https://en.wikipedia.org/wiki/Deiodinase) **come in**

- Deiodinases remove one of the iodines from T4 to create T3 (T3 is the active hormone)
- The story gets a little bit more complicated because there are different types of deiodinases, but the three most relevant are D1, D2, and D3
- D1 and D2 are quite similar in that they both convert T4 into T3; what’s different is where they do it
  - D1 is extracellular, it’s on the [cell membrane](https://en.wikipedia.org/wiki/Cell_membrane) facing outward
  - D2 is on the membrane of the [endoplasmic reticulum](https://en.wikipedia.org/wiki/Endoplasmic_reticulum) and it’s facing internal to the [cytosol](https://en.wikipedia.org/wiki/Cytoplasm)
  - Put that aside for a moment and just keep in mind that D1 and D2 both convert T4 into the active hormone T3, and T3 is the one that has all of the positive effects of thyroid hormone
- D3 is different in that D3 takes T4 and makes something called reverse T3
- [Reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) is very similar to T3 except for a very important difference, which is it doesn’t activate the receptor that T3 activates
  - It occupies the receptor without activating it
  - In effect, you can think of reverse T3 as anti-T3; it basically blocks the effects of T3
- It sounds like a very bad idea to have reverse T3 floating around, and unfortunately in the modern world it often is
  - Reverse T3 usually is a sign of inflammation, illness or things of that nature
  - The reason it probably exists is to cope with shortage of nutrients
    - When nutrients are scarce, when you need to slow down metabolism, one of the first things that the body does is it increases the production of reverse T3 to block the effects of T3

**One of the things Peter used to notice when fasting**

- When fasting for a week at a time, he would check his blood pre and post
- He was surprised at how much his thyroid function deteriorated during that period of time
  - How much much his free T3 and reverse T3 changed
- The ratio of free T3: reverse T3 might go from 0.25 (normal) to 0.05 or less in a 5-7 day fast
  - About half of that was due to the reduction in T3, and the majority was due to the increase in reverse T3

***The body is going to regulate these three enzymes in response to various physiologic circumstances, and that’s effectively at the cellular level how the body is controlling thyroid function***

**Evaluating thyroid function**

- This creates a bit of a problem when you want to evaluate a patient for their thyroid status because the traditional way to think about a patient’s thyroid status is just to look at their TSH
- On the surface this makes sense because if everything is working perfectly, the TSH should give you the answer
  - If the *TSH is very high*, there must not be much T3 around because it would be inhibiting TSH [refer to figure above]
  - If *TSH is very, very low*, you would be getting a lot of inhibition from these things [on the figure above], and you would be in a [**hyperthyroid state**](https://en.wikipedia.org/wiki/Hyperthyroidism#Signs_and_symptoms)
- But the reality of it is you can sometimes have a *normal TSH* and still have the symptoms of [**hypothyroidism**](https://en.wikipedia.org/wiki/Hypothyroidism)
  - For example, you have *very high amounts of reverse T3* and very low amounts of T3, in other words, if your T4 is being preferentially shunted into reverse T3 instead of T3, you might feel like you have the symptoms of hypothyroidism
    - You could be cold, your metabolism might be slow, you’d have difficulty sleeping
    - If it were really extreme, your nails might even get brittle, you’d be constipated
    - These sorts of unfortunately nonspecific symptoms which make it difficult to make such a diagnosis at times

**Where does this matter when it comes to how we treat hypothyroidism?**

***To be clear, hypothyroidism is far more common than hyperthyroidism***

- Peter is not going to talk about hyperthyroidism, he’s going to talk about hypo
- The **standard treatment for hypothyroidism** is to give T4
  - We give a synthetic version of this hormone, the inactive thyroid hormone, and we do that with the knowledge that most patients will convert that T4 into T3 (via D1 and D2)
  - The T3 will go on to have all the biologic effects, and it will also suppress TRH and TSH, and the body will come back into line
- For example, if a patient shows up and they have the classic symptoms of hypothyroidism and their TSH is elevated (for example, at 6-7), you might give them 75 mg of T4
  - And you might expect to come back and see that TSH at 2-3 and them feeling better
  - Many times it works out that way, but unfortunately it doesn’t always work out that way
- Sometimes you give a patient T4 and they start to feel worse, and sometimes their TSH actually improves
  - And the reason it improves is T4 does have some inhibition of TSH (not as much as T3, but some)

**What if for physiologic reasons, their D1 and D2 are being down regulated while their D3 is being up regulated, and they’re taking that T4 that you’re giving them and they’re just making more and more reverse T3**

- This may be a person who’s insulin resistant, a person who has low grade inflammation, as these are typically things that we might see drive that state
- That patient, even though their TSH improves, doesn’t necessarily feel better
- For those patients, it might make more sense to actually give them T3
  - Because if you give T3, you’re basically bypassing this system all together, you’re still getting the feedback that’s appropriate, but you bypass the step where the body might erroneously turn the T4 into reverse T3

**Giving patients T3**

- There’s a bit of a problem in giving T3 because the regular version of T3, a drug called [Cytomel](https://en.wikipedia.org/wiki/Liothyronine) is a very difficult drug for patients to tolerate
  - When Peter was in training, they would give T3 to patients after they did [thyroidectomies](https://en.wikipedia.org/wiki/Thyroidectomy) for thyroid cancer, and patients could rarely tolerate it
  - They had to give it to them because they would immediately take all of their thyroid out in one moment, and they needed a big dose of T4, but a hefty dose of T3 to get them over the hump
    - Oftentimes they would feel pretty lousy from that
- Since that time, T3 has largely fallen out of favor, and not many doctors use Cytomel, (which is the trade name for T3) because it is so rapid in its onset

**Instead, people are typically using two other formulations**

- 1 – A **compounded controlled release T3**
  - It’s the exact same hormone T3, but it’s just compounded in a way to be slowly released
  - This seems to be much more well tolerated, and the doses can be pushed a little bit higher
  - A typical dose might be anywhere from 10-25 mg (or even 30) of controlled release T3, and that seems to last a patient throughout the day
    - Patients have to take this generally in the morning to make sure that it’s out of their system by evening (or at least it’s reduced in potency)
- 2 – Another way that patients often receive T3 is in combination with T4 vis-a-vis a formulation known as **desiccated thyroid**
  - Desiccated thyroid is basically whole thyroid gland and therefore it contains T4, T3, and even some T2 (but we’re not going to talk about T2)
  - The two most common versions of desiccated thyroid are a formulation called **Nature-Throid** and **Armour Thyroid**
    - “*If you’re watching this video and you’re interested in this topic, you’ve undoubtedly heard of these things.*”
    - There are competing schools of thought on which is better, and Peter is not going to get into this debate

> “*If you’re really interested in treating hypothyroidism, you better know all of them because there are some patients in whom one way works and another way doesn’t*”‒ Peter Attia

- The reason Peter generally doesn’t like to use desiccated thyroid (except when it works) is you’re giving a fixed amount of T4 and T3, and you don’t get to control it
  - The ratio is set, and it’s something like 1:4.2, meaning that for every unit of T3, you’re giving 4.2 units (or μg) of T4
    - For some patients, that’s just right
    - But there are other patients who need more or less of one of the other, and that’s why Peter tens to use T4 and T3 separately

***The goal is to fix the symptoms more than fix the numbers, and you’ll ultimately end up using whatever works***

**A word on half-life**

- T4 has a very long half-life, it’s a matter of days; therefore, a patient shouldn’t panic if they miss a day of T4

***If a patient forgets their dose of T4, it’s okay, just take it the next day and don’t double up***

- Conversely, T3 has a much shorter half-life, and therefore you do need to stay on top of your T3 when you give it
- What Peter is referring to includes endogenous T3
- Remember the controlled release and the immediate release T3 also have very different half-lives

> “*One of the takeaways from this is that it’s a little more complicated than you might be led to believe if your doctor is only looking at your TSH.*”‒ Peter Attia

- Unfortunately, when you go to the doctor’s office, a lot of the times TSH is the only lab they’ve ordered

***When there is any concern about hypothyroidism, Peter prefers to order TSH, free T4, free T3, and reverse T3***

- He doesn’t always order this blood test
  - If the TSH is normal, the T3, T4 are normal and the patient is asymptomatic, he’s not looking at their reverse T3
- But if a patient has symptoms and you need to investigate them, I think you have to understand all of these
- What you’re basically doing is using the amounts of free T4, free T3, reverse T3 to impute the action of these deiodinases
  - And therefore what your treatment strategy needs to be

## The adrenal system [15:45]

\*\*\*

- This is the most confusing system, and it’s the one for which we can get virtually no information from a blood test

**Blood tests of cortisol levels don’t mean anything**

- Blood tests are measuring total cortisol, and this includes what is bound to a carrier protein known as [cortisol binding protein](https://en.wikipedia.org/wiki/Transcortin)
  - The majority of cortisol is bound to this
  - Cortisol is also bound to [albumin](https://en.wikipedia.org/wiki/Albumin) and other proteins

***What we need to understand is how much cortisol is unbound, what’s called free cortisol***

- Free cortisol exerts biologic activity

**There are two ways to measure free cortisol**

- 1 – A saliva test
- 2 – A urine test
  - This is Peter’s preference and he uses the [DUTCH test](https://dutchtest.com/info-dutch-complete/) (he has no affiliation with them) because it measures free cortisol and cortisol metabolites
    - Cortisol metabolites are very helpful when it comes to understanding what cortisol production looks like
- Peter doesn’t do these tests on everybody

**Basics of the adrenal system**

- You have two [adrenal glands](https://en.wikipedia.org/wiki/Adrenal_gland), one on top of each kidney, and the adrenal glands produce [cortisol](https://en.wikipedia.org/wiki/Cortisol)
- If you want to go high enough on the chain, you’ll know that this comes as a precursor via [cholesterol](https://en.wikipedia.org/wiki/Cholesterol)
  - Cholesterol is the precursor that ultimately results in cortisol production just as it does [androgens](https://en.wikipedia.org/wiki/Androgen)
- If you go and get a blood test for cortisol, all it’s doing you is telling you the total amount of this you have in your system, but understanding that most of that is bound to carrier proteins
- Only the **free cortisol** does the important job of a [glucocorticoid](https://en.wikipedia.org/wiki/Glucocorticoid), and that’s what we care about
- The DUTCH test provides a snapshot of how much free cortisol, cortisone, and their metabolites exist (aka breakdown products: alpha-tetrahydrocortisol [⍺THF], beta-Tetrahydrocortisol [ꞵTHF], and Tetrahydrocortisone [THE]; indicated in the figure below)
  - It’s typically measured 4 times over 24 hours
  - This tells us the total adrenal output

**Adrenal fatigue**

- Adrenal fatigue is a term that you hear thrown around a lot
- The suggestion is that if a person feels lousy, it’s because their adrenal gland isn’t making enough cortisol, because it’s fatigued
- Of course, these people may indeed have low levels of cortisol, and they may even have low levels of free cortisol
  - But that doesn’t mean their adrenal glands are fatigued
  - In most cases this is probably *not* true
  - For most of those patients, the total metabolized amount of cortisol and cortisone show ample amounts of production

***What might be happening is that they are degrading too much of their cortisol and/or turning too much of their cortisol into the inactive cortisone, and instead of converting it back, it’s just metabolized***

![](https://peterattiamd.com/wp-content/uploads/2023/05/f2-hormonewhiteboard.png)

**Figure 2. Metabolism of cortisol**.

**How cortisol levels are regulated**

- Enzymes called [**reductases**](https://en.wikipedia.org/wiki/Cortisol#A-ring_reductases_(5alpha-_and_5beta-reductases)) regulate turning cortisol into its metabolites and cortisone into its metabolite
  - The names of these enzymes are not really important (5⍺-reductase [5⍺R] and 5ꞵ-reductase [5ꞵR])
  - These enzymes break down cortisol and cortisone as shown in the figure above
- Inflammation, obesity and factors that are generally associated with poor health accelerate that conversion of cortisol and cortisone into their breakdown products
- If a person is feeling lousy and their free cortisone is low, yet they have ample amounts of these breakdown products, you really need to reverse the factors that are driving these things here
  - You really need to address the obesity (Ob), the insulin resistance (IR), the leptin resistance (LR), the underlying inflammation
- A far **more common problem** is in people who have very high or very low levels of free cortisol, and they may have symptoms associated with those things

**What to look for**

- You have to look at what’s going on with their **cortisone**
- Peter always looks to make sure **adrenal output** is appropriate, and it’s virtually always appropriate
- The second thing he asks is, “*Is the rhythm normal?*”
  - Meaning, do they wake up with a low level of free cortisol? (see the upper left of the figure above)
  - Do they have a nice rise a couple of hours after waking?
  - Does it fall in the afternoon and is it down here at bedtime?
- If the answer is yes, then we’re all done

**When adrenal output is low**

- If the answer is no, and let’s assume that the person is really low, so they wake up here, they stay low, they stay low, they stay low, and they’re symptomatic
  - They say, “*Boy, I just can’t get going during the day*.”
- Then Peter asks, “*How much cortisone do they have?*”
- They might actually have **plenty of cortisone**, and in that case, what we have to do is flip the way this enzyme is working because there’s an enzyme [11ꞵ-HSD](https://en.wikipedia.org/wiki/11%CE%B2-Hydroxysteroid_dehydrogenase) that converts cortisol to cortisone and back
- But here’s what’s interesting, the direction of travel is determined by various things:
- **Cortisone gets converted to cortisol** preferentially when you have insulin resistance, obesity, inflammation, low thyroid function, leptin resistance
- In the other direction, **cortisol being turned into cortisone** is facilitated when you have glucocorticoid
  - For example, if a patient is taking steroids, understandably, the body says, we don’t need any more cortisol, let’s turn it into cortisone
    - This also results from hyperthyroidism, progesterone, [PCOS](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome), and even supplements like [curcumin](https://en.wikipedia.org/wiki/Curcumin)

**In the patient who doesn’t have enough cortisol but has plenty of cortisone**

- They look like the graph on the upper left, and is symptomatic
- Try to address the issues listed on the diagram above [insulin resistance (IR), obesity (Ob), inflammation, low thyroid, leptin resistance (LR)]
  - One of the most potent things to do is use an **adrenal support** (usually a supplement) such as licorice root
  - High enough amounts of licorice will render a person functionally high in cortisol
- Peter remembers from medical school, a person showed up looking think they had [Cushing’s disease,](https://en.wikipedia.org/wiki/Cushing%27s_syndrome) a condition of excess cortisol production
  - No one could figure out how this was happening until the nephrologist involved with this patient’s care noticed that the patient was constantly eating licorice (about 10 packs a day)
  - This was enough licorice to basically shut off this system and drive his cortisol through the roof
  - So you can use that to your advantage if this is part of the problem

**Ways to suppress the system**

- A person shows up whose cortisol levels shoot up once they wake up and stay high; they are having a difficult time sleeping
- Peter likes to use something like [phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine) to suppress cortisol production in the evening
  - That helps facilitate sleep
  - This is something he will use when he is **jet-lagged** or need to do a big timezone jump
    - For example, if he needs to go to bed at noon functionally to get in the timezone of where he is going (and it’s nighttime there but noon in his home timezone)
    - He will take anywhere from 400-600 mg of phosphatidylserine, and what that does is drop the cortisol
  - It’s not clear what the mechanism of action is, but he’s seen the result

**Peter’s takeaway**

- It is very difficult, if not impossible, to impute what’s going on with adrenal function by looking at a blood test because it’s looking at total cortisol
  - If that weren’t bad enough, it’s just one snapshot in time
- You really do need to see what’s going on in total
- Secondly, free cortisol and free cortisone by themselves still don’t tell you a total picture
  - You do need to have some sense of what their metabolites are because that’s what’s actually telling you total adrenal output
- Next thing you need to understand is the balance of cortisol and cortisone
  - How much do they have of each?
  - Cortisone is inactive, and you can think of it as a repository where excess cortisol can be placed if it’s not needed
  - The arrows pointing down [from cortisol to ⍺THF and ꞵTHF, or from cortisone to THE] are a one-way street, and once you go down to there, you’re not reversing those, you’re just slowing those enzymes
  - But you can go back and forth between cortisol and cortisone

***This is complicated because when a person has low free cortisol and they’re symptomatic, you really do not want to give them hydrocortisone or prednisone or any glucocorticoid replacement. You would only reserve such treatment for a person who’s truly in distress.***

- A person who is truly in distress would be someone in an [Addisonian](https://en.wikipedia.org/wiki/Addison%27s_disease) crisis
  - This happens when the adrenal gland completely shuts down
- Another example is someone who has an overwhelming infection
- Those people need glucocorticoids or they will die
- But *not* for the average person who’s walking around dragging, feeling blah, and indeed they have low free cortisol
  - Peter certainly wouldn’t favor using glucocorticoids as a treatment for that

**Treatment for the average person feeling blah with low free cortisol**

- Peter favors addressing the underlying issues ‒ either extracting cortisol into its metabolites or turning cortisol into cortisone
- The problem is there are very few pills that fix that
- A lot of that comes down to this word we all hate, **lifestyle management**, but unfortunately that is the key
- Licorice root is probably one of the best things you can use
- On the flip side, you can use other adrenal supports as well

## The female sex hormone system [27:00]

\*\*\*

![](https://peterattiamd.com/wp-content/uploads/2023/05/f3-hormonewhiteboard-1024x661.png)

**Figure 3. Hormone changes that occur during the menstrual cycle**.

- This looks pretty complicated, but Peter is going to make it less complicated
- The easiest way to understand this is to look at what’s happening with a woman’s sex hormones during her [menstrual cycle](https://en.wikipedia.org/wiki/Menstrual_cycle), during her reproductive years
  - It looks a lot more simple after menopause, but we will start here
- First, assume a 28-day cycle (this is not always the case as some women have a shorter or longer cycle)

**The cycle is divided into two phases: the follicular phase and the luteal phase**

- Really there are three phases counting the menstrual phase
- The **menstrual phase** starts at **day zero**, that’s the first day of bleeding
  - Even if it’s just spotting and not a heavy period
  - That’s the shedding of the endometrial lining (we’ll come back to)
- Then you move into the **follicular phase**
  - This is driven by [follicle stimulating hormone (FSH)](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) and [estrogen](https://en.wikipedia.org/wiki/Estrogen)
  - The purpose is to ripen the follicle for ovulation
- Ovulation takes place mid cycle
- After ovulation, we move into the **luteal phase**
  - The luteal phase is dominated by [luteinizing hormone (LH)](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [progesterone](https://en.wikipedia.org/wiki/Progesterone)
  - The purpose of the luteal phase is to prepare the endometrial lining for implantation
- When pregnancy does not occur, the endometrial lining gets shed, and that results in this crashing progesterone level and the shedding of the endometrial lining
  - This is what the period is and that brings the cycle back to day 0 of the graph above

**How these hormones work from the beginning of the cycle (day 0)**

- FSH along with LH are secreted from the pituitary gland (the same place that makes TSH that we talked about in the thyroid system)
- Remember, the purpose of FSH is to get the follicle ready for [ovulation](https://en.wikipedia.org/wiki/Ovulation)
- The follicular phase is really dominated by estrogen and FSH
- Peter is very particular about when he likes to do a blood test here, especially when a woman is approaching a [perimenopausal](https://en.wikipedia.org/wiki/Menopause#Perimenopause) state
  - As a woman is getting closer and closer to menopause, we will really be monitoring the level of FSH and estradiol at about **day 3, 4 or 5**
  - ***The “canary in the coal mine” as a woman is getting close to menopause from a biochemical standpoint is a rising FSH during that phase***
  - FSH should normally be very low during day 3, 4 or 5, which is usually when a woman is still in her period
  - If FSA starts to climb, especially if estradiol is low, you can be pretty sure that she’s heading towards menopause
  - In fact, menopause is chemically demonstrated by a high FSH, typically north of 25, 35, 40 and low estradiol
  - A woman who’s been in [menopause](https://en.wikipedia.org/wiki/Menopause#) for many years would easily have an FSH level of 50 or higher, and unmeasurable levels of estradiol
- Back to this situation here, FSH is rising; it has a little bit of a peak just before ovulation
- Estrogen really rises now; so peak estradiol occurs right at or just before ovulation
- The follicle comes out and away it goes to see if indeed the egg is going to be met with a sperm
  - If so, is it going to attach to the endometrium, etc.
- Now, this is where we enter the second half of the phase, the luteal phase
  - This is dominated by LH
- The purpose of LH is to prepare the endometrium for this implantation
- What is *not* drawn here (because it’s just too complicated), is the thickness is of the endometrial lining as we go from [day 0 to day 14]
- Just as a woman is finishing her period [**before day 7**], the endometrium is at its thinnest
  - It has just shed that lining and it’s slowly, slowly building up
- At about **day 14**, it really starts to build up that lining because it’s preparing for implantation
- Progesterone is rising again and by about **day 21** (when progesterone peaks), the body figures out if it’s pregnant or not
- In most cases it’s not pregnant, and the level of progesterone begins to rapidly drop
- Estrogen has also risen for a second peak
  - The absolute peak of estrogen occurs earlier, but this is a second peak
- Now both of these hormones [estrogen and progesterone] come crashing down, and the body begins to shed that endometrium at the end of that cycle

**Peter’s takeaways on how hormone levels relate to the menstrual cycle**

- At any point in time when you get a blood draw on a woman and you are looking at FSH, LH, estradiol, and progesterone, you have to know where you are in her menstrual cycle
  - Once you do a lot of this, you’re pretty good at guessing
- If a woman has sky-high LH and estradiol, you probably drew the blood right around the time that she was ovulating
- It helps to have some sense of what is going on when things get a little bit **more complicated**:
  - When women’s periods are irregular
  - When a woman is approaching perimenopause
  - When a woman has an IUD and as a result of that, she is not menstruating (not discussed)
- In the case where a woman is not menstruating at all [**menopause**], it tends to be pretty easy because you’re going to see very high levels of FSH or LH

**What happens between day 21 and day 28 is really profound physiologically (PMS)**

- Peter has talked about this previously on the podcast, on [AMA #4](https://peterattiamd.com/ama04/)
- Women who have experienced PMS know it’s a real thing, and Peter has spoken to enough women who have that to give him a real sense of why it’s probably happening
- It’s not entirely clear if it’s the drop in progesterone that’s driving PMS, but this is likely the reason
  - Peter suspects there are central receptors for progesterone, and in susceptible women, when progesterone levels are withdrawn so quickly, that can easily result in mood alterations
  - He’s not sure how well this has been investigated

***A simple way to treat PMS is with a low dose of progesterone that is administered starting at day 21 to 28***

**How does that work?**

- If a woman has a fairly regular cycle, she’ll know when she ovulates, and she’ll know about a week after ovulation to take a low dose of progesterone
  - Typically, about 50 milligrams orally
  - That’s taken for just 7 days until she has her period
- What that does is it completely blunts this effect
- This effect is still happening, but her total levels of progesterone are not nearly as dramatic in the reduction, and this tends to ameliorate symptoms

**What’s the drawback of that approach?**

- From a physiologic perspective, none
- The biggest drawback is just the logistics of having to remember that 7 days out of every 28, you have to take progesterone
- This is an entirely safe thing to do
- Peter has used this with a number of women in the past, and it seems to work very well
- Alternatively, women can stretch that out and take progesterone for the entire 14 days following their ovulation
- Of course, they can take oral contraceptives throughout
  - But now that’s creating a whole new set of issues around oral contraceptives, which many women simply don’t want to do
- Peter points this out about PMS to say (1) he thinks when you look at a graph like this, hopefully you get an appreciation for what a profound level of withdrawal a woman is experiencing during the end of the luteal phase, and (2) that there are lots of hormonal ways to address that

**Testosterone**

- The other hormone not on this diagram is [testosterone](https://en.wikipedia.org/wiki/Testosterone)
- Peter didn’t draw it for two reasons
- 1 – It doesn’t change much during the cycle (only a little bit)
  - Most studies suggest a peak testosterone [between day 7 and 14] when you have peak estradiol, but the fluctuation is so minor that he doesn’t think it adds any value to this
- 2 –  If he were to draw testosterone to scale on this graph, you’d have to look at the ceiling
  - That’s how much more testosterone a woman has in her body than estrogen

***It sounds very counterintuitive, but it’s true. Even at peak estradiol level (which is during ovulation), a woman has 5-10x more testosterone in her body than she does estradiol.***

**What happens as a woman leaves her reproductive years?**

- Her body is less able to make estradiol and progesterone
  - Estradiol and progesterone production go down in women, just as testosterone production goes down in a male
    - Although for men, it happens far less abruptly
  - The pituitary gland senses this because there’s a negative feedback loop and it says, “*I want more;*” so, it starts making more FSH and more LH
    - Of course, the higher those go, initially the body responds and you’ll see a period where the cycle does continue
    - Sometimes it spreads out, it gets a little bit longer, but the body is able to compensate until of course it isn’t

***When a woman is in menopause, what you’ll see is no estrogen, no progesterone, very high LH, very high FSH***

**Hormone replacement therapy (HRT)**

- Peter initiates hormone replacement therapy dfore these hormonal changes
  - You never want to wait until a woman is in that state where she has flat line estradiol, flat line, progesterone, sky-high FSH, sky-high LH
  - You want to do it as she’s transitioning from a regular menstrual cycle into menopause
  - That could be literally a year or two years prior to that state [of menopause]
- What we’re doing is we’re giving her enough estradiol that her FSH usually ends up hovering around 20 to 30
  - That’s still a pretty high level of FSH
  - This means that her brain is still thinking, “*I want more estradiol,*”
  - But you don’t need to give maximum amounts of estradiol
  - We’re simply trying to control the vasomotor symptoms, the hot flashes, the night sweats, the vaginal symptoms, atrophy, dryness, and perhaps most importantly, cardiovascular risk factors and bone risk factors

> “*Estrogen being the most important hormone both in men and women as it regulates sending the signal of tension on the bone into bone building via osteoblasts*”‒ Peter Attia

***In summary, the female endocrine system is much more complicated than the male sex endocrine system because of both the cyclic nature of it and the abruptness with which it goes away***

**Peter’s takeaways**

- This is something every woman needs to understand, and if you care about a woman, you should understand
- Hopefully this will give you give empathy toward women who are struggling during that last portion of their luteal phase
  - Men don’t have an equivalent of this; they don’t have a scenario whereby they are having a tenfold reduction in a major sex hormone that occurs over the course of a week
- By understanding how this works, you have a sense of whether a woman is typically getting closer to menopause, which is generally one of our considerations as we’re looking at these hormone levels
- As a woman is entering that perimenopausal period, you want to be especially attentive to the time in which you draw blood
  - Day 3, 4, 5 become the most important blood draws as a woman is becoming perimenopausal because it’s that FSH level at day 3, 4, and 5 that becomes your “canary in the coal mine”
  - If that level starts creeping up and it’s over 10, 11, 12, even though she’s not in menopause, she’s probably getting close, and that’s when we start to have our discussion about what hormone replacement therapy looks like

## The male sex hormone system [40:00]

\*\*\*

- The male sex hormone system is a little bit simpler than the female system, but it still has its nuances
- Let’s go back to a very similar pattern we saw with the thyroid system, which is upstream regulation at the hypothalamus vis-a-vis [GnRH (gonadotropin releasing hormone)](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone) that tells the pituitary to secrete [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)
  - Shown in the figure below
  - If you just watched Peter go over the female system, you’ll realize we have the exact same thing happening there; he just didn’t draw all of this because we had so many other complicated things to talk about

![](https://peterattiamd.com/wp-content/uploads/2023/05/f4-hormonewhiteboard.png)

**Figure 4. The male sex hormone system**.

- LH and FSH are speaking to the testes
  - As Peter drew this, he realized he didn’t need to draw two of them
  - Nevertheless, the testes have different cells in them, [Sertoli cells](https://en.wikipedia.org/wiki/Sertoli_cell) and [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) that respond differently (we’ll come back to this)
- The testes make [testosterone](https://en.wikipedia.org/wiki/Testosterone) (we’ll come back to more complexities in a moment)
- Most testosterone is bound to either [SHBG (sex hormone-binding globulin)](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) or [albumin](https://en.wikipedia.org/wiki/Albumin), and a relatively small amount remains as free testosterone (or unbound testosterone)
  - 1-3% of the total testosterone is **free testosterone**
    - This depends on how much albumin and SHBG you have
  - This is similar to the earlier discussion of cortisol, where most cortisol is bound

**There are two things that are siphoning testosterone away that are very important**

- 1 – The first is [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase)
  - This is the same enzyme we talked about back when we were going over cortisol
  - 5⍺-reductase siphoning off some of that testosterone to make [dihydrotestosterone (DHT)](https://en.wikipedia.org/wiki/Dihydrotestosterone)
    - Not huge amounts, a couple of percent
- **DHT** is a very important sex hormone, and it has anywhere from 2-10x ,for the androgen receptor as compared to testosterone
  - Keep in mind that DHT has a much higher binding affinity for the [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor) than testosterone does
  - We’ll come back to the androgen receptor in a minute
- 2 – The other thing that is siphoning off testosterone is the [aromatase enzymes](https://en.wikipedia.org/wiki/Aromatase) that are converting testosterone into [estradiol](https://en.wikipedia.org/wiki/Estradiol)
  - Yes, that’s the very same estrogen that women have as well
  - Estrogen turns out to be a very important hormone for men, and this is something that hasn’t been always appreciated, but we now understand that estrogen is important in the male for mood, for body composition, for bone mineral density

> “*Things that suppress estrogen have to be considered judiciously because of the negative side effects of having low estrogen*”‒ Peter Attia

**The feedback loop**

- The feedback loop works as follows, testosterone levels as they rise will inhibit both the hypothalamus and the pituitary
  - This slows down GnRH and LH and FSH
  - This is actually much more complicated than what is drawn here, and Peter realizes that there’s going to be some purist out there who says, “*Oh my God, you forgot to mention this.*”
    - It turns out that the hypothalamus does not have an overwhelming number of androgen receptors
    - So, this is not happening directly, but rather indirectly
    - Testosterone is inhibiting a slightly different neuron that is then speaking to the hypothalamus
  - But for the purpose of this discussion, the figure above is sufficient
- The other thing to point out is that estrogen also inhibits LH secretion via the pituitary
  - This becomes really important when we talk about certain drugs that are used to replace testosterone or to increase testosterone

**Peter’s summary**

- In the normal functioning system GnRH tells the pituitary to make LH and FSH
- They tell the testes to make testosterone
- Small amounts of testosterone are siphoned off to make DHT, and even smaller amounts (less than 1%) are siphoned off to make estrogen
- And the system is in perfect balance

*How much of that testosterone is actually exerting its biologic effect on the androgen receptor?*

- It turns out very little is because SHBG and albumin are soaking up most of the testosterone
- Only the free testosterone is the biologically active, and that represents only about 1-3% of total testosterone
  - But the good news is that’s all you need (the stuff’s pretty darn potent)

**The action of testosterone**

- Testosterone binds to an [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor)
- DHT also binds to an androgen receptor; it just does so in a way more potent fashion
- This binding happens inside the nucleus of a cell, and that’s what affects [transcription](https://en.wikipedia.org/wiki/Transcription_(biology))

**Determining if testosterone is low and when to treat**

- This is a subject that is way more complicated than people are being led to believe it is
- It’s not as simple as looking at the total testosterone or even the free testosterone and determining if a person has low testosterone (aka low T)
- The reason for that is when you are measuring total testosterone, you don’t really know what the **free T** is
  - The free T is a calculated lab value
  - Most lab assays don’t really measure free T, they measure total testosterone, they measure SHBG and albumin, and they calculate free T
- Let’s assume that the calculation is fairly accurate
  - Even if you don’t rely on a lab to do that calculation, there are [calculators online](https://www.mdapp.co/free-and-bioavailable-testosterone-calculator-544/) that can do that for you
- Let’s say you now know the free T (we’ll talk about what some ranges are in a moment)
- The question becomes ‒ does the patient’s low level of T explain their symptoms?
  - Let’s just say they’re at the 30th percentile for what their level is
- This not entirely clear because what we don’t know is what’s happening here
  - We don’t know how many androgen receptors a person has, and therefore we don’t know how saturated their androgen receptors are with either testosterone or DHT
- We have to sometimes treat these things empirically
  - Meaning, we’re treating symptoms, but we’re using numbers as a guide to do so

**The most common symptoms of low testosterone (**[**androgen deficiency**](https://en.wikipedia.org/wiki/Androgen_deficiency)**)**

- The big ones: low libido, erectile dysfunction, low mood, difficulty putting on muscle mass, and insulin resistance
  - These symptoms are in no particular order because they will vary significantly

**Benefits of TRT**

- We know from [clinical trials](https://pubmed.ncbi.nlm.nih.gov/16728551/) that when you give a group of insulin resistant men testosterone, their insulin resistance improves
- We know that if you give men testosterone and you provide them with a training stimulus, muscle mass increases, strength increases, and body composition improves (which means adipose tissue goes down)
- We know that mood improves
- We know that a whole bunch of factors move in the right direction

***Despite all of that, Peter is still pretty cautious when giving testosterone because he thinks it is an overused hormone***

- Too many people are being given testosterone, and they probably don’t need it because they’re just being treated on their total testosterone level without necessarily considering these other factors
  - Such as free testosterone
  - Without understanding these things, which none of us can outside of a lab
  - So we have to really treat based on symptoms

**What are the treatment options?**

- Broadly speaking, there are two ways to think about this
- 1 – A **direct** way to do it, which is giving testosterone, and this can be done in many formats
  - The most common formats would be topical testosterone or injectable testosterone, but there’s also an intranasal formulation
  - There are pellets that can provide a slow release over a period of months
- 2 – There are **indirect** ways to give testosterone, which are basically tricks that mimic these hormones
  - The first of these is something called [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin), and hCG is a mimetic of LH
    - An injection of hCG will tell the body to make testosterone just as you were giving LH
  - There is also a synthetic FSH
    - It’s far more expensive and it’s virtually never used
    - The typical use case for synthetic FSH is in men who have been on testosterone replacement therapy for many years, who have now lost the ability to make testosterone

***If you are given enough exogenous testosterone, you will shut down the capacity to make testosterone in very short order***

- Within a year, two years, you will permanently lose that ability
  - Minus some Herculean doses of synthetic LH and synthetic FSH

“*We should make sure we never lose sight of that*”

- When you give testosterone, you have to be mindful of the fact that your LH and FSH are going to go to zero because your body is going to stop making testosterone
  - This is a very potent feedback loop

**Other indirect ways to give testosterone**

- One drug that has become very popular is [Clomid (or clomiphene)](https://en.wikipedia.org/wiki/Clomifene)
  - Historically, this is a drug that has been used by women for fertility purposes.
  - Clomid is effectively tricking the brain via stimulation of GnRH by blocking the estrogen receptor to make more LH and FSH

**There are several reasons why Peter is not a fan of Clomid**

- One of the most important reasons is that it blocks the effect of estrogen in the brain, and that turns out to be a negative thing
- It turns out we want the feedback of estrogen in the brain because it has many beneficial effects for mood
- There are some men who actually, when they’re on Clomid, even though their testosterone levels soar, don’t feel any better, and Peter wonders if in fact, that’s because of Clomid
- There are some men that are on Clomid that feel great on it, but not every man

**When you give testosterone, these hormones will go up, and this depends on a number of factors**

- [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase) has quite a strong genetic component
  - Some men are very strong 5⍺-reductase producers, and they’re going to make a lot of DHT
    - By the way, this is responsible for one of the side effects of testosterone, which is **hair loss**
    - A lot of hair loss is driven by DHT and the androgen receptor
    - ***If you give testosterone and you make more DHT, you’re going to accelerate hair loss***
- Similarly, [aromatase](https://en.wikipedia.org/wiki/Aromatase) activity varies genetically, but it also varies by factors such as insulin resistance, obesity, and factors like that
  - Therefore, the more adipose tissue you have, typically the more aromatase you have
  - A person who is overweight is going to make more estradiol, all things equal, from a given amount of testosterone than a person who is lean

**Are there side effects of having too much estradiol?**

- Yes, there are
- At some point, estradiol levels can become counterproductive
- If they get very high we can see [gynecomastia](https://en.wikipedia.org/wiki/Gynecomastia) (that’s when a man will develop breast tissue)
  - Peter has never seen a case of this in 10 years of prescribing testosterone
  - Again, these are typically things that are only seen in people who are using excessive amounts of testosterone, usually not under the care of a doctor
- If estradiol levels do get a little too high, they can be managed with a drug that blocks that conversion ‒ the drug is known as [anastrozole](https://en.wikipedia.org/wiki/Anastrozole)
  - Peter is not a big fan of using it because he finds you really don’t need to use it in most men
  - Peter will typically not use anastrozole unless the estradiol level is in excess of 50 (55 or even 60), unless we are seeing symptoms that we would attribute to that

**Benefits of estradiol**

- In fact, it’s nice to have the estradiol levels go up because you want it for bone health, you want it for mood, you want it for all of those other reasons

**Peter’s philosophy on testosterone replacement therapy (TRT)**

- There has to be a biochemical case for it, i.e. free testosterone needs to be relatively low (at least below the 50th percentile)
- More importantly, there needs to be a symptomatic case for it
- If both of those conditions are met, and of course, the patient understands the risks and benefits, he would give TRT for a period of 8-12 weeks
- Then he would determine if the biochemical issue was fixed
  - For example, if the patient went from being at the 30th percentile to the 80th percentile
- He would also assess the symptoms
- Sometimes the man doesn’t feel any better, you fixed the number but you haven’t fixed the symptoms
  - At this point (with very few exceptions), Peter thinks it doesn’t make sense to continue TRT, and they stop it
- One exception that that would be if you’re using TRT for bone health
  - If a man has osteopenia and he has low estradiol and low testosterone, we don’t really care about symptoms at that point
  - We want his testosterone high, we want his estradiol high because those are going to be two of the most important steps we can take in combination with heavy training to increase or at a minimum maintain his bone mineral density
- For most men, we care about the symptoms more than we care about the numbers, and if we don’t fix the symptoms, we take it off
- He also watches to see if symptoms get worse when we remove the testosterone
  - Often they don’t
- Peter suspects that some men may have either low amounts of [estrogen receptors](https://en.wikipedia.org/wiki/Estrogen_receptor) or their estrogen receptors are highly saturated with the little bit of testosterone they have in the first place

§

## Selected Links / Related Material

**DUTCH test of free cortisol**: [DUTCH COMPLETE](https://dutchtest.com/info-dutch-complete/) (Adrenals only panel) | Precision Analytical Inc | [17:15]

**Previous episode of** ***The Drive*** **that discussed PMS**: [#45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more](https://peterattiamd.com/ama04/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 18, 2019) | [33:15]

**Testosterone replacement therapy improves insulin resistance**: [Testosterone replacement therapy improves insulin resistance, glycaemic control, visceral adiposity and hypercholesterolaemia in hypogonadal men with type 2 diabetes](https://pubmed.ncbi.nlm.nih.gov/16728551/) | *European Journal of Endocrinology* (D Kapoor, et al. 2006) | [47:15]

**Testosterone therapy discussed on an upcoming episode of** ***The Drive***: Mohity Khera, M.D., M.B.A., M.P.H. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (June 23, 2023)

**Women’s sex hormones discussed on an upcoming episode of** ***The Drive***: Sharon Parish, M.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (June 19, 2023)

**Hormone replacement therapy for women discussed previously on** ***The Drive***: [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT](https://peterattiamd.com/joannmanson/) | JoAnn Manson, M.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 8, 2023)

§