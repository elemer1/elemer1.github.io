# #357 ‒ A new era of longevity science: models of aging, human trials of rapamycin, biological clocks, promising compounds, and lifestyle interventions | Brian Kennedy, Ph.D.

**Source:** [https://peterattiamd.com/briankennedy/](https://peterattiamd.com/briankennedy/)

---

Brian Kennedy is a renowned biologist, leader in aging research, and director of the Center for Healthy Longevity at the National University of Singapore. In this episode, Brian shares insights from ongoing human aging studies, including clinical trials of rapamycin and how dosing strategies, timing, and exercise may influence outcomes. He presents two key models of aging—one as a linear accumulation of biological decline and the other as an exponential rise in mortality risk—and explains why traditional models of aging fall short. He also explains why most current aging biomarkers lack clinical utility and describes how his team is working to develop a more actionable biological clock. Additional topics include the potential of compounds like alpha-ketoglutarate, urolithin A, and NAD boosters, along with how lifestyle interventions—such as VO2 max training, strength building, and the use of GLP-1 and SGLT2 drugs—may contribute to longer, healthier lives.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/briankennedy/the_Drive_public.png)

Play

#357 ‒ A new era of longevity science: models of aging, human trials of rapamycin, biological clocks, promising compounds, and lifestyle interventions | Brian Kennedy, Ph.D.

#357 ‒ A new era of longevity science: models of aging, human trials of rapamycin, biological clocks, promising compounds, and lifestyle interventions | Brian Kennedy, Ph.D.

1x15s30s

0:001:56:41

## We discuss:

- Brian’s journey from the Buck Institute to Singapore, and the global evolution of aging research [2:45];
- Rethinking the biology of aging: why models like the hallmarks of aging fall short [9:45];
- How inflammation and mTOR signaling may play a central, causal role in aging [14:15];
- The biological role of mTOR in aging, and the potential of rapamycin to slow aging and enhance immune resilience [17:30];
- Aging as a linear decline in resilience overlaid with non-linear health fluctuations [22:30];
- Speculating on the future of longevity: slowing biological aging through noise reduction and reprogramming [33:30];
- Evaluating the role of the epigenome in aging, and the limits of methylation clocks [39:00];
- Balancing the quest for immortality with the urgent need to improve late-life healthspan [43:00];
- Comparing the big 4 chronic diseases: which are the most inevitable and modifiable? [47:15];
- Exploring potential benefits of rapamycin: how Brian is testing this and other interventions in humans [51:45];
- Testing alpha-ketoglutarate (AKG) for healthspan benefits in aging [1:01:45];
- Exploring urolithin A’s potential to enhance mitochondrial health, reduce frailty, and slow aging [1:05:30];
- The potential of sublingual NAD for longevity, and the combination of NAD and AKG for metabolic and exercise enhancement [1:09:00];
- Other interventions that may promote longevity: spermidine, 17𝛼-estradiol, HRT, and more [1:17:00];
- Biological aging clocks, clinical biomarkers, and a new path to proactive longevity care [1:23:15];
- Evaluating rapamycin, metformin, and GLP-1s for longevity in healthy individuals [1:32:15];
- Why muscle, strength, and fitness are the strongest predictors of healthspan [1:37:30];
- Why combining too many longevity interventions may backfire [1:39:30];
- How increased funding and AI integration could accelerate breakthroughs in aging research [1:41:45];
- The research Brian is most excited about, and the need to balance innovation with safety in longevity clinics [1:47:00];
- Peter’s reflections on emerging interventions and the promise of combining proven aging compounds [1:54:00]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Brian Kennedy is a renowned biologist and leader in the field of aging research
  - He’s the former CEO of of the Buck Institute for Research on Aging
  - He is now the director of the Centre for Healthy Longevity at the National University of Singapore

In this episode we discuss

- Why Brian moved his research from the US to Singapore, and how that shift opened the door to running larger-scale medical aging studies
- How the field of longevity research changed around 2017, when serious funding started pouring in
  - Reshaping the priorities and pace of discovery
- We explore two different concepts of aging
  - One being the linear accumulation of wear and tear with age
  - The other being the exponential (or nonlinear) increase in all-cause mortality with age
  - Brian’s explanation here is one of the more interesting ones Peter has heard
- We talk about how rapamycin is being tested in humans today
  - What we know so far
  - Why dose and timing (especially around exercise) can be critical
- Why current aging biomarkers miss the mark, and what Brian’s team is doing to build a clock that clinicians might actually find useful
- Compounds that show early promise, such as 𝛼-ketoglutarate, urolithin A, and sublingual NAD boosters
  - NAD is a molecule Peter has long discussed and questioned, and Brian himself has been skeptical of
  - We found an interesting place to discuss it here
- How to combine lifestyle factors and pharmacology with a focus on VO2 max, strength training, and the use of GLP-1 agonists and SGLT2 inhibitors

## Brian’s journey from the Buck Institute to Singapore, and the global evolution of aging research [2:45]

- Brian used to run an institute called the [Buck Institute](https://www.buckinstitute.org/about/)

**Tell folks a little bit about what the Buck is and what you did there**

- It was the first institute solely devoted to understanding aging and longevity, and it started around 2000 with some money that was donated by a woman who died in Marin County north of San Francisco
- Brian was the second CEO there in 2010
- There were about 20 faculty at the time all ***devoted to either aging or aspects of aging***, very basic science
  - As you can imagine in the 2000s at around 2010, that was a significant component of the aging research field
- It was still a very small field, and so the goal was really to help that institute grow
- It was tough times in the 2010s because the funding levels were low, and it was right before the real interest in aging and longevity happened around 2017, 2018
- So we were really struggling to keep the doors open and the Buck’s doing a lot better now as well as the rest of the aging field

**At the time that you were there, how much of the funding came from NIH and how much came from either donations or industry?**

- It was heavily oriented to NIH and our goal was to get more industry funding
- We started 7 companies when Brian was there, some of which are still hanging around
- We also really tried to ramp up philanthropy, but philanthropy for aging wasn’t really happening until around 2017, 2018 when people started really getting the idea that you could slow aging and prevent all these diseases and stay healthy and functional

**The faculty there are quite the star-studded cast**

- [Eric Verdin](https://www.buckinstitute.org/lab/verdin-lab/) is there (he came after Brian left and took over as CEO)
- [Judith Campisi](https://www.cell.com/cell/fulltext/S0092-8674(24)00183-1) was there until she passed away
- [Henry Jasper](https://www.gene.com/scientists/our-scientists/heinrich-jasper) was there, he’s now gone on to Genentech
- [Gordon Lithgow](https://www.buckinstitute.org/lab/lithgow-lab/) and a bunch of other people working on aging
- It was a good group of people for sure

**You alluded to something that happened in 2017, 2018 that brought a lot more interest into the field, what do you think led to this interest?**

- You just reach an inflection point, and it’s really hard to know what triggers it
- [Calico](https://www.calicolabs.com/mission-and-values/) started a few years before that
  - Google’s alphabet companies that was focused on longevity
- They’ve not been very open about what they’re doing, but it triggered a lot of publicity for longevity field
- It got Silicon Valley interested
- Brian and [Matt](https://www.linkedin.com/in/mkaeberlein/) used this slide that you have aging pointing to all these different diseases [shown below]

![](https://peterattiamd.com/wp-content/uploads/2025/07/f1-briankennedy.png)

**Figure 1. Diseases related to aging**. Image credit: Brian Kennedy

Brian explains, “*We started using that slide around 2005, and we were making the point around healthspan shortly afterwards and really this idea of preventing disease and keeping people healthy, interacting earlier*.”

- Now Brian is so sick of that slide; he can’t look at it anymore
- Back then, there were a few scientists doing it and it finally helped trigger a movement (hopefully)

**Do you think the field would’ve accelerated sooner had it not been for some notable setbacks?**

- For example, [resveratrol](https://en.wikipedia.org/wiki/Resveratrol)
  - Peter doesn’t remember exactly when GSK bought resveratrol, around 2006, 2007
  - By about 2010, it was clear to him that was not going to work
  - GSK probably knew sooner

*Do you think that that type of hype with nothing to show for it was a negative force in that equation and maybe this inflection point could have happened sooner,and it could have been easier 7 raised funds if there had been less of those examples?*

- It’s hard to know
- It’s unfortunate that investors made money off that deal when what was developed wasn’t going anywhere

***It probably slowed things down a little bit because there’s always this doubt about whether you can slow the aging process***

- When you have a major effort that’s triggered around trying to do that, even though they ended up focusing on disease, and when something like that fails, it probably does slow down other investor interests
  - We can talk about the struggles of longevity biotech companies in that way

**Today you’re in Singapore; tell me what you’re doing there**

- Brian has one foot in academics and one foot in the private sector these days
- On the academic side, he’s really focused on targeting aging
- And that comes back to what he alluded to with the biotech companies a minute ago: a lot of them are targeting aging pathways, but to raise money and get their drugs tested, they have to turn to some disease indication (which is understandable)
- The companies he’s involved with do that too, but that’s not what we really want to do

> “*What we really want to do is slow the aging process and keep you from getting sick*.”‒ Brian Kennedy

- In an academic setting, we can test that clinically
  - We basically have a whole range of animal models, a pipeline from yeast, worms, flies, killifish, mice, and humans (billion years of evolution there)
- We bring interventions in at the right place, validate them, really believing the idea that if it works across different model organisms, it’s more likely to work in humans
- Then we design human clinical intervention studies to validate that they’re targeting the aging process

Brian adds, “*I don’t think anybody knows exactly how to do that yet (including us), but we’re doing our best and learning as we go.*”

**How is the institute you’re at funded?**

- [Brian is at the [Centre for Healthy Longevity](https://coe.nuhs.edu.sg/centre-for-healthy-longevity/about-us) at National University in Singapore]
- Mostly through the university and the government in Singapore, but we also have some philanthropy, and we do contract sponsored research to test interventions from companies sometimes

**How many PIs are there?**

- Brian runs a program that has about 35 PIs in it
- But a lot of them are doing other things
  - They’re not all focused on that one concept he just spoke about
  - They have their projects around Alzheimer’s disease
  - Or we just have this guy [Michael Chee](https://discovery.nus.edu.sg/1382-wei-liang-michael-chee), who’s working on sleep and aging, which is so understudied
  - It’s kind of like an academic department where people have their own projects they’re focusing on

**Is there any department at a US university that brings together as many people that are focused on specifics of aging this way?**

- Brian doesn’t think so, although it depends on how you define aging
- If you branch it out to cancer then there are, but he’s not sure if that is focused on the actual aging process

## Rethinking the biology of aging: why models like the hallmarks of aging fall short [9:45]

- Peter wants to start with a question that he thinks they’ll end up coming back to because it’s so fundamental

Peter adds, “*I enjoy going down the rabbit hole of fundamental questions in physics.*”

**What do we think is actually causing aging?**

Brian jokes, “*I’m going to force you into physics since you asked that question.*”

- The first ever international [conference](https://medicine.nus.edu.sg/trp/healthy-longevity/events/global-conference-on-gerophysics/) on gerophysics was held in Singapore
- Brian was one of the organizers, and the reason he got behind it is this very question
- We’ve been debating what aging is for the longest time, and I think we would argue for two hours and at the end of it, we would come up with the definition: shit happens in the new time
  - It’s really just frustrating
  - Brian doesn’t even want to talk about it now
- [Vadim Gladyshev](https://dms.hms.harvard.edu/people/vadim-gladyshev) has been on an evangelical rant about: How do we define aging?
  - He asked that question at every conference
  - It’s a fair question, and we all throw our hands up in the air

**⇒** We don’t know how to define aging

- The idea was we have a lot of human data now and aging researchers are beginning to try to model that data, but they’re not modelers
  - Most aging biologists, or at least Brain if he has a skill, it’s intuition ‒ it’s not writing equations and code
- But the theoretical physicists people, they know how to model things, and they model things based on physical principles that are proven
- And so we’ve been trying to bring these groups together because Brian believes maybe the only answer to Peter’s question is that we have to write in equations early days on that
  - Brian is excited about where that’s going

Peter adds, “*Do you think that these will be explainable through equations or do you think that this exceeds our level of intelligence to understand, and it’s really going to be up to a black box that contains a neural network to this?*”

**Take a step back, listeners have heard us on this podcast talk about the “hallmarks of aging.” Explain what this concept is**

![](https://peterattiamd.com/wp-content/uploads/2025/07/f2-briankennedy.png)

**Figure 2. The 12 hallmarks of aging**. Image credit: [*Cell* 2023](https://pubmed.ncbi.nlm.nih.gov/36599349/)

*Explain why stating those hallmarks [shown in the figure above] is not the same as answering the question that everyone is struggling with*

- This is kind of an existential crisis with Brian because the “[hallmarks of aging](https://pmc.ncbi.nlm.nih.gov/articles/PMC3836174/)” came out in 2013
- Then Brian wrote another [paper](https://pubmed.ncbi.nlm.nih.gov/25417146/) right after that about the “pillars of aging” [shown in the figure below], which is kind of the poor stepchild of the hallmarks of aging
  - That was because there was an NIH conference and there were 7 topics discussed, and they asked him to write a review calling them the pillars of aging
- In that [review](https://pubmed.ncbi.nlm.nih.gov/25417146/), he had the 7 pillars of aging, but he connected them all with lines because what strikes him is how entrained everything is
  - These hallmarks and pillars, which are the pathways in the cell that are thought to be driving the aging process (inflammation, epigenetic changes, these kinds of things), they’re all interesting to aging and you can modify them or they get modified if you slow the aging process

![](https://peterattiamd.com/wp-content/uploads/2025/07/f3-briankennedy.png)

**Figure 3. The 7 pillars of aging**. Image credit: | [*Cell* 2014](https://pubmed.ncbi.nlm.nih.gov/25417146/)

**⇒** If you take an intervention like [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) that slows aging, it can impact all of the hallmarks

- Those are outputs or ways you can look at aging, but nobody is really just targeted

***The idea that you can target each hallmark and then you’ll live forever is not going to work because it’s really the network that connects the hallmarks together***

**Healthy aging is about maintaining homeostasis**

- It’s about maintaining a responsive network in your body that sort of keeps you in equilibrium
  - Responds to the events that are happening during aging, the stochastic events, the damage that’s happening, and it keeps you functional
- And that network is highly malleable
- You can influence that network by drugs or behavior and if you do, you get drive benefit from it and you can read it out as an improvement of all the hallmarks
- It’s not like one thing of exercise affects only this hallmark

**Brian’s views about the 12 hallmarks of aging**

- The hallmarks was good because it drove interest in the field as part of the reason a lot of investment came in the biotech sector

***But it also is misleading because the idea that aging is 12 different things and you just need to fix all 12 of them is completely wrong***

- It’s really about your body knows how to function in a healthy way
- It’s about trying to maintain that and maybe improve upon it

## How inflammation and mTOR signaling may play a central, causal role in aging [14:15]

**When you look at the hallmarks, do you see a seniority of them in terms of causality?**

*One of the hallmarks is mitochondrial dysfunction*

- Peter proposes that one could say that mitochondrial dysfunction occurs independent of another hallmark of aging, epigenetic change
- Alternatively, you could say actually it’s the epigenetic change that occurs stochastically and that that is driving mitochondrial dysfunction
- And if you reverse the epigenetic change to the previous epigenetic layout, you will correct the mitochondrial dysfunction

*How do you think about the interconnectedness through the lens of causality?*

- The primacy issue is a major one
- Brian likes the idea that mitochondria might be one of the primary drivers

**⇒** Every time we do an experiment, we keep coming back to inflammation

- All of the interventions that extend lifespan, reduce chronic inflammation on almost all of them
- And every time we create a new biologic aging clock, it’s always related to inflammation
  - This is something he’s doing a lot of now in his lab
  - And we do principle components and figure out what the main driver is

***There is something, it may not be inflammation; inflammation may be a response, but it’s so central that a lot of the interventions are working by dampening inflammation***

- Inflammation could be a readout stage
- When you modify it, you get an outcome
- It’s not just an endpoint that you look at

**How are you measuring inflammation?**

*Walk me through how you’re doing it in different model systems*

- Brian is not studying it in yeast, but you can study innate inflammation in worms and flies because the rudimentary elements of those pathways are there
- In mice you have both innate and adaptive immunity that you can study

***We look at inflammatory cytokine panels and a range of other things in various tissues to see how that’s changing over time and how interventions impact that***

- We do that in humans too in our clinical studies

**What do you believe is the hallmark of maladaptive inflammation?**

*Do you think that is based on deteriorated immune function and/or overaggressive immune function, or do you think the hallmark of that could simply be found in a cytokine profile that is not typical?*

- It’s central to mTOR
- Brian was one of the earliest to publish the finding that baseline levels of [mTOR](https://en.wikipedia.org/wiki/MTOR) are creeping up during aging
  - You can’t turn the pathway off

> “*I think most of the interventions (sirtuin’s, mTOR, inflammation) it’s not about doing anything super physiologic with the interventions. It’s about restoring the dynamic range that you had when you were youthful.*”‒ Brian Kennedy

**mTOR is a great example of that dynamic range**

- You need mTOR ‘on’ when you wound your skin or you get an infection or you have a big meal (in your liver), but you need it ‘off’ the rest of the time
- When you’re young, you’re very good at maintaining that dynamic range
- What’s happening with aging (at least in stem cells) is that the baseline levels of mTOR are creeping up

## The biological role of mTOR in aging, and the potential of rapamycin to slow aging and enhance immune resilience [17:30]

*Talk about mTOR complex 1, talk about mTOR complex 2, talk about rapamycin*

- Peter points out that people on this podcast are pretty familiar with mTOR
  - We’ve had [David Sabatini](https://www.davidsabatinilab.com/) on many times, as well as [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/)
  - [for a list of previous episodes with these guests, see the “selected links” section at the end]
- He wants listeners to understand why mTOR is so central across all of life that we’ve ever known
- Brian’s entry into the mTOR pathway was in yeast
- He and Matt Kaeberlein were [screening](https://pubmed.ncbi.nlm.nih.gov/26456335/) the yeast deletion set ‒ looking for a gene that made the yeast live longer
  - There are about 5,000 genes in yeast
  - This was a set of strains where each gene was deleted
  - Some of those genes are essential, and if you knock them you, the yeast are dead (you can’t screen those)
  - Surprisingly there were 300 genes that met that description

Matt shares, “*One thing I learned from that is that extending lifespan (at least in a simple organism like yeast, and there’s also data in worms) is much easier than anybody would’ve ever expected.*”

- Peter thinks that was a pretty cool tour de force in the 90s
- They did the [sirtuins](https://en.wikipedia.org/wiki/Sirtuin) stuff in the 90s and the full genome screen in the 2000s, when Brian was in Seattle with Matt
  - It was a lot of brute force work ‒ people were sitting at microscopes dissecting yeast all the time
  - There were 80-some authors on that [paper](https://pubmed.ncbi.nlm.nih.gov/26456335/) (for a yeast paper, that might’ve been a record)
- One of the main things we hit was the [mTOR pathway](https://en.wikipedia.org/wiki/MTOR) and downstream of it is [protein translation](https://en.wikipedia.org/wiki/Translation_(biology))
- We hit a lot of things in protein translation
- mTOR is a nutrient responsive kinase
  - It responds to the levels of carbohydrates and also amino acids that the cell encounters
- So that fit into the calorie restriction data (which Peter has talked about) that reducing calories can extend lifespan
  - [Discussed in episodes [#171](https://peterattiamd.com/steveaustad/), [#222](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/), [#324](https://peterattiamd.com/ericravussin/)]
- So it seemed like it was going to be very central in modifying aging, and Brian thinks that’s proven true

**⇒** Turning down mTOR signaling across a wide range of species extends lifespan

***The data in humans is not fully validated, but Brian thinks if you alter mTOR signaling in the right way, you can probably slow aging in humans too***

**Why do the first human studies with mTOR modulation show up in the form of immune suppression?**

- That’s unfortunate in a way
- [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus) was discovered on Easter Island, and it almost died
  - Peter went through the whole story of this [in episode [#272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]
  - It’s probably one of the top 5 stories in science
  - Peter wrote about it in his book [[*Outlive*](https://www.amazon.com/dp/0593236599/?bestFormat=true&k=outlive%20peter%20attia&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_7&crid=2QT68H85V04W4&sprefix=outlive)chapter 5]
  - Peter went to [Easter Island](https://en.wikipedia.org/wiki/Easter_Island); Brian hasn’t been there
- Rapamycin had the ability to kill bacterial cells (it was bactericidal)
- Then they discovered it had an impact on human cells, but almost got thrown away
- Then it gets restored and it makes a new life as an **immune suppressant**
  - Certainly if you use it at high enough doses and you really dampen the ability to activate TOR, you can impair the immune system
  - Especially if you combine it with [cyclosporine](https://en.wikipedia.org/wiki/Ciclosporin) or some other anti-inflammatory or immune suppressant, then it’s used for after organ transplant in those contexts

Peter asks, “*Do you think that it’s that necessary combination with one to two other immune suppressants that allows it to shine? And I’m actually not aware of literature that looked at Rapamune or rapamycin in isolation as a potential treatment for organ transplant patients.*”

- Brian is not either
- At high enough doses, it may have that impact, but he thinks the side effect profile would be too extreme
- By combining it with other drugs at lower doses, he thinks you get a bigger effect

**⇒** The main thing for aging is that it’s not immune suppressant at the levels that people are taking it for longevity (which is once a week, let the trough levels come down)

**What do you think of the window we got into this idea of immune modulation and maybe immune enhancement with that type of a dosing regimen vis-a-vis the paper that** [**Joan Mannick**](https://www.tornado-tx.com/team) **and Lloyd Klickstein published about 12 years ago?**

- [discussed in episode [#272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]
- Brian likes those papers [published in [2014](https://pubmed.ncbi.nlm.nih.gov/25540326/), [2018](https://pubmed.ncbi.nlm.nih.gov/29997249/), and [2021](https://pubmed.ncbi.nlm.nih.gov/33977284/)]
- There’s definitely a nugget of truth in there
- Brian thinks it can protect from respiratory infections if used correctly

> “*I still think rapamycin is the gold standard for a small molecule impacting aging. At the end of the day, it may not be the best, but right now I think the evidence is still the best*.”‒ Brian Kennedy

- Coming back to the earlier thought, when you have mTOR creeping up when it shouldn’t be, that’s driving chronic inflammation and then chronic inflammation is continuing to drive mTOR

**⇒** It’s this feed-forward circle of disruption that connects this nutrient pathway to inflammatory signaling

- Brian thinks that’s one of the earliest events that’s happening

## Aging as a linear decline in resilience overlaid with non-linear health fluctuations [22:30]

- Peter goes back to something Brain said a moment ago, which is absent the equations, biologists have to rely on their intuition

**If we believe in the primacy of that homeostatic deterioration that you just described, what is driving it? Is this entropy? What is it that is changing?**

- [Entropy](https://en.wikipedia.org/wiki/Entropy) has been used off and on ever since Brian started in the aging field
- Peter thinks it’s just a lazy term we use because we don’t have something better to say
- Brian thinks there’s a nugget of truth in that
- His colleague [Peter Fedychev](https://www.linkedin.com/in/peterfedichev/) at [Gero](https://gero.ai/about) is probably the deepest thinker in the aging field in terms of understanding the process of aging at a mathematical level
- Brian was a math major, and he works with Peter Fedychev to help him reframe what he says in a way the rest of the world can understand

*Fedychev really thinks about things deeply ‒ his view on aging is it’s all about resilience*

**Brian’s analogy to visualize the relationship between insults, good health, aging, and disease**

- Imagine when you’re young, you’re living in this deep valley and you do all kinds of crazy things

![](https://peterattiamd.com/wp-content/uploads/2025/07/f4-briankennedy.png)

**Figure 4. Analogy to visualize how resilience decreases with age**.

- You get too much fast food, you get sick, you diverge off the bottom of the valley, the lowest activation energy
- And biologically you look older, but you’re in a deep valley
- You keep getting pulled back to health ‒ almost no matter what you do (at least in the short term), you’re coming back into health
- There are hills you can go over into what you would call failure states, which could be chronic diseases or could be some major functional decline
- And that doesn’t happen when you’re young because it’s a very steep hill
- But these hills are coming down as you get older
- When you diverge off the healthy state, it’s harder to get you back and occasionally you go over the side and then you’re in a frailty mode once you have a later stage disease

**The question is how to mathematically model that and it’s more of a dynamic systems type of modeling**

- And when you look at the large data, it almost looks like there’s a linear accumulation of damage
  - Brian is getting to the point where you’re going to understand why he needs the physicist
- What we’re doing now is we’re trying to measure biologic age from large data sets like [UK Biobank](https://www.ukbiobank.ac.uk/)
- Then we’re breaking it down into principle components
- When you do that, a lot of the principle components don’t track with aging
  - They track with sex or smoking or something else
- The ones that track with aging, usually there are a couple of them
  - One of them is the primary driver and it’s kind of going up linearly and that looks like damage ‒ that’s probably the main driver of aging
  - It doesn’t have to be damage; it could be stochastic events, it could be subtle changes

Peter asks, “*When you say damage, what damage do you mean?*”

- That’s why Brian is trying to back off a bit
- It may be stochasticity not really defined as damage, subtle changes here and there that each on their own have tiny little impacts
- But when they start to add up, they put stress on this network and eventually it starts to break down

***So that looks linear, and the problem is that mortality looks exponential***

- If you model it into a mathematical equation that talks about these valleys going down
  - That’s a linear change
  - But the chance the ball’s going to go over the hill is an exponential change

***What Brian likes about it is you can fit human data into an equation that is compatible with*** [***Gompertz equations***](https://en.wikipedia.org/wiki/Gompertz_function) ***and exponential increase in mortality***

- He thinks it’s on the right track
- There’s probably a lot of changes

**There’s also another component usually in these biologic aging clocks that’s age related, and it’s oscillating**

- It sort of oscillates around that first component going up
- Brian thinks that’s why you see these methylation clocks are going up and down and changing and everything

Brian explains, “*I think of that component is how well you’re functioning at the damage state you’re at*.”

- You have all these events that are going bad and that’s defining your age
- Maybe it says you’re 50, but then you can be somewhere between 40 and 60 depending on what your behavioral patterns, what supplements or drugs you might be taking
  - And those things are going up and down
- That’s why when you get sick, you look older and then you get better, you come back down
  - That first driver is not changing, it’s the second one that’s oscillating
- And most of the interventions seem to affect the second one, which suggests that what we’re doing right now is…
  - I’m going to say this, then I’m going to qualify it

***It suggests that what we’re doing right now is sort of working around the edges***

- We’re doing things that may have 5 or 10 years impact on healthspan
  - Which by the way is a revolution if that’s successful.

> “*I think that’s a major breakthrough in medicine if we can give everybody five or 10 years of extra healthspan.*”‒ Brian Kennedy

**⇒** But these things may not impact maximum lifespan in humans, and they may not get us to 150 or 200

- The kinds of ways to get there may be totally different kinds of interventions
- Brian is thinking about that a lot with [Peter Fedychev](https://www.linkedin.com/in/peterfedichev/) right now
- Brian switched his research into translation about 10 years ago because I was like, “*I don’t want to be retired and 80 on a porch somewhere and not have any impact on humans.*”

*But now he’s starting to think back a little bit to basic science because he’s starting to think that the interventions that we need to develop if we really want to have the big changes are not being done yet, and we have to go back to some discovery science to do that*

**Understanding Resilience as the Missing Link Between Aging Damage and Mortality Risk**

- We have a linear process of damage (he’s using that word loosely) and over time, that is increasing monotonically and linearly and it’s not alterable
- Superimposed on that, we have cyclic episodic volatile change that probably explains a lot of the difference between two 50-year-olds that you might see
  - You might see a 50-year-old, they look great
  - You see another 50-year-old, they look like they’re 75
  - Why?
  - Or you might see it even within an individual
    - Boy at 50, I looked horrible, but I got my act together and by 55 I actually look like I did 10 years sooner
  - So that’s the superimposed curve
- You’re saying, look, everything we’re doing from a translational perspective, all the stuff Peter talks about, wrote a whole [book](https://www.amazon.com/dp/0593236599/?bestFormat=true&k=outlive%20peter%20attia&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_7&crid=2QT68H85V04W4&sprefix=outlive) on this topic is: *How do you impact the oscillation?*
  - Well, if you sleep this way, if you exercise this way, if you eat this way, if you take this supplement, this drug, manage all of these factors, you are absolutely going to put yourself on the better wave here
  - But you are not impacting this guy

**Is your explanation for why aging follows a** [**Gompertz curve**](https://en.wikipedia.org/wiki/Gompertz_function) **as opposed to a linear curve, is that all due to the superimposed wave that goes on top of the linear curve?**

*Or was there another reason that aging follows exponential Gompertz law?*

- No, Brian conflated 2 ideas a once there
- Peter has described the wave better, so we’ll leave there with that
- He thinks Peter is right: ***it’s almost like we’re trying to get to the best state we can be at for the damaged state we’re in***
- Peter loves this description

**What Peter says to patients**

- People come to Peter and say, “*I really want to live to 150. I’m told you’re the guy.*”
- Peter replies, “*Actually, I’m not the guy. I don’t believe it’s possible. What I believe is possible is 7 to 10 more years of infinitely higher quality life. And if that’s not what you want, if you want something that is far in excess of that, you’re going to have to go to somebody who’s got proof that they can do different.*”
- Brian doesn’t think there is any proof right now, but he leaves the idea open that it could be possible

**Brian’s analogy to understand the linear to exponential aspect of aging**

- You’ve got a ball, if you do it at 2 dimension, you’ve got a curve that looks like this and you’ve got a ball here, and the damage is causing the [hills] to come down
- And so the chances the ball going over is actually exponential
  - So even if you have a linear reduction in the height of the hills, the activation energy will increase probability exponentially over the curve

*Peter is trying to think through why that’s the case*

- Is it a V-squared problem in getting over the hill if we were to model it out as actual balls?
- It’s something like that

***It also explains very well why treating disease doesn’t work because you have 50 failure states you can go into***

- Each person based on their genetics and their lifespan, the hill to go over that failure state may be a little bit different
  - Sometimes person’s not going to go over this one, but there’s a chance you’re going to go over a lot of different failures
  - If you block one of them, say you treat diabetes or something, you’re still going to go over the other ones

***The only way to really slow aging is to keep the hill higher***

- Peter thinks that’s a beautiful mental model for how to think about it and yet still equally infuriating because he don’t know why the walls are coming down

**Why are the hills coming down? What’s the particle reason for the wall height coming down?**

- Brian thinks the hills are resilience

**⇒** Resilience is the most important term in aging that nobody understands

*All Brian can give is a half-baked answer*

- What’s happening is this damage is impacting this network that’s keeping you healthy (this homeostatic network)
- It’s in little ways here and there and here and there and the network compensates for that and does okay, but when enough damage happens, you just can’t compensate anymore for events that are happening
- So, when you get sick, you get some viral infection or you fall down when you’re 80 and break your hip, ***you just don’t have that homeostasis pathways in place to allow you to recover and compensate for that***

## Speculating on the future of longevity: slowing biological aging through noise reduction and reprogramming [33:30]

> “*This idea of the linear and monotonic increase in damage is the thing that has to be addressed if we’re going to make a step-function change in human longevity*.”‒ Peter Attia

- Peter likes how Brian has described it: we’re really tinkering around the edges
  - [with current interventions for longevity and improved healthspan]
- But if we fundamentally want to get to a point where maximal human lifespan is changed and healthspan is fundamentally altered, we have to bend the slope of that line

**What is the probability in your mind that rapamycin is doing that based on what you’ve seen in animal models?**

- If you look at something like a worm, the modeling is very different there
- Worms are already in a failure state
  - They’re designed to last for two weeks
  - They don’t have that homeostasis that humans have
  - You can get huge impacts

**⇒** You can get filled by the success of interventions in worms; the effect size in humans is going to be much smaller

***Brian suspects that’s where rapamycin is ‒ it’s going to provide a modest effect in size but not change the hill (not change the slope)***

- He doesn’t think any intervention is going to affect everybody, but a majority of people may benefit from it

**Brian is one of the few people (along with** [**Matt**](https://www.linkedin.com/in/mkaeberlein/) **and** [**David**](https://www.davidsabatinilab.com/)**) who can really talk in depth about rapamycin and mTOR**

- Let’s stay in the world of speculation
- If you had to even imagine something that can change the slope of the line
- Let’s define maximal lifespan as the 90th percentile of lifespan
  - Maybe age 90 or 105
  - 120 is the 99.999 [percentile of absolute lifespan]
- If we’re going to take the 90th percentile of human lifespan up by 25 years and in the year 2100, 90% of humans will live to be 130

*Give me your best guess as to what did this (this is a fun, sci-fi game)*

- Is your guess going to be small molecules, genetic engineering, epigenetic engineering, or multimodal?
  - It’s going to have to be 10 different things
- Brian thinks the scary thing is that that linear accumulation, it does look like entropy, which reversing the second law of thermodynamics is
- We don’t have to reverse it, we just have to slow it down
- Even slowing it down is a challenge from a physics standpoint

>  “*My motto with the consulting I do is that I know what I don’t know.*”‒ Brian Kennedy

- It’s not a good motto for consulting
- As you get into the physics of it, it’s really about temperature
  - Brian doesn’t mean temperature in terms of the temperature in the room

***He means the energy in the system that’s driving the changes or damage, and the question is how do you lower that?***

- Maybe what you need to do when you’re looking for longevity interventions is not looking for how long a worm lives
  - Because the worm is dying for a different reason
  - It’s already in the failure mode

It’s about how to lower the noise in the system and lowering the noise in the system might be a way of changing that slope

- That could be transcriptional noise
- It could be anything you can measure as noise that happens over time
- Now that may also come with secondary effects that people don’t want
  - There might be a retardation of growth and development early in life and it might be one of those things where you don’t want to touch the slope for the first 30 years of life
- Where’s the point at which you want to intervene?

That temporal component is really important

- It’s taking us into a different concept, **antagonistic pleiotropy**
- It is true that if you look at all the yeast mutants that extend lifespan, most of them would not make happy yeast in the wild
  - They slow growth or they do something else
  - It affects some property like mating that is not going to make for a yeast that survives through natural selection
  - But if you put them in a lab, they can divide more times

**⇒** A lot of long-lived mutants have fitness costs

***The question would be that if you target this noise in the system (which is a completely different way of thinking about interventions), what will the fitness cost be with that?***

- Maybe you can get around it by temporal things like the mTOR pathway you probably don’t want to impact as a child, but as an adult, it’s more important early in life than it is later in life
  - It’s only important at certain times
- So, if you impact it the right way, you can get the benefits without the cost

***Maybe that’s possible at these interventions, but we’re so early that Brian can’t with any confidence say what kinds of interventions would have that impact***

**Brian thinks reprogramming is potentially a way to mitigate some of this entropic change**

- Because if you can replace the cells with new cells, those new cells may have some of the damage because they come from the old cells, but they would probably get rid of a lot of the damage too
- That may be a way of changing the slope
- Reprogramming is still very early stage, that may be feasible strategy

## Evaluating the role of the epigenome in aging, and the limits of methylation clocks [39:00]

**Peter’s thought experiment to give Brian a twin**

- Brian remains in Singapore, and now we’re going to have a North American version
- We have 2 of Brian, and one is going to act as the control (we’ll give him some vehicle)
- On the second Brian, we’ll use [CRISPR](https://en.wikipedia.org/wiki/CRISPR#Applications) to revert his entire epigenome (in every cell) to be what it looked like when he was 20 years old
  - Let’s assume fidelity of CRISPR
  - And anytime the epigenome gets out of whack, it’s changed right back to 20-year-old Brian
  - Only the epigenome is changed (not the genome or proteome ‒ although Brian argues that those are going to change)

*What is your guess as to the difference in lifespan and health span of those 2 versions of you?*

- Interesting question
- There would be a difference for sure; Brian is not sure it would be a huge difference

***Brian is not as sold on the primacy of the epigenetics***

Peter asks, “*What could go wrong?*”

- Peter gives the example: if you look at epigenetic code for two different hepatocytes (liver cells), one from a 20-year-old, one from a 50-year-old (and you know which one is from the 20-year old and the 50-year-old); then you see a bunch of others ‒you can always tell which one’s the older one, which one’s the younger one
- Brian adds that you can probably tell that from the mitochondria or a lot of other things too

*Is your belief system that just because you revert the epigenome back to what it looked like when it’s 20, it’s not going to change gene expression enough to move the needle?*

- Brian thinks it’ll definitely influence gene expression
- But there’s also DNA damage that’s happened; there are mitochondrial changes
- The question we’re asking is: If you revert that, how many of these other things can we fix and restore?
  - That’s the unknown answer

***Brian suspects you would have a significant impact on those things, but not fully restore them***

- He thinks the question of the primacy of the epigenome is an open question
  - Nobody knows the answer to this

**How would you design the experiment to test that?**

- That’s difficult because if you want to do it in a very direct way, you really need to modify the factors that are controlling the [epigenetic regulation](https://en.wikipedia.org/wiki/Epigenetics#)
  - But there are a lot of factors doing that
  - It’s not just [DNA methylation](https://en.wikipedia.org/wiki/DNA_methylation), it’s [histone modification](https://en.wikipedia.org/wiki/Histone#Histone_modification)
  - There’s nuclear packaging and [nuclear lamins](https://en.wikipedia.org/wiki/Lamin#) which are linked to aging as well
- There’s not just one pathway to change

***From a real life standpoint, it’s hard to think about how you would do that effectively***

- People have really jumped on this idea of the epigenome being a driver of aging because you can get a biologic age by measuring the DNA methylation changes across the genome
- But you can get to that same point by measuring the **proteomic changes,** by measuring the **microbiome changes**, by looking at **facial structural changes**
  - [Jackie Han’s](https://cqb.pku.edu.cn/hanlab/Team.htm) got great [data](https://www.nature.com/articles/s42255-020-00270-x) on that in China
- Anything in a human where you have a deep enough data set that’s enriched enough and you have samples across a wide enough age range, you can make a clock that predicts their age and the facial clock is about as accurate as the [methylation clock](https://en.wikipedia.org/wiki/Epigenetic_clock)

> “*I think that a lot of people have jumped on this methylation or epigenetic bandwagon, but they’re taking association and causality and they’re making a big leap there.*”‒ Brian Kennedy

- We know that you can modify epigenetic factors and extend the lifespan of yeast and worms and flies, maybe even mice
- So, it does have a role, but you can do that with catalytic factors or nutritional regulators or calorie restriction or a lot of other things
- It’s not clear to Brian that that’s a bigger effect than you’re going to get from targeting these other interventions
- To be fair, none of them are completely reversing things either
- So, they’re not addressing your question

## Balancing the quest for immortality with the urgent need to improve late-life healthspan [43:00]

**Do you think that immortality is impossible unless we define it through AI copying your brain? I mean physical immortality, do you believe that that is impossible?**

- Brian likes to tell people that he’s immortal because he thinks that’s a very healthy mindset
- Peter talks a lot about the emotional aspects of aging in his book [[*Outlive*](https://www.amazon.com/dp/0593236599/?bestFormat=true&k=outlive%20peter%20attia&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_7&crid=2QT68H85V04W4&sprefix=outlive)] (Brian loves that chapter), but he doesn’t really believe it’s true
- He thinks the odds that you could achieve that level of change in aging is non-zero, but close
  - He’s skeptical that it can be done, but he wouldn’t rule out the possibility
- Of course, nobody’s ultimately going to be immortal because you’re going to get hit by a bus sooner or later
- What you’re really talking about is being immortal in terms of dying from aging

*What Peter is really saying is can one ever get to the point where resilience is high enough that you cannot die from disease?*

- Brian has seen nothing so far that suggests that’s possible, but that doesn’t mean it isn’t possible

*Physical frailty and sarcopenia*

- For Peter, that gets even to physical frailty and [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) and things like that, where even when we see centenarians and supercentenarians, their frailty is still pretty remarkable
  - Meaning they still look pretty feeble and frail
  - Age adjusted, they’re great
  - But at the end of the day when they’re 110, they still look like someone who’s in the final years of their life just as someone would if they were 84, 85
- Brian had 2 grandmothers that lived to almost 100
  - One was still driving at 95
  - At 93, she bowled a 238 game
  - She was like a 70-something-year-old at that  point
- Peter’s point is she just had a phase shift of 20 years, but it didn’t undo theinevitability of that decline

***Brian agrees with that ‒ getting to 100 is a good goal***

**Do you think that we’re spending too much time worrying about finding immortality, escape velocity, understanding the core of aging, when maybe we should be spending more time on how do we preserve healthspan in the last decade of life?**

*Why is it that most people in the final decade of their life are physically too frail to enjoy life?*

- They’re just not cognitively sharp enough (even absent Alzheimer’s disease)
- They’re in pain
- They’re fracturing their hips
- They’re not doing what gave them joy through most of their life

***Brian agrees, we should fund aging somewhere closer to the level we’re funding cancer and answer both of those questions at the same time***

**Questions to fund research on**

- 1 – One of them is a translational question: How do we slow aging as much as we can right now and improve the health of the population as much as possible?
- 2 – The other one is a basic science question: Can we stop aging? Can we reverse aging?
- If anybody tells you they have the answers to that, they’re lying to you or they’re lying to themselves
- We don’t know
- It’s maybe the most important question in biology and we should be throwing money at it
- We’ve seen all this money go into the private sector side, biotech companies, supplement companies, longevity clinics, and on and on.
- Brian has spent a lot of time working with those groups because he thinks it’s important, but we’re not seeing the academic funding that’s going into the basic science of aging and longevity
- The big questions that Peter just raised are still not answered

Brian adds, “*I’m changing your question to a plea for more funding, and unfortunately, the kind of funding that supports that is usually government funding, foundation funding. That’s under major threat right now. I’m really worried that we’re not going to answer those questions.*”

- This was a discussion that came up on a Longevity Roundtable [episode [#333](https://peterattiamd.com/longevityroundtable/)]
- Most people, including Peter were really surprised to hear how disparate the funding differences are, and if you could reallocate 10% of funding from the disease-specific pools to the age pools, it could have an enormous difference based on that
  - Enormous is an understatement

## Comparing the big 4 chronic diseases: which are the most inevitable and modifiable? [47:15]

- The big 4 chronic diseases are: cardiovascular disease, cancer, dementing diseases, and metabolic diseases
- Peter has often maintained that the least inevitable of them is ironically the one that is the most deadly today, which is cardiovascular disease, atherosclerotic diseases
  - Cerebral and cardiovascular are, ironically, the most preventable, both because we have the best understanding of what causes them and we couple that with the most tools to prevent them
  - Whether it be tools to combat hypertension, dyslipidemia, etc.
  - They’re responsive to lifestyle modification

**Which of those major diseases of the other 3 (dementing, cancer, metabolic disease) do you believe is the most inevitable to our species?**

- Brian wouldn’t put metabolic disease in that category (Peter agrees)
  - Because he sees that more like cardiovascular disease

*Of cancer and the dementing or neurodegenerative diseases, which one is seemingly inevitable?*

- We don’t know enough about dementia to answer
- Cancer is a little bit different than these other diseases
  - It may be less modifiable by longevity interventions
- Brian’s guess for dementia is it’s highly modifiable too, but there’s not enough data to be sure of that like there is for metabolic and cardiovascular disease
- Cancer is an accumulation of mutations ‒ it’s a more defined event that’s happening
  - It’s also an impact on the immune system that’s different a little bit than normal aging
  - It may be less approachable from a longevity viewpoint
- Peter shares that exact view, that cancer is the most inevitable of these diseases

**Do you think that the inevitability or the age-related component [of cancer] stems more from the accumulation of mutations or the weakening of the immune system?**

- It’s probably both
- You don’t get the cancer without the right mutations happening, but we’re learning more and more that the immune system is playing a major role in it
- We can see that very clearly from the interventions that improve immune function and they’re having a big role in certain types of tumors
- Brian thinks that’s going to be true for Alzheimer’s and dementia as well

***We’ve completely underestimated the role of inflammation in the immune system and those diseases as well; they may be the primary drivers***

**Brian is very frustrated by the Alzheimer’s field**

- There’s been so much focus on one or two mechanisms of disease that we spent 30 years *not* studying the others, which may be more important

*Why do you think that’s happened?*

- Peter points out that’s not an isolated incidence in science
- This is a field where the results are otherwise so dismal

Brian replies, “*What’s the saying that scientific progress happens one funeral at a time?*”

- That’s part of it
- You get people that have successful research programs and their post-docs get hired in all the jobs
  - So, when you take a field and it grows from a small field to a bigger field, everybody can draw their lineage back to 4 or 5 different PIs
  - Those PIs get really focused on those models and they see that as their ticket to prizes and things like that

***Then you focus on a subset of the disease mechanisms at the exclusion of all others***

- Brian doesn’t want to single Alzheimer’s out ‒ a lot of diseases meet that category

***What we’re realizing is that there’s a lot of factors that contribute to any disease, and longevity may be an interesting way of looking at it***

**Mouse models of Alzheimer’s disease**

- We’ve tried to make Alzheimer’s models in mice and they don’t prove that informative
- Why? You’re creating a disease a mouse doesn’t get genetically in a young mouse and comparing that to a natural disease in an old human

***Brian thinks you learn more about Alzheimer’s if you look at the brain neurodegenerative changes that happen in the mouse normally with aging***

- The downstream things are different, but the drivers may be the very similar to the ones that are driving Alzheimer’s
- That may be a better model of Alzheimer’s than trying to artificially create something that a mouse doesn’t get
- Aging is helping change that perspective

> “*The drivers of aging I think are very similar between a mouse and a human. That downstream events can be different, but the drivers are what we care about*.”‒ Brian Kennedy

## Exploring potential benefits of rapamycin: how Brian is testing this and other interventions in humans [51:45]

**Do you believe that the primary effect of rapamycin is tamping down maladaptive inflammation through obviously the intermittent blunting of mTOR?**

- That’s one of the major things
- There’s good evidence for enhancement of [autophagy](https://en.wikipedia.org/wiki/Autophagy)
- There’s good evidence for changes in [protein translation](https://en.wikipedia.org/wiki/Translation_(biology))
- And those things are not mutually exclusive to inflammatory changes
- Those are the 3 things that we have pretty good evidence for

> “*I really think that all of these interventions that we’re looking at are restoring dynamic range…We’re restoring things that happened when you were young*.”‒ Brian Kennedy

- It may take super physiologic changes to change that linear line, but that’s not what we’re looking at right now

Peter explains, “*Given that we’re not likely to have human clinical trials of rapamycin that study aging for the simple fact that we don’t even know what an aging biomarker is, we’re going to largely be extrapolating from animal data if we have to make decisions about humans using rapamycin for geroprotection.*”

- Brian pushes back a little

**Brian is doing a study in Singapore on humans**

- A 6-month intervention with rapamycin
  - Peter’s initial response, “*Yeah, you can’t in 6 months.*”
- We’re looking at many different parameters of age (not disease)
- We’re taking people age 40-60 without disease
  - They may have a precondition for a disease, but they don’t have anything that would be defined as a disease (it could be high glucose)
- Then we’re looking at changes in a wide range of different biomarkers, clocks
- We have around 150-200 people  in the study (it’s not huge)
- We’re dosing it intermittently (5 mg rapamycin, once a week)
- It’s being run by Brian’s collaborator [Andrea Meyer](https://discovery.nus.edu.sg/19564-andrea-britta-maier)

*Measuring*

- A range of clocks
- Inflammatory cytokine panels
- Functional measures
- [Pulse wave velocity](https://en.wikipedia.org/wiki/Pulse_wave_velocity)
- [DEXA](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)
- Strength measurements
- Cognitive measurements
- Brian is missing a couple of them

*Do you expect to see changes in strength or cognition or things like that?*

*Do you worry that those are the wrong outcomes to look for in a 6-month study of people that are young?*

- This comes back to: What do you measure?
- Brian doesn’t think we know
- Certainly you can change those parameters
  - If you exercise, you’re going to change your strength measurement
  - Exercise might also change the cognitive parameters
    - Peter adds that a 6-month sleep correction trial would undoubtedly change cognitive parameters
- For Brian, it’s not unreasonable that a drug could do these things as well

**Rapamycin is complicated when it comes to muscle ‒ Brian’s observations with personal experimentation**

- Brian knows that partly because he’s going to be non-scientific for a minute
- He’s become his own best model organism: he tries all kinds of different things on himself
  - He admits, “*I know it’s n=1*”
- He’s not sure what rapamycin is going to do to skeletal muscle without exercise
- Brian is a runner (always has been); he’s gone to more lifting in the last 3-4 years

**⇒** When Brian takes rapamycin and does a hard run, he’s noticed: “*I don’t have good runs within 24 hours of taking rapamycin.*”

- It may be because you have to activate mTOR in a context or something like that

 Peter asks, “*What about if you take rapa after a run? Is your recovery better?*”

- Brian doesn’t have a sense of that
- What he knows is 3-4 days after he takes rapa, he has really good training

Brian explains, “*I think what’s happening is that maybe in that short window after you take it, you can’t activate the pathway enough, but in the long-term, what you’re doing is dampening the basal signaling and you’re getting a better dynamic range.*”

- Perhaps his trough levels are low
- Peter is going to experiment with that
  - He always takes rapa the same day of the week
  - He does the same workouts on the same days of the week
  - He’s going to do an adjustment and see
- Brian doesn’t know what the effect is on resistance training

**What tools do we have to measure** [**autophagy**](https://en.wikipedia.org/wiki/Autophagy) **in humans?**

- You can pull out blood cells and you can look at **white cells** and see whether autophagy pathways are induced or not
- You can take **muscle biopsies**
  - We don’t really like doing that in our clinical studies because it makes it harder to get volunteers
  - If you do muscle biopsies the right way, they’re probably not that painful to people, but people have that perception and we need healthy volunteers for our studies
  - Brian would love to look at muscle

*Brian thinks that autophagy is another one of these dual-edged swords*

- You don’t want autophagy on all the time
- You want it on at the appropriate levels at the right time
- If it’s on all the time, you’re going to get **muscle atrophy** probably
- So, it’s about dynamic range

**What would you need to see in this study to feel that rapamycin is geroprotective?**

*Peter’s concern is since we can’t measure aging, we’re not going to see enough of a signal*

- Peter’s concern would be that you’re not going to see a difference in: DEXA, physical performance, cognitive function
- You might see a reduction in certain cytokines, but not all cytokines
- In an ideal world, epigenetic clocks would be the perfect tool to measure them except for the [Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) experiment [discussed in episode [#333](https://peterattiamd.com/longevityroundtable/#:~:text=Matt%20tested%204%20different%20direct%2Dto%2Dconsumer%20biological%20age%20kits) after 35:00]
  - Brian brings Matt to all his conferences now because he uses that slide where he did all [the direct-to-consumer biological age kits] at once
  - Matt Kaeberlein bought 4 of the top commercial tests, did them in duplicate simultaneously
  - He took 8 tests at the same moment in time
  - He has a funny graph that shows how pathetic they are

***Not only do none of the biological ages tests agree with each other, the identical tests rarely agree with each other***

Peter adds, “*So, just if you’re listening to this and you want to go out and get a commercial test that tells you how old you are biologically, reconsider it*.”

There are multiple issues here

- 1 – Do the consumer testing companies have a standardized enough protocol that it’s reliable (Brian is skeptical)
- Brian is doing everything in-house for the study he’s doing with Andrea
- He has the potential for a better clock
  - Consumer-wise, there are concerns

**What are you using as a control when you talk about given how inflammation and epigenetic change might be the only two signals that you find here?**

- Peter is being pessimistic in thinking there will not be a finding in any of those other measurements, but you might have a chance with inflammation and the epigenome
  - Brian adds [pulse wave](https://en.wikipedia.org/wiki/Pulse_wave_velocity)
- Peter’s problem with pulse wave: it’s so user-dependent in terms of the technician who is doing it
  - We don’t use it clinically at all because we think it’s a useless test
- Peter thinks the [carotid intimal thickening (CIMT)](https://en.wikipedia.org/wiki/Intima%E2%80%93media_thickness) is a useless test, and that’s an easier test to do because unless you have a tech who basically has a PhD in how to do vascular imaging and they’re the only one that does it every minute of every day

***Peter worries that all of those tests, they’re just going to be noise, no signal, but these other 2 might have signal***

*What’s your control for accelerated aging or something else?*

- In other words, it’d be really interesting if you did a 6-month parallel fasting trial
  - Where you took people and you rendered them hypocaloric, you put them on some draconian 60% calorie diet for 6 months where you really think you would tamp down inflammation and autophagy
  - If anything’s going to reprogram the epigenome in six months, you think that would be it?
  - That would be a very interesting control, even if you had a fraction of the number of subjects

Brian is doing multiple studies

- The first study was with a time-release version of [AKG (𝛼-ketoglutarate)](https://en.wikipedia.org/wiki/%CE%91-Ketoglutaric_acid) with PDL Health
  - That study is finished and we’re analyzing the data (so he can’t say much about the data yet)
  - We did a 6-month and a 3-month follow-up
  - We want to see if there changes, and do they maintain if you stop taking the compound?
    - Because in mice, oddly they do for aging, but Brian is skeptical that’s going to happen in humans
- Brian is doing multiple studies
  - They’re not all at the same time
  - We will be doing the same study over and over and over again with different interventions
  - An ITP equivalent in humans
- Brian doesn’t know if 6 months in humans is long enough
  - He doesn’t know if they’re doing the right tests
  - He doesn’t think anybody knows these answers

**What is the cost of doing that experiment you just described?**

- About $1.5 million in Singapore (so that’s $1-1.5 million US dollars)

**How can people fund insanely high levered research?**

- Peter gets asked by people all the time, “*Where can I put money?*”
- Brian would love that because it’s really hard to raise money for this still
- Peter thinks many people listening to this would like to put a million dollars to work on something that would add a decade to life
  - He thinks you’re better off putting money into this type of translational research than you are into basic science or into pharma research
- Pharma is still not doing aging (they’re thinking about it)
- Peter has strong opinions on ideas for how to do some of these experiments

## Testing alpha-ketoglutarate (AKG) for healthspan benefits in aging [1:01:45]

**Walk us through the rationale for how 𝛼-ketoglutarate came to be something that you would put through this type of rigorous program**

*Disclosure*: Brian is involved with [PDL Health](https://rejuvant.com/About), they have a product called [Rejuvant](https://rejuvant.com/Home)

- They came to Brian and [Gordon Lithgow](https://www.buckinstitute.org/lab/lithgow-lab/) many years ago at the Buck Institute, and they wanted to screen [for] natural products that would have an impact on aging
  - Because the mindset of what became the CEO of this company was, “*I can’t get drugs approved for aging at any time in the near future, let’s work with natural products.*”
    - Things the FDA calls [GRAS](https://en.wikipedia.org/wiki/Generally_recognized_as_safe) right out of the gate
  - Let’s look for combinations of things that work together because we can get [IP](https://en.wikipedia.org/wiki/Intellectual_property) around combinations, we can’t get IP around single natural products
- We screened a lot of things in worms and [AKG](https://en.wikipedia.org/wiki/%CE%91-Ketoglutaric_acid) came out as one of the best things in worms
- Then we started testing interventions in mice
- Brian’s group does 4 or 5 different intervention studies in mice every 6 months now
  - Not just with natural products and not just for this company
  - We built that into our own kind of ITP in mice too, although we do it differently

***AKG came out as one of the biggest effects, and then in the mouse studies we found that for male mice there was a combined effect with vitamin A***

- Vitamins are an interesting discussion too
- There was also a combined effect with both sexes with vitamin D, and so that led to this product [Rejuvant](https://rejuvant.com/Home), which is time-release
  - With AKG that’s very important because otherwise it goes away in 5 minutes if you don’t have a time-release version

**Tell folks what 𝛼-ketoglutarate is. Is it part of the Krebs cycle?**

- Yeah, it is part of the [TCA cycle or the Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle)
- It’s a central metabolite involved in hundreds of reactions

***It’s a lot like NAD, they’re doing different things, but they’re both central metabolites, they’re both going down with aging in organisms and the idea is supplementing them back up would be beneficial***

**⇒** When we did that with AKG in mice, we see about a 5-10% increase in lifespan, but a dramatic decrease in frailty

- This squared the longevity curve discussed earlier
- If that translated to humans, it would be a big impact

Peter adds, “*I think that if you did not extend lifespan by a day, but you just improved healthspan, that’s a home run.*” (Brian agrees)

- Improving healthspan is what most people want
- What we’re doing now is providing more lifespan without healthspan
  - It’s called medicine 2.0 (that’s treating disease)
- Brian is still excited about this product, about AKG and especially the time-release version, and there’s been some studies that have been [published](https://pubmed.ncbi.nlm.nih.gov/34847066/), one of which we helped analyze the data for using rudimentary methylation clocks showing that it reverses aging by a few years
- Again, it’s that oscillation thing we were talking about earlier, and that’s why we wanted to do a controlled placebo, double-blinded clinical trial at the university
  - In that case we’re just testing the time-release AKG
  - We didn’t include the vitamins because we’re trying to get some mechanistic information, we don’t want confounders in there

***The data is still pretty good on AKG that it’s going to have an impact in people***

- That human trial has been completed, you’re evaluating the data, you’re going to have to see a signal

**In each of these trials, do you do the same measurements, the same outcomes?**

- Generally, yes, but we sometimes modify the primary endpoint because we want to choose a primary endpoint that’s most likely impacted by the intervention
- In a way, it doesn’t matter that much because we’re measuring as many things as possible anyway
- Of course, we learn over time as we do things, so we add things or take things out that are not working well, that sort of thing

## Exploring urolithin A’s potential to enhance mitochondrial health, reduce frailty, and slow aging [1:05:30]

**Did you guys do a study on** [**urolithin A**](https://en.wikipedia.org/wiki/Urolithin_A) **as well?**

- We haven’t published it yet, but Brian is happy to talk a little bit about it

***We don’t have human data, but the mouse data is really good on urolithin A: it dramatically reduced frailty and male mice but not females***

- And so we’re repeating that, there may be specific differences
- We were the first ones to see that, so we want to go back and see what’s going on
- Peter recalls a newsletter he wrote on this where he came down on the side of, “*This isn’t doing anything*.”
  - Maybe he’s mistaking it for a different molecule

*Is this the one that in theory enhances mitochondrial function?*

- Yeah
- The idea is that it enhances [mitophagy](https://en.wikipedia.org/wiki/Mitophagy), so turnover of damaged mitochondria
  - Brian is not sure he completely agrees with that, we do see that in cell culture, but we also see mitochondrial biogenesis, and so these 2 things are connected
  - If you induce mitochondrial biogenesis, you’ll also induce mitophagy, and he’s not sure where’s the chicken and where’s the egg in this, but it does seem to induce mitochondrial turnover, but we also find other pathways
- When we look at a molecule, if we don’t know enough about it
  - Take for example rapamycin, we know it binds to mTOR
  - Urolithin, we don’t know what it does
  - And AKG also, we know a lot of things it can do, we don’t know which ones are relevant for aging
- For urolithin, we went back and did this screening assay to proteomics, thermal shift assay to look for binding partners for the compound, and we have some

*Tell me about the history that led to using it*

- [Johan Auwerx](https://people.epfl.ch/johan.auwerx?lang=en) published this [data](https://pubmed.ncbi.nlm.nih.gov/27400265/) that it was slowing aging in mice, and that’s led to a lot of research
  - Brian wasn’t the first one to study urolithin

Brian adds, “*A lot of what we do is testing interventions that come from other labs because if I’m going to do a human study, I want to at least see it repeat in my hands in an animal first.*”

**Do we know the mechanism of action for urolithin A?**

- They would argue it’s increased mitochondrial turnover
- Brian has targets he hasn’t published yet
- He plans to study this in humans, but it hasn’t been done yet

Peter suggests, “*This might be actually one of the ones where I would say, unlike in the RAPA trial, you actually want to come up with primary outcomes that are quite different.*”

- Peter would want to see: fat oxidation, Zone 2 efficiency
  - If urolithin A is improving mitochondrial function, he’s not aware of a better test of mitochondrial function
- Brian agrees and adds: that raises the point of whether we should couple these interventions to exercise
  - That adds complication, but it may be worth doing in this context
- And do muscle biopsies on these people because it’s just too important to understand what’s happening
- For this study, you’re going to have to get athletes

***Brian thinks a lot of these supplements are impacting exercise*** (going back to the n=1 story)

- It’s kind of a win-win, you take something, you exercise better, you drive benefits from that exercise
  - You win twice with some of these

## The potential of sublingual NAD for longevity, and the combination of NAD and AKG for metabolic and exercise enhancement [1:09:00]

**Brian’s experience with** [**NAD**](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide)

- Brian has been very skeptical of NAD
  - Not that going down and restoring it won’t be good
  - He’s skeptical it’s going through [sirtuins](https://en.wikipedia.org/wiki/Sirtuin)
  - It could be doing a lot of other things, but he’s also skeptical that [NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside), [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide) are really changing NAD levels that much
- Brian’s mice don’t really respond in studies with NR, NMN
- He’s personally never noticed anything taking NR (again, that’s just one person)

**Peter’s view on NR**

- Peter knows he’s going to get a lot of hate mail for saying this
- When Peter last looked at NR, the only [study](https://pubmed.ncbi.nlm.nih.gov/30668199/) he’s seen in humans that shows a real benefit of NR was in patients with ALS that had the patients in the NR group had a longer time before requiring ventilation than the patients on the placebo

*Is there another study?*

- There’ve been health spend studies arguing improved health spend
  - Brian doesn’t know the metric used
- Brian sees very subtle changes in aspects of frailty measurements (in mice), but it’s not enough to convince him that it’s statistically significant

***Brian wouldn’t be shocked if there is a tiny effect***

**Why do you think this is? Do you think that NR and NMN are not efficient vehicles to generate enough NAD?**

- Yeas, that’s one thing for sure

*The rest of the story and why Brian has given up on the pathway*

- A company ([iX Biopharma](https://www.ixbiopharma.com/)) came to Brian and wanted him to test one of their products (a [sublingual NAD](https://www.biospace.com/press-releases/new-study-demonstrates-that-sl-nad-delivers-nad-into-cells))
  - They specialize in technology for sublingual delivery, and they make other things too

*Explain to folks why you can’t take NAD orally because it just gets destroyed*

- Typically, people take NAD intravenously, but if you take something under the tongue, you get this magical property where it dissolves and it enters the circulation without passing through the digestion, and obviously the liver where these things get chewed up
  - You can do this every day
  - Lots of drugs are given in this manner ([*sublingual*](https://en.wikipedia.org/wiki/Sublingual_administration))
  - IV is not practical on a repetitive basis
- It’s 100 mg of NAD, and the one Brian is taking also has [apigenin](https://en.wikipedia.org/wiki/Apigenin) in with (which is a CD38 inhibitor)
  - CD38 is a consumer of NAD, so if you block that enzyme, then you effectively increase NAD
  - This inhibitor is another natural product
- Brian was taking NAD along with the [Rejuvant](https://rejuvant.com/Home) (which is the AKG plus vitamin A, and also it has B complex, but mainly AKG effect)

***When he takes them [Rejuvant and NAD] together, he notices this acute effect on his exercise performance***

- When he’s running, his heart rate goes up, but his respiratory rate doesn’t go up as much
- It goes up a little bit, but normally if his heart rate’s at 150 or 155, he’s breathing hard
- He’s breathing closer to normally when he takes these 2 things together
- He’s gone off, gone back on; he’s taken one off

Peter asks, “*Is your rate of perceived exertion tracking more with your respiratory rate or your heart rate?*”

- It’s tracking more with Brian’s respiratory rate
- He doesn’t perceive that he’s exerting… he runs faster when he uses it

**What Peter would like to measure**

- Measure your lactate levels at a fixed heart rate under those 2 different respiratory rates, but under the same load
- Do it on a treadmill just to make it unambiguous
- Peter would be super curious to see a lactate performance curve
- Peter would like to quit his job and do nothing other than these experiments
- Brian agrees, he should do that; but this may happen for no one else (he doesn’t know)
- When Brian goes off [the supplement], it sort of goes away
- It’s starting to not go away now because it’s improving his exercise performance and now he’s getting more fit
  - So it’s getting harder to see the effect
  - But it still comes and goes when he goes on and off either the AKG or the NAD

*Another thing Peter would be interested to see*

- Let’s let’s pretend that “off drug” heart rate is 150, RPE 7, velocity X
- “On drug,” Peter wants Brian to go back to the same RPE, let heart rate go higher, and let the velocity go higher

***He’s curious as to how long you can sustain that relative to what you were doing before***

- In other words, does some other system get in the way that ultimately reduces your capacity?

Brian can answer

- The reason he noticed is he’d taken it 3 days (every morning)
- He was on the treadmill running, he kept pushing the speed up and he was not getting out of breath

***He was going to run 5K and he ran 12K, and he still didn’t feel that tired at the end of it***

- He started thinking, how did this happen?
  - Because he knows how his body performs normally

**Is this molecule in trials yet in humans?**

- It doesn’t have to be in trials; it’s a natural product; it’s on the market

Peter adds, “*Yes, but for those of us who want to actually know if it works… Those of us who believe in this pesky thing called evidence.*”

- There’ve been a lot of animal studies (Brian’s not sure this is published), and when they add sublingually in a rat model, you see the NAD incorporated very highly in red blood cells
  - You have to anesthetize the rats to get the sublingual delivery
  - This was just with the NAD, not epigenetic
- There is literature to support this (this is not Brian’s field), there are channels that can take up NAD directly in certain cell types
- Peter had [Josh Rabinowitz](https://www.ludwigcancerresearch.org/scientist/joshua-rabinowitz/) on the podcast and he talked at length about this [episode [#216](https://peterattiamd.com/joshrabinowitz/)]
  - What Peter took away from that discussion was that intravenous NAD will work
  - The question is, what’s it working for?

**Would the effect you experienced here be mirrored by what somebody experiences with intravenous NAD notwithstanding the limitations of the frequency that they could do it?**

- Yes, Brian thinks so
- But the dose that’s so much higher on IV NAD, it could be too high
- In theory, yes
- This is so simple, every morning it’s gone in 30 seconds
- For Brian, it’s enhanced by the AKG
- You’re adding 2 metabolites that are both going down with aging, that are both involved in hundreds of different…

Brian explains, “*They’re giving you cellular metabolic flexibility, I think that’s what they’re doing. I don’t think it’s one pathway they’re activating.*”

**What’s combined with the 𝛼-ketoglutarate?**

- For a male, it’s vitamin A and the new product has some B complex in it as well [see [Rejuvant](https://rejuvant.com/Home)]
- These are commercially available
- Rejuvant (AKT) has been [published](https://pubmed.ncbi.nlm.nih.gov/34847066/)
  - This was not placebo-controlled; it was a methylation study of users, so take what you want out of that
  - Peter responds, “*Not much*”
- Brian thinks community data is valuable
- If you go back and look at the paper, we didn’t do any of the analysis, we just analyzed the data
- We were very clear in that paper, even in the abstract of the limitations of the finding
- Brian thinks that for community-based data, it’s better to have it out there and published, but you want authors that are willing to be honest about what the data says and what the data doesn’t say
- The study that’s being completed is just AKG time-release, so none of the vitamins, and it’s placebo controlled in as many parameters as we can measure, so hopefully it’ll show something

Peter asks, “*And then are you doing the one with vitamin A and E?*”

- Brain is not doing that right now; he’d love to do that
- He financed the study; the only thing the company did was supply the time-release AKG
- It would be good to go back and look at the actual product combined with this NAD now
- But Brian just figured that out himself 5 months ago, he doesn’t even have any animal data to show that’s true
- It would be interesting to go back and add these things in animals
  - You can anesthetize a rat and do sublingual delivery one time and measure the PKPD, but doing it all the time is going to be a nightmare

## Other interventions that may promote longevity: spermidine, 17𝛼-estradiol, HRT, and more [1:17:00]

[**Spermidine**](https://en.wikipedia.org/wiki/Spermidine) **is getting quite a bit of buzz. Tell us everything about spermidine**

- Brian studied this when he was at the Buck Institute
- We were confused because at that time the data was spermidine could extend lifespan, but it didn’t impact metabolism
  - He knew that almost everything in a mouse that extends lifespan has some impact on metabolism
- So we did a high-fat [study](https://pubmed.ncbi.nlm.nih.gov/34060628/) with spermidine and we showed that in old mice, spermidine could suppress the metabolic dysfunction that came from a high-fat diet
  - But we had some control mice too (not many), but the study wasn’t designed to do lifespan
  - We left them alive and looked at survival and the spermidine extended the lifespan of the mice too

**Has spermidine been studied in the ITP?**

- Neither Peter or Brian think it has
- Brian was able to repeat the lifespan effect in mice even though that wasn’t the goal of our study and show that it restores metabolism in a calorie-challenged context
- That’s what made him believe that it’s a robust molecule
  - That we can see that effect as well
- Brian is optimistic about spermidine even though he hasn’t done a lot with it

**Where does spermidine occur in nature?**

- It is naturally occurring in certain [foods](https://en.wikipedia.org/wiki/Spermidine#Sources)

**Have you looked at** [**𝛼-estradiol 17**](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol)**?**

- No; he would like to look at it
- Brian is also director of an [Asian Center for Reproductive Longevity and Equality in US and Singapore](https://www.acrle.com/about-us/) where we’re looking at ovarian aging
  - It’s like PhD biologist: all of a sudden he’s getting asked a million questions about HRT, so he decided he better learn something
- There’s 2 things Brian has learned from this
- 1 – Geroprotectors tend to extend fertility in mice
  - And it’s not just one thing; this includes spermidine, AKG, metformin, and rapamycin
  - Peter points out a [rapa trial](https://www.nyp.org/advances-womenshealth/pilot-study-evaluates-weekly-pill-to-slow-ovarian-aging-delay-menopause) going on at Columbia
  - That’s one really potentially useful avenue of translation for these geroprotectors, Brian is really excited about that
- 2 – The other thing Brian points out, “*The question should not be: Should a woman do HRT? The question should be: Is there any reason a woman should not do HRT?*”

***Brian sees the value of hormone replacement to far outweigh the risk in the majority of women***

**⇒** 17𝛼-estradiol is interesting because it worked in males (and not females)

- It’s also non-feminizing (Brian doesn’t know what that really means, not sure how much he believes that)
- It could be triggering some of these same pathway

[**Testosterone**](https://en.wikipedia.org/wiki/Androgen_replacement_therapy) **is another one**

- Brian did the study on it and showed a little bit of an increased risk in prostate cancer
- Then everybody said, don’t do testosterone replacement
- That’s been fully debunked now
- Most men are not doing that
- Or if they’re doing it, they’re doing it in an uncontrolled ways that taking levels maybe to too high, that could be dangerous
- Peter feels like men are in a better position today because more trials have been done to undo the bad ones
  - The [TRAVERSE trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025) (published a year ago) undid a lot of the damage of some of the fear-mongering from really bad studies that suggested testosterone was causing prostate cancer
  - Turns out it’s the exact opposite
  - Even though the TRAVERSE had many problems with it

[**HRT**](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) **for women**

- Women unfortunately are still struggling under the dark cloud of the [Women’s Health Initiative](https://pubmed.ncbi.nlm.nih.gov/12117397/) (which was apocryphal, no one’s undone it)
- Brian traveled to 25 countries a year and a lot of countries in Southeast Asia, and so now everywhere he goes, if he sees a doctor, he asks, “*How many women are doing HRT?*”
  - Extremely low
- The changes and what doctors tell people is slower in these countries, but maybe there’s less risk
- It also costs money
- If you have somebody who doesn’t have a lot of access to finances, they may be less able to do it in these countries
- Brian doesn’t know all the reasons, he’s just looking into it now

Brian adds, “*It’s stunning how low the HRT [use] is around the world still, and we’re just missing an easy opportunity, I think, to help people*.”

- Peter agrees
- There’s part of him that is so interested in the frontier of how do you push the boundaries of this stuff
- Peter could be infinitely happy working at the frontiers of thinking about the molecules, but at the same time he feels just as excited about trying to figure out how to make sure people are scoring own goal all day
- There’s so many ways to just help a person without anything magical
  - Find another 5 years of life and dramatically improve health span through judicious use of everything from HRT to correct exercise, reasonable nutrition
    - Obviously the idea of doing both of these is so appealing

**Brian comes back to the US every 3 months ‒ what he notices**

- He lived here for 50 years before he left
- You leave some place, you come back, you notice things you didn’t notice
- He notices the same 2 things, every time he comes back
  - He doesn’t even have to leave the airport
- 1 – So many people are not in shape, there’s so much obesity, it’s striking compared to almost anywhere else in the world.
- 2 – People just seem so stressed here
  - Singapore is a pretty stressed country, and Brian still feels that people are more stressed here when he comes back

Peter asks, “*What are the obesity rates in Singapore?*”

- Relatively low
- But in Asia, there is this challenge with skinny diabetes
  - You have a lot of people who can’t build the adiposity they need
  - They’re storing the fat in the wrong places (visceral fat), and this may be even worse
- The diet is moving more western in Asia and it’s creating problems, it’s just not as obesity associated

Peter asks, “*Do you notice a difference at all based on* [*GLP-1 agonists*](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor)*?*”

- It’s not passing the airport test yet
- He doesn’t know how widespread they’re being used

## Biological aging clocks, clinical biomarkers, and a new path to proactive longevity care [1:23:15]

**Do you think there could be value in the epigenetic clock as a tool?**

- Peter holds a high bar to justify their use
- Right now, we have this thing called chronologic age
  - He can look at your birth certificate and know how old you are, and based on that, he can make an estimate of how much longer you will live
  - For a person who’s 40 years old and another person who is 65 years old, if he know  nothing else about them, he can say with a high degree of confidence that the 65-year-old will live somewhere between 20-30 more years and the 40-year-old will live 30-50 more years
    - Peter is making this up because he’s not an actuary
  - That’s a pretty good test; he knows something measurable about them (their birthdate) and it predicts future life

*Peter’s questions*

- Do you think biologic clocks will ever serve a purpose like that where you could take two 50 year olds and one of them has a biologic age 40, and one of them has a biologic age of 60 according to the clock, and that those numbers will actually be better at predicting future life than their chronologic age of 50?
- Or do you put yourself in the camp that says, “*No, Peter, that’s a ridiculous standard that no biologic clock could ever come to.*”
- But it might tell you about their health, it might be yet another biomarker that says, “*Hey, the guy at 40 is just healthier than the guy at 60*.”
  - And somehow, by the way, it’s picking that signal out of a data field that you can’t pick out anywhere else, because they otherwise look identical

**Brian measured this recently**

- Along with collaborators at NUS ([Jan Gruber](https://medicine.nus.edu.sg/bch/faculty/jan-gruber/) and [Fong Sheng](https://www.linkedin.com/in/sheng-fong-69668429b/?originalSubdomain=sg)), Brian had a small role in this project
  - Fong Sheng is a geriatrician, he sees people all the time
- Frustrated, the geriatricians have limited things they can do
  - They’re seeing people that already have multi-morbidity, and the clocks are not that useful
- Fong wanted to know: How do we create a reliable clock that a doctor can understand?
  - For the purpose of biologic age (more about this later)
- The **first generation clocks** try to predict your chronologic age
- The **second generation clocks** predict some outcome

*The question is, we want to predict mortality, we don’t want to predict your chronologic age*

- Intrinsically, if it works, it’s going to do better than the chronologic age for the second generation clock
- In their [study](https://pubmed.ncbi.nlm.nih.gov/38898237/), they took in NHANES data collected around 1999, 2000 (mortality data for 200 months)
- These parameters are nice because you can actually do a consumer test of [HbA1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin)
  - There are many labs that do that, it’s reproducible to a large extent, much better than DNA methylation
  - And doctors use all these parameters; so the things that are in NHANES [along with]: LDL, inflammatory markers, medical tests, some cognitive self-reported stuff
- We took everything as a feature and used AI (a linear model) to try to predict mortality

***We’re on the second generation of this clock now, and it predicts mortality better than any other parameter in NHANES; it’s way better than ASCVD (there’s cardiovascular disease measurement)***

**Recently the methylation data came out in NHANES, so we could go back and compare the mortality prediction for methylation clocks**

- Some of the first generation clocks are worse than chronologic age, your passport is better than they are at predicting mortality
- Which to Brian means that they’re not useful because even if they’re not designed to predict mortality, if they don’t capture some element of that, what are they measuring?
- The second generation clocks like grim age and phenol age, they do better job than chronologic age, for sure (at predicting mortality)
- Just to be clear, this is all out of the NHANES database (that’s the only thing they’ve looked at right now)
  - 200 months of forward-looking data [16.6 years]

Peter asks, “*You’re saying if we know the methylation of somebody at that time in the cohort, 1999 to 2000, we could predict their date of death better than the actuarial data of their age?*”

- Yeah
- Peter wasn’t aware of that ‒ that answers a question he’s never seen answered
- It’s been accepted for publication [[published](https://pubmed.ncbi.nlm.nih.gov/40268972/) in April 2025]

Brian adds, “*Our clinical chemistry clock does better than those.*”

**What is included in that clinical clock?**

- There are about 50 parameters that we measure now
  - A complete blood count gives you about 30 of those parameters, so it’s not as elaborate as you think it would be
- It’s a lot of standard markers that you already measure, you probably measure all of them in your patients
- It’s about $300 in Singapore if you did it all de novo, but anybody going to a doctor’s office has most of those parameters measured anyway, and if they’re going to a wellness longevity center, all of them are probably being measured

**Life insurance companies are really good at predicting mortality**

- Peter points out: MetLife is better at predicting mortality than anybody on the planet
  - Pick the best life insurance company, this is their business
  - They’re so good at predicting mortality, it’s frightening
  - Brian doesn’t know how they do it (nobody does), so he can’t comment directly
- Peter’s point is, point is, they’re looking at age, they’re looking at a whole bunch of things in your medical history, they’re looking at a whole bunch of blood tests, your blood pressure, your weight, your waist, your circumference, all those things, and they’re coming up with an exceptional prediction of remaining years of life

*The real question is, do you believe they will incorporate a second generation epigenetic clock, or do you believe that they’ve already got that captured in their data set?*

- They may
- It’s an unanswerable question
- Brian’s group is focusing on the clinical chemistry, they’re not doing any methylation

> “*What we’re finding is hospitals want to use this now*.”‒ Brian Kennedy

- The clinical chemistry
- When you show doctors a list of parameters, they don’t have to be an expert in epigenetics to figure out what’s going on

**The parameters identified by Brian’s biologic age/clinical chemistry clock are all actionable**

- We have principal components that we can break it down in and we can see smoking in one component and we can see metabolic disease in another one and obesity in another one

**A few conclusions from this are really interesting**

1 – We find cases where nothing’s out of the reference range

- So a doctor that’s looking at things, especially if they have a few minutes to look at, they’re not going to prescribe anything for this person
- These 4 parameters in this principle component are increasing their biologic age by 4 years, which means it’s a 50% increase in mortality risk
- These are actionable things: you can treat LDL, high blood pressure

***And so clinicians are actually willing to then be a little bit more aggressive and try to prescribe something or lifestyle modification or something to treat these markers ‒ it’s actionable***

**Peter’s takeaway**: the reason you prefer this is it doesn’t just give you an answer, it gives you a solution

- Yeah; that’s what they’re working toward

2 – NHANES also has all the medications people are taking

- The weakness is it’s a snapshot, it’s a cross-sectional measurement of all these things
- But they measured a lot of stuff and so we could look at people’s clinical parameters out of the reference range, should they be being prescribed some drug and they’re not being given it
- And that goes up to about 20% when you’re 65 years old (in the year 2000 in the US)

***Meaning 25% of people should be treated for something, but they’re not being treated; and those people have a higher biologic age and faster mortality (not surprising)***

There’s also the group at 65 every clinical parameter looks good.

- They have a lower biologic age, they live longer
- But you can break that group down
  - One group is not taking any medication
  - The other group is taking medication, it’s just their clinical parameters are managed well

**⇒** The people taking the medication have a lower biologic age and live longer., and it doesn’t really matter what the medication is (it’s true for the major medications you would give for metabolic and cardiovascular disease in the year 2000)

**Brian’s takeaway**

- That suggests that being more aggressive and getting people optimized earlier is better than being pretty healthy and having blood pressure that is a little high but not needing to take medication

> “*I think the other thing is that suggesting that these drugs that were around in 2000 for these treating preconditions are actually aging drugs, they’re actually extending lifespan.*”‒ Brian Kennedy

**What are the classes of drugs that we see the most commonly? Lipid and hypertension?**

- Hypertension, metformin, it’s the standard things

## Evaluating rapamycin, metformin, and GLP-1s for longevity in healthy individuals [1:32:15]

**Do you think** [**metformin**](https://en.wikipedia.org/wiki/Metformin) **will have geroprotective properties in people who are metabolically healthy?**

- Brian is skeptical

***What it is saying is that if you catch preconditions early enough, you protect against the other failure states a little bit too***

**Are you more optimistic that rapamycin would be geroprotective in humans than metformin?**

- Yeah, that would be Brian’s prediction

**Do you think there is a drug out there that you think is more likely to be geroprotective in humans than rapamycin at this time?**

- The [GLP drugs](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) and [SGLT2](https://en.wikipedia.org/wiki/SGLT2_inhibitor) are interesting
- Brian doesn’t think we have the data right now

*If we took a population of middle-aged healthy individuals, we could design an experiment*

- Placebo arm
- Metformin arm
- Rapamycin arm
- SGLT2 inhibitor arm
- GLP-1 agonist arm

What is your prediction in length of life or additional years of life given in that six-arm study or whatever it is?

- Brian thinks the last 3 would be comparable
- He’s skeptical of metformin
- We don’t have data in healthy people with SGLT2 and GLP-1

Peter asks, “*Mechanism of action is what?*”

- If the GLP-1 group and the SGLT2 group are metabolically healthy, they don’t have glucose excursions that are high, they’re completely insensitive
- Brian is going by a different statement, which is *most people we’re calling healthy are not totally metabolically healthy*
- In those cases, Brian thinks there would be a benefit
- He doesn’t know about the perfectly optimized person whether there’d be a benefit
- Every time he talks to a doctor, he asks them, “Are you losing more lean muscle mass with these drugs than you are just by fasting or lifestyle?”
  - And if he asks 10 doctors, he gets 10 answers
  - So he doesn’t know what the answer to that question is
- Peter reasons, “*If the GLP-1 agonists and SGLT2 inhibitors only work if you have some degree of glucose irregularity, then… it says, look, glucose homeostasis is one of the most important features of living great*”
- But if you could correct that with diet, sleep, and exercise (which you can; it’s hard); then those things aren’t going after fundamental pillars of aging
  - Because people who eat well, who exercise well and sleep well still age

**Studies in mice**

- Brian and Matt published a [study](https://pubmed.ncbi.nlm.nih.gov/39332712/) in mice recently where they analyzed all the data that’s out there in mice and tried to determine the reality of interventions that extend lifespan in mice
- Because if the control mice are really short-lived, which happens a lot
- It’s just really hard to control
  - If you look at the ITP data, the control mice are all over the board and they’re very well controlled; the best scientists are doing the experiment
  - Brian sees a lot of variation too: in some cases there are bad [vivariums](https://en.wikipedia.org/wiki/Vivarium) and that causes a problem
  - But even in good vivariums
  - It’s true in every organism, in yeast and worms: one cohort of worms will all live a little bit shorter, and one cohort of worms will live a little bit longer
  - It’s cohort dependent, but Brian doesn’t know why
- If the mice are short-lived, if your extension is there, all you can say is “*It’s longevity normalizing.*”
  - You don’t know that it’s slowing aging
- It’s only when the controls are really long-lived and you’re getting an extension that you can really make the argument it’s **longevity extending**
- And so that gets to the question

**Back to people**

- The real answer though is dependent on how many people you believe that are optimized right now
  - Because it’s possible to do the study
  - It’s very few

***Brian contends that longevity normalizing works, at least for keeping people healthy, but whether it’s really slowing aging is an open question***

- Brian thinks the best case would be for rapamycin

**This begs the question, could these effects be additive?**

- Would there be a benefit to a person who is on balance quite healthy, but let’s say their [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) (if it is indeed an accurate representation of their average glucose) is 5.4%
  - It probably translates to an average blood glucose of 110 or so [mg.dL](http://mg.dl)
  - There are data that show based on hemoglobin A1C that lower is always better
    - So 5.0 is better than 5.4, even though 5.4 is deemed completely healthy
    - That’s all-cause mortality data
  - So we’re saying we take a person who’s at 5.4, they’re not even pre-diabetic, they can barely see where pre-diabetic starts, let alone diabetic, but we give them an SGLT2 inhibitor

Brian replies, “*I’m at 5.4, I can volunteer for this study.*”

- If you go from 5.4 down to 5.1 just on the basis of a SGLT2 inhibitor, and we throw a GLP-1 agonist on top of that, now you’re at 4.9
- Then we give you rapamycin, which really doesn’t impact your glucose, but we think it’s going to do something a little bit different

Peter asks, “*You would say in that situation you might believe that there’s some actual geroprotection? (but not adding metformin)*”

- Brian doesn’t want to lose muscle mass though
- The drug he would be most afraid of is the GLP-1 agonist

## Why muscle, strength, and fitness are the strongest predictors of healthspan [1:37:30]

- Brian thinks lean muscle mass is super important
- It’s probably better to have high lean muscle mass and be a little bit more fat than it is to be low on both (his best guess)

**What do you think of the hazard ratios for mortality based on high VO2 max and high muscle mass and high strength, and how those three things stand out so far above anything else?**

- Meaning when you look at hazard ratios associated with smoking, type 2 diabetes, even cancer, they are not as lethal as being incredibly weak, incredibly low in muscle mass and incredibly low in fitness

*How much causality do you think is there versus how much of that is just those are just such good markers of health?*

- Brian thinks there is causality there
- He thinks it’s super important
- It may only be important for squaring the curve
- He doesn’t think there is much evidence that maximum lifespan is extended by these things
  - We don’t have the human data, of course
  - We can’t do the experiment
- The animal data is pretty much with exercise as you square the curve

***Brian agrees with Peter, it’s a revolution if we can do that, but he doesn’t know if there’d be an effect on maximum lifespan or not***

- Brian believes it so much that he put a lot of effort in increasing his lean mass
- That’s why he started resistance training because he wasn’t getting as much from running
  - He gets more mindfulness from running

***Peter tells patients he thinks exercise is reducing your risk of chronic disease***

- But then you get into the whack-a-mole game
  - If it lowers your risk of Alzheimer’s disease, it might not have much of an impact on cancer risk, it’s unclear
  - But if it lowered your life expectancy by 6 months, it would still be worth it based on the healthspan benefits that you get and the quality of life you would enjoy (especially in that final decade of life)

## Why combining too many longevity interventions may backfire [1:39:30]

**Brian believes we need to empower people to make decisions on their own health**

- He supports hackers, if they want to educate themselves and try different things and they know what the benefits and risks might be and what we know and we don’t know, more power to them
- He feels like part of the reasons we get such low compliance in medications is that we don’t empower people
  - We don’t give them choices
  - They don’t know why they’re doing things
  - We just tell them what to do and people don’t respond well to that

**Having said that, Brian can’t pick 3 interventions that work well together in a mouse and he does these studies all the time**

- They’re more likely to cancel each other out than to have additive effects
- If you’re taking 20 pills, it’s like mixing 20 colors of paint together, you’re going to get some ugly gray outcome, or at best you’re going to get an unknown outcome that we can’t predict

*Brian is really cautious and wants to tell people: try 1 thing at a time*

- There are a lot of people out there promoting, doing a million different things at the same time
- Brian tries 1 or 2 things at the same time
  - He tries to see how my body responds
  - He measures things, even simple measures are useful

***He thinks that if you’re doing 10 things, you don’t have any idea what’s working and what’s not working and whether things might be impairing each other***

- That’s a scary path to go down

Peter asks, “*How are you deciding to use the 𝛼-ketoglutarate (AKG) and the NAD?*”

- He’s seen some evidence that each of those individually works
- Brian had been using the regimen with the AKG for a long time
- He was involved in the research
- He’s on the board of the company
- It’s something he’s just taken for years

***And he adds one thing to it and takes it away***

- He’s tried [astaxanthin](https://en.wikipedia.org/wiki/Astaxanthin), he’s tried [fucoidan](https://en.wikipedia.org/wiki/Fucoidan), he’s tried [rapamycin](https://en.wikipedia.org/wiki/Sirolimus), and he’s tried a bunch of other things too

***He tries to measure before and after (he’s getting better at that)***

- When he first started doing it, he wasn’t measuring that much

**⇒** He never takes 6 things at one time

- It’s kind of intuitive: if something is interesting to Brian and he sees an effect on the mice, he wants to try it
- He wants to do urolithin and astaxanthin [combination] next

## How increased funding and AI integration could accelerate breakthroughs in aging research [1:41:45]

**What is your current budget this year for both animal and human research?**

- It’s complicated because they have multiple streams
- Probably about 4 million a year

**If that number were multiplied by 10 or 20, 25, if you had $100 million annual budget to do world changing translational geroscience, what would you be doing different?**

Scale would be one

- When you do a combination in mice, you’ve got 4 groups
- If we had more money, we could design multifactorial clinical studies and preclinical studies where we’re testing many compounds at the same time
- We’re sort of doing nested groups and we could get an indication for things that actually could be additive together, not just things that are working on their own
- Right now we struggle to get to that next step for finances

***And we could apply those to human studies and combine it with lifestyle interventions too***

Basic science

- The other thing we really believe is that when you have a compound like urolithin, you’re never going to really know what to combine it with unless you know what the compound’s doing
- We do a lot of discovery stuff now trying to figure out [basic science]
  - If you take a drug like rapamycin, it affects every hallmark, that doesn’t tell you the primary thing the drug is doing
  - In this case, we know it binds TOR
  - For urolithin, we don’t know

***We need to know what that molecule’s binding to in the cell and if we understand the mechanism at that level, we can combine it better with other interventions and start to understand how to put the puzzle together of what we need to combine to get the biggest effect***

**Do you have enough human resources to deploy that kind of capital if it were available?**

- It would take a center to do it
- But yeah, we could build it
- Singapore is very motivated, Brian gives the government credit
  - They’ve understood the aging problem before almost anybody
  - It’s taken them a long time to really figure out what to do about it
  - They went through kind of early stages of putting roofs on sidewalks so people walk an extra 100 steps in the hot sun, that sort of stuff helps
  - Now they’re really motivated to commit to targeting health span
  - If they do, it’s the right place to be because it’s a small island; it’s a compliant population; they believe in their government

Singapore is a good place to take these studies

- 5 million people live in there permanently and there are 1 million workers
- Not just in the clinic, but move them into the community and actually get validation in large populations

***That’s why Brian likes being in Singapore; he thinks the opportunity is there to make it an example for how to do healthspan***

- It’s already very long-lived
  - It’s among the top 3 in the world depending on what statistics you want
- But the healthspan, people still have morbidity there
  - They still have 10, 12 years of sickness and decline
  - There’s a lot of frailty there, you can see that just walking around
  - So there’s room for improvement for sure

**How will AI help in this field?**

*Peter’s questions*

- Do you think it will allow for more intelligent experiments?
- Will it allow for better signal detection in messy data?
- How do we unleash AI on this problem?

*Brian is using it now already for the clocks and signal detection*

- He’s using it to pick drugs
- He just published a [paper](https://pubmed.ncbi.nlm.nih.gov/39418098/) with [Eric Verdin](https://www.buckinstitute.org/lab/verdin-lab/) and Germany where we’re trying to improve how to ask large language models medical questions related to longevity
- Brian talks to a lot of doctors and they say, “Y*ou shouldn’t be asking* [*Perplexity*](https://www.perplexity.ai/) *these questions.*”
  - Brian is a realist, and people are asking this
  - So let’s figure out how to get the questions asked in the right way to get the right answer

*Peter is thinking more in terms of research*

- Brian thinks what’s going to happen next is AI’s going to start telling us what questions to ask
- Right now it’s telling us how to analyze our data

***AI is still not very good at telling us what the next question is, and Brian thinks that’s the threshold***

**How do we get there?**

- Brain is not qualified to answer that
- The trajectory it’s on now is amazing
- The question is: is there a barrier to go to that next step, or is it just a matter of getting computational power and slightly modifying neural network algorithms (or something)?

Brian adds, “*There’s a reasonable chance that I’m not going to be needed in 10 years.*”

*Peter thinks about this question a lot when it comes to experimental topics because he still doesn’t have a good enough sense of how many training cases, and AI needs to learn this*

- We know for language what it took
- We understand how many tokens were needed to allow the neural networks to do what they do today, and it was enormous
- So there are some problems that might require far less input
- You might be able to do it with 10,000 hours of data as opposed to billions of hours of data
- Peter thinks that’s the question more than anything else
- Brian doesn’t know
- All he knows is half his lab is doing it now
  - He would’ve never guessed that 5 years ago
  - They’re using AI to help them ask experimental questions or interpret data
- His lab has become half dry lab
  - Meaning that half the people just sit at computers and aren’t doing experiments in animals

## The research Brian is most excited about, and the need to balance innovation with safety in longevity clinics [1:47:00]

**What are you most excited about trying to uncover (truth or high probability of truth) in the next 5 years?**

1 – Experimentally, pre-clinically, he wants to find interventions that really combine together to have synergistic impacts

- He doesn’t think there’s much out there
- There’s rapamycin and metformin and a couple other things from the ITP, but they are small effects

***Can we break through a barrier and get 50, 60% effects in mice by combining things together?***

2 – The other thing Brian is excited about is, going back to this entropy question

***Are there new classes of interventions that change that primary linear accumulation of “damage”?***

3 – Brian is also really excited now that he’s working with longevity clinics in various countries

- We’re applying the clock we built
- We’re also helping them try to decide which interventions to do and hopefully collect data so it can be analyzed
- There’s so much going on
- Brian tells this joke all the time: it used to be that yeast and worms and flies were the model organisms for aging research and now billionaires are the model organisms
  - Because they’re doing all kinds of stuff he can’t even test
- He’s really curious to see what’s happening
  - Some of it might work; some of it might not work
- But we can’t find out any other way and he doesn’t want to see these clinics working in isolation
- He’s at least learning what’s coming out of the data, even if it’s not perfect

***There’s a lot of cutting edge stuff going on***

- Brian will work with people if they’re doing something he considers safe and if they’re honest about the data on efficacy
- Those are the 2 things he asks: transparency and safety, and then he’s happy to try to interact

**What are you seeing that you’re worried about?**

- What trends do you see that people are doing from a biohacking longevity standpoint that have you concerned?
- Peter puts this in 2 buckets: the higher bucket would be safety, second bucket would be predatory behavior around basically people having their money wasted even if the agents that are being sold are not necessarily harmful

*The first one Brian is excited about is gene therapy*

- He thinks it’s interesting and may really change the field going forward
- He even likes [follistatin](https://en.wikipedia.org/wiki/Follistatin#Clinical_significance)
- Follistatin is a protein, but those treatments are not very well proven yet and Brain would not do it

Peter asks, “Y*ou wouldn’t spend $100,000 for follistatin gene therapy?*”

- Brian probably doesn’t have to spend the money, he still hasn’t done it
- Brian has done [MSCs](https://en.wikipedia.org/wiki/Mesenchymal_stem_cell) though (IV)
- Stem cells, it’s a different question there
  - If you’re repairing soft tissue damage or something like that and injecting them directly, it probably works
  - For aging he has no idea but thinks it’s probably safe if you have somebody that’s a good practitioner that knows what they’re doing
- The problem with stem cells is you go places and you really don’t know who you’re working with
  - And if they’re really treating the cells correctly
  - If you’re putting the right things in your system

***There’s a safety concern there based on the practitioner***

**Brian hasn’t gotten totally on board with** [**growth hormone**](https://en.wikipedia.org/wiki/Growth_hormone) **yet**

- Used correctly might be okay
- The data’s interesting
- Peter agrees: he can’t point to a study that tells you this is a bad idea, and he’s never spoken to a person who takes a modest, judicious dose of growth hormone who doesn’t say they feel better
  - It’s hard to believe it’s not making people feel better
  - He’s never seen data to suggest it initiates cancer, but that seems very biologically plausible that if you have small amounts of cancer, then your probability that it becomes clinically significant is higher (no data)
- Peter’s view has been to leave growth hormone off the list (despite his own interest in trying things)
- Some clinical studies are being done

*How do we address the safety concern?*

- You really need to be able to track people for quite a long period of time who are cancer susceptible
- We don’t know what the long-term [effects are]; it’s a gray area

Brain notes, “*From what I read in your book, you’re doing sort of validated stuff. You’re not really out there in the stratosphere doing crazy stuff that we don’t know about.*”

- Peter shares that some people are very critical of his use of rapamycin in patients for geroprotective reasons
- There are people who might think he’s crazy for giving people SGLT2 inhibitors who don’t have diabetes
- Fewer than 10% of his patients take rapamycin because his view is, unless you’re willing to have a very lengthy discussion about the pros, the cons, the risks, the uncertainties
  - Peter doesn’t tell people, “*Oh, this stuff’s amazing*.”
  - His answer is, “*I don’t know. Here’s how I think about it probabilistically, here are the trade-offs*.”
  - You can tell he’s not a good salesman if only 10% of the patients are taking it
- Brian thinks that’s reasonable

**There are clinics doing some really ‘out there’ stuff**

- Brian wonders about he long-term **safety**
- He thinks if you’re going to do that stuff, you need to go in with your eyes open ‒ you’re taking a risk

*Peter has seen so many horror stories*

- A lot of this stuff you can’t do in the U.S.
- People are coming back from South America or Mexico, places in Asia having done follistatin therapy or other very questionable stem cell therapies and people have had horrible infections, literally just artifacts of the treatment
- That’s the practitioner problem with this

*There’s some great stuff happening too*

- Brian works with Bumrungrad Hospital in Thailand and they’ve got a [longevity clinic](https://www.bumrungrad.com/en/centers/vitallife-scientific-wellness-center-bangkok-thailand) now and they’re very grounded in good science

> “*The problem is if you’re a consumer for these products, it’s really hard to know*.”‒ Brian Kennedy

**‘Rules of thumb,’ heuristics for navigating the never-ending landscape of longevity hacks**

- This could be things that show up on your instagram feed, TikTok feed, diet books, clinics around the world
- Brian think’s it’s really hard to sort that out
- It’s clinical practice and research at the same time ‒ it’s a very unique situation
- Maybe some functional medicine is a bit like that too

***It’s better for scientists to engage with these clinics (provide oversight) and try to help them than it is to just let people do things***

- A lot of academics don’t even want to work with these clinics at all
- Brian gets criticized for working with them sometimes

## Peter’s reflections on emerging interventions and the promise of combining proven aging compounds [1:54:00]

**Peter is very interested in**

- Seeing the paper Brian mentioned on the second-gen epigenetic clock
  - [The clock is trained on NHANES data from 1999-2000 then tested on NHANES data from 2001-2002 ‒ [published](https://pubmed.ncbi.nlm.nih.gov/40268972/) in April 2025]
- Peter’s personal curiosity there will be, is that clock providing value over all the other data we have?
  - His intuition is it won’t
- The fact that we now at least have a clock that can outperform chronologic age is a step in the right direction
- It’s going to be very interesting to see some of the data that Brian has talked about as far as 𝛼-ketoglutarate
- Brian also piqued Peter’s curiosity with the sublingual NAD (that’s really interesting)

*Have you been able to measure NAD levels in your RBCs?*

- Brian hasn’t done it himself, there have been some studies done by the company, but he doesn’t think anything is published
- Peter likes this idea of taking ITP winners and combining them and seeing if you could get accretive value or additive benefit (that would be pretty amazing)

---

## Selected Links / Related Material

**The Centre for Healthy Longevity**: [Centre for Healthy Longevity](https://coe.nuhs.edu.sg/centre-for-healthy-longevity/about-us) | National University Health System (2025) | [8:45]

**Hallmarks of aging**: [12:15]

- [The Hallmarks of Aging](https://pmc.ncbi.nlm.nih.gov/articles/PMC3836174/) | *Cell* (C Lopez-Otin et al. 2013)
- [Hallmarks of aging: An expanding universe](https://pubmed.ncbi.nlm.nih.gov/36599349/) | *Cell* (C Lopez-Otin et al. 2023)

**The pillars of aging**: [Geroscience: Linking Aging to Chronic Disease](https://pubmed.ncbi.nlm.nih.gov/25417146/) | *Cell* (B Kennedy et al. 2014) | [12:15]

**Episodes of** ***The Drive*** **with David Sabatini**: [17:30]

- [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) (August 13, 2018)
- [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023)

**Episodes of** ***The Drive*** **with Matt Kaeberlein**:  [17:30]

- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) (August 20, 2018)
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) (September 13, 2021)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) (May 16, 2022)
- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022)
- [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023)
- [#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Ph.D., Matt Kaeberlein, Ph.D., Richard Miller, M.D., Ph.D.](https://peterattiamd.com/longevityroundtable/) (January 27, 2025)

**Genome screen in yeast for longevity**: [A Comprehensive Analysis of Replicative Lifespan in 4,698 Single-Gene Deletion Strains Uncovers Conserved Mechanisms of Aging](https://pubmed.ncbi.nlm.nih.gov/26456335/) | *Cell Metabolism* (M McCormick et al. 2015) | [19:00]

**Episodes of** ***The Drive*** **about calorie restriction**: [19:30]

- [#171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules](https://peterattiamd.com/steveaustad/) (August 9, 2021)
- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022)
- [#324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.](https://peterattiamd.com/ericravussin/) (November 4, 2024)

**Rapamycin provides immune enhancement**: [22:00]

- [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine* (J Mannick et at. 2014)
- [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://pubmed.ncbi.nlm.nih.gov/29997249/) | *Science Translational Medicine* (J Mannick et at. 2018)
- [Targeting the biology of ageing with mTOR inhibitors to improve immune function in older adults: phase 2b and phase 3 randomised trials](https://pubmed.ncbi.nlm.nih.gov/33977284/) | *Lancet Healthy Longevity*(J Mannick et al. 2021)

**Jackie Han’s study of facial structural changes and biological age**: [Three-dimensional facial-image analysis to predict heterogeneity of the human ageing rate and the impact of lifestyle](https://www.nature.com/articles/s42255-020-00270-x) | *Nature Metabolism* (X Xia et al. 2020) | [42:00]

**Longevity roundtable episode of** ***The Drive***: [#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Ph.D., Matt Kaeberlein, Ph.D., Richard Miller, M.D., Ph.D.](https://peterattiamd.com/longevityroundtable/) (January 27, 2025) | [46:45]

**Rejuvant 𝛼-ketoglutarate supplement**: [Rejuvant](https://rejuvant.com/Home) (2025) | [53:00]

**Rejuvant reverses aging by a few years**: [Rejuvant®, a potential life-extending compound formulation with alpha-ketoglutarate and vitamins, conferred an average 8 year reduction in biological aging, after an average of 7 months of use, in the TruAge DNA methylation test](https://pubmed.ncbi.nlm.nih.gov/34847066/) | *Aging* (O Demidenko et al. 2021) | [1:04:30, 1:15:30]

**Urolithin A slows aging in mice**: [Urolithin A induces mitophagy and prolongs lifespan in C. elegans and increases muscle function in rodents](https://pubmed.ncbi.nlm.nih.gov/27400265/) | *Nature Medicine* (D Ryu et al. 2016) | [1:07:00]

**Benefits of NR for ALS patients**: **Benefits of NR for ALD patients**: [Efficacy and tolerability of EH301 for amyotrophic lateral sclerosis: a randomized, double-blind, placebo-controlled human pilot study](https://pubmed.ncbi.nlm.nih.gov/30668199/) | *Amyotrophic Lateral Sclerosis & Frontotemporal Degeneration* (J de la Rubia et al. 2019) | [1:09:30]

**Episode of** ***The Drive*** **with Josh Rabinowitz**: [#216 – Metabolomics, NAD+, and cancer metabolism | Josh Rabinowitz, M.D., Ph.D. (August 1, 2022)](https://peterattiamd.com/joshrabinowitz/) | [1:14:45]

**Spermidine suppresses metabolic dysfunction from a high-fat diet in mice**: [The Autophagy Inducer Spermidine Protects Against Metabolic Dysfunction During Overnutrition](https://pubmed.ncbi.nlm.nih.gov/34060628/) | *The Journals of Gerontology* (C Liao et al. 2021) | [1:17:30]

**Second-generation biological aging clock trained on NHANES data predict mortality**: [LinAge2: providing actionable insights and benchmarking with epigenetic clocks](https://pubmed.ncbi.nlm.nih.gov/40268972/) | *NPJ Aging* (S Fong et al 2025) | [1:25:00, 1:54:30]

**Interventions that extend lifespan in mice**: [The impact of short-lived controls on the interpretation of lifespan experiments and progress in geroscience – Through the lens of the “900-day rule”](https://pubmed.ncbi.nlm.nih.gov/39332712/) | *Ageing Research Reviews* (K Pablis et al. 2024) | [1:35:00]

**Use of generative AI for longevity medicine**: [Longevity biotechnology: bridging AI, biomarkers, geroscience and clinical applications for healthy longevity](https://pubmed.ncbi.nlm.nih.gov/39418098/) | *Aging* (Y Lyu et al. 2024) | [1:45:30]

---

## People Mentioned

- [Eric Verdin](https://www.buckinstitute.org/lab/verdin-lab/) (Professor, President and CEO of the Buck Institute, expert in the epigenetic regulators of the aging process) [4:45, 1:45:30]
- [Judith Campisi](https://www.cell.com/cell/fulltext/S0092-8674(24)00183-1) (1948–2024, was a Professor at the [Buck Institute](https://www.buckinstitute.org/lab/campisi-lab/), expert in cellular senescence) [4:45]
- [Heinrich (Henry) Jasper](https://www.gene.com/scientists/our-scientists/heinrich-jasper) (Principal Fellow at Genentech, expert in age-related decline in stem cell function) [5:00]
- [Gordon Lithgow](https://www.buckinstitute.org/lab/lithgow-lab/) (Professor at the Buck Institute, expert in genetics and small molecules that prolong lifespan through enhanced molecular stability) [5:00, 1:02:00]
- [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) (CEO of Optispan, Affiliate Professor and Co-Director of the Dog Aging Project at at the University of Washington, expert on interventions to promote healthspan) [5:45, 17:30, 33:00, 57:30]
- [Michael Che](https://discovery.nus.edu.sg/1382-wei-liang-michael-chee)e (Professor and Director of the Centre for Sleep and Cognition at the Yong Loo Lin School of Medicine, National University of Singapore, expert in the impact of sleep on cognition and health) [9:15]
- [Vadim Gladyshev](https://dms.hms.harvard.edu/people/vadim-gladyshev) (Professor of Medicine at Harvard Medical School; expert in aging, lifespan control and rejuvenation) [10:30]
- [David Sabatini](https://www.davidsabatinilab.com/) (PI with labs at [IOCB Boston](https://iocbboston.org/) and Prague; expert on mTOR pathway, rapamycin, and the regulation of growth and metabolism)  [17:30, 35:00]
- [Joan Mannick](https://www.linkedin.com/in/joan-mannick-8089a614/) (Co-founder and CEO of [Tornado Therapeutics](https://www.tornado-tx.com/team), expert in mTOR and geroscience) [22:00]
- [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) (President & CEO at Koslapp Therapeutics, a rheumatologist and immunologist with an extensive career in the biopharmaceutical industry) [22:00]
- [Peter Fedichev](https://www.linkedin.com/in/peterfedichev/) (Director and Co-founder of [Gero](https://gero.ai/about), expert in physics-based machine learning models that analyze health data) [23:00]
- [Jing-Dong Jackie Han](https://cqb.pku.edu.cn/hanlab/Team.htm) (PI at the Center for Quantitative Biology, Peking University, Beijing; expert in using AI and computational biology to understand aging) [42:00]
- [Andrea Britta Maier](https://discovery.nus.edu.sg/19564-andrea-britta-maier) (Professor of Medicine at the National University of Singapore, expert in mechanisms of aging and aging-related diseases) [53:30]
- [Johan Auwerx](https://people.epfl.ch/johan.auwerx?lang=en) (Professor at the École Polytechnique Fédérale in Lausanne, Switzerland, where he directs the Laboratory for Integrated and Systems Physiology; expert in how diet, exercise, and hormones control metabolism) [1:07:00]
- [Josh Rabinowitz](https://www.ludwigcancerresearch.org/scientist/joshua-rabinowitz/) (Director of the Ludwig Institute for Cancer Research Princeton branch and Professor of of Chemistry & Lewis-Sigler Institute for Integrative Genomics, expert in metabolism, NADPH and folate) [1:14:45]
- [Jan Gruber](https://medicine.nus.edu.sg/bch/faculty/jan-gruber/) (Associate Professor of Biochemistry at the National University of Singapore; expert in aging, age-dependent diseases, and interventions against) [1:25:15]
- [Sheng Fong](https://www.linkedin.com/in/sheng-fong-69668429b/?originalSubdomain=sg) (Clinician scientist and consultant geriatrician at Singapore General Hospital, worked on [clinical aging clocks](https://medicine.nus.edu.sg/news/clinical-ageing-clocks-nus-and-sgh-develop-algorithm-powered-tests-to-indicate-mortality-risk/)) [1:25:15]

---

![](https://peterattiamd.com/wp-content/uploads/2025/07/bio-briankennedy-600x600.png)

##### Brian Kennedy, Ph.D.

Brian Kennedy earned his bachelor’s degree in biochemistry and mathematics from Northwestern University. He earned his Ph.D. in biology at MIT and completed postdoctoral research at Massachusetts General Hospital Cancer Center. Dr. Kennedy was a professor of Biochemistry at the University of Washington in Seattle until 2010. He was a visiting professor at Guangdong Medical College in China until 2014. He served as the President and CEO of the Buck Institute for Research on Ageing from 2010-2016. Currently, Dr. Kennedy is a [distinguished professor of Biochemistry and Physiology](https://medicine.nus.edu.sg/bch/faculty/brian-kennedy/) at the Yon Loo Lin School of Medicine at the [National University of Singapore (NUS)](https://discovery.nus.edu.sg/9418-brian-keith-kennedy/about) where he also serves as: Director of the Center for Healthy Longevity, Programme Director of the Healthy Longevity Translational Research Programme, and Director of the Asian Centre for Reproductive Longevity and Equality. His affiliations include Adjunct Senior Principal Investigator at the Singapore Institute for Clinical Sciences at A\*STAR; and Adjunct Professor at the Leonard Davis School of Gerontology at USC in Los Angeles. Dr. Kennedy’s research focuses on understanding the biology of aging and translating research discoveries into new ways of delaying, detecting, preventing, and treating human aging and associated diseases. He uses multiple model organisms for these purposes, relying on non-vertebrates for discovery-based approaches to generate hypotheses regarding aging mechanisms and studies in mammals to test hypotheses and to develop translational strategies. He then conducts clinical studies in humans to evaluate these strategies and interventions that target aging. [[NUS](https://medicine.nus.edu.sg/bch/faculty/brian-kennedy/)]