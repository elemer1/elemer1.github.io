# #198 – Eye health—everything you need to know | Steven Dell, M.D.

**Source:** [https://peterattiamd.com/stevendell/](https://peterattiamd.com/stevendell/)

---

Steven Dell is an ophthalmologist, current Medical Director of Dell Laser Consultants, and a leader in refractive eye surgery with over 20 patents to his name. In this episode, Steven explains the anatomy and functional mechanics of the eye and how they relate to common variations in vision. He discusses changes in vision that occur with aging, the fundamentals of different types of vision loss, and provides an in-depth look into the various treatments and procedures available for corrective eye surgery. Additionally, Steven explains how one might protect the eyes and prevent vision loss—a topic particularly important for children in light of the epidemic of myopia.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/stevendell/the_Drive_public.png)

Play

#198 - Eye health—everything you need to know | Steven Dell, M.D.

#198 - Eye health—everything you need to know | Steven Dell, M.D.

1x15s30s

0:002:43:41

## We discuss:

- Why Steven chose ophthalmology, and the crossovers to other medical disciplines [3:45];
- Anatomy of the eye, common types of vision loss, and age-related vision changes [14:15];
- Eye drops that can potentially improve vision [27:30];
- The explanation for different eye colors [33:15];
- Physiology of the eye and its connections to the brain [34:45];
- Understanding human vision through an evolutionary lens [41:00];
- Enhancing vision beyond 20/20 [47:00];
- Astigmatism: definition, cause, and high prevalence [51:30];
- Nearsightedness (myopia): causes, epidemic in children, and prevention strategies [54:15];
- Cataracts: impact of aging and how they can be repaired [1:05:00];
- Lens implants that can correct and improve vision [1:19:30];
- Effects of eye trauma [1:26:45];
- Corneal abrasion from ‘dry eye’: causes, treatment, and prevention strategies [1:29:00];
- Sunglasses for eye protection [1:35:00];
- Solutions to correct nearsightedness [1:42:00];
- Laser eye surgery—photorefractive keratectomy (PRK) [1:45:45];
- Laser eye surgery—LASIK [2:02:00];
- Laser eye surgery—small incision lenticule extraction (SMILE) [2:11:45];
- Glaucoma: definition, causes, symptoms, and care [2:13:45];
- Tips for preserving eye health [2:20:00];
- Screen time and eye health [2:24:15];
- Contact lenses: good hygiene and considerations [2:27:45];
- A bonus benefit from repairing cataracts [2:29:00];
- Questions about corrective eye surgery [2:31:30];
- How an eye exam can be a window into metabolic illness [2:33:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Steven is an internationally recognized leader in refractive eye surgery, specializing in [LASIK](https://en.wikipedia.org/wiki/LASIK) surgery, cataract surgery, and refractive lens exchange
- He’s also the chief medical editor of the [Cataract & Refractive Surgery Today](https://crstoday.com/)
- He’s the Emeritus Chair and President Emeritus of the [American European Congress of Ophthalmologic Surgery](https://aecosurgery.org/)
- He’s a principal investigator on a variety of FDA clinical trials in the field of eye surgery
- He’s the inventor of several surgical instruments and devices and holds over 20 US and international patents in the field of eye surgery
- He is also the author of numerous textbook chapters and peer-reviewed journal articles
- Peter notes, “*In this episode, we talk about all things related to the eye, and I’m pretty open in the outside of this in explaining that of all the things that one would learn in medical school there are none that I know less about than the eye. In fact, I come into this episode truly knowing as little as a layperson would know about the eye, and I think at the outside of the interview, I explain the extent to what I know about the eye. While it may be slightly more than you will know, I promise you that within about 15 minutes of this episode we are all going to be at the same level.*”
- Peter found this discussion fascinating; he treated it almost like the discussion he would have with Steven if they were at a cocktail party
  - He really picks Steven’s brain about the anatomy of the eye
  - Why is this relevant?
  - How does it factor into the natural processes of aging?
  - How does that differ from some of the pathologic processes that also tend to increase with age, but are not necessarily related to aging, per se.?
- This episode gets into the really simple fundamentals— what is nearsightedness?
  - What is farsightedness?
  - What is presbyopia, which by the way Peter used to think was farsightedness till he did this interview
- Also discussed are what the treatments look like for these things
  - Including a very nuanced discussion about how the different treatments might be beneficial to some people versus others
- [LASIK](https://en.wikipedia.org/wiki/LASIK) eye surgery will be explained as well as a procedure that came along slightly before that’s called [PRK](https://en.wikipedia.org/wiki/Photorefractive_keratectomy)
- Steven will talk a little bit about a procedure that is coming online today, called [SMILE](https://en.wikipedia.org/wiki/Small_incision_lenticule_extraction)
- All three of these surgeries are similar, but they differ in fundamental ways, and that can be an important thing to consider for someone in the market for one of these procedures
- Eye health is also discussed
  - What are the things that one can do?
  - What can be done to maximize eye health in our kids?
- Also discussed are some of the real epidemics that are going on in myopia
  - That is to say, kids that are requiring glasses earlier and earlier
  - What could be the cause of this and what can be done in our kids to prevent those things, and also in ourselves, what we can be doing
  - A lot of stuff is covered in this episode

> “*This is really the everything you need to know about the eye episode*” – Peter Attia

## Why Steven chose ophthalmology, and the crossovers to other medical disciplines [3:45]

- The eye is a topic that everybody has questions on, Peter included
- From medical school, Peter remembers there is an [optic nerve](https://en.wikipedia.org/wiki/Optic_nerve), a [cranial nerve](https://en.wikipedia.org/wiki/Cranial_nerves), and the second cranial nerve (this is the optic nerve)
  - He remembers something called [fovea](https://www.umkelloggeye.org/conditions-treatments/anatomy-eye), and he knows there’s a blind spot, but he’s forgotten why
- Peter remarks, “*It’s safe to say my knowledge of this topic right now is probably at par with everybody’s right?*”
- Steven understands, “*Well, that’s not rare, frankly, because the eye is so literally compartmentalized. We just don’t interact that much with other specialties, so it’s not rare for people who are in other specialties to be very ignorant of the eyeball, and that’s fine because I think it’ll help us keep the level of discussion at an approachable level for everyone.*”
- Peter asks if there has ever been discussion suggesting that ophthalmologists don’t need to do the four-year MD degree
  - How much of what was learned in medical school became relevant in residency?
- Steven says there was quite a lot
  - There’s nothing specifically magical about the eyeball
  - It’s got neurological tissue in the back, actual brain tissue in the back
  - It’s got a vascular supply
  - There are a lot of crossovers to other medical disciplines
  - All of the cellular processes are the same
  - He operates adjacent to the eye
- He thinks it’s important for ophthalmologists to have a general sense of medical knowledge, particularly because so many systemic diseases manifest as eye problems
- Now there is a discipline of medical training or of visual training, basically [optometry](https://en.wikipedia.org/wiki/Optometry)— which deals with the eye, but not all of the surgical stuff
- He works in a collaborative fashion with optometrists
  - Those are the folks who are fitting glasses
  - They’re screening for eye disease
  - They’re handling preoperative and postoperative care in many cases
  - They’re treating some diseases that are specific to the eye, such as glaucoma

**Ophthalmology training**

- Peter asks about ophthalmology residency— does everyone spend time operating?
  - Is there a nonsurgical discipline to this?
  - Does the training bifurcate?
- Steven explains, “*There are nonsurgical ophthalmologists, but I think they all start out as surgeons to become an ophthalmologist. You’re really training to become an eye surgeon.*”
  - But there are, for example, neuro-ophthalmologists, which are really more neurologists than eye surgeons; they don’t do eye surgery
  - There are some ophthalmologists who don’t do eye surgery
- Peter recalls one of his lasting memories from residency was stealing suture from the ophthalmology OR at Hopkins
  - As the [number of the suture](https://en.wikipedia.org/wiki/Surgical_suture#Sizes) gets larger the suture itself gets smaller
  - An O suture is thick, like a piece of rope
  - The scale progresses from 1-0, 2-0, 3-0, etc
  - By a 4-0 suture, it’s actually quite thin
- Steven replies they use an 11-0 suture
- Cardiac surgery uses a 7-0
  - Occasionally there’s some guys that would sew the distal end of a coronary artery with an 8-0 and at that level, it’s already very thin; just the slightest tug too much, and it breaks
- Peter recalls about ophthalmology, “*you guys wrote 11-0, and so I used to steal 11-0 constantly every night I was on call and practice suturing with 11-0. The thinking being, if you can tie in 11-0 with your hands and not tear it, that 7-0, which normally is like a piece of hair is going to feel like a piece of rope. I used it to help me develop a good feel for fine suture*”
- The tools in ophthalmology are tiny and Steven can remember the operating room where he did his training was near orthopedic surgery

> “*You hear this Black and Decker stuff going on over there, and our little tiny tools are very, it’s just totally different*” – Steven Dell

- Everything he does operationally is under a microscope
  - They use a binocular microscope
  - So he’s looking through both eyes, and this is either mounted from the ceiling and is controlled by his feet
    - The X, Y, and Z, and the zoom focus are controlled by a foot pedal
    - And that either comes from the ceiling or it’s on a really large stand
- He’s sitting and looking straight ahead, so the image is here, but he operating down below
  - It’s interesting because sometimes his wife will kid him, I’ll come home from a day of surgery exhausted, but she says something like, “*well, I don’t really get it. You’re just sitting in a chair, making these little tiny movements, and there’s soft music playing. It all seems very, very sedate.*”
  - It’s incredibly stressful and exhausting
- Ophthalmologists  have a problem where they tend to hyperextend
  - They tend to bring their head forward, to come up to the oculars and that creates a whole other set of problems
  - There are ergonomic challenges for sure, and he remembers early on in his career, he was coached very carefully on how to sit, how to have his spine arranged
    - One doesn’t want to crane their neck forward
    - He  has to make sure his shoulders are down
  - Steven notes, “*It’s interesting because when you train surgeons, and you look at them, they’re all raising their shoulders up, and they’re terrified that they’re going to do something wrong. They’re in a very, very compromised and stressful position, and then they tend to lift their hands up.*”
  - The surgical movements are these little tiny movements, so very small positional changes can have a huge impact on the outcome of the surgery
- Peter understands this problem, he has 2 friends from residency who required multiple neck surgeries
  - One of them could no longer operate after his surgery; he trained as a cardiac surgeon and now does cardiac critical care
    - It’s still a great career, but after 10 years of training as a cardiac surgeon, to not be able to operate…
- Peter asks if Steven knew he wanted to do ophthalmology when he began medical school
- No, but he knew he wanted to do something surgical, something with his hands
- He remember a Eureka moment where the first time he looked through a slit lamp (which is basically a microscope to look into the eye) he was hooked
  - This was during an ophthalmology rotation in a weeks where they did a little  ophthalmology and a little ear, nose, and throat
  - It was then that he knew ophthalmology was what he wanted to do
  - He had some exposure to ophthalmology prior because the father of one of his friends was an ophthalmologist
- Peter asks if ophthalmologists do a general surgery internship
- Some do; Steven did what is referred to as a transitional residence internship, where one does a little bit of everything: general surgery, internal medicine
  - It was very helpful
  - The general surgery part was rough, but it was nice to have exposure to a little bit of everything
- It was a 4-year residency, including the internship
- Peter asks what was the “bread and butter”?
  - For example, in general surgery in the 1960’s and 1970’s, it would’ve been Billroth procedures and things like that, where the most common thing one was doing was cutting out half of the stomach because of peptic ulcer disease and things like that
  - By the time he got to residency, he never did one of those because [H2 blockers](https://en.wikipedia.org/wiki/H2_antagonist) and [PPIs](https://en.wikipedia.org/wiki/Proton-pump_inhibitor) basically eliminated the need to surgically remove part of the stomach for gastric or peptic ulcers
- Peter wants to know, at the time of his training, where did 80% of the volume come from? What type of cases?
- It was [cataract surgery](https://en.wikipedia.org/wiki/Cataract_surgery) and then retinal disease
  - It’s still [cataracts](https://en.wikipedia.org/wiki/Cataract)
  - The scourge of essentially diabetes causes these very, very complex retinal problems

## Anatomy of the eye, common types of vision loss, and age-related vision changes [14:15]

- When Steven explains the eye to a kid, he compared it to a camera with film in the back; that’s the retina
  - Then the kid looks at his parents and asks, “*What’s a camera? Film, what’s that?*”
- The eye is built like a camera where in the very front is the [cornea](https://en.wikipedia.org/wiki/Cornea)
  - The cornea is the covering on the front of a watch; that’s the thing that a contact lens would sit on

![](https://peterattiamd.com/wp-content/uploads/2022/03/f1-dell.png)

**Figure 1. Anatomy of the eye.**  Image credit: [Kellogg Eye Center](https://www.umkelloggeye.org/conditions-treatments/anatomy-eye)

- The next thing is the [pupil](https://en.wikipedia.org/wiki/Pupil), which is the hole in the iris
- Behind that is the [lens](https://en.wikipedia.org/wiki/Lens_(anatomy)), it’s really one of a couple of different lenses inside the eye; but the lens behind the pupil
- Then there is the [vitreous cavity](https://en.wikipedia.org/wiki/Vitreous_chamber) and in the very back
- The [retina](https://en.wikipedia.org/wiki/Retina), which attaches to the [optic nerve](https://en.wikipedia.org/wiki/Optic_nerve), and that’s what goes to the brain
- Images come in; they’re bent by the cornea first, then bent again by the lens, and then they focus (hopefully) on the retina
- In a perfectly sized eye, in someone who doesn’t need spectacles to see, images come from say, optical infinity, which is for the purposes of this discussion, is about 20 feet or beyond where light rays come in parallel, and they’re bent so that they fall perfectly on the retina
- Peter asks him to clarify what fraction of the back of the sphere is considered retina
- The whole back of the eye is coded by retina
  - But there is the [fovea](https://en.wikipedia.org/wiki/Fovea_centralis), mentioned earlier; that’s the point where one casts their gaze
  - The image of the thing one’s looking at falls on the fovea, which is the very center, the bullseye literally of the retina
  - Steven notes, “*When I’m looking at you, images from you are following on the fovea of both of my retinas.*”

**Common types of vision loss and age-related changes**

- Now, if someone is [nearsighted](https://en.wikipedia.org/wiki/Myopia) (aka myopia), those images come into focus in a point that is not exactly on the retina, and so that can become a problem
  - Nearsighted means one sees things near well; one sees better up close, and needs glasses to see things at a distance
- [Farsighted](https://en.wikipedia.org/wiki/Far-sightedness) (aka hyperopia) is a little trickier because farsighted people see better at far
  - But their far might also be blurry; it’s just that the near vision is even worse
- Peter asks about the person who says they are near and farsighted; is that an accurate statement
- No, it’s actually probably that they’re [presbyopic](https://en.wikipedia.org/wiki/Presbyopia), which is that they see well far away
  - Their focusing ability is compromised, typically through age, and they can’t see up close
- Peter is very interested in the details of this because a few years ago this rocked his world, it didn’t happen gradually but seemed to happen overnight

> “*Some people wake up on their 40th birthday, and they say, I just can’t see up close anymore, and for others, it’s a little more gradual process*” – Steven Dell

- When a person is born, and when they are young, the lens of their eye is extremely elastic
  - It’s like a gummy bear, and it can change shape to bring near objects into focus
- With age, and this is universal, the elasticity of the lens goes down, and one is no longer able to zoom focus in
  - So one has to start pushing things farther and farther away or get some optical aid like a pair of spectacles to see up close
  - That process continues as the lens become less elastic and harder, eventually resulting in a [cataract](https://en.wikipedia.org/wiki/Cataract) where it begins to lose its optical clarity
  - With a cataract, the lens is stiff, hard, and starts to become opaque
- Peter asks if this is considered a natural product of aging, the way our skin wrinkles and the elasticity changes, or is it considered a pathology in the way that type II diabetes is a pathology, not necessarily a normal consequence of aging, but it can be avoided?
- Steven thinks that cataract formation is a universal component of days on earth
  - He doesn’t recall seeing many people in their 70s without some degree of cataract formation
  - It starts to become universal
  - However, there are things that can pathologically prematurely cause cataract formation
    - Some of them are surprising, like being electrocuted can actually cause premature cataract formation; trauma, head trauma can certainly do it
    - Typically the eye is in the head, and if the head receives trauma, there’s going to be a certain amount of trauma in the eye itself
    - Peter clarifies, the point is, it doesn’t have to be direct trauma to the eye
    - Forces of the brain are presumably also being reverberated through the vitreous fluid
    - The eye is a fluid-containing organ, and when it receives trauma, those same forces come to bear on the eye itself
    - It is more common to develop cataracts when one has direct eye trauma, buteven head trauma alone can predispose someone to cataract formation
    - Certainly, diabetes is a cause of premature cataract formation
    - Steroid use, corticosteroid use can lead to cataract formation

**The lens of the eye**

- Peter asks if the [lens](https://en.wikipedia.org/wiki/Lens_(anatomy)) is a vascular structure
- It is  not; the lens is about the shape and size of an M&M candy, a plain chocolate one
  - It’s got a coating like the candy shell, and the protein inside (the chocolate) is optically clear when one is a kid
  - That protein does not turn over or exchange, but the membrane (the candy coating, the so-called [lens capsule](https://en.wikipedia.org/wiki/Capsule_of_lens)) can allow molecules to diffuse in and out
  - A classic example of this— someone will point out, hey, my vision, my glasses prescription suddenly changed; they became much more nearsighted, or farsighted in the space of a month
    - They go to the eye doctor, and find out that their glasses are totally wrong
    - The first thing Steven thinks of is for them to go get their blood sugar checked because glucose can diffuse into the lens and cause it to swell
      - This will change the shape of the lens
      - The lens becomes physically bigger; it’s like a thicker, more powerful lens
    - Diffusion of glucose into the lens causes an osmotic change
    - The timeframe for that to happen is over a period of several weeks
    - If the blood sugar goes up there may be a lag of a month or two before the vision change
    - And when the blood sugar goes down, same thing; it takes weeks for that to go back to normal

**Blood-retinal barrier**

- Peter asks if the eye is an [immune-privileged site](https://en.wikipedia.org/wiki/Immune_privilege)
  - Is it more or less susceptible to systemic infection?
- Steven notes the eye itself is certainly prone to damage from systemic infection
- There is a blood-retinal barrier in the same way that there’s a blood-brain barrier that protects that highly metabolically active retina from systemic disease
- The lens itself is relatively privileged from an immune standpoint
  - It’s within that capsule, and it’s hard for large molecules to get across that, small molecules can
- Peter notes this is important from a pharmacotherapy standpoint

**Eye drops in development improve vision by restoring elasticity to the lens**

- On that topic, Steven mentions a medication being examined as a way of softening the lens to to maybe break some of the [disulfide bonds](https://en.wikipedia.org/wiki/Disulfide) that become a problem and become one of the reasons why the elasticity of the lens is lost
  - This is a lipoic acid choline ester; [the safety study was just published](https://www.nature.com/articles/s41433-020-01391-z)
- Peter clarifies, “*You’re saying there might be a day when there’s either an optical or injectable substrate that could go into the lens that could delay the onset of farsightedness?*”
  - Yes, and the onset of cataract
  - At the moment it’s in the early experimental phase
  - This compound must be applied in a topical fashion
  - So putting in an eyedrop and that drop has to run the gauntlet of going through the cornea, which has lipid layers and water-soluble layers
  - It’s got to get through all that into the aqueous humor in the front and then through the lens capsule into the lens to actually do its work
  - That’s why this particular drug or compound is a choline ester, because that allows it to get through that lipid layer in the front, through the water-soluble portion of the cornea, and then hopefully into the lens itself
  - This is not easy to do; the lens is a relatively privileged area, both from an immunological, but also a pharmacological standpoint

**Anatomy of the eye from back to front**

- Everyone recognizes the [pupil](https://en.wikipedia.org/wiki/Pupil) as the dark part
  - The pupil changes size to dilate and constrict, or is this just the iris moving (the colored part of the eye)?
- Yes, the physical aperture of the pupil changes in size; it gets bigger; it gets smaller
  - When someone goes to the eye doctor, and their pupils are dilated, the pupil is physically opened up pharmacologically, and that’s mostly so the doctor can see into the back of the eye to see what’s going on
  - In effect, this forces the iris to move out of the way
- The [iris](https://en.wikipedia.org/wiki/Iris_(anatomy)) almost looks like the aperture of a camera; one can either constrict it or make it bigger

## Eye drops that can potentially improve vision [27:30]

- Interestingly, one of the big pharmacological frontiers in development are drugs that intentionally shrink the aperture (of the pupils) in the pursuit of increased depth of focus
- Students of photography will know that the smaller the aperture, the smaller the hole, the more stuff is in focus at the same time
- If one can make the pupil small pharmacologically and get it into the sweet spot (which is probably about 1.6 millimeter) one can suddenly see up close again
  - This expands the depth of focus
- Peter clarifies, so another way to manipulate the ability to see things up close is to force the aperture of the lens to be in a position that isn’t necessarily dictated by the availability of light?
  - This relates to the movement of the lens in and out along the Z-axis
  - Also putting aside any other problems that can occur with the lens
- Steven explains, “*That’s exactly right. Imagine it’s squinting.*”
  - When one squints, they’re reducing the aperture through with they are looking and filtering out optically
  - If one can get rid of those scattering rays that make the image blurry and only use those parallel rays that happen to be coming parallel off of an object, then one can actually resolve it and see up close again

**Presbyopia**

- Peter thinks this is a little counterintuitive
  - He’s farsighted and knows that nothing makes it worse, nothing makes [presbyopia](https://en.wikipedia.org/wiki/Presbyopia) worse than darkness
  - One example is the difficulty he has reading this train book to his kids in bed
    - It’s dark and the font is small
    - So he has to get his glasses
  - The other place it’s a problem is in a restaurant, where it’s usually poorly lit
  - In both those situations, isn’t his aperture narrowed?
    - Steven explains no, it’s the opposite; “*If you put the sun on something, you’re going to be able to read it because your pupil constricts*”
    - Peter asks if this is why light makes the difference
    - Yes, it’s the pupil effect alone; constriction of the pupil
    - Some of it is the light; there’s much more light energy available to resolve something

“*So yes, there are competing forces when you reduce the size of the aperture. You’re letting less light in, but the only light you’re letting in are those rays that happen to be parallel in perfect focus, and you can actually see.*” – Steven Dell

- In an ongoing clinical trial that he performed to look at this, those competing forces were examined very closely, and they found that the aperture effect, the depth of focus outweighed any loss of vision from loss of light
  - Data not yet published
- How long would the effect of these eye drops last?
- This actually depends a little on eye color
  - Light eyes tend to react more to any given strength of dilating drop (or constricting)
- It would last about 6-8 hours, maybe up to 10 hours
  - So this would be a once-a-day, maybe a twice-a-day eye drop
- Peter wonders if this would compromise far vision
- No, and what was really interesting is when Steven looked at patients who had their pupil size reduced pharmacologically, their distance vision also improved by the same principle because their depth of focus was so good
  - In the same way that one can squint and make out a highway sign if someone is a little bit nearsighted or a little bit farsighted, or has an [astigmatism](https://en.wikipedia.org/wiki/Astigmatism)
- Squinting improves vision and pharmacological manipulation of the pupil will do this as well
  - He thinks commercials for these drugs will begin to be aired early in 2022
- Peter notes, the complicated aspect of these eye drops is the drug has to make its way into the lens
  - He sees now why that would be more about the cataract issue and not about the presbyopia issue; this would be a much easier way to solve presbyopia because the drug only has to get onto the iris
- Steven explains that this is a drug that shrinks the pupil and works in 15 minutes
- Versus something that softens the lens that might work in 15 months
- Those  are very different markets
- Lipoic acid choline ester is being pursued as a presbyopia near vision aid or something to reduce the effects of
  - One real goal is to reduce the incidence or delay the onset of cataract formation, which would be really cool
  - Study published in *Eye* in 2021,  [Topical lipoic acid choline ester eye drop for improvement of near visual acuity in subjects with presbyopia: a safety and preliminary efficacy trial](https://www.nature.com/articles/s41433-020-01391-z)

## The explanation for different eye colors [33:15]

**Darker eye color provides greater protection from UV light**

- Is there any clear evolutionary explanation for why different eye colors have emerged? What’s the advantage of brown iris versus blue?
- The advantage of a brown iris is the protection it offers from [UV light](https://en.wikipedia.org/wiki/Ultraviolet), and visible light
  - This works in the same way as darker skin tones
  - So typically, it is common to see dark-eyed people clustered closer to the equator because the visible light and UV light and infrared light or infrared radiation are really destructive
- One of the few things that people remember from medical school about the retina is it’s one of the most metabolically active tissues in the body
- And because it’s constantly being bombarded with radiation, effectively, it’s prone to free radical formation
  - So what’s called the [retinal pigment epithelium](https://en.wikipedia.org/wiki/Retinal_pigment_epithelium), which is the pigmented layer behind the retina, underneath the retina, that is responsible for shielding the vascular supply behind the retina from all of this radiation
  - This is important because the vascular network behind the retina has a very high oxygen tension, and it would be prone to free radical formation if it were constantly being bombarded by UV light, infrared radiation, visible light
  - That’s why one sees in people with more pigment  near the equator; and that’s also true of the iris as well

## Physiology of the eye and its connections to the brain [34:45]

**The role of rods and cones in vision**

- [Cones](https://en.wikipedia.org/wiki/Cone_cell) are primarily for daytime vision and they’re clustered in the center of ones visual sphere
  - So near the center of the [macula](https://en.wikipedia.org/wiki/Macula_of_retina), which is the central portion of the retina, and the very center of the macula, is the [fovea](https://en.wikipedia.org/wiki/Fovea_centralis); this is where the cones are
- The [rods](https://en.wikipedia.org/wiki/Rod_cell) are in the periphery and they typically are responsible more for dim illumination vision like night vision
  - And they’re very good at picking up motion
  - So as predators, we want to make sure that we can hone in on where prey is, but as prey ourselves, we want to be able to detect, danger something moving in the periphery
- Each rod cell and each cone cell provides one signal
  - They are highly specialized calls
  - They are referred to as [photoreceptors](https://en.wikipedia.org/wiki/Photoreceptor_cell) and they have stacks of structures within them that are photosensitive; and that causes a depolarization
  - Peter asks if they work like channel opsins; do they use a photon to create an action potential?
    - Yes, once a photon hits a particular cell photoreceptor, there’s a change in the membrane and ions flow; and that’s how a signal is generated
    - And this ion flow ultimately makes its way to the optic nerve and then to the brain

**Visual processing in the brain**

- Most of the visual processing is in the very back of the brain
- And about half of the overall brain structure deals with vision in some capacity
  - That’s why, for example, when people have a stroke, there’s almost always some component of visual involvement in a stroke
  - Someone may have a droopy face on one side and then a limb is droopy as well
  - But if one maps out the visual sphere, they will detect some deficit in the visual sphere for most strokes
- Peter puts this in context of brain structure—
  - The [brainstem](https://en.wikipedia.org/wiki/Brainstem) is the most primitive piece of the brain; it is basically responsible for autonomic function
  - Next is [midbrain](https://en.wikipedia.org/wiki/Midbrain) that sits on top of it
    - It is sort of a reptilian brain, a lot of emotion there
  - Then, what in theory distinguishes humans from all the other animals is this remarkable [cortical](https://en.wikipedia.org/wiki/Cerebral_cortex) piece that sits on top of it
    - How much of the visual processing is in that [neocortex](https://en.wikipedia.org/wiki/Neocortex)? Is it virtually all done there? —Yes
  - Pupil responses are controlled by the midbrain, autonomic stuff
  - Visual processing and the actual mapping of the visual sphere has been mapped to the cortex
  - Parts of the brain that are specific to edge detection or moving edge detection has been mapped quite elegantly to the cortex
- Peter asks, “*Is there a cross? Is the left doing the right and vice versa?*”
  - Yes, that’s right
  - Remember, information is sent from your left visual sphere to the right side of the brain
  - But information is coming from both eyes
- The simplest way to think about something is that at the [pituitary](https://en.wikipedia.org/wiki/Pituitary_gland), there is something called the [optic chiasm](https://en.wikipedia.org/wiki/Optic_chiasm)
  - This is where the optic nerve crosses; about half the fibers cross
  - So if a visual deficit is in one eye only, this shows that it is in front of the chiasm
  - And if it’s behind the chiasm, it should affect both eyes, maybe asymmetrically, but it should affect both eyes
  - This can be very helpful in localizing where a particular problem is
  - Now, a lot of that’s done through imaging, but there used to be quite an art to this clinical exam
- Peter remembers both in neurology and probably neuroanatomy, kind of going into these really crazy tests where he’d see the patient performing the tests and missing a certain thing
  - It looked like they must be faking it; like there’s no way to produce such a bizarre deficit in this one part of this one visual field
  - But then, if there was a tumor, it would totally explain this once one understands how the nerves cross
- Steven remarks, “*It kind of goes back to one of your earliest questions, which is, do you think that eye surgeons need to go to medical school? Yes, because we diagnose brain tumors. We find things that are systemic diseases that have ocular manifestations.*”

## Understanding human vision through an evolutionary lens [41:00]

**Vision is our most highly developed sense**

- Peter notes that our eyesight is the one sense humans have that rivals the best in nature
- From an evolutionary standpoint, “*Is that because we both had to, as you said, be hunters and be hunted for such a large part of our evolution?*”
- Steven thinks yes, “*Imagine you are in the desert and there is a single candle a mile away from you and it’s pitch black. There’s no moon. You can see that*”
  - But in that same desert at high noon, where there may be 200,000 [lux](https://en.wikipedia.org/wiki/Lux) illumination, human eye site is still good
  - Humans can see so many, many orders of magnitude of change of illuminations
  - It’s astonishing that our eyes can function in both of those environments
- Peter notes humans have a short-lived advantage over some animals when it gets darker
  - There’s a very narrow window at dusk and dawn, where humans have better vision
  - Maybe humans evolved to have good vision in a slightly greater range of light
  - He’s always been amazed at why we did not develop a better sense of smell
    - Humans effectively can’t smell compared to animals; it’s absurd how different it is
    - This is true for our hearing as well; ours is nothing compared to them
- Steven notes about vision, “*It’s the one sense that if you asked people which sense they’d be most willing to give up…this is the last one*”
  - It’s very common for patients to grab his arm as they are going into surgery and say,  “*Dr. Dell, you don’t understand. My vision is really important to me. I’ve got to see. I’ve got to see.*”
- Peter understands the importance of sight relative to other senses
  - In COVID many people lost a sense of smell and a sense of taste, at least transiently
    - This is inconvenient, but it’s totally survivable

> “It’s hard to function in the world as a blind person. It’s a fear that many of us have.” – Steven Dell

- It’s a sense that people value very highly
- And also evolutionarily it’s valued highly just owing to the fact that so much of the brain is devoted to vision

**Vision loss due to trauma can often be prevented**

- Peter recalls, “*When I was a kid, we did so many dumb things without ever any concern for our eyes. I just don’t think our parents knew enough and we didn’t think about it. So I’d be out in the backyard, chucking things around, cutting wood, smashing rocks, never a thought to put on safety goggles. And now my kids, who are both completely obsessed with cutting down trees and they’re very active outdoors. I mean, they just know, you’re wearing your safety goggles if you do that stuff, because I’m totally paranoid they’re going to have one of these tragic accidents.*”
- Steven agrees, this is a good PSA; he sees a lot of eye injuries

> “*I think injuries are one of the main causes of devastating visual loss in young people*” – Steven Dell

- In general, almost all of the big causes and movers of visual loss are senescence-related or age-related
  - But in young people, it’s trauma
- Blunt trauma is the most common eye injury he sees
- The eye is pretty well protected with the brow and the cheek, but there are certain things that can get in there and can directly impact the eye
- In a young person, trauma is something one has to watch out for
- Peter asks, “*What is the velocity at which we can’t out blink it?*”
  - “*Because the other day my son was smashing beads and he didn’t want to put his safety goggles on. And I was like, “Look buddy, you got to get these things on.” And he goes, “No, dad.” And he’s like, “Why?” And I said, “Because you’re hitting sharp objects with a sharp object. If one of them flies up and hits your eye,” and he goes, “I would see it. And I would close my eyes.” And I’m like, “No you wouldn’t, buddy.”*”
  - Steven agrees, you wouldn’t blink in time to keep objects like this out
  - Peter notes that some objects move slower; “*If somebody’s throwing you a ball and you misjudge it, you’re going to blink. That’s slow enough that you can catch it.*”
  - Steven agrees but points out there are other objects that move faster
  - He’s operated on a number of major league baseball players and for them seeing the laces on the ball as hitters is enormous; it’s their career
    - It’s the difference between them hitting well or average
    - And some of these players that he’s operated on have been 20/20 before they had surgery, but they wanted to be 20/15 or 20/10

## Enhancing vision beyond 20/20 [47:00]

**What is 20/20 vision and can this be enhanced?**

- 20/20 simply means that one can see at 20 feet what a “normal” person can see at 20 feet
- If one’s vision is 20/10, they can see at 20 feet what a normal person has to get 10 feet up to in order to see
  - So 20/10 is better than 20/20
- So some of these major league baseball players want to be 20/10 or 20/15
  - He’s been able to achieve that with modern forms of laser vision correction
- Steven had a discussion yesterday with a guy who owns a soccer team and he said, “*Have you ever had your players tested for their vision?*”
  - The guy sort of froze and turned white for a second; and he just said, “I*t’s so crazy you say that because we put them through this barrage of tests physically to see what their heart, their lungs, their kidneys, all that stuff, we didn’t check their vision.*”
- There are ways to boost human performance beyond 20/20
- The theoretical limit of how well one can see is defined by essentially the pixelation of their retina
  - This is the spacing of the cells of those [photoreceptors](https://en.wikipedia.org/wiki/Photoreceptor_cell) discussed earlier
  - This varies from person to person, but it’s somewhere in the vicinity of about 20/08 or so
  - With a sharp enough image, one could theoretically see better than 20/10
  - And the only way one can really achieve that is to remove some of the optical irregularities that everyone is born with and somehow neutralize them along with the glasses prescription
    - Currently, this can be achieved laser vision correction

**Laser vision correction compared to contact lenses**

- Peter asks, “*Why would it be beneficial to an athlete who, for understandable reasons, needs the best vision possible to undergo laser corrective surgery versus just using contact lenses to accomplish the same thing? Is that possible?*”
- Let’s first consider contact lenses; anyone who’s ever worn contact lenses knows that when they put in a brand new pair, they can see pretty well with them
  - But then the eye begins to regard that contact lens as a foreign object
  - So one’s body just begins to attack it, coat it with all sorts of immunological debris
  - One is susceptible to pollen, dust, whatever it is that coats this formerly pristine object
  - And let’s say there is correction for [astigmatism](https://en.wikipedia.org/wiki/Astigmatism) in that contact lens, where its orientation is important
  - Every time one blinks, that contact lens moves a little bit
  - All of those factors contribute to optical performance that is less than what could be achieved with spectacles or laser vision correction
  - In particular, soft contact lenses do a very, very good job, but they typically don’t provide superhuman vision performance
- Peter recalls, “*It’s funny, I experimented two years ago with a stronger prescription than normal to get me to 20/15 in my dominant eye for archery.*”
- Steven comments this must have goofed-up his near vision
  - Yea, that was the problem
  - Peter abandoned it immediately after 6 months of suffering
  - It made his [presbyopia](https://en.wikipedia.org/wiki/Presbyopia) worse

## Astigmatism: definition, cause, and high prevalence [51:30]

- Steven describes [astigmatism](https://en.wikipedia.org/wiki/Astigmatism) as when the eye is shaped like a football instead of a basketball
- Specifically the [cornea](https://en.wikipedia.org/wiki/Cornea), the very front part of the eye, typically
  - The cornea is about as thick as a credit card, about 500-550 microns (half a millimeter)

![](https://peterattiamd.com/wp-content/uploads/2022/03/f2-dell-1024x749.png)

**Figure 2. Anatomy of the eye, the cornea.**  Image credit: [Britannica](https://www.britannica.com/science/human-eye/Extraocular-muscles)

- There can be astigmatism in the lens itself, the lens behind the pupil
- Peter has a corneal astigmatism; that’s the normal one
  - This simply means the eye is not perfectly shaped; it’s a bit oblong like an egg or football
  - Steven compares it to an American football, “*So if you are walking along the laces of the football, you would encounter a fairly gradual curve. But if you took a right turn and walked it perpendicular, it would be very steep.*”
  - That means that the power differs by meridian; so Peter needs a different glasses prescription in this meridian versus this meridian
- The prevalence of astigmatism is pretty high
  - Around 60% of patients with a glasses prescription have some significant degree of astigmatism

**Evolution of vision problems**

- Peter wonders why poor vision has been allowed to evolve, “*Vision that would impair your ability to survive through reproductive age probably didn’t evolve*”
  - Maybe there was a day when the genetic variability of eyes was broad enough that a subset of people had really poor vision; the type of people who maybe aren’t around today?
  - Steven agrees, “*This is a super interesting topic and it shows you how plastic the evolutionary or actually the adaptive component of the eyeball is itself.*”
  - The length of the eye is really what determines whether one is nearsighted or farsighted
    - This is the distance from front to back, anterior-posterior length of the eyeball
    - Primarily, that is the main driver as to whether one is nearsighted or farsighted
  - Those who are in the know and are watching this or listening to it also realize that sometimes it’s the curvature of the cornea that contributes to whether someone is nearsighted or farsighted

## Nearsightedness (myopia): causes, epidemic in children, and prevention strategies [54:15]

- But let’s say for the purposes of this discussion that it’s the length of the eyeball that is the main reason why someone is nearsighted or not or farsighted.
  - So a very nearsighted person has a very long eyeball
- Peter wants clarification, with a very long anterior-posterior axis, one is going to have a hard time seeing things far away
  - Is that because the further away something is, the harder it is to focus all the light coming in?
- Steven explains, when most of one’s visual environment is close, then the light rays from that close object are diverging
  - So these light rays are falling behind the retina of someone who’s perfectly targeted for distance
  - The eyeball is really smart and it says, “*Okay, so you’re telling me everything is here, close up. I know, I’ll just grow longer so that these near objects are in perfect focus.*” And that is exactly what happens
  - This can happen over a period of months
    - If a young person exclusively performs near tasks, their eye will grow longer so that those near objects are in perfect focus

- Peter comments “*So if you could do an awful experiment…*”
  - Steven says, “*It’s been done*”
  - This is what is happening in our current society;  children looking at screens, near objects, for hours on end and not going outside often develop nearsightedness
- There are two drivers of nearsightedness in the plastic developing human
  - 1) Deprivation from outdoor light
  - 2) Near work
- Many of studies of children have been done in Asia, where there is an epidemic right now of [myopia](https://en.wikipedia.org/wiki/Myopia) of astonishing proportions
  - About 90% of the population is now nearsighted in certain southeastern nation cities
  - When that becomes such a dominant phenotype, something is really oddly off
- Peter notes, “*this really transcends evolution because if you can change something in years or months*”
- Steven clarifies, “*It’s not evolutionary. It’s adaptive within the eyeball itself.*”
- Groups of 7- to 11-year-old children have been studies
  - Send half of them outside for 80 minutes during the school day for recess
  - Keep half of them indoors for recess
  - The risk of or the incidence of nearsightedness is half in the group that went outside
    - So the risk of nearsightedness can be cut in half by going outside
    - Without any instruction to go and look at things far away, but just by the very fact that outside there’s so much more to see and ones is going to be looking further out
- This has been further studied in terms of is it just being outside or is it the light?
  - It’s actually both
  - But the light is really the most important driver of protection from nearsightedness
  - So if one is outside on a bright sunny day, they’re releasing a fair bit of [dopamine](https://en.wikipedia.org/wiki/Dopamine) from the retina and dopamine inhibits the growth of the eye
  - So the worst thing to do is stay inside in a dimly lit room and perform near tasks
    - That raises the risk of nearsightedness 16 fold compared to kids who go outside
- Peter asks if epidemiological studies show that the further one is from the equator the greater the risk of nearsightedness, simply based on the light part of this argument?
- Yes; there is some data that shows that
  - And not only that, they’ve taken children and given them equal intervals of outdoor activity, but the ones who had noontime outdoor activity did better than the ones who were outdoors at 8:00 AM, when there was less illumination
  - Further, it is known from animal models that it is illumination that is critical in this dopamine release
  - So does that mean more skylights in classrooms or more windows or more natural light would be beneficial?
    - Could artificial light mimic some of the sunlight by making these rooms brighter and prevent some of this myopia epidemic?
- Peter reasons, “*Is a photon, a photon, a photon?*” How does this work
- It is not known whether that’s the case because there’s a whole spectrum of light
- So is the blue light more important? This is tangential
  - One hears all this negativity about blue light
  - Blue light is critical for wakefulness, for attention, and Steven thinks for preventing myopia

**Other risks associated with nearsightedness**

- By the way, myopia (or nearsightedness) is not just the inconvenience of wearing glasses or contact lenses or having laser vision correction when one is 23 years old
- There are pathologies that are much more common in very nearsighted patients compared to the general population
  - It’s much more common to see cataract formation in myopic patients
  - They get something called myopic macular degeneration
  - They’re at risk for glaucoma
  - They’re at risk for tears and detachments of the retina
  - These are disease-associated conditions

**Considering vision from an evolutionary perspective—Is there genetic susceptibility to vision loss?**

- Peter returns to his evolutionary question, “*it’s quite possible that over hundreds of millions of years, any deficit in vision that would’ve prevented you from reproducing or impaired your ability to escape a predator would’ve taken that out. So from a genetic standpoint, our vision should be very good.*”
- Steven clarifies that vision is very good in non-literate societies
  - In hunter-gatherer tribes, there is no nearsightedness; it just doesn’t happen
- Peter finds this amazing and asks, “*This suggests that because my parents wore glasses, I should wear glasses, is not true. Or is there an epigenetic part of this?*”
- Both are true; there is a genetic component
  - For siblings of individuals who wear spectacles, there is a higher incidence of [myopia](https://en.wikipedia.org/wiki/Myopia) or [hyperopia](https://en.wikipedia.org/wiki/Far-sightedness)
    - This could be susceptibility
    - It is not known whether parents of reading children were reading children themselves; so it’s hard to separate out the genetic component; there does seem to be a genetic component as well
    - But the environmental component seems to be way stronger and more powerful
      - Take parents who don’t wear spectacles and put their child in a dark room and give them an electronic device or a book or whatever it is and have that child focus at near for hours on end, odds are they’re much more at risk for developing nearsightedness
- Peter thinks about his kids; his wife has perfect vision and his [diopter](https://en.wikipedia.org/wiki/Dioptre) is -3 and -4
  - What does that mean in terms of the 20 scale?
  - It depends on how much he squints when he looks at the eye chart
  - Steven honestly doesn’t attach a lot of significance to the 20/100 or 20/80, whatever it is
    - Peter is probably in that ballpark, maybe 20/100
  - Peter notes that he’s at the point where without contacts, he can’t drive, he can’t do anything
    - And some people are -15
    - They literally must have their glasses near the bedside
    - Peter can spend the first hour of the day without contact lenses
      - It’s easier for him to read without his contacts

**Near tasks such as reading and extended screen time can result in nearsightedness**

- Steven notes that things are very well in focus at a typical normal reading distance for Peter; so his eyes have been tuned postnatally for near work
  - That is a result of his development
  - Peter must have spent a lot of time reading or doing near tasks
  - Peter notes, “*I grew up in Canada. So from a light perspective, it wasn’t so great. You had two months of no light whatsoever, but I didn’t watch TV much as a kid, maybe 30 minutes a day. I was mostly outdoors. I’ll tell you, this is funny. I didn’t need my first pair of glasses till college. So it could also be that this happened later in my life as a result of more book work.*”
- The classic example Steven sees is law students who have great vision when they enter law school but then they read for 12 hours a day and then they come in and they say, “*You know, I think my vision’s going.*”
  - He looks at them and sure enough, they’ve become nearsighted
  - That’s not rare in many graduate school situations, where there’s just grinding reading for hours on end

**Preventing nearsightedness in children**

- So Peter thinks this is very important for his kids; it’s too late for him
- Steven agrees, get them outside
  - Make sure they’re spending a couple hours outside a day
  - The data also suggest that good illumination would be helpful as opposed to poor illumination
  - But he doesn’t want to discourage near activities because those are really important developmentally
- Peter wonders if the opposite is true for hunter-gatherers or illiterate societies who are outside all the time
  - They don’t develop nearsightedness
  - Do they develop farsightedness?
- No, Steven thinks they are fairly well tuned to distance vision, to prey hunting, etc.

## Cataracts: impact of aging and how they can be repaired [1:05:00]

- Now, there’s a whole host of other problems that come into play once one has outlived their genetic usefulness, after one has reproduced and imparted their knowledge onto the next generation
  - Then one can go ahead and get cataracts because they’re done from a standpoint of genetic utility
- Peter asks if developing cataracts is functionally like atherosclerosis
  - It’s something that has no bearing on reproductive capacity, but is otherwise inevitable to our species
  - Steven agrees, it seems to be fairly inevitable to our species
  - He hasn’t seen patients in their 70s typically who don’t have some cataract formation
  - Now there are patients who are 80 that are still functioning with cataracts, but the optical clarity of their lenses has degraded to the point that it’s not the way it was when they were 20
    - Maybe their visual needs are significantly reduced

> “*But if you took an 80-year-old lens and you put it in a 20-year-old person, they would be shocked at how poor their vision is*” – Steven Dell

**Vision loss due to light exposure and trauma**

- Peter recalls, earlier Steven mentioned that [senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence) or their soluble secretory products probably play a role in the loss of vision as one ages
- In the lens, Steven thinks it’s mostly that the lens proteins are degrading or becoming damaged over time
- Maybe UV light contributes to this
- It’s known that light exposure is related to cataract formation, as are some of the other things previously discussed like: glucose going into the lens, corticosteroid use
- It is not known what it is specifically about trauma that causes a premature loss of clarity of the lens proteins
  - The trauma worries Peter because he boxed for so long
    - He took way too many hits to the head
  - Steven comments “*The cataract would be the easiest thing to fix*”

> “*Cataract surgery today is like a four or five-minute procedure, and it’s astonishingly effective*” – Steven Dell

**Cataract surgery implants a new lens**

- Cataract surgery typically is not repeated; it’s a once in a lifetime deal
- Peter asks what the cataract patient experiences; is it like wearing glasses that are dirty
- The first thing they probably notice is changes in their night vision
  - Glare, halos, streaks off of lights at night, problems with contrast sensitivity, for those who can appreciate that loss of contrast
  - These are really early signs of cataract formation
  - This is common at age 54 or 64
- Steven typically lets the patient decide when it’s the right time for them to have the surgery once he determines that the cataract is visually significant
- There are people who elect to have their cataracts removed earlier than they really need them removed as a means of getting rid of their glasses prescription
- Now the implant lenses that are put in to replace the cataract, they have advanced in terms of function to the point that they can fix the near vision, as well as the distance vision, the astigmatism, the nearsightedness, the farsightedness, the presbyopia
  - These are all correctable with artificial lenses that he puts in the eye to replace the cataract
- There’s a fascinating history about the evolution of [intraocular lenses (IOL)](https://en.wikipedia.org/wiki/Intraocular_lens)
  - But back in the days of his residency, the implant lenses that were put in were simply designed to give the patient good vision with spectacles
  - These lens only replaced the cloudy lens with something that was in the ballpark of good distance vision; the patient would still need to wear spectacles after the surgery
- Peter asks, “*Does all cataract surgery involve the placement of an extra lens?*”
  - Yes, virtually every cataract surgery he performs involves removal of the cataract and replacing it with an artificial lens
  - To clarify, “*Does that mean removing the entire lens or removing a diseased part of the lens that has the cataract in it?*”
  - Remember the analogy of the M&M candy
    - The shell is left
    - He opens a hole in the front of the shell and takes out all the chocolate
    - Now it is kind of like a flattened bowl; it looks like a Japanese teapot flattened
    - The implant lens is placed in that bowl; the bowl holds the implant in place
- The implant lens is a bendable plastic object; it can be folded up and put through a tiny incision then opened up again
  - This folding and opening of the implant lens was a very big advancement that happened in the 1980’s

**Cataract treatment in ancient times**

- Prior to this is a really amazing series of stories
- In the ancient world, if one had cataracts, the way they dealt with it is that they would just poke the lens of the eye backward, and it would drop down into the bottom of the eye so that the person now had a clear optical pathway, again, to let light in
- This took someone who was functionally blind and allowed them to see shapes
- They no longer have a lens, so there is no way to focus
- But it’s basically like taking someone who has no light transmission and saying, “*We’re going to let unfocused light go through.*”
- This is what happened in in [Hammurabi time](https://en.wikipedia.org/wiki/Hammurabi)
  - The fact that they knew enough to do that is kind of amazing
- There’ve been artifacts uncovered; a lot of them were made out of gold
  - They would take a gold needle and poke it through the cornea
  - The procedure was called [couching](https://en.wikipedia.org/wiki/Couching_(ophthalmology))
  - They would just poke the lens, and it would detach from its ligamentous attachments and then drop down into the bottom of the cavity of the eye
  - There are some of these artifacts from Egypt
  - This was done in China
  - It was certainly done in ancient Greece; that was how they dealt with cataracts back then
  - Peter notes, “*you’re talking about, what, 5,000 years ago, right. This is not… In an evolutionary timescale that’s a pittance, right*”
    - Would it be better to be the poorest person on earth today than to be the Pharaoh of Egypt 5,000 years ago
    - Steven thinks in many ways, yes

**The first implant lens**

- Fast forward to right after [World War II](https://en.wikipedia.org/wiki/World_War_II); there’s an ophthalmologist in the UK named [Harold Ridley](https://en.wikipedia.org/wiki/Harold_Ridley_(ophthalmologist))
  - He notices that some of the [RAF fighters (Royal Air Force)](https://en.wikipedia.org/wiki/RAF_Fighter_Command) would have fragments of their plexiglass canopy inside their eyeballs
    - This canopy would shatter when they were fired upon
    - Shards of plexiglass essentially would be inside the eyeball
  - And the dilemma was what to do about this
  - He learned very early on that these fragments were biologically inert
    - The eye was perfectly happy and people could walk around the rest of their lives with a shard of sharp plexiglass inside their eyeball
    - This is a foreign object that has now entered the eye, not necessarily in the human lens; it might even be in the [vitreous cavity](https://en.wikipedia.org/wiki/Vitreous_chamber), or in the front of the eye
- So the light bulb goes off; he realizes one can put plexiglass (which is essentially [polymethyl methacrylate](https://en.wikipedia.org/wiki/Poly(methyl_methacrylate))) in the eye, and the body doesn’t really care that it’s there, doesn’t mount an immune response
- So in Ridley’s [book](https://www.amazon.com/Sir-Harold-Ridley-Fight-Sight/dp/1556427867/ref=sr_1_1?keywords=Harold+Ridley&qid=1637684118&qsid=131-3146834-4509605&sr=8-1&sres=1556427867%2C0197604544%2C022617428X%2C0692536558%2C0399185372%2CB006UKH7KU%2C1163749982%2C1934331465%2C0692124004%2C163388600X%2C0842381740%2CB09JGJNN6K%2C1137513179%2CB000000YH4%2C0140127836%2C1556434197&srpt=ABIS_BOOK) (which Steven has read, it’s really amazing) some intern asked him, “W*ell, when you take this cataract out, are you going to replace it with a new lens?*”
  - He looked at this young intern in a British fashion, and Steven assumes he said, “T*hat’s the stupidest question I’ve ever heard.*” And then he went home and thought, “*Wait a minute, that’s brilliant. We should replace it.*“
  - Then they lathed a lens from some spectacle maker that was about the size and shape of the human lens
  - They put 8 of these in patients
  - There’s amazing footage of these early operations
    - They dropped the lens on the floor, and of course, it’s the only one they had; so they pick it up, and rinse it off
    - And it’s fine; they put it in
    - These patients did shockingly well, and this was viewed as heresy
      - There was 20 years of, “*You’re blinding people.*” But eventually, the technology won out and became standard
        - There must have been bad outcomes in the beginning
    - Like any new technology, the first iteration of it is probably terrible and maybe just a little bit less terrible than the alternative
    - Now it’s ubiquitously used

**Current technology used in cataract surgery**

- Peter didn’t realize it until Steven said it, but polymethyl methacrylate is all over the body in terms of joints
  - A replacement knee joint, the tibial plateau, he thinks it’s made out of polymethyl methacrylate
  - So presumably, there’s something about it that is just invisible to the immune system
- Steven notes that this material isn’t used anymore because it’s stiff
  - It’s not deformable
  - In the old days, they had to make a fairly large incision to get it in
  - First, the cataract was removed and then the implant lens placed in
  - 2 converging technologies made that go away:
    - 1) They were able to take the cataract out through a tiny in incision
      - They break it up; essentially they emulsify it with ultrasound
      - Now sometimes they use a [femtosecond laser](https://en.wikipedia.org/wiki/Mode-locking) to break up parts of it
      - But the bottom line is that they can remove the cataract through about a two-something millimeter incision, which is very small, like the thickness of a pencil lead
    - 2) The implant lens can be folded up and put them through that same tiny incision and then they can open up and be exactly where they need to be
- Now, why is it important for the incision to be small?
  - A big incision takes longer to heal
  - It also induces astigmatism
  - It’s best for the incision to be tiny
- Going back to the M&M analogy, Peter asks, “*Does the coating on the surface of the M&M grow back?*”
  - The answer is no; whatever hole they put there remains
  - Sometimes the coating, the M&M candy shell, can begin to opacify after surgery; this can be treated in the office with a laser where he can just disrupt that coating
- Peter remarks, “*My mom’s 72nd birthday is today. I don’t know if she’s had any issues with cataracts. But if not, she’s due for them. My dad has. He’s 83. I’m trying to think. He must have had surgery by now, right?*”
  - The odds are they have cataracts
- Peter remarks, “*this must be a game-changer for a patient*”
- Steven does cataract surgery in an [ambulatory surgery center](https://en.wikipedia.org/wiki/Outpatient_surgery#Ambulatory_surgery_centers)
  - He notes that Peter’s Dad probably didn’t talk about it because this is such a non-event
  - A patient goes in for cataract surgery, and the next day they’re back to their regular activities
- Cataract surgery can greatly improve the ability to see
  - Especially now that the implant lenses can correct the near vision and the distance vision
  - This in addition to the added clarity from just removing the cataract, patients typically have this benefit of not needing spectacles
- The number 1 risk of this surgery is infection
  - It’s extraordinarily unusual; less than 1 in 10,000 cases results in a serious infection
  - It’s like any other surgery in the body
    - He looks for bleeding, damage to the inside of the eye
    - He has to to keep tabs on the pressure
    - It’s basically everything that a doctor would look for if they were taking out an appendix, but they’re also dealing with in the eye
- Peter asks, “*What fraction of patients do not have a material improvement in their vision? Or have some deterioration of even another subset of vision?*”
- This is pretty unusual because the science behind getting the prescription correct or very close to correct is pretty advanced

## Lens implants that can correct and improve vision [1:19:30]

- Not everybody gets the same lens; lens to correct vision are expensive and the patient has to pay some extra money to get them
- Regular cataract surgery makes no attempt to get rid of spectacles
  - Regular cataract surgery is probably going to be completely covered by a person’s health insurance
- One may have to pay thousands of dollars out of pocket if they wanted to get rid of their glasses
  - Patients ask “*Well, what else do I use every waking moment of my life forever?*”
  - They could go on a vacation for a week or two and spend that money, but then the vacation is over
  - He finds that patients value their vision; they value it pretty highly
  - It’s their independence, that they’re trying to preserve
- Peter is in awe at how much he didn’t know, “*I thought cataract surgery is literally removing the sort of crud that’s in the lens… I just naively assumed the good stuff would grow back. I never knew you were putting another lens in, let alone that you could actually use the new lens as a way to correct other visual defects.*”
- The technology has evolved to the point where he can actually correct those spectacle requirements
  - Now, many of his patients don’t really care about spectacle independence
  - They just want to see well, and that’s easy to achieve
  - But as these lenses have gotten better, the capabilities of ophthalmologists have gotten better
- Peter asks, if he needed cataract surgery today, knowing his diopter (-4 and -3 with a slight astigmatism), could his vision be corrected?
  - Yes, but the problem with a lot of these eyes is they are attached quite firmly to people
  - Sometimes the patient’s expectations can be unrealistic in terms of what can be delivered
  - He has to carefully educate them on, “*Well, what can these lenses actually do? Am I going to see a perfect hunter at dusk while still being able to read up close?*”
    - And maybe the answer is yes;  maybe the answer is no
- Peter asks if the lenses can tune vision for distance or near vision
  - He doesn’t mind wearing contacts, but hates his reading glasses
  - Contacts are easy because he puts them in, in the morning and takes them out at night
  - Reading glasses are annoying because he never remembers to bring them to a restaurant, so he’s shining a phone light on the menu
    - Or he’s reading his kid a book at night and has to pause to get his glasses
- This is not an unusual request
  - They can intentionally set one’s vision for near or leave it for near
  - It’s just an optical calculation to set the point of focus where one wants it to be
- What gets measured at the clinic?
  - One of the first things that he has to do is make sure that the surface of the cornea is tuned up from a [dry eye](https://en.wikipedia.org/wiki/Dry_eye_syndrome) standpoint
    - Because dry eye patients, the surface of their corneas, it’s not optically pristine; it’s a little distorted
    - Contact lens make this a lot worse; it can throw off his measurements
      - This can throw off the calculation because it’s pretty simple [Newtonian physics](https://en.wikipedia.org/wiki/Classical_mechanics)
  - Knowing the length of the eyeball, the curvature of the front of the eye, the index of refraction of stuff inside the eyeball (how bendy the material is), and considering where the implant lens is going to reside— a calculation can correct for placing the image on the retina
    - The more perfect the shape of the cornea, the better that calculation is
      - This is probably the weak link in the set of measurement they take
    - The length of the eye from front to back can be accurately measured with lasers
    - With light, they can bounce a beam off the back of the retina and know exactly how long the eyeball is
      - It’s almost like [sonar](https://en.wikipedia.org/wiki/Sonar), but with light
    - He knows roughly where the implant lens is going to rest when he puts it in
    - If he knows some other dimensions of the eye and uses the front curvature as another piece of data, he can predict what power implant lens to put in
- Peter finds this remarkable

**Implant technology in development**

- In the mid-2000s, Steven started getting involved in product design for a type of implant lens that could actually zoom focus front to back
  - Not a bifocal or a trifocal where there are different zones of focus
  - But a lens that could actually move or change its shape
- He developed an implant that was put in humans in multiple clinical trials outside the United States and found that these could zoom focus kind of like the human lens would
- But multifocal lenses, that they’ve been talking about, the bifocals, trifocal implants, they surpassed the capability of what could be achieved with the lenses that he designed
  - Until someone comes out with a focusing implant lens that can zoom focus with the same degree of power as the bifocal and trifocal implants, it’s not going to be successful
- But if there was a lens that could change its shape or change its position and zoom focus seamlessly from near to far, that would be a game-changer

> “*But if we had a lens that could change its shape or change its position and zoom focus seamlessly from near to far, that would be a game-changer*” – Steven Dell

- Peter asks, “*You don’t take like the lens from a young person who’s passed away and ever try to implant that into*”
  - No, no; it doesn’t work the way a cornea does for instance [see more about [cornea transplantation](https://en.wikipedia.org/wiki/Corneal_transplantation)]

## Effects of eye trauma [1:26:45]

**What happens when there is trauma to the lens?**

- Steven notes, “*if you violate that capsule of the lens, the lens immediately becomes cloudy.*”
  - Here’s an example about trauma; so a typical scenario is somebody is working with a weed eater, a weed whacker, or whatever
  - And a shard of rock or glass or something goes through the cornea and embeds itself in the lens
    - This might even be an optically unimportant part of the lens; maybe it’s off to the side
  - But once that capsule has been pierced, inevitably, lens protein starts leaking out,and it’s no longer an [immune privileged site](https://en.wikipedia.org/wiki/Immune_privilege)
  - A cataract becomes visible within days
  - Now they need a new lens
  - Peter asks about the cornea
    - Sometimes they need a new cornea, but oddly enough, sometimes an object will pass through the cornea; and because it’s traveling at such a high velocity, it’s usually sterile, and it’ll go through the cornea and embed itself in the lens or the iris or wherever
    - Some of these objects can be left alone
    - But if the cornea has been damaged sufficiently that it’s no longer able to transmit a clear image, then it has to be replaced

**What happens when there is trauma to the cornea?**

- One thing Peter remembers from surgery is to always tape the patient’s eyes shut, to avoid corneal abrasions
  - One doesn’t want a patient’s eyelids flipping open in the middle of surgery when nobody’s paying attention, and the drape is running over the eye and scraping the cornea
- Is this the biggest insult for the cornea?
  - It’s one of the more common ones
  - An eye that’s been left open in surgery while a patient is asleep and not blinking, that’s the extreme version of dry eye where the cornea has completely dried out
    - Even if the cornea is not abraded, those [epithelial cells](https://en.wikipedia.org/wiki/Epithelium) would be so damaged by exposure, just by not being continuously bathed in tears that they would be severely damaged
  - So dry eye is intimately related to corneal abrasion because these patients lack the lubrication that normally takes place to prevent that type of thing

## Corneal abrasion from ‘dry eye’: causes, treatment, and prevention strategies [1:29:00]

- [Dry eye](https://en.wikipedia.org/wiki/Dry_eye_syndrome) is an enormous issue in our society
- Think about the things that cause dry eye
  - Lots of medications do it through [anticholinergic](https://en.wikipedia.org/wiki/Anticholinergic) side effects
  - Antihistamines
  - Hormonal influences are profound in terms of dry eye
  - Anything that causes dry mouth can also cause dry eye
  - [Autoimmune conditions](https://en.wikipedia.org/wiki/Autoimmune_disease) can cause dry eyes or [Sjogren’s](https://en.wikipedia.org/wiki/Sj%C3%B6gren_syndrome) [rheumatoid arthritis](https://en.wikipedia.org/wiki/Rheumatoid_arthritis)
  - All of the [connective tissue diseases](https://en.wikipedia.org/wiki/Connective_tissue_disease) have a dry eye component to them
  - Perturbations of [thyroid](https://en.wikipedia.org/wiki/Thyroid_disease) metabolism cause dry eye
  - A lot of women suffer from dry eye mostly due to a lack of [testosterone](https://en.wikipedia.org/wiki/Testosterone), that is probably most intimately linked to dry eye.
    - He sees women on [hormone replacement therapy](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) that have miserable dry eye
    - This relates to the health of the epithelial cells on the conjunctiva in the absence of testosterone, and  there may be also influences on the secretion of tears from the lacrimal gland as well
- Dry eye is extremely common

**Treatment for dry eye**

- Peter asks, “*What type of eye drops should we be using? How do we apply them?*”
- It depends on the type of dry eye
  - One thinks of tears as just saltwater, but that’s really not what it is
    - It’s really an emulsion of [lipids](https://en.wikipedia.org/wiki/Lipid) and [mucin](https://en.wikipedia.org/wiki/Mucin) and all sorts of [immune modulators](https://en.wikipedia.org/wiki/Immunotherapy#Immunomodulators) and [antibodies](https://en.wikipedia.org/wiki/Antibody) and all sorts of things in this soup
    - Some of it is just what is referred to as the aqueous component of tears, really just the saltwater
  - But the [sebaceous glands](https://en.wikipedia.org/wiki/Sebaceous_gland) that are in the eyelids are called [meibomian glands](https://en.wikipedia.org/wiki/Meibomian_gland) (where the lashes come out of the skin), the secretions of those meibomian glands can become dysfunctional
    - And that means that the tears have a hard time gliding over the surface of the cornea; and that can lead to dry eye
    - So all sorts of things that cause meibomian gland dysfunction
      - Some of that relates to diet; some people believe that a diet high in saturated fats is more likely to cause meibomian gland dysfunction
      - Certainly colder weather affects these glands, just like the sebaceous glands in the skin, they respond better to sunlight, to heat
      - In a cold environment the meibomian glands can become plugged up and bacteria can build up along the eyelid margin causing inflammation
      - And when there’s inflammation, the lacrimal gland shuts down even more

**Eye drops**

- Peter notes, “*when I think about eyedrops, I think about sort of the dropper that you try to get in your eye, and you can never get it, at least I can never get it in my eye because I end up blinking all the time. So then you try and drop it into the corner*”
- But he’s also seen the mist applicators
- What are the different ways eyedrops can be applied?
- Eye drops work pretty well for most people; most artificial tears come in the form of an eye drop
- There are some mist sprays, believe it or not, one is a [hypochlorous acid](https://en.wikipedia.org/wiki/Hypochlorous_acid) compound that is sprayed on the lids; and it sort of migrates into the eye
  - This actually is very good for reducing the bacterial counts at the lid margin, which is part of that inflammation cycle that is so critical in dry eye
- The eye drops do need to get on the eyeball
- Eye drops are just one of just a whole bunch of strategies used for treating dry eye
  - There’s a very significant benefit from supplementing with omega-3 fatty acids, especially high doses of [omega-3 fatty acids](https://en.wikipedia.org/wiki/Omega-3_fatty_acid) and certain types of [omega-6 fatty acids](https://en.wikipedia.org/wiki/Omega-6_fatty_acid) such as:
    - [GLA (gamma-linolenic acid)](https://en.wikipedia.org/wiki/Gamma-Linolenic_acid); that’s what you’d find in black current seed oil, borage oil, or evening primrose oil
  - There was a very large randomized clinical trial looking at omega-3 supplementation in pretty high doses, 3 grams of [EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) and [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid)
    - Published in *Opthalmology* in 2020, [Effects of Omega-3 Supplementation on Exploratory Outcomes in the DREAM Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6926153/)
    - And the placebo arm used olive oil, which is presumed not to have a benefit in dry eye
    - It showed no superiority of omega-3 compared to olive oil
    - However, there has been a lot of criticism of this study; it was called the [DREAM study](https://www.pennmedicine.org/departments-and-centers/ophthalmology/about-us/news/department-news/dry-eye-and-omega-3s)
      - This study was conducted by the [National Eye Institute](https://www.nei.nih.gov/)
      - Participants were able to continue to use whatever eye drops they used to help with dry eye
      - It turns out that if you bring people into the eye doctor four times a year, everybody gets better; their compliance with artificial tears gets better
  - But he has a very strong clinical impression that omega-3s in high doses do help with dry eye; primarily from an anti-inflammatory standpoint

## Sunglasses for eye protection [1:35:00]

- Peter has some friends who are so fanatical about the importance of light that they never wear sunglasses
  - He thinks light is great but likes wearing sunglasses because there’s a part of him that’s sort of afraid that too much UV light is damaging
  - What is a good balance?
- There’s a dose-related phenomenon here— too much light is bad; too little light is bad
- He tends to recommend sunglasses for his patients for a number of reasons:
  - 1) The most common site of skin cancer is the lower lid
    - There are lots of [basal cell](https://en.wikipedia.org/wiki/Basal-cell_carcinoma) and [squamous cell carcinomas](https://en.wikipedia.org/wiki/Squamous_cell_carcinoma), and sunglasses certainly reduce the incidents of that
  - 2) Consider photoaging of the lens itself; It’s not a bad thing to delay the onset of cataract
  - 3) [Retina macular degeneration](https://en.wikipedia.org/wiki/Macular_degeneration); there’s pretty clear evidence that UV exposure, particularly of the magnitude that one can get outside, is associated with an elevated risk of age-related macular degeneration
    - Peter asks if this is seen in hunter-gatherers who have otherwise amazing habits and therefore tend to be relatively privileged from optical pathology
    - The confounding variable there is that Northern European ancestry is a risk factor for macular degeneration, probably because of the lack of pigment
      - Pigment in the eye is protecting that very vulnerable vascularized component of the back of the eye
      - The darker one’s eye, the more protected they are in the same way that skin is more protected with more [melanin](https://en.wikipedia.org/wiki/Melanin)
      - So light-eyed patients have more light getting in from the front of the eye; their iris literally blocks less light hitting the lens and the retina has less pigment behind it
      - For light-eyed patients, the vascular supply to the retina is more exposed to UV light, and that’s the way it’s evolved because they’ve been in environments that don’t have as much light available
      - But if one lives near the equator or one’s ancestry is from that area, then they’re going to have more pigment from an evolutionary standpoint
- If the goal is longevity or the postponement of senescence, certainly ocular senescence, he thinks it makes sense to protect one’s eyes from UV light
- If he’s outside and is vision is better with sunglasses then he’s going to wear them; if it’s not worse with sunglasses then he’s going to wear them
  - He’s doesn’t wear them at night
- Peter relates this to sunscreen, one is still susceptible to sunburn on a cloudy, overcast day
- He asks if it’s still a good idea to wear sunglasses even when it’s cloudy
  - Yes
- This kind of came up during a recent eclipse because people were saying, “*Okay, I’ll look at the eclipse; I’ll just use sunglasses*.”
  - Well, that’s actually much, much worse because this increases the aperture of one’s pupil
  - Because everything is dim, but it’s letting through all this very damaging light

> “*No amount of sunglasses could block a straight shot looking at the sun*” – Steven Dell

**Polarized sunglasses**

- What about polarized lenses?
- A polarized lens is a lens that has a bunch of lines drawn in it, all in the same direction, so that some of the light is blocked
  - In one meridian all the light effectively is let through
  - But perpendicular to that, none of the light gets through
- Polarized lenses have some pluses and minuses
  - One of the big minuses is the difficulty in viewing a lot of the displays in cars now
    - One gets this really messed up cross polarized effect where the light coming off of the screen is polarized
    - When one looks at it through polarized glasses, with a certain tilt of the head, it gets brighter and at other orientations it can’t be seen
  - By the same token, he’s noticed that many of the car windows, he don’t know if it’s the windshield or the side windows, would produce these very weird effects when he tilts his head because of the cross polarized effect
  - Essentially this happens where there are 2 different polarized filters and it’s letting through variable amounts of light depending upon the orientation of your head and your eye, and the spectacles
- Peter has found himself more comfortable in non-polarized lenses, unless he’s on water
  - The issue there is that the light bouncing off the water, or theoretically a highway
    - A lot of it is polarized in one direction
    - That’s the rationale behind polarized lenses
    - And for seeing a fish; if one is a fly fisherman, that’s helpful
- In terms of polarization, there’s no evidence that polarization versus non-polarization in sunglasses helps
- It’s really the UV filter that is helpful in terms of protection of eye health
  - One could wear clear spectacles, as long as they had UV protection, and still achieve the benefit of sunglasses
  - It’s not the tint that protects the eyes; it’s the ultraviolet protection
  - The same is true for car windows
- Car and truck windows do let some UV light in
  - In North America, truck drivers see more UV damage to the  left side of their face than the right side of their face by far
  - And in the UK, it’s exactly the opposite

## Solutions to correct nearsightedness [1:42:00]

**Which is better, glasses or contacts?**

- When a nearsighted person comes in, they can correct this with glasses or contacts, Peter asks “*Do you nudge people one way or the other?*”
  - Peter recalls he wore glasses for the first 4 years that he needed corrective lenses
  - Then by med school he was wearing contacts
  - But by residency he went back to glasses because he couldn’t be predictable about when he was going to put them in
  - Since then he’s used contacts
- Steven notes that when residents, fellows, or whatever see the optometrist and are asked “*When did you last have your contacts out?*”
  - They’re like, “*I think it was June 30th, right before my internship started four months ago.*”
  - Residents are notoriously bad about their own health hygiene, because they’re so busy
- But to answer the question more directly, Steven doesn’t really see patients for regular eye exams; the people he sees are seeking surgery

> “*The safest thing you can do is wear spectacles for sure*” – Steven Dell

- So spectacles and glasses are synonymous; that’s the safest option
  - They’re going to work every time and there’s essentially no risk associated with them
- There’s a big debate about what the next safest thing is
  - Is it contact lens wear for 10 years, where one might be susceptible to infection, or is it laser vision correction?
  - He tends to say, “*If you’re doing fine with spectacles or contact lenses, do that.*”
  - Peter was hoping he would say, “*Get laser eye surgery*” because part of him wants to get rid of contacts once and for all
  - But after a bunch of questions, Steven’s conclusion was, “*These don’t seem to be an inconvenience for you. You’ve never once had an eye infection. You tolerate them really well. They don’t seem to bug you.*“
  - If he was to correct Peter’s distance vision with laser surgery and set both of his eyes for distance, he would lose that near vision
    - Until maybe he gets cataracts fixed; that’s a whole other story

## Laser eye surgery—photorefractive keratectomy (PRK) [1:45:45]

**The first laser eye surgery**

- Everybody listing to this has heard of [LASIK](https://en.wikipedia.org/wiki/LASIK) (laser-assisted in situ keratomileusis)
- Most people probably haven’t heard of [PRK](https://en.wikipedia.org/wiki/Photorefractive_keratectomy) (photorefractive keratectomy), which came alone first
- The approvals for PRK and LASIK were in the mid ’90s, 1995, 1996
  - The first procedure was PRK and it was done in New Orleans, and he had happened to be in training there at the time
  - This was performed by a physician called [Marguerite McDonald](https://en.wikipedia.org/wiki/Marguerite_McDonald)
    - She did the very first treatment on a human eye
  - The way this came about was an engineer at IBM realizes that [excimer lasers](https://en.wikipedia.org/wiki/Excimer_laser), used to etch microchips, could also be used to change the curvature or make cuts in human tissue
    - And because of the nature of this ultraviolet laser, there was essentially no bystander trauma to the adjacent tissue, so the tissue could be etched or cut
    - Further, because it generated no heat, there was typically no immune response generated, so these incisions would heal without scarring
  - He remembers vividly looking at the very first patients to undergo PRK in an FDA clinical trial, and was astonished that one could look at them under a microscope and not detect that surgery had been done

> “*That was really a revelation for me, where I just saw these eyes that looked like normal eyes, and the only difference was the patients could see*” – Steven Dell

- So the first eyes were treated in ’89 (as part of a clinical trial) and that led to FDA approval in ’95

**How PRK works**

- Consider the cornea again like the glass on a watch, the thing a contact lens would sit on
  - And let’s say that the person is nearsighted; their cornea is a little bit too steep to focus the light perfectly on their retina
    - Or the eyeball is a little too long; probably a little of both
  - The length of the eye cannot be changed; this was discussed as being somewhat malleable during development
  - The corneal shape doesn’t seem to change that much throughout life
  - It’s the length of the eye that changes, unless there’s a pathological condition that changes the cornea
  - The cornea is about half a millimeter thick (500 microns)
  - Since the length of the eye cannot be changed; what can be changed is the curvature of the front of the eye
    - The curvature doesn’t have to change that much; think about how thin a contact lens is
  - Only a little curvature needs to change in order to focus the light on the retina
- Take for example a person who’s [diopter](https://en.wikipedia.org/wiki/Dioptre) is -1; they have a very minimal degree of nearsightedness
  - Their cornea is less potent in bending light than the -10 person is
  - That -10 means their eye is 10 units too strong, and the power of the eye needs to be reduced
- To fix their vision with a contact lens, the contact hast to be flatter than their eyeball
  - They need a larger radius sub-curvature or a flatter eye
  - The solution is to build up the outside of the lens
- It’s even easier to explain with laser vision correction
- Consider a crude analogy, which is that the cornea is made out of wood and he has some sandpaper
- He can sand down the center of the wooden cornea and make it flatter
  - Now it’s less powerful in bending the light, and the light can be focused on the retina
- So in the -1 example, he would remove about 20 microns of tissue; that’s not a lot
  - Compare this to a human hair, it’s about 50 microns
  - So this is less than half of one human hair’s thickness
- PRK does this with an excimer laser on the very front part of the cornea
- The very front coating of the cornea is called the [epithelium](https://en.wikipedia.org/wiki/Epithelium)
  - It’s a very thin layer, about 50, 55 microns thick; it’s got a basement membrane
  - 1) He removes that layer of cells with a solution of alcohol eye drops; it just sloughs right off, and it grows back in the same configuration
    - He anesthetizes the eye first
  - 2) Then he uses a very carefully calibrated laser to change the shape of the cornea
    - The laser is effectively perpendicular to the cornea
    - The patient is laying down flat on their back
- Peter asks if the people are sedated
  - Steven gives [Valium](https://en.wikipedia.org/wiki/Diazepam) simply because it is intimidating; but the procedure only takes a minute
- Peter’s fear is that his desire to blink would be so overwhelming that he would break the little eye barrier or end up moving his head and the doctor would zap the wrong part of his eye and he would be blind
  - Steven comments, “*That’s everyone’s fear. It turns out Valium is undefeated. It’s just a question of how much.*”
- A lot of patients fear that they’ll do something to goof up the surgery and there are a number of reasons why that really can’t happen

**Details of the PRK procedure**

- Long before this patient ever laid down on this gurney to have this laser treatment done, their eye was digitally mapped using what is referred to as a [wavefront](https://en.wikipedia.org/wiki/Wavefront) sensing device
  - So think about this, a very narrow beam of light is sent in with a laser and how it bounces back from the cornea is determined
  - It bounces back in a distorted fashion
  - An ideal ray of light in, or multiple rays of light are sent in, and they bounce back in a distorted fashion
  - The amount of that distortion allows a map to be created
  - It’s much more than a topographical map
  - It’s the entire optical pathway of the eye from the retina to the back, all the way to the back and front
  - The entire distortion pathway is visualized
    - There’s more than one way to do this:
    - 1) There is a topography-based way to do this as well, which is very effective
    - 2) The one he’s describing is sort of the easiest one to think of
      - A known uniform beam of light is sent in and he looks at how it bounces back from the back of the eye
      - That reveals what are the distortions present in this eye; how much nearsightedness, farsightedness…
- Diagnostically, this is part of the workup for laser vision correction
  - They look at how a particular eyeball distorts light as it goes through the optical pathway
  - This technology was developed for telescopes that have to contend with atmospheric distortion, like the [Keck](https://en.wikipedia.org/wiki/W._M._Keck_Observatory)
    - They send up a diagnostic laser into the atmosphere and the distortion that that laser is encountering is adjusted for in real time with a deformable mirror, a very thin mirror, and that allows them to essentially correct for the distortions of the atmosphere in real time
    - And those are constantly changing
  - In the eye they have the benefit of not having to deal with real time, evolving distortion, but he can take a snapshot of what the distortions are in the eyeball
    - Part of that involves the ability to track the eye
    - They have to lock onto, and register the eye with the equipment
    - The laser can track any movement one makes far more rapidly than it is possible to move the eye
  - It doesn’t matter if the patient’s eyes are moving during this diagnostic because the laser is moving
  - He does coach them to, “*Hey, look at the flashing light*” but that’s really just to keep them in the ballpark of where the tracker can lock onto them
- The fear of the patient, “*I’m going to mess it up.*” is not a ridiculous fear; it’s universal
- Steven tells patients, “*Hey, I’m not going to let you do anything to mess this up*”
- The laser will not fire unless the patient is within its range of tracking, and the laser will move faster than the patient can move
- So PRK is changing the shape of the eye by vaporizing the tissue
  - It’s a laser that’s scanning around the cornea where it does a little treatment here and there
  - Thermally one doesn’t want to do another shot right next to the previous one, so it moves over to another area to let the tissue cool down for a few milliseconds
    - So the laser dances around
- This takes anywhere from 15 seconds to 2 minutes
  - The worse the prescription is, the longer it takes
  - So a -10 would take a minute or so
  - It depends on the laser and the overall treatment size
- This fixes the astigmatism and all the little distortions
- He measures all the little optical distortions, the [coma and trefoil](https://en.wikipedia.org/wiki/Aberrations_of_the_eye) (terms optical physicists are very familiar with), and does his best to eliminate them with laser vision correction
- For PRK this takes 2-3 minutes, plus the Valium time
  - The patient takes Valium a half an hour before; it works pretty quickly when they chew it
- Comparing PRK and LASIK— 30 days after the procedure, the results are indistinguishable
  - But the LASIK patients get there way quicker

**PRK recovery**

- With PRK the epithelium is removed so now there is a 7-8 mm diameter area of the central cornea that has no epithelium
  - It has to grow back
  - That’s like having a big corneal abrasion
- Luckily there are drops that can reduce the feeling of the foreign body sensation dramatically
- They put a contact lens over the eye; it acts like a band-aid
  - It’s really like a regular soft contact lens
- Then the epithelium begins to heal from the outside in
  - This takes about 4 days
  - But here’s the thing, if one has a cut on their arm, it would heal over but they could still be able to detect where the cut was because those cells have not fully remodeled themselves
  - After 4 days the contact lens is removed, but the vision is still not perfect yet because those cells have to reorient themselves like a bunch of orderly bricks in a brick wall
  - When the cells first cover that defect, it’s a very thin sort of disorganized layer of cells that have accomplished their mission of sealing the defect and preventing one from being susceptible to infection
    - This is their job to quickly cover the defect
  - But then the body can turn its attention to reorganizing those cells in a model
- Peter asks if they do one eye at a time
- Not with PRK or LASIK; no
- Typically they do both eyes on the same day because the level of vision is probably about 20/30 or 20/40 within a day or 2
- The patient recovers vision pretty quickly, but that last little bit takes several days
  - So they could probably drive 2-3 days later; but they wouldn’t have 20/20 vision at that point

## Laser eye surgery—LASIK [2:02:00]

**How LASIK works**

- LASIK is different from PRK because the epithelium is not shaved off; instead a flap is cut
- The new shape of the cornea is determined by how much tissue is removed when the flap comes back
- The same laser is used in LASIK and PRK
- Instead of using the laser on the surface of the eye, a step is added before that
- He creates a flap in the cornea using a different type of laser
  - He uses a [femtosecond laser](https://en.wikipedia.org/wiki/Mode-locking) to create about a 100 micron flap; so now he can work under the epithelium
  - He’s taken about 20% of the cornea up
- Think of the analogy used earlier of sanding a wooden eye; now think of the cornea as a book
  - In PRK he removes the first 10 pages of the book
  - In  LASIK he opens the book to page 100 and takes out pages 100-110; then he closes the book

> “*The beauty of LASIK is that because the tissue removal is sequestered under that flap, the body doesn’t perceive that anything has been done*” – Steven Dell

- It’s very typical for patients who have LASIK to be 20/20 the next morning
  - That’s the appeal of this procedure
- Peter asks if LASIK was developed after PRK as a way to get around the healing process of PRK
  - Yes, the way it was developed was sort of a technological race
    - Part if this was the pursuit of more rapid visual recovery
- About 80-85% of the corrective eye surgery in the US today is LASIK
  - There another procedure called [SMILE](https://en.wikipedia.org/wiki/Small_incision_lenticule_extraction) which has a very small, but perhaps growing segment of the market
  - PRK still has a significant chunk of the market

**Recovery from LASIK**

- Peter asks if the risks are different in LASIK versus PRK
  - The risk of infection with LASIK is lower because the epithelium is not taken away
  - But another step is introduced in the procedure, the flap; if the flap is not performed correctly, it can lead to problems
  - There is more dry eye following LASIK compared to PRK
    - Creating the flap temporarily severs some of the  nerves that send the signal from the front of the eye to the [lacrimal gland](https://en.wikipedia.org/wiki/Lacrimal_gland), which secretes tears
    - Those nerves typically regrow back and one reestablishes that feedback mechanism
    - Some people have data to show that dry eye is equal in patients receiving LASIK and PRK, but he thinks there is more dry eye following LASIK; it’s controversial
    - Some patients have dry eye for really long periods of time after both procedures
    - The majority of patients are back to their baseline in about 60 to 90 days

**Night vision after corrective laser eye surgery**

- Peter asks about night vision or low-light vision
- In the early days of LASIK and PRK, the weakest part of vision was night vision
- This was due to the shape of the treatment that was used; and the diameter that was treated was limited
- They couldn’t really treat the peripheral part of the cornea that comes into play when the pupils gets big
- When they are treating a central part of the cornea that is smaller than a big pupil at night, one is going to see halos from that untreated peripheral part of the cornea
- From the ’90s to now, the treatment beam patterns have changed to address that issue and to treat that peripheral cornea differently
- So now, night vision complaints are pretty unusual with laser vision correction

**Cost of laser corrective eye surgery**

- Peter asks if there is a difference in the cost of LASIK and PRK
  - Steven charges the same
  - The added step of LASIK adds some cost
  - But PRK has more postoperative care; this requires more visits
  - So he prices them the same
- The cost has stayed pretty stable over the last 20 years; it’s a couple thousand dollars per eye

**Contraindications for LASIK and/or PRK**

- Peter asks, “*What are the exclusion criteria, who is not a candidate for either one?*”
- There are conditions of the cornea where the cornea is biomechanically unstable, where the cornea actually has a tendency to bow forward in a pathological state
  - And that means that the cornea is essentially a moving target
  - So further biomechanically weakening of the cornea makes no sense, and either procedure would do that
- There are patients who have irregularities in their astigmatism that cannot be measured or corrected with any laser vision correction
- There are patients that have certain autoimmune diseases that maybe render them as poor candidates for laser vision correction
  - Based on the risk of healing or even just the overall health of the eye
- People who have other eye diseases like cataract, or maybe glaucoma, or retinal pathology are not good candidates for laser vision correction
- These operations are typically performed on healthy eyes

**When is PRK the best option?**

- Given the differences explained, Peter asks, “*why are 15% of people still opting for PRK?*”
- There are certain patients where PRK is a far better option
- He talked about how this procedure is akin to removing pages from a book
  - What if a really deep treatment is needed and the book is sort of thin to start out with?
  - Maybe it’s better to begin on page 1 than to begin page 100
- Sometimes the thickness of the cornea will dictate this
- Sometimes it might be related to someone with preexisting dry eye, and he thinks PRK may be a little better
- There used to be some restrictions in branches of the military
  - These pretty much all went away; all aviators and pilots can now have LASIK or PRK
  - In fact, the military is one of the largest providers of laser vision correction now in the United States
- Peter asks if it’s a given that someone will have 20/20 vision after laser corrective surgery
  - Yes, the way lasers are built today, this is typically the case
  - Patients will be 20/20 or better
- If the patient is taken to 20/15 and they have presbyopia to begin with, does it get any worse or is it that they notice it all the time because they never take their glasses off so to speak and see the difference?
  - If the surgery nails their prescription perfectly, their distance vision will be phenomenal and their near vision will be based on their age
  - So if they’re 50 years old, they are probably going to need some near correction, some spectacles for reading
  - If their in their early to mid 40’s, they may not need glasses for close up

## Laser eye surgery—small incision lenticule extraction (SMILE) [2:11:45]

**How SMILE works**

- [SMILE](https://en.wikipedia.org/wiki/Small_incision_lenticule_extraction) (small incision lenticule extraction) is an interesting procedure
- It’s using a single laser, a [femtosecond laser](https://en.wikipedia.org/wiki/Mode-locking)
- Consider again the book analogy, the book is opened to page 100
  - Imagine creating a little tunnel down to page 100 and then remove pages 100-110 while keeping the incision really tiny
    - This is performed through a very small keyhole procedure
- This seems to be an effective procedure

Peter asks, “*What problem is it solving? Given how effective LASIK is.*”

- This was designed to solve dry eye
- The problem it really solved, especially outside the United States, was needing only 1 laser instead of 2
  - PRK can also be done with just 1 laser but it has a prolonged recovery time
  - The idea with SMILE is to provide a LASIK-like return of vision with a single laser
- SMILE technology is evolving
- Steven hasn’t seen any data that shows that SMILE is in any way better than LASIK or even equal to LASIK; but it seems to be a very good procedure
- He doesn’t currently use the SMILE procedure; but when the next generations of it rise to the point when they are better than what he is doing he will probably adopt it

## Glaucoma: definition, causes, symptoms, and care [2:13:45]

- When the optometrist blows air at the eye, is that to detect [glaucoma](https://en.wikipedia.org/wiki/Glaucoma)?
  - That’s a way of measuring the [intraocular pressure](https://en.wikipedia.org/wiki/Intraocular_pressure) that he doesn’t use
  - It has the advantage of not requiring the patient to be touched with anything
  - This can indent the cornea with a known amount of force from an air puff and look at how it optically deforms
  - The disadvantage to the air puff, and it’s not really considered the gold standard of measuring pressure, is that if the patient blinks really quickly and squeezes, there can be a false reading with that type of [air puff tonometry](https://en.wikipedia.org/wiki/Ocular_tonometry)
  - He doesn’t typically use
- Steven uses 2 ways to measure intraocular pressure, both of which physically indent the cornea
  - After he anesthetizes the eye with a known amount of force, then he can look at the amount of force required to cause a certain amount of indentation
- Glaucoma is probably about a hundred different diseases, but they all share the final common pathway of damage to the [optic nerve](https://en.wikipedia.org/wiki/Optic_nerve) (the nerve in the back of the eyes) and the [cranial nerve](https://en.wikipedia.org/wiki/Cranial_nerves) (mentioned at the beginning), that is somehow related to pressure
  - So this is a pressure related optic neuropathy
  - Now what’s odd about glaucoma is that there are people who have totally normal pressures with relation to the population, but that pressure’s too high for them and they can develop damage to their optic nerve

**Symptoms of glaucoma**

- Peter asks about the symptoms of glaucoma
- It’s funny, this question just sort of triggered a memory
  - Steven had a patient when he was in training years ago and he was explaining to a patient about glaucoma
  - The patient had no symptoms at all
  - One wouldn’t notice glaucoma at all and yet, if it’s not diagnosed, it could be really bad
  - And the patient said, “*Well, if it has no symptoms, what do I care? What’s the point?*”
  - Steven realized what he should have said was it has no symptoms until the very end
- The peripheral vision is damaged at the end of glaucoma
- Most people will not detect a slight reduction in their peripheral vision, particularly if it’s segmental
  - There will be just a little area off to the side that they can’t see
  - This is particularly true if the other eye is covering for that area
- But as glaucoma progresses, it can affect central vision, and then it becomes symptomatic
- Luckily glaucoma has become much more treatable
  - The pharmacological management of glaucoma has gotten way better
  - And there are numerous laser procedures that can treat glaucoma, what are referred to as [minimally invasive glaucoma surgery (MIGS)](https://en.wikipedia.org/wiki/Minimally_invasive_glaucoma_surgery)

**Cause of glaucoma**

- Peter asks “*what’s the 80/20 of this? 80% of them are caused by what*”
- So 80% of them are caused by what is referred to as garden variety chronic open angle glaucoma
  - This means that the glaucoma is not a function of the anatomy of the front of the eye being too crowded, where the fluid can’t get out
  - It’s more a problem of overproduction of fluid inside the eye, and the pressure is too high inside the eye
    - This is the aqueous fluid not vitreous fluid
  - It is not know what causes this; the pathogenesis is likely multifactorial
  - It runs in families, so there is a family history component but it’s not simple heredity
  - It is not coupled with diabetes
  - There’s some relationship to hypertension, blood pressure; but it can be seen in patients who are not hypertensive at all
  - It’s very common

> “*Every eye surgeon sees glaucoma patients daily, multiple glaucoma patients daily*” – Steven Dell

- Peter notes, “*So presumably like any* [*neuropathy*](https://en.wikipedia.org/wiki/Peripheral_neuropathy)*, if you catch it early enough, it’s fully reversible, and if you catch it too late, there you damage it, or is it… Because this is a central nerve, not a peripheral nerve*”
- Yes, Steven thinks the progression can be arrested; but once damage has occurred, it can’t be undone
  - Such as optic nerve damage
- Peter asks, “*So it’s not like* [*sciatica*](https://en.wikipedia.org/wiki/Sciatica)”
- No, Steven doesn’t think so
  - Once there’s been damage, he expects that damage to remain
  - So it’s not unusual for a patient to have what is referred to as a visual field defect
    - This is a little area missing from their field of vision
    - Then his goal becomes to prevent that defect from getting any bigger; this is possible once it is identified
- Peter asks at what age this starts to become a concern, when should screening begin?
- Steven things everyone should be screened for glaucoma when they go to the eye doctor for a yearly exam
  - The appearance of the optic nerve is examined as well as the pressure, and those are probably the two most important things to look for with glaucoma
- Incidence does go up with age; so in the 50’s and beyond, it’s much more important to pay attention to glaucoma
- Peter notes, “*presumably in the developing world where people aren’t going to get eyecare or even in the United States, if people don’t choose to get eyecare or can’t afford to get eyecare, it’s a bigger risk because they’ll only present when they have symptoms*”
- That’s exactly right

## Tips for preserving eye health [2:20:00]

- Peter summarizes, “*we think about the longevity of the longevity of the eye as a pretty important thing. If you want to figure out a way to live to a hundred…*”
  - Think about how to delay the onset of atherosclerosis
  - And an aggressive strategy to mitigate cancer, Alzheimer’s disease, etc.
  - But these other things don’t get enough attention:  teeth, ears, and eyes

> “*I mean, you don’t want to get to be a hundred and have no teeth.  And you don’t want to get to be a hundred and be deaf. And you don’t want to get to be a hundred and be blind*.” – Peter Attia

- Steven notes, “*Trying to get a kid to wear sunglasses is tough*”
- Hats are important as well, that’s a very good and effective way to protect the eyes
  - But it’s not enough because a certain amount of light bounces off and hits the bottom of one’s cheek and goes right into the eye

**Supplements**

- Nutritional supplements might have some effect
- Vitamin C deficiency is associated with an elevated risk of cataract
  - But it’s been shown conclusively that vitamin C supplementation to super normal levels does not protect against cataract formation
- Other antioxidants that have been looked at (vitamins A, C, and E) basically have no effect on cataract formation
  - There is a little bit of mixed weak evidence for [lutein](https://en.wikipedia.org/wiki/Lutein) and [zeaxanthin](https://en.wikipedia.org/wiki/Zeaxanthin) as possibly being protective for cataract and macular degeneration
- In the drugstore they sell [AREDS](https://www.preservision.com/Products/Choose-Your-PreserVision/areds-formula-soft-gels/) formula for [macular degeneration](https://en.wikipedia.org/wiki/Macular_degeneration); that stands for Age-Related Eye Disease Study
- The [Age-Related Eye Disease Study](https://en.wikipedia.org/wiki/Age-Related_Eye_Disease_Study) was a [National Eye Institute initiative](https://en.wikipedia.org/wiki/National_Eye_Institute)
  - First they looked at C, E and beta-carotene with zinc and a little copper
  - They put the copper in because they were worried about copper deficiency with zinc supplementation
  - Then they got concerned about beta-carotene, so they did another study where they took beta-carotene out and put in lutin and zeaxanthine, powerful antioxidants
  - They showed this supplementation could delay or reduce the conversion of mild macular degeneration to severe disease; but it had not effect on severe disease
  - Interestingly, it had no effect on people who didn’t have macular degeneration; it didn’t prevent them from going on to get it
  - Most ophthalmologists believe there’s something there, there’s some signal embedded in that noise
- Light is also a big risk for macular degeneration
  - It’s a dose thing
  - One wants enough light to avoid becoming nearsighted but not so much that the retinas are fried and cataracts develop
- He Thinks some form of broad spectrum antioxidant protection makes sense

## Screen time and eye health [2:24:15]

Peter asks about screen use, “*So what do we know about phones specifically and computers?*”

- People ask Steven all the time about [blue-blocking glasses](https://en.wikipedia.org/wiki/Glasses#Blue-light_blocking_glasses)
- The amount of UV radiation coming off of screens is sufficiently low that there has been no evidence at all that it’s going to cause macular degeneration in the same way that one can’t get a sunburn from a screen
- The amount of blue light that one gets from going outside is many, many, many orders of magnitude greater than what one can get from screens
- Blue light can mess up one’s circadian rhythm
  - If you take someone and expose them to blue light at noon, that’s great
  - But then expose them to that at 11:00 PM when they are going to try to go to sleep, that’s messed up
- It’s almost like running a gigantic experiment with humans
  - Think about a turtle, consider a species of turtle that spends 90% of its time in the water, 10% on land
  - Now take that and flip it so it spends 10% of its time in the water
  - Now there seems to be something weird going on with these turtles; yes, they’re surviving, but they’re in a very altered environment compared to what they were evolved to deal with

> “*So giving people blue light from a screen that’s bright at 10:00 PM, 11:00 PM, and then asking them to go to sleep is a problem*” – Steven Dell

- Exposure to blue light from a screen at night is not damaging their retinas or giving them cataracts, but may be messing up their circadian rhythms
  - Although it is hard to disentangle that from the total amount of light that they’re seeing, which is also unnatural and what comes with it
  - Peter notes, “*There seems to be a difference between watching TV and checking email before bed. Maybe neither are ideal, but one seems demonstrably worse, at least for me*”
- Steven has software embedded in all of his PCs that changes the color temperatures
  - [f.lux](https://justgetflux.com/) is a software that’s free; it will take the blue light sequentially out of the monitor as the day goes on, as the evening goes on to the point that it’s like super amber, as it gets close to bedtime
    - He really thinks that’s great

## Contact lenses: good hygiene and considerations [2:27:45]

Peter asks what else people should think about to protect their eyes

- He notes, the big takeaways for him have been the importance of sunglasses, artificial tears, taking one’s contact lenses out as frequently as possible, right?
  - Don’t sleep in contact lenses and stuff like that
  - The daily ones seem best if one can afford it
  - It makes more sense than the 2-week ones that have to be washed every night
  - Steven thinks the most important thing is to just get them out of the eye
  - He doesn’t like extended-wear contact lenses
- As an eye surgeon, he tends to see a selected sample of patients who are the problems
  - The people who have sight-threatening infections from sleeping typically in contact lenses
  - Yes, he realizes there are millions of people who sleep in their contacts and don’t get infections, but the people who end up in his office have had problems; and some of them quite devastating problems
  - He’s  not a big fan of sleeping in contact lenses in general, but if one is going to sleep in them, he’d rather they be a perfect, pristine, new pair every single time
    - And get them out as quickly as you possibly can

## A bonus benefit from repairing cataracts [2:29:00]

- Peter notes, “*The other takeaway for me, is not to be so afraid of cataracts. They’re inevitable. And…  there’s a potential silver lining, which is not only the improvement of your vision, but potentially the correction of other age-related visual changes.*”
- Steven agrees, it’s interesting that once word got out in the community that this was something that could be done, he saw people coming in asking for cataract surgery a little sooner than they otherwise would
  - Because they know that this added benefit is a potential possibility
  - In the old days when intraocular lenses were not available, people would have to wear these cataract glasses
    - These super thick lenses that were very, very powerful and magnified everything
    - It didn’t really work all that well optically
    - Without implant lenses, their prescription was typically about +10
    - People with a prescription of -10 can’t see without glasses
  - So this was the context in which people would put off cataract surgery as long as possible
- Peter asks if cataract surgery is one and done; do people every need reoperations
  - It’s not unheard of; if the implant lens isn’t functioning, it can be replaced

## Questions about corrective eye surgery [2:31:30]

- The other question Peter had on laser surgery is, how stable does one’s prescription need to be?
  - There are 3 variables to think about
  - 1) The cornea
  - 2) The length of the eye
  - 3) The lens itself
  - The lens will continue to change throughout life, but typically not until one’s in their 50’s, 50’s, and 70’s, when cataract formation will start to affect the light bending power of the lens
  - The cornea should not be changing
  - So just the length of the eye needs to be fixed
    - And typically, unless someone is going back to law school or reading 30 hours a day, that is typically finished changing in the early twenties (around 23, 24)
    - Prescriptions really shouldn’t be worsening unless one is developing some cataract formation
- He often tells patients that at some point they will start to develop some cataract formation

**Risk from exposure to ionizing radiation**

- He does  see people who do [fluoroscopy](https://en.wikipedia.org/wiki/Fluoroscopy), health professionals who are exposed to [ionizing radiation](https://en.wikipedia.org/wiki/Ionizing_radiation); this increases the risk of cataract formation
  - A ship captain on a boat that’s carrying nuclear waste who smokes and is also a diabetic is going to develop cataracts a lot sooner

## How an eye exam can be a window into metabolic illness [2:33:45]

- Peter asks about [hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin), which is a pretty crude, unimpressive way to assess glycosylation
  - He doesn’t think this measure is helpful outside of extremes
  - But he thinks the eye is the most sensitive end organ to excessive glycosylated hemoglobin
  - And it’s also one of the few things one can look at directly
  - Could an angio of the eyes be done noninvasively?  Yes
    - Peter thought that was really cool, he liked knowing that he had beautiful little vasculature back there
- Peter asks if there will come a day when everybody has an angio done on their eyes every year, to look for changes?
  - He notes, “*Your hemoglobin A1C might only be 5.5, your quote unquote normal, but that might actually reflect higher turnover of RBCs and in reality, there’s a problem.*”

> “*One of the really interesting things about the eyeballs, is that it’s a transparent organ… you can just look in and see what the problem is”* – Steven Dell

- For example, there is a layer of brain tissue readily available for observation, including its capillary network
  - So he can look and see, are these capillaries damaged?
    - This is something seen in diabetics
    - Are they exudating fluid? Are they leaking fluid?
    - This is a very early sign of diabetic retinopathy
  - The lens could be imaged to determine if glucose is leaching into this lens?
    - Does it contain more glucose than one would expect a normal individual to have in their lens?
    - Might that be a screening technique for diabetic disease… probably yes
  - And what about the fact that diabetes manifests primarily as a microvascular disease in so many end organs and in the eye, one can actually directly visualize this microvascular disease occurring
    - If it’s in the eye, it’s probably in the kidney, it’s probably in the toes
- Peter notes this diagnosis is not binary; this is a spectrum
  - When the hemoglobin A1C is 6.5%, the person has type II diabetes
    - But at 6% they’re prediabetic
    - And at 5.6%, we say they’re normal

> “*A much more interesting way to go about gaining a foothold in our understanding of a person’s metabolic health is to create this as now a new standard, right?*” – Peter Attia

- Peter wants to make sure that these nearly invisible arteries and capillaries are perfect
  - And when they cease to be, it’s going to prompt investigation
    - Whether it be lipids, whether it be glucose, whether it be blood pressure
  - All of the things that can damage a microvascular system, this becomes a beautiful window in which we can look at them
- What is the cost of doing that test?
- Steven notes, it’s very inexpensive and “*I honestly believe that we would see perturbations in the glucose migration into the lens way sooner than we would see architectural changes in the retinal microvasculature*”
- The technology to measure glucose in the lens doesn’t exist commercially, although it’s being studied
- He could look at how the lens essentially reacts to light that is shined into the lens with a particular wavelength, and determine how much glucose there is in that lens, and is that abnormal compared to a normal population?
- But looking at the retinal vasculature, he can do that with [optical coherence tomography](https://en.wikipedia.org/wiki/Optical_coherence_tomography)
  - And he can image, in a noninvasive way, the capillary network
- In initial diagnosis and screening, the canary in the coal mine is actually going to be the lens distortion due to the osmotic effect of glucose
- But what happens very commonly is that a diabetic will come into us and say, “*My sugar is well controlled. My doctor told me I’m under great control.*”
- But when he looks at their retina, there’s no way they’re under great control
  - They have fluid exuding into their retina
  - There are what are referred to as [hard exudates](https://www.columbiaeye.org/education/digital-reference-of-ophthalmology/vitreous-retina/retinal-vascular-diseases/hard-exudates)
  - There are [microaneurysms](https://www.columbiaeye.org/eye-library/diabetic-eye-disease) in their capillary vasculature; these are signs that their diabetes is out of control
  - Then he’ll say, “*I’m glad that your A1C was normal; would you mind going back to your doctor and mentioning that I saw direct evidence of problems with your microvasculature?*”
    - This problem observed in the eye probably exists everywhere in the body
    - Typically the endocrinologist will accept this news
    - They’ll say, “*Okay, well for this individual, that level of A1C is not acceptable.*”
    - Typically, they’ve been very receptive because they know we can directly visualize this
- Peter feels strongly that ophthalmology should be more integrated into medicine than less
  - What ophthalmologists do in some ways operates outside of what the surgeons, and the internists, and endocrinologists do
  - Obviously here’s an example of where an ophthalmologist can see something important to systemic health
  - He thinks there should be more of an integration of this
  - People might not have appreciated that ophthalmologists  get to directly look at the brain
  - They can look directly at the central nervous system in a way that a gastroenterologist can directly look at the colon
    - That’s why colon cancer screening is so freaking effective; the doctor gets to look with the naked eye directly at a polyp as it becomes cancerous
    - And he’s so thankful for them, because of all they can save us from

> “*It is amazing that we have the ability to directly observe the brain and the vascular tree, and so that’s very, very helpful*” – Steven Dell

§

## Selected Links / Related Material

**Medication in development to restore elasticity to the lens of the eye**: [Topical lipoic acid choline ester eye drop for improvement of near visual acuity in subjects with presbyopia: a safety and preliminary efficacy trial](https://www.nature.com/articles/s41433-020-01391-z) | *Eye* (M S Korenfeld *et al*. 2021) | [25:00]

**Review of interventions to treat myopia and discussion of eye drops**: [Myopia: attempts to arrest progression](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1771373/) | *The British Journal of Ophthalmology* (S M Saw *et al.* 2002) | [30:30]

**Book about Harold Ridley, the inventor of ocular implants**: [Sir Harold Ridley and His Fight for Sight: He Changed the World So That We May Better See It](https://www.amazon.com/Sir-Harold-Ridley-Fight-Sight/dp/1556427867/ref=sr_1_1?keywords=Harold+Ridley&qid=1637684118&qsid=131-3146834-4509605&sr=8-1&sres=1556427867%2C0197604544%2C022617428X%2C0692536558%2C0399185372%2CB006UKH7KU%2C1163749982%2C1934331465%2C0692124004%2C163388600X%2C0842381740%2CB09JGJNN6K%2C1137513179%2CB000000YH4%2C0140127836%2C1556434197&srpt=ABIS_BOOK) by  David J. Apple (2006) | [1:14:00]

**Effects of Omega-3 supplementation on dry eye**: [Effects of Omega-3 Supplementation on Exploratory Outcomes in the DREAM Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6926153/) | *Opthalmology* (M Oydanich *et al*. 2020) | [1:33:45]

**The DREAM study on dry eye**: [The DREAM Study](https://www.pennmedicine.org/departments-and-centers/ophthalmology/about-us/news/department-news/dry-eye-and-omega-3s) | Emma Wells, PENN Medicine (2017) | [1:34:15]

**Pathophysiology of dry eye**: [Intense pulsed light for evaporative dry eye disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5488788/) | *Clinical Ophthalmology* (S J Dell 2017)

§

## People Mentioned

- [Harold Ridley](https://en.wikipedia.org/wiki/Harold_Ridley_(ophthalmologist)) (British ophthalmologist who invented intraocular lenses) [1:12:45]
- [Marguerite McDonald](https://en.wikipedia.org/wiki/Marguerite_McDonald) (The first person to perform PRK) [1:46:15]

§

![](https://peterattiamd.com/wp-content/uploads/2022/03/bio-pic-dell.jpeg)

##### Steven Dell, M.D.

Steven Dell is a board certified ophthalmologist in Austin and the Medical Director of [Dell Laser Consultants](https://www.dellvision.com/).  He is an internationally recognized leader in refractive eye surgery specializing in: LASIK laser eye surgery, cataract surgery and refractive lens exchange.  He is the chief Medical Editor of the medical journal [*Cataract and Refractive Surgery Today*](https://crstoday.com/)*.*  He is the Chair-emeritus and President-emeritus of [The American-European Congress of Ophthalmic Surgery](https://aecosurgery.org/).  He is a principal investigator for a variety of FDA clinical trials in the field of eye surgery.  He has invented several surgical instruments and devices, and holds over 20 US and international patents in eye surgery including the: Dell Astigmatism Marker™, Dell Fixation Ring™, Dell PlumeSafe Ophthalmic Evacuation System™,  and Dell PlumeSafe Handpiece™.  He is also the author of numerous textbook chapters and peer-reviewed journal articles. [[Dell Laser Consultants](https://www.dellvision.com/about/our-doctors)]