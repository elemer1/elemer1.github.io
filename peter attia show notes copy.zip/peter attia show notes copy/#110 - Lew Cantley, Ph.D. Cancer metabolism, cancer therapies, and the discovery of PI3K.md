# #110 – Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K

**Source:** [https://peterattiamd.com/lewcantley/](https://peterattiamd.com/lewcantley/)

---

In this episode, Lew Cantley, Professor of cancer biology and Director of the Sandra and Edward Meyer Cancer Center at Weill Cornell Medical College in NYC, walks us through his amazing discovery of phosphoinositide 3-kinase (PI3K) and the implications for the care of patients with cancer. He explains various combinations of therapies being tested and used, including the possibility of pairing prescriptive nutritional therapies to increase the efficacy of drugs like PI3K inhibitors. Lew also explains the metabolic nature of cancer through the lens of his research into the connection between sugar consumption, insulin resistance, and tumor growth. Additionally, Lew provides some details about his exciting new clinical trial that is just now enrolling patients with stage 4 breast cancer and endometrial cancer.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lewcantley/the_Drive_public.png)

Play

#110 - Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K

#110 - Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K

1x15s30s

0:002:11:22

## We discuss:

- Teaching science through the lens of discovery—a better approach to learning science [5:15];
- The metabolic nature of cancer, mitochondria, and a more nuanced explanation of the Warburg Effect [8:30];
- The observation that convinced Lew to stop eating sugar [20:15];
- The connection between obesity, insulin resistance, and cancer [25:30];
- Sugar consumption and tumor growth—What did Lew’s 2019 paper find? [32:00];
- Natural sugar vs. HFCS, fruit vs. fruit juice, insulin response and cancer growth [43:00];
- Increasing efficacy of PI3K inhibitors with ketogenic diets, SGLT2 inhibitors, and metformin [53:30];
- Lew’s clinical trial enrolling stage 4 breast cancer and endometrial cancer patients [1:07:30];
- Pairing diet with drug could be the future of cancer treatment [1:09:30];
- PI3K inhibitors on the market, alpha vs. delta isoform, and the possibility of pairing them with a food prescription [1:16:15];
- What questions will Lew be focused on in the next chapter of his career? [1:22:15];
- Lew’s early work that ultimately led to the discovery of PI3K [1:27:30];
- Studying the mechanism by which mitochondria make ATP [1:30:45];
- How understanding the mechanism by which insulin drove glucose uptake into a cell got Lew closer to finding PI3K [1:38:15];
- How Lew knew PI3K was important in driving growth of cancer cells [1:55:00];
- Lew’s unlikely observation of phosphorylation at the 3′ position of the inositol ring resulting in the formation of phosphatidylinositol-3-phosphate [1:59:00]; and
- More.

§

## Show Notes

## Teaching science through the lens of discovery—a better approach to learning science [5:15]

- Peter proposes the idea that science should be taught at a young age through the lens of discovery
- Currently, biology and other sciences are taught through rote memorization unfortunately
- If we’re trying to screen for people who are interested in science…what you have to be screening for is:
  - the process
  - the discovery
  - the game
  - the thinking that went into the experiment

> “Serendipity in science is absolutely critical that when you get a result that’s unexpected, you should be laser focused on understanding at the biochemistry, at the chemical level, why you got the different results then you expected to get.”

- Science is about one big mystery needing to be solved
- It’s about curiosity
- Peter points out that Lew’s career has been less about innate brilliance and more about his desire to follow an observation that had unexpected results

> “If I get a result that suddenly doesn’t make sense, to me that’s more exciting. It means there’s something more complicated going on than the simplest explanation for what I’m seeing. . . if you’ve broken up a whole new field because your simple explanation doesn’t work and you figured out why it didn’t work and what was wrong, then that’s where most breakthroughs come from.”

## The metabolic nature of cancer, mitochondria, and a more nuanced explanation of the Warburg Effect [8:30]

Around 2005…

- [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) (who trained under [Craig Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson)) and [Heather Christofk](https://www.biolchem.ucla.edu/people/faculty/heather-christofk) began working under Lew
- Matt was obsessed with understanding glucose metabolism
- In parallel, Heather made an unexpected observation… “*In that one experiment, she rediscovered everything that had been published, of all the things that bind to tyrosine phosphorylated proteins but she’s discovered the thing that bound better than anything else in the cell, or that was most massively pulled down, was an enzyme of metabolism, pyruvate kinase. And that was shocking.*“

Matt and Heather published back to back papers in Nature ([1](https://www.nature.com/articles/nature06734) and [2](https://www.nature.com/articles/nature06667)) that explained:

- 1) how phosphotyrosine proteins binding to pyruvate kinase could turn off its activity
- 2) why turning off the activity of pyruvate kinase was important to increase anabolic growth

⇒ Lew says that was the basis for which he and Craig Thompson started [Agios](https://www.agios.com/) – a pharmaceutical company focused on developing small-molecule anti-cancer therapeutics targeting cancer cell metabolism via the growth factor pathway

**Lew’s 2009 review that provided a more complex explanation for the Warburg Effect**: [Understanding the Warburg Effect: The Metabolic Requirements of Cell Proliferation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) (Vander Heiden, et al., 2009)

*When did Lew start paying attention to the Warburg Effect?*

- Otto Warburg made the observation that even in the presence of sufficient cellular oxygen to generate ATP much more efficiently through the mitochondria, it was as though the cancer cell elected to go this faster, less efficient route
- The question was… *Why doesn’t it make ATP through mitochondrial oxidative phosphorylation instead of through glycolysis?*

In the 60s and 70s, ideas that cancer was just due to an altered metabolism fell out of favor…

- [Evidence](https://www.nobelprize.org/prizes/medicine/1989/press-release/) for virally induced cancers came to light
- And the discovery of [oncogenes](https://en.wikipedia.org/wiki/Oncogene) ([c-SRC](https://en.wikipedia.org/wiki/Proto-oncogene_tyrosine-protein_kinase_Src) being the first discovered)
- So the focus shifted to gene mutations causing cancer

However…

- People like [Efraim Racker](https://en.wikipedia.org/wiki/Efraim_Racker) continued to realize that you have to alter metabolism to do cancer.
- In order to divide and make a bigger cluster of cells, you have to drive glucose and amino acid uptake and anabolic processes converting those to proteins and lipids and DNA and RNA.
- So there was no doubt you had to turn up metabolism.

**⇒ The question really was**: *At what level did metabolism play the role? Was it just a consequence of the viral transformation or the oncogenic transformation or did they work cooperatively in some more complicated way?*

- Lew and team’s [paper](https://www.nature.com/articles/nature06667) on pyruvate kinase suggested “yes”… there is some clear cooperation where the act of tyrosine phosphorylating proteins was directly regulating the activity of metabolic enzyme rather than just turning up the expression, for example, through a transcriptional cascade

> “The truth is chemotherapy is really targeting metabolism. You’re blocking DNA synthesis or other steps in metabolism as a way of killing cancer cells. So that is, in a way, targeted metabolism.”

**What was the point that you guys made that was so novel in that** [**2009 paper**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/)**?**

- In the paper, Lew and team came up with a very clear explanation for why the Warburg Effect might exist that differs from the simplest explanation
- **The easy explanation**: mitochondria don’t work, therefore the cancer cell has no choice but to undergo anaerobic glycolysis
- **Lew’s more complicated explanation**: Even with totally functional mitochondria, you could divert intermediates in glycolysis into anabolic processes by regulating steps in glycolysis
- In other words, it could divert intermediates in glycolysis from making ATP to instead make carbon atoms of glycolysis that go into lipid synthesis, ribose synthesis, serine synthesis, glycine synthesis

⇒ **Analogy**: You have a flowing river and you want to flood some fields to grow crops so you build a dam and some canals upstream of the dam to push water into the fields.

- “*That’s sort of what happens if you turn off pyruvate kinase. Then you slow down ATP production. That means there’s less ATP made. That means glycolysis, the upper part of glycolysis continue, but instead of going to make more ATP, it goes off to make serine and glycine and ribose and lipids, and that gives you all the molecules you need to grow*.”

## The observation that convinced Lew to stop eating sugar [20:15]

- Lew grew up in the backwoods of West Virginia in the 1950s
- They were eating “incredibly healthy” meals at the time
- They lived off their own farming of animals and vegetables
- They had very little income
- Sugar was extremely expensive at the time and so they almost never had it
- Then Lew went off to Cornell for his graduate degree
- In the 1960s, a Japanese scientist invented [high-fructose corn syrup](https://en.wikipedia.org/wiki/High-fructose_corn_syrup), which was much easier to make than cane sugar and cost much less
- When Lew came back to West Virginia, noticed a dramatic change in that all my friends and relatives were suddenly becoming obese
- He saw that they had started consuming massive quantities of sugar and HFCS in the form of sodas and desserts
- He also noticed that they were “addicted” to sweets
- Lew made the decision in 1975 to stop drinking soda and to stop eating dessert

> “I didn’t know anything about the metabolism of fructose or glucose. Just empirically I saw the change in diet and the consequent massive change in obesity.”

## The connection between obesity, insulin resistance, and cancer [25:30]

**Insulin and cancer**

- Lew saw that this PI-kinase activity was co-precipitating with SRC and insulin receptor…
- He realized that the same enzyme was mediating the effects of the oncogenes and also the effect of normal insulin signaling
- “*By 1990 it was very clear in my mind that insulin was triggering cell growth in exactly the same way that oncogenes were. They were both activating PI 3-kinase.*”
- Next, Lew realized that insulin resistance, which creates the need for more insulin, could be helping cancer grow
- Since the 1970s, Lew began to realize that if you add insulin to cancer cells in culture, it makes them grow better
- Cancer cells tend to have more insulin receptors than the tissue from which they emerged
- In the process of tumors growing, evolving, they turn up the expression of the insulin receptor and that allows them to respond to insulin better
- Lew was convinced that **being insulin resistant would accelerate tumor growth**

> “I became convinced that the state of being insulin resistant in humans sets them up to accelerate tumor growth.”

**Obesity, hyperinsulinemia, and cancer**

- In Peter’s [podcast interview with Sid Mukherjee](https://peterattiamd.com/sidmukherjee/), they discuss how **obesity is the second leading predictor of cancer** after smoking
- This was also discussed in the PBS documentary titled [Cancer: The Emperor of All Maladies](https://www.pbs.org/show/story-cancer-emperor-all-maladies/) (Lew made an appearance in this)

![](https://peterattiamd.com/wp-content/uploads/2019/07/obesity-and-cancer-768x930.gif)

**Figure 1. Cancers associated with overweight and obesity.** Image credit: National Cancer Institute

*-But is it the* ***obesity*** *or is it the* ***hyperinsulinemia*** *which often accompanies obesity?*

- Peter and Lew believe it’s **less the obesity** and **more the** [**hyperinsulinemia**](https://en.wikipedia.org/wiki/Hyperinsulinemia) that accompanies obesity in 80% of cases
- If fact, being lean and hyperinsulinemic is worse than being obese without hyperinsulinemia

**⇒ Paper suggesting insulin sensitivity is more relevant than body mass in breast cancer risk:** [Breast Cancer Risk in Metabolically Healthy but Overweight Postmenopausal Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4657855/)

- The subset of overweight women who were insulin sensitive did not have an increased risk of breast cancer, but the ones that were insulin resistant did
- Lean women who got breast cancer were commonly insulin resistant lean women
- Furthermore, visceral fat is a result of insulin resistance even without obesity

**Current methods of using BMI as our correlation with cancer are not good enough**

- Things like visceral fat and hyperinsulinemia are better

⇒ [2013 paper](https://science.sciencemag.org/content/341/6148/856.full.pdf+html) by [Mitchell Lazar](https://en.wikipedia.org/wiki/Mitchell_Lazar)

![](https://peterattiamd.com/wp-content/uploads/2020/05/mitch-lazar-2013-paper-two-faces-of-obesity-and-mortality-1024x828.png)

**Figure 2. Two faces of obesity and mortality?** **Obesity, defined by a high BMI, substantially increases the risk of developing diabetes, cardiovascular diseases, cancer, and other chronic diseases, leading to higher mortality. However, it has been estimated that about 10% of adults in the United States have obese BMI and are metabolically healthy, compared with 8% who have a normal BMI and are metabolically unhealthy. In contrast, 26% of adults have normal BMI and are healthy, whereas 21% have obese BMI and are unhealthy.** Image credit: (Ahima and Lazar, 2013)

## Sugar consumption and tumor growth—What did Lew’s 2019 paper find? [32:00]

**Lew’s 2019 paper showing that HFCS increased tumor growth in mice**: [High-fructose corn syrup enhances intestinal tumor growth in mice](https://science.sciencemag.org/content/363/6433/1345)

- **The experiment design**: To see if there was a higher risk for *colorectal cancer* with high sugar consumption (in mice)
- **Lew’s hypothesis**: High sugar consumption would eventually lead to **insulin resistance** (therefore high insulin) which may accelerate the growth of colorectal cancer
  - And indeed this turned out to be true

> “I always challenge people in my lab to prove me wrong rather than prove me right, and because it’s always learn more if the simplest idea is wrong.”

**-Next…** they wanted to see if **sugar itself was directly feeding tumors** (and not needing insulin)

- The fed the rats a high sugar diet but controlled for calories in order to NOT make them obese
- They were consuming the equivalent of a 12 ounce cola sugary drink
- Over 6 months, the mice did not gain wait or become insulin resistant
- Yet, they still had **increased polyp size by two to three fold** in the colon

*-But was it the* ***glucose or the fructose*** *causing tumor growth?*

- Turns out it needed to be a COMBINATION of both glucose and fructose (aka sucrose and/or HFCS)
- Neither glucose alone nor fructose alone could cause tumor growth

*-Solid food vs. liquid sugar*

- Lew also found that liquid sugar was way more potent than solid food with the same amount of sugar
- The liquid nature of the sugar allowed the sugar to travel more quickly and the fructose (and some glucose) made it all the way to the colon to feed the tumors

**–***Other relevant finding*:

- Rats who were fed sugar water ad libitum actually were “protected” from insulin resistance because the polyps were eating so much of the sugar

**Why glucose PLUS fructose is the killer:**

–*The real surprise was when we got to the molecular mechanism…*

- You had to have fructose and glucose because the actual carbon atoms that were being used to grow the tumor were coming from the glucose and NOT from the fructose.
- What the fructose was doing… when it went into the polyp, it was converted to [fructose-1-phosphate](https://en.wikipedia.org/wiki/Fructose_1-phosphate) by an enzyme called [ketohexokinase](https://en.wikipedia.org/wiki/Hepatic_fructokinase) (aka fructokinase)
- The fructokinase enzyme is only found in three tissues in any significant concentration
  - the liver
  - the kidney, and
  - the gut.
- And so these polyps have that fructokinase enzyme

–*What happens is the fructose goes in…*

- it gets phosphorylated by that enzyme very rapidly
- And that drops the ATP level in the cell because you’re consuming ATP to phosphorylate that fructose that is coming in.
- Now, I mentioned earlier that the thing with the Warburg hypothesis is that in order to get glucose to flux at a high rate into a cell, you have to drop the ATP level.
- Well, this is a way to drop the ATP level.
- Instead of consuming it in some other way, you’re consuming it by phosphorylating the fructose.

–*There’s an additional intervention that is also important…*

- which is once you start doing glycolysis at a higher rate, the process of doing glycolysis incorporates an inorganic phosphate to make the doubly phosphorylated glycerol and bisphosphonate.
- And so that additional consumption of inorganic phosphate drops a negative regulator of inosine deaminase, and that drops the ability to keep ATP synthesis going on in the cell.
- So the combination two drops the ATP level dramatically
  - and now the glucose that’s coming in is flooding through glycolysis, but it’s going into all these anabolic processes.
  - It’s being used to make lipids, fatty acid synthesis, serine synthesis, nucleotide synthesis… all going up by 5x-10x

–*But if you leave the fructose out…*

- Even though the glucose gets into the cell, it can’t go through glycolysis at a high rate and so you don’t get growth
- You must have both molecules:
  - The carbon atoms are coming from the glucose, and
  - The fructose is basically driving the kinetics

## Natural sugar vs. HFCS, fruit vs. fruit juice, insulin response and cancer growth [43:00]

**If sugar is found in nature, how can it be so harmful? Is HFCS even worse?**

- Our metabolism really hasn’t changed in the last 100,000 years
- 100,000 years ago, we’d only have high access to sugar seasonally while in a temperate climate
- Maybe a month or so
- Very small berries, very small apples, for example
- If you could eat enough of those, you could put on weight that might be critical for you to survive the harsh winter

> “Almost anyone 50,000 years ago who didn’t put on 50 pounds or so in the fall would not be alive for the next spring.”

==> Peter had [Rick Johnson on the podcast](https://peterattiamd.com/rickjohnson/)

*==> Rick Johnson article*: [Ancient Mutation in Apes May Explain Human Obesity and Diabetes](https://www.scientificamerican.com/article/ancient-mutation-in-apes-may-explain-human-obesity-and-diabetes/)

- He described how homo sapiens evolved from a certain line of primates who developed a mutation in both uricase and fructokinase which allowed them to put on fat from sugar in order to survive the winter
- And we as a humans species have these mutations that would have served us well when glucose and fructose combined were provided just at the right level

**Sugary beverages**

- Sugary drinks like soda and fruit juices are still very high
- Yet, the data are becoming almost impossible to ignore that there is something unique toxic (chronically) when it comes to sugar-sweetened beverages

*-Anything that can be done policy-wise to reduce consumption?*

- There’s a lesson to be learned there from the cigarette situation
- Reducing advertisement is one way to do it.
- TV commercials today are skewed towards sugary food and many of them tailor to young children to get them addicted as young children, you’ve got them for life.
- Just like cigarette smokers, you get them addicted at 15, they’re addicted for life, then there’s a sustained market for you.
- So getting those ads off could be a good approach, says Rick
- Taxing also helps, says Rick
- Like it was in the ’50s, if sugar is the most expensive thing that you can buy at the grocery store, then maybe you would quit buying it.

**Any distinction between sucrose versus high fructose corn syrup?**

- “No”
- There was little difference in the effects of sucrose (aka sugar from cane sugar plants) compared to  HFCS
- There’s isn’t much evidence that “natural sugar” is any better than high fructose corn syrup

**Fruit vs. fruit juice**

- With apple juice, you’re going to get a glucose spike for sure
- Eating a whole apple, you may get hardly any change in your glucose because it takes so long to break it down that the absorbance is slower
- For Peter, nothing spikes his blood sugar more than a raisin on a per mass basis it doesn’t have the water, it doesn’t have the fiber, doesn’t have anything else.
- Glucose AUC
- Compare apple to apple juice, if you did equal grams of glucose, you might even get a similar area under the curve.
- However… with apple juice you will have a **big spike** but with the apple you’ll get a **gradual rise**
  - So glucose AUC could be the same, but the **insulin response** could be quite different

> “In my opinion, it’s all about insulin. Most endocrinologists worry about the glucose. I worry about the insulin.”

## Increasing efficacy of PI3K inhibitors with ketogenic diets, SGLT2 inhibitors, and metformin [53:30]

**Drugs that block PI3K**

- By 1990, Lew was sure that insulin went through PI3K and that many cancer have emerged because of activation of PI3K
- So some pharma companies approached him about making a PI3K inhibitor
- But at that time, Lew was not sure how you could possibly do that without causing severe diabetes
- “*I never pulled the trigger in starting a company or even encouraging anyone else to start a company to make inhibitors of PI 3-kinase*” says Lew
- Ultimately, pharma companies pursued this anyway
- Lew agreed to assist [Novartis](https://en.wikipedia.org/wiki/Novartis) in their attempt to develop a PI3K inhibitor
- “T*he question then is can you thread that needle? Can you manage the glucose level without getting insulin levels so high that they would reactivate PI 3-kinase in the tumor? And that had been the challenge*.”
- Lew strongly believed that a PI3K inhibitor could not be deemed effective if the patient needed to be given insulin
- The Novartis drug called [Piqray (alpelisib) was finally approved in May 2019](https://www.novartis.com/news/media-releases/fda-approves-novartis-piqray-first-and-only-treatment-specifically-patients-pik3ca-mutation-hrher2-advanced-breast-cancer)
- “*It took a long time because roughly half the patients who tried to enroll could not be managed on metformin (without insulin).*”

**Comparing metformin, SGLT2 inhibitors, and ketogenic diets and their ability to enhance efficacy of PI3K inhibitors**

⇒ ***Lew’s 2019 paper*** *evaluating metformin, SGLT2 inhibitors, and ketogenic diets and their ability to enhance efficacy of PI3K inhibitors***:** [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6197057/)

- The question being asked: **Which one best assisted PI3K inhibitors in shrinking the tumor?**
- **First…** *Why does the PI3K inhibitor need help?* …
  - B/c you can’t develop a complete inhibitor for physiologic reasons
  - And a massive amount of insulin is enough to reactivate PI3K in the liver and muscle even in the presence of the drug.
- “*What we’re trying to stop is insulin, because insulin is what’s driving the activation. Those mutations in PI 3-kinase will not activate PI 3-kinase unless insulin is added to the tumor.*”

–**Results of the study**: *What was the efficacy of a ketogenic diet versus an SGLT2 inhibitor and metformin? Were they equal?*

- Ketogenic diet was the most effective if the patient could actually stay on it
- SGLT2 inhibitors tend to be easier for people so that would be second best

**Keto diet plus PI3K inhibitor is best**

- Lew says that the keto diet alone doesn’t seem to have nearly the same effect as compared to when you combine it with PI3K inhibitors
- That said, there is a clinical assay that can measure the volume of insulin receptors on a tumor that can tell you whether the keto diet is a favorable approach

**Insulin is enough to grow a tumor even with PI3K inhibitor**

- A PI3K inhibitor suppresses PI3K but not 100% because you can’t develop a complete inhibitor for physiologic reasons
- In other words, it’s like a porous dam
- And in the presence of high enough insulin, PI3K will still be activated even in the presence of the PI3K inhibitor

> “Insulin is what’s driving the activation. Those mutations in PI 3-kinase will not activate PI 3-kinase unless insulin is added to the tumor.”

*Peter tells a story of a friend who survived metastatic breast cancer…*

- A friend of Peter’s was in a breast cancer trial
- She ended up being the only woman with metastatic breast cancer that survived
- She, on her own accord, went on a ketogenic diet during the trial
- This anecdote was part of the reason Lew and Sid did this [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6197057/)

## Lew’s clinical trial enrolling stage 4 breast cancer and endometrial cancer patients [1:07:30]

**Lew’s clinical trial**

- **About**: He is enrolling people in a phase 1 trial for a new PI3K alpha inhibitor (serabelisib) combined with a SGLT2 inhibitor (canagliflozin)
- **Lew’s company that is doing the study**: [Petra pharmaceuticals](https://petrapharmacorp.com/)
- **Link to the study**: [Study information on clincialtrials.gov](https://clinicaltrials.gov/ct2/show/NCT04073680?term=petra%2C+PIK3%2C+SGLT2&cond=cancer&draw=2&rank=1)
- **Participants needed**: People with solid tumors of breast cancer or endometrial cancer (stage 4)

*\*Note about diet for the participants*:

- People in the trial will need to eat breakfast before they take their pills in the morning to reduce the possible toxicity of the medication
- But it matters greatly WHAT they have for breakfast
- It needs to be low carb/low sugar
  - E.g., eggs, avocado, whole milk yogurt,
  - Absolutely NO juice and no [Ensure](https://ensure.com/nutrition-products/ensure-original) (like they give to cancer patients in hospitals to help with to not lose too much weight)

## Pairing diet with drug could be the future of cancer treatment [1:09:30]

**Lew’s meal company**: Faeth Pharmaceuticals (not yet making meals, just now getting the company started)

- **About the company**: Making meals for dietary intervention in cancer patients
- The plan will be preparing the meals to make sure they have exactly the right composition as opposed to just giving advice and hoping people find the right foods
- Note, it’s not purely ketogenic
- It will also be focused on *reducing certain amino acids* in order to make some drugs more effective
  - [Serine](https://www.pnas.org/content/113/7/1778)
  - [Methionine](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6951023/)
  - Glycine
  - “*trying to selectively deprive a cancer cell from nucleotide precursor*”

**It’s really the COMBO of diet and drug that makes the difference**

- Neither a keto diet or a PI3K inhibitor will do anything to tumors on their own
- But when given together, the tumors completely disappear
- You have to combine the diet with the right drug or it doesn’t really work

> “This diet-drug pairing is really on the cusp of innovation right now. We’re scratching the surface of that.” —Peter Attia

## PI3K inhibitors on the market, alpha vs. delta isoform, and the possibility of pairing them with a food prescription [1:16:15]

**Current PI3K inhibitors**

**–**[Alpelisib](https://en.wikipedia.org/wiki/Alpelisib) (brand name Piqray)

- Novartis drug brand name Piqray
- Hits specifically only the **alpha isoform**. . .that’s the isoform that insulin activates, immediates everything insulin does, and that’s the one that’s caused all the problems with hyperglycemia

–[Idelalisib](https://en.wikipedia.org/wiki/Idelalisib) (brand name Zydelig)

- made by Gilead Sciences
- Treats blood cancers
- It blocks the delta isoform of the enzyme phosphoinositide 3-kinase
- The delta is seldom mutated…but it’s actually required for [B cell](https://en.wikipedia.org/wiki/B_cell) growth
- The first possible place to work was for B cell lymphomas since that enzyme was already known to be critical in B cells and that turned out to be effective

–[Copanlisib](https://en.wikipedia.org/wiki/Copanlisib) (trade name Aliqopa)

- Made by Bayer
- It hits delta and alpha
- For the treatment of adult patients experiencing relapsed follicular lymphoma who have received at least two prior systemic therapies [wikipedia.org]

**More about the alpha isoform**

- Alpha is where you see the most mutations
- Breast cancer, for example, is far more common than [lymphoma](https://en.wikipedia.org/wiki/Lymphoma)
- Alpha is the only one that causes hyperglycemia… which means it will require the most management of the hyperglycemia and the hyperinsulinemia
- I*s that message reaching the oncologists*?
  - “Slowly”, says Lew, “they’re beginning to understand why it’s important to keep the insulin down.”
  - Peter and Lew say this lack of understanding is due to the super specialization of doctors
  - Peter strongly believes we need a subspecialty of oncology called **metabolic oncology**

**What is the dosing schedule of these drugs?**

- It’s based on the drug level goes into the bloodstream and how long it stays high, and following how quickly it declines
- In Lew’s trial, the alpelisib is given daily, in the morning, with breakfast
- Without breakfast, you can have absorption problems and you get more side effects like diarrhea or nausea

**Possibility of a food prescription?**

- The problem is that there’s no formal recommendation as to what you’re supposed to eat for breakfast before you take the drug
- Hence the importance of a company like **Faeth** that could start to standardize the food

*Wouldn’t it be great if as a doctor you could write a prescription that’s not just covering the drug but covering the food?*

- “Yeah, that’s what we’re anticipating at Faeth.” says Lew
- The hold up is that you need to prove in a phase three clinical trial that you need this particular food in order to maximize absorption, minimize side effects, and most importantly **maximize efficacy**
- You should be able to get that food paid for the delivery of the exact food that matches what your needs

## What questions will Lew be focused on in the next chapter of his career? [1:22:15]

> “My real motivation, of course, is to convert every observation we make in the laboratory to actually change in practice for whether it’s diabetes, or cancer, or what other disease, that we begin to understand the molecular mechanism. If we don’t convert those observations into actual change in behavior or change in practice or change in drug metabolism and diet, then in the end we failed.”

## Lew’s early work that ultimately led to the discovery of PI3K [1:27:30]

Peter Attia:

There are a lot of things I want to talk about today, but I do want to start with the discovery that you led that probably most people would associate with you if they go to your Wikipedia page, that’s probably the first thing they’re going to see. Although I haven’t been to your Wikipedia page in awhile, so I don’t recall. But let’s talk about PI 3-kinase. How do we define it by the way, tell people what it is.

Lew Cantley:

PI 3-kinase stands for [phosphoinositide 3-kinase](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase), and the 3 means that it phosphorylates the 3 position on the [inositol](https://en.wikipedia.org/wiki/Inositol) ring, which is the head group of this lipid.

Lew Cantley:

And in the mid, early mid 1980s, phosphatidylinositol phosphorylation, which was known to occur from 1949, the purpose of it was totally ambiguous. Why did this lipid get phosphorylated? And in early 1982, 83 there was a breakthrough with the discovery that the phosphorylated form phosphatidylinositol with phosphate at the 4 and the 5 positions of the inositol ring… by the way, inositol is hexahydroxy-cyclohexane, so there’s six hydroxys. One of them connects to the glycerol backbone and then the others are potentially available to be phosphorylated. Anyway, the 4 position and the 4 plus 5 position were both identified the year I was born, 1949, and the purpose of that was not known. It was called the [futile cycle](https://en.wikipedia.org/wiki/Futile_cycle) maybe a way of just getting rid of-

Peter Attia:

Getting rid of phosphates or something.

Lew Cantley:

Or getting rid of ATP.

Peter Attia:

Yeah.

Lew Cantley:

You just phosphorylate it and de-phosphorylate it and-

Peter Attia:

Sort of like an ATP sync.

Lew Cantley:

And then the idea, the observation that this phosphorylation could be stimulated by various [GPCR](https://en.wikipedia.org/wiki/G_protein-coupled_receptor) pathways and growth factor pathways, got people thinking about what it might be doing and it tended to correlate with calcium elevation. And so the breakthrough paper showed that in fact when cells are stimulated with certain growth factors like [EGF](https://en.wikipedia.org/wiki/Epidermal_growth_factor_receptor) or a certain subset of GPCR activators.

Peter Attia:

And those stand for?

Lew Cantley:

G protein coupled receptors.

Peter Attia:

And EGF just for folks.

Lew Cantley:

Epidermal growth factor.

Peter Attia:

All growth.

Lew Cantley:

And these signaling pathways would activate the hydrolysis of that lipid that the [inositol 1,4,5-trisphosphate](https://en.wikipedia.org/wiki/Inositol_trisphosphate) that comes off when you hydrolyze it away from the lipid. It turned out to regulate calcium release from cells, and that was a huge breakthrough because no one knew how calcium got elevated and that explained it. And so I, in the meantime, it was not working on that particular pathway.

**Breakthrough discovery in the early 1980s showing that when cells are stimulated with certain growth factors like EGF or GPCR would regulate calcium release from cells**: [Inositol trisphosphate: Discovery](https://en.wikipedia.org/wiki/Inositol_trisphosphate#Discovery) | (wikipedia.org) [1:28:45]

## Studying the mechanism by which mitochondria make ATP [1:30:45]

Peter Attia:

And let’s pause for a moment and remind everybody. You trained, you were interested in science from a young age. But you were sort of deciding I think a little bit if I recall between chemistry and biology. You were very interested in both. Correct?

Lew Cantley:

I was a pure chemist. The last biology course I took was in 1964 when I was a sophomore in high school.

Peter Attia:

You very quickly declared chemistry your obsession.

Lew Cantley:

I hated biology because at that time, at least in the backwoods of West Virginia where I was growing up, biology was just a bunch of descriptive memorization. And I was bored with that and decided I would never take another biology course and I stuck to that. I was pure chemistry, mainly organic chemistry, and then I switched into physical chemistry. But was totally uninterested in biology at all until I took one semester of biochemistry and realized maybe there’s something interesting going on in biology. I went to Cornell in Ithaca to get my PhD and there I focused on biophysical chemistry. It was a chance to apply chemistry to questions like “how do you get molecules across membranes?”

Lew Cantley:

And that’s what I worked on. How do you synthesize ATP in the mitochondria or chloroplasts? That kind of the slippery slope of going into biological questions that could be addressed by simple chemical questions or physics questions.

Peter Attia:

Now, what got you interested in the mitochondria so early?

Lew Cantley:

I read a paper when I was an undergraduate that was an idea that Peter Mitchell had proposed, that the way you make ATP in the mitochondria and or chloroplasts was using a proton gradient. And his idea was that that gradient would allow you to pull the protons in one direction, the hydroxyl ions in the direction, and remove water from phosphate plus ADP and condense that into ATP. That was just a very simple physical property that if you could move those two ions in different directions, it would produce ATP. In effect, the idea was not correct. It was correct that ATP was made from the proton gradient, but the actual mechanism turned out to be different. They’re actually three Nobel prizes given for how ATP is synthesized in the mitochondria.

Peter Attia:

I wasn’t aware that there were three separate Nobel prizes. Do you recall who won all of them?

Lew Cantley:

Mitchell.

Peter Attia:

Mitchell obviously. Yeah.

Lew Cantley:

[Peter Mitchell](https://en.wikipedia.org/wiki/Peter_D._Mitchell) got one. Then there was a second one by [Paul Boyer](https://en.wikipedia.org/wiki/Paul_D._Boyer). When he figuring out the actual mechanism by which this occurs and then a third one from Peter Walker [CORRECTION: Lew meant to say [John Walker](https://en.wikipedia.org/wiki/John_E._Walker)] who figured out the structural basis for how this all worked.

Peter Attia:

Oh, I didn’t know the Walker one. Okay.

Lew Cantley:

He was a crystal structure, did crystal structures. And I met all of them when I was a young man before becoming a professor, and it’s stuff is very invested in that and that’s what I worked on

Peter Attia:

For the person who’s listening to this, who’s world is not necessarily wrapped up in this, which is most people. It’s worth pausing for a moment on how much is involved for the Nobel committee to recognize one body of work that says something that three times they would recognize a different angle of the same body of work, probably speaks to why there is so much to this day, complete interest and fascination with the mitochondria beyond just the obvious, the energetics, which is what was initially how we would think about it.

Lew Cantley:

Well, it was a fascinating question. In the 1960s this was the biggest mystery because we knew how you made ATP from glycolysis. But how you made it into mitochondria and how could the mitochondria do it so much more efficiently than glycolysis? That was the big question when I was a graduate student.

Peter Attia:

I think this podcast may represent the point at which mitochondrial topics exceed all others. It also speaks to that nature. Mitchell the great, tell me about how you interacted with Mitchell. How did you come across him?

Lew Cantley:

He came to give a talk at Cornell, and I should say Ef Racker, [Efraim Racker](https://en.wikipedia.org/wiki/Efraim_Racker), who chaired the biochemistry department at Cornell, and who I got to know as first year graduate student, because I was getting mitochondria from his laboratory in order to purify the enzyme that synthesized ATP. Every time I would be waiting for the centrifuges to stop running, he saw me. He would grab me and pull me into his office and start throwing out ideas of how he thought ATP was synthesized.

Lew Cantley:

And the truth was, at that time, he did not believe Mitchell’s chemiosmotic hypothesis Peter Mitchell was proposing. And as a consequence, I got all of these ideas that he was throwing at me. I personally believed that the chemiosmotic hypothesis was correct. Between those discussions as I continued to, I was working in physical chemistry, I was in the chemistry department, not the biochemistry department. But the fact that he would spend so much time with me, even though I wasn’t even in his department to me was quite flattering and really exciting that this world quality person who had done it was willing to talk to me.

Lew Cantley:

He went on, because he was trying to prove Peter Mitchell wrong, he completely purified every component, generated a synthetic membrane, re-constituted the proton pump into that membrane, generated a proton gradient, and was able to quantitatively synthesize ATP. And it was the year after he published that paper saying that the chemiosmotic theory is actually correct. But he did the definitive experiment that the prize went to Peter Mitchell. Today, I can almost guarantee the prize.

Peter Attia:

They would have shared it, yeah.

Lew Cantley:

Mitchell had the idea. Racker proved that it was correct even when he was trying to prove that it was incorrect. That was an interesting story that Mitchell was invited to come and give a talk at Cornell just at that time, my last year as a graduate student. And he met with me and my advisor, Gordon Hamis, and I went through my entire PhD thesis with him and Ef Racker showing them the various experiments I did about the mechanism by which this [mitochondrial] enzyme worked.

Lew Cantley:

It was really quite interesting because this was before Racker actually published the definitive proof paper, so he had still some questions. And every slide I would show Mitchell would say, that’s consistent with the chemiosmotic theory. And Racker would say, no, but this is why it’s not right. And I hardly got to say a word because the two of them argued every piece of data I showed.

Peter Attia:

But you provided the substrate for the argument?

Lew Cantley:

Yeah. It was the data from my PhD days. That was a fun experience.

Peter Attia:

This is early seventies?

Lew Cantley:

It was 1974 when I met Peter Mitchell and in any event it was next year I decided finishing my PhD that I would look for a place that was asking questions that were a little more biological. But I didn’t want to dive too deeply into biology. I was looking for someone who was working on red cells or something that was pretty simple to study and ended up going to [Guido Guidotti](https://www.mcb.harvard.edu/directory/guido-guidotti/)’s laboratory, who had focused on membrane biochemistry. He was an MD-PhD, but he understood medicine quite well. But his real focus was in biochemistry, he was not a practicing clinician and he was in the department of biochemistry and molecular biology at Harvard, recruited there by [James Watson](https://en.wikipedia.org/wiki/James_Watson).

## How understanding the mechanism by which insulin drove glucose uptake into a cell got Lew closer to finding PI3K [1:38:15]

Lew Cantley:

He was absolutely, is still, a brilliant biochemist. I learned a lot from him and he was working on [sodium-potassium ATPase](https://en.wikipedia.org/wiki/Na%2B/K%2B-ATPase). It had first been purified in his laboratory, the enzyme that pumps sodium out of cells and potassium into cells, and since I’d already worked on how you pump protons into cells with an ATP molecule, I thought this would be easy for me to understand. I knew how to do those kinds of assays so that’s why I started working on it. But it turns out that [Guido](https://www.mcb.harvard.edu/directory/guido-guidotti/) was also very interested in how insulin worked because whenever you add insulin to cells within seconds to minutes they take up a massive amount of glucose that they also turn up this sodium-potassium ATPases sodium pump, use that sodium gradient to move amino acids into cells, and so there was a lot of membrane transport being regulated by insulin.

Peter Attia::

Was it understood at that time how anabolic insulin was? What you’ve described are anabolic attributes, but was it understood, clinically, how anabolic the hormone was?

Lew Cantley:

Yes it was because just by observation that type 1 diabetics failed to thrive. They were very small, they did not put on weight, their cells didn’t grow, and so during development, insulin is an anabolic molecule. In a mature adult, it no longer, except under certain situations, drives growth. It will continue to drive growth of fat cells. It can also facilitate growth of muscle, but most tissues do not grow further, but in those two major tissues. So yes, it was well known there was an anabolic process.

Peter Attia:

But now you were seeing the steps by which it could carry out that anabolic property.

Lew Cantley:

Yeah, and it was generally known. What I just said was generally known, that amino acid uptake accelerated immediately within a minute or so. Sodium export of the cell went up, and glucose flux, of course, went in, particularly in muscle and fat cells, and glycogen was stored, and then of course there was a whole lot of change in transcriptional regulation and all kinds of things.

Lew Cantley:

So we knew all of that, but the actual mechanism was totally unknown. In the mid 1970s, no one had even purified the insulin receptor, had no idea what the receptor was. People could quantify it, because if you added radioactive insulin to fat cells, it would stick to the surface with very high affinity, and that correlated with the responses that you see. So we knew it existed, we knew roughly how many copies there were per cell, we could quantify by radioactivity, but no one had quite purified the enzyme into homogeneity, and so numerous labs were trying to purify it.

Lew Cantley:

So eventually the insulin receptor was purified, and it was about the same time that [c-Src](https://en.wikipedia.org/wiki/Proto-oncogene_tyrosine-protein_kinase_Src), the c-Src tyrosine kinase, the Src oncogene, for [Rous sarcoma virus](https://en.wikipedia.org/wiki/Rous_sarcoma_virus) was shown by [Harold Varmus](https://en.wikipedia.org/wiki/Harold_E._Varmus)‘s lab, to be protein that had homology to [PKA](https://en.wikipedia.org/wiki/Protein_kinase_A), protein kinase A, and it also was an endogenous protein that had been picked up by the virus and altered. So that really was a major breakthrough and got the [Nobel prize for Harold Varmus](https://www.nobelprize.org/prizes/medicine/1989/summary/) and-

**Work that got Harold Varmus and Michael Bishop the Nobel Prize**: [The Nobel Prize in Physiology or Medicine 1989](https://www.nobelprize.org/prizes/medicine/1989/summary/) | (nobelprize.org) [1:41:00]

Peter Attia:

He shared that one with Michael, right?

Lew Cantley:

Michael.

Peter Attia:

Yeah, [Michael Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop).

Lew Cantley:

Michael Bishop.

Peter Attia:

In ’89 they shared it.

Lew Cantley:

’79, I think.

Peter Attia:

Oh, but they won the prize in ’89 maybe? Maybe I’m-

Lew Cantley:

Oh yeah, the prize was like-

Peter Attia:

The prize was awarded.

Lew Cantley:

Yeah. The discovery was ’78,’79.

Peter Attia:

Yeah, yeah.

Lew Cantley:

So that was about the time the insulin receptor was being purified as well, and then [Ray Erikson](https://en.wikipedia.org/wiki/Raymond_L._Erikson)‘s labs [showed that c-Src had a kinase activity](https://www.ncbi.nlm.nih.gov/pubmed/205879). They thought it was a threonine kinase, they looked for that possibility, [Joan Brugge](https://brugge.med.harvard.edu/) was his lab at that time, given the sequence homology to protein kinase A, that this was probably also a protein kinase. And then [Tony Hunter](https://www.salk.edu/scientist/tony-hunter/) showed that actually lectin layer, the molecule that was thought to be phosphothreonine, [was actually phosphotyrosine](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6693627/), and phosphotyrosine had never been seen as a product of a protein kinase before. It had been picked up as an intermediate in DNA unwinding, and so that he could get a marker for that from [Jin Wang](https://www.bcm.edu/people/view/jin-wang-ph-d/baylor-college-of-medicine-faculty-and-staff-primary-faculty-nbsp-pharmacology-and-chemical-biology/b27a1ed7-ffed-11e2-be68-080027880ca6/0f100c2a-2460-11e3-ba52-005056b104be)‘s lab, that he could use on the thin layer, and showed that what c-Src was actually producing was actually phosphotyrosine.

Lew Cantley:

So that opened up a whole field, and in comparing the sequence of the insulin receptor, to PKA versus c-Src, it was clearly most highly related to c-Src. And so multiple labs at that point showed that yes, the insulin receptor was, like c-Src, a [tyrosine kinase](https://en.wikipedia.org/wiki/Tyrosine_kinase), but in this case, a transmembrane protein had an extracellular insulin binding component, and then the intracellular kinase activity.

Peter Attia:

So putting that in English for folks, insulin hits this transmembrane tyrosine kinase, and when the molecule of insulin hits it, inside the cell this kinase pathway kicks up, it moves the GLUT4 transporter. Well, there’s another step in there, but oversimplifying a little bit, that chemical reaction is necessary to translocate this transporter across the cell to bring glucose in. And that’s, so the leap there, the new insight was exactly how insulin got glucose in this cell chemically and mechanically, right?

Lew Cantley:

So the initial observation was then, insulin binds, and about the same time EGF receptor was purified, and FGF receptor, and PDGF receptor, and they all sort of were like insulin receptor. They had an extracellular…

Peter Attia:

And this was back, I mean today a young student who’s in a lab doing this now is scratching their head going, what do you mean? Why didn’t you just use PCR or something like that. But I mean you guys were literally what, crystallizing a protein? Or how were they actually figuring out what the structure was?

Lew Cantley:

So these proteins were all being purified to homogeneity, by just plain fractionation. There was no way to knock out genes, and knock them down, so you just had to purify the protein based on its ability to bind insulin. You just run it over column, after column, after column, and eventually you’ve got to a single band on a gel and you said that was your protein.

Peter Attia:

And that only gives you the primary structure of the protein, it doesn’t tell you how it’s folded, does it?

Lew Cantley:

That only tells you-

Peter Attia:

It tells you the molecular weight, basically.

Lew Cantley:

Only thing you get is the molecular weight.

Peter Attia:

Yeah, here it is on the band, yeah.

Lew Cantley:

Insulin receptor is, it gets cleaved but-

Peter Attia:

It’s a heterodimer isn’t it?

Lew Cantley:

It’s a single polypeptide that gets clipped, during processing, into two proteins, that are held together by disulfide bonds. So it’s, and then it, dimer of that composition. So that we knew, late 1970s, and EGF receptor, it’s all these other receptors, all look a lot like the insulin receptor, and they all had tyrosine kinase activity that was triggered by binding the growth factor insulin, IGF-1 receptor also very similar insulin receptor. One by one by one different labs purified them and they all found the same thing. You add the growth factor to the cell, and you get the tyrosine kinase activity activated on the inside of the cell. You know that was a huge breakthrough. But still, if you ask when you triggered the cell with insulin, or EGF, or PDGF, and you ask “what was a major thing phosphorylated?” It was the receptor itself.

Lew Cantley:

So you just asked, where’s the radioactivity going, the radioactive phosphate, it goes mainly to the receptors. It’s auto-phosphorylating. So now we’re left with this several years of, we have a tyrosine kinase which explains how all of these growth factors work, including insulin, and how c-Src works, but we can’t find anything other than auto-phosphorylation. How does that help? So the breakthrough ultimately then came with the observation that these auto-phosphorylations, or phosphorylation of adapter proteins were recruiting a host of other proteins to the membrane that were actually doing the work that was required to drive the cell growth.

Lew Cantley:

And so that was again, early 1980s, these were all being figured out. So I got interested as soon as I saw that there was a different kinase activity, this tyrosine kinase. I got very excited about it, and realized there was an opportunity now if I can figure out what that tyrosine kinase does, to figure out what might be the downstream signal. So we got one step into the cell, we didn’t know how many steps we needed to explain glucose uptake, or amino acid uptake, et cetera, et cetera, or glycogen synthesis.

Lew Cantley:

So I saw a paper by [Ray Erikson](https://en.wikipedia.org/wiki/Raymond_L._Erikson)‘s laboratory in which he found an activity associated with c-Src that would phosphorylate glycerol, and he [published it in JBC](https://www.jbc.org/content/258/4/2126.full.pdf). It co-purified with the protein through numerous steps of purification. And so in addition to having the ability to phosphorylate tyrosine, antibodies that got phosphorylated on tyrosine on the purified protein, there was also an activity there that phosphorylated glycerol. And I looked at that and thought, “now glycerol looks like half of an inositol”. So inositol is six carbons, glycerol is three. In both cases-

Peter Attia:

But in the pure glycerol case, it has OH on each of the carbons?

Lew Cantley:

You have three carbons with an OH on it, and inositol has six carbons with an OH on all.

Lew Cantley:

So if you took two…

Peter Attia:

Yeah, if you take the two rings and shoved them together, yeah…

Lew Cantley:

Glued them together, you would get inositol. And then what the paper showed, was to Km, it was a 50% concentration of glycerol you needed for it to be phosphorylated, was something like a hundred millimolar.

Peter Attia:

Enormous concentration.

Lew Cantley:

Huge. Like a hundred to thousand fold higher unit ever found in a cell. Yeah. So they weren’t claiming this was a physiologically relevant…

Peter Attia:

I see. They were just saying, here’s a chemical reaction that can take place.

Lew Cantley:

And they just noticed it because they saw this molecule running on their thin layer that ran faster than proteins. When they isolated it, it turned out to be phosphorylated glycerol. It was sort of out there, we saw this other activity, what might it be? And so I went to Ray Erikson and said, “well that looks a lot like inositol”, so why don’t we-

Peter Attia:

Was Ray at Harvard at the time?

Lew Cantley:

Yeah. One floor below me, at Harvard. So my graduate student, [Malcolm Whitman](https://www.dfhcc.harvard.edu/insider/member-detail/member/malcolm-whitman-phd/), who knew how to do kinase assays on small molecules, [collaborated with Ray Erikson’s postdoc](https://www.pnas.org/content/81/7/2117.short) to see whether phosphatidylinositol might be a better substrate than glycerol. And he tried it and sure enough, he got this Km of like five micromolar.

Peter Attia:

Wait, whoa, how is this even possible? Let me make sure I understand what you just said. You take glycerol and you need a Km of a hundred millimolar to get it phosphorylated. You simply take the same structure but now it’s basically two of them stuck together in a ring, and you get down to five micromolar?

Lew Cantley:

And it’s also on a membrane component. So the inositol is in a membrane bilayer. So you sonicate the lipid and instead of free molecule floating-

Peter Attia:

Oh, so it’s not a free inositol. It’s the inositol in the phospholipid, or in the lipid.

Lew Cantley:

In the lipid, yeah.

Peter Attia:

Tell me from a chemistry standpoint, and I apologize, I know that for some of you listening right now you’re thinking, wow, you guys are really in the weeds. I promise we’re going to get out of the weeds in a minute, but I also think this is just an interesting example of the specificity of biology too. What is it about that lipid holding that, is it the position with which it holds the ring in place that enables that phosphorylation?

Lew Cantley:

Well, now that we know the structure of PI 3-kinase, and how it works, and its mechanism, it’s easy to explain in retrospect. But at that time we didn’t know that there was anything there other than c-Src. So it was hard to explain why the c-Src, tyrosine kinase itself, was carrying out this reaction.

Peter Attia:

What did the editors even say of that? I mean that’s one of those things where people are like, is there a mistake here? Cause that’s like a five log difference.

Lew Cantley:

Physicists had no problem understanding what I just said. If you confine things to two dimensions, they can come together much more readily than if you do it in three dimensions.

Peter Attia:

And that would account for the difference?

Lew Cantley:

Yeah. Easily. Try closing your eyes and bringing your two fingers together in space, in three dimensional space and then do it again on the table, and you’ll find, they’ll find each other. Yeah. So combining things to two dimension is way nature continually uses membranes-

Peter Attia:

And the lipid’s basically keeping it in a two dimensional plane.

Lew Cantley:

Yep. So any event, we really get in the weeds here now.

Peter Attia:

I just personally, I mean all of that is intuitive to me. What’s not intuitive to me is five log difference. I would take a one log difference for what you said. That’s what’s amazing to me. I didn’t-

Lew Cantley:

Well there are other reasons that will come clear as we move on. So the bottom line was that that c-Src preparation, which we assumed was completely pure, wasn’t completely pure, it was a certain amount of the c-Src harvested out of the cell brought along this second enzyme, which ultimately turned out to be PI3K, phosphoinositide 3-kinase. But we didn’t know that, at that time, and so, we suggested in the paper that the c-Src, very same insomatic pocket, could both accommodate tyrosine as a substrate and also accommodate the head group of phosphatidylinositol. That, in the end, turned out to be incorrect. Even though, by all criteria that we could characterize at that point, we couldn’t prove that there was a separate function. If you used a kinase-dead c-Src, or a mutant of c-Src that no longer had activity, then the phosphatidylinositol kinase also went away. That’s why we thought it was the same pocket that was doing both.

Lew Cantley:

In retrospect it turns out that the enzyme has to be active in order to bind to PI 3-kinase, and that’s why that activity was coming along. So we published that. We’re very, very clear to say that we used sonicated membranes to do the assay, which was necessary to get this many log preference for that substrate. In the meantime, after publishing that, multiple other labs tried to reproduce it, but they didn’t have the machine that would sonify the lipids to make the membrane bilayers. So they just added detergent. So even though we showed in our paper that if you added detergent, the enzyme activity completely disappeared.

Peter Attia:

Wouldn’t the detergent break the glycerol off the lipid?

Lew Cantley:

The phosphatidylinositol would now get embedded into the detergent rather than being a bilayer.

Peter Attia:

Yeah, it wouldn’t stick to it at all, right?

Lew Cantley:

Right. So you’re going to lose that advantage of having a membrane.

Peter Attia:

And that wasn’t known at the time, I guess?

Lew Cantley:

Well we knew it because I’d worked on membranes for the previous 10 years.

Peter Attia:

But the other labs didn’t, I guess at the time they didn’t know…

Lew Cantley:

They were not membrane biochemists, they were all molecular biologists. So they tried to reproduce the result, but they didn’t have a sonifier to make membrane lipids. And they assumed that  phosphatidylinositol, it shouldn’t make any difference, how you present it. And so they presented it, detergent, and they could not reproduce the results. So there were three prominent papers coming out a year or so later.

Peter Attia:

Saying, Nope, this is incorrect. This is incorrect, this incorrect.

Lew Cantley:

From major laboratories. So at that point I had already started a collaboration with [Tom Roberts](https://www.dfhcc.harvard.edu/insider/member-detail/member/thomas-m-roberts-phd/).

Peter Attia:

But at that point, Lew, did you have confidence that you had done this correctly or were you questioning yourself?

Lew Cantley:

I had no doubt.

Peter Attia:

So you knew this was a methodologic error on the part of those other three labs. And despite the fact that at this point the scientific community would look at you and say, Lew, you’re probably wrong. You were confident in your methodology?

Lew Cantley:

Yeah, there was no doubt. All my research had been on membrane enzymes and membrane reconstitution, et cetera. So I knew what I was doing made sense, and I knew our results are reproducible because not only could multiple people in my laboratory do it, but multiple people in Tom Robert’s laboratory, who we started a collaboration with, could do it. And [Brian Schaffhausen](https://gsbs.tufts.edu/facultyResearch/faculty/schaffhausen-brian)‘s lab, which was a third collaborator, could also reproduce it. So multiple people, in multiple independent labs, all got the same result. If you sonified the lipid, and if you added NP40, and detergent to solubilize the liquid, then the activity went away. So there was no doubt about that.

Lew Cantley:

So I had no lack of confidence that we were right. But the problem was how to convince these other laboratories that they needed to do the assay right. They didn’t want to buy a sonifier. They were like, “I’m done with that, went there… It doesn’t work”. So we actually sent [David Kaplan](https://www.sickkids.ca/AboutSickKids/Directory/People/K/David-Kaplan.html), who registered in Tom Robert’s lab, and Malcolm Whitman, the graduate student in my laboratory, to these other laboratories with the sonifier. They went there, they sonified the liquid for them, gave them to their graduate students, who then did the assay again, and now they got the same result we got.

## How Lew knew PI3K was important in driving growth of cancer cells [1:55:00]

Peter Attia:

Are you pushing this hard to get through their labs to see it because you know how important this is going to be, or you have a sort of premonition about the role that PI3K is going to play in growth? I mean, you couldn’t have possibly seen in the early 80s what you know today. So how much of this was just scratching an intellectual itch, versus a biologic intuition about the importance of this to overall growth, which is obviously where we’re going? I’m amazed we are this far in and we haven’t used the C-word yet.

Lew Cantley:

So the reason I was completely convinced by 76, 77, that this was driving growth of cancer cells, is the collaboration we started with Tom Robert’s lab. And Tom Roberts had been working on [polyoma middle T](https://en.wikipedia.org/wiki/Middle_tumor_antigen). So polyomavirus is a DNA virus, while c-Src is an RNA virus. And so it causes, as the name implies, the formation of multiple tumors in mice. So you infect a mouse with this virus and all kinds of tumors show up everywhere. And so Tom had begun mutating various regions of polyoma middle T. The reason we looked at polyoma middle T, is because his lab, and [Sara Courtneidge](https://www.ohsu.edu/people/sara-a-courtneidge-phd-dsc)‘s lab, and others, and Schaffhausen, had shown that c-Src co-purifies with polyoma middle T. We already knew by the mid 70s that c-Src was somehow implicated in how polyoma middle T transforms cells and forms all these tumors.

Lew Cantley:

That’s why I went to collaborate with Tom because he had additional tools that we could collaborate with to understand. And so he had made all kinds of mutations. He’d also found that c-Src phosphorylated a site, and polyoma middle T, a tyrosine site, was highly phosphorylated. And even more importantly, that if you mutated that tyrosine residue to [phenylalanine](https://en.wikipedia.org/wiki/Phenylalanine), polyoma middle T completely lost its ability to transform cells with a single point mutation. Even though the c-Src protein was still bound, there was no longer tyrosine 315 phosphorylation, and that eliminated the ability to transform cells.

Lew Cantley:

So we said, well, if PI 3-kinase is not c-Src itself, maybe it binds to middle T independently, but we found that if you prevented c-Src from binding to middle T, then you didn’t get that tyrosine phosphorylation, and now there was no PI 3-kinase activity bound to middle T. So you needed c-Src for middle T to bind to PI 3-kinase. At this time, we didn’t know it was phosphorylated in the three position, which we will come back to.

Lew Cantley:

However, the shocking result was that if you eliminated that tyrosine residue, now PI 3-kinase would no longer bind, and the middle T would no longer transform cells, even though c-Src was still there and was still activated. So that said that activating c-Src is not sufficient to transform a cell, unless you also activate PI 3-kinase. And we published that in Nature in 76, I think 76, 77 in Nature. [CORRECTION: He meant 1986-87]

**1985 Nature paper**: [Association of Phosphatidylinositol Kinase Activity With Polyoma middle T Competent for Transformation](https://pubmed.ncbi.nlm.nih.gov/2987699/) (Whitman et al., 1985)

Peter Attia:

Were you collaborating with Bishop and Varmus at this point in time?

Lew Cantley:

Sorry… 86, 87. So 84 was when we published the paper with Ray Erikson, and then a couple of years later with Tom Roberts. And a couple of papers we had, and we showed that PDGF receptor also, when activated, brought down PI 3-kinase activity, et cetera, et cetera.

**1984 paper by Lew and Ray Erikson**: [Evidence That the Rous Sarcoma Virus Transforming Gene Product Phosphorylates Phosphatidylinositol and Diacylglycerol](https://pubmed.ncbi.nlm.nih.gov/6326105/?from_single_result=%28%28Cantley+L%5BAuthor%5D%29+AND+%28Erikson+RL%5BAuthor%5D%29%29+AND+%28%28%221983%22%5BDate+-+Publication%5D+%3A+%221985%22%5BDate+-+Publication%5D%29%29&expanded_search_query=%28%28Cantley+L%5BAuthor%5D%29+AND+%28Erikson+RL%5BAuthor%5D%29%29+AND+%28%28%221983%22%5BDate+-+Publication%5D+%3A+%221985%22%5BDate+-+Publication%5D%29%29) (Sugimoto et al., 1984)

Lew Cantley:

So that’s where we were in 1986, 87, or so, and at least some of the people who had gotten sonicaters also believed us, that this was really, uniquely associated with tyrosine kinases after they were activated by growth factors. We saw the insulin receptor would also bring down PI 3-kinase. Only if you simulate with insulin first, then you could also bring down this PI kinase activity.

## Lew’s unlikely observation of phosphorylation at the 3′ position of the inositol ring resulting in the formation of phosphatidylinositol-3-phosphate [1:59:00]

Lew Cantley:

But at that time, the only mono-phosphorylated form of phosphatidylinositol known, was [phosphatidylinositol 4-phosphate](https://en.wikipedia.org/wiki/Phosphatidylinositol_4-phosphate). That was discovered in 1949, I mentioned earlier, there’s a four phosphorylation, and there’s a 4 plus 5 phosphorylation, and those were the only two species of phosphorylated phosphatidylinositol. So we assumed that this was phosphorylation at the 4 position.

Lew Cantley:

But as we began to characterize the ability of proteins from cells to phosphorylate phosphatidylinositol, we found that there were two activities. There was one that required that you sonified the membranes, for it to have activity, and another that would work perfectly well, in fact even better, if the lipid was dissolved in a detergent. So we called those two enzymes, type I, and type II, PI-kinase. And it was only the type I, the one that required sonified lipids, that co-precipitated with all these tyrosine kinases. The type II had completely different insomatic characters. So it was inhibited by adenosine, the type I wasn’t, and so we had a whole lot of profiles that said these were two different enzymes.

Lew Cantley:

So [Malcolm Whitman](https://www.dfhcc.harvard.edu/insider/member-detail/member/malcolm-whitman-phd/), registered in my lab, decided to separate them. So he ran column fractionation with or without detergent, with or without adenosine, and he characterized the two enzymes, separated them completely. And we had a lab meeting in which, every other spot on the thin layer, which is how we characterize the lipid phosphorylation, we ran it out to separate the molecules based on migration in a solvent on a silica plate.

Lew Cantley:

And we noticed in the lab meeting that every other spot migrated about one millimeter different from the previous spot. And the way that Malcolm spotted them on the thin layer, was it was type I, then type II, and type I, and type II, type I, type II, all the way across. If you looked at where the radioactivity ran, it went up, down, up, down, up, down, up, down, up, down. And the bottom line was, to me as a chemist, the fact that they migrate differently means they have to be chemically different. So that meant that one of those molecules was being phosphorylated at a different position on the inositol ring from the other, and so we began the process then of chemically characterizing the product of the type I and the type II enzyme.

Peter Attia:

And how subtle was this, by the way? Was this obvious in looking at it, or was it something that could have easily been dismissed?

Lew Cantley:

I’ll guarantee almost everybody would’ve dismissed this. One millimeter.

Peter Attia:

Yeah, I was about to say that just doesn’t sound like-

Lew Cantley:

The spot was at least 10 millimeters diameter, and the center of the spots were one millimeter different.

Peter Attia:

Do you naturally have an eye that gravitates towards symmetry?

Lew Cantley:

I have an eye that gravitates towards unexpected results. And to me there’s no way to explain it. If you had only two spots beside each other you could say, well that side of the thin layer migrated a little faster because of the solvent front was not completely horizontal. But this, you couldn’t explain the up, down, up, down, up, down, all the way across.

Peter Attia:

Do you still have a photo of that?

Lew Cantley:

It’s in figure one in the Nature paper that we did.

Peter Attia:

From 87?

Lew Cantley:

88, published in 88.

Peter Attia:

We’ll link to that figure.

**The 1988 Nature paper**: [Type I phosphatidylinositol kinase makes a novel inositol phospholipid, phosphatidylinositol-3-phosphate](https://www.nature.com/articles/332644a0) (Whitman et al., 1988)

![](https://peterattiamd.com/wp-content/uploads/2020/05/fig-1-from-1988-nature-paper-lewcantley-with-description-1024x811.png)

**Figure 3. Image depicting the one millimeter difference in position giving the clue that there was a previously unknown phosphatidylinositol-3-phosphate.** Image credit: [Whitman et al., 1988](https://www.nature.com/articles/332644a0)

Lew Cantley:

But the observation was made in 1987. I bumped into [Peter Downes](https://en.wikipedia.org/wiki/Peter_Downes), who’s one of the best lipid chemists in the world at a meeting at Cold Spring Harbor and I told him this result and I said, “I know you must have standards for inositol degradation, so can we work together?” And so we knew it had to be some site, other than the 4 position, but it could have been the 5, it could have been the 3.

Peter Attia:

Yeah, was there a chance it could have been, you were looking at 4, versus 4 plus 5?

Lew Cantley:

No, no. Because we knew that 4 plus 5, it would migrate about three inches different.

Peter Attia:

So that would look totally different?

Lew Cantley:

Yeah.

Peter Attia:

So the null hypothesis is you’re just looking at 4, and your assay is a little dirty, but you’re thinking, no, it’s something else.

Lew Cantley:

Yep. Of course, we repeated it multiple times, and we also did HPLC separation, reverse phase, every way you could look at it. And in every way we did it, they were chemically different, they migrated differently, in numerous… The Nature paper, we only put that one slide, that one figure of the slightly different migration, and because from there on we did the chemistry to prove it was the 3 position.

Peter Attia:

Why do you think the 3 position had such a similar look to the 4, versus the 5?

Lew Cantley:

Well, keep in mind there are only two species known to exist, at the time we made this discovery. Phosphatidylinositol 4-phosphate…

Peter Attia:

Oh, and 4,5. There was not a 5 by itself.

Lew Cantley:

There was not a 5 by itself. So this told us there’s a 3 by itself, and then we went on to show there’s also a 3,4. And also 3,4,5. PI 3-kinase could phosphorylate to 3 position, whether or not the 4, or 5, were already phosphorylated. So we now, that generated three new species, PI3P, PI34 and PI345, but I have to say the 3,4,5… This is sort of another sidebar that we could drop out of this, but it’s so cool. Never published it because it was embarrassing. But you know, at this age you may as well get embarrassed.

Lew Cantley:

So we knew that there were species that had been claimed to be 4,5 that were probably 3,4 for the same reason that the 3P, was thought to be 4P, because separating the 3,4 from the 4,5 was also hard. So we looked for that carefully, and found that in fact there was a 3,4 being made, and proved that the same enzyme was making 3P and if you gave it PI4P to the substrate, it would make 34P2.

Lew Cantley:

[Leslie Serunian](https://www.gtlaw.com/en/professionals/s/serunian-phd-leslie-a), a postdoc in the laboratory, was doing the experiments to really verify that those two species really were being made from the same enzyme. And in the course of that work, she came into my office one day and said, “I no longer get the same results that I’ve been getting for the last six months. Something has changed.” And so we went over all of her thin layers again, this is how we separated all the species, and sure enough, after getting numerous results in which she could give PI4P and get PI34P2 suddenly over the past week, she no longer got that doubly phosphorylated lipid when she added purified PI 3-kinase to that liquid.

Lew Cantley:

So the question was what changed? And she said, well, “the only thing that changed is we ran out of the PI4P, and I had to buy a new jar of PI4P from [Behringer Mannheim 00:02:06:18]”. And I said, huh, that’s interesting. And I looked at the thin layer more carefully, I noticed that just when the experiments were no longer working, there was a new spot on the thin layer that was just off the origin, where we’d assumed it would probably just be ATP. There was always a little bit of contaminating ATP that got leftover when you separate the lipid out. And we assumed that that was ATP, but I noticed it ran just a little bit faster than ATP. And that it only appeared in experiments where she could not find the 34P2. And I said, okay, stain this with iodine and it’ll tell you where the lipid that you used from [Behringer Mannheim 00:02:07:02] runs, and I’ll bet that it’s actually 45P2.

Lew Cantley:

And that turned out to be the case, that they’d mislabeled the bottle, what was commercially sold as phosphatidylinositol 4-phosphate, was actually phosphatidylinositol 4,5-bisphosphate. And so by accident, I almost think that God looked down on us and said, look, they’re missing the most important lipid, PI345P3. It never occurred to us to look for it because we were, no one had ever claimed there was something like that ran, on a thin layer. And that was because they run so close to the ATP, that was always missed.

Peter Attia:

Because it’s got three phosphates.

Lew Cantley:

Yeah, it’s very highly charged and therefore runs.

Peter Attia:

I never once thought of that until you just said that, Lew. I never would have had that thought actually, and then of course when you say it now, I mean that’s, think about how dominant those three phosphates are, right?

Lew Cantley:

In fact, the year after we made this observation, the paper came out. In fact, I got called by Nature saying, there’s this paper claiming they found something that looks like triply phosphorylated, phosphatidylinositol, and they asked, do you think that’s possible? And I said, yeah, in fact, I know it’s possible. We already have results showing that that can happen with purified enzyme.

§

## Selected Links / Related Material

**Lew’s 2009 review that provided a more complex explanation for the Warburg Effect**: [Understanding the Warburg Effect: The Metabolic Requirements of Cell Proliferation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) (Vander Heiden, et al., 2009) [8:30, 12:15, 16:45]

**Peter’s interview of Ted Schaeffer on The Drive**: [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) | Peter Attia (peterattiamd.com) [11:30]

**Back-to-back papers in Nature that both explained structurally how phosphotyrosine peptides or proteins binding to pyruvate kinase could turn off its activity**: [11:45]

- [The M2 splice isoform of pyruvate kinase is important for cancer metabolism and tumour growth](https://www.nature.com/articles/nature06734) (Christofk, et al., 2008)
- [Pyruvate kinase M2 is a phosphotyrosine-binding protein](https://www.nature.com/articles/nature06667) (Christofk, et al., 2008) [16:00]

**A pharmaceutical company started by Lew and Craig Thompson focused on developing small-molecule anti-cancer therapeutics targeting cancer cell metabolism via the growth factor pathway**: [Agios](https://www.agios.com/) | (agios.com) [11:45]

**The Warburg Effect**: [Warburg effect (oncology)](https://en.wikipedia.org/wiki/Warburg_effect_(oncology)) | (wikipedia.org)  [13:00]

**Evidence for virally induced cancers, SRC, by Harold Varmus and Mike Bishop was shown that viruses could turn on cancers which pushed the idea cancer was an altered metabolism out of favor**: [The Nobel Prize in Physiology or Medicine in 1989](https://www.nobelprize.org/prizes/medicine/1989/press-release/) | (nobelprize.org) [14:15]

**Peter’s interview of Sid Mukherjee where they discussed obesity and cancer**: [#32 – Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process](https://peterattiamd.com/sidmukherjee/) | Peter Attia (peterattiamd.com) [29:30, 1:02:30]

**PBS special focused on cancer in which Lew appeared**: [Cancer: The Emperor of All Maladies](https://www.pbs.org/show/story-cancer-emperor-all-maladies/) | (pbs.org) [29:45]

**Paper suggesting insulin sensitivity is more relevant than body mass in breast cancer risk:** [Breast Cancer Risk in Metabolically Healthy but Overweight Postmenopausal Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4657855/) (Gunter et al., 2015) [30:45]

**Mitch Lazar paper suggesting body mass is less important than metabolic health**: [The health risk of obesity–better metrics imperative.](https://science.sciencemag.org/content/341/6148/856.full.pdf+html) (Ahima and Lazar, 2013)  [31:45]

**Lew’s 2019 paper showing that HFCS increased tumor growth in mice**: [High-fructose corn syrup enhances intestinal tumor growth in mice](https://science.sciencemag.org/content/363/6433/1345) (Goncalves et al., 2019) [32:00]

**Mayor Bloomberg’s attempt to ban certain large sizes of soda sold in NYC**: [Sugary drinks portion cap rule](https://en.wikipedia.org/wiki/Sugary_drinks_portion_cap_rule) | (wikipedia.org) [32:00]

**Bert Vogelstein’s paper showing that APC is the first gene in human cancer that gets lost to initiate the process of colorectal cancer development**: [APC Mutations Occur Early During Colorectal Tumorigenesis](https://pubmed.ncbi.nlm.nih.gov/1528264/) (Powell et al., 1992) [34:00]

**Rick Johnson’s article about how apes that humans evolved from developed a mutation in uricase and fructokinase which allowed them to put on fat from sugar in order to survive the winter**: [Ancient Mutation in Apes May Explain Human Obesity and Diabetes](https://www.scientificamerican.com/article/ancient-mutation-in-apes-may-explain-human-obesity-and-diabetes/) | Richard J. Johnson and Peter Andrews (scientificamerican.com) [45:15]

**Peter’s interview of Rick Johnson on The Drive**: [#87 – Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com) [45:15]

**Lew’s study evaluating metformin, SGLT2 inhibitors, and ketogenic diets and their ability to enhance efficacy of PI3K inhibitors:** [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6197057/) (Hopkins et al., 2019) [58:45]

**Lew’s pharma company that is doing the clinical trial with treatment for stage 4 cancer patients**: [Petra pharmaceuticals](https://petrapharmacorp.com/) | (petrapharmacorp.com) [1:08:00]

**Link to the information about enrolling in Lew’s clinical trial**: [A Phase 1b/2 Study of Serabelisib in Combination With Canagliflozin in Patients With Advanced Solid Tumors](https://clinicaltrials.gov/ct2/show/NCT04073680?term=petra%2C+PIK3%2C+SGLT2&cond=cancer&draw=2&rank=1) | (clinicaltrials.gov) [1:08:45]

**Lew’s nutrition company he started with Sid Mukherjee that will be making meals for dietary intervention in cancer patients**: Faeth pharmaceuticals [1:11:00]

**Evidence that reducing serine levels can make some drugs more effective**: [Identification of a small molecule inhibitor of 3-phosphoglycerate dehydrogenase to target serine biosynthesis in cancers](https://www.pnas.org/content/113/7/1778) (Mullarky et al., 2016) [1:12:00]

**Reducing methionine levels may make other cancer drugs more effective in different mutational backgrounds**:

- [Dietary methionine links nutrition and metabolism to the efficacy of cancer therapies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6951023/) (Gao et al., 2020)
- [Altering Diet Enhances Response to Cancer Treatments in Mice](https://www.cancer.gov/news-events/cancer-currents-blog/2019/targeting-cancer-metabolism-low-methionine-diet) | (cancer.gov) [1:12:00]

**Current PI3K inhibitors:** [1:16:15]

- [Alpelisib](https://en.wikipedia.org/wiki/Alpelisib) (brand name Piqray) by Novartis
- [Idelalisib](https://en.wikipedia.org/wiki/Idelalisib) (brand name Zydelig) by Gilead Sciences
- [Copanlisib](https://en.wikipedia.org/wiki/Copanlisib) (trade name Aliqopa) by Bayer

**May 2019 paper by Lew about the Insulin-PI3K signalling**: [Insulin-PI3K signalling: an evolutionarily insulated metabolic driver of cancer.](https://www.ncbi.nlm.nih.gov/pubmed/32127696) (Hopkins et al., 2020) [1:25:00]

**Breakthrough discovery in the early 1980s showing that when cells are stimulated with certain growth factors like EGF or GPCR would regulate calcium release from cells**: [Inositol trisphosphate: Discovery](https://en.wikipedia.org/wiki/Inositol_trisphosphate#Discovery) | (wikipedia.org) [1:28:45]

**The Nobel Prizes given for how ATP is synthesized in the mitochondria**: [1:32:30]

- Peter Mitchell: [The Nobel Prize in Chemistry 1978](https://www.nobelprize.org/prizes/chemistry/1978/summary/)
- Paul Boyer and John Walker: [The Nobel Prize in Chemistry 1997](https://www.nobelprize.org/prizes/chemistry/1997/summary/)

**Efraim Racker’s work that proved Peter Mitchell’s chemiosmotic hypothesis**: [Unraveling the Enzymology of Oxidative Phosphorylation: the Work of Efraim Racker](https://www.jbc.org/content/281/4/e4.full#ref-6) (Kresge et al., 2006) [1:35:15]

**Work that got Harold Varmus and Michael Bishop the Nobel Prize**: [The Nobel Prize in Physiology or Medicine 1989](https://www.nobelprize.org/prizes/medicine/1989/summary/) | (nobelprize.org) [1:41:00]

**Ray Erikson’s labs showed that Src had a kinase activity in 1978**: [Protein kinase activity associated with the avian sarcoma virus src gene product.](https://www.ncbi.nlm.nih.gov/pubmed/205879) (Collett and Erikson, 1978) [1:41:45]

**Tony Hunter showed that the molecule was thought to be phosphothreonine was actually phosphotyrosine**: [Phosphotyrosine – a new protein modification](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6693627/) (Tony Hunter, 1982) [1:41:45]

**Ray Erikson’s paper that Lew saw in the early 80s in which Ray found an activity associated with Src that would phosphorylate glycerol**: [Evidence That the Rous Sarcoma Virus Transforming Gene Product Is Associated with Glycerol Kinase Activity](https://www.jbc.org/content/258/4/2126.full.pdf) (Graziani et al., 1982) [1:46:45]

- Other papers from Erikson on this topic:
  - <https://www.jbc.org/content/258/10/6344.full.pdf> (Graziani et al., 1983)
  - <https://www.jbc.org/content/256/22/11381.full.pdf> (Erikson et al., 1981)

**Lew’s paper in collaboration with Ray Erikson to see whether phosphatidylinositol might be a better substrate than glycerol**: [Evidence that the Rous sarcoma virus transforming gene product phosphorylates phosphatidylinositol and diacylglycerol](https://www.pnas.org/content/81/7/2117.short) (Sugimoto et al., 1984) [1:48:15]

**1985 Nature paper**: [Association of Phosphatidylinositol Kinase Activity With Polyoma middle T Competent for Transformation](https://pubmed.ncbi.nlm.nih.gov/2987699/) (Whitman et al., 1985) [1:57:45]

**1984 paper by Lew and Ray Erikson**: [Evidence That the Rous Sarcoma Virus Transforming Gene Product Phosphorylates Phosphatidylinositol and Diacylglycerol](https://pubmed.ncbi.nlm.nih.gov/6326105/?from_single_result=%28%28Cantley+L%5BAuthor%5D%29+AND+%28Erikson+RL%5BAuthor%5D%29%29+AND+%28%28%221983%22%5BDate+-+Publication%5D+%3A+%221985%22%5BDate+-+Publication%5D%29%29&expanded_search_query=%28%28Cantley+L%5BAuthor%5D%29+AND+%28Erikson+RL%5BAuthor%5D%29%29+AND+%28%28%221983%22%5BDate+-+Publication%5D+%3A+%221985%22%5BDate+-+Publication%5D%29%29) (Sugimoto et al., 1984) [1:57:45]

**The 1988 Nature paper containing the figure showing the one millimeter difference in position**: [Type I phosphatidylinositol kinase makes a novel inositol phospholipid, phosphatidylinositol-3-phosphate](https://www.nature.com/articles/332644a0) (Whitman et al., 1988) [2:02:15]

§

## People Mentioned

- [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) [8:30]
- [Craig Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson) [8:30]
- [Heather Christofk](https://www.biolchem.ucla.edu/people/faculty/heather-christofk) [9:15]
- [Ted Schaeffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261) [11:30]
- [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) [13:00]
- [Efraim Racker](https://en.wikipedia.org/wiki/Efraim_Racker) [13:00, 18:00, 1:34:45]
- [Harold Varmus](https://en.wikipedia.org/wiki/Harold_E._Varmus) [14:15, 1:41:00]
- [Mike Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop) [14:15, 1:41:00]
- [Bert Vogelstein](https://www.hopkinsmedicine.org/pharmacology_molecular_sciences/faculty/bios/vogelstein.html) [26:30, 32:15, 55:00]
- [Siddhartha Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) [29:30, 1:02:30, 1:11:00]
- [Ken Burns](https://en.wikipedia.org/wiki/Ken_Burns) [30:00]
- [Mitchell Lazar](https://en.wikipedia.org/wiki/Mitchell_Lazar) [31:45]
- [Michael Bloomberg](https://en.wikipedia.org/wiki/Michael_Bloomberg) [32:15]
- [Jihye Yun](https://www.bcm.edu/people/view/jihye-yun-ph-d/8052942a-a2a2-11e7-b983-005056a012ee) (Lew’s postdoc who helped with 2019 Science paper) [32:15]
- [Marcus Goncalves](https://weillcornell.org/marcus-dasilva-goncalves-md-phd) [35:45, 1:11:00]
- [Rick Johnson](https://www.cudoctors.com/Find_A_Doctor/Profile/9426) [45:15]
- [Karen Vousden](https://www.crick.ac.uk/research/labs/karen-vousden) (co-founder of Faeth) [1:11:00]
- [Oliver Maddocks](https://www.gla.ac.uk/researchinstitutes/cancersciences/staff/olivermaddocks/#biography) (co-founder of Faeth) [1:11:00]
- [Benjamin Hopkins](https://twitter.com/hopkins914?lang=en) (co-founder of Faeth) [1:11:00]
- [Scott Lowe](https://www.pnas.org/content/115/4/630) (co-founder of Faeth( [1:11:00]
- [Greg Hannon](https://en.wikipedia.org/wiki/Gregory_Hannon) (co-founder of Faeth) [1:11:00]
- [David Fruman](https://www.faculty.uci.edu/profile.cfm?faculty_id=4541&term_list=fruman&name=David%20A%20Fruman) [1:16:45]
- [Peter Mitchell](https://en.wikipedia.org/wiki/Peter_D._Mitchell) [1:32:30]
- [Paul Boyer](https://en.wikipedia.org/wiki/Paul_D._Boyer) [1:32:30]
- [John Walker](https://en.wikipedia.org/wiki/John_E._Walker) [1:32:30]
- [Guido Guidotti](https://www.mcb.harvard.edu/directory/guido-guidotti/) [1:37:45]
- [James Watson](https://en.wikipedia.org/wiki/James_Watson) [1:37:45]
- [Ray Erikson](https://en.wikipedia.org/wiki/Raymond_L._Erikson) [1:41:45, 1:46:45]
- [Joan Brugge](https://brugge.med.harvard.edu/) [1:41:45]
- [Tony Hunter](https://www.salk.edu/scientist/tony-hunter/)  [1:41:45]
- [Jin Wang](https://www.bcm.edu/people/view/jin-wang-ph-d/baylor-college-of-medicine-faculty-and-staff-primary-faculty-nbsp-pharmacology-and-chemical-biology/b27a1ed7-ffed-11e2-be68-080027880ca6/0f100c2a-2460-11e3-ba52-005056b104be) [1:42:15]
- [Malcolm Whitman](https://www.dfhcc.harvard.edu/insider/member-detail/member/malcolm-whitman-phd/) [1:48:30, 2:00:15]
- [Tom Roberts](https://www.dfhcc.harvard.edu/insider/member-detail/member/thomas-m-roberts-phd/) [1:53:15]
- [Brian Schaffhausen](https://gsbs.tufts.edu/facultyResearch/faculty/schaffhausen-brian)  [1:54:00]
- [David Kaplan](https://www.sickkids.ca/AboutSickKids/Directory/People/K/David-Kaplan.html) [1:54:30]
- [Sara Courtneidge](https://www.ohsu.edu/people/sara-a-courtneidge-phd-dsc) [1:56:00]
- [Peter Downes](https://en.wikipedia.org/wiki/Peter_Downes) [2:02:30]
- [Leslie Serunian](https://www.gtlaw.com/en/professionals/s/serunian-phd-leslie-a) [2:05:15

§

![](https://peterattiamd.com/wp-content/uploads/2020/05/lew-cantley-2x1-1-500x492.jpeg)

##### Lewis Cantley, Ph.D.

*Meyer Director of the Sandra and Edward Meyer Cancer Center at Weill Cornell Medical College, Professor of Cancer Biology in Medicine*

Lewis Cantley has made significant advances in cancer research, stemming from his discovery of the signaling pathway phosphoinositide 3-kinase (PI3K) in 1984. His pioneering research has resulted in revolutionary treatments for cancer, diabetes and autoimmune diseases. The author of over 400 original papers and more than 50 book chapters and review articles, Dr. Cantley is a fellow of the American Academy of Arts and Sciences and a member of the National Academy of Sciences. He graduated summa cum laude with a B.S. in chemistry from West Virginia Wesleyan College (1971) and obtained a Ph.D. in biophysical chemistry from Cornell University (1975). He conducted postdoctoral research at Harvard University, where he was appointed assistant professor of biochemistry and molecular biology in 1978. He became a professor of physiology at Tufts University in 1985, but returned to Harvard Medical School as professor of cell biology in 1992. He became chief of Harvard’s new Division of Signal Transduction, and a founding member of its Department of Systems Biology in 2002. In 2007, he was appointed director of the Beth Israel Deaconess Cancer Center. He joined the faculty of Weill Cornell Medical College and NewYork-Presbyterian Hospital in 2012.