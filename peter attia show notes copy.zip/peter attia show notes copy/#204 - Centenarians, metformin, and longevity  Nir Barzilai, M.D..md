# #204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.

**Source:** [https://peterattiamd.com/nirbarzilai2/](https://peterattiamd.com/nirbarzilai2/)

---

##### Check out more content from Nir Barzilai, M.D:

- *(Jan 7, 2019)* [#35 – Nir Barzilai, M.D.: How to tame aging](/nirbarzilai/)
- *(August 10, 2020)* [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](/joanmannick-nirbarzilai/)
- *(April 25, 2022)* [#204 – Centenarians, metformin, and longevity](/nirbarzilai2/)

Nir Barzilai, Director of the Institute for Aging Research at the Albert Einstein College of Medicine, is back for his third appearance on The Drive. In this episode, Nir divulges insights into lifespan and healthspan through the lens of his extensive research on centenarians as well as the latest from the TAME trial (Targeting/Taming Aging with Metformin), a multi-center study investigating the concept that the multi-morbidities of aging can be delayed in humans. He discusses common gene variants found in centenarians, important pathways for longevity, and ultimately what we can learn from centenarians about extending lifespan while also trying to improve healthspan. Additionally, Nir goes into depth on metformin as a longevity tool for humans, including studies with positive and negative results. He discusses the impact metformin can have on exercise for both strength training and cardiovascular training, as well as future research facilitated by data from the TAME Trial. He also touches on epigenetic clocks and concludes with his take on the usefulness of NAD precursors as a potential gero-protective agent.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/nirbarzilai2/the_Drive_public.png)

Play

#204 - Centenarians, metformin, and longevity | Nir Barzilai, M.D.

#204 - Centenarians, metformin, and longevity | Nir Barzilai, M.D.

1x15s30s

0:002:29:33

## We discuss:

- Insights from genetic studies of centenarians and twins [3:00];
- Genes with protective variants that aid longevity [13:00];
- The relationship between growth hormone and IGF-1 [22:45];
- Use of growth hormone as a longevity tool [34:00];
- Longevity genotypes: the role of APOE e2, Lp(a), Klotho, and CETP [41:45];
- The correlation between high TSH and longevity [46:30];
- Important pathways for longevity [52:00];
- Insights from centenarian studies, nature vs. nurture, and more [59:00];
- The contraction of morbidity that comes with improved healthspan [1:08:00];
- Defining healthspan [1:13:13];
- Unique perspectives and positive attitudes of centenarians [1:17:30];
- Lessons to take away from centenarians [1:24:00];
- Metformin overview: history, studies, and potential for gero-protection [1:28:45];
- The TAME trial (Targeting Aging with Metformin) [1:39:00];
- The challenge of studying metformin in animals models [1:46:45];
- How data from the TAME trial could provide insights into biomarkers of aging and facilitate a future study on proteomics [1:53:30];
- The search for biomarkers to identify who can benefit from treatment [2:00:30];
- The impact of metformin on exercise, and finding the right indication for the use of metformin [2:10:30];
- Are NAD precursors geroprotective? [2:21:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Nir Barzilai is making his 3rd appearance on the podcast
  - He was previously on the podcast in [August 2020 with Joan Mannick](https://peterattiamd.com/joanmannick-nirbarzilai/)
  - He was originally on back in [January of 2019](https://peterattiamd.com/podcast/)
- In this episode, Nir and I speak mainly about two topics in much more detail than we’ve ever spoken about them before—  centenarians and [metformin](https://en.wikipedia.org/wiki/Metformin)
  - What can we learn from centenarians
- We talk about longevity genes such as: [GH](https://en.wikipedia.org/wiki/Growth_hormone)/[IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1), one [CETP](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein), [FOXO](https://en.wikipedia.org/wiki/FOX_proteins), [TSHR](https://en.wikipedia.org/wiki/Thyrotropin_receptor), and [ApoE](https://en.wikipedia.org/wiki/Apolipoprotein_E)
- We talk about whether or not environment matters at all in these individuals or whether it’s all genetic
- What can we learn from centenarians about the importance of preventing diseases?
- What can we learn from centenarians around extending lifespan while also trying to improve healthspan?
- We dive deep into Metformin and the [TAME trial](https://www.afar.org/tame-trial)
- Nir shares his thoughts on why the Rich Miller ITP program found metformin to be an unsuccessful net model and why he thinks that may or may not apply to humans
  - [Rich Miller was a guest on the podcast in February 2021](https://peterattiamd.com/richardmiller/)
- We talk about the impact metformin can have on exercise, both strength training and cardiovascular training
- Lastly, we speak a little bit about [epigenetic clocks](https://en.wikipedia.org/wiki/Epigenetic_clock)
- We end with a conversation around [NAD precursors](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Biosynthesis)
- Nir is a director of the [Institute for Aging Research at Albert Einstein College of Medicine](https://www.einsteinmed.edu/centers/aging/)
  - He is spearheading the [Longevity Genes Project](https://einsteinmed.edu/centers/aging/longevity-genes-project/about-the-study/), conducting genetic research on more than 500 healthy elderly people between the age of 95 and 112 and on their offspring
  - He’s also the director of the [Paul F. Glenn Center for the biology of human aging research](https://www.hms.harvard.edu/agingresearch/index.php/about)
  - And of the [National Institutes of Health Nathan Shock Centers for Excellence in the basic biology of aging](https://www.nia.nih.gov/research/dab/nathan-shock-centers-excellence#EinsteinAnchor)

## Insights from genetic studies of centenarians and twins [3:00]

**Centenarians**

*It is hard to compare generations*

- Peter notes that genes don’t seem to play a big role in people living to 70 versus 80, but when you start to talk about living to 90 versus a 100, genes play a pretty big role
- Nir notes that genetics don’t have a large impact in people living to 70 or 80
- It is problematic to compare the lifespan of fathers and sons (or mothers and daughters, or sons), consider this example:
  - Nir’s grandfather had a heart attack at 68 and died
  - Nir’s father had a heart attack at 68 and had a triple bypass; he died at 84
- Let’s say the correlation between age of death in different cohorts is 20%
  - If we really understand that 20%, we can use that to prevent the 80% impact of the environment

**Twin studies**

- Twin studies looking at the discordance and concordance of traits can help discern the role of genes in separate environments
- There are problems with twin studies
  - Twins are usually born small for their gestational age
    - Further, 1 twin is usually smaller than the other
  - Studies in rats where you ligate the uterine artery and make them small, they get diabetes, which they never get at 3 months
  - We know that babies that are born small for age, develop age related disease very rapidly; it’s called the [Barker’s hypothesis](https://en.wikipedia.org/wiki/Thrifty_phenotype)
    - This stems from the observation in Holland during World War II
    - [Epigenetic effects / imprinting](https://en.wikipedia.org/wiki/Genomic_imprinting) are involved
    - healthspan is decreased in the small twin
    - Many genes are involved but this hypothesis is not definitive
  - Nir doesn’t think twins are the right model unless you understand that and account for these effects

**Generics of centenarians**

- Compare a cohort of individuals who live to 80 to a cohort who lives to 100
  - What genes seem to offer protection to the group living to 100?
- There are 3 hypothesis:
  - 1) Longevity can be explained completely by the environment
  - This is the hypothesis that centenarians did everything exactly right
    - This is not true because 60% of men (30% of women) centenarians are smokers
    - 50% of centenarians are obese, don’t exercise, they’re not vegetarians
  - 2) Longevity is due to genetics
  - This is the hypothesis that centenarians have the perfect genome
    - Whole genome sequencing was performed for the first 44 centenarians in his study
    - There wasn’t a control (so we don’t know what the average person has)
    - They looked at [ClinVar](https://www.ncbi.nlm.nih.gov/clinvar/) (database of clinical variants / alleles responsible for disease)
    - They found 15,000 clinical variants in this initial analysis
    - To put this in perspective, there are around 20,000 coding genes in the human genome
    - Each centenarian had 5-6 bad variants (alleles responsible for disease); so this hypothesis isn’t true either
    - 2 centenarians were [homozygous](https://en.wikipedia.org/wiki/Zygosity#Homozygous) for [APOE4](https://en.wikipedia.org/wiki/Apolipoprotein_E); this confers one of the best known risks for Alzheimer’s, but they had no dementia at age 100
    - We know a lot of genotypes that put us at risk for age-related disease so maybe 1 out of 10,000 don’t have these [alleles](https://en.wikipedia.org/wiki/Allele)
    - This is the absence of bad genes (alleles) not the presence of good genes
  - 3) There are genes that slow aging, we call them longevity genes
  - This is the hypothesis that the presence of genes that protect against disease and slow aging are the reason for longevity
- Nir’s research has found a decrease also in bad genotypes in centenarians (some decrease), but really the majority of the study shows that it’s not the perfect genome, it’s something else
- Peter notes that the 3rd hypothesis is harder to demonstrate because there is probably a much smaller library of disease-sparing variants (alleles) as opposed to disease-causing variants

## Genes with protective variants that aid longevity [13:00]

- How are these protective variants discovered?
- Nir began to study this in 1998; one of the things he had to do is establish the phenotype
  - One of the phenotypes that came up is a very high level of [HDL cholesterol](https://en.wikipedia.org/wiki/High-density_lipoprotein)
    - This was more obvious in the offspring of the studied centenarians, more so than the centenarians
    - The offspring had HDL cholesterol levels 130, 140, fold higher than it should be
  - They got very compelling data on 2 genotypes that seemed to be functional important; they both were involved in controlling lipid metabolism
    - 1) A [CETP](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein) genotype
    - 2) An [APOC3](https://en.wikipedia.org/wiki/Apolipoprotein_C-III) genotype
    - A homozygous genotype for these variants occurred in 8-9% of controls and almost 20% of centenarians
- If a genotype is killing you then those genotypes will decrease in 80-90-year-olds
  - An increase in specific genotypes in 80 & 90 year olds suggests these genotypes have a role in longevity
  - This was his initial discovery
  - Drug companies were lining up to get in the market for people who live to 100
    - Peter comments, “*isn’t it amazing how big the graveyard is of* [*CETP inhibitors*](https://en.wikipedia.org/wiki/CETP_inhibitor)*?*”
    - Nir agrees and notes that he doesn’t understand it
    - The [podcast with Tom Dayspring](https://peterattiamd.com/tomdayspring3/) discussed this in great detail
    - Peter thinks it comes down to our lack of understanding of the biology of HDL
    - CETP inhibitors raised HDL, this reproduced the phenotype, but what were the other important physiological details
    - Some people with atherosclerosis have elevated levels of HDL
- Nir comments on the pathways that lead to high HDL; he thinks that larger particle size of LDL is what is important
- The 2 centenarians with [APOE4](https://en.wikipedia.org/wiki/Apolipoprotein_E#E4) genotypes both had very high HDL cholesterol and were homozygous for CETP
  - It’s possible that the major phenotype was not cardiovascular but instead was cognitive function/ physiology
  - Maybe there’s an effect on physiology from the perspective of the brain that is not yet understood

**Gene variants that seem to play a role in longevity**

- Peter asks about the variance of [*KLOTHO*](https://en.wikipedia.org/wiki/Klotho_(biology)), especially in those homozygous for APOE4
  - Having at least 1 copy of the *KLOTHO* variant seems to abrogate the effect of APOE4
- Klotho is an example of a V-shape or U-shaped genotype
  - Klotho seemed to kill 50% of subjects by age 85, but this phenotype disappears after this age
    - At age 100, centenarians born with Klotho also had other longevity genes, this made Klotho not significant
    - Another hypothesis is that Klotho is protective via another mechanism
  - Published in *Circulation Research* in 2005, [Association between a functional variant of the KLOTHO gene and high-density lipoprotein cholesterol, blood pressure, stroke, and longevity](https://www.ahajournals.org/doi/10.1161/01.RES.0000157171.04054.30?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed)
- Peter asks about other genes that Nir has found to be associated with longevity
- How did he come to study [*FOXO*](https://en.wikipedia.org/wiki/Forkhead_box_protein_O1)?
- *FOXO* came out of research from Japan and Okinawa
- Nir notes, “*the research now has changed very much the teams… because you need the computational and the AI people and the doctors and the physiology; it’s we*”
- In the mid 90’s, it became apparent that changing just 1 gene in a [nematode](https://en.wikipedia.org/wiki/Nematode) allows them to live 10x longer
- This gene was bugging him because it’s the [IGF (insulin-like growth factor) receptor](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1_receptor) gene and the nematodes were insulin resistant and they also had abdominal obesity
  - They accumulated fat in their intestinal cell
  - It wasn’t the right example but the concept was right
  - Review in *Experimental Gerontology* 2005, [The insulin/IGF-1 signaling in mammals and its relevance to human longevity](https://pubmed.ncbi.nlm.nih.gov/16168602/)
- This led him to study centenarians
  - He already discussed the first genes that he saw
  - This led him to write a grant

> “*Most of the grants that I wrote the hypothesis ended up being wrong, though we found the right explanations mostly*”— Nir Barzilai

- In 1 grant he proposed (knowing that it was wrong) that the growth hormone/ IGF signaling pathway has something to do with human longevity
  - They had the data from the nematodes
- He found 60% of their centenarians have genes that impairs the growth hormone/ IGF signaling pathway
  - This includes FOXO3a
  - 60%— it’s the most common genotype
  - It’s not only a genotypes by the way, there’s lots of ways to get to this
    - [microRNA](https://en.wikipedia.org/wiki/MicroRNA)
    - IGF receptor genotypes
    - Deletions of the growth hormone receptor

## The relationship between growth hormone and IGF-1 [22:45]

**Hundreds of genes are involved**

- There are hundreds of genes that contribute to growth
  - If you only look at what determines height, there’s hundreds of genes that are determining height (it’s a [complex trait](https://en.wikipedia.org/wiki/Complex_traits))
- [The growth hormone signaling pathway](https://en.wikipedia.org/wiki/Growth_hormone#Function) comes from the pituitary (controlled by the hypothalamus) and makes you grow when you need to grow
- Nir notes, “*I said growth hormone and IGF and I’ll stand by picking those two but for growth, there are actually hundreds of genes*”

**IGF-1**

- It has a specific action of binding to its receptor in the liver and releasing the second important growth hormone called [IGF-1 (insulin growth factor one)](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)
- The advantage of IGF-1 is that it’s measurable
  - Growth hormone is measurable in young people but not much in old people
  - IGF is a biomarker for the action of growth hormone
- IGF itself is really complicated because there are 5; and there are 7 binding proteins
  - And there’s a lot of regulation in between
  - But it’s true to say that levels of IGF are very good biomarkers even if you don’t agree that they’re causative for variety of health outcomes
- Nir also notes, “*in nature, the dwarves are doing better as far as longevity. The little dogs are doing better, the ponies are living longer and in animals, everyone, no matter how you interfere, you’re getting better longevity. Even the* [*Laron dwarves*](https://rarediseases.info.nih.gov/diseases/6859/laron-syndrome) *that have deletion of the* [*growth hormone receptor*](https://en.wikipedia.org/wiki/Growth_hormone_receptor)*, we don’t know if they live longer but at least they have less age related diseases like cancer or diabetes*.”
- Nir and colleague [Gil Atzmon](https://www.einsteinmed.edu/faculty/8649/gil-atzmon/) studied the growth hormone pathway and discovered that their centenarians had a deletion of [exon](https://en.wikipedia.org/wiki/Exon) 3 in the [growth hormone receptor](https://en.wikipedia.org/wiki/Growth_hormone_receptor)
  - 3% of the population are homozygous for this deletion but this rose to 12% in the centenarians they studied
- The IGF-1 levels were significantly lower in centenarians homozygous for deletion of exon 3 of the growth hormone receptor
  - Published in *Science Advances* in 2017, [The GH receptor exon 3 deletion is a marker of male-specific exceptional longevity associated with increased GH sensitivity and taller stature](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC5473676/)
  - But they were significantly taller than the rest of the people, by 2-3-inches
  - The relative [Z-score](https://en.wikipedia.org/wiki/Standard_score) difference between them and IGF showed a 20% decrease
  - There was nothing special about their IGF binding proteins
- Genetic differences need to be validated
  - Gil found 3 other studies that showed the same thing— the oldest people show a false difference in their growth hormone in this deletion
    - This was interesting; the question remains— why are they taller?
- Another collaborator, [Pinchas (Hassey) Cohen](https://gero.usc.edu/faculty/cohen/) (the Dean the gerontology school at USC) is a growth hormone expert
  - He studied [lymphoblasts](https://en.wikipedia.org/wiki/Lymphoblast) from their centenarians; these are cells grown in culture that can be studied
    - They were grown with and without growth hormone
  - They observed that growth in the absence of  growth hormone resulted in lower than expected activity of the growth hormone receptor
  - Growth of these cells in the presence of growth hormone resulted in increased phosphorylation (3x as much)
    - Proliferation was lowered
    - They don’t understand the switch mechanism
    - When they go through puberty, they are activating growth hormone; they are very sensitive to it and grow taller
    - Their growth hormone decreases after puberty but they are already taller
    - Their IGF stays low for the rest of their  lives
    - This occurs in 12% of centenarians

**The literature about growth and IGF is confusing** [29:30]

- Nir went to the [UK Biobank](https://www.ukbiobank.ac.uk/) to validate his hypothesis on IGF-1
  - This biobank has 440,000 people with IGF-1 measurements
- The [study](https://onlinelibrary.wiley.com/doi/10.1111/acel.13443) looked at young people with high IGF-1 levels
  - He noticed that high IGF-1 was protective from a variety of age-related diseases and from mortality (although not from cancer)
- But for people over 60, the relationship is the exact opposite
  - Those with high IGF-1 levels had more of every age-related disease except cancer
  - They had increased mortality
  - It was a linear relationship
- This contrasting effect in young versus older individuals is an example of the [antagonistic pleiotropy hypothesis of age](https://en.wikipedia.org/wiki/Antagonistic_pleiotropy_hypothesis)
  - Things that are good for you when you’re young can become bad for you when you are old
  - Growth hormone is needed for reproduction but after reproduction it needs to switch, growth doesn’t make sense
- Looking at the age of individuals when studying this literature made all the difference
- Peter asks about evolutionary pressures and when it makes sense for this flip to occur
- Nir notes that for evolution, he believes in the grandparent theory
  - But still if you have a child and died anytime afterwards, he thinks it’s too late for evolution
  - Secondly, there is the observation that people with exceptional longevity have fewer offspring
    - From an evolutionary point of view, they should be losing longevity genes

> “*Anybody with kids will immediately find that completely intuitive. They just suck all the life out of you*.”— Peter Attia

- Nir notes that maybe we are losing longevity genes because of reproduction

## Use of growth hormone as a longevity tool [34:00]

- Peter prescribes growth hormone to patients when they are healing from orthopedic injuries
  - He’s seen good literature that says if you tear a bicep and have surgery to repair it, taking growth hormone for eight weeks fosters rehabilitation better than if you did nothing
  - He’s prescribed this for maybe half a dozen patients, and they all say, “*I’ve never felt better*”
    - This helps him understand why there is a cottage industry of doctors out there who run longevity clinics prescribing growth hormone
    - Peter doesn’t think the literature shows any benefit of growth hormone for longevity
    - But he doesn’t think taking it will hurt either
- Nir thinks it’s important to consider the chronic environment
- He thinks this relates to [antagonistic pleiotropy](https://en.wikipedia.org/wiki/Antagonistic_pleiotropy_hypothesis) and is relevant to [TAME](https://www.afar.org/tame-trial) and [Metformin](https://en.wikipedia.org/wiki/Metformin)
- It’s possible that things that are good for you when you are young are bad for you when you’re old
- So many people when they should start taking geroprotectors, gero-therapeutics, vitamins,
  - The answer is, he doesn’t really know
  - You shouldn’t need [senolytics](https://en.wikipedia.org/wiki/Senolytic) before age 70 or 80
  - Metformin may be helpful
- In his study of Metformin, a large effect is seen in people recruited above the age of 50
  - He thinks maybe the answer is age 50
  - This is not clear based on the literature, based on clinical trials
- Peter supposes that there are hundreds of thousands of people in the United States alone who are taking growth hormone daily as part of a gero-protective regimen
  - Why aren’t they all dying prematurely? Assuming that they’re older
  - Nir replies that we don’t know if this is happening or not
  - People taking growth hormone are probably also taking Metformin, and exercising, and doing other things
  - So there are confounders to seeing this signal from just growth hormone
    - Nir wishes we had more data on this
- Nir notes another gray zone for him— most of the negative effect of growth hormone / IGF in humans is observed in females not males
  - This is true in animals too
  - There are 2 observations:
    - 1) [Sofiya Milman](https://www.einsteinmed.edu/faculty/12865/sofiya-milman/) measured IGF-1 in all of their patients
    - Published in *Aging Cell* in 2014, [Low insulin-like growth factor-1 level predicts survival in humans with exceptional longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC4116456/)
    - In centenarians, the IGF-1 level predicts longevity
    - 30% of centenarians die each year, but females with the lowest half of IGF-1 live 2x as long as those with the highest levels
    - 2) The ratio of female to male centenarians around the world is about 85 females for every 50 men
    - A lot of the female centenarians never got married
  - Women in the bottom quartile of IGF-1 levels live longer
    - There are no more likely to be sarcopenic (have muscle loss) than women with higher IGF
    - They have better cognitive function, they’re smarter
- Nir comments that he is not sure that low IGF is the best way to preserve muscle
  - Maybe it makes muscle biology better
- Similar trends are seen in males with lower IGF but it’s not significant

## Longevity genotypes: the role of APOE e2, Lp(a), Klotho, and CETP [41:45]

***APOE e2*** **allele**

- Having 1 cope of the [*APOE e2* allele](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) is the most common (and best validated) general longevity genotype we know
  - Review published in *The Journals of Gerontology* in 2019, [APOE Alleles and Extreme Human Longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC6298189/)
- The *APOE e2* allele is associated with disease too, so it’s not simple
- For a long time Nir thought they had [ascertainment bias](https://en.wikipedia.org/wiki/Sampling_bias) in their study
  - That they didn’t get people with *APOE e2* because they were demented and not participating in any studies
  - But further analysis and increasing the proportion of other genotypes in their study convinced him that the *APOE e2* phenomenon is real
- He doesn’t know the mechanism by which *APOE e2* contributes to longevity

**Lp(a), Klotho, and CETP**

- Peter asks about the [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) genotype in centenarians
- Nir agrees that Lp(a) in interesting
- He notes that people are losing [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology)) with age
- We are also losing a little Lp(a) and regaining it
- In computational biology studies (system biology), we have interacted every one of those bad genotypes with a longevity genotype
  - They found that centenarians with high Lp(a) are homozygous for the [CETP](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein) genotype
    - Peter notes that CETP may be a mechanism to protect against high Lp(a)
- Nir notes that Lp(a) is common, about 10% of the population overexpress it
  - It’s  true that evolution wasn’t selecting against atherosclerosis
  - But Lp(a) could have played a role in managing infections, for example
  - Or it could have been a manner in which we fought oxidative stress
  - So it begs to at least question the idea, do the centenarians who have it get some benefit from high Lp(a) while having genes that offset some of its negatives?
  - Peter questions how all of the sudden at age 85 a switch occurs allowing high Lp(a) to be protective
    - Or is it a denominator problem where at age 85 much of the population is eliminated and now you are looking at the people for whom high Lp(a) never caused harm
  - Nir agrees, this is one possible explanation
    - Another explanation is these people with high Lp(a) are protected by another longevity gene thereby making high Lp(a) irrelevant
  - Peter doesn’t think these 2 explanations are mutually exclusive
    - Nirs explanation would amplify the first explanation
  - Maybe these people have a CETP variant that offers protection against atherosclerosis, irrelevant of a high HDL cholesterol phenotype
    - Now when other with high Lp(a) have died, it’s these people who are left standing
    - Peter speculates that maybe high Lp(a) offers some benefit

## The correlation between high TSH and longevity [46:30]

- Nir found a correlation between high TSH and longevity
  - Published in *The Journal of Clinical Endocrinology and Metabolism* in 2009, [Genetic Predisposition to Elevated Serum Thyrotropin Is Associated with Exceptional Longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC2795660/)
- [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone) controls thyroid function in the sense that if you become [hyperthyroid](https://en.wikipedia.org/wiki/Hyperthyroidism), then this TSH, this hormone from the pituitary will increase in order to get those thyroid hormones to a normal level
  - And they might fail and then you’ll be hypothyroid
  - But there’s an effort to increase secretion of thyroid hormone from your glands
- Peter notes, when he sees a high TSH in a normal person, the first question he asks is if their thyroid gland is not making enough T4, or converting enough T4 to active hormone T3
  - This is the [feedback loop that tells the pituitary how much TSH to make](https://openstax.org/books/anatomy-and-physiology/pages/17-4-the-thyroid-gland)
- Nir has observed a higher amount of TSH in long-lived people and their children
  - This is a subclinical (or potentially clinical) degree of low thyroid function ([hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism))
- This discovery led the Thyroid Association to change their recommendation of what to do with old people
- TSH is increased in centenarians
  - Normal levels of TSH go up to 5 (4.2 in the lab Peter uses)
  - [Thyroid hormones](https://en.wikipedia.org/wiki/Thyroid_hormones) themselves are normal, normal free T3 and free T3
  - Only TSH is increased, to 5-8
    - Peter asks what these people’s TSH levels would have been at age 30 or 40
    - Nir is studying this; a lot of them have high TSH at age 60
- Nir notes that growth hormone deficiency models also have hypothyroidism; this physiology might be related
- Peter asks about [prolactin](https://en.wikipedia.org/wiki/Prolactin) and other [pituitary hormones](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary_hormone) that tend to move with TSH
  - Nir notes this is a good question
- The hypothesis is that the metabolism of these people is slow and maybe they’re compensating via higher TSH
  - He doesn’t think their data necessarily support the idea of low metabolism
  - But if an elderly person come in with at TSH between 5-8, he doesn’t think it needs to be treated straight away

## Important pathways for longevity [52:00]

- Nir notes that the genetic data is disappointing because most of it is not predictive
- He can find genes for obesity but people with those genes will have normal lipids
- He has investigated lots of genotypes and in trying to assess how much the increase the risk of disease he has found that usually it’s not by much
- He wants an instrument that will do [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) to longevity

> “*We’re doing something so stupid in genetics. We do lots of genotypes and we take each one of this genotype and we ask, is this associated with obesity or diabetes or not?*”— Nir Barzilai

- We are not building 1 genotype at a time; we’re built with numerous genotypes
- He has found many things, but to make them statistically significant he needs 100,000 more people in this study
- In his latest Nature paper he’s looking at the difference between centenarians and people without longevity
  - Published in 2019, [A meta-analysis of genome-wide association studies identifies multiple longevity genes](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC6694136/)
  - Centenarians are 1 out of 10,000, less than 1%
  - He’s going to study all those rare genotypes
    - There are 80,000 rare genotypes in our population alone

> “*We take those genotype and put them in pathways and look at the enrichment of the pathways rather than a specific genotype*”— Nir Barzilai

- From this study he saw that the genetics of longevity in humans is exactly what we learned from animals
  - It’s the [insulin signaling pathway](https://en.wikipedia.org/wiki/Insulin_signal_transduction_pathway), it’s the [mTOR signaling pathway](https://en.wikipedia.org/wiki/MTOR), it’s the [MET kinase pathway](https://en.wikipedia.org/wiki/C-Met)

- Many people complain that animal models are not good, not good for diabetes, Alzheimers, etc.
- But for aging, animal models are really good because of conserved evolution
  - Animals, their skin, their hair, their skeletal, they get cancers, they get diseases— it’s the same pathways

**IGF insulin-signaling pathway**

- The first pathway to come out of this was the IGF insulin signaling pathway; see the figure below
  - Published in *Aging Cell* in 2021, [The antagonistic pleiotropy of insulin‐like growth factor 1](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC8441393/)

![](https://peterattiamd.com/wp-content/uploads/2022/04/f1-nirb2.jpg)

**Figure 1.  Insulin / IGF1 signal transduction pathway.**  Image Credit: [*Diabetes* 2012](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC3357299/)

**Many genes should be considered to understand longevity**

- Peter notes this points towards the importance of [polygenic risk scores](https://en.wikipedia.org/wiki/Polygenic_score)
  - Peter and [Richard Isaacson](https://vivo.weill.cornell.edu/display/cwid-rii9004) (whose research focuses on understanding Alzheimer’s disease) are working on a paper looking at the polygenic assessment of risk for dementia
  - His thinking on this subject has evolved so much in the past 5 years
  - 10 years ago he would asy being homozygous for [*APOE e4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) is a death sentence (this is roughly 1% of the population)
  - But 5 years ago they looked at the dat again and realized it’s not 20x the risk of *APOE e3* but 12 x the risk
  - They have patients homozygous for *APOE e4* who don’t have Alzheimer’s disease or any of its early signs
    - They are starting to look at other genes that are abrogating some of the effects of this genotype
  - Now the focus has become less on *APOE e4*; they’re taking a polygenic approach
    - Looking at *APOE e4* plus: [TOMM40](https://en.wikipedia.org/wiki/TOMM40), mitochondrial haplotype, [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology)), etc
  - This polygenic approach seems like a logical way to approach longevity as well as cardiovascular disease
- Nir agrees, “*You describe the problem and the solution absolutely right*”
- 12 of the longevity genes he identified are associated with resiliency to Alzheimer’s
  - Published in *Nature Aging* in 2021, [Rare genetic coding variants associated with human longevity and protection against age-related diseases](https://www.nature.com/articles/s43587-021-00108-5)

> “*The genetics of resiliency, which is what we’re calling longevity*”— Nir Barzilai

- Peter asks, “*Would you put FOXO in that category as kind of a general resilience gene that is less disease specific and more broadly protective?*”
- Yes, Nir counts FOXO3A in the insulin IGF signaling pathway, see the figure above

## Insights from centenarian studies, nature vs. nurture, and more [59:00]

**Advantages of studying centenarians in a genetically homogenous population, Ashkenazi Jews**

- Nir has 750 centenarians in his study, they are all [Ashkenazi Jews](https://en.wikipedia.org/wiki/Ashkenazi_Jews)
  - This is important because they are genetically homogenous
  - This population went through a [bottleneck](https://en.wikipedia.org/wiki/Population_bottleneck) where very few survived; their population has since expanded
  - They live in isolation and intermarry
  - With this type of population we need between 20-50x fewer people to get the same data significance
    - A few thousand is enough
    - But it’s still not enough to find all longevity genes

> “*One of the things that we realize is that there are 50 ways to leave your lover. There are 50 ways probably to get to longevity*. ”— Nir Barzilai

- It’s possible there is only one person who’s 150 years old somewhere and if we knew his genotype it will solve the problem for anyone
- We have 20 genotypes in centenarians and 1 in the control group
- Once they identify a genotype the look at the function
- His friend [Yusin Su](https://einsteinmed.edu/faculty/10886/yousin-suh/) is looking into the function of the genotypes identified
  - She studying each genotype in cell culture to see how it impacts cell resiliency to injury
  - There are a lot of genes

**Going forward with new studies of centenarians** [1:01:00]

- The biggest news now is that the American Federation of Aging Research received $2.8 million from a single guy to recruit 10,000 centenarians across the United States and their offspring and controls
- This will accelerate our understanding of longevity and the development of getting drugs that promote longevity
  - And also discovery of things that we don’t know yet
  - Some of the things that we discovered are in pathways that were not in our lexicon of longevity
- Nir hired 2 companies who have different approaches to this study
  - And there’s a preliminary study to see what’s the best way to approach to enrolling people in this study
  - It’s all going to be basically web based
  - We need their children and grandchildren
  - We’re going to send them a swab so that they can take their sample (at least on the first pass), and we’ll be able to rapidly do the genetics
    - We’ll sequence both the [exome](https://en.wikipedia.org/wiki/Exome) and whole genome
    - He doesn’t know the cost of sequencing an exome
    - In his previous study [Regeneron](https://www.regeneron.com/) did that and paid for it
  - Then we’ll immediately post the data so people can start looking at it and making sense of it

**Peter’s thought experiment to understand the contribution of nature versus nurture to longevity** [1:03:15]

- There is someone out there who will live to 150 years old
  - That person that will concentrate all of these genes in perfection
  - And if we could look at that person’s genes, we might have an answer
- But maybe we’re discounting the stochastic nature of this
  - The likelihood that you’ll identify which environmental factors turned on those genes or amplified some and attenuated others seems very low
- If you took 10,000 identical people with whatever program you have of the perfect genotype
  - These people have as many of the good genes as possible and none of the bad genes
  - Put these people in a time capsule and let them live their lives but randomly divide them into 3 groups
  - 1) The base group gets to live a normal life
  - 2) This group does everything that’s bad
    - They start smoking at 15, drink 3 drinks a day, never exercise, only eat at McDonald’s
  - 3) This group does everything that’s healthy
  - What results would Nir predict?
- Nir replies, “*I was trying to do things simple and you complicate me again and I’m taking aback*”
- First, he thinks the maximum human lifespan for us as a species is about 115 years
  - Even if it’s 122 and most people die before the age of 80, we are talking about 35 years we can realize
    - 35 years is a long time
- Nir thinks aging will improve by other methods and mechanisms to allow us to eventually break through this 115 years and maybe get to 150
- Peter wants to understand, “*how, in the perfect genetic makeup, how much can environment hurt or better what is already a genetic lottery?*”
- Nir goes back to their discussion of APOE4 and how the initial finding of a 20-fold risk became smaller (12-fold)
  - Who were the people in which this risk became smaller and how were their lives different from those who were studied 20-40 years ago
  - This gets back to the earlier example of his grandfather and father who had heart attacks
  - The environment (what we do, medical treatment, etc.) has an impact

> “*We think that there are master switch to longevity and some of them we’re doing with exercise and food*”— Nir Barzilai

- He doesn’t have a good sense of how much longer the people in group 3 could live, doing all the right things with an amazing genotype
- Peter notes that at a macro level, most people don’t have many longevity genes
  - So the interesting question is, how much difference does the environment make?
- Nir notes that centenarians ask him, “*Okay, what can you do for me?*”
  - The question is, if those centenarians are willing to start exercising and change their diet, is it going to help them or hurt them?
  - He doesn’t know the answer

## The contraction of morbidity that comes with improved healthspan [1:08:00]

- Peter notes that [Thomas Perls](https://en.wikipedia.org/wiki/Tom_Perls) has written quite a bit about this idea
  - He describes 3 groups:
    - Escapers
    - Delayers
    - Survivors
- Nir notes that Tom Perls and [Paola Sebastiani](https://en.wikipedia.org/wiki/Paola_Sebastiani) have done terrific work; he is collaborating with them
- The average life expectancy is 80; some people are going to be 81, 80, 83
  - It’s not that 100 years old is special, but you want to study people who aged before or aged later
- What they have done together is to look at data in both studies and ask what is the healthspan of centenarians previously studied versus the way this cohort lives now
  - Centenarians get a variety of age-related diseases 20-30years later
  - In the control group, people accumulate a lot of disease between age  60-80
    - At 80 only 10% of them don’t have a disease
  - In the centenarians, after age 100, 30% of them don’t have disease
    - So that’s 20-30 years of healthspan
    - But at the end of their life, they too get sick and die
    - Some have a compression of morbidity, unlike most who are sick for years at the end of their life
- He thinks this is about the boundaries
  - First, there are humans that can live healthy and long and have contraction of morbidity
    - They have great health and a great life
    - They’re checking-out much quicker without diseases at the end of their lives
    - This is what we are trying to imitate
- Peter asks, “*could it be that the average person has their first heart attack at 70, languishes with congestive heart failure for 5 years and dies at 75. The centenarian has their first heart attack at 101 and they die 6 months later?*”
  - Could the reason that the younger guy languished for 5 years technically had more resilience given he was 25 years younger?
  - For a grim thought experiment, we could easily replicate the contraction of morbidity in non-centenarians with a rule that says, the moment you get a disease we’re not going to cure you, we’re going to kill you
    - This would immediately square everybody’s longevity curve
    - It would contract that period of morbidity to replicate what happens in centenarians
    - But it would dramatically truncate lifespan and widen the gap between non-centenarians and centenarians
  - For Peter it’s difficult to disentangle the objective
    - Do I want to lengthen lifespan
    - He does want to delay the onset of chronic disease
    - He does want to compress the period of morbidity, not by dying quicker but by having a longer, healthy life
- Nir notes this question (and Peter’s discussion about advocacy in previous podcasts) have stopped him from being an advocate

> “*I think that the reason that centenarians are dying so fast is because they’re already frail. They are aging, and so they are less resilient*.”— Nir Barzilai

- In these centenarians, without disease, some of them are working until age 107
  - They’re painting, they’re active as long as they have no pain and mobility
  - Their life is good, not like at age 20 but still good
- He agrees that if you prevent aging and age-related disease, you’re going to compress morbidity too

## Defining healthspan [1:13:13]

- Peter notes, “*one of the biggest challenges I have with healthspan is I don’t think that we have great ways of describing this in medicine*”
  - The definition isn’t wonderful
  - Freedom from disability and disease doesn’t really capture it
  - He knows plenty who don’t have a disability or disease but their healthspan is still poor
  - This excludes a very important element of healthspan, our emotional health
    - But let’s put this aside because this is not particularly age-dependent
  - You can have people who can still carry on activities of daily living but one of them has a [VO2 max](https://en.wikipedia.org/wiki/VO2_max) of 50 mL/min/kg and the other is 30 mL/min/kg
    - Those with a higher VO2 max can clearly get more out of life
  - You can take someone who has the grip strength to hang onto a bar for 30 seconds versus hang onto a bar for 2 minutes
    - Both of those people will see no immediate difference in their day-to-day activities
    - But one person can do far more, should they choose to
  - One person can sit on the floor for half an hour and play with kids and feel nothing; another person, their back will ache for the rest of the day
  - Secondly, nothing learned in medical training even remotely prepares us for how to help people be truly stronger late in life
  - His point is that it’s hard for him to really interpret the data and get at something he’s very interested in, “*which is do centenarians truly have better healthspan or are they just dying later, and for the most part, they have this period of compressed morbidity?*”
  - A 90 year old who will become a centenarian is functioning more like a 70 year old who will not, but this still very difficult to quantify
    - He doesn’t think we have great metrics here
- Nir agrees, healthspan is not well defined
- For the NIH reducing aging is preventing diseases
  - This is enough to get a drug approved
  - For a geriatrician and a physician, this is not satisfying
  - For an economist, there are 2 issues
    - 1) The medical cost of the last 2 years of life
    - CDC data on centenarians show their last 2 years of life cost a third of that for someone who dies in their 70’s
    - Peter notes this is a great statistic to capture the quality of a person’s life
    - 2) Their value, referring to an economical term Andrew Scott discussed in a Nature paper
    - Published in *Nature Aging* 2021,  [Achieving a three-dimensional longevity dividend](https://www.nature.com/articles/s43587-021-00074-y)
    - If you increase the health span of someone, consider not only medical cost
    - Because this guy is going to travel and spend money traveling and buy gadgets and buy houses for his kids
    - The value of the person life is going to be increased
    - The economical value is going to be huge

## Unique perspectives and positive attitudes of centenarians [1:17:30]

**Story about a 102-year old guy**

- He is the nicest guy; Nir is talking with him about his life
- When Nir leaves the room he bumps into the man’s son, who is 80
  - Nir tells him, “Y*our father is just the nicest guy I’ve ever met*”
  - The son looks him in the eye and says, “*You should have seen the son of a bitch when he was my age. He was a terrible, terrible person*.”
- Nir wrote a paper about the personality of centenarians and positive attitudes
  - But apparently this man only became positive when he was 100 years old, not when he was 80
  - Published in *Aging and Mental Health* in 2017, [Positive Attitude Towards Life, Emotional Expression, self-rated health, and depressive symptoms among centenarians and near-centenarians](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC5048681/)
- Then there are papers like one from the University of Pennsylvania; they took two groups of people, young and old people, and showed them bad pictures (cockroaches in pizza) and good pictures (islands in the Caribbean)
  - They asked them to repeat what they’ve seen
  - The young people remembered a lot, both bad and good
  - The old people remember less but mainly the good things

> “*So I’m waiting for this part in my physiology that I remember only the good things*”— Nir Barzilai

- What Nir is getting at is the complexity— your brain has aged, you are retired, you lost your spouse, you moved from independence or you moved to somewhere else, you get to be 100 years old
  - There’s changes, not only in your environment, but in your physiology
  - And life can still look good to you— is this wrong?
- Peter asks what fraction of the centenarians in his study were not married
  - They had to have children to be in the study
  - Most of them have lost their spouse though
  - A lot of them have lost children

**How long would you want to live?**

- Peter recalls a question someone asked him once, “*If you could wave a magic wand, how long would you want to live?*”
  - He replied, “*Not that long, truthfully, because unless I could wave that magic wand for the people around me, I think it would be an awful life*”
- What if Peter had a magic wand and said, “*Nir, you have immortality and not just immortality, I’m going to let you preserve your quality of life today. So as smart and healthy and able as you are now, I’m going to let you do this for the next 500 years*.”
  - Peter would view this as an awful curse because of all the people he would have to watch die
- This gets at something he had never considered for centenarians— “*is the price of being a centenarian… losing most of your friends; and how many funerals do you go to?*”
- Nir notes the most common thing a centenarian tells him is about losing the second generation, their children have died, the children of their friends have died
  - They ask, “*what’s coming next?*”
- Peter notes that centenarians have been adapting, not only because what got them to that age, but also being able to harbor and maybe put in compartments lots of stuff
- Nir replies that centenarians are not telling you about the spouse they lost (or other people); they’re telling you about where they went and what they do
  - They’re going to a concert, their grandchild is coming to visit them
- Peter comments, these centenarians have a gift, which is their great-grandchildren will know them
  - With a preserved healthspan, you can go to concerts (or on vacation) with your great-grandchildren
    - That’s amazing
    - Think about the implication of how much of their life you’ve been a part of
  - Most of his patient’s can’t tell them the names of any of their great-grandparents (we all have 8)
  - Centenarians will have lost many people in their life but they will also get to know more people

## Lessons to take away from centenarians [1:24:00]

- Peter also notes that he’s never really met somebody who is dying at the age of 75 who didn’t wish to have another year of life

**If we want to live an extra year (or 5), what are the most important lessons we can take away from centenarians?**

- Nir recalls the wrong lesson, from one of his darkest days in research
  - [Jay Leno](https://en.wikipedia.org/wiki/Jay_Leno) in [*The Tonight Show*](https://en.wikipedia.org/wiki/The_Tonight_Show_with_Jay_Leno) said, “*There’s those people at Einstein and they said, ‘The secret for longevity is don’t exercise, don’t … be obese.’… If you die, you don’t care anyhow*.”
- Nir knows a woman who smoked for 90 years and died at age 110
  - He wonders if she could have been the next [Madame Calment](https://en.wikipedia.org/wiki/Jeanne_Calment) (person with the longest, documented life; she died at age 122) if she didn’t smoke

> “*So the lesson for most of us is still exercise and nutrition*”— Nir Barzilai

- This not the lesson from centenarians
- The lesson from centenarians is that there are longevity genes that could be translated into drugs and Nir believes that they could afford years of health span
  - This is the clinical lesson, not the emotional lesson
- Peter notes, the superpower he sees in the centenarians is simply delaying the onset of bad things

> “*Bad things just happen to them 20 to 25 years later*”— Peter Attia

- The distribution of death for centenarians is shockingly similar to that of non-centenarians, with a couple of differences
  - They tended to have a little more atherosclerosis, a little more heart attacks, a little less Alzheimer’s disease, and a little more pneumonia
  - But directionally, they had the same actuarial table of death as people dying in their 80s
  - It’s just a time shift
- Nir reviewed the paper from Germany where they looked at pathology in 1000 centenarians who died in their homes
  - The title was funny because it was something to the effect, “*there’s nothing special about the centenarians*”
  - They’re dying for the same thing, but 30 years later
  - This misses the point; it’s like a negative study
- You can look at the resiliency of centenarians or the fact that their aging was slow

- Peter is interested in ultra primary prevention and how to live an extra 5 or 10 years
  - Not preventing the second heart attack
  - Preserving healthspan

## Metformin overview: history, studies, and potential for gero-protection [1:28:45]

- Peter gets questions several times a week about gero-protection from [Metformin](https://en.wikipedia.org/wiki/Metformin), [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) or some combination of [NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside), [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide), or [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide)

**Metformin**

- Nir is leading a Metformin study, but he’s not pushing Metformin
  - This is the difference between advocacy and science
- He has a method that works 100% of the time
  - Clinical data published in *Cell Metabolism* in 2016, [Metformin as a Tool to Target Aging](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC5943638/)
  - Mechanisms of action discussed in *Cell Metabolism* from 2020, [Benefits of Metformin in Attenuating the Hallmarks of Aging](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(20)30183-2)
    - The figure below summarizes action of metformin to blunt mechanisms that contributing to aging

![](https://peterattiamd.com/wp-content/uploads/2022/04/f2-nirb2-1018x1024.png)

**Figure 2. Mechanisms by which Metformin may combat aging.**  Image Credit:  [*Cell Metabolism* 2020](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(20)30183-2)

> “*The 3 best drugs in the world are nutraceuticals: Rapamycin, statins, and Metformin*”— Peter Attia

- Metformin is an extract of the French lilac; some people say it’s [nutraceutical](https://en.wikipedia.org/wiki/Nutraceutical)
  - It is modified and it is a drug
- An early form of Metformin was [Phenformin](https://en.wikipedia.org/wiki/Phenformin)
  - It’s impact on the mitochondria was a little too potent and caused trouble
- Metformin was used initially to treat the flu and malaria and inflammatory diseases
- Then people began to notice that patients with type 2 diabetes had lower glucose levels when they took Metformin
- So Metformin moved to diabetes diabetes treatment in the 1950’s-60’s
- In the United States, it was approved only in 1993 or so
- When Nir came in as a fellow to Ralph DeFronzo at Yale, his my mission was to describe the mechanisms of action of Metformin in humans
  - He did insulin clamps and was the first to describe that Metformin decreases hepatic glucose production rather than increased insulin sensitivity in the periphery
  - He did not think about it as aging
- There are billions, and billions of years of use for Metformin
  - Every patient takes it for years
  - Some people on Metformin are 90 years old
  - Nir cannot think of a drug with a better safety record
  - If there are any side effects to Metformin, they happen usually in the first week of use
    - Usually this occurs if you don’t take it the way you should, which is in small doses with food, when your stomach is full
    - But 3-5% will have diarrhea that won’t stop; they can’t take Metformin
    - In the TAME study, they are going to follow these patients who are sensitive to Metformin and see if there’s something unique about them
- 10 years ago, people started to notice that diabetics who take Metformin do better, when compared to diabetics who don’t take Metformin
  - They have lower mortality from all causes and also from very specific causes
  - The difference in mortality could be 50-80%
  - This is when curiosity began to peak that maybe Metformin has some protection against aging
- The base of gero-therapeutics has to be a drug that has effect beyond its disease, whether it’s on other diseases, whether it’s on overall mortality, not a disease-specific mortality
  - And fits that criteria Metformin exactly

**Clinical studies of Metformin**

- There are some association studies and clinical studies showing benefits of Metformin
  - The [Diabetes Prevention Program (DPP)](https://www.niddk.nih.gov/about-niddk/research-areas/diabetes/diabetes-prevention-program-dpp) is a NIH funded study where Metformin was one arm
    - There was also an arm of lifestyle changes
    - Both of them were preventing diabetes in about 30%
    - The study was stopped early because it was significant after 4 years, even though it was funded for 5 years
- Peter notes one of the problems with the DPP study is that the patients in the Metformin arm could easily fall out of that arm and therefore not be counted
  - So if they progressed to a need for medication beyond Metformin, or if they couldn’t tolerate Metformin, or if they were not compliant with Metformin, they were no longer counted
  - And this is true, not just of the DPP, but of course, when you compare the Metformin patients to the other patients who are taking other diabetes drugs, you always have this potential confounder, which is you are disproportionately selecting the healthiest people
    - These are the people who can be compliant with medications, which might say much more about their behaviors outside of medications whose diabetes is maybe just mild enough that it’s always kept at bay with Metformin and never requiring other medications, including insulin
  - Nir agrees with this criticism
    - Diabetes is a problem because it’s a progressive disease
    - You can go back to the data and show whether the people who were on Metformin from the beginning (versus others) have done better, and whether it stops… there’s a lot of things
- Peter asks if there are any clean examples of studies that demonstrate gero-protection of Metformin in humans?
- Nir replies that even the clinical studies are not perfect studies, but there are still enough of clinical studies (or small studies) that provide confidence
  - There are 2 studies of people with mild cognitive impairment that were treated with Metformin with some success
    - In 1, patients were treated for half a year
    - In another, patients were treated for 1 year, and some of the outcomes have changed
    - There is no different in how they were treated
    - They didn’t have diabetes, so it’s not that they switched to other medications
- If these studies (and other similar studies showing benefit of Metformin) were compelling enough you could argue that we wouldn’t need [TAME](https://www.afar.org/tame-trial)

## The TAME trial (Targeting Aging with Metformin) [1:39:00]

**Geroscience and the study of disease**

- There are studies for individual diseases of old age but there are no studies agnostic of disease

> “*We’re targeting aging. We don’t care what disease you have and we don’t care which disease you’re going to get*”— Nir Barzilai

- In geroscience we think aging is going to drive your next disease (outlined in the figure below)
  - Therefore it’s the cluster that is going to count; and we’re counting the clusters
  - You get a point for mortality, just like you get a point for a disease

![](https://peterattiamd.com/wp-content/uploads/2022/04/f3-nirb2.jpeg)

**Figure 3. Diseases of old age.**  Image credit: [American federation for aging research](https://www.afar.org/tame-trial)

- Imagine if reduction of cardiovascular disease comes up in the TAME study
  - The FDA will tell us to stop the study because we cannot continue with the placebo
    - This would ruin it for us
    - So the whole problem of the statistics of TAME is to make sure that we’re not getting a significant effect for any disease
    - We’re just focusing on trends, cluster of disease
  - If mortality is significant that will trigger an early end of the study as well
- Peter asks, “*So statistically, your biggest mistake here is overpowering the study for mortality and therefore appropriately powering the study for subsets of disease-specific mortality?*”
  - Yes

**Details of the TAME trial**

- This is a study that is going to look at people who do not have Type II diabetes, who are between the ages of 65-79
  - There are some other exclusion criteria (having cancer in the last year) but it’s not important for this discussion
- These these people are going to be taking statins; they’re going to be taking medication for blood pressure; some of them will be overweight; some of them will be normal weight
  - They don’t want to recruit future centenarians
  - These people need to have something to show their age
    - Such as a walking speed of less than 6 M/sec
    - They are not exceptionally fit
  - Peter compares it to the patient population that [PREDIMED](https://en.wikipedia.org/wiki/Predimed) started with
    - This was a primary prevention study for cardiovascular disease that found a statistical significant difference in under 5 years (but expected the study to go for 7 years)
  - You’re looking for people whose risk of death in the next five years is high enough that you’re going to move the needle [with Metformin]
- The risk of this patient group is you may get a negative study, which means there is no difference in all cause mortality or even disease-specific mortality
- And the counterargument might be that you started too late
  - That’s like applying the brakes on a car that’s driving towards a cliff, when it’s only 20 feet from the cliff
- Should this be a longer study where you start this at people when they’re 50 and your 5 year mortality expectation is very low?
  - Peter’s not saying this can be done because it’s a very expensive study
- Nir notes there are 2 arguments here
  - 1) Starting a study at 50 years old where you have to show mortality is going to be a 20-year study
    - This is too expensive
  - We need to start this study when people are starting to accumulate disease in order to have a lot of events
  - Our hypothesis is that the aging part of your biology doesn’t stop working when you’ve had your first disease
    - It’s still going to get your next disease
    - If we think biologically like that, we should be able to intervene quite late, as we do with animals
  - 2) There are Metformin studies which included elderly people and their results in prevention diabetes were similar to that of younger people
    - The DPP had 20% over the age of 60
  - There are several other studies that tell us that Metformin will still target aging even if you start it later
- Peter notes, if TAME shows a reduction in all cause mortality in older people, this would suggest biologically that there would be a benefit to starting sooner
  - But how soon?
- Nir clarifies that they are only looking at trends in mortality in TAME (not an endpoint of mortality)
- The primary outcome of TAME is to look at the cluster of cardiovascular disease, cancer, cognitive disease, and mortality
  - Patients get 1 point for each
  - Peter asks why mortality is given equal weight to disease occurrence, why wouldn’t it be 3 points?
  - Nir replies that each of these are an outcome, each incurs health spending

## The challenge of studying metformin in animals models [1:46:45]

- Peter notes that animal models look pretty good for aging
  - Even though they are not great for diseases like Alzheimer’s, cancer, and cardiovascular disease
  - But Metformin has had challenges in animal models
  - He and [Rich Miller](https://www.richmillerlab.com/) ([on the podcast last year](https://peterattiamd.com/richardmiller/)) talked about [ITP (intervention testing program)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp), where Metformin was successful in the ITP when combined with rapamycin, but alone, it was not
    - These are studies that are conducted using a particularly good model of mouse that is less troubled by the usual difficulties mice studies have
    - It’s also done independently at 3 laboratories concurrently
    - And they look at all cause mortality
  - He asks Nir, “*why Metformin did not succeed in isolation in the ITP study?*”
- Nir reflects on the big picture, “*It is possible that some of the drugs that had a mild effect in ITP will have much bigger effect in humans and maybe rapamycin is not going to be as effective in humans as it is in animals. We just have to accept it.*”
- Nir thinks one of the problems with animal studies is the dosage that they’re using, 0.1%
  - 1% is too much because Metformin is a weak cyanide; it binds to a complex in the mitochondria
  - It probably affects Complex I and also Complex III
  - If you give too much, its deadly
  - He doesn’t think 0.1% is the appropriate dose; there’s no dose response curve
    - Maybe 0.2% would be better
- Peter recalls [Rafael De Cabo](https://www.nia.nih.gov/research/labs/tgb)’s paper from 2013 about Metformin and the questionable data
  - Published in *Nature Communications*, [Metformin improves healthspan and lifespan in mice](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC3736576/)
  - There were 2 groups of mice
    - One of them getting 0.1% Metformin
    - One of them getting 1% Metformin
  - The group getting 1% were killed by the toxic of Metformin
  - The group getting 0.1% lived a staggering 4% longer
    - It was basically a null trial that was touted as the definitive animal study for why Metformin works

> “*It’s like an Onion article, when you disassociate the title from the actual data*”— Peter Attia

- Nir explains, when he makes a table with all the longevity data, the effect of Metformin across studies was between 7-10%; not a huge effect
  - Peter thinks 7-10% effect in animals, if consistent, is pretty good
- But the effect of Metformin on healthspan is much bigger
  - Prevention of cancers
    - The problem with animals (and centenarians too) is they die **with** cancers
    - We don’t know if they die **from** cancer
    - Peter compares this to the prostate cancer issue
- In humans, cardiovascular disease is probably the leading cause of death; for animals, it’s cancer
- When animals were given Metform in the ITP, they showed 10% increase in longevity at one center, 9% increase at another
  - But Rich Miller’s point was -2%
  - So Nir wonders if they were actually giving the same dose or what was going on
- Peter asks if we should care about mouse studies of Metformin now that we are moving to a human clinical trial; does it matter if the mice were treated with 0.1% or 0.2%
- No, Nir notes that preliminary data from humans show a 20-30% effect
  - This is really impressive
  - Once they have the data from TAME, he doesn’t know if they will need animal studies to discover more about Metformin

## How data from the TAME trial could provide insights into biomarkers of aging and facilitate a future study on proteomics [1:53:30]

- Peter asks if the $50 million budget of TAME will allow them to look at mitochondrial function and [omics](https://en.wikipedia.org/wiki/Omics) that are associated with other deeper markers that go beyond the hard outcomes that feed into the primary outcome
- The NIA had given them a grant (now delayed) to look at biomarkers as part of TAME
  - Even with $50 million from NIH they are able to store lots of plasma, DNA, and other resources
  - These will be available for omics studies
- Nir works with teams that have computational capacity such as [Xiao Dong](https://med.umn.edu/bio/ibam-faculty/xiao-dong)
  - Other look at functional genetics as well as [Yusin Su](https://einsteinmed.edu/faculty/10886/yousin-suh/) and [Sofiya Milman](https://www.einsteinmed.edu/faculty/12865/sofiya-milman/)
- The reason to have a big team is very simple, all he knew when he began was insulin; now he’s looking at billions of datasets
  - Consider just genetics, whole exome sequencing for 3000 people
  - Proteomics, 5,000 proteins for 1000 people

> “*It’s all big data. And in order to do something with the big data, you have to ask the right questions*”— Nir Barzilai

- The first paper that came out of the UK Biobank For Aging said that longevity is all about [assortative mating](https://en.wikipedia.org/wiki/Assortative_mating)
  - Published in *Heredity* in 2019, [Indirect assortative mating for human disease and longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC6781106/)
  - So if you’re a smoker, you marry a smoker
  - If you’re obese, you marry someone who is obese
  - If you’re poor, you marry someone who is poor
  - All of these have consequences on health

**2 questions important to Nir** [1:56:15]

- 1) What are the biomarkers for aging?
  - Can we do a test at 50 years old and know if we’re 40 or we are 60?
  - If we’re 40, we skip colonoscopy?
  - If we’re 60, we have to do something about it
- 2) Biomarkers change with treatment
  - We want to make sure that when we try all those treatments that we can get an answer (if they are working) in 2-3 months
- TAME is trying to address these questions

**Proteomics data point to proteins that play a role in protection from disease** [1:57:00]

- The [proteomics](https://en.wikipedia.org/wiki/Proteomics) data was incredible for many reasons
  - This was a study of 1000 people, looking at 5000 proteins
  - They asked what changed between the age of 65 and 95
    - This did not include their centenarians
  - Lots of proteins are changing but #1 was IGF-related proteins
  - A lot of what they saw was breakdown
    - Breakdown of collagen
    - Granulation of thrombocytes
    - Breakdown of extracellular matrices
- So he thought, “*We have to stop the breakdown. This is probably going to be the best marker for any treatment*.”
- The top 2 proteins with the most significance (10-80 significance), when you express them in animals, they live a long time
  - These are protective proteins
- With these protein results, you don’t know which are protective and which are causing problems and that’s a challenge
- The other observation from the proteomics study is that the [proteome](https://en.wikipedia.org/wiki/Proteome) of females is much more stable
  - Only half of the proteins are significantly changing in women as compared to men of the same age
  - So you’d need to look at different biomarkers for women and men
  - This was one of the eureka moments for them

> “*Females and males have different biology, as far as aging*”— Nir Barzilai

- Some gero-therapeutics work for both men and women, like Metformin and rapamycin
  - Maybe not equally
  - Others are totally sex-specific, [17 beta-estradiol](https://en.wikipedia.org/wiki/Estradiol)
- Of the 1000 people in his proteomics study, 500 were opus— offspring of parents with usual survival, no longevity in the family
  - 1 was opal— offspring of parents with exceptional longevity
    - They have half of the biomarkers of the control group, because they’re younger, they’ll get those biomarkers later

## The search for biomarkers to identify who can benefit from treatment [2:00:30]

- Nir doesn’t know if [methylation](https://en.wikipedia.org/wiki/DNA_methylation) is going to be the best biomarker for treatment
  - They’re stable; they’re going up and down but they’re stable
- He thinks proteomics are going to provide better biomarkers
- Metabolomics is very complicated
  - It depends on how you establish a sample
  - If someone is fasting more or less matters
  - Or if someone’s insulin level is more or less also matters
- Peter notes this is the same problem with biological clocks; it’s a terrible biomarker
  - They are easily to manipulate
  - He could get 5 copies of a biologic clock and do 5 different self-experiments and see a range of 20 years for his biological clock
  - Using fasting glucose and vitamin D levels to determine a biologic clock is useless on the individual level
- You need a metric that doesn’t change on a day to day basis
  - Fasting glucose can be 95 or 105 depending on what was eaten the night before and current cortisol levels
- Peter comments that he was interested in methylation until the [results of the twin astronaut brothers](https://www.nasa.gov/feature/nasa-s-twins-study-results-published-in-science) came out
  - 1 twin went to the international space station for a year and his twin brother stayed here on earth
  - Each of their methylation clocks were analyzed after a year and they were vastly different
  - This test was repeated 3 days after the twin brother was back on earth and the methylation patterns had changed to match his brother
  - To see such a change in 3 days makes peter wonder how biologically relevant this data can be
- Nir notes the research of [Morgan Levine](https://www.morganlevinelab.com/) on epigenetics and aging
- Peter bring up [Steve Horvath](https://ph.ucla.edu/faculty/horvath) who also studies epigenetics of aging
- There is something interesting in [epigenetics](https://en.wikipedia.org/wiki/Epigenetics) but Peter has a hard time seeing it
  - What is the purpose of characterizing this?
- With biomarkers, the purpose is clear— to guide therapeutics
  - You do a test to see if a therapy is making you better or worse
- Peter fears that no tests have been validated at a level that would give him any confidence
- Nir agrees, methylation is not mechanistic, he doesn’t think it will help with prescribing general therapeutics
  - The research of Morgan  Levinea nd Steve Horvath is very good, they’re responsible
  - Morgan has a mechanistic way of looking at epigenetics
    - If methylation has a function, she wants to cause methylation and see that there’s changes in gene expression

**Data gathered by the TAME trial**[2:05:15]

- Nir notes that in the TAME trial they will gather genome-wide epigenetic data to evaluate changes caused by treatment
  - They are not looking at clock epigenetics
  - When they do a methylation scan they can obtain clock information from them
  - The NIA (National Institute on Aging) will have RFA (request for application, for funding) for people who want to have sub-projects in relation to the samples collected by the TAME study
  - Those RFA’s can be in centers; for example, if a center wants to look at skin aging
  - There will be a process by which applications will be reviewed and people can look at the data for a variety of things
- One thing Peter would like to see is bone marrow sampling
  - He’s interested in the impact of immune function, specifically memory [T cell](https://en.wikipedia.org/wiki/Memory_T_cell) and [B cell](https://en.wikipedia.org/wiki/Memory_B_cell) function
  - He’s interested to know if Metformin is having any impact on immune function, because it plays a role in both infection and cancer
- Nir replies that they are not going to torture the elderly people in this study
  - They don’t want any excuse for them to leave
  - They are offering their offspring a MRI of their brain and a coronary CT
  - But they’re not doing biopsies in this study
- The TAME study is not doing brain MRI, at least not initially
  - The same goes for exercise function
- They have to first measure the outcomes
  - First you want to make sure the participants of TAME are taking their drugs
- The TAME study will have 3,500 subjects
  - They are starting with 14 centers that each have about 250 people, all in the US
- Peter asks if they will do [CPET testing](https://en.wikipedia.org/wiki/Cardiac_stress_test) every 3 months
  - Doing it every 2 yours would be an issue
  - At a minimum, he would look at fasting lactate levels or resting lactate levels
- Nir notes that everybody has a suggestion but he has to focus on what is practical

> “*I’m doing TAME not because I don’t believe in Metformin, because we need to have a target that’s similar to aging*”— Nir Barzilai

## The impact of metformin on exercise, and finding the right indication for the use of metformin [2:10:30]

**Peter’s experience with Metformin**

- Peter took Metformin for 8 years or so
- 3 years ago, when he began to constantly monitor his lactate levels (both in and out of exercise), he realized that his lactate levels were too high
  - His fasting lactate level was typically above 1 mmol (between 1-2 mmol)
  - His perceived mitochondrial efficiency was lower
  - If you take lactate levels in people at rest, there’s a high association between that value their general health
    - So the less healthy an individual is, the higher their lactate level is
- He realized that people taking Metformin are not exercising constantly and doing all the other things he was doing
  - So he decided not to take Metformin anymore until he had better data

**Studies of the impact of metformin on exercise**

- A couple of studies have shown impaired cardio-respiratory fitness in people taking Metformin
- Studies of the impact of Metformin on strength training show a mixed response
  - It does not appear to impact strength gains
  - It only appears to impact hypertrophy
- We know that strength matters more than hypertrophy in longevity
  - Discussed in a recent podcast, [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/)
- Peter asks Nir about the impact of Metformin on cardio-respiratory fitness and what he thinks about people who exercise a lot

> “*When we go from a drug that has certain capabilities to personalized medicine, all of a sudden it becomes about the person*”— Nir Barzilai

- Nir notes that lactate is one of the biomarkers used when prescribing Metformin, in every patient
- In 1987, when he did the Metformin study, lactate went from below 1 to above 1 in everyone who took Metformin
- He will be measuring lactate in the TAME study
- Peter notes that following lactate will be useful in determining compliance
- Nir notes there are other metrics to use to confirm that patients are taking Metformin
  - There’s a better test, it’s called [GDF15](https://en.wikipedia.org/wiki/GDF15)
  - It’s one of those peptides that goes up with aging
  - It’s a protective peptide
  - GDF15 goes 3-3.5-fold in people who take Metformin
- With regards to exercise, Nir makes the point that it’s not only about the muscle
  - Exercise improves brain function
  - Exercise decreases cancer
- Metformin had many other effects other than its effect on the muscle

**Metformin’s effect on muscle**

- With regards to muscle, research with [Charlotte Peterson](https://www.uky.edu/chs/cpete4)
  - Biopsies were taken from people who exercised and took Metformin and compared to people who only exercised
  - Published in *Aging Cell* inn 2019, [Metformin blunts muscle hypertrophy in response to progressive resistance exercise training in older adults: A randomized, double‐blind, placebo‐controlled, multicenter trial: The MASTERS trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826125/)
  - Published in *Aging* in 2020, [Metformin alters skeletal muscle transcriptome adaptations to resistance training in older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7655218/)
- Nir notes, in supplement figure 4 of her first study she showed that the strength of the muscle didn’t change, which means that you did better per gram muscle
- When you try to understand the biology it became clear that muscle needs to activate [mTOR](https://en.wikipedia.org/wiki/MTOR) to grow

> “*So mTOR is good for muscle and for muscle growth, it’s not good for aging*”— Nir Barzilai

- Metformin decreases expression of  mTOR
- On the other hand, transcriptome analysis showed other [transcripts](https://en.wikipedia.org/wiki/Transcription_(biology)) that had to do with inflammation, autophagy, and oxidative markers were upregulated in people taking Metformin and not in the exercise-along group
  - Published in *Aging Cell* in 2017, [Metformin regulates metabolic and nonmetabolic pathways in skeletal muscle and subcutaneous adipose tissues of older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5847877/)
  - So there were trade offs, you get less muscle [growth from exercise on Metformin], but the muscle is stronger
  - Studying the transcripts suggest that the muscle seems biologically younger too
- In Nir’s studies of biopsies from people who are old and young and with every treatment, they look to see if the intervention in old people causes the transcripts to resemble transcripts in young people… and it does
  - He’s tested many interventions: [resveratrol](https://en.wikipedia.org/wiki/Resveratrol), Metformin, [acarbose](https://en.wikipedia.org/wiki/Acarbose), exercise, and now he’s looking at fasting
  - They looked at changes in groups of transcripts
    - Did they increase or decrease?
    - Did they change to resemble those of young people or old people?
  - This was a 16-week trial
- Peter asks how this information would apply to a longer period of time in a non-intervention setting
- Nir notes that 4 months is a long period of time but it’s also a dynamic period of time in this experiment because they’re building muscle throughout that time
- In this experiment, Metformin resulted in transcripts that resembled those of young people
  - mTOR was increased by exercise

**Who will benefit from Metformin?**

- Peter wants to know about the differences in cardio-respiratory fitness
  - Metformin is a weak mitochondrial inhibitor
  - It seems that it would blunt cardio-respiratory fitness
- Would the net benefits of taking Metformin be positive in some people but maybe not for those who exercise a lot (because they are already getting so many other benefits from exercise)?
- Nir replies this gets back to the issue of when do we start Metformin or what is the biological age of those people who exercise and take Metformin?
  - He takes a very personalized approach [hence the need for good biomarkers]
  - For people who are biologically young and exercise, he doesn’t think they should take Metformin
- In Nir’s experience, taking Metformin in combination with fasting, he finds his capacity to exercise has increased significantly
  - He’s not measuring lactate or exercising the way Peter is
- Eventually they will find out specifically who can and cannot take Metformin
  - A personalized approach is better than simply making a generalization
- Peter has changed his practice over the past few years and now only reserves Metformin for people where there is an obvious indication
  - Such as a trace of insulin resistance, hyperinsulinemia that is not treated with exercise, nutritional changes, sleep, things like that
- Peter is interested in the results of the TAME study but worried that it won’t fully answer the question for his patient population
  - Because the population of the participants in TAME are not very healthy
  - They are selecting people who you would expect to have bad outcomes in 5 years

> “*I think it’s important to people listening to this to understand, we may not get the answer we want for them, for the healthy 40 year old person.*”— Peter Attia

**Primary goal of the TAME trial**

- Nir comes back to the point of the TAME study— to get an FDA indication for aging
- TAME will provide more and better biomarkers for aging
- This will allow drug companies to do testing at 2 and 3 months and find out if their drug is working, before a [phase III trial](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_III)
  - Pharmaceutical companies will jump in and they won’t make many mistakes
  - Think of a phase II trial for any diabetes treatment, this requires 12,000 people
  - With the information from TAME, now only 3,000 people are needed
    - These studies are going to be much, much cheaper

## Are NAD precursors geroprotective? [2:21:30]

- Nir has a problem understanding any geroprotective effects of [NAD precursors](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_III) (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/04/f4-nirb2-1024x401.png)

**Figure 4. Three precursors for NAD****+**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Biosynthesis)

![](https://peterattiamd.com/wp-content/uploads/2022/04/f5-nirb2-1024x408.png)

**Figure 5. Metabolic pathways that synthesize and use NAD****+**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Biosynthesis)

- When you give them to a animals, they do better
- When they were given in the [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) (intervention testing program), no benefit was observed
- When you give these drugs to people and try to follow it, you cannot measure it anywhere; you cannot measure a derivative of it
  - So where is the biology?
- [Joe Baur](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8216891) (a really good NAD biologist) thinks when we take NR or NMN, it goes to our [microbiome](https://en.wikipedia.org/wiki/Microbiome) and results in an indirect health benefit from that interaction
- He did a really good study, where he discovered that the NAD for the microbiome comes not from food, but from the gut walls
- Nir doesn’t understand the biology of it and worries it is a placebo effect
- One study he wants to do is a placebo control crossover with biopsies
  - He want to do it with NAD
  - He’s doing one now with intermittent fasting
- Nir started taking [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide) at one point
  - He noticed that his REM sleep improved a lot
  - He stopped taking it and his REM sleep wasn’t as good (so he restarted taking it)
  - Then he tried an expensive brand of NMN and his REM sleep didn’t return
    - So he’s not currently taking NMN
    - He thinks the preparation of it may loose activity over time
    - He doesn’t know which ones to recommend
  - All this is to say, he’s not convinced about the benefits of taking NAD precursors

§

## Selected Links / Related Material

**Previous podcasts with Nir Barzali:**

- [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](https://peterattiamd.com/joanmannick-nirbarzilai/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2020) | [0:45]
- [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Host Peter Attia, Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 7, 2019) | [1:00]

**TAME trial website**: [The TAME Trial: Targeting the Biology of Aging. Ushering a New Era of Interventions](https://www.afar.org/tame-trial) | afar (American federation for aging research) | [1:45, 37:00, 1:30:30, 2:05:15]

**Podcast with Rich Miller**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Host Peter Attia, Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 7, 2019) | [1:45]

**Nir is the director of the Institute for aging at Albert Einstein College of Medicine, website**:

- [Institute for Aging Research](https://www.einsteinmed.edu/centers/aging/) | Albert Einstein College of Medicine | [2:15]
- [Institute for Aging Research:  Longevity Genes Project](https://www.einsteinmed.edu/centers/aging/longevity-genes-project/) | Albert Einstein College of Medicine | [2:15]

**Longevity genes project website**: [Longevity Genes Project](https://einsteinmed.edu/centers/aging/longevity-genes-project/about-the-study/) | Albert Einstein College of Medicine | [2:15]

**Nir is the director of the Paul F. Glenn Center for Biology of Aging Research, website**: [Paul F. Glenn Center for Biology of Aging Research](https://www.hms.harvard.edu/agingresearch/index.php/about) | Glen Foundation For Medical Research | [2:30]

**Nir is the director of the NIH Albert Einstein College of Medicine Nathan Shock Center, website**: [Albert Einstein College of Medicine Nathan Shock Center](https://www.nia.nih.gov/research/dab/nathan-shock-centers-excellence#EinsteinAnchor) | [2:45]

**Podcast with Tom Dayspring discussed CETP inhibitors**: [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/) |  Host Peter Attia, Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 2018) | [16:15]

***KLOTHO*** **variant associated with both longevity and early-onset cardiovascular disease**: [Association between a functional variant of the KLOTHO gene and high-density lipoprotein cholesterol, blood pressure, stroke, and longevity](https://www.ahajournals.org/doi/10.1161/01.RES.0000157171.04054.30?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) | *Circulation Research* (DE Arking *et al.* 2005) | [19:45]

**Role of insulin/IGF-1 signaling in longevity**: [The insulin/IGF-1 signaling in mammals and its relevance to human longevity](https://pubmed.ncbi.nlm.nih.gov/16168602/) | *Experimental Gerontology* (M Rincon, E Rudin, and N Barzilai 2005) | [21:30]

**Deletion of exon 3 of the growth hormone receptor in 12% of centenarians**:  [The GH receptor exon 3 deletion is a marker of male-specific exceptional longevity associated with increased GH sensitivity and taller stature](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC5473676/) | *Science Advances* (D Ben-Avraham *et al*. 2017) | [25:45]

**Lower IGF-1 levels predicts longevity in females**: [Low insulin-like growth factor-1 level predicts survival in humans with exceptional longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC4116456/) | *Aging Cell* (S Milman *et al.* 2014) | [39:15]

**Role of APOE alleles in longevity**: [APOE Alleles and Extreme Human Longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC6298189/) | *The Journals of Gerontology* (P Sebastaini *et al.* 2019) | [42:00]

**High TSH levels are correlated with longevity**: [Genetic Predisposition to Elevated Serum Thyrotropin Is Associated with Exceptional Longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC2795660/) | *The Journal of Clinical Endocrinology and Metabolism* (G Atzmon *et al.* 2009) | [46:45]

**Difference between centenarians and people without longevity**: [A meta-analysis of genome-wide association studies identifies multiple longevity genes](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC6694136/) | *Nature Communications* (J Deelen *et al.* 2019) | [54:00]

**IGF-1 signaling could be harmful in older adults**: [The antagonistic pleiotropy of insulin‐like growth factor 1](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC8441393/) | *Aging Cell* (WB Zhang *et al.* 2021) | [55:30]

**Review of metabolic pathways involved in aging, Insulin and IGF-1 signaling**: [The Critical Role of Metabolic Pathways in Aging](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC3357299/) | *Diabetes* (N Barzilai *et al.* 2012) | [55:30]

**Review of longevity genes**:  [Genetics of extreme human longevity to guide drug discovery for healthy ageing](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC7912776/) | *Nature Metabolism* (ZD Zhang *et al*. 2020) |

**Longevity genes and study of polygenic risk of age-related disease**: [Rare genetic coding variants associated with human longevity and protection against age-related diseases](https://www.nature.com/articles/s43587-021-00108-5) | *Nature Aging*(JR Lin *et al.* 2021) | [58:00]

**The socioeconomics of longevity, Andrew Scotts’** ***Nature*** **paper**: [Achieving a three-dimensional longevity dividend](https://www.nature.com/articles/s43587-021-00074-y) | *Nature Aging* (AJ Scott 2021) | [1:16:45]

**Personality and positive attitude of centenarians**:  [Positive Attitude Towards Life, Emotional Expression, self-rated health, and depressive symptoms among centenarians and near-centenarians](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC5048681/) | *Aging and Mental Health* (K Kato *et al.* 2017) | [1:18:30]

**TAME trial, clinical data on the role of Metformin in improving longevity**: [Metformin as a Tool to Target Aging](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC5943638/) | *Cell Metabolism* (n Barzilai *et al.* 2016) | [1:31:30]

**Mechanisms by which Metformin may improve longevity**: [Benefits of Metformin in Attenuating the Hallmarks of Aging](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(20)30183-2) | *Cell Metabolism* (AS Kulkarni, A Gubbi, and N Barzilai 2020) | [1:31:30]

**Podcast with Rich Miller**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Host Peter Attia, Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 7, 2019) | [1:47:15]

**Rafael De Cabo’s paper on Metformin**: [Metformin improves healthspan and lifespan in mice](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC3736576/) | *Nature Communications* (A Martin-Montalvo *et al.* 2013) | [1:50:00]

**Role of assortative mating in longevity, study from the UK Biobank for Aging**:  [Indirect assortative mating for human disease and longevity](https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC6781106/) | *Heredity* (K Rawlik, O Canela-Xandri, and A Tenesa 2019) | [1:55:45]

**Podcast discussion of the importance of strength for longevity**: [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/)

 | Host Peter Attia, Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 20, 2021) | [2:12:00]

**Effect of metformin on muscle response to resistance training, Charlotte Peterson’s studies**:

- [Metformin blunts muscle hypertrophy in response to progressive resistance exercise training in older adults: A randomized, double‐blind, placebo‐controlled, multicenter trial: The MASTERS trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826125/) | *Aging Cell* (RG Walton *et al.* 2019) | [2:13:45]
- [Metformin alters skeletal muscle transcriptome adaptations to resistance training in older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7655218/) | *Aging* (AS Kulkarni *et al.* 2020) | [2:13:45]

**Transcriptome analysis of muscle and adipose biopsies in patients taking Metformin show benefit to pathways implicated in aging**: [Metformin regulates metabolic and nonmetabolic pathways in skeletal muscle and subcutaneous adipose tissues of older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5847877/) | *Aging Cell* (AS Kulkarni *et al.* 2018) | [2:15:00]

**Nir Barzilai’s TED talks**:

- [How to die young at a very old age](https://youtu.be/TsA4SHhUzt4) | Nir Barzilai | TEDxGramercy (September 30, 2014)
- [Nir Barzilai: Can we grow older without growing sicker?](https://www.tedmed.com/talks/show?id=624556) | TEDMED (2016)
- [Ageing is a treatable disease](https://youtu.be/XN7rLbCBO1c) | Nir Bazilai | TEDxBeaconStreetSalo (June 9, 2020)
- [How to stop, delay and even reverse aging](https://tedxgateway.com/portfolio/nir-barzilai/) | TEDx Gateway (May 21, 2021)

**Nir Barzilai’s book**: [Age Later: Health Span, Life Span, and the New Science of Longevity](https://www.amazon.com/Age-Later-Healthiest-Sharpest-Centenarians/dp/1250230853/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Nir Barzilai (June 16, 2020)

§

## People Mentioned

- [Gil Atzmon](https://www.einsteinmed.edu/faculty/8649/gil-atzmon/) (collaborator at Einstein) [25:30]
- [Pinchas (Hassey) Cohen](https://gero.usc.edu/faculty/cohen/) (growth hormone expert and Dean the gerontology school at USC) [27:30]
- [Sofiya Milman](https://www.einsteinmed.edu/faculty/12865/sofiya-milman/) (collaborator at Einstein) [39:15, 1:55:00]
- [Richard Isaacson](https://vivo.weill.cornell.edu/display/cwid-rii9004) (Professor at Weill Cornell Medical College, studies Alzheimer’s disease) [55:45]
- [Yusin Su](https://einsteinmed.edu/faculty/10886/yousin-suh/) (collaborator at Einstein) [1:00:45, 1:55:00]
- [Thomas Perls](https://en.wikipedia.org/wiki/Tom_Perls) (founding director of the New England Centenarian study and collaborator) [1:08:00]
- [Paola Sebastiani](https://en.wikipedia.org/wiki/Paola_Sebastiani) (collaborator at Boston University) [1:08:15]
- [Richard Miller](https://www.richmillerlab.com/) (Professor at the University of Michigan, studies aging) [1:47:15]
- [Rafael De Cabo](https://www.nia.nih.gov/research/labs/tgb) (Chief of the Translational Gerontology Branch at the NIH National Institute on aging) [1:50:00]
- [Xiao Dong](https://med.umn.edu/bio/ibam-faculty/xiao-dong) (computational biologist and collaborator at Einstein) [1:55:00]
- [Morgan Levine](https://www.morganlevinelab.com/) (Professor at Yale studies epigenetics of aging) [2:03:15]
- [Steve Horvath](https://ph.ucla.edu/faculty/horvath) (Professor at UCLA studies aging) [2:03:15]
- [Charlotte Peterson](https://www.uky.edu/chs/cpete4) (Professor at the University of Kentucky studies muscle physiology) [2:13:45]
- [Joseph (Joe) Baur](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8216891) (Professor at the University of Pennsylvania Perelman School of Medicine, studies aging and NAD) [2:22:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/04/bio-image-nirb2-500x500.jpeg)

##### Nir Barzilai, M.D.

Born in Israel, Dr. Barzilai graduated from The Ruth and Bruce Rappaport Faculty of Medicine at the Technion-Israel Institute of Technology in Haifa and completed his residency in internal medicine at Hadassah Medical Center in Jerusalem. He served in a refugee camp during the war in Cambodia (1979-1980) and built a nutritional village in the homeland of the Zulu (1983 – Kwazulu). He has completed 2 fellowships at Yale (metabolism) and Cornell (Endocrinoology and molecular Medicine). He  served as chief medic and physician in the Israel Defense Forces. He was an invited speaker to the 4th Israeli President Conference (2012) and a Vatican conference on efforts to enhance cures (2013, 2016). He has also taken part in Global initiatives and spoke at The Milken Global Institute, Asian Megatrends and is an advisor for the Prime Minister of Singapore on Aging. Dr. Barzilai has been on the ‘Forward 50, top 50 influential Jews in the US (2011). His work has been profiled by major outlets, including the New York Times, the BBC and PBS’ NOVA science now, TEDMED and several TEDx talk is the leading feature on the Ron Howard/Jonathan Silberberg/National Geographic film about the Age of Aging. He authored Age Later (2019).

Dr. Nir Barzilai is the director of the [Institute for Aging Research at the Albert Einstein College of Medicine](https://www.einsteinmed.edu/centers/aging/) and the Director of the [Paul F. Glenn Center for the Biology of Human Aging Research](https://www.hms.harvard.edu/agingresearch/index.php/about) and of the [National Institutes of Health’s (NIH) Nathan Shock Centers of Excellence in the Basic Biology of Aging](https://www.nia.nih.gov/research/dab/nathan-shock-centers-excellence#EinsteinAnchor). He is the Ingeborg and Ira Leon Rennert Chair of Aging Research, professor in the Departments of Medicine and Genetics, and member of the Diabetes Research Center and of the Divisions of Endocrinology & Diabetes and Geriatrics at [Albert Einstein College of Medicine](https://www.einsteinmed.edu/faculty/484/nir-barzilai/).

Dr. Barzilai’s research interests are in the biology and genetics of aging. One focuses on the genetic of exceptional longevity, where we hypothesize and demonstrated that centenarians have protective genes, which allows the delay of aging or for the protection against age-related diseases. In a Program he is leading we take full advantage of phenotypes, DNA, and cells from the Ashkenazi Jewish families with exceptional longevity and the appropriate controls and his group have established at Einstein (over 2600 samples of which ~670 are centenarians) and discovered underling genomic differences associated with longevity. [Longevity Genes Project (LGP)](https://einsteinmed.edu/centers/aging/longevity-genes-project/about-the-study/) is a cross-sectional, on-going collection of blood and phenotype from families with centenarian proband. [LonGenity](https://www.einsteinmed.edu/centers/aging/longevity-genes-project/) is a longitudinal study of 1400 subjects, half offspring of parents with exceptional longevity, validating and following their aging in relationship to their genome. The second direction, for which Dr. Barzilai is holding an NIH Merit award that focuses on the metabolic decline of aging, and his team hypothesize that the brain leads this decline. His lab has identified several central pathways that specifically alter body fat distribution and insulin action and secretion by intraventricular or hypothalamic administration of several peptides that are modulated by aging including: Leptin, IGF-1, IGFBP3, and resveratrol.

He has received numerous grants, among them ones from the [National Institute on Aging (NIA)](https://www.nia.nih.gov/), [American Federation for Aging Research](https://www.afar.org/), the [Ellison Medical Foundation](https://www.ellison-med-fn.org/), and [The Glenn Medical Foundation](https://glennfoundation.org/). He has published over 280 peer-reviewed papers, reviews, and textbook chapters. He is an advisor to the NIH on several projects and serves on several editorial boards and is a reviewer for numerous other journals. Dr. Barzilai is in the Scientific Director and on the board of the American Federation for Aging Research, is its co-scientific director, and has served on several NIA study section. He is also a founder of [CohBar Inc.](https://www.cohbar.com/), a biotech that develops mitochondrial derived peptides as therapy for aging and its diseases and of [Life Biosciences biotech](https://www.lifebiosciences.com/). Dr. Barzilai has been the recipient of numerous prestigious awards, including the Beeson Fellow for Aging Research, the Ellison Medical Foundation Senior Scholar in Aging Award, the Paul F. Glenn Foundation Award, the NIA Nathan Shock Award, the 2010 Irving S. Wright Award of Distinction in Aging Research and the IPSEN Longevity Prize (2016).

He is currently leading an international effort to approve drugs that can target aging. Targeting Aging with METformin ([TAME](https://www.afar.org/tame-trial)) is a specific study designed to prove the concept that multi-morbidities of aging can be delayed by metformin, working with the FDA to approve this approach which will serve as a template for future efforts to delay aging and its diseases in humans.

[[Albert Einstein College of Medicine](https://www.einsteinmed.edu/faculty/484/nir-barzilai/)]