# #03 – Ron Krauss, M.D.: a deep dive into heart disease

**Source:** [https://peterattiamd.com/ronkrauss/](https://peterattiamd.com/ronkrauss/)

---

Whenever I’m stumped on a patient case, or in my thinking about lipids, [Dr. Ron Krauss](https://www.chori.org/Principal_Investigators/Krauss_Ronald/krauss_overview.html) is one of the first people I turn to for insight. I’m not alone. Ron is recognized globally for his research into lipidology and has worn many hats in his career, including clinician, lipidologist, nutrition, genetics, and drug researcher. He received both his undergraduate and medical degrees from Harvard and is board certified in internal medicine, endocrinology, and metabolism. He’s currently the senior scientist and director of atherosclerosis research at Children’s Hospital in Oakland.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

My hope is that both the curious patient and the physician can get a lot out of this episode by being more informed about dyslipidemia and the interventions used to reduce the risk of atherosclerotic disease, cerebrovascular disease, and peripheral vascular disease.

![The Peter Attia Drive](images/ronkrauss/the_Drive_public.png)

Play

#03 - Ron Krauss, M.D.: a deep dive into heart disease

1x15s30s

0:001:56:04

## We discuss:

- The pathogenesis of atherosclerosis;
- How early atherosclerosis begins;
- Ron’s motivation for getting into lipidology;
- How reading an article series in the *NEJM* in 1967 had a profound impact on him and his career;
- The “battle” between LDL particle size and particle number;
- The use of statins;
- The role of chronic inflammation in atherosclerosis;
- Why niacin may have been unjustly dismissed as a therapeutic option;
- The HDL paradox: why drugs that raise HDL-C seem to elevate (or have little impact on) heart disease risk;
- Mendelian randomization: nature’s randomized trial;
- How PCSK9 inhibitors work and why they may be underutilized;
- Lp(a); and
- More.

## Show Notes

“Atherosclerosis is a multifocal, smoldering, immunoinflammatory disease of medium-sized and large arteries fuelled by lipids.” [[Falk, 2006](https://www.sciencedirect.com/science/article/pii/S073510970502872X#bib5)] [6:30]

What is the pathology and pathogenesis of atherosclerosis? [7:00]

What is the most common first presentation of heart disease? [10:15]

The different stages of atherosclerosis. [12:20]

When does heart disease begin? [12:40]

What is the biggest risk factor for heart disease? [13:40]

What’s the difference between cholesterol, lipoproteins, LDL-C, LDL-P, and ApoB? [15:40]

One of the greater drivers in the discordance between LDL cholesterol and particle concentration is metabolic syndrome. [25:00]

Does LDL cause heart disease? [30:45]

Taking into account time, and magnitude, of exposure of LDL concentrations. [38:30]

Cholesterol remnants. [42:00]

Ron worked at the NIH with Donald Fredrickson and Robert Levy. [42:45]

As a Med student (Ron had a family history of heart disease), Ron read [a series of five articles in the *NEJM*](https://www.nejm.org/doi/full/10.1056/NEJM196701052760107), that completely transformed him. Ron “made it his business” to come to the NIH and work with Fredrickson, Levy, and Lees after his medical training. [43:30]

![](https://peterattiamd.com/wp-content/uploads/2018/07/fredrickson-classification-table-1024x919.png)

###### Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Hyperlipidemia)

![](https://peterattiamd.com/wp-content/uploads/2018/07/familial-forms-of-hyperlipidemia-Relative_prevalence_of_familial_hyperlipoproteinemias-300x226.png)

**Figure. Relative prevalence of familial forms of hyperlipoproteinemia.**

###### Image credit: [Wikipedia](https://commons.wikimedia.org/wiki/File:Relative_prevalence_of_familial_hyperlipoproteinemias.png)

Ron wrote a review article on the history of lipoprotein research (Siri-Tarino and Krauss, 2016). [44:45]

“Anybody that’s seriously interested in this field,” Ron said, speaking about lipidology, “should probably understand its origins.” Ron said he received an email after the paper was published, from [Joe Goldstein](https://en.wikipedia.org/wiki/Joseph_L._Goldstein), [a Nobel Laureate for his work with cholesterol](https://www.nobelprize.org/nobel_prizes/medicine/laureates/1985/goldstein-facts.html), who told him that everyone who goes into lipid research should read [Ron’s paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5036374/).

“The remnants are probably the most pathologic particles of all.” [45:30]

Xanthomas. [46:00]

PCSK9 and PCSK9 inhibitors. [47:00]

Mendelian Randomization. [49:15]

LDL particle size and particle number. [52:00]

Small and *very small* LDL and how Ron’s testing a hypothesis that these very small particles may be secreted directly (rather than through the VLDL pathway). [1:01:15]

Can LDL-C / LDL-P / ApoB be too low? [1:02:30]

Statins. [1:04:45]

Dementia and desmosterol AUC of the ROC. [[Sato et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3276481/); [Attia, 2005](https://www.olarts.com/pdf/c175.pdf) for more info on AUC & ROC interpretation] [1:07:30]

Adverse effects of statins (different types of statins may have different side effects). [1:10:45]

Statins and diabetes risk. [1:13:00]

Ron was part of a consensus group on statin side-effects. The first paper came out in 2015 ([Stroes et al., 2015](https://academic.oup.com/eurheartj/article/36/17/1012/2465952)) on myopathy, and the second one just came out ([Mach et al., 2018](https://academic.oup.com/eurheartj/advance-article/doi/10.1093/eurheartj/ehy182/4987130)), and it describes the data related to diabetes, cognitive function, etc. [1:20:30]

What if statins reduce events, but not by lowering LDL? Maybe the benefits come from the endothelial health and/or inflammatory reduction? [1:24:15]

There was a trial ([Ridker et al., 2017](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914)) that said we can make no change to the lipoprotein, we can reduce inflammation (in a subset of patients with an elevated CRP, using canakinumab [[the CANTOS trial](https://www.cardiobrief.org/2017/08/27/cantos-validates-role-of-inflammation-in-heart-disease/)], a therapeutic monoclonal antibody targeting interleukin-1β), and see a lower rate of recurrent cardiovascular events. [1:26:00]

We may or may not see the same thing with methotrexate trial ([CIRT trial](https://clinicaltrials.gov/ct2/show/NCT01594333)) results (the study was stopped early, not based on any safety concerns) on the horizon. [[CardioBrief, 2017](https://www.cardiobrief.org/2018/05/21/nih-halts-large-cardiovascular-inflammation-reduction-cirt-trial/)] [1:26:00]

The JUPITER trial analyzed the associated benefit of LDL-lowering against CRP-lowering, a marker of inflammation. A potential double-whammy. Statins may have a unique ability to hit inflammation and LDL metabolism. [1:27:00]

How does Ron rate the strength of the evidence in primary prevention of statins in men and women? [MACE](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events) and death? [1:29:00]

Statins and cognitive function. [1:33:30]

Statins, muscle effects, and adverse effects on the mitochondria. [1:36:30]

Ron’s involvement with the last ATP panel (ATP IV), a part of the NIH, which handed it off to the American Heart Association and the American College of Cardiology. [[Stone et al., 2014](https://www.onlinejacc.org/content/63/25_Part_B/2889?_ga=2.237292809.84270705.1529761633-1958562193.1529761633)] [1:38:00]

Why niacin has fallen out of favor, and why Ron still uses it for patients. [1:40:45]

The HDL-raising effects of niacin are not protective. That’s the conclusion to take away. [1:43:00]

HDL function. [1:45:00]

Does niacin specifically target smaller LDL particles over larger particles? [1:46:30]

Lp(a). [1:47:45]

How statins and PCSK9 inhibitors can widen the discordance between LDL-C and LDL-P, lowering medium- and larger-size LDL particles, and have less of a therapeutic effect on smaller particles, and none on the very small LDL particles. [1:50:00]

§

## Selected Links / Related Material

- [Pathogenesis of Atherosclerosis](https://www.sciencedirect.com/science/article/pii/S073510970502872X#bib5) (Falk, 2006)
- [Stages of atherosclerosis: A Definition of Advanced Types of Atherosclerotic Lesions and a Histological Classification of Atherosclerosis](https://circ.ahajournals.org/content/92/5/1355) (Stary et al., 1995)
- [Atlas of Atherosclerosis Progression and Regression](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?ie=UTF8&qid=1526578233&sr=8-1&keywords=stary+atherosclerosis) by Herbert C. Stary
- [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | peterattiamd.com
- [Good Calories, Bad Calories](https://www.amazon.com/Good-Calories-Bad-Controversial-Science/dp/1400033462) by Gary Taubes
- [The Multi-Ethnic Study of Atherosclerosis (MESA)](https://mesa-nhlbi.org/) | mesa-nhlbi.org
- [Framingham Heart Study](https://www.framinghamheartstudy.org/) | framinghamheartstudy.org
- The LRC-CPPT: [The Lipid Research Clinics Coronary Primary Prevention Trial Results](https://jamanetwork.com/journals/jama/article-abstract/391065?redirect=true) (JAMA, 1994)
- MRFIT: [Multiple Risk Factor Intervention Trial](https://jamanetwork.com/journals/jama/article-abstract/377969?redirect=true) (JAMA, 1982)
- [The straight dope on cholesterol – Part VI](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-vi/) | peterattiamd.com
- [The Sortilin Pathway – A New Target for Reducing LDL and CVD Risk](https://www.lipid.org/sites/default/files/11-krauss_nla_maui_3-14.pdf) (Krauss .PPT, National Lipid Association)
- [All Low-Density Lipoprotein Particles Are Not Created Equal](https://atvb.ahajournals.org/content/34/5/959/tab-figures-data) (Krauss, 2014)
- [Atherogenic lipoprotein phenotype: A proposed genetic marker for coronary heart disease risk](https://www.ncbi.nlm.nih.gov/pubmed/2372896) (Austin et al., 1990)
- [Low-density lipoproteins cause atherosclerotic cardiovascular disease. 1. Evidence from genetic, epidemiologic, and clinical studies. A consensus statement from the European Atherosclerosis Society Consensus Panel](https://www.ncbi.nlm.nih.gov/pubmed/28444290) (Ference et al., 2017)
- Fat Transport in Lipoproteins — An Integrated Approach to Mechanisms and Disorders: [Part I](https://www.nejm.org/doi/full/10.1056/NEJM196701052760107) | [Part II](https://www.nejm.org/doi/full/10.1056/NEJM196701122760206) | [Part III](https://www.nejm.org/doi/full/10.1056/NEJM196701192760305) | [Part IV](https://www.nejm.org/doi/full/10.1056/NEJM196701262760406) | [Part V](https://www.nejm.org/doi/full/10.1056/NEJM196702022760507) (Fredrickson, Levy, and Lees, 1967)
- [A new apoprotein of human plasma very low density lipoproteins](https://www.ncbi.nlm.nih.gov/pubmed/4361735/) (Shelburne and Quarfordt, 1974)
- [The early years of lipoprotein research: from discovery to clinical application](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5036374/) (Siri-Tarino and Krauss, 2016)
- [Molecular Characterization of Loss-of-Function Mutations in PCSK9 and Identification of a Compound Heterozygote](https://www.cell.com/ajhg/fulltext/S0002-9297(07)62750-5) (Zhao et al., 2006)
- [Sequence Variations in PCSK9, Low LDL, and Protection against Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa054013) (Cohen et al., 2006)
- [Clinical Implications of Discordance Between LDL Cholesterol and LDL Particle Number](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070150/) (Otvos, 2011)
- [Clinical and pathophysiological evidence supporting the safety of extremely low LDL levels—The zero-LDL hypothesis](https://www.lipidjournal.com/article/S1933-2874(18)30014-X/fulltext) (Masana et al., 2018)
- [Statin-associated muscle symptoms: impact on statin therapy—European Atherosclerosis Society Consensus Panel Statement on Assessment, Aetiology and Management](https://academic.oup.com/eurheartj/article/36/17/1012/2465952) (Stroes et al., 2015)
- [Adverse effects of statin therapy: perception vs. the evidence – focus on glucose homeostasis, cognitive, renal and hepatic function, haemorrhagic stroke and cataract](https://academic.oup.com/eurheartj/advance-article/doi/10.1093/eurheartj/ehy182/4987130) (Mach et al. , 2018)
- [Low-density lipoprotein subclass patterns and risk of myocardial infarction](https://www.ncbi.nlm.nih.gov/pubmed/3418853) (Austin et al., 1988)
- [C-Reactive Protein: Eighty Years from Discovery to Emergence as a Major Risk Marker for Cardiovascular Disease](https://clinchem.aaccjnls.org/content/55/2/209) (Ridker, 2009)
- [Identification of a new plasma biomarker of Alzheimer’s disease using metabolomics technology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3276481/) (Sato et al., 2012)
- [Reduced plasma desmosterol-to-cholesterol ratio and longitudinal cognitive decline in Alzheimer’s disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4876914/) (Sato et al., 2015)
- [Hopkins General Surgery Review Manual](https://www.olarts.com/pdf/c175.pdf) (Attia, 2005)
- [Antiinflammatory Therapy with Canakinumab for Atherosclerotic Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914) (Ridker et al., 2017)
- [CANTOS Validates Role Of Inflammation In Heart Disease](https://www.cardiobrief.org/2017/08/27/cantos-validates-role-of-inflammation-in-heart-disease/) | cardiobrief.org
- [Cardiovascular Inflammation Reduction Trial (CIRT)](https://clinicaltrials.gov/ct2/show/NCT01594333) | clinicaltrials.gov
- [Methotrexate and Cardiovascular Protection: Current Evidence and Future Directions](https://journals.sagepub.com/doi/full/10.1177/1179559X17741289) (Mangoni et al., 2017)
- [NIH Halts Large Cardiovascular Inflammation Reduction (CIRT) Trial](https://www.cardiobrief.org/2018/05/21/nih-halts-large-cardiovascular-inflammation-reduction-cirt-trial/) | cardiobrief.org
- [ApoE4.Info: The Alzheimer’s Gene Reference](https://www.apoe4.info/wp/) | apoe4.info
- [2013 ACC/AHA Guideline on the Treatment of Blood Cholesterol to Reduce Atherosclerotic Cardiovascular Risk in Adults: A Report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines](https://www.onlinejacc.org/content/63/25_Part_B/2889?_ga=2.237292809.84270705.1529761633-1958562193.1529761633) (Stone et al., 2014)
- The JUPITER trial: [Rosuvastatin to Prevent Vascular Events in Men and Women with Elevated C-Reactive Protein](https://www.nejm.org/doi/full/10.1056/NEJMoa0807646) (Ridker et al., 2008)
- HPS2-THRIVE: [Effects of extended-release niacin with laropiprant in high-risk patients](https://www.nejm.org/doi/10.1056/NEJMoa1300955?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dwww.ncbi.nlm.nih.gov) (HPS2-THRIVE Collaborative Group, 2014)
- AIM-HIGH: [Niacin in Patients with Low HDL Cholesterol Levels Receiving Intensive Statin Therapy](https://www.nejm.org/doi/10.1056/NEJMoa1107579?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%3dwww.ncbi.nlm.nih.gov) (The AIM-HIGH Investigators, 2011)
- [Expression of human apolipoprotein A-I in transgenic mice results in reduced plasma levels of murine apolipoprotein A-I and the appearance of two new high density lipoprotein size subclasses](https://www.pnas.org/content/88/2/434) (Rubin et al., 1991)
- [Levels of Cholesterol in Small LDL Particles Predict Atherosclerosis Progression and Incident CHD in the HDL-Atherosclerosis Treatment Study (HATS](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0056782)) (Williams et al., 2013)

§

## People Mentioned

- [Tom Dayspring](https://truehealthdiag.com/leadership/thomas-dayspring/)
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman)
- [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes)
- [Donald Fredrickson](https://en.wikipedia.org/wiki/Donald_S._Fredrickson)
- [Robert Levy](https://nihrecord.nih.gov/newsletters/12_12_2000/obits.htm)
- [Robert Lees](https://imes.mit.edu/robert-lees-cardiologist-former-mit-professor-dies-82/)
- [Joseph Goldstein](https://en.wikipedia.org/wiki/Joseph_L._Goldstein)
- [Jim Otvos](https://en.wikipedia.org/wiki/Jim_Otvos)
- [Paul Ridker](https://en.wikipedia.org/wiki/Paul_Ridker)
- [Greg Brown](https://www.cecity.com/nla/enhance/brown.htm)

§

![](https://peterattiamd.com/wp-content/uploads/2018/06/Ronald-Krauss-image-bio-image-500x500.jpg)

##### Ronald Krauss, M.D.

Ronald M. Krauss, M.D., is the:

- Senior Scientist and Director of Atherosclerosis Research at Children’s Hospital Oakland Research Institute;
- Adjunct Professor in the Department of Medicine at UCSF and in the Department of Nutritional Sciences at UC Berkeley; and
- Guest Senior Scientist in the Department of Genome Sciences of Lawrence Berkeley National Laboratory.

He received his undergraduate and medical degrees from Harvard University with honors and served his internship and residency on the Harvard Medical Service of Boston City Hospital.

He then joined the staff of the National Heart, Lung, and Blood Institute in Bethesda, Maryland, first as Clinical Associate and then as Senior Investigator in the Molecular Disease Branch.

Dr. Krauss is board-certified in internal medicine, endocrinology and metabolism, and is:

- a member of the American Society for Clinical Investigation;
- a Fellow of the American Society of Nutrition and the American Heart Association (AHA); and
- a Distinguished Fellow of the International Atherosclerosis Society.

He’s a member of the U.S. National Cholesterol Education Program Expert Panel on Detection, Evaluation, and Treatment of High Blood Cholesterol in Adults, founder and past Chair of the AHA Council on Nutrition, Physical Activity, and Metabolism, and a National Spokesperson for the AHA.

Dr. Krauss has also served on both the Committee on Dietary Recommended Intakes for Macronutrients and the Committee on Biomarkers of Chronic Disease of the Institute of Medicine of the National Academy of Sciences.

He has received numerous awards including the AHA Scientific Councils Distinguished Achievement Award and the Centrum Center For Nutrition Science Award of the American Society for Nutrition, and he is listed in Who’s Who in America and the World.

Dr. Krauss is on the editorial boards of a number of journals and is Associate Editor of Obesity.

Dr. Krauss has published nearly 400 research articles and reviews on genetic, dietary, and drug effects on plasma lipoproteins and coronary artery disease.

In recent years Dr. Krauss’ work has focused on interactions of genes with dietary and drug treatments that affect metabolic phenotypes and cardiovascular disease risk. [[chori.org](https://www.chori.org/Principal_Investigators/Krauss_Ronald/krauss_overview.html)]