# #141 – AMA #18: Deep dive: sugar and sugar substitutes

**Source:** [https://peterattiamd.com/ama18/](https://peterattiamd.com/ama18/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob talk all about sugar and sugar substitutes and provide a way to think about sugar consumption. The conversation begins by defining the various forms of sugar, delineating between added sugar and naturally occurring sugar, and describing the important variables that determine the potential for metabolic damage from consumption. They then take a dive deep into three main categories of sugar substitutes—non-nutritive sweeteners, alcohol sugars, and leaving [allulose](/replacing-sugar-with-allulose/), in a class by itself—including the safety profile of each, impact on blood sugar and insulin, side-effects, taste preferences, and more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #18 show notes page](https://peterattiamd.com/ama18/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Delineating the various forms of “sugar” (2:00);
- Added sugar vs. naturally occurring sugar (12:30);
- Important variables related to sugar consumption: Density, volume, and velocity (17:00);
- Alternatives to sugar: Non-nutritive sweeteners (22:30);
- Alternatives to sugar: Alcohol sugars (34:15);
- Alternatives to sugar: Allulose (39:00);
- Contextualizing risk when it comes to sugar substitutes (45:00);
- Why some people report feeling better when eliminating non-nutritive sweeteners from their diet (46:30);
- The impact of sweetness—Cephalic insulin response and the metabolic drive to eat more (49:45); and
- More.

§

The Peter Attia Drive

Deep dive: sugar and sugar substitutes

§

## Show Notes

## Delineating the various forms of “sugar” [2:00]

Peter’s [Sunday email](https://peterattiamd.com/replacing-sugar-with-allulose/) on sugar, allulose, and other sugar substitutes

Peter’s [Sunday email](https://peterattiamd.com/191020/) about diet soda

\*\*\*

**Clarifying the nomenclature around the term “sugar”**

- Peter says he’s frustrated by the use of the term “sugar”
- It means a lot of different things, and all of those things can be true.
- For example, Glucose is a sugar. Galactose is a sugar. Fructose is a sugar. Sucrose is a sugar. Allulose is a sugar.
- Rather, Peter prefers to think about these things through the *lens of molecules* and their basic *attributes* and not through the most generic nomenclature of their existence

**Glucose and fructose**

- Glucose and fructose are monomers — they form the simplest building blocks of carbohydrates
- They even have the same chemical formula — same number of carbons, hydrogens, and oxygen (C6—six carbons, H12—12 hydrogens, O6—six oxygens)
- The difference is glucose is arranged in a six carbon ring, whereas fructose is arranged in a five carbon ring (and one of those carbons hangs outside the balance)
- This seemingly small difference “makes all the difference in the world”

> “All things equal, if you just have humans or mice or dogs or camels and force fed them glucose or fructose to their heart’s content, even though they’re the same chemical formula and very similar chemical structure, they would have dramatically different metabolic effects.” —Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2020/12/glucose-and-fructose.png)

**Figure 1. Glucose and fructose structures.** [[source](https://www.researchgate.net/profile/Lionel_Hebbard/publication/276208583/figure/fig1/AS:294518269202453@1447230035986/Glucose-versus-fructose-chemical-structure-A-The-hemiacetal-group-of-glucose-is.png)]

⇒ See podcasts with [Rob Lustig](https://peterattiamd.com/roblustig/) and [Rick Johnson](https://peterattiamd.com/rickjohnson/)

**Some differences**

- First of all, we rarely consume fructose by itself, and we very often consume glucose by itself
- A bowl of rice or pasta breaks down from more complex starches into simple monomers of glucose
- Whereas when you consume things that are sweet tasting — those foods contain fructose combined with a dose of glucose as well (e.g., an apple, some honey)
- As a general rule, the sweeter it is, the more fructose

> “Is glucose a sugar? Yes. Is fructose a sugar? Yes. Are they the same? Not even close.” —Peter Attia

**Sucrose and HFCS**

- Sucrose is one molecule of glucose and one molecule of fructose put together, covalently, giving you what’s called a disaccharide
- The easiest example of where sucrose exists is **refined sugar** out of things like canes and beets

![](https://peterattiamd.com/wp-content/uploads/2020/12/sucrose-1024x549.png)

**Figure 2. Structure of sucrose.** [[source](https://alevelbiology.co.uk/wp-content/uploads/2020/03/sucrose.jpg)]

*Introduction of* [*high fructose corn syrup*](https://en.wikipedia.org/wiki/High-fructose_corn_syrup) (HFCS):

- Around the 1970s, tariffs were added to sugar and then we introduced high fructose corn syrup
- And people sort of thought of fructose is almost like a health food
  - People would say honey, for example, was okay for diabetics because fructose doesn’t stimulate insulin secretion the way that glucose does
- At its conception, there was a really big spike in HFCS
- New technology turned sucrose into a solution (HFCS)–
  - the structure was changed to 45/55 in favor of fructose, so that made it a little sweeter
  - You could produce HFCS in unlimited quantities, solving a big problem for food manufacturers

**Current thinking by the public on fructose and HFCS**

- There probably still is a belief that fructose is better for someone with diabetes because you don’t have to chase it with insulin (notwithstanding the fact that fructose does so much for insulin resistance)
  - A topic covered exquisitely by both [Rob](https://peterattiamd.com/roblustig/) and [Rick](https://peterattiamd.com/rickjohnson/)
- Even so, there’s been a little bit of a revolt against HFCS
- The irony, however, is the belief that things that are more “natural” like dried mangoes and dates and “healthy”, as well as the belief that sucrose is any better for you than HFCS

## Added sugar vs. naturally occurring sugar [12:30]

**Understanding food labels**

- Food labels will list both sugar and added sugar (along with carbohydrates, fiber, etc.)
- Taking a look at dried mangos (commonly thought of as a health food):

![](https://peterattiamd.com/wp-content/uploads/2020/12/dried-mango-trader-joes-1024x553.png)

**Figure 3. Label of Trader Joe’s dried mangos.** [[source](https://www.traderjoes.com/fearless-flyer/article/5324)]

- - The only ingredient is organic mangoes (i.e., no added sugar)
  - One might be lulled into thinking there’s no “sugar” in this, but that’s not the whole story
  - This food has 24 grams of sucrose—which is “naturally occurring”—so they don’t have to put “added sugar” on the label

- *But does that make it “healthier” than a similar amount of sugar that is “added”?*

- Take a bottle of coke, for example, which may have a similar about of sugar, but all of it is “added”

*Is there really a difference?*

- The point here is that **neither of these are good options** — but the misconception is that the dried mango is somehow healthy and the coke is terrible
- There’s really no difference in the carbohydrate molecules of sugar found in fruits or HFCS but the **soluble fiber** in the (non-dried) fruit stabilizes blood sugar

> “Drinking [coke] is about the worst thing you can do. . .though I’m going to make the case that eating that bag of dried mango is a very bad thing to do. . .despite the fact that it’s pedaled as a health food.” —Peter Attia

## Important variables related to sugar consumption: Density, volume, and velocity [17:00]

**Recapping so far…**

- Sucrose is made up of glucose and fructose
- High fructose corn syrup is an additive
- Fructose and glucose metabolized differently
- Fructose accounts for more of the metabolic damage of sugar

**Important variables: Density, volume, & velocity**

**-Density**

- Consider a dried mango versus a whole mango, or prune versus the plum
- The density of sugar contained within it is higher, because you’ve got the same amount of sugar at a lower volume (aka quantity)

**-Volume**

- This could also be called “quantity” — i.e., what’s the actual quantity you consume?
- A thimble of Coca-Cola is of no harm to you, but a gallon of it is devastating
- One puff of a cigarette once a week has virtually no likelihood of increasing your risk of lung cancer, but smoking a pack a day absolutely does
- And so if you’re a person who can buy the Trader Joe’s bag of dried mango and eat one piece a day for 30 days, great… “*but I haven’t met that person yet*”

**-Velocity**

- How quickly do the molecules of sugar make their way out of the stomach and into ultimately the upper part of the duodenum, where they’re functionally going to come in contact with your liver? — *that is the question of velocity*
- With fructose, the “heavy lifting” from a metabolism standpoint is going to be done in the liver
- See [episode of The Drive with Gerald Shulman](https://peterattiamd.com/geraldshulman) for more on why the liver is such a key player in insulin resistance/metabolic syndrome

*Real life examples*:

- Dried fruit
  - You have a whole mango, and you simply dry it out (remove all the water), it’s just becomes a mass balance equation — it’s now much more **dense**
  - If all you’ve given up is water and going from a regular mango to a dried mango, what you’re probably changing is the **speed** with which it might hit the liver
  - Additionally, going from whole mango to dried mango allows you to consume much more (**volume**)
- Smoothies
  - Peter says smoothies are an example of when velocity/speed is a big issue
  - Smoothies and juicing are a “farce” and a “fiasco” because really your packing it so much fruit that would be impossible to eat whole and blending it into a liquid

**TIP**: Drink carbonated beverages (like bubbly water)

- Gatorade, for example, is a drink that you can just pound easily partially because it is not carbonated

***Exercise****: Can exercise help to mitigate the damage of eating the worst types of food?*

- Yes, it can
- However, at some point you will go past the metabolic breaking point (which Peter did personally even during his [ultra swimming days](https://www.youtube.com/watch?v=yMQFd9q07Zo))

## Alternatives to sugar: Non-nutritive sweeteners [22:30]

**3 main categories**

1—Non-nutritive sweeteners

- This means that they either don’t have calories, or they do have calories, but they’re so much sweeter than sucrose that you’re using them in micro doses

2—Alcohol sugars

- Their structure resembles an alcohol
- Some of them have more calories than others, and they have some advantages to them

3—Allulose

- A molecule that stands in its own place, which is itself a sugar.
- It meets all the sort of structural classifications of a sugar, but it doesn’t behave like sugar

**Non-nutritive sweeteners**

**1 –** [**Ace K**](https://en.wikipedia.org/wiki/Acesulfame_potassium)

- Found in [Tab soda](https://en.wikipedia.org/wiki/Tab_(drink)), a 1980s drink for people wanting to lose weight

- The FDA approved this in 1988
- Not much info on this, but there have been no reports of significant concerns
  - Acute consumption had no effect on glucose or insulin ([Steinert et al., 2011](https://pubmed.ncbi.nlm.nih.gov/21255472/))
  - Chronic consumption in humans not really studied but showed no effect on glucose or insulin in mice

**2 –** [**Aspartame**](https://en.wikipedia.org/wiki/Aspartame)

- Approved in 1981 (earliest of all artificial sweeteners)
- Brand names: NutraSweet, Equal, and Sugar Twin
- Methyl ester as its compound
- It’s *180 times* sweeter than sucrose (table sugar)
- It’s actually just as caloric as sugar, however, it’s a zero calorie compound at a functional level because it’s 180 times sweeter
  - One packet is ~37 milligrams of aspartame
  - A diet coke is ~200 milligrams — so basically has no caloric effect
- Two types of safety questions: i) *Are there any* ***acute*** *toxicities?*, and ii) *Are there any* ***chronic*** *toxicities?*
  - No compelling evidence to demonstrate that there is **chronic toxicity** associated with this
  - There’s really no compound that had been more scrutinized by the FDA going back to the 1960s than aspartame
  - Regarding **acute toxicity** — there’s no effect on glucose or insulin
    - That said, [one study](https://pubmed.ncbi.nlm.nih.gov/3298939/) did report a **cephalic insulin response** — there was a rise in insulin with a decrease in glucose prior to consumption
- **Taste**: Most people agree that aspartame doesn’t taste very natural

**3 –** [**Saccharin**](https://en.wikipedia.org/wiki/Saccharin)

- Brand name: Sweet’n Low (pink packet)
- Approved ~20 years ago
- 300 times more sweet than sucrose
- It has four kilocalories per gram, but again, functionally, you’re getting virtually nothing in terms of caloric intake
- There is absolutely no evidence of chronic or acute toxicity (e.g., no effect on glucose or insulin) associated with these things at the levels that humans consume them
  - A couple studies: [Skokan et al., 2007](https://www.researchgate.net/publication/5863289_Influence_of_Artificial_Sweetener_on_Human_Blood_Glucose_Concentration) and [Azari et al., 2017](https://pubmed.ncbi.nlm.nih.gov/28251932/)
- NOTE: There are [“misleading” studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1637197/#:~:text=Saccharin%20is%20carcinogenic%20for%20the,bladder%20carcinogenesis%20than%20female%20rats.) in rats showing it can cause cancer:
  - If you could make a rat eat an eighth of its body weight in saccharin a day, you could actually create problems for that rat (like cancer)
  - People took too much stock in these findings when the reality is that **the dose is what matters** — and people never approach that dose given to rats

**4 –** [**Sucralose**](https://en.wikipedia.org/wiki/Sucralose)

- Brand name: Splenda (yellow pack)
- Approved ~20 years ago, but took some time to become mainstream
- It is 600 times sweeter than sucrose
- It’s just as caloric as sugar, but again functionally no calories at the levels we consume
- Overall, there’s mixed evidence on its impact on glucose tolerance after acute consumption
  - [Some evidence](https://pubmed.ncbi.nlm.nih.gov/23633524/) that it’s more detrimental in someone who’s metabolically ill (e.g., someone with pronounced obesity may have reduced glucose tolerance following ingestion)

**5 –** [**Stevia**](https://en.wikipedia.org/wiki/Stevia)

- Peter calls it the least palatable of all of the non-nutritive sweeteners
- It’s naturally occurring in the plant called Stevia rebaudiana
- 200-300 times sweeter than sucrose
- Stevia has been “propped up” by the fact that it’s “naturally occurring”
- **Note on the designation of ‘naturally occurring’**: “*It doesn’t mean anything. There are lots of things that are naturally occurring that are harmless. There are lots of things that are naturally occurring that are harmful. Similarly, there are lots of things that are synthetic that are harmful. There are lots of things that are synthetic that are harmless. We really ought to not use naturally occurring as a branding tool.*”
- There’s limited evidence on stevia, but it **does not appear to pose any postprandial glucose or insulin impacts**, and therefore is generally regarded as a reasonable compound for people who are trying to avoid sugar ([Khan Ayob et al., 2014](https://www.researchgate.net/publication/271842614_Effect_of_Acute_Stevia_Consumption_on_Blood_Glucose_Response_in_Healthy_Malay_Young_Adults))

**6 –** [**Monk fruit**](https://en.wikipedia.org/wiki/Siraitia_grosvenorii)

- About 250 times sweeter than sucrose occurs in a plant
- Peter says this is the ***best tasting*** of all of the sweeteners
- It occurs naturally in the [luohan guo plant](https://en.wikipedia.org/wiki/Siraitia_grosvenorii)
- Limited evidence but Generally Recognized as Safe (GRAS) by the FDA
- [Mogrosides](https://en.wikipedia.org/wiki/Mogroside#:~:text=A%20mogroside%20is%20a%20glycoside,the%20manufacture%20of%20sugar%20substitutes.) are not absorbed in the upper gastrointestinal tract and do not contribute calorie
- When the compound reaches the colon, gut microbes cleave off the glucose molecules and use them as an energy source. The mogrol and some metabolites are then primarily excreted from the gastrointestinal tract, while minor amounts are absorbed into the bloodstream and excreted in the urine

![](https://peterattiamd.com/wp-content/uploads/2020/12/NNS-summary-1024x593.png)

**Figure 4. Non-nutritive sweeteners: Summary of findings.**

![](https://peterattiamd.com/wp-content/uploads/2020/12/NNS-upshot-1024x443.png)

**Figure 5. Upshot on acute and chronic effects of NNS.**

\*\*\*

⇒ Peter’s article about artificial sweeteners: [What are the side effects of aspartame, stevia, and other sugar substitutes?](https://peterattiamd.com/what-are-the-side-effects-of-aspartame-stevia-and-other-sugar-substitutes/)

## Alternatives to sugar: Alcohol sugars [34:15]

==> Peter’s [ice cream recipe](https://peterattiamd.com/make-ice-cream-keep-talking/) sweetened with xylitol

\*\*\*

**3 main alcohol sugars**

1. [Xylitol](https://en.wikipedia.org/wiki/Xylitol)
2. [Erythritol](https://en.wikipedia.org/wiki/Erythritol)
3. [Sorbitol](https://en.wikipedia.org/wiki/Sorbitol)

*Overview*:

- They are all monosaccharides — ‘naturally occurring’ things
- **Approval**: Erythritol was approved about ~20 years ago, whereas sorbitol and xylitol were approved in the 1980s
- Caloric values:
  - Sorbitol and xylitol are **caloric**
  - Xylitol is basically **matched in sweetness** to sucrose
  - Whereas sorbitol is actually about **half to two-thirds as sweet** as sucrose
  - In fact, sorbitol is not even a “low-calorie” food, because if you actually want to get the same sweetness, you’re actually going to bring the caloric value right up to that of sucrose
  - Erythritol, on the other hand, is actually quite a low-calorie sweetener because it’s about 0.2 kilocalories per gram and it’s almost as sweet as sucrose (60% to 80%)

**Comparing the 3 alcohol sugars**

*Erythritol*

- Very **efficiently absorbed** and renally excreted
- About [90% is excreted unchanged in the urine](https://www.tandfonline.com/doi/abs/10.1080/10408398.2019.1623757?journalCode=bfsn20), making it truly as close to no calorie alcohol sugar as you can consume
- It’s also the easiest on the gut

*Sorbitol*

- It’s very **poorly absorbed** which means you’re not actually getting the calories
- But you’re dealing with another problem with just 10 grams ([GI distress, diarrhea, etc.](https://link.springer.com/article/10.1007/s00217-015-2437-7)) — even requires a warning label for a possible laxative effect
  - For perspective, 1 stick of chewing gum would have 1-2g sorbitol per serving size

*–More on erythritol*

- Erythritol sort of emerged as a better alternative to sorbitol
- Some people do [report nausea](https://www.tandfonline.com/doi/abs/10.1080/10408398.2019.1623757), bloating, and even diarrhea with enough erythritol, but you really have to consume this in “Herculean doses” (like up to 75 grams) for this effect
- *Relevance for diabetic patients*: [Some evidence](https://www.tandfonline.com/doi/abs/10.1080/10408398.2019.1623757?journalCode=bfsn20) suggests that two weeks of daily ingestion of erythritol can decrease hemoglobin A1C in diabetics
  - Note: It’s hard to say if this reduction in HbA1c was due to the consumption of erythritol or whether it was a substitution effect (i.e., reduction in sugar in favor of erythritol)

*Xylitol*

- Xylitol can also result in some laxative effects — however, there’s a big range of side effects based on the individual — some people profound GI distress while others do not feel anything severe
- Glucose and insulin response to acute xylitol is similar to starch and lesser than sucrose or glucose: Consistent with this, xylitol (50 g) leads to a small but significant increase in glucose and insulin compared to water ([Wölnerhanssen et al., 2019](https://www.tandfonline.com/doi/abs/10.1080/10408398.2019.1623757?journalCode=bfsn20))
- *Interesting tidbit*: Xylitol may help to prevent dental caries/cavities
- **TIP from Peter’s dentist**: Anytime you eat something, chew a piece of xylitol gum for 10 minutes and then spit it out as a way to sort of get rid of it, even using a xylitol based toothpaste and things like that
- Note: Bob chews a lot of [Juicy Fruit](https://en.wikipedia.org/wiki/Juicy_Fruit), a sugar-free gum sweetened with xylitol

![](https://peterattiamd.com/wp-content/uploads/2020/12/alcohol-sugars-summary-1024x249.png)

**Figure 6. Alcohol sugars: summary of findings.**

## Alternatives to sugar: Allulose [39:00]

==> Check out Peter’s Sunday email on this topic: [Replacing sugar with allulose](https://peterattiamd.com/replacing-sugar-with-allulose/)

\*\*\*

**Overview**:

- [Allulose](https://en.wikipedia.org/wiki/Psicose) is actually a sugar (unlike the non-nutritive sweeteners or the polyols)
- It’s about 70% as sweet as sucrose
- It’s chemical structure is the mirror image of fructose (an [enantiomer](https://en.wikipedia.org/wiki/Enantiomer)) — a small difference that makes a HUGE impact

![](https://peterattiamd.com/wp-content/uploads/2020/12/allulose2.jpg)

**Figure 6****.** **Comparison of fructose and allulose structures.** [[source](https://chipmonkbaking.com/blogs/updates/our-sweeteners)]

When you ingest it, it’s fully absorbed by the intestines which means:

- i) you do not get any GI distress
- ii) It’s effectively completely excreted by the kidneys
- An animal [study](https://www.researchgate.net/publication/11346367_D-Psicose_Is_a_Rare_Sugar_That_Provides_No_Energy_to_Growing_Rats) in rats reported that allulose only contributes to 0.3% of the energy deposit in animals

More data from animal studies suggest that compared to fructose and/or glucose, allulose may…

- lower [blood glucose](https://www.tandfonline.com/doi/abs/10.1271/bbb.60036),
- [reduce abdominal fat](https://www.sciencedirect.com/science/article/abs/pii/S030881461201744X),
- [decrease insulin resistance](https://www.sciencedirect.com/science/article/abs/pii/S030881461201744X)
- [Decrease fat accumulation in the liver](https://onlinelibrary.wiley.com/doi/abs/10.1046/j.1440-6047.2001.00246.x); and
- Prevent or [delay the onset of type 2 diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4304484/)

*\*****But it also has another important effect***: A meta analysis of human studies shows that allulose may drag glucose with it, so when you consume it with food it [LOWERS postprandial glucose by an average of about 10%](https://www.sciencedirect.com/science/article/abs/pii/S0261561420301047#:~:text=Allulose%20significantly%20reduced%20the%20postprandial,%5D%2C%20P%20%3C%200.01).)

Taste and mouthfeel:

- It probably has the best taste and mouthfeel of any of these things
- It’s almost indistinguishable to sugar when you match it by quantity—so you have to plus it up by about 30-50%

Commercial use:

- Allulose has struggled to penetrate the market due to early classification as an “added sugar” on food labels
- For example, [Quest](https://www.questnutrition.com/) was using allulose in some of it’s [products](https://www.questnutrition.com/products/us-4-hero-bar-vanilla-caramel-box?_pos=1&_sid=944b0daa9&_ss=r) and were required to put “added sugar” on the food label
- Partly due to Quest’s efforts, the FDA changed that ruling no longer requiring “added sugar” to be put on the label
- In Oct 2019, FDA [announced](https://www.federalregister.gov/documents/2020/10/19/2020-22901/the-declaration-of-allulose-and-calories-from-allulose-on-nutrition-and-supplement-facts-labels) exemption of allulose from total and added sugars on nutritional label but adding 0.4kcal/g as carbohydrate

*Concern with bladder issues (like cystitis or even bladder cancer)?*

- If allulose drags glucose out with it, is there a chance that it could drag glucose out of one’s bladder resulting in a little increase in cystitis, at best, or something like bladder cancer, at worst?
- It turned out that’s not the case at all when you inductively reason the risk profile by referencing a [2019 meta-analysis study](https://pubmed.ncbi.nlm.nih.gov/30972917/) of sodium-glucose co-transporter-2 inhibitors (SGLT-2i) and cancer (Peter explains that [here](https://peterattiamd.com/replacing-sugar-with-allulose/))
- Peter says, “*I’m very comfortable with the safety profile of this.*”

**Cooking with allulose**:

- It does brown when heated making it challenging if you’re worried about the “look” of the end product
- But it does make a good alternative to sugar when baking sweet things (along with monk fruit)
- Peter, for example, made cranberry sauce with allulose for Thanksgiving
- If you need some inspiration as you embark on recipes with allulose replacement, [here](https://www.instagram.com/p/CCRXISxAtRI/) is one of Peter’s daughter Olivia’s allulose-sweetened cakes to whet your palate

## Contextualizing risk when it comes to sugar substitutes [45:00]

When making the decision as to which alternative to sugar you should consume…

- It really comes down to taste and preference, as there’s not much chronic or acute toxicity for any of them
- However, if you are in the “very risk averse” camp, you can probably feel best about aspartame because the amount of data we have on it is so overwhelming
- Epidemiology likes to bastardize things like diet Coke, but the reality is that diet Coke consumption is really just a proxy for people who are trying to lose weight
  - So when it says more people who drink diet Coke have diabetes than people who drink Coke, they’re missing something very obvious
  - Are the people who drinking diet Coke getting cancer disproportionately? “I think the answer here is overwhelmingly, ‘no’.”

> “Everything we do in life carries some risk and we should pay more attention to the types of risks that are measurable.” —Peter Attia

## Why some people report feeling better when eliminating non-nutritive sweeteners from their diet [46:30]

Why might people who go off of non-nutritive sweeteners sometimes report feeling better or losing weight?

- Peter’s experience with patients has shown numerous cases where a person stops drinking six diet Cokes a day and will get better/feel better

Possible explanations for this:

- 1 – All that aspartame in that situation was **revving up their appetite** and they were eating more elsewhere
  - So, by swapping diet Coke for bubbly water, or water, or coffee, or tea or something else, it reduced total caloric intake
- 2 – Some mechanism that pertains to the **gut biome**
  - A couple of papers out there that have actually postulated that things like aspartame or other non-nutritive sweeteners can disrupt the gut biome: Saccharin, sucralose, stevia have been studied to alter gut microbiota (more research needed) ([Ruiz-Ojeda et al., 2020](https://academic.oup.com/advances/article/10/suppl_1/S31/5307224), [Liauchonak et al., 2019](https://www.mdpi.com/2072-6643/11/3/644))
  - obviously that would be a very plausible explanation for why the response to reducing intake of non-nutritive sweetener is so heterogeneous (in a good way)
- 3 – A **psychological** component
  - People feel like “hey, now that I’m really cleaning things up and I’m not drinking this can of diet Coke, I’m going to make behavioral changes”
  - You can think of this as the [healthy user effect](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3077477/#:~:text=The%20healthy%20user%20effect%20The,partake%20in%20other%20healthy%20behaviors.)

**The upshot**:

- If anybody’s listening to this and they’re kind of plateaued somewhere in their health and they’re still drinking six diet Cokes a day, “I cannot strongly enough advocate that they stop it.”
- At least try to stop for a designated period of time (e.g., 90 days) to see how you feel
- “Because in the end, it doesn’t really matter what a study says. It matters what happens to you.”

## The impact of sweetness—Cephalic insulin response and the metabolic drive to eat more [49:45]

**Cephalic responses**

- Cephalic phase responses (CPRs) are [physiological responses](https://academic.oup.com/advances/article/11/5/1364/5855277) that occur in response to eating-associated cues (thought, smell, sight, taste) but before any actual nutrient absorption.
- Cephalic phase insulin responses (CPIRs) occur when the pancreas begins to secrete insulin before a meal actually gets into the bloodstream
- Because artificial sweeteners provide a sweet taste stimulus without subsequent carbohydrates, it is unclear how they would affect the CPIR.
- There is not a clear answer on whether or not cephalic responses to non-nutritive sweeteners will alter someone’s glucose metabolism, but it does appear that it can for some people ([Wiedemann, 2020](https://www.sciencedirect.com/science/article/pii/S0195666320300192))

**Literature on the impact of sweetness**

A recent [experiment](https://pubmed.ncbi.nlm.nih.gov/32574112/) by Rick Johnson knocked out the taste receptors in mice and gave them the option to drink various sweetened beverages (glucose, fructose, sucrose) and/or plain water

- The questions were: A) What are they going to prefer to drink? And B) What is the metabolic effect on them?
- They found that even when you knock out sugar sensing abilities, they still **prefer to consume a sugar sweetened beverage**
  - The explanation for this was based on the metabolic demands of sugar — essentially the way eating sugar (in the absence of fiber) requires energy to metabolize it you develop this short-term energy deficit which then drives you to consume more and more of it
- The other finding of that paper was the mice that lost their ability to taste—even when consuming less sugar than mice that retained their ability to taste—still got metabolic syndrome in a bad way

§

## Selected Links / Related Material

**Peter’s Sunday email covering sugar, allulose, and other sugar alternatives**: [Replacing sugar with allulose](https://peterattiamd.com/replacing-sugar-with-allulose/) | Peter Attia (peterattiamd.com) [3:00]

**Episode of The Drive with Rob Lustig that takes a deep dive into fructose**: [#14 – Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system](https://peterattiamd.com/roblustig/) | Peter Attia (peterattiamd.com) [6:15, 9:30]

**Episode of The Drive with Rick Johnson that takes a deep dive into fructose**: [#87 – Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com) [6:15, 11:45]

**Trader Joe’s dried mango ingredient label**: [Trader Joe’s Organic Dried Mango](https://www.traderjoes.com/fearless-flyer/article/5324) | (traderjoes.com) [13:00]

**For why the liver is such a key player in the context of sugar consumption see episode of The Drive with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [19:30]

**Scene from Back to the Future when Marty goes back in time and tries to order a Tab soda**.: [pepsi free.wmv](https://www.youtube.com/watch?v=xteH6y0Mr0k) | naglaw10 (youtube.com) [25:00]

**Acute consumption of Ace-K had no effect on glucose or insulin in healthy adults**: [Effects of carbohydrate sugars and artificial sweeteners on appetite and the secretion of gastrointestinal satiety peptides](https://pubmed.ncbi.nlm.nih.gov/21255472/) (Steinert et al., 2011) [25:15]

**Peter’s article about artificial sweeteners**: [What are the side effects of aspartame, stevia, and other sugar substitutes?](https://peterattiamd.com/what-are-the-side-effects-of-aspartame-stevia-and-other-sugar-substitutes/) | Peter Attia (peterattiamd.com) [27:15]

**One study did report a cephalic insulin response—a rise in insulin with a decrease in glucose—with aspartame**: [Cephalic phase metabolic responses in normal weight adults](https://pubmed.ncbi.nlm.nih.gov/3298939/) (Bruce et al., 1987) [27:30]

**Absolutely no evidence of chronic or acute toxicity (e.g., no effect on glucose or insulin) associated saccharin at the levels that humans consume them**: [28:30]

- [Influence of Artificial Sweetener on Human Blood Glucose Concentration](https://www.researchgate.net/publication/5863289_Influence_of_Artificial_Sweetener_on_Human_Blood_Glucose_Concentration) (Skokan et al., 2007)
- [Inhibition of sweet chemosensory receptors alters insulin responses during glucose ingestion in healthy adults: a randomized crossover interventional study](https://pubmed.ncbi.nlm.nih.gov/28251932/) (Azari et al., 2017)

**Some evidence sucralose may result reduced glucose tolerance following ingestion in people who are metabolically ill/obese**: [Sucralose affects glycemic and hormonal responses to an oral glucose load](https://pubmed.ncbi.nlm.nih.gov/23633524/) (Pepino et al., 2013) [30:10]

**Stevia does not appear to pose any postprandial glucose or insulin impact**: [Effect of Acute Stevia Consumption on Blood Glucose Response in Healthy Malay Young Adults](https://www.researchgate.net/publication/271842614_Effect_of_Acute_Stevia_Consumption_on_Blood_Glucose_Response_in_Healthy_Malay_Young_Adults) (Khan Ayob et al., 2014) [31:30]

**Peter’s ice cream recipe sweetened with xylitol**: [The Peter Attia Ice Cream](https://peterattiamd.com/make-ice-cream-keep-talking/) | Peter Attia (peterattiamd.com) [34:00]

**Sugar free gum that Bob chews**: [Juicy Fruit, Fruity Sugarfree Chewing Gum](https://www.amazon.com/Gum-Fruity-Sugarfree-Chewing-Pieces/dp/B00QT2ACY2) | (amazon.com) [36:15]

**Large analysis of alcohol sugars**: [Metabolic effects of the natural sweeteners xylitol and erythritol: A comprehensive review](https://www.tandfonline.com/doi/abs/10.1080/10408398.2019.1623757?journalCode=bfsn20) (Wölnerhanssen et al., 2019) [37:45]

**Peter’s Sunday email on allulose**: [Replacing sugar with allulose](https://peterattiamd.com/replacing-sugar-with-allulose/) | Peter Attia (peterattiamd.com) [39:00]

**Animal studies looking at the effect of allulose**: [39:30]

- An animal [study](https://www.researchgate.net/publication/11346367_D-Psicose_Is_a_Rare_Sugar_That_Provides_No_Energy_to_Growing_Rats) in rats reported that allulose only contributes to 0.3% of the energy deposit in animals
- More data from animal studies suggest that compared to fructose and/or glucose, allulose may

- lower [blood glucose](https://www.tandfonline.com/doi/abs/10.1271/bbb.60036),
- [reduce abdominal fat](https://www.sciencedirect.com/science/article/abs/pii/S030881461201744X),
- [decrease insulin resistance](https://www.sciencedirect.com/science/article/abs/pii/S030881461201744X)
- [Decrease fat accumulation in the liver](https://onlinelibrary.wiley.com/doi/abs/10.1046/j.1440-6047.2001.00246.x); and
- Prevent or [delay the onset of type 2 diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4304484/)

**Consuming allulose with food can lower postprandial glucose by an average of about 10%**: [Effect of fructose and its epimers on postprandial carbohydrate metabolism: A systematic review and meta-analysis](https://www.sciencedirect.com/science/article/abs/pii/S0261561420301047#:~:text=Allulose%20significantly%20reduced%20the%20postprandial,%5D%2C%20P%20%3C%200.01).) (Braunstein et al., 2020) [41:00]

**Product by Quest Nutrition that uses allulose**: [Hero Bars](https://www.questnutrition.com/products/us-4-hero-bar-vanilla-caramel-box?_pos=1&_sid=944b0daa9&_ss=r) | (questnutrition.com) [43:00]

**Saccharin, sucralose, stevia have been studied to alter gut microbiota (more research needed)**: [47:45]

- [Effects of Sweeteners on the Gut Microbiota: A Review of Experimental Studies and Clinical Trials](https://academic.oup.com/advances/article/10/suppl_1/S31/5307224) (Ruiz-Ojeda et al., 2020)
- [Non-Nutritive Sweeteners and Their Implications on the Development of Metabolic Syndrome](https://www.mdpi.com/2072-6643/11/3/644) (Liauchonak et al., 2019)

**Some evidence of cephalic phase response with non-nutritive sweeteners**: [Evidence for cephalic phase insulin release in humans: A systematic review and meta-analysis](https://www.sciencedirect.com/science/article/pii/S0195666320300192) (Wiedemann, 2020) [49:45]

**A recent paper that Rick Johnson’s group found that even when you knock out sugar sensing abilities, mice still prefer to consume a sugar sweetened beverage**: [Sugar causes obesity and metabolic syndrome in mice independently of sweet taste](https://pubmed.ncbi.nlm.nih.gov/32574112/) (Andres-Hernando et al., 2020) [51:15]

§

## People Mentioned

- [Cleon Daskalakis](https://en.wikipedia.org/wiki/Cleon_Daskalakis) [1:30]
- [Pete Peeters](https://en.wikipedia.org/wiki/Pete_Peeters) [1:30]
- [Doug Keans](https://en.wikipedia.org/wiki/Doug_Keans) [1:30]
- [Bill Ranford](https://en.wikipedia.org/wiki/Bill_Ranford) [1:45]
- [Andy Moog](https://en.wikipedia.org/wiki/Andy_Moog) [1:45]
- [Rob Lustig](https://robertlustig.com/) [6:15, 9:30, 11:45]
- [Rick Johnson](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) [6:15, 11:45, 51:15]
- [Rachel Harrus](https://www.linkedin.com/in/rachel-harrus-32633965/) [24:00]
- [Marty McFly](https://en.wikipedia.org/wiki/Marty_McFly) [25:00]

§