# #08 – Tom Bilyeu: nutrition, fasting, meditation, mindset, immortality, and the secret formula of fulfillment

**Source:** [https://peterattiamd.com/tombilyeu/](https://peterattiamd.com/tombilyeu/)

---

Tom Bilyeu is the founder of Impact Theory and a co-founder of Quest Nutrition. In this episode, among the highlights, Tom provides powerful insight he’s gained through his pursuit of fulfillment which led to a billion dollar company in Quest Nutrition. Tom makes a compelling case that it starts with a growth mindset and he’s determined to impart this knowledge to as many people as possible.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tombilyeu/the_Drive_public.png)

Play

#08 - Tom Bilyeu: nutrition, fasting, meditation, mindset, immortality, and the secret formula of fulfillment

#08 - Tom Bilyeu: nutrition, fasting, meditation, mindset, immortality, and the secret formula of fulfillment

1x15s30s

0:001:38:13

## We discuss:

- Tom’s history with dieting and his changing views on fat [4:00];
- Tom’s dream of immortality [10:00];
- Life leading to Quest Nutrition and how “mindset” made the difference [18:45];
- Why Tom started Quest Nutrition and what made it a success [27:00];
- Why Tom started Impact Theory [35:00];
- Money and motivation [44:00];
- What Tom learned interviewing every employee at Quest, and the one question everyone answers exactly the same [54:15];
- Tom’s secret formula of fulfillment and the ubiquity of suicide [1:00:00];
- Nutrition, fasting, sleep, meditation and other routines Tom uses to function at his best [1:13:15]; and
- More.

§

## Show Notes

### Tom’s history with dieting and his changing views on fat [4:00]

- For years, Tom was “fat-phobic” and adhered to a high protein (80%+), “rabbit starvation” diet of 1,200-1,500 total kcals per day
- Looked great, but struggled with chronic wrist pain
- Met with Peter and Dom D’Agostino (5 years ago) who convinced Tom fat was not the enemy
- Tom tried a 4:1 ketogenic diet (4 grams of fat for every 1 gram of protein+carb: see Figure 1 in the [Dom D’Agostino show notes](https://peterattiamd.com/domdagostino/) for more information) and after 5 days his wrist pain completely disappeared (“…a drug-like effect”)

### Tom’s dream of immortality [10:00]

- Does Tom *really* want immortality?
  - “Yes, without question…definitively”
- Peter believes death creates urgency (cf. Steve Jobs quote in the [D.A. Wallach show notes](https://peterattiamd.com/dawallach/))
- Tom’s internal battle is “I don’t have enough time” and believes immortality would give him more time to pursue all his passions rather than having to pick and choose
- Book recommendation: [Einstein’s Dreams](https://www.amazon.com/Einsteins-Dreams-Alan-Lightman/dp/140007780X/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=)

### Life leading to Quest Nutrition and how “mindset” made the difference [18:45]

- Tom went to USC film school and earned great grades, but bombed his senior thesis
  - He felt like a failure because he had a “fixed” mindset (the belief that basic qualities, like intelligence or talent, are fixed traits that cannot be developed) (cf. [Mindset](https://www.amazon.com/Mindset-Psychology-Carol-S-Dweck/dp/0345472322) by Carol Dweck)
- A game-changing moment came when Tom discovered through voracious reading that certain mechanisms in the brain allow for learning and growth throughout life
  - This was the beginning of Tom developing a “growth” mindset (the understanding that abilities and intelligence can be developed)
- Tom met [Ron](https://entrepreneur.wiki/Ron_Penna) and [Mike](https://www.linkedin.com/authwall?trk=gf&trkInfo=AQHtnBfs_mcxOAAAAWTyEI-oTjLayI3KgvXniYgDAm3LPnSLo8RJZgpBJoh3VKlfZo5xAf5QB6s7Mk1ZefwgH18K30jNG7bACraF4rQSRBYO9Om0fFRIIVUs1HLvF1cY6H0vC4E=&originalReferer=&sessionRedirect=https%3A%2F%2Fwww.linkedin.com%2Fin%2Fmike-osborn-0699b964), two high-standards individuals who fostered an environment of learning, growing, getting stronger and better
- Tom created [Awareness Technologies](https://en.wikipedia.org/wiki/Awareness_Technologies) (2002) with Ron and Mike, and in 2009 started working full-time on developing [Quest Nutrition](https://www.questnutrition.com/)

### Why Tom started Quest Nutrition and what made it a success [27:00]

- Awareness Technologies made him rich, but not happy (“living the cliché”), he needed to do something he was passionate about
- Tom was passionate about health and nutrition, going through his own transformation through diet and exercise, while also being concerned about the obesity epidemic, which was afflicting members of his own family
- Quest Nutrition started with an underlying infrastructure that emphasized:
  - Value creation
  - Community building
  - Helping people lose weight
  - A noble mission to end metabolic disease
  - Authenticity
  - Content creation through storytelling
- This approach, leveraged by the early stages of social media, helped build the necessary community that eventually led to the explosion of Quest
- Tom credits [Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)’s book ([4 Hour Work Week](https://www.amazon.com/4-Hour-Workweek-Escape-Live-Anywhere/dp/0307465357/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)) and [Kevin Kelly](https://twitter.com/kevin2kelly?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)’s essay ([1,000 True Fans](https://kk.org/thetechnium/1000-true-fans/)) for shaping his approach to marketing

### Why Tom started Impact Theory [35:00]

- [Mission](https://impacttheory.com/about/) is to “…end the poverty of poor mindset”
- Prior to [Impact Theory](https://impacttheory.com/), Tom had begun taking a strong interest in improving the lives of Quest employees and empowering them to grow
  - But to grow, Tom realized that you first must have the right mindset
- “When I’m at my most honest, I love helping with the body…but helping with the mind is what I’m meant to do”
- Tom authored the [25 bullet points](https://impacttheory.com/blog/impact-theory-belief-system-25-bullet-points/), a belief system which lays the groundwork for approaching life with the right mindset
- Tom created a show called [Inside Quest](https://www.imdb.com/title/tt6335620/episodes) which interviewed successful people, trying to understand how they achieved it, specifically to help Quest employees grow
- Tom eventually turned the Inside Quest studio into a new show and company called Impact Theory

### Money and motivation [44:00]

Did Tom feel different when he hit it big with Quest?

- “No…you think ‘when I get money…all the insecurities that I have will get washed out’…but you feel exactly the same the next day…”
- Money won’t change how you feel about yourself, but it will extend your capabilities
- With the right approach, money can allow you to “aim incredibly intelligent, capable people, at problems *you* want solved”
- How does Tom want to use his wealth? “I want to make sure no human fails to encounter an empowering mindset”

People doing remarkable things with their money:

- [Bill Gates](https://twitter.com/BillGates)
- [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett)
- [John Arnold](https://twitter.com/JohnArnoldFndtn?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
- [Elon Musk](https://twitter.com/elonmusk?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (sidebar: check out this [incredible auditory experience](https://www.youtube.com/watch?v=x7uQ8OWiheM) of a [SpaceX](https://www.spacex.com/) launch)

### What Tom learned interviewing every employee at Quest, and the one question everyone answers exactly the same [54:15]

- Interviewed every Quest employee who applied
- Asked each person a “magic genie question” where he or she would get one wish and the answer had to be selfish
  - Nearly every single person answered the exactly the same: “1 million dollars”
- This taught Tom an important lesson about humanity: “you only dream as big as you think, and you only think as big as what you see,” and so the problem is, “your thinking is so limited by what you’ve seen”
- Tom has since become obsessed with how to impart his ability to train his mindset into others, and he believes narratives and storytelling is the best medium for this

### Tom’s secret formula to fulfillment and the ubiquity of suicide [1:00:00]

Peter would rather ask for fulfillment than money from the magic genie because fulfillment strikes him as “one of the hardest things to find”

Tom’s secret formula to fulfillment:

- Becoming someone that you’re proud of
- Building a skill set that was incredibly hard to get that serves not only you but others as well
- Build your identity as someone who is willing to do the hard things, not just the things that are pleasurable, in order to become extraordinary
- “The cool stories are the stories that, while you’re in it, suck”

#### **The ubiquity of suicide and what might be causing it**

Peter offers up 2 questions:

1. Is there any evolutionary basis for suicide?
2. Do we believe that we are seeing suicide to a greater extent now or are we just paying closer attention to it?

- Suicide is so against our DNA of survival, yet it’s so ubiquitous
- Tom’s intuition says the prevalence of suicide is indeed rising, and offers up the idea that the [microbiome](https://en.wikipedia.org/wiki/Microbiota) might play a larger role than we realize in our mood and happiness
- Peter wonders if depression is a result of people feeling more alone today than they did a couple hundred years ago, perhaps today’s society doesn’t facilitate the same kind of camaraderie that we may have been wired to experience
- Tom advises not to lose playfulness

### Nutrition, fasting, sleep, meditation and other routines Tom uses to function at his best [1:13:15]

- Tom’s top priority is to optimize cognition through diet and exercise (even though he hates working out, he makes sure to workout 5x per week)
- Peter loves deadlifts (hex bar) and he shares his routine and how to do it safely
  - Rule #1: don’t get hurt
  - Warmup is: empty bar, 135, 185, 225, 275, 315
  - If something seems off, Peter is done deadlifting for the day (same rule for squatting)
  - This happens approximately 1 out of every 5 sessions

### Tom’s nutrition [1:17:30]

- LCHF (low-carb/high-fat)
- Whole foods
- A lot of colorful vegetables
- Eggs
- Plenty of fat, mostly olives, and olive oil
- Not afraid of red meat
- Only cheats a couple times per year

### Fasting [1:18:30]

- Once per year, Tom does a 5 day water-only fast (Peter mentions his experience with a [5-day FMD](https://prolonfmd.com/fasting-mimicking-diet/?doing_wp_cron=1532713843.2594439983367919921875))
- Typical day for Tom is dinner at 6 PM and breakfast at 8 AM (~14-hour fast)
- Tom’s 3-week keto/protein/keto protocol
  - 1 week ketogenic with daily 16-hour intermittent fasting (IF)
  - Followed by 1 week “high” protein (replaces about 40 grams of fat with 40 grams of protein for a total of roughly 140 grams protein) and does NOT do IF, this week kicks him out of ketosis
  - Followed up with another week of keto with daily IF

### Sleep [1:23:30]

- “I’m a psycho about sleep… being tired is a unique form of misery”
- Religiously in bed at 9 PM, M-F, sleeps until he wakes up, no alarm
- A [sleep study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435718/) shows signs that sleep deprivation contributes to memory loss and insulin resistance
  - Results section of the [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435718/): “The insulin concentration for the half-maximal pAkt–tAkt response was nearly 3-fold higher …(P = 0.01)… and the total area under the receiver-operating characteristic curve of the pAkt–tAkt response was 30% lower (P = 0.01) during sleep restriction than during normal sleep. A reduction in total body insulin sensitivity (P = 0.02) paralleled this impaired cellular insulin sensitivity.”

### Meditation [1:26:15]

- “Even on my worst day, I can get to absolute zero where I am totally stress and anxiety free”
- Learned to meditate from former Navy SEAL [Mark Divine](https://twitter.com/markdivine?lang=en)
- Tom’s approach to meditation is “all breath, 100%”
- Meditates prior to all big events (e.g., speeches)
- Part of Peter’s interest in meditation came from the notion that negative feelings are either rooted in the past (depression) or future (anxiety) (cf. [the episode with Tim Ferriss](https://peterattiamd.com/timferriss/), and Michael Pollan’s [recent book](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225/ref=sr_1_4?s=books&ie=UTF8&qid=1530096268&sr=1-4&keywords=how+to+change+your+mind), for more on the concept of mental “time travel”) and using something like [Mindfulness meditation](https://en.wikipedia.org/wiki/Mindfulness), which focuses on being as present as possible, could help
- Can meditation help with pain?
  - Peter says that sometimes the emotions and sensations surrounding physical pain are more about the *anticipation* of the pain and the possible worsening of that pain
  - He did his own experiment with the idea that meditation can help reduce the negative sensation of pain

§

§

## Selected Links / Related Material

- **Tom’s nutrition company**: [Quest Nutrition](https://www.questnutrition.com/) | (questnutrition.com) [00:45, 18:45, 27:00, 33:00, 44:00, 51:00]
- **Tom’s company trying to “end the poverty of poor mindset”**: [Impact Theory](https://impacttheory.com/) | (impacttheory.com) [1:00, 17:45, 35:00]
- **Book containing a short story regarding immortality that Tom found interesting**: [Einstein’s Dreams](https://www.amazon.com/Einsteins-Dreams-Alan-Lightman/dp/140007780X/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by Alan Lightman | (amazon.com) [16:00]
- **Fixed vs Growth mindset**: [Dr. Dweck’s discovery of fixed and growth mindsets have shaped our understanding of learning](https://www.mindsetworks.com/science/) | (mindsetworks.com) [21:00]
- **Tech company started by Tom, Ron Penna and Mike Osborn**: [Awareness Technologies](https://en.wikipedia.org/wiki/Awareness_Technologies) | (wikipedia.org) [25:00]
- **Book that made a big impact on Tom when starting Quest**: [The 4-Hour Workweek: Escape 9-5, Live Anywhere, and Join the New Rich by Tim Ferriss](https://www.amazon.com/4-Hour-Workweek-Escape-Live-Anywhere/dp/0307465357/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) | (amazon.com) [30:45]
- **Podcast that impacted Tom’s thinking about marketing**: [The Tim Ferriss Show: Interview of Kevin Kelly, Co-Founder of WIRED, Polymath, Most Interesting Man In The World?](https://tim.blog/2014/08/29/kevin-kelly/) | Tim Ferriss (tim.blog) [30:45]
- **Essay by Kevin Kelly that shaped Tom’s thinking about marketing**: [1,000 True Fans](https://kk.org/thetechnium/1000-true-fans/) | Kevin Kelly (kk.org) [30:45]
- **Tom’s summary of what it takes to change your mindset and be successful**: [The Impact Theory Belief System in 25 Bullet Points](https://impacttheory.com/blog/impact-theory-belief-system-25-bullet-points/) | Tom Bilyeu (impacttheory.com) [38:30]
- **Show chronicling the transformations of people in the Quest community**: [Inside Quest](https://www.youtube.com/channel/UCi4xh-87QOWzQfdMgmF7sIA) | (youtube.com) [39:30]
- **The incredible sounds of a SpaceX launch**: [Extended Cut – The Incredible Sounds of the Falcon Heavy Launch – (BINAURAL AUDIO IMMERSION)](https://www.youtube.com/watch?v=x7uQ8OWiheM) | The Sound Traveler (youtube.com) [49:30]
- **Book that helped Tom understand the impact of narrative**: [Homo Deus: A Brief History of Tomorrow](https://www.amazon.com/Homo-Deus-Brief-History-Tomorrow/dp/0062464310/ref=sr_1_1?ie=UTF8&qid=1532551527&sr=8-1&keywords=homodeus+book) by Yuval Noah Harari | (amazon.com) [58:45]
- **Book that helped Tom understand the impact of narrative**: [Sapiens: A Brief History of Humankind](https://www.amazon.com/Sapiens-Humankind-Yuval-Noah-Harari/dp/0062316117/ref=asap_bc?ie=UTF8) by Yuval Noah Harari | (amazon.com) [58:45]
- **Toyota helps soup kitchen with efficiency**: [In Lieu of Money, Toyota Donates Efficiency to New York Charity](https://www.nytimes.com/2013/07/27/nyregion/in-lieu-of-money-toyota-donates-efficiency-to-new-york-charity.html) | Mona El-Naggar (nytimes.com) [1:03:00]
- **The Fasting Mimicking Diet (FMD) by Valter Longo**: [What is The Fasting Mimicking Diet?](https://prolonfmd.com/fasting-mimicking-diet/?doing_wp_cron=1532713843.2594439983367919921875) | (prolonfmd.com) [1:20:15]
- **Eve Van Cauter’s (and colleagues) study showing sleep deprivation contributes to insulin resistance**: [Impaired Insulin Signaling in Human Adipocytes After Experimental Sleep Restriction A Randomized, Crossover Study](https://www.ncbi.nlm.nih.gov/pubmed/23070488) (Broussard et al., 2012) [1:24:30]
- **Meditation practice Peter mentioned as helpful for staying in the present**: [Mindfulness](https://en.wikipedia.org/wiki/Mindfulness) | (wikipedia.org) [1:29:30]

§

§

## People Mentioned

- [Lisa Bilyeu](https://www.instagram.com/lisabilyeu/?hl=en) (Tom’s wife, co-founder of [Impact Theory](https://impacttheory.com/about/)) [4:00, 1:07:00]
- [Dominic D’Agostino](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (convinced Tom fat wasn’t bad) [4:15]
- [Ron Penna](https://entrepreneur.wiki/Ron_Penna) (founder of Quest Nutrition) [4:15, 18:45, 22:30, 40:30]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) ([Einstein’s Dreams](https://www.amazon.com/Einsteins-Dreams-Alan-Lightman/dp/140007780X/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) book) [16:00]
- [Mike Osborn](https://www.linkedin.com/in/mike-osborn-0699b964) (founder of Quest Nutrition) [18:45, 22:30, 40:30]
- [Steven Spielberg](https://en.wikipedia.org/wiki/Steven_Spielberg) [20:30]
- [Tony Robbins](https://twitter.com/TonyRobbins?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Tony’s work helped Tom develop a growth mindset) [22:30]
- [Mother Teresa](https://en.wikipedia.org/wiki/Mother_Teresa) (“If I look at the mass I will never act. If I look at the one, I will.”) [30:15, 1:02:30]
- [Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (his [podcast with Kevin Kelly](https://tim.blog/2014/08/29/kevin-kelly/) changed Tom’s thinking on marketing) [30:45]
- [Kevin Kelly](https://twitter.com/kevin2kelly?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (wrote [1,000 True Fans](https://kk.org/thetechnium/1000-true-fans/) which inspired Tom) [30:45]
- [Joseph Campbell](https://en.wikipedia.org/wiki/Joseph_Campbell) (“If you want to change the world, you have to change the metaphor.”) [42:00]
- [William Shakespeare](https://en.wikipedia.org/wiki/William_Shakespeare) [42:15]
- [Elon Musk](https://twitter.com/elonmusk?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Tom is immensely inspired by Elon) [48:30, 51:30, 1:12:45]
- [Bill Gates](https://twitter.com/BillGates) (doing remarkable philanthropy with his money) [51:00]
- [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) (doing remarkable philanthropy with his money) [51:00]
- [John Arnold](https://twitter.com/JohnArnoldFndtn?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (doing remarkable philanthropy with his money) [51:00]
- [Anthony Bourdain](https://en.wikipedia.org/wiki/Anthony_Bourdain) (depression and suicide) [1:06:45]
- [Kate Spade](https://en.wikipedia.org/wiki/Kate_Spade) (depression and suicide) [1:06:45]
- [Mark Divine](https://twitter.com/markdivine?lang=en) (Navy Seal that got Tom to start meditating) [1:26:45]
- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (meditation) [1:28:45]
- [Josh Martin](https://www.facebook.com/josh.martin.319) (Peter’s [body worker](https://www.kriyabodywork.com/)) [1:30:00]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/08/tom-bilyeu-wide-shot-500x400.jpg)

##### Tom Bilyeu

Tom Bilyeu is the co-founder of 2014 Inc. 500 company Quest Nutrition — a unicorn startup valued at over $1 billion — and the co-founder and host of Impact Theory. Impact Theory is a first-of-its-kind company designed to facilitate global change through the incubation of mission-based businesses and the cultivation of empowering content. Every piece of content Impact Theory creates is meant to underscore the company mission to free people from The Matrix and help them unlock their true potential. Impact Theory exists to inspire the next generation of game-changing companies and creators that will make a true and lasting impact on the world. [[youtube.com](https://www.youtube.com/channel/UCnYMOamNKLGVlJgRUbamveA)]

Tom on YouTube: [Tom Bilyeu](https://www.youtube.com/channel/UCnYMOamNKLGVlJgRUbamveA)

Tom on Instagram: [@tombilyeu](https://www.instagram.com/tombilyeu/)

Tom on Facebook: [Tom Bilyeu](https://www.facebook.com/tombilyeu/)

Tom on Twitter: [@TomBilyeu](https://twitter.com/TomBilyeu?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)