# #221 ‒ Understanding sleep and how to improve it

**Source:** [https://peterattiamd.com/understanding-sleep/](https://peterattiamd.com/understanding-sleep/)

---

In this special episode of The Drive, we have pulled together a variety of clips from previous podcasts with sleep expert Dr. Matthew Walker to help listeners understand this topic more deeply, as well as to identify which previous episodes featuring Matt may be of interest.  In this episode, Matt gives an overview of why we sleep, the stages of sleep, and sleep chronotypes, and he provides tips to those looking to improve their total sleep and sleep efficiency. Additionally, Matt discusses the pros and cons of napping, and gives his current thinking on the effects of blue light and caffeine on sleep. Finally, Matt explains the dangers of sleeping pills and reveals what he believes are the most useful alternatives for someone struggling with sleep, such as those with insomnia.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/understanding-sleep/the_Drive_public.png)

Play

#221 ‒ Understanding sleep and how to improve it

1x15s30s

0:001:37:03

## We discuss:

- Evolutionary reasons to sleep [2:15];
- Stages of sleep, sleep cycles, and brainwaves [10:00];
- Understanding sleep chronotypes and how knowing yours could help you [25:45];
- Defining sleep efficiency and how to improve it [36:15];
- Correcting insomnia: a counterintuitive approach [38:45];
- Pros and cons of napping, and insights from the sleep habits of hunter-gatherer tribes [41:30];
- Sleep hygiene, wind-down routine, and tips for better sleep [50:15];
- The optimal room temperature and body temperature for the best sleep [59:30];
- Blue light: how Matt shifted his thinking [1:08:30];
- Caffeine: how Matt has adjusted his hypothesis [1:14:45];
- The dangers of sleeping pills, useful alternatives, and cognitive behavioral therapy for insomnia [1:19:45];
- More.

§

## Show Notes

**\*Notes from intro**:

- Welcome to another special episode of *The Drive*
- As we’ve released so many episodes over the past 4 years, we realize we’ve covered a lot of various topics in detail across a variety of episodes
- It can be hard at times to piece everything together
- We also realize there are newer listeners who haven’t had the chance to listen to all of our older episodes
- So we did a test back in May of 2022, where we did an [episode](https://peterattiamd.com/exercising-for-longevity/) that pulled a variety of clips from previous podcasts all on one topic, which was [exercise](https://peterattiamd.com/category/exercise/)
- The feedback we received from that episode was overwhelmingly positive and people asked for more
- So for this week’s episode, we’re going to do something similar to that, but this episode will focus on clips from a variety of past topics that discuss [sleep](https://peterattiamd.com/category/sleep/)
- We put these clips in order of what we think is the best way to listen from top to bottom
- Along the way in between some of the clips in this episode, Peter will provide some commentary to set the stage
- Our hope is that this will not only allow you to understand the topic of sleep better, but also help identify some previous episodes you may be interested in listening to if you want to dive deeper
- In all of these clips, Peter is joined by sleep expert [Matt Walker](https://www.sleepdiplomat.com/)
- Matt has been on the podcast several times, including 3 AMAs (see the links at the end of these notes)
- Some of these clips are from AMAs, so if you’re not a subscriber, you’ll be able to get an idea of what we cover on those episodes
- As this is still a newer concept and only our second time doing this we really want feedback
  - If you like this, tell us and we’ll keep doing it
  - If you don’t like it, we’ll scrap it

## Evolutionary reasons to sleep [2:15]

From episode [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/); discussed from [1:01:00] – [1:09:15]

- Sleep has become stigmatized as laziness and sloth
- In 70 years, we’ve lost 20-25% sleep
- By comparison, imagine a reduction in O2 saturation by 20-25%
  - It’s very clear that’s not a good idea

**Peter’s personal story about his attitude towards sleep**

- He resisted lots of sleep until about 2012
- “*I’ll sleep when I’m dead*”
- During med school, he spent about 114 hrs per week working in the hospital and got about 28 hours of sleep a week
- A few years later, [Kirk Parsley](https://www.docparsley.com/) said to him, “*So let me get this straight. You just decided that you’re going to sleep half of what is evolutionarily programmed? … Does it strike you as odd that evolution would have designed us to spend a third of our life, not mating, not watching out for predators, not hunting for food, but doing this thing for some other purpose? Do you think that thing must have been important?*”
- Overnight it changed the way Peter thought about sleep, which was that evolution went to great lengths to do this

> “*Sleep is the greatest life support system you could ever wish for. It’s a remarkable health insurance policy, it’s largely democratic, free and largely painless*”‒ Matt Walker

**Sleep is the foundation of health**

- In terms of de-risking just about every disease that is killing us in the developed world, it’s very hard to look no further than sleep
- Nutrition and exercise are important, but sleep is the foundation
- “*Sleep is the foundation on which those two other things sit. It’s not the third pillar of good health, I think it is the foundation*”

**How long can you survive without sleep?**

- The record someone survived without food might be 382 days (a lean person maybe 30 days)
- Deprivation of sleep causes the quickest reduction of health
- [Guinness has banned trying to set record for sleep deprivation](https://www.sciencealert.com/watch-here-s-what-happened-when-a-teenager-stayed-awake-for-11-days-straight) (record might have been up to 24 days) because it’s so dangerous (cancer, mental health, CVD, metabolic syndrome, suicidality).
- Think about this:
  - [Felix Baumgartner](https://en.wikipedia.org/wiki/Felix_Baumgartner) went up in [hot air balloon to outer surface of Earth and then jumped out](https://www.youtube.com/watch?v=E-w2_nTnunc), fell over 1000/km/hr, broke sound barrier
  - That was NOT banned by Guinness, but sleep deprivation was – gives you sense of how dangerous it is not to sleep

## Stages of sleep, sleep cycles, and brainwaves [10:00]

From episode [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/); discussed from [40:15] – [54:45]

- Let’s shift gears a little and go back to the [polysom](https://en.wikipedia.org/wiki/Polysomnography)
- Let’s explain:
  - The stages of sleep, different patterns of brain waves (as measured by an [EEG](https://en.wikipedia.org/wiki/Electroencephalography)), see the figure below
  - Commercially available ways to track
    - Peter thinks these are still not accurate enough to compare them to their polysom

**Humans (mammals) have 2 stages of sleep:**

- 1 – [Non-REM](https://en.wikipedia.org/wiki/Non-rapid_eye_movement_sleep)
  - Non-REM has 4 stages‒ cleverly titled stages 1, 2, 3, and 4
  - Stages 3 and 4 are the very deep restorative stages
  - Stages 1 and 2 are the lightest stages of sleep
- 2 – [REM](https://en.wikipedia.org/wiki/Rapid_eye_movement_sleep)
  - REM sleep (REM = rapid eye movement, based on the bizarre horizontal shifting eye movements)
- Non-REM + REM sleep combine to form **90 minute sleep cycles**
  - Every 90 minutes, your brain cycles between non-REM and REM sleep
  - Then this is replayed every 90 minutes to create what we call a standard cycling architecture of sleep, or what we call a [hypnogram of sleep](https://en.wikipedia.org/wiki/Hypnogram)

![](https://peterattiamd.com/wp-content/uploads/2022/08/f1-understandingsleep-942x1024.png)

**Figure 1. The brainwaves of wake and sleep**. Image credit: [*Why We Sleep*](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1657202907&sr=1-1) by Matthew Walker

**Brainwaves when first lie down (before you fall asleep)**

- [Alpha rhythm](https://en.wikipedia.org/wiki/Alpha_wave)
- Frenetic high-frequency electrical activity with a small amplitude (see the figure above)
- Analogy‒ if you held a microphone over a sports stadium, what you’re picking up is the signal from the crowd before the game starts‒ that’s wakefulness
  - During wakefulness, the 100,000 people in the stadium (the 100,000 neurons) are all talking to each other but not in any kind of coordination
  - This results in a very nonsynchronous signal but voices (neurons) cancel each other out
  - The size of the brain wave is not very big
  - But the frequency is high, it goes up and down maybe 50-60x per second
- Before you start to go to sleep, the back of brain (visual brain) is the first part that starts to settle down
  - It goes into alpha rhythm when you close your eyes
  - It stops processing the outside world
  - The frequency slows from 50 cycles/sec to 10 cycles/sec (still relatively low amplitude)

**Transitioning to sleep**

- You can see this transition in your bed partner
- Eyeballs start to roll (slow rolling eye movements)
  - This is the first sign of transition to sleep (the reason is unknown)
- First you go into the light stages of non-REM, stages 1 and 2
- After ~20 minutes you go into the deep stages 3 and 4 of non-REM sleep

**Stages of non-REM**

- In stage 1: [theta waves](https://en.wikipedia.org/wiki/Theta_wave) begin
- Stage 2:
  - 50 cycles/sec down to 6-7 cycles/sec, the amplitude is getting bigger
  - Every now and then, you’ll get these synchronous bursts of electrical activity called [sleep spindles](https://en.wikipedia.org/wiki/Sleep_spindle) ⇒ big slow wave, then a burst of spindle
    - The sleep spindles go up to 10-15 cycles/sec and last for about 1.5 seconds
- Stages 3 and 4:
  - Brain in synchronous chant of slow waves
  - The brain waves slow down to 1 or 2 cycles/sec, but the size of the waves are huge
  - Back to the stadium analogy‒ during the game spectators are chanting in unison, it’s louder and everyone is making the same sounds together and you can actually hear what’s being said
  - Now the brain coordinates hundreds of thousands of neurons to fire together and go silent together
    - This is unique
  - The frequency is slow, once a second, and this looks in some ways like coma
  - Sleep scientists in the past thought this was a time that the brain is not doing nothing
    - Now we realize the opposite is true
  - During this deep sleep info transfer occurs in brain
  - Analogy‒ a long-wave radio, if you’re in the city you tune into FM (short-wave radio) and pick up a bunch of signals, but the further you drive out into the desert/ countryside you lose those channels because the range from the tower is short
    - But if you go to the long-wave radio stations, you can pick up signals for hundreds of miles because the carrier frequency of those radio waves is much slower allowing the distance for transferring information to be much further

***Deep sleep is a brain state of long-distance information transfer***

**How to tell the difference between stage 3 & 4**

- They are both [delta waves](https://en.wikipedia.org/wiki/Delta_wave)
- They are difficult to distinguish morphologically
- Defined as a proportion of 30-second period of sleep that is consumed by deep slow wave activity
  - Stage 3 is less than 50%
  - Stage 4 is more than 50%
- Waves in stage 4 are larger in amplitude and slower in frequency

**Stages** ***must occur in order*** **with 2 exceptions**

- 1 – [Narcolepsy](https://en.wikipedia.org/wiki/Narcolepsy) pathology– one goes from being awake straight into REM sleep
- 2 – If chronically REM sleep derived, occasionally you can go into REM sleep directly (e.g., heavy alcohol use)
  - Alcohol blocks your REM sleep

**Summary of the 90 minute cycle**

- Go through stage 1-4 on non-REM
- Then after 70 min, you go back to stage 2 on non-REM
- Then you will briefly transition to REM sleep
- Then you flip flop between non-REM and REM ⇒ back down into non-REM, back to REM, back to non-REM, back to REM

**What changes is the ratio of non-REM to REM within that 90 minute period, as you move across the night**

- In first half of night, the majority of 90 minute cycle is deep non-REM and very little REM sleep (see the figure below)
- In the second half of the night, the majority of the cycle is REM and almost no deep sleep
- If get 6 hours sleep (instead of 8), you’re losing 25% of sleep, but **you could be losing up to 70% of all REM sleep**

![](https://peterattiamd.com/wp-content/uploads/2022/08/f2-understandingsleep-1024x469.png)

**Figure 2. The architecture of sleep**. Image credit:  [*Why We Sleep*](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1657202907&sr=1-1) by Matthew Walker

***You always go through a linear progression of the stages of the sleep cycle***

## Understanding sleep chronotypes and how knowing yours could help you [25:45]

From episode [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/); discussed from [1:06:00] – [1:16:37]

**Your sleep chronotype simply means**

- Are you a morning person? (25-30% of the population)
- Are you an evening person? (25-30% of the population)
- Or are you somewhere in between? (the rest of us 40-50%)

**Sleep science breaks it into 4 categories**

- 1 – Extreme morning types
- 2 – Morning types
- 3 – Middle evening types
- 4 – Extreme evening types

**There is a strong genetic component underlying sleep chronotypes**

- Evidence that it’s genetic‒
- 1 – There is a significant degree of heritability
- 2 – There are a collection of genes that will determine, to a degree, your chronotype

- Data from [23andMe](https://blog.23andme.com/23andme-research/the-genetics-of-being-a-morning-person/) says there’s about ***9 different genes*** that will contribute to your chronotype
- Most are what we call “clock genes”‒ this refers to the fact that these genes control the rhythm of your circadian cycle
- These genes control WHEN that sinusoidal wave of your circadian cycle arrives on the clock face
  - Said another way, “*If you have a certain type of gene compliment that makes you a morning type‒  your peak alertness is going to arrive earlier in the day and the downstroke of your circadian rhythm will arrive earlier in the evening*“
- For an evening type, your circadian rhythm looks very similar in its sinusoidal pattern but WHEN the ***peak*** and the ***trough*** of that circadian rhythm arrive on the 24 hour clock face is very different than for a morning type

**Evolution of the sleep-wake cycle over your lifetime**

- No matter what chronotype you are, you will change as you develop from a young child to an adolescent teen, to an adult, to an older adult
- More of a morning type when you’re a kid
- A teen’s chronotype makes your bedtime later and your wake time later in the morning (sleeping more in total)
  - This is a problem for early school start times
- Once you become an adult (age 30-40), bedtime becomes a little earlier
- As we get older, we tend to go to bed earlier and earlier (with earlier wake times)

**Your innate chronotype can still be twisted/contorted by non-genetic forces**

- Examples‒ modern social norms, light exposure, technology, etc.
- Interesting experiment‒ [a camping study during *winter*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5335920/)
  - At the end of the week, their [melatonin](https://en.wikipedia.org/wiki/Melatonin) levels began to rise 2.6 hours earlier
  - Going to be much earlier (more than 2 hours)
  - But they did NOT wake earlier
  - As a result, they got 2.3 hours more sleep (~9 hr was the median)
  - NOTE: this may not be realistic to normal life
  - And if you do the same in experiment in *summer* you don’t get as dramatic an effect because of so much sun (almost like solstice effect in scandinavia)

**How to determine your sleep chronotype**

- Paid genetic test like [23andMe](https://www.23andme.com/)
- Free online survey‒ the [MEQ test](https://sleepsurge.com/morningness-eveningness-questionnaire/) provides a decent approximation with genetic tests

**How knowing your chronotype could benefit you**

- Life gets in the way of your ideal sleep times
- Think parents with young kids, college kids who stay up late simply because that’s the norm for your peers, teens having to wake up early for school

- 1 – It would explain a lot about why you might struggle so much where other people seem to be just these energizer bunnies who go to the gym before getting to the office at 7 am

- 2 – Realizing that you’re not culpable, it’s not your fault
  - E.g., a lot of night owls have gone throughout life being chastised

***Matt says society really needs to be much more understanding and then also modify how we do things in response***

- 3 – It can sometimes explain incorrectly diagnosed insomnia
  - If you were on a desert island with no responsibilities, you could sleep whenever you want and get up whenever you want‒ what time would you normally go to bed?
  - People often go to bed early because they need to wake up early for work, but they can’t fall asleep then
  - This can occur when your chronotype is mismatched with your schedule

> “*When you fight biology, you normally lose.  The way you know you’ve lost is often through disease and sickness*”‒ Matt Walker

## Defining sleep efficiency and how to improve it [36:15]

From episode [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/); discussed from [2:29:15] – [2:31:45]

**Sleep duration**

- When Matt recommends getting ***7-9 hours of sleep per night***, he is talking about ***actual sleep***, *not just time in bed*

**Sleep efficiency**

- The time you are asleep divided by the time you are in bed
- You might only be asleep for 85-90% of the time you are lying in bed
- If you are someone who needs 8 hours of actual sleep, and you’re sleep efficiency is about 90%, then you need to be lying in bed for approx. *8 hours and 50 minutes* (sleep opportunity)

**Sleep opportunity**

- This is the time you plan to be in bed with the opportunity to sleep

***Plan for 8-9 hours in bed to get 7-8 hours of total sleep***

**Oura ring**

- Peter says this is why he loves the [Oura ring](https://ouraring.com/)
- It’s very good at telling you how long you were in bed and how much of that time you were actually asleep
  - It will tell you your total sleep time

**What Peter tells his patients…**

- If there’s a problem with total sleep time and efficiency is low, you have to improve the quality
- If total sleep time is low and efficiency is high, you need more time in bed

## Correcting insomnia: a counterintuitive approach [38:45]

From episode [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/); discussed from [2:31:45] – [2:34:45]

**The caveat for insomnia patients**

- If you’re someone who’s struggling with insomnia and you’re lying in bed awake a lot of the time, you may need to *decrease your time in bed* to increase sleep pressure
- It’s counterintuitive, but one of the tools in the [CBT-I](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy_for_insomnia) toolbox is to shorten the sleep opportunity
- Re-establish confidence that you can fall asleep in bed
- Constraining the person down to just 6 hours of sleep opportunity
- By compressing that window down you’re sleeping less and you’re building up more of that sleep pressure because as a consequence of the reduction of sleep opportunity time, you’re going to be awake during the day longer
- The longer that you’re awake, the more of that sleep pressure you build up
- The idea is force your brain to realize that it only has this tiny opportunity of 6 hours so it must take advantage

> “*It’s this ironic way that we help treat insomnia.  We constrain total sleep time.  Use brute force efficiency in a brute force response from the brain and all of a sudden something magical happens.  You start to control your sleep rather than your sleep controlling you.*”‒ Matt Walker

**Example insomnia patient‒  someone who’s chronotype is early to bed, early to rise, but they’re having problems with insomnia**

- Do you push them more on delaying bedtime? ⇒ Slice off the sleep opportunity on both sides
- Next, you should hold the wake up time constant
- And then try to go to be a tad earlier, and earlier
- If you have a set back you can “reign it back in” by shortening the sleep opportunity again

> “*This is usually one of the last tools in the CBT-I box that you typically use just because it’s so hard for compliance and adherence and it is pretty miserable because we’re putting you on essentially a short sleep restriction… but it’s a wonderful way for the patient to then finally feel as though they have control because it’s a technique that they can use once they understand how the sleep system works.*”‒ Matt Walker

## Pros and cons of napping, and insights from the sleep habits of hunter-gatherer tribes [41:30]

From episode [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/); discussed from [42:15] – [56:45]

- Now that we’ve set the stage for what sleep is and why it’s so important, these next set of clips will look at ways we can improve sleep
- We’ll look at the pros and cons of napping
- Proper sleep hygiene
- Ideal wind-down routine
- Optimal temperature for sleep
- How Matt changed his thinking on blue light

**Pros and cons of napping**

- Naps as short as 17 minutes can produce learning and memory benefits (*unpublished data from Matt*)
- And you can some benefit from a cardiovascular standpoint as well *(unpublished data from Matt*)
- Downside of naps is that it can take away sleep pressure which could exacerbate nighttime sleep issues

**If you’re struggling with falling asleep at night (sleep onset insomnia)**

- Avoid naps during the day
- You want to build up as much sleep pressure/sleepiness as you possibly can during the day

- On the flip side‒
  - If you are NOT struggling with your sleep at night, there’s no problem with napping regularly during the day

**Looking at** [**biphasic sleep**](https://en.wikipedia.org/wiki/Biphasic_and_polyphasic_sleep) **of hunter-gatherers**

- If you study hunter-gatherer tribes (whose way of life hasn’t changed for thousands of years), they don’t necessarily sleep the way that we do today
- During the summer months, they will typically have an afternoon nap
- This make sense because when you study human brains you see that somewhere between about 2:00 to 4:00 PM we have a drop in physiological alertness
- As a species, we’re almost pre-programmed to have this enforced dip in our alertness suggesting maybe we should be biphasically sleeping at certain times during the year
  - As opposed to monophasically sleeping

**How long is the afternoon nap by the hunter-gatherers?**

- Typically pretty short, says Matt, less than 90 minutes
- Hunter gatherers would typically sleep just 6.5 hours at night, and then they would make the rest up with an afternoon nap
  - When combined, this matches most sleep experts recommendation that we get 7-9 hours per night

**Is this like the “first and second sleep” of the Dickensian era?**

- No, this is very different to something else that’s been described in the literature, which is “*first sleep and second sleep*”, documented during the [Dickensian era](https://en.wikipedia.org/wiki/Charles_Dickens)
- People would sleep for the first 4 hours—then they would wake up in the middle of the night to write, drink, socialize, etc.—then they would go back for another 4 hours of sleep
- Overall, ***that sleep pattern was more sociologically-driven*** rather than biologically-driven

**Other interesting things about hunter-gatherers**

- 1 – **The concept of midnight**‒ it’s the middle of the night for them, i.e., “mid”-night because they usually go to bed around 8:30-9pm and then they’re awake just a little bit before dawn
- 2 – **Temperature (not daylight) wakes them up**‒ a rise in temperature seems to happen before daylight starts to break and it seems that regulation of the sleep-wake rhythm is more tied to temperature

## Sleep hygiene, wind-down routine, and tips for better sleep [50:15]

From episode [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/); discussed from [56:45] – [1:06:00]

- Caveat‒ Matt is not a sleep physician so it is not his practice to treat individuals
- He’s a sleep researcher so he’s infinitely more qualified to help people start to think through the parameters that factor into sleep

**5 main sleep hygiene tips**

- 1 – Regularity: Going to bed at the same time, waking up at the same time.
- 2 – Light: Getting lots of darkness at night because we are a dark-deprived society (and making sure you get daylight during the first half of the day)
- 3 – Temperature: You need to get cool to get to sleep
- 4 – “Walk it out”: Don’t lie awake in bed because trains your brain to be triggered by your bed and force you awake because you have a learned association
  - TIP: If you’ve been awake for 20 minutes, then get up, go and do something else and only come back to bed when you’re sleepy
- 5 – Alcohol/caffeine: Avoid caffeine in the afternoon and alcohol in the evening

> “*Sleep is much more like trying to land a plane. It takes time to gradually descend down onto that hard foundation of this thing that we call a stable night of sleep.*”‒ Matt Walker

**Additional advice for optimizing sleep**

- 1 – Wind-down routine
  - This is absolutely critical to build it into your routine, says Matt
  - Many people in society expect sleep to be like a light switch‒ it’s just not like that
  - A routine might be 15 minutes for some, for others it’s 30 minutes
  - Things like light stretches, meditation, putting all of your phones and your gadgets away can be part of the routine
- 2 – Remove clock faces
  - If you are struggling with sleep, remove all clock faces from your bedroom
  - Knowing that it’s now 2:35 AM in the morning is only going to trigger more anxiety
  - This [study](https://pubmed.ncbi.nlm.nih.gov/16793001/) from UC Berkeley by [Allison Harvey](https://psychology.berkeley.edu/people/allison-harvey) showed that removing clock faces was helpful for poor sleepers with insomnia
- 3 – Remove technology from the bedroom
  - Technology (esp. phones) can cause “anticipatory anxiety”
    - Don’t make checking your phone (e.g., emails, texts, etc.) the first thing you do in the morning
    - This trains your brain in a “[Pavlovian](https://en.wikipedia.org/wiki/Classical_conditioning) way” that even as your tucking yourself in bed at night to expect that anxiety waiting for you on your side table
    - This “anticipatory anxiety” actually lightens your sleep throughout the night because of that expectation
  - Technology can result in “sleep procrastination”
    - Example would be scrolling through your phone looking for that next interesting thing and procrastinating the process of putting your mind to rest
  - Tip from Matt’s colleague, [Michael Grandner](https://www.michaelgrandner.com/about.html)‒ ***if you’re going to have your phone in your bedroom, make it a rule that you can only use it if you’re standing up. After 5-10 minutes of standing you just think, “God, I just want to sit down. I just want to get into bed.”***
  - Peter has started a new habit that he enjoys‒ don’t look at your phone for an hour after you wake up
- 4 – Set manageable goals
  - Matt references [BJ Fogg](https://www.bjfogg.com/), a researcher at Stanford, who looks at behavioral change and applies it to sleep
    - If you are accustomed to checking your phone the moment you wake up, try to start by giving yourself 5 minutes without checking it
    - Next, keep pushing it longer and longer (10 min, 20 min, and so on)
    - Don’t set yourself up for failure, ease into it and set yourself up for success

***\*Important Note: These tips are for improving your sleep performance, and are for people without a sleep disorder. If you do have an actual sleep disorder (insomnia, apnea, etc.) you need to get help from a physician.***

## The optimal room temperature and body temperature for the best sleep [59:30]

From episode [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/); discussed from [38:30] – [50:45]

**Did our ancestors get better quality sleep during certain times of the year and/or in certain climates?**

- Best data that we have right now is looking at these hunter gatherer tribes
- Take tribes that live in warm climates (e.g., close to the equator)
  - In summer when it’s hotter, they sleep less at night
    - However, they tend to take naps in summer afternoons to make up for that
  - In winter when it’s cooler, they sleep longer at night
    - The frequency of daytime naps decreases

> “*The data favors coldness for longer sleep*”‒ Matt Walker

⇒ Tip: Peter uses the [chiliPAD](https://www.chilisleep.com/) in the summer time

**Is there an optimal room temperature?  What do lab tests show?**

- Between 65-67 degrees, says Matt
- But the answer is more complex than that
- For example, it varies from person to person

**Studies have been done where they strap people into a bodysuit where you can exquisitely control the temperature of any part of the body show**

- 1 – For your extremities (hands and feet), if you warm them up with socks, for example, it will bring heat to them away from your body, resulting in a cooling of your core temp so you will fall asleep faster
- 2 – Then you need to get cold to stay asleep during the night
- 3 – And then you need to warm up to wake up in the morning

**Other tips for cooling your core body temperature**

- Take a hot bath or a shower
- All of the blood is charmed to the surface of your skin, and it radiates the heat out of the core of your body
- Your core body temperature plummets once you get out

*So in real life, to fall asleep faster…*

- Warm yourself up with a hot shower to radiate that heat out and get you to sleep quicker
  - Wearing socks or using a hot water bottle at the end of your bed to warm your feet will have the same effect
- Keep the room cool to keep your body cold throughout that middle section and later section of sleep
- Then, set your thermostat to rise in the last 15 minutes of your sleep so you will wake up easier and feel less groggy
- Bringing up the core body temperature will help you feel more awake
  - This is why many people like a hot drink in the morning (even in the summer) because the increased temperature helps you wake up (in addition to any caffeine)

**How much better would you predict one would sleep if the room temperature went from 75 to 65?**

- On average, people are more likely to sleep considerably better at 65 than 75
- In terms of duration, or stage quality, or what metric?
- Some people will see it in terms of quantity of deep sleep, but most benefit is in **quality** of sleep
- In [studies](https://academic.oup.com/brain/article/131/2/500/407617?login=false), much of the benefit of the cooler temperature is in the **quality of your sleep measured by the electrical brainwave signature**
  - This detail is NOT something you’ll see on any current personal sleep tracker
- Realize, if you aren’t seeing an improvement in *quantity* on your sleep tracker, don’t just assume it’s not helping

## Blue light: how Matt shifted his thinking [1:08:30]

From [episode #127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/); discussed from [5:45] – [12:15]

**Overall**: Matt says the things he’s most changed his mind about recently is his understanding about the impact of blue light on sleep ⇒ “*I’ve actually down-regulated my belief in the effects of blue light*”

**In the** [**book**](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1657202907&sr=1-1)**, for example, he wrote about** [**study from Harvard**](https://www.pnas.org/doi/10.1073/pnas.1418490112) **(which he still thinks is valid)**

- Participants either read on an iPad or a book under dim light for an hour
- It showed that the iPad had this detrimental effect on sleep by delaying the release of [melatonin](https://en.wikipedia.org/wiki/Melatonin)
- That caused a reduction in REM sleep
- The even concluded that the effect lasted a couple days after stopping the iPad reading at night

[**Research by Michael Gradisar**](https://jcsm.aasm.org/doi/10.5664/jcsm.3272) **from Flinders University pushed back on that conclusion**

- This study suggested it’s that these devices ACTIVATE us, and that activation masks/mutes our sleepiness so we go to bed later and lose sleep
- It’s less about the blue light, and more about the devices ability to increase alertness/physiological arousal in the brain
- In other words, you were sleepy all along, but these devices hit a mute button on the sleepiness

**In summary**

- The studies implicating blue light as especially bad for sleep were principally looking at melatonin
- In other words, they were simply saying, “*How does it affect your melatonin?*”
- But the next question should be, “*How does it then affect as a consequence of that change in melatonin?*”

***And it turns out that the melatonin piece may not be the principal reason why sleep is affected when you consider the brain arousal component***

> “*It really sort of made me shift my belief system*”‒ Matt Walker

- Matt now thinks these devices are simply mentally stimulating, and he is interested in the invasion of devices into our evenings and bedrooms

**The next evolution of the science will be to do 2 types of studies**

- 1 – Studies where you use the same amount of light exposure but use different types of lights (type of light being the variable‒ blue light versus red light)
  - Studies have played around with the wavelength of light and have found that the shorter wavelength (blue light) is most detrimental
  - [Studies](https://pubmed.ncbi.nlm.nih.gov/12970330/) years ago by [Charles Czeisler](https://sleep.hms.harvard.edu/faculty-staff/charles-czeisler) and [Steve Lockley](https://sleep.hms.harvard.edu/faculty-staff/steven-w-lockley) at Harvard show that short wavelength light stamps the brakes on melatonin, and this led to this belief
  - Screens were blamed because they are LED-based, which is enriched for shorter wavelength light
  - These studies focused more on melatonin and less on the [polysomnography](https://en.wikipedia.org/wiki/Polysomnography) of a full nights sleep (where the downstream consequences could be assessed)
- 2 – Studies where the type of light actually becomes the constant stimulus where you maintain the same light exposure but cognitively arousing activity is different
  - In one condition you’re doing something cognitively activating
  - In the other condition you’re simply getting hit with the same light but not doing anything cognitively activating

## Caffeine: how Matt has adjusted his hypothesis [1:14:45]

From [episode #127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/); discussed from [12:00] – [16:30]

- In the last set of clips we’ll focus on the effect caffeine can have on sleep and the dangers of sleeping pills
- If you find yourself enjoying this content, we have 7 episodes with Matt including 3 AMAs (see the selected links section at the end)

**Overall**: Matt has added more construct to his beliefs around caffeine, sleep, and disease risk

**Caffeine and disease risk**

- While most evidence is associational from epidemiological studies, the evidence is mounting that coffee drinkers are less at risk to “a whole constellation of diseases”
- However, once you get past kind of like 3-4 cups, things go in the opposite direction
- Seems to be a very clear association between low-to-moderate caffeine consumption and de-risking health disease conditions

**\*Caveat**‒ **caffeine can disrupt your sleep**

- A lack of sleep is associated with an increase in the same diseases that are said to decrease in coffee drinkers
- Even knowing this, Matt says that he might be willing to encourage more coffee consumption if there is more causal evidence that emerges
- But, caffeine can disrupt your sleep

> “*The dose and the timing make the poison when it comes to caffeine*”‒ Matt Walker

- If you’re drinking it later in the day, you’re less likely to see those health benefits
  - In fact, you would likely see health detriments

**More complexity to Matt’s hypothesis**

- Matt’s thinking has been shaped after listening to the audiobook called [*Caffeine*](https://www.amazon.com/Caffeine-How-Created-Modern-World/dp/B083MYJXZT) by [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan)
- Pollan believes that the health benefits are not really due to a cup of coffee, but the fact that the coffee bean itself carries with it lots of **antioxidants**
- And for many Americans who don’t get a balanced diet, coffee in the morning may be one of the only primary sources of antioxidant consumption which may explain the health associations
- A [review paper from 2017](https://pubmed.ncbi.nlm.nih.gov/28826374/) showed that **decaffeinated coffee** carries the same antioxidant load, but without the caffeine, and has many health benefits associated with it

**Matt’s personal behavioral adjustment**

- He now drinks **decaffeinated** coffee in the mornings
- He’s still concerned about caffeine’s effect on sleep, even when consumed in the morning
- This [study](https://pubmed.ncbi.nlm.nih.gov/7796154/) showed that dosing people with caffeine at 7 AM lead to a reduction in the quality of that deep sleep

**Genetic differences amongst individuals**

- There are genetic differences in how quickly people metabolize caffeine
- Some people have very little sensitivity to caffeine, for example, and for those people caffeine in the morning is fine

## The dangers of sleeping pills, useful alternatives, and cognitive behavioral therapy for insomnia [1:19:45]

From episode [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/); discussed from [1:24:30] – [1:45:00]

> “*I feel very comfortable telling patients that I would rather you stick your genitals in a grinder than you take Ambien or Lunesta*”‒ Peter Attia

**Ambien and Lunesta**

- These are sedative hypnotics and don’t actually get you into your good sleep stages
- The [FDA updated its mortality risk warnings](https://www.fda.gov/news-events/press-announcements/fda-requires-stronger-warnings-about-rare-serious-incidents-related-certain-prescription-insomnia) regarding those sleeping pills because of this increased risk of death

⇒ Study: [Hypnotic drug risks of mortality, infection, depression, and cancer: but lack of benefit](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/)

- But even more scary says Peter is the increased risk of chronic illness
- Sleeping pills seems to weaken the immune system leading to higher rates of infection
- Weakened immune can increase cancer risk as well
- In 2016, the [American College of Physicians said sleeping pills must no longer be the first line recommendation for insomnia](https://www.acponline.org/acp-newsroom/acp-recommends-cognitive-behavioral-therapy-as-initial-treatment-for-chronic-insomnia)
  - It has to be something else called [Cognitive Behavioral Therapy for Insomnia (CBT-I)](https://www.sleepfoundation.org/insomnia/treatment/cognitive-behavioral-therapy-insomnia)

**CBT-I**

- Peter has had several patients go through CBT-I with “great success”
- It’s a nonpharmacological, psychological method working with a therapist
- They try to understand where your sleep problems are at and create a bespoke solution for you, the individual
- It’s just as efficacious as sleeping pills in the short term
- But the real benefit is in long term benefits
- When you stop sleeping pills, the benefit goes away, and you might have even made it worse (“rebound insomnia”)
- With CBT-I, the [benefits can last for years after stopping therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3481424/)

**How do you recommend people find good CBT-I therapists?**

- Peter recommends a sleep doctor [Vik Jain](https://dreamsleepmedicine.com/) in Chicago [now in Frisco, TX]
- Here’s a site to help you [find a facility near you](https://sleepeducation.org/sleep-center/) that is AASM accredited

**What questions to ask a potential sleep doctor?**

- Ask them about their success rates
- Ask them where they have found problems with your patients
- Which patients have you typically had the hardest difficulty with in terms of the profile of sleep problems?
  - And if they sound like you, then maybe you want to look elsewhere as well

**Tylenol PM and Benadryl**

- For Benadryl…
  - Benadryl-induced sleep also has some of the risks associated with it that sleeping pills have
  - It’s less potent in terms of that bad consequence and outcome to sleep
- For Tylenol PM…
  - Not good enough data yet to suggest that it’s either good or bad

**What about low doses, or intermittent use of** [**benzodiazepines**](https://benzodiazepines)**?**

⇒ Examples: [Xanax](https://en.wikipedia.org/wiki/Alprazolam), [Valium](https://en.wikipedia.org/wiki/Diazepam)

- Matthew says be careful, only use it in the most dire of circumstances
- It may have [similar negative consequences as Ambien and Lunesta](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3293137/) per one study by [Dan Kripke](https://profiles.ucsd.edu/daniel.kripke)
  - Even just 3-18 pills per year can have a significant mortality risk

> “*See how far you can really get with all of the other kaleidoscope of possibilities of sleep enhancing possibilities that we’ve discussed.  And if those fail, then I think you can think about last resources.  But those drugs typically just are not producing natural sleep.  So I would think of those medications like that box on the wall that says, ‘Break glass in terms of emergency.’  If you’re in that situation and you’re really struggling, then it’s possible that that’s the time to break the glass, but those shattered shards can sometimes still cut you*.”‒ Matt Walker

**What about** [**GHB**](https://en.wikipedia.org/wiki/Gamma-Hydroxybutyric_acid) **and** [**XYREM**](https://en.wikipedia.org/wiki/Sodium_oxybate) **as a precursor?**

- Xyrem is a potent drug for people with [narcolepsy](https://en.wikipedia.org/wiki/Narcolepsy)
- Matt says that Xyrem or GHB are are drugs that appear to increase the amount of deep sleep that you have because it puts your brain into a more sort of sedated slow rhythm
- HOWEVER… a closely look in the lab shows it may not look like naturalistic sleep
- Xyrem seems to be detrimental to [sleep spindles](https://en.wikipedia.org/wiki/Sleep_spindle)
  - Sleep spindles are short synchronous bursts of electrical activity that happened during non-REM sleep
  - They last for 1-1.5 minutes
  - They are critical for things like learning memory and brain plasticity

***When you take GHB or Xyrem, the amount of sleep spindle activity is decreased often***

⇒ Sleep spindles

- We see sleep spindles at the end of a deep, slow wave
- And what happens is that once you’ve hit the peak of that slow wave, you will often have a little bit of a spindle burst (that burst in tandem is called phase amplitude coupling)
- That coupling is critical for long term memory transfer and for strengthening connections between brain cells (brain plasticity or long-term potentiation)
  - So when your blocking those sleep spindles, the idea is you are preventing typical memory and brain plasticity events

***So Xyrem and GHB are not recommended to people who do not have narcolepsy***

> “*We don’t have deep sleep in a pill*”‒ Matt Walker

§

## Selected Links / Related Material

**Audio roundup on exercise**: [#206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more](https://peterattiamd.com/exercising-for-longevity/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 9, 2022) | [01:15]

**Episodes of** ***The Drive*** **with sleep expert Matt Walker**:

- [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 1, 2019) | [01:45]
- [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 8, 2019) | [01:45]
- [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 15, 2019) | [01:45]
- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (June 17, 2019) | [01:45]
- [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 28, 2019) | [01:45]
- [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 31, 2020) | [01:45]
- [#127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 7, 2020) | [01:45]

**Matt’s book on sleep**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1657202907&sr=1-1) by Matthew Walker (2017) | [53:30]

**Matt is the Director of the Center for Human Sleep Science at UC Berkeley**: [Center for Human Sleep Science](https://www.humansleepscience.com/h-o-m-e) | Matt Walker (2022)

§

![](https://peterattiamd.com/wp-content/uploads/2020/09/1x1-matthewwalkerama3-500x500.jpg)

##### Matthew Walker, Ph.D.

Matthew Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized speaker, a successful entrepreneur, and a Sleep Scientist for Google.  [[sleepdiplomat.com](https://www.sleepdiplomat.com/)]

Twitter: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

Publications: [Center For Human Sleep Science](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)