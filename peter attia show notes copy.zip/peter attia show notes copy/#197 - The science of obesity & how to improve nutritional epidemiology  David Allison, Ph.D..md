# #197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.

**Source:** [https://peterattiamd.com/davidallison/](https://peterattiamd.com/davidallison/)

---

##### Check out more content on this topic:

- *(Oct 17, 2021)* [Ten errors in randomized experiments](/ten-errors-in-randomized-experiments/)
- *(Feb 26, 2022)* [Nutritional epidemiology: abolition vs defending the status quo](/nutritional-epidemiology-abolition-vs-defending-the-status-quo/)
- *(Feb 28, 2022)* [The science of obesity & how to improve nutritional epidemiology](/davidallison/)

David Allison is an award-winning scientific writer who has been at the forefront of obesity research for the last 20 years. Currently the Dean of the Indiana University School of Public Health, he has also authored many publications on statistical and research methodology and how to improve research rigor and integrity. David’s focus on evidence and data brings forth an interesting discussion of what we know (and don’t know) about the science of obesity. He provides an insightful and unemotional explanation of the potential impact of nutritional epidemiology in public health while also explaining its many pitfalls and limitations. He offers his take on the path forward in addressing the obesity epidemic, and he closes with a lucid explanation for the evident lack of credibility in science and the steps we can take to change that.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidallison/the_Drive_public.png)

Play

#197 - The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.

#197 - The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.

1x15s30s

0:002:14:14

## We discuss:

- David’s background, interest in obesity, and focus on evidence [5:00];
- The moment when the obesity crisis was recognized, and the sloppy science that ensued [13:00];
- What twins studies tell us about the genetics of obesity [20:30];
- How doctors and scientists have historically approached obesity treatment [23:45];
- Do surgical procedures for obesity prolong life? [32:00];
- The ‘Obesity Paradox’ [36:00];
- Interpreting BMI and mortality data and considering confounders [43:15];
- How body composition and ethnicity factor into consideration of BMI data [50:30];
- Superior tools for measuring obesity at the individual level [57:15];
- Using BMI data for actionable steps to combat obesity [1:02:00];
- Why maintaining weight loss is more challenging than losing weight [1:06:00];
- Differing perspectives on the utility of nutritional epidemiology [1:16:30];
- A mouse study illustrating the impossibility of fully controlling for confounds in observational studies [1:22:15];
- Limitations of nutritional epidemiology and how it can improve [1:26:30];
- Addressing the obesity epidemic—the path forward and obstacles to overcome [1:37:15];
- What David believes to be the most promising interventions we could take to address obesity and improve public health [1:47:30];
- Reproducibility in science, normative and non-normative errors explained [1:51:30];
- Rebuilding trust in science and differentiating between science and advocacy [1:59:00];
- More.

§

## Show Notes

**\*Notes from intro:**

- David Allison received his PhD from [Hofstra University](https://www.hofstra.edu/) in 1990
- He went on to complete his post-doctoral fellowship at the [Johns Hopkins University School of Medicine](https://www.hopkinsmedicine.org/som/)
- And a second post-doctoral fellowship at the [New York Obesity Research Center at St. Luke’s Roosevelt Hospital Center](https://www.nynorc.cuimc.columbia.edu/)
- He’s currently the Dean and Provost Professor at the [Indiana University Bloomington School of Public Health](https://publichealth.indiana.edu/)
- Prior to that, he was an endowed professor and a director of an NIH-funded [nutrition organization research center at the University of Alabama in Birmingham](https://www.uab.edu/norc/)
- He’s authored over 500 scientific publications and received many awards, including:
  - The 2002 Lilly Scientific Achievement Award from the Obesity Society
  - The 2002 Andre Mayor Award from the International Association for the Study of Obesity
  - The National Science Foundation Administered 2006 Presidential Award for Excellence in Science, Mathematics, and Engineering Mentoring
- In 2012, he was elected to the [National Academy of Medicine and the National Academies](https://www.nationalacademies.org/home)
- He serves on or has served on many of the editorial boards and currently serves on:
  - As an Associate Editor or Statistical Editor for [The International Journal of Obesity](https://www.nature.com/ijo/)
  - [Nutrition Today](https://journals.lww.com/nutritiontodayonline/pages/default.aspx), [Obesity Reviews](https://www.worldobesity.org/resources/journals/obesity-reviews), [Public Library of Science (PLOS Genetics)](https://journals.plos.org/plosgenetics/), [Surgery for Obesity and Related Diseases](https://www.soard.org/), and [The American Journal of Clinical Nutrition](https://academic.oup.com/ajcn)
  - He is also the founding Field Chief Editor of [Frontiers in Genetics](https://www.frontiersin.org/journals/genetics)
- David’s research interests include obesity and nutrition, quantitative genetics, clinical trials, statistical and research methodology, and research rigor and integrity
- Peter has known David Allison for probably about 7-8 years now
- He has always found him to be one of the most insightful and thoughtful people on virtually any topic
- In this episode we talk about obesity
  - We spend a lot of time getting into what is known and what is not known about obesity and also the science of obesity
  - In particular we focus on the science of nutrition and nutritional epidemiology
  - We talk about all these pitfalls, which for many of my listeners, will be familiar
- David brings a very unemotional and a very insightful, logical, and thoughtful approach to how he thinks about the pitfalls in this field
- There are parts of this discussion that are actually quite frustrating in the sense that David acknowledges that most of the measures that we have in place from a public health perspective are probably not founded in any scientific basis
- We then talk a little bit about the reproducibility of science and we close with a very clear elucidation of the challenges that science seems to be facing
  - This kind of existential threat where science and scientists are often confounded
  - Where science and advocacy is often confounded
  - There seems to be a bit of a crisis around this
  - David offers his thoughts on that and whether or not there is a crisis or not
  - For Peter, this is one of the most interesting parts of the discussion, and it’s something that he’s been trying to wrap his head around for some time without much success
    - That is the seeming lack of credibility that science has today
  - David is quick to point out that it’s probably not science that is being doubted
    - Certainly the scientific method is not in doubt, as it is a means by which knowledge can be reliably and reproducibly gained
    - But rather it might be the confounding of science and advocacy
  - Peter would encourage you to listen all the way through, even if at the outset, you find the topic of obesity not particularly to your interest to hear what David has to say on this topic

## David’s background, interest in obesity, and focus on evidence [5:00]

**Even as an undergraduate David was focused on evidence, data**

- Peter admires the intellectual approach David has to obesity research, his lack of emotional thinking
- For many people, the field of obesity is a loaded field, scientifically and politically
- David doesn’t really know why he turned out the way he did
  - To quote his friend [Don Ruben](https://en.wikipedia.org/wiki/Donald_Rubin), “*we may be able to figure out what the causal effect of X is, but we may not be able to assess whether X cause Y*”
- When David went to college he wanted to be a psychologist
  - What this meant to him at the time was Hitchcock films
  - He was going to interpret people’s dreams and figure out the meaning
- When he got to college he started to think about the evidence for these things
  - That opened up this whole can of worms
- He became more and more cognitive behaviorally-oriented
- He remembers in graduate school the professor explaining IQ tests and different theories of intelligence
  - The professor noted that some people think there is 1 factor in intelligence, some people think 3 and one person thinks its 144
  - David asked who was right
  - The professor said, “*Well, they bring their different evidence to bear, and they argue*”
  - David asked about the evidence
  - The professor replied “*these factor analyses…you have to go study multivariate statistics if you want understand that*”

> “S*o I don’t like to take anybody’s word for anything*” – David Allison

- So David went and studied multi-varied statistics
- He became more and more involved with statistical analysis to the point where eventually people started thinking he was a statistician
- He sort of became, by evolution, a statistician, having been trained as a psychologist
- He thinks all of that comes down to evidence
  - Body fat is no different than any other variable
- People are another variable; they still have to obey the same laws of probability and physics and mathematics and so on that we apply to anything else
  - People talk and so folks who study people think about the words that people say, whereas if you’re studying atoms and molecules, you don’t think about the words they say, you just apply scientific methods
  - For example the same person who would never question a diabetol*ogist* on what the beta cell of a pancreas is doing, would say to an obesity research, “*Well, this is how obesity works and it’s this aspect of food or that aspect of culture or that aspect of child rearing*”
    - Based only on the fact that they were children or had children and had some experience
  - David takes a step back and says, “*whether it’s pigs today and pigs tomorrow, whether it’s Xs and Ys, they’re just variables and applying the same laws of thinking to all those systems*”

**David’s interest in the field of obesity**

- As an undergraduate, a sophomore at [Vassar College](https://www.vassar.edu/) in New York, he took a class on human emotion and motivation.
- He studied the theories of [Stanley Schacter](https://en.wikipedia.org/wiki/Stanley_Schachter), who at the time was a professor of psychology at Columbia University; he is since deceased
- Stanley was an amazing, brilliant man who wrote a book called *Emotion, Obesity, and Crime*
  - He talked about the connection among these and how the distinction between our cognitive state and our physiologic arousal state might lead us to certain kinds of behaviors, including in the case of some people, eating more calories than they might otherwise eat
- His experiments were so creative; David just loved it
  - He would put a clock on the wall and he would have the clock move a little faster, but not perceptively faster
    - Then he would bring some students in and give them some work to do under some ruse
    - Then the clock would say for some of the students at 11:00 AM, that it was noon, and he’d say, “*By the way, I have a big tray of roast beef sandwiches out here. So whenever you’re hungry for lunch, just let me know and you can have some sandwiches*.”
    - For some people, the clock wouldn’t say it was noon until 1:00 PM
    - And for some people, it would say it was noon at noon
    - He’d say, “*Who would be following the clock and who would be following the actual time?*”
  - Obese or overweight persons were more likely to follow the clock; this became the external theory
  - This didn’t always work out; another experiment would show that it only holds up under this circumstance
- He had to write lots and lots of papers at Vassar College
  - He got a great education in writing and thinking there
  - There were not so many tests but lots of papers
  - When he took physiologic psychology, he would write about the physiologic psychology of obesity
  - When he took behavioral psych, he wrote about the behavioral obesity
  - When he took developmental, he wrote about the developmental aspects of obesity
  - He loved being able to look at obesity from so many different angles
    - No one researcher does this; everybody’s got their pet thing— this nutrient is toxic, the problem is food marking practices, the problem is cultural, it’s exercise
    - There are so many factors involved and he enjoyed studying it from many angles (and he still does)
- He finished his PhD in the mid to late ‘80’s
- Obesity rates then were not as high as they are now
  - There have been steady increases

## The moment when the obesity crisis was recognized, and the sloppy science that ensued [13:00]

- Looking at the data from the 1700s forward, there have been relatively steady increases in obesity rates in westernized industrialized countries since then
- A wake-up moment occurred in the early ‘90’s with the [NHANES III study](https://wwwn.cdc.gov/nchs/nhanes/nhanes3/default.aspx)
  - This is the National Health and Nutrition Examination Survey
  - It’s an annual study performed today, a survey of a representative sample of Americans with measured heights and weights
  - This is how obesity levels are tracked
  - In the early ‘90’s it was only done every few years
  - Prior to this obesity was an issue, but it wasn’t on top of everyone minds, especially for kids
- Pharmaceuticals were still seen as the realm of charlatans at that point
- Doc’s that proposed the use of obesity medications were called diet docs, and that was a very bad stigma
- There weren’t many good medications available
- Surgery was still looked at as a very peculiar thing for very extreme cases, and many medical professionals disdained it
- In the early ‘90’s when the  NHANES III data came out, it showed this big jump in obesity levels
  - This got everyone’s attention
  - Words like epidemic started to be used, especially for childhood obesity
- The public health policy and environmental perspective started to shift in the mid-90’s
- People like [Kelly Brownell](https://en.wikipedia.org/wiki/Kelly_D._Brownell) suddenly started to say, “*Maybe we’ve got it wrong. Maybe it’s this environment*.”
  - He was probably one of the most forceful voices at the time
  - He was a colleague of [Tom Wadden](https://en.wikipedia.org/wiki/Thomas_Wadden) (University of Pennsylvania)
  - And a student of [Mickey Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) of the cognitive behavioral individual clinical treatment approach to obesity
  - He popularized the term “toxic environment”
- It was at this point that people began to think about prevention and children and the overall environment, the political, economic, social, food marketing environment we live in
- The same public health people who had battled cigarette companies and tobacco for decades, came with their tools and said, “*We know how to deal with things that are environmental, social, political problems*”
- It began to be seen as an environmental, social, political problem
- In some ways, a lot was gained, because obesity research got a lot more funding, more attention, more efforts, more research
  - But in some ways a lot was lost

**As interest in obesity research grew, the science became sloppy**

- David grew up in the field in the early-90’s in the first federally-funded obesity research center, which is the [New York Obesity Research Center](https://www.nynorc.cuimc.columbia.edu/)
- As a young postdoc, if he were to say something that didn’t quite jive with physiology or genetics or anatomy or clinical medicine, there was a physiologist and a geneticist and an atomist and a medical doctor with whom he could consult
  - They all knew each other, they knew the arguments, they knew the literature for the last 20 years
- Then the public health people came in fresh without kind of knowing so much
  - It was great to have more interest in obesity
  - But it brought about a **dilution of the rigor of the field intellectually**
    - It became a lot more of opinion, a lot more of advocacy
    - In the absence of rigorous evidence showing what worked, people are saying, “*This seems like it ought to work*”

**Peter asks what scientists believed to be the “cause” of obesity** (prior to the NHANES III study) [17:15]

- There wasn’t a single cause
- What some people today call the **energy balance model** was accepted as valid
  - Maybe not as a model but as a description of what occurs
  - Peter notes, this sort of tautology doesn’t really tell us anything; it’s implied and obvious but not explanatory
  - David agrees that “*not explanatory is maybe the best way of describing it*”
  - He likes the term **energy balance “*****statement”*** because it doesn’t imply *causality*

*Peter asks if prior to NHANES III the belief was that obese people ate more calories than they were expending by choice (i.e., it was behavioral)?*

- David notes this is a hard question to answer because people’s thinking was so sloppy and they didn’t distinguish among things well
  - This is still true today
  - People talk about the influence of biology versus behavior as though there can be behavior without biology
- But if you really drill down, smart people understood there is a genetic component to obesity
  - Any rancher could have told you a hundred or more years ago that there’s a genetic component
  - We can selectively breed animals for being thinner or fatter
  - It’s [prima facie](https://en.wikipedia.org/wiki/Prima_facie) evidence

## What twin studies tell us about the genetics of obesity [20:30]

Peter asks, *what is the* [*concordance*](https://en.wikipedia.org/wiki/Concordance_(genetics)) *of obesity in identical twins separated at birth?*

- For monozygotic (or identical twins) separated at or nearly after birth, it’s nearly the same magnitude as it is for twins reared together, which is around 0.8
  - He misspoke in the podcast when he said the concordance is 0.9 and asked us to correct this number to 0.8
  - Published in the *International Journal of Obesity and Related Metabolic Disorders* in 1996,  [The heritability of body mass index among an international sample of monozygotic twins reared apart](https://pubmed.ncbi.nlm.nih.gov/8782724/)
  - Of course you can argue, well, that also takes into account the intrauterine environment, maybe some epigenetic things, but bottom line is whatever those things are, they’re not just child rearing of the home
  - Rearing of the home does have an influence, but it’s not huge
  - Peter notes, this is “*an incredible degree of concordance”*
- Peter asks when this degree of concordance was realized; when were these studies done?
- There were many hints for quite some period of time
  - Lots of people observed this in ranching data, mouse data, and family data
- But there was this moment where a key figure came in to both see it and say it with a degree of crispness that wasn’t there before
- In 1923, [Davenport](https://en.wikipedia.org/wiki/Charles_Davenport) published under the Carnegie Foundation, these studies of concordance of families; his 1923 data showed this genetic component
  - He is probably looked at now as a racist from the past
- But it was [Albert J. (Mickey) Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) who did the first major high quality twin and adoption studies
  - David knew Mickey; he was a wonderful man
  - He got Torkel Sorenson and other people to start working on twin studies with the great Nordic data, Sweden, Denmark, and so on, and adoption studies
  - It was the twin and adoption studies coming out of Sweden and Denmark that really nailed it
  - Finally in The *New England Journal of Medicine* with Mickey Stunkard behind it with clear writing, with high quality data, people said, “*We got it. There’s a big genetic component.*”
    - Published in 1986, [An Adoption Study of Human Obesity](https://www.nejm.org/doi/full/10.1056/NEJM198601233140401)
    - Published in 1990, [The Body-Mass Index of Twins Who Have Been Reared Apart](https://www.nejm.org/doi/full/10.1056/NEJM199005243222102)

## How doctors and scientists have historically approached obesity treatment [23:45]

- Peter notes when genetics play a role in disease, pharmacologic therapy makes sense
  - For example, if somebody is genetically predisposed to hypothyroidism, a doctor wouldn’t think twice about replacing thyroid hormone as necessary
    - The endocrine system is relatively straightforward to understand
- Why was there this disconnect in the early ‘80’s when it was understood that genetics plays a role in obesity but medical tools were not being used
  - What was being done?  Were people simply counseled to eat less and exercise more?

**A focus on reducing energy intake**

- Most of the focus was on developing tools to help people reduce energy intake
  - This is still the case today
  - Surgery and drugs mostly help people reduce calorie intake

> “*We know that reducing energy intake works. It’s just really hard to do, and telling people to do it and saying, ‘I’ll try to do it,’ is not all that effective*.” – David Allison

- Behavioral therapy began to be used in the ‘60’s
  - [Stewart](https://en.wikipedia.org/wiki/William_Stewart_Agras) began thinking about using behavioral therapy to treat obesity
  - It has continued to get better and better since then
- David’s sense is that we have been [asymptoting](https://en.wikipedia.org/wiki/Asymptote) for a long time
  - We’re getting incrementally better but not meaningfully better with many of the behavioral/cognitive things

**Early pharmaceuticals**

- In the early 90’s he was a postdoc at the New York Obesity Research Center
  - At this time a few people started using pharmaceuticals to treat obesity
  - [Fen-phen](https://en.wikipedia.org/wiki/Fenfluramine/phentermine) is a drug that came up and caught people’s attention
    - We now know it’s dangerous and it’s gone
- Fen-phen is a nickname for two drugs used in combination, phentermine and fenfluramine
- [Phentermine](https://en.wikipedia.org/wiki/Phentermine) is a drug that was and still is approved by the FDA for the treatment of obesity
  - Though it’s never been approved for long-term
  - This goes back a long way, it’s a [catecholaminergic](https://en.wikipedia.org/wiki/Catecholaminergic) [agonist](https://en.wikipedia.org/wiki/Agonist)
  - It’s a relatively safe drug; no drug is perfectly safe
  - It’s modestly effective
- [Fenfluramine](https://en.wikipedia.org/wiki/Fenfluramine) is a selective serotonergic reuptake inhibitor, which originally was used for depression and people realized sometimes those drugs ([SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor)) cause weight loss
- Somebody realized you could put those two together and it seemed to provide better results
  - So that became a big craze
  - There were many unscrupulous medical providers who did provided it in ways they shouldn’t have
  - But there were many scrupulous medical providers who used it carefully and thoughtfully, and it did seem to have much better benefit than other people had predicted before
- So suddenly, pharmaceutical treatment was starting to be credible
- People like [George Bray](https://en.wikipedia.org/wiki/George_A._Bray), who’s still around today and working on obesity, jumped on board and started to really think through all the cornucopia of pharmaceuticals we knew about and which ones might be useful
- Then a very young, smart pathologist at the Mayo Clinic (not an obesity researcher; David doesn’t remember her name) began noticing peculiar valvulopathy on autopsies
  - This was not a common thing
  - What they shared in common was the patients had been on fen-phen
  - This began the investigation into fen-phen
- People quickly realized that fen-phen did produce a certain valvulopathy and further investigation made it clear it was the fenfluramine component, not the phentermine component that did that
  - So fenfluramine was withdrawn
- Many drugs in the history of obesity hurt people; but what was good about this is prompted people to think more about obesity as a serious medical disorder
  - Obesity began to receive serious attention from credible physicians
  - And incredible scientists began working at the molecular pharmaceutical and physiologic level
- Peter asks, “*how much of Fen Phen’s mechanism was understood?*”
  - Was it simply that one component was increasing energy expenditure while the other was reducing appetite?
- David doesn’t think with any of these things we ever fully know the components, but it wasn’t that simple
- Compare it to statins, which are thought of so highly
  - It’s unclear whether they really have their beneficial effects by reducing LDL cholesterol (which is sort of the initial thought) or through other mechanisms (that are being debated now)
- Fen-phen was thought to reduce appetite through 2, slightly different mechanisms, and therefore help people control their food intake better
  - One was [serotonergic](https://en.wikipedia.org/wiki/Serotonergic) and the other was more [adrenergic](https://en.wikipedia.org/wiki/Adrenergic)
  - Phentermine more than the fenfluramine may have had modest effects on energy expenditure
- David doesn’t know the mechanism for the valvulopathy they cause
- Fen-phen was pulled in the late ‘90’s, maybe ‘97

**Surgical options**

*When did gastric bypass and other surgical approaches begin to be used?*

- David doesn’t know if there was a singular moment, rather it’s been sort of a steady march
- There was 1 key step in the credibility of the surgical approach
  - The Swedish obesity study from Lars Sjostrom in Sweden
  - Published in the *New England Journal of Medicine* in 2004, [Lifestyle, Diabetes, and Cardiovascular Risk Factors 10 Years after Bariatric Surgery](https://www.nejm.org/doi/10.1056/NEJMoa035622?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov)

> “*Surgery had been around for a while. Interestingly, even among physicians and scientists, it was very controversial and still is*.” – David Allison

- Some people think surgery is abhorrent, but he thinks you just have to take the data as it is
  - Would the world be better if no one needed surgery, yea; but that’s not the world we live in
- Surgery is the most effective life-saving, life-changing treatment we have, and it’s a good one
- Many physicians had vitriolic battles on this topic
  - David remembers John Carl (who was a very good surgeon) being chastised by a physician colleague over dinner at a conference
  - The physician told him, “*When you are done with a patient Dr. Carl, they will never eat normally again*”
  - Dr. Carl replied, “*No, when I’m done, they will never eat abnormally again*”
- As more and more surgeries were performed, people got better at doing them, mortality rates went down and efficacy went up

## Do surgical procedures for obesity prolong life? [32:00]

- Lars Sjostrom asked if these surgeries prolonged life
- David remembers Lars telling him about his senior mentor (Pierre Bjorn Thorpe)
  - Pierre Bjorn Thorpe was known for fat cell theories and the apple versus pear idea [body shape]
    - Jean Vogg proposed the idea of apple versus pear in France in the ‘50’s
    - But this idea really took hold in the ‘70’s and ‘80’s
    - Bjorn Thorpe was one of the big people that picked it up
  - Pierre laughed at him and said, “*Lars, everybody knows this. Everybody knows that surgery will cause weight loss and help people live longer. There’s no point in doing this study*.”
  - Lars replied, “*You may be right, that it does, but we have to do this study because everybody doesn’t accept and believe that and it hasn’t been shown*”

> “*We know over and over again, you’ve got to do the experiment*” – David Allison

- As [John Hunter](https://en.wikipedia.org/wiki/John_Hunter_(surgeon)) famously said to [Edward Jenner](https://en.wikipedia.org/wiki/Edward_Jenner), when Jenner says, “*I think*,” (and he’s thinking about the first vaccine), Hunter comes back and says, “*Why think? Do the experiment. Got to do the experiment and show it.*”
- Sjostrom didn’t do a pure experiment, not a randomized trial, but it’s a controlled trial
  - The [IRB](https://en.wikipedia.org/wiki/Institutional_review_board), at the time, didn’t think it was ethical to randomly assign people to either surgery or not
  - So if they were willing to get surgery, Sjostrom would find a closely matched control and give them usual care
  - He showed more than a decade later in the [*New England Journal of Medicine*](https://www.nejm.org/doi/10.1056/NEJMoa035622?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov) that surgery reduced the mortality rate
    - Surgery had very powerful effects on obesity
    - It was clearly a life-saving and a beneficially, life-changing treatment
    - This was probably a big jump
    - Since then, many other trials, some randomized, have been done showing positive benefits on many things, including longevity
- Peter asks what the risk reduction was in all-cause mortality
  - David doesn’t recall from that study, but looking across studies (as it varies a bit), it’s on the order of a 50% reduction, sometimes a little more
- How does this change in patients with and without [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)?
  - David doesn’t know off the top of his head, but he shares the intuition that it is probably more beneficial for people with type 2 diabetes
  - Many factors are involved
- One of the surprising things in the Swedish Obesity Study was the effect on hypertension
  - Diabetes really came down and stayed down very well, even if weight came back up a little (which it did, on average)
  - Hypertension came down as well, but did not stay down; it would come back up
    - Why was this?
    - Is it damage to the endothelial elasticity that’s not really repairable, and so you get a short-term effect of negative energy balance that’s not sustained?
      - It goes back to the need to do the experiment
      - You can’t make priority assumptions about the effects of treatments
      - You’ve got to do the experiment and look at the effects of treatments
- Peter notes, “*it’s interesting that hypertension would return and yet mortality would still improve*”
  - It’s surprising because of how causally related hypertension is to atherosclerosis
  - This suggests perhaps that the benefits of improved insulin sensitivity preserve and play a greater role in mortality than body weight
  - David notes that hypertension may be an additional role and if it too could be reduced over the long term, there would be an even bigger reduction in mortality

## The ‘Obesity Paradox’ [36:00]

*When did the idea of the* [*‘Obesity Paradox’*](https://en.wikipedia.org/wiki/Obesity_paradox) *start to be observed?*

- That phrase ‘Obesity Paradox’ has never been really crisply defined
  - And whether it really is something that’s a paradox is not clear
- People use it to mean at least 2 different things
  - There’s this so-called U-shaped curve, more accurately concave upward, it’s a bathtub shaped curve (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/02/f1-davidallison-1024x923.png)

**Figure 1. The relation between Longevity and obesity in humans**  Image credit: [*PNAS* 1958](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC528632/)

- So people at the very thin end also die earlier than people in the middle, just as people at the very heavy end die earlier
- We can argue whether it’s causal
- There are 2 observations here:
  - 1) It is clear that people thinner than those with an intermediate BMI also die earlier
  - 2) When people are sick or injured, obese people often live the longest
    - This is true even though obesity is associated with increased mortality rate or decreased longevity

- So if somebody comes in with kidney failure or someone comes in after a major injury or a major infection, they’re in the hospital, it’s often the heaviest people that live longer
  - This started to be talked about maybe 10, 15 years ago

> “*It’s very difficult to disentangle cause and effect. We can observe lots of associations, but it’s just hard to know what to make of all of these associations, and what’s causal*.” – David Allison

- There are multiple hypotheses that are consistent with the data
  - That’s why the randomized experiment allows us to do things that otherwise we can’t do, sort of eliminates more competing hypotheses
  - We don’t know what’s causal yet
- We have thrown out 1 model
- David and his postdoc (Doug Childers, a good mathematician) asked 2 questions:
  - 1) What if obesity makes it more likely that you get a major illness or injury
    - Could this be why obesity is associated with a risk of early mortality?
  - 2) Once you get a major illness or injury, does being heavier (more obese) reduce your risk of dying from it?
  - Compare to this analogy— suppose we are going on a hike in the Grand Canyon
    - We go to an outfitter and he says, “*you’re about 10 years younger than me; you have a choice.  I can give you this fat suit you can wear, it has lots of padding on it. If you fall off the cliff, it makes it much more likely you’ll survive, but it makes you a little clumsy. So it makes you more likely to fall off the cliff*”
    - You might think that you have good balance and eyesight, you’re  young and strong; so you say no to the fat suit
    - Somebody 10 years older may be struggling with eyesight, balance, or strength; and they may say yes, “*I’ll take the fat suit*”
    - And so whether the fat suit is good for you may depend upon the probability of falling, to begin with
  - Under that mathematical model, David can show, in fact, that the point of BMI, the nadir of that bathtub shape concave upward curve, should keep moving to the right as you age, which is exactly what it does
    - They have a model that’s consistent with the data, but the data don’t prove their model
    - There are other models that would be consistent with it

**Putting some numbers to it**

- Peter notes that this U-shaped curve gives an optimal BMI, a BMI associated with the lowest mortality (see the figure below)
  - Is David suggesting that instead of using 1 plot for everybody, graph it by decade?
  - What does this U-shape cure look like for people in their 20s, 30s, 30s…up to 90s?

![](https://peterattiamd.com/wp-content/uploads/2022/02/f2-davidallison-1024x994.png)

**Figure 2. Mortality rates versus BMI at age 20 (red), 30 (green), 40 (yellow), 50 (purple), 60 (magenta), and 70 (blue)**  Image Credit: [*International Journal of Obesity* 2010](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3186057/)

![](https://peterattiamd.com/wp-content/uploads/2022/02/f3-davidallison-1024x569.png)

**Figure 3.  BMI for a range of heights and weights, colors indicate World Health Organization BMI categories: underweight, normal weight, overweight, moderately obese, severely obese, and very severely obese**  Image Credit: [Wikipedia](https://en.wikipedia.org/wiki/Body_mass_index)

- David tells a story that’s not perfectly true; it’s roughly true; it conveys the nice element of this
  - The average American might gain about a pound a year
  - For an average height, about 6 or so pounds might be a [BMI](https://en.wikipedia.org/wiki/Body_mass_index) unit
  - And so that might mean that over 6 years, you’d be about one BMI unit heavier
  - And that’s not too far off from how the [nadir](https://en.wikipedia.org/wiki/Nadir) moves
  - It’s almost as though your weight is increasing to keep you at the nadir, which is an interesting speculation
  - And if you looked at people who are maybe 20 years old, that nadir might not be too far from 20, in some populations
- We can come back and make distinctions by age, race, and sex
- But putting that aside for the moment, very loosely speaking, you might say, that nadir might be far down near [a BMI of] 20 when you’re 20
  - And by the time you’re 80, it’s not to 80, but by the time you’re 80, it might be well above [a BMI of] 30, maybe even in the low 30s
    - We generally say, “*30 is the beginning of obesity*”
- For those who are not used to BMI’s, here are some touchstones (see also the previous figure)
  - The supermodel Kate Moss (at least a decades ago) had a BMI in 16 to 17 range
  - We say that about 18.5 is sort of the beginning of normal weight; less is underweight
  - David’s BMI right now is probably 21-ish
  - Bill Clinton’s BMI at the height of his presidency was probably 27, 28 (he’s since lost weight)
  - Obesity begins around a BMI of 30
  - A top class Sumo wrestler has a BMI of about 43, 44
  - So it’s really 30, 32, where you see people 70, 80, and above, having that lowest mortality rate

## Interpreting BMI and mortality data and considering confounders [43:15]

- Peter wonders if there is a risk that we are looking at confounders here?
  - Could affluence be a confounder?
  - When body composition is taken into account, do you see the same thing?
    - Some people have a BMI of 30 and fall into the obese category even though they only have 15% body fat; instead they are incredibly muscular
  - How do we reconcile, one, the potential confounders of that type of an analysis with this layer of granularity in the data that looks at adiposity versus lean mass?

> “*The confounding question is a nightmare*” – David Allison

- David notes this is the challenge of observational research in general
- There are no simple solutions to it, other than trying to triangulate on the answer with multiple studies
- What we really want are pure, randomized experiments in humans
  - With large samples and perfect compliance for many years
  - And we want to randomly assign people to be obese or not obese
  - Obviously, we can’t do that
- What we have is  observational epidemiology
  - There are randomized trials where people lose weight
  - There are non-randomized trials, like Sjostrom’s with surgery
  - There are mouse studies

> “*We look at all these different things, and we try to just put the puzzle together as best we can*” – David Allison

**Possibilities for confounding of the BMI, mortality data**

- There are a lot of possibilities for confounding, cigarette smoking was one of the early ones
  - Avery famous paper by [JoAnn Manson](https://en.wikipedia.org/wiki/JoAnn_E._Manson) and colleagues, published in *JAMA*, pointing out that the “*right way*,” to analyze BMI and mortality data was to exclude smokers; otherwise you may have confounding by smoking
    - Published in 1987, [Body Weight and Longevity: A Reassessment](https://jamanetwork.com/journals/jama/article-abstract/364101?resultClick=1)
  - Smoking makes you thinner; smoking kills you earlier
  - You’ve got to throw out the subjects who die early, because subjects who die early may have been sick
  - And sickness makes you thinner and makes you die earlier, that is a confounder
- It has since been proved mathematically, that throwing out these confounders is not a good thing to do
  - But for a long time, it was believed
- Peter asks about the low end of the BMI chart
  - One of the most obvious explanations for the uptick in mortality at very low BMIs, is all of liver disease, the kidney disease, the types of chronic diseases that actually do lead to muscle wasting and things like that
- David includes them in his analysis
  - What they’ve shown is that throwing out subjects who die early in the analysis doesn’t help, or it doesn’t reliably help
  - What they showed is not that that confounding doesn’t occur
    - Confounding absolutely can occur and they think it’s likely

**David’s early work analyzing BMI data** [46:15]

- When David went to analyze his first BMI mortality data set, he had no training in this
  - So he called up his friends to ask about it and ask for references to explain this
  - The **epidemiologists** would say “*No, it’s obvious that it works*”
    - David replied, “*Well, it’s not obvious to me*”
    - And they said, “*Well, maybe you’re not smart enough to be an epidemiologist*”
  - When he asked the **statisticians** about a paper that says you have to eliminate early death in the analysis, they would laugh and they replied, “*That’s the most ridiculous thing I’ve ever heard. We don’t just throw out data and think it makes things better. You’ve got to have a model that you fit things to*.”
- David got a small grant from the CDC and looked at mathematical proofs, computer simulations, and meta-analysis
- The mathematical proof showed that not only did removing early deaths help reduce the confounding, it could make it worse
- Simulation showed the same thing in realistic data scenarios
- Then the meta-analysis showed that on average it didn’t make much difference at all

> “*So throwing out the subjects who die early, basically, just reduces your power in most practical situations*” – David Allison

**Confounding factors**

- People suggested throwing other people out of the analysis, to control for intermediary variables
  - Diabetes and hypertension
    - Cutting people with these conditions out of the analysis wasn’t enough to flatten out that left end of the U-shaped curve
  - So he also cut out people with a lot of weight fluctuation
    - This got rid of most of it, but it didn’t completely get rid of it
    - This was one of the bigger variables, but what it means is unclear
- [Katherine Flegal](https://en.wikipedia.org/wiki/Katherine_Flegal) has written very well on this, and talked about how much you’re throwing away
  - She points out that we do observe these patterns, but what they mean causally is unclear

**Stigma from being overweight may have an effect**

- The bottom line is, it’s likely that there’s confounding by cigarette smoking and socioeconomic status and stigma

> “*How much does obesity kill you because it stigmatizes you and it creates some stress?”* – David Allison

- Stigma may be why the BMI associated with the lowest mortality has been increasing over calendar time
  - It’s not just with age of individuals
  - If you compare data collected in the 1970s to data collected in the 1990s, obesity doesn’t look quite as bad in the 1990s as it did in the 1970s
    - At least from an association point of view
    - This is true in Denmark, in the US, in meta-analyses
    - But it’s not true for every age, race, sex group
      - Why is that?
      - Maybe it’s stigma
- If you’ve ever watched that old TV show, [*The Three Stooges*](https://en.wikipedia.org/wiki/The_Three_Stooges), the character Curly was often mocked as the fat guy
  - By today’s standards, he’s not that big
  - So as different BMIs become normative, stigma too changes over time
  - Maybe this accounts for part of it
- There’s lots of potential confounding going on there, but there’s lots of other possible explanations

**Important questions**

- The bottom line, we don’t know; and the real important question then is, what’s the effect of intervention?
- One of the clearest thinkers David knows is [Don Rubin](https://en.wikipedia.org/wiki/Donald_Rubin), a statistician at Harvard
  - He developed the [Rubin Causal Model](https://en.wikipedia.org/wiki/Rubin_causal_model)
  - He is always asking, “*What’s the intervention? If you say, does this cause that? What do you mean? Compared to what?*”
  - It’s always got to be compared to what?
- So if you say weight loss is going to increase longevity (that’s the question) well, how are you going to achieve that weight?
  - What are you going to do to get that?
  - If it’s surgery, then what’s the effect of surgery?
  - If it’s a GLP-1 agonist, what’s the effect of a GLP-1 agonist, et cetera?
- David thinks this is the key question
- We are starting to see that some of these things do prolong life: surgery, SGLT-2 inhibitors, GLP-1 agonists, and so forth

## How body composition and ethnicity factor into consideration of BMI data [50:30]

- BMI is a measure of mass divided by stature
- It was developed back in the 19th century by [Adolph Quetelet](https://en.wikipedia.org/wiki/Adolphe_Quetelet), who was a Belgian astronomer, epidemiologist, statistician, mathematician, a brilliant guy
- One would think that the mass of a three dimensional object ought to increase in proportion to the cube of a linear dimension
  - If we were spheres of uniform density, but we’re not
  - Empirically, BMI works closer to the square for adult humans
- Quetelet said, “*Take mass or weight over stature squared, the square of stature*”
  - Then it was called Quetelet’s Index
  - Now we call it BMI
  - It was rediscovered in the ‘60s or ‘70s by [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys), and termed BMI, body mass index
  - And every few years, some smart person likes to come along, says, “*It should be cubed*”
- BMI doesn’t really take into account body composition
  - The NBA center would have a BMI greater than 30 and yet look how strong and fit that person is
    - What physician in their right mind would diagnose them as obese?

> “*BMI is a useful tool for epidemiologic research and some simple physiologic research and some simple clinical trials, it’s not a perfect clinical tool*” – David Allison

- For the average person, BMI works okay

**Do conclusions about BMI hold up in different ethnicities?**

- Peter asks about different ethnicities, Asians, East Asians
  - Some people are [skinny fat](https://apoorvamandavilli.com/wp-content/uploads/2010/10/April04-1.pdf#page=7), they have a BMI of 26 but have metabolic syndrome, tons of visceral fat, very little muscle mass ([see Ethnic Differences in BMI and Disease Risk](https://www.hsph.harvard.edu/obesity-prevention-source/ethnic-differences-in-bmi-and-disease-risk/))
  - This is a different phenotype than perhaps what the model was built on
- How much is the metric that we use for BMI validated in other ethnicities?
  - Where a BMI of 20 to 25 is about perfect
  - 25 to 30 is overweight
  - 30 to 40 is obese
  - Then morbidly obese kicks in at some point
- With a few exceptions, the idea that there’s a curve and that it’s a generally concave up curve
- Yes, there are exceptions
- The shape of that curve is not the same in every age, race, and sex group
- It does seem that the right side (the part where you’re getting too high in BMI and risk is going up) seems to occur a lot *earlier* among people of Middle Eastern and East Asian descent
- So this is very simple model to use just 1 curve for everybody
- A slight more complicated models takes into account some of the other factors
  - How much of your fat is subcutaneous versus how much is visceral.
    - Some groups have more visceral fat than the others for any given body mass index; and therefore it adjusts the curve

> “*The narratives we have about obesity, including about ethnicity and obesity, are grossly oversimplified*” – David Allison

- So we often hear, “*Obesity’s selectively a disease of the poor and uneducated*”
- In this country, it’s often stated, “*Minority status leads to less income, less education, which in turn, leads to poorer access to healthcare, poorer habits, poorer living environments, which leads to poor health and reduced longevity*”
  - And there’s probably some truth to that, but it’s not 1 to 1; it’s not simple
- For example, when we hear that there’s this inverse relationship between socioeconomic status and obesity, this varies depending on ethnicity
  - We hear this over and over again
  - It was first shown by [Mickey Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard), again, in the 1950s, in the Midtown Manhattan Project
  - It’s reliably true in adult white women
  - When you go outside the group of adult white women, it’s not always true
  - If you go to African American women, there is virtually no association between socioeconomic status and obesity
  - When you go to African American men and look at their obesity levels, they’re very similar to the obesity levels of European American men, white American men
  - But if you look at African American women’s obesity levels, and you compare it to European or white American women, it’s much higher
  - If you bring Hispanic Americans in, both men and women have higher levels of obesity, than do European American men and women
  - So in Hispanic Americans, there is an ethnicity difference (but not by gender)
  - In African Americans, there is a gender by ethnicity difference
  - When you look at mortality, the African American curves follow similarly, but not identically, to the European American curves
- But in Hispanic Americans, David’s research can’t find an association between BMI and longevity in this group
  - This is true across all BMIs
  - The data sets they have are not perfect; the follow-ups may not be long enough, the sample sizes may not be big enough
  - He’s not saying it’s causal, he’s only explaining what they observed in publicly available datasets of Hispanic Americans
  - Analysis of BMI and longevity could not show an association between elevated BMI and mortality in Hispanic Americans

## Superior tools for measuring obesity at the individual level [57:15]

- Peter is at the other end of the spectrum in terms of concerns at the public health level; he has the luxury of looking at 1 person at at time and trying to come up with the best course of action
- His view of BMI is quite negative
  - Maybe it’s the least bad tool available to get massive data sets and broad assessments on, for understanding what’s going on at the population level
- But BMI offers little insight, relative to other tools
- Peter uses **other tools to measure obesity**; [DEXA scans](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) provide 4 points of information:
  - 1) % body fat
  - 2) Visceral fat (VAT, visceral adipose tissue)
  - 3) Bone mineral density
  - 4) Appendicular Lean Mass Index, a measure of muscle mass
  - It also provides information about subcutaneous fat, but that doesn’t seem to matter because it is incredibly genetic and relatively uncoupled from metabolic health
  - VAT, the visceral adipose tissue seems to be much more tightly correlated to what we see when we look at more sophisticated biomarkers of insulin sensitivity and metabolic health, and any evidence of liver fat
- So Peter is glad he gets to look at these other metrics
  - It’s a luxury that a statistician or an epidemiologist doesn’t have
  - At the individual level, there is much more data and you can be more nuanced in your appreciation for things
- Peter wonders if at the population level, something better than BMI will come alone one day
  - This example with the Hispanic subset is mind boggling and speaks to the futility of BMI measurement in some populations
- David acknowledges this is one plausible interpretation
- He doesn’t think we’re far away from better tools
- He published some work years ago on the idea of using 3D photography, take a picture of somebody from a couple of angles
  - This came out of work experience way back at the New York Obesity Research Center, when [Steve Heymsfield](https://www.pbrc.edu/research-and-faculty/faculty/heymsfield-steven-phd.aspx?faculty=4060) (David’s mentor) would study professional basketball players
  - He was the king of body composition, and he would study them
  - Technicians who measured people’s body composition every day would say, “*I can look at a person and tell you how much fat they have. And I’ll be very accurate*.”
  - David thought if they could do this with their eye, then he could do it with a camera
  - He got a NIH grant with [Olivia Affuso](https://www.uab.edu/norc/about-us/members/regular/olivia-affuso) and Steve Heymsfield to look at this; they published a paper on it, and since then many others have done it as well
  - He thinks Amazon may be working on this or already have something out on this; we’ll get to the point where we have 3D photography
- If you can measure something’s weight and volume, you know it’s density
  - If you know a little bit about human anatomy, you can figure out from density, body fat
  - He can do this with a camera
- To measure mass there is: DEXA, plethysmography, isotope dilution techniques, etc.
- There’s this idea of fit for purpose
  - If you were to say, “*Is my vehicle that I drive, is this precision enough for the Indy 500?*’ The answer is no; you need a better vehicle
    - But I’m not in the Indy 500, I’m just driving 5 miles to and from work every day; it’s fine
  - Similarly, if you were to say, “*What proportion of that country has obesity?*”
    - BMI probably provides a reasonable estimate
  - But if you want to say, “*I want to help this individual patient*,” especially at the sort of the kind of artisan level that Peter goes at
    - Then you need better tools

## Using BMI data for actionable steps to combat obesity [1:02:00]

**Important questions**

With BMI we can accurately plot out the histogram of exactly what the BMI is by age and by demographic and all those things

- Questions:
  - Are people in Indiana more or less healthy than people in Kentucky?
  - And are they more or less healthy than the average American?’
  - What can we do to improve their health?
  - Could everybody become healthier?
  - Could we extend the life of the average person in the state of Indiana by three years?
    - What would the intervention need to be?
    - These questions lead to more complicated problems
- David notes when he talks to people, even physicians, even highly educated scholars, there’s this bifurcation
  - There’s the data and those who look at the data, and if they’re really honest, they say, “*We agree. Surgery works, pharmaceuticals work, individualized or group-based clinical treatment with behavioral cognitive techniques work somewhat for some period of time, meal replacement formulas work, somewhat for some period of time*.”
  - But if you’re honest, all the public health stuff we’ve tried for obesity doesn’t work
- He gets asked a lot, “*What is your goal?*”
  - Is it to expose people to ideas so the next really smart kid can figure it out
    - This goal of raising consciousness is fine
  - Is the goal to tell communities, “*We know you’re suffering and we know this is concerning, and we want you to know we care, and we’re trying. We’re not really going to necessarily reduce obesity levels. We want you to know we care, and you want farmers markets in the school parking lot. You want vending machines changed. You want running tracks built in your neighborhood. We’ll build a running track and so on. And we’ll feel better about we’re caring for each other, but it’s probably not going to affect obesity, given what we know right now*”
  - Or is the goal to actually have less people suffer from obesity; to reduce the obesity levels and improve public health?
    - This won’t win any feel-good awards
- Successful approaches include: surgery, pharmaceuticals, and to some extent, individualized treatment, cognitive behavioral group-based treatment, including things like meal replacements and so on
- If the state of Indiana handed me $10 million and said, “*Make a difference*” he:
  - Would NOT build farmers markets in school yards
  - He would give a small number of people bariatric surgery
    - And a subset of those would likely live longer, on average

## Why maintaining weight loss is more challenging than losing weight [1:06:00]

- This is a tough one; there is probably no single explanation
- You can approach this from an evolutionary perspective, biochemical perspective; you can think about mechanisms
  - David doesn’t know all the answers
- From the evolutionary point of view, for a long time, the meme was it’s the [thrifty gene hypothesis](https://en.wikipedia.org/wiki/Thrifty_gene_hypothesis) from [James Neel](https://en.wikipedia.org/wiki/James_V._Neel)
  - The idea is that animals/ humans throughout evolutionary history have been on the brink of starvation
  - They did anything they could to preserve energy
    - When given the opportunity to get more energy, they ate as much as they could, while they could
  - Now in the modern environment, most of use over consume
- David think’s this is simplistic for many reasons
  - 1) As the lawyers say, *“Objection, it assumes facts, not in evidence*”
    - It’s not at all clear that humans have been on the brink of starvation throughout history
    - [Robert Fogel](https://en.wikipedia.org/wiki/Robert_Fogel), who won the Nobel prize for looking at these old data, going back to at least the 1700s, of British naval recruits and other places, saw that BMI (on average) went up over the centuries
      - There’s a little fluctuation as things get better and worse in places
  - 2) How does this account for pregnancy
    - The latest data from [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) and colleagues in *Science* suggests that women’s energy intake doesn’t need to go up that much during pregnancy, but they still go up
      - Published in August 2021, [Daily energy expenditure through the human life course](https://www.science.org/doi/10.1126/science.abe5017)
      - So, if humans have been reproducing for millennia, where did all that extra energy come from if we were all on the brink of starvation all the time?
  - 3) Anybody whoever goes fishing knows that the idea that every animal is hungry all the time and is going to grab every bite of food you throw in front of it, is not true
  - 4) Some animals do get obese when given unlimited food, some don’t, both within and across species there’s lots of differences
- This is where John Speakman came in and questioned this idea
- Speakman thinks its [freedom from predation](https://www.cell.com/cell-metabolism/fulltext/S1550-4131%2807%2900160-X)
  - Back in history we were prey; then there was a certain point where we learned to use tools and hunt together, and we stopped being prey, and we started being predators
  - When we switched from being prey to predators, we didn’t need to hide in our boroughs and eat the least we could because every time we came out we were potentially exposed to a predator
  - As a predator we could sort of walk around and eat kind of ad-lib
  - In this situation, the genes that were being selected for that gave us satiety mechanisms that kept our weight down were no longer under selection
  - It wasn’t that nature was selecting for genes that made us fatter; instead nature was not selecting for genes that keep us thin
    - [Drift mutations](https://en.wikipedia.org/wiki/Genetic_drift) allow this to happen
  - There’s not just 1 factor

**Compare to sexual reproduction to understand fitness**

- Why is maintaining weightloss difficult?
- David compares this question to the evolution of sexual reproduction, “*the queen of questions in biology*”
  - Nobody can really figure out why do we have sexual reproduction when asexual seems so much more efficient from a [genetic fitness](https://en.wikipedia.org/wiki/Fitness_(biology)) point of view
  - People have proposed different hypotheses for it and no one seems to work mathematically
  - Maybe it only works mathematically when you put all these hypothesis together
  - Maybe it’s just an inelegant solution
- For example, [Daph (*Daphnia*)](https://en.wikipedia.org/wiki/Daphnia) is a species that can reproduce both sexually and asexually (see the figure below)
  - There are many species that can do this
  - In asexual reproduction an organism makes a copy of itself; it reproduces all of its genes
  - From the [Richard Dawkins](https://en.wikipedia.org/wiki/Richard_Dawkins) point of view, [*The Selfish Gene*](https://www.amazon.com/Extended-Selfish-Gene-Richard-Dawkins-dp-0198788789/dp/0198788789/ref=mt_other?_encoding=UTF8&me=&qid=1643642044), those genes all got their way
    - Those genes all won; they got copied
    - And genes that are good at getting copied will get copied again in the future, so you have more of those
    - That’s how evolution works

![](https://peterattiamd.com/wp-content/uploads/2022/02/f4-davidallison-1024x980.png)

**Figure 4. The life cycle of** ***Daphnia*** **species alternates between asexual (parthenogenetic) and sexual reproduction**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Daphnia)

- Sexual reproduction requires a partner
  - This invites questions like why are there only 2 sexes?
    - Why Have sexes at all?
    - DNA could be exchanged without sexes; bacteria do it through [conjugation](https://en.wikipedia.org/wiki/Bacterial_conjugation)
  - Say there are two sexes male and female, they come together and the offspring has roughly 50% of the genetic material of one parent and 50% of the other
    - The organism only copied half of itself so it didn’t win as much as if it copied itself entirely
    - Why would an organism switch to sexual reproduction?
    - It’s very inefficient from a genetic fitness point of view
- The most compelling hypothesis David has heard is the so-called red queen hypothesis
  - This is from [*Alice in Wonderland and Through the Looking Glass*](https://www.amazon.com/Alice-Wonderland-Through-Looking-Glass/dp/B004NKCQA0/ref=sr_1_1?crid=33PN9U90OJG9P&keywords=Alice+in+the+Looking+Glass&qid=1643642453&s=books&sprefix=alice+in+the+looking+glass%2Cstripbooks%2C152&sr=1-1) where the red queen is running with Alice
  - Alice at one point says, “*We don’t seem to be getting anywhere.*” And the red queen says, “*Oh, in this world you have to run as fast as you can just to stay in place*.” Alice says, “*Oh, in my world we run and we actually get somewhere*.”
  - The red queen hypothesis is the idea that you keep running as fast as you can just to stay steady
    - This means, as humans live for a long time, there are these microbes in a human and they’re evolving much more rapidly because they have a much more shorter generation time
    - As these microbes evolve, they start to get good at getting past human defenses and locks
    - They start developing keys to the locks and the human wants to reset the locks
    - The way you reset the locks is by getting a partner and mixing up your DNA with them
  - The idea is that sexual reproduction is a way to keep up with the Jones’s
    - And the Jones’s are all the microbes in your body
    - This is the red queen hypothesis
- Peter notes that if humans used asexual reproduction, we would have a population of identical people
  - There might only be a few hundred thousand gene pools
  - David agrees, there would be much less diversity
- From a species point of view, if you believed in group selection, then you’d say, “*this is good for the species*”
- A smart evolutionary biologist would come along and say that group selection doesn’t make sense
  - Selection occurs at the individual or gene level
  - It has to make sense for that individual; it has to enhance their fitness or their gene’s fitness
  - One can argue that if only half the genes get reproduced, then the fitness level has to double to break even; this doesn’t really hold up
- [Muller](https://en.wikipedia.org/wiki/Hermann_Joseph_Muller) and others have argued that if you consider a handful of things, put them together, that maybe the math works; but it’s very inelegant
  - It’s probably the same with people and evolution
- [Neel](https://en.wikipedia.org/wiki/James_V._Neel) had his [thrifty gene hypothesis](https://en.wikipedia.org/wiki/Thrifty_gene_hypothesis); which argues you need to be selected to get food when you can
  - Maybe not everybody was dying of starvation, but if you’re not getting enough food you may not be big enough to win the battle for mates in a polygyny physical combat mating system
    - That may select for wanting to eat more
  - If women get too thin, they stop menstruating
    - They may not die of starvation, but their reproductive fitness goes down
- Another idea centers around predation; freedom from predation is an idea [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) supports
- Food safety is another idea; this is supported by [Gary Beauchamp](https://en.wikipedia.org/wiki/Gary_Beauchamp), from [Monell Chemical Census Center](https://en.wikipedia.org/wiki/Monell_Chemical_Senses_Center)
  - Back in time before refrigeration and a modern, safe food supply, every time you ate something you were potentially exposed to microbes and toxins (not just predators)
    - Eating less meant less exposure
  - But now with a safer food supply, this pressure is less
- Cooperative living is another angle; as a group it’s a bad situation if the members are so hungry all the time they are willing to kill each other for the last bite
  - It would be good to have some satiety mechanisms to preserve social order
  - Then everyone gets to eat a little and can work together to build tools and so on

## Differing perspectives on the utility of nutritional epidemiology [1:16:30]

- Epidemiology is married very closely with statistics
  - Without statistics you can’t really do epidemiology
- Most people understand this field has its limitations
- There are 2 camps, 2 ends of the spectrum of views on nutritional epidemiology
  - 1) There’s a camp of people that would say there is absolutely nothing wrong with epidemiology, nutritional epidemiology
    - It is a masterful tool that provides exceptional insights without which we would be lost
  - 2) There are people who say this is a tool that has probably reached its peak of utility
    - The epidemiologists should probably focus on other problems outside of nutrition now
    - Peter is a little closer to this end of the spectrum

**David’s perspective on nutritional epidemiology**

- David feels this is a topic that needs more discussion
- In group 2 are the abolitionists:
  - [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) said nutrition epidemiology is a dead science and it’s time to bury the corpse
  - [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes) has been very critical
  - [Nina Teicholz](https://en.wikipedia.org/wiki/Nina_Teicholz) and many others have pointed out that perhaps this is just a worthless waste of time and misleading
- Group 1 is the other end of the spectrum
  - They are defenders of the status quo that say nutrition epidemiology is imperfect, as all tools are, but it is still a very valuable tool
  - They claim there’s nothing seriously wrong with it  and those who criticize it are naive and ignorant
  - David doesn’t think that Gary Taubes, John, and Nina are naive and ignorant

> “*We know that there’s something wrong there. When we look at the evidence, it’s very clear that many findings from nutrition epidemiology have not held up once we’ve done randomized controlled trials*.” – David Allison

**What is going on? Why don’t the findings of these studies hold up?**

- People will argue that there is nothing wrong with the evidence
  - That meta-analysis on intervention and non-randomized studies give very similar findings to randomized studies
    - But they’re often citing a non-randomized intervention study or a non-randomized observational study of pharmaceutical or other medical treatment
    - They’re usually not citing nutritional studies
    - These are very different situations
- David argues that findings of nutritional epidemiology often don’t hold up very well
- When you really look, you see a lot of things that look like obfuscation, exaggeration, sweeping under the rug of measurement error, and so on
- There are huge issues with confounding
- There are huge measurement problems
- Many people say the status quo is not okay
  - More change is needed than some minor fine-tuning

> “*We need reformation but we also need to use these tools well. This field is not going to go away whether you want it to or not*.” – David Allison

**Reform is needed**

- David believes reformation is essential; the status quo is completely unacceptable
  - But abolition is neither realistic nor desirable
- In one observational epidemiology nutrition study, the author correctly and honestly points out that it’s an observational study
  - It reports an association, it doesn’t necessarily show causation
  - Then says, “*but how could I be wrong?*”
    - It could be that a measurement error creates this problem
    - The authors reply, “*I used a validated food frequency questionnaire so it’s really okay*.”
    - It could be confounding due to socioeconomic status
    - Does the nurse who works in a poor school in rural Indiana has the same socioeconomic status as the nurse who is married to a billionaire?
  - They dismiss the idea that it’s not really causation
- It would be okay measured and controlled for all these things: food intake, diet composition, housing and socioeconomic status, genetic background
  - But you could never do this in humans

## A mouse study illustrating the impossibility of fully controlling for confounds in observational studies [1:22:15]

- These controlled studies have been done in mice
- David ran a mouse study where he randomly assigned mice to eat different amounts of calories, but all on the same diet
  - Published in the *European Journal of Clinical Investigation* in 2016, [Observational Research Rigor Alone Does Not Justify Causal Inference](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5118066/)
  - The mice were all given the same food
  - They were all genetically identical because they were an inbred, isogenic strain ([C57BL/6 mice](https://en.wikipedia.org/wiki/C57BL/6))
  - They’re all in the same housing conditions
  - There’s no smoking.
  - He had 4 groups of mice, randomly assigned to 1 of the following groups:
    - 1) Low calorie
    - 2) Medium calorie
    - 3) High calorie effectively
    - 4) [Ad libitum](https://en.wikipedia.org/wiki/Ad_libitum)
- What he found was the more calories he assigned the mice to eat, the shorter they lived
  - No surprise; this has been shown a thousand times in the literature by [Roy Wallford](https://en.wikipedia.org/wiki/Roy_Walford), [Rick Weindruch](https://experts.news.wisc.edu/experts/richard-weindruch), and others over the decades
- The interesting finding was with the *ad libitum* group
  - Within that group, some chose to eat more than others
  - Further, in this group they now have an observational epidemiologic study and can correlate amount chosen to be eaten with longevity

> “*Those mice that choose to eat more live longer. The association in the observational component is exactly opposite to the causal effect in the experimental component*.” – David Allison

- People argue that this observation is confounding
  - They argue that the mice that are the strongest and healthiest have the biggest appetites and eat more
  - This observation is confounding by general health
- David agrees, and this is the point
  - In an observational study that is more pristine than anybody will ever be able to do in humans, they can’t reproduce the cause of effect
  - This suggests to David that reform is needed

**Observational studies can be improved**

- David would love it if he never heard the plural analogy— there are no randomized controlled trials of parachute jumping
  - There’s a wonderful book called, [Randomistas](https://www.amazon.com/Randomistas-Radical-Researchers-Changing-World/dp/0300236123/ref=sr_1_1?crid=1KY5ODSCMIX50&keywords=Randomistas+by+Andrew+Leigh&qid=1643812155&sprefix=randomistas+by+andrew+leigh%2Caps%2C67&sr=8-1) (like fashionistas) by [Andrew Leigh](https://en.wikipedia.org/wiki/Andrew_Leigh)
  - He says actually there are randomized controlled trials of parachute jumping
  - It’s just not true
    - Peter asks how the IRB for that was ever approved
    - Participants have to be in the army
  - This is used often as an excuse to argue, “*I can’t do the pure perfect pristine randomized control trial so therefore you have to accept any old observational study*”
  - David doesn’t agree
- David acknowledges that we may have to accept that we’re going to draw some inferences from something other than the pure classic pristine randomized control trial
  - But in between that and any old observational epidemiologic study, there’s a lot of space
- There are better studies
  - Co-twin controls (hinted at that earlier) use identical twins and we randomly assign each to a different group
  - For example, randomly assign 1 twin to exercise a lot; their twin brother doesn’t exercise, but has the same genotype
    - That’s a tight control
  - How about observing interventions, even if they are not assigned at random
    - For example, build a restaurant in 1 town but not another
    - This is the realm of [Bethany Bell](https://sam.research.sc.edu/uscera/facultyExpertise/cv/27731), she [looks at food deserts](https://www.ncbi.nlm.nih.gov/pmc/articles/pmid/32543428/) and things
    - Built a grocery store where there was a food desert and we’re told that food deserts are a problem, but it doesn’t look like things got better when we built the grocery store
      - That’s a much stronger design than just asking people how far away do you live from a grocery store?

## Limitations of nutritional epidemiology and how it can improve [1:26:30]

**Peter’s take away from this**

- Peter remarks that the mouse study is remarkable
- One reason why Peter struggles so much with the legitimacy of epidemiology has to do with food-frequency questionnaires
  - He simply can’t take seriously anything that relies on these questionnaires
  - For every patient he’s ever come in contact with, to try to accurately assess what they eat based on a food frequency questionnaire is a fool’s errand
    - These questionnaires are simply unrelated to what they eat, full stop
- The second issue he has with nutritional epidemiology comes down to the [hazard ratios](https://en.wikipedia.org/wiki/Hazard_ratio) that very commonly show up and lead to grand statements
  - For example, a hazard ratio on the order of 1.16 being used to support a causal relationship between bacon and cancer is weak

> “*What would the actual fathers of epidemiology be saying in their graves if they were looking at these strengths of association?*” – Peter Attia

- Peter’s not saying there should be no epidemiology
- But there needs to be a referendum on how the media is taught how to interact with such studies and on how we scrutinize some of the methodologies behind these things
  - For example, checking a food frequency questionnaire once in an 8-year study just doesn’t mean anything
  - Amazingly though, this is the basis of an observation
  - This is a problem

**David’s discussion of reforms needed**

- David notes that many people incorrectly perceive the problem to be a measurement issue
  - They agree that measurement of food intakes is a big problem but think everything else is fine
  - David’s mouse study show that when the measurement is near perfect, everything is not fine
- We don’t have to go back to the fathers of epidemiology

- We can go back to at least [Confucius](https://en.wikipedia.org/wiki/Confucius) who says, “*To know what you know and to know what you do not know, that is true knowledge*”

> “*This idea that we have to be honest with ourselves and each other about what we know and don’t know and how we know it and don’t know it is clear. I think that’s part of that reform.*” – David Allison

- We need a greater level of honesty
- [Simine Vazire](https://en.wikipedia.org/wiki/Simine_Vazire) just had a paper in one of the peer review journals, looking at or writing about [epistemic](https://en.wikipedia.org/wiki/Epistemology) humility and saying when you get to the discussion section of a paper and you consider that the hypothesis that you made, which now seems to be supported by your data, and you say, “*but I might be wrong*”
  - Published in *Nature Human Behavior* in October 2021, [Aspiring to greater intellectual humility in science](https://pubmed.ncbi.nlm.nih.gov/34711978/)
  - It’s not honest for the discussion to systematically go through with the greatest effort and art to show how the findings are not wrong, and how all the competing explanations can be dismissed
    - This is not an honest epistemic
  - An honest epistemic humility would say, “*I really might be wrong, and here’s all the ways I might be wrong that I and others should test going forward*”
- Michael Strevens in his book, [*The Knowledge Machine*](https://www.amazon.com/Knowledge-Machine-Irrationality-Created-Science/dp/1631491377/ref=sr_1_1?crid=YXGIB4ASM8N5&keywords=The+Knowledge+Machine+strevens&qid=1643814997&sprefix=the+knowledge+machine+strevens%2Caps%2C97&sr=8-1), does a beautiful composition, decomposition, construction, deconstruction of this, and talks about the idea of communities doing this
  - The battle shouldn’t be [*ad hominem*](https://en.wikipedia.org/wiki/Ad_hominem)
  - The battle shouldn’t be undercutting each other by who you are, and who you work for, and what your beliefs are
  - He calls that the iron rule of evidence

> “*It needs to be a battle about the data*” – David Allison

- David doesn’t think the nutrition epidemiology field has been quite honest about the limits of its measurement
  - Neither has its attackers
- David has been careful about saying he thinks measurements of energy intake and expenditure from self-report methods are so bad that they shouldn’t even be used
  - To say that it’s so bad, one can’t even be guaranteed to get the directional effect; so don’t even use it
- But on the other hand, if the question is, do people eat vegetarian or not, or eat kosher or not, or eat after midnight or not
  - He doesn’t know; maybe people do report this type of information accurately
    - Maybe they don’t; he honestly doesn’t know
  - He thinks it’s important to look at the purpose of the self-reporting questionnaire
- [Katherine Flegal](https://en.wikipedia.org/wiki/Katherine_Flegal) wrote a very famous paper about the obesity wars
  - Published in *Progress in Cardiovascular Disease* in 2021, [The obesity wars and the education of a researcher: A personal account](https://www.sciencedirect.com/science/article/pii/S0033062021000670?via%3Dihub)
- David notes that her meta-analysis published in 2005 really got people’s attention
  - Published in *JAMA*, [Excess deaths associated with underweight, overweight, and obesity](https://jamanetwork.com/journals/jama/fullarticle/200731)
  - This analysis found that BMIs in the overweight range were actually not strongly associated and consistently associated with increased mortality rate
    - In some cases were associated with lower mortality rate
    - The media went crazy, responding as if this were a new finding
  - The new finding that there’s a genetic component to obesity
    - This was known decades ago
  - The people that are the defenders of you can never be too rich or too thin went crazy and attacked her
    - But this wasn’t new data, it was a [meta-analysis](https://en.wikipedia.org/wiki/Meta-analysis)
    - In the 1950’s [Linus Pauling](https://en.wikipedia.org/wiki/Linus_Pauling) (the double Nobel Laureate) has a paper on BMI and life expectancy; it’s got a bathtub shape curve
  - This report was not new at all, but somehow it was seen as new
  - People started attacking her very vociferously
    - One investigator called it a worthless pile of rubbish
    - David thinks these are very inappropriate statements
  - The data are the data whether the person on the paper has a MD or not

> “*In science, three things matter: the data, the methods used to collect the data (which give them their probative value), and the logic which connects the data and the methods to conclusions. Everything else is not science*.” – David Allison

- It may be pragmatic to say, “*Oh, I trust Peter and he’s a smart guy. I know he studies a lot and he tells me I should eat this*”, but it’s not science
- The science is the data, the methods, and the logic connecting the data to conclusions; not whether I trust you or not
- All these *Ad hominem* things were said, they way they attacked her; it was very vociferous and very inappropriate
  - But there are many other people who’ve been attacked
  - David has been attacked
- When [Nina Teicholz](https://en.wikipedia.org/wiki/Nina_Teicholz) had an editorial in Lancet, talking about some elements of nutrition, and fat, and carbohydrate, and many people wrote in trying to get it retracted
  - This is a sort of regular occurrence now
- When [Brad Johnston](https://foodscience.tamu.edu/people/johnston-bradley/) published on red meat roughly 2 years ago, he was vigorously attacked
  - It was a big meta-analysis showing that the association between red meat consumption and negative health outcomes was not strong and compelling
  - Published in *Annals of Internal Medicine* in 2019, [Red and Processed Meat Consumption and Risk for All-Cause Mortality and Cardiometabolic Outcomes: A Systematic Review and Meta-analysis of Cohort Studies](https://www.acpjournals.org/doi/full/10.7326/M19-0655?rfr_dat=cr_pub++0pubmed&url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org)
  - People tried to get it retracted before it was published instead of just engaging with the data, the methods, and the logic
    - Thankfully it wasn’t retracted
- This sort of thing happens a lot in obesity and nutrition
  - It happens elsewhere too; it’s terrible
  - David thinks this is because nutrition has to do with the everyday experience
  - All of us eat every day, almost all of us eat almost every day
    - Food is culture; it’s family; it’s love; it’s economy; it’s commerce; it’s political beliefs; it’s philosophical beliefs
    - It’s so connected to so many emotional things
    - We all have that everyday experience and have to make decisions every day
    - We make these decisions and then we may want to justify them; we may need to believe they’re good

> “*We may mistake our experience for expertise*” – David Allison

- David thinks when you get into any field where people have everyday experience, people have very strong feelings and often will opine quite aggressively in the absence of data

## Addressing the obesity epidemic—the path forward and obstacles to overcome [1:37:15]

- Some pretty exciting pharmacologic things have come along
  - [Semaglutide](https://en.wikipedia.org/wiki/Semaglutide) (a glucagon-like peptide-1 receptor agonist) is a remarkable drug

> “*It’s certainly the most impressive thing that I’ve seen clinically for obesity*” – Peter Attia

- 25 years ago when he was in medical school, Peter remembers the first gastric bypass he ever saw in a surgical rotation
  - This was before they were done laparoscopically; it was done as an open roux-en-Y gastric on a 400-pound man who would die 40 days later in the hospital of sepsis
  - He never got out of the hospital; he had an anastomotic leak
  - That was a very dangerous operation 25 years ago
- Today, that operation is done laparoscopically; it is an incredibly safe procedure, and it has also remarkable efficacy
- Amazing progress has been made on the surgical front and pharmacological front
- It’s not clear why progress hasn’t been made on the nutritional front
- David notes that letters between President Taft (who was very obese) and his physician about diet were found recently
  - These could have easily been letters written today
  - A diet has not been found that reliably causes sustained weight loss

**The big question— what diet results in sustained weight loss?**

- David questions the underlying premise
  - Why should there be one diet that causes sustained weight loss?
  - This is important to think about
- There is a misperception in the field around nutrition and weight loss or food intake and weight loss
  - That there is a good diet with respect to weight loss, such that for most people, if they just ate the right way, they wouldn’t have to count calories
  - They wouldn’t have to be uncomfortable and hungry
  - They wouldn’t have to feel deprived and yet would maintain a good, healthy weight
  - David has no reason to believe that’s true
- Lots of people argue it is diet A or diet B
  - This one thinks it’s low carb and that one thinks it’s high or low fat
  - This one thinks it’s don’t eat at night
  - This one thinks it’s whatever it is, eat paleo, et cetera

> “*Maybe the null hypothesis is, it doesn’t matter that much*” – David Allison

- There isn’t such a diet for many people
- Now, for some people, they do maintain a normal, healthy, desirable weight without trying to restrict their energy, but maybe for others, it’s just not the case
- David thinks the paths forward are manifold

> “*I think in some cases we are on the good path and in some cases, we are wandering in the drunkards walk*” – David Allison

**Where we are making good progress**

- We’re on the good path I think on surgery and pharmaceuticals
  - There is clearly a long way to go, but they’ve gotten much better
  - David would love to see more funding for good research
- We need to get on a much better path as a society making obesity treatments available to people
  - If you have cancer, we’re willing to treat you
  - If you have obesity, maybe not
    - If you’re rich, you can pay for that
    - If you’re not rich, what do you do?
- We’re on a good path on stigma, but there’s a long way to go
  - As a society, we’ve woken up to say stigmatizing obese people is not okay
  - Shaming people about their body habit is not okay
- Sometimes the counterargument is, “*But it’s good for them because it’ll help them want to lose weight*.”
- And sometimes the argument made against the shaming is empirical
  - The evidence shows that people who experienced a lot of weight shaming gain more weight
  - Then the causal thing is thrown in, so therefore, you shouldn’t do it
  - It’s a moral issue; it’s not an empirical issue
- We know so much more about genes, and physiology, and metabolism, and cells with respect to obesity and nutrition than we knew 20, 30, 40 years ago

**Where we are not making progress**

- The one area where we are *not* making progress, and we aren’t yet on a good path, is with this public health community, school based, community based, policy based approach

> “*I think we are continuing to look for our keys under the lampposts because that’s where the light is as opposed to where the keys might be*” – David Allison

- We continue to ignore the data
- We keep saying the same old suggestions that people have been trying for decades
  - And that when you really look at the data, these have at best not been shown to work, and at worst been shown to not work
  - There are some people who have patently obfuscating those data
- The [cluster randomized trials](https://en.wikipedia.org/wiki/Cluster_randomised_controlled_trial) we see in the childhood obesity literature bring to mind the phrase that rhymes with cluster muck
  - This is distorted evidence, this is science gone wrong in the worst sens
- We’ve got to clean up the quality of the science we do
- We’ve got to start treating this like science
  - Just as much as the science of quirks, or tires on automobiles, or beta cells of pancreases
  - Treat it like real science and take it just as seriously

**The cluster randomization problem**

- A [cluster randomized trial](https://en.wikipedia.org/wiki/Cluster_randomised_controlled_trial) is a trial which instead of randomizing the individual unit of observation (one person), entire intact units are assigned to one treatment or another
  - An individual might be a child in a school who you either assigned to the treatment group, maybe it’s exercise, or the control group, no special exercise
  - An entire intact unit might be a classroom, or a school, or a neighborhood, or a family
- There’s nothing wrong with randomizing a unit of people as long as there are at least 2 clusters assigned to each condition
  - This allows some ability to observe variants
  - Although frankly, with only 2 there is so little power and robustness; for practical purposes, that would be invalid, but theoretically it’s valid
- Then one must analyze the data to take into account *both* what’s called the clustering and the nesting
  - The *clustering* is that you have people grouped and that grouping leads to more similar individuals
    - So imagine that we did a trial and the trial was you and your brother randomly assigned to eat low carb, and me and my brother randomly assigned to eat high carb; and at the end we see a difference by an ordinary [t-test](https://en.wikipedia.org/wiki/Student%27s_t-test)
    - One question that arises— was that the effect of diet or is it that the Attia brothers are different from the Allison brothers?
    - This has to be taken into account, so you need more than 1 cluster
    - So if you get the Attia brothers, and the Jones brothers, and the Allison brothers, and the Smith brothers, now, in theory, you can do it
  - But now you can’t treat us like we’re 8 different people; what you really have is 4 different clusters, 4 different sets of brothers
  - This must be taken into account and it results in less [degrees of freedom](https://en.wikipedia.org/wiki/Degrees_of_freedom_(statistics))
    - People don’t do that reliably and they don’t do it correctly often, and that leads to many papers being wrong
    - David has written countless letters to editors about this
- There have probably been at least 3 or 4 cluster randomized trials retracted as a result of letters he’s written
  - People have had to come back and just say, “*The results don’t hold up*”
- But until this has changed, we have people out there who understandably say, “*But I read these papers suggesting that this works. Gardening in schools makes kids thinner*.”

> “*That’s not what the results showed, but that’s what the paper says*” – David Allison

- And until we become more rigorous and more honest, we’re not on the right path

## What David believes to be the most promising interventions we could take to address obesity and improve public health [1:47:30]

Peter asks David what intervention (or set of interventions) could improve public health outcomes

- *What would he test first?* ⇒ **General education**, not nutrition education, general education
  - There are provocative data strongly suggesting that general education, especially for girls and women, leads to lower BMIs, lesser rates of obesity, and lesser diabetes than less education
  - Some studies in Europe of policies where someone puts in a policy and it effectively gives a cohort of people more education show this results in that cohort, less obesity, especially among women
  - There’s a famous study by the Ramey’s, who are a husband and wife investigative team ([Craig Ramey](https://fbri.vtc.vt.edu/people-directory/primary-faculty/ramey-c.html) and [Sharon Landesman Ramey](https://en.wikipedia.org/wiki/Sharon_Landesman_Ramey))
    - They worked at [UAB](https://www.uab.edu/newsarchive/43387-ramey-receives-top-honor) when David first got there,
    - They started a study decades ago at [UNC](https://fpg.unc.edu/), it was [head start](https://en.wikipedia.org/wiki/Head_Start_(program)) on steroids
    - They called it the [Abecedarian study](https://abc.fpg.unc.edu/abecedarian-project)
    - They gave these kids the super head start program; it was mostly just general education, there may have been a little nutrition education
    - It wasn’t a weight loss study
    - 30 years later they followed-up on the participants
    - There’s a paper in *Science* on this; the women have less obesity
    - Published in 2014, [Early Childhood Investments Substantially Boost Adult Health](https://www.science.org/doi/10.1126/science.1248429)
  - The [Moving to Opportunity Study](https://en.wikipedia.org/wiki/Moving_to_Opportunity#:~:text=Moving%20to%20Opportunity%20for%20Fair,high%2Dpoverty%20public%20housing%20projects.) funded by [The Department of Housing and Urban Development](https://www.nber.org/programs-projects/projects-and-centers/moving-opportunity?page=1&perPage=50) took families who lived in so-called poor neighborhoods, and they randomly assigned them either
    - 1) To a control group, where they basically got nothing
    - 2) Or to a group where they received housing vouchers; but the housing vouchers required that they moved to less poor neighborhoods
    - What they found years later in follow up is that there was less obesity and diabetes in those assigned to move to the less poor neighborhoods and given the financial wherewithal to do so
    - Published in the *New England Journal of Medicine* in 2011, [Neighborhoods, Obesity, and Diabetes — A Randomized Social Experiment](https://www.nejm.org/doi/full/10.1056/NEJMsa1103216)
    - Published in *Science* in 2012, [Neighborhood Effects on the Long-Term Well-Being of Low-Income Adults](https://www.science.org/doi/10.1126/science.1224648)
    - These studies suggest that general education may help
- This speaks to this whole socioeconomic thing we started about way earlier— what is it about higher socioeconomic status that at least in some groups (not all, but at least in white women) seems to be associated with less obesity?
  - David doesn’t know what the causal mechanisms are
- So if somebody said to him, “*You’re going to be the king for a year, and you’ve got the federal budget, and you can take this big chunk of money, and you can make an impact on obesity and diabetes*.”
- He would choose to divide it into 4 pots
  - 1) One pot is going to be surgery, and it’s going to be both providing it and continuing to study it
  - 2) The next one’s going to be pharmaceuticals, both providing it and continuing to study it
  - 3) The third pot is going to be some general education, maybe general wellbeing, safety, security, starting in early childhood to see whether that alone is enough
    - Reducing disparities back to [Confucius](https://en.wikipedia.org/wiki/Confucius); Confucius said, “*We are not so concerned with an absence of wealth, we are concerned with a disparity of wealth*.”
    - It may be that reducing disparities is really important
  - 4) And then the fourth pot would be basic research, basic science questions
    - Look at [senolytics](https://en.wikipedia.org/wiki/Senolytic), and look at [microchimerism](https://en.wikipedia.org/wiki/Microchimerism), and all the things that you talk about so often in your podcast, but against both metabolism, and obesity, and nutrition, but also the fundamentalist in essence
    - David wonders if we use microchimerism (or sanalytics) to restore people to younger metabolic states?

## Reproducibility in science, normative and non-normative errors explained [1:51:30]

- David was on a panel set up by the National Academy of Science, Engineering, and Medicine; they looked at the question of reproducibility in science
  - [Reproducibility and Replicability in Science](https://www.nationalacademies.org/our-work/reproducibility-and-replicability-in-science)
- The phrase that [Harvey Feinberg](https://en.wikipedia.org/wiki/Harvey_V._Fineberg) (who was the chair of the panel) started using is— “*no crisis but no cause for complacency*”
  - The idea is that we must make things better
- There might be some things that are getting worse, but on average, there’s a lot of evidence that things are getting better
- David finds that science is better and more rigorous than it’s ever been in history
- But we also see all the flaws and science must get better
  - This is why [Marcia McNutt](https://en.wikipedia.org/wiki/Marcia_McNutt) (the President of the National Academy of Sciences) instantiated this new [strategic council on trust and integrity and rigor in science](https://www.nationalacademies.org/news/2021/07/new-strategic-council-for-research-excellence-integrity-and-trust-established-by-national-academy-of-sciences-to-support-the-health-of-the-research-enterprise) and very generously appointed me as one of the 3 co-chairs.
  - Many other organizations are also trying to help on this too
- Peter asks how much of this situation is intrinsic to science itself and how much is a result of the media’s interface with science
- David thinks both are important
  - Michael Strevens book, mentioned earlier, ([*The Knowledge Machine*](https://www.amazon.com/Knowledge-Machine-Irrationality-Created-Science/dp/1631491377/ref=sr_1_1?crid=YXGIB4ASM8N5&keywords=The+Knowledge+Machine+strevens&qid=1643814997&sprefix=the+knowledge+machine+strevens%2Caps%2C97&sr=8-1)) does a wonderful job explaining how hard science is
- We have to make the distinction between normative errors and non-normative errors

**Normative errors**

- [Normative](https://en.wikipedia.org/wiki/Normativity) errors occur because of limitations in instruments/ technology used to study a phenomenon
- Consider 2 examples:
  - 1) A few hundred years ago [Galileo](https://en.wikipedia.org/wiki/Galileo_Galilei) was under house arrest, and from his house Galileo directs a study
  - He has two colleagues go out to 2 tops of mounds, or hills, or mountains far apart, each holding a lantern with shutters and a synchronized watch or timepiece
  - He direct them at a predetermined moment to open their shutters and record when they see the other guy’s light
    - He wants to figure out whether light travels instantaneously or not
  - They conclude that light travels instantaneously because they can’t discern any time delay
    - Today we know that’s wrong
    - But with their instrumentation they couldn’t have done better; this is a normative error
    - Galileo didn’t do anything wrong; it’s great question and great way of working on it
  - 2) Similarly, when [Linus Pauling](https://en.wikipedia.org/wiki/Linus_Pauling) says DNA is a triple helix before [Watson and Crick](https://en.wikipedia.org/wiki/Molecular_Structure_of_Nucleic_Acids:_A_Structure_for_Deoxyribose_Nucleic_Acid) show it’s a double hex
  - Pauling didn’t have good x-ray crystallography data, he’s working at the edge; this is a normative error

**Non-normative errors**

- A very famous non-normative error is people working to determine the size of the thymus gland in children
  - They used cadavers in the early 20th century
    - Poor people tend to become cadavers, poor children tend to be undernourished
    - Undernourished children tend to have smaller thymus glands
- So when physicians started seeing richer children dying of sudden infant death syndrome, and they examined them, they thought, “*That’s a big thymus gland*”
  - Well, it was actually a normal thymus gland because their norms were determined from undernourished kids
  - The doctors then proceeded to irradiate these kids with big thymus glands to prevent sudden infant death syndrome
    - This probably caused lots of cases of thyroid cancer because the thyroid and the thymus us are very close to each other
  - This is an example of a non-normative error because even 100 years ago, any epidemiologist or statistician could have told you that is bad sampling and bad inference from bad sampling

**Current examples of non-normative errors**

- The distinction between normative and non-normative errors needs to be made
- A lot of the errors in nutrition epidemiology today cannot be called normative errors anymore, these are non-normative
- The misanalysis of the cluster randomized trials, these are not normative
  - Any statistician knows how to do it
  - People are either obfuscating or they’re just woefully ignorant and not using professional statisticians when they need to
- People are using food frequency questionnaires to draw causal inference about some of these things we have discussed, these are not normative errors, people should know better
- Then there’s the stuff about the more general public about believing things and how we promote our ideas
  - This is where the scientific community needs to take responsibility

## Rebuilding trust in science and differentiating between science and advocacy [1:59:00]

> “*I think we need to be prepared to lose some battles in order to win the intellectual war*” – David Allison

- This means we need to be prepared to not use all the rhetorical tools at our disposal at any one point in time to convince somebody that X is true
  - Even when we’re really worked up and think it’s important we believe X is true
  - Even when we think it’s important that others believe X is true because we want them to eat what we think is good
    - Or we want them to eat more broccoli and less ice cream, we want them to take their vaccine, wear their mask, wear their seatbelt, stop smoking
  - We may be right about all those things, but if we use rhetorical devices, the we may win that battle may lose the war in **helping people think though what good evidence** is and elevating our level of dialogue
    - Rhetorical devices such as if you and I are debating and I attack you on that homonym grounds, or I exaggerate the strength of my evidence, or I don’t honestly say that I’ve shown an association and not causation
  - Compare this to what a late night comedian would’ve said 30 years ago in making jokes about wives, and husbands, and race, and sex
    - That would never be considered acceptable today
  - We are able to change societal norms about dialogue
- There is a need to elevate our societal norms of dialogue on epistemological and empirical issues
  - So that ordinary people can say, “*Oh, you’re telling me you have a treatment for X. Was there a study? Was the study in humans? Was it a randomized study? Was it a study of the actual outcome you’re making a claim about? Was it a study that was long enough for this to be a meaningful outcome? Was there a statistically significant result? Was the result big enough to matter? Was the dose a dose I might realistically take?*”
    - Those are not all that difficult questions to train ourselves and each other to reliably ask
    - And if we just reliably ask those and reliably and honestly answer them, this can take us a long way
- Peter agrees and thinks of discussions about COVID
  - COVID has been such a polarizing scientific phenomenon in a way that he’s become quite frustrated in watching it
  - COVID has accelerated the loss of the public’s faith in science
  - Well-meaning public health officials have simply failed to communicate the nuance of science and lost so much credibility

**The difference between science and advocacy**

- David reflects that part of the problem is the lack of clarity on the identity of whose speaking
- We need to be clear when we are speaking as scientists versus advocates
  - Scientists must not compromise the truth
  - The standard is not so high for an advocate
- Scientists can advocate but need to make it clear by saying “*I’m not being a scientist right now, I’m just telling you what I want you to do. And I’m going to say whatever I need to say to convince you*”

**Trust**

- Another important component is trust
- David hears a lot that trust in science has been really weighed down in the last few years
  - He doesn’t think it is true
  - It depends what you mean by science
  - If what you mean is science as a process of developing and finding knowledge, he knows of no evidence that it’s down
  - If what you mean by science is trust in individual elements of the scientific community then he’s not sure it’s down either, but it’s spread around
    - Some people think [Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) is trustworthy and some people think [Gwyneth Paltro](https://en.wikipedia.org/wiki/Gwyneth_Paltrow) is trustworthy
    - Some people think David Allison is and some people think Peter Attia is; and some people think we’re corrupt, and ignorant, and confused, and terrible
- The challenge is that there are people who cannot distinguish between the statements of a Tony Fauci and **the extent to which they are or are not backed by evidence**, and the statements of a [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) and the extent to which they are or not backed, versus the statements of a Gweneth Paltro or somebody else
  - That’s the challenge

> “*It’s not that people don’t trust science, it’s that people don’t know which voice to trust as a communicator of the science and therefore they don’t trust individual elements of the canon of science.*” – David Allison

- This can be seen in nutrition
  - There’s a nice [summary on the Pew Charitable Trust website](https://www.pewresearch.org/science/2019/08/02/findings-at-a-glance-nutrition-research-scientists/) now indicating that trust in science is high, trust in dieticians is high, trust in medical doctors who talk about nutrition in treating their patients is high
  - But trust in nutrition scientists is low compared to dieticians and medical doctors who talk about nutrition, and compared to other scientists
- So in nutrition we have met the enemy and it is us
  - We have shot ourselves in the credibility foot with our obfuscation, and our exaggeration, and our hype
  - David thinks that pocket of trust is gone even though trust in science overall has not down
- Peter really likes this point; the difference  between science and advocacy can’t be overstated
  - It would be amazing if people, himself included, had the self-awareness to speak and know which hat we were wearing
  - Think about the problems that could be solved if people always had to have a hat on; they couldn’t blind the listener to which hat they were wearing
  - The **scientist hat**— focused on the nuanced hard truth, as messy as it might be, as unclear as it might be, with no regard for how a person feels when they hear it and what action they may or may not take as a result of it
  - This is different from the **advocacy hat**— saying, “I *want to change your behavior because I think it’s in your best interest*.”
  - We can come up with a two hat system and everybody gets to own two hats

§

## Selected Links / Related Material

**Concordance of BMI in monozygotic twins**: [The heritability of body mass index among an international sample of monozygotic twins reared apart](https://pubmed.ncbi.nlm.nih.gov/8782724/) | *International Journal of Obesity and Related Metabolic Disorders* (D B Alison *et al.* 1996) | [20:30]

**Swedish obesity study from Lars Sjostrom in Sweden**: [Lifestyle, Diabetes, and Cardiovascular Risk Factors 10 Years after Bariatric Surgery](https://www.nejm.org/doi/10.1056/NEJMoa035622?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov) | *New England Journal of Medicine* (L Sjöström *et al.*  2004) | [20:45]

**Stunkard’s key publications on the genetics of obesity**:

- Published in 1986, [An Adoption Study of Human Obesity](https://www.nejm.org/doi/full/10.1056/NEJM198601233140401) | *The New England Journal of Medicine* (AJ Stunkard *et al*. 1986) | [22:45]
- Published in 1990, [The Body-Mass Index of Twins Who Have Been Reared Apart](https://www.nejm.org/doi/full/10.1056/NEJM199005243222102) | | *The New England Journal of Medicine* (AJ Stunkard *et al.* 1990) | [22:45]

**Doug Childers’ and David Allison’s publication on the ‘Obesity Paradox’**: The ‘Obesity Paradox:’ a parsimonious explanation for relations among obesity, mortality rate, and aging? | *International Journal of Obesity* (DK Childers and DB Allison 2010) **|** [38:15]

**JoAnn Manson’s paper on excluding smokers from BMI mortality analysis**: [Body Weight and Longevity: A Reassessment](https://jamanetwork.com/journals/jama/article-abstract/364101?resultClick=1) | *JAMA* (JE Manson *et al.* 1987) | [45:00]

**Women’s energy needs during pregnancy**: [Daily energy expenditure through the human life course](https://www.science.org/doi/10.1126/science.abe5017) | *Science* (H Pontzer *et al.* 2021) | [1:07:45]

**Book claiming randomized controlled trials of parachute jumping**: [Randomistas: How Radical Researchers Are Changing Our World](https://www.amazon.com/Randomistas-Radical-Researchers-Changing-World/dp/0300236123/ref=sr_1_1?crid=1KY5ODSCMIX50&keywords=Randomistas+by+Andrew+Leigh&qid=1643812155&sprefix=randomistas+by+andrew+leigh%2Caps%2C67&sr=8-1) by Andrew Leigh (2018) | [1:24:45]

**Mouse study found mice who chose to eat more lived longer**: [Observational Research Rigor Alone Does Not Justify Causal Inference](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5118066/) | *European Journal of Clinical Investigation* (K Ejima *et al.* 2016) | [1:22:15]

**Simine Vazire calls for epistemic humility in the discussion section of papers**: [Aspiring to greater intellectual humility in science](https://pubmed.ncbi.nlm.nih.gov/34711978/) |  *Nature Human Behavior* (R Hoekstra and S Vazire 2021) | [1:29:00]

**Strevens book calls for epistemic humility and a focus on data**: [The Knowledge Machine: How Irrationality Created Modern Science](https://www.amazon.com/Knowledge-Machine-Irrationality-Created-Science/dp/1631491377/ref=sr_1_1?crid=YXGIB4ASM8N5&keywords=The+Knowledge+Machine+strevens&qid=1643814997&sprefix=the+knowledge+machine+strevens%2Caps%2C97&sr=8-1) by Michael Strevens (2020) | [1:29:45]

**Katherine Flegal’s papers about the obesity wars**:

- [The obesity wars and the education of a researcher: A personal account](https://www.sciencedirect.com/science/article/pii/S0033062021000670?via%3Dihub) | *Progress in Cardiovascular Disease* (KM Flegal 2021) | [1:31:15]
- [Excess deaths associated with underweight, overweight, and obesity](https://jamanetwork.com/journals/jama/fullarticle/200731) | *JAMA* (KM Flegal *et al.* 2005) | [1:31:30]

**Nina Teicholz’s editorial in Lancet**: [Response to critique of review of The Big Fat Surprise](https://pubmed.ncbi.nlm.nih.gov/31226050/) | *Lancet* (N Teicholz 2019) | [1:34:45]

**Brad Johnston’s meta-analysis challenges the association between red meat consumption and negative health outcomes**: [Red and Processed Meat Consumption and Risk for All-Cause Mortality and Cardiometabolic Outcomes: A Systematic Review and Meta-analysis of Cohort Studies](https://www.acpjournals.org/doi/full/10.7326/M19-0655?rfr_dat=cr_pub++0pubmed&url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org) | *Annals of Internal Medicine* (D Zeraatkar *et al.* 2019) | [1:35:00]

**Children who completed the early education (Abecedarian program) had better health outcomes 30 years later**:  [Early Childhood Investments Substantially Boost Adult Health](https://www.science.org/doi/10.1126/science.1248429) | *Science* (F Campbell *et al.* 2014) | [1:49:00]

**The Moving to Opportunity Study showed moving to a less poor neighborhood was associated with improved health outcomes**:

- [Neighborhoods, Obesity, and Diabetes — A Randomized Social Experiment](https://www.nejm.org/doi/full/10.1056/NEJMsa1103216) | *New England Journal of Medicine* (J Ludwig *et al.* 2011) | [1:49:00]
- [Neighborhood Effects on the Long-Term Well-Being of Low-Income Adults](https://www.science.org/doi/10.1126/science.1224648) | *Science* (J Ludwig *et al* 2012) |  [1:49:00]

**Findings by the Pew Charitable Trust, trust in dieticians and doctors is high but trust in nutrition scientists is low**: [Findings at a glance: Nutrition research scientists](https://www.pewresearch.org/science/2019/08/02/findings-at-a-glance-nutrition-research-scientists/) | Pew Research Center (August 2, 2019) | [2:08:30]

**A few of David’s publications on how to improve research**:

- [Reproducibility: A tragedy of errors](https://www.nature.com/articles/530027a) | *Nature* (DB Allison *et al.* 2016)
- [Childhood Obesity Intervention Studies: A Narrative Review and Guide for Investigators, Authors, Editors, Reviewers, Journalists, and Readers to Guard Against Exaggerated Effectiveness Claims](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7436851/) | *Obesity Reviews* (AW Brown *et al.* 2019)
- [Toward more rigorous and informative nutritional epidemiology: The rational space between dismissal and defense of the status quo](https://pubmed.ncbi.nlm.nih.gov/34678079/) | *Critical Reviews in Food Science and Nutrition* (AW Brown *et al.* 2021)

§

## People Mentioned

- [Donald Rubin](https://en.wikipedia.org/wiki/Donald_Rubin) (friend and Emeritus Professor of Statistics at Harvard University) [6:45]
- [Stanley Schacter](https://en.wikipedia.org/wiki/Stanley_Schachter) () [10:30]
- [Kelly Brownell](https://en.wikipedia.org/wiki/Kelly_D._Brownell) (Duke University clinical psychologist who studies obesity) [15:00]
- [Thomas (Tom) Wadden](https://en.wikipedia.org/wiki/Thomas_Wadden) (University of Pennsylvania psychologist who studies obesity) [15:00]
- [Albert (Mickey) Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) (University of Pennsylvania psychiatrist who described binge eating) [15:00, 22:45, 55:15]
- [Charles Davenport](https://en.wikipedia.org/wiki/Charles_Davenport) (biologist and eugenist in the early 12900’s) [22:30]
- [William Stewart Agras](https://en.wikipedia.org/wiki/William_Stewart_Agras) (Stanford psychiatrist who studied binge eating and behavioral therapy) [25:15]
- [George Bray](https://en.wikipedia.org/wiki/George_A._Bray) (Louisiana State professor who studies obesity and metabolism) [27:30]
- Lars Sjostrom (Swedish doctor who studied bariatric surgery) [30:45]
- Pierre Bjorn Thorpe (senior mentor of Lars Sjostrom) [31:30]
- [John Hunter](https://en.wikipedia.org/wiki/John_Hunter_(surgeon)) (distinguished Scottish surgeon in the late 1700’s) [33:00]
- [Edward Jenner](https://en.wikipedia.org/wiki/Edward_Jenner) (British physician and scientist who developed the smallpox vaccine) [33:00]
- [Joann Manson](https://en.wikipedia.org/wiki/JoAnn_E._Manson) (Harvard physician best known for work on preventing chronic disease in women) [45:00]
- [Katherine Flegal](https://en.wikipedia.org/wiki/Katherine_Flegal) (CDC epidemiologist who studies obesity) [18:15, 1:31:00]
- [Donald (Don) Rubin](https://en.wikipedia.org/wiki/Donald_Rubin) (Harvard statistician who developed the [Rubin Causal Model](https://en.wikipedia.org/wiki/Rubin_causal_model)) [49:45]
- [Adolph Quetelet](https://en.wikipedia.org/wiki/Adolphe_Quetelet) (developed BMI) [50:45]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (physiologist who studied influence of diet on health) [51:45]
- [Steven Heymsfield](https://www.pbrc.edu/research-and-faculty/faculty/heymsfield-steven-phd.aspx?faculty=4060) (David’s mentor at the New York Obesity Research Center) [59:45]
- [Olivia Affuso](https://www.uab.edu/norc/about-us/members/regular/olivia-affuso) (obesity and nutrition scientist who worked with David at the New York Obesity Research Center) [1:00:15]
- [James Neel](https://en.wikipedia.org/wiki/James_V._Neel) (geneticist known for the [thrifty gene hypothesis](https://en.wikipedia.org/wiki/Thrifty_gene_hypothesis)) [1:06:30]
- [Robert Fogel](https://en.wikipedia.org/wiki/Robert_Fogel) (Nobel Prize winning economic historian and scientist) [1:07:15]
- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) (British biologist working at the University of Aberdeen studies energy expenditure in animals) [1:07:45, 1:15:00]
- [Richard Dawkins](https://en.wikipedia.org/wiki/Richard_Dawkins) (evolutionary biologist, Professor at New College, Oxford) [1:11:00]
- [Hermann Joseph Muller](https://en.wikipedia.org/wiki/Hermann_Joseph_Muller) (geneticist) [1:14:00]
- [James V. Neel](https://en.wikipedia.org/wiki/James_V._Neel) (geneticist, developed the thrifty gene hypothesis) [1:14:15]
- [Gary Beauchamp](https://en.wikipedia.org/wiki/Gary_Beauchamp) (expert in chemosensory science and former director of the [Monell Chemical Census Center](https://en.wikipedia.org/wiki/Monell_Chemical_Senses_Center)) [1:15:00]
- [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) (Stanford professor of epidemiology, proponent of evidence-based research) [1:18:00, 2:08:00]
- [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes) (science writer and author of many books on nutrition) [1:18:15]
- [Nina Teicholz](https://en.wikipedia.org/wiki/Nina_Teicholz) (journalist and author who has focused on nutrition) [1:18:15]
- [Roy Wallford](https://en.wikipedia.org/wiki/Roy_Walford) (UCLA pathologist, a proponent of calorie restriction) [01:23:00]
- [Richard Weindruch](https://experts.news.wisc.edu/experts/richard-weindruch) (University of Wisconsin-Madison professor of medicine, a a proponent of calorie restriction) [01:23:00]
- [Andrew Leigh](https://en.wikipedia.org/wiki/Andrew_Leigh) (former professor of economics, Australian politician, author) [1:24:45]
- [Bethany Bell](https://sam.research.sc.edu/uscera/facultyExpertise/cv/27731) (Studies food deserts, Professor of Social Work at the University of South Carolina) [1:26:00]
- [Confucius](https://en.wikipedia.org/wiki/Confucius) (Chinese philosopher from the late 16th century) [1:28:30, 1:50:45, 2:11:15]
- [Simine Vazire](https://en.wikipedia.org/wiki/Simine_Vazire) Professor of Psychology Ethics and Wellbeing at the University of Melbourne [1:29:00]
- Michael Strevens (author of [The Knowledge Machine: How Irrationality Created Modern Science](https://www.amazon.com/Knowledge-Machine-Irrationality-Created-Science/dp/1631491377/ref=sr_1_1?crid=YXGIB4ASM8N5&keywords=The+Knowledge+Machine+strevens&qid=1643814997&sprefix=the+knowledge+machine+strevens%2Caps%2C97&sr=8-1)) [1:29:30, 1:55:00]
- [Katherine Flegal](https://en.wikipedia.org/wiki/Katherine_Flegal) (epidemiologist at the CDC who studies obesity) [1:31:00]
- [Linus Pauling](https://en.wikipedia.org/wiki/Linus_Pauling) (biochemist in the early-mid 1900’s, double Nobel Laureate) [1:32:30]
- [Nina Teicholz](https://en.wikipedia.org/wiki/Nina_Teicholz) (journalist and author of *The Big Fat Surprise*) [1:34:45]
- [Bradley Johnston](https://foodscience.tamu.edu/people/johnston-bradley/) (Professor of Nutrition at Texas A&M University) [1:35:00]
- [Craig](https://fbri.vtc.vt.edu/people-directory/primary-faculty/ramey-c.html) and [Sharon Landesman Ramey](https://en.wikipedia.org/wiki/Sharon_Landesman_Ramey) (husband-wife investigative team at UNC then UAB who studied early education) [1:48:30]
- [Harvey Feinberg](https://en.wikipedia.org/wiki/Harvey_V._Fineberg) (Chair of the National Academy panel on reproducibility and replicability in science) [1:52:00]
- [Marcia McNutt](https://en.wikipedia.org/wiki/Marcia_McNutt) (the President of the National Academy of Sciences)  [1:54:15]
- [Galileo Galilei](https://en.wikipedia.org/wiki/Galileo_Galilei) (16th-17th century astronomer) [1:55:30]
- [Linus Pauling](https://en.wikipedia.org/wiki/Linus_Pauling) (20th century biochemist) [1:56:45]
- [Watson and Crick](https://en.wikipedia.org/wiki/Molecular_Structure_of_Nucleic_Acids:_A_Structure_for_Deoxyribose_Nucleic_Acid) (20th century molecular biologists) [1:56:45]
- [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) (director of NIAD and chief medical advisor to the president) [2:07:45]
- [Gwyneth Paltro](https://en.wikipedia.org/wiki/Gwyneth_Paltrow) (actress) [2:07:45]
- [David Allison](https://en.wikipedia.org/wiki/David_B._Allison) (obesity researcher and Dean of The Indiana University School of Public Health-Bloomington) [2:07:45]
- [Peter Attia](https://en.wikipedia.org/wiki/Peter_Attia) (physician focused on applying science to longevity) [2:07:45]

§

![](https://peterattiamd.com/wp-content/uploads/2022/02/david-allison-1x1-1-500x500.jpeg)

##### David Allison, Ph.D

David B. Allison received his Ph.D. from Hofstra University in 1990. He then completed a post-doctoral fellowship at the Johns Hopkins University School of Medicine and a second post-doctoral fellowship at the NIH-funded New York Obesity Research Center at St. Luke’s/Roosevelt Hospital Center. He was a research scientist at the NY Obesity Research Center and Associate Professor of Medical Psychology in Psychiatry at Columbia University College of Physicians & Surgeons until 2001. He became Dean and Provost Professor at the Indiana University School of Public Health-Bloomington in 2017. Prior he was Distinguished Professor, Quetelet Endowed Professor, and Director of the NIH-funded Nutrition Obesity Research Center (NORC) at the University of Alabama at Birmingham.

He has authored more than 600 scientific publications and received many awards, including the 2002 Lilly Scientific Achievement Award from The Obesity Society (TOS); the 2002 Andre Mayer Award from the International Association for the Study of Obesity (IASO); the National Science Foundation–administered 2006 Presidential Award for Excellence in Science, Mathematics, and Engineering Mentoring (PAESMEM); and the 2018 Harry V. Roberts Statistical Advocate of the Year Award from the American Statistical Association. In 2009, he was awarded the Centrum Award from the American Society of Nutrition (ASN) and the TOPS research achievement award from the Obesity Society. In 2013, he was awarded the Alabama Academy of Science’s Wright A. Gardner award and the American Society of Nutrition’s (ASN) Dannon Institute Mentorship award. He was elected as a Fellow of the American Statistical Association (ASA) in 2007, the American Psychological Association (APA) in 2008, the American Association for the Advancement of Science (AAAS) in 2009, the NY Academy of Medicine in 2014, the Gerontological Society of America in 2014, the Academy of Behavioral Medicine Research in 2017, and inducted into the Johns Hopkins Society of Scholars in 2013. In 2012, he received an NIH Director’s Transformative Research Award entitled “Energetics, Disparities, & Lifespan: A unified hypothesis.” In 2020, he was awarded the American Statistical Association’s San Antonio Chapter 2020 Don Owen Award in recognition of excellence in research, statistical consultation, and service to the statistical community. In 2021, he received the Obesity Society’s Friends of Albert (Mickey) Stunkard Lifetime Achievement Award.

In 2012 he was elected to the National Academy of Medicine of the National Academies. In addition to co-chairing their Strategic Council for Research Excellence, Integrity, and Trust (with Marcia McNutt and France Córdova), he was selected for their ad hoc committee to develop methods for assessing misinformation about biological threats. He has also served on the Scientific Advisory Board for the Nutrition Science Initiative (NuSI) and served on the board-appointed Committee on Science and Technology Engagement with the Public (CoSTEP) for the American Association for the Advancement of Science (AAAS), 2014–2020.

He has contributed to many editorial boards and is currently an associate editor or statistical editor for *Obesity*; *International Journal of Obesity*; *Nutrition Today*; *Obesity Reviews*; *Public Library of Science (PLOS) Genetics*; *Surgery for Obesity and Related Diseases (SOARD)*, and *American Journal of Clinical Nutrition.* Dr. Allison is also proud to be the founding Field Chief Editor of *Frontiers in Genetics*.His research interests include obesity and nutrition, quantitative genetics, clinical trials, statistical and research methodology, and research rigor and integrity.  [[Indiana University Bloomington School of Public Health](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison)]