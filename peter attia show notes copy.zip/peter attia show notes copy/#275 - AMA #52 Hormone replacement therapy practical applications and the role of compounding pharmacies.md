# #275 – AMA #52: Hormone replacement therapy: practical applications and the role of compounding pharmacies

**Source:** [https://peterattiamd.com/ama52/](https://peterattiamd.com/ama52/)

---

In this “Ask Me Anything” (AMA) episode, the discussion zeroed in on the practical application of hormone replacement therapy in women. Peter walks through the signs, symptoms, and hormonal changes in women approaching – and going through – menopause. He provides an overview of the FDA-approved HRT formulations and explains how women might go about choosing the right option for themselves. Peter also describes the significant changes in testosterone levels in women over time and the options, as well as the considerations and challenges of testosterone replacement therapy (TRT) for women. Lastly, Peter highlights the necessary role of compounding pharmacies in HRT, underscores concerns regarding the quality and sterility of compounded drugs, and offers guidance on locating a trustworthy pharmacy.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #52 show notes page](https://peterattiamd.com/ama52). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Why hormone replacement therapy is such an important topic [2:00];
- The onset of menopause: symptoms, blood tests, and when to consider HRT [6:00];
- Tests that may provide indications of perimenopause and their implications for fertility [9:15];
- Vasomotor symptoms: hormonal changes that cause hot flashes/night sweats, and HRT therapies that can help [13:45];
- The role of estrogen in menopausal HRT [17:30];
- The limited role of progesterone in HRT protocols [25:15];
- What is a “bioidentical” hormone? [28:30];
- Overview of the FDA-approved HRT formulations [31:45];
- Determining HRT dosing and considerations for perimenopausal women [37:45];
- Choosing the right HRT formulation: pros and cons [43:30];
- Examining the link between certain forms of estrogen and breast cancer [46:45];
- Changes in testosterone levels in women over time and why it matters [50:00];
- Recognizing low testosterone in women: common symptoms and diagnosis [53:45];
- Testosterone replacement therapy for women: options, considerations, and challenges [57:30];
- The long-term use of testosterone in women: examining the limited data [1:00:15];
- What is a compounding pharmacy? [1:09:30];
- Reasons to opt for a compounding pharmacy over a pharmacy that adheres to stricter regulations [1:16:00];
- The tragic incidents that heightened concerns about compounding pharmacies [1:20:45];
- Tips for finding a reputable compounding pharmacy [1:27:45]; and
- More.

§

The Peter Attia Drive

Hormone replacement therapy: practical applications and the role of compounding pharmacies

§

## Show Notes

§

## Why hormone replacement therapy is such an important topic [2:00]

- Today, we’re going to do is answer questions that have come through from subscribers around, hormone replacement therapy and testosterone replacement therapy as it relates to women
  - This is a topic that’s been talked about on the [JoAnn Manson episode](https://peterattiamd.com/joannmanson/), [Sharon Parrish episode](https://peterattiamd.com/sharonparish/), as well as the [Endocrine System podcast](https://peterattiamd.com/endocrinesystem/)
- These questions really focus around the **practical** application of HRT and TRT for women and how you use these in your practice with your female patients
- Wrapped up in this conversation around HRT is the topic of [compounding pharmacies](https://en.wikipedia.org/wiki/Compounding)
  - Those who need to get HRT and custom HRT prescriptions, we’ll use compound pharmacies
- When you talk about something like sex hormones, there’s a potential thinking that you’re only speaking to half the population, but of course, while everything we’re going to talk about is directly applicable to women, it’s obviously applicable to men who know or care about women

**Why is HRT for women an important topic**

*Why did you feel it was important to touch on hormone replacement therapy again as it relates to women and pull more questions around this?*

- This is a very frustrating topic, says Peter
- The mainstream medical community has committed a gross injustice over the past 20 years in the misinterpretation of the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) and the subsequent demonization of hormones in perimenopausal and postmenopausal therapy for women
  - ⇒ Check out [episode #153 with Joann Mason](https://peterattiamd.com/joannmanson/)

> “The sum total of lives that have been saved due to less breast cancer as a result from the lack of HRT for the past 20 years is exactly zero.” —Peter Attia

- There were zero additional deaths due to HRT from breast cancer
- There were more cases of breast cancer—1 in 1,000—but it translated to nothing in deaths
- In addition, Peter says “*I’m positive we could point to additional deaths due to hip fractures*.”
  - See [AMA #37](https://peterattiamd.com/ama37/)
- And all that says nothing about the quality of life that has been compromised
- The purpose of this podcast today is to talk about the logistics of how one goes about hormone replacement therapy and what all of the options are

## The onset of menopause: symptoms, blood tests, and when to consider HRT [6:00]

There’s a broad spectrum of the severity of symptoms that women will experience in menopausal transition

*How will women know if it’s time for them to start considering HRT?*

*And what the tests are that can be done to confirm the onset of menopause?*

- Menopause is a clinical diagnosis and technically, it’s really diagnosed retrospectively—it requires 12 months of amenorrhea, so 12 months of not having a period, without any other obvious pathologic or physiologic cause
- That said, there are a number of things that we can measure in the blood that tell us we’re heading there or if you just happen to have difficulty or for other reasons have an inconsistent period (such as the use of an IUD, which can interfere with a period) these blood tests can be particularly helpful.
- The mainstay of looking at this is measuring [follicle-stimulating hormone (FSH)](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) and to a lesser extent, luteinizing hormone (LH)
- FSH is perhaps the single most important hormone to look at to get a sense of where a woman is on her trajectory towards menopause

This was covered in great detail in the [video](https://www.youtube.com/watch?v=NTBkJzSPDCA) that Peter made on the female sex hormone system where you’ll get a sense of what FSH and LH are doing and how they’re changing throughout a cycle:

The “gold standard”—especially in the case of a woman who is still having a period—if you can measure FSH and LH and estradiol just to round it out on day five, day one being the day the period begins so five days in, that’s a very good test

- Once that number starts to get to 20 or 25, that’s really the surefire sign that a woman is in menopause

It’s important to understand that if a woman is sitting here and she’s not in menopause yet and wondering, well, “is that it? Is that the diagnosis?”

- No. Again, the diagnosis is based on amenorrhea
- But for many women, they’re going to be having symptoms even before they get there

**Common symptoms**

- The most common symptoms that women experience are the so-called vasomotor symptoms of hot flashes and night sweats
- These significantly precede other symptoms such as vaginal dryness, vaginal atrophy and things of that nature
- More significant issues are the bone mineral density
- Looking at the FSH, LH and estradiol level on that day five, you’ll see FSH and LH go up, you’ll see estradiol come down
- You might start to see symptoms even before that diagnosis of menopause and we would of course refer to those as **perimenopausal** symptoms

## Tests that may provide indications of perimenopause and their implications for fertility [9:15]

***Are there other tests that might be indicative of perimenopause?***

- The short answer is “yes”
- Peter does not do this in his practice, but if you’re chasing fertility, you may also be looking at the anti-mullerian hormone (AMH)
- Anybody listening to this who has thought about fertility, whether it be through IVF or other means, is probably familiar with AMH—it’s a hormone that is produced by the granulosa cells of a growing follicle
- These small follicles, sub eight millimeter follicles, are making this hormone, and **the more of this hormone you have, the more** [**ovarian reserve**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5509971/) **you have**
- AMH declines precipitously before the onset of menopause
- So knowing your AMH level and knowing both the rate of decline and the absolute level can also be predictive
- Again, this is not necessarily a valuable tool for predicting menopause
- The better use of this is actually around trying to get a better handle on ovarian reserve if reproduction is still in the cards

![](https://peterattiamd.com/wp-content/uploads/2023/10/f1-corrected-ama52.png)

**Figure 1.** Source: [Nelson et al. Hum Reprod Update. May 2023](https://academic.oup.com/humupd/article/29/3/327/6990969)

- On the X axis, it shows you time
- So time 0 is the final menstrual period, therefore halfway between the zero and 1 would be the definition of when you enter menopause
- This graph starts on the left 5 years before menopause
- And five years before menopause, you can see FSH and LH are very low
  - They’re represented by the green line for FSH, the blue line for LH
- The dotted lines on either side of the solid lines just show you the 95% confidence intervals—this is very, very tight
- Five years prior to menopause, the anti-mullerian hormone (AMH) is very high
- The FSH and LH concentrations are shown on the left Y axis, and the right Y axis shows the AMH concentration
- So five years pre-menopause…
  - The AMH concentration is 0.6 (the units are nanograms per milliliter, but most people would just say 0.6 because those are the only units they’re typically measured in)
  - The FSH and LH are very low—somewhere between 2 and 5
- Watch what happens as you move from basically five years prior to menopause towards menopause…
  - The AMH drops very suddenly within a period of about a year or two—it goes from 0.6 to 0.1 and lower
  - Whereas the FSH and LH rise
  - If you look at that green curve, you’ll see that FSH is hitting 25 right around menopause, maybe even a little bit before

One [study](https://www.fertstert.org/article/S0015-0282(12)01892-4/fulltext) looks at the *rate of change* of AMH as a predictor of menopause

Another [study](https://academic.oup.com/jcem/article/96/8/2532/2834584) suggests that if your AMH is below 0.2 and you’re more than 40, then the probability that you’re going to go through menopause in the next five years is very high

- Again, the FSH is still valuable, in fact, it’s probably necessary to determine how early or late you are in it whereas the AMH is helpful when it’s high
- So if your AMH is above 1.5, you’re likely not perimenopausal
- In fact, even if you’re over 40 but your AMH is over 1.5, menopause is probably at least six years away

“*Those are examples of where the AMH can be helpful, again, especially if you’re still considering fertility*.” says Peter

## Vasomotor symptoms: hormonal changes that cause hot flashes/night sweats, and HRT therapies that can help [13:45]

Menopause results from the ovarian decline in the production of estrogen and progesterone

- Most of the symptoms that women experience, however, are attributed to the **reduction in estrogen levels**
- Estrogen and progesterone levels can vary a lot in perimenopause, which is we tend to look at these other things like FSH to understand where you are on that relative scale
- We measure estradiol just so we have a baseline—we’re not paying attention to estradiol level to make this diagnosis

HRT

- HRT seeks to offset the estradiol loss because estradiol is playing the dominant role in the symptomatology
- HRT generally implies estrogen plus or minus progesterone and plus or minus testosterone, depending on the clinical symptoms

*Why are we talking about testosterone in women?*

- We’re talking about testosterone in women because it is still, at the peak of her reproductive years, 10 times more prevalent than estrogen
- It has 10 times higher concentration of testosterone than estrogen, and she will also experience a drop in testosterone during menopause
- Some of her symptoms can be attributed to that
- The drop in testosterone can also occur or be accelerated by estrogen replacement
- That means that if a woman would otherwise have a reasonable testosterone level or a slower decline of testosterone, which is what happens in menopause, testosterone does not fall off as precipitously
- The reason for that is testosterone, it has a greater amount of its production coming from adrenal feedstock
- So the adrenal glands are making DHEA, DHEA gets converted to androstenedione, androstenedione gets converted into testosterone
- That’s part of the reason why women can continue to make reasonable amounts of testosterone that are only declining slightly as they age
- But if they take estrogen as part of their hormone replacement therapy, it’s doing two things:
  - 1) It’s increasing sex hormone-binding globulin, which is not decreasing testosterone production but decreasing the amount of available testosterone
    - Peter makes this point in his [male hormone video](https://www.youtube.com/watch?v=K63K8F39Z4M) on YouTube
  - 2) And estrogen is a very potent feedback signal to the hypothalamus to have the body make less testosterone
  - So the effect of exogenous estrogen is both to increase SHBG, which lowers total available free testosterone, and to actually feedback negatively on testosterone production
  - That’s why we will come back to this question of testosterone replacement therapy as a part of more traditional HRT

## The role of estrogen in menopausal HRT [17:30]

***What determines which of those hormones are actually replaced with menopausal HRT?***

- Estrogen is really the mainstay of HRT
- The term HRT is a little bit antiquated
  - Most doctors and patients use the term “HRT” but the menopausal society has transitioned to MHT, which is menopausal hormone therapy

Back to the question of what determines which of those hormones are actually replaced with menopausal HRT?

- The simple answer is if a woman still has her uterus, she receives estrogen and progesterone
  - The progesterone is there to prevent endometrial hyperplasia, which increases the risk of endometrial cancer
- If a woman does not have an intact endometrium
  - Then she would just take estrogen, unless progesterone were warranted for the alleviation of some symptom
  - The main symptom that progesterone helps with is sleep
  - It is an important hormone around sleep, and a number of women find it to be an essential part of sleep post menopause
  - But nowadays, we don’t often use systemic progesterone, unless women need help with it for sleep, we would use local progesterone in the form of a progesterone coated IUD

The other point to mention here is that there are three forms of estrogen in humans

- E1 – estrone
- E2 – estradiol
- E3 – estriol
- Virtually all of hormone replacement therapy is done using the dominant one of these, which is estradiol or E2
- But we are going to talk about estrone, E1, and estriol, E3, as well.

![](https://peterattiamd.com/wp-content/uploads/2023/10/f2-ama52.png)

**Figure 2.** Source: [Dutch Test](http://dutchtest.com)

- Peter says do not pay any attention to all the stuff in the light blue boxes in the figure above
- Peter just wants to highlight the pathways by which these hormones are made

The pathways:

- The adrenal glands make DHEA
- That gets converted into androstenedione
- Androstenedione gets converted directly into testosterone
- The other thing that we see is that androstenedione gets converted directly into estrone (E1)
- E1 can be turned into E2 via a hormone that’s going to come up again and again in this discussion called 17 beta-HSD

There are two versions of 17 beta-HSD

- One version that converts estrone into estradiol
- And another one that can convert estradiol back into estrone
- Estradiol can also be converted, this time irreversibly, into E3 (estriol)
- Estriol doesn’t play much of a role in the story we’re going to talk about today outside of pregnancy

The story is a little bit more complicated because estrone (E1) can be converted into three other downstream estrogen metabolites

- 16-hydroxyestrone
- 4-hydroxyestrone
- 2-hydroxyestrone
- Why is this interesting?… Two reasons:
  - First, the 16-hydroxyestrone can also be converted back into estriol via 17 beta-HSD
  - and a different version of 17 beta-HSD can convert estriol into 16-hydroxyestrone
    - But remember, 16-hydroxyestrone cannot be turned back into estrone.
  - The second reason this is interesting is that of all of the associations we see with breast cancer, it seems to be that 4-hydroxyestrone might be the culprit
    - So when people say estrogen is implicated in breast cancer, there is indeed a grain of truth to that
    - The question is which one? ⇒ well it appears to be not estradiol, not estriol, but indeed 4-hydroxyestrone
    - You can see that, of course, estradiol can be converted into that, but estriol cannot

The big takeaway:

- Estradiol is what we typically replace, though we can also replace estriol
- There’s almost no case for replacing estrone
- The other thing worth mentioning is that testosterone can be converted into estradiol through the process of aromatization
- And as Peter said earlier, estriol feeds back on the hypothalamus to reduce the production of testosterone

*With the three estrogens, are there biological differences between them? [23:15]*

- Yes, they are different in their potencies, meaning the strength with which they bind to the estrogen receptors
- These are androgen receptors, so the order of potency is
  - 1) Estradiol (E2)
  - 2) Estrone (E1)
  - 3) Estriol (E3)
- In a premenopausal *non-pregnant* woman, E2 is dominating—it’s 1.5-5x the concentration of E1
- E3 pretty much only becomes an issue during pregnancy, so estriol is the primary estrogen during pregnancy because it’s produced by the placenta

*Measuring levels*

- Peter says that he will only measure estradiol, E2
- But if he were using other formulations of these things, that would be a reason to look at E1 and E3
  - If he were using something called a Bi-Est or a formulation of estrogen that contains both E2 and E3, that would certainly be a reason to be measuring E3
  - If you had real concern over estrone levels, that might be a reason to do that
- But the bulk of what we’re going to talk about today is going to focus on really where we have FDA-approved therapies for estrogen replacement, and that is around estradiol

The other point worth making…

- Because E1, E2, and E3 are competing for the same receptor, it might be tempting to say, “*well, gosh, if you’re just replacing estradiol, does that somehow negate some of the benefits of estrogen elsewhere?*”
  - The answer seems to be “no, it doesn’t”
  - And that’s because 1) they’re all competing for the same receptor, and 2) there’s this interconversion between them that we discussed

## The limited role of progesterone in HRT protocols [25:15]

- Progesterone is just a far less interesting part of the discussion, especially now that we’ve largely moved away from synthetic progesterone
- Peter and many others are convinced that most of the negative consequences of the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) (i.e., an additional 1 in 1,000 women did have breast cancer) was a result of that in the arm of the study that received conjugated equine estrogen plus MPA
- When you compare that to the women who only got the estrogen with no MPA, they had a reduction of the same magnitude in breast cancer
- Most thoughtful observers would argue that it was the synthetic progesterone that was the culprit there
- That point is largely moot because it’s now rare for anyone to be using that formulation

Use of progesterone

- When it comes to progesterone, what we’re talking about is oral micronized progesterone and progesterone coated IUDs
- The first question is “Do you have progesterone systemic symptoms?”
  - If so, you would take the oral micronized progesterone
  - If you do not, in which case you’re just looking for endometrial protection, then you’re just going to use a progesterone coated IUD

For the sake of historical significance, there are [several RCTs](https://pubmed.ncbi.nlm.nih.gov/33109992/) that look at progesterone-only replacement therapy

- This is women who have been deemed so risky that they could never take estrogen or be in the same room as estrogen but are still having menopausal symptoms
- So how are those alleviated with the use of progesterone?
  - The short answer is not nearly as much as they would be by taking estrogen

![](https://peterattiamd.com/wp-content/uploads/2023/10/f3-ama52.png)

**Figure 3.**

- It’s worth looking at understanding that the synthetic hormones and the actual hormones don’t always look the same
- It’s helpful to just take a look at progesterone versus medroxyprogesterone acetate or MPA, which is the form of progesterone that was used in the Women’s Health Initiative.
- You can see how they look mostly similar, but there’s enough of a difference that they’re not the same
- Biology is really complicated, and it’s certainly not always the case that something that isn’t a perfect mirror of the biologic version is problematic
- But it’s very hard to say in this particular study that this wouldn’t be the most obvious reason for the difference in cancer risk

## What is a “bioidentical” hormone? [28:30]

***What is even meant by that term, bioidentical hormones?***

First of all, bioidentical just means it’s a physiologic hormone

- So if you take a form of progesterone that looks exactly like the progesterone that the body makes, then it’s bioidentical
- Sometimes there are synthetic hormones that are developed (MPA is a synthetic version of progesterone, ethinylestradiol is a synthetic version of estradiol)
- Well, why are synthetic hormones made?
- Part of the reason is that they might have greater bioavailability
- For example, bioidentical estradiol has less availability when you take it as a pill than ethinylestradiol
- The other reason that something might not be bioidentical is if it’s related to another species
- An example would be conjugated equine estrogens that were a part of the WHI that were taken from the urine of pregnant horses
- So again, to be clear, the first use of the term bioidentical is to distinguish the more frequently used other forms of HRT that were used in the past.

A second reason that the term bioidentical is very prominent in the vernacular of the current era:

- It’s a tool used by compounding pharmacies that are selling this term
- You’ll see something called BHRT or bioidentical hormone therapy
- Truthfully, it’s a bit of a marketing description
- The compounding industry has used the term BHRT to make people feel like their products are safer if people feel that HRT is not safe
- In summary, it’s important to understand that bioidentical has a technical meaning, but it also seems to have a bit of a marketing meaning
- Compounded versions of estrogen are typically made in creams or pellets or things of that nature.
- And the nature of a compounding pharmacy, as we’ll discuss later, is such that they can custom make anything
  - One of the very popular things that they custom make is a topical estrogen preparation that is 20% estradiol and 80% estriol, so very rich in E3, not so rich in E2. That’s called a Bi-est.
  - You can make a Tri-est where it’s 80% estriol, 10% estradiol, 10% estrone
- You could make anything you want, really

## Overview of the FDA-approved HRT formulations [31:45]

**The list of what is FDA-approved currently for HRT**

- There are 26 FDA-approved estrogen-only medications that come in different forms, patches, pills, injections, gels, vaginal creams, skin creams, sprays, vaginal inserts and rings
  - These are pure estrogens or estrogen-onlys
  - But there are also FDA-approved combo products

*Note about dosing*

- So oral estrogens have relatively low systemic bioavailability because of what’s called the first pass effect, which is the liver’s metabolism when you ingest something orally
  - Therefore, your doses are much higher when you’re taking something orally than if you’re taking something, say, transdermally, where you get to skip the first pass effect
- This is why it can be very confusing when you look at doses of these things
- So if you look at the Women’s Health Initiative, they were taking 0.625 milligrams per day of CEE, conjugated equine estrogen—an oral estrogen
- Not uncommon for women who are taking oral estradiol to take one milligram a day
- With transdermal applications, like a Vivelle-Dot (an estradiol patch that you change twice a week), the dose would be 0.05 milligrams per day
  - So this is like a 20-fold difference in dose so keep that in mind when you’re looking at doses.

![](https://peterattiamd.com/wp-content/uploads/2023/10/f4-ama52.png)

**Figure 4.**

**Summary of the figure above**:

- Estradiol
  - Generic estradiol exists under multiple brand names: Vivelle-Dot, Minivelle, Estraderm, Menostar, Alora, all of these different things
  - You have gels, pills, a vaginal insert ring, a vaginal insert tablet, Vagifem versus Estring
  - All of these are bioidentical in that they are pure estradiol
- You then have synthetic conjugated estrogens—both of these are discontinued in the US but they are available outside of the US
- Injectable version of bioidentical estrogen called estradiol valerate
  - this is interesting because you can now have a way to get systemic levels of bioidentical estradiol without having to use a pill if a cream or a patch that doesn’t get absorbed fully
- One thing to point out:
  - One of the things on this list is Premarin, which was the one that was used in the WHI—that’s the conjugated equine estrogen
  - The brand name is Premarin, but the generic name of course is conjugated estrogens, and these come in pills, vaginal creams, injections, etc.
- SERMs
  - A SERM is a selective estrogen receptor modulator, so they’re structurally different from estrogens, but they can still interact with the estrogen receptor
  - SERMs are an interesting agent with two use cases
    - 1 – There’s women who are out of menopause—meaning they’re far enough out of menopause that they no longer have vasomotor symptoms—but they’re still at risk for other things such as the vaginal symptoms and the bone health issues
      - In those cases, it’s kind of a perfect drug, although it does, believe it or not, have a side effect of potentially bringing back some hot flashes
    - 2 – The other use case for it is it seems to have a much lower, if not zero, risk of breast cancer
      - Again, effectively no risk of breast cancer in any population, and you can take it after menopause has initiated to cope with the non-vasomotor symptoms of it in a pill form
- On the progesterone side…
  - There’s basically only two FDA-approved forms (in the form of pills)
  - There’s obviously progesterone coated IUDs
  - But basically in the pill form, you have Prometrium, which is the brand name of micronized progesterone which comes in a 100 or 200 milligram capsule
    - That’s the bread and butter of what we use in women who do benefit from oral progesterone.
  - Then Provera is the brand name of the MPA
    - Again, in the Women’s Health Initiative, it was Premarin plus Provera is what the women took—Peter wouldn’t prescribe that to anybody
- We also have seven combined HRT medications
  - One of them is Prempro which is conjugated estrogen plus MPA is Prempro, which is what you get when you combine the Provera and the Premarin
- Overall: Peter just wants people to see here’s a generic, here’s the brand, here’s what it means, this is synthetic, this is bioidentical, and so on

## Determining HRT dosing and considerations for perimenopausal women [37:45]

***How is dosing determined for HRT?***

- The short answer: This is all dosed based on *symptoms*
- You have biomarkers that can help guide you and you obviously have starting points that you would use, and as such there are brackets that you could put on doses for things
- For example, progesterone is easier to dose relative to estrogen
  - Most women are somewhere between 100 and 200 mg
  - At some point, if you go low enough, you’re not going to get any of the endometrial protection
  - “Clinically I would be uncomfortable with a woman taking less than 100 milligrams if that were her means of endometrial protection”
  - If a woman were still having negative symptoms from the progesterone at 100, Peter would switch over to an IUD
- The estrogen dosing is where it gets more complicated

**Estrogen dosing**

- When we have the fortune of initiating this perimenopausally and into menopause, we’re basically looking to alleviate her symptoms without creating more symptoms and we’re looking at the FSH as our guidepost
  - So we’re really thinking a lot about symptoms and paying most attention to FSH
  - An FSH level between about 25 and 35 really seems to be the sweet spot
- So how do you know if you’re giving too much estrogen?
  - The most common symptom we might see would be headaches and breast tenderness
  - But also, you’re going to see very low FSH
    - For instance, some women come into the practice who have been prescribed HRT outside and they show up and their FSH is very low and it turns out that they’ve been on a “Herculean dose” of estradiol
    - Fortunately, many of them are not having any symptoms, but Peter would still argue that they’re taking more estrogen than is needed and he would still move to back that off
  - As far as following the estradiol level, Peter don’t find it to be remarkably predictive of symptoms
  - Estrogen levels become a little bit important if you’re using compounded formulations where you’re presumably also using estriol and potentially even estrone
- The long and short of it: **Symptoms matter the most**

**Peter’s preferred modality**

- Peter’s preferred modality of estrogen is the Vivelle-Dot
- He finds that to be the best combination of practicality, ease of use, and consistency of dosing
- He usually starts patients as low as 0.025 milligrams per day and titrate up until they get to where they want to be
- Dosing can go as high as 0.1 milligram per day
- Things you need to be thinking about: if your patients are very active, lots of time in the sauna, lots of exercise, lots of sweating…they might have to change the patch a little bit more frequently than is recommended (which is about every four days)

*What about the difference in dosing for perimenopausal women as opposed to menopausal women? [41:30]*

- When we say perimenopausal, we’re talking about women who are showing up with vasomotor symptoms and/or they may be experiencing irregular menses and there’s not an obvious other explanation for that
  - A lot of times, a low-dose combined oral contraceptive can work—so 10 to 20 micrograms of esterified estrogens can help during that transition when you move to the more physiologic
  - Again, because Peter prefers to use actual estradiol and actual progesterone, he’d want to transition them off the oral contraceptives once they’re in menopause
  - Peter notes that *it’s not entirely clear if there’s an advantage to starting HRT in perimenopause*
- Another important point:
  - If a woman is not tolerating micronized or oral progesterone—meaning they are having significant mood disturbances (even if their sleep might be improving)
  - In this case, he would immediately pivot to the Mirena IUD
  - A [systematic review from 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8127097/) summarized seven RCTs and four other prospective cohort studies that looked at the Mirena ring or similar examples, so progesterone coated IUDs, and found that they were equally effective compared to oral progesterone or progesterone suppositories in terms of predicting against endometrial hyperplasia
  - So there should be no hesitation towards moving in that direction if oral progesterone is not warranted and/or not tolerated

## Choosing the right HRT formulation: pros and cons [43:30]

***What are some of the pros and cons that might help someone determine which formulation is right for them?***

- It comes down to a bunch of things:
  - What’s the patient preference?
  - What’s the availability?
  - What’s the cost?
  - Are there any other risks associated with it?
- Speaking of risks
  - Oral estrogens should be avoided in women, for example, with high triglycerides, with gallbladder disease or with known clotting factors such as factor V Leiden, and that’s even if they don’t have a history of venal thromboembolism.
    - One [study](https://link.springer.com/article/10.2165/00003495-199040040-00006?adb_sid=bd73ee3b-a36f-4585-8d3e-967cba74f006) looked at comparing transdermal estradiol to oral estradiol and found a hazard ratio of 1.7, so a 70% increase in the risk of venous thromboembolism
- Other considerations: compliance
  - For some people, taking a pill every day is easy
  - For others, putting a patch on is easy
- Creams and gels
  - Peter is not be a huge fan of creams and gels for a couple of reasons
  - It has quite variable absorption and can also change based on, for example:
    - Did you exercise or not
    - Are you still sweating when you put it on or not?
    - Is your skin more or less exfoliated or not?
  - If you’re really trying to be as rigorous as you can with the application of creams, you have to have a period of time once the cream goes on, it’s fully allowed to dry, it doesn’t get wiped off on your clothing or things like that
  - A few other things to keep in mind with the topical stuff
    - First is you have to be thoughtful about what other creams and lotions and potions you’re using
      - A lot of people use just skin creams to help with their skin or sunscreen. You can’t be using those at the same time
    - Secondly, you are limited in your ability to shower, bathe, swim, etc. for at least an hour
    - Thirdly, you then have to worry about the risk of transmitting the hormone to somebody else
      - if you’re putting it on right before bed, for example, and your partner is being exposed to it and they don’t need extra estrogen, that’s something you’ve got to be aware of

## Examining the link between certain forms of estrogen and breast cancer [46:45]

***Is there an association between certain forms of estrogen and breast cancer?***

- There’s limited evidence that estrogen is associated with the initiation of breast cancer
- However, certain forms of estrogen (most notably estrone) and its metabolites, especially 4-OH-E1, may be associated with the progression of breast cancer
- Estrone dominates as the primary estrogen after menopause, and this may be why breast cancer has a higher prevalence in older women than younger women
- It’s also still produced after menopause, although to lesser amounts, but the conversion to estradiol significantly drops which is why estrone becomes the more dominant hormone.

Estrone [may contribute](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9798480/) to the progression of ER-positive or estrogen receptor positive breast cancer

- The biologic or mechanistic explanation might be that it cooperates with what’s called the nuclear factor or NF-kappa-beta
- So NF-kappa-beta stimulates inflammation, whereas premenopausal women have a lot of 17-beta-estradiol to oppose NF-kappa-beta
- Once that goes away, the estrone begins to dominate and it recruits different co-regulators to the estrogen receptor to induce, in the case of estradiol, it would be to repress, transcription factors of a gene called [SNAI2](https://breast-cancer-research.biomedcentral.com/articles/10.1186/s13058-018-0988-9#:~:text=19%20June%202018-,SNAI2%20upregulation%20is%20associated%20with%20an%20aggressive%20phenotype%20in%20fulvestrant,receptor%2Dpositive%20metastatic%20breast%20cancer)
- SNAI2 is a gene that when upregulated is associated with actually an aggressive phenotype of breast cancer
- So this is a type of breast cancer that has estrogen receptors but seems resistant to estrogen receptor antagonism as a form of therapy

What seems clear is that estriol would have the least bearing on this. *How do we know this?*

- Mechanistically, there isn’t a solid explanation for how it would, but also remember, estriol levels get very, very high during pregnancy
- We’re not seeing a lot of breast cancer during pregnancy
- And if we really believe that estrogen was the biggest driver of breast cancer, presumably we would see more breast cancer during a period of a woman’s life when estrogen is the highest and it’s never higher than during pregnancy

One question becomes: *Should we be utilizing estriol as the dominant form of HRT to reduce the risk of breast cancer if that were possible?*

- And the short answer is: We don’t really know
- To Peter’s knowledge, there haven’t really been any studies that have looked at this
- What would an HRT approach that relied on estriol look like?
  - Again, estriol is a weaker estrogen, but it is competing for the same receptor, and therefore it would be very interesting to know if we could achieve both the symptom alleviation, but at the same time, you would have no backwards movement to estradiol or estrone
  - So you could basically replace as much estriol as you wanted and you wouldn’t move back any further

## Changes in testosterone levels in women over time and why it matters [50:00]

***How does testosterone change in women as they age?***

- Testosterone is produced by the adrenal glands
- The adrenal glands make DHEA that turns into androstenedione that gets turned into testosterone
- It’s also made by the ovaries. And even after menopause, the ovaries continue to make it.

![](https://peterattiamd.com/wp-content/uploads/2023/10/f5-ama52.png)

**Figure 5.** Source: [Dimitrakakis & Bondy Breast Cancer Research Oct. 2009](https://breast-cancer-research.biomedcentral.com/articles/10.1186/bcr2413)

- On the Y axis here, you are seeing both the estrogen and the testosterone level in the same units, picogram per milliliter

*Estradiol levels*

- Look at the bottom graph first, the one with the clear circles—this is estradiol level
  - Estradiol level at birth starts at about a hundred, drops down to zero by the time the little girl is four years old
  - It basically stays at zero until she hits puberty, and then it’s back up into that level of a hundred
  - Now notice what happens from about the age of 18 to 46, it’s pretty constant
  - But once she goes through menopause, you can see it starts to go down until she’s in her 50s when it falls back down to zero
  - It will remain at zero indefinitely unless she undergoes estrogen replacement therapy, which is what’s shown with the clear triangles
- The purpose of this graph is to show you two things: One is to show you what her testosterone levels look like with and without HRT and how that varies over the course of her life

*Looking at testosterone:*

- Again, she’s actually born with quite a high testosterone level, but that falls to a very low level when she’s very young then it rises throughout
- What you’re seeing with testosterone is a very similar shape curve to the estrogen but it’s just significantly higher
- Here’s the interesting part of this graph:
  - At menopause, it doesn’t go to zero the way estradiol does, it just goes down in a much slower decline
  - However, if a woman undergoes estrogen replacement therapy, her testosterone really falls in the context of HRT
  - Again, that fall in testosterone in the context of HRT is due to the feedback loop between estrogen and the hypothalamus.
- What this graph *doesn’t* show is that the clinical effective reduction of testosterone is even greater than what’s shown in this figure
  - Why? Because what this figure doesn’t capture is the increase in sex hormone-binding globulin that reduces free testosterone even more
  - So this graph is showing total testosterone, but as we’ve discussed many times before, we much prefer to look at **free testosterone** to get a better sense of what’s happening clinically
- This explains both the relationship of testosterone over a woman’s life but also how estrogen replacement therapy will paradoxically and maybe somewhat counterintuitively lower testosterone or accelerate the decline in testosterone

## Recognizing low testosterone in women: common symptoms and diagnosis [53:45]

***How would a woman know if she has low testosterone? Are there common symptoms? Is there something where it can be diagnosed?***

- It’s very easy to measure the testosterone levels and see how they might stack up percentile wise
- But the truth of it is this is very much a clinical issue that pertains to **symptoms** as opposed to just numbers

Symptoms that would be attributed to low testosterone (discussed in [episode 259](https://peterattiamd.com/sharonparish/) on women’s sexual health)

- low libido
- vaginal dryness
- lack of energy
- loss of muscle mass and muscle tone
- reduced BMD
- weight gain
- difficulty sleeping
- thinning hair
- dry and thinning skin
- (To be clear: you could also see some of those symptoms due to, for example, a thyroid deficiency, so one has to be careful in their workup for this)

Measurements

- Peter will measure testosterone in women and men alike
- He will measure total testosterone and free testosterone
- And when you’re replacing testosterone in women, you definitely have to be mindful of side effects

***In your practice, you mentioned that you are testing testosterone. If you put someone on therapies, are you retesting that in certain time windows? How are you determining if it’s working or not?***

- Anytime you’re replacing a hormone, you’re going to be measuring the level and using that to help guide as you’re addressing benefit and side effects
- The two most common by far of excess testosterone:
  - Acne
  - Increased hair growth
  - Look for things like facial hair and more leg and body hair than usual
  - In these situations, you’ll dial the dosage down
- Women who have abused steroids for bodybuilding may some significant masculinization like an Adam’s apple and/or clitoral enlargement (note that this is not really seen in proper medical management of TRT)

**Levels to aim for with TRT**

- The levels that we’re aiming for are basically to get a woman back to a normal physiologic range for someone in her 30s to 40s or even to her 50s
- For total T that would be between about 50 and 100 nanograms per deciliter
- And depending on how high the sex hormone-binding globulin is and how well she can tolerate from a side effect standpoint, you’re going to adjust that up or down
- For context:
  - if treating men with testosterone replacement therapy, they’re going to end up probably somewhere between 700 and 1,200 nanograms per deciliter
  - for treating women, they’re going to be 50 to 100

## Testosterone replacement therapy for women: options, considerations, and challenges [57:30]

***Are there any FDA-approved testosterone therapies for women?***

- No, there are not, only for men
- So any use of testosterone in women is going to be off-label

Below are the approved TRT for men:

![](https://peterattiamd.com/wp-content/uploads/2023/10/f6-ama52.png)

**Figure 6.** FDA-approved testosterone replacement for men.

- You can get it in a gel such as AndroGel
- A nasal spray like Natesto
- A patch, Androderm
- An FDA-approved pellet called Testopel—These are little crystalline testosterone pellets that are injected into the subcutaneous space and they absorb over the span of a couple of months.
- An injection version, testosterone cypionate with the brand name Depo-Testosterone as the most popular
- You have Xyosted, which is testosterone enanthate, which is just a preloaded pen
- Basically, enanthate and cypionate, almost indistinguishable clinically
- There’s an oral testosterone that basically is a testosterone ester that can be absorbed via the lymphatic system and it therefore bypasses the portal circulation

**Dosing challenges for women**

- One of the challenges that you have when using male products on females is the dose
  - For example, if we wanted to give females a Depo-Testosterone dose, we’d have a very hard time doing it because the formulation of Depo is 200 milligrams per ml
    - Peter would give male patients 0.25 ml twice a week
    - Since women need about one-tenth that, there is really no way to do it
- So when it comes to testosterone replacement therapy in women, the **nasal gel** seems to be a reasonable option because the dose is very high in men
  - Men need about six squirts a day so you can adjust that to get to a reasonable dose in women
- Other options for women would be to rely on either trimmed patches and/or compounded creams to actually get a dose or concentration that is appropriate for women

## The long-term use of testosterone in women: examining the limited data [1:00:15]

***Given there’s no FDA-approved therapy for testosterone in women, do we even have good evidence for long-term use of testosterone in women?***

- We know a lot less than we know in men
- In men, we have good evidence that long-term therapy is completely safe over the long run

When it comes to women, the longest study we have is the [APHRODITE Study](https://pubmed.ncbi.nlm.nih.gov/18987368/), is a one-year intervention study with a one-year extension phase

- It included over 800 post-menopausal women who were not taking estrogen therapy but they were diagnosed with hypoactive sexual desire
- The indication here was for low libido in women who were postmenopausal but not taking other HRT
- These women were divided into two doses of testosterone of either 150 or 300 microgram patches per day
- Within six months of the study, both dose groups had a significant increase in sexual desire and a decrease in the distress associated with low sexual desire
  - In that sense, it accomplished its goal
- The most common adverse reactions was unwanted hair growth in 20% of women taking the higher dose versus 11.5% in those taking the 150 micrograms and 10.5% in the placebo
- There were no cases of breast cancer in the placebo group
- There were three breast cancer cases diagnosed at four, seven and twelve months of treatment
  - But let’s be clear on the timescale of these—Clearly, these weren’t initiated by the drug, but it’s unknown if testosterone may have influenced the progression of these diseases
  - Also, you don’t really have statistical significance at such a small study and with such small N
- In the extension phase of this, remember this was a one-year treatment and then a one-year followup, there was one additional case of breast cancer three months after the cessation of the study in a woman receiving 300 micrograms of testosterone
  - it’s unclear what to make of that
  - Did testosterone play a role in propagating breast cancers that clearly existed at the time of the study? Unclear
  - Is the fact that they were not taking estrogen somehow relevant? Not clear
- What’s unfortunate about this study is that
  - a) it’s short, it stands in isolation, and
  - b) more importantly, it’s problematic because these women don’t really represent the population we’re thinking about
    - We’re really talking about treating *women who are perimenopausal and postmenopausal who are also on HRT*

***What other data can we look at?***

A 10-year [prospective study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6937705/) (The ‘Dayton study’ )

- This evaluated adverse effects such as breast cancer in 1267 women with testosterone deficiency (both pre- and post-menopausal women) who had received TRT with testosterone pellets
- One issue with pellets is you get these huge doses of testosterone initially for the first month or so and then it wanes off
- The compounded pellets were implanted into the patients
  - if the patients were also breast cancer survivors, they were also put on anastrozole, which is an aromatase inhibitor
- The testosterone implant was dosed based on weight
- Peter notes that the women were at very high levels of testosterone
- Serum testosterone levels four weeks post-implant were as high as 300 nanograms per deciliter—3x the upper limit of what Peter would normally replace women to
- And even when they came back to have their pellets replaced, which was about four months later, they were still at 171 nanograms per deciliter on average, which again is about twice normal
- Despite these profound levels, there were no reported adverse events attributed to testosterone therapy other than what you would expect
  - 85% of the patients reported a mild to moderate increase in facial hair
  - 6% reported a severe increase in facial hair
  - 11% reported an increase in acne
  - 50% reported an improvement in skin moisture, tone and texture with fewer wrinkles
  - 1% reported perceived voice changes, voice cracking or deeper voice
- What about breast cancer?
  - 11 cases of invasive breast cancer were diagnosed in women within 240 days of their most recent testosterone implant insertion, and the incidence rate was 165 cases per 100,000 person years
  - The question is, because you don’t have a placebo… How does that compare to women who are age matched in the largest database we have, which would be the [SEER database](https://seer.cancer.gov/about/overview.html#:~:text=For%20more%20information%20on%20this,percent%20of%20Hawaiian%2FPacific%20Islanders.)?
  - And interestingly, the age matched SEER incidents for invasive breast cancer is 271 cases per 100,000 person years versus the 165 in this trial
  - So here, you have a trial that suggested a reduction in the amount of breast cancer
- So how do we make sense of that, because it’s not placebo controlled?
  - Well, the SEER database includes everybody, but the Dayton Study is using women who are clearly *health conscious—*If you’re going out of your way to get testosterone replacement therapy, presumably you are more health conscious than the average person
  - For that reason, we just can’t look at this study and infer anything as it pertains to breast cancer

**The largest case-control** [**study**](https://www.jogc.com/article/S1701-2163(16)35385-3/pdf) **came out of the UK**

- Over 8,000 women, average age 47
- The follow up was a little bit shorter at 4.5 years
- It had roughly 2,000 patients that received oral testosterone or intramuscular testosterone or implants
- And about 6,000 women were used as control
- There was no difference in this study between those on active treatment and those on placebo in terms of breast cancer or any other disease that they looked at, which included cardiovascular disease, heart disease, diabetes, cerebrovascular disease, etc.

All that said, you just look at these studies with a little bit of a grain of salt, truthfully

- Peter is comforted by the fact that the two large epidemiologic studies don’t find any increase in risk of anything
- But he doesn’t know what to make of that one weird RCT that is using testosterone in isolation in older women
  - But again, it was such a small study that the statistical significance doesn’t really have value

**To come back to the original question**: *Do we even have good evidence for long-term use of testosterone in women?*

- The short answer is that “we don’t really know”
- “I can tell you with far greater confidence and precision what it means to put you on estrogen progesterone”
- “I can tell a man with far greater precision and accuracy and confidence what it means to put him on testosterone”
- “But here I come at it from a place of greater uncertainty”

> “It comes down to if the symptoms warrant it, we do it, and we’re just more aggressive in how we are screening for other complications, and if the most significant of these is breast cancer then so be it. We have remarkable tools in how we can screen for that.” —Peter Attia

## What is a compounding pharmacy? [1:09:30]

***What is a compounding pharmacy?***

- Compounding is the process of creating a drug by a licensed pharmacist to meet whatever the need might be of the patient or physician when a commercial drug doesn’t meet those needs
- What could that imply? ⇒ Well, compounding pharmacies carry out the preparation, the mixing, assembling, altering, packaging and delivery of the drug
- To be clear, it is not permitted by law that a compounding pharmacy can make a copy of a commercially available drug—so in theory you can’t call them up and have them make a version of something that already exists
- Do some compounding pharmacies do this? ⇒ Absolutely, but this is just the tip of the iceberg on what part of the problem is with compounding pharmacies
- There are some good ones and there are some very bad ones

*Not FDA approved*

- Compounded drugs are not FDA-approved which means the FDA does not review the drugs to evaluate their safety, their effectiveness, their quality before they reach patients
- Therefore, there are a lot of risks that are posed by compounding pharmacies

**Good pharmacies exists**

- There are good compounding pharmacies out there
- Peter using them with patients
- And because of the relationship we’ve had with them for a very long time and we know them very well, we know the quality of their work we do, on the relatively rare occasion when we need to have something compounded and that’s pretty unusual
- “*I trust their ability to compound, but it is truly the wild west*.”

*Things to watch out for with compounding pharmacies*

- Compounded drugs are exempt from good manufacturing practices, GMP
  - GMP is a process that is basically required anytime you make a drug for human use.
  - Supplements are also not subject to GMP practices, and that’s why one has to be very careful with supplements
  - These are not required to report adverse events to the FDA. This is mandatory for FDA regulated medications.
- There are also some compounding pharmacies that engage in activities that go well beyond the boundaries of what they’re permitted to do, such as large scale production of compounding medications without an individual patient prescription
  - When you want a compounded medication, you actually have to present a prescription for it and then they make it specifically for the patient
  - Where you get into these real shady areas is they can create copies of drugs that are not yet FDA-approved in the United States.
  - A very important example of this right now is a drug called enclomiphene, which is a drug very related to clomiphene or Clomid is the brand name
    - This is a drug that’s used in fertility therapy
    - It’s also a drug that is very common in testosterone replacement therapy for men
    - So clomiphene acts at the hypothalamus to tell the pituitary to make more FSH and LH, and enclomiphene has I think a better safety profile
    - there’s evidence that it’s probably a slightly better drug
    - That said, it’s not yet FDA-approved so it’s under investigation, but you can’t buy this drug legally in the US. Compounding pharmacies are making it already
  - There’s been a number of published reports of independent testing of the products produced by compounding pharmacies, and they consistently show that compounded drugs often fail to meet the specifications and that they’re at a far lower rate of basically making what they say and making it safely than an FDA-approved formulation

> “Again, that’s just my public service announcement on compounding pharmacies. They’re not all bad. And hopefully by the end of this discussion, you’ll have a better sense of how to suss out the good from the bad.” —Peter Attia

**Two types of compounding pharmacies**:

- The first one is called a 503A—these are the community pharmacies
- Then there are the outsourcing facilities, the 503Bs
  - the 503Bs produce huge batches of these products that are then basically sold to healthcare facilities for office use only
  - This is the exception. They are allowed to make them without a specific prescription. They are allowed to do tha
  - There are very few 503B pharmacies—73 in the United States
  - If you’re going to go and buy hormones, for example, pellets to be used in HRT, they’re going to be potentially made by a large-scale 503B pharmacy, and you could buy from an intermediary.

*More about the 503A pharmacies*

- The majority of the time you interact with the compounding pharmacy, it’s going to be a 503A
- They make much smaller batches, and they’re basically making it on demand for a specific prescription
- There are about 32,000 503A compounding pharmacies in the United States.
- In summary, they’re very poorly regulated
- The majority of them are small pharmacies that also have the ability to compound. And they can’t just do it “willy-nilly”
- And they can’t make something that already exists

## Reasons to opt for a compounding pharmacy over a pharmacy that adheres to stricter regulations [1:16:00]

***What are some reasons someone would even use a compounding pharmacy based on everything we talked about versus one that’s much more regulated?***

- One reason is you might need a custom medication
  - So you might need a specific medication for which the strength doesn’t exist in the FDA formulation
  - An example would be testosterone in women where you need something in the proper dose
- Secondly, you have a patient that has an allergy to an ingredient in the FDA-approved drug, and the compounding pharmacy can basically make it without it
  - Example is that micronized progesterone contains peanut oil. So somebody with a peanut allergy is going to have to have a version of this compounded without peanut oil
- Another reason might be that you need access to something that’s really important and it’s unavailable or on back order
- Another reason could be that you have something that only comes in a pill but you might want to have it for a patient in a liquid
- These are all very important reasons and this is why compounding pharmacies are valuable in their service, but they have to be doing things right

***What are some of the most common uses of compounding pharmacies as it relates to HRT?***

- The most common thing are in the Bi-est creams and maybe the Tri-est but they’re less common.
  - So the Tri-est is the tried and true thing you’re going to see coming out of a compounding pharmacy. — “I don’t know who came up with the idea that 80% estriol, 20% estradiol was the ‘right way to do it.’ It may have been born of the belief that, ‘hey, this is going to have a much lower risk of breast cancer.’”
  - It’s certainly possible that that’s true, but that would probably be one of the most common applications we see in HRT.

The second most common would be in the pellet use

- These pellets are very tiny little things, especially in women
- You basically take the hormone, estrogen or testosterone, and the material is pressed or fused into this very small crystal to create a pellet.
- This has to be done sterilely, so that’s the other thing you want to keep in mind, is there are different levels of drugs that are produced
- Pills, topical stuff, **then there are things that are implanted or injected, and you have to be very thoughtful about that**

Compounding pharmacies also make testosterone formulations for men

- “I can’t really come up with a great use case for that. I think there are so many testosterone applications for men out there that I don’t understand why you would need a compounding pharmacy to make that. But nevertheless, that’s something that happens.”

They make gels and creams that can absorb better

- They have much more flexibility around the formulation for how the gels and creams are formulated.
- So the generic gel that most things exist with is an alcohol-based gel and a lot of people don’t absorb those very well.
- So compounding pharmacies have other tricks up their sleeve to create transdermal delivery vehicles on the skin that have higher absorption or other properties.
- So in addition to just the very standard alcohol-based, they have an oil-water emulsion-based. They have a lipodermal-based cream, and they have even an anhydrous-based that is specifically compounded for HRT.
- So what’s the application here?
  - Well, you have a woman who, for whatever reason, is not absorbing any of the standard FDA-approved products and she doesn’t want to go down the path of an injection or pellets
  - Peter has seen this work in the past where a standard or generic base doesn’t work, and yet one of these other more creative bases work.

## The tragic incidents that heightened concerns about compounding pharmacies [1:20:45]

***What happened where it first got on your radar roughly 10 years ago?***

- In the last decade, three separate meningitis outbreaks have been traced to supposedly sterile steroid injections that were contaminated with fungus or bacteria and they were made in compounding pharmacies
- The most notable and tragic of these was in 2012 and it brought greater scrutiny to compounding pharmacies
- A 503A pharmacy called the [New England Compounding Center](https://en.wikipedia.org/wiki/New_England_Compounding_Center_meningitis_outbreak), NECC, was distributing steroid injections without patient specific prescription
- They were making methylprednisolone acetate
- Methylprednisolone is just a type of steroid that is used for epidural steroid injections for back pain and they were not making these in a completely sterile way
- Three lots that were distributed to a total of 75 medical facilities across 23 states and which ended up having a distribution sometime between May and September of 2012 potentially exposed up to 14,000 patients, resulted in 800 who were infected by fungal meningitis
- If you have a fungal contamination and you then go and give an epidural injection, you’re now directly putting this stuff potentially in the proximity of the cerebral spinal fluid, you gain access to the central nervous system
- In this case, 800 people got infected and another 100 died
- This pharmacy was breaking the law in that they weren’t even supposed to be doing this
- Then, of course, clearly, when there’s no oversight, there’s no regulation around their manufacturing process
- When you look at the sorted history of compounding pharmacies, generally the most common problems you deal with are sterility, of which this is the most egregious example
- You also sometimes have a lack of potency and quality

This stuff impacts supplements

- Peter says that if he’s taking vitamin D or EPA and DHA or any of these supplements, he’s very particular about which companies he’s taking them from because they have to be reputable
- The company itself are the ones holding themselves to the standard because the FDA will not do it in this case

***After the outbreak of 2012, was there any additional regulations that came to compounding pharmacies?***

- Yes, but Peter would argue that they have largely been based at making it harder for the 503Bs to screw up
- Peter finds this ironic given that it was the 503As that were making the mistakes
- There was something called the [Drug Quality and Security Act](https://en.wikipedia.org/wiki/Drug_Quality_and_Security_Act) that was passed in response to the 2012 outbreak of this fungal meningitis
- This act placed requirements on some licensing restrictions which made it a little more stringent to make sure you had patient prescription requirements for the 503As and the certificate of analysis for all bulk substances, and it required that 503Bs report adverse events.
- It also made it illegal to compound drugs that have been removed from the market or to make drugs that are the exact copies of commercially available drugs
- However, Peter says he still sees compounding pharmacies potentially violating this
- There were also some limits put on distribution, however, clearly there are still enormous loopholes on this
- Peter says that truthfully he doesn’t think the Drug Quality and Security Act really changed 503A compounding that much

> “At the end of the day, I think what it comes down to is you have to trust the pharmacist and the pharmacy itself because they are the ones that are going to hold themselves to the standard.” —Peter Attia

- When the FDA inspects a 503A compounding facility, there is an evaluation of the pharmacy’s compliance with the 503A section of this DQSA, as well as an identification of the conditions there.
  - I.e., *How sanitary is it?*
- Most compounding pharmacies are state regulated so they do need to maintain state licensure and they do need to comply with what’s called the USP standard.
- Nevertheless, *when it comes to the most important issue, which is batch testing, it remains* ***voluntary***

**What is most important**:

- Sterility and potency and accuracy of what’s in the drug is something that they would have to *voluntarily submit to third-party batch testing*.
- Now, why wouldn’t they do this? ⇒ Essentially because it’s expensive to do so

A recent convo with a patient of Peter’s:

- He told the patient that they use a reputable compounding pharmacy that they trust
- That said, Peter still always tries to find something that is an FDA product if possible
- The goal is to have as little risk as possible and also to understand that the risk is much lower if they’re making a pill or if they’re making a cream than if they’re making an injectable compound.

## Tips for finding a reputable compounding pharmacy [1:27:45]

***What’s the best way to find a reputable compounding pharmacy? Do we know anything? Can we offer any advice to people on that front?***

The FDA maintains a [list of compounding pharmacies](https://www.fda.gov/drugs/human-drug-compounding/compounding-inspections-recalls-and-other-actions) that have ever been issued a warning letter or anything of that nature

Other tips:

- Ask for certificates and accreditations such as licensure (usually state-based)
- Try understand their quality standard
  - Are they in compliance with USP compounding standards sourced from an FDA-registered facility?
  - Do they do any third-party testing? (it’s not required, but it’s important to ask)
- Ask for a certificate of analysis for every substance that they put into their compounded medications.
  - So if you’re having a drug made or you’re having a hormone made, make sure you see the certificate of analysis
  - you want to understand the pharmacy and understand the accreditation of the pharmacy by the compounding association board
  - Each and every bulk substance, i.e., active pharmaceutical ingredient used for compounding, should be made at an FDA-registered facility
  - You should have your COA, your certificate of analysis, and you should be doing this for 503As and 503Bs
- Finally, be very thoughtful about batch testing for anything for which sterility is essential
  - So sterility doesn’t really matter that much for oral and topical
  - It matters a lot for injectables, for pellets, for eye drops, things like that
  - You would want to see some batch testing for those types of compounds

§

## Selected Links / Related Material

**Previous episodes of The Drive related to HRT and women’s health**: [2:15]

- [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.](https://peterattiamd.com/joannmanson/) |  Peter Attia (peterattiamd.com)
- [#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones | Peter Attia, M.D.](https://peterattiamd.com/endocrinesystem/) | Peter Attia (peterattiamd.com)
- [#259 – Women’s sexual health: Why it matters, what can go wrong, and how to fix it | Sharon Parish, M.D.](https://peterattiamd.com/sharonparish/) | Peter Attia (peterattiamd.com)

**Large study that linked breast cancer to HRT**: [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) | (wikipedia.org) [4:30]

**Episode that discusses hip fractures and the morbidity and mortality associated with it**: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/) | Peter Attia (peterattiamd.com) [5:15]

**The video that Peter made on the female sex hormone system where you’ll get a sense of what FSH and LH are doing and how they’re changing throughout a cycle**: [Female sex hormone system: PMS, menopause, hormone replacement therapy, and more | Peter Attia](https://www.youtube.com/watch?v=NTBkJzSPDCA) | Peter Attia MD (youtube.com) [7:00]

**One** [**study**](https://www.fertstert.org/article/S0015-0282(12)01892-4/fulltext) **looks at the** ***rate of change*** **of AMH as a predictor of menopause**: [Contribution of the rate of change of antimüllerian hormone in estimating time to menopause for late reproductive-age women](https://www.fertstert.org/article/S0015-0282(12)01892-4/fulltext) (Freeman et al., 2012) [12:45]

**Another study suggests that if your AMH is below 0.2 and you’re more than 40, then the probability that you’re going to go through menopause in the next five years is very high**: [Anti-Müllerian Hormone Predicts Menopause: A Long-Term Follow-Up Study in Normoovulatory Women](https://academic.oup.com/jcem/article/96/8/2532/2834584) (Broer et al., 2012) [12:45]

**Several RCTs that look at progesterone-only replacement therapy**: [Efficacy of progestin-only treatment for the management of menopausal symptoms: a systematic review](https://pubmed.ncbi.nlm.nih.gov/33109992/) (Dolitsky et al., 2020) [26:45]

**A systematic review from 2019 that found that progesterone coated IUDs were equally effective compared to oral progesterone or progesterone suppositories in terms of predicting against endometrial hyperplasia**: [Benefits of Levonorgestrel Intrauterine Device Use vs. Oral or Transdermal Progesterone for Postmenopausal Women Using Estrogen Containing Hormone Therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8127097/) (Clark and Westberg, 2019) [42:00]

**One** [**study**](https://link.springer.com/article/10.2165/00003495-199040040-00006?adb_sid=bd73ee3b-a36f-4585-8d3e-967cba74f006) **looked at comparing transdermal estradiol to oral estradiol and found a hazard ratio of 1.7, so a 70% increase in the risk of venous thromboembolism**: [Transdermal Estradiol: A Review of its Pharmacodynamic and Pharmacokinetic Properties, and Therapeutic Efficacy in the Treatment of Menopausal Complaints](https://link.springer.com/article/10.2165/00003495-199040040-00006?adb_sid=bd73ee3b-a36f-4585-8d3e-967cba74f006) (Balfour and Heel, 2012) [44:00]

**Estrone may contribute to the progression of ER-positive or estrogen receptor positive breast cancer**: [Estrone, the major postmenopausal estrogen, binds ERa to induce SNAI2, epithelial-to-mesenchymal transition, and ER+ breast cancer metastasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9798480/) (Qureshi et al., 2022) [47:30]

**The “APHRODITE Study” looking at TRT in women with low libido over 2 years**: [Testosterone for low libido in postmenopausal women not taking estrogen](https://pubmed.ncbi.nlm.nih.gov/18987368/) (Davis et al., 2008) [1:01:30]

**The “Dayton Study”: A 10-year prospective study that evaluated adverse effects such as breast cancer in 1267 women with testosterone deficiency (both pre- and post-menopausal women) who had received TRT with testosterone pellets**: [Incidence of invasive breast cancer in women treated with testosterone implants: a prospective 10-year cohort study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6937705/) (Glaser et al., 2019) [1:03:30]

**The tragic incident in 2012 involving a compounding pharmacy infecting people fungal meningitis**: [New England Compounding Center meningitis outbreak](https://en.wikipedia.org/wiki/New_England_Compounding_Center_meningitis_outbreak) | (wikipedia.org) [1:21:00]

**The FDA maintains a list of compounding pharmacies that have ever been issued a warning letter or anything of that nature**: [Compounding: Inspections, Recalls, and other Actions](https://www.fda.gov/drugs/human-drug-compounding/compounding-inspections-recalls-and-other-actions) | (fda.gov) [1:28:00]

§

## People Mentioned

- [JoAnn Manson](https://prevmed.bwh.harvard.edu/joann-e-manson-md-dph/) [2:15]
- [Sharron Parish](https://vivo.weill.cornell.edu/display/cwid-shp9079) [2:15]

§