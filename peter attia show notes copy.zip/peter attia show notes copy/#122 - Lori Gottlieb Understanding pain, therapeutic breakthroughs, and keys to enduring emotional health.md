# #122 – Lori Gottlieb: Understanding pain, therapeutic breakthroughs, and keys to enduring emotional health

**Source:** [https://peterattiamd.com/lorigottlieb/](https://peterattiamd.com/lorigottlieb/)

---

Lori Gottlieb is a psychotherapist and the bestselling author of [Maybe You Should Talk to Someone](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055). In this episode, Lori extracts important lessons from her experiences as both a therapist and a patient. The stories Lori shares has provided her the material for insights into living a more fulfilling life. In our conversation, Lori also dispels some misconceptions about therapy, explains the process of big therapeutic breakthroughs, and reveals the most important steps for enduring emotional health.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lorigottlieb/the_Drive_public.png)

Play

#122 - Lori Gottlieb: Understanding pain, therapeutic breakthroughs, and keys to enduring emotional health

#122 - Lori Gottlieb: Understanding pain, therapeutic breakthroughs, and keys to enduring emotional health

1x15s30s

0:001:30:12

## We discuss:

- Lori’s unique path to becoming a therapist [3:00];
- Dissecting cadavers—a profound experience during med school [12:30];
- The sunk cost fallacy—How Lori was able to walk away from med school [17:15];
- Being aware of the gift of life, and other lessons from Lori’s terminally ill patient [24:00];
- How underlying pain can manifest in obnoxious behavior [32:45];
- Counseling versus therapy [36:15];
- The story of John—why men hide their feelings, breaking down his shield, and uncovering his pain [38:30];
- “Breaking open”—A shocking revelation about John that tests Lori’s resolve as a therapist [46:30];
- Rewriting your story, the recovery process, and the most important step for lasting change [49:00];
- The process of  many big therapeutic breakthroughs [56:00];
- The 2 types of suicidal thoughts, and the importance of talking about it [1:01:00];
- The most common issues that bring patients to therapy with Lori [1:02:45];
- Clinging to the familiar—why change is so hard [1:05:15];
- A story of shame, lack of [self-compassion](/kristin-neff-the-power-of-self-compassion/), and self-sabotage [1:07:00];
- The importance of managing mental health to reduce unnecessary suffering [1:15:45];
- Dispelling the misconceptions about therapy [1:23:15]; and
- More.

§

## Show Notes

## Lori’s unique path to becoming a therapist [3:00]

Lori’s book: [Maybe You Should Talk To Someone](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055)

- The book follows four seemingly very different patients going through therapy with Lori as their therapist
- Then there’s a fifth “patient”, Lori herself, going to her own therapist
- By the end of the book, Lori hopes everybody says, “*I saw myself in every single one of these patients.*”

> “It’s a book about how we’re all more the same than we are different and how we grow in connection with others.”

**Lori’s current work**

- Lori is a psychotherapist
- Weekly column for The Atlantic called, [Dear Therapist](https://www.theatlantic.com/category/dear-therapist/?gclid=Cj0KCQjw6uT4BRD5ARIsADwJQ182CDc_otMPRxFoBwpuscpmiECY9MYzljlqhe5RATtD8SNuPwJDPgYaAq-qEALw_wcB)
- New podcast called [Dear Therapists](https://podcasts.apple.com/us/podcast/introducing-dear-therapists/id1523340696?i=1000484652853) co-hosted by [Guy Winch](https://twitter.com/guywinch?lang=en) and produced by [Katie Couric](https://en.wikipedia.org/wiki/Katie_Couric)
- See her [TED Talk](https://www.ted.com/talks/lori_gottlieb_how_changing_your_story_can_change_your_life?language=en) where she talked about how changing our stories help us change our lives

> “I think that what I really love about what I do is that no matter what lens through which I’m doing it, whether it’s a column or a podcast or a Ted talk or a book or my practice, I’m really dealing with, I think what makes us most human at our core.”

**Nonlinear path to becoming a therapist**

- After college, began working in network television for NBC the same year that the shows [ER](https://en.wikipedia.org/wiki/ER_(TV_series)) and [Friends](https://en.wikipedia.org/wiki/Friends) were debuting
- While working on the show ER, a doctor saw the interest Lori had for medicine and encouraged her to go to medical school
- “*Nobody comes to an ER because they expected something to happen. It’s always an inflection point in some way in someone’s life. . . I was really interested in those inflection points in people’s lives.*”

**Med school**

- She eventually got into med school at Stanford
- Pretty early on, Lori realized that what she wanted was to guide people and to have close relationships with patients — “*And it seemed like the new medical model was not going to be conducive to that*”
- Eventually, she **left medical school to become a journalist** “*because I felt like I could really delve into people’s stories and help them to tell their stories through writin*g”

**Becoming a journalist**

- Lori became a journalist and had 10 years of success before making the next switch
- She considered going back to med school to become a psychiatrist
- But she came to the realization that she’d rather do the deeper therapy

She decided to get a graduate degree in clinical psychology

**Now, Lori is a psychotherapist**

> “I went from telling people’s stories as a journalist, to helping people to change their stories as a therapist…I feel like I’m as much an editor as I am a therapist, because I really feel like what I’m doing is people are coming in, they’re telling me we’re all unreliable narrators. They’re telling me a faulty narrative. They’re telling me a narrative that is keeping them stuck and I’m there to help them edit this story.”

## Dissecting cadavers—a profound experience during med school [12:30]

- As early med students (or pre-med), you are required to dissect a human cadaver
- Both Peter and Lori describe the experience as profound
- They found certain parts of the dissections to be emotionally tougher than others
- Peter and Lori both found the hands and the face to be particularly emotionally challenging

Lori’s says,

“*The hand is so revealing. And you think about what we use our hands for. When I was dissecting the hands, I remember thinking, ‘Whose hands did this person hold? Who did this person have? What did the person do with their hands?’*”

Peter says,

“*I don’t recall one instance of any of my classmates doing anything that felt disrespectful. I really felt like there was a remarkable both comradery amongst us as classmates, but also just a camaraderie with the cadavers. I think the families of those people would be proud of what their family members did in terms of the donation and how we as students learn from it.*”

## The sunk cost fallacy—How Lori was able to walk away from med school [17:15]

> “And it occurred to me that we all have a terminal diagnosis. Life has a hundred percent mortality rate and that’s not just for other people.”

**Walking away from med school**

- Lori admits she might be more risk averse today (now that she has kids) than she was in the past
- But at the time she was just pursuing what she was passionate about
- She quotes one of her patients who was diagnosed with terminal cancer, “*Why do people need a terminal diagnosis to really pay attention to what they want to do in their lives? We shouldn’t need that*.”

> “I sort of went into that place of knowing inside, that I think we all have, that is very quiet in most of us. We don’t listen to it. All that noise outside about what we should do or what the practical thing is, that usually drowns out that voice inside that takes us to that place of knowing.”

–*Relating this to therapy…*

- Lori says a lot of patients come to therapy looking for the therapist to tell them what to do
- Instead, Lori says she wants to help them find the answer inside themselves
- “[*The answer] is there, they just can’t hear it yet. And they have a better answer than I do for them*.”

**The logical fallacy of the “sunk cost”**

*When Peter was considering leaving medicine…*

- a group of people around him understandably made a sunk cost argument to him — i.e., “*you’ve put 10 years, into this endeavor. It’s crazy for you to walk away before you actually start your career*”
- The most encouragement he got to pursue something outside of medicine came from [Peter Pronovost](https://en.wikipedia.org/wiki/Peter_Pronovost), an attending at Hopkins, who handed Peter a [Joseph Campbell](https://en.wikipedia.org/wiki/Joseph_Campbell) book, [The Power of Myth](https://www.amazon.com/Power-Myth-Joseph-Campbell/dp/0385418868)
- In the book there was a line about line that really stood out to Peter (paraphrased)— “***a hero is the one who had the courage to pursue his own bliss***”

*When Lori was considering leaving journalism to become a therapist…*

- Lori says she faced the same “sunk cost” push back from people around her when she was decided to leave journalism to become a therapist
- People were saying, “You’re going to be 40.”
- And Lori would respond, “But I’m going to be 40 anyway…So shouldn’t I turn 40 and be doing something that I want to do?”
- Lori called the sunk cost argument to be very **faulty logic**

## Being aware of the gift of life, and other lessons from Lori’s terminally ill patient [24:00]

> “*Be aware of the gift of your life today. When you wake up, be intentional about how you want to live your life. What are your priorities? Are you living those?*”

**How Lori came to meet Julie**

- Julie was a newly-wed, young women who had just come home from her honeymoon
- She discovered a lump in her breast and doctors told her it was a very treatable form of breast cancer
- She came to Lori not because she was dying, but because she just wanted to get some support as a newlywed going through cancer
- After her breast cancer was successfully treated, Lori said goodbye to Julie—“*It’s always interesting as a therapist to say goodbye to people because that’s our goal. Our goal is to have people leave us. It’s a terrible business model, but it’s very rewarding emotionally*.”

*-Six months later…*

- Julie was diagnosed with a form of cancer unrelated to her breast cancer
- This time she was given 1 to 10 years to live
- She returned to Lori and asked Lori if she would stay with her until the day she died, and even asked that Lori would attend her funeral
- Lori said this was a very transformative experience for her— “*to watch her and be inspired by her, not because she was a saint, because what I loved about her was she was so real, and raw, and honest about what this experience was like*”

*-She did things others thought was crazy—*

- She decided she wanted to be a cashier at Trader Joes because she loved the small, but tangible interactions with customers
- She told Lori, “*You’re tangibly making someone’s day better, even if it’s for a minute. . . That’s what I want to do.*”
- It begs the question… “*Are we saying she’s ‘crazy’ because we think she’s making a bad choice, or are we saying this because we’re jealous? Do we envy the fact that she is not chicken shit like the rest of us to do something so bold that everybody else thinks is crazy*?”

**The hidden lesson**:

- She’s doing something that the rest of us wouldn’t do because we don’t have that [metaphorical] gun to our heads
- But in reality, we do have that gun to our head, we just don’t realize it
- She’s doing something that we wish we had the courage to do

> “There was so much about taking off the mask, about stripping down to the essentials, that feels invigorating. Just getting rid of the performative aspects of life, the pretense, all of that. And just saying, ‘This is who I am. Can you hear me? Can you understand me? This is how I want to manifest myself in the world.’”

## How underlying pain can manifest in obnoxious behavior [32:45]

**About John**

- John was a therapy patient of Lori’s
- He was very abrasive, rude, condescending, etc.
- From the very beginning, he was insulting Lori directly

*Why would Lori take him on as a client?*

- Lori says that these type of people are the one who **grow the most in therapy**

> “We use our behaviors to speak something, to communicate something that we can’t do with words. So we take the unspeakable and we convert it into a behavior to communicate something.”

*What was John communicating with his behavior?*

- By being obnoxious, he was keeping everyone at a distance
- His narcissistic traits might appear as him thinking very highly of himself and not so highly of others—but in reality it was a defense mechanism
- **Lori says his behavior was communicating the following**, “*I have this unspeakable pain, and I’m going to keep everybody at a distance so that they don’t get near my pain, because if they get near my pain, I might have to look at it*”
- At the time, Lori had no idea was that pain was… but she knew that eventually she could liberate him from the emotional shackles constraining him
- \*Lori’s [book](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055) reveals where that pain was coming from

**The lesson from John’s story**:

> “*There’s something about John and how it makes [people] think about the ways that we make judgments about people when we first meet them, and then how much we could come to love them if we really knew who they were.*”

## Counseling versus therapy [36:15]

See Lori’s article in the NY Times: [What Brand is Your Therapist?](https://www.nytimes.com/2012/11/25/magazine/psychotherapys-image-problem-pushes-some-therapists-to-become-brands.html)

See chapter 49 in her [book](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055)

**Counseling**

- Many people want to “buy an answer to their problem”
- We have little patience these day—she calls it “*instant gratification-itis*”
- This quicker, solution oriented style is what Lori refers to as counseling

**Therapy**

- Lori keeps a term “**ultracrepidarianism**” taped up in her office as a reminder to herself—the term means t*he habit of giving opinions and advice on matters outside of one’s knowledge*
- The person being treated must access their own place of knowing, and that’s what Lori says is her goal as their therapist
- Lori says **it’s crucial that the patient comes to their own conclusion** about what they should do
- This may take longer, but it more likely leads to enduring change

## The story of John—why men hide their feelings, breaking down his shield, and uncovering his pain [38:30]

*Peter asks Lori if John was her hardest case ever*

- Definitely not the hardest case, says Lori
- When people present for therapy, they’re not at their best
- For John, it was clear that there was this characterological piece where this is how he interacted in the world in all spheres—professional, personal, his marriage, his kids, at work
- You never know what’s going to happen with people, says Lori, which is what makes her job so surprising

*What gave Lori confidence that she could actually help John?*

- She kept in mind that the [relationship between the therapist and patient is the most important factor in the effectiveness of therapy](https://www.psychologytoday.com/us/blog/compassion-matters/201612/the-importance-the-relationship-in-therapy)
- “*The relationship in the room is a microcosm for the relationships that they will have outside.*”
- Furthermore, Lori understands that when someone volunteers to attend therapy, that in and of itself is a sign of strength
- So when someone comes in, Lori doesn’t just ask why they came in, but **why NOW?**
- Often, they know something needs to change, but they usually don’t realize that THEY are the ones that need to change

*How often do people come in because they feel like they have personally hit a low point VS coming to therapy thinking everyone around them is the problem?*

- She gets both
- But in most cases, but in most cases people feel like they are having a problem with those around them as opposed to them saying “*I know that I have a problem and I want to change*”
- There’s a saying that therapists have: “*Before diagnosing someone with depression, make sure they aren’t surrounded by assholes.*”
- People are often dealing with difficult people, but the questions they need to ask are—
  - What is their role?
  - What is their response to those difficult people?

**Why men don’t show their feelings—**

- Men often feel like they can’t show their feelings because they need to be strong for those around them
- Lori describes a common scenario when she is doing a couple’s therapy session:
  - The woman will ask that the man open up to her and share more of his feeling
  - And then when the man finally does open up, maybe even starts crying, the women will look at Lori like “a deer in headlights”
  - This is sending a mixed message to men, says Lori

–*In John’s case…*

- he really felt like he needed to be the rock for his family
- He really felt like if he became vulnerable, if he showed his pain, that the whole family would collapse because he had to be the strong one
- Lori says this is a common feeling among men
- And this feeling causes men to hold much of their pain inside

> “So I think that on the one hand, we tell men, ‘We want you to be really emotionally available. We want you to feel your feelings.
>
> And on the other hand, we don’t really, because we don’t really create the space for them. There’s a lot of shame around that. And we do shame men. And even in ways like in that couple situation where somebody says, ‘I want you to do this,’ and then you do it, and then she’s scared because you’re crying.”

## “Breaking open”—A shocking revelation about John that tests Lori’s resolve as a therapist [46:30]

**Breaking open**

- Lori has known from the beginning of working with John that there is an enormous pain lurking under the surface
- That pain is manifesting in being rude and condescending to those around him in order to keep everyone at a distance (emotionally)
- But in a powerful moment, John finally reveals to Lori the source of his pain and he gets emotional — a moment when Lori describes as “**breaking open**” as opposed to breaking down

Peter asks, *How do you control your emotions in that moment as a therapist as she’s witnessing the complete destruction of John’s armor?*

- Lori admits she had a lot of empathy for him
- John had revealed to her the death of his mother when John was 6
- John felt in some way responsible because he wanted her to rush home and he missed her
- He was carrying the burden of that and not really being able to talk to anybody about
- Those around him just kept encouraging him to move on
- “I felt like I could see glimpses of him and who he really was and the younger him and the more tender parts of him.”
- But when John really opens out about something else that happened, Lori says she was “really blindsided”
- In that moment, she actually teared up — John even calls her out with a sarcastic remark about it

> “It was an incredibly sad, tragic moving story, and I don’t think anybody could sit in that room with him and not cry. You’d have to be a robot and we’re not robots.”

## Rewriting your story, the recovery process, and the most important step for lasting change [49:00]

**Rewriting your story**

- Like many therapy patients, John had a story in his head that he was continually telling myself
- This narrative is really why he can’t sleep and what he dreams about and what keeps him up at night
- Many times we leave no room for any other interpretation of the story that we’ve created in our head
- But oftentimes we NEED to be able to look at it again and ask whether it’s the accurate story

> “Our story becomes so ossified that there’s no room for sort of any other interpretation of events and all roads in his story led to he’s a horrible person, and that just wasn’t the case.
>
> So it was really about how do you manage your remorse, how do you manage regret, and then how do you also forgive yourself, which I think is really hard.”

**The recovery process**

- We often tell ourselves a story that leads to self-loathing and an utter lack of self compassion
- But it’s possible for anyone to change
- John, for example, gives Peter hope as he strikes Peter as almost a caricature of a phenotype of a person that you just think is beyond hope—narcissistic, condescending, etc.
- But Lori counters that there’s so much room for people to grow and change and transform—

> “What’s so hopeful about when people land in my office is that’s a triumphant moment that they got there. They came and they said, “I’m ready.” They don’t know what they’re ready for yet, but they’re ready.”

**The most important step for lasting change**

There’s a chapter in the [book](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055) called How Humans Change which outlines all the steps that we go through that we’re not even aware of in preparation for the change

- The most important step is not making the actual change itself
- It’s actually the last step in a process of steps called **maintenance**—it’s ‘*How do you maintain the change?*’
- It’s important to understand that **change is not linear**—people relapse, but you can always go back to the change, and that’s okay

> “Change happens gradually, then suddenly.”

## The process of  many big therapeutic breakthroughs [56:00]

**Lori on how most big transformations come about—**

> “Most big transformations come about from the dozens or even hundreds of tiny, almost imperceptible steps that we take along the way.”

**Laying the groundwork for change**:

- Before a breakthrough can happen in therapy, Lori has to establish a feeling of connection with the patient
- The goal with John was to have just a tiny moment of connection in every session—“*He immediately gets rid of me. Every time. He can’t tolerate it.*”
- Despite being surrounded by family, colleagues, and friend, Lori describes John as incredibly lonely because he was just living in his own world and putting out a false self to maintain order
- Those few minutes of connects, no matter how brief, were the “glue” that held Lori and John together

**Helping patients get out of their own way**

- Many times people come to therapy and they feel trapped by their circumstances
- But oftentimes we are trapping ourselves

When Lori was a patient in therapy with her own therapist, he offered her the following piece of wisdom:

***“You remind me of this cartoon, and it’s of a prisoner shaking the bars desperately trying to get out, but on the right and the left, it’s open. No bars.***

***And so why don’t we just walk around the bars? Why is it preferable to us to shake the bars and say, ‘I’m a victim. I can’t do this. This isn’t available to me?’***

***It’s because if we walk around the bars, we’re free, but then we have to take responsibility for our own lives.***

***A lot of us would rather blame other people or other circumstances for why we can’t have happiness or joy or meaning or whatever it is in our lives than to say, ‘Oh, now I’m responsible for that, and if it doesn’t work out, that’s on me.’”***

\*Lori uses this analogy in her [TED Talk](https://www.youtube.com/watch?v=O_MQr4lHm0c) explaining that when people realize the bars are open, they get both elated and frightened at the same time

## The 2 types of suicidal thoughts, and the importance of talking about it [1:01:00]

**Two types of suicidal thoughts**

1—Something goes wrong which disrupts an otherwise good life (e.g., death of a loved one, getting laid off) and now there’s nothing to look forward to

2—Life itself is just barren so there’s never been anything to look forward to (Lori’s patient, Rita, falls into this category)

*How often are Lori’s patients contemplating ending their life?*

- It’s not terribly common, says Lori
- But it’s an assessment that all therapist must make when someone is very depressed

\***Important point for people suspecting a loved one may have suicidal thoughts**\*

- You have to bring it up—A lot of people feel like I don’t want to bring up suicide because that will plant the idea in their head… this is wrong!
- Lori says many parents are so afraid to discuss it with their teenage kids who seem depressed
- But Lori says you SHOULD ask about suicide because a lot of times people feel like they can’t talk about it, so it’s a relief for them, for someone to give voice to those feelings that they might be having

*One of the biggest risk factors for suicide*:

- The feeling of isolation, of being completely alone in the world
- If you’re experiencing such pain and you can’t share it, you feel really alone in the world

## The most common issues that bring patients to therapy with Lori [1:02:45]

**Relational issues**

In Lori’s practice, the most common reason people come to her is for **relational issues** with…

- Coworkers
- Parents
- Kids
- Spouses, or
- The **relationship to themselves**

**The relationship to the self**

- Many come to Lori because their life is not going the way that they had expected it to go
- Or something’s not working *but they can’t figure out what*

**The value in therapy**

- A therapist who can look at you from the perspective of not having all that other information yet and being able to see what is going on right here, right now.

> “Therapy is getting a good second opinion on your life.”

**Humans are ridiculous in a relatable way**

- Humans are ridiculous, “*we say one thing and we do another all the time*”
- We try to protect ourselves in ways that actually make things **less safe**
- We try to be heard or seen yet the way we’re doing it **ensures that we’re not going to be heard or seen**
- We chase after some kind of meaning or joy but we end up doing the exact thing that will basically **guarantee our own unhappiness**
- We commonly self-sabotage in ways that we aren’t even aware of
- Lori hopes that by watching the people in her book go through, it gives people an idea that maybe they can do that, too

## Clinging to the familiar—why change is so hard [1:05:15]

- Change is so hard because we cling to the familiar
- We try desperately to stay with the safe thing
- But the moments in life when bad or unwanted things occur are often when something really transformative happens

> “We cling to what we know. And so even if you’re making a really positive change, sometimes we fight that because we don’t like uncertainty. Humans don’t like uncertainty.”

## A story of shame, lack of self-compassion, and self-sabotage [1:07:00]

**About Rita**

- 69 year old woman
- Lives alone – one of the most isolated people Lori has ever known
- Her adult children are estranged from her
- Almost no physical contact with other people
- She is living with an incredible sense of regret after making significant mistakes as a parent

*The ultimatum*—She told Lori, “*If things don’t get better by my 70th birthday [in one year] then I don’t want to live anymore.*”

**Lori’s goal for Rita**—To have her “join the human race again” and make connections

- But Rita had no interest in doing that in the ways that Lori suggested

**Self-sabotage**

- When things started to change for Rita a little bit, she sabotaged it right away
- Rita had what’s called “[cherophobia](https://en.wikipedia.org/wiki/Aversion_to_happiness)”—the fear of joy

> “A lot of people who grow up in situations where they felt like they were robbed of their joy are very suspicious of joy. They don’t trust it.”

*Where did this “fear of joy” come from?*

- As a young girl, Rita’s mother was very distant
- Occasionally, her mother would start to act like a normal, loving mom
- But then her mother was go dark again
- As a result, Rita never trusted joy and connection, so when those feeling presented in her adult life she would do everything she could to ruin it

Similar to John —

- John would **actively** distract and destroy the connection
- Rita would do it in a very **passive** way

⇒ Example,

- Rita met a man named Myron who seemed to be a wonderful opportunity for Rita to having a meaningful connection to someone
- However, Rita writes a letter to Myron—which she shows to Lori—which basically lays out all the reasons why he shouldn’t get involved with her—**she’s a monster and she is unlovable**

**A portion of Rita’s letter to Myron**:

“*Wait, you don’t know, Myron, what even my second and third husbands didn’t fully know is that their father, my first husband, Richard, drank. And when he drank, he hurt our children, my children. Sometimes with words, sometimes with his hands. He would hurt them in ways I can’t get myself to write here. Back then, I would scream at him to stop, pleading, and he would yell back at me. And if he was very drunk, he’d hurt me, too, and I didn’t want the children to see that, so I would stop. You know what I did instead? I would go into the other room.*

*Did you read that, Myron? My husband would be hurting my children, and I would go in the other room. And I would think about my husband, you are ruining them forever, hurting them beyond repair, and I would know that was ruining them too. And I would cry and do nothing.*”

**Reconciling your mistakes of the past with who you are in the present**

- When Rita was a young mother, her husband was an abusive alcoholic
- Something he would hit their children and Rita would go in the other room instead of trying to stop him
- She never has forgiven herself for this (and neither have her kids)
- On the one hand, what Rita did is reprehensible
- But on the other hand, there are so many understandable reasons (even if they’re not excusable reasons) for why she did what she did.
- Lori says, “*I don’t think she’s a monster at all, but I can understand why her kids do. So there’s both sides of that.*”
- In fact, today, “*Rita is a lovely person*,” says Lori

\*The question then becomes: *How do you reconcile the monstrous person she described in her letter with the person she is at her core? The person BEFORE she became so damaged by her own experiences that she then damaged other people because of it?*

## The importance of managing mental health to reduce unnecessary suffering [1:15:45]

**Peter points out how importance of managing mental and emotional health**:

“I think when the story of my life is going to be told, the people who are going to have literally saved my life are going to be the people who helped me with my mental health. And I don’t think that can be overstated, and I think that that represents the greatest single opportunity to reduce suffering on this planet is through this.” —Peter Attia

**When people graduate from therapy**:

- Lori’s goal with her patients are to have to leave her
- In other words, to graduate from therapy
- Peter asks how she knows when people are ready?

**Lori compares therapy to physical health and training**

- First, physical health and mental health are not separate, they are intertwined
- But then the other part of it is that if something feels off in your **body** you have no qualms with getting it checked out
- For example, if you’re have some discomfort in your chest, you go to a cardiologist before you have a massive heart attack
- By contrast, if someone is having some emotional discomfort, they often justify it or minimize it to being not that bad
- So when they finally land in a therapist’s office, they’re having the equivalent of an emotional heart attack

**The problems with waiting until you have an “emotional heart attack” before seeking help**:

1—You’ve suffered unnecessarily for all of that time that you were feeling the discomfort and you didn’t need to

2—It’s harder to treat right now because now you’re in this crisis phase—you could have dealt with it in a different way and change would have happened much more easily… “*Now we’re digging out of the hole.*”

3—The collateral damage is also worse—if you’re sitting there with a bum knee that you ignore for 10 years too long, it probably hasn’t hurt other people as much as if *you spend 10 years in depression*

## Dispelling the misconceptions about therapy [1:23:15]

**Misconception #1**: You go to therapy and you talk about your childhood ad nauseum and you never leave

- That’s just not what therapy is, says Lori
- In fact, it’s very much focused in the present
- Perhaps you’ll discuss how a story from your past is living inside of you and is getting in your way, but it’s really about what you are doing in the present in order to have a better future

**Misconception #2**: You go to therapy, “download” the problem of the week, go home, repeat.

- That’s also not therapy, says Lori
- There’s a saying in therapy: “***Insight is the booby prize of therapy.***”
- Meaning, you can have all the insight in the world, but if you don’t make changes out in the world, the insight is useless.
- **Analogy**: It’s like going to physical therapy or working out
  - If you go to physical therapy and you don’t do the exercises at home that you need to do in between, you’re not going to improve, nothing’s going to change, and it’s not going to feel better ultimately
  - The exercises you do in physical therapy (or in the gym) are not for the sake of the exercise itself — it’s so that you can apply it to the activity of life

§

## Selected Links / Related Material

**Lori’s book**: [Maybe You Should Talk to Someone: A Therapist, HER Therapist, and Our Lives Revealed](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055) by Lori Gottlieb | (amazon.com) [3:15]

**Lori’s weekly column for The Atlantic**: [Dear Therapist](https://www.theatlantic.com/category/dear-therapist/?gclid=Cj0KCQjw6uT4BRD5ARIsADwJQ182CDc_otMPRxFoBwpuscpmiECY9MYzljlqhe5RATtD8SNuPwJDPgYaAq-qEALw_wcB) | (theatlantic.com) [5:15]

**Lori’s new podcast co-hosted by** [**Guy Winch**](https://twitter.com/guywinch?lang=en) **and produced by** [**Katie Couric**](https://en.wikipedia.org/wiki/Katie_Couric): [Dear Therapists](https://podcasts.apple.com/us/podcast/introducing-dear-therapists/id1523340696?i=1000484652853) | (podcasts.apple.com) [5:15]

**Lori’s TED Talk**: [How changing your story can change your life](https://www.ted.com/talks/lori_gottlieb_how_changing_your_story_can_change_your_life?language=en) | (ted.com) [5:15, 1:00:45]

**Joseph Campbell book that Peter was gifted when deciding whether or not to leave medicine**: [The Power of Myth](https://www.amazon.com/Power-Myth-Joseph-Campbell/dp/0385418868) by Joseph Campbell | (amazon.com) [21:00]

**Lori’s article in the NY Times about counseling vs. therapy**: [What Brand is Your Therapist?](https://www.nytimes.com/2012/11/25/magazine/psychotherapys-image-problem-pushes-some-therapists-to-become-brands.html) | Lori Gottlieb (nytimes.com) [36:30]

**Studies suggest most important factor in the success of someone’s therapy is the relationship that you have with your therapist**: [The Importance of the Relationship in Therapy](https://www.psychologytoday.com/us/blog/compassion-matters/201612/the-importance-the-relationship-in-therapy) | Lisa Firestone Ph.D. (psychologytoday.com) [40:30]

§

## People Mentioned

- [Guy Winch](https://twitter.com/guywinch?lang=en) [5:15]
- [Katie Couric](https://en.wikipedia.org/wiki/Katie_Couric) [5:15]
- [Peter Pronovost](https://en.wikipedia.org/wiki/Peter_Pronovost) [21:00]
- [Joseph Campbell](https://en.wikipedia.org/wiki/Joseph_Campbell) [21:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/08/1x1-lori-gottlieb-500x500.jpg)

##### Lori Gottlieb

Lori Gottlieb is a psychotherapist and author of the New York Times bestseller [Maybe You Should Talk to Someone](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055), which is being adapted as a television series. In addition to her clinical practice, she writes [The Atlantic’s weekly “Dear Therapist”](https://lorigottlieb.com/dear-therapist/) advice column and [contributes regularly to The New York Times](https://lorigottlieb.com/articles/) and many other publications. Her recent [TED Talk](https://www.ted.com/talks/lori_gottlieb_how_changing_your_story_can_change_your_life) is one of the top 10 most watched of the year. A member of the Advisory Council for Bring Change to Mind and advisor to the Aspen Institute, she is a sought-after expert in media such as The Today Show, Good Morning America, The CBS This Morning, CNN, and NPR’s “Fresh Air.” She is also the co-host of the [new iHeart Radio podcast, “Dear Therapists,”](https://lorigottlieb.com/podcast/) produced by Katie Couric. Learn more at [LoriGottlieb.com](https://lorigottlieb.com/) or by following her on Twitter [@LoriGottlieb1](https://twitter.com/LoriGottlieb1) and Instagram [@lorigottlieb\_author](https://www.instagram.com/lorigottlieb_author/).