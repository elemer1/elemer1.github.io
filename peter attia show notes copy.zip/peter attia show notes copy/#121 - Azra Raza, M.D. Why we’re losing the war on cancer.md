# #121 – Azra Raza, M.D.: Why we’re losing the war on cancer

**Source:** [https://peterattiamd.com/azraraza/](https://peterattiamd.com/azraraza/)

---

Azra Raza is a physician, scientist, author, and outspoken advocate for reconfiguring the current model of research in cancer. In this episode, Azra discusses the content of her book, The First Cell, which takes a critical look at the outdated models being used to study cancer resulting in a lack of progress in survival rates for cancer patients. Azra offers a solution which focuses on early detection and prevention, and she concludes with an optimistic outlook for the future of cancer research.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/azraraza/the_Drive_public.png)

Play

#121 - Azra Raza, M.D.: Why we're losing the war on cancer

1x15s30s

0:001:54:55

## We discuss:

- Azra’s upbringing, interest in oncology, and the basis for writing her book [3:30];
- The lack of progress in cancer treatment over the decades [18:45];
- What is holding the oncology field back? [33:15];
- Do the purported advances in oncology reflect the billions of dollars spent on cancer research? [40:00];
- Economics of new cancer drugs—how small increases in survival come with staggering financial burdens [47:00];
- How good intentions can still lead to misaligned incentives and a broken system [1:03:00];
- Why 95% of new cancer drugs fail—a critical review of the cancer research model [1:11:15];
- Early detection and prevention—a potential solution to the cancer problem [1:22:30];
- Coping with the loss of her husband to cancer [1:46:00];
- Azra’s optimistic view of the future [1:49:30]; and
- More.

§

## Show Notes

## Azra’s upbringing, interest in oncology, and the basis for writing her book [3:30]

- Azra had no intention of ever writing a book
- In fact, she always explicitly said that she is NOT a writer
- However, she certainly had the credentials to write a book about cancer:
  - First, she has spent 30 years studying oncology
  - Secondly, she’s had a very active basic science laboratory throughout that time
  - Third, she is a cancer widow—lost her husband to cancer in 2002
- But even that wasn’t enough to motivate her to write the book
- The **final push** to write the book happened when her daughter’s best friend, at age 22, developed a [glioblastoma multiforme](https://en.wikipedia.org/wiki/Glioblastoma)—one of the most malignant tumors known to mankind

> “It slapped me in the face physically that, on the one hand, the ferociousness and violence of his tumor, and on the other hand, the utter helplessness of all of us, his oncologists, to do anything about it. Our complete failure in front of Andrew. How is it possible that we are so spectacularly failing a 22 year old boy? That’s what forced me to write the book.”

**What drove Azra to oncology?**

- Growing up in Pakistan, she was very interested in the nature world around her
- She like embryology
- She loved evolution and was a fan of Darwin’s work
- If it were an option for her in Pakistan, she claims she was have likely studied [myrmecology](https://en.wikipedia.org/wiki/Myrmecology)—the scientific study of ants

*A couple things happened to her that set her course into oncology*:

  1 | In his third year of medical school, she saw her first patient—

- That patient was a young woman with acute myeloid leukemia presenting with a very large spleen
- “I *realized from that moment on that all of my life would be devoted to somehow use the best that science has to offer to reduce human suffering*.”

 2 | Witnessing the violent nature of cancer

- Karachi, Pakistan is very impoverished and when a person would get cancer they would travel long distances by donkey and on foot
- By the time they arrived for care, they would have end stage malignancies sprouting through breasts or huge lumps breaking out of people’s heads and arms

The combined factors of i) the violence of the disease, and ii) the intellectual challenge of understanding cancer pushed her into oncology

> “It was the malevolence of the tumor, the violence of the disease, on the one hand. On the other hand, the intellectual challenge of trying to figure out how this whole thing began in a single cell and how that cell goes rogue, what journeys has it undertaken to reach this level of malignancy? It was the dual emotional as well as intellectual grip that basically caught me at a young age.”

**The commonality of being moved by a med student’s “first patient”**:

- Peter tells a similar story of how moved he was after seeing his first patient as a med student—someone with stage four colorectal cancer who Peter became very close with until he died 2 years later
- [Steve Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg)’s first patient—
  - The patient had metastatic gastric cancer to the liver, which should have killed the patient, but somehow his tumor was eradicated
  - This led Steve to conclude the only way that was possible was if his immune system eradicated it — and Steve has since pioneered effective immunotherapies for cancer
- Azra says she is very mindful of this experience for first year med student

Azra quotes [Emily Dickinson](https://en.wikipedia.org/wiki/Emily_Dickinson), “***Tell all the truth but tell it slant. Success in circuit lies. Too bright for our infirm delight, the truth superb surprise. As lightning to the children eased, with explanation kind, the truth must dazzle gradually or every man be blind.***”

## The lack of progress in cancer treatment over the decades [18:45]

When Azra came into oncology, she says it was almost a “stigma” to have cancer

- People didn’t want to talk about it, so many people hid it (even from themselves)
- They would delude themselves into thinking that it was some kind of infection that would go away
- There were very little screening measures being performed (especially in Pakistan)
- This would result in most people presenting with advanced cancers

In med school at [Dow Medical College](https://en.wikipedia.org/wiki/Dow_Medical_College), they were taught that the causes of cancer were:

- Genetic or hereditary component where you have a predisposition for high risk of some sorts of cancers
- Some environmental exposure to toxins
- Pathogens were considered an exciting new avenue for research
- Perhaps this was a viral disease — especially retroviruses
- And then smoking was known to have a strong component of association

**The lack of progress in oncology**

- Azra says if you want to measure the success of treatment in cancer, then you need to look at—**What is the age adjusted mortality of cancer today in 2020?**
  - *It is the same as it was in 1930*, says Azra
  - Yes, there is a ~27% decline in mortality we are seeing in the last 30 years, but that is following a 30 year increase in mortality in cancer due to smoking
  - In other words, there was such an increase in the incidence of cancer from smoking that the decline in mortality basically parallels the decline in smoking

> “We are really at square one and that is the embarrassment that nobody wants to recognize.”

Peter says that what Azra is saying about the lack of progress in cancer seems “*completely at odds with what the propaganda machine is saying*”

Azra explains her statements with some history:

- Solid tumors—
  - The first known treatment of cancer was in 500 BC
  - The Persian queen Atossa had felt a lump in her breast
  - She got a Greek slave to slash off her breast with a sword
  - What’s the primary treatment for breast cancer today? “*Same slash*”
- Liquid cancers—
  - Since you can’t cut it out, you need to poison it somehow
  - During the World War I, chemical weapons were created as weapons of war
- one of the side effects that people died from was low blood counts
  - [Goodman and Gilman, two pharmacologists at Yale, decided that this could be used to treat cancer](https://yalealumnimagazine.com/articles/3173-pioneers-in-chemotherapy#:~:text=In%201942%2C%20he%20assigned%20two,the%20Johns%20Hopkins%20medical%20school.)
  - Those chemicals were cytoxan, chlorambucil, and melphalan
  - And those chemicals are still in use to this day
- The point is this… “We are slashing. We are poisoning the same way and then burning with radiation therapy the same way.”

> “The only good news you can give to a cancer patient is ‘Oh, we caught it early so we can get rid of it.’ We know that cancer itself may not kill; it’s the delay in treatment that really kills.”

**Comparing statistics over the decades**

- Today, 68% of newly diagnosed cancers are cured via slashing, poisoning, burning, surgery, radiation, and chemo
- Except for a few cancers where there are targeted therapies or antibodies available, “*really not much has happened,*” says Azra
- The 32% who present with advanced disease, we can’t use the slash/poison/burn protocol
- In other words, the same treatments that were working in earlier stages are not working in later stages

\**The point Azra will keep making OVER and OVER*: The only thing we can do right now is to **find the cancer earlier**

- Some of the promising targeted therapies that are not working, may actually work if caught earlier
  - E.g., FLT3 mutations caught early may respond much better to FLT3 inhibitors

Peter points out the contrapositive to the point Azra is making—

- We don’t really have therapy that works for **systemic** disease
- In other words, if you present with metastatic cancer (breast, colong, prostate, etc.), you are no better off today than you were 50 years ago

## What is holding the oncology field back? [33:15]

Problem #1:

- We are celebrating chronic versions of cancer (e.g., [chronic myeloid leukemia](https://en.wikipedia.org/wiki/Chronic_myelogenous_leukemia)) that have a genetic origination which can be cured by targeting a single gene with the drug (Gleevec in the case of CML)
- The problem with celebrating this is because it’s chronic, i.e., not malignant, and once it becomes “acute” the drug therapy no longer works
  - Meaning it must be caught very early for the cure to work
- It’s also extremely rare — probably accounted for less than 1% dent in cancer mortality in the past 20 years

Problem #2:

- We celebrate hematologic malignancies—acute promyelocytic leukemia—which is cured with arsenic or with vitamin A analog ([ATRA](https://en.wikipedia.org/wiki/Tretinoin))
- But the reality is that the discovery of this cure was stumbled upon in a way
- And they only figured out after the fact by working backwards to find the molecular lesion

Problem #3:

- Lymphomas are successfully treated with a cocktail of chemotherapy and drugs
- And from there the scientific logic became… “*we just have to find the right four drugs for pancreatic cancer or ovarian cancer, and we’ll fix it.*”

> “These are rare types of cancers. Melanoma, dramatic differences in survival today, but again, all of these together would account for less than 10% of cancers together. Still, we have to go back to whatever we can slash, poison, and burn and successfully we are able to do that for 68% cancers either because their disease is responsive…or because it is amenable to surgery. That’s it.”

**A counter argument to Azra’s point**—one that optimistic people tend to use—is that if we just keep plugging away, in a few more decades we will figure out the 32% of cancers that are not responsive (I.e., it’s just a matter of time)

- Azra says she’s been hearing that argument forever
- And how do we even define advances?
- Azra poses the question: *Have the advances reflected the quarter of a trillion dollars we have invested in research?*

## Do the purported advances in oncology reflect the billions of dollars spent on cancer research? [40:00]

**Looking at the field of immunotherapy for cancer—**

- The 2 most popular immunotherapies are…
  - i) cell therapies—work with cell, cytokine, interleukin therapies combined with T cells, etc.
  - ii) [checkpoint inhibitors](https://en.wikipedia.org/wiki/Checkpoint_inhibitor)—
    - normal cells will have signals on themselves saying, “Eat me or don’t eat me.” and these signals are the **checkpoints**
    - And by using drugs you can unmask the signal which has been covered up by the cancer cell

The two main ideas in immunology that came along were—

- i) How to target these checkpoints so that the body’s own immune cells can recognize the cancer as being alien to the normal functioning of the body and must be eliminated
- ii) Can you take the body’s own immune cells and **engineer them** in such a way that they can selectively kill cancer?
  - [CAR T cells](https://en.wikipedia.org/wiki/Chimeric_antigen_receptor_T_cell) have been proclaimed as revolutionary, but the problem is that it has done very little for patients
  - *Why has it done so little for patients?*
    - CAR T cells cannot distinguish between normal and cancer cells
    - “*CAR T cells are just another form of killing machine indiscriminately*.”
    - The only thing CARs are working for right now is B cells because you can replace B cell function after you kill every single last B cell in the body, **but you can’t do that to pancreatic cancer because it will kill the whole pancreas**
    - Azra says the problem is that the oncologists/immunologists will not acknowledge this fact

> “In all of those talks, I have never heard any serious scientists, oncologists or immunologists say that their CAR T-cells cannot distinguish between normal and cancer cells. They just ignore that. It’s like they just don’t want to acknowledge it.”

*But what about the promising case studies?*

- Peter points out that there are some cases studies that look more promising that the picture that Azra painted
  - Such as in [cholangiocarcinoma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6314790/), pancreatic cancer, [colon cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7019711/), breast cancer — instances where they are able to identify the unique antigen of the cancer such that you can send the T cell loose and eradicate just the cancerous piece
  - One might look at these case studies and think that adoptive cell therapy (i.e., CAR T-cell therapy) and checkpoint inhibitors are really going to be the way of the future

*Does Azra hold out hope that these will result in a* ***demonstrable*** *step function forward in cancer therapy?*

- “No, not particularly.” says Azra
- While Azra thinks we are making progress, she thinks we could be making better progress

***“Here’s the problem”***:

- 95% of experimental agents in cancer fail completely
- And the 5% that do “succeed” really should have been considered a failure because all they are doing is prolonging survival by a few months for 20-30% of the patients
- In oncology, we consider [progression-free survival](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/progression-free-survival) when measuring success — “S*urvival has become too big of an obstacle to overcome*.”
- So a drug that extends life by *a few months* will then be approved and the drug will make *billions of dollars*

## Economics of new cancer drugs—how small increases in survival come with staggering financial burdens [47:00]

**Example of** [**Avastin**](https://en.wikipedia.org/wiki/Bevacizumab)

[Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) brought forth an idea—

- If a tumor can’t make new blood vessels it can’t get very big
- Therefore, the ability to make new blood vessels must be of paramount importance to metastases
- So the concept of neovascularization became key
- This led to a whole class of drugs called [anti-VEGF drugs](https://en.wikipedia.org/wiki/Anti%E2%80%93vascular_endothelial_growth_factor_therapy) (Avastin being one of them)

*Survival impact of Avastin—*

- Avastin was tested it in colorectal cancer
- Normally, a patient that had metastatic colorectal cancer is not going to survive
- When you added Avastin into the entire mix of the standard care, **you only increase median survival by several months depending on the type of cancer** (e.g., [4.7 months for colorectal cancer](https://pubmed.ncbi.nlm.nih.gov/15175443/))
- Yet, the cost of the drug could be **$100,000**

⇒ See this NY Times Article: [A Cancer Drug Shows Promise, at a Price That Many Can’t Pay](https://www.nytimes.com/2006/02/15/business/a-cancer-drug-shows-promise-at-a-price-that-many-cant-pay.html)

This led to a new discussion—**What is the value of a life?**

- In countries with *public* insurance, they came up with the term “quality adjusted life year” (QALY)
- It became a cost-benefit discussion… “*Do we believe that the cost of a life is worth ‘X’ such that a publicly funded insurance for health would be accountable to spend that money*?”

Azra quotes [John Donne](https://en.wikipedia.org/wiki/John_Donne), “*Any man’s death diminishes me, because I am involved in Mankind. And therefore never send to know for whom the bell tolls: It tolls for thee.*“

- Azra says that every oncologist is trying their hardest, but they are **not following the correct path**

> “They’re all trying their hardest, but it’s like trying to use a map to find your way in London, but you’re using a map of Paris. It’s not going to work.”

**Example—*****acute myeloid leukemia (AML)***

- Working as a fellow in 1977, Azra says that it was standard practice to give a combination of Ara-C and Daunomycin to patients with acute myeloid leukemia (AML)
- That combo was given for 7 days with one of them and 3 days for the other — this became shortened to “7+3”
- In 2020, guest what? … They are still giving “7+3”
- The median survival in 1977 was 10%
- Now, in 2020, the median survival in 26%
- What accounts for the increase? ⇒ **Better supportive care** measures (antibiotics, more platelets are given, red cell transfusions, etc.)
- *“The supportive care is better, but the backbone of treatment is the same, 7+3.”*

*The cost of 7+3—*

- The standard 7+3 treatment was priced at $5,000 for one cycle of treatment
- But a company came along and made a “new” drug where they took the same “7+3” and they packaged into a fatty envelope and it was approved for patients aged 60-75
- This “new” drug was priced at **$45,000 for one cycle**
- Yet, even with cherry-picked patients, this new drug **only increased the median survival by 3.7 months**

**The extreme pressure on oncologists**

- Azra says that oncologists are under *extreme pressure* to give these drugs despite the exorbitant cost and little relative life extension for a small fraction of patients
- If the doctor were not to give the patient the drug, and the patient dies (which they eventually do because it’s an older age group) then the family would likely **sue the doctor**
- The family will point out that the drug was available and it COULD have given the patient an extra 3.7 months

> “So now the decisions that we are making as individual oncologists are not being made by us. They’re made just by key opinion leaders, or the very institutions, like FDA, which are supposed to protect the patients.”

*Lowered standards for drug approval—*

- Drug approval standards has been lowered to “laughable” criteria
- Under the pressure of advocacy groups who are demanding more drugs for cancer patients at any cost, the FDA has lowered its bar of approving drugs to “laughable criteria”
- With that in mind, it is “no surprise” that—
  - [42% of cancer patients](https://www.beckershospitalreview.com/finance/cancer-forces-42-of-patients-to-exhaust-life-savings-in-2-years-study-finds.html#:~:text=Financial%20Management-,Cancer%20forces%2042%25%20of%20patients%20to%20exhaust%20life,in%202%20years%2C%20study%20finds&text=Two%20years%20after%20a%20cancer,The%20American%20Journal%20of%20Medicine.) who are diagnosed today will be completely financially ruined by the second year of their diagnosis
  - [50% of women with stage 4 breast cancer](https://www.medscape.com/viewarticle/903202) are being hounded by collection agencies

“*Every human life is important*” says Azra, “*but at what cost to the others*?”

==> Marty Makary ([previous podcast guest](https://peterattiamd.com/martymakary/)) writes about this problem with the US healthcare system is his book, [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110)

## How good intentions can still lead to misaligned incentives and a broken system [1:03:00]

**Azra quotes** [**The Ballad of Reading Gaol**](https://en.wikipedia.org/wiki/The_Ballad_of_Reading_Gaol) **by Oscar Wilde—**

“***Yet all men kill the things they love. By each, let this be heard. Some do it with a bitter look and some with a flattering word. The coward does it with a kiss, the brave man with the sword. But each man kills the thing they love. By each let this be heard.***“

*What did he mean by this?*

- When we meet someone (or have an idea) we immediately make an impression in our mind
- The next time we meet them (or explore the idea) they don’t correspond with the impression we had
- From there, instead of correcting our impression, we start trying to change the person—And this is how we enter the cycle of self-delusion and kill the thing that we love

*What does this have to do with oncology?*

- Because we started with good intentions
- But Azra is frustrated with the quickness people go to monetize things
- “*It leaves such a bad taste in my mouth.*”

> “You are never going to be able to cure an advanced cancer by a diet of any sort, or even by supplementing chemotherapy with the diet. All you are aiming for is improving their survival by a few months. But more important is to make companies. Why? Why have we come to this?”

**Peter’s response**:

- Peter points out that progress has to be funded somehow
- He wants to get Azra’s thoughts on the role of pharma in the entire landscape

Public funding—

- (e.g., [NIH](https://www.nih.gov/), [NCI](https://www.cancer.gov/))
- Since [Nixon declared the war on cancer](https://www.youtube.com/watch?v=lQYfC9kisHw) in 1971, more than half of research dollars were funneled through the NCI

Pharma—

- Pharma has now outsourced R&D
- Instead, they acquire R&D products — this opens up opportunity for smaller companies with venture capital money investing in stage one risk
- Pharma comes in and brings the huge capital allocation required for late stage two/three that is closer to drug approval
- This opens up opportunity for pharma to reposition the “7+3” drug and charge 10x more for it
- Peter wonders how we are ever going to get pharma to put patient’s best interest above their shareholders’ best interest
- Instead, you get a situation where Keytruda is costing an arm and a leg and only extending life by a few months — but the pharma company is making big money on it

> “Every life is valuable, and that includes the lives that remain…That’s the counterpoint that’s never made. It’s not just the life of the individual that we’re debating extending by 3.1 months at some unbelievable sum, it’s the lives of everybody that remains and what it says about their social security check, what it says about their schools, and what it says about their healthcare.” —Peter Attia

**Azra main point**:

- We started with good intentions
- But we’ve become accustomed to the existing landscape which has become corrupt
- She compares it to a frog that will slowly get boiled—“I*f you take a living frog and you throw it in boiling water, it will jump out. But if you put it in cold water and start heating it slowly, it will die in there, because it has been desensitized so slowly*.”

## Why 95% of new cancer drugs fail—a critical review of the cancer research model [1:11:15]

**About** [**95% of anticancer drugs we bring to the bedside fail**](https://www.nature.com/articles/nrd1470)

Azra’s take on why that’s the case…

- The pretesting platform we are using is so artificial—We are taking a very complex disease like cancer, and we’re trying to reduce it by reductionist approaches into trying to replicate this complexity in mouse models, tissue culture, cell lines. And if those don’t work, we add layers upon layers of complexity to it by genetic engineering, immunocompromisation of the animal.
- In Azra book, [The First Cell](https://www.amazon.com/First-Cell-Human-Pursuing-Cancer/dp/1541699521), she points out the futility of following the standard drug testing approach of starting in an in vitro cell system, moving to mouse models, then going to humans
- This is the same old, ancient platforms that have led to a 95% failure rate of cancer drugs

**Explaining why this old model is used**:

- You can’t test a new drug in humans because you don’t know if it’s safe
- First, you test the drug against tumor cells in culture — but they don’t survive long in culture
- In order to make them survive longer, the tumor cells have to be engineered
- Those engineered cells can then be put into mice and they will grow

The problem, however, as Azra points out in The First Cell—

- When it was tested to see what kind of genes are the tumor cells were expressing, instead of expressing genes that were faithful to the tissue of origin from which they came—e.g., an ovarian cancer cell line should be expressing genes that are expressed in ovarian cancer—it turned out that there has been a **transcriptomic drift that basically all the cell lines, irrespective of their tissue of origin, express similar genes that make them survivable under adverse in vitro conditions**

**Cancer is actually not that hard to kill**

- In fact, we all probably have 30 chemicals under our sink that could kill even the deadliest of cancers
- The challenge is killing cancer and not killing everything else.
- But when you have immortalized cancer through engineering in the context of in vitro cultures, they have become so genetically skewed it’s not longer relevant to the species of interest–a human being

Bringing it back to the Oscar Wilde quote—

- We started with a good thing. When it didn’t correspond to what we were hypothesizing, instead of changing our concept, we keep tinkering with trying to change the other thing.
- And that’s how we got to the situation where **up to 90% of the papers published in the highest profile journals of science are irreproducible**
- “It is unconscionable what we are doing.”
- Why are they not reproducible? ⇒ Because for the same reason, one set of mice don’t correspond to another set of mice in another lab.

**Azra’s main point**:

- 95% of your drugs are failing
- After quarter of a trillion dollars in research
- About $6 billion a year
- And NCI funding and another $6 billion from philanthropy funding
- **Where is all this $12 billion going?**

For the academic researcher —

- She will try to get grants
- At best she will get $250,000
- And with that money, all you can do is study one gene, one signaling pathway
- If she gets super lucky, she will find something encouraging and is a potential target
- In order to get that to the bedside for a cancer patient, it must first be tested in these mouse models
- A phase 1 trial at the bedside will then cost $30 million
- And by the time this drug will get approved, it will have cost 2.5 billion dollars
- And the only group that can fund such a thing is **big pharma**
- This puts academics in a strange position—when recruiting young faculty, universities are asking candidates, “How many clinical trials are you going to open when you come?”

**Peter’s take**:

- It’s a symptom of a broader issue, which is the **incentives have come out of line**
- Another example is the entire **system of publishing in academic**s and how it has become so skewed
- It started with a good idea… scientists would do work, would publish them in journals would have them peer reviewed
- Knowledge would be shared broadly so that others might see it, learn from it, and not make the same mistakes, and build on the work of others
- But now, total publications is a criteria for promotion within the academic system, which leads to an entire cottage industry of garbage journals and garbage studies
- This is how you get to the point where almost none of the studies are not reproducible

The process that Azra is describing is “a logarithmic order in front of that”

- And that is taking research from the so-called bench to the bedside
- Peter says he’s very discouraged

## Early detection and prevention—a potential solution to the cancer problem [1:22:30]

- Back in 1961, [Peter De Vries](https://en.wikipedia.org/wiki/Peter_De_Vries) wrote the following in his [book](https://www.amazon.com/Blood-Lamb-Novel-Peter-Vries/dp/0226143880), referring to his young daughter’s battle with leukemia: “*So death by leukemia is now a local instead of an express. Same run, only a few more stops. But that’s medicine, the art of prolonging disease*.”
- In 2020, Azra says we’re still taking the local train — “I *feel like I’m living in a theater of the absurd*.”

Azra ponders—

- Why do we keep promoting the tumor three months or five months advantage in survival?
- Why aren’t we going for bigger goals and better things?
- “*We can do it!*”

> “We are living in an era of the most sophisticated technological advances possible, and yet the treatment of cancer is paleolithic. . .The kind of disfiguring, horrible treatments we give is like beating the dog with a baseball bat to get rid of its fleas.”

**Is Azra against testing drugs in animals?**

- She is not against animal research in general
- But she is against testing drugs for drug development in animals because what you learn in animals does not automatically extrapolate to humans
- She says it shouldn’t be tested for safety OR for efficacy

*What should we do instead?*

- Start testing the drug in humans at one five-hundredth of the dose (a [Phase 0 study](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_0))
- From there you slowly work your way up in dose

**Early detection and prevention—a potential solution**

- The only thing that has worked is early detection, says Azra
- We should take advantage of the cutting edge genomics, transcriptomics, proteomics, metabolomics, the scanning and imaging devices that have been developed
- We should then use artificial intelligence to put all this together and develop as many tests are necessary to identify biomarkers for cancer
- We combine all this with the latest technology to for **continuous monitoring** in the human body (as opposed to once year or less)
- For example,
  - There is technology that allows someone to put a single drop of blood onto a [microfluidics chip](https://www.genengnews.com/news/prostate-cancer-detection-gets-help-from-liquid-biopsy-chip/) (M chip) as a PSA test in the context of prostate cancer
  - You can slide into a small device (and very soon into your cell phone) and give you your PSA multiple times in a day

*Finding biomarkers for cancer*

- Azra says we need to **focus on the development a biomarker** for the earliest footprints of pancreatic cancer, ovarian cancer, etc. — like a barcode and with one drop of blood
- Toshiba [announced](https://www.japantimes.co.jp/news/2019/11/25/business/corporate-business/toshiba-test-cancer-blood/) that they can detect 13 different cancers from one drop of blood in four hours for $180
- A company in the Bay Area called [Grail](https://grail.com/) is developing similar technology looking at ~30 different cancers

**Peter’s 3 Rules for not dying of cancer—**

Rule #1 = Don’t get cancer

- We know that cancer incidence is higher in a modern world than in a non-modern world
- Why aren’t we trying to better understand what the environmental triggers of cancer? — Diet? Stress levels? Lack of exercise?
- If changing factors of our lifestyle could reduce your risk of cancer by 30 to 50% (which Peter believes it possible), how could we not make that a high priority to understand?

Rule #2 = Very smart screening for cancer

- Peter says that most people who are critics of early screening are lacking the nuance to appreciate the accepted failures of things like PSA and mammography

Rule #3 = If you get cancer, treat it as early as possible

- Treat it when it’s in the millions, rather than the billions, of cells

==> For more on PSA screening, check out [The Drive episode with Ted Schaeffer](https://peterattiamd.com/tedschaeffer/)

==> For more on the limitation of mammography, check out [The Drive episode with Raj Attariwala](https://peterattiamd.com/rajpaulattariwala/)

**Will early detection and prevention reduce the need for finding big breakthroughs in treating metastatic lung, pancreas, prostate, breast, colon and GBM cancer?**

*Peter says:*

- Perhaps it’s that we have to catch these things long before they’re ever in a position to leave the primary organ
- Rather than try to reinvent the “onc drug discovery wheel” or come up with another cocktail that we hope we get lucky with

**What causes cancer?**

- Lifestyle factors play a role in cancer prevention, for sure
- However, we are finding that for the *vast majority of cancers*, it is random mutations that account for them—which means that cancer is most commonly associated with **increasing age**

*Why does cancer increase with age?*

- With age, many more of the cells in our body have undergone several divisions, and with each division we pick up some DNA copying errors
- By the time the cells are 60 years of age, every cell has undergone multiple cycles of proliferation, therefore, multiple genetic mutations have collected
- These mutations are making the cell unstable and susceptible to turning cancerous

Metabolism can go wrong and cause cancer

- There are a few advanced cancers where no mutations were found
- Other times, a disturbed metabolism leads to production of reduced oxygen species or free radicals which cause genetic mutations—So the primary event is a metabolic disturbance and that genetic mutations are a secondary event

**The problem with today…**

- We are still overwhelmingly using slash/poison/burn
- And it is not for lack of resources or a lack very smart people in the field
- The answer is just **very complicated and complex**

**The need to reallocate our research resources**

- Considering the complexity of treating existing cancers, we should instead shift our focus to prevention
- Instead of spending 5% in prevention, **we should spend 50% in prevention and early detection**
- Azra says she is “uncompromising” in her criticism because “*I have brought the patient back front and center and everything I look at is through patient’s human anguish*”
- 90% of our researchers never see a cancer patient because they are basic scientists and they study tumors that they grow in their labs and in animals
- We should instead **employ all of the sophisticated technology and intellectual resources to developing biomarkers for early detection in humans**
- We should look at blood, sweat, tears, saliva, urine, microbiome everything  — and do it in humans

## Coping with the loss of her husband to cancer [1:46:00]

- Azra says it’s very hard to describe the emotions that one goes through when losing someone they love to cancer
- She says she’s been through every human emotion that a wife could go through which was heightened by also having a young child
- When Harvey (Azra’s husband) was told of his diagnosis, his reaction was, “*Well, I’m glad it’s me and not you or [our daughter]. This I can handle. That I couldn’t.*”

In classic Azra, she uses an Emily Dickinson quote to capture the feeling—

‘***I had no time to hate, because***

***The grave would hinder me,***

***And life was not so ample I***

***Could finish enmity.***

***Nor had I time to love, but since***

***Some industry must be,***

***The little toil of love, I thought,***

***Was large enough for me.***’

## Azra’s optimistic view of the future [1:49:30]

**Azra’s tissue repository**

- Since 1984, Azra has been collecting samples from cancer patients
- Today, there are over 60,000 samples from thousands of patients
- It’s a depository which can really unravel so much and trace back to the cell of origin, the first cell
- With these samples, we can look for biomarkers of a early cancer
- For example, we can potentially find the biomarkers associated with something like a pre-leukemia before it spiraled out of control into acute leukemia within months, and compare it to a pre-leukemia that took 15 years to become acute
- The technology is developed and hopefully the resources will be there to finally study the whole tissue repository property and **find that first cell**

> “I am extremely optimistic about the future—even though we spent most of our time talking about a very negative and very depressing, pessimistic review of what the field has been—the future looks extremely bright.”

§

## Selected Links / Related Material

**Azra’s book**: [The First Cell: And the Human Costs of Pursuing Cancer to the Last](https://www.amazon.com/First-Cell-Human-Pursuing-Cancer/dp/1541699521) by Azra Raza | (amazon.com) [3:30]

**Azra’s TEDx talk**: [Why curing cancer is so hard | Azra Raza | TEDxNewYork](https://www.youtube.com/watch?v=07rgtBzN4Qo) | TEDx Talks (youtube.com) [4:00]

**Book that can help an aspiring writer**: [The Elements of Style](https://www.amazon.com/Elements-Style-Fourth-William-Strunk/dp/020530902X) by William Strunk Jr. and E. B. White | (amazon.com) [5:00]

**Potential for CAR T cell therapy for colorectal cancer where authors conclude their efficacy is “debatable”**: [Chimeric Antigen Receptor T-Cell Therapy for Colorectal Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7019711/) (Sur et al., 2020)  [44:30]

**NY Times Article about the big cost of Avastin**: [A Cancer Drug Shows Promise, at a Price That Many Can’t Pay](https://www.nytimes.com/2006/02/15/business/a-cancer-drug-shows-promise-at-a-price-that-many-cant-pay.html) | Alex Berenson (nytimes.com) [47:30]

**Avastin added to standard care for colorectal cancer only extends life by about 4.7 months**: [Two steps forward in the treatment of colorectal cancer](https://pubmed.ncbi.nlm.nih.gov/15175443/) (Robert J Mayer, 2004) [47:30]mar

**50% of breast cancer women with stage four breast cancer are being hounded by collection agencies**: [Breast Cancer Wariness: Half Pursued by Debt Collectors](https://www.medscape.com/viewarticle/903202) | Nick Mulcahy (medscape.com) [59:45]

**Marty Makary’s book about the broken US health care system**: [The Price We Pay: What Broke American Health Care–and How to Fix It](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110) by Marty Makary | (amazon.com) [1:00:00]

**Marty Makary’s appearance on The Drive podcast to discuss the broken US health care system**: [#68 – Marty Makary, M.D.: The US healthcare system—why it’s broken, steps to fix it, and how to protect yourself](https://peterattiamd.com/martymakary/) | Peter Attia (peterattiamd.com) [1:00:00]

**Azra quotes this famous poem by Oscar Wilde to describe how good intentions may not lead to good results**: [The Ballad of Reading Gaol](https://en.wikipedia.org/wiki/The_Ballad_of_Reading_Gaol) | (wikipedia.org) [1:03:30]

**Richard Nixon declares a war on cancer in 1971**: [From the Archives: President Nixon Signs the National Cancer Act](https://www.youtube.com/watch?v=lQYfC9kisHw) | Richard Nixon Foundation (youtube.com) [1:08:00]

**Up to 90% of papers published in the highest profile journals of science are irreproducible**: [Replication crisis](https://en.wikipedia.org/wiki/Replication_crisis) | (wikipedia.org) [1:17:00]

**Peter De Vries wrote “So death by leukemia is now a local instead of an express. Same run, only a few more stops.” in his 1961 book**: [The Blood of the Lamb: A Novel](https://www.amazon.com/Blood-Lamb-Novel-Peter-Vries/dp/0226143880) by Peter De Vries | (amazon.com) [1:22:30]

**Microfluidics chip (M chip) technology that can do a PSA test in the context of prostate cancer using a single drop of blood**: [Prostate Cancer Detection Gets Help from Liquid Biopsy Chip](https://www.genengnews.com/news/prostate-cancer-detection-gets-help-from-liquid-biopsy-chip/) | (genengnews.com)  [1:27:15]

**Toshiba’s technology that can detect 13 different cancers from one drop of blood in four hours for $180**: [Toshiba says its device tests for 13 cancer types with 99% accuracy from a single drop of blood](https://www.japantimes.co.jp/news/2019/11/25/business/corporate-business/toshiba-test-cancer-blood/) | KYODO, JIJI (japantimes.com) [1:28:00]

**A company in the Bay Area is developing similar technology looking at ~30 different cancers**: [Grail](https://grail.com/) | (grail.com) [1:28:45]

**The Drive episode discussing PSA screening in the context of prostate cancer**: [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) | Peter Attia (peterattiamd.com) [1:30:30]

**The Drive episode on the limitation of cancer screening (e.g., mammography) check out**: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/) | Peter Attia (peterattiamd.com) [1:30:30]

**Azra’s discussion with Perry Marshall**: [Azra Raza On Cancer’s $250 Billion Elephant-In-The-Room](https://www.youtube.com/watch?v=bascCLXY1w4&feature=emb_title) | Evolution 2.0 (youtube.com) [1:43:30]

§

## People Mentioned

- [Dorothy Parker](https://en.wikipedia.org/wiki/Dorothy_Parker) [5:00]
- [John Brockman](https://en.wikipedia.org/wiki/John_Brockman_(literary_agent)#:~:text=John%20Brockman%20(born%20February%2016,of%20scientific%20and%20technical%20fields.) [5:30]
- [Harvey Preisler](https://www.chicagotribune.com/news/ct-xpm-2002-05-23-0205230193-story.html) (Azra’s late husband) [8:15, 54:00]
- [Charles Darwin](https://en.wikipedia.org/wiki/Charles_Darwin) [11:00]
- [Steve Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg) [15:15, 46:00, 1:13:15]
- [Emily Dickinson](https://en.wikipedia.org/wiki/Emily_Dickinson) [17:30, 1:47:45]
- [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) [48:00]
- [John Donne](https://en.wikipedia.org/wiki/John_Donne) [51:30, 1:00:30]
- [Marty Makary](https://en.wikipedia.org/wiki/Marty_Makary) (author of The Price We Pay) [1:00:00]
- [Sughra Raza](https://physiciandirectory.brighamandwomens.org/details/1292/sughra-raza-radiology-boston) (Azra’s younger sister and head of Women’s Radiology at the Brigham) [1:03:15]
- [Oscar Wilde](https://en.wikipedia.org/wiki/Oscar_Wilde) [1:03:30, 1:16:45]
- [Lord Alfred “Bosie” Douglas](https://en.wikipedia.org/wiki/Lord_Alfred_Douglas) [1:04:30]
- [Richard Nixon](https://en.wikipedia.org/wiki/Richard_Nixon) [1:08:00]
- [Peter De Vries](https://en.wikipedia.org/wiki/Peter_De_Vries) [1:22:30]
- [Ted Schaeffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261)[1:30:00]
- [Raj Attariwala](https://aimmedicalimaging.com/tag/dr-raj-attariwala/) [1:31:30]
- [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) [1:36;30]
- [Perry Marshall](https://www.perrymarshall.com/bio/) [1:43:30]
- [Thomas Kuhn](https://en.wikipedia.org/wiki/Thomas_Kuhn) [1:44:30]

§

![](https://peterattiamd.com/wp-content/uploads/2020/07/bio-image-azra-500x500.png)

##### Azra Raza, M.D.

Dr. Azra Raza is the Chan Soon-Shiong Professor of Medicine and Director of the MDS Center at Columbia University in New York. She is the author of [The First Cell: And the human costs of pursuing cancer’s last](https://www.amazon.com/First-Cell-Human-Pursuing-Cancer/dp/1541699521) published by Basic Books, October 2019. She is considered an international authority on pre-leukemia (MDS) and acute leukemia and is one of those rare physician-scientists who divide their time equally between caring for patients and supervising a state-of-the-art basic research lab which is well-funded by multiple large grants. Dr. Raza started collecting blood and marrow samples on her patients in 1984 and now her Tissue Bank, the largest and oldest in the country with >60,000 samples, is considered a unique national treasure. She’s the recipient of numerous awards including The Hope Award in Cancer Research 2012 (shared with the Nobel Laureate Dr. Elizabeth Blackburn). [Full bio at [azraraza.com](https://azraraza.com/about/)]