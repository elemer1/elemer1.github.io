# #300 – Special episode: Peter on exercise, fasting, nutrition, stem cells, geroprotective drugs, and more — promising interventions or just noise?

**Source:** [https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/](https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/)

---

In this special edition celebrating 300 episodes of The Drive, Peter discusses a variety of popular topics and health interventions and classifies them based on their level of evidence and relevance using the following categories: proven, promising, fuzzy, noise, and nonsense. Peter first delves into the topic of geroprotective molecules, covering rapamycin, metformin, NAD and its precursors, and resveratrol. Next, he explores the significance of metrics like VO2 max and muscle mass, as well as emerging concepts like blood flow restriction and stem cells. The conversation extends to nutrition, addressing questions surrounding long-term fasting, sugar consumption, sugar substitutes, and the contentious role of red meat in cancer. Peter not only provides his current stance on each topic—most of which have been covered in great detail in the previous 300 episodes—but also reflects on how his opinion may have evolved over the years.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ep-300-exercise-nutrition-fasting-more/the_Drive_public.png)

Play

#300 - Special episode: Peter on exercise, fasting, nutrition, stem cells, geroprotective drugs, and more — promising interventions or just noise?

#300 - Special episode: Peter on exercise, fasting, nutrition, stem cells, geroprotective drugs, and more — promising interventions or just noise?

1x15s30s

0:001:40:04

## We discuss:

- Defining the categories of “proven, promising, fuzzy, noise, and nonsense” [3:15];
- Rapamycin [9:30];
- Metformin [17:00];
- NAD and its precursors [24:30];
- Resveratrol [32:45];
- The importance of VO2 max, muscle mass, and muscular strength for lifespan [38:15];
- Blood flow restriction (BFR) training [44:00];
- Using stem cells to treat osteoarthritis or injury [51:30];
- Fasting as a tool for longevity (and why Peter stopped his fasting protocol) [55:45];
- The energy balance theory [1:06:30];
- The idea that sugar is poison [1:12:00];
- The idea that sugar substitutes are dangerous [1:22:15];
- The debate on red meat and cancer [1:28:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- This special episode of *The Drive* celebrates our 300th episode
- We’re going to do something a little different for this episode, but it’s going to mirror the structure of a recent [interview](https://www.menshealth.com/fitness/a43137717/peter-attia-outlive-exercise-longevity/) Peter did, which he thought was interesting
- For today’s episode, we’re going to cover a variety of topics which you have all weighed in on, and Peter is going to rank them into the following categories: proven, promising, fuzzy, noise, and nonsense
- A couple of months ago, some of you may recall, Peter put out a video on social media where he asked people to weigh in on the types of topics that they wanted to hear covered
  - We got thousands of responses
  - We’ve sorted those into different categories and we’re about to cover half of them here
  - Turns out the response was far in excess of what we predicted, and we’ll have to finish this another time
- In this conversation, we’re going to cover geroprotective drugs, including rapamycin, NAD and its precursors, metformin, and resveratrol
- We’re going to talk about VO2 max, muscle mass, blood flow restriction, and stem cells
- Then we talk about nutrition
  - Specifically questions around long-term fasting, sugar, sugar substitutes, and the role of red meat in cancer
- All of these topics have generally been covered in greater detail across the previous 300 episodes and/or across our newsletter over the past 10 years
- We will certainly point you back to areas where we go into great detail into these topics, but the goal here today is that if you’re coming to these topics without any background or you just want the [TLDR](https://dictionary.cambridge.org/us/dictionary/english/tldr), this is the place for you
  - So as such, if you want to learn more, check out the show notes both here and elsewhere
- Before we jump into this, Peter adds, “*I want to thank everybody for being a part of The Drive. Whether this is your first episode or your 300th, it is an absolute honor to be learning in front of you, and that’s exactly how I feel about this.*”

## Defining the categories of “proven, promising, fuzzy, noise, and nonsense” [3:15]

**Did you ever think we would get to episode 300 when we started recording the first few 7 years ago?**

- Peter asks, “*Was it 7 years ago or 6 years ago?*”
- It launched in June 2018, but we were recording previous because the original episodes were part of Peter’s research for his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZXv42gm3e5yZwOVrYDOggEQPnB-0MJD179kN9LgnXOsQ-B4fKurPREA5YpaJiCAfbvjOiFAeeTThG6YgSt5QRI_qlrxDCRap9IIK8zSVcS8WPoj-eBfRgd2BbYWojBJrWHvN2csTmmvh7xnDbQMKdVLeE1zXd6gnCt8N9ir99Rv0bFq965QkmPMVE0cShZFWmOAqcrLdgQOWhKTpKrKUDwU.3Qb0leUEWM92K0xvK3liUnVEYEoM7PQV7dW0RD8zbkc&qid=1710265017&sr=8-1)
  - So we started having some of these discussions in 2017
- Peter never really thought about it
  - To him it was binary
  - We started it as a 12-part series and thought it was going to be either uninteresting/ unhelpful/useless (in which it dies) or it was going to be potentially interesting/ valuable (and we keep doing it)
  - Once we hit that binary spot after 3 months and decided to keep doing it, he never really thought of the milestones
- What we like to do for every hundred episodes is do a special episode, something a little different, and release it to everybody
  - It’s shot as an AMA, but just a little bit of a different style
- When we were thinking of how we wanted to do this one, we thought of a recent [interview](https://www.menshealth.com/fitness/a43137717/peter-attia-outlive-exercise-longevity/) Peter did, which was structured in a way we liked
  - He gave his opinion on various drugs, supplements, behaviors, interventions, and put them in the following **categories**: proven, promising, fuzzy, noise, nonsense
  - We thought it was a cool way to go through and talk about some of these different things in a little detail and categorize them so people could understand how he thinks about them, how he applies them to his life and his patients
- A lot of these topics, are things that we’ve covered in various podcasts, newsletters, and we’ll link to those [see the *selected links* section at the end]
- The goal here isn’t to be super in depth, go through all these studies, all this background research
  - We’ll link to those in the show notes for anyone who is interested
- This is going to be more of a conversation where a patient comes to Peter and asks about something

**We use the terms “proven, promising, fuzzy, noise, and nonsense” as heuristics, but what does Peter really mean by those things?**

***To be clear (and people have heard him say this before): in biology there is no such thing as proof***

- This is not physics or mathematics or even physics
- In biology it’s all probability
  - When we say **“proven”**, what we’re really saying is what we’re talking about has such well-established data that the probability that it is untrue is so small that it would be foolish to not act on it
- Conversely, **“promising”** says the claim looks really good
  - There are a lot of data supporting it, but there’s something that’s missing from a data perspective
    - Either there isn’t just quite enough human data or there just isn’t quite enough [RCT](https://en.wikipedia.org/wiki/Randomized_controlled_trial) data or there’s some slight thing that’s missing that would keep you from saying, this is effectively proven
- **“Fuzzy”** is shorthand for there are some data around this claim, but they might be the best data
  - The data might be inconsistent, they might be contradictory
    - Not just one study is contradicting another study, but it’s like there’s real contradictions here and therefore we clearly need to do more before we could elevate this
- **“Noise”** is an interesting category, and it largely says that the data out there today are not of sufficient quality to make a judgment, but there might be something compelling that could move this in the other direction
  - For example, there might be very compelling mechanistic data
  - There might be a very compelling biochemical story around an idea, but the data have just been too small, too incomplete, to even elevate it up to fuzzy
  - And by the way, noise can quickly turn into nonsense when you shine enough light on it
- **“Nonsense”** basically says, “*No, actually this has been studied and it’s bunk.*”
  - We really have a high degree of confidence in saying that there is nothing there that should be paid attention to
  - And that doesn’t necessarily mean it’s harmful, but it means that this is not doing what people say it is doing

***All of that takes a long time to explain, so Peter doesn’t want to have to explain it every time, but he thinks explaining it upfront hopefully gives people a sense of where we are***

- With each example, we’ll provide enough detail to rationalize that position (hopefully)

**The beauty of science is that as new evidence comes out, Peter is happy to change his opinion on what he thinks about things**

- Let’s say we do this in another hundred episodes, then what we’re going to talk about with new evidence can easily move up or down the chain
  - So it’s not like this is how it is and this is how it will be
- And if we did this a hundred episodes ago, Peter can even look at this list and tell you things he would’ve said different 100 episodes ago
- He would be foolish to suggest that 100 episodes from now, if we come back and revisit this list, he would have the exact same things to say about it
  - That’s very unlikely

## Rapamycin [9:30]

- This includes rapamycin, metformin, NAD, and resveratrol

**Peter’s definition of a geroprotective drug and how he thinks about that**

- Geroprotection really talks more broadly about mechanisms that target hallmarks of aging

***A geroprotective drug would be a drug or a molecule that you’re taking not because it necessarily provides benefit in 1 arena against 1 chronic disease or 1 symptom, but rather because you believe it is fundamentally altering the biology of aging***

- And as such, taking this drug moves things in your favor, and that should mean that you would live longer taking this drug
  - That’s a very high bar
  - There are lots of drugs that are really effective at doing things that wouldn’t quite rise to the level of being geroprotective

**What category do you put rapamycin in?**

***Peter puts rapamycin in the promising category, but clearly it’s not proven***

- We’ve covered rapamycin so much in other podcasts, and this podcast is in no way meant to displace or be a substitute for those things [see the *selected links* section at the end]
- At a high level, [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is a substance that was discovered from a bacteria discovered on Easter Island in the mid-sixties
  - The bacteria was [*Streptomyces hygroscopicus*](https://en.wikipedia.org/wiki/Streptomyces_hygroscopicus), which at the time was a very novel organism that had never been discovered anywhere else
  - And it secreted this chemical that was named rapamycin to honor the island where it was discovered, [Rapa Nui](https://en.wikipedia.org/wiki/Easter_Island)
- This molecule was found to be a very potent antifungal and made it a very logical choice for a bacteria to have evolved to produce it
  - Bacteria is trying to fight a fungi by inhibiting them through this molecule
- The first thought was, “*Hey, this might be the next cure for athlete’s foot*.”
- That drug, which almost died a thousand deaths due to lack of interest, finally was championed through a guy named [Suren Sehgal](https://journals.lww.com/indianjcancer/Fulltext/2017/54040/Surendra_Nath_Sehgal__A_pioneer_in_rapamycin.24.aspx) (who has since passed away)
  - Suren single-handedly figured out utility for this drug that ultimately put it on the map as a drug with clinical application in organ transplantation as an immune suppressant
- In 1999, the FDA approves this drug for solid organ transplantation, and it spends the next decade in relative obscurity
- When Peter was in his residency, rapamycin was used amongst a cocktail of other drugs for patients who had received heart transplants, kidney transplants, and liver transplants
- Fast-forward to 2009, and a very well-done [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) is published as part of the [Interventions Testing Program (ITP)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) that looked at the use of rapamycin in a very well-documented strain of mice that are far more representative of what happens in biology than the typical strain of mice that are used in a clinical research setting
  - That study showed more convincingly than any other study in the ITP history that rapamycin extended life in male mice, in female mice, and most importantly, when initiated very late in life (a period of time in which no other drug had ever been able to extend life)
- This was replicated many, many times in the ITP and elsewhere
- It was also replicated in other model systems, meaning it wasn’t just replicated again in mammals
- People went back and asked the question, how does this drug rapamycin (which inhibits [mTOR),](https://en.wikipedia.org/wiki/MTOR) how does it work in yeast, in fruit flies, in worms
  - This constitutes about a billion years of evolution?

***It turns out that rapamycin always seems to work***

**It’s for all of those reasons that Peter says, “*****Wow, this is really promising,*****” but why can he not say this is proven?**

- We don’t yet have sufficient evidence in the organism of interest, or the species of interest (which is us)
- And the reason for that is that while there have been some interesting studies done in human, there are clearly short-term studies that demonstrate that the differential dosing pattern of rapamycin can actually produce immune augmentation and immune enhancement rather than immune suppression
  - In a previous podcast [[episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)] we discussed work by [Lloyd Klipstein](https://srfcure.org/lloyd-klickstein/) and [Joan Manic](https://milkeninstitute.org/events/fhs19/speakers/39958)
- That doesn’t quite translate to the question that many of us want to know the answer to, which is, “*Hey, if I take rapamycin intermittently, as demonstrated by these shorter human clinical trials, will that translate to not just better immune function but a longer life?*”

***Absent really good biomarkers for some of these hallmarks of aging, we still have a ways to go before we could say the following: rapamycin is geroprotective towards humans, and taking rapamycin according to Protocol X will add years to human life, and presumably improve health span***

- That’s an enormous claim where Peter thinks a lot of work still needs to be done
- Some of that work needs to be done in other animal models, such as what [Matt Kaeberlein](https://mkaeberlein.com/) is doing in the [Dog Aging Project](https://dogagingproject.org/)
- Some of that work actually is going to need to be done in humans using biomarkers that have yet to be developed, that will be substitutes for some of these more important cellular markers of aging

**Even though Peter takes rapamycin, that doesn’t mean he thinks everyone should go out and blindly take it**

- Very few of Peter’s patients are taking it (<10%)
- The reason for that quite simply is unless a patient is willing to go down the rabbit hole with him on understanding this and understanding the risks and probabilities and the uncertainty, Peter just doesn’t view this as something that is responsible
- Peter knows that there were many physicians out there who are giving out rapamycin like it’s Tic-Tacs and Chiclets, and the truth of it is we’re not seeing a lot of horrible things happening

***So clearly in the short run, that doesn’t appear to be a problem, but it’s irresponsible to represent that we know that that’s going to lengthen life***

- Peter has been taking this drug for the past 6 years, and yet this is the reason for his hesitation in giving it to anybody who walks in the door

## Metformin [17:00]

***Peter would place*** [***metformin***](https://en.wikipedia.org/wiki/Metformin) ***in the fuzzy category***

- A hundred episodes ago, he would’ve put this in the *promising* category
- The podcast with [Andrew Huberman](https://med.stanford.edu/profiles/andrew-huberman#bio) last year [[episode #270](https://peterattiamd.com/andrewhuberman2/)] was a journal club where we talked about what Peter believes are the 2 most important large epidemiologic papers that are trying to address this question indirectly
  - The first [study](https://pubmed.ncbi.nlm.nih.gov/25041462/) was done in 2014
  - The second [study](https://pubmed.ncbi.nlm.nih.gov/36287641/) was done in 2022
  - These studies represent the bookends of an observation that creates a lot of interest [about metformin]
    - This is a great example of where epidemiology is very helpful

**In 2014,** [**Banister**](https://uk.linkedin.com/in/bannisterca) **et al** [**published**](https://pubmed.ncbi.nlm.nih.gov/25041462/) **something that at the time was almost impossible to believe**

- Peter remembers getting an embargoed copy before it came out, and just really being shocked
- The study at the surface looked at people who had type 2 diabetes who were taking metformin, and people who did not have type 2 diabetes and who were obviously not taking metformin
- It asked the question: who had a lower all cause mortality rate?
  - We know that people with type 2 diabetes are going to have their lives truncated by an average of 6-7 years relative to someone without type 2 diabetes
  - So you wouldn’t think that the addition of metformin to somebody with type 2 diabetes would materially affect that
  - Maybe it would close that gap from 6.5 years to 4 years or something like that
- What the study found was that people taking metformin with type 2 diabetes actually lived slightly *longer* than the people who did not

***There was about a 15% reduction in all cause mortality over a three-year follow-up period***

- This was done in an enormous population using a UK Biobank dataset
- This more than any other paper, set the stage for the excitement around metformin as a geroprotective compound
- What’s clear is that the diabetics taking metformin still had inferior glycemic control to the non-diabetics
- In other words, if they’re living longer, it’s not because they have better glycemic control
  - It would seem to be that they’re better because of something else that metformin is doing outside of managing presumably hepatic glucose output
- [Nir Barzilai](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) has been on the podcast twice [episodes [#204](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) & [#35](https://peterattiamd.com/nirbarzilai/)], and people who are interested in this should go back and listen to those podcasts because Nir has argued that indeed metformin is geroprotective and that there are many benefits to metformin that completely transcend its properties within the liver for glycemic control
  - But Peter has become *less convinced* of that
- Peter talks in the [podcast](https://peterattiamd.com/andrewhuberman2/) with Andrew about holes in the Banister study that center around methodology
  - Something called **informative censoring,** where the patients who were in the metformin diabetes arm were censored out of the analysis that demonstrated a reduced mortality if they were lost to follow-up or if they had a medication change
    - Usually, a medication change on someone who’s only taking metformin is meaning that the disease is progressing, so you’re adding another medication
    - The problem with that is: you realize that you were censoring out people who were sicker and you were actually selecting for the healthiest possible people, not to mention the fact that you’re also *not* doing this in a randomized fashion

**The follow-up** [**study**](https://pubmed.ncbi.nlm.nih.gov/36287641/) **(done by** [**Keyes**](https://portal.findresearcher.sdu.dk/en/persons/matthew-thomas-keys) **et al in 2022) basically sought to improve on the methodology of the Banister paper**

- It did something quite clever, which is it repeated the analysis using a different patient cohort (a Danish patient population cohort)
- It set up 2 studies within the study: 1 very similar to what the Banister experiment was, and then 1 using a set of twins who differed only in that 1 twin had diabetes and 1 twin didn’t
  - That’s a clever design, and it’s hard to do
- They looked at half a million people, but they were still able to find roughly a thousand in each group of the twin and non-twin discordance with respect to type 2 diabetes

***They actually found the opposite: they found exactly what you would expect to find, which is whether you were talking about identical twins, fraternal twins, unrelated people, if you had type 2 diabetes, even if you were on metformin, your risk of mortality was significantly higher***

- It varied anywhere from 33% higher to 80% higher depending on the covariate analysis and the cohort that was being looked at
- This was much more consistent with what one would expect

*This is a better analysis for several reasons*

- What’s most interesting: they went and did an informative censoring analysis to see if indeed informative censoring was exclusively responsible for the results in the Banister paper, and it turned out it wasn’t
  - In other words, even when they repeated that methodology, they still produced the finding you would expect

**The other reason Peter would continue to keep metformin in a** ***fuzzy*** **category (as opposed to a** ***promising*** **category) is that metformin has failed in the ITP**

- Remember, *fuzzy* doesn’t mean it doesn’t work
- [Rich Miller](https://www.richmillerlab.com/biog) talked about the ITP in detail in 2 podcasts [episodes [#281](https://peterattiamd.com/richardmiller2/) & [#148](https://peterattiamd.com/richardmiller/)]
  - Why the ITPs are such impressive studies
  - Why so few molecules have succeeded in the ITP, but metformin is not one of them
- The only time metformin has ever been positive in an ITP (to Peter’s recollection) was when it was combined with rapamycin
  - Metformin *alone did not succeed*, whereas other drugs such as canagliflozin, acarbose, rapamycin have succeeded
  - Peter doesn’t want to go on too much further because this content exists elsewhere, and he just wants to really focus people on the high level

***Peter’s view today is that metformin is in the fuzzy category***

**One other thing, there is a study that is eventually getting funded: the** [**TAME study**](https://www.afar.org/tame-trial)

- Peter doesn’t know if it’s began enrollment yet
- The TAME study is going to attempt to answer this question in humans by studying disease onset in susceptible but otherwise healthy individuals

***And that’s why Peter thinks it’s safe to say that whether it’s episode 400 or episode 500, we are definitely going to be talking about metformin again***

## NAD and its precursors [24:45]

**How would you put NAD into a category?**

***This NAD stuff is noise at the moment***

- When we talk about [NAD](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide), we’re really talking about multiple things
  - We’re talking about NAD itself
  - But Peter is also speaking a little bit more broadly about precursors because NAD can’t be taken orally
    - It could be given intravenously when there are lots of clinics out there that do that
    - But from a practical standpoint, we tend to look at things that you can take orally, so we really tend to be talking about [NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside) and [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide), which are oral precursors that become converted into NAD
- Just to provide just a touch of context: NAD was discovered more than a hundred years ago, and over time, people have come to understand it’s a very important signaling molecule
  - It’s a very important part of cellular metabolism
  - Also, it declines with age

***So now you have this thing that’s super interesting and super relevant and completely ubiquitous, and as we age, it goes down***

- Understandably, in the early 2000s, it became a very high interest topic

**It further became of interest when it became linked to something called** [**sirtuins**](https://en.wikipedia.org/wiki/Sirtuin)

- Sirtuins are proteins that require NAD to deacetylase lysine residues
  - Which is just fancy chemical talk for: it changes the modification of an amino acid
- This is something that occurs so much and is so important to maintaining **DNA integrity** and managing **oxidative stress** that basically there were 2 hypotheses broadly speaking
- 1 – One hypothesis is the reason NAD levels decline with age is because DNA damage goes up with age (we know that that’s true)
  - Are those two causally related?
  - Is the rise in DNA damage with age driving an increase in NAD utilization and that’s why NAD is going down?
- 2 – Or are these uncoupled?
  - Is DNA damage going up with age, which it is, and is NAD abundance going down with age for a separate reason and oh, if we only had more NAD, we could offset more DNA damage?

***It’s safe to say we don’t yet know the answer to that***

- Nevertheless, a cottage industry around NAD has come up which says, “*Look, we know the answer to this, or at least we’re going to postulate that the answer is, of course NAD is going down with age. Whether or not that’s causal or not, giving more NAD is going to be a better thing.*”
- What does the data have to say?
  - This is an area where there is a remarkably booming industry around the administration of NAD and its precursors

***It’s actually surprising how little data is out there***

**The most promising data**

- Remember, Peter thinks, “*This NAD stuff is* ***noise*** *at the moment. I’m putting this in a category even below fuzzy, but to be clear, I’m not putting it in the nonsense category.*”
  - What that means is there may still be clinical scenarios under which this makes sense, even if it is not geroprotective (a very important distinction)
- There are a couple of studies in neurodegenerative disease (one in [ALS](https://pubmed.ncbi.nlm.nih.gov/30668199/), one in [Parkinson’s disease](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(22)00045-6)) that are both so small
  - Peter doesn’t want to be disparaging to the studies, but they’re not amazing studies
  - They’re reasonable first attempts at looking that maybe there’s something there and maybe in these scenarios there is a benefit
- Again, we’re asking this through the lens of geroprotection, and we’re really asking the question in this context of, “*Hey, if I take a bunch of NAD, or a bunch of NAD precursors such as NR and NMN, am I going to live longer or even live significantly better?*”

***The answer to that question is noise***

**The** [**ALS study**](https://pubmed.ncbi.nlm.nih.gov/30668199/) **gave patients pretty high dose of a combination drug of** [**nicotinamide riboside (NR)**](https://en.wikipedia.org/wiki/Nicotinamide_riboside)**, and** [**pterostilbene**](https://en.wikipedia.org/wiki/Pterostilbene) **for 4 months, and then it followed symptoms of ALS on a functional scale**

- Unfortunately for anybody who has known a patient with [ALS](https://en.wikipedia.org/wiki/ALS) (or a family member), it’s in the top 3 most debilitating diseases in the history of our species
  - Unfortunately there is no cure, and the end is just a very tragic end
- What this study was basically asking is, “*Look, can we delay this in any way, shape or form?*”
  - The answer appeared to be yes
  - This compound of nicotinamide and pterostilbene actually delayed progression by a short period of time for these patients
    - On one of the functional scales of progression
- This was a very small, phase I study
  - In a [phase I study](https://en.wikipedia.org/wiki/Phases_of_clinical_research), first and foremost, you’re making sure there’s no toxicity (which there wasn’t)
- Peter thinks a phase II study is ongoing
  - A phase II study is significantly larger, has robust endpoints, and therefore can shed light on this question
- Let’s be clear, if there is a compound out there that can keep a patient off a ventilator longer when they have ALS or can prevent secretion issues longer or respiratory distress longer, by all means, that’s a very important thing to know

**The other** [**study**](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(22)00045-6) **was also a very small study that was done in 20 patients with** [**Parkinson’s disease (PD)**](https://en.wikipedia.org/wiki/Parkinson%27s_disease)

- 10 were put on [nicotinamide riboside](https://en.wikipedia.org/wiki/Nicotinamide_riboside), 10 on a placebo for 4 weeks
- It saw some change in 1 of the movement disorder rating scales that’s used to subjectively quantify movement in patients with PD
  - But there’s a bit of a catch because there was a confounder in that some of those patients were closer in their last dose to [levodopa](https://en.wikipedia.org/wiki/L-DOPA) (which is a medication that in the early stages of the disease is quite effective at improving movement)
- It was not a very well-done study, and the most charitable thing one could say about that study is that it maybe suggests that there’s something they’re worth looking at
  - Peter doesn’t think that that would even rise to the level of being as compelling as the standard therapies that are used for patients with PD

**There’s one other** [**study**](https://alz-journals.onlinelibrary.wiley.com/doi/10.1002/alz.044746) **that looked at MCI (mild cognitive impairment) and NAD use**

- As Peter recalls, it was studying some aspects of memory and physical function
- It showed some improvements in physical function (which would not be the primary concern for MCI), but it did *not* show any improvement in cognitive impact
- It might mean that there is an improvement in cognitive impact, but not over such a short timeframe
  - Because it was a Phase I study, it was too small to actually see a signal
  - It wasn’t powered to see a signal (which is not always the case in a Phase I)

***Peter thinks that the evidence that NAD and its precursors is geroprotective (meaning we are going to take a bunch of people who don’t have disease and we’re going to make them live longer) is a very, very low probability but not zero***

- He thinks the probability that we’re not going to be talking about this one in another 100 episodes is pretty low

**In the spirit of, “*****How much do I believe in this?*****”**

- Peter doesn’t take these compounds
  - He doesn’t take NAD infusions, NR, or NMN
- It’s certainly not because there isn’t an abundance of those things out there, but this tells you his level of confidence in this

## Resveratrol [33:00]

**The final geroprotective drug that we get asked about a lot is resveratrol. Where would you rank that, and how do you think about that compared to the three we’ve talked about so far?**

- Peter was really surprised when the team sent him the list with resveratrol on it
  - Because the implication is that it had been asked enough in that survey we put out there that people wanted to hear about it
  - All he has to say is, “*Wow. I’m amazed people are still talking about resveratrol. This is absolute nonsense*.”

***I’m just saying we’re going to put this in the nonsense category, and we never need to talk about this again***

- In other words, there’s not just an absence of evidence; there’s actually evidence of absence here
- [Resveratrol](https://en.wikipedia.org/wiki/Resveratrol) is a [phenol](https://en.wikipedia.org/wiki/Naturally_occurring_phenols), it’s a chemical that activates [sirtuins](https://en.wikipedia.org/wiki/Sirtuin)
- Understandably, in all the early 2000s hoopla around sirtuins, the view was, “*Oh my god, sirtuins are good. They’re repairing DNA damage. Resveratrol is an activator of sirtuins. That’s got to be good. Away we go*.”
- A landmark [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) in 2006 garnered an unbelievable amount of attention
  - The attention was just as much from the fact that in minuscule amounts resveratrol is found in red wine
  - It wasn’t just that, “*Oh, we have another molecule that in some obscure mouse model maybe seems to extend life*.”
  - It was about this molecule at about 1/100th the level is found in red wine
  - On a serious level, is this an explanation for the French paradox?
  - On a clickbait level does this mean we should just be drinking as much wine as possible?
    - That’s the only explanation Peter has for why this story gathered traction and why it continues to this day to cloud the judgment of folks

**In the first episode with** [**Rich Miller**](https://www.richmillerlab.com/biog) **[**[**episode #148**](https://peterattiamd.com/richardmiller/)**], the** [**2006 mouse resveratrol study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) **was at best misinterpreted**

- There was indeed a longevity benefit, but it’s a very obscure model
- It was a mouse model where the mice were fed a diet of 60% coconut oil
  - Consider that mice are herbivores and wouldn’t be eating coconut oil or that much fat
- You have these mice on a 60% coconut oil diet and the cause of death was so much fat accumulation in the liver that the liver expanded into the hemithorax and collapsed their lungs
  - Again, usually when we do experiments with mice, they die based on their genetic predilection to die of cancer
  - We’re typically trying to ask the question, “*Hey, in the case of rapamycin, you give rapamycin to these mice, they get less cancer than these mice*.”

***Here we’re force-feeding them coconut oil to turn their livers into big blobs of fat that expand into their chest and compress their lungs; and it turned out that under those conditions, there was a longer time to death (on average median lifespan) if they were on resveratrol than if they were not***

- By the way, there was *no difference* in maximal lifespan
  - You didn’t shift the curve of mortality for the top 10% of mice
  - You just shifted it for the median mice
- Somehow that generated all of the interest in this drug, and very few people paid attention when the ITP came along and said, “*We’re going to* [*study*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) *this really, really rigorously. We’re going to study this in mice that are not chromogenic mutants and we’re not going to force-feed them fat. We’re going to give them normal mouse food and watch them die of normal mouse deaths.*”
  - And it made no difference
- They gave them 300 mg of resveratrol per kilo of food (which is 300 PPM), and nothing happened
- Just for comparison’s sake, wine is less than 2 PPM (parts per million) of resveratrol
- The folks who say resveratrol works have criticized that study saying the bioavailability is low, and therefore you need much, much, much more than the 300 PPM that was given in that study
  - But again, that was a concern and a criticism that was only voiced after the study
  - The proponents of resveratrol were involved in that study and they signed off (they’re on the paper); this was their view

***Peter has a hard time believing that there is any value in resveratrol, and that’s why he doesn’t take it independent of the fact that it’s still a ubiquitous compound that’s found everywhere***

## The importance of VO2 max, muscle mass, and muscular strength for lifespan [38:15]

**Start with a few anchoring things that you talk about often just so people can understand where you put the importance of VO****2** **max and muscle mass on this scale**

*Where would you rank them on the scale that we’re using today?*

***Those are the 2 closest things you could put to proven***

- They would be right up there with smoking cessation and blood pressure management
- We really think of muscle mass as a proxy for strength (which is the better predictor)

***You can’t prove anything in biology, but the probability that having a high VO******2*** ***max, high muscle mass, and high muscle strength are going to increase the length of your life and improve the quality of your life, that probability is so high that to act in disregard of that is irresponsible***

- There’s very little on this topic Peter has not expounded on both on this podcast and on others and social media

> “*This is a topic I can’t say enough about because the magnitude of the effects is so much greater than everything else*.”‒ Peter Attia

- You can see why Peter gets animated when people ask him about resveratrol and sirtuin activators and NAD and NR and they’re *not exercising*
  - Or they’re exercising, but their exercise is totally JV
  - It’s like, “*Wait a minute, you are picking up pennies in front of a steam train fighting over basis points of theoretical possible benefits of something, and you’re completely missing this other thing over here.*”
- You’ve heard Peter tease folks (including patients sometime) and say, “*Look, once you’ve got your VO**2* *max here and your muscle mass here and your strength here, then we can talk about the 37 supplements that you’re interested in taking.*”
- It’s helpful for people to understand where these things rated and how they compare to others
- Peter hit a really important point: if you’re worried about taking all these geroprotective drugs and you want to take them, that’s your prerogative, but if you think that’s going to save you from exercising, needing to have muscle strength, needing to have a higher VO2 max ‒ maybe that’s not the best risk mitigation strategy
  - Look at this as how you mitigate the risk of not being capable of having a longer lifespan and even more importantly, a better healthspan
- Peter often says, “*Even if exercise had no effect on lifespan (so it was lifespan neutral or be more dramatic, even if exercise slightly shortened your lifespan by a year), it’s undoubtedly worth it for the improvement in the quality of your life, both physically and cognitively and in many cases emotionally.*”

**Peter points out why VO****2** **max, muscle mass and strength stand out as the greatest predictors of lifespan**

- These stand out as far greater predictors of lifespan than cholesterol levels, blood pressure, blood glucose, all of these things that clearly relate to how fast you’re going to live or die
- Even smoking is a worse predictor of lifespan than your fitness level

***This speaks to how potent exercise is as a tool to impact the cellular processes of aging, but it also speaks to the fact that you can’t cram for the test when it comes to these tests***

- If a person has a high VO2 max, they have been doing a lot of exercising for a long time
  - It doesn’t have to mean their whole life, but they didn’t just decide a week ago
  - If your VO2 max is in the top 2 or 3% of your age group, you’ve been at this for a while

***Therefore, the VO******2*** ***max measurement is really an integration of work that you have done; and the same is true for muscle mass and more importantly for muscle strength***

**Things like why does grip strength always come up as this incredible predictor of mortality?**

- Is it because being able to squeeze things with your hand is especially important?
  - Yeah, there’s probably some edge cases
- What does it imply if you have high grip strength?
  - You didn’t just wake up and have high grip strength, by definition, you have been lifting and carrying heavy things
  - You have been using your hands aggressively, manipulating things, carrying, squeezing, all of these things, pulling, and it’s that work that is being captured through the integral of the final metric or the test

**Is it ever too late to start exercising?**

- Maybe you’re in the older category where you don’t want to get hurt
- We will have a special episode that will be coming out in a few weeks dedicated to this topic

## Blood flow restriction (BFR) training [44:00]

- Blood flow restriction (BFR) is used when people are dealing with injuries or don’t want to lift heavy weights
- We got a lot of questions about this after the podcast with [Jeremy Loenneke](https://hesrm.olemiss.edu/people/jeremy-paul-loenneke/) [[episode #179](https://peterattiamd.com/jeremyloenneke/)]

**Where would you rank blood flow restriction in this ranking system?**

***Peter would put BFR in the promising category***

**Is the question: Does using BFR and higher reps, lower load weights, produce superior results to the same reps, the same weights without BFR?**

- That is clearly the case

***It’s promising/ proven***

**To back up for those who didn’t hear the podcast (or who need a refresher)**

- This became a topic of interest not that long ago (maybe 25 years ago) when it was demonstrated that if you applied a tourniquet around a limb as it was exercising, you would see superior improvements in strength and muscle size relative to an untourniqueted limb
  - Provided they were both doing the same amount of work
- The question is: Why?
- Anybody who’s done BFR can tell you it’s not very comfortable
- When you impair venous return slightly (and that’s really the goal of blood flow restriction … It’s not complete occlusion, it’s partial occlusion), you are allowing the accumulation of metabolites at a much higher rate
  - More lactic acid is pooling, more metabolites of metabolism beyond that
- The thought is that something about that is creating more of a stress signal than would otherwise be present absent the tourniquet
- An immediate use case became around injury: we use far lighter weights, but still produce a profound amount of discomfort
- Using **Peter as an example**, when he had shoulder surgery, he wanted to be able to still exercise that arm, but for months after surgery, he could not carry a barbell that was the same weight that he would’ve carried before
  - It was still too much pressure on the humerus in its newly-repaired joint around the labrum
- What if he used a third of the weight that he might’ve previously used?
  - He’d do a lot more reps, but he’ll create this blood flow restriction around it, and he will experience a much higher training effect
    - The data have largely borne this out
- What makes this type of research really elegant, is every patient can be their own control, because you’re doing limb isolation
  - It’s a little goofy for the patient because you’re going to have one leg that might get bigger or stronger than the other, but every patient can be their own control
- Jeremy Loenneke did a large [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/21922259/) in 2011 that showed that if you look at low load resistance training in BFR and without BFR

***BFR clearly results in greater muscle strength and hypertrophy improvements***

- It’s not subtle; these are really pretty big effects
- Peter adds, “*There’s still a question that I don’t think we know the answer to, which is how does BFR training at higher reps lower weight compared to non-BFR training with higher weight and presumably lower reps?*”
  - That’s a much harder head-to-head to design because the question is how do you design the protocol in each, because now you’ve broken one of the constants that have been preserved across all of these studies
- That the answer there is still unknown

**As such, Peter wouldn’t recommend that somebody exclusively rely on BFR**

- First of all, it’s not that comfortable and you can’t do it for everything
  - It’s very limb-centric
- Even if you were just to talk about restricting it to how you train your arms and your legs, there are lots of scenarios where using BFR doesn’t make sense
- Peter really likes to use BFR as finishers
  - He’ll do some sort of upper body finishers and lower body finishers (on upper body and lower body days respectively)
  - But it’s not really the bulk of what he’s doing

***This is disproportionately useful in the case and setting of a person who is rehabbing something***

- Peter uses it liberally with patients, trying to get them moving immediately post-surgery
  - Even just using their own body weight
  - For example, a patient that’s had knee surgery, the minute we get permission from the surgeon, we’ve got them doing leg extensions with just the weight of their leg, but doing it with a BFR cuff
    - There’s actually a training effect in the quads, but without overloading the knee

**What brand BFR cuff do you use?**

- Peter has no affiliation with them
  - He doesn’t get paid by them or anything
  - It’s just one he’s tried a lot and found real enjoyment with

***A brand called*** [***KAATSU***](https://kaatsu.com/collections/all)

- Peter uses 2 different types of KAATSU devices, one is his go-to where he puts the armbands on and leg bands on, inflates to pressure, and then exercises
  - He apologies that he doesn’t remember the exact name (maybe it’s called the C3)
- They have another one that he likes, and it does what are called “passive cycles”
  - You use these during recovery
  - It does a 20-second inflate, hold, deflate, repeat
  - If Peter is sitting at the computer, he’s got this thing cycling on his arms or legs, and it just feels great
- There is a real art to this
  - There’s a clinical way that you want to be able to go about doing this, where it’s not just put a tourniquet on
    - Which is what Peter used to do and hope for the best because you have to make sure the pressure is such that you are still allowing both blood in and blood out
    - You’re just trying to blunt that somewhat

## Using stem cells to treat osteoarthritis or injury [51:30]

**What is your current thinking about stem cells?**

- It’s come up on a few podcasts with [Alton Barron](https://altonbarronmd.com/about/) [[episode #232](https://peterattiamd.com/altonbarron/)] and [Adam Cohen](https://adamcohenmd.com/about-adam-cohen-md-top-orthopedic-doctor-nyc) [[episode #264](https://peterattiamd.com/adamcohen/)] looking at the upper body, lower body

***This is an area that is really complicated, and Peter puts it “somewhere between noise and fuzzy”***

- He’s talking about this through one application: [osteoarthritis](https://en.wikipedia.org/wiki/Osteoarthritis)
  - Where it’s most talked about and most studied in animals
- He still finds it very plausible that there are arenas in which stem cells could be beneficial
- There are actually scenarios under which Peter would take stem cells if he had a certain injury
  - If he tore his rotator cuff and it was a marginal call as to whether it was surgical, then he would absolutely start with a stem cell injection
    - If it could mean avoiding surgery and waiting for a repair
- Peter would love nothing more than to see an actual randomized clinical trial that takes patients who have torn their rotator cuff
  - Again, let’s try to take people with comparable injuries and randomize them into 3 groups: stem cell injection, surgical repair, non-surgical repair, rehab
  - We could debate the merits of each of these approaches, but he would really love to see that provided there was a way to create a uniform protocol around what it means to get stem cells

***The lack of such a randomized clinical trial is what has been hampering this field***

**To be clear, the FDA does** ***not*** **authorize the use of stem cells**

- So all of this is existing either outside of the United States where it’s not regulated by the FDA or there’s some sort of gray areas where it can be done, but it’s obviously not covered by insurance or any of these other things
- If you’re presumably using, Peter’s not sure how much these protocols are using *autologous stem cells* versus the *stem cells of others*
- The total lack of consistency in what the actual agent is, the actual stem cell is a big part of what makes this very challenging
- Peter asks, “*Who do I trust?*”
  - It’s not like he can look at someone’s data and draw conclusions
  - You’re basically looking at a bunch of marketing material, not actual data.

**When we talk about** [**osteoarthritis**](https://en.wikipedia.org/wiki/Osteoarthritis)**, at least we have the advantage that there are canine models of osteoarthritis where they’ve looked at stem cells**

- They have mixed results
- Some of them have shown that dogs with osteoarthritis, when injected with stem cells do tend to improve their gait, do tend to see a reduction in lameness (partially assessed by gait, partially assessed by pain relief through medications)
- Other studies have found no benefits whatsoever
- It’s hard to tease out what that means
  - Does it mean that the methodologies are flawed and that in some of these studies, they’re not actually using the right stem cells?
  - What is the concentration of stem cells?
  - What’s the protocol? How many injections do you need?
  - All of this stuff is still unclear

**Again, stem cells is a very broad term**

- Are we talking about a pluripotent stem cell?
- Are we talking about a donor derived stem cell?
- Are we talking about a fetal derived stem cell?

> “*We have a cottage industry that is the absolute wild west.*”‒ Peter Attia

- Peter wishes there was greater financial incentive to study for what the answer is as opposed to just say, “*Yeah, we know the answer. It works*,” or “*We know the answer. This is a total sham. It shouldn’t be done*.”

***It’s very hard to have this above noise right now because of a total absence of data, not because there isn’t biological plausibility***

- There is biological plausibility, but it’s just there’s no data
- Peter is clearly am not going to call this nonsense, but this is not going to rise to the level of promising in his mind yet

## Fasting as a tool for longevity (and why Peter stopped his fasting protocol) [55:45]

**How do you think about long-term fasting as it relates to longevity?**

- Peter hates talking about nutrition even though he is knowledgeable on the subject

***Peter is going to call this fuzzy***

**This is an area where Peter has seen an enormous change in his point of view over the past 300 episodes**

- Disclosure: some people listening to this podcast might know of Peter’s [work](https://peterattiamd.com/zero/) in the fasting space
- For Peter, fasting has historically been a very important part of his thinking about how to live longer, how to use fasting as a geroprotective tool
- A little bit of historical context is relevant here
  - We spoke earlier about rapamycin, which stands alone in the pantheon of molecules as the only molecule that has universally extended life across all model systems of eukaryotes (which span 1 billion years of evolution)
    - That’s a big deal
  - But we shouldn’t forget that there is one non-drug intervention that has also done that: fasting or **caloric restriction** (and it did it long before rapamycin)

***So there’s clearly something magical going on with caloric restriction when it comes to elongating life***

**But the question is, can we extend that into humans?**

*Perhaps the more important question is, what would the fasting protocol be?*

- Peter [wrote](https://peterattiamd.com/wanna-know-what-keeps-me-up-at-night/) a piece on this a long time ago about: How long should you fast? To what extent should you fast, and how frequently should you repeat the fast?
  - Those are basically your 3 variables
  - And there are obviously so many combinations of those
  - You can do it for 1 day, 3, days, or 5 days
  - You could do it once a year, once a quarter, or once a month

***Even if you took reasonable spots, it quickly becomes impossible to test all of these, and so instead, what we’re left with is a cult of personalities where people tell you what they do***

- Peter has been guilty of that, although he hopes he has always been clear about saying, “*I have no clue if this is ‘right’.*”
- Peter was doing 7-10 days of water only fasting once a quarter
- And then 3 days once a month on the alternative
  - So 2 months, a short fast, and 1 month, a long fast; repeat
- What data could he point to for that protocol?
  - None. Absolutely none. He made it up
    - And was very transparently that he made that up

**Were things happening in his body from a cellular level that were beneficial?**

- Probably

*Did he have great biomarkers to show that?*

- No, because he was relying on very standard biomarkers
- Fortunately, his standard biomarkers are generally quite good, so it’s not like, “*Yes, your glucose is going to go down, your ketones go up, your insulin goes down a little bit*,” but those things are transient
- And by the way, a lot of things got really bad when you fasted: your thyroid function completely deteriorated, your androgen function completely deteriorated

**But what was really interesting is the thing we** ***couldn’t*** **measure: what was actually happening to those hallmarks of aging?**

- Were we improving at the cellular level, things like senescence, autophagy, all of those things?
  - We can’t measure those things, so we don’t know
- Peter had some rationale, extrapolating from mouse studies
  - So many hours of fasting in a mouse produces cellular changes that are incredibly beneficial to disease prevention
  - Given what we know about the relationship between mice fasting and human fasting, it should be that by about 5 days to experience some of those benefits
- Even if that were true, the question remains: how often do you need to do that?
  - No idea

**Why Peter stopped his fasting protocol**

- It came down to 2 things
- The most important was that he took a look at the bigger data of himself and realized that over the course of 3 years he had lost close to 20 lbs of muscle (it might have been 16 lbs)
  - It’s very difficult to gain back the lean muscle you keep losing
    - You lose a ton and you regain some of it

***Around 2021 he stopped fasting and focused on gaining back the 20 lbs of muscle he lost***

**Is fasting a viable tool for weight loss?**

- Yes, it’s one of the tools in the [CR/ DR/ TR](https://peterattiamd.com/my-nutritional-framework/) kit
- Peter is still a TR (time-restricted eating) guy for caloric restriction purposes
  - He drinks a coffee in the morning
  - He will have a protein shake in the morning that is very low in calories (120-150 calories)
  - He doesn’t eat a male until 2:00 in the afternoon
  - He has dinner at 6 or 7
  - He does this to manage total caloric intake, not because there’s some magical benefit to not having meals spread throughout the day

**Why is this fuzzy?**

- In many ways, this suffers the same problem in terms of getting into much more dispositive clinical trials
  - Which is, we’re clearly never going to do the experiment that asks people to undergo different fasting protocols for the entirety of their life to determine if indeed they live longer

***So we are going to have to come up with better proxies, meaningful biomarkers of the hallmarks of aging***

- If we can do that, then maybe we can start to get a sense of whether or not rapamycin and fasting should be important parts of our armamentarium as we think about ways to impact those hallmarks of aging

**You mentioned there were 2 things that caused you to change your mind [about fasting]. The first was muscle loss, what was the second?**

***The second one was more of a social issue***

- Peter happened to be traveling a lot during the time he was fasting
- It’s very easy for him to fast when he is away from home
- All of these fasts were done while he was in New York and lived in San Diego
  - So he didn’t have to be fasting around anybody
  - He was just fasting in his apartment alone
  - Even if he went out to dinner with friends, he would just drink soda water while they were eating dinner
- Once he stopped traveling it meant all those fasts were going to have to be done at home, and he didn’t want to do it
  - He didn’t want his kids to wonder why daddy is never eating

**Back to biomarkers to know if fasting is working. What would have to be true or what would have to change outside of that to cause you to start fasting again long-term?**

- Peter doesn’t know
- He would need to see something incredibly compelling in a higher order model
  - Maybe in a dog model or something like that
- This is a great example of where he thinks companion dogs are a great model to study things, because he thinks most people find binary fasting far easier than caloric restriction
  - And there’s already a lot of controversy around caloric restriction
- Peter has an entire chapter on this in [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZXv42gm3e5yZwOVrYDOggEQPnB-0MJD179kN9LgnXOsQ-B4fKurPREA5YpaJiCAfbvjOiFAeeTThG6YgSt5QRI_qlrxDCRap9IIK8zSVcS8WPoj-eBfRgd2BbYWojBJrWHvN2csTmmvh7xnDbQMKdVLeE1zXd6gnCt8N9ir99Rv0bFq965QkmPMVE0cShZFWmOAqcrLdgQOWhKTpKrKUDwU.3Qb0leUEWM92K0xvK3liUnVEYEoM7PQV7dW0RD8zbkc&qid=1710265017&sr=8-1) where he talks about the [Wisconsin/ NIA monkey studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/)
- But for most people, if you told them they just had to reduce calories by 25% for the rest of their life to live longer, most people would say, “*I don’t want to live longer. That’s torture.*”
- It’s actually easier to periodically do these big fasts
- Peter would like to see an experiment of that done in a better model than just mice

## The energy balance theory [1:06:30]

- Historically since the podcast started, we’ve had tons of guests on who have different opinions on this
- This is something that Peter has written about a lot

**How do you think about the energy balance theory right now as it relates to the ranking system?**

***Peter puts this right between promising and proven***

**To summarize the energy balance theory**

- Energy balance is determined solely by the caloric density of the foods consumed, less the energy expenditure
  - And that the net available caloric density of a food is its contribution to energy balance
- This is where Peter feels a little bit bad talking about this because he hasn’t been as diligent as maybe he should be in staying up on this world
  - Over the past decade, he’s largely not paid attention to it
  - Because in many ways, he’s seen what he believes is a reasonable answer
- For folks who don’t know part of the history here, Peter was once running an organization that funded research directly to try to answer this question
  - He went into that thinking the answer was going to be one thing, but actually very excited to see regardless
- That [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4962163/), while it had some flaws, actually came out and showed something else, which was if indeed isocaloric manipulations of macronutrients change energy expenditure, it’s not an enormous difference
- What does that mean in English?
  - If you give 2 people equally caloric diets that are radically different in macronutrients, do you have a significant difference in energy expenditure?
    - That’s what was being tested by that theory

***The evidence is much more clearly in favor of the fact that no, you do not [have a significant change in energy expenditure]***

*A couple of caveats*

- There are clearly differences in the **thermogenesis** of food
  - 1000 calories of protein, 1000 calories of fat, and 1000 calories of carbohydrates are going to have different processing amounts of energy that will result in different amounts of **net available energy**
- Furthermore, different types of foods are going to differentially impact **appetite**
- Therefore in a free living environment, this isn’t to say that macronutrients don’t matter, but what we’re really trying to tease out *is there truly a scenario under which a person who’s eating 3000 calories of a balanced diet can switch to 3000 calories of a ketogenic diet and have weight melt off them?*
  - Just because they’re on a ketogenic diet, they somehow magically start burning a lot more energy
  - Peter believes the answer to that question is *no*
    - He does not see any evidence to support that

***Peter thinks that if a person is on 3000 calories a day of a balanced diet and they switch over to what they believe is 3000 calories a day of a ketogenic diet and the weight starts pounding off them, they’re either moving more or eating less than they realize***

**How would you respond to people who maybe get frustrated at your ability to change your mind if new data comes out?**

- In general,there may be at times in science, a resentment if you do change your mind, and that leads to potentially people sticking with their beliefs maybe longer than they should
- First of all, this is news to Peter that people are upset about that
  - He would bet it’s not scientists who are upset
  - Any scientist who doesn’t do that needs to be questioned

> “*If you can’t change your mind in the presence of new data, I think by definition, you’re not a scientist. You’re an advocate.*”‒ Peter Attia

- Advocacy has its place, but not without science
- The only thing Peter would ask of those people that are upset with him is, “*What would you propose as the alternative?*”
- Is it vexing that Peter changes his mind on things
  - Yes, if it means that it impacts your belief about what is good to do and what is not good to do
- Look at the alternative: Peter is confronted with new data but ignores it?
  - Or he pays attention to it and lies about it?
  - How is this better than simply being uncomfortable with the fact that he used to believe this thing and now he doesn’t anymore?

## The idea that sugar is poison [1:12:00]

**Is sugar poison?**

- This is a very loaded question
- Peter would argue, is the premise of the question even logical?
  - What is a poison?
    - Poison is a word that speaks to a dose, speaks to a frequency, speaks to chronicity, acuteness, all of these things
- Broadly thinking, is something *chronically* a poison? Is it *acutely* a poison?

**Let’s start with something everybody has in their house: acetaminophen (Tylenol)**

- Is it a poison?
  - It doesn’t have a skeleton on the cover with bones through it, right?
  - It doesn’t look like the Drano you have under your sink that is clearly marked as a poison
- What happens if you took 20 grams (20x the dose)?
  - You would be dead of liver failure in 3 days if someone wasn’t able to pump your stomach in time or get you a liver transplant
  - So that sounds like a poison
  - That’s actually acutely quite toxic

**Is alcohol a poison?**

- It depends on the dose
- There are clearly doses at which alcohol is quite toxic (it’s neurotoxic)
- And there’s certainly a scenario where you have a glass of wine a few times a week and it would be almost impossible to measure a negative effect of that
- Peter says all of those things to anchor people in what we’re talking about

***The phrase sugar is poison is not helpful: it’s loaded, it’s emotional, it’s sort of nonsensical***

**What we should really be asking**

*What are the biochemical effects of sucrose or high fructose corn syrup (or fructose in general) at different doses and under different metabolic conditions?*

- This is an area where Peter’s view has changed quite a bit, and it’s changed because of the data

***He just doesn’t see the data to demonstrate that an isocaloric substitution of fructose for glucose is demonstrably worse for health outcomes if total energy intake is preserved***

**Now, does that mean that eating sugar in an unrestricted manner in a free living environment is of no consequence?**

- No, it doesn’t mean that at all
- And it certainly appears that in at least a susceptible individual, that a high consumption of fructose (and it seems even more clear in liquid fructose) can drive [appetitive](https://en.wikipedia.org/wiki/Appetite) behavior
  - To put that in English, if you’re drinking a lot of sugar, it makes you want to eat more calories
    - Now, we can debate how many calories, and Peter believes that these data have been misrepresented and overstated

***Peter thinks that in a free living environment, people will consume more energy if they have more access to sugar***

**Peter had this discussion on the podcast with** [**Rick Johnson**](https://drrichardjohnson.com/about/) **[**[**episode #194**](https://peterattiamd.com/rickjohnson2/)**] using one of the most robust** [**experiments**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137694/) **on this topic**

- To his recollection it was 9 months in mice (an eternity)
- Under isocaloric conditions, when these mice were fed, when their total calories were controlled and you had high fructose versus low fructose groups, you did *not* see a statistically significant difference in body weight (That’s a big deal)
- Now, would you see a statistically significant difference in metabolic parameters?
  - Peter thinks you might if the fructose dose gets high enough
- This comes back to something Peter said at the outset, “*The dose makes the poison.*”

**We don’t know yet what that does looks like as a function of the other parameters**

- For example, when Peter was a teenager, he trained 6 hours a day and never ran less than 8 miles in the morning, and there was no way he was eating fewer than 200 g of sugar a day
  - He would drink 2 L of orange juice as a snack
  - He didn’t eat bowls of cereal, he at them a box at a time
  - Was he unhealthy? No chance
  - He probably had 4% body fat

***The point is, the context matters***

- If he ate that much food today (nevermind sugar), he’d be dead

**Peter’s takeaway**: ***everything about this is problematic because people want to focus on just 1 macronutrient (in this case, fructose or sugar as a molecule), and we don’t want to focus on the overall dietary pattern that accompanies it***

- When Peter consumes **fructose**, it’s generally in the form of fruit
  - He doesn’t restrict his consumption of fruit (he eats it all the time)
  - He generally doesn’t drink calories outside of protein shakes
    - These are artificially sweetened with sucralose and things like that
    - If he drinks a carbonated beverage that’s sweet it’s a diet Dr. Pepper once or twice a month
    - Would the regular Dr. Pepper kill him? No, but he’s choosing diet because of his teeth

> “*What you’re hearing me kind of react to is not because I think sugar is poison. I think a high sugar diet is just a dietary pattern that is incongruent with eating the right kinds of foods that I generally want to eat anyway*.”‒ Peter Attia

**Give your quick 2×2 framework of metabolically healthy, unhealthy**

- Nick thinks this paints a bigger picture of why Peter doesn’t look at sugar as being toxic, but how he looks at it more holistically
- For metabolically unhealthy patients, who need to lose weight and need to increase their muscle mass, Peter might not be so liberal with sugar for them
- Peter adds, “*There’s definitely an area where I’m still actively trying to investigate this.*”

**We will do a podcast on this topic: Is there a unique role that fructose plays in the development of** [**NAFLD (non-alcoholic fatty liver disease)**](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)**?**

- NAFLD is running rampant right now in the world
- 1 hypothesis is that it’s not just energy imbalance (which is clearly associated with NAFLD)
  - In other words, you take a person with NAFLD and they lose 20 pounds, their fatty liver is going to get better no matter what

*But then the question is, should those people be restricting fructose?*

- And again, lots of great mechanistic data for why fructose rather than glucose would disproportionately play a role in the development of NAFLD
- There’s even more compelling evidence for why liquid fructose is potentially playing a greater role
- Peter hasn’t yet seen a compelling clinical trial that can that independent of weight loss, isocaloric substitution of fructose for glucose results in an *improvement* of NAFLD
- For his patients with NAFLD, he tells them not to drink alcohol and not to consume fructose (outside of mild amounts of fruit)
  - This is a recommendation for which they don’t have incredible evidence, but if nothing else, that change in behavior reduces caloric intake, which results in weight loss (what we care about)

**Peter’s 2×2 framework involves 3 questions**

- 1 – Is the person overnourished or undernourished?
  - That is determined by the total amount of body fat and visceral fat
- 2 – Are they adequately muscled or under-muscled?
  - This can be determined by looking at the [fat-free mass index](https://health.ucdavis.edu/sports-medicine/resources/dxa-info) or [appendicular lean mass index (ALM)](https://pubmed.ncbi.nlm.nih.gov/26071168/#:~:text=Appendicular%20lean%20mass%20(ALM)%2C,muscle%20mass%20in%20sarcopenia%20research.)
- 3 – Are they metabolically healthy or not

***Understanding the answer to those questions, you pretty quickly can come up with a point of view on how a person needs to train and how a person needs to eat and maybe even in some cases, how you want to tweak their macronutrients***

## The idea that sugar substitutes are dangerous [1:22:15]

**How do you think about the idea of sugar substitutes and if they are dangerous?**

- See one of our [premium newsletters](https://peterattiamd.com/sugar-substitutes/) on this topic
  - Peter thinks it’s one of our best premium  newsletters ever (it may be a bit long)
- Sugar substitutes have been around for a long time
- In the ‘70s and last 20 years there have been concerns around the toxicity of them (especially [aspartame](https://en.wikipedia.org/wiki/Aspartame) and [saccharin](https://en.wikipedia.org/wiki/Saccharin))

***If you want to talk toxicity, the doses of sugar substitutes [used in toxicity studies] are literally orders of magnitudes greater than what would be consumed by humans***

- Even though there were maybe flaws in some of those studies, even if you were to take them at face value, it’s hard to imagine

**The** [**rat study**](https://www.aei.org/articles/ruminations-on-a-rat-saccharin-and-human-risk/) **that got everybody worried about saccharin**

- The rats that developed tumors were being fed the equivalent of 800 diet sodas for every day of their life
  - That’s how much saccharin those rats were being fed to develop these liver tumors
- It’s a very slippery slope to then say, “*Oh, well then these things are poisonous*.”
  - By that logic, if you took 20x the dose of Tylenol, you’d be dead
    - And you’d be dead much quicker than you would die from this cancer
- Here we’re talking about 800 times the dose over the entire duration of a life
  - At that level (just to be glib) oxygen is toxic to people
    - We have 21% oxygen in the air that we’re breathing
    - If you are in a 100% oxygen environment indefinitely, the amount of free radicals you would develop would kill you

***Everything becomes toxic at some point***

**The aspartame data was a little less extreme**

- A [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1964906/) in 2007 looked at higher rates of cancer in rats that consumed pretty high amounts of aspartame from the day they were born right on to the duration of their life
  - They were still consuming the equivalent of 20 cans of diet soda every single day to get to some of those outcomes

**Is it possible that these things are cancer causing at normal doses?**

***It is possible, but Peter doesn’t think it’s that probable, and therefore when he thinks about sugar substitutes, he’s less concerned with the cancer stuff and more concerned with the metabolic stuff (the impact on gut health and those other things)***

**The 2 biggest areas to talk about with non-sugar sweeteners**

*What is the impact on body weight and what is the impact on glycemic control or metabolic health?*

- The 1st generation versions of these ([saccharin](https://en.wikipedia.org/wiki/Saccharin), [aspartame](https://en.wikipedia.org/wiki/Aspartame), [sucralose](https://en.wikipedia.org/wiki/Sucralose)) seem to have a slightly negative effect on those parameters when calories are controlled
- Conversely, the newer ones ([xylitol](https://en.wikipedia.org/wiki/Xylitol), [erythritol](https://en.wikipedia.org/wiki/Erythritol), [stevia](https://en.wikipedia.org/wiki/Stevia), and [allulose](https://en.wikipedia.org/wiki/Psicose)) appear to have less detrimental effects
  - Some of them that are not even what we would consider non-nutritive
  - Allulose may even have slightly beneficial effects on glycemic control due to [SGLT1](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_1) signaling, but it’s a little too soon to say that
- This now comes back to a heuristic, “*How do I behave around these things?*”
  - Peter is clearly consuming some of them
    - Even the cleanest protein drink has some amounts of these products in them
    - The ones Peter generally uses have sucralose in them
- Peter doesn’t usually drink diet sodas because he mostly drinks sparkling water
- He doesn’t add sweeteners to anything he consumes
  - If he’s drinking coffee, he puts a little cream in it
- He does chew gum with xylitol in it, and that’s more around some of the potential benefits of xylitol on the enamel of teeth

***Peter’s advice to people who are consuming lots of artificial sweeteners who are struggling with glycemic control, body weight or things like that is: substitute them out, but don’t substitute sugar in, just get rid of it period***

- For example, go from drinking diet Coke to drinking water, bubbly water
  - Not drinking Coke, because that’s probably a worse outcome if no other reason just from more calories coming in
- If you’re struggling on that front, getting rid of those things might matter

**The area where we are most interested in understanding things is what is the impact of these things on the gut, and how foreign are these things to the bacteria in our gut?**

- Are they being provided in a high enough quantity to even materially impact the guts?
- There are some animal studies that suggest that this is a big issue
- Peter thinks it’s a bit too soon to say that

## The debate on red meat and cancer [1:28:45]

**Does red meat give you cancer?**

- Peter begins by saying, “*This is going to sound bold, but* ***I would actually put this in the nonsense category***.*”*

- Which is not to say that a dietary pattern high in red meat could not play a role in the development of cancer, but that’s very different than the question
- If the question is, “*Does red meat cause cancer?*”
  - That’s not correct and there’s plenty of evidence that that is not correct

**If the question is, “*****Do people who eat a lot of red meat or do people who eat a lot of processed red meat have a higher risk of getting cancer?*****”**

***The answer to that question is yes, but it’s probably less because of the meat***

- Although in the case of certain processing, it may be the case
- But it’s probably much more because of what they’re *not eating*
  - Their diets tend to be much lower in **vegetables** and specifically much lower in **insoluble fiber** (which plays a very important role in the prevention of colorectal cancer)

**The debate on red meat and cancer goes back for long periods of time**

- It suffers from all of the usual trappings of nutritional epidemiology, which is why [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) famously said, “*All nutritional epidemiology belongs in the wastebasket*.”

*The 2 most obvious problems with nutritional epidemiology in this regard are*

- 1 – It’s very difficult to get an accurate reflection of what people consume using food frequency questionnaires (almost impossible)
- 2 – It’s very difficult to disentangle the variable of interest from the other lifestyle variables that are covariates within the problem and that speak to what we refer to as the “[healthy user bias](https://peterattiamd.com/ns003/#healthy%20user%20bias:~:text=from%20the%20truth.%E2%80%9D-,Healthy%2Duser%20bias,-People%20who%20are)”
- Peter doesn’t dispute for one moment that every time you do an epidemiologic survey and you compare people who live on hot dogs and pepperoni to vegetarians, the epidemiology will always tell you that the vegetarians are going to live longer
  - While that might be an extreme example, you do appreciate that on average those vegetarians have a much higher socioeconomic status, they are much more health conscious
    - They are exercising much more, they’re much less likely to be smoking, doing yoga, all these other things

**Therefore, how can we disentangle the variable from the effect?**

- When you look at the most compelling case for people who eat the highest amount of meat and their risk of cancer, there was a [study](https://academic.oup.com/jnci/article/97/12/906/2544064) that was done in Europe that looked at nearly half a million people
  - It divided them into a cohort that were eating more than 160 grams per day of protein from red meat and processed meat. It compared them to people that were eating virtually none, 20 grams per day
    - They’re comparing the extremes, and indeed there was a difference (but it was relatively small)
  - The difference between a 1.7% increase in the risk of cancer versus a 1.3% absolute risk for colorectal cancer over the period of study
- So just again, what does that mean?
  - It means that the difference in risk between the super high protein consuming meat group and the low group was 0.4% of actual percentage points
  - ***That means basically you have to put 250 people on a low meat diet to reduce 1 case of colorectal cancer***
- Again, that’s assuming that you arrived at this through randomization, which you didn’t
- There was another [study](https://jamanetwork.com/journals/jama/fullarticle/200150), it was a 10-year observational study that looked at about 150,000 people with the highest tertile of red meat consumption
  - They had a 50% increase in relative risk to those in the lowest tertile
  - The error bar on this study was so big that it barely made statistical significance despite the sample size there
    - This just speaks to the heterogeneity of this

**Peter’s takeaway:**

- Every one of these studies basically ends up having the same issue: when you look at the details, you realize it is very difficult to come up with a meaningful view that it’s red meat specifically that is driving cancer
  - As opposed to the absence of vegetables, the absence of fiber, or maybe the presence of some of the ultra processing things that go into consuming certain patterns of meat (like gas station bought jerky and stuff like that)

***Peter thinks the ill health effects for red meat consumption are incredibly weak; the hazard ratios themselves for this are very, very small, even with all of the limitations that he mentioned***

- Therefore, if you go back to the [Austin Bradford Hill criteria of epidemiology](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) (which Peter outlines in great detail in the [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZXv42gm3e5yZwOVrYDOggEQPnB-0MJD179kN9LgnXOsQ-B4fKurPREA5YpaJiCAfbvjOiFAeeTThG6YgSt5QRI_qlrxDCRap9IIK8zSVcS8WPoj-eBfRgd2BbYWojBJrWHvN2csTmmvh7xnDbQMKdVLeE1zXd6gnCt8N9ir99Rv0bFq965QkmPMVE0cShZFWmOAqcrLdgQOWhKTpKrKUDwU.3Qb0leUEWM92K0xvK3liUnVEYEoM7PQV7dW0RD8zbkc&qid=1710265017&sr=8-1)), it’s very hard to imagine that there is **causality** here
- The epidemiology here is so underwhelming that it almost draws the opposite conclusion
  - It’s almost hard to believe there is a signal given how underwhelming the epidemiology is
- Whereas conversely, when you look at the epidemiology of smoking or the epidemiology of exercise, those are so overwhelming that it factors into what we see as the overall causality narrative

**Give us feedback**

- If you like the theme of going through and ranking these things let us know
  - We have a huge list of items we can hit moving forward
- Normally, we do super deep dives, but once in a while we do a summary synthesis of evolving positions on things
  - Let us know if you like these and we’ll look to do that more

§

## Selected Links / Related Material

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=KAK83CGLVDPH&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZcgbQlnqFiCOpITpGSBWWFKQPmq7QPEoud0LkEwOoOMzaTokGXJnzdZ92p2yMF0SXjPvwoSfJRYUHDqFyaDjV3ISzctkIkm-w_czluuc95Au54ahfvU9H9ySsY5UvnMSZSJLwhPijy7N0oCRBJiPTKdfC7NuBNfeESBeYROO7BTWXTCZf2bow0ioRjb8k9uLd2z1vATULi3YNs0ll3VrpKE.Nnz9NBGVj9Y3QzwhHOxec4PnrBGysM3j_dSOLLhWjvQ&dib_tag=se&keywords=outlive+peter+attia&qid=1711025777&sprefix=outlive%2Caps%2C84&sr=8-1) by Peter Attia with Bill Gifford (March 2023) | [3:45, 1:34:30]

**Previous episodes of** ***The Drive*** **that discuss rapamycin**: [11:00]

- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/) (May 16, 2022)
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) (September 13, 2021)
- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)
- [#118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging](https://peterattiamd.com/lloydklickstein/) (July 6, 2020)
- [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) (August 13, 2018)

**Rapamycin is one of the bigger hits in the ITP study**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) | *Nature* (D Harrison et al. 2009) | [13:00]

**Previous episodes of** ***the Drive*** **that discuss metformin**:

- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#279 – AMA #53: Metabolic health & pharmacologic interventions: SGLT-2 inhibitors, metformin, GLP-1 agonists, and the impact of statins](https://peterattiamd.com/ama53/) (November 13, 2023)
- [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers](https://peterattiamd.com/andrewhuberman2/) (September 11, 2023)
- [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/) (March 13, 2023)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/) (May 16, 2022)
- [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) (April 25, 2022)
- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)
- [#73 – AMA #9: NAD & metformin, fat-burning zone, creatine, estrogenization of men, emergency kit for cold & flu, and more](https://peterattiamd.com/ama09-preview/)
- [#45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more](https://peterattiamd.com/ama04/) (March 18, 2019)

**Large epidemiological studies on metformin**: [17:30]

- [Reassessing the evidence of a survival advantage in Type 2 diabetes treated with metformin compared with controls without diabetes: a retrospective cohort study](https://pubmed.ncbi.nlm.nih.gov/36287641/) | *International Journal of Epidemiology* (M Keys et al. 2022)
- [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls](https://pubmed.ncbi.nlm.nih.gov/25041462/) | *Diabetes, Obesity & Metabolism* (C Bannister et al. 2014)

**Previous episodes of** ***The Drive*** **with Nir Barzilai**: [20:00]

- [#204 – Centenarians, metformin, and longevity](https://peterattiamd.com/nirbarzilai2/) | Nir Barzilai, M.D. (April 25, 2022)
- [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) (January 7, 2019)

**Previous episodes of** ***The Drive*** **with Rich Miller**: [23:30]

- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)

**TAME trial**: [The TAME Trial: Targeting the Biology of Aging. Ushering a New Era of Interventions](https://www.afar.org/tame-trial). | afar: american federation for aging research (2024) | [24:00]

**Previous episodes of The Drive that discuss NAD**: [24:30]

- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#216 – Metabolomics, NAD+, and cancer metabolism | Josh Rabinowitz, M.D., Ph.D.](https://peterattiamd.com/joshrabinowitz/) (August 1, 2022)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/) (May 16, 2022)
- [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) (April 25, 2022)
- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)
- [#73 – AMA #9: NAD & metformin, fat-burning zone, creatine, estrogenization of men, emergency kit for cold & flu, and more](https://peterattiamd.com/ama09-preview/)
- [#02 – Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more](https://peterattiamd.com/rhondapatrick/) (July 2, 2018)

**Newsletter about NAD**: [Separating substance from nonsense in a study on NMN supplements](https://peterattiamd.com/nmn-and-exercise-performance/) | PeterAttiaMD.com (A Misic, K Birkenbach, & P Attia 2023) | [24:30]

**Small studies supplementing with NAD in patients with neurodegenerative disease**: [28:15]

- [The NADPARK study: A randomized phase I trial of nicotinamide riboside supplementation in Parkinson’s disease](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(22)00045-6) | *Cell Metabolism* ( B Brakedal et al 2022)
- [Efficacy and tolerability of EH301 for amyotrophic lateral sclerosis: a randomized, double-blind, placebo-controlled human pilot study](https://pubmed.ncbi.nlm.nih.gov/30668199/) | *Amyotrophic lateral sclerosis & frontotemporal degeneration* (J de la Rubina et al 2019)

**NAD supplementation and MCI**: [Results from a pilot study: The effects of nicotinamide riboside on mild cognitive impairment](https://alz-journals.onlinelibrary.wiley.com/doi/10.1002/alz.044746) | *Alzheimer’s Association* (M Orr et al 2020) | [31:30]

**2006 mouse study on resveratrol**: [Resveratrol improves health and survival of mice on a high-calorie diet](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) | *Nature* (J Baur et al 2006) | [34:00]

**Previous episodes of** ***The Drive*** **that discuss resveratrol**: [34:45]

- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)

**Newsletter about resveratrol**: [Is low-to-moderate alcohol consumption beneficial for longevity?](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/) | PeterAttiaMD.com (A Misic, K Birkenbach, & P Attia 2024) | [34:45]

**ITP study of resveratrol**: [Evaluation of Resveratrol, Green Tea Extract, Curcumin, Oxaloacetic Acid, and Medium-Chain Triglyceride Oil on Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) | *The Journal so Gerontology Series A* (R Strong et al 2012) | [36:30]

**Previous episodes of** ***The Drive*** **that discuss the importance of muscle mass and strength**: [38:15]

- [#285 – AMA #55: Exercise: longevity-focused training, goal setting, improving deficiencies, managing emotional stress, and more](https://peterattiamd.com/ama55/) (January 15, 2024)
- [#242 – AMA #44: Peter’s historical changes in body composition with his evolving dietary, fasting, and training protocols](https://peterattiamd.com/ama44/) (February 13, 2023)
- [#235 ‒ Training principles for mass and strength, changing views on nutrition, creatine supplementation, and more | Layne Norton, Ph.D.](https://peterattiamd.com/laynenorton3/) (December 19, 2022)
- [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) (October 17, 2022)
- [#206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more](https://peterattiamd.com/exercising-for-longevity/) (May 9, 2022)
- [#205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)](https://peterattiamd.com/laynenorton2/) (May 2, 2022)
- [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/) (September 20, 2021)
- [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) (May 24, 2021)
- [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) (March 1, 2021)

**Newsletters about muscle mass**: [38:15]

- [Can a new drug mimic the effects of exercise on bone and muscle?](https://peterattiamd.com/can-a-new-drug-mimic-the-effects-of-exercise-on-bone-and-muscle/) | PeterAttiaMD.com (S Lipman, K Birkenbach, & P Attia 2023)
- [Muscle Mass and Cognitive Function](https://peterattiamd.com/muscle-mass-and-cognitive-function/) | PeterAttiaMD.com (A Misic, K Birkenbach, & P Attia 2022)

**Previous episodes of** ***The Drive*** **that discuss VO****2** **max**: [38:15]

- [#261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.](https://peterattiamd.com/training-for-the-centenarian-decathlon/) (July 10, 2023)
- [#223 – AMA #39: The Centenarian Decathlon, zone 2, VO2 max, and more](https://peterattiamd.com/ama39/) (September 19, 2022)
- [#217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.](https://peterattiamd.com/mikejoyner/) (August 8, 2022)
- [#206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more](https://peterattiamd.com/exercising-for-longevity/) (May 9, 2022)
- [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) (March 28, 2022)
- [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/) (September 20, 2021)
- [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) (March 1, 2021)

**Newsletter about VO****2** **max**: [The [almost] unbelievable effects of a high maximal aerobic capacity on all-cause mortality](https://peterattiamd.com/all-things-vo2-max/) | PeterAttiaMD.com (S Lipman, K Birkenbach, & P Attia 2024) | [38:15]

**Previous episode of** ***The Drive*** **with Jeremy Loenneke**: [#179 – Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength](https://peterattiamd.com/jeremyloenneke/) (October 11, 2021) | [44:15]

**Other episodes of** ***The Drive*** **about BFR**: [44:15]

- [#242 – AMA #44: Peter’s historical changes in body composition with his evolving dietary, fasting, and training protocols](https://peterattiamd.com/ama44/) (February 13, 2023)
- [#196 – AMA #32: Exercise, squats, deadlifts, BFR, and TRT](https://peterattiamd.com/ama32/) (February 21, 2022)

**Meta-analysis of blood flow restriction training**: [Low intensity blood flow restriction training: a meta-analysis](https://pubmed.ncbi.nlm.nih.gov/21922259/) | *European Journal of Applied Physiology* (J P Loenneke et al. 2011) | [47:30]

**Brand of BFR cuff Peter uses**: [KAATSU](https://kaatsu.com/collections/all) | [50:00]

 | [51:30]

**Previous episode of** ***The Drive*** **with Alton Barron**: [#232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities](https://peterattiamd.com/altonbarron/) | Alton Barron, M.D. (November 28, 2022) | [51:30]

**Previous episode of** ***The Drive*** **with Adam Cohen**: [#264 ‒ Hip, knee, ankle, and foot: diagnosis, treatment, and surgery of the lower extremities](https://peterattiamd.com/adamcohen/) | Adam Cohen, M.D. (July 31, 2023) | [51:30]

**Newsletter on variables involved in fasting**: [Wanna know what keeps me up at night?](https://peterattiamd.com) (2019) | [59:00]

**Other newsletters about fasting**:

- [Intermittent fasting](https://peterattiamd.com/intermittent-fasting/) (2020)
- [Fasting & protein: the impact of fasting on muscle mass](https://peterattiamd.com/the-impact-of-fasting-on-muscle-mass/) (2022)
- [Is alternate-day fasting superior to calorie restriction for fat loss in lean adults?](https://peterattiamd.com/is-alternate-day-fasting-superior-to-calorie-restriction-for-fat-loss-in-lean-adults/) (2021)

**Wisconsin/NIA monkey studies of caloric restriction**: [1:06:00]

- [Caloric restriction improves health and survival of rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/) | *Nature Communications* (JA Mattison *et al.* 2017)
- [Caloric restriction reduces age-related and all-cause mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988801/) | *Nature Communications* (RJ Colman *et al.* 2014)
- [Impact of caloric restriction on health and survival in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3832985/): the NIA study | *Nature* (JA Mattison *et al.* 2012)
- [Caloric restriction delays disease onset and mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) | *Science* (RJ Colman *et al.* 2009)

**Do diets that differ in macronutrient content result in differences in energy expenditure?**: [Energy expenditure and body composition changes after an isocaloric ketogenic diet in overweight and obese men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4962163/) | *The American Journal of Clinical Nutrition* (K Hall et al 2016) | [1:08:00]

**Previous episodes of** ***The Drive*** **with Rick Johnson**: [1:16:00]

- [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/) (February 7, 2022)
- [#87 – Rick Johnson, M.D.: Metabolic Effects of Fructose](https://peterattiamd.com/rickjohnson/) (January 6, 2020)

**Mouse study comparing high-fructose and low-fructose diets**: [Sucrose induces Fatty Liver and Pancreatic Inflammation in Male Breeder Rats Independent of Excess Energy Intake](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137694/) | *Metabolism* (C Roncal-Jimenez et al 2011) | [1:16:00]

**Previous episode of** ***The Drive*** **on sugar and sugar substitute**s: [#141 – AMA #18: Deep dive: sugar and sugar substitutes](https://peterattiamd.com/ama18/) (December 14, 2020) | [1:19:15]

**Newsletters on sugar substitutes**: [1:19:15, 1:22:15]

- [Sugar substitutes: deep dive into the pros, cons, available options, and impact on metabolic health](https://peterattiamd.com/sugar-substitutes/) | PeterAttiaMD.com (K Birkenbach & P Attia 2023)
- [Silencing the alarm on aspartame and cancer](https://peterattiamd.com/aspartame-and-cancer/) | PeterAttiaMD.com (K Birkenbach & P Attia 2023)
- [Replacing sugar with allulose](https://peterattiamd.com/replacing-sugar-with-allulose/) (P Attia 2020)

**Newsletter explaining Peter’s framework for viewing nutrition**: [My nutritional framework](https://peterattiamd.com/my-nutritional-framework/) | PeterAttiaMD.com (P Attia 2020) | [1:19:15]

**Rat studies on the ability of saccharin to cause cancer**: [1:23:30]

- [Ruminations on a Rat – Saccharin and Human Risk](https://www.aei.org/articles/ruminations-on-a-rat-saccharin-and-human-risk/) | *AEI* (W Havender 1979)
- [Bladder tumors in rats fed cyclohexylamine or high doses of a mixture of cyclamate and saccharin](https://pubmed.ncbi.nlm.nih.gov/5411626/) | *Science* (J Price et al 1970)

**Data on the ability of aspartame to cause cancer**: | [1:24:30]

- [Life-Span Exposure to Low Doses of Aspartame Beginning during Prenatal Life Increases Cancer Effects in Rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1964906/) | *Environmental Health Perspectives* (M Soffritti et al 2007)
- [First experimental demonstration of the multipotential carcinogenic effects of aspartame administered in the feed to Sprague-Dawley rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1392232/) | *Environmental Health Perspectives* (M Soffritti et al 2006)

**Studies comparing cancer risk in people who eat the most processed meat to people who eat the least processed meat**: [1:32:00]

- [Meat, Fish, and Colorectal Cancer Risk: The European Prospective Investigation into Cancer and Nutrition](https://academic.oup.com/jnci/article/97/12/906/2544064) | *Journal of the National Cancer Institute* (T Norat et al 2005)
- [Meat Consumption and Risk of Colorectal Cancer](https://jamanetwork.com/journals/jama/fullarticle/200150) | *JAMA* (A Chao et al 2005)

**Newsletters about red meat**:

- [The red meat and plant-based recommendation war](https://peterattiamd.com/the-red-meat-and-plant-based-recommendation-wars/) (2020)
- [Is ditching meat a “game-changer” for your health?](https://peterattiamd.com/191027/) (2019)
- [Is red meat killing us?](https://peterattiamd.com/is-red-meat-killing-us/) (2018)

§

## People Mentioned

- [Matt Kaeberlein](https://mkaeberlein.com/) (Professor of Pathology at the University of Washington, founder of the Dog Aging Project, and expert in longevity) [15:45]
- [Andrew Huberman](https://med.stanford.edu/profiles/andrew-huberman#bio) (Associate Professor of Neurobiology at Stanford and host of the [*Huberman Lab*](https://www.hubermanlab.com/) podcast) [17:30]
- [Nir Barzilai](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) (Professor of Medicine and of Genetics at Albert Einstein College of Medicine and PI of the [TAME trial](https://www.afar.org/tame-trial)) [20:00]
- [Rich Miller](https://www.richmillerlab.com/biog) (Professor of Pathology at the University of Michigan, Director of the Paul Glenn Center for Biology of Aging, and expert in the Interventions Testing Program) [23:30, 34:45]
- [Jeremy Loenneke](https://hesrm.olemiss.edu/people/jeremy-paul-loenneke/) (Associate Professor of Exercise Science at the University of Mississippi and expert in blood flow restriction) [44:15]
- [Alton Barron](https://altonbarronmd.com/about/) (Orthopedic surgeon with expertise in shoulder, elbow, and hand) [51:30]
- [Adam Cohen](https://adamcohenmd.com/about-adam-cohen-md-top-orthopedic-doctor-nyc) (Orthopedic surgeon with expertise in sports medicine injuries of the shoulder, elbow, hip, knee and ankle) [51:30]
- [Richard (Rick) Johnson](https://drrichardjohnson.com/about/) (Professor of Medicine in the Department of Nephrology at the University of Colorado and expert in fructose metabolism and metabolic disease) [1:16:00]

§