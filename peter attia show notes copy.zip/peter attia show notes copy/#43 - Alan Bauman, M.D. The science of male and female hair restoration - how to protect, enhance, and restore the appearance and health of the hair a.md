# #43 – Alan Bauman, M.D.: The science of male and female hair restoration – how to protect, enhance, and restore the appearance and health of the hair and scalp

**Source:** [https://peterattiamd.com/alanbauman/](https://peterattiamd.com/alanbauman/)

---

In this episode, Alan Bauman, certified hair transplantation surgeon and hair restoration expert, discusses both male and female pattern hair loss, the science behind what drives it, and what that tells us about prevention and restoration. Having treated over 20,000 patients, Alan shares his invaluable insights into what works and what doesn’t in terms of the non-surgical treatment options. We also go into great detail about the more invasive approaches like PRP, and of course, hair transplantation, a procedure which Alan has refined over the years into a proprietary method that seems to produce unbelievable results. Additionally, Alan provides tips for maintaining scalp health, which is vital for hair growth, as well as the importance of choosing a hair specialist who has the tools, expertise, and patience to develop a compassionate and encompassing approach to hair restoration.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/alanbauman/the_Drive_public.png)

Play

#43 - Alan Bauman, M.D.: The science of male and female hair restoration - how to protect, enhance, and restore the appearance and health of the hair and scalp

#43 - Alan Bauman, M.D.: The science of male and female hair restoration - how to protect, enhance, and restore the appearance and health of the hair and scalp

1x15s30s

0:001:55:57

## We discuss:

- Alan’s unique path, and how he became interested in hair transplantation [7:15];
- The prevalence of hair loss, types of hair loss, and the different patterns in men vs. women [15:45];
- The role of genetics in hair loss, and when does it start [19:00];
- Female hair loss: the role of hormones, pregnancy related hair loss, and what it means to have thinning and shedding [22:30];
- Primary drivers of male hair loss, finasteride as a treatment, and the potential side effects [26:15];
- Common treatments – Proscar, Propecia, Rogaine, and more – how they all came about and what you need to know [29:45];
- Primary drivers of female hair loss, potential treatments, and the different types of hair follicles [33:15];
- What are some of the unproven/snake oil methods of hair treatments being pushed to the public? [37:15];
- Preventative steps to take if you’re worried about future hair loss [42:00];
- Medications that may negatively affect hair quality [45:30];
- The importance of seeing a hair specialist [47:15];
- Impact of scalp health and inflammation on hair growth, how to pick and apply shampoo and conditioner, and how to avoid and treat hair breakage [50:15];
- Treatment options – finasteride, minoxidil, laser caps – how they work and what you need to know [57:15];
- PRP treatment: How it works, details of the procedure, and Alan’s proprietary protocol [1:11:45];
- The hair transplant procedure [1:29:30];
- Risks involved with a hair transplant procedure [1:44:00];
- Is a donor hair susceptible to the forces of the implant site that caused the hair loss? Can a hair follicle grow anywhere on the body? [1:47:45];
- Age appropriate procedures, how far the field has come, and why Alan loves his work [1:51:45]; and
- More.

§

## Show Notes

## Alan’s unique path, and how he became interested in hair transplantation [7:15]

- Met through a mutual patient
- Peter was intrigued and impressed by the hair restoration Alan had done on a mutual patient

Alan’s training

- Medical degree from [New York Medical College](https://www.nymc.edu/) in Valhalla, NY
- [Mt. Sinai Medical Center and Beth Israel Medical Center](https://www.mountsinai.org/locations/beth-israel) is where he did residency in general surgery
- Alan trained in general surgery ⇒ This is unique, most hair specialist don’t do this
- One of only ~200 surgeons certified by the [American Board of Hair Restoration Surgery](https://abhrs.org/)
- Alan had a mentor in hair transplantation dating all the way back to high school

> “I always thought that plastic and reconstructive surgery, that’s kind of where I was headed. It really wasn’t until I met a patient, who had had a hair transplant, did I even consider looking at hair transplant surgery as a potential procedure that I would even want to perform. . .And then I met this patient, and I couldn’t tell that he had had a hair transplant, I was basically blown away.”

## The prevalence of hair loss, types of hair loss, and the different patterns in men vs. women [15:45]

Hair loss is super common according to the [American Hair Loss Association](https://americanhairloss.org)

- 80 million men
- 46 million women

Forms of hair loss:

- Thinning
- Receding hairlines
- Loss of volume
- Loss of coverage of the scalp

“It’s a big concern for many, although very much undertreated.”

**Men vs. women**

- For men, it’s more socially acceptable
  - Side note: Peter shaves his head about once per week
- For women, there’s much less socially acceptable hair loss, so it can be much more devastating.

Female pattern hair loss:

- behind the hairline, that’s where that density loss can occur.
- Not equally, it’s very rarely equally distributed
- This is helpful in the sense that women can lose 50% of their hair but from across the room it can look like a full head of hair

Male pattern hair loss:

- Men lose more hair on top and less, if any, along the sides
- So with men you can see the hair loss progression more easily than in women

![](https://peterattiamd.com/wp-content/uploads/2019/03/male-vs-female-pattern-hair-loss.jpg)

**Figure 1. Male vs. female pattern hair loss.** Image credit: [pcds.org](https://www.pcds.org.uk/clinical-guidance/alopecia-male-and-female-pattern-alopecia)

## The role of genetics in hair loss, and when does it start [19:00]

Is there such thing as “premature” hair loss?

- “No, that doesn’t make any sense” say Alan, “It’s in the eye of the beholder.”
- We all lose hair starting at different times and at different rates starting after puberty

**Visible signs of hair loss**

In men:

- 20% of men in their 20s
- 30% of men in their 30s
- 40% of men in their 40s
- See: [Prevalence of male pattern hair loss in 18-49 year old men.](https://www.ncbi.nlm.nih.gov/pubmed/9865198)

In women:

- It’s a little bit later on
- It’s also more multifactorial, “we can see other things that are affecting the hair loss process”

**Genetics: How much of hair loss is genetically determined?**

- In men: [98-99% genetically determined](https://www.ncbi.nlm.nih.gov/pubmed/29146897)
- About [200 genes play a role in hair loss](https://www.ncbi.nlm.nih.gov/pubmed/26843402)

*The genetics also* [*play a role in the characteristics of hair*](https://www.ncbi.nlm.nih.gov/pubmed/30531825)*:*

- Color
- Curl
- Texture
- “And all of these play a role in terms of coverage.”

*Do we just need to look at our mom’s dad to know if we will be bald?*

- “That’s really not the case. We know that there’s other factors, that come from both sides of the family, the genetic components that play a role in all those factors that I mentioned. The color, the quality of the hair, the speed at which the hair loss occurs, and the patterns, and so forth.”

Variation within a family

- It can also skip generations
- There can be different hair loss in twin brothers, for example

## Female hair loss: the role of hormones, pregnancy related hair loss, and what it means to have thinning and shedding [22:30]

**What role do hormones play?**

*Looking at what happens during and after pregnancy:*

⇒ During pregnancy…

- The amount of follicles that are **in antigen** when you’re in pregnancy, is a much higher percentage
- More follicles staying in antigen, longer time in antigen, so your hair will be thicker and fuller during that time of your pregnancy

⇒ After childbirth…

- Shedding phase (aka effluvium or telogen effluvium)
- Hormones crash back down after childbirth, then those ratios go back to normal
- Shedding can occur in about six to 12 weeks

“But if you’re prone to female pattern hair loss, sometimes you don’t necessarily recover from that dramatic effluvium. So you shouldn’t just say, ‘Oh, well, it’s just pregnancy shedding, and that’s it.’”

**Thinning hair in women**

*What does it mean to lose thickness?*

- They could be losing thickness in the individual hairs, the fiber diameter
  - That can change just with age
  - It gets thinner with time
- Losing volume
  - It could also be that they feel like their whole head of hair is not as thick as it was
  - So that could be the sheer numbers of hairs that are growing at any given time

*The ponytail litmus test:*

- “When I was in my 20s, I put my ponytail, with a scrunchie and I could just turn it two times, and boom. That was it. It was like horse’s tail. And now, here I am, 10, 15 years later, and I can turn it three times,” meaning they need another wrap around.”

**Shedding is a confusing symptom**

- Shedding happens every day ⇒ “Hair follicles turn on and turn off, hair follicles will grow for five to seven years, a long, strong hair, and then turn off, rest for 90 days, and then the cycle begins again.”
- A certain percentage of hair follicles are in that growing phase, and let’s call it 84 or 85%, but all of the sudden, if you do something to switch those percentages, then you’re going to get a thinner head of hair. Meaning, that there’s less trees in the forest, perhaps.

## Primary drivers of male hair loss, finasteride as a treatment, and the potential side effects [26:15]

Testosterone and DHT

- Dihydrotestosterone (DHT) is a hormone that will precipitate male baldness in a genetically susceptible individual
- “That is the primary trigger, according to the data that we see right now.”

The data is very clear:

- If you put someone on [finasteride](https://en.wikipedia.org/wiki/Finasteride) (which blocks the enzyme that turn testosterone into DHT), they have a [90% chance of looking the same or better in about 5 years](https://www.ncbi.nlm.nih.gov/pubmed/18573713) (but not indefinitely)
- “That’s a pretty safe bet, that DHT is the bad guy, responsible for a lot of follicular homicide out there.”

**Finasteride**

- Sold under the brand names [Proscar](https://www.rxlist.com/proscar-drug.htm#indications) (the 5 mg dose) and [Propecia](https://www.rxlist.com/propecia-drug.htm) (1 mg dose)

*Side effects of finasteride*

- A subset of men experience sexual side effects with them
- Prostate cancer: literature is very confusing ⇒ Lower rates of prostate cancer, but potentially higher grade when it does occur
- Alan says data shows [finasteride does NOT increase risk of high-grade prostate cancer](https://www.ncbi.nlm.nih.gov/pubmed/19138953)

**Alan gives a potential explanation for finding of an increase in high grade cancers:**

*“For example, finasteride five milligrams is one of the more prominent treatments for BPH, Benign prostatic hyperplasia, a large prostate. You put somebody on five milligrams of finasteride, their regular prostate tissue shrinks.*

*And so that’s likely what’s happening also at a one milligram dose (of finasteride for hair loss). . .*

*And so what happens if the normal prostate tissue is shrinking, and you go to biopsy that tissue, you might be more likely to find some high grade cancer, or cancerous material in there just because the* ***normal tissue*** *is less voluminous.*

*Not everybody in the world gets a prostate biopsy, but everybody in a clinical trial does, so that can skew the numbers.*

*That’s one of the ways it’s been explained to us… in the world of hair restoration surgery. . .you’re not causing the prostate to become cancerous. And of course, thank God, people don’t die of prostate cancer. It’s a very slow moving thing, obviously. There’s very good survivability, if you should be diagnosed. But the point is, is that you’re shrinking that good, healthy tissue.*

*And then you’re more likely to find something on the biopsy, and that more likely will be high grade. And high grade cancers in prostate, are very, very rare. So it doesn’t take much to skew the numbers from like, let’s call it, and don’t quote me, but let’s call it a quarter percent to three-quarters of a percent. All the sudden, it doubled.”*

## Common treatments – Proscar, Propecia, Rogaine, and more – how they all came about and what you need to know [29:45]

Finasteride ([Proscar](https://www.rxlist.com/proscar-drug.htm#indications), the 5 mg dose, and [Propecia](https://www.rxlist.com/propecia-drug.htm), 1 mg dose)

- Originally approved as a prostate indication, however, they knew it was going to work for hair growth all along
- Then, they got FDA approval for hair loss (1 mg dose, i.e. Propecia) in 1998

[Minoxidil](https://en.wikipedia.org/wiki/Minoxidil) (common brand name Rogaine)

- First approved medication for hair loss (minoxidil plus [propylene glycol](https://en.wikipedia.org/wiki/Propylene_glycol))
- [Originally administered for hypertension before a hair loss drug](https://www.pharmaceutical-journal.com/news-and-analysis/how-minoxidil-was-transformed-from-an-antihypertensive-to-hair-loss-drug/11080942.article?firstPass=false)
- People on oral doses were [seeing hair growth in many places](https://www.ncbi.nlm.nih.gov/pubmed/4401051) (i.e. their knuckles)
- Not a great blood pressure medicine, so turned it into a topical for hair growth

> “So that is an important data point in the history of hair loss, when we write the history books, that really started hair loss as something that we can treat, and the beginning of the end, if you will, of a snake oil era.”

Rogaine, today

- Over-the-counter
- a number of different formulations
- two percent or five percent solutions
- foam versions
- There’s generic versions all over the place

Issues:

- Most of those are very, very irritating to the scalp
- Very greasy or gooey (the foam versions) so if you had any kind of hair on your head whatsoever, it can be very difficult to apply, to get into the scalp
- Consistently [ranked as the most disappointing hair loss treatment](https://www.webmd.com/skin-problems-and-treatments/hair-loss/news/20100406/survey-most-baldness-treatments-dont-work#1) ever by Consumer Reports

**Better versions of minoxidil**

- More sophisticated formulations like [82M and 82F](https://www.baumanmedical.com/product/minoxidil-formula-82m/)
- Penetrating better and actually getting to the follicles where it is needed
- easier to use
- less irritating to the scalp
- Helps with inflammation

## Primary drivers of female hair loss, potential treatments, and the different types of hair follicles [33:15]

What is driving hair loss in women (outside of pregnancy-related hair loss)?

- DHT levels could be very low, but she can also be androgen sensitive
- There is about a [50% success rate when you apply finasteride in postmenopausal women](https://www.ncbi.nlm.nih.gov/pubmed/15459533) with hair loss
- **CAUTION**: Finasteride is ONLY okay for women beyond their child-bearing age (postmenopausal) because DHT is important for the development of a male fetus

**Young women with** [**polycystic ovary syndrome**](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome) **(PCOS)**

- PCOS, a hormonal problem:
  - Acne
  - [Hirsutism](https://www.mayoclinic.org/diseases-conditions/hirsutism/symptoms-causes/syc-20354935) (hair growth on the face)
  - Hair loss, devastatingly bad
- *What do all of those have in common*? ⇒ They’re all androgen processes
- And can’t give them finasteride/[5α-Reductase inhibitor](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_inhibitor) (blocker of DHT) because they are in childbearing age

What can you give young women with PCOS?

- “We’re left with other non-androgen modalities”
- Minoxidil to directly stimulate the scalp
- [Low-level laser therapy](https://en.wikipedia.org/wiki/Low-level_laser_therapy) to impart energy to the hair follicles
- Maybe injectable treatments like [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma)

Can their hair loss be restored? Or, is it permanent?

- If you can normalize their hormones, many of their hair loss symptoms improve slightly
- But once the follicle is damaged beyond repair, miniaturized down to a certain level, it reaches a point of no return

**Types of hair follicles**

**⇒** [**Terminal hair**](https://en.wikipedia.org/wiki/Terminal_hair): a good, healthy oak tree in the forest, your best quality hair is a terminal hair

⇒ [**Vellus hair**](https://en.wikipedia.org/wiki/Vellus_hair): the type of hair you have on the top part of your cheek, it’s invisible, it’s less than two millimeters long, it doesn’t have any pigment to it, and it’s very thin, in terms of its diameter

- So if a follicle was producing a terminal hair and then it miniaturizes all the way down, to now creating a vellus hair, you’re out of luck.
- Meaning, that there’s nothing that’s going to revive that follicle, and get it to regain any kind of significant amount of growth.

> “So whatever kind of hair loss you have, male, female, the idea is that you got to take action soon to protect the functioning of the follicles before there’s that point of no return.”

## What are some of the unproven/snake oil methods of hair treatments being pushed to the public? [37:15]

Peter says… “I feel like when you look at old magazines, like there’s always ads for like some tonic or some ridiculous chemical.”

*What are some of snake oil things that were being peddled out there to people today?*

- Thanks to the FDA approval for Rogaine in 1988, it was the “beginning of the end of a snake oil era”
- So that started to clear out the industry of those oil treatments, tonics, etc., that had no clinical efficacy whatsoever out of the market
- Because now, in order to advertise hair growth, you had to have that FDA clearance

***Be aware that not everything will work for everyone:***

People will say, “Oh, well, Rogaine didn’t work for me,” but remember…

- Application matters
- Compliance matters
- Expectations matter

[Low-level laser therapy](https://en.wikipedia.org/wiki/Low-level_laser_therapy) does work despite some claims that it doesn’t

- For example, “that small, little handheld laser is just that you’re trying to water your lawn with a watering can, when really what you needed was a sprinkler system. You needed a different type of delivery system.”
- “For many years, people thought that low-level laser therapy had no influence on the hair follicle. And obviously, [they were all proven wrong by the exhaustive studies that have been done now](https://www.ncbi.nlm.nih.gov/pubmed/?term=low+level+laser+therapy+hair+growth), and all of the FDA clearances, which prove not only safety, but certainly hair growth.”

**Things that probably don’t work:**

*1* [*Finasteride in postmenopausal women with androgenetic alopecia.*](https://www.ncbi.nlm.nih.gov/pubmed/11050579)

*2 Biotin*

- Given to race [horses to improve hoof issues to improve the strength](https://www.ncbi.nlm.nih.gov/pubmed/9932094)
- Not much data in humans
- Put a person biotin (a high dose, say 10,000 micrograms)… 9 out of 10, they’ll tell you their nails are getting stronger and [it also improves hair tensile strength](https://jddonline.com/articles/dermatology/S1545961617S0141X/5)
- **But remember. . .**“That’s not going to improve your female pattern hair loss or male pattern hair loss problem to any substantial amount. It may make the hairs that you have stronger, but it’s going to need to be coupled with some other effective treatment, and that’s where layering these kinds of therapeutic interventions are really, really important.”

## Preventative steps to take if you’re worried about future hair loss [42:00]

- First step is performing evaluations and measurements
- Use trichometers to do hair bundle measurements
- We’ll look at the areas that are permanent (back of scalp) to see what is their maximum hair mass index (the number that is a combined measurement of the diameter and the density in a given area of scalp)
- Then compare that area to an area that might be a risk, like the crown area, or the frontal zone
- When you’re going through puberty, your hair mass is essentially all the same over the entire top of your scalp
- So I can pick up if they have a tendency towards hair loss very, very early on, way before it’s noticeable to the naked eye.

*Regardless of genetics, will everyone eventually lose their hair?*

- Most likely
- Some people however, very few, have a remarkable unwavering hairline (like a friend of Alan’s)
- But… “I’m come across tens of thousands, hundreds of thousands of people in my life so far, and I’ve never seen anybody else like him. So I don’t know if it’s a 100% true, but I would guess that it is something like that, where over time, you will see some kind of thinning.”

## Medications that may negatively affect hair quality [45:30]

Alan says that in his experience with 20,000+ patients, he’s figured out through conversations that the following types of medications may have a negative impact on hair loss:

- Blood pressure meds
- Cholesterol modulating meds
- Mood modulators

Hypothesis or documented facts?

*“Well, it’s just been so clear. I mean, I’ve treated about 20,000 patients, and many patients say, ‘You know what, when I started that medication a year ago,’ fill in the blank, ‘Cholesterol medication, that’s when I really started to notice my hair changed.’”*

## The importance of seeing a hair specialist [47:15]

“The general feedback from most of my patients is that, unfortunately they have been around the block to a number of different physicians. Maybe endocrinologists, dermatologists, their primary doctor, family doctor, whomever, doing all sorts of blood tests, looking for why their hair is thinning, and no one has ever even looked at their scalp, measured their hair, or talked to them about potential treatment options, except maybe an over-the-counter Rogaine bottle, on the way out the door. Here, catch.”

“Unfortunately, dermatologists often hold themselves out as experts in skin and hair, but yet, they have little ability to diagnose the hair loss process. They have no interest in measuring, or monitoring, or prescribing even a treatment regimen, and keeping a patient compliant with it. So it’s just kind of like a doorknob conversation for them, and they don’t have the time to do it, honestly.”

“A good, strong hair loss consult in my office takes at least an hour, typically. Patients usually spend about an hour and a half in my office when they come in for a consultation. You’re not going to spend an hour and a half with your local derm, certainly. They’re going to do a quick exam, look for some funky mole, and then kind of send you on your way.”

**The takeaway:** *Find a specialist*

> “Find somebody who does it full-time, that’s their area of expertise and specialty. And yes, who has those tools at their disposal to measure, and monitor, and figure out what’s going on, whether it’s genetic testing to look at androgen sensitivity in that postmenopausal women. I mean, a lot of derms just don’t have access to some of that stuff.”

## Impact of scalp health and inflammation on hair growth, how to pick and apply shampoo and conditioner, and how to avoid and treat hair breakage [50:15]

> “The soil in the forest needs to kind of be fertile, and if it’s really inflamed, or there’s inflammation going on, that can definitely shut down the follicle and impair hair growth.”

There is good [data from studies showing that **scalp inflammation** can have a detrimental effect on hair growth](https://www.ncbi.nlm.nih.gov/pubmed/19467978)

Dandruff:

⇒ There are many types of dandruff that can give Alan a clue of what might be going on:

- Thick and yellow
- Small and white
- Oily dandruff
- Dry dandruff

[Trichology](https://en.wikipedia.org/wiki/Trichology): the study of the chemistry of the scalp ⇒ “Essentially, where we look at scalp pH levels, moisture levels, sebum levels, and really try to assess, what’s the right protocol of scalp care.”

Shampoo and conditioner tips:

- You should **always follow your shampoo with a conditioner**
  - Shampoo is like degreasing, essentially, it’s a cleanser
  - If you shampoo in a harsh way, or with a strong surfactant, let’s call it, then you’re going to strip out a lot of the natural oils of the scalp, and also of the hair.
  - And a conditioner replaces those natural moisturization of the hair. So it’s kind of important to do both of those things, but there’s a huge spectrum of different types of shampoos.

*“Shampoo is not going to cure your hair loss”*

- But again, you have to understand, if we can rectify some imbalance at the level of the scalp, and reduce inflammation, or tackle a fungal overgrowth, and we’re going to start to improve some things.
- And if we have some ingredients that maybe we want to apply in the shower, while the scalp is kind of steamed, if you will, sometimes that’s the right time to do it.

Finding the right shampoo and conditioner regimen for you has to do with variables such as:

- Scalp pH level
- Moisture level
- Oil level
- Your natural sebum production
- Your hair care regimen (a lot of product, or hair spray, or things like that that need to be rinsed and washed out?)
- Are you in a dirty environment? (City where there’s smoke, toxins, and debris, that you need to wash out of your hair on a regular basis?)

Some general guidelines

- **So if your hair is kind of long and curly** (“kinky” or “afro” type hair). . .
  - You need like **dermal conditioning** (conditioners that kind of stick around for a while)
- **If you’re hair is thin and kind of limp. . .**
  - You need very, very light conditioners
  - And you want to make sure you’re using shampoo that strips out a lot of that oil, so that you get some weightlessness to the hair, in order to style it

How to apply shampoo and conditioner

- Shampoo ⇒ important for the scalp to work lather starting at the scalp and move out
- Conditioner ⇒ more important for the ends of the hair so start at the ends and work towards the scalp

The importance of a conditioner:

- The ends of the hair are the ones that are typically the driest, it’s been around the longest, the hair doesn’t “self-repair”
- It’s a keratin fiber, it’s not alive, and so the tips of the hair is the part where you’re going to see a fraying of the hair
- The tips of the hair are also what take the most abuse (UV rays, heat, blowout, straightening, curling, coloring, etc.) leading to **hair breakage**

**Hair breakage:**

![](https://peterattiamd.com/wp-content/uploads/2019/03/hair-breakage-1024x869.png)

**Figure 2. Hair breakage.** Image credit: [blog.designessentials.com](https://blog.designessentials.com/articles/5-signs-hair-breakage-problem/)

- Hair breakage is when the cuticle is starting to peel up, the ends are starting to split and fray
- A very common problem for hair loss in women, **it’s a trigger of hair loss in women**
- The hair breakage, literally, that they’ve stressed out the fiber so much, that the fibers are actually breaking

*⇒ What causes hair breakage?*

- Harsh chemical treatments
- New trends for flat ironing… the hot ceramic flat iron again, and again, and again, on your hair to straighten it, to straighten out the curl.
- That application of heat and/or other products can degrade the hair fiber, so you should condition the hair, itself, rather than the scalp.

Scalp treatments

- “But don’t forget, that sometimes the scalp needs a little love too”
- Many different types of products for…
  - Exfoliation
  - Moisturization
  - Anti-inflammatories
  - Psoriasis issues

## Treatment options – finasteride, minoxidil, laser caps – how they work and what you need to know [57:15]

2 buckets of treatment

1. Chemical therapies (oral or topical medications)
2. Non-chemical therapies (Laser and PRP)

For men…

- First intervention is typically finasteride (90% success rate)
  - How to avoid side effects:
    - Change timing of dose
    - Frequency of dose
    - Amount of dose
    - Change from oral dose to topical (82F)

For women…

- First is laser light topicals
- Then maybe PRP

**Lasers**

How does it work? ⇒ Laser works by imparting energy to the follicle

The [mechanism of action as described by Dr. Michael Hamblin](https://www.ncbi.nlm.nih.gov/pubmed/28070154):

- photons of light, in specific wavelengths, are accepted at the level of the electron transport chain in the mitochondrial membrane, at the [cytochrome c oxidase](https://en.wikipedia.org/wiki/Cytochrome_c_oxidase)
- what you get is a hyperpolarization of that mitochondrial membrane
- And those ions flowing back and forth into and out of the mitochondria is what generates ATP
- If you can make those mitochondria kind of fire up, and produce a lot of fuel, you end up getting a better, stronger, healthier hair growth
- Note: It’s not that people are losing their hair because there’s a deficiency in ATP production at the follicle, **we’re just trying to override whatever it is that’s potentially causing the issue**.

**Minoxidil**

“When you apply a topical medication like minoxidil, you know that it has nothing to do with DHT, but you’re basically pushing that gas pedal all the way down to the floor, trying to push that follicle into the best possible growth.”

*Mechanism:*

- It’s a potassium channel opener
- Essentially, it keeps the follicle in the growing phase
- [Here’s the research](https://www.ncbi.nlm.nih.gov/pubmed/18258787)

[*3 phases of hair growth*](https://www.philipkingsley.com/hair-guide/hair-science/hair-growth-cycle)

1. Antigen (growing) phase
2. Catagen phase (transition)
3. Telogen phase (resting phase)

![](https://peterattiamd.com/wp-content/uploads/2019/03/phases-of-hair-growth.jpg)

**Figure 3. The phases of hair growth.** Image credit: [hairlossrevolution.com](https://www.hairlossrevolution.com/vellus-hair-to-terminal-hair/)

⇒ In male pattern and female pattern hair loss, you’ll see more and more percentage of hair moving out of antigen phase to telogen phase

*When you put somebody on minoxidil…*

- resting follicles start to kick into action and grow
- And hairs already in the growing phase that may want to turn off too soon, are kept in the growing phase
- Also, the longer you keep a follicle in antigen, the thicker the fiber becomes over time

*In summary, how does minoxidil work?*

- It decreases the amount of follicles that are in that resting phase
- It keeps them in the growing phase
- You get better, thicker, stronger, healthier hair, from those follicles that *could be rejuvenated*, that are not too far gone

**Recommendation**: Get *compounded* minoxidil

- Don’t buy it off the shelf, get the “compounded” versions which reach the scalp better
- Get formulas that are mixed [Tretinoin](https://www.webmd.com/drugs/2/drug-3956/tretinoin-topical/details) (brand name Retin-A)
- Good clinical data that [shows that the combination of minoxidil plus tretinoin, improves the hair growth and increased hair density](https://www.ncbi.nlm.nih.gov/pubmed/17902730)

⇒ For example: [Compounded Minoxidil Formula 82M](https://www.baumanmedical.com/product/minoxidil-formula-82m/)

- “Our most powerful, most popular treatment, most easily compliant version of minoxidil”
- Formula includes a bit of fluocinolone (anti-inflammatory) to fight any scalp irritation

**Inflammation and hair loss**

- Alan was part of a [study where they looked at the micro-inflammation at the level of the hair follicle](https://www.ncbi.nlm.nih.gov/pubmed/?term=bauman+inflammazome)
- They determined that there there is a lot of micro-inflammation at the level of the follicle
- So we think that maybe the fluocinolone that’s in the 82M be making it more tolerable to the scalp while also addressing that micro-inflammation right at the level of the follicle
- It also helps us understand maybe how some of our sophisticated PRP creation techniques may improve hair follicle function.

> “Once you understand that that’s some bit of inflammation going on, it kind of opens the door to some other modalities of treatment.”

**Minoxidil for women**:

⇒ Same product as the male formula, no difference

*Coaching women how to apply minoxidil…*

- Over the counter foams (Rogaine) are very difficult and most of it is not reaching the scalp
- Applying a compounded product like 82M:

- Part the hair
- The bottle that the 82M comes in, has an applicator tip.
- Put the tip of the bottle directly onto the scalp when you apply it, so you’re kind of parting the hair, and you’re directing the application directly onto the scalp
- It takes 90 seconds
- Twice a day, every day

> “And that’s the other piece of the puzzle. Most people who buy minoxidil over-the-counter, think that once a day is going to do the job. And that very, very rarely has any substantial effect on hair growth whatsoever.”

**Laser caps**

- Years ago the laser could be quite laborious (i.e. the laser comb)
- Today: the laser cap or cap therapy devices just sit on your scalp like a baseball hat

⇒ Best of the best: [CapillusRx](https://www.baumanmedical.com/qa/capillusrx-laser-therapy-cap/)

- 312 diodes
- Can only get with a prescription
- Cost: ~$3,500, but it is a one time fee and can last 10+ years
- No side effects (non-chemical)
- 6 minutes per day

![](https://peterattiamd.com/wp-content/uploads/2019/03/laser-cap-1024x456.png)

**Figure 4. Capillus laser cap.** Image credit: [amazon.com](https://www.amazon.com/Capillus82-Laser-Hair-Growth-Cap/dp/B01H554NUA) and [hairregrowthaustralia.com](https://www.hairregrowthaustralia.com.au/Capillus-312-RX-Laser-Cap-p/hra-0041.htm)

## PRP treatment: How it works, details of the procedure, and Alan’s proprietary protocol [1:11:45]

[Platelet-rich plasma](https://en.wikipedia.org/wiki/Platelet-rich_plasma) (PRP) treatment **in orthopedics** is unsolved, “the jury is still out”, says Peter

*Does it really work for hair loss?*

- If the follicle is dead and gone, PRP will not solve the problem (i.e. total hair loss)
- However, you’re not wasting time and money if you have ongoing progressive hair loss ⇒ “You may not reach your goal with PRP, but it may help mitigate future loss”
- It’s not going to bring back a receding hairline, but it’s going to keep it from receding further or faster.
- So, PRP has a role in preventing the loss of follicle function

**How PRP works:**

- Platelet rich plasma
- It’s derived from your own blood
- Take a sample of your blood, and we’re going to spin it in a centrifuge, to separate the formed components in the blood
- Red blood cells weigh much more than platelets do or white blood cells so when you spin a sample of the blood, you can then separate the blood components, based on their mass
- Platelets contain very powerful ingredients called growth factors and cytokines, and platelets are responsible for not only clotting blood but also for tissue regeneration and repair

⇒ You get a paper cut:

- Platelets clot the blood to stop bleeding
- They release growth factors to help repair the wound
- May even recruit stem cells to the area, or increase new blood vessel formulation

*Well, what does all this have to do with hair?*

- Anything that helps out with wound healing tends to have a nice positive effect on hair growth
- 15 years ago, PRP was being used as a wound healing treatment, in conjunction with hair transplantation
- As a [wound healing treatment](https://www.ncbi.nlm.nih.gov/pubmed/25331465), the therapy works really well but we were also seeing an improvement in hair growth
- “And so we started applying into other areas of the scalp, that maybe we weren’t transplanting, and low and behold, we were noticing that there was some improvements in the thickness, and the caliber, and the length of some of these miniaturized hairs.”

**More details about PRP treatment:**

- What size needle? ⇒ 27 gauge, ½ inch needle
- Is PRP treatment painful? ⇒ Not painful, use local anesthetic
- How much injections? ⇒ 700 injections
- Length of treatment? ⇒ whole procedure 1 hour, the injection process only 10 minutes
- So, with someone who has a really good set of patient criteria selection, are you pretty optimistic that PRPs going to move the needle? ⇒ **“Oh yeah. I mean, PRP works well.**”
- How often does one need to be treated? ⇒ Depends on the power and strength of that individual’s PRP

*The sweet spot of platelets*

- The more platelets the better, generally speaking
- So if you come to my clinic and you have 150,000 platelets per microliter, you have a different platelet concentration than somebody has 250,000
- As you increase the concentration of platelets, for example, on neovascularization, there is a dose dependent upward curve on that, [so the higher the platelet concentration, the more neovascularization you’re going to get](https://www.ncbi.nlm.nih.gov/pubmed/27631460)
- However, [studies suggest that there is a sweet spot](https://www.ncbi.nlm.nih.gov/pubmed/19170984) in terms of stem cell mobilization
- So what exactly is that concentration in both of those studies, what is that concentration supposed to be? ⇒ According to that data, it says, **“Somewhere between 1.4, 1.5 million platelets per microliter,” is where that sweet spot exists**

What about the characteristics of the platelets?

- Research is still in its infancy so they don’t know if this matters
- Size, for example ⇒ not sure if bigger is better
- Only know that more platelets is associated with better results
- “Hopefully, in 10 years, you have a different assay than just something as blunt as the CBC, right. You can measure some cytokine or you can measure some other functional property of the platelet, that probably matters a heck of a lot more than the number.”

White blood cells

- “But the other thing that I’ve learned over the years of doing those thousands and thousands of PRP treatments for nearly 10 years, is the importance of the white blood cell.”
- [Monocytes](https://en.wikipedia.org/wiki/Monocyte) (a subtype of white blood cell): “I think they’re under appreciated, in not only in the literature in terms of what they do in the body, but especially in PRP.”
- “I’m a very strong proponent of the importance of monocytes in the final PRP. . .and we say that our PRP is monocyte-rich.”

Dual-spin process

⇒ First spin:

- The first spin is kind of a gentle spin, to take off the red blood cells. We don’t want red blood cells in our PRP. Red blood cells in the skin are extremely inflammatory.
- So I prefer to have PRP that has less than 1% [hematocrit](https://en.wikipedia.org/wiki/Hematocrit)

⇒ The second spin:

- After the first spin, it leaves a plasma, which contains the platelets
- So the plasma-based spin, which is the second spin, then essentially, pushes the platelets to the bottom.
- So we’ve captured this maximum number of platelets, we can take off the platelet-poor plasma to as much as we would like, leaving us within a reconstituted amount of whatever we choose concentration and volume of PRP.
- “So that process, that dual-spin process, and I haven’t found another one that has been able to duplicate this consistently, removes the red blood cells, consistently gives me a very high concentrate of platelets, and consistently gives me this bump or boost in monocytes.”

*How many tubes of blood are you actually drawing out for the full treatment? ⇒* 60 cc’s on a treatment, and that concentrates down to about 7.5 cc’s of PRP

***So how long does a PRP treatment last for one of Alan’s patients?***

- Most dermatologists are spinning test tubes, they’re getting two to three times concentrate
- Alan is getting seven to eight times
- They’re missing all the monocytes
- Additionally, their patients are coming in monthly, or every 2 months, for treatment
- Alan’s patients PRP last 10-14 months on his proprietary protocol (maybe 5% that need it more often than that, and then another small cohort of patients that can get away with it almost every two years)

*And what’s the percentage of patients that are not responding?*

- Well, everybody responds to some degree
- The question is, “Are they responding where they want?”
- It won’t regrow the the receding hairline
- But the other zones (that they didn’t even realize were thinning) we’re going to get a **20 to 50% boost in volume** in many of those areas

![](https://peterattiamd.com/wp-content/uploads/2019/03/Female-PRP-1024x355.jpg)

**Figure 5. Result from PRP treatment.**

![](https://peterattiamd.com/wp-content/uploads/2019/03/male-PRP-1024x512.jpg)

**Figure 6. Results from PRP treatment.**

## The hair transplant procedure [1:29:30]

**History of hair transplants**

Single follicle implants

- Alan was learning this in the mid-1990s
- Instead of a plug, or a punch, or a four millimeter biopsy of skin, they were cutting down and dissecting, or getting down to literally a one hair follicle graft
- If you angle and orient that appropriately in the right position in the scalp, the result looks natural
- They can’t be put in a row, or perpendicularly in the skin
- You have to angle them, but there are ways to work with single follicle implants, to make your end result look a 100% undetectable
- That’s why that guy went from NY to Toronto (mentioned earlier) to see [Dr. David Seager](https://www.seagerhairtransplant.com/choose-seager/dr-seager/)

Linear harvesting

- Back then (and unfortunately some still now), doctors did linear harvesting
- It was a linear graft from ear to ear which means it left a big line scar

![](https://peterattiamd.com/wp-content/uploads/2019/03/strip-scar.png)

**Figure 7. Scar resulting from linear/strip harvesting.** Image credit: [hairsite.com](https://forum.hairsite.com/t/patient-ssp-a-complete-strip-scar-camouflage-forhair-dr-cole/27760)

How long did this single follicle, linear harvest, procedure take?

- In the 1990s, Alan moved 2,000-3,000 grafts in a single day for those patients
- He did that early on in his own practice, as well
- And used a linear harvest
- Up to 5 technicians working simultaneously dissecting follicles using stereoscopic magnification
- You can’t sterilize the scalp, but the good news is the scalp is very much immune to severe infection
- Single strip, ear to ear
- They ended up with some wide scars
- Alan helped pioneer techniques to reduce the size of the scar but he couldn’t completely avoid it

**New surgical technique:** [**Follicular unit extraction**](https://en.wikipedia.org/wiki/Follicular_unit_extraction)

![](https://peterattiamd.com/wp-content/uploads/2019/03/strip-vs-FUE.jpg)

**Figure 8. Strip harvesting vs. FUE.** Image credit: [hair-implants.net](https://hair-implants.net/history-and-types-of-hair-transplantation/)

- Alan adopted FUE at a very early stage of the game (late 90s)
- FUE is the use of a very tiny punch (~ 1 millimeter, smaller than tip of a pen)
- One harvest of an individual follicular unit yields two or three hairs each
- So the graft comes out of the scalp basically ready without a scalpel and without stitches

Early days of FUE

- Very difficult
- Alan designed the first manual hand-turned instrument available to physicians to be able to do this procedure⇒ [The Bauman MINDEX](https://www.georgetiemann.com/layout.asp?include=browse&cat1=2383&cat2=40528&cat3=40941)
- Very slow procedure
- They weren’t very efficient, they weren’t very accurate
- But what we learned through many, many years of time on tissue, applying this kind of technique, eventually, we got to a point where it became a viable procedure

Today

- Now you can move a lot of hair
- and not leave someone with a disfiguring scar
- It also gives them much more flexibility in hairstyling
- Is anyone still doing large scars?
- Many of the large national clinics that you see on late night infomercials, still do linear harvesting
- And many of my colleagues here, in the US, still prefer to do a linear harvest rather than FUE
  - Why?? ⇒ *“They’re going to say, ‘Oh, well, we get a lot more hair this way. It’s a lot more efficient, I don’t have to buy any expensive equipment to do this. I don’t have to learn any new skills.’”*

![](https://peterattiamd.com/wp-content/uploads/2019/03/smartgraft.jpg)

**Figure 9. Dr. Bauman performing FUE with the SmartGraft tool.**

⇒ Describing a big case with a lot of harvesting…

- So we’ve done very, very large cases, all in a single day
- But today, we would really prefer to do anything over 2,000 graphs in two consecutive days
- We find it a lot more comfortable for the patient, it’s a lot more comfortable in the office for the staff, and our harvest rates, and our harvest quality is much, much more improved than trying to do a marathon
- Large harvest can be up to 5,000 grafts
- And if someone is totally bald on their crown it may take 8,000-9,000 grafts (like Alan’s father)

![](https://peterattiamd.com/wp-content/uploads/2019/03/FUE-1024x512.jpeg)

**Figure 10. Lack of scarring from an FUE procedure.**

**Harvesting hair from the body**

When a person doesn’t have enough hair left on their head to harvest for a transplant, body hair can be harvested and used on the head

Beard hair

- Some people have thicker beard hair than their scalp
- Some have thinner beard hair than their scalp
- Some have curlier, coarser hair on their beard (most common)
- “So we’re not going to put your beard at the frontal hairline, it’s going to be used as filler”

The problem with body hair…

- In general, the farther away from the scalp, the follicles spend less time in the *growing phase*
- For example, of 10 follicles from the body, the chest, maybe only 5 of them are growing at any given time
- Beard is good for a male and for covering a scar

**Hair transplants in women**

- Less volume to cover, generally (long hair covers more space and female pattern baldness is less empty on the crown of the heat)

⇒ Different problems in women…

- Can’t give her a really short hair cut (like a man typically is okay with)
- So if you need to move a lot of hair for a female patient, it needs to be done in steps and stages
- So there’s a couple of ways to approach the donor area in women, that would be like shaving a tiny, little strip
- We may trim a couple of hairs, let’s say one out of every 10 or 20 hairs, and then go after those hair follicles the next day, so there’s no shaving whatsoever

⇒ Hairline in women…

- Many women have receding hairlines around their temples
- The temples part of the hairline is the most common area that we transplant in women
- Lowering the hairline on the forehead:
  - very easy to do transplantation, to fix a high hairline
  - Doesn’t involve cutting with a scalpel, or stitches, or a prolonged recovery, or risk of invasive surgery

![](https://peterattiamd.com/wp-content/uploads/2019/03/female-transplant-hairline-1024x512.jpg)

**Figure 11. Female hair transplant patient showing new hairline.**

![](https://peterattiamd.com/wp-content/uploads/2019/03/male-transplant-2-1024x760.jpg)

**Figure 12. Male hair transplant patient.**

## Risks involved with a hair transplant procedure [1:44:00]

**What are the biggest risks of this procedure?**

- No risk of bleeding and infection… “bleeding is a non-issue”
- Worst infection is generally just a few pimples

*Main concern:*

- “The real risk comes down to that you’re simply not happy with the result, and so again, it all comes down to the consultation process.”
- Doctors have to be very, very clear about what’s possible and what’s not…“I can’t put back a full head of dense hair for you, but I can make you look like you have a full head of hair.”

> “After 8,000 surgeries, I can tell you with very, very good confidence, what’s possible, and what’s not, and what it will take to get there.”

For example, Alan’s father…

- His father was completely bald on the crown of his head
- He now looks 20 years younger, but he will never will have that density that he had

**The best approach is a team approach**

*After a transplant…*

- The patient needs to protect the existing hair
- “Because in order to get the best results, there has to be a good amount of buy-in and partnership with what we do and what we recommend. I can tell you what kind of therapies, and treatments, and such that are going to keep your hair growing strong, but you have to do that work.”

## Is a donor hair susceptible to the forces of the implant site that caused the hair loss? Can a hair follicle grow anywhere on the body? [1:47:45]

*When you move a donor hair from one area (the back of the head, for example), and move it to the crown of the head as a transplant. . .*

*⇒ Is that donor hair now susceptible to the DHT forces that lead to hair loss in that area?*

*⇒ Or, does the donor hair bring with it its genetic pattern from it’s donor site?*

Alan:

⇒ “The way that I would explain that to patients is . . .”

- How long the follicles stay in the growth phase has a lot to do with where those follicles come from
- *But there is some* ***local effect***: A colleague did an experiment where he [moved a follicle to different places in the body and it grew to different lengths](https://www.ishrs.org/wp-content/uploads/2018/01/Forum_16_2.pdf) depending on where it is now located
- “What we do say, and especially true for women, where sometimes they can have a more diffuse hair loss problem because not necessarily all androgen dependent. . .we say that those hairs are *relatively* permanent.”

Can hair grow anywhere on the body?

- As an experiment, Alan implanted a follicle on the palm of someone’s hand
- A prankster on YouTube named [nalts](https://www.youtube.com/user/nalts) had some [hair follicles implanted into the palm of his hand](https://www.youtube.com/watch?v=LnaHmjoHG1Q), during his last hair transplant procedure, and it grew fine

How is this possible?

- The hair follicle is a self-determining organ
- Anywhere that you have a blood flow, it will grow because all it needs is energy, it needs the oxygen, it needs the nutrients
- For example…
  - If you have a non-healing wound on the side of your leg (a diabetic ulcer)
  - You can implant follicles into that area, and those follicles are so metabolically active, that they will actually secrete the growth factors, demand more blood flow, vascular neogenesis will occur, and the wound healing will be accelerated and enhanced by placing hair follicles into that non-healing wound
- The population of cells within the hair follicle are among the most highest metabolically active cell populations in your body (part of the reason why chemotherapy knocks them out)

## Age appropriate procedures, how far the field has come, and why Alan loves his work [1:51:45]

- You’re born with about 100,000-150,000 hair follicles
- And you can lose all the hair on top of your head and make it look full with strategic procedure with only 10,000 grafts (20,000-30,000 hair follicles)

Age appropriate procedures:

- We’re not going to recapitulate a teenager hairline
- Age appropriate matters, so the recession of the hairline that’s going to look normal and natural
- That’s where some of the nuance is
- The discussion between our patients who are maybe in their 20s who want to look like they did in their teenage years, versus patients who may be a little bit more mature in their 30s or 40s
- So the idea is to design something that looks normal and natural, as they go through the process

![](https://peterattiamd.com/wp-content/uploads/2019/03/male-hair-transplant-1024x683.jpg)

**Figure 13. Age appropriate hairline of a transplant patient.**

How far the field has come:

“It’s incredible how quickly things have changed in hair transplantation from, whether it be linear harvesting to follicular unit extraction, to the use of cellular therapy, PRP, and other things like low-level laser therapy and compounded medications to attack the hair follicle. And from all sides, and all different ways, and all different modalities, to help our patients really grow better hair, and look great, and feel great.”

**Why Alan loves his work:**

> “I mean, that’s what it’s all about, right, it comes down to the emotion. When you look in the mirror and you see that hairline growing back in, patient after patient, they say, ‘This is amazing. This is a miracle. This is like I would never thought I would see my hairline again. I never thought I’d cover that bald spot, except with a hat.’ I mean, that’s the exciting thing that keeps me going every day.”

§

## Selected Links / Related Material

**The Whipple procedure**: [Pancreaticoduodenectomy](https://en.wikipedia.org/wiki/Pancreaticoduodenectomy) | (wikipedia.org) [15:15]

**100 million Americans are suffering from some form of hair loss according to**: [American Hair Loss Association](https://americanhairloss.org/) | (americanhariloss.org) [16:00]

**20% of men in their 20s, 30% of men in their 30s, 40% of men in their 40s have visible signs of hair loss**: [Prevalence of male pattern hair loss in 18-49 year old men.](https://www.ncbi.nlm.nih.gov/pubmed/9865198) (Rhones et al., 1998) [19:30]

**Male hair loss is 98-99% is genetically determined**: [GWAS for male-pattern baldness identifies 71 susceptibility loci explaining 38% of the risk.](https://www.ncbi.nlm.nih.gov/pubmed/29146897) (Pirastu et al., 2017) [20:15]

**Studies looking at genes that determine hair loss and the different hair qualities**: [20:30]

- **Male hair loss 16 new genes**: [Hunting the genes in male-pattern alopecia: how important are they, how close are we and what will they tell us?](https://www.ncbi.nlm.nih.gov/pubmed/26843402) (Heilmann-Heimbach et al., 2016)
- **Blonde hair is associated with over 200 genes**: [Genome-wide study of hair colour in UK Biobank explains most of the SNP heritability.](https://www.ncbi.nlm.nih.gov/pubmed/30531825)  [20:30]

**Men put on finasteride, about a milligram a day, have a 90% chance of looking the same or better  5 years later**: [Progression of hair loss in men with androgenetic alopecia (male pattern hair loss): long-term (5-year) controlled observational data in placebo-treated patients.](https://www.ncbi.nlm.nih.gov/pubmed/18573713) (Kaufman et al., 2008) [26:45]

**Finasteride does not increase high-grade prostate cancer**: [Finasteride does not increase the risk of high-grade prostate cancer: a bias-adjusted modeling approach.](https://www.ncbi.nlm.nih.gov/pubmed/19138953) (Redman et al., 2008)  [27:45]

**How minoxidil went from a blood pressure drug to hair loss drug**: [How minoxidil was transformed from an antihypertensive to hair-loss drug](https://www.pharmaceutical-journal.com/news-and-analysis/how-minoxidil-was-transformed-from-an-antihypertensive-to-hair-loss-drug/11080942.article?firstPass=false) | Jenny Bryan ([pharmaceutical-journal.com](https://pharmaceutical-journal.com)) [30:00]

**People on oral doses of minoxidil for hypertension were seeing hair growth in many places like their knuckles**: [Combined therapy with vasodilator drugs and beta-adrenergic blockade in hypertension. A comparative study of minoxidil and hydralazine.](https://www.ncbi.nlm.nih.gov/pubmed/4401051) (Gottlieb et al., 1972) [30:45]

**The story of Viagra and how it was originally tried as a treatment for hypertension**: [VIAGRA TURNS 20: THE HISTORY OF THE “LITTLE BLUE PILL”](https://www.getroman.com/romanhood/history-viagra/) | Lisa Beebe (getromen.com) [31:15]

**Rogaine is consistently ranked as the most disappointing hair loss treatment ever by Consumer Reports**: [Survey: Most Baldness Treatments Don’t Work](https://www.webmd.com/skin-problems-and-treatments/hair-loss/news/20100406/survey-most-baldness-treatments-dont-work#1) | Denise Mann (webmd.com) [32:30]

**More sophisticated formulations of minoxidil**: [Compounded Minoxidil Formula 82M](https://www.baumanmedical.com/product/minoxidil-formula-82m/) | (baumanmedical.com) [33:00]

**There is about a 50% success rate when you apply finasteride in postmenopausal women with hair loss**: [Finasteride treatment of patterned hair loss in normoandrogenic postmenopausal women.](https://www.ncbi.nlm.nih.gov/pubmed/15459533) (Trüeb et al., 2004) [33:45]

**More studies on finasteride in women**: [33:45]

- [Clinical efficacy of oral administration of finasteride at a dose of 2.5 mg/day in women with female pattern hair loss.](https://www.ncbi.nlm.nih.gov/pubmed/29464847) (Won et al., 2018)
- [Lack of efficacy of finasteride in postmenopausal women with androgenetic alopecia.](https://www.ncbi.nlm.nih.gov/pubmed/11050579) (Price et al., 2000)

**Biotin for horses with hoof issues**: [Effect of supplementary dietary biotin on hoof growth and hoof growth rate in ponies: a controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/9932094) (Reilly et al. 1998) [40:45]

**Humans on biotin (10,000 micrograms) will see their nails getting stronger and we know this becuase of hair tensile strength studies**: [A Novel Multi-Targeting Approach to Treating Hair Loss, Using Standardized Nutraceuticals](https://jddonline.com/articles/dermatology/S1545961617S0141X/5) (Farris et al., 2017)  [41:15]

**Dandruff and yeast overgrowths in the scalp that show inflammation and the over-activity of those populations are out of control, then you can get a detrimental effect on hair growth**: [Dandruff and seborrheic dermatitis adversely affect hair quality.](https://www.ncbi.nlm.nih.gov/pubmed/19467978) (Sinclair et al., 2009) [51:30]

**The mechanism of action of low-level laser therapy**: [Proposed Mechanisms of Photobiomodulation or Low-Level Light Therapy.](https://www.ncbi.nlm.nih.gov/pubmed/28070154) (de Freitas and Hamblin, 2016) [59:45]

**The mechanism of minoxidil**: [Human hair follicles contain two forms of ATP-sensitive potassium channels, only one of which is sensitive to minoxidil.](https://www.ncbi.nlm.nih.gov/pubmed/18258787) (Shorter et al., 2008)[1:01:15]

**The 3 phases of hair growth**: [The Hair Growth Cycle](https://www.philipkingsley.com/hair-guide/hair-science/hair-growth-cycle) | (philipkingsley.com) [1:01:15]

**Growing/resting Anagen/Telogen ratios in normal and abnormal scalp**: [Follicular density and ratios in scarring and nonscarring alopecia.](https://www.ncbi.nlm.nih.gov/pubmed/23435361) (Horenstein and Bacheler, 2008) [1:01:15]

**Good clinical data that shows that the combination of minoxidil plus tretinoin improves the hair growth**: [Efficacy of 5% minoxidil versus combined 5% minoxidil and 0.01% tretinoin for male pattern hair loss: a randomized, double-blind, comparative clinical trial.](https://www.ncbi.nlm.nih.gov/pubmed/17902730) (Shin et al., 2007) [1:04:15]

**Study at the University of Miami that looked at the micro-inflammation at the level of the hair follicle in which Alan donated a number of follicles from hair transplant patients**: [Caspase-1 level is higher in the scalp in androgenetic alopecia.](https://www.ncbi.nlm.nih.gov/pubmed/?term=bauman+inflammazome) (de Rivero Vaccari et al., 2012) [1:05:15]

**Laser therapy for Alzheimer’s disease that works by hitting cytochrome c oxidase**: [#38 – Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer’s disease treatment and prevention – is AD actually a vascular and metabolic disease?](https://peterattiamd.com/franciscogonzalezlima/) | Peter Attia (peterattiamd.com) [1:06:30]

**The laser cap by CapillusRx**: [What is the CapillusRx Laser Therapy Cap?](https://www.baumanmedical.com/qa/capillusrx-laser-therapy-cap/) | (baumanmedical.com) [1:11:30]

**PRP for wound healing**: [[Platelet-rich plasma for treating acute wounds: a meta-analysis].](https://www.ncbi.nlm.nih.gov/pubmed/25331465) (Wang et al., 2014) [1:16:30]

**PRP mechanism of action on hair growth**: [A Mechanistic Model of Platelet-Rich Plasma Treatment for Androgenetic Alopecia.](https://www.ncbi.nlm.nih.gov/pubmed/27631460) (Gupta et al., 2016) [1:22:30]

**PRP sweet spot**: [Identification of an optimal concentration of platelet gel for promoting angiogenesis in human endothelial cells.](https://www.ncbi.nlm.nih.gov/pubmed/19170984) (Giusti et al., 2009) [1:22:45]

![](https://peterattiamd.com/wp-content/uploads/2019/03/PRP-2.jpg)

**From the48th Annual Meeting of the Orthopedic Research Society**: Platelet Concentrate and MSC stem cell migration (Haynesworth et al, 2002)

![](https://peterattiamd.com/wp-content/uploads/2019/03/PRP-1.jpg)**Top hernia repair clinic**: [Shouldice Clinic](https://www.shouldice.com/) ([shouldice.com](https://www.shouldice.com/)) [1:30:45]

**The first manual hand-turned instrument available to physicians to be able to FUE**: [The Bauman MINDEX](https://www.georgetiemann.com/layout.asp?include=browse&cat1=2383&cat2=40528&cat3=40941) | (georgetiemann.com) [1:35:45]

**Some evidence of recipient area control**: [Hair transplants. Long-term results and new advances.](https://www.ncbi.nlm.nih.gov/pubmed/4922433) (Orentreich, 1970) [1:48:45]

**Researcher who took a hair follicle from one place on his body, and put it into another place, and then moved that follicle someplace else, and tracked those lengths of time that it spent in the growing phase**: [Long-term Evaluation of Hair Transplantation into Various Recipient Sites](https://www.ishrs.org/wp-content/uploads/2018/01/Forum_16_2.pdf) | Sungjoo “Tommy” Hwang, MD, PhD Seoul, South Korea ([ishrs.org](https://ishrs.org/)) [1:49:00]

**The guy who grew hair on his palm and put it on YouTube**: [Nalts Hair Today – NeoGraft FUE Transplant Results](https://www.youtube.com/watch?v=LnaHmjoHG1Q) | Alan Bauman (youtube.com) [1:49:45]

§

## People Mentioned

- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) (full head of hair even at the end of this long life) [44:30]
- [Dr. Michael Hamblin](https://www.dfhcc.harvard.edu/insider/member-detail/member/michael-r-hamblin-phd/) (studied the mechanism of action of low-level laser therapy) [59:45]
- [Dr. David Seager](https://www.seagerhairtransplant.com/choose-seager/dr-seager/) (early pioneer in hair transplants) [1:31:45]
- [nalts](https://www.youtube.com/user/nalts) (The guy who grew hair on his palm and [put it on YouTube](https://www.youtube.com/watch?v=LnaHmjoHG1Q)) [1:49:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/03/bio-image-500x500.jpg)

##### Alan Bauman, M.D.

Alan J. Bauman, MD, ABHRS, IAHRS, FISHRS is a full-time hair transplant surgeon who founded his medical practice in Boca Raton, Florida in 1997 and has treated nearly 20,000 patients and performed over 8,000 hair transplant surgeries to date. His compassionate, patient-centered philosophy and individualized artistic approach to protecting, enhancing and restoring the appearance and health of the hair and scalp is what sets him apart from non-specialists and other practitioners. Dr. Bauman moved to Boca Raton with his wife Karen after receiving his M.D. degree from New York Medical College, doing his surgical residency training at Mt. Sinai Medical Center and Beth Israel Medical Center in Manhattan, and completing his hair transplant Fellowship training in New York.

Dr. Bauman is one of only approximately 200 physicians worldwide to achieve certification from the esteemed American and International Board of Hair Restoration Surgery (ABHRS), be an accepted member of the International Alliance of Hair Restoration Surgeons (IAHRS) and also recommended by the American Hair Loss Association. Dr. Bauman achieved the coveted Fellow status within the International Society of Hair Restoration Surgery (FISHRS) and is a frequently invited faculty member at numerous international scientific meetings, live surgery workshops, and major beauty industry events.

Dr. Bauman is the first-ever hair transplant surgeon to be formally accepted as an Intercoiffure America/Canada Industry Partner; Intercoiffure is the most powerful and influential organization in the hairdressing industry. He is also an Advisory Board Member for the World Trichology Society and an active Trustee-Level Member of the Greater Boca Raton Chamber of Commerce; he credits part of his early and ongoing success thanks to his involvement in local and national professional networks. He is also the author of numerous articles and textbook chapters on the science of hair care and hair transplantation, including eyelash transplant surgery, and has been extensively featured in the world’s leading mass media as a medical expert and successful early-adopter and pioneer of some of the most advanced technologies in the effective treatment of hair loss. Dr. Bauman’s international reputation and his exceptional team at Bauman Medical attracts patients from all corners of the globe for hair loss diagnosis and the latest and most effective hair restoration treatments and procedures.

This past year, Dr. Bauman was named both a “Top 5 Transformational CEO” and one of “10 CEOs Transforming Healthcare in America” in Forbes, as well as voted North America’s “#1 Top Hair Restoration Surgeon” by Aesthetic Everything. His accessible and interactive presence on social media has garnered millions of video views on YouTube and thousands of subscribers, connections and followers on the most popular platforms. A recent Live Hair Transplant Surgery broadcast directly from the procedure room in his Boca Raton office gained over 100,000 simultaneous views from more than 20 countries. Dr. Bauman also has been a member of the highly respected Pantene Hair Research Institute, a global network of leading hair experts focused on the advancement of hair science, technologies, and products. He is currently serving as an inaugural Luminary Board Member for Church & Dwight (NYSE: CHD).

In addition to serving as the CEO of Bauman Medical and teaching and consulting internationally, Dr. Bauman personally treats patients at his nearly 12,000 sq. ft. Bauman Medical Hair Transplant and Hair Loss Treatment Center in beautiful oceanside Boca Raton, Florida. [[baumanmedical.com](https://www.baumanmedical.com/about-dr-alan-bauman-hair-transplant-surgeon/)]

Instagram: [@dralanbauman](https://www.instagram.com/dralanbauman/)

Twitter: [@dralanbauman](https://twitter.com/dralanbauman?lang=en)

YouTube: [Dr Alan Bauman](https://www.youtube.com/channel/UC76IfFEFOt6jB2dFv9gcXNQ)

Website: [baumanmedical.com](https://www.baumanmedical.com/)