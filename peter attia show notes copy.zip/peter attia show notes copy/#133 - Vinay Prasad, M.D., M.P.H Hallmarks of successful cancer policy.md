# #133 – Vinay Prasad, M.D., M.P.H: Hallmarks of successful cancer policy

**Source:** [https://peterattiamd.com/vinayprasad/](https://peterattiamd.com/vinayprasad/)

---

Vinay Prasad is a practicing hematologist-oncologist who doubles as a “meta-researcher,” studying the quality of medical evidence, health policy, and clinical trials. In this episode, Vinay discusses the differences in clinical treatment from the existing medical evidence, often leading to useless, or even harmful, outcomes for patients. With a focus in oncology, he takes a deep dive into the field’s structural problems, which include the disconnect between progress and funding, drug costs, and financial conflicts of interest. He concludes with his “six hallmarks of successful cancer policy” as a potential roadmap to sustained progress against cancer and a way to avoid repeating the policy and practice mistakes of the past.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/vinayprasad/the_Drive_public.png)

Play

#133 - Vinay Prasad, M.D., M.P.H: Hallmarks of successful cancer policy

#133 - Vinay Prasad, M.D., M.P.H: Hallmarks of successful cancer policy

1x15s30s

0:002:12:04

## We discuss:

- Vinay’s background and unique perspective [3:15];
- Medical reversal—the disconnect between research findings and clinical applications in medicine [10:15];
- The uniquely challenging field of oncology [22:45];
- The importance of bedside manner with cancer patients [30:00];
- Structural problems in oncology—Problem #1: Huge costs for small improvements [37:00];
- Structural problems in oncology—Problem #2: Medical reversal—when medical practices are adopted based on low levels of evidence [40:15];
- Structural problems in oncology—Problem #3: Slow progress in cancer research (despite all the hype and propaganda) [45:00];
- Structural problems in oncology—Problem #4: The burden of payment is not matched with those making treatment decisions [54:45];
- “No-brainer” moves in oncology [1:06:45];
- “Fool’s gold” treatments in oncology [1:09:30];
- The six hallmarks of successful cancer policy [1:16:00];
- Cancer policy hallmark #1: Independence [1:18:00];
- Cancer policy hallmark #2: Evidence [1:28:15];
- Cancer policy hallmark #3: Relevance [1:31:30];
- Cancer policy hallmark #4: Affordability [1:32:00];
- Cancer policy hallmark #5: Possibility [1:47:00];
- Cancer policy hallmark #6: Agenda [1:52:00];
- Tumor genome sequencing and liquid biopsies [1:54:30];
- Vinay’s clinical philosophy, being skeptical without being too contrarian, and practicing medicine without perfect information [2:03:30]; and
- More.

## Show Notes

## Vinay’s background and unique perspective [3:15]

Currently

- Practicing hematologist and oncologist
- Associate Professor of Medicine at UC San Francisco
- In addition to clinical care, does research on health policy, clinical trials, and decision-making
  - “meta researcher:” studies the quality of medical evidence
  - Author of over 250 academic articles and two books: [Ending Medical Reversal](https://www.amazon.com/Ending-Medical-Reversal-Improving-Outcomes-dp-1421417723/dp/1421417723/ref=mt_other?_encoding=UTF8&me=&qid=1600822907) (2015) and [Malignant](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635/ref=pd_bxgy_img_2/147-2075134-8416100?_encoding=UTF8&pd_rd_i=1421437635&pd_rd_r=511204a1-bb7e-4bdf-8dfb-09de1a7237da&pd_rd_w=6y6KF&pd_rd_wg=1LcTU&pf_rd_p=ce6c479b-ef53-49a6-845b-bbbf35c28dd3&pf_rd_r=4XA8K85FJXZF35JEC2AV&psc=1&refRID=4XA8K85FJXZF35JEC2AV) (2020)
- Recently started at UC San Francisco, where Peter went to get trauma training while he was a med student at Stanford

Background and unique perspective

- Vinay brings a unique perspective as his path to medicine wasn’t traditional
  - He wasn’t a premed student and was a philosophy major in college
  - Planned to major in science at Michigan State
  - But took a philosophy course in college, prof reached out, and chose that as his major
  - Not certain about his path until later in college
- Went to med school at the U of Chicago
  - Peter says that his med school, Stanford, was “very relaxed” but suspects Chicago wasn’t
  - Vinay says Chicago had a “really gritty, city hospital feel”
  - “A lot of the faculty had trained on the east coast, and I think it really had that east coast mentality. It was an intense place. “
  - “I remember yelling in the operating room was common, throwing things was common, people getting chewed out was common.”

The medical school experience

- There is a relevant book called [Forgive and Remember](https://www.amazon.com/Forgive-Remember-Managing-Medical-Failure/dp/0226066789) written by a sociologist from Penn, [Charles Bosk](https://www.inquirer.com/obituaries/philadelphia-inquirer-obituaries-obituary-charles-bosk-penn-sociologist-reducing-medical-errors-20200909.html). Bosk spent 18 months late ’70s / early ’80s with a group of surgical residents to understand the culture of surgical training; the place not named but was likely Chicago, very toxic environment
  - Peter says, “There’s a real east coast / west coast divide in medical education. … when I applied to my residency on the east coast at Hopkins, there was a real view that no one from Stanford could go there and do general surgery because the last guy who had gone and done general surgery who had come from Stanford had committed suicide.”
- Vinay did not really like med school, especially the first two years in the classroom where the focus was on memorization.
  - “Those first two years I found it really demoralizing. I wasn’t somebody who was used to memorizing lots of things in a disconnected way, I was somebody who liked to think about things and think about them rigorously.”
  - “It was only when third year started and I was there on the wards, and I was on internal medicine first as my clerkship, and I had some really great and influential practitioners of medicine who would teach me how they think about cases, that was when I started to feel okay. That’s the first moment that this felt like the right choice for me.”
- Assumed he’d practice clinical medicine in a private practice

## Medical reversal—the disconnect between research findings and clinical applications in medicine [10:15]

- Vinay finished medical school with the belief that he was going to pursue private practice
- But that started to change in residency where he saw disconnect between clinical situations and research findings:

> ### **“There were things we were doing that were not supported by strong evidence, there were some things that appeared to run counter to the best evidence. It didn’t make a lot of sense to me.” – Vinay Prasad**

This realization began his foray into medical research

- He started doing studies on ineffective practices that had become part of medical culture, termed “medical reversal,” and has [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3238324/) [papers](https://elifesciences.org/articles/45183) about it
- “I got into it from the point of view of a clinician who was struggling to make sense of what was going on around me, and that was really how I fell into research. I didn’t know that research would become my career, but the funny thing about life is you do something long enough and it starts to define you. …Eventually it starts to turn into a career.”

**Stents — An example of medical reversal**

- Some indications are questionable, which is problematic if patients suffer a complication
  - A stent is a little flexible metallic tube that expands and is placed in a coronary artery when there is a blockage
  - In a critical situation, a stent is a transformative, life-saving intervention (an [AST elevation](https://en.wikipedia.org/wiki/Aspartate_transaminase)-related myocardial infarction, a total blockage of the artery)
  - But it can also be used more broadly
- *What about somebody who just has a little bit of narrowing of the arteries and maybe just a touch of angina?*
  - Angina is the reproducible chest pain that comes on when you shovel your driveway or go for a long walk
  - Can’t just extrapolate from a critical situation to a less severe situation
  - But less severe situations are much more common than severe ones, so they are a big driver of market share
- Stents became very popular for chronic stable angina
  - a large, mega randomized control trial called Clinical Outcomes Utilizing Revascularization and Aggressive Drug Evaluation ([COURAGE](https://www.nejm.org/doi/full/10.1056/NEJMoa070829)) asked whether or not stents lower the rate of heart attack or improve longevity
  - for people with chronic stable angina, there was no improvement in survival and no reduction in subsequent myocardial infarction
  - Yet patients receiving stents thought that it was being done to improve survival or to reduce risk of later MIs
  - “There was a disconnect between what patients felt it was for, and what doctors knew it could do.”
- Stents have complications: cardiac arrest occlusion of the stent, a thrombus that forms within this foreign body

> ### **“All things in medicine have some complications, but the question that plagued me was it’s okay to accept the risk of a complication if the procedure has a net benefit, but if the procedure is questionable as it’s being done and the benefit is questionable, you’re just taking risks without any upside.” – Vinay Prasad**

- - This issue motivated Vinay to look deeper and understand why doctors do what they do
- Peter: there are conflicts of interest in medicine, like interventional cardiologists being compensated for the number of stents being placed.
  - “If I were in their situation I’m not sure how I would self-police.”
  - Not bad people but, like all of us, suffer from their own cognitive biases
- In this case, there are two parts to the equation that make stents so seductive
  - 1) patients are happy to have a stent because they believe the doctor has saved or extended their life. They may even believe they feel better
  - 2) Doctors also earn more money for each stent they do
- “When you combine that powerful, psychological stimulus of gratitude with a little bit of financial remuneration, I think that’s the methamphetamine of being a doctor.”
- But then the Percutaneous Coronary Intervention in Stable Angina ([ORBITA](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(17)32714-9/fulltext)) study says that when patients thought they had a stent but didn’t, they actually had the same exercise tolerance improvement on a treadmill test as those who got a stent
  - This can be hard for doctors to accept: it doesn’t fit with their experience or the way they’ve been paid. It becomes very hard to dispel established practices

**Medical reversal beyond just stents**

> ### **“The moment you start to recognize some of the classic research pitfalls, the evidence pitfalls, you … start to see it everywhere.” – Vinay Prasad**

- One theme is “mechanical interventions done to alleviate a subjective symptom” like angina or pain or dyspnea—Studies suggest this is a placebo effect, no better than a [sham intervention](https://en.wikipedia.org/wiki/Sham_surgery)
- Sham interventions not commonly done anymore, but once were
  - For example, with degenerative osteoarthritis of the knee, can do surgery to debride the cartilage, which might get better results than PT or taking ibuprofen. But if you just put scope in but not actually do anything, patients still report feeling better. So it’s not the surgery but the idea that something is being done for them.
  - This has also been shown true for other procedures: injecting polyacrylamide cement into osteoporotic fractures of the vertebra, a couple of shoulder procedures
- Also with stenting chronic stable angina ([ORBITA](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(17)32714-9/fulltext) trial)
- *Peter asks: In ORBITA did they actually cannulate the femoral artery?*
- - They cannulated the artery and performed a diagnostic angiogram
  - But patient had headphones so didn’t know if got stent
  - primary outcome that they’re looking at is the modified [Bruce protocol treadmill exercise](https://en.wikipedia.org/wiki/Bruce_protocol) test
  - The difference was 16 seconds, and it’s not statistically significant, and it’s not clinically meaningful
- Now Vinay is in oncology and hematology and doesn’t get to see other specialties as often

## The uniquely challenging field of oncology [22:45]

- At Chicago, had really good mentors in internal medicine and many students chose it
  - Wanted to have a broad look at the body and think broadly
  - Considered a few other specialties like cardiology and critical care
- Had a great experience with oncologists at Northwestern
  - One was Hidayatullah Munshi, who’s still there on faculty: he knew basic science, clinical trials, and evidence, and also had great a bedside manner
  - Vinay saw them making decisions he thought were “substantive and important” and decided to go into oncology too

*Tell me about your first days as a medical oncology fellow when you’re seeing multiple things (GI cancers, liquid cancers, etc.) again.*

- Vinay went to the National Cancer Institute, it’s a unique and fascinating program
- Internal medicine doesn’t teach you much about oncology—so steep learning curve, new drugs, diseases, genetics.
  - “T*o be honest I probably think that’s one of my favorite years of training, my first year as an oncology fellow. … We were learning 20 new things every day. I thought it was really a terrific and transformational year for m*e.”
- Peter says NCI is a special place: “It’s not hyperbolic to say there’s no place like it on earth. I still remember that first day I stepped foot on that campus as a third year medical student just thinking, how can this place exist? It is so marvelous.”
  - A lot of fundamental work took place there
  - Anyone training in medicine should spend some time there

**The challenge of oncology as a field**

- Oncology is challenging because what we call “cancer” is really very dissimilar diseases
- There is variation even within cancer types
  - Example: non-small cell lung cancer, which itself is a category of lung cancer, can be further divided into categories like [EGFR](https://lcfamerica.org/lung-cancer-info/types-lung-cancer/egfr-mutation/) mutation type, [ALK](https://lcfamerica.org/lung-cancer-info/types-lung-cancer/alk-positive-lung-cancer/) rearrangement type, [RET](https://mc.vanderbilt.edu/ckm/gl/mutation_profiles/pdfopen.php?fnp=lung_cancer/content/RET/Lung_Cancer_and_RET_Fusions.pdf), and [ROS1](https://lcfamerica.org/lung-cancer-info/types-lung-cancer/ros1-positive-lung-cancer/#:~:text=ROS1%20rearrangements%20occur%20in%20approximately,fuses%20with%20a%20nearby%20gene.)
  - We have all these molecular categories, we have RAS, this undruggable target. We have superimposed that with the role of immunotherapy.
- To keep up, Vinay reads an article or two every night, reads [Up to Date](https://www.uptodate.com/home) and looks at the references
  - Still so much he doesn’t know
  - “I once heard somebody say 1963 was the last time a scientist died who knew everything. It’s just impossible to know it all.”
- He sees patients about half the time and bases what he needs to learn off that
  - Start with the patient and work your way outward, he’s still learning 6 years into practice

## The importance of bedside manner with cancer patients [30:00]

- Peter observes that bedside manner is important, but there is tension between how draining medicine is for the doctor and the need to connect with patients

> ### **“I think there is a misconception among many people outside of oncology that oncology is often doom and gloom, and tough situations. … We also have many patients in whom we cure and we have to follow for long-term side effects.” – Vinay Prasad**

**An anecdote to provide some perspective:**

- Vinay tells a story about a senior oncologist who’d been practicing for 30 years talking with a patient he’d seen for more than a decade.  The patient had reached a point where no more could be done for him.
  - “I go into the room and he does what would be the stuff of legend. He’s compassionate, he’s caring, he’s hearing the patient, he’s seeing the patient, he’s keeping a little bit of distance, he’s giving the information he needs to give, but he’s also giving the emotional support he needs to give as well. It’s very hard for me to even describe how he did it. It felt like magic to me as a trainee.” And the patient thanked the doc for taking care of him all of those years.  It was “a rare privilege moment of being a doctor.”
  - Vinay asked doc how he did such a good job with those hard situations, and doc said he tried to get better every year – never allowed himself to become complacent.
- Oncology is not just prescribing the right meds, it’s also being there for your patients – part of what makes field interesting and satisfying
  - Peter worked with a doctor who did not allow residents to say a patient failed the medicine, only that the medicine had failed them
  - Peter’s mentor Steve Rosenberg said, “*Patients who are dying need us more than patients who are living*.”

## Structural problems in oncology—Problem #1: Huge costs for small improvements [37:00]

- One year at the National Oncology Conference everyone was celebrating a new drug
  - Yet, the median survival before drug was about 6 months, and the drug extended it to 11 months but didn’t cure it
  - A non-doctor friend of Vinay’s pointed out how inadequate that was and told him medicine needed to do better than that. Was eye-opening for Vinay
- In 71 consecutively approved drugs for solid cancers, as a [famous study](https://pubmed.ncbi.nlm.nih.gov/25068501/) showed, the average improvement was 2.1 months.
  - And the cost of those meds is 100,000 to $200,000 per year of treatment, need to take it for 8-10 months to get the two-month benefit
- “Why are we spending so much money on these drugs that appear to offer less than what we would want and hope for for our patients? … Why aren’t there fewer, but better drugs coming? What are the sort of structural problems in this space that create a glut of often me-too drugs? … And so that was … one of the core questions that started me on this path.”
- Vinay’s book [Malignant](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635/ref=pd_bxgy_img_2/147-2075134-8416100?_encoding=UTF8&pd_rd_i=1421437635&pd_rd_r=511204a1-bb7e-4bdf-8dfb-09de1a7237da&pd_rd_w=6y6KF&pd_rd_wg=1LcTU&pf_rd_p=ce6c479b-ef53-49a6-845b-bbbf35c28dd3&pf_rd_r=4XA8K85FJXZF35JEC2AV&psc=1&refRID=4XA8K85FJXZF35JEC2AV) is about cancer drug research and policy: “I realized that there’s a story that could be told across all these different domains and that it makes more sense when you tell the whole story. And so that’s why I decided to write that book.”

## Structural problems in oncology—Problem #2: Medical reversal—when medical practices are adopted based on low levels of evidence [40:15]

- Vinay looked at clinical situations that didn’t seem to match the best available evidence
- He and Adam Cifu asked: how many medical practices are adopted based on low levels of evidence, how they were adopted, and what happens if later evidence shows they are not effective?
- They weren’t just replaced by something better, but reversed, so they termed them **medical reversals**: when either doing nothing or doing what had been done in an earlier time was actually better than the current practice
- Led to the book [Ending Medical Reversal](https://www.amazon.com/Ending-Medical-Reversal-Improving-Outcomes-dp-1421417723/dp/1421417723/ref=mt_other?_encoding=UTF8&me=&qid=1600822907)

*Some examples of medical reversal:*

- Hormone therapy
  - Since premenopausal women have low rates of heart CV events but postmenopausal women don’t, maybe estrogen is protecting them and we should give it to postmenopausal women (drug company Wyeth was instrumental in driving prescriptions of hormone replacement therapy)
  - There *seemed* to be a lot of evidence supporting this (basic science and observational studies)
  - But in early 2000s, a randomized controlled trial called the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) randomly assigned postmenopausal women to estrogen supplementation or not. The study was stopped early because of an increase in thromboembolic and cardiovascular events; seemed to do opposite of what it was thought to do
- [Premature ventricular contractions](https://www.mayoclinic.org/diseases-conditions/premature-ventricular-contractions/symptoms-causes/syc-20376757#:~:text=Premature%20ventricular%20contractions%20(PVCs)%20are,skipped%20beat%20in%20your%20chest.) (PVCs)
  - Post MI, EKGs show PVCs, and the more a patient has the more likely they are to have sudden cardiac death. Led to the idea that PVCs could precipitate cardiac arrest.  So gave drugs that suppress PVCs
  - But when they did a randomized trial ([CAST](https://en.wikipedia.org/wiki/Cardiac_Arrhythmia_Suppression_Trial)), it turned out that the drug increased the risk of dying. Docs didn’t even want to do trial because they thought it unethical not to give some patients the drug.  (These studies have led to the abandonment primarily of [Class Ic antiarrhythmic agents](https://en.wikipedia.org/wiki/Antiarrhythmic_agent) like flecainide)
  - The advocates of this treatment were backed up by “plausible pathophysiology” and a retrospective observational story, but it was still wrong.
- This made Vinay wonder if it had happened elsewhere

> ### **“We started investigating. Now we have lists of hundreds of items. They span everything from ways in which we screen patients, ways in which we test patients, drugs we give patients, procedures we do on patients, surgeries you do on patients. It really spans the gamut. There have been these medical reversals across broad domains of medicine. They are quite common.” – Vinay Prasad**

- Peter wants to point out that “the [WHI](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) is arguably the worst study that’s ever been done” and that it can be challenging to figure out whether your own patient is represented in a study population. The biggest WHI headline was that HRT increased breast cancer, which later turned out not to be a correct conclusion.  It also raised questions about the difference between relative risk and absolute risk. Now back to oncology …
  - Here’s a [paper](https://www.tandfonline.com/doi/abs/10.1080/13697137.2018.1514008?journalCode=icmt20) indicating that WHI’s initial conclusions about breast cancer had been wrong

## Structural problems in oncology—Problem #3: Slow progress in cancer research (despite all the hype and propaganda) [45:00]

- Peter tells his patients that there are three broad pillars of disease: 1) cardiovascular and cerebrovascular disease, 2) cancer, and 3) neurodegenerative disease.
  - The foundation of metabolic disease (hyperinsulinemia, insulin resistance, fatty liver disease, type 2 diabetes) makes these three disease processes get a lot worse
- Peter points out that we’ve really only had any success against CVD
  - you have a much better chance of surviving a heart attack now that you did in 1960 (advanced cardiac life support, better drugs to lower cholesterol, lower blood pressure, stents in patients who are having an MI or immediately after). We now have a greater pathophysiologic understanding of it.
  - But not much improvement in metastatic breast cancer or Alzheimer’s disease, which is hard for people to understand especially given the resources out into it
- Vinay says hundreds of billions of dollars have been invested in cancer research. We’ve made great progress on a few diseases like [chronic myeloid leukemia](https://www.cancer.org/cancer/chronic-myeloid-leukemia/about/what-is-cml.html) (CML), but the average patient still has “a very grave prognosis.”
- Peter remembers going to the American Society of Clinical Oncology (ASCO) conference and seeing a presentation about a drug that increased survival for about 20 days – at a cost of $38,000 for the extra days.  How do we decide if that’s an appropriate cost?
  - First, the .7 months / 20 days applies to the study subjects, who are not average cancer patients.  They tend to be younger and have fewer comorbidities (diabetes, obesity, CVD, kidney disease, etc.)
    - “One of my colleagues describes clinical trial patients as somebody who could run a marathon who also happens to have cancer.”
    - They can handle side effects better than the average cancer patient.
  - And yet, even in these individuals, the drug only gives them .7 months longer.  A frail patient who can’t handle the side effects won’t even get that much.  Some empirical studies question whether the average American gets any benefit at all from these drugs
- [Sorafenib](https://en.wikipedia.org/wiki/Sorafenib#:~:text=Sorafenib%20(co%2Ddeveloped%20and%20co,and%20radioactive%20iodine%20resistant%20advanced), a drug for liver cancer patients for whom surgery isn’t an option
  - It has a median survival of 11 months compared to 8 months with a placebo but got a standing ovation at a national meeting
  - Researchers who looked at Medicare data sets [found](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5016063/) that the median survival for Medicare (Americans over 65) taking sorafenib was 3 months
  - “So in other words, in the real world, somebody taking the drug that improves survival lives 50% as long as the person taking a sugar pill in the trial, which just shows you the Grand Canyon of difference between real world patients and clinical trial patients.”
  - Benefits evaporate when use them in board populations
- Peter refers to his [recent interview](https://peterattiamd.com/azraraza/) with Azra Raza, who made the same point
  - Clinical trials are the best case scenario “by a log order” based on patient selection
  - Drug companies are trying to get the drug approved, so they are motivated to pick the healthiest patients
  - Your patient is not likely to be nearly as healthy as the trial subjects: won’t tolerate the drug as well or have the same “physiologic reserve”
- Vinay says “we can’t blame the tiger for being the tiger” – pharma needs to recoup their R&D costs
  - If the product is successful they will earn, on average, $12 billion in the next 14 years (with a p of 0.049. But if p = 0.051, you lose a few hundred million dollars, your outlay on the drug
  - They’re going to handpick patients and test against drugs that might be the weakest and not what is typically prescribed. Some trial patients end up getting substandard care

## Structural problems in oncology—Problem #4: The burden of payment is not matched with those making treatment decisions [54:45]

- In med school, Peter read about the luminary oncologist [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman)‘s idea to cut off the blood supply to a tumor.  This was a new idea when he proposed it; the usual treatment was surgery, chemo, and/or radiation
  - [Steve Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg) and [Jim Allison](https://en.wikipedia.org/wiki/James_P._Allison) were also working on immunotherapy ideas
  - Judah eventually proposed using anti-VEGF (blood growth factor) compounds
- [Bevacizumab](https://www.drugs.com/mtm/bevacizumab.html) (Avastin) was the first such drug approved (for colon cancer)
  - Cost about $100K for a year
  - [Hurwitz paper](https://pubmed.ncbi.nlm.nih.gov/15175435/) originally led to approval; increased survival by a **couple of months on average**
  - Some countries (like the UK) wouldn’t pay for it because didn’t meet their payment threshold guidelines
    - quality adjusted life year (QALY) – was about 100K pounds per QALY then
    - In US, insurance companies (government or employer) paid
  - When you’re a clinician you do what the patient wants, base toxicity on whether it’s worth it to the patient
    - Might be different than what a national policy should be
  - “***Every dollar spent on Avastin is a dollar not spent on a lot of healthcare interventions that may have better bang for your buck***.”
    - Avastin for 100 people might equal getting 100K people to take their lisinopril or hydrochlorothiazide (blood pressure medications) more religiously
    - They might exceed the benefit of Avastin in terms of life years added “by an order of magnitude”
- When we pay for our own healthcare, we should get what we want.  But if society pays, consider the common good because healthcare is considered a human right
  - This can mean making tough decisions… E.g., Instead of giving cancer drug that extends survival for a few months to 20 people, give pregnant women access to something that might benefit future generations
- All countries have to grapple with the question of how to spend limited resources
  - But other countries have open discussion about rationing

> ### “In the US we do ration, but we ration in a way you don’t see because some people don’t get anything. … And so we rationed by discriminating against people. That’s a different type of rationing. It’s cruel and irrational, but it is rationing nonetheless.” – Vinay Prasad

- If people spent their money as they chose, might not choose this drug for themselves if it meant more money for their kids, but they could choose it [(00:59:46]
- If spending society’s money, more obligation to make sure you’re getting a clear benefit

*How does Vinay’s philosophy background shape his thinking on these issues?*

- Vinay often uses utilitarianism – doing greatest good for the greatest number of people – as a framework. This approach would suggest not paying for expensive cancer drugs with minimal lifespan extension
  - People criticize the UK for having worse cancer outcomes than the US (may be overstated), but they have better life expectancy. Care might be better there
  - Some people might value end-of-life care regardless of how it impacts others
- [Deontological](https://en.wikipedia.org/wiki/Deontological_ethics) perspective: saying don’t use Avastin is not saying don’t treat the patient – there are other options
- Peter has an American friend who lives in Saudi Arabia.  He spends summers in the US but leaves on the AC in his apartment in Riyadh all summer. About ten years ago it only cost him $4/month for all the extra energy because it’s subsidized by the government. He would never do that in the US
  - Peter says “when we don’t have skin in the game, we are incapable of making rational cost decisions.”
  - You chose very differently when you only have to pay a fraction of the price
- The question is **how to reconcile doctor and patients not having skin in the game with the fact that costs of these cancer drugs are so high** when it’s not clear how to make them have any
  - if you only pay 5% of the price of a car, you’ll get a [McLaren](https://www.mclaren.com/)
  - But what if you pay 5% for the price of the car, but you never actually get the car and you don’t get to drive the car? You just get told how good the car is and are not in a position to judge how good the car is
- People think that if there is any benefit, and they hear someone else is paying, “*I’ll try the drug*”. But these drugs have downsides that patients might not be aware of – they might even have a net downside
  - 1) they don’t actually improve survival
  - 2) they may have an opportunity cost: patients end up tethered to a hospital and infusion machine for their last months rather than doing more meaningful things with their remaining time. Might be spending 40% of their extra life in the clinic lobby
- People make choices at odds with drugs’ actual benefits
- They might be better off if we did not promote options that are not in patients’ best interests

## “No-brainer” moves in oncology [1:06:45]

*What do you think are the “no regret” moves in oncology today?*

- **1: surgery to remove localized cancers**
  - Not much different for the last 50 years
  - Although some procedures (like [Whipple](https://en.wikipedia.org/wiki/Pancreaticoduodenectomy)) have improved
  - And, as with radical mastectomies, now more localized surgeries are often done
- **2: radiotherapy**
  - really useful in many situations
  - like the [Michael Douglas case](https://www.survivornet.com/articles/my-dad-is-102-i-never-thought-id-die-michael-douglas-on-surviving-tongue-cancer/#:~:text=Douglas%20was%20diagnosed%20with%20tongue,the%20star%20to%20Paris%20Match.): localized in head and neck
  - Anything stage [4A or better](https://www.cancer.net/navigating-cancer-care/diagnosing-cancer/stages-cancer) has “a great shot of a long-lasting cure with chemoradiotherapy”
- **3: drugs**
  - Hodgkin’s Lymphoma can be cured with a four-drug combination
  - Drugs can cure 95% of patients with testicular cancer that has spread
    - Peter asks: *even seminomatous types?*
    - Depends on the subtype, sometimes need a combination of both chemotherapy and surgical therapy (e.g., for teratoma)
  - Chronic myeloid leukemia (CML): the transformative [Gleevec](https://en.wikipedia.org/wiki/Imatinib) story
    - Peter points out that some will argue that CML is not cancer
      - It’s a blood-based cancer
    - Find it sooner because can be detected with blood test
    - Sole driver is essentially [BCR- ABL fusion](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/bcr-abl-fusion-gene), a genomic event
      - If you give a drug that inhibits that fusion event, change life expectancy from 3-4 years to normal
    - In a Swedish [dataset](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3138632/), they’re living until a year shy of normal life expectancy. That is a tremendous advance in medicine
- In summary: the no-brainers are when **there’s some benefit and the toxicity is low** or when **there’s a benefit but the toxicity is reversible** (giving you a chance to at least try it)

## “Fool’s gold” treatments in oncology [1:09:30]

- But some things are much more dubious
  - caustic, toxic treatments with long-term toxicity
- Patients are in a very difficult position – they don’t know all the science or how to think about the data.

> ### **“[Patients are] in a vulnerable position. Their life is on the line. And that’s not always a great position to make choices. And people often tend to make choices that may not be compatible with their best interests.” – Vinay Prasad**

- Decision-making is a thorny process; sometimes there is pressure to make certain decisions from family members

*What’s an example of something currently getting a lot of attention that might not run out to be a significant advance? Cell-based therapies for immunotherapy? Or maybe* [*checkpoint inhibitors*](https://en.wikipedia.org/wiki/Checkpoint_inhibitor) *like Keytruda?*

- The cell-based therapies (things like [CAR T cells)](https://en.wikipedia.org/wiki/Chimeric_antigen_receptor_T_cell) have a lot of promise and show great responses in some people, but it’s not clear how wide a range of conditions they will benefit
- For [multiple myeloma](https://www.mayoclinic.org/diseases-conditions/multiple-myeloma/symptoms-causes/syc-20353378#:~:text=Multiple%20myeloma%20is%20a%20cancer,crowd%20out%20healthy%20blood%20cells.), get remission but it doesn’t last (different than what we found with [lymphoma](https://www.mayoclinic.org/diseases-conditions/lymphoma/symptoms-causes/syc-20352638) and with pediatric [acute lymphoblastic leukemia](https://en.wikipedia.org/wiki/Acute_lymphoblastic_leukemia), ALL)
- Keytruda trial results have been mixed
- So it’s on a case-by-case basis depending on cancer and patient

**Vinay’s example: pancreatic cancer**

- Some patients have a germline mutation in the [BRCA gene](https://www.cancer.gov/about-cancer/causes-prevention/genetics/brca-fact-sheet) that confers susceptibility to cancers (breast as well as pancreas)
- Pancreas Cancer Olaparib Ongoing ([POLO](https://www.nejm.org/doi/full/10.1056/NEJMoa1903387)) trial: a randomized trial that gave people a minimum of four months of the standard of care ([FOLFIRINOX](https://en.wikipedia.org/wiki/FOLFIRINOX) therapy), then randomized to Olaporib or sugar pill
  - Olaparib had a progression-free survival benefit compared to sugar pill, but no overall survival benefit.
  - control arm shouldn’t have been sugar pill, it should have been continuing FOLFIRINOX
- Drug costs about $12,000 a month
- Sounded good because it was a targeted drug based on genomic signature unique to individual tumor, but was not better than traditional chemotherapy
- An example of hype being greater than benefit

**Progression-free survival**

- Often interpreted in the lay press as the time it takes for cancer to get worse, which is not quite right
- It is the time from when a patient enrolls on a study to one of four things happening:
  - 1) death.
  - 2) a new lesion on a CAT scan
  - 3) tumor gets 20% bigger (arbitrary cut point)
  - 4) tumor gets smaller, then bigger (it could then be 20% from the smallest it ever was)
- Often trials are driven by the latter two events. The tumors look 120% bigger.
- Also, measuring on a CAT scan is not like measuring your height – it’s much less precise and doctors don’t always agree about where the tumor ends and where the normal tissue begins
- Going back to [POLO](https://www.nejm.org/doi/full/10.1056/NEJMoa1903387) trial:  the only thing the drug improved was progression-free survival, “which is an arbitrary line in the sand for tumor growth” and tell you if people are living longer or feeling better

## The six hallmarks of successful cancer policy [1:16:00]

*Can you* w*alk us through your six hallmarks and explain what they mean?*

- The Six Hallmarks of Cancer
  - Proposed by Hanahan and Weinberg in probably one of the most cited [papers](https://www.cell.com/fulltext/S0092-8674(11)00127-9) in oncology
  - Includes the biological hallmarks such as invasion of the basement membrane, poor immune surveillance, angiogenesis, etc.
- Vinay thought of also distilling cancer policy into six essential hallmarks as well

## Cancer policy hallmark #1: Independence [1:18:00]

- This hallmark is about conflicts of interest
- Industry ties to those who should be watching: it funds patient advocacy groups, rotating door with industry and FDA, most expert oncologists get drug funding and sometimes support questionable drugs
- Drug reps buy residents lunches, unique pens, etc.  It’s small but a hook, the beginning of a slippery slope

 *Peter asks: have things changed in the last 20 years? I assume that pharma is not allowed in the hospital anymore.*

- In some but not every place

> ### “There is evidence that shows even so much as a meal that is paid for by the industry is associated with a statistically significant, but very small, increase in prescribing patterns. So it is a strategy that pays dividends.” -Vinay Prasad

- - These problems have largely been curtailed through a number of well-intentioned efforts
- But reform has focused too much on the low end – pens, meals – than on the high end (e.g., oncologists who get $100K+ per year in funding, even millions in research funding)
  - Even when controlling for research funding, prior publications, and seniority, Vinay [found](https://drive.google.com/file/d/1co0CAsyPYaEkQwPd6pmxK9ZlG6R3Ohkm/view) that “personal payments from the industry are associated with greater publication in the future.”
    - “It’s likely it’s a positive feedback loop. Working with the industry helps your career, which helps you work with the industry, which helps your career.”
  - Guidelines written by people making large amounts of money from industry.  And the guidelines, by law in the US, make Medicare pay for drugs for off-label purposes.
  - “So those relationships, I think, are, in order of magnitude, more concerning than the hungry resident taking a meal. In fact, I try not to talk too much about those sort of little things.”
  - The solution is not to set hard rules with punishments, because that doesn’t change behavior
- Instead create a different set of incentives
  - We still need guidelines to help decide what to cover off label. Why don’t we incentivize people who don’t have conflict to join those guidelines?
  - What if we had rules and policies that favored faculty members who didn’t take money from the industry to be on the guidelines? Suddenly career incentives look very different.
    - Perhaps should have to make choice between drug consulting and sitting on a guidelines committee
    - So change incentives: “create opportunities for academics to not take money and still have robust and rich careers.”  Right now all opportunities are tied to taking money from the industry

*Is there evidence that physicians are, for the most part, honestly disclosing these things? I know there was* [*a very famous case*](https://www.the-scientist.com/news-opinion/top-breast-cancer-researcher-didnt-disclose-financial-ties-64774) *at Memorial Sloan Kettering, where there was a huge blow up over this. So if a system like the one you described were in place, do we think that we could believe people?*

- available evidence suggests that disclosure is incomplete and often inaccurate
  - many people don’t even believe they have a conflict
- José Baselga: did not mention highly relevant conflicts in many articles
  - Pushed out of  Memorial Sloan Kettering
  - But became vice president of the drug company AstraZeneca, a job that likely pays a few times as much money as he was making earlier.  Not exactly a punishment
- We don’t really take disclosure seriously
- Some psychology / business evidence suggests that if someone discloses you might actually trust them more
- Divestment is a better way
  - Say a drug costs $100,000 a year and alters the (somewhat subjective) tumor size on CAT scan but we don’t know if it increases lifespan or improves quality of life
  - Who decides whether or not we should recommend that routinely or not? The guidelines will shape how many doctors practice and they should be made by doctors without a conflict of interest
- “It’s like a courtroom where the prosecutor and the defense are both being paid by the defendant”
- We need profit to drive innovation, but it needs to be separated from the people who are supposed to monitor and push back on drug companies

*What is the opposition to this idea?*

- The people who are best in the position to fix the situation are the ones who are personally getting the most money
  - Our professional societies and senior leadership at universities and academic medical centers are driven by industry payments

> ### **“I think it’s hard in any system where the people you need on your side to change the system, the people with the power, are the ones benefiting most from the system” – Vinay Prasad**

- Most people rationalize their actions, seeing themselves as products of their circumstances and not an unethical person
- The real way to fix this problem is to have somebody external to the medical profession come in and do it

## Cancer policy hallmark #2: Evidence [1:28:15]

- Measure what matters and do it fairly
  - when we give cancer drugs, we care about two things: increased survival or health related quality of life.
- In our current system:
  - One third of approved drugs shrink tumors more than 30% in a fraction of people
  - One third delay tumor growth by 20%
  - One third allow you to live longer and/or better.
  - So we’re spending all this money on costly drugs, but only about a third actually affects what actually matters to people. The other two thirds you’re measuring tumor size on CAT scans.

*Why do we use tumor shrinkage of 30% as a cutoff?*

- Goes back to a [1976 paper](https://acsjournals.onlinelibrary.wiley.com/doi/10.1002/1097-0142(197607)38:1%3C388::AID-CNCR2820380156%3E3.0.CO;2-A) where oncologists measured marbles under foam rubber with calipers
  - The size difference at which two doctors could reliably tell the marble had gotten bigger or smaller became the cut point
  - And that cut point is what we still use today
- So why put so much stock in drugs with a 10 or 20% response rate? Cutoffs are arbitrary and tell you nothing about whether patient lives longer or better

*Does this mean that two thirds of the treatments out there go in the waste bin?*

- They won’t be approved at the same moment in time. It would change a lot of things in the industry
- Would do more trials in patients with relapsed cancer because that’s where the event rate is highest
- Companies would be more selective about drugs they advance in the process

*Would it actually change the number of drugs that come to market?*

- We’ll likely have fewer but better drugs coming to market

## Cancer policy hallmark #3: Relevance [1:31:30]

- Need more studies done on subjects who are more representative of average Americans
- Need to study average people to see if the drugs work as they will be prescribed
- Will reduce drug success rates due to both decreased tolerability and actual poor response [but ones that make it to market are likely to be more effective for the average patient]

## Cancer policy hallmark #4: Affordability [1:32:00]

- Affordability is a thorny problem
- Vinay has written a [number](https://pubmed.ncbi.nlm.nih.gov/27261866/) [of](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4600021/) [review](https://jamanetwork.com/journals/jamaoncology/fullarticle/2212206) [articles](https://pubmed.ncbi.nlm.nih.gov/22660868/) that have looked at many different solutions; here he will just put them into buckets
  - Two kinds: solutions that rely on existing legal structures vs. those that require novel legal structures.
- If a drug is approved in the US, Medicare has to pay for it and can’t negotiate the price
  - It also has to pay for any drug recommended at a level 2A or higher by guidelines (like the [National Comprehensive Cancer Network](https://www.nccn.org/professionals/physician_gls/default.aspx)’s), by many people writing the guidelines are funded by the industry
- We should give Medicare the ability to decline to pay for drugs
  - Years ago, a couple of states asked Seema Verma and colleagues at HHS to let states make different standards for what Medicare would pay for, but no experimentation at the state level was allowed
  - We should encourage state-level experimentation to explore new ways to bring down drug prices
- Also are a number of technical solutions

> ### **“A drug that you cannot actually get in the hands of somebody is no better than no drug at all.” – Vinay Prasad**

- Many drugs, for the most part, are out of reach of billions and billions of people
  - There are some drugs that are transformative but the best centers globally do not have access
  - Example:  Trastuzumab, a drug developed in the late 1990s for a certain type of breast cancer
    - An [Indian study](https://pubmed.ncbi.nlm.nih.gov/22293249/) found that only a small number of people who were eligible for that drug had access

*Do we have a sense of on average, how much more a drug costs in the United States than, say, in Europe or Asia?*

About 50% of pharmaceutical spending in the world comes from the US even though we account for maybe 4% of the world’s population

*Do we know how much of that is volume versus price?*

- Peter says it seems like the US has a “deal” with the pharmaceutical industry that it will do most R&D in the US, so the US basically subsidizes the cost for the world in exchange for first access to the drugs
- If you compare the US and Norway, which have comparable GDPs, we pay roughly double what Norway pays for cancer drugs
- We should ask why we subsidize marginal drugs the same way we subsidize transformative drugs
  - For example,  Avastin has multiple approvals for many different tumor types.  It has a median survival of about one to two months without curing the disease. Global lifetime earnings are close to $100 billion.
  - Another example: Gleevec. It doesn’t cure everybody, but works dramatically well when it does. Lifetime earnings in the several billions and billions of dollars.
- Marginal drugs
  - Toxic drugs that don’t do that much and still can accrue billions of dollars
- To correct the market, incentivize drugs that have more substantive benefits and don’t pay so much for those drugs that really don’t add a lot, don’t cure people and just prolong survival very modestly in very select cohorts
- While the cost of innovation is staggering, pharma also grossly overstates the risk they’re taking
  - Research has essentially been outsourced to biotech: drug discovery is now a venture capital problem, which means it’s a risk funded by private citizens
  - Pharma only comes in at Phase 3 after risk reduced, increasing success rate

*What’s the knockoff effect of a new system going to be in terms of incentivizing pharma?*

- Peter says it seems obscene that [Centers for Medicare & Medicaid Services](https://www.cms.gov/) (CMS), which is part of the Department of Health and Human Services (HHS), doesn’t have the ability to negotiate
- But at the same time, he doesn’t want anybody in the US government making a decision when it comes to healthcare because he no longer trusts them
  - There are 550 or 600 people in the US Congress, but maybe 2 of them have science degrees, so they are not the right people to make scientific decisions. Same for the Supreme Court

*So how do we think about balancing this?*

- Peter says maybe it would be better to let the states do it so there’s less collateral damage, but that carries its own problems
- the problem remains unsolved
- CMS as it is provides a kind of incentive: if you can get FDA approval we’ll pay no matter what the cost
  - No company wants to be an outlier in this system
  - Also make CMS pay when docs use drugs off label, so companies have incentive to convince doctors to do this
  - The hurdle for a drug is drug approval, and then you can charge whatever you want
  - don’t have to look at cost to bring to market or what the benefit of the drug is
- happened with CAR T cells: cost $300K or $400K but justified it because it’s one-time dose and other drugs with more frequent dosing cost $200K a year
  - creates cycle of high cost justification
- The fact that CMS can’t negotiate is a decision to incentivize approval

*How do drugs get approved?*

- Bar for approval is getting lower and lower – need fewer subjects, some trials don’t have a control arm, etc.
- A drug (*Vinay forgets the name*) “lowers the rate of a blood protein” but also causes ocular impairment in almost everyone who takes it, in some cases severe
  - We don’t know if it makes better live longer or better, but ophthalmology costs are high
  - Why is this drug approved?
- Value based pricing model:  we should pay more for drugs that provide us more value with more incremental survival benefits
- With any policy, you will get unintended consequences and people finding unforeseeable paths of least resistance
  - Some policy experimentation is good to see what works and course correct

*CMS might be 25-35% of insurance in the US, but why haven’t private insurance companies banded together to negotiate prices?*

- Peter says part of reason is because they don’t bear much risk because majority of their business is probably administrative services only ([ASO](https://www.investopedia.com/terms/a/administrative-services-only.asp))
- If companies don’t cover what CMS covers, they look bad
  - There have been many [news](https://www.npr.org/sections/health-shots/2020/03/16/816807617/insurers-cover-fewer-drugs-leaving-some-patients-struggling-to-get-needed-treatm) [reports](https://health.usnews.com/health-news/patient-advice/articles/2015/05/05/when-your-insurer-pulls-your-drug-coverage) about patients’ [personal](https://www.fresnobee.com/news/local/article232478212.html) [battles](https://khn.org/news/drug-coverage-denied-by-medicare-how-seniors-can-fight-back/) with health insurance companies’ drug coverage denials over the last 30 years
  - Small population that needs drug, so it might be cheaper for them just to pay for the drug than it is to deal with the pushback from not paying for it
- [Affordable Care Act](https://en.wikipedia.org/wiki/Affordable_Care_Act)  capped insurance company profit on revenue to 20% profit on revenue (minimum [medical loss ratio](https://www.healthcare.gov/glossary/medical-loss-ratio-mlr/) or MLR)
  - If can’t earn more than 20%, have high incentive to make as much as possible
  - “So if I tell you you’re really hungry and you can only eat 20% of the pizza, what size pizza should I order? The answer is going to be extra large.”

*Why do insurers impose pre-authorization requests and other requirements that make things difficult for doctors?*

- One, the insurer’s incentive is to make sure year-to-year variability of costs is predictable and that they can model that out and make sure their premiums go where they need them to go to ensure their profit revenues
- Also, insurers don’t have enough skin in the game to keep costs down, so they really don’t care
  - Peter thinks it’s the employer that has the most skin in the game
  - “But the problem is they’re so disaggregated and so spread out that they can’t speak in a unified way and they can’t fight in a unified way.”
- Also a “[tragedy of the commons](https://en.wikipedia.org/wiki/Tragedy_of_the_commons)” problem
  - Why would one company fund the proper trial if all their competitors will also have access to the info?
  - A few companies ran clinical trials for autologous stem cell transplants for breast cancer that ultimately debunked that procedure

## Cancer policy hallmark #5: Possibility [1:47:00]

- The preclinical pipeline must be expanded
- We talk about fledgling biotech, the pharmaceutical industry, etc. but forget the role of the National Institutes of Health (NIH)  in drug development
  - NIH bears some of the risk, funds some “science for science’s sake,” identifying targets that are then clinically exploited
  - We spend about $30B a year on NIH, but that’s not nearly enough
- “That science is like the greatest thing that people have ever done, and if I were in charge of anything, I would crank up the funding for science. Because I think science is possibility.”
  - We should increase science funding slowly and steadily (if increase it too fast, not used yet used it and will result in waste)
    - Must separate science from politics – funding should be stable and not dependent on elections
    - “science needs slow, steady growth.”
- We give out billions of dollars in research funding but have never really studied how it should be distributed
  - Some labs are flush with money while others get almost none
  - We need to do some studies on measures of equity of who gets the money, the research satisfaction, burnout, measures of how translation occurs, etc.
- Blue sky science: where it’s just science for science’s sake
  - Not aimed at a specific cure but on understanding how things work; very hard to get funding for that.  Shouldn’t be that way

> ### **“Some of the greatest advances in science were people who pursued things purely because that interested them and the finding and the translation was serendipitous.” – Vinay Prasad**

- Peter agrees – people who give money at NIH are not really allowed to take big risks
  - Must go back and show you did x, y, and z to get continued funding.
  - Makes sense to avoid waste but also discourages exploration
- Peter suggests having two research funding arms:
  - translational funding arm that is meant to be incremental: is this ready to go to the next step on a clinical pathway?
  - Another arm for basic inquiry and the advancement of natural knowledge, regardless of where it takes us
    - some of the most exciting discoveries in the history of the last 400 years came from nothing other than pure inquiry
- People thought that some work (like the [work](https://en.wikipedia.org/wiki/James_P._Allison) of immunotherapy doctor Jim Allison) “was foolish and misguided and that was never going to succeed”
  - But the work ultimately led to a blockbuster class of drugs and he won the Nobel prize

## Cancer policy hallmark #6: Agenda [1:52:00]

What happens when you take a 30,000-foot view of cancer and look at the clinical trials’ agenda?

- In some spaces in cancer medicine, people are running redundant and duplicative trials
  - “They’re all testing them in the same tumors, in the same setting, with the same old controls.”
- There are also many different clinical trials with drugs that have low promise
- By chance alone, aren’t some of these trials going to be positive?
  - Using a non-stringent nominal cutoff for significance ([p =0.05](https://en.wikipedia.org/wiki/P-value))
- Peter says it’s like you need a [Bonferroni correction factor](https://en.wikipedia.org/wiki/Bonferroni_correction) for the number of trials
- Vinay wrote a [paper](https://www.thelancet.com/journals/lanonc/article/PIIS1470-2045(19)30744-2/fulltext) where they used a Bonferroni
  - “We got a lot of [pushback](https://www.thelancet.com/journals/lanonc/article/PIIS1470-2045(19)30854-X/fulltext) from those peer reviewers”
  - Totally novel application of how it was used

> ### **“Within a study, if you do a lot of comparisons, you take into account the number of comparisons to some degree. … When you’re running many, many studies, shouldn’t you also do the same?” – Vinay Prasad**

- More a philosophical than a statistical question
- The most scarce resource in cancer medicine are the patients themselves
  - For some tumor types, there are now more trials ongoing than there are people with that condition
- The big picture
  - It’s like when little kids play soccer – they don’t play positions, they all run after the ball
  - Lots of people are running duplicative trials
  - Somebody has to think about the big picture and recognize what the agenda looks like across the entire field.

## Tumor genome sequencing and liquid biopsies [1:54:30]

*Is there a role in oncology for* [*tumor genome sequencing*](https://www.cancer.gov/about-cancer/treatment/types/precision-medicine/tumor-dna-sequencing)*?*

- Peter doesn’t know what to say when people ask his advice about essentially incurable cancers. He doesn’t really have any advice because their oncologist has already said there is nothing more to do
- Peter’s perspective is that there’s nothing wrong with hope, and for a lot of things we don’t know if they work or not
  - But ask about the cost, because “I’m certainly pretty squirrely when someone’s offering a panacea treatment for $20,000.”
- Is there anything out there that’s in the “holistic” world that’s going to work?
- Peter has sent people to [Foundation Medicine](https://www.foundationmedicine.com/), but it has never been a game changer
- He had one dramatic experience: a friend had pancreatic cancer related to [Lynch Syndrome](https://www.cancer.net/cancer-types/lynch-syndrome), which is more likely to involve checkpoint mutations
  - Got him into a trial of Keytruda
  - He turned out to be a remarkable responder and has now been cancer-free for almost a decade

*What are your views on tumor sequencing, off-label drug use, targeting therapies, that sort of thing?*

- Vinay doesn’t take a strong stance against alternative or complementary therapies as long as 1) they aren’t too expensive, 2) don’t have an opportunity cost, and 3) don’t interfere with his treatment plan
  - He gets irritated with docs who “want to die on that hill” and destroy their relationship with a patient
  - “At the end of the day, if it doesn’t cost too much, it’s not really too harmful, And somebody really is motivated to do it and it’s not going to interfere with what you want to do, have at it”
  - Peter adds that we must recognize there’s a lot we don’t know
- [Next generation sequencing](https://en.wikipedia.org/wiki/Massive_parallel_sequencing) (NGS) and  tumor genomics: some cancer patients need to be tested for mutations
  - Lung cancer
    - at least six or seven mutations that we now have FDA-approved therapies for
    - need to know about [EGFR](https://lcfamerica.org/lung-cancer-info/types-lung-cancer/egfr-mutation/) and [ALK](https://lcfamerica.org/lung-cancer-info/types-lung-cancer/alk-positive-lung-cancer/) (particularly if the person is a younger non-smoker)
  - Melanoma: you need to know about [BRAF](https://www.aimatmelanoma.org/wp-content/uploads/BRAFinMelanoma.pdf)
  - Colon cancer: you need to know about [microsatellite instability](https://en.wikipedia.org/wiki/Microsatellite_instability#:~:text=Microsatellite%20instability%20(MSI)%20is%20the,MMR%20is%20not%20functioning%20normally.) (MSI) high status
  - There are maybe 20 or 30 mutations a good oncologist should know
- MSI high: no matter what tumor type, that’s something that we have an approved drug for, so it’s quite reasonable to test for it
  - Appropriate to use NGS to pair your patient with a clinical trial
- But sometimes you have gone through the steps and find a mutation that you might have a drug for, but no trial
  - Do you use the new drug or standard treatment?

> ### **“It is so seductive to believe that because we found the mutation and the target, it’s better to use the targeted drug than that older drug that may have a longer track record. And I think that’s where people get into a bit of trouble, that sometimes you actually end up eroding outcomes, not enhancing outcomes. You actually make worse choices in those cases.” – Vinay Prasad**

- Some tumor mutations vary widely by site, so would use different drugs depending on where biopsy was done
- Has also been variation with same tumor sent to different lab companies, which is concerning
- Look for fusion events in people with rare tumors at young ages; important to know about and there are some trials at Sloan Kettering
- If patient has tried various therapies and we don’t really know about mutations for their tumor, not obligatory to do sequencing:
  - “be careful that you don’t just gravitate to what is a key in a lock, what sounds like a key in a lock, but it may be sort of taking you away from something that has a better track record.”
- [Liquid biopsies](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/liquid-biopsy) are done for leukemia

*What about the phase two data on liquid biopsies for solid organ tumors and lymphomas?*

- Leukemia is always a few steps ahead of everything else because it can be more easily detected and measured volume wise
- There are a number of approved liquid biopsy tests which will have a role
  - “If you can find out that mutational information without having to stick a needle in someone, everyone is going to be grateful for that”
  - But ask if the test is sensitive enough in this case: will you still need to do a biopsy?
- An advantage of liquid biopsy if that you can track something over time

## Vinay’s clinical philosophy, being skeptical without being too contrarian, and practicing medicine without perfect information [2:03:30]

- Example when Vinay took a different stance and others gave him a hard time: the use of dexamethasone for COVID
- “Medicine by press release”
  - The drug company Eli Lilly announces top line results are positive, this drug improved outcomes ([hazard ratio = 0.7](https://en.wikipedia.org/wiki/Hazard_ratio))
  - But the press release did not include how long patients lived or if they had side effects
  - Press releases are primarily for shareholders and generally doctors should not be making decisions based on them – need to wait for the paper to get more information
- A [recent UK study](https://www.nejm.org/doi/10.1056/NEJMoa2021436) found that people who are hospitalized requiring oxygen [when their oxygen saturation levels are less than 94%](https://www.healthline.com/health/normal-blood-oxygen-level) or people who are mechanically ventilated get an all-cause mortality benefit from dexamethasone
  - But maybe people who are hospitalized but do not require supplemental oxygen did not benefit
- During COVID, docs were trying everything and doing whatever they could think of for COVID patients
  - This particular study’s protocol was available and defined pre-specified endpoints, so Vinay thought the evidence in the press release was enough
  - “I like to say a press release and a protocol, that’s like a driver’s license and a social security card. And a paper, that’s like a passport. Do I have to show you my passport? I can show you the other two. It’s another form of identification.”
  - He was criticized by those who thought they should wait for the paper
- The best way to keep a balance between skepticism blind acceptance is to go into the clinic, where patients are taking drugs you might be skeptical of

**Vinay’s clinical philosophy**

- The doctor’s role is not to determine what treatment is right for someone, it’s to convey to the patient what they know about the drug: what has and has not been shown, potential benefits, uncertainties, known toxicities and risks
  - Then walk the patient through the decision-making process so they understand if it’s worth it to them to take the risks
  - Different people will choose differently

> ### **“The more you practice medicine, the more you realize that it’s an art. You’re never going to have perfect information. You’re going to have to make decisions today with less than perfect information.” – Vinay Prasad**

- Peter reflects that the art/science of medicine is very different from a field like experimental physics where you can debate the experimental results
  - if you’re too much of a skeptic, there’s a cost of doing nothing
  - if you blindly accept everything, you are almost unquestionably subjecting patients to unnecessary treatments
- Peter and his colleagues debate with each other, “but we never lose sight of the fact that it’s not an intellectual pursuit. At the end, a decision needs to be made”
- Recognizing that sometimes others might do things differently than we would helps balance skepticism

§

## Selected Links / Related Material

**Vinay’s books**:

- *2015 book*: [Ending Medical Reversal: Improving Outcomes, Saving Lives](https://www.amazon.com/Ending-Medical-Reversal-Improving-Outcomes-dp-1421417723/dp/1421417723/ref=mt_other?_encoding=UTF8&me=&qid=1600822907) by Vinayak K. Prasad and Adam S. Cifu | (amazon.com)
- *2020 book*: [Malignant: How Bad Policy and Bad Evidence Harm People with Cancer](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635/ref=pd_bxgy_img_2/147-2075134-8416100?_encoding=UTF8&pd_rd_i=1421437635&pd_rd_r=511204a1-bb7e-4bdf-8dfb-09de1a7237da&pd_rd_w=6y6KF&pd_rd_wg=1LcTU&pf_rd_p=ce6c479b-ef53-49a6-845b-bbbf35c28dd3&pf_rd_r=4XA8K85FJXZF35JEC2AV&psc=1&refRID=4XA8K85FJXZF35JEC2AV) by Vinayak K. Prasad | (amazon.com)

**Where to find Vinay online**: [1:30]

- He hosts an oncology podcast called [Plenary Session](https://soundcloud.com/plenarysession)
- He runs a [YouTube channel](https://www.youtube.com/channel/UCUibd0E2kdF9N9e-EmIbUew)
- Primarily active on Twitter at [VPrasadMDMPH](https://twitter.com/VPrasadMDMPH?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

**Previous episode of The Drive with Azra Raza discussing oncology and cancer policy:** [#121 – Azra Raza, M.D.: Why we’re losing the war on cancer](https://peterattiamd.com/azraraza/) | Peter Attia (peterattiamd.com) [2:25]

**Vinay’s papers on medical reversal**:

- [Medical Reversal: Why We Must Raise the Bar Before Adopting New Technologies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3238324/) **|** (Prasad & Cifu 2011) [11:03]
- [Meta-Research: A comprehensive review of randomized clinical trials in three medical journals reveals 396 medical reversals](https://elifesciences.org/articles/45183) **|** (Herrera-Perez et al. 2019) [11:03]

**COURAGE trial on stents:** [Optimal Medical Therapy with or without PCI for Stable Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa070829) **|** (Boden et al. 2007) [13:27]

**ORBITA study with sham stents:** [Percutaneous coronary intervention in stable angina (ORBITA): a double-blind, randomised controlled trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(17)32714-9/fulltext) **|** (Al-Lamee et al. 2018) [17:19, 20:40, 21:24]

**Famous paper showing that the average solid cancer drug extends life by only about 2 months:** [Unintended consequences of expensive cancer therapeutics—the pursuit of marginal indications and a me-too mentality that stifles innovation and creativity: the John Conley Lecture](https://pubmed.ncbi.nlm.nih.gov/25068501/) **|** (Fojo et al. 2014) [38:25]

**CAST trial showing that PVC-suppressing drugs increased rather than decreased mortality**: [Mortality and Morbidity in Patients Receiving Encainide, Flecainide, or Placebo](https://www.nejm.org/doi/full/10.1056/NEJM199103213241201) **|** (Echt et al. 1991) [43:27]

**Paper indicating that WHI’s initial conclusions about breast cancer had been wrong:**  [Menopausal hormone therapy and breast cancer: what is the evidence from randomized trials?](https://www.tandfonline.com/doi/abs/10.1080/13697137.2018.1514008?journalCode=icmt20) **|** (Hodis & Sarrel 2018) [44:08]

**Paper showing mean survival for Medicare patients taking sorafenib was 3 months:**  [Sorafenib Effectiveness in Advanced Hepatocellular Carcinoma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5016063/) **|** (Sanoff et al. 2016) [50:40]

**Paper showing that Avastin increased survival by a couple of months:** [Bevacizumab plus irinotecan, fluorouracil, and leucovorin for metastatic colorectal cancer](https://pubmed.ncbi.nlm.nih.gov/15175435/) **|** (Hurwitz  et al. 2014)  [55:56]

**Swedish study on Gleevec restoring life span for CML patients:** [Success Story of Targeted Therapy in Chronic Myeloid Leukemia: A Population-Based Study of Patients Diagnosed in Sweden From 1973 to 2008](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3138632/) **|** (Björkholm et al. 2011) [1:08:57]

**POLO trial comparing Olaporib and placebo:** [Maintenance Olaparib for Germline BRCA-Mutated Metastatic Pancreatic Cancer](https://www.nejm.org/doi/full/10.1056/NEJMoa1903387) **|** (Golan et al. 2019) [1:12:29, 01:15:14]

**Widely cited paper on hallmarks of cancer**: [Hallmarks of Cancer: The Next Generation](https://www.cell.com/fulltext/S0092-8674(11)00127-9) **|** (Hanahan & Weinberg 2011) [1:16:55]

**Vinay’s paper on the connection between industry payments and publication:** [The relation between publication rate and financial conflict of interest among physician authors of high-impact oncology publications: an observational study](https://drive.google.com/file/d/1co0CAsyPYaEkQwPd6pmxK9ZlG6R3Ohkm/view) **|** (Kaestner, Edmiston, & Prasad 2018) [1:21:54]

**Paper from the 1970s using marbles and foam rubber as tumor size proxies:** [The effect of measuring error on the results of therapeutic trials in advanced cancer](https://acsjournals.onlinelibrary.wiley.com/doi/10.1002/1097-0142(197607)38:1%3C388::AID-CNCR2820380156%3E3.0.CO;2-A) **|** (Moertel & Hanley 1976) [1:29:06]

**Vinay’s articles on affordability issues:**

- [The UK Cancer Drugs Fund Experiment and the US Cancer Drug Cost Problem: Bearing the Cost of Cancer Drugs Until It Is Unbearable](https://pubmed.ncbi.nlm.nih.gov/27261866/) **|** (Prasad & Mailankody 2016) [1:32:11]
- [How should we assess the value of innovative drugs in oncology? Lessons from cost-effectiveness analyses](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4600021/) **|** (Prasad & Mailankody 2015) [1:32:11]
- [Five Years of Cancer Drug Approvals: Innovation, Efficacy, and Costs](https://jamanetwork.com/journals/jamaoncology/fullarticle/2212206) **|** (Prasad & Mailankody 2015) [1:32:11]
- [The apples and oranges of cost-effectiveness](https://pubmed.ncbi.nlm.nih.gov/22660868/) **|** (Prasad 2012) [1:32:11]

**Indian study on lack of access to trastuzumab:** [Estrogen, progesterone and HER2 receptor expression in breast tumors of patients, and their usage of HER2-targeted therapy, in a tertiary care centre in India](https://pubmed.ncbi.nlm.nih.gov/22293249/) **|** (Ghosh et al. 2011)  [1:33:57]

**Vinay’s paper using a new application of the Bonferroni correction factor:** [Multiplicity in oncology randomised controlled trials: a threat to medical evidence?](https://www.thelancet.com/journals/lanonc/article/PIIS1470-2045(19)30744-2/fulltext) **|** (Prasad & Booth 2019) [1:53:11]

**UK study showing mortality benefit from dexamethasone in some hospitalized COVID patients:**  [Effect of Dexamethasone in Hospitalized Patients with COVID-19: Preliminary Report](https://www.nejm.org/doi/10.1056/NEJMoa2021436) **|** (RECOVERY Collaborative Group 2020) [2:03:29]

§

## People Mentioned

- [Azra Raza](https://en.wikipedia.org/wiki/Azra_Raza) [2:25, 52:25]
- [Charles Bosk](https://www.inquirer.com/obituaries/philadelphia-inquirer-obituaries-obituary-charles-bosk-penn-sociologist-reducing-medical-errors-20200909.html) [7:16]
- [Hidayatullah Munshi](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=12716) [22:51]
- [Steven Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg) [34:26, 54:44]
- [Adam Cifu](https://www.uchicagomedicine.org/find-a-physician/physician/adam-cifu) [40:21]
- [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) [54:44]
- [James P. Allison](https://en.wikipedia.org/wiki/James_P._Allison) [54:44, 01:51:44]
- [José Baselga](https://en.wikipedia.org/wiki/Jos%C3%A9_Baselga) [1:24:49]
- [Seema Verma](https://en.wikipedia.org/wiki/Seema_Verma) [1:42:57]

§

## DRUGS MENTIONED

- [Flecainide](https://en.wikipedia.org/wiki/Flecainide) (Tambocor) [43:27]
- [Sorafenib](https://en.wikipedia.org/wiki/Sorafenib#:~:text=Sorafenib%20(co%2Ddeveloped%20and%20co,and%20radioactive%20iodine%20resistant%20advanced) (Nexavar) [50:14,
- [Bevacizumab](https://www.drugs.com/mtm/bevacizumab.html) (Avastin, Mvasi, Zirabev) [55:56, 1:36:07]
- [Lisinopril](https://www.drugs.com/lisinopril.html) (Qbrelis, Zestril, Prinivil) [58:13]
- [Hydrochlorothiazide](https://www.drugs.com/hydrochlorothiazide.html) (Microzide) [58:13]
- [Pembrolizumab](https://en.wikipedia.org/wiki/Pembrolizumab) (Keytruda) [1:10:39, 1:55:21]
- [Olaparib](https://en.wikipedia.org/wiki/Olaparib) (Lynparza) [1:11:53]
- [Trastuzumab](https://www.breastcancer.org/treatment/targeted_therapies/herceptin) (Herceptin) [1:33:57]
- [Imatinib](https://en.wikipedia.org/wiki/Imatinib) (Gleevec) [1:36:07]
- [Dexamethasone](https://en.wikipedia.org/wiki/Dexamethasone) (Dextenza, Ozurdex)  [2:03:29]

§

![](https://peterattiamd.com/wp-content/uploads/2020/10/bio-image-vinay-500x500.png)

##### Vinay Prasad, M.D., M.P.H

Vinay Prasad M.D., M.P.H. is a practicing hematologist-oncologist and Associate Professor of Medicine at the University of California San Francisco.  He studies cancer drugs, health policy, and clinical trials and better decision making. He is author of [these academic articles](https://www.vinayakkprasad.com/papers), and the books [*Ending Medical Reversal*](https://www.amazon.com/Ending-Medical-Reversal-Improving-Outcomes/dp/1421417723/) (2015), and [*Malignant*](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635/) (2020).  He hosts the oncology podcast [Plenary Session](https://soundcloud.com/plenarysession), and runs a YouTube Channel [VinayPrasadMDMPH](https://www.youtube.com/channel/UCUibd0E2kdF9N9e-EmIbUew).  He tweets [@VPrasadMDMPH](https://twitter.com/VPrasadMDMPH). [[vinayakkprasad.com](https://www.vinayakkprasad.com/)]