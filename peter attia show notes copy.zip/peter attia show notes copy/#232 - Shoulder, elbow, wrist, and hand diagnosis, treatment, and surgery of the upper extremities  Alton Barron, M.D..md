# #232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities | Alton Barron, M.D.

**Source:** [https://peterattiamd.com/altonbarron/](https://peterattiamd.com/altonbarron/)

---

Alton Barron is an orthopedic surgeon specializing in the shoulder, elbow, and hand. In this episode, Alton breaks down the anatomy of the upper extremities and discusses the most common injuries associated with this area of the body. He explains in detail how he examines the shoulder, elbow, and hand to find the source of the pain and lays out the non-surgical and surgical treatment options as well as the factors that determine whether surgery is appropriate. Additionally, Alton describes the surgical procedures that, when done appropriately, can lead to tremendous reduction of pain and improvement in function.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

(See “Selected Links” section at the bottom of show notes for a list of all YouTube video clips created from this discussion)

![The Peter Attia Drive](images/altonbarron/the_Drive_public.png)

Play

#232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities | Alton Barron, M.D.

#232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities | Alton Barron, M.D.

1x15s30s

0:003:38:24

## We discuss:

- Alton’s path to orthopedic surgery [3:45];
- Evolution of orthopedics and recent advances [8:45];
- Anatomy of the upper extremities [13:30];
- Rotator cuff injuries, shoulder joint dislocation, and more [21:15];
- Peter’s shoulder problems [31:30];
- The structure of the biceps and common injuries [35:30];
- Labrum tears in the shoulder and natural loss of cartilage with usage and time [38:15];
- Shoulder evaluation with MRI vs. physical exam, diagnosing pain, and when to have surgery [41:30];
- How anatomical variation can predispose one to injury and how screening may help [50:30];
- Pain generators in the shoulder, and the important nuance of the physical exam [56:00];
- Frozen shoulder [1:05:15];
- Shoulder pain that originates in the neck [1:11:15];
- Surgical treatments for a labral tear, and factors that determine whether surgery is appropriate [1:16:00];
- Repairing the rotator cuff [1:29:15];
- Are platelet-rich plasma (PRP) injections or stem cells beneficial for healing tears? [1:38:15];
- Repair of an AC joint separation [1:45:15];
- Total shoulder replacement [1:55:45];
- The elbow: anatomy, pain points, common injuries, treatments, and more [2:05:30];
- How Tommy John surgery revolutionized Major League Baseball [2:17:15];
- History of hand surgery and the most significant advancements [2:22:15];
- The hand: anatomy, common injuries, and surgeries of the hand and wrist [2:29:30];
- Carpal tunnel syndrome [2:40:00];
- Other common injuries of the hand and forearm [2:47:15];
- Grip strength [2:55:15];
- Arthritis in the hands [2:59:30];
- Trigger finger [3:07:45];
- Nerve pain, numbness, and weakness in the upper limbs [3:14:00];
- The Musician Treatment Foundation [3:22:00];
- Gratitude and rucking [3:34:15]; and
- More.

§

## Show Notes

**\*Notes from intro:**

- Alton Barron is a board certified, fellowship-trained shoulder, elbow, and hand surgeon
- He has clinical practices in both Austin and New York
- He specializes in both routine and complex problems in the upper limb
- Alton was Peter’s surgeon
  - Peter had shoulder surgery in March of 2022
  - He’s documented that recovery process along the way and promised to do a deep dive on the upper extremity
- In this episode we focus on the upper limb
  - Elbow, shoulder, hand, and wrist
  - Nerves located throughout
- Alton goes through the structure, anatomy, things that can cause pain and injury, and how and when to think about surgical intervention
- In addition to our conversation on the podcast, Alton runs through what a typical physical exam looks like
  - This is really important
  - Certainly surgeons rely on MRI imaging, but any good orthopedist Peter knows has always said the same thing, “*The exam and the symptoms matter usually more than what the image shows*”
  - This is also something you can do on yourself to understand if something you are feeling is problematic or is going to get better over time
- This is one episode you are going to want to watch on video
  - Due to the discussion of physical exams and sketches of anatomy
- Due to long length of this podcast, we have broken it out into some specific videos
  - Isolating the videos of the shoulder, elbow, hand, wrist, and the innervation
  - Videos of the various exams Alton does, demonstrated on Peter
  - You can find all of the videos on the show notes page or YouTube page
- One other thing that comes up in this podcast is the foundation he founded, the [Musician Treatment Foundation](https://mtfusa.org/)
  - This is a nonprofit that provides direct orthopedic shoulder surgery/ hand interventions along with non-surgical care to uninsured/underinsured musicians
  - Alton is incredibly passionate about this as he is also a musician
  - He talks about the amazing work he has done so far, where they want to go with it, how they are putting funds to use
  - The foundation has their big annual event in Austin, coming up on Dec. 2
    - Head over to their [website](https://mtfusa.org/) to learn more

## Alton’s path to orthopedic surgery [3:45]

- Peter did general surgery, but outside of trauma, he knows very little about orthopedics
  - This it probably true for a lot of doctors
  - How much more is that true for patients?
- Orthopedics is a broad field and pretty specialized at the same time
- Alton agrees, in medical school we only do a subset of rotations
  - He knows nothing about urology, brain surgery
- It depends on the luck of the draw, on what we get exposed to
- Then we narrow ourselves down like a funnel in terms of knowledge
- There has been a knowledge explosion for the past 2 decades in terms of research and new science
- There are subsets of orthopedics and then there are subsets of shoulder surgery that involves just research versus just clinical practice
- Alton’s well informed patients ask him about things, and hopefully he knows a lot of it, but he doesn’t know all of it
  - Some of them are very good at looking at true scientific articles and approach him with new articles
  - He is learning every week from his patients about shoulder surgery

**When you went to med school, did you think you wanted to be an orthopedic surgeon?**

- He didn’t know
- Alton had a very circuitous path
- He was an engineer at UT in Austin
  - Mechanical and biomedical
  - His dad was an engineer so he went that way
- At the end, he wasn’t sure about going into industry
- On a whim he went to dental school for a year
  - He had 2 uncles that were dentists
  - He didn’t like that at all, but he loved the science
- He was exposed to the anatomy of the entire body
  - His anatomy instructor at dental school was a MD, PhD and when he confided in her that he was leaving, she suggested he try medical school
- He came back to Austin, TX and painted houses for a year, then applied to medical school
- In med school he loved invasive cardiology
  - All the aspects of the physiology and the electricity going on in our bodies
- Then he was exposed to orthopedics and knew he liked it
  - It felt so natural putting things together, like a jigsaw puzzle
  - It felt all in perfect line with his engineering background

**At the time when you went through orthopedics, was it common for people to also do a fellowship after 5 years of residency?**

- It was
- He went to Tulane, this was pre-[Katrina](https://en.wikipedia.org/wiki/Hurricane_Katrina)
  - It was a big program
  - They had 8 residents per year
  - At the time, about 4 going to general practice
- Fellowships were not ubiquitous then
  - Now they’re almost mandatory because you need to have a special interest because the groups you’d apply to work for want you to have some subspeciality
- Peter agrees, this is the case in medicine
  - Even if you did general surgery and didn’t do a fellowship, you’d be hard pressed to go into the community and do everything
  - You’d probably focus on one part of the body

**Where did you do your fellowship?**

- Upper extremity
- He did a shoulder fellowship at Columbia in New York
- Then he did a hand fellowship at Roosevelt Hospital in New York
  - 2 separate fellowships
  - Most people didn’t do that at the time, but he just really like both very much
- He dabbled with spine during residency
- The reason he wanted to do upper extremity is because there’s nothing cookie cutter about it
  - There were very few cutting jigs, very few linear things
  - There’s so much variability in the upper limb, both anatomy and the specific pathology
  - It was more creative for him

## Evolution of orthopedics and recent advances [8:45]

**What year did you finish your training?**

- He started practice in ‘96

**When did minimally invasive orthopedic surgery become common for joints?**

- Peter recalls, there was a day when the shoulder surgery he had would have been done with a big open incision

- Knee [arthroscopy](https://en.wikipedia.org/wiki/Arthroscopy) was the first big arthroscopic realm to develop
- Dick Asbury was hugely innovative in that space
- Shoulder arthroscopy was primitive by the time Alton was in residency
  - They had the basic equipment to get into the shoulder, but they couldn’t do much
- By the time he finished his shoulder fellowship, they were doing open shoulder [arthroplasty](https://en.wikipedia.org/wiki/Arthroplasty)
- He was at one of the meccas of shoulder surgery, so everything advanced was being done there at the level it could be done
- But it was open shoulder arthroplasty
  - The incisions were smaller but it was still open
  - They did open instability repairs, open labral repairs
- They didn’t appreciate the [slap tear](https://en.wikipedia.org/wiki/Shoulder_problem#SLAP_tear_(lesion))
  - They knew it existed, but they didn’t know the impact
- There were certainly no arthroscopic repairs of the [labrum](https://en.wikipedia.org/wiki/Glenoid_labrum) (see the figure below) except these early devices where you’d get in there, see it, and you’d just drill a little hole and mallet in this big broad tack
  - That was just so primitive, and they would fall out
  - They had a high failure rate, but that was the state of the art at that time

![](https://peterattiamd.com/wp-content/uploads/2022/11/f1-altonbarron.jpeg)

**Figure 1.  Shoulder anatomy and labrum**.  Image credit: [Hospital for Special Surgery](https://www.hss.edu/conditions_shoulder-labrum-tears-overview.asp)

**Was any of this being done in clinical trials?**

- The downside of the tried and true approach is patients would have a big scar and the surgery would tear a bunch of muscle, so the recovery would be longer
  - But, once they got in there, they would know what to do
- In contrast, the minimally invasive way that has all these advantages
  - But the drawback is a high failure rate
- This was the discussion that went on with patients
- The FDA was involved a little with approval, but not a lot
  - So you could go ahead a try these humanitarian devices and so forth
  - The patients had to sign a release and it was all fine
  - There were trusted surgeons that were doing it
- There wasn’t clinical trials
- There were a lot of retrospective analyses going on
  - We did this in 107 patients and 47% failed

**The spectrum of Alton’s work, early on**

- In Alton’s early years, they were still doing mostly open surgery and waiting for the industry to catch up with better devices
- Some of his colleagues (and occasionally him) were adding little bitty innovative aspects of these, whether they’re application devices or the style of implants

***Today, we’ve gone from purely metal to now often purely braided polyester as an anchor device***

- This is super cool because there’s no metal in your body
- And the transition through that was plastic
  - That plastic could be either hard plastic (which stays in your body), but it’s still benign
  - Or a bioabsorbable tacks that Alton has his my own issues with
    - It create an inflammatory response in the body
    - It creates a little cavity in the bone and so forth

***Now we are using tiny drills, tiny suture anchors, and you can put many in***

- Now if you have to do a revision of some failed repair, you’ve got plenty of real estate to work with (that’s nice)

***One other aspect, which shows how much the field has changed, is that*** [***slap tears***](https://en.wikipedia.org/wiki/Shoulder_problem#SLAP_tear_(lesion)) ***were not appreciated as a clinically relevant entity***

- Slap tears were just viewed as another type of labral tear, but a benign one that didn’t matter
- A lot of overhead athletes were coming in with secondary problems as a result of that, and the secondary problems were being treated without treating the underlying stuff
  - They were having recurrent pain

## Anatomy of the upper extremities [13:30]

- Peter thinks to understand and appreciate the complexity of the upper extremity, you have to appreciate what we did during evolution
  - When we stood up, that became an enormous force multiplier
  - If you think about this through the lens of warfare, people talk about having night vision as a force multiplier in war
  - For us to be able to stand and walk with amazing efficiency on two legs was a force multiplier, and then also to have these incredible upper extremities
  - But you pay a price for it, which is stability

***We paid an enormous price in these joints, not as strong, not as stable***

- When we went from the ball on socket joints or the very stable, simple hinge joints to these cup and saucer type joints (specifically the shoulder, which is intrinsically very unstable)
- Our opposable thumb at the basal joint is terribly unstable
  - We call it a biconcave saddle, but it’s barely that
  - There’s really no intrinsic bony stability
- The shoulder is similar, Alton uses an analogy that’s slightly off, “*A golf ball on a tee*”
  - The tee is a little bigger, but that’s what it is, very flat and shallow
- Alton draws quick diagrams for his patients (see the figure below)
- If we look at just the [glenoid](https://en.wikipedia.org/wiki/Glenoid_fossa)‒ that’s the socket, that’s the “golf tee”
- Then you add a [humeral head](https://en.wikipedia.org/wiki/Humerus#Upper_extremity) to it
  - This portion to the right of the dotted line is what’s covered by cartilage
  - That’s the nice smooth Teflon cartilage in this space
- For orientation, if you’re looking straight at a person, this is the right humeral head
- That little space we’re going to talk about is the [glenoid fossa](https://en.wikipedia.org/wiki/Glenoid_fossa)
  - This is the flat end of part of the scapula
  - This is a real complex looking triangular bone with a big ridge on it and collarbone attaches to it

![](https://peterattiamd.com/wp-content/uploads/2022/11/f2-altonbarron-988x1024.png)

**Figure 2. The right shoulder joint with bone and cartilage drawn in black, connective tissue drawn in red**.  Sketched by Alton Barron

![](https://peterattiamd.com/wp-content/uploads/2022/11/f3-altonbarron-1024x600.png)

**Figure 3.  The glenoid fossa on the shoulder, highlighted in red.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Glenoid_fossa)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f4-altonbarron-1024x674.png)

**Figure 4.  The scapula**.  Image Credit:  [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/8-1-the-pectoral-girdle)

- The high level point here is in the hip you have the [acetabulum](https://en.wikipedia.org/wiki/Acetabulum), which creates a true socket for a big ball
  - Alton drew the hip joint above the right shoulder joint, 3 figures above
- Here the heavy lifting really is done by soft tissue, not bones
- The difference between the shoulder and the hip‒ the hip is a joint that is completely contained versus the shoulder, which is a shallow one that can slip and slide all over the place

> “*The best way to describe the shoulder joint being a delicate balance of mobility and stability, and it’s very easy to get out of whack because it is biomechanically so complicated*”‒ Alton Barron

- The space between the humeral head and the glenoid is occupied by a nice thick layer or cartilage on both sides
  - It’s effectively [articular cartilage](https://en.wikipedia.org/wiki/Hyaline_cartilage#Articular_cartilage) there
- When you have **arthritis**, this gets worn down, chipped away, and begins to fissure, and then actually develop full thickness loss to the point where then at some point it’s not really functioning very well and it’s very painful
- If we have this basic bony cartilage structure here, it would just fall off if it were just left there if there were no additional stabilizing structures (drawn in Alton’s figure above in red)
  - Such as ligaments or labrum or muscle tendons
- \*\*Peter mentions that [ligaments](https://en.wikipedia.org/wiki/Ligament) and [tendons](https://en.wikipedia.org/wiki/Tendon) are not the same
  - Tendons are the connective tissue that connects muscle to bone
  - Ligaments are connective tissue that connect bone to bone

**Is labrum considered a ligament or is it considered its own entity?**

- [Labrum](https://en.wikipedia.org/wiki/Glenoid_labrum) is kind of its own entity
- It has a transition zone between fibrous tissue to osseous bony tissue
  - It’s a fibro-osseous structure
  - Alton likens it to calamari, and it’s rubbery just like that
- Alton has drawn on 2 of the 4 rotator cuff muscles here
  - This is the one up above ([supraspinatus muscle](https://en.wikipedia.org/wiki/Supraspinatus_muscle))
  - This is the one in front ([subscapularis muscle](https://en.wikipedia.org/wiki/Subscapularis_muscle)), the big muscle that allows us to reach behind our back and pull our hand away from our back
  - This is also the one that helps us (along with the [pectoralis](https://en.wikipedia.org/wiki/Pectoralis_major)) in front to pull things together (like doing flies and so forth)

**A tear in the supraspinatus tendon**

- The supraspinatus is the primary muscle that initiates elevation of the shoulders, so it’s very, very important
- What we see here is this zone is where the muscle transitions into tendon (highlighted in green in Alton’s drawing above)
  - And then it becomes pure tendon
- For the supraspinatus tendon which is commonly torn, there are some physiologic downsides to its location
  - It can be rung out
  - It doesn’t have a great blood supply
  - The key is it gets where those 2 arrows are (in the left of Alton’s drawing earlier) is essentially where the tendon tears most of the time
  - And that is the part that attaches to the bone, and it gets blood supply from that bone (this includes nutrients and growth factors)
- Surgically, the goal is to get that reattached to that bone so it can get all of those growth factors and that new healing back

**4 muscles that make up the** [**rotator cuff**](https://en.wikipedia.org/wiki/Rotator_cuff)

- The [supraspinatus](https://en.wikipedia.org/wiki/Supraspinatus_muscle), the [subscapularis](https://en.wikipedia.org/wiki/Subscapularis_muscle), the [infraspinatus](https://en.wikipedia.org/wiki/Infraspinatus_muscle), and the [teres minor](https://en.wikipedia.org/wiki/Teres_minor_muscle) (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f5-altonbarron-1024x326.png)

**Figure 5.  Muscles in the rotator cuff.**  Image credit: Wikipedia

- The infraspinatus, and the teres minor are on the backside of the joint
  - You can superimpose them over the subscapularis
  - They are very important as the external rotators
  - They give us our backhand in tennis
  - They give a lot of stability to the shoulder, whether you’re playing golf or lifting weights
    - They’re a dynamic stabilizer
  - They’re very important doing bench press, pushups, archery, all sorts of activities like that

## Rotator cuff injuries, shoulder joint dislocation, and more [21:15];

**When a person “tears their rotator cuff,” that can be a very heterogeneous diagnosis**

- Technically it could apply to a tear in any of those 4 muscles
  - Or a tear in the junction between the muscle and tendon
  - Or a complete separation of the tendon from the osseous structure of the bone
- Alton notes it is critical to identify what the tear is
  - You can predict this somewhat based on the age of the person, their physiology, and the mechanism of the trauma
- Tears are broadly classified into **degenerative tears** and **traumatic tears**
- For younger people (under 40), it’s rare for them to tear their rotator cuff
  - But it can happen traumatically
- Alton had a young fellow who worked as a merchant marine years ago, and he was doing something with the anchor and the massive chain and his glove got caught in that
  - Basically, it almost ripped his arm off
  - He was okay, except that he had torn traumatically as a young 26 year old
    - It ripped off 3 of his 4 muscles and they had to be repaired
    - But he was okay
- It’s that rare, dramatic circumstance that leads to traumatic tears in young people

**Where is the weak link in someone that young? Does it tear at the muscle itself or more at the tendon?**

- The younger you are, the strong the linkage of the tendon to the bone
  - You often pull off some bone
- In the case of a **skier’s thumb** (a common injury in the hand from skiers), the younger you are, the more likely it is to pull off with a piece of bone
- And that’s actually great because bone heals to bone much better than tendon to bone

**Fracture of the greater tuberosity in the shoulder joint**

- There are fractures that occur that involve this area of the shoulder
  - Alton draws a common fracture with a squiggly line, highlighted in yellow in the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/11/f6-altonbarron-1024x910.png)

**Figure 6.  A fracture of the greater tuberosity in the shoulder joint.**  Sketched by Alton Barron

- Alton drew a chunk of bone coming off
  - That’s the [greater tuberosity](https://en.wikipedia.org/wiki/Greater_tubercle)‒ it’s a prominence of the bone that the biggest portion of the rotator cuff attaches
- The supraspinatus and the infraspinatus pulls off
- Alton would rather pull that off and you have a good quality repair than have 2 tendons rip off that bone

**What type of athlete or person presents with this type of injury?**

- That isolated greater tuberosity is generally a fractured dislocation
- You have a pretty violent injury
  - Your rock climbing, you fall off, you maybe hit it directly, your arm is wrenched back
  - Or let’s say a football player has a traumatic dislocation; they’re hit in just the right way mechanically, and it shears that off
- It’s most often associated with the dislocation ([subluxation](https://en.wikipedia.org/wiki/Subluxation) of the shoulder)
  - Technically a subluxation is an incomplete dislocation; it’s the shoulder coming out, but it pops back in easily
  - A dislocation is where the shoulder comes out and it needs to be put back in
- The more dislocations (or subluxations) one has, the more stretchy and compliant the tissues become
  - So then it can slip and slide back in and out with regularity

**Stability of the shoulder joint**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f7-altonbarron-1024x877.png)

**Figure 7.  Right shoulder socket without the humeral head.**  Sketched by Alton Barron

- In the figure above, Alton drew another picture but took the humeral head away
  - We’re just looking at the right shoulder socket and we’re looking at it en fosse (from the side, facing forward), the [glenohumeral fosse](https://en.wikipedia.org/wiki/Shoulder_joint)
- The front of the person is the anterior (labeled Ant. in the figure above), and the posterior (labeled Post.) is to the back
- Superior is up above, and inferior is down below
- Importantly, around the outside (that second circle) is the outline of the labrum
  - That’s a rubbery calamari-like structure, really chewy like bad calamari
  - It’s very strong
  - What is does is amazing because it effectively developed as a way to decrease the depth of the socket
  - It works like a suction cup
  - Alton adds, “*If you take a non arthritic cadaver specimen and dissect away all of the muscle, all the ligaments, and you stick it on the humeral head, on the labrum, it’ll sit there*.”
  - But just like a thermometer held to the window with a suction cup, if you get your finger in there and break the seal, it falls away
    - That’s what happens here

***We get a lot of static stability in our shoulder from this superior, inferior, anterior, and posterior labrum***

**In a nonpathologic state, when you have a young person (who has not experienced any shoulder trauma), is that contained space of fluid between those two cartilaginous surfaces of the glenoid fossa of the humeral head fully contained?**

- Absolutely, you couldn’t have suction without an aqueous, viscous fluid
  - And as soon as you poke a hole in that you lose suction
- You have a nice viscous joint fluid in all of our joints like that

**When a person has a subluxation, it doesn’t necessarily tear the labrum, does it?**

- Correct, and that’s another huge point that factors into Alton’s treatment recommendations and mechanisms of injury
  - If you are a young woman playing soccer, women in general have looser joints
  - Actually, because of the weird nature of the shoulders, there are men who also have super loose shoulders at baseline (they’re born that way)

***In general, if you think of someone whether male or female who has super loose joints, then they can sublux out in and out without tearing anything***

- They just ride up over that because it’s just loosey-goosey
- The tighter the shoulder is, the more you have to lose

**What happens to the fluid when they sublux?**

- Nothing, the ligaments are stretchy and they’re bigger
  - “*It’s more like a balloon that you’ve kept blowing up repeatedly*”

**Shoulder dislocation in someone with a stable joint**

- But if you have someone who has a pretty stable joint (not loosey-goosey) and then they sublux, the only way you can do that is by **tearing the ligaments**, but usually you also **tear/** **separate the labrum** (the inner arc in the figure above)  from its hard, bony cartilaginous, perfectly fused attachment
  - This attachment is very strong
  - It takes a massive force to dislocate the shoulder or perfect mechanics
- For example, classically, if you’re reaching up to get a rebound and someone grabs your arm and jerks it backwards, that’s an unnatural leverage that makes the head tend to go out anteriorly inferiorly (in the bottom-left direction in the figure above)
  - And that’s also a vulnerability based on where the muscles attach
- This labrum is tough, but it tears off
  - On the right side of the drawing above is the classic location where you tear the labrum
  - It takes either a small tear that then is repetitively increased in size just from aggressive, but repetitive use
  - Or it takes a one-time significant dislocation

**The attachments of the 4 rotator cuff muscles**

- Muscles are drawn as ovals around the outside of the [rotator cuff](https://en.wikipedia.org/wiki/Rotator_cuff) in the previous figure
- These are the cross-sections of the muscles that are just outside the joint
  - These encompass and enshroud the joint
  - This is the cross-sectional muscle bellies
- As you’d come further out toward the head (to the left of the drawing), they taper down and form the tendons

***That’s so important because no shoulder can be stable alone just by these static stabilizers, the labrum and the ligaments***

- The ligaments lie in between the labrum and the rotator cuff on the right edge of the drawing

**When you’re referring to a** [**SLAP tear**](https://en.wikipedia.org/wiki/SLAP_tear)**, SLAP stands for superior labral anterior posterior**

- That is on the top side of the diagram (the superior), the green line labeled SLAP
- That’s an odd injury
- The first person that taught us about this was a fellow named [Steve Snyder](https://www.linkedin.com/in/stephen-snyder-673226157) in Northern California
  - He was the first to categorize and identify these as clinically relevant entities
- SLAP tears are not clinically relevant for everybody
- They are relevant for younger, very athletic people (overhead athletes, weightlifters, people doing CrossFit, people doing all manner of more aggressive sports)
- This is different from having a tear in the right side of the previous figure
  - You’re active and you keep dislocating, subluxating in the direction of the arrow
- This was Peter, he had a big anterior inferior tear

## Peter’s shoulder problems [31:30]

- Peter had his first subluxation in boxing when he was about 17
- He remembers 2 injuries in high school
  - The 1st subluxation was boxing and just bad timing throwing a hard punch, and the guy gets out of the way and probably smacked his arm and it came out
  - The 2nd one (6 months later) was doing an absurdly heavy military press, and he remembers boom, it just popped out (and down)
- From then on, it was a vicious cycle of never ending subluxations with each couple of years having a really bad one
- Another really bad one was during an open water swim race, swimming freestyle
  - He’s in the reach phase with his right arm in front, and the swimmer in front of him kicked down on that arm with some force (but not absurd), and the down kick of that arm took him out
- Alton notes Peter is describing so many great and different types of mechanisms that cause shoulder dislocation
  - Especially boxing, he’s seen a lot of these‒ the recoil where you don’t hit something your body is anticipating and it’s tightened up and ready for a contact that doesn’t happen
  - It’s no different than there’s an extra step in front of you that you don’t know about, and you step and you go, whoa, and then you feel like it shutters your whole body
  - Peter probably did have a posterior subluxation
- Peter had a tear going all the way from posterior all the way around, about 240 degrees
  - Indicated in the previous figure by the blue line
  - You don’t get that from 1 injury
- It became looser and looser over time and because Peter is so fit, he was compensating for it very well
  - He was doing all the right upper body, shoulder strengthening exercises
  - He was using his dynamic stabilizers to compensate for the loss of static stabilizers

**Dynamic stabilizers can compensate for the loss of static stabilizers but they will fatigue, leading to problems**

- What happens is when you are maxing out and doing it repetitively, the dynamic stabilizers fatigue
  - This is one of the most common scenarios Alton sees in young swimmers (more often female)
  - They’re competing and they need the stability, especially they’re doing flying fly and backstroke
  - They acquire all this laxity in their shoulder and they’re so strong dynamically that they’re fine and it gives them that extra pull, that extra inch or two
  - Fatigue is a problem
    - If they have a weekend-long match (8 events in 3 days), they are fine the 1st 2 days, but by the 3rd day, they are fatigued and then they start subluxing
    - Then they get all this secondary inflammation and pain and that’s when the damage occurs and they have to sit out
  - Then we have to strengthen rehab, sometimes even tighten up the capsule when they get so loose

## The structure of the biceps and common injuries [35:30]

- The [biceps](https://en.wikipedia.org/wiki/Biceps) tendon can be incredibly painful ([tendonosis](https://en.wikipedia.org/wiki/Tendinopathy))
- Peter thinks for an average person, it’s not entirely clear where that pain is coming from if they feel pain there
- Alton notes that the biceps are a weird structure, and it’s part of that weird evolution we have
- The biceps is 1 muscle in our arm, but it’s 2 tendons at the origin in the shoulder (see the figure below)
- It has a single point of attachment in the forearm, crosses the joint as 1 muscle and then splits into 2 bellies with 2 attachment points

![](https://peterattiamd.com/wp-content/uploads/2022/11/f8-altonbarron.png)

**Figure 8.  Anatomy of the bicep muscle tendon.**   Image credit: [OrthoVirginia](https://www.orthovirginia.com/blog/the-biceps-tendon/)

- The long head (indicated in the figure above, also shown in Alton’s previous drawing) is the one that often gets inflamed
- It can be quite painful and can affect everyday life
- The 2nd tendon peels off and goes outside the joint (the short head in the figure above, also shown on the left most side of Alton’s previous drawing)
  - It attaches to a bony prominence in that weird scapula that they talked about
  - It attaches there and literally never tears
- But people often do tear this biceps (labeled in Alton’s previous drawing)
  - Due to wear and tear or acute trauma
  - It leads to a classic [Popeye muscle](https://en.wikipedia.org/wiki/Biceps#Clinical_significance) where half their muscle is balled up and looks weird
  - It’s not really that much of a functional consequence
  - Usually it stops hurting when it ruptures
  - [John Elway](https://en.wikipedia.org/wiki/John_Elway) (the great quarterback from Denver) was having shoulder pain and was even thinking about retiring
    - His biceps tendon ruptured, the pain went away, and then he won another 2 superbowls after that
- It’s a structure that’s not necessary and there’s a lot of argument in orthopedics about how important it really is
- It is anchored up at the superior labrum
- When you tear that superior labrum, that biceps does funky things
  - It becomes unstable and it gets more inflamed often
  - Then you get all that secondary pain
- Some people (not Alton) who fix a lot of these will automatically just snip that biceps and reattach it in the front so it’s no longer a pain generator ([tenodesis procedure](https://www.orthomedctr.com/tenodesis.php))
- Alton only performs a tenodesis when he sees tearing, splitting, something structurally wrong with the biceps
  - He knows he can get a good repair of the superior labrum, and once that’s stable, the biceps is fine again (it’s no longer symptomatic)

## Labrum tears in the shoulder and natural loss of cartilage with usage and time [38:15]

- Peter makes a comparison, “*The torn labrum is to the shoulder what the disc herniation is to the back*”
- You could take a MRI of a person who has no spine issues and see many asymptomatic herniations, which mean nothing
- He suspects a labral tear in the shoulder is the same
  - Alton agrees, and this is such a point of frustration
  - Radiologists do their job in reading abnormalities
  - The problems is that most of us by middle age will have plenty of positive findings, but they’re asymptomatic

> “*It’s a very double-edged sword to get those MRIs.  Same thing in the labrum*.”‒ Alton Barron

- The labrum will naturally degenerate just by using it, so will the cartilage
- We know there’s a genetic predisposition to arthritis
- By arthritis, Alton means not just inflammation of the joint, but a true loss of the cartilage integrity
  - Those two terms are used interchangeably by different people in different subspecialty
  - But for an orthopedic surgeon, it’s when the joint is degenerating and the cartilage surfaces are no longer pristine (just like you’re chipping the paint on your car)

**Does loss of cartilage integrity occur preferentially on the humeral head or in the glenoid fossa?  Or is it one of those things where the second you get one chip, it starts happening on both sides?**

- We don’t have a good natural history of that
- Alton has done total shoulders on people who had no cartilage left on their humeral head
  - It was perfectly round and smooth bone, there was no cartilage left
  - Whereas the glenoid still had cartilage on it
  - That’s a case where the loss on the humerus was smooth enough and gradual enough to where it didn’t dig in and eat away at the socket
  - But it doesn’t matter, you still have to replace the socket
- For younger athletic people, who have a humeral head that’s been damaged and they have a big chunk, maybe a quarter size (maybe a 50 cent piece size) of full cartilage loss, that’s not great
  - That just keeps sloughing off cartilage and keeps getting inflamed
  - They’re on the young side so you don’t want to do a shoulder replacement on them
  - Instead, they will do a humeral head resurfacing (a nice, new, smooth metal head), but they leave the glenoid intact and they have good cartilage there
    - So, it’s metal on natural cartilage

**What kind of metal is used?**

- Cobalt-chromium alloys
  - Just like the hips
- The nice thing about those is, if you can get 5 years, they can be much more aggressive with their activities
  - Aton has some people who get 10 years and are fine
- If it does wear down the glenoid side, then you just go back in and revise it and put a plastic cup for the glenoid

## Shoulder evaluation with MRI vs. physical exam, diagnosing pain, and when to have surgery [41:30]

**The contrast between MRI findings and the physical exam**

- Peter remembers the first time he saw Alton (about a year before his surgery), he knew his labrum had been torn to shreds for years but didn’t want to have surgery unless he really needed to
  - In that first exam, Alton agreed, he wasn’t ready for surgery yet

**How do you test the surrounding structures to elicit feedback on the labrum?**

- Alton is glad Peter asked, “*Because one should never make their clinical, especially surgical decision-making on just an MRI*”
- Alton has written a couple of book chapters on this, including complete examination of the shoulder with provocative maneuvers and so forth
- It’s important to get a good history of the mechanics of the injury
  - Whether it was from shooting a bow and arrow, playing basketball, lifting weights, etc

***You need to know a combination of the mechanism of injury, the symptoms, and the physical exam,  and if you do those compulsively and well, you will be 95% accurate without any MRI***

**When to have surgery**

- Peter remembers one of the things that changed before his surgery
  - He couldn’t serve a volleyball with his daughter
  - He couldn’t shout one basket
  - But he could pull a 95-lb bow back and take 100 shots
  - This didn’t make sense to him
- It all comes down to the mechanics of each individual and this is where the MRI does come in
- Alton uses MRIs more to corroborate things that can be there
  - The difference between a partial thickness rotator cuff tear and a full thickness or a full thickness small and a full thickness large
    - Those are variable based again on the patient’s activity
- Alton adds, “*We know from good studies done with ultrasound MRI that walking down the street, half the people age 60 have rotator cuff tears*”
  - They’re asymptomatic
  - It may not be a big tear, but it can be

***It’s so important that we don’t ignore something that can get much worse and make treatment or recovery much more difficult.  But at the same time, we need to be more circumspect about who we’re operating and who we’re not operating on.***

**Are there indications where we operate on asymptomatic things in the shoulder?**

- In general, no
- Unless you have a tumor
- Alton was swimming with his dad about 6 months before he passed away (at age 95)
  - His dad was really vigorous, mentally and physically fit
  - He ended up having pancreatic cancer that killed him at 95
  - He had a great life, no complaints
  - At 86, he was a guy who could still do pull-ups, who was swimming in the lake
    - Peter adds, “*This guy is my hero*”
  - He did all his own yard work, everything
  - He never took medication
  - He was running to get out of the way of the sprinkler, did a banana peel, and had a dislocation of his shoulder, ripped off two and a half of his four tendons
    - Remember, one of them never tears, so he tore almost his complete functional rotator cuff
  - Alton did a little FaceTime with his dad and noticed he couldn’t lift his arm
  - He urged his dad to visit and get an MRI
  - Alton and his partner fixed him
  - They didn’t give him much sedation, just regional anesthesia, and he got a good 6 anchor repair
  - At age 94, you couldn’t tell he ever had a tear
    - He healed and went back to doing everything

**What would have been the natural history for Alton’s dad if he didn’t have this surgery?**

- A lot of doctors might have left him alone, and then he would have been miserable for the next 9 years of his life
  - Because he couldn’t lift his arm
  - It might not have been that painful, but he wouldn’t have been able to do everything he wanted

***Pain shouldn’t be the only symptom we look for‒ we have to look for function***

- If someone came in with a traumatic motor vehicle accident where they tore their rotator cuff badly at age 60, 65
- Alton would tell them it’s not necessary to have them repaired
- But if you don’t repair it, those muscles that lost their muscle-tendon connection are going to atrophy
- It may not be painful, but if you want to do things you were doing before the accident, they need to be repaired
- The 2nd caveat is you may start having symptoms in 6 months even doing those other things
  - If you do, don’t ignore it, go back to the orthopedist
- It’s a dynamic state over a long period of time; so you need to be flexible

***If you start having symptoms when you’ve been asymptomatic, something has changed (anatomically, physiologically or something), and it’s time to reassess***

**When a person comes in with shoulder pain, what is on your differential diagnosis in the exam (before the MRI)?**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f9-altonbarron-1024x559.png)

**Figure 9.  Front view of shoulder anatomy**.  Image credit: Alton’s drawing and [Wikipedia](https://en.wikipedia.org/wiki/Acromioclavicular_joint)

- Alton drew the shoulder again and added the [clavicle](https://en.wikipedia.org/wiki/Clavicle) (collarbone) and the [acromion](https://en.wikipedia.org/wiki/Acromion) (the bony roof of the shoulder, another part of the weird scapula), see the figure above
- When you hear about someone separating their shoulder, this is the [acromioclavicular joint (AC joint)](https://en.wikipedia.org/wiki/Acromioclavicular_joint)
  - Circled in red at the top of the drawing above
  - It only rotates about 20 degrees
- The collarbone is a stabilizer bar
  - For car lovers, it’s effectively a [MacPherson strut](https://en.wikipedia.org/wiki/MacPherson_strut) on a car
- Some people are born without collarbones and they can bring their shoulders completely together in the center
- In cyclists, collarbones are the most commonly injured because they land on the outside of their shoulder
- The AC joint is what happens when people separate their shoulder (also super common)
  - It’s different from a dislocation
  - It’s usually from a force coming down from the top
  - So we’re pitched forward, we land on the point of our shoulder and it jams it down (we can talk about that later)

## How anatomical variation can predispose one to injury and how screening may help [50:30]

- The acromion is that bony roof, and under that roof is where the rotator cuff glides
- As the head rotates back and forth around, the rotator cuff is attached here and it goes back and forth here, and it’s rubbing or moving underneath this
  - See the arrows back and forth in the previous diagram
- Any place in our body that there’s two structures, anatomically in the limbs that move differentially with one another, there’s usually a [bursa](https://en.wikipedia.org/wiki/Synovial_bursa) that forms in between
  - So, that bursa is drawn in green (in the previous figure)
  - That bursa is just a thin filmy structure that can thicken up and become very inflamed and become [bursitis](https://en.wikipedia.org/wiki/Bursitis) (very painful)
    - That’s a common, common diagnosis
  - Otherwise, the purpose of the bursa is to allow these things to glide past each other frictionless
- Then some of us are born with an extra kind of downsloping of that [acromion](https://en.wikipedia.org/wiki/Acromion) (shown in the figure below), or a bone spur, or we acquire it from repetitive athletic use (there are multiple reasons)
  - Also indicated in Alton’s drawing by the red shaded area at the top left, on top of the bursa (which is green)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f10-altonbarron-1024x577.png)

**Figure 10.  The acromion on the shoulders and left scapula highlighted in red**.  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Acromion)

- It’s as though you have a big bird beak coming down and pointing into the bursa
- You can imagine if this is running back and forth, it’s irritating the bursa, creating bursitis
- And it’s also frictionally rubbing against the rotator cuff tendon
- You can get bursal-sided upper part rotator cuff tears from that alone
  - Alton knows because he had a big spur like that in his shoulder

***For Alton, the spur occurred because he was genetically predisposed to it based on the shape of his bursa***

![](https://peterattiamd.com/wp-content/uploads/2022/11/f11-altonbarron-905x1024.png)

**Figure 11.  Front view of shoulder anatomy with 3 types of acromion (in blue).**  Sketched by Alton Barron

- You can have a type I, a type II, or a type III acromion (drawn in blue, at the top of the figure above)
  - Type I is totally flat (this is the majority of people)
  - Type II is the second most common
  - Type III predisposes you to this problem (about 30% of people have this type)
    - You’re only at risk of you are an overhead athlete, lift weights overhead or do aggressive things
    - If you’re sedentary and never exercise, you’ll never have a problem because you’re not repetitively loading it enough to wear it down or cause a tear
- Peter relates that people often say “*Well, I can do so and so and I’ve never had an issue. Therefore, it’s okay.*”
  - If you have the type I acromion, you can probably get away with a lot more overhead activity
  - But for somebody who’s in category III, every time they do excessive overhead activity they might get injured
- Peter thinks it would be interesting if we knew these things in advance and we could maybe modify and temper our activity around our genetics effectively
- Alton agrees, the anatomic/ mechanical predisposition to injury is interesting

**Peter’s personal example of anatomical predisposition**

- Peter had an MRI for other reasons and discovered he has a narrow C-spine (there’s no wiggle room)
- As a result, he takes” tech neck protocol” very seriously
- He know he already has 2 small herniations
  - Luckily, they aren’t doing anything to him
  - But nobody’s going to go in and remove one without doing the other, which means they’d fuse him out of the gate
- Knowing this is helpful
  - It tells him to do a lot of rehabilitative exercises even before having an injury
- He thinks he’s fortunate he’s no longer a surgeon, because a lot of his surgery colleagues ended up having neck surgery (resulting from working in a certain position all the time)
- Peter never thought about this from a joint context
- Alton adds, “*If you have a congenitally narrow stenotic spine and you’re playing football, you’re way more at risk for catastrophic spinal cord injury*”

**Screening for anatomical predispositions to injury**

- Alton was team doctor for almost 15 years a college up in New York
  - But if you have your first stinger, then you need to be screened, and see if you are at high risk
  - If you are, then you have a very serious discussion about what you’re subjecting your neck to
    - There are a lot of sports to play, and you don’t necessarily have to be butting heads at high velocity
- But it hasn’t been done in the shoulder
  - It’d be a simple, easy screen
- This could be important for kids who have a lot of athletic potential, and at age 11 are going to decide what to focus on
  - If you knew you’d have a longer shelf life in one sport over another, that should weigh into the decision-making process
- For instance, if you have super loose joints, then you’re going to need to pick the ones that you can keep dynamically stabilized but are not going to be subjected directly to unnecessary forces

## Pain generators in the shoulder, and the important nuance of the physical exam [56:00]

**Pain generators in the shoulder**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f12-altonbarron.png)

**Figure 12.  Front view of shoulder anatomy with 3 types of acromion.**  Sketched by Alton Barron

- A type III acromion can be a pain generator
  - Drawn in blue at the top of the drawing above
- The AC joint is another one
  - Circled in red in the drawing above

> “*Almost everybody through wear and tear, middle age and beyond, has arthritis in the AC joint… it’s almost always asymptomatic, but it can be symptomatic*”‒ Alton Barron

**The little red structure you’ve drawn, that ligament that is connecting the clavicle to the acromion, is there fluid within that space?**

- There’s a tiny amount of fluid, but very little
- Any place there’s cartilage, there’s a tiny amount of fluid
- But it can expand, and if it’s arthritic, you can get more fluid
- Young weightlifters can develop fluid in the end of the clavicle from repetitive use
  - This end of the clavicle is shaded in red in the previous drawing
  - Doing heavy bench press and other activities can result in distal clavicle [osteolysis](https://en.wikipedia.org/wiki/Osteolysis)
  - Repetitive jamming or bruising of the bone and cartilage causes the cartilage to disintegrate and the bone to lose its integrity
    - It starts to get very soft and it gets very inflamed
  - As soon as you start breaking up cartilage, all the macrophages from the body come in there and then you get a big inflammatory response
    - You get a lot of extra fluid and a lot of pain

**From a chronic perspective, does this occur more in somebody doing bench press or military press or which direction?**

- Yes (in both) and also with heavy lat raises
- Lat raises puts so much leverage on that joint, it just jams up
  - Alton does *not* recommend his patients do these
  - If you are to do it and want to minimize stress, Peter is in favor of thumbs going up (not down), and not directly laterally but more in the natural plane of the scapula

**More about the biomechanics of this joint**

- If you lie directly on the point of your shoulder and it jams that again, and causes a lot of pain there
- That pain comes right down the front and kind of follows the biceps
- So, you have to differentiate that between the 2
- Then you look at an X-ray (without an MRI), and you see these **spurs** that are down there
  - The area of the previous drawing circled in red, near the AC joint
  - Well, those spurs aren’t ever going to tear the rotator cuff, because that tendon is out there (to the left)‒ it never gets that far
  - But it rubs, and we see it as an indentation in the muscle
  - Every time you’re working out, you hypertrophy your muscles, so if you have that constantly rubbing there and then you hypertrophy around it, it hurts
    - Peter notes, “*That’s an athlete who complains that when they’re lifting, it hurts more*”
    - Yet when they’re relaxed and haven’t been exercising, they have rock solid strength
    - But if you get them up into positions, or if they’ve been working out and you test them, they’ll be weak (their brain stops them to prevent pain)

**The nuance of the shoulder exam**

- This reminds Peter of a book he read once he decided he was going into surgery, [Cope’s Early Diagnosis of the Acute Abdomen](https://www.amazon.com/Copes-Diagnosis-Abdomen-Twenty-Second-Paperback/dp/B09WQDW15R/ref=sr_1_1?crid=15ZHSRU3KI5W8&keywords=cope%27s+early+diagnosis+of+the+acute+abdomen&qid=1667240251&qu=eyJxc2MiOiIxLjc5IiwicXNhIjoiMS4zOSIsInFzcCI6IjEuMjUifQ%3D%3D&sprefix=Cope%27s+Early+Diagnosis+of+the%2Caps%2C69&sr=8-1)
  - The entire book was based on diagnosing appendicitis
  - Peter thought it was the most fascinating thing in the world, because you had this old school general surgeon who said, “*This is 100% a clinical diagnosis*”
    - This was before anyone was using a CT
  - An appendicitis is the single most prevalent condition in general surgery
  - Nobody training today would ever dream you could waste an entire book to diagnose something where you could just shove somebody in the scanner and get the answer
- This exam makes Peter thinks of Coope’s Appendicitis because things are more complicated
- Peter doesn’t think there will ever be a substitute for the nuance of the exam and the history of the injury and of what causes pain
- For Alton, the guy who was his Cope was his Professor of Cardiology at Tulane, [C. Thorpe Ray](https://tmedweb.tulane.edu/clubs/ctr/about-dr-ray/)
  - He was in his 80s at the time
    - He had thyroid cancer and spoke in a very hushed tone
  - He could tell you exactly what was wrong with which heart valve just by listening to you with a stethoscope, with his hands, sometimes he just put his ear up there
    - He could tell by the nature of the subtle variations in the heart murmurs what the diagnosis was

> “*I do lament the fact that that’s a dying art*”‒ Peter Attia

- Peter acknowledges, the reality of it is that today with echo and stuff we’re better
- He was probably such an outlier that most people could never reach that level
  - Just like most people could have never attained the clinical acumen of Cope
- It would be great to have both
- Peter adds, “***It’s interesting to think that in orthopedics it might be one of those specialties where this judgment of the exam is still really, really relevant***”
- Alton agrees and adds, you get pinpoint diagnoses with the various tests
- There are plenty of things you find with tests that aren’t symptomatic
- Alton points out, “***But our patients need us to be able to still diagnose, listen to them, hear what they’re saying***”
  - You want to hear the patient’s story and know what’s really going on to determine whether they need surgical or non-surgical care or what kind of care they need
- Peter felt like this was a very important message in residency, “*The single most important thing that you will learn is when to operate and when not to operate*”
- When you start residency, you’re just so preoccupied with mastering the technical side of things (there’s so much to learn)
  - It’s like learning to master an instrument and learn a new language at the same time, and you’ve only got 5 years to do it
- Alton agrees, but unfortunately there are plenty of people who will operate on any MRI
- Peter adds, “*We had one surgeon who the joke was, if you rubbed Betadine on the wall, he would operate on the wall. Don’t let Betadine near the wall, because he’ll start cutting it*.”
- Alton agrees, there are economic incentives
- He has to suppress that information because it makes him too cynical and sad, but it happens
- He sees patients that walk in with their MRI all the time and say, *“I’m scheduled for this surgery in my shoulder or my elbow. My friend said I should just come get one more opinion*.”
  - Alton does the exam and does not find a need to operate
  - He tells them, “*Look, I wasn’t there at the time of your examination, so I can’t speak for what that person saw and what their statement is. But today, based on your MRI, your history and your physical exam, I will not operate on you… Maybe someday, but not now.*”
    - Sometimes this is confusing for patients
- Peter notes, “*The thing you always have to remember as a patient, and I think of this myself, is once you commit to doing something, the inertia to do it is huge*”
  - There is an asymmetry in this decision‒ to not have surgery doesn’t remove any options
    - You can have surgery later if it is the right thing to do
    - Once you have surgery, the operative field never looks the same the second time
    - So, you want to keep in mind the asymmetry of a pause

## Frozen shoulder [1:05:15]

**Shoulder pain can have many causes**

- The AC joint can be the problem
- Bursitis
- A rotator cuff injury
- A labral injury
- Bicep tendon inflammation
- Arthritis
- Adhesive capsulitis (discussed next)
- Neck pain from the spine (discussed later)

**Frozen shoulder (adhesive capsulitis)**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f13-altonbarron-1024x898.png)

**Figure 13. The capsule in the shoulder joint.**  Sketched by Alton Barron

- The best place to see the capsule is with a MRI because it’s thicker there and more distinct (there’s not other structures obscuring it)
- Normally, if you have a super loose joint, you can have a very capacious capsule like that, that allows it to flop down and even sublux or dislocate
- When it’s very high and tight and thick there, that can be representative of something called [adhesive capsulitis](https://en.wikipedia.org/wiki/Adhesive_capsulitis_of_the_shoulder)
  - This is very common, and it can conflate all sorts of diagnoses
    - He sees 2-3 new cases every week
  - The **frozen shoulder** is the layman term for adhesive capsulitis
- We don’t know why this happens but it’s multifactorial
  - Like many things, it’s worse if you have diabetes
    - But you don’t get it with more frequency if you have diabetes
  - There’s a lot of misinformation about it because the old literature says it will get better with time (not true)
  - Only about 1 out of 5 of Alton’s patients actually ever need surgery, and he never does this at the beginning
    - Surgery would be a simple, 30-minute release of the capsule and reduction of the inflammation
  - 80% do not need surgery, they need some way to control the inflammation along with really good physical therapy and a home program
    - To restore mobility
- You can get a stiff shoulder if you have impingement
  - If you have a big bone spur and your brain says “*I’m not going to let you move it there*”, then it just gradually stiffens up
    - That’s a secondary stiffness or adhesive capsulitis
  - It’s not the weird primary adhesive capsulitis that could happen to you or me just suddenly
    - It’s a spontaneous intense inflammation in the inner lining
    - If you take a little camera and stick it in there and just look, you see it’s beet red
    - Normally in an arthroscopy, everything’s kind of off white

**Does a frozen shoulder respond to NSAIDs or is this a part of the body that doesn’t have enough of a vascular supply in the capsule that you don’t get enough penetration?**

- It has a rich vascular supply
- Alton gives NSAIDs when people want them and are afraid of an injection
- But he thinks NSAIDs aren’t strong enough
  - That inner lining is so robust
  - He likes to put a small dose of **cortisone** into the joint 1 time
- He always injects cortisone from the back for 2 reasons
  - 1 – This part is more richly supplied by the brachial plexus, so it’s more sensitive
  - 2 – People kind of see you coming at them with a needle
  - He never uses an ultrasound, you can feel where you’re going
- He puts local anesthetic in there as well
  - People come in with a lot of stiffness and pain, and they walk out saying “*Oh my gosh, it’s amazing*”
  - So for these patients  they’re free in 10 seconds
- They probably still need physical therapy, but they feel dramatic relief from such a simple treatment

**Do you recommend that a patient with frozen shoulder err on the side of earlier intervention with a cortisone shot to then allow them to do more rehab sooner? Or do you want them to do 3 months of rehab first?**

- It depends on their exam, their history and how long they’ve had it, and how acutely symptomatic it is
- When examining them, if Alton can stretch them and they say it hurts a little at the end, but they have decent motion
  - They are simply tight and need PT to really stretch them out
  - They don’t need anything else, not even NSAIDs
- But if he can’t get them to move and they’re screaming, they’re not going to get anywhere in PT (because it will hurt too much to do it)
  - So he’ll inject them and send them to PT
- He always sees them back in about 6 weeks
- Much of them are dramatically better, but not all of them
- Very rarely they need a second shot
- Then some of them are just recalcitrant and they just stay stiff, and then Alton will do the little surgical procedure on them

## Shoulder pain that originates in the neck [1:11:15]

- A big source of shoulder pain is referred pain from the neck
  - Alton includes this in his shoulder exam
- Alton takes care of a lot of professional musicians; their necks are doing all sorts of crazy things (think of a violinist)
- All types of musical instruments lead to having to maintain these certain postures that sometimes are very counterproductive to one’s overall musculoskeletal health
- People will come in with shoulder pain going down their arm, maybe even down to their hand
  - They’ve already gotten a shoulder MRI
  - They’re 55, and they have 4 findings on their MRI, ***but the pain is not coming from their shoulder, it’s coming from their neck***
  - Alton has to make sure and differentiate that, because the worst thing he could do to them is have them take time off from music to fix what doesn’t need to be fixed in their shoulder and then have them return

**What in the exam makes you think to look at the neck first with the MRI?**

***For intrinsic shoulder pathology, almost never does the pain radiate down below the elbow***

- Whether it’s a rotator cuff, whether it’s impingement, or whether it’s arthritis

***Whereas neck origin almost always goes down below the elbow and into the hand***

- Whether it’s a pinched nerves at any the lower cervical spine (where it’s more common to have pathology)

- One odd ball is C7
- Alton learned this not that long ago from some really great cervical spine surgeons‒ if you have a deep posterior pain under your scapula, that can be C7
  - He’s had two musicians recently, both with that diagnosis

![](https://peterattiamd.com/wp-content/uploads/2022/11/f14-altonbarron-1024x531.png)

**Figure 14. Cervical vertebrae highlighted in red, numbered from top to bottom C1, C2, C3, C4, C5, C6, C7.  The C7 vertebra is highlighted in the second panel**.  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cervical_vertebrae)

- Peter understands as the only time he ever had a neck issue, the pain didn’t present as neck pain
  - One morning he woke up and his left trap felt like it was in spasm
  - He ignored it thinking he slept wrong
  - The next day it was super uncomfortable and still in spasm
  - This went on for a week
  - He realized he had never had a muscle this tense for this long
  - About this time he started to notice a abrupt loss of tricep strength in the gym
    - He was doing skull crushers where you have 2 dumbbells
    - All of a sudden, he couldn’t move the weight with his left arm
    - It progressed rapidly so that in about 2 days he couldn’t pull his bow back because he couldn’t extend his left arm
  - He had these motor symptoms but had zero pain in his neck
    - No numbness, tingling, no paresthesias anywhere
  - He saw a surgeon who shared Alton’s ethos and recommended rehab first
  - She wanted to do an injection, but Peter wasn’t excited about it because it was an anterior injection
    - So he tried prednisone and traction
  - Within 3 months his strength was back and the problem never returned

> “*That was a real wake-up call to me that I had a cervical symptom that didn’t present with any neck pain*”‒ Peter Attia

- Alton thinks this story is so instructive
- He won’t get MRIs or x-rays of the neck; instead often gives one very low dose of prednisone, and it usually goes away

\*\*\*

**Shoulder exam:**

**Discussion about the shoulder + shoulder eam:**

\*\*\*

## Surgical treatments for a labral tear, and factors that determine whether surgery is appropriate [1:16:00]

**Peter had repair of a complete labral tear.  Is the approach the same for repairing a SLAP tear?**

- There’s just a little more to do, technically
- The largest incisions are 1-1.5 cm
- The others are small percutaneous holes to put cannulas in and then drill through
- It takes 10 minutes to do each anchor, and Peter needed a bunch
- Peter recalls, the exam under anesthesia is crucial
- Alton points out that with a dynamic exam, your brain has been dealing with this problem for a long time
  - Peter has been exercising and has good muscle tone, so if Alton is examining him, he probably can’t sublux his shoulder
  - Usually, he can get 1-2 subluxations before the patient tenses up
- Alton points out, the great thing about an exam under anesthesia is he can move the patient’s arm freely
  - The patient is on a regional block where their arm is super numb (they’re in a position where they’re going to have the surgery)
  - They are so sedated and relaxed, they can’t control anything
  - The patient’s muscles have very little effect
- Alton tests the static stabilizers
  - For Peter he could take it pretty far out back and could completely dislocate his shoulder out the front
  - This tells Alton important information and what to look for on the inside
- Now when he looks on the inside, he needs to asses not just the labrum (which he knows is torn) but also the capsule
  - In the case of the anterior, Peter had been like the balloon you’re blowing up repeatedly
  - He’d also been stretching out his capsule
- He was still compensating, less well and less well with the muscle
- So if that is stretched down the front, Alton needs to know that
- In addition to just repairing the labrum itself, he needs to gather up some of this capsule (which has become too capacious), and do what we call a **capsulorrhaphy** (which is to gather and tighten that up too)
  - That’s kind of a judgment call
  - When you’ve done a lot of them, you kind of know how much to gather
  - You don’t want to gather too much because then it tightens them up too much

**Caveat about unnecessary surgery**

- Alton had a professional violinist in her early 60s who had shoulder pain
- She saw a sports doctor, got an MRI
- She had some degenerative labral tearing that he said needed to be repaired
  - Her MRI didn’t really say anything else
- She presented with shoulder pain and a little stiffness
- The sports doctor did a repair of the labrum and she came to Alton about 6 months later in tears
  - She had not been playing for 6 months and had the stiffest shoulder he had ever seen (it didn’t move)
- The doctor did a labral repair in a 62-year-old, who’s not an athlete, and really tightened the capsule
  - In someone who’s not an athlete it would never be necessary
- Alton had to go in and scope her
  - It was really hard because it was so tight
- He had to bit by bit, release everything that had been done and release the capsule that was all crunched up and tightened up
  - He even had to take some of the sutures out to free up her shoulder

*What was her initial injury?*

***-Alton thinks she simply had the classic frozen shoulder***

- Maybe she should have had PT plus a single injection of cortisone to reduce the inflammation (at most)
- The surgery was the exact opposite; it produced a complete tightening of the capsule
- There’s a school of thought in orthopedics that says, “*We just don’t like repairing labrums and doing capsule repairs in older people because that’s the outcome you get,*” and that’s valid

**How does age factor into the decision to operate?**

- Some people thought Peter was crazy to have a labral repair at age 50
  - But he hasn’t lost any mobility, which is remarkable
- In Peter’s case, Alton doesn’t think there was a choice because of his subluxation with all the different activities
  - He already had some arthritis
  - He was wearing down some cartilage
  - It was this surgery or the inevitability of having a shoulder replacement in another 10 years
- For Peter, knowing what he knows now (that there is a little arthritis there), he wishes he had had surgery sooner
- He had a ton of pain 10-15 years ago, but got out of it with a lot of good tissue work and training
  - He made some modifications and decided there were certain things he couldn’t do
- Alton notes that people now are so much younger physiologically (in better condition)
- We know that a 50-year-old now cannot be compared to data of 50-year-olds 20 years ago
  - So Peter is not a typical 50-year-old from the literature

***Alton based his decision on biological age, not chronological age***

- There are some people he scopes because there’s no other way than looking to see what’s there
  - Sometimes they have better cartilage than what the MRI is indicating and he can go ahead and do a repair
  - He’s done a couple of 58-year-olds, 60-year-olds, but their joint was pristine, it looked as good as a 25-year-old
    - They just had a discrete labral tear
- For Peter this is an extension of what he thinks of as **precision medicine**
  - We use evidence-based medicine (which is incredibly heterogeneous) to make population-based assertions and general broad recommendations
  - But ultimately, the only patient that really matters for most doctors is the one right in front of them
  - Therefore, you have to be able to make evidence-informed decisions based on the appropriate physiology that you see
- Alton agrees and adds it’s a conversation with the patient and not a unilateral decision
  - Physicians need to say, “*Here are the possibilities, and what do you want to do?*”

**Scope imaging**

- The biggest ports are for the camera, and there are a few working ports in the front and back
- Pathology is superior and anterior
- You’re working in the superior in the front and go in through the back with a camera (to get a good panoramic view of everything)
- They have 2 different kinds of angled lenses, so they can see around corners if needed
- He can see the superior labrum; he can see the biceps

**Do you** [**insufflate**](https://en.wikipedia.org/wiki/Insufflation_(medicine)) **with carbon dioxide?**

- Yes, you’re shooting carbon dioxide to blow everything up
- And he uses water to do the same thing, but not at high pressure (35 mmHg)
  - It makes the capsule bigger
  - Lower pressure means less postoperative pain and less distention
- You can still put in little retractors, kind of pull tissue out of the way and so forth
- So that’s just a technique that’s more of an extension of what Alton does in the elbow
  - Because there’s a lot more peril because of the nerves being so close
- Usually you need 2 working portals in the front
  - Which are just basically canals to get in with instruments, that are long enough to fit through and do the work
- In the case of a superior labrum, we use a percutaneous hole right through the top, just underneath… right under where that red arrow is going (highlighted in yellow in the figure below)
  - And that just gets you to the superior labrum
  - So that’s a little percutaneous, a tiny little hole in the rotator cuff muscle-tendon junction
  - It just spreads the fibers apart, so it doesn’t do any damage to that
  - And then you’ve got a perfect bird’s eye direction for the drilling and putting in a few anchors in the top
  - And then that’s really it

![](https://peterattiamd.com/wp-content/uploads/2022/11/f15-altonbarron-1024x884.png)

**Figure 15. Front view of shoulder anatomy with highlighted arrows indicating direction of holes made during surgery.**  Sketched by Alton Barron

**Explain how the surgical repair works**

- You drill a little hole in the glenoid fossa
  - The diameter depends on what kind of anchor you are doing
  - Usually not more than 3 mm, and now we’re down to 1.8 mm
  - 3 mm seems big, but that’s what you fit the plastic or the absorbable anchor in that you tap in with the mallet
- You’re drilling into the bone, and you have to get the angle right
  - Indicated with arrows pointed right (see the small red arrows highlighted in blue in the figure above)
  - And then the anchor inserts through that
  - They’re not circumferential, they’re straight in
    - If we did them open as we used to, we’d drill holes and use a suture going through circumferentially

**What holds the anchor in?**

*Is it the pressure of putting in an anchor that is bigger than the hole?*

- Yes
- Historically there were some that we screw in, but not anymore
- Now they are purely basically braided polyester
  - The suture goes in, and then as you carefully pull it back out, the way they’re designed, they ball up
  - It’s super strong; you can lift the shoulder off the table
  - Alton knows if he tugs on it multiple times, it’s not going to come out
    - It would take fully traumatic force to dislodge it

**Do you examine the cuff while you’re in there?**

- Absolutely, he goes through and does a survey of the joint
- He looks at the cartilage surfaces, all the nooks and crannies
- He looks at the rotator cuff inserting on the bone, from inside out
  - And you can see if it’s smooth, if it’s frayed
  - If it’s notably frayed, you can probe it
  - Occasionally he may see a small, almost full-thickness tear (because they’re athletes)
    - Then I might put a stitch or two in that to fix that
  - You look at the biceps
    - You can pull the biceps into the joint and see a pretty good segment of it and see if it’s inflamed, torn, something abnormal there
  - You can see the tendon of the biceps really well too, and if it’s frayed

**How much damage do you need to see to do the** [**tenodesis**](https://www.shoulderdoc.co.uk/article/724)**?**

- Not a lot
- If he sees a combination of a modest amount of fraying and a lot of inflammation around it
- And when he pulls it in the joint, that extends further out, then he’ll tenodese it

**It’s important to understand how much your eyes are helpful here**

- When you look at Peter’s intra-op images, it is very plain, banal sort of gray-white (normal)
  - \***See photos as an addendum at the end of the show notes**\*
- Inflammation shows up as really red
- Alton likes to get a little electrocautery wand, and he paints the internal and gets rid of all that pink because it’s inflammatory
  - It hurts, and that’s part of one of the big pain generators
- Now, theoretically, if you fix everything, that’s going to go away anyway
  - But it helps patients early post-op
- A recent patient that Alton did a pretty significant repair on, after 5 days, he said, *“I haven’t had any pain. What’s going on? Did you do anything to my shoulder?*”
  - Alton repaired it, but he thinks part of it is just getting rid of that inflammation and so forth

## Repairing the rotator cuff [1:29:15]

**What is the most common athlete’s tear to the rotator cuff?**

- It depends on if they’re an overhead athlete
  - In that case, the supraspinatus is usually torn
  - Sometimes it can be the infraspinatus

**If a guy has a straight-up supraspinatus tear, do you even need to enter the capsule necessarily, depending on how close it is?**

- You do, you need to make sure that you’re not missing anything, which is common in the athletes
- There are a couple of interesting variations

- Alton drew 3 sequential axillary views, which are a bird’s eye view looking straight down on the top of your shoulder proper (see the figure below)
  - We’re sitting on top looking straight down
  - We’ve got the glenoid, the socket here, toward the head
  - And we’ve got the ball out here toward the outside, where the deltoid lives
    - These muscles are shown in the second figure below
  - This is the supraspinatus I’ve drawn in here on the top
  - In the back, as we talked about before, that’s the infraspinatus
  - And then in the front is the subscapularis

![](https://peterattiamd.com/wp-content/uploads/2022/11/f16-altonbarron-624x1024.png)

**Figure 16. Three sequential axillary views of the shoulder with tears indicated in red.** Sketched by Alton Barron

![](https://peterattiamd.com/wp-content/uploads/2022/11/f17-altonbarron-994x1024.png)

**Figure 17.  Anatomy of muscles of the shoulder A.** [**deltoid**](https://en.wikipedia.org/wiki/Deltoid_muscle)**, B.** [**supraspinatus**](https://en.wikipedia.org/wiki/Supraspinatus_muscle)**, C.** [**infraspinatus**](https://en.wikipedia.org/wiki/Infraspinatus_muscle)**, (D)** [**subscapularis**](https://en.wikipedia.org/wiki/Subscapularis_muscle).  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Shoulder_joint#Muscles)

- The [teres minor](https://en.wikipedia.org/wiki/Teres_minor_muscle) (the fourth muscle of the rotator cuff) is not really a relevant player in the pathology because it almost never tears
- Peter likes Alton’s birds-eye view of the shoulder as it allows you to see how the subscapularis and the infraspinatus are stabilizing the front and the back, while the supraspinatus is coming in over the top
  - We usually look at them from front and back

*Is the supraspinatus that wide, relatively speaking?*

- In anatomic diagrams it looks like a tiny little muscle, because you’re looking at it from the front

- But it’s broad and has three-dimensionality, and it has roughly 3.0-3.5 centimeters of width going front to back

**Back to the 3 bird’s eye views of the shoulder in Alton’s drawing (above)**

- #2 – The most common one is the middle one because that’s anterior
  - The biceps is indicated with 3 blue arrows
  - That’s an anterior-superior tear
  - That’s the one that the overhead athletes get a lot (non-throwing athletes)‒ tennis players, volleyball players, and weightlifters
  - “*And that is one of the critical zones where it can get wrung out and not have good blood supply, and that’s where they tea*r”
  - The arrows indicate where they tear, that’s where Alton had little tears on both shoulders
  - That’s also the one that can be caused by a spur pushing down on it
- Alton drew a little arc in red on #2 because they’ll tear off, and then they’ll form a little arc of smooth tissue
  - You repair it, you freshen up the bone, and then put the sutures in that leading edge of the tendon and put it back just like you’d put a tarp with a tent stake back in
    - You get it back to the good bony bed, and you get that good biologic healing
  - He’s drawn a small tear in red, but they can be bigger and more chronic
- #3 – The one down below shows the subscapularis in the front
  - That is the one that can tear in young people or older people based on mechanism
  - If you have a linebacker who is going forward at full velocity, and then somebody is knocked into him and shoots him across
    - He’s got his arms out there ready to go, and he gets eccentrically loaded into external rotation
    - That’s how you can tear the subscapularis
  - The other way is people falling downstairs and grabbing the banister and wrenching back
  - It’s commonly torn with eccentric load
- #1 –  This upper one occurs in throwing athletes
  - Baseball players and football players externally rotate dramatically, and that’s how they get their extra angular velocity to really get that zip on the ball
  - So they acquire external rotation starting at a young age, and their arms/ shoulders are very asymmetric
    - One side will externally rotate to 90 while the other one will go back another 45 degrees, and that’s how they get that whip
  - One of the consequences of that (in a subset of them) is that as this rotates and follows this area around (indicated by the red arrow in #1), that area of the rotator cuff (circled in black on the left) which is at the junction of the infraspinatus and the supraspinatus abuts up against the hard bony rim of the glenoid, and they get an internal impingement
  - Ultimately they get small partial-thickness or even full-thickness tears there
  - We have to be super cautious with those
    - We have to repair those, but you have to be really careful because if they lose 10 or 15 degrees of external rotation, they lose

**Where does the** [**Tommy John**](https://en.wikipedia.org/wiki/Tommy_John#1974%E2%80%931975:_The_injury,_the_surgery,_the_recovery) **surgery fit into this?**

- That’s the elbow
- It fits in because a lot of people add torque on their elbow because they have shoulder pathology
  - If they have a little weakness or something going on in their shoulder, they will overthrow with their forearm and their flexor-pronator mass
  - They’ll overthrow with the torque, and then they’ll tear their [medial collateral ligament](https://en.wikipedia.org/wiki/Medial_collateral_ligament) of their elbow
  - And vice versa, if they have a partially torn medial collateral ligament that hasn’t yet been identified, they can overthrow with their shoulder to compensate, to get more angular velocity on that, because they can’t muster it through the elbow

**How many years ago would it have been the case that a torn rotator cuff was the end of a pitcher’s career or a quarterback’s career at the professional level?**

- Probably 15
- But not today
- Peter can’t think of anything that could be more stressful, “*throwing a baseball seems even more stressful than throwing a football because you do it more times in a game*” and Alton agrees

***What has changed is earlier diagnosis***

- Now at the Division 1 collegiate level, any pain is almost over-evaluated
  - This uses a lot of resources but can be good for the players because it identifies these things very early

**Do they repair very small tears before they become a bigger tear?**

- It depends
- You’d certainly watch it carefully
- Sometimes it’s not the tear that causes symptoms
  - It could be just some inflammation related to it and if you can cool that down, the tear is not biomechanically significant yet

***Alton has had patients with full-thickness tears that are minimally symptomatic and others with partial-thickness tears that are very symptomatic***

- So it depends on what you have

**Back to Alton’s drawing of muscles in the shoulder, explain a full-thickness tear**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f18-altonbarron-1024x701.png)

**Figure 18.  Shoulder joint with the supraspinatus tendon highlighted in yellow.**  Sketched by Alton Barron

- Peter notes, “*I think one thing that’s kind of missing from this picture in the subscapularis, in the infraspinatus, is just how long they are*”
  - We are looking at the top, but these muscles cover the scapula

- Back to an earlier picture Alton drew of the supraspinatus tendon, that perpendicular distance through there is the full thickness
  - It varies depending on the size of the patient

*Could it be a tear across the entire 4 cm by 0.5 cm?*

- When we speak typically about full thickness, we mean the depth of it this way (going up and down), so that you can have a partial-thickness tear that’s maybe half the tendon there, or full thickness
- Now, if you have half the tendon torn, you’ve lost enough biomechanics that if you’re a high-level throwing athlete, no way can this be ignored
  - Whereas a partial-thickness tear off the tendon could easily be ignored
- Those muscle bellies are huge
- In football players and guys who are so strong, sometimes they have that wrenching injury, and they don’t rip the tendon off the bone, but they interstitially tear at the [musculotendinous junction](https://en.wikipedia.org/wiki/Skeletal_muscle#Attachment_to_tendons)
  - And they have a tremendous amount of edema, weakness, pain, but that will heal without any intervention
    - With just some some anti-inflammatory and just time to heal

## Are platelet-rich plasma (PRP) injections or stem cells beneficial for healing tears? [1:38:15]

**What role do stem cells or** [**PRP**](https://en.wikipedia.org/wiki/Platelet-rich_plasma) **play in any of this?**

- Peter doesn’t think stem cells are going to replace a labrum, but if you have a tear in the muscle, they can be valuable

*Are people running randomized clinical trials on stem cells in that indication?*

- Alton thinks so, but he doesn’t know that literature
- There are a lot of terribly designed studies all around that are being used to justify using stem cells or PRP
  - So one has to be careful to extrapolate it to your individual practice
- There’s a lot of money involved too
  - Alton has patients that routinely fly to various places (including Germany) and pay a lot of money to get stem cells injected for things we’ve been talking about
- And there’s no data on there
- There are a few anecdotal reports where people say there was a tear on the MRI, they injected PRP and it’s healed, gone
  - Alton doesn’t know what to make of those
  - They’re just one-offs
  - We also don’t know what the natural history of that injury would have been without the PRP
- One of the best scientific things Alton can relate goes down to the elbow
  - He was speaking just before COVID at the American Association of Sports Medicine to non-surgical, general medicine doctors who do sports medicine
  - 2 papers (listed in the selected links section) were presented before his talk, back-to-back on over a thousand patients
    - Double-blind, randomized studies on [tennis elbow (lateral epicondylitis)](https://en.wikipedia.org/wiki/Tennis_elbow), comparing cortisone, PRP, and placebo
    - ***The placebo and the PRP were the same, while the cortisone was much more effective***
  - These were back-to-back studies at different institutions
- The literature is replete with studies that say PRP really helps
- Alton sees patients all the time that have had PRP injections

***Alton has a PRP machine in his office in Manhattan, and based on his current knowledge of the literature for rotator cuff repairs, for tendon ruptures, for lateral epicondylitis, certainly for Tommy Johns and medial tendon ruptures, he uses it twice a year (when someone begs him to do it)***

**Is there a financial incentive for giving PRP instead of cortisone?**

- Cortisone is covered by insurance, and it’s only a couple hundred dollars for a shot
- PRP is $1,000 and it’s not necessarily covered by insurance
- Some people charge a lot more ($2,500) for a PRP injection
- The concept of PRP is great‒ it has growth factors, it’s our own bodily fluids
  - But it hasn’t yet borne out to be a game changer

**There’s not enough data to support benefits from PRP injection**

- Now, if you take someone who’s the highest-level athlete and they have bursitis, and you inject some PRP in there, some stem cells, maybe it will be better, who knowns
- There’s not really good data on it
- But there’s no downside to doing it
- The only downside Alton sometimes sees is more flare reactions from PRP injected into tennis elbow, where people are really painful for a couple of weeks
  - They end up coming to him for either surgery or cortisone
  - This is just anecdotal, he doesn’t have a comparative study
- Peter needs to spend more time in this literature, and notes the problem is we don’t have that natural history
  - There are a lot of anecdotes that say, “*This injury was present. Stem cells were injected. The injury is gone radiographically.*”
  - We don’t have the contra positive case
- Alton knows of a [natural history study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5491331/) on asymptomatic rotator cuff tears that came out of WashU
  - [Ken Yamaguchi](https://www.ortho.wustl.edu/content/Patient-Care/2763/Find-a-Physician/Physician-Directory/Ken-Yamaguchi-MD/Bio.aspx) was the lead on that article
  - They looked at ultrasounds which is great because they’re non-invasive, non-costly, and very effective if you have a good ultrasonographer
  - They looked at the natural history of these asymptomatic tears, and they found that they never repaired on their own
  - At very best, a subset of them stayed the same
  - The larger the tear, the more likely it was to become even larger with time
    - And a subset become symptomatic
  - None got better spontaneously
- This suggests to Peter that if people are saying, “*Here’s my MRI pre and post stem cells, and it got better*,” that would suggest in that individual it might have worked
- Alton agrees, but points out that MRIs vary significantly from machine to machine
  - That would have to be very well controlled
  - “*If you showed me even 20 patients done by someone that I know is legitimate and they did that and showed comparative MRIs that even 10 out of 20 showed healing and reconstitution, man, I’d be in*.”
- Peter hopes that study is being done
- Another thing to standardize is the process of generating the stem cell
  - One of the challenges of doing a clinical trial is everybody has to get the same drug

**How standardized is the procedure for capturing and processing stem cells?**

- It’s non-standardized
- It differs between different companies that bring the machines in
- It differs between individual clinicians

> “*It can be apples and oranges*”‒ Alton Barron

## Repair of an AC joint separation [1:45:15]

**When does it just get left alone and you’re stuck with a little bit of deformation?**

- [AC separations](https://en.wikipedia.org/wiki/Separated_shoulder) are common injuries

- Alton sketched the [AC joint](https://en.wikipedia.org/wiki/Acromioclavicular_joint) with the [glenohumeral joint](https://en.wikipedia.org/wiki/Shoulder_joint) removed (see the figure below)
  - The clavicle is coming across
  - There are the 2 stabilizers of the clavicle, one is the coracoid process
  - There are the [coracoclavicular ligaments](https://en.wikipedia.org/wiki/Coracoacromial_ligament)
  - We’re looking at it straight on
  - It’s a thumb that sticks out from yet another weird part of that scapula

![](https://peterattiamd.com/wp-content/uploads/2022/11/f19-altonbarron-902x1024.png)

**Figure 19. Separation of the AC joint**.  Sketched by Alton Barron

- Secondarily, we have the acromioclavicular (AC) joint that we were talking about, and those are the [ligaments](https://en.wikipedia.org/wiki/Acromioclavicular_ligament) that are circumferential around the acromioclavicular joint
- So if you fall hard off your bike and you sprain your AC joint, we call that a [type I](https://en.wikipedia.org/wiki/Separated_shoulder#Type_I)
  - You stretch a little bit and injure these ligaments (drawn in red in part A of the figure above) and maybe even stretch those a tiny bit
  - It doesn’t look any different on x-ray
  - Those can hurt, and those can damage the cartilage a little bit
  - You can get a grade I that persists in being painful, but generally they don’t
  - They go away
- Alton did this recently on some slime out in Dripping Springs on a bike ride
  - There was a low-water crossing and he just went out like it was on ice
  - It hurt for 6 weeks, and then it was gone
  - It wasn’t braced and now it’s completely normal

**Did you diagnose it just by pressing on it?**

- Yes, he knew by pressing right on it, it hurt like heck, but it didn’t blot
  - It didn’t move up and down, and he could lift his shoulder
  - He could feel it not moving
- This is one of the things that’s biomechanically and we talk to the residents about when we’re teaching‒ ***it’s not that the clavicle pulls up, it’s that the shoulder falls away***
  - One of the primary suspenders of the shoulder are these two ligamentous structures
  - So if you tear them, the shoulder kind of falls away
  - So that’s why we treat it by wearing a sling and get that heavy weight of the arm off
- Back to the figure Alton drew, in part B. there is a shadow (drawn as a dotted line)
  - Here’s the clavicle
  - We have one acromion, which it’s sitting up about 30% or so, and that’s where you have torn the AC ligaments
- A [grade II](https://en.wikipedia.org/wiki/Separated_shoulder#Type_II) is where you’ve clearly torn the AC ligaments and it’s up by about 30%
  - This could be a partial or complete tear, but it just didn’t distort it too much
  - Almost all those can be treated nonoperatively
  - Again, like the I’s, they can hurt, persist, and you might have to do something later, but they’re basically stable

*When you treat it non-operatively, is the treatment that it will return to its position with elevation?*

- Sometimes, but usually not
- Usually it stays a little elevated, but people don’t really care
  - It’s barely asymmetric
- [Grade III](https://en.wikipedia.org/wiki/Separated_shoulder#Type_III) is where you it’s completely up
  - We measure that by the distance between the coracoid and the clavicle
  - In part B of the figure above, Alton drew a second coracoid process and a red arrow to express the difference in height (the coracoclavicular distance)
    - If it’s up to 30% widening, increase in that space, then that’s the **grade II**
    - If it’s 100% or more, then that’s a **grade III**
- There was a good study done probably 20 years ago for NFL athletes who had sustained these, and the prevailing wisdom for the doctors who were treating the NFL teams was that most of that type III’s did not need surgical treatment
  - But a subset of them did go on to needing it later
- Now, in reality, when they’re up that high and people want to get back sooner, we have better reconstructive techniques now
- If you’re a professional cyclist and you fix them, you can get back on the bike in 3-4 weeks
- So there’s a gray zone, but the type III’s are that transition
- The vast majority of the operative ones are in the III category
- Alton saw a weightlifter the other day and gave him the options
  - We can fix this tomorrow or next week
  - But you could also wait and see how you feel in 3-4 weeks because you can have the same repair then
    - You don’t lose anything by waiting
    - But you will lose something by waiting 3-6 months because you don’t have the same biology going on
  - This guy felt great 4 weeks later and ended up not wanting surgery
    - The pain was almost gone
- Asymmetry won’t have a functional impairment, generally speaking
  - Except if you’re doing certain exercises‒ heavy flys, heavy bench, high back squat

**How the repair is done**

- This is where Alton differs from some people, a lot of people get in and get out quickly
- If you have it fairly fresh and you have good ligamentous tissue in here, then we do what’s called a **dog bone**, which is basically 2 titanium grommets
  - See the blue lines in part A of the drawing above
  - This is heavy polyester suture
  - We drill through everything, drill through the clavicle, drill through the coracoid, and then, pass (these are some of his little tricks)
  - Pass the suture up through, pull everything down, have your assistant pull it down and you tie that over
  - Then it is rock solid, and they really do well

*So in other words, you don’t do it by going back to the acromion process*

- You get the torn ligaments to be in continuity again and then they can heal
- The polymer is not biodegradable
  - It will stay forever
  - They’re super strong
- You don’t let somebody go back to regular activity in a week, but depending on their sport, you can let them get back in maybe 3-4 weeks
  - Certainly 6 weeks as by then, everything is pretty strong

**Emergency orthopedic surgery**

- Peter just had a patient go through this, the clavicle and [mediastinum](https://en.wikipedia.org/wiki/Mediastinum) separated
  - This is not common, but can be very problematic
- This patient had a high fall (maybe off a horse), but what surprised Peter was the patient said, “*Look, I just saw two surgeons at HSS and they said I need to have surgery right away*”
- This turned out to be one of those things in orthopedics that needs immediate surgery
- Alton drew a lordotic view basically of the [manubrium sternum](https://en.wikipedia.org/wiki/Sternum#Manubrium) (see the figure below)
  - Our breastplate is there
  - We can follow our clavicle across to that and we can feel the little nubs right there at the base
    - We can feel those [sternoclavicular joints](https://en.wikipedia.org/wiki/Sternoclavicular_joint)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f20-altonbarron-1024x562.png)

**Figure 20. Lordotic view of the manubrium sternum.**  Sketched by Alton Barron

- You can see it’s even worse than the shoulder; it’s a very shallow joint
- So if you take a hard blow laterally (a common injury)
  - Cocky players get slammed up against a glass
  - The football players, the quarterbacks that get tackled by these 300 pounders, and their shoulders are wedged together like that
  - It just so happens that the injury that [Quinn Ewers](https://en.wikipedia.org/wiki/Quinn_Ewers) (the quarterback for UT) suffered when he was knocked out in the Alabama game
    - He’s now back
    - So he obviously didn’t have this full dislocation
    - But that’s what can happen, in weird circumstances such as Peter was talking about, the mechanics can be that
  - It happens a little more commonly in kids, but if the fall is just right and the mechanic’s just right, it will open this up, tear everything and then, displace it behind the [manubrium](https://en.wikipedia.org/wiki/Sternum#Manubrium)
    - And that’s where a major vein lives (red and blue circles at the top of the drawing above), and that can be hugely life-threatening
    - We have to be careful with those
- This one, where it subluxes out the front are also a problem
  - You can see that there’s no way it’s going to fall back into place there
  - So either they stay out, they stabilize, and people just don’t do that much to irritate them
  - Or they have to be reconstructed
  - Alton has had to go in and reconstruct these, where he takes a tendon from the forearm and makes a figure of eight across the front to basically rebuild those ligaments to hold it back in place
    - This is stronger than doing an anchor or something like that

**What is it about the insult laterally that will determine a separation at the medial end (sternoclavicular joints) versus the lateral end (acromial end)?**

- These are two weak points at each end of the clavicle
- It more frequently happens at the acromial end, but that’s usually a top down impact
  - That’s usually pitching forward and landing
- But what happens more commonly than the [SC joint (the sternoclavicular joint)](https://en.wikipedia.org/wiki/Sternoclavicular_joint) is just a clavicle fracture (these are ubiquitous)
  - And that just fractures somewhere over there
  - We fix them some and we don’t fix others (those heal)
  - But this weird little joint is very important
  - Damage here is not common, but it’s not rare

## Total shoulder replacement [1:55:45]

- A lot of people are pretty familiar with the total knee replacement, a total hip replacement
- For Peter, the hip replacement has been one of the modern marvels of orthopedic surgery in the last 30 years
  - When he thinks back to when he was in medical school, a shoulder replacement was a brutal procedure
  - Today they are outpatient (unless you have comorbidities)
- Alton points out, “*The types of implants we’re using now have evolved significantly*”
- So when you’ve worn down the cartilage completely (either on one or both of the surfaces), that’s incompatible with good function
  - Usually because of pain
  - Pain is the primary indication
- Alton sees patients all the time who have the ugliest x-rays you’ve ever seen, but they have *no* *pain* and they can do whatever they want to do
  - So they’re fine
  - Occasionally, they’ll say, “*Hey, I’m going on a trip, where I want to be able to play golf for 2-3 weeks with my family.  Can you give me a cortisone shot*”
    - They get the shot and they rock on
    - They get 3-4 months of relief and keep on going
- It’s only the very active people who need to be able to do certain things, and age is not a factor
- Alton’s oldest patient who he did shoulder replacements on (quite a long time ago), she was 97 and she was spry and healthy
  - She walked the streets of Manhattan up and down, and she actually was still working at 97
  - She was the oldest and longest standing employee of a famous place
  - After he did her surgery (back to back), he’d see her on the street, walking down 57th Street, and she’d say, “*Hey doc, I’m doing great*”
  - It totally changed her life, because she couldn’t use her arms and they were hurting so much
  - So age is not a factor

**What caused so much degeneration in her?**

- Some people just get it
- It doesn’t have to be constant subluxations
- One of Alton’s attendings when he was in med school residence said, “*Yeah, it’s like a paint job. You can have a paint job that’s a Mercedes or you can have a paint job that’s a Ford Pinto*.”
  - It’s the quality of the paint you’re born with
  - That’s the main source of garden-variety [osteoarthritis](https://en.wikipedia.org/wiki/Osteoarthritis) of the shoulder
- And then, there are the athletes who are separate categories based on wear and tear

**What is the youngest person Alton has done a shoulder replacement on?**

- Almost 55
- He saw a 48-year old guy about 15 years ago who was booked for a replacement
  - Alton told him he was too young for him to operate on and he should at least give him a shot
  - He also recommends a **scope clean out**
    - The data is not great, but anecdotally patients have about a 50% chance of getting better
  - These patients have arthritis, but they don’t have instability
  - Cleaning them out will buy them some more time
    - It’s a minimal operation, no recovery
    - If people have bilateral osteoarthritis, they don’t need both sides done and are happy with one good side
  - About 15 years later, the guy came back and his shoulder motion was fine
    - His x-rays had *not* advanced
    - He came back for something else
- Another of Alton’s patients was a very athletic woman who was still sailing in regattas at age 75
  - She was still going racing all the time, pulling lanyards, etc.
  - She complained that she couldn’t do it anymore and wanted to keep doing it
  - Alton replaced both of her shoulders about 4 months apart
  - She gave up sailing for a year but is now back at it

**Anatomy of a shoulder replacement**

- There are 2 pieces to it‒ the humeral side and the glenoid side
- Alton draws what an arthritic shoulder looks like in the little picture labeled part A in the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/11/f21-altonbarron-1024x864.png)

**Figure 21.  An arthritic shoulder (A) and shoulder replacement surgery (B).**  Sketched by Alton Barron

- The head kind of flattens out
- You have no space in there at all
- You get a bone spur down here
- You get some spurring around the perimeter of the glenoid, and all of that conspires to greatly diminish the motion of the shoulder and cause pain

- There are 2 reasons patients come in
- 1 – Dysfunction, because they can’t do what they desperately want to do, whether it’s recreational or work sometimes
- 2 – Pain
- Either one of those is a solid indication, when the radiographic findings are there
- We do these through a very small anterior incision and take down part or all or part or most of the [subscapularis](https://en.wikipedia.org/wiki/Subscapularis_muscle), the tendon in the front
  - We have to have a window in
  - Now we can work through the interval, the space between the supraspinatus and the subscapularis, but only if it’s a more limited replacement
- But anyway, you take some of the humeral head off (to the right of the diagonal black line)
  - You have a window there, you have retractors in, and you use an oscillating saw and just take that arthritic head off and all the bone spurs
  - Then with that space that that creates, you use another retractor, push the head, what’s left of the shaft away
  - And then, you get in and work on the glenoid and you ream that down to where it’s all smooth, get the bone spurs out of the perimeter, and then put in this little high density polyethylene socket (drawn in blue in part B of the figure above)
    - This is ultra high molecular weight polyethylene (very durable)
    - It’s the same thing on the tibial plateau
- We use these little pegs by drilling holes, put in a little cement, and it’s a perfect new Teflon surface for the cobalt/ chromium (or whatever alloy it is) humeral head
  - The pegs are draw in black in part B of the figure above
  - The metal humeral head is shaded green to the right of the black diagonal line in part B of the figure
  - The bone has a central core and you clean that out (shaded in green to the left of the black diagonal line in part B of the figure)
  - And this is press fit
    - We don’t cement these anymore, unless people have really bad bone or it’s a revision
    - We just press fit it into that cancellous bone and it’s super solid
  - The rotator cuff is still intact on top (the black line above part B of the figure), you’re working around that
- Reattach the subscapularis

**If you’re going to transect the subscapularis, what is the least traumatic place to do it?**

***On the tendon, where it inserts on the bone***

- We leave a sleeve, so we can suture tendon to tendon
- But then, we also put this heavy suture into bone

***So you’ve got bone reinforcement and you’ve got tendon to tendon healing***

- By doing that, you also maintain the normal length

**The biggest thing this person is missing is a labrum**

- Yes, and they don’t really need it

*What stabilizes the joint?*

- The fact that it’s arthritic, it’s already stabilized itself
  - Unless it’s a weird dislocating joint, which is a different entity (that you have to address that differently)
  - For the garden variety one, they’ve already stiffened up

**So what does their capsule look like when you go in, typically?**

- It’s super thick
- We resect some of it

**In a good case, what is the limitation on this person, a year out from surgery?**

- Really nothing except heavy weights
  - Alton doesn’t want people doing bench press or Iron Cross type things
- They can throw a ball and play catch with their grandkids, for sure
  - They can play tennis and golf
  - They can shoot basketball
  - They can swim, that’s a big one what people love
    - Later in life, it’s such good general action exercise

**Is this another one of those game changing operations?**

- It’s different than the hips and the knees, they allow people to live in the world again
- Alton won’t do them if he knows he can manage them and kick the can down the road and just inject them once a year with cortisone
- He wants them to be dragging that arm in and saying, “Y*ou’ve got to do it now. I’m not getting enough relief from the cortisone.*”

## The elbow: anatomy, pain points, common injuries, treatments, and more [2:05:30]

**Anatomy**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f22-altonbarron-1024x830.png)

**Figure 22.  Anatomy of the elbow.** Image credit: Adapted from [Wikipedia](https://en.wikipedia.org/wiki/Elbow) and [Learn Muscles](https://learnmuscles.com/glossary/muscles-of-the-anterior-forearm-deep-view/)

- The humerus bone is the arm bone is coming down
  - You see it’s a super weird undulating structure there, which makes it intrinsically quite stable
  - So different from the shoulder

- There’s all these fun little almost jigsaw puzzle pieces that stick together
- We have the radial head, which is the rotating bone of the forearm
- We have the ulna, which is the fixed straight bone of the forearm
- What’s cool about the elbow is the tendons that go down to the forearm and to the hand originate above the joint
  - Juxta-articular, close to the joint but above it
  - And then, the ones that go from the shoulder and arm down attach below the joint
- In tennis elbow a tear occurs on the radial collateral ligaments
  - On the inside of the elbow, where our funny bone nerve is
  - The funny bone nerve is the [ulnar nerve](https://en.wikipedia.org/wiki/Ulnar_nerve)
- Overlying that is the muscles, the [flexor pronator muscles](https://en.wikipedia.org/wiki/Pronator_teres_muscle), that helps bend the elbow and pronate the forearm
  - And those can tear right in this region (marked with a star in the figure above)
  - That’s actually where we get [golfer’s elbow (medial epicondylitis)](https://en.wikipedia.org/wiki/Golfer%27s_elbow)
  - On, the lateral side, which is the [tennis elbow (lateral epicondylitis)](https://en.wikipedia.org/wiki/Tennis_elbow)
- Another common tendon injury occur to the [biceps tendon](https://en.wikipedia.org/wiki/Biceps#Structure)
- The 4th (less common), is shown in the lateral where the triceps comes down and attaches to the tip of our elbow
- We talked about the bursa before, and there is a bursa that lives over the tip of our elbow
  - And we can get the big golf ball size filling of fluid ([olecranon bursitis](https://en.wikipedia.org/wiki/Olecranon_bursitis))
- This is beyond what we’re talking about today, to go into the fractures, but any parts of these can be broken

> “*The elbow is a very finicky joint. You can see it’s stable, because of those undulating surfaces. But because they’re undulating, there’s less wiggle room.*”‒ Alton Barron

- If you don’t get those things perfect when you fix them, they can quickly lead to arthritis
- And some of the, even the subtle fracture patterns that happen and aren’t seen or appreciated, can lead to rapid destruction of the joint. So it’s a finicky joint.
- There is a very thick ligament on the inside of the elbow, that is the Tommy John ligament
  - It’s not really Tommy John but he’ll clarify that in a minute
  - That’s the the [ulnar collateral ligament](https://en.wikipedia.org/wiki/Ulnar_collateral_ligament_of_elbow_joint), and that’s the one that’s torn in throwing athletes
    - It can be career ending, except now because of the reconstructive surgery, it’s generally not

**Why do tennis players get inflammation in the** [**lateral epicondyle**](https://en.wikipedia.org/wiki/Lateral_epicondyle_of_the_humerus)**, whereas golfers get inflammation in the** [**medial tendon**](https://en.wikipedia.org/wiki/Medial_epicondyle_of_the_humerus)**?**

- - Of course, people who have never played tennis or golf often get these things
  - Those are not dissimilar from the supraspinatus tendon, where they have a little ringing out and they can become degenerative and partially tear
  - Just like we talked about rotator cuffs, there are tons of people walking down the streets with partial tears in those tendons, and they’re asymptomatic
    - Use patterns are significant for that
  - The reason the lateral was historically associated and called tennis elbow is because of one-handed back hands
    - It’s a much less mechanically sound
    - And we have less strength with our external rotators than we have with our pectoralis and our subscapularis for forehand shots, so it’s under more stress
  - You can get them at any age
  - Alton treats a lot of people age 40-60
    - And now that’s creeping up to the 70’s
  - Now in competitive tennis players, he’s seeing just as much medial epicondylitis, which is traditionally golfer’s elbow
    - And the reason is because everybody is trying to hit massive top spin
    - And they are hit using their pronators so much more than they used to, and that’s a reason why it is stimulated more

- Historically, even golfers were getting it

- Alton don’t know why, because you’re not supposed to be overhitting with your trailing arm

- Most people play right-handed and they were getting it on their right medial epicondylitis because they were overhitting, hitting stumps, hitting rocks, duffing

- And it was that jolt, again, the eccentric load on these tendons, which our tendons don’t like

- But now he’s seeing, because golfers are hitting so much harder, they’re hitting bigger clubs (especially drivers and such) and they’re getting more left leading arm lateral epicondylitis

- This causes damage on the leading arm when they’re just trying to hit harder and farther

**First line treatment**

- The first line of treatment is always rest, good stretching (just like you stretch your hamstrings to keep from tearing them as frequently or injuring them as frequently), and usually NSAIDs by mouth
- Rarely does he use physical therapy for these formally, because it’s just not much to do
- Sometimes they’re very painful
  - Some people wake up in the morning, they can’t even straighten their elbow out
  - The elbow is spongy and really inflamed
    - He doesn’t splint those but has them stretch
    - More often, because they can’t use their arm, he will go ahead and give them a half dose of cortisone just to cool everything down

**Peter’s experience with elbow pain**

- Peter remembers Alton injected him 4-5 years ago when he was in the transition of really learning how to control his scapula and had overcooked doing too many pullups
  - The pullup pain was translating into tennis elbow, which surprised him
  - It was a stubborn pain
  - He went to see Alton after 6 months of pain, but that 1 injection cooled it off
  - It never hurt again because he had already fixed the underlying movement pattern

*Is this a common scenario?*

- Yes, it’s common and this is one reason why Alton doesn’t operate right away
- He operates on 20% at the most

***Most people get better after a cortisone shot and correcting the underlying movement pattern***

**What are the indications for operating on the lateral versus the medial side?**

- The indications are the same‒ failing conservative treatment
  - A lot of stretching and strengthening
- A lot of people get these
- In Peter’s case, it was mechanics and overdoing

***Many people get these because they’re getting back into something that they haven’t done in a long time and they overdo it***

- It can be weightlifting or something more mundane like lifting your luggage around on a 2 week vacation

***The theme is conditioning, if people don’t have grip strength and are weak***

- Strengthening is a critical component
- Alton has a device he has patents squeeze, and if they can squeeze that without a little pain, he has them do that first
  - Often it will cure it
  - But if they can’t squeeze it without undue pain, he gives them a little dose of cortisone
- If it’s chronic, like Peter’s was, then there’s not that much to do
  - Peter is fit, he’s got great tone and full motion
  - So he only needed a little booster dose of cortisone to knock it out
- We think sometimes just sticking the needle in a few times kind of stimulates a healing response (we haven’t ever done the study to prove it)
  - Peter has seen a lot of anecdotal stuff around dry needling
  - Just increasing the influx of inflammatory cells and getting macrophages to come and clean it up

**Outside of fractures, how often does Alton see acute injuries to the elbow, that ultimately are surgical cases?**

- Antecedent elbow pain or forearm pain is common in middle age in a very active/ fit person
  - They don’t know what did it but they [ruptured their distal biceps](https://en.wikipedia.org/wiki/Biceps_tendon_rupture) and they get a Popeye muscle (see the figure below)
- The bicep is the primary supinator of the forearm and a secondary elbow flexor

![](https://peterattiamd.com/wp-content/uploads/2022/11/f23-altonbarron-1024x741.png)

**Figure 23.  Anatomy of the elbow and distal biceps tendon.**  Image Credit: [Riley Williams, MD](https://rileywilliamsmd.com/distal-biceps-tendon-repair-orthopedic-elbow-surgeon-manhattan-new-york-city-ny/)

***So when people tear their biceps, they don’t lose that much flexion strength, but they lose most of their supination strength***

- So if they are used to turning screwdrivers, wrenches, surgical instruments, maybe depending on what they do, then it can be really disabling.
- In the exam, patients will come in and they won’t be in pain but will have a deformity
  - Alton will pronate them to wrap that tendon kind of around the radius, and then have them pull up, like they’re doing a pronated curl‒ and they scream
    - You get it just isolated
  - And then, you test their supination, and they didn’t know that they didn’t have any supination strength
  - Then you’d test their other side and they can lift you off the table

**When you surgically repair that, are you reattaching the tendon?**

- Yeah, it’s like a tendonisis
- After surgery, many patients say they feel stronger than before the injury
  - But they probably had a partial tear for a long time
  - They were working around, they were little decondition in their biceps, they were compensating with their brachialis, the big muscle underneath that
  - And then, they get even stronger, because they have a good tendon again

## How Tommy John surgery revolutionized Major League Baseball [2:17:15]

- This is a tear on the medial side from the ligament being subjected to super physiologic torques
  - Think high-level throwers who are throwing 90+ mph
- When the [medial collateral ligament (aka ulnar collateral ligament)](https://en.wikipedia.org/wiki/Ulnar_collateral_ligament_of_elbow_joint) is subjected to such traction forces, it will rupture (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f24-altonbarron-1024x764.png)

**Figure 24.  The Ulnar collateral ligament (aka medial collateral ligament)**.  Image credit: [Performance Health Academy](https://www.performancehealthacademy.com/your-quick-ucl-rehabilitation-guide.html)

- And the way they keep from rupturing, in general, is by steady long-term fitness
  - Flexor pronator fitness, that’s shoulder strengthening, biceps, triceps, and so forth
- By strengthening everything around it, you can protect that ligament
- And if you don’t, then it can rupture, because it’s being subjected repetitively over and over and over again year after year to super physiologic loads
- When it ruptures‒ instantaneously, they lose 10 miles per hour on their fast ball
  - They can still throw, but it just immediately downgrades their ability to throw

*Most of us can’t throw a ball 50 mph.  Does this mean I would go from 50 to 40?  Would I notice a difference?*

- This is a common fallacy
- You would notice it
- If we’re playing catch, we don’t need the ligament

**This is really an operation only for the most elite throwers**

- What was done on Tommy John was not the same operation
  - It was the same ligament, but it was totally different now
  - It’s good to refer to it as that
  - The guy who invented it was brilliant
- Some parents will bring their kids in asking for this surgery, who say, “*We know our kid has this great potential*” but their kid has no problem
  - Because so many people have had partial tears (like the biceps), and once they have a reconstruction, they can throw 5-7 mph faster
  - News of that travels through the chat rooms and lore, prompting parents to bring their kids in

**What type of injury will damage the triceps tendon to the point where it’s coming off the** [**olecranon**](https://en.wikipedia.org/wiki/Olecranon)**?**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f25-altonbarron.png)

**Figure 25. Anatomy of the triceps tendon and olecranon**.  Image credit: [Sports Injury Clinic](https://www.sportsinjuryclinic.net/sport-injuries/elbow-pain/posterior-elbow-pain/triceps-tendon-inflammation-strain)

- Eccentric loading
  - They almost always tear falling, skiing, when someone is trying to stop themselves from smashing their face
  - Alton sees them every winter

**How clean a break is it?**

- It varies
- If someone has a chronic condition and has bone spurs in there, it will pull off part of the bone spur and everything
- It’s usually pretty clean

> “*But man, the triceps is a huge muscle*”‒ Alton Barron

- The triceps is bigger than the biceps
- And so the injury here is really disabling
  - People can even pus up out of chairs
- You have to fix these injuries
- They’re not ruptured in sedentary, low-functioning people
- They rupture in active people

\*\*\*

**Elbow exam:**

**Discussion about the elbow + elbow exam:**

\*\*\*

## History of hand surgery and the most significant advancements [2:22:15]

- Peter points out that he didn’t do a rotation in orthopedics or plastics, so this is like a black box to him
- It’s a highly specialized field
  - Anybody who wants to operate on the hand has to complete both the orthopedics program or plastics program and then go on to a dedicated fellowship

**What do we know today about the hand, in terms of repair or injury that wasn’t known when Alton finished his residency?**

- In the 50s-60s [microvascular techniques](https://www.erickagelmd.com/microvascular-surgery/) were developed
  - That was the holy grail of so much in the hand
- Prior to this if you had a laceration or war injury, there really wasn’t much you could do for those injuries (especially nerve and blood vessel related)
  - These were not reconstructible, and you would do a lot of amputations
- [J. William Littler](https://journals.lww.com/plasreconsurg/fulltext/2006/11000/j__william_littler,_m_d_,_1915_to_2005.43.aspx), who was one of the most famous, living hand surgeon, for a few decades in the world, was exposed to that at Valley Forge and elsewhere during the war
  - And that’s how he and other luminaries in the field developed these techniques that brought us where we are today
- The most significant advancement, since Alton graduated and went into private practice, has been the the **complete hand transplantation**
  - It involves general surgeons, it involves hand surgeons, it involves a huge team to be able to do that
  - And the results are mixed
  - As recently as 5 years ago, only a few had been done
  - Only in the last several years have these teams been built up at larger institutions to be able to handle this
    - Even then, it’s fraught with peril
    - You have to have a patient in  perfect physiology as any comorbidities greatly decrease the likelihood of success
    - And it requires a huge investment for the patients themselves
  - A bilateral hand amputee is usually the one that can qualify for this surgery (as opposed to a single hand amputee), and they have to meet all the physiologic parameters
- The hand transplantation is joined at the midpoint of the wrist
  - At the distal forearm where you’re beyond that transition zone and can link up tendon to tendon
  - The nerves need to be linked as well
- You have to [HLA match](https://en.wikipedia.org/wiki/Human_leukocyte_antigen) these things because they’re all cadaveric
- The only other thing that’s changed a lot, that relates so much to the hand, is the **spinal implants** and the various types of full muscle transfers that can restore function in the hand for someone who previously had no ability to control even a prosthesis

> “*These electrical prosthesis now that are linked to the brain, it’s cool*”‒ Alton Barron

**Are there injuries in the forearm where they will take a muscle from the leg (or something like a** [**sartorius**](https://en.wikipedia.org/wiki/Sartorius_muscle)**) and attach it there?**

- Absolutely, and it’s really intended to just give some primitive function back
  - To be able to flex the elbow for instance, or extend the elbow or flex the wrist
- It’s really more the elbow more than anything because most of these injuries, the patients can still control their shoulder, can position the arm somewhere
- But if you just have an elbow extension contracture where you cannot flex better than 90 degrees, you can’t get your hand to your mouth, to your hair, to your face‒ you can’t do a lot
  - There are many limitations just trying to get through an average day

**What fraction of those injuries that require surgical intervention are the result of an acute trauma versus chronic injury (wear and tear)?**

- It varies depending on where you are
- Alton took trauma calls for a couple of decades, but not any more
- He sees cold trauma that still needs surgery, but it’s not acute
  - It’s subacute and it needs to be fixed in a delayed fashion
- If you are in a practice such as a county hospital where there’s trauma coming in (whether it’s hunters, highways, etc.), then a much higher percentage of your day and your week is spent repairing acute, traumatic, often polytrauma injuries
- Alton is in a mature metropolitan type practice where it’s more in the area of 50/50
  - There’s plenty of arthritic conditions, of wear and tear conditions (gym work, or getting back into various forms of exercise, or the weekend warrior phenomenon)
    - And those are not dramatic traumatic injuries
  - And then there are the people that are falling off the scooters and water skiing and dislocating their shoulders, all that spectrum
  - But the actual acute… something as mundane as cutting avocados, he sees tons of nerve injuries and tendon injuries in the palm

***But it’s usually spread pretty evenly between arthritic and sports related ruptures and injuries, and then fractures and dislocations and ruptures due to traumatic events***

**Peter’s takeaway:** *If the bony anatomy of the shoulder is a little more straightforward, it starts to get a little more complicated in the elbow and it gets a little more rigid.  The hand is really complex.*

## The hand: anatomy, common injuries, and surgeries of the hand and wrist [2:29:30]

**Anatomy of the hand**

- There are 3 bones in each finger (except for the thumb, which has 2), so 12+2 = 14 bones
- Then you have the next layer, which are the [metacarpals](https://en.wikipedia.org/wiki/Metacarpal_bones), 5 of those
- And then the [carpal](https://en.wikipedia.org/wiki/Carpal_bones) bones in the wrist are 8 small bones
  - They are are called coalitions where they’re fused together
  - Alton had a resident that used to make fun of hand surgeons who would say, “*Never operate on a bone you can swallow*”
  - He was just, in a fun way, piling the fine smaller, caliber things that we’re dealing with in the hand and wrist region
- The wrist owns the one bone that is the hardest to heal in the body, the [scaphoid bone](https://en.wikipedia.org/wiki/Scaphoid_bone) (see the figure below)
  - “*It’s like a carob coated cashew*”
  - It’s almost all encompassed by cartilage
  - So there’s only a couple of little areas where tiny blood vessels can get into that bone, and unlike almost all the other bones in our body, we don’t have what we call antegrade flow into that bone (leaving the heart going down through the arteries and the capillaries and going into the bone from point A distally to point B)
    - It goes in retrogrades
    - So if you crack that bone in the middle (at baseline), it has very little blood supply, and you probably disrupt it
    - This one generally takes 10-12 weeks to heal (compared to 6 weeks for the average bone)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f26-altonbarron.png)

**Figure 26. The scaphoid bone highlighted in red.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Scaphoid_bone)

**What’s the common injury that breaks the scaphoid?**

- A hard fall with just the right position of the wrist, where it’s leveraging on that
  - A directed wrist extension force
- The scaphoid spans the two rows of bones in the wrist that we call the distal row and the proximal row of these arcs of bones and it spans that

**Does a patient with a broken scaphoid typically present with a lot of pain?**

- No, often they know they injured their wrist and they’ll get some swelling there, but it’s not that bad
  - Often in young athletes that are used to pain, they just shake it off
- There’s no great distortion of the wrist when you fracture your [distal radius](https://en.wikipedia.org/wiki/Distal_radius_fracture), it just swells up and looks like a dinner fork

![](https://peterattiamd.com/wp-content/uploads/2022/11/f27-altonbarron-1024x540.png)

**Figure 27. Location of the radius and X-ray of a distal radius fracture**.  Image source: [Wikipedia](https://en.wikipedia.org/wiki/Distal_radius_fracture)

- Often athletes with a fractured scaphoid bone come in at 6 weeks because they can’t lift weights, they can’t shuck somebody on the offensive line, etc.

**Is the scaphoid fracture the one that’s really easy to miss on an X-ray?  Would a MRI or CT scan be the imaging of choice?**

- A [MRI](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging) is used to detect occult hidden fractures
- The scaphoid is not big enough for a [CT](https://en.wikipedia.org/wiki/CT_scan)
- We can see edema
- Peter has seen a number of people who had this issue and it’s been long enough that they don’t necessarily tie the problem back to the fall

**The evolution of treatment for these patients**

- Historically, we treated all of these non-operatively
- Then there was an Australian fellow named Herbert who came up with a really ingenious screw that had two sets of threads on it and they were a different pitch
  - So when you’d screw it down the middle of the bone and turn it and when it engaged both bones, it would actually compress them together because they were different pitch (called the Herbert screw)
  - And that was a game changer for us, especially for treating athletes

**Where do you access this bone operatively?**

- There are different schools of thought
- When Alton was coming out of training, everybody made a full incision to expose everything (on the underside of the thumb near the base of the thumb and wrist )
  - And you had jigs that you can put those screws down
- Alton does almost all of his via a small, percutaneous incision, and he’ll go either retrograde often or antegrade (working from the top side of the thumb at the base)
  - It’s really a 3D effort to just get it in the right position
  - Get a central core guide wire down, and then you use a little hand drill to drill out that and then put the screw down over the wire
  - It’s really great because patients hardly feel that they’ve had any surgery
  - They heal very quickly, faster
  - This allows you to start movement earlier so that when it is healed, you already have your movement back so you’re not stiff and needing to do a lot of physical therapy

**Are there scenarios when you would not operate on a scaphoid fracture?**

- There are many
- If they’re non-displaced, then we can expect them to heal
  - We put them in a splint
  - As long as you mobilize the wrist (even if the thumb and fingers are free), these will heal
- Athletes often get a screw because they just can get back faster, even with protection

**What is the time course for recovery?**

- Let’s say you go and get the MRI to confirm the fracture right away and have surgery the next day
  - You’ll be back catching a ball in 6 weeks
- As long as it’s not contact, the surgeon can operate in a week
  - It’s really fast, a game changer now

**What is the safest wrist position?**

- Peter notes, “*You alluded to something that is one of the few things I do remember from residency, which was the position to make the splint. What is it about having the wrist in this position that for us, general surgeons, would be basically, “Let’s just let the hand guys look at this tomorrow morning. We don’t have to call them at two o’clock in the morning if this is a non-operative or non-urgent issue, but let’s at least put them in this safe position*.””

***A neutral position in terms of the carpus, some wrist extension***

- Too much flexion or too much extension increases the pressure on the [median nerve](https://en.wikipedia.org/wiki/Median_nerve) and the [carpal tunnel](https://en.wikipedia.org/wiki/Carpal_tunnel) (see the figure of nerves in the arm below)
- So people can get acute carpal tunnel syndrome (especially with some extra swelling from the injury)
  - That can be quite substantial in those more extreme positions
- So a neutral position is best for function in terms of if you’re in a splint
- But at least trying to get some finger movement, maybe typing at a keyboard or something, then that’s a good neutral position
- On occasion if Alton has to immobilize a musician for example, he will immobilize them in the position they need to play their instrument
  - Everybody’s different
  - It’s an important consideration

**What do we need to understand about the anatomy of the radial bone, the ulna bone, and these 2 big nerves (the median nerve and ulnar nerve)?**

- The [median nerve](https://en.wikipedia.org/wiki/Median_nerve) and [ulnar nerve](https://en.wikipedia.org/wiki/Ulnar_nerve) are shown in the figure below
  - The ulnar nerve runs on the pinky side

![](https://peterattiamd.com/wp-content/uploads/2022/11/f28-altonbarron-1024x698.png)

**Figure 28.  A. Nerves of the left arm and the B. ulnar nerve**.  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Ulnar_nerve)

- The 3rd nerve which completes the hand is the [radial nerve](https://en.wikipedia.org/wiki/Radial_nerve)
  - That’s profusely sensory, but it is important and provides sensory input on the back side of the hand and thumb
- Both the ulnar and radial nerve are at risk for lacerations
  - They’re at risk even when you distort the anatomy through a fracture

**What is the approximate size of the median nerve?**

- Peter remembers it was bigger than he expected and about 3-4 mm wide by 2 mm deep
- It’s an oval shape and it varies, but it is even bigger than this
  - A smaller petite person would have one about that size
  - Alton has seen them as large as almost 12 cm wide and 4-5 mm thick in a large hand
- Peter remarks, “*I guess speaks to the innovation of this unbelievable part of our body that occupies so much of our* [*homunculus*](https://en.wikipedia.org/wiki/Cortical_homunculus)”
- Meaningful hand use is so important for cognitive development and wellbeing
  - Over 60% of our higher cortical neurons are devoted just to our hand through the homunculus
  - The sensory homunculus (shown below) has big ears, big eyes, but huge hands and then a tiny shriveled up torso

![](https://peterattiamd.com/wp-content/uploads/2022/11/f29-altonbarron-1024x867.png)

**Figure 29.  Sensory homunculus**.  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cortical_homunculus)

> “*We need to keep using our hands to keep our minds vital in whatever form we’re doing*”‒ Alton Barron

- Some great studies have been done on that to show what’s the effect of just typing at a keyboard
  - And it doesn’t stimulate our cortex very much at all
  - Not typing nor texting
- But handwriting still does stimulate our brain
  - It’s an art form even though it doesn’t feel like it for many of us
  - Alton recalls a study done a long time ago at Virginia (or maybe Indiana), and they looked at kids who were asked to hand write versus type the answers to essay questions
    - The kids who were handwriting used longer sentences, bigger words, more ideas, and produced it faster than the kids who were typing
    - There was way more cortical activity with handwriting

***There are so many nerve endings concentrated in our hands that we really need to keep them functioning and get them back to function as quickly as possible***

## Carpal tunnel syndrome [2:40:00]

- If you took a cross-section through the hand the carpal tunnel is created by a Roman arch of bones (shown in the figure below)
- We have a tie bar across the top, which is a very thick [transverse carpal ligament](https://en.wikipedia.org/wiki/Flexor_retinaculum_of_the_hand) and it holds that together
  - That creates a U-shaped inverted parabola tunnel through which the 9 [flexor tendons](https://orthoinfo.aaos.org/en/diseases--conditions/flexor-tendon-injuries/) and the median nerve pass and occasionally, a medium sized artery

![](https://peterattiamd.com/wp-content/uploads/2022/11/f30-altonbarron-1024x730.png)

**Figure 30. The carpal tunnel**.  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Carpal_tunnel)

**There are 9 flexor tendons**

![](https://peterattiamd.com/wp-content/uploads/2022/11/f31-altonbarron.png)

**Figure 31.  Flexor tendons**.  Image credit: [OrthoInfo](https://orthoinfo.aaos.org/en/diseases--conditions/flexor-tendon-injuries/)

- There are 2 flexor tendons in each finger (shown above) and 1 in the thumb (9 total)
- If we look at our palm up, the median nerve is running down almost the center of the wrist and it is vulnerable to compression
  - So that if we then flex our wrist down, those flexor tendons are trying to bow string down, they will press that median nerve up against that rigid transverse carpal ligament
  - Swelling (edema) can compress that nerve as well (a problem with rheumatoid arthritis)
  - The tendons aren’t really vulnerable in that way, but the nerve is very vulnerable to compression, and that’s why it’s such a ubiquitous problem

**Which functions are controlled by the median nerve versus the ulnar nerve?**

- People often come to Alton thinking they have carpal tunnel syndrome (because it’s so ubiquitous)
- [Carpal tunnel syndrome](https://en.wikipedia.org/wiki/Carpal_tunnel_syndrome) must have numbness and tingling in the median nerve distribution
  - Which is the palm side of the thumb, index, middle, and usually half of the ring finger
- However, if you have an arthritic process, without having as much numbness and tingling, you can have isolated atrophy of the muscles
  - You have atrophy of the thumb muscles
    - It can be very gradual
    - It occurs from the encroachment on that nerve of bone spurs that grow through he arthritic process
- Rarely in a younger person, Alton will see where they have an odd motor branch, which is the nerve that comes off the median nerve that goes to those muscles
  - They’ll have a weird compression of just that without any numbness and tingling
  - But they will have isolated atrophy, and that needs to be addressed surgically

**People who often get carpal tunnel syndrome**

- Pregnant women often have carpal tunnel in the 3rd trimester simply due to swelling and fluid imbalances
- People can get carpal tunnel if they’re always pressing down and putting extra pressure on that area
  - It’s a dynamic situation
  - People who use jackhammers
  - Or people who are cyclists and they’re always pressing down and putting extra pressure on that area can get carpal tunnel syndrome only when they’re cycling.
  - Weightlifters can get it, depending on the style of what they’re doing

> “*Generally speaking, most people don’t get carpal tunnel just from typing*”‒ Alton Barron

- There was a massive class action lawsuit against IBM many years ago, and they lost the case because there was no data to suggest that it was caused by just using a keyboard
- However, if you already have it, typing will absolutely exacerbate it
  - That’s why ergonomics are so important, how you’re sitting
- During COVID, everybody went back home and worked from home and worked at random places (the kitchen table, with their laptop in bed)
  - Alton saw a lot more of both wrist tendonitis and carpal tunnel syndrome after that
  - That doesn’t affect the ulnar nerve, it involves the median nerve

**The ulnar nerve**

- While our opposable thumb is critically important, that’s governed mostly by the [median nerve](https://en.wikipedia.org/wiki/Median_nerve)
- The [ulnar nerve](https://en.wikipedia.org/wiki/Ulnar_nerve) is so important because it supplies almost all the rest of the small muscles (intrinsic muscles) of the hand
  - These allow us to spread our fingers apart, pull our fingers together, do these weird funky positions that we do
  - Like the intrinsic plus position, that is almost all ulnar nerve
- The [intrinsic flexors](https://en.wikipedia.org/wiki/Muscles_of_the_hand#Intrinsic) are ulnar
- The [extrinsics](https://en.wikipedia.org/wiki/Muscles_of_the_hand#Extrinsic) are split between the median (more approximately in the forearm)
- From an evolutionary perspective, the hand is a pretty primitive structure
  - Except for the opposable thumb
- Our foot is fantastically adapted and modified over evolution to walk
  - When we stood up, our food completely changed
- Our brains grew when we started using our hands and making tools
  - That’s when our heads enlarged

## Other common injuries of the hand and forearm [2:47:15]

**There are 3 categories of common hand injuries**

- 1 – Acute traumatic events (usually fractures, sometimes dislocations)
- 2 – Wear and tear injuries (begin in middle age and go on into older age)
- 3 – Degenerative arthritic types of problems
  - This will vary among individuals based on genetics and lifestyle

**Fractures**

- The most common by far is the [distal radius fracture](https://en.wikipedia.org/wiki/Distal_radius_fracture) (the big bone of the [radius](https://en.wikipedia.org/wiki/Radius_(bone)) near the wrist)
- Now, the the [forearm](https://en.wikipedia.org/wiki/Forearm) is super cool (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/11/f32-altonbarron-932x1024.png)

**Figure 32.  Bones of the forearm, the radius and ulna.**  Image credit: [Mayo Clinic](https://www.mayoclinic.org/diseases-conditions/broken-arm/multimedia/arm-bones/img-20007018)

- We already talked about the elbow, at that really complex, weird undulating structure there
- The ulna that we talked about is the elbow bone that we feel, the prominence of our elbow
  - That’s a straight bone and that goes down and it forms the bump here that we see on the back of our wrist
- The radius is a curved, arching bone
  - The radius is flared and provides the biggest structure at the wrist level, but it’s much smaller at the elbow level
  - It rotates around through a fixed ulna (the ulna never moves rotationally) a
  - So any disruption of that can dramatically alter our ability to hold a bowl of soup or to pronate and type and write
  - And that can be disrupted in many ways
- It’s super common to fall and have a bending moment on the radius that fractures and displaces it
  - Alton sees this commonly in **kids** who fall off jungle gyms
    - They’ll have both a forearm fracture and a mid forearm fracture, and that’s just another bending moment
  - That can very much disrupt the function there
- At any different point along the forearm (depending on the mechanism), these bones can break
- And if they’re displaced, we have to often fix them (except in very young kids)

**Nursemaid’s elbow**

- A [nursemaid’s elbow](https://en.wikipedia.org/wiki/Pulled_elbow) occurs when a parent grabs a kid by the arm to yank them across the road
- This is a subluxation of that round radial head at the elbow
- Alton had the interesting and formative experience to create one in his first daughter
  - He remembers spinning her around, she was giggling and so forth
  - Then he felt just the tiniest little weird movement in her elbow, it kind of threw her hand
  - He saw her face start to scrunch up and set her down
  - Then he just had this vision, he knew what it was
  - He quickly did the reduction maneuver so fast that she hadn’t even started crying, and then it just immediately stopped hurting

- When you pronate, it will cause that radial head just to slip out (pop up) a little bit
- So the easy maneuver is you [supinate](https://www.kenhub.com/en/library/anatomy/pronation-and-supination) (twist the forearm towards the core so the palm faces up) and flex the elbow up with a little pressure (bend at the elbow to bring the hand up to the chest)
  - This is the most stable position of that bone
  - And it will pop right back in every time
- If it stays out and you sit in an emergency room for 6-8 hours, then it’s harder to get back in
  - You’ll often have to do it under anesthesia
- Peter has seen a lot of radial fractures in friends and kids and it really seems like one of those awful luck things
  - If you fall out of a tree, slip on ice, etc.
- Then the older we get, if we have a little [osteopenia](https://en.wikipedia.org/wiki/Osteopenia) or [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis), then it takes less and less force to fracture those bones

**Does the ulna ever break on its own?**

- The most common cause is a direct blow
- For example in football, it can be a weight falling
- It can be a door smashing into you, that’s called a nightstick fracture
  - Named for the billy clubs in the UK where it would strike you when you had was up and it cracks the ulna
  - That’s the most common
- Often it is fractured in association with the distal radius
  - The styloid part can come off, it’s attached to a ligament or it can just both snap same time, and that complicates the treatment
- Then the other common one is really more of an elbow fracture, it’s the ulna (the olecranon)
  - That’s when you fall on your elbow
  - The only other way you can pull that bone off is if you fall really hard, say snow skiing
  - With the eccentric load, that triceps pulls it right off
  - Alton loves that Peter [educates](https://peterattiamd.com/michaelrintala/) so many people about eccentric loading because it’s more injurious in a way

**What chronic injuries of the hand and wrist ultimately require surgical care?**

- Overuse patterns are more tendonitis
- There are subtle differences between [tendonitis](https://en.wikipedia.org/wiki/Tendinopathy) and [tenosynovitis](https://en.wikipedia.org/wiki/Tenosynovitis)
- Tendonitis is just inflammation in the tendon
  - If the tendon is beginning to wear and tear and degenerate, you’ll get some longitudinal fissuring in those collagen fibers and then it fills in with some inflammatory tissue, and then that can envelope the tendon
  - This is a constant rubbing and further degeneration of that
  - You get chronic pain
  - You can inject it with cortisone, but ultimately they can rupture depending on how much force they’re being subjected to and for how long it’s been there
- Tenosynovitis is a subset of that where we have these effectively watertight tubes, on our flexor tendons (the [synovium](https://en.wikipedia.org/wiki/Synovial_membrane))
  - Our body produces a little bit of lubricating fluid to keep the tendons gliding smoothly in there
  - It can get inflamed from overuse and the tendon becomes trapped in there and it really hurts
  - It can limit mobility and can even cause the tendon to lock down sometimes
  - He often cures this with a cortisone shot, rest, or both
  - A subset of them ultimately require surgery (which is very minor)
- This is important for hand function
  - If you have one finger that’s really stiff, whether you dislocated it or even just sprained it, the other fingers, they’re all linked so indelibly together that actually it will make your whole hand feel stiff

## Grip strength [2:55:15]

- Peter is obsessed with grip strength and about a year ago he started experimenting with training the way rock climbers do, where you’re only using finger strength
  - What blew him away was how much weaker he felt all the way through his lats when he would restrict the amount of fingers he used to do a pull-up
  - It took him a while to work up to 10, 4-finger pull-ups (a couple months)
    - Then he moved to 3-finger pull-ups, and that was an order of magnitude harder

*Why is it when I use only 3 fingers that all of my strength fades away?*

- Alton has a couple of theories
- 1 – It could be that your brain is holding you back
  - For example, this applies to the weakness you feel and detect asymmetrically in a rotator cuff
  - If you have a small partial thickness rotator cuff tear (tiny and  mechanically not relevant), yet you can be quite weak
  - Your brain is so smart, it knows it doesn’t want to overstress that area
  - Alton’s instinct is that the first reaction, especially when you’ve never done that before, is for your brain to say, “*Whoa, that’s putting way too much tension on the other one. So I’m going to relax everything. I’m not going to give you what you need because they may rupture*.”
- What’s ironic is that the ulnar nerve is much more important for grip strength
  - This innervates only 2 fingers‒ the pinky and ring finger

- Let’s say you have an ulnar nerve that’s completely in and a median nerve that’s out, you’re going to be pretty strong still
- Whereas if you have an ulnar nerve out and a median nerve that’s still in, you’re going to be much weaker
  - The middle finger, forefinger and thumb are under the median nerve distribution

**Peter’s takeaway**:

- The pinky and ring finger matter more to grip strength than middle finger, fore finger, thumb
- You can engage your forearms much more with your pinky and ring finger
- He is endlessly fascinated by what our hands are capable of
  - It’s such a force multiplier for our species
  - It’s an unbelievable asset in our ability to carry things
    - [Michael Easter](https://eastermichael.com/about/) has written about this in his book [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767), which introduced us all to rucking
    - Other animals (domesticated) can carry a lot on their back, but we can carry our body weight in our hands
  - Alton adds, “*When you look at the Vitruvian man and when you look at the standard anatomic position of in medicine, the elbow has a carrying angle built into it to get whatever we’re carrying away from our body so we can carry more. So we have a 12 to 15 degree natural built in, what’s called valgus or away from our bodies to give us more area to carry heavy things with*.”

## Arthritis in the hands [2:59:30]

- There are 2 types
- 1 – [Rheumatoid arthritis](https://en.wikipedia.org/wiki/Rheumatoid_arthritis)
  - An autoimmune form of arthritis
  - It impedes function and physically deforms the fingers in the joints
- 2 – Common [osteoarthritis](https://en.wikipedia.org/wiki/Osteoarthritis)
  - More of a wear and tear problem
  - It’s doesn’t have an autoimmune component
- Currently Alton sees very few rheumatoid arthritis patients because there is so much more medical therapy available for them now
  - The biologics are amazing, an absolute game changes in keeping people normal for a long time
- When he started his practice he would operate as often in a patient with rheumatoid arthritis, but now he sees maybe 1 a month that needs surgery
  - It’s pretty rare

**For Rheumatoid arthritis**

- Surgery is needed because of functional limitations in the hand
  - This can also occur in the elbow and shoulder
- It’s a tendon subluxation, joint deviation that weakens their hand and decreases their ability to remain independent

**For Wear and tear osteoarthritis**

- This varies among individuals
- Some people have really good hands until the very end
- Alton compares it to a nice paint job on a car and a cheap one
- There’s a big genetic component
- He will see some young patients (50 years old) that already have a lot of visible alterations
  - Not affecting function so much as they are getting the knobbiness and inflammation in the joints

**Arthritis at the base of the thumb**

***Arthritis at the base of the thumb is ubiquitous, about 50% of all of us will develop this***

- It’s a biomechanics problem, there are 6 degrees of freedom
- It’s this biconcave saddle joint that in order to come back and forth this way (radial and ulnar deviation), then straight up (palmar abduction), and then rotating around and pronating in order to oppose the thumb tip to the fingertips
- It’s doing 3 different directional movements and it just wears out
- It’s just subjected to so many odd stresses and it’s unstable like the shoulder

**In what fraction of those people will osteoarthritis at the base of the thumb pose a functional limitation, more than something that is treatable with some Aleve here and there?**

- We don’t know the exact subset
- Many people walk around with osteoarthritis and never have pain
  - They have some stiffness and some deformity
- Of the people that present with some pain, about 25% of those potentially are going to need surgery for that at some point
  - This would be around 12.5 % of the overall population

> “*One fourth of the people that present with pain in the thumb are going to need surgery*”‒ Alton Barron

**What is the surgical procedure?**

- It varies depending on what stage they present at, but it’s some form of reconstruction
- Unlike the hips and knees that are so ubiquitous and so wonderful, we don’t have those kind of great implants for this
  - They don’t work
  - There’s very high failure rates
  - If a hip replacement or a knee replacement has a 5% failure rate at 5 or 10 years, the thumbs are 70% failure rate
- What we use is basically a reconstruction using your own tissue
- Because of the way we evolved, we have so much protective redundancy (this is super cool)
  - We have so many tendons
  - All of the flexor tendons that flex the fingers also flex the wrists and give a strength
  - We have multiple tendons that pull the thumb out
    - They do subtle differences
    - But we use those for tendon grafts
- Going back to evolution, hold your hands out and touch the tips of your thumbs and pinky finger
  - There is a big tendon that pops up on the underside of the wrist/ forearm
  - Alton has it on his right arm but not his left, and Peter has huge ones on both sides
  - That’s the [palmaris longus](https://en.wikipedia.org/wiki/Palmaris_longus_muscle)
  - Those are hugely developed in quadrupeds, in horses and so forth, a big important muscle
  - But they don’t do anything in us so they are used as a tendon graft all the time
  - We’re evolving, 15% of people don’t have this

**Does that mean you’re not actually addressing the surface of the saddle joint, which is arthritic in this procedure?**

- You’re not recreating some artificial joint (at the base of the thumb)
- What we’re creating is a [pseudoarthrosis](https://en.wikipedia.org/wiki/Nonunion)
  - We stabilize it, get it stabilized back on top
  - Alton takes a little bit of the bone off to create a space and then he rolls up the rest of that tendon and put it in there as a cushion
  - This relieves the pain and restores function
- This operation has a high level of success

> “*I don’t know how I didn’t realize you could make a case that roughly 5-10% of the population will require this at some point in their life*.”‒ Peter Attia

- This is the single most common, non-traumatic surgical repair of the hand along with a trigger finger

## Trigger finger [3:07:45]

- [Trigger finger](https://en.wikipedia.org/wiki/Trigger_finger) is what we were talking about before with inflammation of the tendon sheath
  - Right in the middle of the hand, there’s a series of pulleys

![](https://peterattiamd.com/wp-content/uploads/2022/11/f33-altonbarron-1024x882.png)

**Figure 33.  Anatomy of the middle finger viewed from the side.** Sketched by Alton Barron

- Take for example the middle finger, it’s the longest
  - There are 4 bones of the finger (see the figure above)
    - The [metacarpal](https://en.wikipedia.org/wiki/Metacarpal_bones) and 3 bones of the [phalanges](https://en.wikipedia.org/wiki/Phalanx_bone)
    - The metacarpal is hidden in the hand
  - The flexor tendon is drawn in black, this allows you to do your pull-ups
  - If you had a muscle attached to this and you pulled on it and didn’t have those blue structures (pulleys), then this would bowstring just like a fishing pole
    - If you don’t put the fishing line through the eyelets, then it just stays way away; and it’s actually stronger that way, but you lose all the mobility, you lose the capacity to really curl your fingers tightly
  - The tendon is gliding through the tendon sheath and held closely to finger bones by pulleys
    - The A1 pulley is shown in the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/11/f34-altonbarron-1024x448.png)

**Figure 34.  Pathology of a trigger finger.** Image credit: [OrthoInfo](https://orthoinfo.aaos.org/en/diseases--conditions/trigger-finger/)

- The pulleys (blue structures on Alton’s drawing) are fibro-osseous tunnels that is very strong (think rock climbing)
  - They can rupture because you’re putting so much force on those in such funky positions and isolating 2 fingers, 1 finger, and so forth
  - Alton sees that a lot in rock climbers

***The point here is that as you’re rubbing constantly going back and forth (whether you’re playing a concerto or you’re rock climbing) and you can get inflamed along that sheath***

- This particular pulley here is down in the palm (A1), that’s the most common site to have inflammation to where you can even get some nodular swelling in the tendon
  - And that thickening up of that pulley, then it just actually catches
- We call it a trigger finger because it has a feeling like pulling a trigger on a gun
- They’re ubiquitous

**Treatment**

- We frequently inject those with cortisone and frequently have to operate
  - If you take someone who presents within say 6 weeks of onset, there’s about a 75% cure rate with 1 or 2 injections
- The longer you wait, the more potential damage and more chronic inflammation that ensues
- In these types of soft tissue procedures, we don’t keep injecting cortisone because it can lead to soft tissue degradation
  - And ultimately even tendon ruptures (Alton has never seen one, but it can happen)

**What is the rule of thumb for how many times you’ll put in a cortisone shot?**

***3 in the lifetime of a tendon sheath***

- Unless it’s very, very broad
- Usually, you don’t see someone back 10 years later who needs another injection

**Extensor tendons versus flexor tendons**

- The extrinsic extensor tendon will straighten up the knuckles, but then we look further out and see that tendon stops at the middle knuckle
- What pulls the whole finger straight is actually this intrinsic muscle that’s tapering down and has a very thin tendon
  - It turns into a lateral band and it travels from the palm side up above the middle knuckle, above that axis of rotation
  - Then it goes all the way on and attaches to the tip
  - It’s a super cool mechanism that through a series of mechanical placements, it’s able to extend (straighten) the finger by contracting
  - But it doesn’t take much to damage that tendon
    - If you take a direct blow to that knuckle and that tendon slips because you’ve disrupted some soft tissue, it can slip below the axis of rotation, then it becomes a flexor and you get a [Boutonnière deformity](https://en.wikipedia.org/wiki/Boutonniere_deformity)
    - Then you cannot straighten your finger up because those lateral bands that are used to extend the finger have slipped down and become a flexor

**Emergency surgery in the hand**

- Peter vaguely remembers one emergency surgery in the hand where that sheath had become infected
- Alton notes, “*Yes. It’s one of the few really orthopedic emergencies in the hand, which is* [*tenosynovitis*](https://en.wikipedia.org/wiki/Tenosynovitis)*, and then it becomes separative (or infected) with puss in there. I mean, there’s so many nerves in our hand anyway, when you get even a few drops of purulent puss in the finger sheath, it hurts like crazy. And your posture is down like this. You can’t straighten your finger up at all. And it’s exquisitely tender and it looks swollen just along that sheath… It’s an operative emergency.*”

**How does a person get that infection?**

- It can be an open injury or even a pin prick
  - Sometimes an insect bite or sting
  - If you’re using sports equipment, you can get a little graphite puncture
- Alton doesn’t see them as much now because he’s not in the ER
- They’re ubiquitous and they come in all the time, year round

\*\*\*

**Hand & wrist exam:**

**Discussion about the hand & wrist + exam:**

\*\*\*

## Nerve pain, numbness, and weakness in the upper limbs [3:14:00]

**Parsonage-Turner syndrome**

- Many people present with numbness, tingling, weakness or pain in the upper limb
- It can start from the neck where the nerve roots exit and travel under our collarbone through the [brachial plexus](https://en.wikipedia.org/wiki/Brachial_plexus) in between the scaling muscles and then travels through our armpit and then comes down in through the arm and into the hand
- It can be confounding
- An example is [Parsonage-Turner syndrome](https://en.wikipedia.org/wiki/Parsonage%E2%80%93Turner_syndrome) (aka brachial neuritis, as in brachial plexus neuritis)
  - It’s uncommon but a fascinating study in that whole process from the neck down
  - It’s an inflammation of those nerves
  - We think it’s probably viral related because there’s usually a viral prodrome associated, but it doesn’t have to be
  - It’s an acute dramatic onset of pain all through here
  - It is a mixed plexopathy can be in multiple different nerves
  - It’s a mixed bag of palsy, weakness, and numbness
  - One of the most common presenting ways is in the [long thoracic nerve](https://en.wikipedia.org/wiki/Long_thoracic_nerve), which is part of the brachial plexus
  - You get scapular winging where you lift your arm up and it just falls down because your scapula cannot support the shoulder and arm weight
    - Because the muscle of the shoulder girdle cannot support that
  - It presents as a mix, it affects multiple nerves because those nerves are more common up here and then they diverge into the different nerves
    - Alton still remembers trying to learn the brachial plexus in med school and it was brutal because it’s really complicated
  - These are people who show up and you certainly couldn’t attribute what they’re experiencing to any one thing
    - It’s like they would have to have six lesions simultaneously

**Is this self-limiting or do you give these people steroids?**

- We give them steroids and most recover completely
- A few have some residual defects long-term

**Shoulder pain that originates in the neck**

- Alton has a tone of patients who present with shoulder pain and they may have a little something on their MRI, but that shoulder pain is actually coming from their neck
- He’ll have someone who will present with carpal tunnel syndrome, but there’s a little extra stuff going on
  - Maybe some ulnar nerve in the little finger, maybe some shoulder pain, maybe some arm pain
- The cool thing diagnostically speaking is an intrinsic shoulder problem (such as a rotator cuff tear, inflammation, bursitis, etc.) usually travels down underneath the pain, underneath the big [deltoid muscle](https://en.wikipedia.org/wiki/Deltoid_muscle), but almost never goes below the elbow

***If Alton sees pain that’s in the shoulder going below the elbow, he’s thinking maybe neck or maybe something else***

- Secondarily, if someone complains of numbness here and some numbness on the back of the hand, the radial nerve is *rarely* involved in association with [carpal tunnel](https://en.wikipedia.org/wiki/Carpal_tunnel_syndrome) or [cubital tunnel](https://en.wikipedia.org/wiki/Cubital_tunnel)
  - The patient will say, “*Oh yeah, my neck’s been really stiff*”
    - Just subtle little cues that you can get by speaking with them
  - They could have something called double crush, and that is where you get [pinching of the nerve](https://en.wikipedia.org/wiki/Radiculopathy) in the neck
    - Maybe through a disc, maybe through a foraminal osteophyte that narrows that little canal it passes through
    - And then because the axoplasmic flow (or the nerve tube), the communication of it is disrupted or compressed, it renders them more susceptible to milder compression down at the carpal tunnel or the cubital tunnel at the elbow
  - So they’re getting a double crush now
- Alton doesn’t treat necks other than some initial PT and maybe steroids
  - He refers those out
- But many patients will then see a neck surgeon who will say they don’t need surgery and they tell Alton to go ahead and treat
  - He’ll do a carpal tunnel release and their carpal tunnel will go away, but they’ll still have some upper nerve pain
- Recently Alton learned from a really smart neck surgeon about compression in the lower level, [C7 nerve root](https://en.wikipedia.org/wiki/Nerve_root)
  - Compression here goes deep under the scapula and gives a problem there
  - This was helpful as Alton often sees patients develop scapulothoracic bursitis
- You can get [scapulothoracic](https://en.wikipedia.org/wiki/Shoulder_girdle#Scapulocostal_joint) bursitis from lifting weights (especially if you’ve been out of the weight room for a long time, and you go back into it)
  - You can get a lot of upper [trapezius](https://en.wikipedia.org/wiki/Trapezius), parascapular, [rhomboid](https://en.wikipedia.org/wiki/Rhomboid_major_muscle) type pain from overuse and those overlap
- So you really have to do the diagnostic work and talk to the patients and listen to the patients to differentiate that

**Example of a complicated patient**

- The one patient that illustrates how complicated it can be was someone who had a bad shoulder fracture
  - He was treated in the emergency department, put into a sling, but then also maybe told to do [pendulum exercises](https://therapia.com/physiotherapy-rehabilitation-exercises/shoulder-pendulum/)
- Well, it was an unstable fracture, very unstable
- The weight of the arm is enormous, and all that weight pulling on an unstable fracture, that put tremendous traction on the nerves
  - It ended up killing his ulnar and median nerve
- He came and he couldn’t pose his thumb, he couldn’t do anything
- All Alton had left to work with was the radial nerve innervate (which are the wrist extensors and the supinators), and he was able to transfer some things and give him back some pretty good function
- But it was all just due to traction

**How long did it take those nerves to die under traction?**

- It was super fast
- Alton saw him 8 weeks post-op
- He said he began to lose hand function within 3 weeks of the fracture
- It’s tragic that no one picked up on this

\*\*\*

**Nerve exam:**

**Discussion about nerves and nerve pain + the nerve exam:**

\*\*\*

## The Musician Treatment Foundation [3:22:00]

- Alton founded the [Musician Treatment Foundation](https://mtfusa.org/) about 6 years ago
- This is indirectly how Peter met Alton, through a doctor in New York City who got to know  Alton through his work taking care of musicians

**Alton’s passion for music**

- When he started his practice in New York City,  he was lucky enough to inherit caring for the New York Philharmonic and the Metropolitan Opera Orchestras (mainstays of classical music echelon)
  - That spilled over into Broadway and then jazz musician, rock and roll, and so forth
- He’s always loved music and had a passion for it
- To be able to take care of musicians is both very stressful initially and incredibly rewarding
  - They’re like athletes, they’re doing this day in and day out
  - It’s their livelihood and if it’s disrupted, then both their mental health and their financial health is greatly jeopardized
- For his whole career, Alton has been taking care of freelance musicians (and their significant others) who doesn’t know when your next gig is and can’t afford insurance
  - He was always discounting his cost (sometimes down to nothing)

> “*The costs are absolutely exorbitant for healthcare*”‒ Alton Barron

- Waiving his cost is one thing, but he can’t waive the cost of anesthesia or the surgeon center
- The average cost for a rotator cuff repair is about $25,000
  - If you pay out of pocket at a surgery center (which is cheaper than the hospital)
- The average income for a fully professional, freelance musician in Austin is about $16,000 a year (pre-COVID)
- This was what was going on for years and it was always in my mind, always upsetting Alton
- Alton laments that our culture doesn’t support the arts more

**Patient zero**

- Alton’s cousin Thor is a mainstay of the Austin music scene, he cut his digital nerve (his finger)
  - He’s a percussionist and now he couldn’t play because such a [neuroma](https://en.wikipedia.org/wiki/Neuroma) had formed and he didn’t have insurance
- He called Alton weeks after he had a simple closure done and told him that he couldn’t feel his finger and couldn’t play
- He used his air miles to fly to New York and Alton fixed it
  - Alton knew the surgery center and anesthesiologist and called in a favor (they didn’t charge him)
  - Now he’s fine
- This was Alton’s patient zero and his aha moment
- He has been lucky enough to treat a lot of other musicians

**How the nonprofit got started**

- One day [Elvis Costello](https://en.wikipedia.org/wiki/Elvis_Costello) and [Diana Krall](https://en.wikipedia.org/wiki/Diana_Krall) were in and he told them he was thinking about doing this officially and asked if they could help in some way (perhaps use their names)
- They got IRS nonprofit status in 2017 and then Elvis said, “*I’m going to do the first concert. I love the Paramount Theater in Austin. Let’s do it in Austin. I’ll do a two hour solo show*.”
  - They raised about a quarter of a million dollars
  - That was the seed money and people came pouring in
- Here in Austin, [HAAM (the Health Alliance for Austin Musicians)](https://www.myhaam.org/) is a big organization that does so much and for so long, but they don’t provide the actual care
  - They were struggling to get specialists to actually discount their care or provide the care
  - And orthopedically speaking, not having your upper limb, your shoulder, elbow or hand, you can’t make music

**The physical demands of playing a violin or the drums**

*What are the types of injuries that high level musicians come in with?*

- Musicians are people too, so they do all the stupid things that we all do to injure ourselves (that’s a separate category)
  - They can’t necessarily take the same rest when they’ve injured something
  - They have to be 100%
- If you’re a violinist in the Philharmonic, there are 15 other highest level musicians waiting in the ranks for the opportunity to sit in your seat, your chair on the stage
- Alton points out one aspect of this, “*I can do surgery with probably three fingers, but if you can’t flex down your index finger or whatever on the fret, then you can’t make the music*.”
- They’re not trying to jump higher, hit the ball farther, drive the car faster, all the different ways that athletes are trying to do to maximize their output
- They are submaximal athletes, but it’s repetitious
- In a standard NFL game, there are about 35 passes
- In a typical Mozart violin concerto, it’s 20,000 bow strokes
- And they do that repeatedly over and over and over again
- A lot of these are very unnatural positions
  - Think about violinists, they need their hands, they’re shoulders, they are abducted, they are externally rotated
  - Their other one is up in the impingement zone
  - They’re living 8 hours a day doing this
  - That is terrible for the shoulder
- Think of the drummers
  - High hats and every which way they’re going and going massively for 3 hours straight
  - It’s just uncanny that they even survive
- It’s very different from athletes
  - Alton remarks, “*I don’t even know how many passes Tom Brady has thrown in his career, but it’s not that huge of a number*”

**Work at the Musician Treatment Foundation (MTF)**

- They were flooded with patients initially
- There was this backlog of patients who hadn’t played for 6-9 months
  - They were just fallow, they were trying to get odd jobs, they couldn’t take gigs
- Alton’s very first patient ([Jennifer Jackson](https://www.jeniferjackson.com/)) is a great singer songwriter in Austin and tours around
  - She had bilateral full thickness rotator cuff tears
  - She had already gone to try to see somebody, and it was going to cost her $10,000 or more
  - She had some very minimal insurance
  - When Alton told her it wasn’t going to cost her anything to fix this, she just started crying
- In 5+ years now they’ve provided over $2 million in free care to under and uninsured professional musicians
- They’ve probably treated around 50 musicians
  - And that doesn’t include the ones he’s been discounting
  - These are the one s they actually funneled through MTF
- They’ve had 100’s of non-operative musicians, it’s mind boggling
  - These are just as bad
  - Often a cortisone shot makes them better
- They have an upcoming [concert in December](https://mtfusa.org/events/elvis-costello-king-of-america-and-other-kingdoms-benefit-concert/) with Elvis, Roseanne Cash, John Leventhal, a bunch of great people
- Alton has been able to recruit over 60 colleagues who he knows and trusts
  - They have the same ethic, they want to give back
  - They are shoulder, elbow and hand surgeons at the best places around the country
- In December they are launching [P For M (Physicians for Musicians Network)](https://mtfusa.org/physicians-for-musicians/)
  - Up until now, Alton had provided all the care but they they’re going to help provide the care
  - They have 60 surgeons signed on now
- Before they were limited because Alton was the only surgeon
- Peter notes they need more dollars to help cover the other costs
  - Physicians waive their fee
  - They need to use the nonprofit resources to fun the surgeon centers and anesthesia fees
- They’ve been unsuccessful in getting any anesthesiologists who are musicians as well, but are hopeful they will once they get the right momentum
- Most surgeons (Alton included) have some participation or partial ownership of a surgery center
- His surgery center in Austin costs 1/10 of Medicare
- So their biggest cost by far is the anesthesia

**Alton’s vision for the Musician Treatment Foundation**

- Peter notes that every year their fundraiser gets bigger and more incredible
  - It’s a huge concert gala

*What types of fundraising go on outside of that each year?*

- Alton is kind of a one-man fundraising machine because of all of his generous patients
- They are applying for grants and starting to get some
- Organizations that provide community grants and so forth are right in the thick of communities because it holds communities together
  - It develops relationships that weren’t there before
  - And it’s all ages

## Gratitude and rucking [3:34:15]

- Alton practices in 2 cities
  - Monday and Friday he sees patients at his clinic in Austin
  - Tuesday, Wednesday, Thursday, he’s in New York City
- Peter is grateful that he’s had the privilege of seeing him in both cities
  - And has sent patients to him in both cities
- The gratitude is likewise; Peter mentioned rucking at one of their mini meetings and Alton loves it
  - He’s carrying 35 pounds
  - He does run rucking because he loves running
  - He’s only been rucking for about 3 months, 2-3 times a week, but it’s changed his body
    - He feels lighter, stronger, better
  - It’s been a game changer for him

§

# PHOTOS FROM PETER’S SURGERY

![](https://peterattiamd.com/wp-content/uploads/2022/11/peter-shoulder-1-altonbarron-934x1024.jpeg)

![](https://peterattiamd.com/wp-content/uploads/2022/11/peter-shoulder-2-altonbarron-918x1024.jpeg)

![](https://peterattiamd.com/wp-content/uploads/2022/11/peter-shoulder-3-altonbarron-899x1024.jpeg)

![](https://peterattiamd.com/wp-content/uploads/2022/11/peter-shoulder-4-altonbarron-907x1024.jpeg)

![](https://peterattiamd.com/wp-content/uploads/2022/11/peter-shoulder-5-altonbarron-1024x820.jpeg)

§

## Selected Links / Related Material

YOUTUBE VIDEO + CLIPS CREATED FROM THE DISCUSSION WITH ALTON:

- **Full discussion + individual exams performed on Peter**: [232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities](https://youtu.be/CtGwx2VAH_E)
- **Shoulder exam on Peter**: [Peter receives a shoulder exam from orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/S1cCsfg_J6s)
- **Shoulder discussion + shoulder exam**: [Shoulder: discussion + exam with orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/qfa4D--5LNU)
- **Elbow exam on Peter**: [Peter receives an elbow exam from orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/QXW-NzTPPaA)
- **Elbow discussion + elbow exam**: [Elbow: discussion + exam with orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/7nsrPRATK80)
- **Hand & wrist exam on Peter**: [Peter receives a hand and wrist exam from orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/m8OTfH2lH4g)
- **Hand & wrist discussion + hand & wrist exam**: [Hand and wrist: discussion + exam with orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/kNHzwLlNuQM)
- **Nerve exam on Peter**: [Peter receives a nerve exam from orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/iqn9zv5KkT0)
- **Nerve discussion + nerve exam**: [Nerves: discussion + exam with orthopedic surgeon, Alton Barron, M.D.](https://youtu.be/KNUsjkD-yOU)

\*\*\*

**The Musician Treatment Foundation**: [Musician Treatment Foundation](https://mtfusa.org/) (2020) | [3:00, 3:19:45]

**Book on diagnosing appendicitis**: [Cope’s Early Diagnosis of the Acute Abdomen](https://www.amazon.com/Copes-Diagnosis-Abdomen-Twenty-Second-Paperback/dp/B09WQDW15R/ref=sr_1_1?crid=15ZHSRU3KI5W8&keywords=cope%27s+early+diagnosis+of+the+acute+abdomen&qid=1667240251&qu=eyJxc2MiOiIxLjc5IiwicXNhIjoiMS4zOSIsInFzcCI6IjEuMjUifQ%3D%3D&sprefix=Cope%27s+Early+Diagnosis+of+the%2Caps%2C69&sr=8-1) Revised by William Silen (22nd edition 2022) | [59:15]

**Comparison of PRP to cortisone to placebo for tennis elbow**:

- [Platelet-rich Plasma or Autologous Blood Do Not Reduce Pain or Improve Function in Patients with Lateral Epicondylitis: A Randomized Controlled Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7371073/) | *Clinical Orthopaedics and Related Research* (L Linnanmaki et al. 2020) | [1:40:00]
- [Autologous Conditioned Plasma Versus Placebo Injection Therapy in Lateral Epicondylitis of the Elbow: A Double Blind, Randomized Study](https://pubmed.ncbi.nlm.nih.gov/28222465/) | *Sportverletz Sportschaden* (V Schoffl et al. 2017) | [1:40:00]
- [Autologous blood and platelet‐rich plasma injection therapy for lateral elbow pain](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8481072/) | *Cochrane Database of Systematic Reviews* (TV Karjalainen et al. 2021) | [1:40:00]

**A natural history study on asymptomatic rotator cuff tears**: [Patterns of Tear Progression for Asymptomatic Degenerative Rotator Cuff Tears](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5491331/) | *Journal of Shoulder and Elbow Surgery* (JD Keener et al. 2015) | [1:42:45]

§

## People Mentioned

- Dick Asbury (orthopedic innovator) [9:30]
- [Stephen Snyder](https://www.linkedin.com/in/stephen-snyder-673226157) (Shoulder Arthroscopic Surgeon) [31:00]
- [John Elway](https://en.wikipedia.org/wiki/John_Elway) (former quarterback for Denver Broncos) [37:00]
- [C. Thorpe Ray](https://tmedweb.tulane.edu/clubs/ctr/about-dr-ray/) (former Professor of Cardiology at Tulane) [1:00:30]
- [Ken Yamaguchi](https://www.ortho.wustl.edu/content/Patient-Care/2763/Find-a-Physician/Physician-Directory/Ken-Yamaguchi-MD/Bio.aspx) (Professor of orthopedic surgery at Washington University) [1:33:00]
- [Tommy John](https://en.wikipedia.org/wiki/Tommy_John#1974%E2%80%931975:_The_injury,_the_surgery,_the_recovery) (retired professional baseball pitcher) [1:33:45, 1:40:45, 2:08:30, 2:16:45]
- [Quinn Ewers](https://en.wikipedia.org/wiki/Quinn_Ewers) (quarterback for the Texas Longhorns, UT) [1:53:30]
- [J. William Littler](https://journals.lww.com/plasreconsurg/fulltext/2006/11000/j__william_littler,_m_d_,_1915_to_2005.43.aspx) (pioneer in hand surgery) [2:22:30]
- [Michael Easter](https://eastermichael.com/about/) (author of [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767)) [2:57:15]
- [Elvis Costello](https://en.wikipedia.org/wiki/Elvis_Costello) (famous English singer-songwriter and record producer) [3:23:45]
- [Diana Krall](https://en.wikipedia.org/wiki/Diana_Krall) (famous Canadian Jazz pianist and singer) [3:23:45]
- [Jennifer Jackson](https://www.jeniferjackson.com/) (singer song-writer in Austin) [3:28:00]

§

![](https://peterattiamd.com/wp-content/uploads/2022/11/bio-image-altonbarron-500x500.jpeg)

##### Alton Barron, M.D.

Alton Barron earned his undergraduate degree in Engineering with honors from the University of Texas at Austin.  He earned his medical degree from Tulane University, where he also completed his orthopedic surgery residency.  He was awarded fellowships in shoulder surgery at Columbia-Presbyterian Hospital and hand surgery at Roosevelt Hospital.

Dr. Barron is a board certified, fellowship-trained shoulder, elbow, and hand surgeon based in New York City since 1996. He specializes in both routine and complex problems of the upper limb, including all sports injuries, severe arthritis requiring shoulder and elbow arthroplasty, nonunions and malunions of bones, and severe nerve injuries requiring tendon transfers and microsurgery. He is a [Clinical Associate Professor of Orthopedic Surgery](https://nyulangone.org/doctors/1033264031/o-alton-barron) at NYU Langone Medical Center, and a [Senior Attending Physician](https://www.orthomanhattan.com/) at the Roosevelt Hand to Shoulder Center at OrthoManhattan. He is [Medical Director](https://www.pscaustin.com/our-physicians) of Pinnacle Surgery Center in Austin and has clinical practices in both Austin and Manhattan.  He is [affiliate faculty](https://dellmed.utexas.edu/directory/alton-barron) in the department of  Department of Surgery and Perioperative Care at The University of Texas at Austin Dell Medical School.

Dr. Barron has been teaching and conducting research for his entire career and has numerous peer-reviewed journal publications, book chapters, and national presentations.  He is a member of multiple professional societies, including the American Academy of Orthopedic Surgeons, American Shoulder and Elbow Surgeons, American Society for Surgery of the Hand, and New York Society for Surgery of the Hand, for which he served as Treasurer (2007-08) and President (2011-2012). Dr. Barron was a Fordham University Team Physician from 2002-2014 and has been a treating doctor for the New York Philharmonic Orchestra and Metropolitan Opera for the past 17 years. He is a consultant for the New Jersey Devils NHL team. He previously held academic teaching positions in Orthopedic Surgery at Columbia College of Physicians and Surgeons from 1998-2014, and the Mt. Sinai Icahn School of Medicine from 2014-2015. He was a Senior Attending Physician in the Department of Orthopedic Surgery at St. Luke’s-Roosevelt Hospital Center from 1999-2015, and a Senior Attending Hand/Upper Extremity Surgeon at the CV Starr Hand Surgery Center at Roosevelt Hospital, the oldest teaching hand service in the country, from 1996 through 2015. He is co-author, with Carrie Barron MD, of [*The Creativity Cure: How To Build Happiness with Your Own Two Hands*](https://www.facebook.com/TheCreativityCure/) published by [Scribner](https://www.amazon.com/Creativity-Cure-Do-Yourself-Prescription/dp/1451636784/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1668013390&sr=8-1) in 2012, and has been Chairman of the Board of Trustees at Post University since 2012.

In 2017, Dr. Barron founded the [Musician Treatment Foundation](https://mtfusa.org/). This nonprofit is the first of its kind, in scope and breadth, and is dedicated to the healthcare needs of professional musicians. The MTF mission is to: 1) Provide direct orthopedic shoulder, elbow, and hand surgical and nonsurgical care for the uninsured and underinsured musicians of Austin, New York, and beyond. 2) Educate musicians (both amateur and professional) on preventive medicine techniques that will minimize or avoid musician-specific injuries. 3) Conduct research and gather outcomes data into the unique diagnostic and treatment issues facing all musicians and to disseminate this knowledge throughout the world. 5) Create the first cloud-based platform to allow state of the art remote preoperative, postoperative, and non-operative continuity of care, and to provide real-time consultation and treatment recommendations and referrals worldwide. 6) Build the first physician-surgeon network in the world dedicated to providing the care for needful, injured and ailing musicians. [[altonbarron.com](https://altonbarronmd.com/about/)]

**Follow Alton here**:

- Instagram: [@draltonbarron](https://www.instagram.com/draltonbarron/?igshid=YmMyMTA2M2Y%3D)
- Facebook: [Dr. Alton Barron](https://www.facebook.com/AltonBarronMD)
- Twitter: [@altonbarronmd](https://twitter.com/altonbarronmd?s=21&t=PlTbJcHGl246iVds3KagYQ)

**Follow Musician Treatment Foundation here**:

- Instagram: [@mtfusa](https://www.instagram.com/mtfusa/?igshid=YmMyMTA2M2Y%3D)
- Facebook: [Musician Treatment Foundation](https://m.facebook.com/mtfusa/)
- Twitter: [@mtfusa](https://twitter.com/mtfusa)