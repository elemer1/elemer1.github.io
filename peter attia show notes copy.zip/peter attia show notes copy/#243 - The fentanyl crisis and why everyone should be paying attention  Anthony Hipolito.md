# #243 ‒ The fentanyl crisis and why everyone should be paying attention | Anthony Hipolito

**Source:** [https://peterattiamd.com/anthonyhipolito/](https://peterattiamd.com/anthonyhipolito/)

---

Anthony Hipolito is a sheriff’s deputy in Hays County, Texas with over 24 years of experience in law enforcement. In this episode, Anthony discusses his work to spread awareness about illicit fentanyl use and the drastic increase in accidental overdoses, especially in young people. Anthony explains the deadly nature of fentanyl, including how many counterfeit drugs are now being laced with deadly doses of fentanyl. He breaks down how fentanyl is being brought to the US and how younger and younger kids are being targeted. Additionally, Anthony discusses his goal of spreading awareness to our communities and provides important advice for what parents can do.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/anthonyhipolito/the_Drive_public.png)

Play

#243 ‒ The fentanyl crisis and why everyone should be paying attention | Anthony Hipolito

#243 ‒ The fentanyl crisis and why everyone should be paying attention | Anthony Hipolito

1x15s30s

0:001:06:50

## We discuss:

- Anthony’s life of service in law enforcement [5:30];
- Fentanyl: medical use, recreational use, and the recent rise in prevalence [8:30];
- The story of a teenager dying from an accidental overdose of fentanyl [16:30];
- The scope of deaths being caused by accidental overdoses (the majority of which are from fentanyl) [23:00];
- How young kids are being targeted, and how fentanyl makes it across our borders and gets distributed [28:30];
- What happens to a person when they overdose [35:30];
- Whether laws around drug possession are helping or hurting, and the need to focus on helping people that feel the need to take these counterfeit drugs [37:00];
- How fentanyl is being added to all kinds of drugs that you wouldn’t expect [42:45];
- What can we do as parents? [47:15];
- Narcan: a treatment for opioid overdoses [50:15];
- Importance of awareness, having conversations with kids early in life, and other key takeaways for parents [56:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Anthony Hipolito is a deputy with over 24 years of experience in law enforcement
- He retired in the summer of 2021 and was about to move on with the next phase of his life when something drew him back into public service
  - His growing concern over the amount of accidental overdoses, poisonings, effectively, on account of illicit fentanyl use
- Peter and his wife heard Anthony speak at a local school meeting a few weeks ago and were really moved by the talk.
  - It’s a really powerful talk and we’ll [link to the entire talk](https://youtu.be/QS4R8Ldmeuw) in the show notes
- In many ways, this episode really is a public service announcement, and therefore everyone will have access to the show notes
- As soon as Peter saw the talk, he realized he wanted to do something to help amplify his message, and there was no better way to do that than to have Anthony on the podcast
- This podcast is not that long relative to most of our podcasts
- We start the discussion explaining what’s going on, what the semantics are, what is fentanyl, and how is it making its way into drugs that are not fentanyl?
- There was a day when Peter sort of assumed that people who were dying of fentanyl overdoses, wanted fentanyl but they were taking too much
  - It turns out that’s not really the case
- What’s really happening is that fentanyl is being used as a feedstock to produce other drugs because it is both so much cheaper and, secondly, produces a better high
  - Therefore, if you’re trying to make sleeping pills or benzos or anything from Percocet pain pills (which also produce a high) to Adderall and things of that nature, they’re putting fentanyl into these things
- The problem is, they’re getting the dose wrong, and effectively kids don’t know what they’re taking
  - They’re accidentally taking something they don’t know
- Kids as young as in middle school are at risk, and certainly kids in high school and college
- Peter realizes he is not speaking through his channel to these kids, instead he’s speaking to parents

> “*If you have kids, I think you really want to listen to this*”‒ Peter Attia

- A lot of people use illicit drugs recreationally
- Most people don’t appreciate the prevalence with which fentanyl is making its way into other drugs, such as cocaine
  - Again, the intention isn’t actually to kill the cocaine user
  - As we will discuss, the intention is to produce a superior product
- If you’re used to listening to the podcast on audio, this might be one where you tune into the video as well, because we include a couple of videos that are quite powerful
  - You can certainly listen to them in audio and go to the show notes afterward
  - We’ll link to those videos separately
  - But if you’re on the fence about whether or not you want to listen to this one or watch it, this might be one to watch
- We close the discussion really with what can you do as a parent?
  - As far as talking to your kids, monitoring social media, having Narcan around (and knowing how to use it)
- After the interview with Anthony, Peter was thanking him for all the work he is doing and how relentless it is, and it was only then that he thought to ask, “*How is this being funded?*”
  - It’s only being funded out of the Hays County Sheriff Office [community outreach program](https://hayscountytx.com/law-enforcement/sheriff/support-services-bureau/community-outreach/), and they don’t really have much money
  - So Peter and his wife are going to make a donation there
- You can connect with your local sheriff’s office and find a similar entity there to figure out how you can get this message into the schools where you live
- Some of these stories are simply baffling
  - Kids are dying in class
  - Kids are thinking they’re taking Adderall to help them study, and instead it’s laced with fentanyl and they die right in front of a class of 24 other children
- Peter thanks Anthony for coming over on a Sunday (he doesn’t normally record podcasts on the weekend), but he and his wife saw a video of Anthony speaking and were so moved by it that they wanted to do all they could to help get this message out more broadly

## Anthony’s life of service in law enforcement [5:30]

**How Anthony got involved in outreach and education about the dangers of fentanyl**

- The dangers of fentanyl knows no boundaries; it’s black, white, brown, it’s rich, poor
  - It affects anybody and everybody, not only in Hays County, not only in Travis County, Texas, but the entire world

**Background in law enforcement**

- Anthony has been in law enforcement for 24 years
- He worked at the Austin Police Department for 23 years, and retired July 2021
- He’s a lifelong resident of Hays County, and he wanted to get out there and serve in the community he grew up in
- He took the summer off in 2021, an was recruited by friends in the Sheriff’s Office to work there in September
- He’s been at the Hays County Sheriff’s Office just over 18 months now
  - He’s currently assigned to the Community Outreach Unit
- During his time at APD (Austin Police Department), he was able to do a variety of assignments
  - APD is a large department
  - Obviously you have to start out on patrol, and he worked several stents of patrol
  - He was promoted twice, and each time you get promoted, you’ve got to go back to the patrol division, answer 911 calls, etc.
  - He worked in organized crime, in public affairs, in internal affairs
  - He did some undercover work
  - He worked mountain patrol, bike patrol on Sixth Street
- In a larger department, you’re able to specialize a lot
- Anthony was able to experience a lot and learn a lot about the department, and he reached the point where he was able to retire
- He now works in the [Community Outreach Unit for Hays County](https://hayscountytx.com/law-enforcement/sheriff/support-services-bureau/community-outreach/)
  - All he does is get out in the community and visit and show the citizens of Hayes County that they’re human
  - They’re  police officers, or sheriff’s deputies, but they’re humans
- At the community outreach unit, they have a Citizens Police Academy
  - They do junior deputy academies during the summer
  - They visit HOAs, but since about August because of what’s going on, it’s all fentanyl, all the time

## Fentanyl: medical use, recreational use, and the recent rise in prevalence [8:30]

**Up until the point of your retirement (in the summer of 2021), how big an issue was fentanyl making its way into other drugs?**

- Fentanyl was around then
- Anthony was working in organized  crime; he was a sergeant over the criminal interdiction unit
  - They battled the Mexican cartel on a daily basis
- I-35 runs up and down through the middle of Hays County, through the middle of Austin
- He had about 10 officers assigned to him, and they had officers that did interdiction work up and down I-35
  - They had officers that worked at ABIA
  - They also had officers that worked with FedEx, UPS, or the postal service, to try to interdict not only drugs but money, guns and any type of criminal element

***Anthony did that assignment for about 3.5 years, and they started seeing fentanyl in 2017/2018, but it was more on the black market***

- People would order fentanyl in the dark web and it would be sent from China via FedEx or UPS
- The majority of their seizures at that time were through FedEx and UPS
- They would work with the postal inspectors and security folks with UPS and FedEx, and they would intercept boxes and boxes of illicit counterfeit pills

**What’s going on now involves the Mexican cartel**

- They’re very competitive and they want to own the drug market
- Since they’ve gotten into the fentanyl game, we’ve seen it become more and more prevalent over the last number of years

**Peter’s experience with fentanyl**

- Peter thinks he’s been asleep at the wheel and hasn’t paid a lot of attention to this until the last six months
- Back when he worked in the hospital, they used [fentanyl](https://en.wikipedia.org/wiki/Fentanyl) all the time
  - It was a very potent intravenous narcotic
- [Morphine](https://en.wikipedia.org/wiki/Morphine) would typically be given in milligram doses
  - If a patient was having a lot of pain, you would use an intravenous infusion of morphine, anywhere from 1-5 milligrams (mg, thousandths of a gram of morphine)
- Fentanyl was much more potent, it came on quicker, and it was dosed in micrograms (μg, millionths of a gram)
  - This is a lot smaller dose, and it was a very good drug for pain and sedation
  - For example, if a patient was having something like a colonoscopy, you would use maybe a 100 μg of fentanyl (that’s 0.1 mg), and say a couple mg of another drug called [versed](https://en.wikipedia.org/wiki/Midazolam) that kind of makes you drowsy and makes you forget what’s going on
    - Anesthesiologists use this all the time in the operating room
    - Fentanyl is the anesthesia part; it takes care of pain

**Peter never knew fentanyl existed outside of a liquid form and had no idea that it was being put into other drugs.**

**When did that transition take place?**

*What is it about this drug? Is it just that they make people high and it’s bad to be high?*

- Fentanyl is powerful, you only take micrograms
- The Mexican cartel is making fentanyl in their labs in Mexico
  - They’re making a synthetic opioid, it has the same molecular structure, they just don’t need the poppy plant to make it

***The big difference between the fentanyl that doctors would prescribe and what the Mexican cartel is making is the dosage***

- The cartel doesn’t know how to control the dosage
- They don’t really
  - They grasp how powerful fentanyl is; ***two milligrams can kill you***
    - That’s beyond a lethal dose

![](https://peterattiamd.com/wp-content/uploads/2023/02/f1-anthonyhipolito-1024x512.png)

**Figure 1. Two milligrams of fentanyl can be lethal**. Image credit: [NaturalHigh.org](https://www.naturalhigh.org/risks-of-fentanyl-poisoning/)

**Why does this drug kill you? What is happening that’s killing people?**

- A lethal dose of fentanyl attacks your respiratory system; it slows everything down
  - You get that euphoric high, but you don’t realize that it’s shutting your body down

***Once your respiratory system starts shutting down, your heart rate starts going down and you can be dead in an instant***

- Anthony adds, “*that’s how powerful and scary this stuff is*”

- Peter saw this in the hospital; it was not uncommon
  - If you accidentally gave a hospitalized patient too much (you misjudged a person’s sensitivity) and gave them 100 micrograms when they probably should have only had 50-75 micrograms, and all of a sudden they would slow down their breathing rate to the point where you would either have to put a breathing tube in them to breathe for them, or you would have to give them something like [Narcan](https://en.wikipedia.org/wiki/Naloxone) to reverse the effect
  - There were actually examples in the hospital Peter trained in where patients had narcotic overdoses completely by accident, but due to the potency of these drugs
    - Especially with fentanyl, less commonly with morphine
- Peter notes, “*If that can happen in a hospital, how much more likely is it if you get this dosing schedule wrong outside the hospital?*”
  - They’re not off by 10-20%, they’re off by an order of magnitude

**Over the course of your career, what was the “bread and butter” of the DEA and law enforcement when it came to illicit drugs?**

- Peter would think the big four would be: cocaine, marijuana, methamphetamines, and heroin

*When did it turn into other drugs like Percocet and legal drugs, but being used illicitly and sold illegally?*

- Anthony thinks it was around 2010/2011 when you started seeing pain management doctors recklessly prescribing the [oxycodone](https://en.wikipedia.org/wiki/Oxycodone), the [Vicodins](https://en.wikipedia.org/wiki/Hydrocodone/paracetamol), the [Percocets](https://en.wikipedia.org/wiki/Oxycodone/paracetamol), and there was no regard for anybody
- These pills are powerful; people get addicted to them
- That’s why a lot of people when they have surgery, they don’t like taking these pain pills because they’re so addictive and they’re afraid they’re going to get hooked on them
- They started seeing that in 2010/ 2011, people would doctor hop
  - If one doctor wouldn’t prescribe, they would go find another doctor, and once they found that doctor, they would continue to go back to them, and they would just stockpile the stuff
- It was around 2010/ 2011, that opioid addiction was pretty prevalent, and this is the fallout of it

> “*The fentanyl game has it just elevated the opioid crisis to a whole, entire new level*”‒ Anthony Hipolito

**Why is fentanyl even being put into these things?**

- With the crackdown on poppy fields, it’s harder to grow natural opioids, but you can make fentanyl synthetically
  - Presumably that’s cheaper, less labor, easier to do

![](https://peterattiamd.com/wp-content/uploads/2023/02/f2-anthonyhipolito.png)

**Figure 2. Fentanyl is synthesized in the laboratory not harvested from an opium poppy**. Image credit: [CDC](https://www.cdc.gov/stopoverdose/fentanyl/index.html)

*Did that immediately shift production to China?*

- When the Mexican cartels found out what China was doing, they started buying the precursor chemicals from China and began to make it themselves
- It’s synthetic, it’s pure fentanyl
- The Mexican cartel wants control of the drug game, and it’s much cheaper for them to make fentanyl than it is for them to make cocaine, heroin, or methamphetamine
  - Simply because they don’t have to worry about the poppy plants (weather, labor, etc.)
  - They just buy the precursor chemicals from India and China
- Anthony has heard that they are now starting to make the precursor chemicals themselves in Mexico; this makes it cheaper and faster
- Once they get fentanyl by the kilo, they just ship it across to the US

## The story of a teenager dying from an accidental overdose of fentanyl [16:30]

**The story of Kevin McConville, age 17**

- Before we go any further, Peter shares a video that Anthony shard that night when he gave a presentation at the school district about the parents of a boy who lost his life

- Their son, Kevin McConville, was 17 years old
- They found him in his bed, he appeared to be asleep, but he was gone
- When they told one of his friends that he had passed, the friend confided in them that Kevin was taking Percocet and Xanax to help him sleep
  - Another “friend” had given Kevin the pills, probably because he confided in that person
  - Kevin had probably taken them before and nothing happened, so he continued to take them
  - They don’t know how many times he took them
  - It could be your first time, it could be your last time
  - No parent wants to see their child in that position; he looked like he was asleep
- Anthony’s reaction, “*That’s a hard video to watch. Very hard, and it’s powerful.*”
- One of the reasons Anthony puts this video on in the beginning of his presentation is because he wants to bring it home and personalize it
  - He wants kids to realize that somebody their age has fallen victim to this
  - Not everybody knows somebody that has died from fentanyl
  - Deaths in kids hasn’t been a prevalent as what we’re seeing now

**The Story of Spencer Wheeler, age 17**

**These are accidental deaths**

- These are not people intentionally taking a dose of fentanyl so high that they end their life
- This is someone who thinks they’re taking something to help them sleep, and then they don’t wake up

**Do we know what dose was in Kevin’s system?**

- The toxicology on Kevin’s case hasn’t come back yet
- We don’t know what Kevin was dealing with personally
  - We all battle our own demons
  - He was taking what he believed to be Xanax because he needed help sleeping
- Anthony adds, “*Kids these days battled so much more than what we had to deal with simply because of social media*”
- Anthony wants to help kids **get rid of the stigma**, “*Let’s figure out why you’re making that decision*”
  - Why you’re needing Xanax to sleep in the first place, and why you’re seeking this out
  - It doesn’t make you a druggie
  - He’s not trying to doa a “say no to drugs” talk
  - He’s trying to personalize it
  - He’s trying to bring as much awareness to this crisis as he can

***We want kids to be able to come forward and ask for help and whatever Kevin was dealing with, led him to take these pills***

- His parents had no idea what was going on until his mom or his dad walked into his room the next morning and he was lifeless
- They’ve been very brave and join Anthony in several presentations
  - It’s hard, but it’s good for her and other parents to talk about it
  - They’re very passionate about saving somebody’s life
- The hard part for the parents is they’ll never know why their son was taking pills to help with sleep

***What Anthony really wants to focus on, for both the kids and the adults, is the “why”***

## The scope of deaths being caused by accidental overdoses (the majority of which are from fentanyl) [23:00]

**Peter calculates that every five minutes someone dies as a result of an accidental overdoses in the United States**

- Current data from the [CDC](https://www.cdc.gov/nchs/products/databriefs/db457.htm#:~:text=The%20number%20of%20drug%20overdose,Vital%20Statistics%20System%2C%20Mortality%20File.) report that 106,699 people died from a drug overdose in 2021
- It’s important to understand this is *not* including people who overdose as a way to end their lives
- This is people who think they’re taking either a recreational drug (like cocaine) or something that’s laced

**Do you have a sense of what percentage of accidental overdose deaths today are attributable to fentanyl (where fentanyl is in the drug they are taking)?**

- About ⅔
- Anthony points out, “*It’s a poisoning. They’re not intentionally trying to kill themselves. They’re taking a drug for whatever reason. They’re not waking up, so they’re being poisoned by these drug dealers, by the Mexican cartel, and that’s sad… it’s insane.*”

**Why in the world haven’t they figured out a way to get the doses right?**

- Killing your customers isn’t good for business
- There are kids taking 2, 4, even 8 milligrams of fentanyl in a single tablet
  - That’s very scary
  - That’s 100x a lethal dose; you might as well have cyanide
- Anthony recalls one of the 15-year-olds that passed away on August 21, Noah Rodriguez
  - He was a sophomore at Johnson High School
  - He was Janelle’s son
  - That video is long but it’s very moving

- Noah took what he believed to be Percocet, and his mom got a call at midnight, August 21st to someone screaming on the other end of the line saying, “*Noah, we believe Noah’s overdosed. We believe he overdosed. So I’m doing CPR.*”
  - Janelle was in Buda, Texas
  - The overdose of the poisoning took place down in San Marcos, Texas
  - So by the time she got there, her mom and dad had already made it to the scene
  - She got out of the car and her mom just shook her head saying, “*He’s gone*.”
- What she has since learned is that Noah had eight milligrams of fentanyl in his system
  - They got toxicology back just a week or two ago
  - It was pure illicit fentanyl that was in his system, and that’s four times the amount that it takes to kill somebody
  - It’s insane; it makes no sense

**Why is there so much fentanyl in these pills?**

- Anthony gets this question all the time about why they are killing their own customers
  - It happens so often they don’t care what they do
  - Obviously they don’t want four kids to die in a four week timeframe because that’s when they get the attention of the DEA and other law enforcement
  - But if they kill a person here or there, they don’t care

**If you asked Peter what was the greatest threat to a young person’s life**

- Someone under 40
- He would say it’s two things‒ dying in a car accident and suicide
  - You’re going to take your own life where you’re going to die in a car
  - We can get into the why’s; there’s alcohol and a whole bunch of reasons

> “*But as you know today, accidental overdose dominates those two, like they’re now the rounding errors*”‒ Peter Attia

- And this happened in one decade
- The numbers have gone up exponentially since 2010/2011
  - And they’re not using the word exponentially hyperbolically
- Fentanyl seizures by law enforcement have gone up over the period from 2018-2021 from 200,000 to 1.5 million to 4.1 million to almost 10 million (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/02/f3-anthonyhipolito.png)

**Figure 3. Law enforcement seizures of pills containing illicit fentanyl**. Image credit: [NIH](https://www.nih.gov/news-events/news-releases/law-enforcement-seizures-pills-containing-fentanyl-increased-dramatically-between-2018-2021)

***Anthony brings up the data from 2021, “If you’re between the ages 18 and 45, fentanyl was the number one killer. It wasn’t gun violence, it wasn’t car crashes, it wasn’t suicides, it wasn’t COVID.”***

- He thinks when we get the 2022 numbers back, it’s not going to be starting at age 18, it’s going to be 13 or 14
- The DEA believes that the Mexican cartel are specifically targeting our young folks, and that’s why we’re seeing that

## How young kids are being targeted, and how fentanyl makes it across our borders and gets distributed [28:30]

**How is the Mexican cartel targeting young people?**

- They’ve started making pills that look like candy
  - In law enforcement, they call it rainbow fentanyl or candy fentanyl
  - It looks attractive to the young folks
    - It’s pretty, it won’t kill me; that won’t happen to me
- They’re also targeting young folks because they want to get people addicted a lot younger so they have that customer base longer

**What does that chain look like?**

- If 13-year-olds and 10-year-olds are potentially being targeted, and you’re going to expand your market, who is the drug dealer in that situation?

*How is it getting its way from a Mexican cartel to distribute these much more friendly looking drugs?*

- It’s no longer a shady looking Percocet with a stamp on it
- It surprised Peter, how good the counterfeits are; they’re indistinguishable from legitimate prescription drugs (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/02/f4-anthonyhipolito.png)

**Figure 4. Fake pills often look like prescription opioids such as Oxycodone/ Percocet**. Image credit: [DEA](https://www.dea.gov/onepill)

***It boggles the mind how they have figured out how to color match, perfectly stamp, and manufacture this, and yet they’re off by a dose of a thousand on the active ingredient***

**We’re seeing this in middle school now?**

- The most recent death in Hays County was a middle school student; she was 13 years old

*How did she acquire the drug?*

- The majority of the time they’ll make the illicit pure fentanyl in Mexico, smuggle it across the border to their counterparts here in the United States, and then it just gets distributed
- Fentanyl come over in power form; it’s blocked in a kilo
  - Just like a brick of cocaine would’ve come across
- Anthony doesn’t know off the top of his head what the wholesale price is of a kilo, but it’s cheap compared to a kilogram of cocaine, heroin, or any other drug
  - This is based on the fact that you get to make it synthetically

**What’s the most porous part of the border that brings this stuff into the United States?**

- Vehicles, there are various ways
- They’ll load cars up, they’ll load semis up, they’ll strap it to people’s bodies, they’ll send it via airplane
- Drones are real big now getting across the border

*What altitude can drones fly at?*

- High enough to get over the wall, high enough to not be detected
- They have grown their business model
  - If they were innovative in other ways, we wouldn’t have traffic problems
- They’re so ahead of the game of law enforcement, like some of this stuff’s not even getting detected by x-rays
  - Some of this stuff’s not even being detected by narcotic dogs
- They’re finding various ways to smuggle it in
  - Candy fentanyl or the rainbow fentanyl, they’re actually smuggling it into the country inside Skittles bags, inside Nerd boxes… it doesn’t have Skittles in it, but it’s full of fentanyl pills that look like a candy (see the picture below)
  - Then it comes over in a regular truck; you would never know

![](https://peterattiamd.com/wp-content/uploads/2023/02/f5-anthonyhipolito.png)

**Figure 5. Fentanyl wrapped in popular candy bags.** Image credit: [Fox13 Tampa Bay](https://www.fox13news.com/news/moody-warns-parents-about-drugs-ahead-of-halloween)

- Peter asks, “*are they going to put these things in Skittles because the idea is a kid that tries one of these Skittles, even if they’re 13, is going to get high and getting high feels good, and they’re going to want more of those Skittles. Is the impression that the kid thinks it’s a skittle or pretty quickly realizes this is no Skittle, but whatever it is, I love it and I just want more of it?*”
  - Anthony thinks they do that specifically just to smuggle it into the country
  - They’re not selling them as skittles
  - They’re going to break it apart when it’s a skittle and turn it back into pills
- Anthony heard a state where the folks down at the border probably intercept 5-10% of the narcotics that go across the border

**Is this low interception of narcotics at the border a staffing issue?**

*Is it simply a numbers game where unless you’re willing to stop and seize every vehicle crossing, which would of course make transport over the border impossible, that’s all you can get?*

- There’s just so much of it
- It’s a staffing issue and a variety of things
- They’re so smart in how they get it across the border that we’re not able to detect it
- If they only intercept 5-10% at the border, that leaves other law enforcement entities throughout the country to try to intercept it

**From a jurisdiction perspective, is the border seizure the responsibility of border patrol or the DEA?**

- It’s border patrol’s responsibility

*So the second it gets across the border, it’s a DEA law enforcement issue?*

- Yes, once it gets across the border it’s under the jurisdiction of the DEA, FBI, ATF, local law enforcement, federal law enforcement
  - It’s any and everybody that specializes in tackling this narcotic game

**Back to the girl in seventh grade (13-year-old)**

*How did she come into possession of this stuff? Was it through an older sibling or was she the direct person who got it from a dealer?*

- Anthony doesn’t know the specifics of her case
- How it works in today’s world, a lot of this stuff is sold on social media
  - It’s [Facebook](https://en.wikipedia.org/wiki/Facebook), it’s [Snapchat](https://en.wikipedia.org/wiki/Snapchat), it’s [Instagram](https://en.wikipedia.org/wiki/Instagram)
  - They’re very blatant about it, especially on school campuses
  - If they bring it to school, all they have to do is put an emoji up on their Snapchat, and all the kids know so-and-so has pills today
  - Or they’re downloading these encrypted apps ([Telegram](https://en.wikipedia.org/wiki/Telegram_(software)), [Signal](https://en.wikipedia.org/wiki/Signal_(software))) to where once these messages are sent and received, they disappear
  - This is an issue with Snapchat as well
- It’s hard for law enforcement to go back and try to trace where these pills are coming from
- Anytime in Hays County when there is a fentanyl related overdose, the narcotic folks go to the scene to try to get phones, talk to witnesses, talk to the friends
  - Their sole goal is to try to trace back where these pills are coming from and to see if they can find out who specifically sold these pills to these kids to put them in federal prison

**Do you have a sense of how many steps they are removed from the guy that receives the brick of fentanyl?**

- It’s not two or three, it’s multiple steps
- There are different plugs in each city
- It’s a whole enterprise on how it’s distributed throughout the country

## What happens to a person when they overdose [35:30]

- This kid actually lived
  - If you watch the entire video you will see EMS gets there, they put him on the stretcher, and he’s sitting up on the stretcher, talking like it’s no big deal
- Peter points out, “*These are hard videos to watch, but I don’t think we’re going to shy away from that. I think it is important that people understand how uncomfortable this is. There’s probably a lot of mixed emotions that are going on around the person who stops breathing*.”
  - Fear and panic
  - Hesitation to call the police or paramedics for fear of reprimand
- Anthony adds that in this video the kid wasn’t getting poisoned, and it was 20-25 minutes before he called 911
  - That attributed to not wanting to get in trouble and not believing his friend is dead

## Whether laws around drug possession are helping or hurting, and the need to focus on helping people that feel the need to take these counterfeit drugs [37:00]

**Let’s say someone calls the police immediately, calls the paramedics, and everybody shows up. How clear is the law on the prosecution of people? Are they going to be prosecuted for drug use?**

- If they are in possession of drugs, they will be prosecuted
- There was a young man who overdosed on a high school campus; he nearly died in class, and he had three or four illicit counterfeit pills on him at the time
  - That’s still in criminal proceedings
- Obviously law enforcement wants to save your life; they will deal with the criminal part later
- If you’re in possession of it, you’re more likely to get charged

**Are criminal charges the right solution to the problem?**

- Peter just [read](https://www.reuters.com/world/americas/canadian-province-tries-decriminalizing-drugs-fight-overdose-crisis-2023-01-31/) that British Columbia is the latest province/ state to decriminalize personal drug possession
  - This is going to be their attempt to address this problem
  - It’s not entirely clear how this fixes the problem, but you can see scenarios where it makes things better
  - It would presumably reduce any friction to someone calling for help the moment someone is down because you don’t have to fear that you’re going to be prosecuted
- If you go back to the case of that kid who basically died in class, it’s a miracle he’s alive

*Taking off your law enforcement hat, just from a personal sort of philosophical standpoint, do you think that’s the right thing to do?*

- This is on a case-by-case scenario from a law enforcement perspective
- There are laws they have to follow
- If they have to end up putting that young man in jail, it doesn’t mean that he’s going to spend the rest of his life in jail
  - It doesn’t even mean he’s going to be in jail
- They have to file the appropriate charges, but their main concern is to make sure he’s alive, make sure he gets the help he needs
- They don’t necessarily arrest him that day
- The young man discussed earlier went to the hospital and got treated, and then we turned those pills in and got them tested
  - If it comes back with illicit narcotic in it, then we would look at filing charges at that time

***Filing charges and putting somebody in jail or at that immediate moment is not a priority. Our priority obviously is life.***

- Peter recalls that Oregon has decriminalized personal possession of small amounts of illegal drugs; Portugal did this 20 years ago
- He thinks Portugal decriminalized any drug for personal possession, and their accidental overdose rate dropped to the lowest of any country in Europe

![](https://peterattiamd.com/wp-content/uploads/2023/02/f6-anthonyhipolito.png)

**Figure 6. 2019 data on drug-induced mortality rates among people aged 15-64**. Image credit: [European Monitoring Centre for Drugs and Drug Addiction, Portugal Country Drug Report 2019](https://www.emcdda.europa.eu/system/files/publications/11331/portugal-cdr-2019_0.pdf)

- That said, it is on the rise again; fentanyl is raising all boats at the moment, Portugal included

![](https://peterattiamd.com/wp-content/uploads/2023/02/f7-anthonyhipolito.png)

**Figure 7. Recent rates of high-risk opioid use in Portugal are high**. Image credit: [European Monitoring Centre for Drugs and Drug Addiction, Portugal Country Drug Report 2019](https://www.emcdda.europa.eu/system/files/publications/11331/portugal-cdr-2019_0.pdf)

- Peter doesn’t know where he stands on this

- - Part of him thinks this is a bandaid
  - He thinks what Anthony said at the outset is the problem, which is, “*Why do you need \_\_\_\_\_ drug?*”

***Why do kids need Percocet, Xanax, whatever it is?***

- Why do kids need these drugs?
- Without the answer to that question, it is very difficult to think about this
- Anthony agrees and adds, “*It doesn’t make you a bad person if I have to arrest you today because you have three pills on you*.”
  - He has a job to do, but he still needs to treat you with respect and try to help you
  - If he puts you in jail today, when you get out, let’s figure out a way to get you the help you need and figure out “why”

***Without that “why,” that person will never be able to get the help that they need***

**Do you feel like enough of it is going into the mental health side of it?**

*Is most of the attention being channeled into seizures at the border, stopping the cartels, the law enforcement side of it?*

- Anthony doesn’t think so
- It is becoming more and more prevalent for people to start asking for help
  - Several kids in Hays have come forward and asked for help; they’ve talked to their pediatricians, counselors, and teachers
    - But they’re being told it’s a six-week wait for a bed, or three-month wait
- We’re learning there are not enough rehab placers for the people to go to
- It’s not just a law enforcement thing, it’s not a school district thing; it’s a community that needs to collaborate together to try to figure out ways to help the folks that are struggling

> “*We’re not going to save everybody. We’re just not.*”‒ Anthony Hipolito

- Anthony has been a cop for 24+ years and has arrested many people that have had drugs or put drug dealers in jail
- We’re never going to win the war on drugs, but if we can take 10 pills off the street a day, we’ve probably saved six people

> “*Six out of every 10 illicit counterfeit pills have enough fentanyl to kill somebody. So if we can take 10 pills off the street, we’re potentially saving six lives*.”‒ Anthony Hipolito

- If Anthony can go talk to a group of 300 students and keep one kid from making that decision to take a drug, or if he can get one of those kids who’s struggling with an addiction to say, “*Hey, I need help*,” then he can sleep well at night knowing that we’re doing something to help

## How fentanyl is being added to all kinds of drugs that you wouldn’t expect [42:45]

**What is the breadth of drugs that you’re seeing fentanyl added to?**

- Peter talked to a friend who goes to [Burning Man](https://en.wikipedia.org/wiki/Burning_Man) every year (lots of drugs are used there), and maybe he head him wrong (or he got his facts wrong), he said at Burning man **there were at least two deaths attributed to fentanyl in drugs that would normally never have fentanyl in them**
  - One was cocaine and one was ketamine
  - Ketamine is a perfectly legal drug, but clearly this person was using counterfeit ketamine
- Potentially fentanyl is being added to every single counterfeit pill out there
  - Pain meds, [Percocet/ oxycodone](https://en.wikipedia.org/wiki/Oxycodone/paracetamol), [Oxycontin](https://en.wikipedia.org/wiki/Oxycodone), and [dilaudid](https://en.wikipedia.org/wiki/Hydromorphone) are your big boys
  - Then you’ve got it going into the [benzos](https://en.wikipedia.org/wiki/Benzodiazepine), your sleeping pills‒ [Ativan](https://en.wikipedia.org/wiki/Lorazepam), your [Ambien](https://en.wikipedia.org/wiki/Zolpidem)

- [Adderall](https://en.wikipedia.org/wiki/Adderall) (stimulants)
- Any pill that a kids wants is going to be laced

- This is frightening because Peter hears from his daughter that it’s not uncommon for kids to say, “*I need something to help me study. I need something to help me sleep.*”

*Has this crept its way into anything that has to do with marijuana?*

- Yes, we’re talking every illicit recreational drug that’s out there
  - Cocaine, heroin, methamphetamines, molly pills, X, marijuana
  - We haven’t seen this particular here in central Texas yet,
  - The DEA says they’re starting to see vape pens that have the THC in it that also contain fentanyl
    - Anthony hasn’t seen this in central Texas yet, but it’s just a matter of time

***Any illicit drug, any vape pen could be laced with fentanyl***

**There is no reason to do this unless you’re trying to get people higher than normal. There’s no cost benefit to putting fentanyl into THC; they’re totally different agents.**

- Anthony agrees
- It’s a competitive market, so they want the people to seek them out for this particular drug
  - The drug dealer who has the strongest cocaine on the market; everybody go to him or her
- Folks are thinking they’re taking cocaine, not realizing that when the pure fentanyl gets here to the country, that drug dealers on this side of the border are starting to put fentanyl in all their drugs
  - So when they sell it, they want their stuff to be more powerful
  - They want that street cred, because it goes out on social media
  - They want to stand out above the rest

**Is there any drug fentanyl has not made its way into yet?**

- No

**It hasn’t shown up in vapes in central Texas yet. Do you think that’s just a matter of time?**

- It has shown up, but fentanyl’s been seized
- It’s showing up in cocaine
  - Today, the chances of fentanyl in it is probably 90 to 99%
- Peter clarifies, “*And most of the time you probably get away with it because it’s not a lethal dose, but you’re playing Russian roulette*”
  - Anthony brings this up in his presentations, because six out of every 10 illicit counterfeit pills
  - So yes, you’re playing Russian roulette by taking a pill that you don’t know where it came from

## What can we do as parents? [47:15]

- Peter would guess that the majority of people listening to this podcast are parents or are going to share it with someone who is a parent; he doesn’t think there is a 13-year-old or a 19-year-old listening
  - Anthony adds, “*They don’t like listening to cops either*”
- Peter thinks about his family, he has a 14-year-old daughter, eight-year-old and five-year-old boys
- This is one of the reasons Anthony is passionate about this, he has kids (a freshman and a senior in high school)
  - He’s seen firsthand how it’s affected his community

***As parents, we have to be nosy; we have to take the blinders off and stop saying “My kid won’t do this”***

**How many parents that you’ve met who’ve lost a child were so shocked (they never knew this was happening) versus parents who knew their kid was struggling with drugs?**

- You hear that first case a lot; Anthony doesn’t have an exact percentage
  - It may not be because they don’t know; it’s that they refuse to believe it
- This goes back to the **stigma**
  - Parents are embarrassed if their kids are doing drugs

> “*We have to stop with the stigma, stop with the judging, and we have to work together as a community to get this as low as possible*”‒ Anthony Hipolito

- We’re not going to get rid of it, but if we can move it around a little bit, then we’re doing what we can
- Anthony hears it too much and as a parent, and he catches himself sometimes, “*Nah, not my kid,*” but he has to remind himself because he sees it so often that it could be his kid
- Kids have social media, but you have to be nosy
  - Actually, Anthony’s freshman no longer has social media

**You mentioned how kids use emojis. Is there any chance a parent is going to figure that out?**

- When Anthony talks about **social media** to parents (at the PTA or HOA meetings), he stresses, “*If you are going to give your kid a phone, and if you’re going to give your kid social media, you better learn as much as you can about every single app that’s out there, because I guarantee you, your kid knows more about that app than you do.*”
  - If you give them Snapchat, you better have it on your phone as well
  - You better learn as much as you possibly can and figure out the tips and tricks that they probably know on how to hide things
  - They’re always going to be more savvy than we are, but it’s our duty as parents to learn about it, if we’re going to hold them responsible
- It’s not only the **apps**, it’s the **games**  ([Roblox](https://en.wikipedia.org/wiki/Roblox)), it’s the **encrypted apps (**[Signal](https://en.wikipedia.org/wiki/Signal_(software)), [Telegram](https://en.wikipedia.org/wiki/Telegram_(software)))

![](https://peterattiamd.com/wp-content/uploads/2023/02/f8-anthonyhipolito.png)

**Figure 8. Emojis being used in conjunction with illegal drugs**. Image credit: [DEA](https://www.dea.gov/sites/default/files/2021-12/Emoji%20Decoded.pdf)

## Narcan: a treatment for opioid overdoses [50:15]

- Peter used to use [Narcan](https://en.wikipedia.org/wiki/Naloxone) in the hospital, mostly at the end of surgery when a patient needed to be brought back and you mistimed the opioid dose
  - A lot of times you’d use it if you accidentally gave that person 120 or 125 micrograms of fentanyl, but that was a bit too much for them, and their breathing rate is slowing (in the situation described earlier)

**If a kid is down and you give them Narcan, are they out of the woods or is there a chance that they have so much drug in them that even though they start breathing again, they’re going to crash?**

- Anthony talks about this because kids have started buying Narcan and carrying it with them saying to a friend, “*Hey, I’m going to poop this pill… hold my Narcan. If I fall down, can you please shoot me up.*”
- What they really don’t understand is this fentanyl is so powerful
  - One injection of Narcan or one nasal spray of Narcan is not helping because fentanyl is so fast-acting
- There’s not a set time because everybody is built differently, metabolism is different

***The quicker you get Narcan into that person’s system, the better chance they have to live***

- But what they’re seeing in a lot of these overdoses and poisonings throughout Hays County is that **one injection of Narcan is not working**
- There was a kid two weeks ago that took 15 doses of Narcan
  - Paramedics were not there yet
- All the deputies in Hays County carry Narcan so if they arrive first and they know it’s a fentanyl related overdose they can administer it
  - The guy could be drunk, and that is so prevalent
  - But you can give them Narcan and it’s not going to hurt them, even if they haven’t taken fentanyl
- They use an intranasal Narcan spray
  - It’s a nasal spray just like one you would use for allergies
- But fentanyl is powerful, and depending on how long it’s been in their system, their respiratory system could have slowed down to the point where Narcan is not going to get through, and that is where **CPR** comes into play
  - CPR gets the blood flowing again so that Narcan can get in there and attach to the opioids

**Peter’s takeaway for parents**‒

- Lesson #1 for parents is to be really hypervigilant about social media
  - Peter has read horror stories of drug dealers on Snapchat who are basically offering dropdown menus (Anthony agrees)
- Ask your kids, “*Do you need something to make you feel happy? Do you need something to help you sleep? Do you need something to help you study? I mean, it’s very banal language.*”

**How long does Narcan last? Does it have any expiration date on it?**

- Anthony doesn’t think it has an expiration date
  - A [2019 study](https://www.tandfonline.com/doi/full/10.1080/10903127.2018.1563257?scroll=top&needAccess=true&role=tab) found that Naloxone products stored for nearly 30 years still retained more than 90% of their active ingredient, meeting the quality standard of containing 90-110% of the labeled amount of active ingredient ([full text pdf](https://sci-hub.ru/10.1080/10903127.2018.1563257))
  - [FAQ on Narcan nasal spray](https://rwjms.rutgers.edu/documents/departments/Psychiatry/Addiction%20Psychiatry/FAQ%20Shelf%20Life%20Extension%20and%20Updated%20Storage%20Conditions%20Final.pdf) states the FDA-approved shelf-life is 36-months

**Should parents have Narcan in their house? Is this something kids should be carrying around with them?**

*If your kids are going to a party, would you tell them to carry Narcan in case something goes wrong with some other kids there?*

- Anthony has mixed feeling about that last question
- He tells parents, “*If you have kids in middle school or above, have Narcan at home somewhere where you can find it under stress*.”
  - We all react differently under stress
  - It’s very important, have Narcan on hand somewhere where you know it’s going to be and you’re able to use it right away
- It may not be your kid that battling whatever, but little Johnny could be spending the night with you that weekend, hanging out with your son or daughter , and you don’t know that he or she’s battling anxiety
  - Maybe their parents are going through a divorce
  - You don’t know if that person is getting bullied, or if they simply need medication to help them sleep
  - And they’ve gotten pills off the street because they’re going to go spend the night at somebody’s house and they’re battling anxiety

> “*It may not be your kid, but if somebody’s spending the night at your house and they start getting poisoned and they start showing signs over an overdose, if you don’t have Narcan on hand, you’re going to feel really bad.*”‒ Anthony Hipolito

**Can Narcan be purchased without a prescription?**

- Yes, you can go to [websites](https://nextdistro.org/naloxone#state-finder) [to find a program in your state that distributes naloxone (generic name for Narcan)]
- It’s becoming more and more available; you can buy it at [Walgreens](https://www.walgreens.com/topic/pharmacy/naloxone.jsp) or [CVS](https://www.cvs.com/content/prescription-drug-abuse/save-a-life)

**Peter’s take away‒** ***we should all go out and buy Narcan, and have it in a kitchen drawer so that under any situation you can access it***

- Think of it like a fire extinguisher; you have one in the house in case one day the grill catches on fire, or there’s an oil fire

**Tell me why you have mixed feelings about kids bringing Narcan to a party, just in case**

- To Anthony, it’s almost like you’re giving permission [to use pills/ drugs]
  - It’s like Narcan is your designated driver
- Peter was thinking of this through the lens of if someone else gets in trouble, he doesn’t want his kids to experience this tragedy that will change their life forever
  - You’re not saying to your kid, it’s okay to take drugs
  - When you watch a video like they did earlier, there are two lives that are lost‒ the kid who died and the kid who watched
- Anthony has mixed feelings about the kid who takes drugs and has his Narcan on the table
  - Who asks a friend, “*Hey, hold my Narcan.*”
- Peter agrees and adds that his mixed feelings aren’t even ethical, they’re practical‒
  - How do you know your buddy’s going to give you the Narcan correctly?
  - How do you know you have enough?
  - You’re really playing with fire in a dangerous way

## Importance of awareness, having conversations with kids early in life, and other key takeaways for parents [56:30]

**Is there anything else parents can be thinking about here?**

- For Peter, there’s a part of him that is a skeptic, thinking, “*Don’t overreact to this. Don’t freak out.*”
  - But you can believe it
- He had a discussion with his eight-year-old, telling him, “*Okay, Reese, if anybody ever gives you candy at school, unless it’s in the wrapper, you don’t eat it.*”
- Peter remembers when he was a kid the panic about never eating apples at Halloween because of razor blades in them
- Now it’s candy fentanyl
- Anthony gets this question all the time right before Halloween, “*Should I let my kids go trick-or-treating?*”
  - What he tells them is, “*Your neighbor is not trying to poison you. Go out and have a good time, let your kid go*”
  - Then he references the ‘80s when he went trick-or-treating and he had to come home and dump out his candy for his parents to inspect
    - Anthony grew up in Texas and Peter grew up in Canada; it’s amazing to think that everybody was putting razor blades in apples (apparently) across the globe, right?
    - It probably happened three times and somehow created a moral panic

**Fentanyl is different from other examples of moral panic**

- When you think of other examples of moral panics, there was prominent one about satanic cults that were killing babies (another weird ‘80s thing)
  - This turned out not to be the case

***Fentanyl is different; this is real; there have been more than 100,000 body bags in the past 12 months***

- It’ll be very interesting to see what the 2022 numbers are
- Anthony keeps waiting for those numbers, and he’s not looking forward to them because he knows they’re going to be scary
  - But they’re real
  - This is not a panic

> “*I’m not trying to scare people when I go and talk to them, I just tell them what I know because it’s real*.”‒ Anthony Hipolito

- It’s not going anywhere
- It’s going to become more and more prevalent
- Unfortunately, we’re going to start seeing stuff that’s stronger than fentanyl because they’re starting to change different structures in the molecule structure to make stuff stronger than fentanyl (different isotopes)
  - Anthony hasn’t seen it in central Texas, but it’s up and down the east coast
- There are variants of fentanyl called [sufentanil](https://en.wikipedia.org/wiki/Sufentanil) and [carfentanil](https://en.wikipedia.org/wiki/Carfentanil)
- Sufentanil is 5-10x as potent as fentanyl
  - Peter was told from somebody on the inside that the single greatest regret of the FDA was that they authorized Sufentanil, because it makes fentanyl look weak
    - It’s opened up an awful Pandora’s box
  - Sufentanil I think is technically a [schedule II drug](https://en.wikipedia.org/wiki/Controlled_Substances_Act#Schedule_II_controlled_substances), meaning it’s highly, highly controlled
  - Medically, it can be used for cancer patients and things like that
- This is why they are trying to create a super Narcan, to try and battle what’s coming

**Is there anything else you want to get across to parents directly or things they can talk about with their kids?**

**Peter’s takeaway‒** ***The most important lesson I take away from this is being very open with your kids***

- He tells his kids they can talk about anything they have a question about it
  - Just talk, he’s not going to give them a legal answer; he’s going to give them a medical answer
  - He’s not going to tell them this is right or wrong
  - This is a no judgment view of the medical answer
- Anthony thinks this is something that probably *not* enough parents are doing
- He has two daughters, and he has seen so much in his 24 years of law enforcement
- He is always upfront with his kids about the world and what he encounters and wh at’s out there on the street
  - He wants them to know what’s going on and how it affects them
  - He doesn’t want to scare them

**Awareness needs to begin early; conversations with your kids are important [1:00:30]**

We need to start in elementary school

- The schools in Hays County have started hanging signs and posters that are age appropriate, talking about pills
  - Talking about fentanyl
  - That conversation is starting at a younger and younger age
- He hasn’t gone into elementary schools to talk to kids, but they talk to the parents at PTA meetings and other public presentation
- Anthony wants parents of elementary school kids to start having those conversations at that age
  - This is where we’ll start seeing the difference
  - The more knowledge they have, the more right decisions they can make
- He doesn’t try to scare people
- High school kids don’t want him to go up on stage and preach to them
- He tries to humanize the badge as much as he can
- He tries to show them he cares about them
  - Because it affects first responders too
  - They go to these calls and can never unhear the moms screaming because their kid’s lifeless on the ground; he can’t unsee that
  - That affects not only officers, but firefighters, paramedics, doctors, that’s stuff that we don’t want to deal with either

***Just start those conversations as much as possible and never not think that your kid won’t do that. Unfortunately, you just have to be nosy.***

- Anthony stresses “*Never believe your kid won’t do it*” because he’s heard it too many times
  - As parents we don’t want to believe what your kid did
- Anthony emphasizes, “***Let’s figure out why****. You know your kid better than anybody. If you start seeing the different signs, their friend groups are changing, the grades start suffering, they’re losing too much weight, they’re gaining too much weight. You know when your kid’s off.*”
- He mentioned his freshman *not* having **social media**
- He gave her social media at too young of age
  - He tried to compare her to his older daughter who was much more mature, and it affected her because she battles anxiety, depression, some other things
- So he took social media media away from her about two months ago
  - Recently, she came up to him and was like, “*Dad, I want to thank you for taking TikTok away from me because I’m so much happier. I didn’t realize how much it affected me.*”
  - All she would do is sit  in her room and scroll and it’s just mindless stuff
  - It holds so much power over your kids

***Anthony’s advice‒ Get to know your kids, and if something is off, say something; start having those conversations***

**Peter’s analogy**

- For Anthony, battling fentanyl has become his life’s mission
- Peter borrows this from the [The Tale of the Starfish](https://www.thestarfishchange.org/starfish-tale)
- Anthony is a guy walking down a beach, and it’s not just him, there are a lot of people doing this
- There are 100,000 starfish washed up on the beach, and Anthony is walking with a guy
- Every few steps, Anthony picks up a starfish and throws it back into the ocean
- The other guy says, “*Anthony, what are you doing?*”
- Anthony replies, “*Well, the tide is out and all these 100,000 starfish on this beach are going to die if they don’t get back in the water*.”
- The guy looks at you funny and says, “*Anthony, you can’t possibly save all these starfish out here. You can’t possibly make a difference.*”
- Anthony picks up another starfish and throws it in and says, “*Made a difference to that one*”

***Peter doesn’t know how many lives Anthony is going to save, but if he saves 100 through his work, that’s 100 lives that are saved. Most people go their whole lives and don’t save a life. Thank you Anthony for what you’re doing.***

§

## Selected Links / Related Material

**Anthony’s presentation at a school board meeting in the Austin area**: [Fentanyl Awareness Presentation](https://youtu.be/QS4R8Ldmeuw) (YouTube January 5, 2023) | [1:15]

**Hays county community outreach program in the Sheriff’s Office**: [HCSO Community Outreach](https://hayscountytx.com/law-enforcement/sheriff/support-services-bureau/community-outreach/) | [4:30, 8:00]

**Video of Kevin McConville’s parents**: [Fentanyl Awareness Presentation from [7:10]](https://youtu.be/QS4R8Ldmeuw?t=430) (YouTube January 5, 2023) | [17:00]

**Hays CISD YouTube channel**: [Fighting Fentanyl series](https://youtube.com/playlist?list=PLjs-_E6R9ZFNBN-mtAGBKQktWfC5T0d1y) (YouTube December 8, 2022) | [17:00]

**Drug overdose deaths through 2021**: [Drug Overdose Deaths in the United States, 2001–2021](https://www.cdc.gov/nchs/products/databriefs/db457.htm#:~:text=The%20number%20of%20drug%20overdose,Vital%20Statistics%20System%2C%20Mortality%20File.) | NCHS Data Brief No. 457, December 2022 (CDC) | [23:30]

**Video of Spencer Wheeler’s dad**: [Fentanyl Awareness Presentation from [43:43]](https://youtu.be/QS4R8Ldmeuw?t=2623) (YouTube January 5, 2023) | [20:45]

**Janelle’s talk about her son Noah Rodriguez**: [Fentanyl Awareness Presentation from [58:51]](https://youtu.be/QS4R8Ldmeuw?t=3531) | [25:30]

**Surveillance video behind the elementary school**: [Fentanyl Awareness Presentation from [18:15]](https://youtu.be/QS4R8Ldmeuw?t=1095) (YouTube December 8, 2022) | [35:45]

**British Columbia decriminalizes personal drug possession**: [Canadian province tries decriminalizing drugs to fight overdose crisis](https://www.reuters.com/world/americas/canadian-province-tries-decriminalizing-drugs-fight-overdose-crisis-2023-01-31/) | Jennifer Gauthier, Reuters (February 1, 2023) | [38:00]

**Emojis being used in conjunction with illegal drugs**: [One Pill Can Kill: Emoji drug code, decoded](https://www.dea.gov/sites/default/files/2021-12/Emoji%20Decoded.pdf) | Drug Enforcement Administration | [50:15]

**Expiration date for Narcan**:

- [Quality Assessment of Expired Naloxone Products from First-Responders’ Supplies](https://www.tandfonline.com/doi/full/10.1080/10903127.2018.1563257?scroll=top&needAccess=true&role=tab) ([full text pdf](https://sci-hub.ru/10.1080/10903127.2018.1563257))| *Prehospital Emergency Care* (S Pruyn et al. 2019) | [53:30]
- [Frequently Asked Questions about NARCAN® (naloxone HCl) Nasal Spray Shelf-Life Extension and Updated Storage Conditions](https://rwjms.rutgers.edu/documents/departments/Psychiatry/Addiction%20Psychiatry/FAQ%20Shelf%20Life%20Extension%20and%20Updated%20Storage%20Conditions%20Final.pdf) | Emergent Biosolutions (2020) | [53:30]

**Find a program in your state that distributes naloxone/ Narcan**: [Reversing an opioid overdose is in your hands](https://nextdistro.org/naloxone#state-finder) | NEXT Distro (2023) | [54:45]

**Fentanyl resource website from Hays County**: [Hays County Fentanyl Resource Page](https://hayscountytx.com/hays-county-fentanyl-resource-page/)

**Fentanyl resource website from Hays School District**: [Hays CISD Fighting Fentanyl](https://www.hayscisd.net/fentanyl)

**Hays county Sheriff Facebook page**: [Hays County Sheriff’s Office](https://www.facebook.com/hayscountysheriffsoffice?mibextid=LQQJ4d)

**Hays county Sheriff’s Office**: [Welcome to the Hays County Sheriff’s Office](https://hayscountytx.com/law-enforcement/sheriff/)

**DEA fact sheet for parents about fake pills**: [What Every Parent and Caregiver Needs to Know About Fake Pills](https://www.dea.gov/sites/default/files/2022-11/DEA-OPCK_Parent%20flyer_V2.pdf) | dea.gov (November 2022)

**FAQ on Naloxone (Narcan)**:

- [Lifesaving Naloxone](https://www.cdc.gov/stopoverdose/naloxone/index.html) | CDC (January 2023)
- [Naloxone DrugFacts](https://nida.nih.gov/publications/drugfacts/naloxone) | National Institute on Drug Abuse (January 2022)

§

![](https://peterattiamd.com/wp-content/uploads/2023/02/bio-image-anthonyhipolito-500x500.png)

##### Anthony Hipolito

Anthony Hipolitoa is a lifelong resident of Hays County. He worked at the Austin Police Department for 23 years, where he rose to the rank of Sergeant before retiring in July 2021. A few months later he joined the Hays County Sheriff’s Office. He is currently assigned to the Community Outreach Unit.

Twitter: [@Anthony\_Hip](https://twitter.com/Anthony_Hip)