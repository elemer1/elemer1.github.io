# #203 – AMA #34: What Causes Heart Disease?

**Source:** [https://peterattiamd.com/ama34/](https://peterattiamd.com/ama34/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into the topic of [atherosclerotic cardiovascular disease (ASCVD)](https://peterattiamd.com/category/diseases/heart-disease-prevention/)—the number one killer in the developed world. Peter argues for the importance of paying attention to and understanding ASCVD given its ubiquity and inevitability. He goes into great detail about the development of atherosclerosis and how it can take hold at a very early age, the role of cholesterol, and the causal factors of ASCVD that determine prevention strategies. Additionally, he discusses the important metrics and biomarkers found in blood work, as well as diagnostic tests such as coronary artery calcium scores (CAC) and CT angiograms which help to determine the level of arterial damage present. Finally, Peter lays out the keys to understanding and interpreting calcium scores before wrapping up the conversation with his key takeaways regarding prevention.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #34 show notes page](https://peterattiamd.com/ama34). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The importance of understanding atherosclerosis early in life [2:15];
- Defining atherosclerotic cardiovascular disease (ASCVD), its causes, and the role of cholesterol [9:00];
- The process of developing ASCVD, part 1 [15:00];
- The process of developing ASCVD, part 2 [24:00];
- The process of developing ASCVD, part 3 [32:45];
- How early in life ASCVD can start to develop [40:30];
- Case studies of atherosclerosis and figures showing real pathology [43:00];
- Coronary artery lesions present in autopsies of different age groups [49:15];
- The causal factors of ASCVD that determine prevention strategies [52:15];
- Labs to identify biomarkers of ASCVD [59:00];
- Diagnostic tests to determine the level of arterial damage present—CAC, CTA, CIMT, and more [1:00:30]
- Calcium scores: keys to understanding and interpreting a CAC score and/or CTA results [1:05:15];
- Is there a risk from cholesterol levels being too low? [1:13:00];
- Key takeaways regarding prevention [1:15:45];
- More.

§

The Peter Attia Drive

What Causes Heart Disease?

§

## Show Notes

§

## The importance of understanding atherosclerosis early in life [2:15]

**Atherosclerosis is ubiquitous**

- It’s the only disease that is inevitable, and it limits human longevity
- Cancer and dementia, also diseases of old age are not inevitable the way atherosclerosis is

> “*Not everybody dies from atherosclerosis, but… everybody dies with it*”— Peter Attia

- You want to understand this because the impact is huge and the tools we have are also huge
- Extending lifespan comes down to delaying the onset of chronic disease, and atherosclerosis is the most common chronic disease

**2 main paths to atherosclerosis**

*Risk factors*

- Smoking, a behavioral risk factor (we’ll put this aside for the moment)
- 1 – Hypertension
- 2 – High blood and lipid abnormalities (we’ll focus on this one)
  - This leads to atherosclerotic cardiovascular disease (ASCVD)

**Studies of pathology show ASCVD begins at a young age**

*What is the most common presentation for a 1st heart attack?*

- Sudden death
- A 1st heart attack in over 50% of people is fatal; today this number is a little less but still staggering

*What is the age distribution of people who have their 1st major adverse cardiac event?*

- Adverse cardiac events are a heart attack or a stroke (or death)
- Figure 1 shows the incidence of cardiovascular events for both males and females in the US

![](https://peterattiamd.com/wp-content/uploads/2022/04/f1-ama34-1024x248.png)

**Figure 1.**  Incidence of cardiovascular events by age and sex.  Credit [*JAMA Cardiology* 2016](https://jamanetwork.com/journals/jamacardiology/fullarticle/2523465)

- The graph on the right shows total annual events
  - The 1st 2 sets of bars show the number of events for people under 65
  - Men are shown in the darker bars comprising slightly below 25% and slightly above 25% of all cardiac events
    - The implication is that **50% of men who are going to have a cardiac event in their life will have it before the age of 65**
  - For women, **a third of women will have their 1st cardiac event before the age of 65**
- The total annual events is not the whole story; it’s important to understand how long it takes for this disease to take hold
  - Early prevention is key
- Almost 25% of these events are in men younger than 54
- When you think of someone who is 45, 50, this disease didn’t start 2 years before

*When you see these stats laid out, it creates a shift in your mind around why you should care about this*

## Defining atherosclerotic cardiovascular disease (ASCVD), its causes, and the role of cholesterol [9:00]

*ASCVD is disease state characterized by the deposition or the buildup of cholesterol (sterols) in the artery wall*

- It begins with a fatty streak that later consolidates into plaques that can ultimately lead to a reduction in blood flow
- Reduction in blood flow is called **ischemia**
- Ischemia results in tissue damage to the heart and this is what results in a **heart attack**
- A heart attack can be fatal depending on the amount of cardiac tissue that is damaged from loss of oxygenation

**Causes of ASCVD**

- You *don’t* have to be obese or have high blood pressure

> “*It’s really a question of the cholesterol in your blood. That’s really what defines the disease.*”— Peter Attia

- Atherosclerosis is defined by the presence of cholesterol in the artery wall
  - This is not necessarily related to the measurement of cholesterol in circulation
- Patients with cholesterol in their arteries do *not* necessarily have to have co-aggravating factors such as: high blood pressure, diabetes, obesity, family history, smoking
  - All these things that exacerbate ASCVD

**Cholesterol explained**

- Cholesterol is an organic molecule, a type of lipid
  - It is not soluble in water
  - It is a hydrophobic molecule
  - Picture pouring oil into water and you would immediately see what it means to have a hydrophobic substance in contact with something that is hydrophilic (water)
    - They repel each other

*Cholesterol is about one of the most important molecules in the body*

- You would die without it
- Rare genetic conditions that impair the ability to make cholesterol are fatal
- Cholesterol is used for 2 main things:
- 1 – The cell membrane of every cell in the body contains cholesterol
  - Cholesterol contributes to the fluidity of the cell membrane, important for membrane channels that allow things in and out of the cell
- 2 – Synthesis of many hormones begins with cholesterol, including: cortisol, estrogen, testosterone
  - It is also essential for the creation of bile acids, necessary to digest food

**Where does cholesterol come from?**

- Most people think of cholesterol as something that comes from eating certain foods
  - This is true, eggs contain cholesterol
- *But the cholesterol in your bloodstream has little to do with the cholesterol in foods you eat*
  - The reason is, the cholesterol we eat in esterified, it has a chemical bond that swings between an intermediary oxygen and another side chain
  - This cholesterol is too large for the receptors in our gut to absorb
  - Most of the cholesterol we eat is excreted

*Most of the cholesterol we will discuss [in our bloodstream] is made in our body and transported between cells through lipoproteins*

## The process of developing ASCVD, part 1 [15:00]

**Anatomy of blood vessels**

- The **endothelium** is a 1-cell layer that lines the surface (and protects) the arterial lumen
  - The **arterial lumen** is the inside of a blood vessel; this is the area through which blood is flowing
- The endothelium has really complex functions
  - It can modulate vascular tone
  - Remember arteries don’t stay in the same shape all the time; they can constrict a bit and dilate
  - This plays an important role in modulating inflammatory and thrombotic processes
- Tom Dayspring provided these images of blood vessels and the process of ASCVD

**Figure 2 shows a small artery cut along its length; think about a coronary artery**

- The red part in the middle is where the blood flows along the length of the artery

![](https://peterattiamd.com/wp-content/uploads/2022/04/f2-ama34-1024x769.png)

**Figure 2.**  Endothelial cells lining a blood vessel.

- The coronary artery, depending on which one
  - If it’s the left main versus a distal part of the left anterior descending coronary artery
    - Wikipedia has a good [image of the coronary arteries](https://en.wikipedia.org/wiki/Left_coronary_artery#/media/File:Coronary_arteries.svg)
  - It may be a small as 1 mm (in diameter) or it could be as large as 4 mm
- There is a **single layer of endothelial cells** lining the entire surface of this artery
  - These are the tan ovals in contact with the red bloodstream
- Also shown is what’s behind these endothelial cells, the other layers of the artery wall
- Unlike veins, arteries have very muscular walls
  - The **muscle cells** are shown as elongated cells with a dot in the center, in Figure 3

![](https://peterattiamd.com/wp-content/uploads/2022/04/f3-ama34-1024x772.png)

**Figure 3.** The muscular walls of arteries and LDL particles flowing in the bloodstream.

**LDL**

- Figure 3 also shows LDL, the low density lipoprotein
  - These are the multicolored balls in the bloodstream
  - LDL is a lipid transport particle
- Remember that oil and water don’t mix well; we have the same problem with cholesterol in blood
- Cholesterol is essential for every cell
  - Cells make cholesterol but not every cell can make enough to meet its own needs
- Transportation in the blood is akin to transportation in water
  - With water soluble things this is easy, like glucose or electrolytes (sodium, potassium, etc)
  - Hydrophobic molecules are different, like cholesterol and triglycerides (fats)
    - These molecules have to be transported in something that is water soluble
    - That something is a **lipoprotein**
- Lipoproteins exist in different densities
  - The 2 most people will have heard of is the low density variant (**LDL**) and the high density variant (**HDL**)
  - It’s unfortunate that these are called bad cholesterol (LDL) and good cholesterol (HDL) because they both carry the same cholesterol
- Technically, there is no such thing as good cholesterol or bad cholesterol; it’s just cholesterol
- Cholesterol does bad things when it is in a low density lipoprotein; this is why LDL got the name bad cholesterol
- LDL’s zip through the bloodstream
- Notice the little black line on the LDL in Figure 3; it looks like a mustache
  - These are apolipoprotein Bs (**apoB**)
- Broadly speaking, there are 2 families of these apolipoprotein lipoproteins.
  - 1 – The apoA family
    - This family encompasses all the different HDLs (multiple)
  - 2 – The apoB family
    - apoB100 – This family encompasses VLDL, IDL, LDL, and Lp(a), which is an LDL with another apolipoprotein called apo(a) attached to it
    - apoB48 – attached to chylomicrons

*The apoB carrying lipoproteins are the ones we’re interested for this process, and of those LDL is the most important for virtually everybody*

 **What is the concentration of LDL?**

- When you’re young, it’s quite low, 20-30 mg/dL of LDL in blood
  - This LDL is simply delivering cholesterol to and from tissues that need it
- LDL-C is the concentration of cholesterol within 1 particle, reported in mg/dL
- LDL-P refers to the number of LDL particles, typically  reported in nmol/L
- ApoB also refers to the number of LDL particles, reported in mg/dL

**What measure should you pay attention to?**

- ApoB, the [podcast with Allan Sniderman](https://peterattiamd.com/allansniderman/) went into detail about this

![](https://peterattiamd.com/wp-content/uploads/2022/04/f4-ama34-1024x763.png)

**Figure 4.**  Some LDLs have moved into the subendothelial space.

- Figure 4 show that some LDLs have escaped from the vascular system and have gone into what’s called the subendothelial space, the space just behind the endothelium
  - LDLs are slipping through the cracks in the endothelium
  - One of the risk factors for atherosclerosis is the health of the endothelium
    - *The dominant risk factor is the lipid concentration*

**Things that are damaging to the endothelium lining blood vessels**

- Uric acid, discussed in the [podcast with Rick Johnson](https://peterattiamd.com/rickjohnson2/)
- Hyperinsulinemia
- Elevated glucose levels
- Homocysteine

*Anything that damages the endothelium is going to increase the likelihood that these LDLs can sneak their way through*

- Once the LDL has moved past the endothelium, there’s a reasonable chance they will get stuck there
  - LDL binds to proteoglycans (green y’s on Figure 4) via surface phospholipids
  - Chemical reactions can occur with reactive oxygen species that will then oxidize the LDL
    - This doesn’t happen to all the LDL particles
- HDL particles will also enter this space from time to time
  - The difference is the HDLs leave; they don’t get stuck in the subendothelial space

**Peter’s takeaway— retention of LDL in the subendothelial space and its oxidation is the problem and the 1st critical step in ASCVD**

## The process of developing ASCVD, part 2 [24:00]

![](https://peterattiamd.com/wp-content/uploads/2022/04/f5-ama34-1024x775.png)

**Figure 5.**  *LDL particles retained in the subendothelial space can be modified or oxidized to become toxic*

- The endothelial system reacts in an effort to prevent further damage
- **The paradox is, the efforts by the endothelium to heal itself is what ultimately kicks off a cascade of events that result in more damage**
- The endothelium is now dysfunctional and expresses something called selectins and vascular cell adhesion molecules
  - These are like a 911 call to immune cells, asking them to come and repair the damage
  - Figure 6 shows dysfunctional endothelial cells in blue expressing selectins and adhesion molecules

![](https://peterattiamd.com/wp-content/uploads/2022/04/f6-ama34-1024x774.png)

**Figure 6.** Endothelial cells become dysfunctional and express selections and adhesion molecules.

- Monocytes, a type of immune cell patrolling in the bloodstream, respond to the damaged endothelium
- Figure 7 shows monocytes as yellow cells with a big, blue squiggle inside

![](https://peterattiamd.com/wp-content/uploads/2022/04/f7-ama34-1024x769.png)

**Figure 7.**  Monocytes are a type of immune cell recruited to the damaged endothelium.

- Monocytes are type of cell that is not fully differentiated
  - They are looking for anything that’s gone wrong in the body
- The little blue hairs coming out of the dysfunctional endothelial cells are **vascular adhesion molecules**
  - This will catch monocytes moving through the bloodstream
  - These adhesion molecules increase the probability that monocytes are going to stop at this site and enter the subendothelial space

*Cytokines elicit a systemic response to endothelial damage*

- These dysfunctional endothelial cells also release cytokines
  - Shown in figure 8
  - **Cytokines** are a chemical signal that goes out to the body
  - They elicit inflammation
  - They initiate a systemic response to injury
  - Examples include interleukin-6 (IL-6) and tumor necrosis factor (TNF)

![](https://peterattiamd.com/wp-content/uploads/2022/04/f8-ama34-1024x770.png)

**Figure 8.**  Damaged endothelial cells release Interleukin-6 and other cytokines

- Cytokines circulate to the liver where they induce the production of **C-reactive protein (CRP)**

*We can measure all of these things, and that gives us some sense of the amount of inflammation going on*

- Cytokines and C-reactive protein are not cardiovascular specific
  - They will also be elevated in a person who has an infection (even a cold)
  - A person with a cold may have a C-reactive protein of 6-7, when the normal level is 1

**The action of monocytes in the subendothelial space is part of the disease process**

- Monocytes enter the subendothelial space (figure 9) and mature to become macrophages
  - Macro meaning big and phage meaning to eat

![](https://peterattiamd.com/wp-content/uploads/2022/04/f9-ama34-1024x772.png)

**Figure 9.**  After stopping at adhesion molecules on damaged endothelium, monocytes enter the subendothelial space.

- Macrophages start to ingest the modified / oxidized LDL particles
  - The term for this is **phagocytosis**
  - Shown in figure 10

![](https://peterattiamd.com/wp-content/uploads/2022/04/f10-ama34-1024x769.png)

**Figure 10.**  Monocytes ingest oxidized LDL particles

- Eating these oxidized LDL causes the macrophages to become **foam cells**

*In all of this is the body doing what it thinks it should be doing to fix a problem. This same thing occurs when you have a bacterial infection and it’s what saves your life. But here, as you can see, it’s starting to become counterproductive.*

**The development of pathology in the artery**

- When a lot of these foam cells coalesce, it starts to form something called a **fatty streak**
  - Shown in figure 11
  - We’ll come back to this later and look at actual slides from autopsies

![](https://peterattiamd.com/wp-content/uploads/2022/04/f11-ama34-1024x769.png)

**Figure 11.**  A fatty streak is formed by the accumulation of enlarged foam cells.

**The role of HDL**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f12-ama34-1024x771.png)

**Figure 12.**  HDL use ABC1 to remove cholesterol from macrophages.

- Remember earlier we mentioned 2 families of lipoproteins: apoB and apoA
- apoA-1 particles are also known as **pre-beta-HDL particles**
  - These take in free/ unesterified cholesterol from macrophages using something called an **ATP binding cassette transporter, A-1 (ABC1)**
  - This means these pre-HDL particles use a suction system to suck sterol [cholesterol] out of the macrophages
    - The ATP binding cassette transporter, A-1 uses the energy of ATP to do move cholesterol from the macrophages to the pre-HDL particles
    - This is an effort to prevent further damage
    - This is why HDL is thought of as good
- Pre-beta-HDL particles will fill themselves up with lipids, that they remove from macrophages
  - This particle gets bigger
  - The HDL will take the lipids to other tissues in the body that need them
  - Shown in figure 13

*HDL removes lipids from the worst place you can have them and take them elsewhere in the body where they can be used*

![](https://peterattiamd.com/wp-content/uploads/2022/04/f13-ama34-1024x770.png)

**Figure 13.**  HDL particles filled with lipids from the subendothelial space go back into the bloodstream to deliver these lipids to other tissues.

- This is why HDL is thought of as being protective
- This de-lipidation process occurs through lots of mechanisms using something called **cholesteryl ester transfer protein (CETP)**
  - Notice 2 things:
  - 1 – *An entire set of drugs has been developed around CETP inhibition*
  - 2 – *CETP genes are some of the genes that are modified in people who live an exceptionally long time, centenarians*

## The process of developing ASCVD, part 3 [32:45]

**Quick aside on the misconceptions about HDL cholesterol**

*It’s overly simplistic (and patently wrong) to think that HDL is good cholesterol and LDL is bad cholesterol*

- You can’t infer anything about risk from a high level of HDL cholesterol
- Every intervention that has tried to raise HDL cholesterol pharmacologically has failed to improve outcomes
  - *This speaks to the complexity of this process*

**How HDL works is complex:** The functionality of the HDL particle is much more complicated than something we can assess through either their size, their number, or their cholesterol content

**Back to the macrophages:**

- The HDLs fix some of the lipids macrophages have taken in, but in the end the macrophages become more and more engorged with oxidized LDL
- The macrophages remain as full-fledged foam cells
- Foam cells produce a whole bunch of things: angiotensin II, collagenase collagenases, elastases, and a whole bunch of other enzymes (shown in figure 14)
  - **This undermine the integrity of the arterial wall leading to more endothelial dysfunction**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f14-ama34-1024x771.png)

**Figure 14.**  As foam cells enlarge they release many molecules that contribute to dysfunction of the endothelium.

> “*Everything that’s happened so far is like little break-ins in the neighborhood. We’re about to enter looting.*”— Peter Attia

**What happens after foam cells accumulate?**

- Chemical signals start to trigger the migration of smooth muscle cells to the area of the injury
- The endothelium barrier is badly damaged and has lost its capacity to do anything
- Smooth muscle cells try to repair the damage by laying down a matrix to heal the injured wall
- This matrix becomes the fibrous cap of the **atherosclerotic plaque**, shown in figure 15

![](https://peterattiamd.com/wp-content/uploads/2022/04/f15-ama34-1024x770.png)

**Figure 15.**  The formation of atherosclerotic plaque.

- It is only now that **the lumen of the artery begins to narrow**

*This is pretty bad but it’s occurring before there is any calcification and before the artery wall is actually shrinking.  Nothing is showing up clinically so far.*

- So much has to happen, years and years before you can start to see damage
  - And it’s the damage that leads to events
- By the time you’re having events, **the process covered so far has happened decades earlier**

**Action of enzymes released by recruited muscle cells**

- These enzymes that are upregulated start to dissolve and weaken the plaque cap
- This typically occurs at the shoulder regions where the diseased endothelium cells meet healthy endothelial cells
  - Some describe this area of plaque as vulnerable
    - This may be a correct term
    - But it also gives kind of a false sense of confidence that we can treat atherosclerosis on a lesion by lesion basis

> “*Atherosclerosis should really be viewed as a systemic condition of the entire arterial system*”— Peter Attia

One of the better papers on this topic is called “[*The Myth of the “Vulnerable Plaque*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4344871/)*”*

**Continuing with the disease process, after plaque has formed in the arteries**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f16-ama34-1024x770.png)

**Figure 16.**  Plaque accumulates at large foam cells and starts to obstruct the artery.

- Smooth muscle cells have migrated to the place of damage
- The damage is greatest at the site of these large foam cells [the green blobs filled with yellow circles]
  - This is incredibly inflammatory
- The **endothelial barrier is very dysfunctional** and is barely holding on for dear life
- Now this **plaque can start to become obstructive** [shown as yellow rectangles]
  - This is how the artery narrows
- Lipid rich plaques can become quite unstable and they can **rupture**, causing really bad things to happen
- In figure 17, the plaque at the bottom is unstable
  - Some lipid is protruding through the cap [yellow balls]
  - If this lipid gets out, it will kick off a **coagulation cascade**
    - Platelets will show up
    - Platelets are in the blood; their job is to stop bleeding if we have an injury

![](https://peterattiamd.com/wp-content/uploads/2022/04/f17-ama34-1024x774.png)

**Figure 17.**  The escape of lipids from plaque activates the coagulation cascade.

- Platelets serve as a kind of cradle for the coagulation cascade to produce a net of fibrin [white blobs]
  - Shown as white blobs in figure 18
  - This leads to a clot
  - Red blood cells are caught in this net

![](https://peterattiamd.com/wp-content/uploads/2022/04/f18-ama34-1024x770.png)

**Figure 18.**  Activation of the clotting cascade leads to an occlusion of blood flow.

- A nonobstructive plaque can lead to a clinical event after the superimposition of red and white **thrombus**
  - This can happen very quickly
  - This is typically the cause of a heart attack
- A **heart attack** does not occur because the lumen narrowed little by little
  - Typically there was some narrowing
  - But it’s the rupture of a plaque that leads to the **sudden occlusion of blood flow**

*That’s why going back to what my pathology professor talked about 25 years ago, a very, very common presentation is sudden death. Those people don’t get a warning. They don’t get to say, “Oh god, I’m really having chest pain walking up the stairs today because I’m slowly losing blood supply to my heart*.”

- People go from being fine to dead if that occlusion occurs in a place where restriction of blood flow is fatal
  - If it occurs at a very distal point in the blood supply, then it might not cause a fatal heart attack
  - If it occurs high enough, it can be a “Widowmaker”

*A Widowmaker lesion is very, very high in the left main coronary artery. At such a level, if you occlude blood flow, you’re basically robbing the entire left ventricle of blood, which would be, universally fatal*.

## How early in life ASCVD can start to develop [40:30]

*3 big points to remember*

- 1 – The number of particles in the blood is important
- 2 – You want your endothelium to be as healthy as possible
- 3 – This takes a very long time to develop

**How early is this happening? Is this happening at five, 10, 15, 20, 30 years old?**

- If we’re talking about apoB bearing particles (LDL particles), entering the subendothelial space, getting retained, getting oxidized
  - This happens very early in life for some individuals
  - There are studies that demonstrate that this actually starts *in utero* where the fetus can be exposed to the mother’s lipoproteins
- Clinically we would say that this disease manifests during the 4th-6th decades of life
  - That means it begins when someone is in their 30s, 40s or 50s
- We typically see a full decade difference between men and women
  - This is something where women have a distinct advantage
    - That’s not true for other diseases; for Alzheimer’s disease women ar at a distinct disadvantage

> “*I think it’s safe to say that if you do an autopsy on most men who die from some other reason in their 30s, you will find evidence of significant atherosclerosis*”— Peter Attia

## Case studies of atherosclerosis and figures showing real pathology [43:00]

These pictures are actual pathology slides from one of Peter’s favorite books, which Allan Sniderman gave him his first copy— the [*Atlas of Atherosclerosis Progression and Regression*](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1) by Herbert Stary

- Herbert Stary is a pathologist who has devoted his career to understanding atherosclerosis through the lens of autopsies
- Below are a series of cross-sections
  - Recall the earlier figures were viewing the artery cut the long way
  - Most people think of cutting an artery in a cross-section
- The lumen should be perfectly patent, meaning perfectly open (shown in figure 19)

![](https://peterattiamd.com/wp-content/uploads/2022/04/f19-ama34.png)

**Figure 19.**  The pro part of the left anterior descending artery from a 29-year old female homicide victim. [[source](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)]

**Part of this artery is normal and part is in the early stages of atherosclerosis**

- Figure 19 was taken from the pro (or close part) of the left anterior descending artery
  - This was taken from a 29 year old female homicide victim
  - [Wikipedia](https://en.wikipedia.org/wiki/Left_coronary_artery) has a simple [diagram of the anatomy of the left coronary artery](https://en.wikipedia.org/wiki/Left_coronary_artery#/media/File:Coronary_arteries.svg)
- **Normal** is shown at the top and bottom of figure 19
  - The endothelium is a tiny cell layer that you can barely see on the closest side to the lumen
  - Then you get into the intima, the adventitia, and the muscular wall at the very outer side

*We’re not going to get too much into the types of lesions because the nomenclature has changed since this book was written, but we’ll list how they were labeled for comparison*

- Figure 19 was referred to as **type II lesion**
  - In the middle area, proximal LAD [left anterior descending branch of the coronary artery], foam cells are accumulating and they’ve led to **intimal thickening**
  - The darker rim in the thickened part is behind the [intima](https://en.wikipedia.org/wiki/Tunica_intima)
    - This is how we know these are foam cells in the intima that have lead to its thickening
  - This woman would not have any symptoms even though this is in her LAD (a very important artery in the heart)
  - The narrowing of the lumen is not clinically relevant
  - This also would *not* show up on a calcium score (we’ll come back to this metric later)

*Intimal thickening is an early sign of atherosclerosis*

**Figure 20 shows a more advanced lesion (type IV)**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f20-ama34.png)

**Figure 20.**  The proximal, middle left anterior descending artery of a 23-year old male  homicide victim. [[source](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)]

- This was a type IV lesion in the proximal, middle left anterior descending, artery of a 23-year old male victim of homicide

*Why is this a more advanced lesion?*

- There is an **enormous lipid core disrupting the musculoelastic layer** above the media layer
- This is now in a deeper part of the artery wall than the previous one
- Notice where it says “fo”, there are **foam cells and macrophages**, but there’s no increase yet in the smooth muscle or the collagen fiber
- This is still an early lesion
- The luminal narrowing is not clinically significant
- The patient would not experience any chest pain or any distress under any circumstance

**Figure 21 shows another type IV lesion**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f21-ama34.png)

**Figure 21.**  The left main coronary artery from a 19-year old male suicide victim. [[source](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)]

- This is the left main coronary artery, the most important artery in the body
- In this case, the extracellular lipid and even the cholesterol in there has been crystallized
- This is a particularly worrisome sign when you start to see **this type of crystallization in the lipid core, because this is even more inflammatory**
  - This is probably more likely to elicit an immune response
- This is in a 19-year old

**Figure 22 shows a type V lesion**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f22-ama34.png)

**Figure 22.** [[source](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)]

- This is a type V lesion in the proximal (so the upper part of the left anterior descending) artery of a 38-year old male accident victim
- This is a much more advanced lesion
- The **lipid core extends** into the media
- Parts of the media and the adventitia (that’s the back most layer) **contain macrophages and lymphocytes** [inflammatory cells]
- There’s already **fibrous tissue in the intima** beyond what is normal
  - That means the intimal layer is starting to thicken with smooth muscle

*If Peter had a crystal ball, and if this person didn’t die in a car accident— would they live to age 65?*

- Probably not
- Still, at age 38 they would be completely asymptomatic
- Their calcium score would be normal

**Figure 23 shows a complete cross section of the artery; some is normal and some is not**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f23-ama34-1024x877.png)

**Figure 23.**  Cross section of the proximal LAD from a 24-year old man who died suddenly. [[source](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)]

- This is a cross section of the proximal, so the upper LAD, left anterior descending artery
  - If you get a blockage here, you’re dead
- This is from a 24-year old man who died suddenly with no clear explanation, even after autopsy (a rare occurrence)
  - Based on the autopsy, it it doesn’t look like he died of a heart attack
- This is a type IV lesion that was 1.5 cm long
  - It starts about a centimeter before the bifurcation of the LAD in the circ
    - This means it’s a very high lesion
- In the middle position here, you can see the full atheroma, so you can see the full core of lipid
- And at the upper and lower edge of the lesions was also something called the type III lesion

## Coronary artery lesions present in autopsies of different age groups [49:15]

**Figure 24 is a graph from Stary’s book**

- The nomenclature is not that helpful because we don’t refer to them as type I’s, II’s, III’s, and IV’s anymore

*The graph is still relevant because it shows the age prevalence of these types of lesions*

![](https://peterattiamd.com/wp-content/uploads/2022/04/f24-ama34-1024x640.png)

**Figure 24.**  Types of coronary artery lesions present in autopsies of different age groups. [[source](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)]

- Nobody has preatheromas or advanced lesions up until age 11
  - These are types III, IV, and V
- After age 11, the graph starts to steadily climb
- **By age 40, 70% of people have these types of lesion**s (types III, IV, and V)
  - He looked at nearly 700 autopsies per age group
  - This is staggering

> “*If we do this today, it’s going to look a little bit better*”— Peter Attia

- This was done 10-15 years ago in soldiers coming home from Afghanistan
- Incidence of these things would shift a bit today due to 2 things
  - 1 – Fewer people smoke today
    - Smoking exacerbates this
  - 2 – People generally have better control of lipids
    - There is more use of lipid lowering medication today
    - That probably plays less of a role in people under 40

## The causal factors of ASCVD that determine prevention strategies [52:15]

*When thinking about prevention, start with what causes this disease*

- Cholesterol causes this disease
- Other things play a causal role
  - Hypertension
  - Smoking
  - Metabolic health
    - Metabolic health is perhaps the most important, subtle thing that is not appreciated here

**You want to manage lipids to prevent ASCVD**

*Typical cholesterol panels*

- The bare bones panel is going to be a total cholesterol, an LDL cholesterol, an HDL cholesterol, and a triglyceride (TG)

> “*I’d rather know your eye color than your total cholesterol*”— Peter Attia

- **Total cholesterol** includes all the lipoproteins in your bloodstream
  - The total concentration of cholesterol contained in the : LDL + HDL + VLDL + Lp(a)
  - There really aren’t any IDLs; they don’t stick around very long

*Hypothetical total cholesterol = 250 mg/dL*

- **LDL cholesterol** is the cholesterol content within the LDL cholesterol particles
- **HDL cholesterol** is the concentration cholesterol in the HDL particles
- **Triglycerides** are the storage forms of fat that reside within those lipoproteins
  - So that LDL and the VLDL (which we didn’t talk about here, because that’s typically not showing up in a standard lipid panel) will also include triglyceride
  - Triglycerides can also be found in albumin, which is another binding protein

*Peter’s tip— make sure you’re getting an LDL that is direct, not indirect*

- Formulas are used to calculate LDL in low-bar labs
- ut you want to use a lab that is doing a direct measure
- The result will always say that it’s direct or indirect
  - So just makes sure you’re getting a direct LDL
- You should go one step further and measure **VLDL cholesterol**
  - This will allow for a non-HDL cholesterol
  - A **non-HDL cholesterol** is the sum of all the cholesterol minus the HDL
    - That’s basically the LDL cholesterol + VLDL cholesterol
    - Non-HDL cholesterol is always going to be more than LDL cholesterol
- Understand that the cholesterol in each particle (LDL, HDL, etc) is all the same cholesterol
- The amount of cholesterol within the HDL particle is a very crude metric that provides little indication of the functionality of the HDL

*HDLs are very important and they do really amazing things to help you reduce your risk of atherosclerosis. The problem is measuring how much cholesterol is in them doesn’t tell you if they’re doing their job well.*

**apoB**

- The [podcast with Allan Sniderman](https://peterattiamd.com/allansniderman/) went into great detail about apoB and why it’s important
  - This is a great episode to flag for watching later
  - Peter’s not going to attempt to do justice to explaining its importance

*Think back to figure 3, showing a cartoon of the endothelial layer in the artery and the LDL flowing in the bloodstream.  What determines the probability that one of those LDLs kicks off this whole miserable thing by entering the subendothelial space, getting retained, getting oxidized, etc?*

- It turns out to be stochastic
  - The **particle concentration [LDL]** is what determines this probability
  - The more particles you have, the more likely it is that particles will go and enter the subendothelial space
- This is unambiguously clear from not just the Mendelian randomization, but also genetic evaluations
  - When you look at people who genetically have no other difference from the rest of us, except that they are unable to make much cholesterol, or they genetically clear LDL particles out of circulation in their liver at a dramatic rate, such that their LDL concentration is very low, they simply don’t get heart disease
  - There are people walking around who genetically have LDL cholesterol levels of 10 to 20 milligrams per deciliter— this is the level of an infant
    - These people don’t get heart disease

> “*That goes through the causal relationship of LDL to this*”— Peter Attia

- It’s not the amount of cholesterol within the LDL that’s a great predictor of the risk
- **It’s the number of LDL particles (and atherogenic particles in general) that’s a good predictor of risk**

*Nothing captures that better than apoB*

- Even though LDL is the dominant player here, there are also VLDL remnants
  - These are VLDL particles that stick around way too long
- There are Lp(a) particles
  - In Peter’s practice, **apoB is the most important metric they look at to predict risk** (though not the only marker)

## Labs to identify biomarkers of ASCVD ]59:00]

- **The full lipid panel**— he always wants to see the non-HDL cholesterol
- **Lp(a)** (measured at least once)
  - If it’s elevated, he might look again, depending on certain interventions
- **apoB**
- ***APOE*** **(genotype)**
  - apoB and *APOE*  are largely unrelated for the purpose of this

*These measures tell about the risk but not how much atherosclerosis is currently present*

- There are not great biomarkers for assessing how much atherosclerosis is present
- The biomarkers for predicting risk are useful so we can lower risk by reducing them
- Additional measurements factor into how risk is managed:
  - **Homocysteine**
  - **Uric acid**
  - **Thyroid function**
  - **Iron**
  - **Ferritin**
- Realize these are biomarkers; he still looks at metabolic health with biomarkers and non-biomarkers
  - He’s aggressive in monitoring blood pressure
    - Even slight elevations of blood pressure are important
    - A lot of this can be treated through changes in behavior

## Diagnostic tests to determine the level of arterial damage present—CAC, CTA, CIMT, and more [1:00:30]

**What diagnostics can capture the level of damage currently present in the arteries?**

- The pathology slides discussed earlier show different levels of damage
- Biomarkers won’t differentiate this

*The 2 most important things we can look at are:*

- 1 – Coronary artery calcium (CAC) score
- 2 – A CT angiogram (CTA)

 **Calcium score (CAC)**

- This is done by doing a very quick CT scan of the heart without any intravenous contrast
- It looks at the amount of calcification in the coronary arteries
  - This is very late in the disease process
- Once you have calcium formation around coronary arteries you’re at the 2nd to last stage of atherosclerosis
  - It’s a late stage of healing
  - Calcium formation is a very advanced finding of disease but it doesn’t tell you much about what’s happening at the point of calcification
- Just yesterday, Peter got a patient’s calcium score back and it was not a very high number, but it wasn’t 0
  - That’s already a big red flag
  - It was at one part of their heart, but that doesn’t really tell much
  - The fact that they have a score of, say 15 at one part of their left anterior descending really means nothing about what’s happening there
  - But that becomes a real global alarm given that person’s age (early 40s)
  - Further, if they have a calcified point right there, they undoubtedly have atherosclerosis elsewhere

**The CT angiogram (CTA) is a much better test**

- But it comes at a higher cost and it comes with more radiation
  - At really good places, it should be in the ballpark of 2 millisieverts of radiation
    - That’s a very small dose of radiation, about 4% of your annual allotted radiation, according to the NRC
- A CT scan of the heart (this one is with contrast) captures the calcification
  - They typically run a dry scan first to look for calcium
  - But then once the contrast is in, you can see with great illumination the arteries
  - This gives a better sense of the luminal narrowing and the presence of soft plaque

*Really, the CAC and the CTA are a very important thing that we use also in risk prediction, especially if the patient is themselves on the fence about preventative measures*

**How can CIMT (carotid intima media thickness) be helpful in understanding ASCVD?**

- CIMT is an ultrasound that’s done of the carotid arteries in the neck
- *Peter finds this to be a completely unhelpful test for a couple of reasons:*
  - 1 – It is so user dependent in terms of the operator
  - The operator needs amazing technical skill to get a really good look at those carotid arteries
  - 2 – If you will want to see a change in this, you pretty much have to have the same person doing it again and again.
- This might be that this is helpful if you have major, major carotid stenosis
  - Evenstill, Peter would still prefer to to a CTA in this situation
- There are no guidelines that are based on a CIMT
- People look to this test because it has no radiation, but the CAC has virtually no radiation

> “*I don’t see an advantage of CIMT over CAC*”— Peter Attia

- Interpreting results of CIMT can be confusing
- A negative CIMT doesn’t tell much; it’s easy to miss things here
- Obviously if there is a lot disease in the carotid artery, the CIMT will show it

*Peter prefers a CAC over a CIMT*

## Calcium scores: keys to understanding and interpreting a CAC score and/or CTA results [1:05:15]

- For many patients, Peter doesn’t bother getting a CAC score
  - If it’s not going to add any benefit to what they’re already doing for risk prevention
  - Depending on family history
- The CAC score is not something that you follow serially over time
- It’s used a couple times to establish risk

**More about what the CAC score means**

![](https://peterattiamd.com/wp-content/uploads/2022/04/f25-ama34-1024x405.png)

**Figure 25.**  Odds ratio (adjusted) of coronary heart disease for different CAC scores.  Credit: [*American Journal of Cardiology* 2006](https://pubmed.ncbi.nlm.nih.gov/16728214/)

- Figure 25 is a table taken from the Family Heart Study, published in 2006
- It looked at CAC scores on a little over 3,000 subjects between 2002, 2004
- About 400 of these people were clinically diagnosed with CHD
- These patients were all asymptomatic at the initial exam
  - The initial exam took place 7-9 years earlier
- Basically what you’re looking at is calcium score progression to coronary events in people who were asymptomatic at the time of outset
- Look at the **odds ratio (adjusted) row** in the middle
  - The easiest way to think about the odds ratio is by comparing all these columns to the 1st column
    - A 1.2 in the 2nd solemn is a 20% greater risk relative to the 1st column
    - An odds ratio of 2.0 is 100% greater risk (a doubling of risk) compared to the 1st column
- What you’re looking at in figure 25 is the number of people who had events versus those who didn’t have events based on their calcium score
  - There is a clear relationship between the increase in the calcium score (CAC) and the likelihood of a cardiac event
- A **CAC of 0** is used as the unit case
- A **CAC of 1-49** is generally considered low and is a 1.2 increase in risk over 8 years
- A **CAC of 50-99** nearly doubles the risk
- A **CAC of 100-199** has an odds ratio of up to 3.8
- By the time the **calcium score is 2,000**, the odds ratio is 55.7,  significantly higher
- When Peter had his calcium score measured at age 35 it was 6
  - 6 is a very low number when the scores go up to 2,000
  - At age 36 this put him at about the 75th percentile of the population

> “*That was, of course, for me, the huge wake up call to learn everything I could about this disease and mitigate that risk*.”— Peter Attia

- The CAC was really valuable for him because his lipids weren’t that high
- Much of that risk was mediated through things that are not easy to measure, such as family history

- At the other end of the spectrum, he has patients that are in their 60s who have “*ragingly high lipids*”, and they’re really hell bent about not taking lipid lowering medication
  - For them a calcium score becomes a very helpful way to assess whether or not lipid lowering medication should be discussed in greater detail
- If a patient who’s 70 has a calcium score of zero, even in the presence of high lipids, you might be more willing to acknowledge that this is a person for whom, despite having very high lipids, may have something that’s offering protection
  - Peter would have this person get a CT angiogram because of all the reasons that calcification alone is not sufficient
  - He’s want to look at the lumen for evidence of soft plaque
  - He’s seen people in their 70s who have really normal CTA despite abnormal lipids, but they are the exception

**Thinking about CAC scores,** ***when is calcium even starting to show up?***

- This is a late stage event
- Thinking back to the pathology reviewed earlier from autopsies, none of these patients had calcification
  - Yet you could see they all had a pretty significant burden of disease
- Figure 26 (below) is from a more recent paper; this shows cross-sections of coronary arteries
  - The nomenclature uses more current language, but we’re not going to get into that

![](https://peterattiamd.com/wp-content/uploads/2022/04/f26-ama34-1024x574.png)

**Figure 26.**  Credit: [*Journal of the American College of Cardiology* 2010](https://www.jacc.org/doi/10.1016/j.jacc.2009.07.078)

- The first one (A) is still abnormal
- Normal would be just a beautiful gray rim
- In (A) there is intimal thickening all the way around
  - PIT stands for pathological intimal thickening
- The one at the most right (E) is where you start to see calcification occur
  - **(E) shows a fibrocalcific lesion that can be picked up with a calcium score**

*The point here is how many people can still be missed*

- You can still be in A, B, C, D, and have a normal calcium score
- Only in E is your calcium score abnormal
- But a CT angiogram can pick up A, B, C, D
- Every patient and doctor have to make the decision— ***when is it worth the additional cost and the slight increase in the amount of radiation to have a much better test than one that can only detect E?***

*There’s nothing that’s black and white. It’s not every patient should do this, everyone should do this. It’s dependent on all these different factors, and together, which I think shows the importance of why diving into this and understanding*.

**The calcium score is nuanced**

- There’s now evidence to suggest that even the calcium score by itself is not sufficient in terms of just understanding calcium versus no calcium
- It turns out that the density of the calcium also matters
- When you’re looking at a CT scan, the bigger the Hounsfield unit, the denser the material that the x-ray is shining through
  - The unit CT density is something called a [Hounsfield unit](https://en.wikipedia.org/wiki/Hounsfield_scale)
  - At very low Hounsfield units (for example,looking at the lungs, because you have the least tissue there) the x-ray can zip right through it
  - The highest Houndsfield units is when you’re stopping at bone
- If you then look at just the differences in the Hounsfield units at the calcification of the coronary artery, that tells you something
  - The denser the calcium, the lower the risk
    - This is a little counterintuitive to people, which is calcification by itself is not a bad thing
    - It’s actually a good thing; it’s stabilizing the plaque
    - It’s just that it’s a harbinger of what’s going on

*When Peter tries to describe it to patients, he compared it to bars over the window in a house*

- If you walk into a neighborhood and see bars all over the window, you can at least conclude that no one’s entering that window
- But what does it tell you about the neighborhood you’re in?

## Is there a risk from cholesterol levels being too low? [1:13:00]

**Is there a risk from having cholesterol be too low?**

- The good news is, no
- When you look again at the laboratory report and look at lipid concentrations, you’re looking at what the amount of cholesterol contained within the lipoproteins circulating within the plasma

**Total cholesterol**

*Consider the biggest reduction in total cholesterol you could have*

- Let’s say you lowered your total cholesterol from 200 mg/dL to 100 mg/dL
- Along the way, you lowered your LDL cholesterol from 130 mg/dL to 40 mg/dL
  - These are realistic numbers for what that type of dramatic reduction would do
  - *Question— how much have you lowered total body cholesterol in the process?*

- Consider figure 27 from a study done by Mark Hellerstein
  - This looks at the total body stores and pools of cholesterol

![](https://peterattiamd.com/wp-content/uploads/2022/04/f27-ama34-1024x765.png)

**Figure 27.**  Credit: [*Current Opinion in Lipidology* 2014](https://pubmed.ncbi.nlm.nih.gov/24362356/)

- The middle column shows the concentration of cholesterol
- To make the math easy, the right-hand column is adjusted for a 70 kg person and shows the total grams of cholesterol
- This shows the total amount of cholesterol in 4 places where it would largely concentrate
  - 1 – **Liver**
  - 2 – **Red blood cells** have lots of cholesterol in them
  - 3 – **Lipoproteins**, this is what we’ve been talking about
  - 4 – All the **peripheral tissues of the body**, obviously where the dominant amount is
- Lipoproteins account for less than 10% of total body cholesterol

*Even if you shrink the cholesterol in lipoproteins by 50%, you’re only reducing total body cholesterol by 4.5%*

- This would be an enormous reduction, although it’s one that he will routinely does in patients
- The vast majority of cholesterol still resides in peripheral tissue, and that’s where it’s being turned into hormones

## Key takeaways regarding prevention [1:15:45]

**Overall takeaway:** Think about prevention decades in advance

- ASCVD is very common
- The good news is, this disease takes a really long time to occur
  - It’s not going to happen overnight
  - The flip side of that is it takes a while to prevent it as well

*It’s a disease that is like moving towards an iceberg at three knots from hundreds of miles away. Just like a slow moving ship towards an iceberg, you can’t wait until you’re looking at the iceberg to do anything about it.*

> “*You have to be very forward looking in your assessment of risk.*”— Peter Attia

- Studies look at the effects of drugs (like a statin) over the course of 2 years
  - The key here is **2 years**; this speaks to the nature of this disease
  - Often you may not see impressive results in this period of time
- The [FOURIER](https://www.nejm.org/doi/full/10.1056/nejmoa1615664) and [ODYSSEY](https://www.nejm.org/doi/10.1056/NEJMoa1801174) trials were **5 year studies** published in 2014 or 2015
  - These looked at 2 PCSK9 inhibitors and showed very impressive results
  - This is especially impressive given that one of them was done in patients who were already on maximum statin dose

> *“You want to be thinking about this through the lens of not 5 years worth of prevention, but 10, 20, 30 years of prevention.” —Peter Attia*

**Takeaway: The importance of understanding apoB**

- The other big takeaway is **the importance of understanding apoB** and why apoB concentration is such an important metric
  - It’s not the only metric, but when you want to think about lipids, you want to think about apoB
- ApoB captures the risk much better than LDLC, and even non HDLC
  - This is discussed at length in the [podcast with Allan Sniderman](https://peterattiamd.com/allansniderman/)
- We will have an upcoming podcast on **Lp(a)** to go deep into that topic
  - *Lp(a) is very relevant for about 10% of the population*
- Everybody should know their Lp(a) and if it’s elevated, this opens a whole new Pandora’s box of things to think about prevention-wise

**Takeaway related to calcium scores**:

- Calcium scores are really good tests
- The **CTA is a much better test than the coronary artery calcium (CAC) score**;
  - You just have to decide if the additional cost and radiation are worth it
- Peter likes the CTA more than the CAC because it’s harder to get fooled
- The CAC is a great way to stratify risk, but you’re going to miss a lot of pieces of pathology if they haven’t reached the level of calcification yet

§

## Selected Links / Related Material

**Source of figure 1**: [Risk of Premature Cardiovascular Disease vs the Number of Premature Cardiovascular Events](https://jamanetwork.com/journals/jamacardiology/fullarticle/2523465) | *JAMA Cardiology* (AD Sniderman *et al* 2016) | [6:45]

**Episode of** ***The Drive*** **with Alan Sniderman**: [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 29, 2021) | [22:00]

**Episode of** ***The Drive*** **with Rick Johnson, discusses the impact of uric acid on blood vessel endothelium**: [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 29, 2021) | [22:45]

**Deep discussion of atherosclerosis as a systemic condition of the arterial system**: [The Myth of the “Vulnerable Plaque”](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4344871/) | *Journal of the American College of Cardiology* (A Arbab-Zadeh and V Fuster 2015) | [37:15]

**Source of pathology slides, the Herbert Stary Atlas**: [Atlas of Atherosclerosis Progression and Regression (Encyclopedia of Visual Medicine Series)](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1)  by Herbert C. Stary (2003) | [43:30]

**Source for figure 25**: [Association of coronary artery calcified plaque with clinical coronary heart disease in the National Heart, Lung, and Blood Institute’s Family Heart Study](https://pubmed.ncbi.nlm.nih.gov/16728214/) | *American Journal of Cardiology* (PN Hopkins *et al.* 2006) | [1:05:45]

**Source for figure 26**: [The Dynamic Nature of Coronary Artery Lesion Morphology Assessed by Serial Virtual Histology Intravascular Ultrasound Tissue Characterization](https://www.jacc.org/doi/10.1016/j.jacc.2009.07.078) | *Journal of the American College of Cardiology* (T Kubo *et al* 2010) | [1:10:00]

**Source for figure 27**: [Reverse cholesterol transport fluxes](https://pubmed.ncbi.nlm.nih.gov/24362356/) | *Current Opinion in Lipidology* (M Hellerstein and S Turner 2014) | [1:14:15]

**Read more on the website about preventing cardiovascular disease**: [Cardiovascular Disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/) | peterattiamd.com (2022)

**Read more on the website about what Mendelian randomization studies reveal about LDL-C**: [LDL-C & systolic blood pressure and lifetime risk of cardiovascular disease](https://peterattiamd.com/ldl-c-systolic-blood-pressure-and-lifetime-risk-of-cardiovascular-disease/) | peterattiamd.com (November 10, 2019)

§

## People Mentioned

- [Tom Dayspring](https://twitter.com/Drlipid?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [13:15, 50:15]
- [Alan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) [22:00, 43:30, 56:30, 1:18:15]
- [Richard (Rick) Johnson](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) [22:45]
- [Valentin Fuster](https://www.mountsinai.org/profiles/valentin-fuster) [37:15]
- [Herbert Stary](https://openlibrary.org/authors/OL242041A/Herbert_C._Stary) [43:30, 49:15]
- [Mark Hellerstein](https://nst.berkeley.edu/users/marc-hellerstein) [1:14:30]

§