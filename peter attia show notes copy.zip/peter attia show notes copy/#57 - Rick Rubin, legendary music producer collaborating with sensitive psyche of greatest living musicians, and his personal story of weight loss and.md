# #57 – Rick Rubin, legendary music producer: collaborating with sensitive psyche of greatest living musicians, and his personal story of weight loss and spiritual quest

**Source:** [https://peterattiamd.com/rickrubin/](https://peterattiamd.com/rickrubin/)

---

In this episode, Rick Rubin, legendary music producer and founder of Def Jam Records and American Recordings, discusses his early foray into music production which started as a hobby as a teenager and ultimately turned into a Grammy award-winning career that produced revolutionary changes in the music industry. Rick has worked with the likes of the Beastie Boys, Red Hot Chili Peppers, and Johnny Cash, just to name a small fraction. Rick talks about the pain and suffering that sometimes drives music and the cycle of drug addiction and how he has been able to help artists through those struggles to make space for their creative genius. We also get into Rick’s own personal health journey including his battle with depression, his struggle with obesity, and ultimately his extraordinary transformation. Finally, Rick shares a really significant health scare which required emergency heart surgery, and how that experience has impacted him.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rickrubin/the_Drive_public.png)

Play

#57 – Rick Rubin, legendary music producer: collaborating with sensitive psyche of greatest living musicians, and his personal story of weight loss and spiritual quest

#57 – Rick Rubin, legendary music producer: collaborating with sensitive psyche of greatest living musicians, and his personal story of weight loss and spiritual quest

1x15s30s

0:003:03:53

## We discuss:

- Early career, and the birth of hip hop [7:15];
- Early success of Def Jam Recordings, and working with LL Cool J [13:15];
- Revolutionary changes in music: LL Cool J, Beastie Boys, and Run DMC [19:30];
- Partnership with Columbia Records, and leaving Def Jam [26:45];
- The success of Licensed to Ill: how it took off, and how it changed things [36:00];
- American Recordings: Rick’s transition to rock and roll [39:15];
- Working with the Red Hot Chili Peppers, and the poetic nature of music [45:45];
- Rick’s favorite music that he did NOT produce [53:00];
- Prevalence of drug use and emotional pain in musicians: Rick’s experience with helping artists through their struggles [57:20];
- NYC vs. LA hip hop [1:05:30];
- Rick’s battle with depression [1:10:00];
- Coping with the death of artists that Rick worked with [1:22:00];
- Working with Johnny Cash [1:26:45];
- Working with Rage Against the Machine [1:34:30];
- The digital age of music: Have we lost something? [1:37:45];
- Rick’s health journey and battle with obesity [1:42:45];
- Radical weight loss: How Rick was finally able to shed the weight [2:00:15];
- Total transformation: Exercise and training with Laird Hamilton [2:11:00];
- Emergency surgery: Rick’s frightening heart condition [2:25:30];
- Methylene blue and exogenous ketones: Are they neuroprotective? [2:46:15];
- The most profound thing Rick learned about himself from his heart condition and major surgery? [2:52:30];
- What life lessons does Rick wish to impart on his son? [2:57:30]; and
- More.

§

## Show Notes

## Early career, and the birth of hip hop [7:15]

Note: Peter interviewed Rick at the famous studio (Shangri La Studio) built for The Band and Bob Dylan in the 1970s

![](https://peterattiamd.com/wp-content/uploads/2019/06/Peter-and-Rick-outside-the-studio-1024x670.png)

**Figure 1. Peter and Rick outside the Shangri La Studio.**

*How long does it take for a band to record an album?*

- Could be a couple weeks, could be a couple years

*Where did Rick grow up and what was his experience with music?*

- Grew up in Long Island Beach, Long Island
- Always loved music
- Attended NYU as a philosophy major, then switched to film and television after 2 years
- In a punk rock band, first experience with recording

*When did he first start producing music?*

- Produced some very early hip hop
- Hip hop started as a small underground form of music in the mid-80s
- To find it you’d have to go to record stores and look for 12 inch vinyl singles
- The records were more, they were less like hip hop records and more like other kinds of records musically other than they may have somebody rapping them. But musically it could have been an R&B record.

*Hip hop in the club*

- The hip hop in the club scene was a much better energy than what was on the 12 inch vinyl singles
- In NY, only place to hear hip hop was at a reggae club called Club Negril on Second Avenue

First hip hop hits

- Run DMC (well-known in early-80s in NYC, but not yet nationwide)
- First album produced by [Larry Smith](https://en.wikipedia.org/wiki/Larry_Smith_(producer)) and [Russell Simmons](https://en.wikipedia.org/wiki/Russell_Simmons)
- “*There were things on that album that were really revolutionary… Run DMC’s first record had a couple of glimpses of what was to come*.”

## Early success of Def Jam Recordings, and working with LL Cool J [13:15]

**Def Jam**

- [Def Jam](https://en.wikipedia.org/wiki/Def_Jam_Recordings) was founded by Rick and he brought on Russell Simmons as his partner
- Rick was a “kid in college” and Russell was already a “big fish in a small pond”

LL Cool J

- From [Hollis, Queens](https://en.wikipedia.org/wiki/Hollis,_Queens)
- Ad-Rock (from the Beastie Boys) brought a demo by LL Cool J to Def Jam
- What was it about LL that struck you as distinctive at the time?
  - Lyrical ability, vocabulary, believable in his presentation
  - He was only 16 at the time
- First songs/album
  - LL Cool J was only 18, Rick was 20
  - Very, very low budget
  - Put out 2 singles before an album
- How did those early songs get made?
  - Rick would program a beat in his dorm room
  - Go to the studio
  - They would bring the drum machine
  - LL Cool J would bring his book of lyrics
  - Rick would go through the lyrics and pick out what he liked
  - They would then form those lyrics into a song

How Rick turned early hip hop into songs

- In those days, hip hop was more like a club remix where the rapper would just rap for 10 minutes over a beat, there was no chorus or song structure
- Rick modeled the songs after the Beatles traditional song structure
- “We would chop up these long raps into a 16 bar verse and then create a hook.”
- Budget was in the $300 to $500 dollar range to make a song

*How did Rick get this hip hop music to the public?*

- Printed a few thousand records and physically took them to the 2 or 3 stores in NYC that might sell them
- Played at Club Negril and then eventually at [Roxy](https://en.wikipedia.org/wiki/Roxy_NYC)
- The Roxy was a roller ring that eventually became the hottest place in NY

## Revolutionary changes in music: LL Cool J, Beastie Boys, and Run DMC [19:30]

**Revolutionary changes in music**

- First album Rick produced: [Radio](https://en.wikipedia.org/wiki/Radio_(LL_Cool_J_album)) by LL Cool J
- Second album Rick produced: [Licensed to Ill](https://en.wikipedia.org/wiki/Licensed_to_Ill) by Beastie Boys
- [Run-DMC](https://en.wikipedia.org/wiki/Run-DMC) (Rick played guitar in their 2nd album, but didn’t produce until their 3rd album: [Raising Hell](https://en.wikipedia.org/wiki/Raising_Hell_(album)))
- Peter calls these albums “step function” changes in the music industry
- “Revolutionary”
- Peter, as a 13 year-old, would listen to these albums on turntables while boxing

![](https://peterattiamd.com/wp-content/uploads/2019/06/Technics-SL-1200MK21.jpg)

**Figure 2. Technics 1200 turntable.** Image credit: [turntablelab.com](https://www.turntablelab.com/pages/guide-to-technics-1200-turntables)

> “License to Ill was perhaps the single most important, influential piece of music I listened to as a kid.” — Peter Attia

**Beastie Boys**

- Rick met them in the punk rock circles
- They came from a punk rock background and put out punk rock albums prior to hip hop
- Their first DJ-based song was [Cookie Puss](https://www.youtube.com/watch?v=0DOMxm0o12c) (Rick got to be their DJ when they would perform Cookie Puss live)

⇒ Licensed to Ill

- How did the songs on those albums get made?
  - Rick and the Ad-Rock would write the songs
  - They liked to go to [Danceteria](https://en.wikipedia.org/wiki/Danceteria) and watch the people dancing and they would sort of joke around with each other trying to make eachother laugh
  - So they would collect a bunch of funny phrases and eventually shaped them into songs
  - Their process was different in that they would collect this big bank of material over months and then go into the studio and make one song, then they would go back and start from scratch

## Partnership with Columbia Records, and leaving Def Jam [26:45]

- Rick never really thought that producing music would turn into a career
- It was more of a hobby
- Considered law school because he knew the music industry needed lawyers
- But Rick and Russell and their musician clients had enough success using independent distributors of their first seven [twelve-inches](https://en.wikipedia.org/wiki/Twelve-inch_single), that they were approached by [Columbia Records](https://en.wikipedia.org/wiki/Columbia_Records)

**Columbia Records**

- When Rick was just 20 years-old, Columbia Records offered to partner with Def Jam
- First album released was [Radio](https://en.wikipedia.org/wiki/Radio_(LL_Cool_J_album))
- Rick said he grew to dislike working with Columbia
- They wouldn’t listen to Rick’s concerns about the interests of the artists
- Columbia had a worldwide exclusive on Def Jam’s music, yet the UK Columbia weren’t interested

> “I was told that Columbia has a policy that they would rather see the works die than have someone else have success with them. . . it seemed so far fetched and so counterproductive when there was an opportunity to be heard that they could be participate in to turn that off because of a corporate policy.”

**Leaving Def Jam**

- Rick decided to leave Def Jam after Rick and Russell’s visions started to part
- Columbia wrote them both a nice check but Rick was more concerned about the ability to spread the music
- “*It may not have been the best decision but it felt very natural to me and it felt like I’m making things that I really feel good about… and if I have a partnership with this big company (Columbia) that’s doesn’t want to do what we want to do, I need to find a different way to do this.*”
- So Rick left it all behind and walked away

## The success of Licensed to Ill: how it took off, and how it changed things [36:00]

*What is it that lit up License to Ill (Beastie Boys album)?*

- The Beastie Boys were white and this was an underground black music
- In terms of deeply penetrating into the rest of the country, the fact that the Beastie Boys were white played a huge difference
- “I didn’t see it so much then but now in retrospect it’s clear.”

*How many copies did Licensed to Ill sell?*

- Over 10 million ([“diamond” status](https://en.wikipedia.org/wiki/RIAA_certification#RIAA_Diamond_certifications))

How did the success change things?

- Drove a wedge in their relationship
- in success, a lot of people started surrounding the artists who were more concerned with placating the artist than doing what was best for the artist
- Rick was always focused on what was best for the artists but they weren’t listening to him
- Ultimately, Beastie Boys left Rick/Russell and Def Jam after Licensed to Ill

## American Recordings: Rick’s transition to rock and roll [39:15]

*What did you do after you’ve walked away from Def Jam, the label you co-founded, left behind all the money and artists*?

- Rick thought that since the Def Jam experiment worked, he could do the same thing but with a better framework
- This lead to the start of Def American (now called [American Recordings](https://en.wikipedia.org/wiki/American_Recordings_(record_label)))
- Rick knew he’d have to work with the big distributors again (e.g. Columbia) but thought he could do it differently

Economics of a record in the 1990s

- If someone buys a record from a retail store:
  - Big label (e.g. Columbia) gets about 50%
  - Artist gets ~12% (some big artists, say Michael Jackson, might get 20%)
    - To clarify, the artist’s percentage is taken from the list price (even if the retail store drops the price)

First artists that signed with American

- [Danzig](https://en.wikipedia.org/wiki/Danzig_(band))
- [Slayer](https://en.wikipedia.org/wiki/Slayer)

Rock and roll

- Nirvana was a “seismic or tectonic shift in music” says Peter
- Did Rick see that coming? ⇒ “*No… it felt more like a continuation of Aerosmith and Black Sabbath and the heavy metal I grew up on, so it didn’t feel as revolutionary as it ended up feeling to others.*”
- Rick was more moved by [Soundgarden](https://en.wikipedia.org/wiki/Soundgarden)
- When Soundgarden broke up, Rick got [Chris Cornell](https://en.wikipedia.org/wiki/Chris_Cornell), to join the band members of [Rage Against the Machine](https://en.wikipedia.org/wiki/Rage_Against_the_Machine) (who had just lost their lead vocalist) to form [Audioslave](https://en.wikipedia.org/wiki/Audioslave)
- [Smells like Teen Spirit](https://www.youtube.com/watch?v=hTWKbfoikeg) by Nirvana “changed everything” says Rick
- [Pearl Jam](https://en.wikipedia.org/wiki/Pearl_Jam) came out shortly after that

## Working with the Red Hot Chili Peppers, and the poetic nature of music [45:45]

*When did you first connect with the* [*Red Hot Chili Peppers*](https://en.wikipedia.org/wiki/Red_Hot_Chili_Peppers)*?*

- The asked Rick to produce their third album: [The Uplift Mofo Party Plan](https://en.wikipedia.org/wiki/The_Uplift_Mofo_Party_Plan) but Rick declined due to the band’s increasing drug problems

Mother’s Milk

- They then put out [Mother’s Milk](https://en.wikipedia.org/wiki/Mother%27s_Milk) (their first breakthrough)
- Peter [listened to Knocked Me Down for his tabata workout recently](https://www.instagram.com/p/BwKIQgWAcu_/?utm_source=ig_web_button_share_sheet)

**The poetic nature of music**:

- Peter: “It really speaks to me more as a struggle of the grandiosity that we experience as we get older and experience success more. I was really moved by it actually in a way that, and I guess maybe that’s something about music in general that’s just very special, is it can mean totally different things, not just to different people…but to the same individual at different points in their life.”
- Rick: “It’s the poetic nature of it that allows that … it’s harder for that to happen when you see a movie. A movie is more face value…whereas books and music, the reader or the listener is making the mental images that you associate with it. You may be nudged in a direction by the artist, but the story that you make up your story is your story, and that can change over time.”

*Why Rick declined to work with RHCP when they first asked:*

- Bad vibe from the group
- Dark energy
- Drug issues
- Lack of trust in the room

**Blood Sugar Sex Magik**

- A few years later, when the band was in a better state, Rick produced their album [Blood Sugar Sex Magik](https://en.wikipedia.org/wiki/Blood_Sugar_Sex_Magik)

*Favorite RHCP album?*

- “No idea. I never listen back [to music I produce], so I don’t know.”

*Rick never listens to his own music:*

- “It’s the effort that goes into making these things is so grueling and in the process of making it, I might hear the song a thousand times and by the time it’s done and signed off, I’m good. It’s like I’ve had my fill of that song, so I don’t feel I need to go back and there’s so much music to listen to. I’d rather listen to something that doesn’t make me think of the process of making it …
- … if there was a reason to listen to it, I’ll listen to it, but I wouldn’t choose, I wouldn’t out of the vast catalog of music available to me. I can’t imagine choosing something that I worked on to listen to for fun.”

## Rick’s favorite music that he did NOT produce [53:00]

[Voodoo](https://en.wikipedia.org/wiki/Voodoo_(D%27Angelo_album)) by [D’Angelo](https://en.wikipedia.org/wiki/D%27Angelo)

- Drummer and producer, [Questlove](https://en.wikipedia.org/wiki/Questlove), also was involved
- D’Angelo is a really great singer with a beautiful voice
- His voice is almost buried and his performance is so understated that it almost sounds like he’s dreaming it as opposed to performing it
- It doesn’t work the way other R&B records work
- Records usually sound, I’ll say perfect, everything is played as good as it can be played and put together in a way that is seamless
- Whereas this album purposely always sounds like it’s on the verge of falling apart and it makes it thrilling

[Forever Changes](https://en.wikipedia.org/wiki/Forever_Changes) by [Love](https://en.wikipedia.org/wiki/Love_(band))

- It doesn’t sound like any of Love’s other albums and no other album sound like it by anybody else
- “It’s a real moment in time, so that’s exciting to me.”

[James Blake’s first album](https://en.wikipedia.org/wiki/James_Blake_(album))

- “Beautiful, it doesn’t sound like anything else. Very original, really touches me.”

## Prevalence of drug use and emotional pain in musicians: Rick’s experience with helping artists through their struggles [57:20]

*Why is there so much drug use in musicians?*

- It’s self medicating
- People who make music tend to be very sensitive

Example, [Kurt Cobain](https://en.wikipedia.org/wiki/Kurt_Cobain)

- He was a “raw nerve”
- He’s going through this world feeling things that other people who have the same experiences don’t feel
- This might help his music, but “it makes it hard to survive in life”
- “People don’t look at that stuff. This goes for most musicians, but it’s always the case of the musician just trying to find a way to exist in a world where they feel like they don’t really fit.”

Example, [Michael Jackson](https://en.wikipedia.org/wiki/Michael_Jackson)

- He was using [Propofol](https://en.wikipedia.org/wiki/Propofol) (not a mainstream recreational drug)
- All he wanted was to numb himself with a general anesthetic
- Talk about a traumatized kid… “Here’s a boy who never stopped being traumatized by something, and ultimately that trauma, he passed that on to other kids.”

Red Hot Chili Peppers

- Both [Flea](https://en.wikipedia.org/wiki/Flea_(musician)) and [Anthony Kiedis](https://en.wikipedia.org/wiki/Anthony_Kiedis) have been open about their struggles
- These guys make unbelievable music, but you get the sense that there’s something tormenting these people

**Rick’s experience with helping artists through their struggles**

> “It’s as much of the part of the job as the music part…helping a sensitive soul work through this life and this business where there are a lot of voices who are more concerned with getting the next record out and cashing in and less concerned with the health of the artist.”

*How has Rick been able to strike the balance between the business and the art to create an environment that fosters both?*

- “If you get the art right, the commerce side of it works itself out.”
- I can help an artist to refocus, to just pay attention to the art instead of overthinking what comes next
- Thinking about all those other business related things “tend to lower the vibration of the entire project”
- “We try to get to this pure art place, and in doing so it benefits them in all areas, but there’s very little thought of the business side.”
- “[Success] happens more through the purity of it instead of through aiming at it.”

## NYC vs. LA hip hop [1:05:30]

*Is it a surprise to you that gangster rap came out of L.A. and not New York?*

- “Not really, because there was more of a gang culture in L.A., in real life, so the gangster rap sprung out of the gang culture that really exists.”

[N.W.A](https://en.wikipedia.org/wiki/N.W.A)

- Rick visited them in the studio while they were recording [Straight Outta Compton](https://en.wikipedia.org/wiki/Straight_Outta_Compton)
- Rick said there was a gap of good rap music between [Public Enemy](https://en.wikipedia.org/wiki/Public_Enemy_(band)) and N.W.A
- “N.W.A. got me excited about hip hop again.”

Public Enemy

- [Chuck D](https://en.wikipedia.org/wiki/Chuck_D)
  - Brilliant, cerebral
- [Flavor Flav](https://en.wikipedia.org/wiki/Flavor_Flav)
  - “A living cartoon character”

How do these groups stay together with all these big personalities?

- Many don’t
- There’s a survivor bias… the ones that actually manage to stay together often do big things
- Example: [Mötley Crüe](https://en.wikipedia.org/wiki/M%C3%B6tley_Cr%C3%BCe) as depicted in the documentary about them, [The Dirt](https://en.wikipedia.org/wiki/The_Dirt_(film))

## Rick’s battle with depression [1:10:00]

*When did Rick realize that his role was not about making music as much as it was about helping artist through pain and mental suffering?*

- This realization happened at age 33 when Rick himself became very depressed
- Crippling
- Hardly able to get out of bed
- Took him 2 years to figure it out
- “I had a much greater understanding of the artist’s pain after that experience.”

**What precipitated Rick’s depression?**

- A seemingly noncontroversial moment that blew up Rick’s world
- It was a phone call with a new executed at a major label who had replaced someone he had a great relationship with
- He called Rick and said, “I just looked at your deal and I’m jealous. I don’t really like it. When you come back, we should talk about it.”
- Sent Rick into a tailspin
- “It just felt like a pin that burst the balloon and honestly, truthfully, I’m still not the person I was before that phone call.”

*⇒ Why was this so impactful?*

- “Triggered some vulnerability in me that I’d never felt before.”
- “The feeling of the rug being pulled out from under me”
- “It was a sense of not being seen.”

**What did Rick do over the next 2 years to try to mitigate his depression?**

- “Everything”
  - Two therapeutic treatments a day
  - Acupuncture
  - Herbal remedies
  - Massage
  - New diet to be one that would better support the brain chemicals
  - Saw a psychic
  - Guided meditations
- Medicine
  - Did not want to take medicine ⇒ tried [Paxil](https://en.wikipedia.org/wiki/Paroxetine), and it was the worst night of his life
  - But knew that an antidepressant was what he needed
  - He eventually found [Remeron](https://en.wikipedia.org/wiki/Mirtazapine) ⇒ “half hour later it felt like all the light in the room turned to candlelight and I felt like I was being cradled, like protected like a baby”

Weight gain

- Remeron increased Rick’s appetite and resulted in weight gain (~60 lbs)
- Drives your appetite through the roof, say Peter

Breaking the cycle

- Despite Rick’s reluctance to take drugs, he knew he had to break the cycle of depression
- Eventually he was able to get off Remeron and was able to manage his depression

*What’s better about Rick today since this experience?*

- He says he feels more empathic
- He felt like Superman prior to this and “I’ve never felt like Superman since.”

## Coping with the death of artists that Rick worked with [1:22:00]

How did Rick deal with the death of artists he worked with?

- Every one of them had a jarring effect
- The younger the artist the more surreal

Artists that Rick worked with that died too young

- [Mac Miller](https://en.wikipedia.org/wiki/Mac_Miller)
- [Chris Cornell](https://en.wikipedia.org/wiki/Chris_Cornell)
- [Chester Bennington](https://en.wikipedia.org/wiki/Chester_Bennington) from Linkin Park
- [Johnny Cash](https://en.wikipedia.org/wiki/Johnny_Cash)

Johnny Cash’s death

- Rick was rocked by Johnny’s death
- Even though Johnny had been sick for a long time
- At the time, Rick was speaking with him daily and his health was getting better and better
- June’s death
- The death of [June Carter](https://en.wikipedia.org/wiki/June_Carter_Cash) took a toll on Johnny
- Johnny told Rick…“*You have to keep me very busy because if you don’t, I can’t do this. I can’t continue.*”

Movie rec: [Walk the Line](https://en.wikipedia.org/wiki/Walk_the_Line)

- The movie depicts the traumatic events of his childhood (relationship with father, death of older brother) that lead to the pain that made the music

> “We love that this person can articulate something that is so deep inside of us that we don’t want to think about or talk about, and yet he can create a scaffolding upon which we can write our own narrative.” —Peter Attia on Johnny Cash

## Working with Johnny Cash [1:26:45]

- Worked with Johnny for the last 10 years of his life
- Produced 6 albums together (2 of which were released after his death in 2003)

![](https://peterattiamd.com/wp-content/uploads/2019/06/rick-rubin-with-johnny-cash-1024x1013.png)

**Figure 3. Rick with Johnny Cash.** Image credit: [ew.com](https://ew.com/article/2015/09/10/john-carter-cash-rick-rubin-johnny-cash/)

Cover song for Nine Inch Nails

- Johnny did a cover song of [Hurt](https://en.wikipedia.org/wiki/Hurt_(Nine_Inch_Nails_song)), but he did not ask for Trent’s permission
- Trent was not thrilled until he saw the video, and at that point “he got it”
- The cover got massive critical and commercial acclaim
- Peter calls that song “top 10 songs that speak to life”

https://www.youtube.com/watch?v=vt1Pwfnh5pc

Which of Jonny’s songs did Johnny really like?

- A handful really meant a lot to him
  - [The Mercy Seat](https://en.wikipedia.org/wiki/The_Mercy_Seat_(song)), a song by [Nick Cave](https://en.wikipedia.org/wiki/Nick_Cave_and_the_Bad_Seeds) that he covered
  - [Redemption Day](https://www.youtube.com/watch?v=nBs-8eCXpGg), a song by [Sheryl Crow](https://en.wikipedia.org/wiki/Sheryl_Crow) that he covered

Covers by Johnny that really “moved” the original artist

- [One](https://www.youtube.com/watch?v=CGrR-7_OBpA) originally by [Bono](https://en.wikipedia.org/wiki/Bono)
- [Desperado](https://vimeo.com/197002502) originally by [Eagles](https://en.wikipedia.org/wiki/Eagles_(band)) ([Don Henley](https://en.wikipedia.org/wiki/Don_Henley) was particularly moved)

Tangent: Peter is [Tom Morello](https://en.wikipedia.org/wiki/Tom_Morello)’s twin

- Peter’s son (4 years old at the time) refused to believe that Peter wasn’t the guy playing the guitar in [this video](https://www.youtube.com/watch?v=n-mq0uJ7rlM&feature=youtu.be&t=397)

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-11-at-11.43.47-AM-1024x630.png)

**Figure 4. Peter very much looking like Tom Morello.** Image credit: [YouTube: Zarastro1040](https://www.youtube.com/watch?v=n-mq0uJ7rlM&feature=youtu.be&t=397)

## Working with Rage Against the Machine [1:34:30]

Peter wonders how Rick managed [Rage Against the Machine](https://en.wikipedia.org/wiki/Rage_Against_the_Machine), a band with so much drama, anger, etc.

*How did he get in contact with them?*

- Recommend by [Perry Farrell](https://en.wikipedia.org/wiki/Perry_Farrell) from [Jane’s Addiction](https://en.wikipedia.org/wiki/Jane%27s_Addiction)
- Rick saw them play in the late 80s and wasn’t tremendously impressed
- But Rick points out that his impression could have been affected by so many things, the venue, the crowd (only 40 people there), his personal mood and emotional state, etc.

> “I have to be in the right frame of mind to be able to be present and open and feeling well enough to not let what’s going on inside of me affect the music that I’m listening to.”

Rick ended up producing 2 albums for them:

1. An album of live music: [Live at the Grand Olympic Auditorium](https://en.wikipedia.org/wiki/Live_at_the_Grand_Olympic_Auditorium)
2. An album of covers: [Renegades](https://en.wikipedia.org/wiki/Renegades_(Rage_Against_the_Machine_album))

![](https://peterattiamd.com/wp-content/uploads/2019/06/RAGE-Renegades-CD-cover.png)

**Figure 5. RAGE cover photo.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Renegades_(Rage_Against_the_Machine_album))

## The digital age of music: Have we lost something? [1:37:45]

*Things that are lost/forgotten when music became digitized*:

- Peter points he used to know what all the album covers looked like
- You knew lyrics by heart because they were printed on the lyric jackets
- You knew the name of every song as well

![](https://peterattiamd.com/wp-content/uploads/2019/06/licensed-to-ill-cover.jpg)

**Figure 6. Licensed to Ill CD cover that Peter used to sketch as a kid.** Image credit: [amazon.com](https://www.amazon.com/Licensed-Ill-Beastie-Boys/dp/B0000024JN)

Peter: “*There really is something so cool about the anticipation of a new album and physically going there, taking your lawn cutting money to buy said album, to bring it home to listen.*”

Rick: “*It’s a give and take. I mean it’s definitely the experience of getting new music is less special than it was. But now you can listen to anything you want, anytime you want. There’s no friction between you and the music, which as a fan of music, that’s really great too.*”

*Peter’s first CD purchases*:

- First CD was the [Led Zeppelin box set](https://en.wikipedia.org/wiki/Led_Zeppelin_Boxed_Set)
- Second CD was [Chronicles](https://en.wikipedia.org/wiki/Chronicles_(Rush_album)) by [Rush](https://en.wikipedia.org/wiki/Rush_(band))

**Music before and after the digital age**

- Since barriers to entry were so much greater in the 1970-1990s, only the best of the best music made it
- Plus, the fact that the technology was such that unless you’re really good, you didn’t even get to make a record
- Today, there is so much noise because anyone can get their music out to the world
- “*Anybody can make anything now, which is great. . . But you just lowered the signal-to-noise ratio.*”

## Rick’s health journey and battle with obesity [1:42:45]

**Rick’s battle with his weight**

- Rick’s heaviest weight was 318 lbs in his 40s
- He’s spent his whole life battling weight issues which run in his family
- Always ashamed of his weight even as a little kid
- His mom struggled and had image issues with it and passed that on to Rick
- “Generational shame.”

Vegan diet

- At his heaviest weight, Rick had been a vegan for 20 years
- He thought he was eating the healthiest diet by he couldn’t stop gaining weight

Rick’s “aha” moment

- Read a book Stu Mittleman who ran 1,000 miles in 11 days
- Rick thought about how he couldn’t “walk to the corner without feeling like I’m gonna pass out”

Phil Maffetone

- In the book, it talked about [Phil Maffetone](https://twitter.com/drphilmaffetone?lang=en)
- Rick found a contact for Phil and reached out to him about becoming a patient
- But Phil was closing his practice to pursue songwriting
- Rick, of course, said he would help Phil with that in exchange for help with his health so they worked out a deal and became friends

First changes that Rick made

- Cut carbs
  - He stayed vegan, to Phil’s frustration, but he had Phil cut out carbohydrates
  - Peter says, “Carbohydrate restriction is very challenging with vegans. It’s not as challenging if you’re a vegetarian. . .a lot of plant fats which are by themselves not…particularly palatable.”
- Walking with a heart rate monitor
  - Rick started to walk at a target heart rate (70% of max so ~156 beats/min) for as long as he could, which at first was only a few minutes
  - Eventually he trained himself to walk for longer and longer
  - He then moved to walking flights of stairs in his home

Adding meat back into diet

- At Phil’s urging, Rick slowly moved away from veganism
- Started with fish and eggs
- Rick says salmon is too “fishy” but Peter is convinced Rick would like [Peter’s family recipe](https://mailchi.mp/attiamedical/180805-420025) (check out this [IG pic](https://www.instagram.com/p/BlovscCA5Cy/?hl=en))

Weight not coming off…

- Even with low-carb, adding meat, and moderate exercise, the weight is not coming off (lost maybe 5 lbs)
- Phil was befuddled
- Peter’s says he has 4 or 5 patients that experienced the same thing (probably more common than 1% of the population)

*Despite no weight loss, how was Rick feeling*?

- He felt much better/healthier
- Sleeping better
- More vitality
- Better fitness

## Radical weight loss: How Rick was finally able to shed the weight [2:00:15]

- Rick was having lunch with [Mo Ostin](https://en.wikipedia.org/wiki/Mo_Ostin) (ran Warner Brothers Records)
- He was concerned with Rick’s weight and introduced him to his nutritionist, [Dr. Heber at UCLA](https://www.uclahealth.org/david-heber)

First visit to Dr. Heber

- Did a body fat assessment ([impedance machine](https://en.wikipedia.org/wiki/Bioelectrical_impedance_analysis))
- Was told he burned 2,300 calories per day
- Put Rick on a 1,400 calorie diet

New diet

- His new diet was based around [Jay Robb egg protein shakes](https://www.jayrobb.com/products/) (6 or 7 per day)
- Dinner was only “food” meal (fish, soup, salad, like a light dinner, a low-calorie dinner with no carbs)
- How was your appetite? ⇒ “*After three days, fine, because the protein in the shakes was so satisfying and I had had them, I’ve had one soon as I woke up in the morning and then every two hours. I never really had a chance to get hungry*.”

Common dinner for Rick:

- He liked to spread out his dinner over a few hours
- First he would have fish and some cooked vegetables
- An hour later he would have vegetable broth or chicken broth
- An hour after that he would have a giant salad, but with just a little bit of oil and lemon juice
- He would occasionally eat an apple and he would really savor it

Weight starts coming off

- In 14 months, **Rick lost 135 pounds**
- Peter says that is a testament to Rick’s ability to stick to it
- Rick calls himself a very disciplined/diligent person with food

Protein requirements:

- A key to the diet, per Dr. Heber, was getting enough protein
- He had Rick eating 1 gram of protein per his target weight goal (e.g. if he wanted to get to 220 pounds, he would eat 220 grams of protein per day)
- **Peter’s says be careful**:
  - High protein diets like that have caused people trouble
  - Some people don’t have the kidney function to be able to handle so much protein
  - This tends to give a “low-carb” diet a bad rap because people replace carbs with protein and not enough fat

*Phil Maffetone prepared Rick’s body to be able to lose weight*

- Without Phil, this new diet wouldn’t have worked, says Rick
- Peter posits that Phil likely fixed Rick’s *fuel partitioning issues*
- Before Phil, Rick was probably glycogen overloaded, hyperinsulinemic, glucose dependent
- But ultimately, Rick was consuming too many calories in order to lose weight (Rick said he would eat 2,000 calories in almond butter in one sitting)

> “I don’t think one can lose weight when the liver and the muscles are full of glycogen. That has to be depleted. And the two quickest things that you can do to deplete glycogen in the liver and the muscle are to exercise and to restrict calories above all else. But within the calories, carbohydrates are probably the most important to restrict.” —Peter Attia

## Total transformation: Exercise and training with Laird Hamilton [2:11:00]

![](https://peterattiamd.com/wp-content/uploads/2019/06/rick-rubin-before-and-after-1024x569.png)

**Figure 7. Rick before and after weight loss.** Image credit: [gigwise.com](https://www.gigwise.com/features/109474/rick-rubin-producer-beastie-boys-johnny-cash-rhcp) (left) and [interviewmagazine.com](https://www.interviewmagazine.com/music/rick-rubin#slideshow_44561) (right)

Training with Laird Hamilton

- Rick met [Laird Hamilton](https://www.uclahealth.org/david-heber) through mutual friend [Don Wildman](https://www.xptlife.com/don-wildman/) (founder of Bally Total Fitness and a super fit older guy who did [23 pull ups at age 80+](https://www.esquire.com/news-politics/a4454/don-wildman-0508/))
- Started training with Laird after he’d lost 90 lbs, wanting to lose another ~50 lbs
- When he first got there, he told Laird that he couldn’t do a single push up… Laird said, “No, don’t say you can’t do it, say you haven’t done it yet.”

Mental challenge

- Before meeting Laird, Rick thought of exercise of “tuning out”, just grunt work
- Learned that it could be mentally challenging as it was physically challenging
- Everything was doing two exercises at the same time while you’re balancing ⇒ “It was very focus intensive … Same thing I do with music.”

Switching up the workouts

- Everyday was entirely different
- One day lifting heavy weights, the next day doing 100 reps of one exercise
- Then sometime super slow reps or even “holding” a position or weight for as long as possible
- Kept it interesting and fun

Pool training

- Originally, they started simply carrying heavy weights underwater from shallow to deep end
- Evolved to 3 days a week in the pool
- Example, they would leave dumbells at the bottom of the deep end (14 feet), swim down and do curls, come up and catch a breath, then swim down and do as many shoulder presses as possible, repeat
- Next, they did jumps from the bottom of the pool to the surface while holding weights
- Also, would train doing backflips underwater while holding weights

Total transformation

- Over the course of 6 or 7 years, Rick goes from a guy who can hardly walk to his car working out with professional athletes
- When he started he couldn’t do 1 push up, and he got to the point where he could do **100 consecutive push ups**
- Peter remembers seeing this article and thinking, wow what a transformation: [Men’s journal article](https://www.mensjournal.com/entertainment/the-rebirth-of-rick-rubin-20131113/)

*How did this transformation affect his life and work*?

> “If anything, I was just in a better mood. I feel like I came alive through that process in a different way. Now I was already alive in the studio, but maybe that was the only place I was alive before. But through the exercise I became alive more in life.”

## Emergency surgery: Rick’s frightening heart condition [2:25:30]

In the summer of 2018…

- Rick informed Peter that he had an [echocardiogram](https://en.wikipedia.org/wiki/Echocardiography) which showed he might have [aortic stenosis](https://en.wikipedia.org/wiki/Aortic_stenosis)
- Peter took Rick to see radiologist, [Bob Peters](https://www.mrict.com/staff.asp), to get a [cardiac MRI](https://en.wikipedia.org/wiki/Cardiac_magnetic_resonance_imaging) (which is said is better)
- Bob then calls Peter 10 times in a row with an urgent message to come see him immediately

**Bicuspid aortic valve**

- Rick and Peter went to see Bob
- Peter could see the issue immediately when looking at the scan
- Rick had [congenital bicuspid aortic valve](https://en.wikipedia.org/wiki/Bicuspid_aortic_valve)
- Most people are born with an aortic valve that has three leaflets
- A small subset of people are born with two leaflets (hence the term bicuspid as opposed to tricuspid)
- You are therefore more prone to calcification ⇒ the valve starts to act like a piece of bone and it models itself like bone… and the problem with that is it becomes harder and harder to open (aka aortic stenosis)
- [Arnold Schwarzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger) had a bicuspid aortic valve and [needed an operation](https://www.livescience.com/62182-arnold-schwarzenegger-heart-surgery.html)

*Implications*:

- This meant Rick would **need surgery immediately** (within days/weeks as soon as they find the right surgeon)
- It also meant Rick would need to **stop doing any heavy weight lifting immediately** (which he’d been doing frequently up to this point)

*More about Rick’s prognosis*:

The aortic valve is what empties the biggest, most powerful chamber in the heart called the left ventricle… and several troublesome things are happening:

⇒ First, the **left ventricle of the heart is getting dangerously large**

- The heart is pumping against a greater and greater force of resistance… And for transient periods, it’s great for the heart to have resistance… but the heart being the most important muscle in the body has great adaptation
- And one of the adaptations is it just gets bigger and bigger and bigger and more muscular and more muscular as it goes against that
- Looking at Rick’s cardiac MRI, Peter noticed how thick the muscles of his left ventricle and septum, which is the muscle wall that separates the left and right ventricle, they were without exaggeration, **twice the normal thickness of a man Rikc’s size**.
- So this can cause an outflow obstruction (i.e., the wall of the heart itself can begin to impede outflow)

⇒ Secondly, it’s getting **harder and harder to get blood out past the aortic valve**

- This can result in sudden death (known as *critical aortic stenosis*)
- Based on the gradient and the pressure across the valve, and the size of what’s left (how many square centimeters of opening is there) … and once you’re below a certain level, it’s called critical… and once you reach that, the probability of sudden death goes up significantly

⇒ Third, an **enlarged aortic root**

- This goes hand in hand with aortic stenosis
- One thought is the higher pressure gradient going across just stretches it out, but Peter posits that whatever congenital factors lead to the defective valve leaflets suggests not having the right collagen mixture or matrix within the ascending aorta
- Based on Rick’s size, **he should have been about 3.9 centimeters, he was at 6.6 or 6.7 centimeters**
- This means Rick was at risk of dissection (tearing) which comes with a mortality of 2-4% per hour that it goes untreated (many people die)

*What did Rick think after getting this news?*

- “Those were the most difficult six weeks of my life.”

Rick’s aversion to needles/surgery and big medical interventions:

- Rick was constantly trying to figure out how to fix his issue without surgery (he has an aversion to big interventions)
- Rick had his appendix burst 20 years ago and he never had it removed (which in many cases leads to death)
- Regarding appendicitis, Peter says: “*Nowadays the approach to appendicitis is much less surgical. It is a much more aggressive antibiotic routine but that said, you are still very fortunate to have survived.*”

The surgery

- Just days before the scheduled surgery, Rick was sending Peter emails and texts every day with “cockamamie ideas” to avoid doing this (Peter thought Rick was joking but he was serious)
- Peter didn’t even realize Rick’s anxiousness about this until after the fact
- Despite Rick’s attempts to avoid surgery, he eventually submitted
- They decided to go with [Dr. Joseph Woo](https://profiles.stanford.edu/joseph-woo) (head of cardiovascular surgery at Stanford)
- He was doing this exact surgical operation three times a week (avg. doc might do it 5 times per year)

## Methylene blue and exogenous ketones: Are they neuroprotective? [2:46:15]

**Methylene blue**

- Rick wanted to take [methylene blue](https://en.wikipedia.org/wiki/Methylene_blue) during the operation
- Rick asked the doctor but they ultimately said “no”

*Why did Rick want methylene blue?* … Peter explains:

- The reason that this was of interest to Rick was he was going to be under circulatory arrest
- This is a much bigger operation than even doing bypassing of the heart because you actually have to do a special type of cannulation to create another type of blood flow to the brain to make up for the fact that even the vessels on the top of the aorta are not supplying the brain anymore
- This is an area of surgery where *speed is everything*
- The human brain can only go so long without it’s natural profusion from the heart and the difference between Joseph Woo doing this operation and somebody else was night and day
- ⇒ So the question is… **“Methylene blue can protect the brain?”**
- Peter was skeptical that it could help in a meaningful way
- However, two months later, Peter had [Francisco Gonzalez-Lima on his podcast](https://peterattiamd.com/franciscogonzalezlima/)
- Peter now has more confidence in methylene blue’s brain protective properties
- “*I hope some anesthesiologists out there are paying attention to this literature because I think there is actually an opportunity to reduce the morbidity and potentially mortality of these really, really dangerous, big, big operations where it’s unavoidable that you have to alter the profusion of the brain*.”
- Idea originally came from [Dr. Jack Kruse](https://jackkruse.com/about-dr-jack-kruse/)
- Peter really would like to see a clinical trial on this

**Ketones**

- Ketones as a brain fuel could also potentially be neuroprotective during an operation like this
- Rick could have eaten a keto diet leading up to the operation to have a larger bank of blood ketones
- Another way to increase ketone availability would be the get exogenous ketones intravenously rather than dextrose (which is more common)
- Rick was worried that as a low-carb person, the dextrose would “shock” his system
- Peter also says that “[lactated ringers](https://en.wikipedia.org/wiki/Ringer%27s_lactate_solution) would have been the perfect intravenous solution and you could happily go days without glucose”
- Ultimately, Dr. Woo did it “his way” and didn’t want to change any of the parameters (such as adding methylene blue and/or IV ketones)

## The most profound thing Rick learned about himself from his heart condition and major surgery? [2:52:30]

- Rick’s biggest hesitation and frustration about having the surgery was the long recovery time (and a small fear of dying)
- Rick developed [atrial fibrillation](https://en.wikipedia.org/wiki/Atrial_fibrillation) post-op which 20% of patients do
- He couldn’t really sleep for 3 weeks b/c he could never get comfortable

Where you are today where do you think you are in terms of percent recovery?

- About 90%, says Rick
- This is normal, it should take about 6 months to get to 80-90% recovered
- However, Rick hasn’t picked up more than 5 lbs since the surgery

Regarding sleep post-surgery, Peter points out…

⇒ “*This is one of those things that I think in medicine we don’t get training on. Maybe it’s changing today but certainly I don’t remember ever once spending a moment, not one second, thinking about how is a patient going to sleep when they get home. And someone who is young and healthy like you, they get over it, but when you start operating on patients who are older, or patients who already have even the slightest amount of cognitive impairment, that sleep deprivation, and I’ve seen it on several occasions, it precipitates a spiral that they never get out of.*”

**What is the most profound thing you learned about yourself?**

> “I won’t say this about myself but I’ll say it about being a human, that as humans we can really handle much more than we think.”

## What life lessons does Rick wish to impart on his son? [2:57:30]

***When you reflect on your life… the successes, the failures, the fear, the pain, knowing that your son has to find his own way in this world… what do you want to impart on him?***

> “To try to have as much fun as possible. To be prepared to work hard for the thing that you’re interested in doing, whatever it is. Knowing that anything that’s worth doing is going to take a commitment and you have to work hard and it feels good. Work isn’t something to be avoided, it’s to be embraced. But balanced with that idea of having fun which I did not have. I had more of a workaholic side.”

**Rick says it’s important to** ***show*** **(as opposed to just tell) his son…**

“Living a loving relationship. Living in a loving household where we care about each other and making sure he always knows how much we love him and are there for them through demonstration.”

![](https://peterattiamd.com/wp-content/uploads/2019/06/tree-768x1024.jpg)

**Figure 8. Tree showing the many rings of life.**

§

## Selected Links / Related Material

### **ALBUMS AND SONGS MENTIONED**

**Debut album by The Band:** [Music from Big Pink](https://en.wikipedia.org/wiki/Music_from_Big_Pink) 7:45

**Run DMC’s first album came:** [Run-D.M.C (album)](https://en.wikipedia.org/wiki/Run-D.M.C._(album)) [12:30]

**Huge early album by Beastie Boys**: [Licensed to Ill](https://en.wikipedia.org/wiki/Licensed_to_Ill) [20:00, 22:15, 25:15, 35:45, 1:38:30]

**LL Cool J breakout album:** [Radio](https://en.wikipedia.org/wiki/Radio_(LL_Cool_J_album)) [20:45, 28:15, 29:30]

**Beastie Boys music video Peter remembers fondly and watched recently with his daughter:** [Beastie Boys – No Sleep Till Brooklyn](https://www.youtube.com/watch?v=07Y0cy-nvAg) | BeastieBoys (youtube.com) [22:30]

**Beastie Boys’ first DJ-based song:** [Cookie Puss](https://www.youtube.com/watch?v=0DOMxm0o12c) | Ben Hansen (youtube.com) [23:30]

**Beastie Boys album after Licensed to Ill which Rick did not produce because they left Def Jam:** [Paul’s Boutique](https://en.wikipedia.org/wiki/Paul%27s_Boutique) [38:45, 1:38:00]

**Nirvana song that changed everything**: [Smells like Teen Spirit](https://www.youtube.com/watch?v=hTWKbfoikeg) | nirvana (youtube.com) [44:15]

**Third album by Red Hot Chili Peppers which they asked Rick to produce but he declined due to the turmoil amongst the group (drugs):** [The Uplift Mofo Party Plan](https://en.wikipedia.org/wiki/The_Uplift_Mofo_Party_Plan) [45:45]

**Breakout album for Red Hot Chili Peppers:** [Mother’s Milk](https://en.wikipedia.org/wiki/Mother%27s_Milk) [46:00]

**Song Peter enjoyed listening to during his tabata workout:** [Red Hot Chili Peppers – Knock Me Down (Mother’s Milk)](https://www.youtube.com/watch?v=cG9Kh8rd2-M) | mason92bs (youtube.com) [47:00]

**Red Hot Chili Peppers album that Peter told Rick that he might have set the record for repeatedly listening:** [Californication](https://en.wikipedia.org/wiki/Californication_(album)) [49:00]

**First album that Rick made with the RHCP after they cleaned up their act:** [Blood Sugar Sex Magik](https://en.wikipedia.org/wiki/Blood_Sugar_Sex_Magik) [51:00]

**Rick’s favorite album that he was not involved in creating/producing, “perfect album for me”**: [Voodoo](https://en.wikipedia.org/wiki/Voodoo_(D%27Angelo_album)) [53:15]

**One of Rick’s favorite albums by a group called Love**: [Forever Changes](https://en.wikipedia.org/wiki/Forever_Changes) [55:45]

**Recent album Rick enjoyed**: [James Blake (album)](https://en.wikipedia.org/wiki/James_Blake_(album)) [57:00]

**Famous Michael Jackson songs that Peter said he never really “gravitated towards” as a kid:** [Beat it](https://en.wikipedia.org/wiki/Beat_It), [Thriller](https://en.wikipedia.org/wiki/Thriller_(song)), [Billie Jean](https://en.wikipedia.org/wiki/Billie_Jean) [59:45]

**Debut studio album by N.W.A that Rick got to watch them make in studio during a visit:** [Straight Outta Compton](https://en.wikipedia.org/wiki/Straight_Outta_Compton) [1:06:00]

**Motley Crue song:** [Mötley Crüe – Dr. Feelgood (Official Music Video)](https://www.youtube.com/watch?v=trGX3ET3jTQ) | Mötley Crüe (youtube.com) [1:09:00]

**Johnny Cash covered the song, Hurt, by Nine Inch Nails which initially displeased Trent but ultimately Trent really liked it after seeing the music videot**: [Johnny Cash – Hurt (Official Video) HD](https://www.youtube.com/watch?v=vt1Pwfnh5pc) | DFTranslateBR (youtube.com) [1:26:45]

**The six albums that Rick produced for Johnny Cash:** [1:26:45]

1. [American Recordings (album)](https://en.wikipedia.org/wiki/American_Recordings_(album))
2. [American II: Unchained](https://en.wikipedia.org/wiki/Unchained_(Johnny_Cash_album))
3. [American III: Solitary Man](https://en.wikipedia.org/wiki/American_III:_Solitary_Man)
4. [American IV: The Man Comes Around](https://en.wikipedia.org/wiki/American_IV:_The_Man_Comes_Around)
5. [American V: A Hundred Highways](https://en.wikipedia.org/wiki/American_V:_A_Hundred_Highways)
6. [Unearthed](https://en.wikipedia.org/wiki/Unearthed_(Johnny_Cash_album)) (box set which includes [My Mother’s Hymn Book](https://www.amazon.com/Mothers-Hymn-Book-Johnny-Cash/dp/B0001NBMTE))

**Nick Cave song covered by Johnny Cash that meant a lot to Johnny:** [Johnny Cash – The Mercy Seat (music video)](https://www.youtube.com/watch?v=gaIo1trTpKQ) | Mark Wright (youtube.com) [1:31:00]

**Sheryl Crow song covered by Johnny Cash that meant a lot to Johnny**: [Johnny Cash – Redemption Day](https://www.youtube.com/watch?v=nBs-8eCXpGg) | ne9ator (youtube.com) [1:31:00]

**Bono was moved by Johnny’s cover version of One**: [Johnny Cash – “One”](https://www.youtube.com/watch?v=CGrR-7_OBpA) | titschyquitschy0008 (youtube.com) [1:31:45]

**Don Henley really liked Johnny’s version of Desperado:** [Johnny Cash – “Desperado” – MV (Unofficial)](https://vimeo.com/197002502) | Jun Li (vimeo.com) [1:31:45]

**Album of live songs that Rick produced for Rage Against the Machine**: [Live at the Grand Olympic Auditorium](https://en.wikipedia.org/wiki/Live_at_the_Grand_Olympic_Auditorium) [1:37:15]

**Another album that Rick produced for Rage Against the Machine**: [Renegades](https://en.wikipedia.org/wiki/Renegades_(Rage_Against_the_Machine_album)) [1:37:15]

**Peter’s first CD purchase ever:** [Led Zeppelin box set](https://en.wikipedia.org/wiki/Led_Zeppelin_Boxed_Set) [1:40:00]

**Second CD Peter every purchased**: [Chronicles](https://en.wikipedia.org/wiki/Chronicles_(Rush_album)) by [Rush](https://en.wikipedia.org/wiki/Rush_(band)) [1:40:30]

§

### **ARTISTS/BANDS/PEOPLE MENTIONED**

- [The Band](https://en.wikipedia.org/wiki/The_Band) (Rick’s studio was built for them in 1974) [7:45]
- [Bob Dylan](https://en.wikipedia.org/wiki/Bob_Dylan) (Rick’s studio was built for them in 1974) [7:45]
- [Run-DMC](https://en.wikipedia.org/wiki/Run-DMC) (Def Jam big hit hip hop group) [12:00, 19:30]
- [LL Cool J](https://en.wikipedia.org/wiki/LL_Cool_J) (early Def Jam client) [12:15]
- [Beastie Boys](https://en.wikipedia.org/wiki/Beastie_Boys) (Rick’s client, help with their song lyrics) [12:15, 23:15, 35:45, 57:30, 1:38:00]
- [Larry Smith](https://en.wikipedia.org/wiki/Larry_Smith_(producer)) (producer for Run-DMC) 12:45
- [Russell Simmons](https://en.wikipedia.org/wiki/Russell_Simmons) (co-founder of Def Jam) [12:45, 19:45, 26:45, 30:15, 38:45]
- [Ad-Rock](https://en.wikipedia.org/wiki/Ad-Rock) (Aka Adam Horovitz, Beastie Boys) [14:00, 25:30, 49:30]
- [Kurtis Blow](https://en.wikipedia.org/wiki/Kurtis_Blow) (first big rapper who Russell managed) [19:45]
- [N.W.A](https://en.wikipedia.org/wiki/N.W.A) (another breakthrough hip hop group, from California) [20:30]
- Mark Silas (8th grade friend of Peter’s who had turntables, Peter lost contact with him… *anyone know him?*) [21:45]
- [Laird Hamilton](https://en.wikipedia.org/wiki/Laird_Hamilton) (pro surfer and Rick’s trainer who really “changed my life”) [25:00, 2:05:30, 2:23:15]
- [Adam Yauch](https://en.wikipedia.org/wiki/Adam_Yauch) (Beastie Boys) [26:45]
- [Mike D](https://en.wikipedia.org/wiki/Mike_D) (Beastie Boys) [26:45]
- [Elvis Presley](https://en.wikipedia.org/wiki/Elvis_Presley) [36:00]
- [Chuck Berry](https://en.wikipedia.org/wiki/Chuck_Berry) [36:00]
- [Little Richard](https://en.wikipedia.org/wiki/Little_Richard) [36:00]
- [Lyor Cohen](https://en.wikipedia.org/wiki/Lyor_Cohen) (manager for the Beastie Boys) [38:45]
- Michael Jackson (someone who might get a higher % of the rev from record sales) [41:15, 59:15]
- [Danzig](https://en.wikipedia.org/wiki/Danzig_(band)) (first few clients Rick got after leaving Def Jam) [42:30]
- [Slayer](https://en.wikipedia.org/wiki/Slayer) (first few clients Rick got after leaving Def Jam) [42:30]
- [Nirvana](https://en.wikipedia.org/wiki/Nirvana_(band)) (seismic shift in music, pain and suicide in artists) [43:00]
- [Aerosmith](https://en.wikipedia.org/wiki/Aerosmith) (Rick’s client) [43:15]
- [Black Sabbath](https://en.wikipedia.org/wiki/Black_Sabbath) (client of Mo Ostin with Warner Bros) [43:15, 2:01:00]
- [Soundgarden](https://en.wikipedia.org/wiki/Soundgarden) (Rick’s favorite band from the grunge movement) [43:30]
- [Chris Cornell](https://en.wikipedia.org/wiki/Chris_Cornell) (formerly with Soundgarden, Rick got him to join up with the Rage Against the Machine group to form the new group called Audioslave, Chris is now deceased which was tough on Rick) [43:45, 1:22:45]
- [Audioslave](https://en.wikipedia.org/wiki/Audioslave) (band Rick helped put together) [43:45]
- [Metallica](https://en.wikipedia.org/wiki/Metallica) (rock and roll) ro[44:00]
- [Guns N’ Roses](https://en.wikipedia.org/wiki/Guns_N%27_Roses) (rock and roll) [44:00]
- [Pearl Jam](https://en.wikipedia.org/wiki/Pearl_Jam) [44:15]
- [Red Hot Chili Peppers](https://en.wikipedia.org/wiki/Audioslave) (Rick’s client) [45:45, 1:01:30]
- [D’Angelo](https://en.wikipedia.org/wiki/D%27Angelo) (artist who made the album called Voodoo, which is Rick’s favorite) [53:15]
- [Questlove](https://en.wikipedia.org/wiki/Questlove) (drummer in Voodoo album – Rick’s favorite album) [53:15]
- [Malcolm Gladwell](https://en.wikipedia.org/wiki/Malcolm_Gladwell) (co-host of Rick’s podcast called Broken Record) [55:30]
- [James Blake](https://en.wikipedia.org/wiki/James_Blake_(musician)) (Rick loved his first album…“Beautiful”) [57:00]
- [Jimi Hendrix](https://en.wikipedia.org/wiki/Jimi_Hendrix) (music Peter loves) [57:30, 2:01:00]
- [The Doors](https://en.wikipedia.org/wiki/The_Doors) (Band Peter lovess) [57:30]
- [Kurt Cobain](https://en.wikipedia.org/wiki/Kurt_Cobain) [58:30, 1:10:00]
- [Madonna](https://en.wikipedia.org/wiki/Madonna_(entertainer)) [59:45]
- [Flea](https://en.wikipedia.org/wiki/Flea_(musician)) (bassist for RHCP, open about his struggles) [1:01:30]
- [Anthony Kiedis](https://en.wikipedia.org/wiki/Anthony_Kiedis) (lead vocalist for RHCP, open about his struggles) [1:01:30]
- [Mac Miller](https://en.wikipedia.org/wiki/Mac_Miller) (artist that Rick worked with that died too young) [1:02:15, 1:22:30]
- [N.W.A](https://en.wikipedia.org/wiki/N.W.A) [1:06:00]
- [Public Enemy](https://en.wikipedia.org/wiki/Public_Enemy_(band)) [1:06:30]
- [Chuck D](https://en.wikipedia.org/wiki/Chuck_D) (Public Enemy) [1:07:15]
- [Flavor Flav](https://en.wikipedia.org/wiki/Flavor_Flav) (Public Enemy) [1:07:30]
- [Motley Crue](https://en.wikipedia.org/wiki/M%C3%B6tley_Cr%C3%BCe) (The Dirt documentary) [1:08:15]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) [1:09:45]
- [Chester Bennington](https://en.wikipedia.org/wiki/Chester_Bennington) (Linkin Park, died too young, client of Rick) [1:23:00]
- [Linkin Park](https://en.wikipedia.org/wiki/Linkin_Park) (Rick produces several albums for them) [1:23:00]
- [Johnny Cash](https://en.wikipedia.org/wiki/Johnny_Cash) (Rick worked with Johnny until he passed away) [1:23:45]
- [Phil Maffetone](https://twitter.com/drphilmaffetone?lang=en) (doctor that help Rick become healthy and changed his life) [1:23:45, 1:43:15]
- [Joaquin Phoenix](https://en.wikipedia.org/wiki/Joaquin_Phoenix) (played Johnny Cash in Walk the Line) [1:25:15]
- [Nine Inch Nails](https://en.wikipedia.org/wiki/Nine_Inch_Nails) (Johnny Cash did a cover of their song) [1:26:45]
- [Trent Reznor](https://en.wikipedia.org/wiki/Trent_Reznor) (lead vocalist of Nine Inch Nails) [1:27:15]
- [Nick Cave](https://en.wikipedia.org/wiki/Nick_Cave) (his song called The Mercy Seat was covered by Johnny Cash which meant a lot to Johnny) [1:31:00]
- [Sheryl Crow](https://en.wikipedia.org/wiki/Sheryl_Crow) (song called Redemption Day was covered by Johnny Cash which meant a lot to Johnny) [1:31:00]
- [Bono](https://en.wikipedia.org/wiki/Bono) (he was moved by Johnny’s version of his song called One) [1:31:45]
- [Don Henley](https://en.wikipedia.org/wiki/Don_Henley) (really liked Johnny’s version of his song called Desperado) [1:31:45]
- [Tom Morello](https://en.wikipedia.org/wiki/Tom_Morello) (Peter’s twin) [1:33:00]
- [Rage Against the Machine](https://en.wikipedia.org/wiki/Rage_Against_the_Machine) (another transformative band that Rick worked with) [1:34:30]
- [Zack de la Rocha](https://en.wikipedia.org/wiki/Zack_de_la_Rocha) (Rage Against the Machine) [1:34:30]
- [Perry Farrell](https://en.wikipedia.org/wiki/Perry_Farrell) (from Jane’s Addiction, the person who told Rick to go see Rage Against the Machine) [1:36:00]
- [Led Zeppelin](https://en.wikipedia.org/wiki/Led_Zeppelin) (Peter and his daughter listen and obsess over Zeppelin) [1:39:30]
- [John Bonham](https://en.wikipedia.org/wiki/John_Bonham) (drummer that Peter and his daughter love) [1:39:30]
- [Taylor Swift](https://en.wikipedia.org/wiki/Taylor_Swift) [1:41:15]
- [Mo Ostin](https://en.wikipedia.org/wiki/Mo_Ostin) (ran Warner Brothers Records, sent Rick to see his nutritionist) [2:00:45]
- [Frank Sinatra](https://en.wikipedia.org/wiki/Frank_Sinatra) [2:01:00]
- [Sex Pistols](https://en.wikipedia.org/wiki/Sex_Pistols) [2:01:00]
- [Dr. David Heber](https://www.uclahealth.org/david-heber) (nutritionist that help Rick to finally lose weight) [2:01:00, 2:07:00]
- [Don Wildman](https://www.xptlife.com/don-wildman/) (owned Bally’s, friend and workout partner of Rick and Laird Hamilton) [2:05:45]
- [Bob Peters](https://www.mrict.com/staff.asp) (radiologist who did the MRI on Rick’s heart and alerted them about the severity of the situation) [2:26:15]
- [Arnold Schwarzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger) (had a bicuspid aortic valve and needed surgery) [2:31:30]
- [Dr. Joseph Woo](https://profiles.stanford.edu/joseph-woo) (doc who did surgery on Rick’s heart) [2:40:00]
- [Randy Green](https://www.upstate.edu/cardiacsurgery/team.php?empID=greeng) (cardiac surgeon who connected Rick and Dr. Woo) [2:40:15]
- [Alejandro Junger](https://www.facebook.com/drjunger/) (wrote the book [Clean](https://www.amazon.com/Clean-Expanded-Revolutionary-Program/dp/0062201662)) [2:42:30]
- Mourielle Hurtado Herrera (Rick’s fiance) [2:43:30]
- [Francisco Gonzalez-Lima](https://liberalarts.utexas.edu/psychology/faculty/fg) (methylene blue) [2:48:15]
- [Dr. Jack Kruse](https://jackkruse.com/about-dr-jack-kruse/) (methylene blue) [2:49:00]

§

### **OTHER RELEVANT LINKS**

**Record company co-founded by Rick:** [Def Jam Recordings](https://en.wikipedia.org/wiki/Def_Jam_Recordings) [4:15, 31:15, 39:45]

**In 2007 in appeared on Times 100 most influential people in the world:** [The 2007 Times 100](https://content.time.com/time/specials/2007/completelist/0,29569,1595326,00.html) | (times.com) [5:00]

**Rick’s studio originally built for The Band and Bob Dylan in 1974:** [Shangri La Studio tour from Zane Lowe](https://www.youtube.com/watch?time_continue=22&v=0XetG_YqjTw) | BBC Radio 1 (youtube.com) [7:45]

**A film of the concert by The Band on Thanksgiving Day 1976 which showed scenes of Shangri La Studio:** [The Last Waltz](https://en.wikipedia.org/wiki/The_Last_Waltz) | (wikipedia.org) [7:45]

**Movie about the early days of Def Jam Recordings:** [Krush Groove](https://en.wikipedia.org/wiki/Krush_Groove) | (wikipedia.org) [12:15, 28:30]

**Popular hip hop club of the 1980s in NYC:** [Roxy NYC](https://en.wikipedia.org/wiki/Roxy_NYC) | (wikipedia.org) [18:00]

**Club where Rick and Ad-Rock came up with lyrics for Beastie Boys songs:** [Danceteria](https://en.wikipedia.org/wiki/Danceteria) **|** (wikipedia.org) [25:15]

**Record company that partnered with Def Jam:** [Columbia Records](https://en.wikipedia.org/wiki/Columbia_Records) | (wikipedia.org) [29:30]

**Record company Rick started after leaving Def Jam:** [American Recordings](https://en.wikipedia.org/wiki/American_Recordings_(record_label)) **|** (wikipedia.org) **[39:45]**

**Record company who signed Red Hot Chili Peppers before they came over to Rick:** [EMI Records](https://en.wikipedia.org/wiki/EMI_Records) | (wikipedia.org) [49:30]

**Rick’s podcast with co-host Malcolm Gladwell:** [Broken Record](https://brokenrecordpodcast.com/) | (brokenrecordpodcast.com) [55:30]

**Documentary about Michael Jackson’s preparation for his last tour**: [Michael Jackson’s This Is It](https://en.wikipedia.org/wiki/Michael_Jackson%27s_This_Is_It) | (wikipedia.org) [59:15]

**Movie about Motley Crue:** [The Dirt](https://en.wikipedia.org/wiki/The_Dirt_(film)) **|** (wikipedia.org) [1:08:15]

**Depression medicine that Rick mentions:**

- [Prozac](https://en.wikipedia.org/wiki/Fluoxetine) [1:17:15]
- [Paxil](https://en.wikipedia.org/wiki/Paroxetine) [1:18:15]
- [Remeron](https://en.wikipedia.org/wiki/Mirtazapine) [1:19:45]

**Movie about Johnny Cash starring Joaquin Phoenix**: [Walk the Line](https://en.wikipedia.org/wiki/Walk_the_Line) | (wikipedia.org) [1:25:15]

**Video of Johnny Cash doing the cover for Hurt which Trent didn’t like until he saw this video**: [Johnny Cash – Hurt (Official Video) HD](https://www.youtube.com/watch?v=vt1Pwfnh5pc) | DFTranslateBR (youtube.com) [1:28:00]

**Video that Peter’s son is convinced is Peter playing the guitar but it is actually Tom Morello doing The Ghost of Tom Joad, circa 2009, Madison Square Garden**: [Bruce Springsteen w.Tom Morello – Ghost of Tom Joad – Madison Square Garden, NYC – 2009/10/29&30](https://www.youtube.com/watch?v=n-mq0uJ7rlM&feature=youtu.be&t=397) | Zarastro1040 (youtube.com) [1:33:00]

**Club on Sunset Blvd where Rick saw Rage Against the Machine play prior to their first album**: [Coconut Teaszer](https://ipfs.io/ipfs/QmXoypizjW3WknFiJnKLwHCnL72vedxjQkDDP1mXWo6uco/wiki/Coconut_Teaszer.html) | (ipfs.io) [1:35:30]

**Peter’s salmon recipe:** [Peter’s family recipe](https://mailchi.mp/attiamedical/180805-420025) | Peter Attia (peterattiamd.com) [1:51:15]

**Protein shakes that Rick lived on during his calorie cutting days with Dr. Heber**: [Jay Robb egg protein shakes](https://www.jayrobb.com/products/) **|** (jayrobb.com) [2:02:45]

**Surfing documentary featuring Laird Hamilton**: [Riding Giants](https://en.wikipedia.org/wiki/Riding_Giants) | (wikipedia.org) **[2:11:45]**

**Men’s journal article about Rick**: [The Rebirth of Rick Rubin](https://www.mensjournal.com/entertainment/the-rebirth-of-rick-rubin-20131113/) | Stephen Rodrick (mensjournal.com) [2:24:15]

**Book by Dr. Junger**: [Clean — Expanded Edition: The Revolutionary Program To Restore The Body’s Natural Ability To Heal Itself](https://www.amazon.com/Clean-Expanded-Revolutionary-Program/dp/0062201662) by Alejandro Junger (amazon.com) [2:42:30]

**The Drive episode about Alzheimer’s disease with Francisco Gonzalez-Lima**: [#38 – Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer’s disease treatment and prevention – is AD actually a vascular and metabolic disease?](https://peterattiamd.com/franciscogonzalezlima/) | Peter Attia (peterattiamd.com) [2:48:15]

**Tim Ferriss podcast episode with Rick which took place inside a sauna**: [Rick Rubin on Cultivating World-Class Artists (Jay Z, Johnny Cash, etc.), Losing 100+ Pounds, and Breaking Down The Complex (#76)](https://tim.blog/2015/05/15/rick-rubin/) | Tim Ferriss (tim.blog) [3:00:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/06/bio-pic-rick-rubin-500x500.jpg)

##### Rick Rubin

Rick is an American record producer and former co-president of Columbia Records. Along with Russell Simmons, he is the co-founder of Def Jam Recordings and also established American Recordings. With the Beastie Boys, LL Cool J, Public Enemy, Geto Boys, and Run-DMC, Rubin helped popularize hip hop music.

Rubin has also worked with artists such as AC/DC, Adele, Aerosmith, At The Drive-In, Audioslave, Black Sabbath, Coheed And Cambria, Damien Rice, Danzig, Dixie Chicks, Ed Sheeran, Eminem, Frank Ocean, Gogol Bordello, Jakob Dylan, Jay Z, Jake Bugg, James Blake, Joe Strummer, Johnny Cash, Jovanotti, Justin Timberlake, Kanye West, Kid Rock, Lady Gaga, Lana Del Rey, Linkin Park, Melanie C, Metallica, Mick Jagger, Neil Diamond, Rage Against the Machine, Red Hot Chili Peppers, Shakira, Sheryl Crow, Slayer, Slipknot, System of a Down, The Avett Brothers, The Black Crowes, The Cult, The Four Horsemen, The Mars Volta, The Smashing Pumpkins, Tom Petty and the Heartbreakers, Trouble, Type O Negative, Weezer, Dan Auerbach, The Black Keys and ZZ Top.

In 2007, MTV called him “the most important producer of the last 20 years”,[3] and the same year Rubin appeared on Time’s 100 Most Influential People in the World.

[wikipedia.org]