# #291 ‒ The role of testosterone in males and females, performance-enhancing drugs, sustainable fat loss, supplements, and more | Derek, More Plates More Dates Pt.2

**Source:** [https://peterattiamd.com/derekmpmd2/](https://peterattiamd.com/derekmpmd2/)

---

Derek is a fitness educator, the entrepreneur behind More Plates More Dates, and an expert in exogenous molecules commonly used and misused by bodybuilders and athletes. In this episode, Derek returns to the podcast to explore the impact of exogenous molecules on male and female health. He covers testosterone, DHT, DHEA, progesterone, clomiphene (Clomid), hCG, and various peptides, alongside updates from the FDA affecting peptide use. Additionally, he addresses the recent hype around increasing muscle mass through myostatin inhibition via follistatin gene therapy and supplementation. Additionally, Derek discusses the various strategies that bodybuilders use for losing fat while preserving muscle, including insights on weight loss drugs.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/derekmpmd2/the_Drive_public.png)

Play

#291 ‒ The role of testosterone in males and females, performance-enhancing drugs, sustainable fat loss, supplements, and more | Derek, More Plates More Dates Pt.2

#291 ‒ The role of testosterone in males and females, performance-enhancing drugs, sustainable fat loss, supplements, and more | Derek, More Plates More Dates Pt.2

1x15s30s

0:002:38:13

## We discuss:

- Testosterone and DHT: mechanisms of action, regulation of muscle growth, and influence on male and female characteristics [2:15];
- TRT in women: the complexities and potential risks associated with testosterone use in women [9:00];
- DHEA supplementation: exploring the benefits and risks for women, and the differing effects on men vs. women [22:00];
- The role of progesterone in both men and women, pros and cons of supplementation, the importance of tailored doses, and more [28:00];
- Measuring levels of free testosterone [37:15];
- The trend towards earlier interest in TRT, and the risks of underground sources of testosterone [42:00];
- The complexities and considerations surrounding the use of Clomid, E-Clomid, and hCG in TRT [46:00];
- Low testosterone: diagnosis, potential causes, treatment options, and other considerations [53:45];
- Growth hormone-releasing peptides: rationale and implications of the recent FDA categorization as high-risk substances [1:03:45];
- Follistatin gene therapy and myostatin inhibition for increasing muscle mass: the recent hype online, human and animal data, and the need for more research [1:14:45];
- Simple tips for lowering calorie intake and losing fat [1:32:30];
- Methods of sustainable fat loss with muscle preservation: insights gleaned from bodybuilders [1:40:00];
- Could prolonged fasting impact testosterone levels? [1:55:30];
- High-protein ice cream [1:57:00];
- Exploring fat loss supplements and drugs: L-carnitine, yohimbine, and more [2:02:15];
- Potential remedies for individuals experiencing metabolic dysfunction due to hypercortisolemia [2:12:30];
- The cornerstones of body composition improvement remain nutrition and exercise, even in the presence of exogenous testosterone [2:19:15];
- The importance of approaching health advice found online with a critical eye and a healthy dose of skepticism [2:23:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Derek from More Plates More Dates is a returning guest
  - The first episode ([#274](https://peterattiamd.com/derekmpmd/) in October of 2023) didn’t cover nearly as much as Peter would’ve liked so he’s back for round 2
- This conversation continues where we left off in the first discussion
- In this episode, we talk about a number of exogenous molecules that impact both male and female health, including: testosterone, DHT, DHEA, progesterone, Clomid, hCG, and various peptides
- We also talk about some updates from the FDA since our last conversation that impact the use of peptides
- We also touch on myostatin, follistatin, and more
- We cover various ways that bodybuilders will lose fat and weight while maintaining muscle
  - Including the various weight loss drugs that are available
- As a reminder, Derek is a fitness educator and entrepreneur behind the More Plates More Dates [YouTube channel](https://www.youtube.com/channel/UCoR7CHkMETs3ByOv74OAbFw), [podcast](https://moreplatesmoredates.com/podcasts/), and [companion website](https://moreplatesmoredates.com/)

## Testosterone and DHT: mechanisms of action, regulation of muscle growth, and influence on male and female characteristics [2:15]

- Last time we spoke, we covered a lot of ground, and yet somehow at the end of it, we felt like there was still a lot to talk about
- Hence we’re back
- Peter is going to do something unusual, which is he’s going to ask what Derek wants to talk about, as opposed to driving down his agenda
  - Peter has a bunch of things that he wants to talk about, but he’s curious as to where Derek thinks we should pick things up
- Derek thinks we covered a lot of stuff at a surface level and there might be some unanswered questions or ambiguity on some specifics when it comes to:
  - Am I a good candidate for hormone replacement?
    - How would I assess that?
  - Should I be worried before I get on it?
  - What kind of things should I look for?
- A lot of people don’t know who to trust or listen to
- Many people (including Peter) are teetering on the thought of exploring hormone replacement, and Derek wants to see what Peter’s thought process is for evaluating this

- It seems like in the last decade there’s been a lot more attention brought to the idea of testosterone replacement
- The role of testosterone as a drug of abuse in sports has tarnished in in a way that we don’t see on the female side
  - When we talk about hormone replacement for women with estrogen and progesterone, that doesn’t come with the same performance enhancing benefit
- Derek points out that it’s odd that testosterone is such a taboo thing when at the end of the day, it’s just a natural hormone that you produce

**Other differences in hormone replacement for men versus women**

- Estrogen and progesterone are not scheduled drugs
  - They’re hormones and you can prescribe them without any limitation
  - They’re unscheduled by the DEA
- Conversely, testosterone is scheduled and much more highly regulated
  - The suggestion here is there’s potential for abuse that we presumably don’t see with estrogen and progesterone

**Talk briefly about testosterone androgen receptors, how they work, the role of DHT, and what this does for muscle protein synthesis**

- Most people are aware of testosterone as the primary masculine hormone, but in reality, it’s produced in significant quantities in both genders
  - It’s just that men produce 10x that of women
- Both men and women also produce estradiol and DHT, but in different proportions and binding proteins
- At the end of the day, the action of these hormones in the body is the same in men and women
- Testosterone binds to the androgen receptor and induces gene expression
  - It causes muscle protein synthesis and other anabolic actions in the bone
  - It has psychoactive effects in the brain
- The only difference between the sexes is the magnitude to which this happen
- Testosterone also is what essentially determines how you sexually mature and differentiate as you enter adolescence
- You could realistically manually manipulate testosterone, and you see this in doping scenarios in sports and in bodybuilding males
- Ultimately, testosterone is the primary androgen that dictates muscle growth and anabolic activity in tissues, and the metabolites of it regulate a bunch of other things in the body

***Testosterone is the primary androgen that men and women alike rely on, just in differing amounts***

- We’ve discussed on the podcast [[episode #180](https://peterattiamd.com/ama28/)] in great detail mechanistically what happens when [testosterone](https://en.wikipedia.org/wiki/Testosterone) binds to the [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor) and how that gets into the nucleus and how it impacts gene transcription for translation of protein
- What’s interesting is that Derek mentioned [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone)
  - DHT has a significantly *higher* affinity for the androgen receptor

**Is there else you want to say about the role of DHT versus testosterone?**

- To elaborate on what the word androgen means, what you derive from androgens are masculine characteristics
- The further on this spectrum of androgenicity, the more masculine and [virilizing](https://en.wikipedia.org/wiki/Virilization) potentially in women it could be
- DHT is the hormone that drives this pathway to the extreme, and it is responsible (alongside testosterone) for maximal sexual differentiation maturation in adolescents
- Mutations in the gene that encodes [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase) (the enzyme that makes DHT) [affect the amount of DHT produced in the body]
  - Certain pseudo-hermaphrodites who don’t have DHT will end up lesser developed in the masculine spectrum than a normal functioning human with full DHT production
- One one end of the spectrum, you have males producing 10x the testosterone and also more DHT
- And then females much more estrogen proportionally to males (depending on where they’re at in their cycle) but 10x lower testosterone (and also much less DHT)

***The ratio of androgens to estrogen essentially dictates if you are going to have male characteristics or female characteristics, and how much those characteristics are going to be exaggerated***

- Even if you’re a fully grown female, if you expose yourself manually to these hormones, you could push yourself in that direction

***What a lot of people know about DHT: hair loss is a common side effect and it’s an important hormone that regulates how masculine you become as you grow up***

- There’s a critical window of exposure to DHT
  - Embryologically, exposure to testosterone and DHT have an enormous impact on sexual differentiation later in life

## TRT in women: the complexities and potential risks associated with testosterone use in women [9:00]

**Testosterone can be masculinization in women**

- Peter has a female patient who is on testosterone and for about a month, she didn’t read the directions correctly and was accidentally taking 10x the dose
  - It’s very easy to do because the doses are so small, and there’s no FDA approved women’s testosterone
  - This means she was taking a male physiologic dose of testosterone
  - The symptoms immediately said that something was going wrong
    - The first symptom she noticed was clitoral enlargement
    - The good news is it is completely reversible once the dose was restored to the 10th that it should have been
- Peter assumes that female bodybuilders routinely use doses of this nature
  - They are aware of the masculinizing potential, and for this reason some will avoid testosterone entirely
- Because testosterone is essentially equally as anabolic as it is androgenic

*This begs the question: why would you be using testosterone as a female if you’re trying to achieve super physiologic muscle growth?*

- In order to push it to that extent, you’re probably going to end up in the male characteristic territory
- Often, women will defer to compounds like [oxandrolone (brand name Anavar)](https://en.wikipedia.org/wiki/Oxandrolone) and sometimes [metenolone (brand name Primobolan)](https://en.wikipedia.org/wiki/Metenolone)
  - These are much more anabolic and much less androgenic

*Is a voice change potentially irreversible?*

- Yeah, you have to be super careful, even with TRT as a female
- A lot of the clinics nowadays will advertise and market testosterone in a way that highlights how great it is for libido, quality of life, glucose management, muscle growth
  - There’s a lot of things that sound attractive about it that are an easy sell to a female who may be asexual, in perimenopause or something
  - Derek has seen standards being promoted as cookie cutter: everyone should have a 200 ng/dL total testosterone (which is very high)
- Derek’s mom got on hormone replacement a few years back, and at the time, he wasn’t overseeing it
  - He just trusted the guy who was prescribing since he was experienced and credentialed
  - But within a couple of weeks, just picking up the phone, he almost didn’t recognize her
    - Her voice was skewing blatantly in the direction of a male, but she couldn’t really tell
  - He doesn’t remember what dose she was on; for compounding creams, it can vary
- There is one practitioner that promotes 200-300 total testosterone in females, which is insane
- We’ll come back and talk more about TRT

**The rationale is that testosterone is a very important hormone for women**

- There is no FDA approval for the use of testosterone in women
- Obviously, there is FDA approval for the use of estrogen and progesterone in women, and testosterone in men

***The thinking around testosterone use in women is that when she enters perimenopause, not only does she experience the predictable drop in estrogen and progesterone, but with it so too goes testosterone***

- As Peter has pointed out, the **units** that are used to represent estrogen and testosterone are very misleading because they’re not the same
  - If you convert them to the same units, you will see that even in a woman, her testosterone is significantly higher than her progesterone and estrogen
  - If you took a mid-follicular estrogen level (an estradiol level) and took it out of picograms per deciliter (pg/dL) and put everything in nanograms per deciliter (ng/dL), her testosterone as a premenopausal woman would be at least 10x and at times, even 50x higher
- So the idea is that losing a hormone that abundant must have ramifications
- Derek alluded to all the side effects, and so the thinking is, well, we should replace it

**To what level should testosterone be replaced in women?**

- Peter has never heard a compelling case for why it should be replaced to a level that exceeds her physiologic limit in her 30s, for example
- He’s never seen a woman in her 30s with a total testosterone between 200-300 ng/dL
  - In other words, those levels exceed even her peak physiologic level
  - So it doesn’t surprise him that that would be androgenizing women

*Do you have a sense of what their rationale is for going so high?*

- Their idea is simply that this is where we achieve blatant symptom relief in everyone, and a feeling of optimization above and beyond this is what it should feel like when you take hormone replacement
- Ultimately androgens feel pretty good if you were just crashed or very low, and then all of a sudden you’re essentially on the male proportional equivalent of a bodybuilder cycle or something

***Derek couldn’t say why they do it exactly, but all he knows is it’s too high, and it’s very common to have some of these [side effects]***

- If you’re not keeping a close eye on them, they can really, really snowball because when you’re seeing yourself in the mirror every day and you’re listening to yourself, you don’t really notice these little minute changes as much as somebody else
- Then you might meet up with a friend a month later, and they’re like, “*What the hell? You don’t even sound the same*.”

**Acne is another common symptom**

- Peter has seen this even at physiologic doses for women who are sensitive enough
- Let’s say the woman is 45 and she has almost unmeasurable levels of testosterone (in the 10-20 ng/dL range)
  - You didn’t know her when she was 30, so you don’t know what her physiological peak was
- You set a target of 80-100 ng/dL, which is in the ballpark of what would be 70th-80th percentile for woman her age
- But it turns out that she was probably lower than that because once you get her there her acne is out of control
- You would surmise from that: she must have lived at a lower level and for her 80 is super physiologic

***For this reason, Peter can’t imagine that they’re pushing women to 200-300 who are not developing horrible cystic acne and facial hair***

- Derek relates that some of them feel so much ‒ now they’re having sex multiple times a day even with their husband, who they didn’t want to touch a couple of months ago
- It’s a pretty big shift, and if they like what they’re getting out of it, sometimes compromises will be made in order to achieve that feeling
- Derek agrees with Peter that not knowing your prior testosterone level combined with how many people have been on combined oral contraceptives for decades, this furthers confounds things

**Oral contraceptives can totally skew everything**

- Derek has dated girls who have had 80% suppression of their hormone levels (free testosterone) especially because of the rise of [SHGB](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) (it goes through the roof)
- They’re operating in a state of [androgen deficiency](https://en.wikipedia.org/wiki/Androgen_deficiency) perpetually and relying on this synthetic progestin to drive all testosterone-like behavior essentially
- And then if they get off, they don’t even know what their natural is
  - They’ve never experienced it
  - They’ve been prescribed oral contraceptives since age 15 or 16
- It’s tough because you don’t even know what your ideal target is
- Even if you were getting blood work, oftentimes it’s totally skewed
- This is something Derek wants to talk about on his [podcast](https://moreplatesmoredates.com/podcasts/) too
  - Some of the testosterone suppression in different formats of birth control, because it’s pretty nebulous
- Derek is very aware of the data on combined oral contraceptives, but even the localized progestins and stuff, there’s very minimal literature (shockingly)
  - If he’s trying to find out how much [Mirena](https://www.mirena-us.com/) affects his girlfriend, he doesn’t know what her baseline was

**Have you been following the** [**Natesto product**](https://www.natesto.com/)**?**

- It looks good if you’re willing to tolerate it
- Natesto is an intranasal administration of testosterone
- Peter thinks the dose is 7 mg [the [prescribing information](https://www.natesto.com/pdfs/natesto-full-prescribing-information.pdf) says 1 pump delivers 5.5 mg]
- It’s used TID (3 times a day), which tells you that the bioavailability is quite low, if you’re taking 21 mg daily
  - That’s slightly more than you would probably take if you were just doing it intramuscularly
  - The idea with it is it’s quicker acting, and that’s why you have to take it 3x times a day
    - Because it’s not sticking around in a fat depot the way an injectable source would be

*The interesting question is, does this help address some of the female use cases?*

- For example, if one of the symptoms that a female is turning to testosterone for is libido, does she really need to be on mega doses of systemic testosterone around the clock versus in the same way a man would use [Cialis](https://en.wikipedia.org/wiki/Tadalafil) for an on-demand ED issue

*Could a woman be using intranasal testosterone for an on-demand libido issue?*

- Derek would hope that would be the case
- In practical application, he doesn’t know if it plays out that way
  - Could you just use it acutely once a week or something on the day you want to get busy?
- Derek has had some experimentation with it (with a female who has low testosterone) and it doesn’t seem to make that big of a difference
  - You wouldn’t expect it to make a difference in a male
  - But this is obviously a N of 1
- Derek hasn’t see this data in the literature and doesn’t know if it even exists
- Peter believes there is a clinical trial ongoing, maybe at Baylor, but he’s not sure
- Derek explains that as much as it sounds great, women typically don’t like using it because it’s messy and dripping down the back of their throat
  - It feels almost like a drug addict snorting something before you have sex every time
- Derek is skeptical that anyone is going to use it for more than a novelty once in a while
- Peter has never seen the product

*Is it particularly viscous, or is it like a nasal spray you would use for an antihistamine or something?*

- Derek has only had experience with a compounded replica of Natesto, and that product was not pleasant, it was almost creamy, not a spray
- Maybe the Natesto formula is more tolerable

## DHEA supplementation: exploring the benefits and risks for women, and the differing effects on men vs. women [22:00]

**A lot of Peter’s female patients are asking to be put on** [**DHEA**](https://en.wikipedia.org/wiki/Dehydroepiandrosterone)

- He’s not sure why this seems to be all the rave today because it’s been around forever
- DHEA is one of the few hormones that’s available over the counter (unique in the US)
- It’s not available over the counter in Canada ‒  there, it’s [schedule I](https://en.wikipedia.org/wiki/Controlled_Substances_Act#Schedule_I)
  - A schedule I means you’re doing something more illegal than having anabolic steroids
  - Peter is surprised by this because here you can buy it on Amazon
  - This makes no sense until you understand the dirty political story behind it
- Derek explains that there are some really backwards compound selections that are banned
  - For example, you can buy [ephedrine](https://en.wikipedia.org/wiki/Ephedrine) at GNC in Canada
    - Why? It’s literally used to make meth
    - In the US, it’s a lot harder to get ephedrine
  - But then you can get [yohimbine](https://en.wikipedia.org/wiki/Yohimbine) in the US, which is a fat burner (we’ll talk about it later)
    - And in Canada, it’s banned
  - Who’s selecting what gets banned?
- A lot of women are led to believe DHEA is the elixir of life
  - Presumably, they’re saying, “*If my DHEA levels are low, it could explain my low testosterone, and this is a ‘more natural’ way to increase my testosterone.*”
- Peter hasn’t seen any compelling data that DHEA does much of anything
  - He hasn’t looked in a decade, but when he looked then, he came to the conclusion DHEA didn’t do much

**What does the data say about DHEA?**

- If you look in **males**, you’ll find no utility
  - It has no effect on testosterone
  - At best, you get a spike in estrogen and no testosterone, seemingly through whatever backdoor
- Yet is is a [USADA](https://www.usada.org/athlete-advisory/key-changes-2024-prohibited-list/), [WADA banned drug](https://www.wada-ama.org/en/prohibited-list) ‒ it’s treated just like testosterone
- In **females**, it actually is useful and can increase testosterone to a degree

*There is a pretty wild* [*study*](https://www.contraceptionjournal.org/article/S0010-7824(18)30076-3/fulltext) *that Derek hasn’t seen anyone talk about*

- A few years ago, Derek was looking into because his girlfriend at the time was shut down to nothingness on a combined oral contraceptive
- He found some papers [[another study](https://www.contraceptionjournal.org/article/S0010-7824(16)30141-X/fulltext)] that showed using DHEA supplementation exogenously (50 mg a day) resulted in a full restoration of total and free testosterone levels while still using combined oral contraceptives
- To Derek, that’s pretty impressive for something that’s not a cream you have to apply, spray you have to put up your nose
- There are many different variants of combined oral contraceptives
  - Depending on the brand, you might have a progestin that’s more androgenic or one that’s less
  - Estradiol is or isn’t included
  - That will all vary

***In general, for the traditional, most commonly sold and prescribed combined oral contraceptives, DHEA restored total testosterone levels to that of baseline while staying on what is otherwise a brutally suppressive compound***

**Can you give a sense of what the increase in total T was?**

- It was like going from your natural 60 down to 15 then back up to 60
  - A 4x bump in total
  - [the figure from this [study](https://www.contraceptionjournal.org/article/S0010-7824(16)30141-X/fulltext#secst0075) is shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f1-derekMPMD2.png)

**Figure 1. Effect of adding DHEA to 2 different types of oral contraceptives on free testosterone levels in women**. Image credit: [*Contraception* 2016](https://www.contraceptionjournal.org/article/S0010-7824(16)30141-X/fulltext#secst0075)

**Why do you think women would be more sensitive to DHEA?**

- Probably because a significant amount of their androgen synthesis derives from adrenal hormone production as opposed to men
- It’s like if you castrate a guy, you can still squeak out 30-40 ng/dL (from  his adrenals)
  - For men, it’s like a drop in the bucket
- In females, it seems to be similar depending on the woman
  - But 30-40 out of her adrenals could be ¾ of her total testosterone

**Possible side effects of using DHEA in women who have natural levels that look pretty good**

- Let’s say you’re on hormone replacement and then you think you need DHEA for some subjective feeling of well-being
  - There’s no real biomarkers to reinforce that you’re deficient
  - Your DHEA-S looks normal, your testosterone looks okay, and there’s not really a clear reason, you just kind of think you need it
- Almost certainly the risk to reward is a little bit worse because ***acne on DHEA is very common in women*** to a degree where it’s like the proportional upside you get out of it
  - You’re not going to get as much anabolic activity out of it relative to seemingly the androgenicity impact at least in skin (from what Derek has seen)

**Is it correct that we don’t measure DHEA levels, we measure** [**DHEA sulfate**](https://en.wikipedia.org/wiki/Dehydroepiandrosterone_sulfate) **levels?**

- Yeah, that’s the only proxy in traditional blood work metrics that Derek is aware of to test for it
- Derek thinks the majority of it is sulfated, so getting a direct measurement of it is not indicative of the total body pool
- He wishes he had a good explanation but just knows that’s the proxy
- It’s kind of like why do we check for [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1#Use_as_a_diagnostic_test) for [GH](https://en.wikipedia.org/wiki/Growth_hormone)?

## The role of progesterone in both men and women, pros and cons of supplementation, the importance of tailored doses, and more [28:00]

**One thing Peter is doing a lot more of with female patients**

- He used to be pretty quick to abandon progesterone systemically if women were having any mood symptoms associated with a full dose (200 mg)
  - They would quickly adopt a [Mirena progesterone-coated IUD](https://en.wikipedia.org/wiki/Hormonal_intrauterine_device) to give the endometrial counterbalance to the estradiol to prevent the hyperplasia and reduce the risk of endometrial cancer with unopposed estrogen
- He was really seeing a lot of women in the middle ground who maybe can’t tolerate a full 200 mg dose of progesterone, but feel great at 50-100 mg
- And so in many ways, what we’re trying to do is just find every woman’s dose, and what’s the amount that you can tolerate?
  - If it’s sufficient, great
  - If it’s insufficient, we’ll backstop it with a Mirena

**Why do you think progesterone is so important for women?**

- If you look at a [steroidogenesis cascade](https://en.wikipedia.org/wiki/Steroid#Steroidogenesis) [shown in the figure below], which is in layman’s terms if you took cholesterol, and then all of the different things it could turn into when you cleave it, and through enzymatic pathways
  - Turn it into glucocorticoids
  - Or downstream to adrenal steroids
  - And downstream to testosterone and DHT and estradiol and estrone

![](https://peterattiamd.com/wp-content/uploads/2024/02/f2-derekMPMD2.png)

**Figure 2. Human steroidogenesis with the major classes of steroid hormones with changes in molecular structure from a precursor highlighted in white**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Steroid#Steroidogenesis)

- Steroidogenesis, the synthesis of all these steroid hormones in your body
- This chart is a big messy thing that has like 7,000 different pathways, and it looks overwhelming
- But up near the top where you start to have [cortisol](https://en.wikipedia.org/wiki/Cortisol) production, you have some of this stuff upstream for [glucocorticoids](https://en.wikipedia.org/wiki/Glucocorticoid), as well as where [pregnenolone](https://en.wikipedia.org/wiki/Pregnenolone) branches from to actual [androgens](https://en.wikipedia.org/wiki/Androgen) and upward to [adrenal hormones](https://en.wikipedia.org/wiki/Adrenocortical_hormone)
- At the top, you have this downstream cascade from [progesterone](https://en.wikipedia.org/wiki/Progesterone) that leads to an array of metabolite hormones that are [pro-anxiolytic](https://en.wikipedia.org/wiki/Anxiolytic) (they will be anti-anxiety) and they kind of balance out the sympathetic drive that you might get from androgens, and also help you get to sleep
  - That’s why progesterone is so useful at night and why it’s placed at that time for dosing
- Taking progesterone orally is impactful on the way it’s metabolized out to get some of these proportional metabolites
  - Because if you had it in a cream or an injection, not only is it maybe harder to get the dose you want out of it, but the metabolite content that you get is totally different when you have a [first-pass metabolism](https://en.wikipedia.org/wiki/First_pass_effect)
- With progesterone in particular, it produces an array of different things, including but not limited to one is [allopregnanolone](https://en.wikipedia.org/wiki/Allopregnanolone), which is seemingly implicated to some extent in [post-finasteride syndrome](https://en.wikipedia.org/wiki/Finasteride#Post-finasteride_syndrome), but also very much in [postpartum depression](https://en.wikipedia.org/wiki/Postpartum_depression)
  - They’ve even created a [synthetic analog of allopregnanolone](https://www.sciencedirect.com/science/article/abs/pii/S2451965022000254#:~:text=Brexanolone%2C%20a%20synthetic%20intravenous%20formulation,3%2C29%2C30%5D.) now that they use to treat postpartum depression

***All of those different metabolites cumulatively, if you are deficient in some amount of them, it could result in a more anxious human than otherwise***

- Depending on the individual’s biochemistry and genetic predispositions

***Derek would expect the dose required to balance out the androgenic signaling relative to all this other stuff going on to vary quite significantly from female to female***

- Especially when you are back filling hormones from a shutdown state, it’s not endogenously regulated the same way when you have feedback mechanisms
- You’re kind of just manually shooting stuff at your liver and hoping it’s going to spit out the right amount of stuff, and you can only really do that through some sort of titration/ experimentation

**Derek would expect there are 3 possible outcomes**

- 1 – A lot of women would need a dose that is *far less* that what seems to produce repeatable outcomes in the literature to achieve the outcome they want
- 2 – Or need a dose *much higher*
- 3 – Or perhaps they don’t respond at all because it’s not what they need

**Is there a role for progesterone use by men?**

- It definitely does *not* have an approved use in men
- There’s *no* literature that points to it as this is something you should use in men
- Derek does believe (and sees it played out) that it could be useful to balance out some of that sympathetic drive and whatnot
  - You could look at blood work and see: in your minimal negligible amount, should you be pushing that to the top of the negligible amount that is your threshold?

**What doses do you see men using?**

- The same doses [as for women] 50-200 mg

*What are the side effects of that?*

- If you are not on exogenous hormones, it does have [negative feedback](https://en.wikipedia.org/wiki/Negative_feedback#Biology)
- Most people are very familiar with how estrogen has negative feedback to the hypothalamus pituitary testicular axis and testosterone through androgen receptors
  - [Discussed in [episode #256](https://peterattiamd.com/endocrinesystem/), see “The male sex hormone system”]
  - But what often goes overlooked is some of the other hormones like progesterone
- Progesterone isn’t as potent of a negative feedback regulator, but it definitely is and it seems to maybe even have anti-androgenic activity as well
  - Derek doesn’t recall if it does that through [competitive inhibition](https://en.wikipedia.org/wiki/Competitive_inhibition)
  - It does seem to produce anti-androgen-like effects, and some of it may be mediated through negative feedback and some of it may be inhibited through actual transcriptional activity

***Ultimately it’s something that will lower your ability to have androgen-like effects in the body to some extent***

*What if you’re on TRT?*

- It doesn’t matter because you’re already shutdown

*What would be the benefits of adding progesterone when you’re on TRT? What is it helping you balance out?*

- It’s common to see disproportionately high free androgen levels in men
- A lot of guys will look at their total testosterone, their free testosterone, their SHBG

***But what often goes overlooked is SHBG binds DHT at a higher affinity than testosterone (5x-10x, but whatever it is, it’s much higher)***

- Think of the ratio of DHT testosterone to estrogen that’s freely circulating
- The primary regulating mechanism that determines how male you are essentially is  SHBG (besides the actual production of the hormones)
- But DHT gets bound up with 5x higher affinity than testosterone (which is 20x higher than estrogen)
- So if you have that regulatory framework driven down through either a dose of testosterone that is higher than you need or a super infrequent dosing pattern that results in a disproportionate drop on certain days (or an array of different things), ***you could end up in this free androgen dominant environment where your sympathetic drive is keyed up perpetually***
- And because you have a long ester compound in your system, you don’t have the luxury of endogenous manipulation of your hormones going up when you need them and down when you need them
  - The pulsatile framework of your natural production is non-existent
  - You’re just getting a big spike whenever you inject and then it’s slowly going to diminish out of your system until you want to inject again
    - A lot of guys, even when they’re doing twice a week or something, you’re still getting some level of spike and then dips and then spike and dips where if you were natural with normal natural testosterone production, it would be very pulsatile with a [diurnal](https://en.wikipedia.org/wiki/Diurnal_cycle) rhythm with natural dips and valleys and peaks and it would not fluctuate where it’s like bam, bam
    - And if you look at a steroid plotter, you can kind of see how this looks and you want to compare a steroid plotter to your actual rhythm naturally ‒ it’s not really the same
- That’s where you get into the idea that more frequent dosing might be better
- At the end of the day, a lot of people are overlooking how dominant the free androgen profile could be in a guy on TRT because you’ll see your total testosterone and it might be 700 when you measure it, but you’re measuring it 3 days after your injection
  - You’re looking only at free testosterone
  - Your DHT has not been evaluated
  - Your free DHT surely hasn’t been evaluated
- Derek doesn’t necessarily think everyone has to spend hundreds of dollars to check those, but ***just be aware that if your SHBG is lower than it was before you started TRT, there is a disproportionate regulating mechanism in play here now***
  - Perhaps you have to account for if you’re in a state of anxiety
  - That might be a factor or if you have trouble getting to sleep

## Measuring levels of free testosterone [37:15]

**Peter was unaware that the is a direct way to measure free testosterone**

- Usually free testosterone is calculated
- Peter asks, “*Do you look at the free androgen index where you’re just taking the ratio of testosterone to SHBG?*”
  - Are you taking the ratio of 2 things that are directly measured?
    - Is that a better proxy for what’s happening physiologically than this indirect calculation of free testosterone?
- If Peter’s memory serves him correctly, free testosterone is a calculation based on testosterone, SHBG, and albumin
  - He asks, “*Is there anything else that factors into it?*”

***Derek is pretty sure that the free direct measurement via*** [***LabCorp***](https://www.labcorp.com/tests/500726/testosterone-free-mass-spectrometry-equilibrium-dialysis-endocrine-sciences) ***is just based on those binding proteins, but with equilibrium dialysis, it is separating it and measuring it directly***

- Equilibrium dialysis is just more cost prohibitive
- The good news is a lot of these tests when they evaluate them against it as a gold standard track pretty closely with it, so you can use them as proxies that are relatively accurate
  - It does get skewed when you get into trying to measure hypogonadal men that might have lower concentrations and you want to make sure you get it right
- It’s not just tracking trends as much or individuals who are using synthetic androgens
- It will for sure cross detect if you’re using a immunoassay or a calculation because it’s going to be based on the cross detection of the total testosterone presumably

***In general, if you wanted to use the gold standard, it would be equilibrium dialysis***

- Derek doesn’t know if it’s always necessary
- However, at baseline measurement for people who are trying to get as ideal and accurate of blood work as possible, he would typically always go with the highest sensitivity
- It’s not like it was wildly different on some of the metrics, but it was significant enough

**Peter’s last blood test for testosterone and estradiol**

- He had LabCorp run both the immunoassay (which is *not* the gold standard, but is the cheaper test) and the LCMS (which is the gold standard)
- The enzyme-based immunoassay for testosterone was *502*
  - The immunoassay says Roche ECLIA right beside it (Roche is the company that provides the assay for LabCorp)
- The LCMS for testosterone was *381*

***That’s a 25% difference, significant enough to justify getting the LCMS test***

- The LCMS is the only test that Peter uses, but he wanted to see what the difference was

*What was more telling was the estradiol*

- Estradiol on the LCMS (more accurate test) was 18.3
- Estradiol on the enzyme-based test was 41.3
  - That’s more than a 2x difference
- Derek add that the enzyme-based testing will cross detect estrone and synthetic estrogens as estradiol
- Peter still thinks his value seems really high given that his estrone and estriol should be very low
  - And he’s not taking any synthetic estrogens

*Why do you think estradiol is off by more than 2x?*

- Peter sees this in other patients as well
- That would be tough for Derek to speculate without seeing the full gamut
- Peter thinks it’s picking up something in his supplements
- Peter has never taken [biotin](https://en.wikipedia.org/wiki/Biotin) but he does take methylated B vitamins
  - Maybe biotin is in his B complex in tiny amounts
    - Derek says this will still mess with it

**Stuff you should not take before your test**

- Biotin is one
  - It skews thyroid values pretty dramatically as well
  - Stop taking it a week before your blood test
- Derek checked with his team ([Marek Health](https://marekhealth.com/)) and they don’t know anything either

## The trend towards earlier interest in TRT, and the risks of underground sources of testosterone [42:00]

- It seems to Peter that younger and younger men are seeking out testosterone replacement therapy

**Is there any data on that or is that just a perception?**

- You’re right, as far as marketing efforts and exposure, if you look at Google Trends and type in TRT, the graph of how many searches are on Google has skyrocketed over the past decade [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f3-derekMPMD2.png)

**Figure 3. Google searches for TRT over the last decade**. Image credit: [Google Trends](https://trends.google.com/trends/explore?date=2014-01-11%202024-01-11&geo=US&q=trt&hl=en)

**Where do most men get their TRT?**

*How much of it is done from an endocrinologist (someone who presumably spent a lot of time understanding the system) and how much of it is done from clinics that only do testosterone (as the other extreme example)?*

- This is tough to answer because countries will differ in their scrutiny on this stuff
- In the US, Derek speculates that the underground market is still the most easily accessible and cheapest
  - With the advent of internet e-commerce stores, it’s not that difficult to find a website that sells testosterone or other anabolics and get some Bitcoin and buy it
  - There’s a lot of people that will get it from their gym bros or online
  - It’s very accessible now
- On the cost side, aside from the prescription barrier of finding a doctor who you actually think will give you the prescription and not necessarily knowing when you go into that consultation or that they’re going to be the flexible doctor that you need
- It’s just easier for a lot of guys to get it black market
- At least in the fitness industry, there’s a significant amount of guys that are suppressed from their hormone use that will be on TRT underground
  - The majority of them are on not scripted TRT
    - Even from lenient telemed clinics
  - A majority are still using underground

**Presumably crypto is what enables that because otherwise the DEA would shut these things down**

*Or is it too much of a game of whack-a-mole or there’s too many of these around?*

- There’s a lot that sell a volume that presumably is not significant enough to focus on
- Or it’s so hard to track because even if you shut 1 down, another one pops up
- It’s based in a country that is not in the US supposedly, and they drop ship it
  - They use crypto, so it’s harder to track the currency

**What kind of testosterone are these guys getting? Are they getting branded depot testosterone or some knockoff from China?**

- Often it’s underground, but there are resellers of pharmaceutical grade too
- Sometimes these guys will have connections with people in Europe, in certain countries where you can just walk into a pharmacy and buy whatever you want for 1/10th of the price
  - And then they will mark it up and then sell it to you in the U.S.
- There’s an array of different options, but typically it is a underground lab that is producing it and making what they’re advertising as an accurately-dosed sterile product that is branded under their underground lab brand

**For folks that want to do this in a little bit more of a responsible way and go and see a doctor**

- There are a lot of these doc-in-the-box operations where they’re basically just “T-docs”
- Peter doesn’t know how they’re operating
  - He assumes that a lot of this is telemedicine
  - He doesn’t know how much longer that will be in existence
    - He believes that a lot of that stuff’s going to be shut down

## The complexities and considerations surrounding the use of Clomid, E-Clomid, and hCG in TRT [46:00]

**Is there anything else you want to say on the** [**Clomid**](https://en.wikipedia.org/wiki/Clomifene)**,** [**E-Clomid**](https://en.wikipedia.org/wiki/Enclomifene)**,** [**hCG**](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin)**,** [**T**](https://en.wikipedia.org/wiki/Testosterone) **trade-offs?**

- When you are trying to restore **fertility** in the short-term and you’re reversed your injections, there’s a lot of factors that could lead Derek to say Clomid might be viable
- In general, if you’re looking at something long-term, he would say typically Clomid or [Enclomifene](https://en.wikipedia.org/wiki/Enclomifene) (which is a more progressive version of the drug but not FDA-approved)
- Neither of those are viable long-term, at least from a risk perspective
  - You are essentially putting yourself in a position of **long-term estrogen receptor antagonism** in certain tissues
    - Meaning you’re going to be missing out on estrogen receptor activity in certain areas of your body that down the line that could manifest in an array of issues
- If you look at the **side effects of serums**, you’ll see weird stuff depending on the compound
  - Sometimes it’s ocular issues

*What do we know about the long-term use of Clomid?*

- Peter points out that we have more data for Clomid than we do Enclomifene (a close derivative of Clomid), but they both work in the same way
  - They both block the estradiol receptor of the hypothalamus
- And then the [zuclomiphene](https://en.wikipedia.org/wiki/Zuclomifene) component of Clomid has two drugs essentially in it, and Derek thinks that component of it is more antigonadotropic
- The enclomifene component is far more specific to the serum activity you are seeking in the hypothalamus
- The zuclomiphene is longer half-life, less efficacious, doesn’t even really represent the target therapy of the drug
- In general, if you’re looking at Clomid, that’s the only one that has approval where you would potentially have the data
- Off the top of his head, Derek doesn’t know of any studies that are going decades long to evaluate something like that
  - He would be doubtful it exists
- From what Derek has seen anecdotally, typically no one ends up with a stable **mood** long term

***It’s not a sustainable therapy long-term for the vitality component you seek from replacement therapy***

- Perhaps on paper your testosterone looks good, but it’s more of a metric that you’re using to justify the drug because you are achieving the target
- Look your testosterone’s better now, but at the expense of literally tricking your brain through inhibiting very, very necessary mechanisms
- It’s not like you are stimulating production through a means that is directly targeted
- It is more like you are trading off the health of one part of your body to get an outcome that is potentially ROI-justifying in another aspect of your body

***You’re getting more testosterone at the expense of estrogen receptors working everywhere in the body***

**Is it blocking estrogen receptors everywhere or just centrally?**

- It is selective, but it’s not perfect (as they discussed last time in [episode #274](https://peterattiamd.com/derekmpmd/))
- If you Google “Clomid side effects,” you’ll see an array of different things including, but not limited to skewing of lipid parameters
  - [Desmosterol](https://en.wikipedia.org/wiki/Desmosterol)
  - Derek wouldn’t want to have that long term
- There’s stuff you’d have to track that are very unknown variables
- At least we kind of know what to expect when you have natural testosterone increasing
  - What happens at a lipid perspective or a negative feedback perspective
  - You’re not dealing with some nebulous activity in different tissues and having to account for it

***Actual brain inhibition is sketchy, and from what Derek has seen people end up not in a good state of mind when on it long-term***

**What doses are you seeing people use in the wild?**

- Around 50 mg daily
- In the bodybuilding world, Derek spoke previously about the absurd PCT regimens (post-cycle therapy) where guys are using 100 mg per day for shorter time frames (super high doses)
- Peter thinks we’re going to see a big increase in the use of Clomid and E-Clomid, even beyond what we’re seeing now just based on the regulatory environment
  - Which is to say that there will be no use of telemedicine for the prescription of any scheduled compounds such as testosterone and hCG (which we’ll talk about later)
    - If you’re adhering to the law, these can only be prescribed in person
  - Whereas via telemedicine, you could still use Clomid or potentially E-Clomid
- The implications of understanding this are actually pretty significant, and Peter would really like to see this studied better because **everything about Clomid is easier to use**
  - You’re going to get over the regulatory issue
  - It’s oral, it’s a pill, you don’t have to inject it
- [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin), as we’ve talked about, is a bit more difficult to use because it needs to be refrigerated
  - It’s a very fragile peptide
  - It’s probably more expensive than both testosterone and Clomid put together

**Anything you want to just say about hCG that we didn’t cover last time?**

- Derek explains, “*I think that if you were looking to restore natural production or assess your testicular response in general before you decide to go down the TRT pathway, it could be a worthwhile thing to do. So if you’re considering TRT, you have a total testosterone of 300 and you’re symptomatic.*”
  - You don’t remember the last time you had morning wood, your energy levels are much lower, it’s much more difficult to retain muscle, etc.

*Actually looking at your blood work to assess what is the release from your pituitary down to your gonads to actually produce the testosterone, what is that signal and is it sufficient?*

- Are you in the range of high normal?
- What does your [luteinizing hormone (LH)](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) look like are your blood work?
  - And if it looks to be adequate (or even high) that would be even more indicating if something’s wrong
  - You could determine from there, why your testes not responding to it
- Peter points out that Clomid gives you 2 pieces of information: it tells you the pituitary response and the gonadal response
- **hCG** will only give you the gonadal response
  - You’re not getting any pituitary information out of it other than the shutdown, but that’s not real, it’s obvious
- As far as interpreting the blood work to understand what **luteinizing hormone (LH)** even does: in general, you would be looking to your response at the testes to this signal from your brain
- And if you were going to use hCG, you could mimic that
  - It’s not identical, but it looks very similar to LH and it behaves in a very similar way on the [luteinizing hormone/ chorionic gonadotropin receptor](https://en.wikipedia.org/wiki/Luteinizing_hormone/choriogonadotropin_receptor)
    - Which initiates the [Leydig](https://en.wikipedia.org/wiki/Leydig_cell) stimulation and intratesticular testosterone production that you would want to actually produce natural testosterone
    - Using hCG is the only way you can directly do that if you had an inadequate signal
  - But the only viable way that would be something you could stick to and have as a monotherapy (ie. the only thing you’re using for HRT) is if your testes are healthy enough to respond to hCG and make testosterone

***When people are trying to determine if they should take synthetic testosterone, Derek recommends they first determine the health of their testes***

## Low testosterone: diagnosis, potential causes, treatment options, and other considerations [53:45]

- Let’s say you learn this and with a testosterone of 381, you take hCG and now your testosterone goes to 1200  (to the upper end of the range)

***You’ve learned that your hypogonadism is central, not peripheral***

- This means that somehow your [pituitary](https://en.wikipedia.org/wiki/Pituitary_gland) isn’t making enough signal because clearly your testes can make enough testosterone

**Armed with that information, what is the best course of action?**

- Peter asks, “*Is it to stay the course and just say, well, hey, keep taking hCG because at least your testes are responding to it, or is there some obvious problem solving?*”
- When Peter thinks of all the **things that would normally impair pituitary function**, the first first thing that comes to mind is sleep disruption
  - Maybe stress, probably hypercortisolemia
  - Over training, under training

*What are the things you would look at to brainstorm if that scenario were the case?*

- Peter asks, “*Is it low because my brain isn’t saying the right thing, or is it low because my body can’t do it?*”
- Derek thinks there are **multiple factors** that could be fleshed out before you ended up on an hCG to even figure out your response at the testes level
- 1 – Figuring out if you can top out the natural signal is the first thing to do
  - Pending your blood work looks like gonadotropins are low to mid-range
  - The question is: why am I only getting a 381 response out of that?
- 2 – He would look at many of the things Peter just said
  - Which obviously Peter is pretty dialed on
- 3 – Then above and beyond that, it would be assessing basics like micronutrient intake, macros
  - Are you eating enough to recover relative to your training stimulus?
    - Derek is not going to say a lot of people over train too much, but maybe they’re just under recovering and their sleep is bad.
  - In many other individuals, micronutrient deficiencies are common across the board
    - Zinc intake is adequate, magnesium intake is super low
    - Low vitamin D is also very impactful

> “*These things can all move the needle like 100+ ng/dL potentially, depending on how deficient you are. So some of these low hanging fruits with the sleep, micronutrients, minerals, actual macro intake*.”‒ Derek

- Some people are eating garbage, ultra processed foods with no micronutrient density, they’re under eating
- Maybe they’re on [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) and they’re super calorie deprived and they have very low protein or something (that’s also impactful)

*Assessments Derek recommends*

- Do I have an adequate **energy intake** and of that energy intake, high quality nutrient value in that energy relative to my demands?
- Am I **training hard enough** to actually maximize testosterone too?

***All of these things in concordance will ultimately dictate your output, and optimizing these things are your due diligence***

**Let’s say you have that all dialed in but you’re still getting an inadequate response**

- It’s either suboptimal signaling or even normal gonadotropin output

***You could then potentially discern partly that you’re not going to be able to get the signal you need out of your pituitary or you actually have some degradation of response at the receptor level in the testes themselves (an age deterioration)***

- Everyone’s testes are *not* going to retain perfect function forever (that’s not the case)
  - So similar to the signal, there’s also the health of the actual organ

**If those things are optimized and you’re at 381, and you take hCG and your T goes up, what does that imply?**

- Peter suggests, “*That there’s some other factor that we’re unaware of that’s impairing central stimulus?*”
- Yeah, Derek would want to know your [GnRH](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone) output, however he doesn’t know how you could measure that
  - Presumably that may be low and/or the receptor response to GnRH is suboptimal
  - You have to look at upstream signaling [discussed in the [previous episode with Derek](https://peterattiamd.com/derekmpmd/) and episodes [#256](https://peterattiamd.com/endocrinesystem/) & [#180](https://peterattiamd.com/ama28/)]
- You could use a GnRH agonist to test out what your pituitary output is, but good luck finding a doctor who understands the nuance of not castrating you with that
- Peter suggests you could use [Clomid](https://en.wikipedia.org/wiki/Clomifene#Testosterone_replacement_therapy) and Derek agrees
- Then if the response to hCG is favorable, you know that directly stimulating the [Leydig cell](https://en.wikipedia.org/wiki/Leydig_cell#Androgen_production) produces testosterone
- Derek points out this assumes you have enough testosterone to aromatize the estradiol, and that was a meaningful impact from inhibiting its negative feedback
- At least with a **GnRH agonist**, you know you’re maximally stimulating pituitary output to whatever capacity it is
  - ***This would test your pituitary output potential***
  - [Gonadorelin](https://en.wikipedia.org/wiki/Gonadorelin) is a GnRH agonist that is often used
    - It’s often misrepresented as a HRT therapy
- With **Clomid**, you’re just inhibiting negative feedback to whatever suboptimal capacity your ER is agonized
- Peter agrees and adds that in his case, maybe that wouldn’t work because his estradiol is so low to begin with
  - You’re not inhibiting that much and Clomid could fail on that basis of that

**Let’s say you learned that you respond favorably to hCG and you do not respond to GnRH**

- The problem is something is wrong with the pituitary, it’s missing the signal
- Derek has seen people diagnose adenoma by digging into that stuff, so it’s worthwhile to understand

***This also depends on how long you have been monitoring your hormones and if you have always been a healthy person***

- Peter adds, “*This is where maybe the endocrinologist can really do the heavy lifting here, right? If you go and see a physician who day and night is thinking through all of the intricate pathways here, yeah, maybe it is microadenom*a.”

**Other things to measure**

- One of the things Peter likes to do in people when we can’t solve this problem (before we send them to an endocrinologist) is measure [prolactin](https://en.wikipedia.org/wiki/Prolactin), [ACTH](https://en.wikipedia.org/wiki/Adrenocorticotropic_hormone), and a few of the other pituitary hormones to kind of get a sense if anything else is out of whack
- Derek adds that sometimes you’ll have a **prolactin secreting** [**adenoma**](https://en.wikipedia.org/wiki/Adenoma) and it’s problematic as well
- There’s a lot of weird stuff that he would love to say, “*You should understand this before you take hormones for the rest of your life,*” but it’s hard to expect everyone to understand this axis to the degree where… even we’re going back and forth
  - You just have to find as good of a medical provider as possible

**What Peter hopes people take away from this conversation**

- HRT is serious business
- A lot of people are doing it incorrectly, and there are a lot of really irresponsible people out there who are frankly just practicing dangerous medicine (if not outright veterinary medicine)
  - Peter doesn’t see a lot of this in his practice, people who have been terribly decimated by someone doing awful HRT in them
  - But he can see people on YouTube where he’s shaking his head going, “*Oh my God, what’s that guy talking about? What’s that guy doing?*”
- Clearly there is a use case to understand this stuff before you go down the rabbit hole, and hopefully this type of content helps

**Anything else you want to say on TRT before we pivot to something else?**

- Just to put a bow tie on the whole **natural stimulation** thing: if you are mindful of fertility, it’s worth consideration of hCG concurrently with whatever you’re going to be using

***If you’re on TRT and you’re going to shut yourself down, don’t make the mistake that thousands of bodybuilders have where they got on hormones and ended up with atrophied testicles***

- Then 10 years later, when they wanted to have a child, they realized the arduous recovery process was pretty significant

**Are there guys that can recover after 10 years of TRT?**

- Derek dug into this question after their conversation last time, and the longest he could find was 4 years where fertility seemed to be reliably restored
  - But this doesn’t happen for some people
  - This was in people who abused TRT, guys who abuse some amounts of synthetic drugs and have been shut down
    - It wasn’t a controlled trial

*To rescue these guys, were they using recombinant FSH and hCG in mega doses?*

- No, it wasn’t standardized recovery, they were just doing whatever PCT they deemed worthwhile

***What Derek has seen from these studies is once the hormones have left your system (even if you were abusing) and there’s no more residual negative feedback, there is a recovery period that could be as short as weeks to months, but most people will recover within 1-2 years, but it’s not 100%***

- Keep in mind these are not the most high quality, controlled studies, but it’s very difficult to control for illegally used drugs at abusive doses in a random bodybuilding population

## Growth hormone-releasing peptides: rationale and implications of the recent FDA categorization as high-risk substances [1:03:45]

\*Derek spoke about growth hormone-releasing peptides in [episode #274](https://peterattiamd.com/derekmpmd/)

- When they last spoke, they talked about a bunch of peptides
- The [FDA recently came out](https://www.fda.gov/drugs/human-drug-compounding/safety-risks-associated-certain-bulk-drug-substances-nominated-use-compounding) and took a list of about 30 peptides and put them on a list called Category 2 [identified as having significant safety risks]
  - This includes 6 of the peptides they discussed, including [BPC-157](https://en.wikipedia.org/wiki/BPC-157), [CJC-1295](https://en.wikipedia.org/wiki/CJC-1295), [ipamorelin](https://en.wikipedia.org/wiki/Ipamorelin)
- Peter’s interpretation is that these cannot be sold, compounding pharmacies cannot make them, and any interstate commerce of these things is a felony
- With that said, he has noticed that there are still sites selling these peptides
  - They seems to be suggesting they’re selling them for research purposes (clearly bullshit)

***Derek’s interpretation is that this ruling has put these peptides on a super high risk list whereby they’re not outright banned, but you will invite heavy scrutiny and perhaps legal action, should you decide to make them***

- Maybe it’s not comparable, but in the dietary supplement world, they have a advisory list and they will pick certain things they think are high risk and add them to this list, and then if you continue to make or sell these, you may receive a warning letter, at which point you have to either discontinue immediately, or they will take you to court and you have to prove why it’s [DSHEA](https://www.crnusa.org/regulation-legislation/fda-ftc-regulations/dietary-supplement-health-education-act-dshea) compliant and legal to sell
  - You could have a court appearance where you could try and make your case, but you will lose, essentially
- Derek doesn’t know if this is going to be the same outcome because it’s pharma stuff too
  - It’s probably under heavier scrutiny
- From the people he’s talked to in the compounding world, even people in the business of selling peptides, they seem to think it’s very risky
  - It was high risk to begin with, and now you’re inviting scrutiny
  - But it’s not necessarily illegal
- When you look at these research chemical sites, they’re no different than they were months ago
  - These are the same sites that have been operating with their pseudo-research, chemical-use-only, fake umbrella the whole time.
  - Those companies exist to try and sell whatever, with no prescription, no compounding pharmaceutical standards
    - At least in compounding there is some level of oversight where you have to be plus/minus some amount of potency
    - You should be submitting it for microbial testing and stuff
  - In this world it’s buy it from Alibaba, private-label it, and then sell it online
  - Maybe the really responsible ones are doing HPLC testing, but the rest are just buying it, repackaging it, and selling it

**Do people buy at these sites with a credit card, or do they have to use crypto?**

- It depends on how big the company is, because sometimes you could get away with credit card processing up to a certain amount until Stripe (or whatever your processor is) determines you’re doing something high risk that’s not a part of their compliant activities
- The bigger companies will do Bitcoin only or other loophole ways of paying
  - Money Gram, Western Union, crypto, stuff like that

**The rationale for putting these 30 peptides on this category 2 list provided by the FDI, is it’s a safety question?**

- They scheduled them this way because they didn’t have sufficient data on their safety

*Is there any reason to believe that these things are harmful*?

- Peter doesn’t really understand what the rationale was
  - He’s not saying that he necessarily disagrees with it
  - He’s trying to understand what’s being communicated in this ruling with respect to these peptides
- Derek thinks the FDA is publically saying there is a safety concern and no FDA approval to justify the production and prescription of these
  - Not an unreasonable conclusion given that a lot of these are research chemicals at the end of the day
- Some of this stuff is very fudged at the end of the day anyways
  - With compounds that got abandoned in the middle of a pipeline, but people had a demand for it, so the research chemical companies have never stopped selling it
- Then compounding pharmacies, the ones that are willing to “risk it for the biscuit” will make a certain amount in quantities that they deem as enough to satisfy the perceived demand, but not enough to get “whack-a-mole’d,” potentially
- It’s weird because you would think it would be black and white
  - Either you don’t make it or you make it illegal
- A lot of people believe it’s a gray area enough that it is still legal to make these peptides
- There are a lot of small compounding pharmacies that are going to do business as usual

**Why do you think there’s such an epidemic of interest in this stuff?**

- Peter is constantly amazed at the frequency with which people forward him links to these bizarre molecules that they’ve heard some influencer talking about on social media, and they’re asking, “*Should they be on it?*”
  - His patience for it is so low, it’s so thin
  - If you would spend half the amount of time you scroll social media looking for obscure molecules that idiotic influencers think you should be taking and maybe put it into working out

*Is this just a symptom of our quick fix obsession?*

- Some of it is, for sure
- One thing Derek wants to preface this conversation with is some of those compounds are useful
  - He thinks it’s a shame they are banned or harder to prescribe/get now
  - Others had no use being sold to begin with

**They talked about CJC-1295 last time**

- [CJC-1295](https://en.wikipedia.org/wiki/CJC-1295) is a good [GHRH](https://en.wikipedia.org/wiki/Growth_hormone%E2%80%93releasing_hormone) analog, and it works well in conjugation with growth hormone releasing [GH secretagogue](https://en.wikipedia.org/wiki/Growth_hormone_secretagogue)
  - It’s not bad, it just never made it through the pipeline
  - Derek thinks [tesamorelin](https://en.wikipedia.org/wiki/Tesamorelin) is superior for that purpose
- [Tesamorelin](https://en.wikipedia.org/wiki/Tesamorelin) is approved for [lipodystrophy](https://en.wikipedia.org/wiki/Lipodystrophy) and presumably it’s still going to be prescribed and sold
  - Derek doesn’t know if they’re going to clamp down on the compounded version
  - You can only get a pharma version

[**BPC-157**](https://en.wikipedia.org/wiki/BPC-157) **was a** [**VEGF**](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor) **analog**

- That one is interesting because it’s pro-angiogenesis that they’re going to be pushing the angle that it might cause cancer, so we can’t get behind it if it didn’t make it through its trial (which, understandable)
- At the same time, it sucks, because we’ve all used it, or know someone who’s used it and benefited from it with perceptively no downside (at least that we can see acutely)
- That’s a tough one to see go
- A lot of it is hype, it’s a sexy new thing where this mechanism has never been targeted
  - It inhibits [myostatin](https://en.wikipedia.org/wiki/Myostatin)
- There’s an array of different compounds that do different things that don’t have FDA approval, so you want to be the first to be in a performance enhancing advantage position relative to other people too
- Even if you’re not a professional athlete, everyone wants the competitive edge or better focus, better muscle growth, better body composition
- Peter points out, “*It’s not clear that these things really do that much in terms of performance enhancement.*”

**When you consider testosterone for example (which has enormous performance enhancement), do any of these other peptides even come close?**

- In terms of hard, lean body mass and strength outcomes ‒ definitely not
- This is part of what fascinates Peter, all of these things are so marginal in their benefits

**What would be interesting (if there were infinite resources) would be to do clinical trials for specific use cases**

- Peter would be very interested in seeing a clinical trial of BPC for a specific type of injury recovery where there’s a really clear use case
  - An 8-12 week trial in post-operative orthopedic patients where that is the one time when you want to see more VEGF
  - Compare that to a placebo and actually see if you get quicker recovery
    - And if so, maybe that becomes a use case for it
- It seems that the FDA has had enough of the “wild west”
- Derek wonders what brought these peptides to their attention
  - Maybe it was this podcast
- There’s definitely been an uptick in the haphazard promotion of them
- Even though they don’t necessarily have impactful outcomes on muscle growth, and ergogenic outcomes that are sport performance enhancing (blatantly, from a rehabilitation standpoint or potentially even a longevity standpoint), but some of them have promise and really interesting outcomes in rodents
  - It would’ve been nice to see what played out in humans
    - But it probably would have never happened anyway
    - It’s just random people taking it

## Follistatin gene therapy and myostatin inhibition for increasing muscle mass: the recent hype online, human and animal data, and the need for more research [1:14:45]

- Derek mentioned [myostatin](https://en.wikipedia.org/wiki/Myostatin) a second ago, which reminds Peter of something that has been going around social media lately ‒ this interesting discussion about a [gene therapy](https://cdn.sanity.io/files/1qkvwzto/production/0776624b0c2591d49fc10ae37beef96dcd7b18c5.pdf) for [follistatin](https://en.wikipedia.org/wiki/Follistatin)
- Peter explains, there is a gene therapy out there where you introduce a vector into somebody, and you activate the gene for follistatin that makes more of the follistatin protein
  - This inhibits the expression of the myostatin gene or maybe inhibits the protein myostatin (one or the other)

*This is theoretically interesting because of what we know about the actions of myostatin*

- When Peter thinks back to images that stand out from his first year of medical school, clearly this is on the top 10 list
  - More than 25 years ago, Peter remembers sitting in class when they showed the myostatin knockout mice and cattle [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f4-derekMPMD2.png)

**Figure 4. A bull showing the double muscling phenotype due to mutation in the myostatin gene**. Image credit: [*PNAS* 1997](https://www.pnas.org/doi/10.1073/pnas.94.23.12457)

**Tell people what a myostatin knockout looks like**

- It produces a double muscle phenotype
- If you look at these cattle, you would think it’s photoshopped by how absurd it looks
  - It’s like the Mr. Olympia of cattle
- In mice, it’s the same deal ‒ they literally have double the muscle fibers as compared to wildtype mice
- Peter remembers the effect in chickens ‒ it was truly remarkable
- Peter remembers talking to his roommate for the rest of medical school about figuring out a way to inhibit myostatin
- Apparently now someone’s working on this, and they’re claiming that for (Peter doesn’t know but maybe) $25,000 for your first shot and maybe $25,000 for every subsequent shot, you can get a gene therapy that will activate and produce more of a protein called follistatin that inhibits myostatin

**That should be good, right?**

- Yeah, it seems like it
- At least in the literature in animals: the myostatin knockouts have this double muscle phenotype
  - You would assume there is actual rodent data where you see administration of follistatin enhances muscle
- As a result of that, a lot of these research chemical companies were very quick to come out with freeze-dried, lyophilized, follistatin product that had 1 mg per vial and you would buy it for hundreds of dollars and then you would basically shoot a vial a day, or something of that nature and spend thousands over the course of a cycle
  - Which was based on no data at all

**How did the follistatin peptide get created? Is this an FDA-approved drug?**

- No, this was a case where they knew what the chemical structure was and got an Alibaba chemist
- This is “gray market” follistatin product
  - Not gene therapy
  - You’re just injecting the protein
    - You’d literally get bacteriostatic water, shoot it in, swish it around until it’s mixed and inject it in yourself
  - The [half-life](https://en.wikipedia.org/wiki/Biological_half-life) is maybe a couple hours
    - So you’d have to inject multiple times a day to have it be stable in your blood to get the effect, presumably
- The outcome seen in the bodybuilding world was not really anything
  - Realize that this has been around for a decade plus
  - There would be the random outlier who gained 20 lbs in 2 days, but everyone else got nothing essentially
- So it was assumed that it didn’t work
- Then we find out there have been these viral vector studies going on behind the scenes in rodents, and maybe even 1 in humans
- Recently a bacterial vector version of it was created
- A lot of big names are getting it, such as that [Bryan Johnson](https://en.wikipedia.org/wiki/Bryan_Johnson) bio-hacker dude
  - Derek has yet to see any actual metrics of before and after muscle growth or anything of that nature he’s kind of just produced
  - Apparently his follistatin increased, so presumably it’s actually doing something

***The question is: is the outcome of more follistatin actually binding enough myostatin to have an effect that is worthwhile?***

**Is there a certified assay for measuring follistatin?**

- Derek doesn’t think so
- As far as he knows, they’re using their own internal measurement
  - They have their own assay that they’ve developed
- There might not be a validated assay for measuring this protein
- Derek couldn’t say for certain that it’s actually measuring it correctly
- Assuming that it is increasing, is it actually doing anything?

**A patient sent Peter a before/after of someone who has done this gene therapy, off Twitter**

![](https://peterattiamd.com/wp-content/uploads/2024/02/f5-derekMPMD2-619x1024.jpeg)

**Figure 5. Twitter post on follistatin gene therapy**. Image credit: [X](https://twitter.com/AbudBakri/status/1731027634279326024)

- The picture looked pretty impressive
- To Derek, it has some of the hallmarks of fitness industry angles and lighting manipulations

*How do you take a pre and post photo and create the most difference? What are the tricks people use?*

- Anybody watching has probably had a cheat day
  - The day you go off the rails and eat whatever junk you want, where you had horrendous distension of your stomach to the point where it almost looked like you’re holding an alien baby or something
- A lot of times these before-and-afters are not actually shot [in that order]
  - Derek is not saying this is the case with this before-and-after
- What is typical: people would take the after shot and they would get their pump, they would make sure that they have heavy down lighting, they’d be oiled up (potentially), they’d be in the perfect circumstance for vasodilation changes (just in temperature, this can vary massively)
  - So you’d want a higher temperature
  - If you went in the gym and cranked the heat, then did 5 sets of curls (or something), you could get your arm to vascularly look unrecognizable compared to what it is now
  - Then you could walk outside and you would just disintegrate as it all vasoconstricts from the cold

***That is something that is very abused in the before and after transformation shots where they will achieve a transient look that is not representative of them walking around, and it is certainly not representative of the complete opposite circumstance that they do the before-shot in***

- They will do everything perfect and take their after-shot, which is as good as they can possibly look, with all circumstances accounted for
- You would take the before shot and, depending on how egregious you want to make it, you go in much worse lighting after you have successfully downed 4 to 5,000 calories of processed garbage food
  - You’re actually swelling, you’re so inflamed
- Think of everything you could do to look as horrendous as possible, even down to the facial expression of looking disappointed on camera with how abysmal your physique is
  - Of course you deliberately stick your gut out to exaggerate it, and it’s not hard because you’re so distended
  - You’re rolling your shoulders forward instead of rolling them back
- It sounds like these factors are not significant enough to make this big of a difference, but until you see them all stacked
- If you haven’t gotten to 10% body fat or less, Derek can’t highlight enough how dramatic it can get
  - Sometimes you’ll see a guy who’s 150 lbs, who’s shredded
    - In the perfect lighting circumstances, the guy could look like a Mr. Olympia competitor through angles, lighting, etc.
    - Then you see him in real life with a T-shirt on, you wonder if he even works out
    - That’s how dramatic it gets
- A lot of people have never got there to know what the difference is

***When you’re lean it’s pretty dramatic how much you can fudge things and it’s abused to high hell by people who want to sell things***

- There was a pretty impressive before-and-after picture for what is supposedly [follistatin gene therapy], and Derek doesn’t know if he used drugs alongside it
  - Supposedly there was no change in nutrition and exercise
  - He looked quite a bit better, but the sniff test said, “*Eh, you’re kind of sticking your gut out a bit. Are you trying to look worse?*”
- He seems like the guy who’s at the forefront of speaking about its utility and all the viability it may have in regenerative medicine
- There’s no [virilizing](https://en.wikipedia.org/wiki/Virilization) outcomes
  - Either, because it’s not acting through [AR](https://en.wikipedia.org/wiki/Androgen_receptor)
    - It’s an independent mechanism, so it sounds cool in theory
    - But the clinical outcomes seen have not been impressive enough for Derek to be floored by it
    - He’s not sure if the transformations we see online are typical or if they’re a little bit exaggerated or what
- Derek thinks there’s some level of potential exaggeration that comes with this stuff

**How much muscle mass did they gain?**

- They did an open-label, phase I trial (Derek thinks it will be published soon)
- It looked like the lean body mass gain was statistically significant but not that impressive
  - From what he recalls, it was about 2 lbs.
- Derek thinks the inflammation markers stayed the same
- The only *p-*values that Peter recalls were statistically significant was the increase in lean body mass to the tune of 2 lbs.
  - He thinks there was something else, maybe a 1% reduction in body fat

Derek asks, “*Intrinsic biological age. I don’t know if you want to speak to the validity of those tests?*”

- Peter explains that there are none; those are meaningless
- Derek adds that it didn’t seem like they controlled for exercise or anything
- Peter was surprised at how little the effect was
  - This mechanism might not matter
- In other words, knocking out the myostatin gene at birth produces a profound muscular phenotype but attenuating the gene later in life might not do much
- Peter asked one of his analysts to look this up and she found a [mouse study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3774565/) where they did a near complete block of the myostatin gene [in 4-month-old mice]
  - More than 99% of the mRNA was deleted
  - It increased muscle mass in the mice by about 25%, which was significant
  - But if you do that at birth, you’re going to more than double muscle mass

***This suggests a best case scenario (if you did this in a developed individual), you’re going to get big results, but it’s not game changing***

- This suggests it’s possible that doubling or tripling follistatin levels (which indirectly work on this pathway) would have *no* effect
- Apparently there’s a phase II trial happening in either Canada or Japan, and there are 6-month results that are more impressive
  - These phase II studies are specific for [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) so Peter assumes they’re recruiting people over 60
- Peter adds, “*Look, if you could add 5 or 10 pounds of muscle to somebody over 60, that would be really impressive.*”

**Do we have any insight into how much training stimulus is required to produce these effects?**

- Derek doesn’t know what this phase II trial is going to encompass or the inclusion criteria or if they’re using training
- Peter proposes an interesting study comparing 3 groups
  - 1 – A placebo group that trains
  - 2 – A treatment group that does *not* train
  - 3 – A treatment group that trains
  - He would love to compare the placebo who trains to the no stimulus treatment group
- Derek adds that follistatin has been hyped for years, and to finally answer if it works in humans would be great
  - To know if it is something you could use to avoid anabolics entirely for the androgen sensitive that might otherwise need anti-catabolic action later in life
  - Because [SARMs](https://en.wikipedia.org/wiki/Selective_androgen_receptor_modulator) definitely didn’t pan out the way pharma had hoped

**Didn’t the trend move in the wrong direction on lipids and metabolic markers?**

- Peter doesn’t know if it reached statistical significance
- Resting glucose was elevated
- Insulin went up
- [HDL-C](https://en.wikipedia.org/wiki/High-density_lipoprotein) went down
- [Triglycerides](https://en.wikipedia.org/wiki/Hypertriglyceridemia) went up
- [LDL-C](https://en.wikipedia.org/wiki/Low-density_lipoprotein) went up

**One thing that is weird about follistatin, when Derek was looking it up he kept seeing** [**FSH**](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) **inhibition statements**

- It turns out that follistatin used to be called follicle stimulating inhibitor hormone or something
- Follistatin is a primary mechanism known to inhibit the production of FSH at the pituitary
- Apparently the isoform used in this vector is one that is less specific for that action
- But Derek doesn’t know if there’s some off-target mechanism that is resulting in the glucose aberrations
  - He has no idea what would be causing it
- It will be interesting to see the phase II results, and hopefully they study it with a large enough sample size that you can make sense of it
- Anecdotally, Derek knows some big names that are using follistatin
  - He doesn’t know if it’s a placebo effect or what, or if those getting good results are just outliers
- Peter’s interest in hearing about what celebrities are achieving (using any sort of treatment) is zero

> “*Just for people to understand this nonsense, it doesn’t matter what celebrity X achieves using drug Y, if you have no idea how their diet has changed, how their exercise has changed, how many steroids they’re taking alongside of it, whether they’re being paid to talk about it; all of these things so dramatically impact what message gets filtered down to people*.”‒ Peter Attia

- Peter doesn’t think we could work hard enough to increase the scientific literacy of people to help them make sense of this
- Derek explains this is why he pays to be a member of *The Drive*
  - The trust factor he has in Peter’s stuff is above and beyond any piece of content he consumes
  - There’s no bias, no financial incentive
    - Peter doesn’t push companies he is an investor in
  - It’s just legit facts
  - “*Here’s Peter’s opinion, with no incentive inherently manipulating my opinion whatsoever. So I just want to say I really appreciate what you do and anyone who’s not a member, you should go be a member right now*.”

## Simple tips for lowering calorie intake and losing fat [1:32:30]

- Peter recalls a really great [video](https://youtu.be/f4ZMupHvXnU?si=02mmWmVXtWCdd58k) that Derek made a while ago about appetite suppression tricks that bodybuilders use
  - He shared a list of dietary tricks for those who want to shed a few lbs
- Derek prefaces this by explaining, “*When bodybuilders are trying to get very lean, it gets to a point where you’re pulling out all the stops to an extent whereby it’s not necessarily reflective of what is the optimal healthy diet.*”
  - Short of any attempt at micronutrient density, they want to hit their protein, fuel their training with enough carbs and enough fat that they don’t have hormone suppression, satiate themselves to the maximum extent
    - Those are the metrics when you get to the end of a dieting phase
- This is not necessarily indicative of what everyone is going to do because most people just want to see a hint of abs for the first time
  - So you don’t need to take this to the extreme
- People watching this know what high quality food is
- Derek doesn’t advocate these tips in all circumstances
- In his opinion, **diet soda** is quite useful for calorie restriction and maintaining a somewhat satisfied sweet tooth
  - [Layne](https://biolayne.com/coach/layne-norton/) published a really good [video](https://youtu.be/FSfdso8-yd4?si=hc-2_5MOo7ccyQrS) comparing diet soda to water
  - Derek is not suggesting to replace water with diet soda
  - But in a state of calorie deficiency, if you have a craving, you’re probably better off drinking a diet soda than you are eating some calorie-rich, fat-laden, sugar-bomb dessert
    - Even some of the keto treats that are marketed as healthy and diet conducive, their calorie content is horrendous
    - Just because the sugar content might be low, the fat content proportionally is far more destructive to your body composition goals (even though it’s added to make it taste good)

**Low-hanging fruit**

*1 – Try to maintain the same volume of food on your plate, but replace it with calorie-light options*

- As much as he loves the micronutrient density of red meat (and it’s one of his go-tos), he will consider swapping some of it to chicken breast
  - Not necessarily long-term
  - Having a 6 oz portion of meat to hit his protein needs, the difference in **calorie to protein content** is pretty significant in lean chicken breast as opposed to ground beef

*2 – Go from fat-filled Greek yogurt to fat-free Greek yogurt*

- It doesn’t taste exactly the same, but it’s close and the calories are a fraction yet you’re still getting proportionally the protein you need

*3 – Swap red meats to white*

- For eggs, going from some eggs with egg yolks to more egg whites
  - A few yolks will provide the micronutrients
  - Replacing 1 or 2 of the eggs with egg whites you almost don’t notice the difference in taste as compared to the whole egg

***With those 3 things, you could probably chop off 500-600 calories***

- Off the top of his head, Derek recalls that a large egg is about 80 calories, while the egg white for the proportional amount of protein is about 30 calories

![](https://peterattiamd.com/wp-content/uploads/2024/02/f6-derekMPMD2.png)

**Figure 6. Calories and nutritional content of 1 large egg compared to the egg white from 1 large egg**. Image credit: [nutritionix](https://www.nutritionix.com/food/large-egg)

- Chicken breast is 30 calories per cooked ounce
- This is why Peter likes wild game, because you’re still getting red meat, but it’s super lean

**What are budget-friendly options for lean meat?**

- Venison sticks are one thing Derek wanted to ask Peter about, “*You pound these venison sticks that are so lean and great. How would you, as a budget-friendly person, go about getting your protein with the most lean cuts?*”
  - It’s cost-prohibitive to get the really good bison, venison, stuff like that
- One option is to go **hunting**
  - If you shoot one large deer, one elk, that’s going to feed your family for more than an year
- Derek notes this is unconventional advice, but is actually practically applicable for what is budget-friendly
- People would say it’s impossible to get elk tags to shoot big elk
  - A cow elk (female cow), those tags are over the counter, and anybody can get them
    - You’re not trophy hunting
    - You can get incredible meat from the cow
  - The state regulates how much you can hunt
- Peter would argue that wild game is the healthiest thing you could eat because these animals are completely unstressed
- Derek has never hunted, so he doesn’t know if this is the right question to ask
  - What does the cost look like to get what you need to hunt with
  - Whatever licensing you need and how many states it is viable in
  - How long does it take to get to a skill level where you could have a successful hunt?
- Peter explains, “*The big divide is if you wanted to bow hunt versus rifle hunt*.”
  - It’s much, much quicker to get there with a rifle than a bow
  - He believes rifle hunting is more humane, when a person is a really good shot
  - It doesn’t take that long to become a really good shot with a rifle, you would be able to shoot an animal inside 300 yards or 400 yards and the animal would die immediately, so there’s no suffering involved
    - That would not be a terribly expensive proposition
    - Now, maybe the first year it is, but remember, you amortize the cost of your learning and buying a gun and things like that out over the cost
    - Peter would have to sit down and do the calculation, but he thinks that would be less expensive than if you were spending that much money on meat for sure, because you’re going to get thousands of dollars worth of meat from that
- Derek thinks this definitely sounds better than what he used to do, which was buy really shitty frozen chicken in boxes at Superstore
- Peter has migrated his diet more and more towards wild game, and can’t eat anything that’s farmed
  - Chicken is so nauseating to him in general
  - But everyone’s palate is somewhat different
- Derek agrees, that’s one of the problems with getting exposed to better food, you develop this refined palate where the stuff you used to get away with that was super budget-friendly and you lived on and you thought was fine, now tastes horrendous

## Methods of sustainable fat loss with muscle preservation: insights gleaned from bodybuilders [1:40:00]

**What’s your advice to somebody who’s trying to lose 10 lbs, but in a sustainable way, and keep it off?**

- Peter notes that in some ways, when bodybuilders are doing it, it’s not really sustainable because they’re starving themselves down to a competition
  - The way they’re eating during that period of time is so catabolic that they’re destroying their endocrine system along the way
    - But it’s short-lived and they refeed when they’re done
- Derek thinks Peter’s perception of what bodybuilders do as far as aggression towards their diet is hinged on their final outcome and how steep it is to get there cumulatively
  - But the way they arrive there, no one is more mindful of preserving tissue than bodybuilders
  - They’re creating huge deficits, but they’re very careful
- When a bodybuilder is stepping on the stage at 5% body fat, you’re stopping at the 8-week out from competition mark (or maybe 10 or 12)
  - The process they took to get even there was very staggered and calculated

*At 10-12 weeks out, what is their body fat relative to that 5% they’re going to step on stage?*

- It depends at what level and how on track they are, but some of them are starting at 12% body fat
- Everyone has different goals of what they consider good, so maybe this is Derek’s skewed fitness perception saying a 10-week out bodybuilder is what you should shoot for
- In general, the process they take to get from their peak body fat percentage to stage lean, no one is more mindful of titrating accordingly the macronutrient and micronutrient input to sustain training volume too, because they need to actually make sure their training doesn’t deteriorate
  - Because if it does, they’re going to lose tissue

***You see them at least hitting 1 gram per pound body weight in protein without fail, but you can’t do that with steaks because it’s way to caloric***

- They will hold that until maybe the week of competition when they’re at their target body fat and then they’re trying some tactics to make their stomach not full of anything as possible

*Are you on chicken breast, protein powders?*

- It depends on the quality of your meat, Derek has seen the macros on venison and it’s basically just protein

***The staggered approach you want to take is you don’t want to lose more than 1% of your body weight per week as a general rule of thumb***

- Depending on how obese you are, you could be a little bit aggressive
- When you are in a deficit, to sustain lean tissue muscle mass you need to eat 1 gram [protein] per lb of body weight
- And from there, you want to be at whatever your maintenance calories is
  - It might take a bit of finagling to figure out what this is when you’ve  never done it before, but there are calculators online that roughly ballpark give you what that will be ± 300 calories
    - What it takes to stably hold your body weight

*What Derek typically does is take that number and use the exact diet for a week, with this calorie amount*

- This is your diet model, and this is your total calorie goal for the day

***Eat exactly this every day and then see what the average is at the end of the week***

- Just going by daily fluctuations could be wildly different
  - You might jump up or down based on water, food volume, if you took a dump or not

**When do bodybuilders come off** [**creatine**](https://en.wikipedia.org/wiki/Creatine)**?**

- They don’t
- They used to think you should come off because it’s bloating, but it’s helpful for cosmetic appearance and for sustaining training performance
- It’s anti-catabolic

> “*Interestingly enough, [creatine] it’s one of the only natural compounds that may inhibit myostatin-2, so it has that upside, and it’s all the things it does from a neurological standpoint, perhaps fertility.*”‒ Derek

- Creatine is even [used for depression](https://www.nature.com/articles/s41398-020-0741-x#:~:text=Furthermore%2C%20human%20intervention%20studies%20demonstrate,adults20%2C22%20with%20MDD.) now in women at around 10+ g, which is crazy

***A lot of use cases are coming out, but overall, we know it works for muscle, for performance in the gym, as well a volumizing the muscle***

**Would you say creatine is hands-down the best over-the-counter supplement for performance?**

- For sure
- Derek cannot think of anything off the top of his head that would be superior
  - It depends on your sport though
    - If weight is everything (if you’re a cyclist or a runner), the downside of the extra 5 lbs of lean mass
- Making sure you have some sort of number you’re going to adhere to and you know how to measure every day
  - Which basically is just reading every nutritional label you have and becoming intimately aware of what you’re ingesting
  - If you put something in your mouth, you count it
    - Regardless if it’s a sauce, regardless if it’s a drink, regardless of it’s a lick, you count that shit

**Do most bodybuilders use an app to do this or can they just keep track in their head after a while?**

- After a while, they are so in tune with it
  - You can look at a piece of meat, know how much it’s going to shrink after cooking, know how many ounces it is, how much that equates to in protein, calories
  - At a high level, it becomes so ingrained that you don’t even need to track it, because you can literally look at it
- Maybe you’ll keep the calorie count and the protein count, but you know what you’re looking at and you can just write it down quickly
  - You don’t have to go look up and cross-reference on [MyFitnessPal](https://www.myfitnesspal.com/), “*What is a chicken breast, 1 ounce cooked equal?*”
- You can at least look forward to this, even though it’s cumbersome and arduous at the start, eventually it becomes so habitual and you’ll just know it

**You have a target calorie amount, and you eat that every day for a week and you see if your weight goes up or down**

- If it goes up, you’re eating a bit too much
- If it goes down, you know you’re in a deficit and you decide from there, is the weight loss too fast?
  - If you lost 3 lbs in a week, perhaps it’s too fast and you want to titrate it back up a little bit
- Ultimately, you can kind of shoot for, once you know your maintenance, some amount of calories where you’re dropping
  - Derek feels like 300 calories is a good deficit to start at

***Ideally, you want to keep your protein where it needs to be (which is 1 g/ lb body weight), and you want to have enough carbs to fuel performance (which can vary depending on what sport you’re doing)***

- Derek recommends, “*A good split a lot of people follow is 40% protein, 40% carbs, and 20% fat.*”
  - This is a ratio that allows you to sustain hormone production and have some amount of fat that supports it, carbs for some level of gym performance, and then protein for hopefully hitting your goals
  - It’ll depend on the person and modulate accordingly, but that’s just a general framework people can start with
- Peter points out, “*That’s a pretty low-fat diet.*”
- Derek explains that the fat and the protein would typically stay around neutral and you would typically lower the carbs according to how intensive your exercise regimen and sport is
- That’s a **minimum amount of fat (20%)** and Derek wouldn’t go lower than that

**What are some of the concessions a person has to make to get that low in fat?**

- Probably the last time Peter tracked his macros, he was almost ⅓, ⅓, ⅓ split between the three, and he didn’t feel like he was eating a ton of fat
- Derek explains that when you’re eating meat, you will achieve the majority of your fat through the meat
  - It will depend on how lean the cuts of meat are and how many eggs you’re eating
- Peter is thinking about olive oil on salad and stuff like that
  - You’re cutting that out as that probably adds 200-300 calories to a big salad (if not more)
  - Unless you’re [Bryan Johnson](https://en.wikipedia.org/wiki/Bryan_Johnson) or willing to get 25% of your calories from oil, it’s probably not a bodybuilding-conductive macro allotment
- Even though fat is satiating, it’s 9 calories per gram

**Where do bodybuilders get the majority of their fiber?**

- Typically it will be through veggies (if they’re having them), and those are going to be proportionally lower calories
- Some of them use supplements like psyllium husk
- Derek doesn’t want to get into a fiber debate because he doesn’t know what the actual answer is there
- In general, bodybuilders aren’t really paying attention to fiber
  - They’re not optimizing for health, if we believe fiber is healthy
- Derek is not saying neglect it, he thinks it is important

***He’s not saying remover your fiber in order to achieve deficit, he’s just saying that you can proportionally get to your goals almost certainly by modulating carb intake exclusively (typically***)

- That’s going to be in the form of starchy carbs
- The satiety is ultimately the takeaway for Derek, because when it comes to the nutritional literature, he hates it as much as Peter

**What Derek has seen in the bodybuilding space**

- Moderating carbs up and down according to needs in the gym
- Protein stays at an amount that is anti-catabolic or conductive to muscle protein synthesis in a surplus
- Fat in some amount that at least supports steroid hormone production as much as you can tolerate
- Carbs are the most performance-enhancing macro in terms of driving your performance outcomes in the gym, volumizing muscle (having glycogen topped out), etc.
- From there, he would recommend a 300 [calorie] deficit

**That week prior to a show, how many calories is a bodybuilder typically down to?**

- If they’re stage-ready and they’re natural and sub-200 lbs , they might be down to below 2000 calories potentially
- If they’re a top IFBB professional, Mr. Olympia competitor who weighs 260, they could be at 2500, 2600 calories
- Peter explains, “*For many people listening, that sounds like a lot of calories still, but you’re saying given how big they are and that they’re still training pretty hard, that’s a pretty big deficit.*”
- It also depends how much they’re willing to lean into cardio, because some guys will actually prefer to just diet themself into the body fat and not do any cardio, because they just don’t like it
  - Derek wouldn’t recommend that though, because one thing he has learned over the years from a nutrient partitioning standpoint, is actually moving when you’re eating is going to produce a better body composition than trying to just diet the whole deficit (typically)
- What we see even in the IFBB with these top bodybuilders who are trying to not get fat as they eat exorbitant amounts of food and they’re on insulin and HGH and huge amounts of anabolics
  - They are doing things like **going for walks after they eat their meal**, which is more potent than [metformin](https://en.wikipedia.org/wiki/Metformin) controlling blood glucose
  - They’re actually making sure they are moving around and actually shuttling nutrients as much as they can even outside of the gym
    - Some are lazy and don’t do that, but the ones that are trying to make the most use of maximizing the calories [do that]
- You’re clearly not going to oxidize everything you ate
  - If they just ate 800 calories, they’re not going to burn 800 calories on a walk of any duration
  - But just getting out there and walking leads to better fuel partitioning
  - Anecdotally, Peter has noticed the improvement in blood sugar
  - Even for stabilization of energy levels too, making sure you’re not hanging out on a couch with your spiked blood glucose seems pretty impactful for mental performance, partitioning, and actually optimizing body composition
    - That’s in enhanced ranks where guys are eating exorbitant amounts

**Back to the layman, in general, if you cut to aggressively**

- You’re in a 300 [calorie] deficit, and you can milk that for all you can
- One of **Derek’s biggest takeaways** from this whole discussion could be that people who aggressively cut way too fast will end up losing more weight off the bat, but they will end up in a state of adaption faster, whereby you are basically going to not only expend less calories at rest
  - Via the depression of non-exercise activity thermogenesis, which is like fidgets and moving with just your everyday activities, you will actually start to subconsciously do that less
- In addition, you are pushing yourself to a state of nutrient deprivation much sooner than was necessary to achieve a fat loss outcome
- So, rather than trying to 6 lbs in 2 weeks, go with 1-2 lbs at most and actually milk what you can out of that little, tiny calorie increment before deciding if you need to add more cardio to your regimen
  - Or deciding if you want to decrease food by another 100 calories, or add metabolic-enhancing pharmacology?
  - You can actually make the call at that point because you’ve exhausted the actual increment and you know you’re not unnecessarily depressing hormone production, and also putting yourself into a hole of what is essentially a malnourished state
- If you push too hard and you go from
  - Let’s just say you’re eating 2,800 calories a day and you instantly drop to 1800, you will lose a ton of weight off the rip and you’ll think, “*Oh, this is great*.”
  - And then very soon, you’ll get to a point where it’s like, “*Holy hell, I am starving. This is not sustainable. What am I doing? What do I do next? I’ve plateaued now and where do I go from here?*”
  - It becomes easy to dig yourself into a hole if you’re not careful about this titration down

***Typically Derek recommends trying to milk what you can [from the 300 calorie deficit] until weight loss has averaged out at neutral for at minimum a few days, but typically a week and then from there decide what’s next***

> “*As a natural, you are very susceptible to major aberrations and hormone suppression if you are going to deprive the hell out of nutrients, and especially if you’re doing huge amounts of cardio concurrently*.”‒ Derek

- Also, don’t put yourself in a hole on the energy expenditure side
- Try and do what you can in a titrating manner

## Could prolonged fasting impact testosterone levels? [1:55:30]

**Peter sometimes wonders if his low testosterone is in response to how much fasting he used to do**

- He used to always do a check of testosterone
  - He would do a full blood work before and after a fast
- He would do a 7-10 day water only fast once a quarter, and the change in hormone levels was profound
  - If his testosterone started out at 500-600, it would probably end at 100-200 total T
  - If his [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone) was 2, it would go to 4 (maybe higher, maybe 6)
  - If his [free T3](https://en.wikipedia.org/wiki/Thyroid_function_tests#Free_triiodothyronine) was 2.5-3 and [reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) was 12, post-fast that free T3 would *go down* to 1.5 and reverse T3 would *go up* to 32
    - The higher the free T3 and lower the reverse T3, the better thyroid function you have
- Peter wonders if repeating that cycle over and over again has maybe impacted his endogenous production
- Although his thyroid function looks stone-cold normal
- It’s just that his T is very low
- Derek would be interested to see what his gonadotropins did when he went back to a normal diet and then how he responded from there
  - It would be interesting if you could see a trend in your testicular response to that and how your brain was shooting things out

## High-protein ice cream [1:57:00]

**What about things like carnitine, caffeine? What role do these play in weight-cutting?**

- Not nearly as much as good diet choices
- Derek would love to get into the fat loss pharmacology momentarily
- There’s a lot of diet hacks that we could spend all day talking about, so he doesn’t want to bore the audience, but 1 thing he wants to mention that is super impactful is protein ice cream
  - There’s this thing called a [Ninja CREAMi](https://www.ninjakitchen.com/products/ninja-creami-7-in-1-ice-cream-maker-zidNC301) and it’s basically a mixing device, but this one in particular is very popular lately because of the consistency of ice cream that it creates

*It’s not the blender, it’s a device that’s different from their blender?*

***Correct, this thing mixes what is already blended into an ice cream***

- You would put it in the freezer blended, and then you’d put it into this thing and it would turn it into an ice cream consistency
- It depends what you want to put in it, because you could make this as healthy as you want, which is essentially just whey isolate plus some non-calorie filled sweetener if you want to risk it
  - Maybe some sugar-free pudding mixture like a chocolate or something
  - And from there, you could have something that is like 300 calories (if even) and it is as good-tasting as horrible ice cream, but hits a 60-gram protein hit with super high-quality stuff, minimal sugar content
  - It’s like 80% as good as something you would buy in a store almost

***The consistency makes all the difference here***

- When Derek was younger, he would put huge amounts of ice into a blender along with fruit, and the consistency he got out of it was not that attractive
  - You could tell it wasn’t ice cream
  - He was eating this sludgy, healthy thing
- But with the Ninja CREAMi, you cam make something pretty damn close to ice cream
  - That’s pretty significant for people with a sweet tooth
- If Peter makes a protein shake, he’s going to use almond or cashew milk and whey protein (typically 25 g [unflavored Promix](https://promixnutrition.com/products/unflavored-whey-protein-powder) with 25 g of a flavored one) and frozen berries (that’s it)
  - He uses unflavored whey protein because he finds the flavored ones so sweet
- Derek replies, “*Imagine that, not drinking it but actually eating it and it takes 10-20 minutes to eat, but the consistency is that of actual ice cream.*”

*Would I blend that in the blender and then put it in this Ninja CREAMi thing and stick that in the freezer?*

- You would put it in the blender and blend it, and this would be in this thing that you would freeze overnight
- Ideally, you would mass blend multiple servings and freeze each so you can just stick it in the CREAMi

***Once you put the frozen mix in the CREAMi, it mixes up a serving of ice cream for you, and from there, you would have the same macros, but it’s infinitely more satiating***

- It’s not just the speed of ingestion (that’s part of it for sure), but there’s some psychological component of eating something
- This is a low-hanging fruit for dieting and chopping many hundreds of calories off anything you drink (unless it’s water)
  - If you can switch it to some solidified format, you will be infinitely more satiated
- Peter suggests that instead of tequila, he’s going to freeze tequila sticks
  - The problem is that alcohol doesn’t freeze so he can’t make little tequila popsicles
- Derek knows some people who eat protein popsicles pre-workout
- They do the ice cream, protein brownies ‒ there is so much that can be done when you get creative
- The only problem is you need to have a significant other who down to do it

Peter asks, “*Why do you need your significant other?*”

- If you like cooking and you like spending time on that stuff, then perhaps that’s fine for you
- For Derek and a lot of dudes… the more creative stuff like the brownies
  - Call him lazy or far to optimizing, but he would not do anything kitchen-related if he could
- Blending stuff isn’t that time consuming
- Peter loves cooking

## Exploring fat loss supplements and drugs: L-carnitine, yohimbine, and more [2:02:15]

**Tell me about L-carnitine**

- Peter has friends that swear up and down by [carnitine](https://en.wikipedia.org/wiki/Carnitine); they inject it
- L-carnitine is present in red meat, and depending on your diet, you may or may not be deficient in it
- It is something that can help incorporate free fatty acids into the mitochondria and help you produce energy
- It also is implicated in certain indirect processes like [AR](https://en.wikipedia.org/wiki/Androgen_receptor) content in the muscle, which is some of the more fringe literature

***In the presence of sufficient anabolic stimulation, carnitine seems to actually increase the expression of what you can get out of your testosterone input***

- This is the main reason why people Derek knows use it
- It’s often advertised as get more out of less androgen, essentially

*Does this work if you are getting sufficient carnitine in your diet? Do you need supra, supra, physiologic doses?*

- In general, if you’re injecting 500 mg (for example), you will be supra
- Similar to [creatine](https://en.wikipedia.org/wiki/Creatine), you can make the argument that endogenously or through your diet, you may be getting enough
  - Maybe you’re not going to saturate muscle stores

*Is this something you inject* [*sub-Q*](https://en.wikipedia.org/wiki/Subcutaneous_administration) *daily?*

- It depends on the volume
- It could be 200 mg/mL or 500 mg/mL, and you can only inject so much sub-Q before you have lumps
- Even though it’s more easily absorbed, you don’t want to be injecting mLs of it

*Where are people getting this stuff?*

- Typically from a compounding pharmacy, online, or they’re making it themselves
  - It’s just an amino acid that you can buy, so you can use a home brew process similar to how you would make underground steroids presumably
    - This is a bad idea unless you know what you’re doing
- Derek wouldn’t risk making it even if he had the instruction manual
- In general, there is pharmaceutical compounded versions (not grade) that are made in an environment that has at least been fact-checked
  - This depends on the rigor of the pharmacy in question
  - Derek recommends Peter’s deep dives into compounding pharmacies [[episode #275](https://peterattiamd.com/ama52/)]
- Even with compounding pharmacies, there have been enormous breaches of good manufacturing processes, and that results in contaminations of legitimate FDA-approved molecules like corticosteroids that have led to literally thousands of deaths
- Peter points out, “*It’s one thing when people are compounding things without good manufacturing process that you’ll take orally, because the gut is a lot more forgiving, but the moment you start talking about things that are injectable and now you are injecting something in yourself that’s dirty, that could be a huge compromise.*”
  - He hopes there are ways for people to vet that stuff

**Derek wants to touch on carnitine quickly**

- The reason people inject it typically is because the oral format is only about 10-15% bioavailable, so you have to take literally 10x the dose to achieve the same yield outcome
- In addition to that, when you ingest things like carnitine and choline, there is a potentially concerning scenario where there is [TMAO](https://en.wikipedia.org/wiki/Trimethylamine_N-oxide) conversion (potentially unfounded)
- So when you ingest a lot of carnitine (for example 4+ grams) to get your yield that is enough to actually have some sort of effect
  - That has shown to upregulate [AR](https://en.wikipedia.org/wiki/Androgen_receptor) content
    - This is still a fringe thing that may not be ultimately founded
- You are using an amount that is going to have some level of conversion that you could avoid by injecting
  - So you are averting the need to use as high of a dose
  - In addition to that, you are potentially avoiding some level of risk from gut-related circumstance
    - Some people use [allicin](https://en.wikipedia.org/wiki/Allicin) with it to circumvent and try and prevent TMAO conversion
    - It’s from garlic and it seems to attenuate TMAO conversion in the gut, but it’s also a fringe application with a hopeful outcome
    - You could measure in serum your TMAO before and after allicin versus not and see if there’s a difference

*Are there any clinical trials that demonstrate any efficacy of injectable or oral L-carnitine?*

- With carnitine, the results are mixed
- Some of it looks promising and then some of it doesn’t
- This is one of those things where you largely go by anecdotes, and with it being a natural amino acid, a lot of people that use it, it depends on their baseline circumstance too
- Those who are deficient will obviously get more from it
  - Peter can see a scenario where somebody’s a vegan and maybe the risk is worth the payoff, but if you’re an omnivore who happens to eat red meat, maybe it’s less so

***Derek is sure that if Peter saw the data, he would not be convinced that it’s worth trying***

- Derek doesn’t think people would want to blindly inject this

*The reason people find it attractive is because it works through a different vector*

- People anecdotally have seen muscle growth outcomes on the same dose of anabolic or lesser so and grow leaner when they use it
- It’s not like there’s literature to show when you’re on testosterone plus carnitine you get better results than just test
  - But that’s what people claim and seems to be at least somewhat reproduced anecdotally, but that’s speculative

***Derek would not recommend it and doesn’t think it’s a potent fat burner***

**How effective is caffeine both in terms of its effect on appetite and potentially its effect on fat oxidation?**

- It’s super reliable and one of the best things you could do
- You know where the data lies for upper tolerability and safety, even the FDA has a threshold amount that they say you’re good to take
  - It’s like 400, which is pretty significant
- You can get some level of increased energy expenditure from that, but largely the benefit from the stimulant category comes from the increased energy you have, even as you go deeper into a deficit as well
- As you enter into nutrient deprivation territory, it becomes a lot harder to even move subconsciously, let alone, actually fuel your everyday activity
- Derek is not saying you should become a caffeine addict to support your deficit
  - That’s not necessarily sustainable

***Caffeine is certainly a reliable way to help attenuate an energy deficit one day where you need a bump***

- It increases metabolic output
- It reliably increases performance in the gym
- It has appetite suppressing qualities
- It has safety data

> “*I would pretty blindly recommend caffeine for most people short of special circumstances.*”‒ Derek

**You mentioned** [**yohimbine**](https://en.wikipedia.org/wiki/Yohimbine) **earlier; say more about that**

- That’s an [alpha-2 adrenergic](https://en.wikipedia.org/wiki/Alpha-2_adrenergic_receptor) antagonist, and when it comes to some of these adrenergic type receptors, it gets kind of confusing
- Even though it’s an antagonist of the alpha-2 receptors, it will have **stimulatory effects**, but contradictory to what you’d expect from a stimulant that’s not vasoconstrictive
  - The same way you might get from an amphetamine or essentially any other stimulant that works well
- This stuff raises [adrenaline](https://en.wikipedia.org/wiki/Adrenaline) signaling very significantly, and there is thought that it could liberate free fatty acids via the adrenergic signaling that you could then take advantage of during exercise
  - Now, is the energy expending component of it worth hanging your hat on?
  - Derek would say no, but the adrenaline inducing component is substantial enough that some people really, really enjoy the use of it in their training and get a uptick in energy that is markedly different than through adenosine receptor antagonism (which is caffeine)

***It feels much more racy and aggressive than caffeine***

*How does it compare to* [*ephedrine*](https://en.wikipedia.org/wiki/Ephedrine)*?*

- Derek thinks ephedrine is a beta-2 receptor agonist, but he could be wrong on that

***It is less euphoric and more like adrenaline spiking, so you feel borderline anxious to a degree where you have a sense of urgency***

*How long does it last?*

- Derek can’t recall the half-life of yohimbine, but it’s relatively short

*Is it the type of thing that people take for the workout when they’re in a calorie deficit?*

- Yeah, typically you would take it before cardio or before training
- Interestingly enough, it’s also used as an aphrodisiac and can enhance erections
  - Which is weird; you wouldn’t expect that from a stimulant
- Also, that doesn’t seem like the right mix of things to be super anxious and irritable
- Derek would reserve this for after you’ve tried all the standard low-hanging fruit options and you’re at your wit’s end and need an energy boost
  - He doesn’t use it, and he wouldn’t use it as much as caffeine
  - This is something that’s more use case specific and not as reliable

## Potential remedies for individuals experiencing metabolic dysfunction due to hypercortisolemia [2:12:30]

- Peter thinks this plays a role in the state of overnutrition
- He’s talked about this before
- When he looks at somebody, he wants to know 3 things
  - 1 – Are you over nourished, undernourished, or adequately nourished?
  - 2 – Are you adequately muscled or under-muscled?
  - 3 – Are you metabolically healthy or not?
- Depending on where you fall in that matrix, you have to decide whether calories need to stay the same, go up, or go down

**1 of the scenarios that is the most clinically vexing is the person who is overnourished, typically metabolically unhealthy, and typically under-muscled**

- That’s a pretty common phenotype
- You’re a little too fat, you don’t have enough muscle, and you’re not metabolically healthy
- A big part of the driver is basically the **hypercortisolemia** that accompanies sympathetic overdrive
  - An individual that is under so much chronic stress, that they basically can’t stop the glucocorticoids from chronically being catabolic to lean tissue and anabolic to fat tissue
- When you think about all the other endocrine scenarios, we have ways to manipulate them, but for this one, we don’t really
- There are certain things we can do
  - You can use [ashwagandha](https://en.wikipedia.org/wiki/Withania_somnifera), you can use [phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine)
    - They certainly help with sleep in that setting

**Do you know anything or do you have any insights into ways to manipulate that person’s physiology, in addition to pulling the big three important levers around nutrition, sleep, and obviously exercise?**

- [Yohimbine](https://en.wikipedia.org/wiki/Yohimbine) (the alpha-2 receptor antagonists) and alpha-yohimbine (which Derek thinks is a drug) are definitely *not* the drugs you want to take if you’re in the hypercortisolemia
  - Peter adds that this is what made him think of this, because a lot of people are chronically in that phenotype
  - The use case: some people get a significantly better appetite suppression effect out of those particular drugs than something else
- As far as actual anti-catabolic action, the most potent thing Derek is aware of is actually [anabolics](https://en.wikipedia.org/wiki/Anabolic_steroid)
  - There are certain ones that are more potent at antagonizing the [glucocorticoid receptor](https://en.wikipedia.org/wiki/Glucocorticoid_receptor), and actually compete with glucocorticoids for binding, and that’s where they get their anti-catabolic action in a deficit
    - Something like [oxandrolone](https://en.wikipedia.org/wiki/Oxandrolone) (not that you can get it now, which we could talk about), but that in burn victims is literally indicated for antagonizing the heightened cortisol glucocorticoid response that you get from being in that state
    - It is one of the most potent anti-catabolic drugs

**What happened there? Was oxandrolone banned altogether?**

- Derek’s understanding (which may not be entirely correct) is it was FDA-approved for many indications, and then the FDA determined in a meeting in the ‘80s that anabolics (Anavar in particular) had no efficacy anymore
  - If you go back far enough, you can find studies which conclude that anabolic steroids aren’t performance enhancing (obviously nonsense)
  - Anavar, which is the branded version of oxandrolone
  - The FDA pulls oxandrolone (the chemical)

*Isn’t this a ruling directed towards not just the company that makes Anavar, but even a compounding pharmacy that would make oxandrolone?*

- Yeah, they are saying that there’s now [no approved use for oxandrolone](https://www.federalregister.gov/documents/2023/06/28/2023-13733/gemini-laboratories-llc-et-al-withdrawal-of-approval-of-one-new-drug-application-for-oxandrin) in totality
- So if you are a pharma company who has a generic version of it, or you’re a compounding pharmacy that makes it, there is no approved use for it
- Presumably, you can’t justify the prescription of it as a doctor unless you can somehow lean on … I guess it’s not even off label because there’s no-
- Peter wonders about the implication of that for the patient in a burn unit where the physician says, “*We’ve been using oxandrolone for years, and it’s got great results.*”
  - Derek wonders where they would get that prescription filled
- Derek knows that some compounding pharmacies are still making it now, and the pharma companies that had generic versions of it have voluntarily pulled their own approvals

**Is oxandrolone taken** [**SL**](https://en.wikipedia.org/wiki/Sublingual_administration) **(right under the tongue)?**

- If you get a troche from a compounding pharmacy, you could get a sublingual format of it, but it’s typically a press tablet that you just pop, and you would take it twice a day (orally)

*Is that* [*hepatotoxic*](https://en.wikipedia.org/wiki/Hepatotoxicity)*?*

- A little bit, but it’s one of the least hepatotoxic 17- alpha alkylated anabolics there is
- If you look at the pharmacology of it, it is metabolized by the kidneys proportionally more than any oral agent, and that creates a superior hepatotoxic outcome where it’s not nothing, but it’s lesser than [oxymetholone](https://en.wikipedia.org/wiki/Oxymetholone) (brand name Anadrol), [stanozolol](https://en.wikipedia.org/wiki/Stanozolol) (brand name Winstrol), or some of these other ones

*Is stanozolol injected?*

- That’s typically taken orally, but it’s also injected in a water base, but almost no one does that
  - Bodybuilders do, but very often it leads to infections, so they often don’t do it now

## The cornerstones of body composition improvement remain nutrition and exercise, even in the presence of exogenous testosterone [2:19:15]

**Peter’s takeaway‒** ***listening to this, all roads point back to nothing seems to matter more than what you eat when it comes to body composition, what you eat and how you exercise***

- This other stuff is like a rounding
- It’s 90% exercise, diet and testosterone
- It’s 10% all of the other stuff
- Derek agrees
- Last time they spoke, they talked about the development of  pharmacology and what is leading to the change in physiques as of recent
- Derek said in order, it was drugs, and then diet, and then training
  - For the last 2, it almost doesn’t matter when drugs are that important for achieving the outcome on a Mr. Olympia stage

***The caveat that Derek definitely wants to make clear, you do not achieve even the outcomes from anabolics without the support of a great infrastructure of diet, and training, and sleep***

- Which is what Peter just said, that 90% of it is this
- As much as it could be a band-aid for all those things, you will achieve a fraction of the results even on anabolics if those are not in check
- As much as he doesn’t want to admit it, Derek has done it himself
  - He’s seen hyper-responder bodybuilders do fluff workouts and get crazy results
  - Being the guy who wants to experiment with everything, when he was younger, he thought, “*Maybe I’m just working too hard. Maybe I’ll try like the fluff Phil Heath workout I saw or something on YouTube*.”
    - Turns out, it doesn’t work for him at all
    - He basically wasted a full cycle of exposure to these compounds and got almost  nothing out of it because his training was half-assed
- Having that baseline, regardless if you’re natural or enhanced is the fuel to support the recovery that may be at an enhanced level with anabolics, but it doesn’t exist without these things

**Has someone done the study of testosterone replacement therapy in a non-active individual who doesn’t change any behavior, and how minimal the changes are?**

- The [Boston study](https://onlinelibrary.wiley.com/doi/10.1111/andr.12454) is the standard-graded dose-response study that everyone’s familiar with
  - He had 2 different studies that were using 600 mg of testosterone a week
  - [One of these studies](https://journals.physiology.org/doi/full/10.1152/ajpendo.2001.281.6.E1172) was graded dose-response [without exercise training]
    - That’s 6x physiologic dose
- The [other study](https://www.nejm.org/doi/full/10.1056/nejm199607043350101) was done in the ‘90s used 600 mg of testosterone versus placebo in a non-training, and training individual (2 x 2 design)
  - They found that the group who trained and took testosterone got the best outcome
  - The group who didn’t train and took testosterone still had better lean body mass outcomes [see the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f7-derekMPMD2.png)

**Figure 7. Body weight, fat-free mass, muscle size, and muscle strength before and after 10 weeks of 600 mg/wk testosterone** Image credit: [*NEJM* 1996](https://www.nejm.org/doi/full/10.1056/nejm199607043350101)

- This kind of spits in the face of what was just said, although that’s 600 mg of testosterone
  - You almost need to see that on 100 mg
  - You also have to draw it out over the span of a training career, because you’re not going to sustain perpetual muscle growth
- When you take steroids for the first time, there is a temporary increase in lean body mass metrics that are essentially unquantifiable by standard metrics of measurement to body composition
- Because ultimately, the way these work is not just through the production of muscle protein synthesis and contractile tissue, it’s also the increased intracellular water that you would not hold otherwise and the increased blood volume
  - These are things that although they’re not contractile, they are still making up your muscle, which is largely water
- Even though they do try to account for total body water that is not muscle-based, there are still some confounding level of the drugs actually facilitate this as the desired outcome

***It’s unquestionable that anabolics, even if you’re not training, will produce a level of muscle that is higher than if you had no hormones***

## The importance of approaching health advice found online with a critical eye and a healthy dose of skepticism [2:23:30]

- Peter points out, “*One of the things you’re known for is debunking the charlatans, which we’ll link to some of your best videos on this*” [see the selected links section]

**Is there anybody you’re looking at now just sort of shaking your head at like, “*****How is this person fooling so many people?*****”**

- We’ve talked about him briefly, [Gary Brecka](https://www.garybrecka.com/), he has a lot of good information, but the guy very heavily emphasizes the importance of getting [gene testing](https://10xhealthnetwork.com/products/10x-health-gene-testing-kit?utm_source=gbrecka) for a limited amount of [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) that are ultimately very common to find in general population, and then making wild, extrapolated claims from that, that assert all of your ailments and problems could be attributed to this
  - He has good information that’s general about lifestyle training, sleep hygiene, but then, he’ll sprinkle in these aggressive claims about methylation
    - If you are homozygous for [C677T, MTHFR](https://pubmed.ncbi.nlm.nih.gov/25449138/) (which Derek is and a lot of people are), he says you need to be taking this exact blend of methylated B vitamins
    - [the MTHFR gene was discussed in [episode #46](https://peterattiamd.com/chrismasterjohn/)]
  - He speaks very articulately, eloquently, confidently, concisely, and it very much gives the impression that this guy knows something you don’t know
  - The implication is that you should follow his advice because he is the one who transformed [Dana White’s](https://en.wikipedia.org/wiki/Dana_White) physique too
    - Dana White speaks very highly of him.
  - Some of the products he sells, he has $140,000 [red light bed](https://10xhealthnetwork.com/products/10x-superhuman-protocol-complete-package?utm_source=gbrecka)

*Does that improve methylation?*

- Derek has no idea, but he would assume it doesn’t do a lot of anything
- He hasn’t looked into it because it never occurred to him as something worth looking into
- It seems a bit expensive ‒ borderline, low-end exotic car territory for a bed that emits light on your face
  - Derek is skeptical

*How much does his* [*gene testing*](https://10xhealthnetwork.com/products/10x-health-gene-testing-kit?utm_source=gbrecka) *cost?*

- About $600
- Derek explains that you could get [23andMe](https://www.23andme.com/) data and could submit it to [Rhonda Patrick](https://www.foundmyfitness.com/about-dr-rhonda-patrick) or somebody who has one of the automated reports and get something as comprehensive (or more so) with no suggestions to buy stuff, but just straight up gives you the interpretation based on everything we know about these SNPs, and it would tell you if you had methylation impairments
- Peter adds, “*We do all of those tests as part of a standard blood panel, and it’s basically free*.”
- Further, you can do a whole genome sequence now for $300
  - We’re not talking SNPs but 3 billion base pairs
- From what Gary says, Derek explains it’s almost like he’s hoping you have one of the most aggressive methylation impairments, so he could point to it and as the reason you feel this way
  - Or to explain that you are a worrier because of a [*COMT* polymorphism](https://en.wikipedia.org/wiki/Catechol-O-methyltransferase#Val158Met_polymorphism)
- Derek explains that even if this is right, “*You got a needle in the haystack, because there’s so much that goes into genetics that is beyond these maybe common SNPs that have some impact*.”
- If he was the most methylation impacted, he would look at betadine or whatever to lower his [homocysteine](https://en.wikipedia.org/wiki/Homocysteine)
  - This is totally reasonable, but don’t assert that it’s the root of everything that’s wrong with me

***The way Gary highlights it is a little bit disingenuous***

- It’s hard to believe that he is this good of an actor, or if he genuinely doesn’t know (unlikely) because he going on the biggest podcast in the world and spits complete misinformation
  - He says that T4 is methylated in the gut to T3 and if you have a mutation of your *MTHFR* you will not convert T4 to T3, and that’s why you might have hypothyroidism
    - That was the assertion made recently on [Joe’s podcast](https://ogjre.com/episode/2060-gary-brecka)
    - This is pretty wild to Derek because Joe is hypothyroid and so Gary is appealing to his medical condition, saying he  has the answer
    - Derek is nearly certain that methylation is not the thing that converts T4 to T3
- Peter agrees, methylation most certainly is not responsible; it’s a series of enzymes called [deiodinases](https://en.wikipedia.org/wiki/Deiodinase) and to his knowledge, this has nothing to do with your *MTHFR* gene
- Derek recommends Chris Masterjohn’s recent [video](https://youtu.be/kMPvCiOkEtQ?si=WPH69ot0vge_xZc5) on this, “*I would recommend people check out his stuff if you want to know anything about methylation*.”
  - Peter has had Chris on the podcast [[episode #46](https://peterattiamd.com/chrismasterjohn/)]

**Is there anybody else out there that’s got you excited?**

- [Bryan Johnson](https://en.wikipedia.org/wiki/Bryan_Johnson) is an interesting dude (mentioned earlier) ‒ the vegan king
- Not [Brian Johnson](https://en.wikipedia.org/wiki/Liver_King) the liver king
  - Bryan is the antithesis of that guy’s diet model
- Both are shockingly prolific in their own way
- Derek explains about Bryan, “*He’s eating sludge vegan shit on camera every day and saying it’s proven by data to be the answer to longevity… He’s done the follistatin thing*. *He’s done tons of stuff.*”
  - Telomere lengthening peptides
  - Thymus regeneration
  - Enhancing peptides, ones that are all banned now or at least category 2
  - Derek hasn’t seen somebody on more stuff than him
- His protocol is endless, leaving Derek to think, “*How do you control for anything at this point?*”
- The other day, he added in oral [Minoxidil](https://en.wikipedia.org/wiki/Minoxidil) at 2.5 mg, which is a super outdated antihypertensive that causes [edema](https://en.wikipedia.org/wiki/Edema)

*Is he doing it for hair growth?*

- Yeah, but that could affect a myriad of things that are also affected by the 77 other things he’s on right now
- Hair growth is a pretty easy metric to count, but when you’re counting health metrics on organ function and stuff, Derek don’t really get how he’s controlling for everything
- Granted, no one else is doing it, so it’s interesting

***Derek watches with skepticism about what is going to come of it, if it’s going to become this monetary incentivized hype train, or if he’s just going to produce the data, some like noble billionaire dude who’s just doing it for the good of longevity, community or what***

**What’s up with Mr.** [**V Shred**](https://vshred.com/aboutvshred?ref=home)**?**

- Derek doesn’t even know where to start with the worst things he’s done
- Peter doesn’t know what the business is despite having seen the commercials
- In general, his go-tos are: “*Here’s your body type quiz, and you tell me if you’re an ecto, meso, or endomorph… And from there, I will tell you the diet that you need to actually get lean because you’ve been given misinformation by everyone else this whole time*.”
- But if you’re an ectomorph, you’re already lean

*So an ectomorph can do whatever they want? Is that the takeaway?*

- Derek doesn’t know
- He’s heard the programs are pretty cookie-cutter
- This guy will clearly hammer you at scale, to recruit as many people as possible, even to the detriment of his credibility
- It’s very old school marketing: Harvard discovered this secret ingredient that they’ve been keeping from you, and it’s the secret to fat loss
  - He’s figured out what it is, and it does, X, X, and X
  - It’s like a 15-minute commercial where he’s hyping this thing up
  - You’ve invested so much time to find out what it is; you just want to find out what he’s going to say at this point
  - It turns out that it’s [capsaicin](https://en.wikipedia.org/wiki/Capsaicin) (from peppers) or something that makes you feel a bit hot
  - He’s selling a fat burner that has some negligible amount of caffeine, capsaicin, and 4 other things
    - The bottle costs more than the ingredients
  - He’s giving you a discount because you made it through the video, but on subscription
- One of the worst ones Derek has seen is him pretending to be on the Joe Rogan podcast
  - Derek remarks, “*It was almost ingenious-level unethical*”
  - People are thinking this guy was on the podcast and is probably a trusted authority on whatever he’s talking about
  - You see the add over and over again, so that means it’s working because he’s dumping ad dollars into it

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Derek**: [#274 – Performance-enhancing drugs and hormones: risks, rewards, and broader implications for the public | Derek: More Plates, More Dates](https://peterattiamd.com/derekmpmd/) (October 9, 2023) | [1:00, 32:15, 41:30, 49:00, 51:15, 1:02:15, 1:03:45, 1:10:45, 2:19:30]

**More Plates More Dates YouTube channel**: [More Plates More Dates](https://www.youtube.com/channel/UCoR7CHkMETs3ByOv74OAbFw) | YouTube (2024) | [2:00]

**More Plates More Dates podcast**: [More Plates, More Dates](https://moreplatesmoredates.com/podcasts/) | Host Derek (2024) | [2:00, 18:15]

**More Plates More Dates website**: [More Plates, More Dates](https://moreplatesmoredates.com/) | [2:00]

**Previous episodes of** ***The Drive*** **where details of testosterone binding the androgen receptor are explained**: [6:15]

- [#180 – AMA #28: All things testosterone and testosterone replacement therapy](https://peterattiamd.com/ama28/) (October 18, 2021)
- [#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones | Peter Attia, M.D.](https://peterattiamd.com/endocrinesystem/) (May 29, 2023)

**DHEA used in combination with combined oral contraceptives**: [24:15]

- [Maintaining physiologic testosterone levels during combined oral contraceptives by adding dehydroepiandrosterone: II. Effects on sexual function. A phase II randomized, double-blind, placebo-controlled study](https://www.contraceptionjournal.org/article/S0010-7824(18)30076-3/fulltext) | *Contraception* (R van Lunsen et al 2018)
- [Maintaining physiological testosterone levels by adding dehydroepiandrosterone to combined oral contraceptives: I. Endocrine effects](https://www.contraceptionjournal.org/article/S0010-7824(16)30141-X/fulltext#secst0075) | *Contraception* (H Coelingh Bennink et al 2016)

**Measurement of free testosterone with equilibrium dialysis by LabCorp**: [Testosterone, Free, Mass Spectrometry/Equilibrium Dialysis (Endocrine Sciences)](https://www.labcorp.com/tests/500726/testosterone-free-mass-spectrometry-equilibrium-dialysis-endocrine-sciences) | LabCorp (2024) | [38:00]

**Gene therapy for follistatin**: [Follistatin-344 plasmid therapy](https://cdn.sanity.io/files/1qkvwzto/production/0776624b0c2591d49fc10ae37beef96dcd7b18c5.pdf) | [Mini Circle](https://minicircle.io/our-therapies/) | [1:15:00]

**Block of myostatin gene in mice increases muscle mass**: [Skeletal muscle gene expression after myostatin knockout in mature mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3774565/) | *Physiological Genomics* (S Welle et al 2009) | [1:27:00]

**Derek’s dietary tricks to lose weight**: [My TOP Fat Loss Tips & Appetite Hacks That Got Me Shredded For The First Time | FAT TO SHREDDED](https://youtu.be/f4ZMupHvXnU?si=0p6mAQIQb4NqFpnL) | More Plates More Dates, YouTube (May 31, 2020) | [1:32:30]

**Layne’s video comparing diet soda to water**: [Diet Soda VS Water: A New Human Randomized Control Trial | Educational Video | Biolayne](https://youtu.be/FSfdso8-yd4?si=aO1TofpfJkt62Ds9) | Dr. Layne Norton, YouTube (November 15, 2023) | [1:34:00]

**Ninja ice cream maker**: [Ninja® CREAMi® 7-in-1 Ice Cream Maker](https://www.ninjakitchen.com/products/ninja-creami-7-in-1-ice-cream-maker-zidNC301) | Shark Ninja (2024) | [1:57:30]

**Peter’s deep dive into compounding pharmacies**: [#275 – AMA #52: Hormone replacement therapy: practical applications and the role of compounding pharmacies](https://peterattiamd.com/ama52/) (October 16, 2023) | [2:04:45]

**Testosterone dose-response study**: [Muscles of the trunk and pelvis are responsive to testosterone administration: data from testosterone dose–response study in young healthy men](https://onlinelibrary.wiley.com/doi/10.1111/andr.12454) | *Andrology* (J Tapper et al 2017) | [1:21:15]

**Effects of testosterone in the absence of exercise training**: [2:21:30]

- [The Effects of Supraphysiologic Doses of Testosterone on Muscle Size and Strength in Normal Men](https://www.nejm.org/doi/full/10.1056/nejm199607043350101) | *NEJM* (S Bhasin et al 1996)
- [Testosterone dose-response relationships in healthy young men](https://journals.physiology.org/doi/full/10.1152/ajpendo.2001.281.6.E1172) | American Journal of Physiology Endocrinology and Metabolism (S Bhasin et al 2001)

**Some of Derek’s legendary videos debunking charlatans**: [2:23:45]

- [The OG Body Transformation Before & After Exposed Video (he did this in 5 hours!)](https://youtu.be/cTTuiWf2WuY?si=EOPiyXkHBC0z9jPP) | More Plates More Dates, YouTube (June 13, 2023)
- [The Liver King Lie](https://youtu.be/BKpmAGZQetc?si=VfcaiOCOLb_OxqaL) | More Plates More Dates, YouTube (November 28, 2022)
- [Kali Muscle shut your mouth](https://youtu.be/gtr-a-brJ_Y?si=fWyVQjE-0FIIUhBe) | More Plates More Dates, YouTube (November 20, 2021)
- [Logan Paul crossed the line – scientifically dismantling prime hydration](https://youtu.be/Pb0dYyuR0ok?si=aUnMRIsEa6HzU5gw) | More Plates More Dates, YouTube (October 11, 2022)
- [Liver King](https://youtu.be/3rpbCG2DimU?si=1mf7rLV6aixIPBTI) | More Plates More Dates, YouTube (October 5, 2021)
- [Chef Rush exposed – 10,000 calories and 2 hours sleep](https://youtu.be/KoL1LOjXGeQ?si=_q_WhakT_p-H6jC6) | More Plates More Dates, YouTube (March 20, 2021)
- [V Shred exposed (again)](https://youtu.be/KTqEOjUlSJ8?si=bwUtf4Yfnr2xpHvA) | More Plates More Dates, YouTube (March 3, 2021)
- [Discovering a retroactive fake natty – Greg Doucette exposed](https://youtu.be/Pz_lnIOrdVo?si=SOLrdNnHK5MVInn-) | More Plates More Dates, YouTube (January 25, 2021)

**Chris Masterjohn explains methylation**: [Fact-Checking Gary Brecka on Rogan: A Deep Dive into MTHFR and Methylation](https://youtu.be/kMPvCiOkEtQ?si=CQmvR4PuPPf0Iiq2) | Chris Masterjohn, PhD, YouTube (November 14, 2023) | [2:28:45]

**Episode of** ***The Drive*** **with Chris Masterjohn**: [#46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more](https://peterattiamd.com/chrismasterjohn/) (March 25, 2019) | [2:29:00]

§

## People Mentioned

- [Bryan Johnson](https://en.wikipedia.org/wiki/Bryan_Johnson) (American entrepreneur and biohacker) [1:19:15, 1:48:45, 2:29:00]
- [Layne Norton](https://biolayne.com/coach/layne-norton/) (Founder of BioLayne, physique coach, natural bodybuilder, and powerlifter) [1:34:00]
- [Gary Brecka](https://www.garybrecka.com/) (biologist and co-founder of 10X Health System) [2:24:00]
- [Rhonda Patrick](https://www.foundmyfitness.com/about-dr-rhonda-patrick) (scientist with expertise in the areas of aging, cancer, and nutrition; co-founder of [Found My Fitness](https://www.foundmyfitness.com/episodes) podcast and website) [2:26:15]

§

![](https://peterattiamd.com/wp-content/uploads/2023/10/bio-derek.png)

##### Derek, More Plates, More Dates

Derek is a Canadian bodybuilder from Vancouver and the host of *More Plates More Dates*, a podcast, YouTube channel, and website. His YouTube channel has 1.39 subscribers, and he posts new videos almost every day. He uses these platforms to discuss men’s health, diving into the topics of bodybuilding, supplements, fitness, self-improvement, and more. [[greatestphysiques.com](https://www.greatestphysiques.com/male-physiques/derek-more-plates-more-dates/)]

Facebook: [More Plates More Dates](https://www.facebook.com/MorePlates/)

Instagram: [moreplatesmoredates](https://www.instagram.com/moreplatesmoredates/)

Snapchat: [@derek-fit](https://www.snapchat.com/add/derek-fit)

TikTok: [moreplates](https://www.tiktok.com/@moreplates?lang=en)

X (formerly Twitter): [@Derek\_Fitness](https://twitter.com/derek_fitness?lang=en)

Website: [More Plates, More Dates](https://moreplatesmoredates.com/)

YouTube Channel: [More Plates More Dates](https://www.youtube.com/channel/UCoR7CHkMETs3ByOv74OAbFw)