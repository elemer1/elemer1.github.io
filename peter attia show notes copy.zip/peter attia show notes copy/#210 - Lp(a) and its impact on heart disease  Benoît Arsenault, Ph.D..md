# #210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.

**Source:** [https://peterattiamd.com/benoitarsenault/](https://peterattiamd.com/benoitarsenault/)

---

Benoît Arsenault is a research scientist focused on understanding how lifestyle and genetic factors contribute to cardiovascular disease risk. In this episode, the discussion casts a spotlight on Lp(a)—the single most important genetically-inherited trait when it comes to atherosclerotic cardiovascular disease (ASCVD) risk. Benoît explains the biology of Lp(a), how it’s inherited, the importance of measuring Lp(a) levels, and the diseases most associated with high Lp(a). He dives into data on the possible treatments for lowering Lp(a) such niacin, statins, and PCSK9 inhibitors, as well as the most exciting new potential therapeutic—antisense oligonucleotides.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/benoitarsenault/the_Drive_public.png)

Play

#210 - Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.

#210 - Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.

1x15s30s

0:002:07:18

## We discuss:

- How Benoît came to study Lp(a)—a new marker for cardiovascular risk [3:15];
- The relationship between Lp(a) and CVD risk [6:45];
- What genome-wide association studies (GWAS) revealed about Lp(a) [16:00];
- Clinical tests to measure Lp(a) [22:00];
- The biology of Lp(a) [25:45];
- How statins lower LDL-cholesterol and why this doesn’t work for an Lp(a) [29:15];
- The structure of LDL-p and Lp(a) and what makes Lp(a) more atherogenic than an equivalent LDL particle [34:00];
- The role of Lp(a) in aortic valve disease [42:45];
- How greater numbers of Lp(a) particles are associated with increased risk of disease [48:00];
- The genetics and inheritance of Lp(a) and how and when to measure Lp(a) levels [52:00];
- Niacin and other proposed therapies to lower Lp(a), apoB, and CVD risk [1:00:45];
- Why awareness of Lp(a) among physicians remains low despite the importance of managing risk factors for ASCVD [1:14:00];
- The variability of disease in patients with high Lp(a) [1:19:00];
- Diseases most associated with high Lp(a) [1:26:30];
- The biology of PCSK9 protein, familial hypercholesterolemia, and the case for inhibiting PCSK9 [1:35:00];
- The variability in PCSK9 inhibitors’ ability to lower Lp(a) and why we need more research on individuals with high levels of Lp(a) [1:50:30];
- Peter’s approach to managing patients with high Lp(a), and Benoît’s personal approach to managing his risk [1:54:45];
- Antisense oligonucleotides—a potential new therapeutic for Lp(a) [1:57:15]; and
- More.

§

## Show Notes

**\*Notes from intro:**

- Benoît is an Associate Professor at the University Institute of Cardiology and Pulmonology of Quebec at Laval University
- He is also a research scientist in the cardiology axis at the Quebec Heart and Lung Institute in Canada
- His research background is in understanding the risk of cardiovascular diseases such as atherosclerosis and aortic stenosis in relation to lifestyle and inherited risk factors
  - This includes extensive research in unraveling the role of Lp(a), HDL metabolism, PCSK9, and lipid-lowering therapies
- This episode will focus on Lp(a)
  - We haven’t had a podcast on this in many years since AMA#14
    - [AMA #14: What lab tests can (and cannot) inform us about our overall objective of longevity](https://peterattiamd.com/ama14/)
  - And a lot has changed since then
- Why care about Lp(a)?
  - While it varies by race, about 20% of the world’s population is in the high risk category of Lp(a); this is higher than Peter thought
  - Most doctors aren’t checking Lp(a) with their patients
  - That means there are going to be people who are listening to this who may not know they have a high Lp(a) and are at risk
  - Lp(a) is the single highest, genetically inherited trait that confers high risk of ASCVD
  - This is an important topic to understand because even if you don’t have an elevated Lp(a), chances are someone you know does
- In this discussion we go back to the basics to explain
  - What is Lp(a)?
  - We talk about the basic biology of Lp(a)
  - We talk about the epidemiology of it
  - We discuss how it is inherited and how it is measured
- We discuss how it impacts things besides ASCVD, such as aortic stenosis and myocardial infarction
- We talk about the importance of measuring Lp(a) in order to target other risk factors of ASCVD
- We discuss how to manage lipid management for those who have high Lp(a)
- We also talk about what we know about possible current therapies and treatments for Lp(a)
  - Including Niacin, Statins, PCSK9 inhibitors, as well as what’s possibly on the horizon with antisense oligonucleotides

## How Benoît came to study Lp(a)—a new marker for cardiovascular risk [3:15]

**Benoît’s training**

- Benoît got involved in Lp(a) research during his postdoc years
- He trained at Laval University in Quebec City from 2006-2009
  - Did work in the field of lipids, looking at LDL particle size, triglycerides, APOB, etc., on cardiovascular outcomes
- Not that many people talked about Lp(a) because there had been so many negative studies on Lp(a) and the risk of cardiovascular disease
  - Such as [myocardial infarction (MIs)](https://en.wikipedia.org/wiki/Myocardial_infarction) and stroke and so on

**Studies of biomarkers associated with cardiovascular events point to Lp(a)**

- Genetic association studies have resurrected the field of Lp(a)
  - These were published in 2009 to 2011
- During that time he was a postdoc in Amsterdam working with [John Kastelein](https://esc365.escardio.org/person/24778)
- John was working on the [treating-to-new-targets trial, the TnT trial](https://www.wikijournalclub.org/wiki/TNT)
  - This is one of the first trials that showed that if you reduce low density lipoprotein (LDL) levels by increasing the statin dose, you’ll get an incremental benefit in cardiovascular outcomes
- They were working on a bunch of sub analyses for that trial
  - They had just measured a whole panel of emerging biomarkers that could be associated with cardiovascular events like CRP, NT-proBNP, inflammatory markers, other biomarkers of insulin sensitivity, and Lp(a)
  - And it turned out that of a huge list of 18 biomarkers that they had measured in thousands of individuals, ***Lp(a) was actually the strongest of them that was predicting residual cardiovascular risk***
  - This was the first paper he published on Lp(a) in those years
  - Published in the *Journal of the American College of Cardiology,* [Oxidation-Specific Biomarkers, Lipoprotein(a), and Risk of Fatal and Nonfatal Coronary Events](https://www.sciencedirect.com/science/article/pii/S073510971002526X?via%3Dihub)
- At that time they were also wondering if there were any genetic variants that could explain statin response
  - Because statins work well in most people, but there’s a huge inter-individual variability in terms of LDL lowering associated with statins
  - They were first used to identify genetic variants associated with specific diseases
- They were part of a big genetic consortium that was called the [GIST consortium (genomic investigation of statin therapy)](https://www.nature.com/articles/ncomms6068)
  - It turned out from that big analysis that Lp(a) was the most important genetic risk factor that explains statin response
  - They showed that ***if you have high Lp(a), then your LDL wouldn’t be lowered as much as if you didn’t have a high Lp(a)***

## The relationship between Lp(a) and CVD risk [6:45];

**Epidemiological studies show the importance of Lp(a)**

- Ballpark numbers are that about 20% of the world population has an Lp(a) level that puts them in a higher risk category
- Individuals of African ancestry have the highest levels while Chinese and Japanese probably have the lowest levels
- Lp(a) was discovered in 1963 by a Swedish scientist named [Kare Berg](https://en.wikipedia.org/wiki/K%C3%A5re_Berg)
- Kare Berg was one of the first to show in the late 70s – early 80s that Lp(a) was associated with cardiovascular events, in European cohorts
- The assays to measure Lp(a) were not as good then as they are today; there was a lot of variability
  - A lot of these studies published in the 90s and in the early 2000s came out negative, so nobody talked about Lp(a)

**Why were initial studies of Lp(a) negative?**

- The hypothesis was that high Lp(a) was associated with cardiovascular events like myocardial infarction, stroke, etc.
  - People with higher Lp(a) levels were at the highest risk
- This turned out to NOT  be the case in many of those studies
- They realized afterwards that the assays used were probably not very good
  - The assays did not correctly identify people with high Lp(a)
  - This has been attributed to the complex structure of lipoprotein(a), copy number variation in the Lp(a) genes
  - And the antibodies that are used against that, sometimes they can bind to different epitopes of Lp(a)
  - So now we have antibodies that are binding to Lp(a) on other regions
    - This provides a much better sense of the number of Lp(a) particles in the bloodstream
  - But back in the days, the assays were overestimating the isoform size that was bigger, and they were underestimating the small Lp(a) isoform size
    - It’s the small Lp(a) isoform size which is associated with high Lp(a)
- The Lp(a) gene was cloned in the 80s by [Angelo Scanu’s group at the University of Chicago](https://www.uchicagomedicine.org/forefront/heart-and-vascular-articles/cardiologist-angelo-scanu-md)
- A PubMed search of Lp(a) shows a straight line form the 70s-mid 80s
  - Then when these studies came back negative, the number of studies listed on PubMed goes down
  - They come back up in 2009/ 2010 when genetic association studies were beginning to be published
    - The great thing about genetic studies is that you don’t necessarily need to measure lipoprotein(a) levels
  - Now the number of studies on Lp(a) listed on PubMed are going back up again
- There were 3 big studies published in 2009 that very convincingly shows that genetic variants associated with high Lp(a) levels were tracking with cardiovascular events
- Phenotypic studies of individuals with lower Lp(a) levels (1 standard deviation below the mean) show reduced risk for 5 cardiometabolic diseases, shown in the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/06/f1-benoit-1024x944.png)

**Figure 1.  Lower Lp(a) levels associated with reduced risk of 5 cardiometabolic diseases.**  Image Credit: [*Journal of the American College of Cardiology* 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5328146/)

**Clarifying semantics about Lp(a) and LDL**

![](https://peterattiamd.com/wp-content/uploads/2022/06/f2-benoit.png)

**Figure 2.  Nomenclature related to Lp(a); by convention gene names are italicized.**

- *LPA* is the gene that codes for [apolipoprotein(a) [abbreviated apo(a)]](https://en.wikipedia.org/wiki/Lipoprotein(a)), which then binds to an apoB on an LDL; this turns an LDL from being just a garden variety LDL particle into a Lp(a) particle
  - Each [LDL particle](https://en.wikipedia.org/wiki/Low-density_lipoprotein#Biochemistry) contains a single [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) (apolipoprotein) on its surface
- *LPA* is the gene; everybody has this gene, but we have different variants of it, and this varies considerably by ethnicity
  - So you’re going to see different expression of the apolipoprotein(a) in different people
- This apolipoprotein(a), which we’ll talk a lot about and what it looks like and its structure and what its heterogeneity is all about, but it wraps onto a low-density lipoprotein (LDL)
  - Then the LDL becomes kind of a supercharged, nefarious, LDL
  - We’re going to talk about all the reasons why it’s not responsive to the same treatments as regular LDL, etc.
- The genotype of *LPA* identified during the [GWAS (genome-wide association studies)](https://en.wikipedia.org/wiki/Genome-wide_association_study)
- Now we can look into causal relationships
- And study it further with [Mendelian randomization studies](https://www.bmj.com/content/362/bmj.k601.full)
- Part of the genetic heterogeneity among different people is the apolipoprotein(a) isoform size
  - So people express different Lp(a) isoforms
  - Some are bigger than the other, and that actually plays an important part of the equation, explaining why some people have a higher Lp(a) than others
  - We’ll come back to this topic

**Difficulties measuring Lp(a) in plasma**

- One of the challenges in studying Lp(a) is the difficulty in measuring the protein
- When we look at something like [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B), one of the things we talk about is that by measuring the concentration of apoB, you can completely and accurately measure the concentration of the atherogenic particles, the majority of which are LDL
- 2 important things about LDL
  - 1 – Every LDL has 1 and only 1 apoB-100 particle on it
  - 2 – All apoBs are the same size, they have a molecular weight
    - Measuring the mass of apoB tells the number of apoB particles
- In contrast, the [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein) particle has multiple [apoAs](https://en.wikipedia.org/wiki/Apolipoprotein_AI) on it
  - This is totally different from [apo(a), which stands for apolipoprotein (a)](https://en.wikipedia.org/wiki/Lipoprotein(a))  not apolipoprotein A on the HDL particle
  - We’re not going to talk about apoA other than to say, you don’t have a unique number

***One problem with Lp(a) that creates a challenge diagnostically is there is no molar weight for it***

- Benoît adds, “*We’re really moving in the right direction in terms of getting the Lp(a) measurement in nanomoles per liter (nmol/L). We have to move away from measurements in milligrams per deciliter, which is really influenced by the isoform size of Lp(a)*.”
  - nmol/L will give a much better sense of the number of Lp(a) particles in circulation
- Lp(a) is going to be measured through immunoturbidimetric assays and not by NMR
  - NMR can actually give you a pretty good estimate of LDL particle number, but you have to use antibodies to measure Lp(a)
  - Peter misspoke by saying it would require separation by electrophoresis

## What genome-wide association studies (GWAS) revealed about Lp(a) [16:00]

**GWAS studies found a much stronger association between the variants of** ***Lp(a)*** **that produce high copy numbers of apolipoprotein(a) and incipient cardiovascular events**

- 3 GWAS studies on Lp(a) were published in 2009; the first one easy by [Robert Clark](https://www.ndph.ox.ac.uk/team/robert-clarke) in the UK using the PROCARDIS Consortium
  - Published in *The New England Journal of Medicine*, [Genetic Variants Associated with Lp(a) Lipoprotein Level and Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa0902604)
  - They looked at around 3000 people with heart disease and 3000 controls
  - They identified 2 SNPs in the *LPA* regions that are completely different from one another
  - They showed a dose response effect of these SNPs on Lp(a) levels with a proportional effect on the risk of heart disease
    - It was like the first Mendelian randomization study, where they nicely showed that if you had 1 Lp(a)-raising allele, you had higher Lp(a) levels, whereas if you had 2 or more Lp(a)-raising variants, then you had even higher Lp(a) levels, and the risk was proportionally higher
- Peter notes that this type of analysis really bridged results from observational epidemiology and clinical trials
- This type of Mendelian randomization uses a handful of assumptions
  - 1 – In the population sampled, nature randomized different copy numbers of these alleles such that different amounts of protein is produced
  - 2 – To link something as causal assumes the gene of interest is not doing something else you are unaware of
    - A hypothetical example: if the *LPA* gene is responsible for making apolipoprotein(a) but it also did something else, changed your susceptibility to secondhand smoke
    - So people who get this gene would be debilitated by secondhand smoke and people who did not would be immune to secondhand smoke
    - In this scenario, the Mendelian randomization study would not be helpful to understand increased risk of cardiovascular disease from having more copies of *LPA* because you don’t know if it’s that or if it’s the exposure / susceptibility to secondhand smoke
- Peter thinks the case of *LPA* is pretty straightforward because it’s a relatively simple gene
  - When the analysis was done it was relatively easy to demonstrate that the gene wasn’t doing anything else in either its coding or noncoding regions

**Complexity of the** ***Lp(a)*** **gene**

- Benoît agrees but points out that geneticists don’t think *LPA* is a relatively easy gene
  - There are 2000 different *LPA* gene variants
  - Then add in the isoforms and each isoform has a specific set of variants
- The beauty of working with Lp(a), but also with most proteins in the circulation, is that you’re looking at cis-acting [SNPs (single-nucleotide polymorphisms)](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism)
  - Cis-acting means variants that are acting within the window of the genes that are expressing their protein
    - Cis-acting affects the protein containing the SNP
    - As opposed to a trans-acting SNP that would affect other proteins
    - An example of a trans-acting SNP would be a SNP in the [*CETP* gene](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein) which we know might be associated with Lp(a), but CETP does a lot of other things (regulates HDL levels and also triglycerides)
    - So we don’t use *CETP* genes to do Mendelian randomization on *LPA*
  - A specific gene being associated with an intermediate phenotype that could on the other hand influence Lp(a) would be reverse causality
- Benoît concludes, “*In the case of LPA, we’re very, very confident that we’re using the correct genetic instruments to infer a causal relationship between LPA and a wide range of atherosclerotic cardiovascular diseases*.”

**There are 2 independent types of analyses that make it very clear that Lp(a) is playing a causal role in the development of atherosclerotic cardiovascular disease, independent of LDL**

- 1 – The regular observational epidemiology, now that assays more accurately measure Lp(a)
- 2 – Mendelian randomization studies that are effectively nature’s randomized experiments
- 3 – Benoît adds a 3rd assumption, that the effect of *LPA* variants on cardiovascular disease are explained by higher Lp(a) levels

## Clinical tests to measure Lp(a) [22:00]

**Over the past decade, Peter has seen 3 different types of commercial assays for measuring Lp(a)**

- 1 – Lp(a) cholesterol content; measured cholesterol of LDLs that had apolipoprotein(a) on them
  - Some labs may still use this one
  - The cholesterol within certain lipoprotein does not necessarily tell you a lot of information about the number of particles that are in the bloodstream, which is the most important thing to measure if you want to estimate risk
  - The same is true for LDL
  - For LDL and ApoB, there is some discordance in the amount of cholesterol
  - But for LDL and Lp(a), the discordance is even higher
- 2 – Most labs report mg/dL of Lp(a); they are simply telling you the mass of Lp(a)
  - Measuring the mass of the Lp(a) particle is much better than measuring the cholesterol in Lp(a) particles
- 3 – ***What you really want to do is try to find a lab that will give you an Lp(a) measurement in nanomoles per liter***
- Don’t let good be the enemy of perfect here; if you have an Lp(a) measurement in mg/dL and it puts you in a high-risk range (an Lp(a) level above 50), then the chances of the Lp(a) assay that will give you a result in nmol/L will also give you a high level
  - Keep in mind that if you have an Lp(a) of 50 mg/dL, the measurement in nmol/L will be around 125 nmol/L
- Lp(a) remains remarkably stable over time, so most guidelines tell you to measure it once in a lifetime
- The figure below shows the levels of Lp(a) associated with increased risk of CVD (in yellow and red)
  - Most people are in the normal, low risk range (shown in green)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f3-benoit-879x1024.png)

**Figure 3.  Lp(a) levels above 50-60 mg/dl are associated with increased risk of CVD.** Image credit: [*Journal of the American College of Cardiology* 2017](https://www.sciencedirect.com/science/article/pii/S0735109716372540?via%3Dihub#bib9)

***Peter’s takeaway: Lp(a) is something we measure to determine risk, after which point we don’t need to measure it; now you need to take measures elsewhere***

## The biology of Lp(a) [25:45]

**Lp(a) particles are produced in the liver**

- All the Lp(a) particles originate from the apolipoprotein(a) that’s only expressed in the liver
- It’s not entirely clear in the literature how or where specifically an apolipoprotein(a) will become an Lp(a), so where it will bind to ApoB and ultimately an LDL particle
  - Multiple hypothesis have been tested
  - Some people say that the apolipoprotein(a), which is like a glycoprotein, is secreted in the bloodstream and there it will bind to whichever LDL is closer to it to form Lp(a)
  - Another hypothesis suggests that it’s probably earlier after the secretion of Lp(a), so not entirely in the bloodstream, but when it leaves the hepatocyte in the liver, that apolipoprotein(a) binds to LDL
    - There is now good evidence to suggest that this happens within liver cell; that ***apolipoprotein(a) binds to apoB [on an LDL particle] to eventually form Lp(a)***
    - There is good evidence to suggest that as soon as apolipoprotein(a) is produced, it can form an Lp(a) when it meets an apoB on a LDL particle
  - Peter notes that the liver brings in many LDLs and is also making apolipoprotein(a), so it seems the obvious place for this marriage to occur rather than out in the periphery
    - But this remains to be seen
- ***The levels of Lp(a) are determined by the rate of production of Lp(a) particles and little by its catabolism***
  - We’re still not entirely sure of how the catabolism of Lp(a) occurs
  - Most of it is by the liver, a little is by the kidney
  - Identifying the receptor at the surface of the hepatocyte that will remove Lp(a) from the bloodstream has been challenging
    - Some evidence suggests it’s the LDL receptor
    - Some evidence suggests it’s the plasminogen receptor
    - We’ll discuss later the homology between apolipoprotein(a) and plasminogen
- It’s really the production of apolipoprotein(a) determines the concentration of Lp(a)



## How statins lower LDL-cholesterol and why this doesn’t work for an Lp(a) [29:15]

- If you give somebody a statin, which is a very potent drug to lower LDL, the primary mechanism by which it does so is by increasing hepatic clearance of LDL
  - So you have more and longer-lasting LDL receptors on the liver, and they’re pulling those LDL out of circulation, which is lowering the plasma concentration
  - But this does nothing to offset the amount of Lp(a), *which is why some people respond really well to statins and some don’t*
- The higher your Lp(a), the worse your statin response because Lp(a) is a subset of your LDL that is not responding to the statin

***Lp(a) is an LDL with 1 other thing covalently bound to it, apo(a)***

- Statins actually reduce LDL particles in the circulation by upregulating the LDL receptor at the surface of the hepatocyte
- The density of the LDL receptor at the surface of the hepatocyte is super important
  - The more LDL receptors you have, the higher the catabolism of apoB-containing lipoproteins will be because apoB binds to the LDL receptor
- So under the assumption that Lp(a) is catabolized by the LDL receptor, you would think that statins would actually reduce Lp(a) levels
  - What we see is NO lowering of Lp(a) by statins
  - Contrary to this, there has been more than 1 study showing that if you put somebody on a statin, you’ll have a small increase in Lp(a) levels
  - This should not be a reason to NOT use a statin
    - Trials like the [Heart Protection Study](https://en.wikipedia.org/wiki/Heart_Protection_Study) have shown that treatment with statins is beneficial in patients with high Lp(a) levels, maybe even more so than patients with low Lp(a) levels

***We have so much experience with statins that we know they work in the overwhelming majority of individuals and even better in patients with high Lp(a)***

- Peter notes, “*One hypothesis for that might be that the statins are bringing a higher influx of LDL to the site of the production of the apolipoprotein(a), and that might possibly be why you’re seeing an increase in Lp(a). If that were true, that would make it even more likely the scenario that that’s the source of the merger between apolipoprotein(a) and LDL*.”

**How much does Lp(a) go up when a patient takes a statin?**

- This depends on the study
- A lot of studies that have shown that statins don’t have an effect
- Most studies have shown a 10% increase in Lp(a) levels
- If you have low Lp(a) levels and you’re treated with a statin, you’ll still remain with a low Lp(a) level
- If you have a high Lp(a) level, then you’ll obviously still remain with a high Lp(a) level, although it’s going to be a little bit higher
- It’s important to notice that Lp(a)-lowering drugs are NOT being tested on top of statin therapy at the moment
- Benoît has published a [paper](https://www.sciencedirect.com/science/article/pii/S0735109715044654?via%3Dihub) in patients with aortic valve stenosis using the ASTRONOMER trial data, showing Lp(a) increases about 20% in patients on a statin
  - But statins are still very effective in patients with high Lp(a), even though they increase it by a small increment
- Peter notes, “*An easy way to think about this would be if you give a statin and let’s say in the most aggressive case, the Lp(a) goes up by 10%, but the apoB comes down by 60%, you’d have to make the case that an Lp(a) is 6-times more atherogenic on a particle for particle basis for that to be an equivalence maneuver*.”

## The structure of LDL-p and Lp(a) and what makes Lp(a) more atherogenic than an equivalent LDL particle [34:00]

***What about Lp(a) is so virulent? What makes it more atherogenic on a particle for particle basis as compared to a regular apoB LDL?***

- Benoît  notes, “*On a per particle basis, Lp(a) is much more atherogenic than an equivalent LDL particl*e”
- There’s evidence that Lp(a) might influence the rates of thrombosis, because Lp(a) has sequence homology with [plasminogen](https://en.wikipedia.org/wiki/Plasmin)
  - Plasminogen plays a role in clotting and has antifibrinolytic activity
- The most important thing is the number of oxidized phospholipids that are transported by Lp(a)
  - This is much higher than the amount of oxidized phospholipids that you see on LDL particles
- Oxidized phospholipids have effects on a wide variety of cells: endothelial cells, smooth muscle cells, macrophages, cells of the aortic valve like valvular interstitial cells
  - Now, they’re sending in signals that will drive pro-inflammatory, maybe pro-thrombotic, and pro-calcifying signals to these cells
  - The action of oxidized phospholipids carried by Lp(a) particles is probably the most important reason why on a per particle basis, Lp(a) is more atherogenic than LDL

**More about the structure of Lp(a) and what makes it atherogenic [35:30]**

*The structure of LDL*

- An LDL is a spherical compound; wrapped around its surface is a single lipoprotein called apoB100 (shown in the figure below)
- Peter asks “*How does this interact with apolipoprotein(a) to become Lp(a)?*”

![](https://peterattiamd.com/wp-content/uploads/2022/06/f4-benoit.png)

**Figure 4. An LDL particle.**  Image Credit: [Encyclopedia Britannica](https://www.britannica.com/science/low-density-lipoprotein)

**The structure of apolipoprotein(a) and how it compares to plasminogen**

- Plasminogen is a gene on chromosome 6
  - It contains 5 kringle repeats, named this because they resemble a round, Danish pastry
- Lp(a) is the gene right next to plasminogen on chromosome 6
- There is reason to believe that during evolution, Lp(a) arose from a duplication of the plasminogen gene, shown in the figure below
  - Lp(a) is derived from kringle IV (KIV, shown in blue), KV (yellow), and the protease domain (white) of the plasminogen gene (illustrated in the figure below)
    - The protease domain is inactive in the *Lp(a)* gene
    - There are 10 subtypes of KIV with KIV2 being present in a variable number of copies
- Peter notes that plasminogen would have been very important 10,000-100,000 years ago because trauma was such a threat to our species, much more than it is today
  - And trauma carries with it  an immediate risk of hemorrhagic shock and blood loss that would have ultimately killed as many people as would a resulting infection
  - Anything to reduce the risk of hemorrhagic shock would have been generally positive
- Peter asks, “*Tell people exactly how plasminogen would’ve played a role in that and why this is something that if a duplication was created, probably worked to an evolutionary advantage, again (until we lived long enough for it not to)*”
- There are a lot of hypothesis about the effect of Lp(a) on wound healing
- When we’re talking about duplication of the plasminogen gene, it’s only the kringle IV and kringle V that remain in the Lp(a) gene
- The kringle IV is separated in 10 different subunits
  - There’s the kringle IV type 1 all the way to the kringle IV type 10
  - The most important is probably the kringle IV type 2 (KIV2), which is where the [copy number variation (CNV)](https://en.wikipedia.org/wiki/Copy_number_variation) is common
    - You can have 1 of these repeats or up to 40 (shown in the next 2 figures)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f5-benoit-1024x624.png)

**Figure 5.  The gene encoding Lp(a) has a variable number of KIV****2** **repeats and higher Lp(a) levels are associated with fewer repeats.** Figure credit: [*Journal of the American College of Cardiology* 2021](https://pubmed.ncbi.nlm.nih.gov/33766265/)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f6-benoit-969x1024.png)

**Figure 6. Lp(a) has a variable number of kringle IV type 2 (KIV****2****) repeats, determined by genotype.**  Image credit: [*Journal of the American College of Cardiology* 2017](https://www.sciencedirect.com/science/article/pii/S0735109716372540?via%3Dihub#bib9)

- The figure above shows Lp(a) and the variability of its size observed in the population
  - Lp(a) is a type of LDL particle  where the apolipoproteinB (apoB) is bound to apolipoprotein(a)
- ***Low levels of Lp(a) in the plasma are correlated with numerous repeats of kringle IV type 2 (KIV******2*** ***repeats)***
- Variation in the number of KIV2 repeats affects the isoform size of Lp(a)
- Other important kringle parts—
  - Kringle IV type 10 (KIV10) is probably the most important for the binding of oxidized phospholipid
  - Kringle IV type 9 (KIV9) is important for the interaction between apolipoprotein(a) and apoB
    - It contains cysteine residues that form a [disulfide bridge](https://en.wikipedia.org/wiki/Disulfide) (covalent bond) with apoB

**Peter’s thought experiment**

*If you could create a drug that would cleave that disulphide bond, so it wouldn’t lower apoB and it wouldn’t lower apolipoprotein little a, it would just prevent their union and therefore it would eliminate Lp(a), but you still had a high concentration of apolipoprotein little a floating around by itself, dragging with it, oxidized phospholipids, would you guess that it would still be problematic?*

- - There isn’t solid data on the form of apolipoprotein(a) that’s not bound to LDL particles
  - We know apolipoprotein(a) can still have oxidized lipids
  - We’re not sure how Lp(a) gets inside cells and if this happens
  - They have some evidence, published with his colleague [Patrick Mathieu](https://www.patrickmathieulab.ca/) (a heart surgeon)
    - Published in *JACC: Basic to Translational Science* in 2020, [Interaction of Autotaxin With Lipoprotein(a) in Patients With Calcific Aortic Valve Stenosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7524777/)
    - They looked at the Lp(a) receptor in the valvular interstitial cells; these are the types of cells that are very abundant in the aortic valve
    - Lp(a) is also associated to a very significant extent to aortic valve stenosis
    - When Benoît talks about the Lp(a) receptor, he’s not talking about the receptor for Lp(a); he’s talking about the [receptor for lysophosphatidic acid](https://en.wikipedia.org/wiki/Lysophospholipid_receptor)
      - [Lysophosphatidic acid](https://en.wikipedia.org/wiki/Lysophosphatidic_acid) is generated by an enzyme carried by Lp(a) in the blood, the enzyme [autotaxin](https://en.wikipedia.org/wiki/Autotaxin)
  - In addition to carrying oxidized phospholipids, apoB, and LDL, Lp(a) has its specific proteome
    - ***Lp(a) carries a lot of different proteins that have functions to make it even more atherogenic***
  - Oxidized phospholipids can have a signaling effect in the aortic valve that might be independent from LDL

- Benoît speculates that there are signaling effects of oxidized phospholipids that are important to activate a lot of different inflammatory processes and also osteoblastic processes

- Because these types of valvular interstitial cells are becoming like osteoblasts, which are the cell types that make bones

- - This makes sense when you’re talking about aortic valve calcification that it’s a bone-like process
- Peter notes for his patients who have elevated Lp(a), one of the 1st tests they do is get a baseline look at their aortic valve
  - Using an echocardiogram
  - If they can’t get a good enough view, they’ll use a cardiac MRI

## The role of Lp(a) in aortic valve disease [42:45]

**How much does risk go up for aortic stenosis in an individual with elevated Lp(a)?**

- There’s not really good evidence showing that Lp(a) is associated with bicuspid aortic valve stenosis because we’re studying genes that are associated with bicuspid aortic valve stenosis and we don’t see really an effect of Lp(a) there
  - It might accelerate the formation of aortic stenosis in patients with bicuspid aortic valve
  - These patients are already at risk
- Lp(a) is probably an initiator of aortic valve stenosis and we’ve known that since 2013, when [George Thanassoulis](https://rimuhc.ca/-/george-thanassoulis-md) and [Wendy Post](https://www.hopkinsmedicine.org/profiles/details/wendy-post) published a genomewide association studies of aortic valve calcification in the CHARGE consortium
  - Published in *The New England Journal of Medicine*, [Genetic Associations with Valvular Calcification and Aortic Stenosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3766627/)
  - They showed that one variant of Lp(a), associated with high Lp(a) levels, was the most important variant associated with aortic valve disease
  - This study was a game-changer for understanding aortic valve stenosis
- We had known for a few years that Lp(a) was present in the valve and it co-localizes with oxidized phospholipids
- The effect of high Lp(a) on aortic valve stenosis really depends on the level of Lp(a)
  - For patients that have highish Lp(a) levels (let’s say, 50 mg/dL or 125 nM), their risk can be increased by 50%, maybe a 100% or double
  - But when you’re looking at patients that have very high Lp(a), the risk can increase quite substantially
    - For these patients, you want to look at the aortic valve; [echo](https://en.wikipedia.org/wiki/Echocardiography) is probably the most widely available tool to investigate this

**Imaging to detect calcification of plaque**

- In Benoît’s lab, they perform [sodium fluoride PET/CT](https://en.wikipedia.org/wiki/Positron_emission_tomography), positron emission tomography coupled with computed tomography using a radio tracer that’s called sodium fluoride
- In patients from the general population that have a high Lp(a) level, they can see a signal before the onset of aortic valve calcification using this radio tracer

> “*This really tells you that there’s an effect of Lp(a) on the initiation of the process of aortic valve stenosis*”— Benoît Arsenault

- They can see metabolic change at the valve before any gradient appears or any flow-related metric
- The sodium fluoride tracer will bind to a chemical called [hydroxyapatite](https://en.wikipedia.org/wiki/Hydroxyapatite), which is literally a complex of calcium and phosphorus, and will eventually be involved in the pathophysiology of aortic valve stenosis
  - They see this process happening at the earliest stage of disease
- They see an effect of Lp(a) on the later stage of disease
- Patients with high Lp(a) might progress more rapidly than patients with low Lp(a)
  - Especially within younger patients with high Lp(a)
  - When you’re looking at patients that are above 75 or 80, there’s a lot of calcium that’s already present in the valve
  - The mechanism driving aortic valve stenosis might be very different in younger patient compared to older patient

**It’s important to identify aortic stenosis in its earliest stages because the outcome data are quite clear that the earlier you intervene, the better the outcome**

- The risk of spontaneous cardiac death and other things goes up with aortic stenosis
- If you look at the literature today, patients seem to have better outcomes when you proceed earlier, before the heart is overly taxed, based on that pressure head that it faces

***Aortic stenosis is a very serious problem, independent of ASCVD, atherosclerotic cardiovascular disease, which is what most people think of when they think of Lp(a)***

## How greater numbers of Lp(a) particles are associated with increased risk of disease [48:00]

**The mass of Lp(a) observed in the population varies greatly from person to person**

- Look again at the earlier figure of Lp(a) that highlights the different number of kringle repeats that can be present, copied below
- This can result in an Lp(a) with a high molar mass (larger isoform size) or a low molar mass (smaller isoform size), depending on the number of repeats present (illustrated by purple circles in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f7-benoit-1024x794.png)

**Figure 7. Smaller Lp(a) particles have fewer repeats and are associated with increased serum levels of Lp(a) and greater cardiovascular risk**.  Image credit: [*Atherosclerosis* 2022](https://www.sciencedirect.com/science/article/abs/pii/S0021915022001940#undfig1)

- Peter asks, “*What does the number of these repeats tell us about the pathophysiology of this?*”
- Our understanding of the pathophysiology of Lp(a) is increasing every week now
- 10 years ago, there was this debate about Lp(a) as to whether or not it was the Lp(a) concentration that matter or if Lp(a) concentration didn’t matter at all because it’s the apo(a) isoform size that mattered, small isoform size being associated with higher Lp(a) levels
  - Summarized in the figure above

***A smaller isoform size results in smaller particles and it’s associated with higher levels of Lp(a)***

- There have been some epidemiological studies that have measured apoA isoform size either through PCR or immunoblotting etc.

> “*These questions were ultimately resolved by looking at genetics*”— Benoît Arsenault

- There’s one particular variant that’s associated small Lp(a) isoform size, but that’s also associated with a low Lp(a) phenotype
  - This was our way to do a discordance analysis by looking at that specific SNP and this genetic variant was not associated with cardiovascular diseases at all
- A study from the DECODE cohort in Iceland did whole genome sequencing, on around 15,000 individuals
  - Published in the *Journal of the American College of Cardiology* in 2019, [Lipoprotein(a) Concentration and Risks of Cardiovascular Disease and Diabetes](https://pubmed.ncbi.nlm.nih.gov/31865966/)
  - They showed unequivocally that the Lp(a) isoform size, even though you can sequence it, really was not associated with the risk of heart attacks and strokes once you take into consideration Lp(a) level

> “*It’s really the Lp(a) number that matters*”— Benoît Arsenault

- This has been very positive for the field because there’s so many puzzles that we still need to figure out in terms of the association between Lp(a) and risk

***At least we can convincingly say that it’s the number of Lp(a) particles that matter and not necessarily the isoform size***

- And the isoform size matters because it’s associated with different levels of Lp(a) and not through an independent effect
- Peter notes, “*This creates a beautiful symmetry here, which is it mirrors apoB. The first, second and third order factor in the harm caused by an LDL particle is the number of the particles, the size, all of those things only factor into the number. Why is it that smaller particles are more often associated with a poor phenotype? Because when you have smaller particles, you generally have more of them*.”

## The genetics and inheritance of Lp(a) and how and when to measure Lp(a) levels [52:00]

**How is this gene inherited? And what are the implications for people who have elevated levels of this?**

- The *LPA* gene is in inherited through an [autosomal dominant](https://en.wikipedia.org/wiki/Dominance_(genetics)) pattern of inheritance
- If you inherit a genetic variant that’s associated with high Lp(a), chances are you’ll have high Lp(a) as well
  - Because you only need 1 variant and not necessarily 2
  - So you’d need either the allele from your father or your mother that will increase Lp(a)
- But it’s a bit more complex; it cannot be considered monogenic because there are 2,000 different variants in the *LPA* gene region that are associated with high Lp(a)
  - Your father can have high Lp(a) because of a specific variant and your mother can have an Lp(a) variant that lowers Lp(a)
  - But your Lp(a) level depends on the combination of SNPs that you ultimately get from both your father and mother
  - Children have very different Lp(a) levels than their mothers and fathers and it can’t really be estimated
    - Lp(a) has to be measured

**Thinking about when to have your Lp(a) measured**

- Lp(a) is fully expressed by age 2 in the liver and the level you have at 5 years old would only increase very slowly through adulthood

***Peter summarizes: You can’t predict the*** [***phenotype***](https://en.wikipedia.org/wiki/Phenotype) ***of the offspring from the phenotype of the parents***

**Contrast the** ***LPA*** **gene with the** ***apoE*** **gene**

- There are a lot of parallels between *apoE* and
- [*apoE*](https://en.wikipedia.org/wiki/Apolipoprotein_E) is a gene that today doesn’t seem to serve a purpose
  - All it seems to do is increase your risk of Alzheimer’s disease and even increase your risk of cardiovascular disease, independent of that
- There are three isoforms of the *apoE* gene— 2, 3, 4
  - It’s the 4th type that’s high risk
  - This genotype was associated with protection from parasitic infections in the brain, which would’ve been far more to our advantage a 100,000 years ago, 50,000 years ago, 10,000 years ago than the downside of Alzheimer’s disease in your 70s or 80s
- With *apoE*, because there are 3 discrete isoforms, there are only 6 combinations
  - So if you know what isoform your parents have, you can determine the probability of a given phenotype in their children
  - You would still need to measure it, but there is a finite number of outcomes
  - You would measure genotype (not phenotype); we don’t measure the phenotype of *apoE* yet

- With Lp(a) there are so many genes associated with it, that if the parents are both elevated, the probability that the offspring are also going to be elevated seems pretty high
  - If 1 parent is elevate and the other is not, there is a decent chance that the offspring will not have elevated Lp(a)

**Medical guidelines for measuring Lp(a)**

- Benoît notes that most guidelines will tell you to measure Lp(a) in everyone, at least once in their lifetime
  - They don’t specify the age when it should be measured
- Guidelines are just starting to advise for Lp(a)
- The American Heart Association guidelines (probably less favorable for Lp(a) measurement) tell you to measure Lp(a) in patients with ASCVD or aortic valve stenosis
  - Or a family history of ASCVD or familial hypercholesterolemia

> “*In other words, measure the Lp(a) once they’ve demonstrated that the disease that it causes is present*”— Peter Attia

- But if you look at the Canadian guidelines, they’ll tell you to measure it in everybody at least once in their lifetime
  - Peter notes, “*This is where Canadians also stand out over Americans, Canadians have long adopted the measurement of apoB as the superior measurement to quantify LDL risk. And yet here in the United States, the guidelines still favor the use of LDL cholesterol, which is clearly inferior to apoB*.”
  - Benoît adds that the Canadian guidelines are much more up to date with the recent literature on that
- The European guidelines actually advise to measure Lp(a) in everybody for a different reason
  - They want to identify patients who have very, very high Lp(a) because that might be the cause for familial hypercholesterolemia
  - You need to measure LDL to diagnose familial hypercholesterolemia
  - And after mutation in the LDL receptor, variation in the LP gene might even be the second cause of familial hypercholesterolemia
    - The reason for that is quite simple, because when you measure LDL, you also measure Lp(a) cholesterol
    - If you have a very high LDL and also a very high Lp(a), there’s a very good chance that the high LDL cholesterol will actually be high Lp(a) cholesterol
- Benoît is not sure if measuring Lp(a) is in the pediatric guidelines
  - In children who have strokes at a young age, many of them have high Lp(a)
  - The literature in children is not a clean as it is in adults

> “*If you have… relatives that had stroke at a young age, it might be a good idea to measure Lp(a)*”— Benoît Arsenault

- Peter’s takeaway— “*the amount of energy that goes into debating it is so ridiculous compared to the relatively low cost of simply measuring the thing. People who debate, why would you spend $14 on an apoB test? It’s like if your life isn’t worth $14, we shouldn’t be having this discussion. Same is true for measuring Lp(a). I think it should be done on everybody, non-negotiable, certainly before your 18th birthday, that would be my thinking on this*.”

## Niacin and other proposed therapies to lower Lp(a), apoB, and CVD risk [1:00:45]

**What’s the greatest number of Lp(a) to LDL you’ve seen?**

- Benoît doesn’t see patients; he’s a biochemist
- He’s seen some very interesting case reports on children that have FH and high Lp(a)
  - Some of them even had to have liver transplant because the lipids were just so high and they were having events during childhood
  - But those are only case reports; it’s not mainstream and he wouldn’t want to scare anybody
- Peter has seen a patient who had an Lp(a) of 690nM/L in the context of an LDL particle concentration of about 1,800nM/L
  - That’s a little over ⅓ of his LDL were Lp(a)

**Proposed therapies, the history of niacin and why this is not a good idea anymore**

- Sadly, some lipidologists still recommend the use of niacin to lower Lp(a)
- There are not any large cardiovascular outcome studies on literally any effect of niacin therapy
- Niacin therapy will reduce Lp(a) levels; it will increase HDL; it will lower triglycerides
  - The effects on plasma lipids are actually pretty good
  - However, if you’re looking at Lp(a), the reduction, the mean reduction will probably be about 20 or 30% with niacin
  - Some lipidologists that have seen very important reductions of Lp(a) with niacin, that they’ve decided to keep those patients on niacin
    - There’s no problem with that
- Even the latest guidelines of European Atherosclerosis Society to advise niacin treatment in some patients with high Lp(a)
- However, when you look at the actual evidence, there’s no cardiovascular benefit it in treating anyone with niacin
  - 2 large cardiovascular outcome trials are the [AIM-HIGH trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3862446/) and the [heart protection study 2-THRIVE trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3640201/)
- Niacin comes with a lot of side effects and not many benefits
  - Flushing is the most important side effect of niacin
- Niacin reduces the production, Lp(a) and Lp(a) still predicts the risk of events in patients treated with niacin
- The AIM-HIGH trial looked at the cost to benefit ratio for niacin, and the evidence really isn’t there to support niacin treatment

**A tangent on the difficulty in understanding HDL biology**

- Peter notes that niacin raises HDL but the outcome trials are clear that this does not translate into a benefit
  - This makes him think about [CETP inhibitors](https://en.wikipedia.org/wiki/CETP_inhibitor), they also cause HDL cholesterol to go up
    - But with this there were cases where more events were observed
    - Usually there was no effect or benefit of increasing HDL
- This points to the complexity of HDL biology and how much we don’t understand
  - We don’t have an assay for HDL functionality
  - The amount of cholesterol in an HDL particle tells us nothing about how the HDL actually works
    - You can have high cholesterol in an HDL particle because of all the cholesterol that’s entering it, or you could have high cholesterol in an HDL particle because not much cholesterol is leaving it
- Low cholesterol is valuable pharmacologically

**Back to Lp(a), reductions that would be beneficial and the time needed to see this benefit**

- In the case of Lp(a), it’s a little more confusing because niacin inhibits the production of Lp(a)
- What LDL and Lp(a) are doing to hurt you is easier to understand than what HDL is doing to help you
- Peter asks, “*So why do you think there is not a more clear signal between the use of niacin and the reduction of events?*”
- The Mendelian randomization studies have been very clear that you will need a very large reduction in Lp(a) to produce cardiovascular benefits
  - The first study Benoît mentioned provides only modeling, no trial data
  - It estimates that you would need 100 mg/dL reduction in Lp(a) to get a benefit in a trial to be comparable to a stating treatment
    - Around a 20% reduction
    - It’s hard to estimate the time needed to get this reduction
- The problem with looking at Mandalian randomization studies, you’re looking at primary prevention and at a lifelong reduction
  - This makes it hard to estimate the time needed for a trial to show benefit
- One study showed that a 100 mg/dL reduction over a lifetimes was needed to take the mortality curve down to the next rung
- Another study suggested 50 mg/dL, a 20% reduction was needed
  - But still over the course of one’s lifetime
- With the statin trials, they have between 2-7years of treatment in patients that already have disease
  - So you cannot really compare apple and oranges
  - That’s obviously a caveat of those studies because you’re trying to estimate the results of a trial using lifelong effects

**CETP inhibitors and apoB**

- With CETP inhibitors, there is evidence, at least for the [anacetrapib](https://en.wikipedia.org/wiki/Anacetrapib), that it might lead to cardiovascular benefit
  - This is the Merk drug
  - They stopped the trial even though it was trending in a positive direction
    - One reason for that was that they saw a lot of drug accumulation in adipose tissue, which is not something you want, if you want to prescribe a lifelong treatment
    - Secondly, the treatment effect was not spectacularly high, maybe a 6% reduction in the rate of events
    - This was a revealed trial
    - It was stopped maybe 2-3 years ago
    - It was a big trial with 30,000 patients; big trials are needed
  - So what they showed is that it was the reduction in the number of apoB lipoproteins that actually mattered

> “*The risk was not proportional to the HDL rising effect; it was proportional to the apoB lowering effect*”— Benoît Arsenault

- If you plot all the clinical trials together, if you plot the apoB lowering effect to the reduction in cardiovascular disease, you can see that all these trials line perfectly on the line
  - Even that specific trial with anacetrapib, it fell right on the line
  - Same with PCSK9 inhibitors, same with ezetimibe, any LDL lowering drug that’s out there, maybe a few exceptions, but it will land on this line
  - So it’s really not about HDL so much

> “*It just further convinced us to hit on apoB containing lipoproteins as hard as we can*”— Benoît Arsenault

- Peter laments about the fact that we even have apoB
  - We could survive with no circulating apoB and we wouldn’t have any atherosclerotic disease
  - We are fortunate that we understand the biology of [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) so much more than apo(a)
  - Eradicating apoB is becoming easier and safer
- Lp(a) is so important because of the residual risk in individuals, 20% of people are at risk because of high Lp(a)
  - This is higher than what Peter usually tells his patients, 10%
  - He didn’t realize he had been underestimating it in the population
  - 20% of the population has high Lp(a), that’s more than 50 mg/dL
    - Benoît clarifies this % depends on ethnicint; it’s certainly 15% of the population
    - Those with African ancestry have the highest Lp(a) levels; this is also true if you adjust for Lp(a) isoform size
- Peter’s takeaway:  “*Lp(a) is hands down the most common hereditary driver of ASCVD, correct? I mean, FH* [familial hypercholesterolemia] *wouldn’t even get within the same zip code when you think about genetic things that are driving atherosclerotic cardiovascular disease*.”
- High Lp(a) is the most prevalent form of dyslipidemia

**The penetrance of high Lp(a) is not 100%, so what other factors contribute to ASCVD?**

*The penetrance of high Lp(a) causing atherosclerotic cardiovascular disease is not complete*

- [Penetrance](https://en.wikipedia.org/wiki/Penetrance) is the proportion of individuals with a certain genotype that will have the disease
- The penetrance is not 100%
  - If it showed complete penetrance then everyone with high Lp(a) would develop disease; this is NOT the case

> “*It’s not everyone that has a high Lp(a) that will have an event”*— Benoît Arsenault

**There is a need to figure out what the drivers of risk are in patients with high Lp(a)**

- Benoît is starting to study this
- For instance, if you have a high Lp(a), but have lower [CRP levels [C-reactive protein]](https://en.wikipedia.org/wiki/C-reactive_protein) or lower inflammation, you might not have a risk that’s as high as if you have high CRP.
- So you can argue that residual inflammation is very important, but there need to be more studies on this because one can make the case that while it might be the same for smoking or type 2 diabetes or any other cardiovascular risk factor that you can think of

***Benoît’s conclusion— even if Lp(a) is not fully penetrant, it is so common that it is by far the most important form of dyslipidemia that w will explain a lot of cardiovascular events at the population level***

## Why awareness of Lp(a) among physicians remains low despite the importance of managing risk factors for ASCVD [1:14:00]

**Awareness of Lp(a) among physicians is low**

- Peter laments, “*What I find so tragic about that statement is the number of good physicians out there, really great doctors that are working hard, taking care of patients, frontline physicians, family medicine physicians, internists, who have no idea what it is*.”
  - They don’t know what Lp(a) is
  - Is this a uniquely American phenomenon?  Is there greater literacy around this in Canada and Europe?
- Benoît  doesn’t have any reason to believe that the literacy in Canada or Europe is higher than it is in the US
  - The inclusion of Lp(a) in their guidelines is new, and it will take a lot of time before they are implemented

> “*Sometimes it takes a full decade before it’s transmitted to younger generation of physician and people actually talk about it*”— Benoît Arsenault

- Benoît is hopeful that this podcast will raise awareness for physicians out there who don’t have any information on Lp(a)
- There’s so many guidelines out there that you can’t blame them for that
  - But that’s why we have to do more to educate physicians
- One of the reasons that people are reluctant to measure Lp(a) is because there’s no treatment or any medical procedure that you do
  - Asking for a measurement has benefits, but it also has consequences
- You don’t want to stress anybody out by saying “*Hey, you have this risk factor. It’s super important*”
  - And you don’t want to overdiagnose and overtreat

**The importance of managing risk factors for ASCVD**

- Even though there’s no specific therapy for high La(a), it doesn’t mean you can’t do anything
  - There’s trial data showing if you prescribe for instance, a statin, and if you lower LDL cholesterol levels in patients that have some risk factors for cardiovascular disease, you’ll reduce their risk of events

> “*In patients with high Lp(a), you need to manage LDL. You need to manage Lp(a). You need to manage lifestyle, smoking cessation, etc*.”— Benoît Arsenault

- Benoît has been working for over 15 years with investigators in Amsterdam and Cambridge on the [EPIC Norfolk study](https://www.epic-norfolk.org.uk/)
- The EPIC Norfolk study is the European Prospective Investigation into Cancer and nutrition
  - They have Lp(a) measurements in 18,000 individuals
  - He’s looked in that population at the effect of Lp(a) on the risk of events
  - But according to what the American Heart Association calls the life simple 7
    - Smoking, having a healthy diet, being physically active, having low body weight, LDL cholesterol, no diabetes, and blood pressure that’s on target
  - Patients with high Lp(a) that manage all of these risk factors could reduce their risk by ⅔
  - This is just an observational study
  - But this is 1 reason why we should measure Lp(a)
    - To identify this risk
    - And to target the other risk factors to prevent cardiovascular disease at the population level

**Parallels between Lp(a) and the** ***apoE*** **genotype**

- As recently as a couple years ago, Peter would have huge arguments with physicians about patients they were co-managing
  - The patient would want their *apoE* genotype measured, Peter would agree
  - But the physician would say, “*That’s an absolutely horrible idea. What good comes of that if they discover that they have an apoE4 gene and their risk is higher, all you’ve done is create anxiety*”
    - This is true for some individuals
    - But this argues that nothing can be done when this is not true
  - ***While you can’t change the gene, evidence shows that modifying behaviors provides an enormous reduction in risk***
- The case of apoE is more complicated because a few years ago we didn’t know about the other genes that will either amplify or attenuate the risk of apoE
  - Today, knowing you’re *apoE4* positive carries less information than it once did

## The variability of disease in patients with high Lp(a) [1:19:00]

**Peter has had patients with a modest increase in Lp(a) but the most devastating ASCVD you can imagine— how do you explain this?**

- Their Lp(a) was 125-150 nmol/L (60 mg/dL)
- They had 6-vessel disease and a calcium score of 2000
- These are people who have coronary artery bypass surgery in their 50’s
- Their LDL and apoB were not through the roof
- They’re not smokers or hypertensive or type 2 diabetic

**In another type of patient, why does a very high Lp(a) not result in early ASCVD?**

- No family history of advanced or premature ASCVD
- Extremely high Lp(a), 690 nmol/L
- A calcium score of zero, but this person was in their 40’s so you don’t expect a calcium score to tell you anything
  - It does confirm they don’t have advanced atherosclerosis
- One of their parents had an elevated level, but the grandparents had nothing

Peter asks, “*Why is it that this person seems somewhat immune from their very elevated LP little a, whereas this other person who’s elevated, but not through the roof is ravaged by it*”

**This is the subject of Benoît’s next grant proposal**

- He wants to study the penetrance of high Lp(a)
  - The penetrance of disease and why everyone with high Lp(a) doesn’t develop ASCVD
- In his lab they isolated the Lp(a) particle from the blood of donors and patients with aortic valve stenosis
  - The reason they’re going to study those particles is because those patients were matched for age, sex, statin therapy, smoking, etc.
  - They’re the same people, demographically speaking, but 1 of them has a disease and the other 1 doesn’t
  - They all have high Lp(a) and they were matched for Lp(a) levels
- ***He wants to know if there’s something happening in the Lp(a) particle***
  - Maybe patients with disease have more oxidized phospholipids
  - Maybe they have different proteins
- He’s found that these patients might have more [cell adhesion molecules](https://en.wikipedia.org/wiki/Cell_adhesion_molecule) that are transported by Lp(a), which make them more “sticky” to endothelial cells or vibrant clots, or maybe even macrophages
  - Because patients with high Lp(a) also have activated macrophages, which can penetrate the vessel wall much more easily
- In their macrophages, there is more apoptosis, more cytokine production (IL-6 I, IL-8, etc.)

***Benoît’s hypothesis is that there might be something that’s different in the Lp(a) particle that contributes to ASCVD and can be used as a metric to predict risk***

- Benoît’s team did a proteomics study to look at this, with about 20 patients in each study arm
  - It’s not easy to remove Lp(a) from the blood and get sufficient quantity so that you can actually do proteomics on it
  - It took a PhD student of his at least 1 year just to recruit the patients and isolate their Lp(a); there were 40 of them
  - Published in *Metabolites* in 2021, [Lipoprotein Proteomics and Aortic Valve Transcriptomics Identify Biological Pathways Linking Lipoprotein(a) Levels to Aortic Stenosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8307014/)
- Lp(a) is isolated by ultracentrifugation, but it has the same size as LDL and the same density as HDL
  - So you have to do chromatography columns to just separate it from LDL and HDL particles
  - They used size exclusion chromatography and affinity chromatography
  - He worked with [Marlys Koschinsky](https://www.robarts.ca/research/scientists/koschinsky_marlys.html) (at the Robarts Research Institute in London, Ontario) on this project
    - Her lab was one of the first to isolate Lp(a) from the blood of patients

***Findings: 1 hypothesis to explain different expression of disease in people that have high Lp(a) is those with disease have more cell adhesion molecules transported by their Lp(a) particles***

**Other hypotheses:**

- There is a need to look at other risk factors
- Maybe there’s another gene that’s out there codes for a receptor of LDL
- The figure below summarizes the atherogenicity of Lp(a)— proatherogenic, pro-inflammatory, and prothrombotic actions

![](https://peterattiamd.com/wp-content/uploads/2022/06/f8-benoit-1024x660.png)

**Figure 8. The atherogenicity of Lp(a) is mediated by 3 mechanisms**.  Image credit: [*Journal of the American College of Cardiology* 2017](https://www.sciencedirect.com/science/article/pii/S0735109716372540?via%3Dihub#bib9)

**Peter asks about results from GWAS (genome wide association studies)**

- Probably the best GWAS on Lp(a) levels was published last year by the group of [George Thanassouli](https://rimuhc.ca/-/george-thanassoulis-md) and [James Engert](https://rimuhc.ca/-/james-engert) (at McGill in Montreal)
  - Published in *Arteriosclerosis, Thrombosis, and Vascular Biology* in 2021, [Genome-wide association study highlights APOH as a novel locus for lipoprotein(a) levels](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7769958/)
- The biggest hit was the [*LPA* locus](https://en.wikipedia.org/wiki/Lipoprotein(a)#Structure)
- apoE also regulates high Lp(a) levels
  - The *apoE* allele that increases the risk of heart attacks will also elevate Lp(a) levels
- The gene [*CETP*](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein) also came up
  - We haven’t talked about the Lp(a) lowering effects of [CETP-inhibitors](https://en.wikipedia.org/wiki/CETP_inhibitor), which is higher than you can get with niacin therapy
- The problem with nacin trials and CETP trials is that they weren’t done particularly in patients with high Lp(a)
  - To properly study this you would have to recruit only patients with high Lp(a); this would get rid of 80% of the trial population
    - These trials would be very hard to do
- When you look at other genes, you have *CETP* and *APOH* (which is on another chromosome)
  - *APOH* codes for [beta2-glycoprotein I (β2GPI)](https://pubmed.ncbi.nlm.nih.gov/22569463/)
  - This protein might actually influence the presence of oxidized phospholipids on apoA
  - Benoît can’t think of a study that has tried to look at this locus with high Lp(a) to see if it has a modulatory effect on outcomes; that would be very interesting
- Interestingly, the LDL receptor and PCSK9 did not come up in that GWAS
  - PCSK9 is probably the most important regulator of the LDL receptor
  - This was surprising given the effect of PCSK9-inhibitors on Lp(a)

## Diseases most associated with high Lp(a) [1:26:30]

**Is it clear that Lp(a)s enter subendothelial space as LDLs do?  Or is that unclear?**

- Peter reviews the pathophysiology of ASCVD and the role of LDL in [AMA #34](https://peterattiamd.com/ama34/)
- Not as much research has been done on Lp(a)
- Postmortem studies show Lp(a) in atherosclerotic plaques and on the aortic valve
- Aortic valves are much easier to get than atherosclerotic plaque as you can remove the valve and then you can study it under the microscope
  - So there’s good evidence that the Lp(a) can actually penetrate there
  - Usually what they do is bind to clots that are in their region of the [atheroma](https://en.wikipedia.org/wiki/Atheroma)
  - They can also send their oxidized phospholipids to different receptors
    - We don’t know what the receptor for Lp(a) is in those tissues
    - At the surface of macrophages are receptors that might bind Lp(a)— [scavenger receptors](https://en.wikipedia.org/wiki/Scavenger_receptor_(immunology)), [toll-like receptors](https://en.wikipedia.org/wiki/Toll-like_receptor), and [CD36](https://en.wikipedia.org/wiki/CD36)

**Peter’s takeaway: Lp(a) plays less of a role in the initiation of atherosclerosis**

- Atherosclerosis is initiated by a monocyte becoming a macrophage in the subendothelial space and engulfing oxidized LDL to become a foam cell
- Lp(a) really lights things on fire once you already have a plaque, that’s where the ability to form a clot goes up
  - Potentially if there are more [VCAMS](https://en.wikipedia.org/wiki/VCAM-1) on it, [adhesion molecules] attracting more macrophages to the site of injury
- Benoît agrees, the macrophages of patients with high Lp(a) are already activated and a soon as there is some endothelial dysfunction, they’ll get there
  - They might even cause endothelial dysfunction

***Benoît’s summary: Lp(a) is probably a main driver before the onset of any discernible plaque, but it also has this double whammy where it also is associated with the progression of disease***

- They talked earlier about PET imaging with sodium fluoride
- These studies have also been done by [Erik Stroes in Amsterdam](https://www.amsterdamumc.org/en/research/researchers/erik-s.-g.-stroes.htm)
  - Instead of sodium fluoride, he used [fluorodeoxyglucose (FDG)](https://en.wikipedia.org/wiki/Fluorodeoxyglucose_(18F))— this is a marker of macrophage activation
  - He looked at the carotids and also the aorta of patients that have no disease, but that are separated on the basis of whether or not they have high Lp(a)
    - This showed a lot of light in patients with high Lp(a)
  - Published in *Circulation* in 2016,  [Oxidized Phospholipids on Lipoprotein(a) Elicit Arterial Wall Inflammation and an Inflammatory Monocyte Response in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4995139/)

**How high is the association between high Lp(a) and cerebrovascular disease?**

- Benoît notes that it is not as high but there is a signal
- Peter remarks that the association between high Lp(a) and ASCVD (and aortic stenosis) is very strong
- Benoît would rank aortic valve stenosis as #1
  - There are fewer contributing factors beyond Lp(a)
  - The relative risk is higher with high Lp(a) but the absolute risk is lower because there’s not that many people who have it
    - Maybe 2% of the population above the age of 60
- But if you look at top quintile versus lower quintile, the biggest risk is with aortic valve stenosis
  - After that, it depends on the study
  - Sometimes it’s myocardial infarction, sometimes it’s [peripheral artery disease (PAD)](https://en.wikipedia.org/wiki/Peripheral_artery_disease)
    - Lp(a) is very strongly associated with PAD

***Benoît’s ranking of diseases associated with high Lp(a), from most to least: aortic valve stenosis, PAD [peripheral artery disease], and MI, then ischemic stroke***

- It’s important to make the distinction between [hemorrhagic](https://en.wikipedia.org/wiki/Stroke#Hemorrhagic) and [ischemic stroke](https://en.wikipedia.org/wiki/Stroke#Ischemic) because Lp(a) is only associated with ischemic stroke
- It’s also associated with [chronic kidney disease (CKD)](https://en.wikipedia.org/wiki/Chronic_kidney_disease)
- Peter summarizes, “*Really, it’s only associated with aortic stenosis, MI’s, peripheral vascular disease, ischemic/ cerebral strokes, and kidney disease*”
- Benoît adds that there was some literature 15-20 years about on deep vein thrombosis and Lp(a), but the genome wide association studies haven’t seen a signal for this
- So it’s pretty clear that Lp(a) is more closely associated with atherosclerotic cardiovascular diseases and less with thrombotic events

**Do we have an assay for Ox-LDL?**

- Yes, but it doesn’t pick up the oxidized phospholipid of Lp(a); this is totally different
- [Sotirios (Sam) Tsimikas’s](https://profiles.ucsd.edu/sotirios.tsimikas) assay will measure oxidized phospholipids (Ox-PL’s) on apoB-containing lipoproteins
  - His assay measures Ox-PL’s on apoB, including Lp(a) of course, and also Ox-PL’s on apo lipoprotein little e, but the correlation coefficient between these two is very high
  - The correlation between Lp(a) levels and Ox-PL on apoB is also very high
  - This is a good predictor of all of the diseases that we’ve just mentioned
    - But it’s not a predictor beyond the level and number of Lp(a) particles

> “*I think we should advise people to measure Lp(a); that would be a gigantic step*”— Benoît Arsenault

- Once we get people to measure Lp(a), then we can see if measuring oxidized phospholipids would bring in added value
  - Benoît hasn’t seen data to suggest that it would though
- Peter stopped measuring Ox-LDL because he didn’t see any benefit to it over apoB; this sounds like the same thing
- Peter notes, “*It’s very complicated to know what to make of these oxidized phospholipid tails that are sitting around there, wreaking havoc, and potentially also forming part of this explanation for the differential expression of the disease*”
- Benoît agrees, and the same is true for LDL
  - LDLs also have oxidized phospholipids and that’s one of the reasons why the LDL particle causes ASCVD, but measuring them in plasma will not tell you how many oxidized LDL particles are in your plaques

> “*So that’s why we need to stick with apoB and Lp(a) because you’ll get a sense of all of the lipoproteins that cause atherosclerotic cardiovascular diseases*”— Benoît Arsenault

## The biology of PCSK9 protein, familial hypercholesterolemia, and the case for inhibiting PCSK9 [1:35:00]

**The PCSK9 protein and its relationship to the LDL receptor**

- [PCSK9](https://en.wikipedia.org/wiki/PCSK9) is short for proprotein convertase subtilisin/kexin type 9
- It was discovered in 2003 by a collaboration between [Nabil Seidah](https://www.mcgill.ca/expmed/dr-nabil-seidah) (who’s at McGill in Montreal) and [Catherine Boileau](https://esc365.escardio.org/person/208701) (who’s in France)
  - They identified this family in France that had a [familial hypercholesterolemia (FH)](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia), but they couldn’t find a mutation in the [LDL receptor](https://en.wikipedia.org/wiki/LDL_receptor) gene that disease

> “*This is one of my absolute favorite stories in all of medicine, certainly in the modern era of medicine*”— Peter Attia

- Their paper was published in *Nature Genetics* in 2003, [Mutations in PCSK9 cause autosomal dominant hypercholesterolemia](https://www.nature.com/articles/ng1161)
- To put this in context, this was around the time that the human genome was being sequenced
  - So this was before genome-wide association studies and whole genome sequencing
  - People were simply doing linkage analysis with satellite DNA
  - Benoît was an undergrad at the time
- They were able to map the gene in that family to a protein that was called NARC-1 at the time; they didn’t know that it was a [pro-protein](https://en.wikipedia.org/wiki/Protein_precursor) [convertase](https://en.wikipedia.org/wiki/Proprotein_convertase)
- When they identified that family in France,  they partnered up with Nabil Seidah who’s a world renowned scientist on pro-protein convertases
  - They mapped it to NARC-1, which eventually became PCSK9

**PCSK9 is a regulator of the LDL receptor**

- When cells make an LDL receptor, it will also make PCSK9
- PCSK9 can bind the LDL receptor inside the cell; this targets the LDL receptor to the [lysosome](https://en.wikipedia.org/wiki/Lysosome) for degradation
  - This can also happen extracellularly when the LDL receptor in an hepatocyte gets stuck in the membrane and PCSK9 is secreted
- PCSK9 can be measured in the blood
- When PCSK9 is secreted it can bind the LDL receptor; this blocks the LDL receptor from binding LDL particles

***Remember, the LDL receptor density at the surface of hepatocytes is super important for LDL clearance; secreted PCSK9 will prevent LDL receptors from taking LDL out of the blood***

- When they realized the importance of LDL receptors on hepatocytes for LDL clearance, families had been identified in Montreal that had a [gain-of-function mutation](https://en.wikipedia.org/wiki/Mutation#By_effect_on_function) in *PCSK9* and familial hypercholesterolemia
  - Published in *Nature Genetics* in 2003, [Mutations in PCSK9 cause autosomal dominant hypercholesterolemia](https://pubmed.ncbi.nlm.nih.gov/12730697/)
- Then [Helen Hobbs group](https://www.utsouthwestern.edu/labs/hobbs-cohen/) at UT Southwestern found common variants of PCSK9 that are associated with low levels of LDL
  - Published in *Nature Genetics* in 2005, [Low LDL cholesterol in individuals of African descent resulting from frequent nonsense mutations in PCSK9](https://pubmed.ncbi.nlm.nih.gov/15654334/)
  - They showed there are common variants in PCSK9 associated with lower levels of PCSK9, lower levels of LDL, and protection against cardiovascular diseases

> “*Now, the pharmaceutical industry didn’t need much more information to develop PCSK9 inhibitors, right?*”— Benoît Arsenault

**Peter’s summary of familial hypercholesterolemia**

- [Familial hypercholesterolemia (FH)](https://medlineplus.gov/genetics/condition/familial-hypercholesterolemia/) is a very heterogeneous disease
- There are at least 3,500 mutations that produce the exact same phenotype, very, very elevated cholesterol
  - The total cholesterol of these patients is typically north of 300 mg/dL
  - The LDL cholesterol, by definition is above 190 mg/dL (off therapy), and often much higher
- This disease is unequivocally linked to accelerated ASCVD
- What was discovered in 2003 was yet another gene that was associated with it
  - But what made it different is most of the genes associated with FH directly involved the LDL receptor
  - Instead, they discovered that it was this protein (PCSK9) that wreaks havoc on the LDL receptor when it’s over expressed either by degrading the LDL receptor in the lysosome before it gets brought to the surface, or just interfering with the receptor when it’s at the surface

**More about how PCSK9 reduces the level of LDL receptors on hepatocytes**

- Peter asks, “*Does PCSK9 also degrade LDL receptors, or increase their turnover when they are at the surface of hepatocytes?*”
- Yes, that’s the 3rd mechanism by which PCSK9 can influence LDL receptor density
  - What people don’t really appreciate is that the LDL receptor when it does its job of bringing LDL particles into hepatocytes, it gets recycled back to the surface of the hepatocyte
    - This can happen a hundred times in the life of the LDL receptor
    - Because, it takes a lot of energy to the cell to produce the LDL receptor
  - Once a PCSK9 is bound to an LDL receptor, it prevents this recycling
    - So, the cell has to make more LDL receptors; and that is under genetic control of the [SREBP-2 transcription factor](https://en.wikipedia.org/wiki/Sterol_regulatory_element-binding_protein_2)
    - So, then the LDL receptor gets produced, and so is PCSK9; resulting in this vicious cycle

**The case for inhibiting PCSK9**

- Peter summarizes, “*It’s interesting to think that if the story had stopped there, it’s not clear we’d be where we are today without the 2006 paper* [[2005 paper](https://pubmed.ncbi.nlm.nih.gov/15654334/)]*, which showed— wow, as bad as that gain of function is, the loss of function is really amazing. Where now, you found these people who had the opposite of FH. These are people who were basically missing their PCSK9, not completely, just significantly under expressed. And these were people that as adults walked around with neonate levels of LDL cholesterol, 10 20, 30 mg/dL*.”
- Benoît adds that the most frequent variant that they look at was present in 2% of the population; they saw very mild LDL reduction
  - It was a 20% reduction in LDL, but it’s a lifelong reduction
  - Further, the Mendelian randomization studies suggest this is beneficial
- There have been some studies on individuals who have virtually no LDL because they have no PCSK9
  - They don’t have atherosclerotic cardiovascular disease, because you need LDL for that
  - They’re perfectly fit; the loss of PCSK9 doesn’t influence reproduction or hormones or anything
    - No increase of risk for other diseases

> “*They just don’t have the risk of ASCVD and their LDL cholesterol is 10-20 mg/dL*”— Peter Attia

- Peter notes this is an **important teaching point**— how can someone with so little LDL in circulation not have other problems?
  - Cholesterol is important for creating the lipid bilayer of cells
  - Cholesterol is a precursor to steroidal hormones
  - Learn more on the website about [cholesterol](https://peterattiamd.com/?s=cholesterol)
    - [Cardiovascular disease and prevention](https://peterattiamd.com/category/diseases/heart-disease-prevention/)
    - Episode of *The Drive* [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/)

***When you look at how much cholesterol is in the body and isolate the fraction in the plasma, even if you take that to zero, you’ve maybe reduced the total body pool of cholesterol by about 10%***

- There is still some cholesterol in the blood because the liver will secrete [VLDL lipoproteins](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) that will not necessarily be targeted by PCSK9
  - There is also [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein)
- You still have a total cholesterol that might fall from 180 mg/dL to 60-70 mg/dL, but it’s not zero
  - The point is you still have so much cholesterol in extra-apoB tissue— red blood cells, hepatocytes, etc.

**What trials of PCSK9 inhibition have showed us**

- The industry is developing [monoclonal antibodies](https://en.wikipedia.org/wiki/Monoclonal_antibody) against PCSK9 and these have been tested in 2 large cardiovascular outcome trials
  - They’ve shown that if you reduce LDL through these PCSK9 inhibitors, you get a reduction in cardiovascular events
  - In these trials, all patients were already treated with statins, then you add on to that a PCSK9 inhibitor, and this really brings LDL cholesterol levels to the floor
  - Post-analysis of these trials show that the benefit was also correlated with the reduction in LDL levels
    - Patients that have the lowest LDL levels had the lowest risk of having a second event
    - It’s a second event because these trials were done in patients with stable CAD (coronary artery disease) and also acute coronary syndrome

***This tells us that we haven’t identified yet the level of LDL that’s so low, that it’s going to harm any physiological or disease process***

- ODYSSEY trial published in *The New England Journal of Medicine* in 2015, [Efficacy and Safety of Alirocumab in Reducing Lipids and Cardiovascular Events](https://www.nejm.org/doi/10.1056/NEJMoa1501031?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov)
- FOURIER trial published in *The New England Journal of Medicine* in 2017, [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1615664)
- Secondary analysis of FOURIER trial published in *JAMA Cardiology* in 2017, [Clinical Efficacy and Safety of Evolocumab in High-Risk Patients Receiving a Statin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5815002/)

> “*This is one of those beautiful moments again, where I was a little worried that FOURIER and ODYSSEY were not going to be positive trials*”— Peter Attia

- The FOURIER trial had patients with an average starting LDL-C in the 70’s
  - Benoît thinks the mean was 90 and treatment brought it down to 30 mg/dL
  - Before the trial, these patients were just being treated with a standard of care, high intensity statins
- Peter notes, “*If they came in on a statin maximally and their LDL was at 90, that’s still very low that still puts them at the 10th percentile. I thought it was 70. So, that would’ve been at the 5th percentile. But the point is, when patients come in and they already have such a low LDL, you add a drug that lowers them to the 30s, but the trial was only 5 years*.”
  - He didn’t think 5 years would be long enough to see a benefit, but he was wrong
- The trial was supposed to last five years, but they saw a benefit at 2.2 years
- They stopped the trial when they knew they had an effect
- There had been post analyses from phase III trials that were very positive in *The New England Journal of Medicine*
  - [Alirocumab and Cardiovascular Outcomes after Acute Coronary Syndrome](https://www.nejm.org/doi/full/10.1056/NEJMoa1801174)
  - In that trial, the relative risk reduction (if you compare PCSK9 with placebo) was only 15%
  - People were expecting a 20+ percent reduction, and many people were disappointed by that
    - But this happened over only 2.2 years; that’s what’s underappreciated

**Peter’s takeaway:** “*If you can hit a 15% relative risk reduction, which ultimately turned into a bigger risk reduction in 2.2 years on a group of patients who show up on the maximum dose of a statin whose LDL is already at the 10th percentile, you’ve changed the field of cardiovascular medicine*.”

***PCSK9 inhibitors are so effective in lowering apoB because they’re mimicking the most extreme loss of function of this gene; it’s taking away PCSK9 that does 3 things to reduce LDL clearance***

## The variability in PCSK9 inhibitors’ ability to lower Lp(a) and why we need more research on individuals with high levels of Lp(a) [1:50:30]

**Why don’t statins lower Lp(a)?  And the benefit of inhibiting PCSK9**

- - Why don’t statins lower Lp(a)?
    - Because Lp(a) levels are determined by their rate of production
  - One of the players that was unanticipated in Lp(a)/ apo(a) production is PCSK9
    - If you incubate liver cells with PCSK9, you’ll see the expression of apo(a) going up, and in lipoprotein turnover studies, you also see that
  - If you treat people with PCSK9 inhibitor, you will actually see a reduction in the production rate of apo(a)
    - There was a nice study that showed this (though complex) by Gerald Watts in Perth, Australia
    - Published in *Metabolism* in 2020, [PCSK9 Inhibition with alirocumab increases the catabolism of lipoprotein(a) particles in statin-treated patients with elevated lipoprotein(a)](https://pubmed.ncbi.nlm.nih.gov/32240727/)

- He also showed in a second group that if you treat patients with a PCSK9 inhibitor and the statin, you can actually see clearance of or increased fractional catabolic rate of Lp(a)

- Benoît notes, “*There’s still so much that we don’t know in this area, and it’s not totally clear why we see this difference of PCSK9 inhibitors that’s depending on whether or not you’re treated with a statin*”
- PCSK9 inhibitors lower Lp(a) by 25-30%, but the variability is enormous
- The variability is very important, and it’s another example where we need to study patients that have high Lp(a), because these are the patients that we want to provide an answer to
- There’s only been one trial that had tested the effect of a PCSK9 inhibitor in patients with high Lp(a)
- There have been sub-analysis in Fourier and Odyssey outcomes and in all these post hoc analyses of PCSK9 inhibitors in patients with high Lp(a)— the reduction is 15%
- In the Anitschkow trial run by [Zahi Fayad](https://icahn.mssm.edu/profiles/zahi-a-fayad) at Mount Sinai in New York, and [Erik Stroes](https://www.amsterdamumc.org/en/research/researchers/erik-s.-g.-stroes.htm) in Amsterdam, they show that even though LDL is greatly reduced and there is a small reduction in Lp(a) (15%), arterial wall inflammation is not affected
  - Published in the *European Heart Journal* in 2019, [Persistent arterial wall inflammation in patients with elevated lipoprotein(a) despite strong low-density lipoprotein cholesterol reduction by proprotein convertase subtilisin/kexin type 9 antibody treatment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6933872/)
  - ***Benoît’s takeaway: this means that there’s an important residual risk that’s associated with Lp(a) and we’re going to have to go after Lp(a) even in patients that have very low levels of LDL***
  - There was no outcome data on lowering LDL with PCSK9 inhibitors
  - They did link Lp(a) with recurrent cardiovascular disease in these trials but the pro-inflammatory effect of Lp(a) on the vasculature remains
- Peter asks, “*Is one interpretation of the fact that PCSK9 inhibitors can lower Lp(a) by 30%, but that might not be sufficient to ameliorate the LP little a risk, specifically, is that it’s just simply not enough*.”
- Benoît doesn’t know if we need to eliminate Lp(a) but we need to take a higher Lp(a) level and bring it down to a lower level

## Peter’s approach to managing patients with high Lp(a), and Benoît’s personal approach to managing his risk [1:54:45]

**Lipid management**

- Peter takes a 2-pronged approach to lipid management
  - 1 – Eradicate apoB to a physiologic level, the level a child has
    - His targets for apoB is to get it down to 30-40 mg/dL
    - Lower apoB without side effects from medication
  - 2 – Use PCSK9 inhibitors to reduce Lp(a), on average 30%

**Benoît’s Lp(a) level and his approach to management of risk**

- Benoît turned 40 this year and had his lipids checked and Lp(a) remeasured
  - His Lp(a) is very high, 200 mmolar
- He had his genotype done by a direct-to-consumer company that lets you look at your own data
  - They send you all of your [SNP](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) information
  - He looked at his favorite SNP in his Lp(a) gene and discovered he is a carrier of one of the most famous Lp(a) variants
- His LDL is a bit higher than average, his Lp(a) is high, so he began to take a statin
- He’s been on a close to vegetarian diet for more than 3 years, he’s physically active
- But looking at his labs, he wants to do more

> “*I see the importance of going after LDL very early and very aggressively*”— Benoît Arsenault

- He’s not on a super high dose statin, but will check it after 3 months
  - If his LDL doesn’t go down, he will increase the dose
  - This is what he thinks people with high Lp(a) should do

## Antisense oligonucleotides—a potential new therapeutic for Lp(a) [1:57:15]

**Future therapeutics, antisense oligonucleotides**

- This is a very exciting time for Lp(a) research with [antisense oligonucleotides](https://en.wikipedia.org/wiki/Antisense_therapy) against the [*LPA* gene](https://www.genecards.org/cgi-bin/carddisp.pl?gene=LPA) being developed
- Antisense oligonucleotides are single-stranded RNA that block the production of a specific protein, in this case Lp(a), by binding to the RNA in the cell that encodes that protein, summarized in the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/06/f9-benoit.png)

**Figure 9.  Antisense oligonucleotides for apo(a) block production of Lp(a) particles in the liver.** Image credit: [*Journal of the American College of Cardiology* 2017](https://www.sciencedirect.com/science/article/pii/S0735109716372540?via%3Dihub#bib9)

- The first one available will probably be from [Ionis Pharmaceuticals](https://www.ionispharma.com/ionis-innovation/pipeline/)
- The second one is a *siRNA* against *LPA* called olpasiran, developed by Amgen
  - Published a couple months ago in *Nature Medicine*, [Preclinical development and phase 1 trial of a novel siRNA targeting lipoprotein(a)](https://www.nature.com/articles/s41591-021-01634-w)
- Back to the first drug, their phase II data in patients with atherosclerotic cardiovascular disease showed that a monthly injection results in a mean reduction of Lp(a) by 80%, even in patients with high Lp(a)
  - Published in *The New England Journal of Medicine* in 2020, [Lipoprotein(a) Reduction in Persons with Cardiovascular Disease](https://pubmed.ncbi.nlm.nih.gov/31893580/)

> “*That’s very encouraging because this is what we’re going to need to prevent heart attacks*”— Benoît Arsenault

- They also showed that 90% of patients who were treated on that dose had Lp(a) levels below 50 milligrams per deciliter; so this drug is very potent
  - It’s a second generation antisense oligonucleotide

**HORIZON trial (in progress) to study the effect of antisense oligonucleotides on Lp(a) levels**

- They have launched a cardiovascular outcomes trial (that’s called HORIZON) to recruit around 8,000 patients with stable cardiovascular disease and study the effects of antisense oligonucleotides on Lp(a) and prevention of major atherosclerotic cardiovascular events
  - This is a secondary prevention trial
  - Peter asks why this trial is taking so long
  - It’s been delayed due to COVID
    - Their hospital was the COVID hospital for the entire region so people didn’t want to come to the hospital for an exploratory trial
  - They expect to have the results of the trial in 2025
  - Even though it’s going to have 8,000 patients, this is not enough
    - The FOURIER and ODYSSEY trials had 15,000 patients; this trial is recruiting half for roughly the same population
  - But they are going to use the full 4 years of their treatment period
- There are 3 companies with antisense oligonucleotides against Lp(a)
  - 1 – Ionis, which is partnering with Novartis for the trial.
  - 2 – Amgen
  - 3 – Another siRNA company called Silence Therapeutics; they haven’t released their phase I study yet

***Benoît’s summary: we can target LDL as low as we want, and there’s still a underappreciated amount of residual risk that’s associated with different things— triglycerides and inflammation, but the first thing that comes to mind is the risk associated with high Lp(a)***

**Peter’s recommendations**

- There’s a 10-20% chance your Lp(a) is elevated
- Demand that your physician checks this level; mg/dL is sufficient
- If you’re elevated (≥50 mg/dL), the best thing you can do at the moment is keep apoB as low as possible and manage all other risk factors that traffic with atherosclerotic cardiovascular disease—
  - Hypertension, smoking, insulin resistance, etc.
- Finally, you should at least once have an echocardiogram to look for early signs of aortic stenosis
  - It is imminently more treatable and the outcomes are better if it is addressed early

§

## Selected Links / Related Material

**AMA #14 discusses Lp(a) briefly**: [#111 – AMA #14: What lab tests can (and cannot) inform us about our overall objective of longevity](https://peterattiamd.com/ama14/) |  Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 18, 2020) | [3:45]

**Among 18 biomarkers, Lp(a) levels were the strongest predictor of cardiovascular risk**: [Oxidation-Specific Biomarkers, Lipoprotein(a), and Risk of Fatal and Nonfatal Coronary Events](https://www.sciencedirect.com/science/article/pii/S073510971002526X?via%3Dihub) | *Journal of the American College of Cardiology* (S Tsimikas *et al.* 2010) | [5:30]

**Genomic Investigation of Statin Therapy (GIST consortium) initial findings**: [Pharmacogenetic meta-analysis of genome-wide association studies of LDL cholesterol response to statins](https://www.nature.com/articles/ncomms6068) | *Nature Communications* (I Postmus *et al.* 2014) | [6:15]

**Guide to Mendelian randomization studies**: [Reading Mendelian randomisation studies: a guide, glossary, and checklist for clinicians](https://www.bmj.com/content/362/bmj.k601.full) | *BMJ* (NM Davies, MV Holmes, and GD Smith 2018) | [12:45]

**Genome wide association studies on Lp(a) published in 2009**: [Genetic Variants Associated with Lp(a) Lipoprotein Level and Coronary Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa0902604) | *The New England Journal of Medicine* (R Clarke *et al.* 2009) | [16:30]

- (only discussed 1 of 3 mentioned; no details for other 2 were provided)

**Statin treatment of patients with aortic valve stenosis resulted in a 20% increase in lp(a), ASTRONOMER trial results**: [Oxidized Phospholipids, Lipoprotein(a), and Progression of Calcific Aortic Valve Stenosis](https://www.sciencedirect.com/science/article/pii/S0735109715044654?via%3Dihub) | *Journal of the American College of Cardiology* (R Capoulade *et al.* 2015) | [33:00]

**Benoît’s publication with Patrick Mathieu on Lp(a) and autotaxin**: [Interaction of Autotaxin With Lipoprotein(a) in Patients With Calcific Aortic Valve Stenosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7524777/) | *JACC Basic to Translational Science* (R Bourgeois *et al.* 2020) | [40:45]

**Genomewide association studies of aortic valve calcification in the CHARGE consortium**: [Genetic Associations with Valvular Calcification and Aortic Stenosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3766627/) | *The New England Journal of Medicine* (G Thanassoulis *et al.* 2013) | [44:00]

**The concentration of Lp(a) not its mass is associated with CVD risk**: [Lipoprotein(a) Concentration and Risks of Cardiovascular Disease and Diabetes](https://pubmed.ncbi.nlm.nih.gov/31865966/) | *Journal of the American College of Cardiology* (DF Gudbjartsson *et al* 2019) | [50:30]

**The EPIC-Norfolk Study**: [The EPIC-Norfolk Study](https://www.epic-norfolk.org.uk/) | University of Cambridge (2022) | [1:13:15]

**Proteomics study of Lp(a) in people with aortic valve stenosis and without**: [Lipoprotein Proteomics and Aortic Valve Transcriptomics Identify Biological Pathways Linking Lipoprotein(a) Levels to Aortic Stenosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8307014/) | *Metabolites* (R Bourgeois *et al.* 2021) | [1:21:00]

**GWAS on elevated Lp(a) levels**: [Genome-wide association study highlights APOH as a novel locus for lipoprotein(a) levels](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7769958/) | *Arteriosclerosis, Thrombosis, and Vascular Biology* (M Hoekstra *et al.* 2021) | [1:24:15]

**Peter reviews the pathophysiology of ASCVD and the role of LDL**: [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 18, 2022) | [1:26:30]

**High Lp(a) is associated with inflammatory plaque**: [Oxidized Phospholipids on Lipoprotein(a) Elicit Arterial Wall Inflammation and an Inflammatory Monocyte Response in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4995139/) | *Circulation* (F van der Valk *et al.* 2016) | [1:29:30]

**Discovery of PCSK9**: [Mutations in PCSK9 cause autosomal dominant hypercholesterolemia](https://www.nature.com/articles/ng1161) | *Nature Genetics* (M Abifadel *et al.* 2003) | [1:36:15]

**Discovery of PCSK9 mutations in people with hypercholesterolemia**: [Mutations in PCSK9 cause autosomal dominant hypercholesterolemia](https://pubmed.ncbi.nlm.nih.gov/12730697/) | *Nature Genetics* (M Abifadel *et al.*  2003) | [1:38:30]

**Discovery by Helen Hobb’s group of PCSK9 mutations that result in low LDL**: [Low LDL cholesterol in individuals of African descent resulting from frequent nonsense mutations in PCSK9](https://pubmed.ncbi.nlm.nih.gov/15654334/) | *Nature Genetics* (J Cohen *et al.* 2005) | [1:38:45]

**ODYSSEY trial results of inhibition of PCSK9 with a monoclonal antibody**: [Efficacy and Safety of Alirocumab in Reducing Lipids and Cardiovascular Events](https://www.nejm.org/doi/10.1056/NEJMoa1501031?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov) | *The New England Journal of Medicine* (JG Robinson 2015) | [1:44:30]

**FOURIER trial results of inhibition of PCSK9 with a monoclonal antibody**: [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1615664) | *The New England Journal of Medicine* (MS Sabatine *et al.* 2017) | [1:44:30]

**Secondary analysis of FOURIER trial**: [Clinical Efficacy and Safety of Evolocumab in High-Risk Patients Receiving a Statin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5815002/) | *JAMA Cardiology* (RP Giugliano *et al*. 2017) | [1:45:00]

**Post analysis from phase III ODYSSEY trial**: [Alirocumab and Cardiovascular Outcomes after Acute Coronary Syndrome](https://www.nejm.org/doi/full/10.1056/NEJMoa1801174) | *The New England Journal of Medicine* (GG Schwartz *et al*. 2018) | [1:47:30]

**Inhibition of PCSK9 in patients with high Lp(a) did not alter arterial wall inflammation**: [Persistent arterial wall inflammation in patients with elevated lipoprotein(a) despite strong low-density lipoprotein cholesterol reduction by proprotein convertase subtilisin/kexin type 9 antibody treatment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6933872/) | *European Heart Journal* (L Stiekema *et al.* 2019) | [1:53:00]

**siRNA against** ***LPA*** **gene, Olpasiran**: [Preclinical development and phase 1 trial of a novel siRNA targeting lipoprotein(a)](https://www.nature.com/articles/s41591-021-01634-w) | *Nature Medicine* (MJ Koren *et al.* 2022) | [1:57:45]

**Clinical trial of antisense oligonucleotide targeting Lp(a)**: [Lipoprotein(a) Reduction in Persons with Cardiovascular Disease](https://pubmed.ncbi.nlm.nih.gov/31893580/) | *The New England Journal of Medicine* (S Tsimikas *et al.* 2020) | [1:58:30]

**Benoît’s faculty profile at the Institut Universitaire De Cardiologie Et De Pneumologie De Quebec Universite Laval**: [Dr Benoit Arsenault](https://iucpq.qc.ca/en/research/researchers#760) (2022)

**Benoît’s laboratory website**: [Labo Arsenault](https://laboarsenault.ca/) (2022)

**Read more about cardiovascular disease on our website**: [Cardiovascular Disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/) (2022)

**Study of natural variation in Lp(a) correlated with risk of CVD**: [Phenotypic Characterization of Genetically Lowered Human Lipoprotein(a) Levels](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5328146/) | *Journal of the American College of Cardiology* (CA Emdin *et al.* 2016)

**Review of the role of Lp(a) in cardiovascular disease and therapies**: [A Test in Context: Lipoprotein(a): Diagnosis, Prognosis, Controversies, and Emerging Therapies](https://www.sciencedirect.com/science/article/pii/S0735109716372540?via%3Dihub#bib9) | *Journal of the American College of Cardiology* (S Tsimikas 2017)

**Review of the role of Lp(a) in calcific aortic valve disease**: [Pathobiology of Lp(a) in calcific aortic valve disease](https://pubmed.ncbi.nlm.nih.gov/28816078/) | *Expert Reviews of Cardiovascular Therapy* (P Mathieu *et al.* 2017)

**Review of Lp(a) and RNA therapeutics**: [Emerging RNA Therapeutics to Lower Blood Levels of Lp(a): JACC Focus Seminar 2/4](https://pubmed.ncbi.nlm.nih.gov/33766265/) | *Journal of the American College of Cardiology* (S Tsimikas, PM Moiarty, and ES Stroes 2021)

**Review of genetic association studies on Lp(a) and CVD**: [Lipoprotein(a) and cardiovascular and valvular diseases: A genetic epidemiological perspective](https://www.sciencedirect.com/science/article/abs/pii/S0021915022001940) | *Atherosclerosis* (BJ Arsenault and PR Kamstrup 2022)

§

## People Mentioned

- [John Kastelein](https://esc365.escardio.org/person/24778) (professor at the University of Amsterdam, Benoît’s postdoctoral mentor) [4:45]
- [Kare Berg](https://en.wikipedia.org/wiki/K%C3%A5re_Berg) (Swedish scientist who discovered Lp(a)) [8:00]
- [Angelo Scanu](https://www.uchicagomedicine.org/forefront/heart-and-vascular-articles/cardiologist-angelo-scanu-md) (cardiologist at the University of Chicago who cloned and studied Lp(a)) [10:30]
- [Robert Clarke](https://www.ndph.ox.ac.uk/team/robert-clarke)  (Professor at the University of Oxford) [16:30]
- [Patrick Mathieu](https://www.patrickmathieulab.ca/) (heart surgeon and PI at Université Laval) [40:45]
- [George Thanassoulis](https://rimuhc.ca/-/george-thanassoulis-md) (Associate Professor at McGill University) [44:00, 1:24:15]
- [Wendy Post](https://www.hopkinsmedicine.org/profiles/details/wendy-post) (Professor of medicine at Johns Hopkins) [44:00]
- [Marlys Koschinsky](https://www.robarts.ca/research/scientists/koschinsky_marlys.html) (collaborator and Professor at the Robarts Research Institute in London) [1:23:00]
- [James Engert](https://rimuhc.ca/-/james-engert) (Associate Professor at McGill University) [1:24:30]
- [Erik Stroes](https://www.amsterdamumc.org/en/research/researchers/erik-s.-g.-stroes.htm) (Professor at Amsterdam UMC) [1:29:30, 1:53:30]
- [Sotirios (Sam) Tsimikas](https://profiles.ucsd.edu/sotirios.tsimikas) (Professor at UCSD) [1:33:00]
- [Nabil Seidah](https://www.mcgill.ca/expmed/dr-nabil-seidah) (Professor at McGill) [1:35:30]
- [Catherine Boileau](https://esc365.escardio.org/person/208701) (Professor at Hospital Bichat-Claude Bernard, Paris, France) [1:35:45]
- [Helen Hobbs](https://www.utsouthwestern.edu/labs/hobbs-cohen/) (Professor at UT Southwestern) [1:38:45]
- [Zahi Fayad](https://icahn.mssm.edu/profiles/zahi-a-fayad) (Professor at Mount Sinai) [1:53:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/06/bio-image-benoit.jpeg)

##### Benoît Arsenault, Ph.D.

Benoît Arsenault obtained his doctoral degree in Physiology-Endocrinology from Université Laval in Québec City, Canada in 2009. He did postdoctoral research at the Academic Medical Center in Amsterdam and at the Montreal Heart Institute.  Benoît is currently an Assistant Professor in the Department of Medicine at the Université Laval and a research scientist in the cardiology axis at the Centre de recherche de l’Institut universitaire de cardiologie et de pneumologie de Québec, in Canada.

The research of Benoît’s team is focused on understanding the risk of cardiovascular diseases such as atherosclerosis and aortic stenosis in relation to lifestyle and inherited risk factors. This includes extensive research in unraveling the role of Lp(a), HDL metabolism, PCSK9, and lipid-lowering therapies.  [[iucqp.qc.ca](https://iucpq.qc.ca/en/research/researchers#760)]