# #127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more

**Source:** [https://peterattiamd.com/matthewwalkerama3/](https://peterattiamd.com/matthewwalkerama3/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In this special episode, Matthew Walker returns for his third AMA episode to provide his expert insight into numerous sleep-related questions directly from listeners. He explains how he adjusted his hypotheses on topics like blue light and caffeine, and why he is more bullish on the importance of REM sleep. Matt also answers questions about sleep wearables, how fasting affects sleep, how sleep deprivation impacts gut health, and magnesium as a sleep aid. Finally, Matt reveals what he believes is the next evolution in sleep science and technology.

If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [show notes page](https://peterattiamd.com/matthewwalkerama3/) for this episode. If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Matt’s framework for changing his mind when faced with new information [1:30];
- Blue light—How Matt shifted his thinking [5:45];
- Caffeine—How Matt has adjusted his hypothesis [12:00];
- REM sleep—Why Matt is more bullish on the importance of dream sleep [16:30];
- How to increase REM sleep [27:30];
- Sleep tracking wearables—criteria for evaluation, and why Matthew favors Oura [35:00];
- Does the electromagnetic force of devices have any impact on sleep? [40:15];
- The relationship between fasting and sleep [46:15];
- Restless leg syndrome [58:10];
- Magnesium supplementation as a sleep aid [1:03:00];
- The relationship between sleep deprivation and gut health [1:08:30];
- The next evolution in sleep science and technology [1:16:30];
- Questions Matt would like to explore if money was no issue [1:24:15]; and
- More.

§

The Peter Attia Drive

Fasting, gut health, blue light, caffeine, REM sleep, and more

§

## Show Notes

## Matthew’s framework for changing his mind when faced with new information [1:30]

Special episode of The Drive where Peter discussed things he has changed his mind about: [Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/)

**How does Matthew think about changing in mind in the presence of new information?**

*Three buckets*:

1. Evidence that’s coming in that’s helping reinforce a belief making Matt more bullish
2. Beliefs which Matthew holds presented with new evidence that doesn’t change his mind but it might add a new construct in that equation
3. Contradiction: New evidence *against* his current hypothesis resulting in a rejection that hypothesis.

In summary:

- New information leads to his beliefs becoming
  - i) Stronger,
  - ii) more nuanced, or
  - iii) rejected

**Peter’s rant about science—**

- *His pet peeve*: When the media/press presents scientific information as **anything but probabilistic**
- Most people don’t have the opportunity to be educated scientifically, but those who are start to realize that it’s really ***all probabilistic***
- Data is very messy and therefore the best you can do when an experiment is concluded is increase your confidence in the **probability** of something being true or being false
- “***There’s no proving anything in science***.”

## Blue light—How Matt shifted his thinking [5:45]

**Overall**: Matt says the things he’s most changed his mind about recently is his understanding about the impact of blue light on sleep ⇒ “*I’ve actually down-regulated my belief in the effects of blue light.*”

In the book, for example, he wrote about [study from Harvard](https://www.pnas.org/content/112/4/1232) (which he still thinks is valid)—

- Participants either read on an iPad or a book under dim light for an hour
- It showed that the iPad had this detrimental effect on sleep by delaying the release of melatonin
- That caused a reduction in REM sleep
- The even concluded that the effect lasted a couple days after stopping the iPad reading at night

[Research by Michael Gradisar](https://jcsm.aasm.org/doi/10.5664/jcsm.3272) from Flinders University pushed back on that conclusion—

- This study suggested it’s that these devices ACTIVATE us, and that activation masks/mutes our sleepiness so we go to bed later and lose sleep
- It’s less about the blue light, and more about the devices ability to increase alertness/physiological arousal in the brain
- In other words, you were sleepy all along, but these devices hit a mute button on the sleepiness

In summary:

- The studies implicating blue light as especially bad for sleep were principally looking at melatonin
- In other words, they were simply saying, How does it affect your melatonin?
- But the next question should be, How does it then affect as a consequence of that change in melatonin?
- And it turns out that the melatonin piece may not be the principal reason why sleep is affected when you consider the brain arousal component
- “***It really sort of made me shift my belief system***.”

The next evolution of the science will be to do two types of studies—

- Firstly, a study where you use the same amount of light exposure but use different types of lights (type of light being the variable)
- Secondly, studies where the type of light actually becomes the **constant** stimulus where you maintain the same light exposure
  - But in one condition you’re doing something cognitively activating
  - And in the other condition you’re getting hit with the same light but not doing anything cognitively activating

## Caffeine—How Matt has adjusted his hypothesis [12:00]

**Overall**: Matt has added more construct to his beliefs around caffeine, sleep, and disease risk

**Caffeine and disease risk**

- While most evidence is associational from epidemiological studies, the evidence is mounting that coffee drinkers are less at risk to “a whole constellation of diseases”
- However, once you get past kind of like three or four cups, things go in the opposite direction
- Seems to be a very clear association between low-to-moderate caffeine consumption and de-risking health disease conditions

*\*Caveat*: Caffeine can disrupt your sleep

- And a lack of sleep is associated with an increase in the same diseases that are said to decrease in coffee drinkers
- Even knowing this, Matt says that he might be willing to encourage more coffee consumption if there is more causal evidence that emerges

The **dose** and **timing** is what matters:

- The dose AND the timing make the poison when it comes to caffeine—
- If you’re drinking it later in the day, you’re less likely to see those health benefits
- In fact, you would likely see health detriments

*More complexity to Matt’s hypothesis*:

- Matt’s thinking has been shaped after listening to the audiobook called [Caffeine](https://www.amazon.com/Caffeine-How-Created-Modern-World/dp/B083MYJXZT) by [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan)
- Pollan believes that the health benefits are not really due to a cup of coffee, but the fact that the coffee bean itself carries with it lots of **antioxidants**
- And for many Americans who don’t get a balanced diet, coffee in the morning may be one of the only primary sources of antioxidant consumption which may explain the health associations
- A [review paper from 2017](https://pubmed.ncbi.nlm.nih.gov/28826374/) showed that **decaffeinated coffee** carries the same antioxidant load, but without the caffeine

**Matt’s personal behavioral adjustment**:

- He now drinks **decaffeinated** coffee in the mornings
- He’s still concerned about caffeine’s effect on sleep even when consumed in the morning
- This [study](https://pubmed.ncbi.nlm.nih.gov/7796154/) showed that dosing people with caffeine at 7 AM lead to a reduction in the quality of that deep sleep

**Genetic differences amongst individuals**:

- There are genetic differences in how quickly people metabolize caffeine
- Some people have very little sensitivity to caffeine, for example, and for those people caffeine in the morning is fine

## REM sleep—Why Matt is more bullish on the importance of dream sleep [16:30]

**Overall**: Matt has become even more bullish on the importance of REM sleep

Backstory:

- All stages of sleep are important
- Different functions are carried out by different stages of sleep at different times of night
- Deep sleep is most commonly considered the most important and many people ask how they can get more deep sleep
- REM sleep, says Matthew, is “*sort of the neglected stepsister in the health conversation of sleep*”

Matt says the dismissal of REM sleep is disappointing for two reasons—

- 1) REM sleep is particularly important for emotional/mental health (see [Matt Walker-Part 4](https://peterattiamd.com/matthewwalker4))
- 2) A lack of REM sleep seems to be *more deadly* than a lack of deep non-REM sleep

*Evidence that lack of REM sleep is more deadly*:

- In the 1980s, scientists [selectively sleep deprived](https://pubmed.ncbi.nlm.nih.gov/2648533/) rats of REM sleep or non-REM deep sleep and found they die sooner from the lack of REM sleep
- A [recent study](https://jamanetwork.com/journals/jamaneurology/article-abstract/2767713) found a linear relationship between REM sleep and mortality—(i.e., the more REM sleep that you got, the lower your mortality risk and vice versa)
  - For every 5% reduction in your REM sleep, there was a 13% increase in your mortality risk
  - Not just all cause mortality, but specific disease states such as cardiovascular disease risk
  - They found that if you collect all of these sleep variables, **REM sleep was the single most predictive variable for your mortality risk**
- *Caveat*: These are *association studies* and do not confer causality

*How much REM sleep do we believe a person should have per night?*

- The recommendation for the *average adult* is for **about 20%** of your sleep to be consumed by REM sleep
- And it’s also age-dependent to a degree

**What is the age-appropriate breakdown of sleep stages as a percentage of total sleep?**

- One of the problems with sleep trackers is…
  - It tells you what percentage of your total sleep are consumed by deep sleep and REM sleep
  - However, it doesn’t tell you what the appropriate amount should be (e.g., Is 14% REM sleep good or bad?)
  - Note: It’s not the fault of the sleep tracking companies, they just don’t really have the data because there’s not much in the way of scientific literature around that

Matthew’s quest to create standardized norms—

- Matthew is working with [Dr. Raphael Vallat](https://twitter.com/raphaelvallat?lang=en) who has gathered over 14,000 nights of polysomnography across 14,000 people ranging in age from 5 to 97-years-old
- They’ve created statistical models of age-appropriate norms and hope to publish the data soon

In addition, they are working on a web-based tool—

- The idea is you go to a website and type in your age, sex, BMI, and other important data and it will tell you what your appropriate levels of deep sleep/REM sleep should be based on your age and physiology

**Could your sleep data predict your biological age?**

- Assuming sleep trackers eventually become close to 100% accurate (currently not there yet)…
- Using the data from a single night of sleep, it would be possible to predict your *chronological age* with about a 75% accuracy using our machine learning algorithms
- But what’s MORE interesting is that this data could contribute towards being able to predict your ***biological age***

> “Could we think that sleep could now provide a contribution to this Horvath clock of determining your biological age? Has sleep got some predictive signaling? I think it probably does.”

People working on [epigenetic clocks](https://en.wikipedia.org/wiki/Epigenetic_clock):

- [David Sinclair](https://genetics.med.harvard.edu/sinclair/people/sinclair.php)
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath)

⇒ Here’s the [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7271997/) that Matt and Peter recently published together

## How to increase REM sleep [27:30]

Deep non-REM sleep is easier to manipulate than REM sleep

- Peter provides tips for more deep sleep in [AMA #12](https://peterattiamd.com/ama12/)
- Matt’s [review paper](https://www.cell.com/trends/neurosciences/fulltext/S0166-2236(18)30064-X) with methods that have been used to improve deep sleep quality

**The challenge of getting more REM sleep**

- REM sleep is very difficult to modulate in an easy way
- There’s a neurochemical in the brain called [acetylcholine](https://en.wikipedia.org/wiki/Acetylcholine) and REM sleep is powerfully regulated by acetylcholine
- So people would manipulate this pharmacology to do REM sleep manipulation
- But since most people are not going to have (nor should that want) anticholinergics or pro-cholinergic agents (Plus they also have side effects in the body because it also controls things like smooth muscle out in the periphery)

*So how can you do this?*

- Matt has one idea that he’s about to start testing and it has to do with **temperature**
- For deep sleep, you *cool the body* to actually increase deep sleep—You actually have to warm up to get cold, to get to sleep, and then you have to stay cold to stay asleep and get deep sleep
- But then to wake up, you have to **warm up**
- But now we’re talking about needing a temperature increase in order to increase REM sleep BEFORE you wake up

**More about the nature REM sleep**—

- REM sleep is a bizarre state where the brain seems to get disconnected from the body in terms what’s called the autonomic regulation (during REM sleep become very autonomically dysregulated)
- What this actually means is that your brain’s systems of controlling and regulating your nervous system (sympathetic and parasympathetic) and your automatic functions (breathing and respiration) all go out the window during REM sleep
- And in fact, you go into these huge accelerations in heart rate, then your heart rate decreases, and then increases again (and it’s not predictable, it’s very erratic)
- **Your temperature is also uncontrolled**—In other words, you stop thermoregulating during REM sleep

*How does this lack of thermoregulation help us think about increasing REM sleep?*

- **Thermoneutrality** is when you can get the temperature around your body (i.e., under your covers) to the same temperature that is natural for your body
- And if you can match those two things, you can get to thermoneutrality and **promote REM sleep**
- As you go further away from thermoneutrality for your body, you disrupt REM sleep
- The hard part is actually monitoring your body temperature with a device and then exquisitely control your body temperature to keep you in the sweet spot of thermoneutrality sweet spot during the *last two hours of your sleep*
- If that can be done precisely, you can increase your REM sleep

*Would something like the Ooler work for this?*

- Peter is a huge fan of a device called an [Ooler](https://www.chilitechnology.com/products/ooler-sleep-system)— a water-cooled pad that goes under your mattress
- Peter asks whether you could simply have a setting added that increases the temperature a few hours before you were planning to wake up in order to increase REM sleep
- Matt says that that can work for the process of *waking up***,** but *probably not for increasing REM sleep*

*To specifically increase REM sleep, you need a* ***closed-loop system*****—**

- By that he means you need real-time data to understand the exact temperature of your body and the  exact stage of sleep that you’re in
- And in order to compliment those—to “close the loop”—you need to be constantly monitoring and tweaking, monitoring and tweaking, to keep you in this sweet spot
- Matt says that they are currently exploring this concept and he is “*actually quite excited about it especially because I’ve now become so bullish on REM sleep*”

## Sleep tracking wearables—criteria for evaluation, and why Matthew favors Oura [35:00]

**Matt thinks about 2 different criteria when it comes to wearables**:

1—Accuracy of sleep data relative to the gold standard of recordings in the sleep laboratory

- [Oura Ring](https://ouraring.com/) does a decent job of that (FitBit and other may be similar in accuracy, says Matt)
- Looking at the entire industry of sleep trackers, they are about 70% overall accurate in terms the measurement of *total sleep*
- The accuracy starts to decline for the different *stages of sleep*
- The accuracy is particularly bad for the amount of time that you are awake at night, meaning your “wake after sleep onset”
- Matt says he is excited to work for Oura to see if he can help improve the accuracy

2—Form factor

- When we go to bed, we typically take things off, we don’t put things on
- Sleep tracking devices that use headbands or wristwatches devices are things that are typically not worn in bed
- So while they may have some advantages to them, Matt thinks the adherence, the compliance, is going to be low for those types of things
- Even if watches, headbands, and the like are 100% accurate, they are useless if people won’t consistently wear them

*It’s a two-by-two matrix*—

- On the one hand, I’ve got how accurate it is
- On the other hand, I’ve got how friction-full or friction-less the device is.
- What you want is a device that’s **very low friction and very high accuracy**

![](https://peterattiamd.com/wp-content/uploads/2020/09/high-accuracy-low-friction-300x300.png)

**Figure 1. 2 x 2 matrix showing ideal tracking device qualities.**

**Some reasons why Matt favors the** [**Oura Ring**](https://ouraring.com/):

- It has comparable accuracy to other devices
- It has some sensing advantages like body temperature
- And being it’s a ring, Matt says there’s a higher likelihood for compliance

## Does the electromagnetic force of devices have any impact on sleep? [40:15]

*Is there any evidence that simply having electronics in a room, through some form of electromagnetic force, is impacting sleep?*

*In other words, if you take the light stimulation out of the equation, does that have any bearing on sleep?*

- There’s no evidence that the electromagnetic force of one of those devices impacts someone’s sleep
- Perhaps that would change is someone essentially duct-taped a device to their head (only Peter did that in medical school so as to not sleep through getting paged at night)
- Matt says the first place one might look is at environmental studies where you look at people who are living very close to high-grade, overhead power lines
- The problem is that this type of data may not be useful since there would be so many confounding variables

## The relationship between fasting and sleep [46:15]

**Sleep issues with prolonged fasting**

- Peter says some of his patients who do multi-day fasting (3+ days) will struggle with falling asleep and staying asleep at night (less so with time-restricted eating or just a 1-day fast)
- On flip side, the sleep you DO get actually seems remarkable
- Peter, for example, notices that the following sleep metrics improve:
  - Heart rate variability goes up by 25- 50%
  - Resting heart rate goes down
  - Body temperature goes down
  - His best nights in terms of staging—Deep sleep is 25%, REM sleep is 25%.

*What are Matt’s thoughts overall on the relationship between food deprivation and sleep?*

- Matt commonly hears the following from fasters—
  - They struggle with falling asleep and staying asleep
  - However, he also hears in many cases that the lesser amount of sleep doesn’t bother them
  - In other words, they don’t feel as sleepy as they normally would (i.e., that little sleep would normally have them feeling miserable)

*What might explain these observations?*

- Some animal literature centers around a chemical called [orexin](https://en.wikipedia.org/wiki/Orexin)
- In the middle of your brain there is a tiny structure called the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus)
  - Despite its size, it has profound effects on almost all of our behaviors, such as:
    - Eating behaviors
    - Sleep-wake regulation
    - Thermoregulation.
  - And within the hypothalamus, there is a cluster of cells called orexin cells
    - One of their functions is to actually monitor the body’s energy balance by sensing, among other things, concentrations of circulating levels of leptin and ghrelin
    - They essentially get a map of the body’s energy balance.
    - The brain’s sensing neurons will release the chemical contained inside of them, which is called orexin.

⇒ See this paper: [Role of orexin in modulating arousal, feeding, and motivation](https://pubmed.ncbi.nlm.nih.gov/23616752/)

*How is orexin relevant to sleep?*

- Orexin turns out to be a wake promoting chemical
- So when you release and dump orexin into the brain and the body, it wakes the brain up
- Normally it shuts down at night and that’s part of the mechanism of what we call the sleep-wake switch

*What attenuates orexin during a fed state?*

1—Hunger signaling hormones like leptin and ghrelin will regulate it

2—It’s also regulated by the master circadian clock called the [suprachiasmatic nucleus](https://en.wikipedia.org/wiki/Suprachiasmatic_nucleus)

- Orexin, like many other hormones and chemicals, seem to be under the control of our 24 hour circadian rhythm which is regulated by the suprachiasmatic nucleus
- You can think of this as the central master clock of the brain which also regulates the release of other things (like melatonin from the pineal gland) and essentially giving out the instructions as to when to release wake promoting chemicals like orexin and when to release sleep promoting chemicals

3—Another part of regulation of orexin is independent of your sleep-wake, it’s actually **dependent on your body’s energy balance**

- When animals go under conditions of starvation, these orexin cells sense the change in the energy balance and they start dumping out more orexin which forces the animal artificially awake for a longer period of time
- The evolutionary reason is because it’s recognizing that the amount of time the animal is normally awake for it to forage for food is not sufficient because it’s starving
- In other words, the **brain is telling the animal to stay awake longer so it can find more food** and avoid starvation
- In *humans* under conditions of fasting, Matt thinks **you are giving the body an ancient, evolutionary signal of starvation which causes the brain to dump more orexin into the system** and therefore your sleep becomes compressed

\*Partial explanation for why sleep metrics improve while in a fasted state:

- It turns out that while the sleep is compressed, the body makes up for that by increasing the quality of that  sleep (something you see with insomnia patients being treated with sleep restriction therapy)
- Important note: This is NOT sustainable over the long term
- But, it does partly explain the observations of
  - i) improved sleep metrics, and
  - ii) people subjective feeling like they aren’t as sleepy as they typically would expect due to the shorter

**Potential therapeutic implications**:

- If compliance to fasting would be better if people got better sleep, a pharmacological agent that blocks orexin might be beneficial
- In fact, several years ago, there was a company that created a new sleep medication called [Belsomra](https://en.wikipedia.org/wiki/Suvorexant)
- While standard sleep meds are just knocking out/sedating the cortex., Belsomra targeted the orexin system
- The thought was that insomnia patients might have artificially enhanced orexin at night
- Unfortunately, the results were disappointing for insomnia patients
- But Matt wonders if perhaps it was “right drug, wrong question” and wonders if Belsomra could be taken by fasters to quiet the orexin signal

**Peter’s sleep hack — Trazodone**

- [Trazodone](https://en.wikipedia.org/wiki/Trazodone) is drug that formerly found its use as an antidepressant at much higher doses, but it wasn’t a very successful
- It became a drug that had no application until people realized that it was a pretty good sleep drug preserving sleep architecture
- Peter personally has found that 25-50 milligrams of trazodone to be a magic bullet when he’s struggling to sleep due to hunger issues
- NOTE: Peter doesn’t recommend this without a doctor’s supervision and only uses in rare instances

## Restless leg syndrome [58:10]

**About restless leg syndrome (RLS)**

- It’s a long-term disorder usually characterized by uncontrollable, and really uncomfortable, urge to move your legs (can also happen in other limbs like the arms)
- People with RLS can’t wear traditional sleep trackers because the motion throws it off
- It effects between 5 to 15% of the population

**Hypotheses on the mechanisms of why it’s happening**

Hypothesis 1: The principle hypothesis is that it’s due a deficiency of dopamine in the brain

- Dopamine has many functions and is most commonly thought of having a hedonic — sensation seeking, motivating chemical
- A lesser known function is that of *muscle control*
  - Example, patients with Parkinson’s disease have degeneration of dopamine neurons in a specific part of the brain that makes them unable to initiate specific motor actions.
- So one theory is that people with RLS are deficient in dopamine
- The first line treatment approach is dopamine agonists to increase the amount of dopamine
  - But the results have been mixed at best
  - And one of the problems is that you start to tolerate the dose of the dopamine which means you have to increase the amount of dopamine
  - Too much dopamine can trigger a change in people’s personality and behavior towards reward seeking, sensation seeking

Hypothesis 2: RLS is due to an iron deficiency

- Supplementing iron for people restless leg syndrome with iron has had mixed results at best
- Problems with iron supplementation is that it’s not a particularly bio available so only a fraction makes it into your system

**More on iron supplementation from Peter**:

- Peter looks at [ferritin](https://en.wikipedia.org/wiki/Ferritin) instead of iron
- Ferritin is a better statement of what the total body iron stores are of that moment whereas iron levels can move quite a bit from day to day
- But once you know the ferritin and the total iron binding capacity, you can get a sense of whether or not a patient is truly iron deficient.
- An iron deficient patient will have low ferritin, a high total iron binding capacity, and generally low, but not necessarily very low, iron
- When supplementing, you’re also balancing against side effects like constipation
- [Dr. Ralph Esposito](https://www.instagram.com/dr.ralphesposito/) is the resident iron expert at Attia Medical

## Magnesium supplementation as a sleep aid [1:03:00]

**How Peter uses magnesium**

- Peter is a big proponent of something called Magnesium L-Threonate
- It is essentially a transporter that, in theory, gets the magnesium into the brain more
- He takes two capsules of Magnesium L-Threonate before bed, every night as part of his sleep protocol
- He also takes magnesium oxide in the evening

**Matthew’s insight into magnesium as a sleep aid**

- General magnesium supplementation is very commonly taken for sleep
- The idea is that it helps relax the body and relax the muscles
- However, there’s actually **little good scientific evidenc**e supporting the benefits

*Why is it discussed so much?*

- There is evidence that people who had sleep disruptions have a deficiency in magnesium (Mg)
- For those people deficient in Mg, supplementing with Mg could be part of the equation for better sleep
- However, that’s a very different things than someone who is NOT deficient could get better sleep by supplementing with Mg
- Matt is not aware of any literature showing good causal evidence that magnesium supplementation actually improves someone’s sleep

That said…

- Absence of evidence is not evidence of absence, so if good scientific studies are done, we may find it helps
- The placebo effect is one of the most reliable effects in all of pharmacology, so if you think that magnesium is giving you a benefit to the quality of your sleep, maybe there’s no harm in it

*\*Be cautious*\* — Magnesium as a supplement is unregulated by the FDA

**Peter’s preferred brands**:

- Peter’s preferred magnesium L-Threonate is made by a company called [Magtein](https://magtein.com/?gclid=CjwKCAjwkJj6BRA-EiwA0ZVPVrn13zzzNne52olR9-Jo5ARcCM16YJjaHdmij2jiTFvQVOVTlQ71mxoCgI0QAvD_BwE)
- Peter also likes a magnesium products from [Nature Made](https://www.naturemade.com/search?type=product&q=magnesium)

## The relationship between sleep deprivation and gut health [1:08:30]

**Matt’s thoughts on the relationship between dysbiosis (leaky gut) and bad sleep**

- Matt says there is evidence starting to emerge about how sleep deprivation leads to poor gut health

Matt’s working with a company called [ZOE](https://joinzoe.com/) in the UK that is tracking the gut microbiome data and Matt is helping to bring sleep into their analysis

- Early data is showing that when you sleep deprive either human beings or animals, you see a shift in the gut microbiome balance away from the bacterial bent and more towards the **fermented bent** of the microbiome
  - [Benedict et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5123208/)
  - [Poroyko et al., 2016](https://www.nature.com/articles/srep35405)
- That shift is interesting because there’s an [association between poor health outcomes and a gut microbiome with a fermented bent](https://link.springer.com/article/10.1007/s40675-018-0100-0)
- Using that logic, sleep deprivation is pushing you into a gut microbiome profile that is not optimal
- Another [experiment](https://www.cell.com/cell/fulltext/S0092-8674(14)01236-7) mimicked jet lag and it also produced that same deleterious shift towards the fermented gut

More recent data comes from a [Harvard paper](https://www.cell.com/cell/pdf/S0092-8674(20)30555-9.pdf?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867420305559%3Fshowall%3Dtrue)—

- If you sleep deprive fruit flies (and rats), they will die
- But this study investigated what could be killing the fruit flies when they’re deprive of sleep and they focused in on free radical damage from reactive oxygen species (ROS)
- They found a vast amount of ROS proliferating—NOT all over the body in all of the major organ systems—but it was expressly happening in the gut of the fruit flies
- So something strange is going on in the gut regarding free radical damage caused by a lack of sleep.

Next, that same [Harvard study](https://www.cell.com/cell/pdf/S0092-8674(20)30555-9.pdf?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867420305559%3Fshowall%3Dtrue) did something elegant—

- They started dosing the flies with ~20 different antioxidants and they were able to keep the flies alive despite sleep depriving them *if they treated the reactive oxygen species*
- The most interesting insight from that study—
  - Melatonin is a [remarkable antioxidant](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6332205/)
  - They found melatonin to be one of the chemicals that seem to be beneficial in preventing these reactive oxygen species
  - **Caveat**: We don’t know if this is going to be replicated in animals, in mice or rats, and we certainly don’t know if this is true in humans
  - But if it did, then melatonin could be an interesting counter measure to help us protect human beings when we have obligatory sleep deprivation

![](https://peterattiamd.com/wp-content/uploads/2020/09/melatonin-and-the-gut-1024x601.png)

**Figure 2. Melatonin extends the life of sleep deprived flies—Figure B shows examples of survival curves for three rescuing compounds: melatonin, lipoic acid, and NAD. The compounds that were able to rescue survival were effective at clearing ROS (Figure C). Rescue of survival was achieved without increasing sleep itself; all animals remained sleep deprived when supplemented with antioxidants. This was true even for melatonin, primarily known for its effects on the mammalian circadian clock, melatonin does not seem to play a major role in controlling circadian rhythmicity or sleep in flies. A lesser known fact is that melatonin is a potent antioxidant (**[**Tan et al., 2015**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6332205/)**), produced at high levels in the vertebrate gut.** Image credit: [Vaccaro et al., 2020](https://www.cell.com/cell/pdf/S0092-8674(20)30555-9.pdf?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867420305559%3Fshowall%3Dtrue)

**Application in the real world**:

- Ideally, there is no “need” for sleep deprivation therefore no need to treat for it
- But the reality is that there is an obligatory need for sleep deprivation at certain times (think about an emergency surgeon on call) and **we’re not protecting those individuals as best we could do**
- Matt thinks that perhaps melatonin could be a countermeasure to “obligatory sleep deprivation”

## The next evolution in sleep science and technology [1:16:30]

Idea #1—**Personalizing sleep medicine**

- Matt would like to create technology that could act as a truly personalized sleep coach
- The technology ingests every piece of data about you
  - Bio-tracking data about your physiology
  - Data about your **mental state**
  - Data out of your calendar as to
    - what you’ve been doing
    - what you’re doing today, and
    - what you’ve got upcoming in your future (E.g., it will know if you have a trip coming up that involves traveling through different time zones)
- After ingesting all the data, for each specific day and evening it would create a personalized, tailored sleep prescription for you
- It’s going to tell you—
  - The best things for you to do today for your sleep
  - When you should be doing them
  - How much of them you should be doing
  - When you should be trying to get to bed
  - When you should be waking up
- When you do go to bed, it’s going to integrate this with the closed loop technology that Matt described earlier
  - (see section above: How to increase REM sleep [27:30])
- It will modulate your sleep, not just for that night, but I’m going to start shifting you, for example, for the travel you’ve got coming up
- The idea is to get you as close as possible to the **perfect sleep schedule**
- Furthermore, it will modulate your food intake, your light intake, your home thermostat for optimal temperatures, even the light in your car when you get into it on the basis of the automatic dimming screens

> “I’m going to create a personalized sleep prescription coach. It’s going to be tailored to you like a Savile Row suit.”

\*\*\*

Idea #2—**Predictolytics**

- This has largely been considered in behavioral change to shift you away from maladaptive behaviors
- Good example would be smoking:
  - If you continue this habit, in 20 years time…
    - This is how you will look, this is how your teeth will look
    - Here are the different disease curves and the trajectory of your risk for cardiovascular disease for stroke
  - Then, you show them how those things change if the habit of smoking is reduced…
    - I.e., If you go down to 10 cigarettes a day rather than 20, or down to 5, or down to 0…
      - Here’s how you’re going to look in 20 years
      - Here’s the change in your risk profile for these different diseases
- Matt wants to do something similar with sleep:
  - If you continue sleeping only 5.5 hr/night…
    - This is your disease trajectories (i.e., Alzheimer’s, hormones, mental health, heart disease, etc.)
  - But if you increase your sleep time time to 7, 7.5, or 8 hrs per night…
    - Here’s how those things change
  - The person can then be offered simple suggestions (e.g., bedtime alarm and wake alarm)
- Right now we’re doing a lot of quantification in the world of tracking, but we’re not doing much modification

> “I’m interested in these ideas of ‘predictolytics’ because I can do modification on the basis of quantification.”

## Questions Matt would like to explore if money was no issue [1:24:15]

Question #1—**Super agers** — *Could sleep represent a new “physiological blue zone”?*

*Cognitive decline with age*

- As we get older our sleep gets worse, and that seems to predict cognitive decline, e.g, an escalation in Alzheimer’s disease related proteins (tau and beta amyloid)
- But what about these centenarians who don’t see the same cognitive decline?
- For example, there are times when two individuals will present with the same amount of tau and beta amyloid in the brain, yet one person has no cognitive decline whereas the other has massive cognitive impairment
- Matt wonders whether or not **sleep** is an unknown factor that is coming in and creating a cushion, or a force that is a countermeasure against pathology

*Metabolic and inflammatory markers*

- If you look at this patient’s blood work and you see high C-reactive protein, insulin resistance, and other markers of aging, but yet they still seem to be alive and healthy…
- Is sleep this countermeasure in all of this? Is sleep and new physiological blue zone?

Matt is hoping to get in contact with [Dan Buettner](https://en.wikipedia.org/wiki/Dan_Buettner) who has famously discussed in his [TED Talk](https://www.ted.com/talks/dan_buettner_how_to_live_to_be_100?language=en) the idea of “blue zones” where people live a long time — Matt thinks sleep needs to be added into his considerations

Peter also suggests talking with [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/) who probably has the largest data set on centenarian

\*\*\*

Question #2: *Can I find a way to compress human sleep without any downside?*

- There is this incessant march of modernization that continues to want us to sleep less
- As much as Matt tries to change that mentality, the pressure remains overwhelming

With unlimited resources and unlimited time, Matt says, “*One of the things  would like to try and do is find out if I can discover a technological way  to develop some kind of technique where I can compress sleep down to four hours, four and a half hours, and it remains just as good as eight hours of sleep.*”

§

## Selected Links / Related Material

**Special episode of The Drive where Peter discussed things he has changed his mind about**: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/) | Peter Attia (peterattiamd.com) [1:30]

**Harvard study looking at the negative impact on sleep of blue light from an iPad**: [Evening use of light-emitting eReaders negatively affects sleep, circadian timing, and next-morning alertness](https://www.pnas.org/content/112/4/1232) (Chang et al., 2015) [6:00]

**Study by Michael Gradisar that suggests the impact of devices on sleep is more due to the mental stimulation and activation of the mind than blue light**: [The Sleep and Technology Use of Americans: Findings from the National Sleep Foundation’s 2011 Sleep in America Poll](https://jcsm.aasm.org/doi/10.5664/jcsm.3272) (Gradisar et al., 2013) [6:30]

**Matt’s thoughts on caffeine has been shaped after listening to this audiobook**: [Caffeine: How Caffeine Created the Modern World](https://www.amazon.com/Caffeine-How-Created-Modern-World/dp/B083MYJXZT) by [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan) | (amazon.com) [13:45]

**Review paper showing decaffeinated coffee has many health benefit associations with it partly because of the antioxidants**: [Coffee, Caffeine, and Health Outcomes: An Umbrella Review](https://pubmed.ncbi.nlm.nih.gov/28826374/) (Grosso et al., 2015) [15:00]

**This study showed that dosing people with caffeine at 7 AM lead to a reduction in the quality of that deep sleep**: [Caffeine intake (200 mg) in the morning affects human sleep and EEG power spectra at night](https://pubmed.ncbi.nlm.nih.gov/7796154/) (Landolt et al., 1994) [15:45]

**When you deprive short sleepers of a night of sleep, they get significantly more deep sleep that following night than control subjects**:  [18:00]

- [Sleep deprivation in rats: effects on EEG power spectra, vigilance states, and cortical temperature](https://pubmed.ncbi.nlm.nih.gov/1858947/) (Franken et al., 1991)
- [The two‐process model of sleep regulation: a reappraisal](https://onlinelibrary.wiley.com/doi/full/10.1111/jsr.12371) (Borbély et al., 2016)

**Studies from the 80s where they deprived rats of sleep**: [Sleep deprivation in the rat: X. Integration and discussion of the findings](https://pubmed.ncbi.nlm.nih.gov/2648533/) (Rechtschaffen et al., 1989) [19:00]

**Study finding that every 5% reduction in your REM sleep, there was a 13% increase in your mortality (i.e., linear relationship between REM sleep and mortality)**: [Association of Rapid Eye Movement Sleep With Mortality in Middle-aged and Older Adults](https://jamanetwork.com/journals/jamaneurology/article-abstract/2767713) (Leary et al., 2020) [19:30]

**Matt’s preferred sleep tracking wearable**: [Oura Ring](https://ouraring.com/) | (ouraring.com)  [22:30]

**The paper that Matt and Peter recently published together**: [Broken sleep predicts hardened blood vessels](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7271997/) (Vallat et al., 2020) [26:15]

**Matt’s review paper with methods that have been used to improve deep sleep quality**: [Slow-Wave Activity Enhancement to Improve Cognition](https://www.cell.com/trends/neurosciences/fulltext/S0166-2236(18)30064-X) (Wilckens et al., 2018) [28:00]

**Bed cooling device Peter uses**: [Ooler](https://www.chilitechnology.com/products/ooler-sleep-system) | (chilitechnology.com) [31:45]

**Literature on orexin and sleep**: [Role of orexin in modulating arousal, feeding, and motivation](https://pubmed.ncbi.nlm.nih.gov/23616752/) (Tsujino and Sakurai, 2013) [49:00]

**Peter’s preferred brands of magnesium**: [1:07:00]

- *Preferred magnesium L-Threonate is made by*: [Magtein](https://magtein.com/?gclid=CjwKCAjwkJj6BRA-EiwA0ZVPVrn13zzzNne52olR9-Jo5ARcCM16YJjaHdmij2jiTFvQVOVTlQ71mxoCgI0QAvD_BwE) | (magtein.com)
- *Peter also likes a magnesium products from*: [Nature Made](https://www.naturemade.com/search?type=product&q=magnesium) | (naturemade.com)

**Company that Matt is working with that is tracking the gut microbiome data and Matt is helping to bring sleep into their analysis**: [ZOE](https://joinzoe.com/) | (joinzoe.com) [1:10:00]

**Data showing that when you sleep deprive either human beings or animals, you see a shift in the gut microbiome balance towards the fermented bent of the microbiome which is not ideal**: [1:10:30]

- [Benedict et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5123208/)
- [Poroyko et al., 2016](https://www.nature.com/articles/srep35405)

**There’s an association between poor health outcomes and a gut microbiome with a fermented bent**: [Sleep and Circadian Alterations and the Gut Microbiome: Associations or Causality?](https://link.springer.com/article/10.1007/s40675-018-0100-0) (Farré et al., 2018) [1:11:00]

**An experiment where you mimic jet lag showed that it produced that same deleterious shift towards a fermented gut**: [Transkingdom Control of Microbiota Diurnal Oscillations Promotes Metabolic Homeostasis](https://www.cell.com/cell/fulltext/S0092-8674(14)01236-7) (Thaiss et al., 2014) [1:11:15]

**Harvard study showing fruit flies died from lack of sleep due to the free radical damage from reactive oxygen species in the gut**: [Sleep Loss Can Cause Death through Accumulation of Reactive Oxygen Species in the Gut](https://www.cell.com/cell/pdf/S0092-8674(20)30555-9.pdf?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867420305559%3Fshowall%3Dtrue) (Vaccaro et al., 2020) [1:11:45]

**Melatonin is a remarkable antioxidant**: [Melatonin as a Potent and Inducible Endogenous Antioxidant: Synthesis and Metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6332205/) (Tan et al., 2015) [1:13:45]

**Dan Buettner’s TED Talk about blue zones**: [How to live to be 100+](https://www.ted.com/talks/dan_buettner_how_to_live_to_be_100?language=en) | (ted.com) [1:25:00]

§

## People Mentioned

- [Tim Ferriss](https://en.wikipedia.org/wiki/Tim_Ferriss) [13:30]
- [Dr. Raphael Valett](https://twitter.com/raphaelvallat?lang=en) [23:15]
- [David Sinclair](https://genetics.med.harvard.edu/sinclair/people/sinclair.php) [26:15]
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) [26:15]
- [Ralph Esposito](https://www.instagram.com/dr.ralphesposito/) [1:02:45]
- [Dan Buettner](https://en.wikipedia.org/wiki/Dan_Buettner) [1:25:00]
- [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/) [1:27:30]
- [Tom Perls](https://www.bumc.bu.edu/busm/profile/thomas-perls/) [1:27:30]

§

![](https://peterattiamd.com/wp-content/uploads/2020/09/1x1-matthewwalkerama3-500x500.jpg)

##### Matthew Walker, Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[sleepdiplomat.com]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

**Center for Human Sleep Science**: [https://www.humansleepscience.com/](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)

**Matthew’s publications**: <https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s>