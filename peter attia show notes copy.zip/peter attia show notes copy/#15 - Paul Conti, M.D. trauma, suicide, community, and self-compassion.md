# #15 – Paul Conti, M.D.: trauma, suicide, community, and self-compassion

**Source:** [https://peterattiamd.com/paulconti/](https://peterattiamd.com/paulconti/)

---

##### Check out more content with psychiatrist, Paul Conti, M.D.:

- *(September 17, 2018)* [Paul Conti, M.D.: trauma, suicide, community, and self-compassion](/paulconti/)
- *(April 10, 2020)* [Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted](/paulconti2/)
- *(January 10, 2022)* [Paul Conti, M.D.: How to heal from trauma and break the cycle of shame](/paulconti3/)

In this episode, psychiatrist Paul Conti, M.D. discusses the impact of untreated trauma, the rising rate of suicide, and the influence of modern society on mental health, to name a few important topics covered. Paul also talks about how to deal with these challenges for yourself, your loved ones, and the community at large.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/paulconti/the_Drive_public.png)

Play

#15 - Paul Conti, M.D.: trauma, suicide, community, and self-compassion

#15 - Paul Conti, M.D.: trauma, suicide, community, and self-compassion

1x15s30s

0:002:09:13

## We discuss:

- Paul’s background, and what drove him to psychiatry [5:00];
- How silent bravado and incessant striving can lead to a functional (and actual) death, and why Paul is critical of the current state of psychiatry [14:45];
- Psychedelics, psychotherapy and the dissolution of the ego [20:30];
- How current society may be contributing to the increasing amount of suffering [25:00];
- The ubiquity and impact of untreated trauma [31:45];
- The rising rate of suicide, parasuicide, and “accidental” death [35:30];
- Types of trauma, why we minimize it, and Peter’s introduction to Bridge to Recovery [44:00];
- Triggering shame and fear, childhood trauma, and why trauma doesn’t care about time [48:00];
- The impact of the brain on the body, and overcoming trauma with self-awareness [55:00];
- How to recognize and stop the cycle of shame transference [1:04:30];
- Peter’s profound experience at Bridge to Recovery, and the importance of finding shared experiences with others [1:11:15];
- How to identify and deal with our own personal trauma [1:19:00];
- Finding meaning in struggle, why we are less happy than ever, and the impact of an isolated society [1:25:30];
- What steps can we take as a society to make an appreciable impact on the rising sense of desperation and misery? [1:43:15];
- Resources, book recommendations, and things you can do [1:56:15]; and
- More.

§

## Show Notes

## Paul’s background, and what drove him to psychiatry [5:00]

- When Peter and Paul met in medical school (21 years ago), Peter was surprised that Paul knew he wanted to be a psychiatrist
- Paul says it “represented a search for truth and…a response to some of the difficult things in my life…and a sense of wanting to understand things more”
- Before med school Paul got a job with a good consulting firm, but what changed?
- It really did not make me happy, missed the intensity of human interaction and struggle
- Wanted to understand what was going on inside of people (didn’t realize at the time that it was partly wanting to delve inside what was happening inside of himself)
- We’re programmed to work hard, be successful, and not complain, but the inability to express oneself and be vulnerable can drain the life from people.
- “We’ve kind of structured our society in a way that makes it very very difficult to live in.”
- In a span of about a year Paul’s brother commited suicide, and a close friend also died from “desperate recklessness”
- Paul decided he wanted to fight against this “thing” that made it so hard for people to get help

## How silent bravado and incessant striving can lead to a functional (and actual) death, and why Paul is critical of the current state of psychiatry [14:45]

- A culture of “silent bravado” can actually lead to real consequence like death
- Sometimes this silent struggle can lead directly to death, or functional death (technically alive but effectively dead) which leads people to die from self-destruction over time
- “In many ways, the way our society is structured, and our metrics of achievement are structured really beckons us to death in life, to losing touch with the basics of our own value system, and essentially to incessant striving…and not to pause and feel the vulnerability.”
- The world, and media, gives us so many markers that say “you’re not good enough, you don’t have enough, you’re too vulnerable…”
- Paul not very optimistic about the state of the psychiatry because it does not “broadly enough train people enough in brain biology, [and too much] in the use of medicine…”
- For psychiatry to help the most people, Paul believes we need to understand the *influence of the unconscious on our behaviors, choices and feelings*, and integrate that with the *brain biology* upon which is rests

## Psychedelics, psychotherapy and the dissolution of the ego [20:30]

[Id, ego, Super-ego](https://en.wikipedia.org/wiki/Id,_ego_and_super-ego)…how much does this apply in today’s world? “Tremendously…applies on a foundational level”

- Definition of words and terms can obscure any understanding, for example, the Freudian concept of the **ego** is much more the “whole self”, the part of self that one can bring itself (consciously) to bear on the questions and issues at hand
- **Id** is about gratification
- **Super-ego** about what you should or shouldn’t do
- But ideally, it’s the ego (the whole self) that pulls the id and super-ego together
- This is a very different use of the term “ego” than how it’s used today where ego is a sense of self that indicates a defense mechanism

“We build a shocking number of defense mechanisms that serve us well at the time but that ultimately are an unhealthy part of the foundation that then gets built upon.”

- The idea of the dissolution of the ego through psychedelics is not the classic Freudian ego (the whole self at its most poised, and comprehensively aware and empowered), it’s more the ego as the defense mechanism
- “It’s almost as if the true us, the Freudian ego, is surrounding by 90 story walls that are supposed to protect us but actually stop of from real connection with self and others and real understanding”
- In the right setting, psychedelics can remove those walls and open us up to an experience of the truth of self that is no longer walled off by all of these unhealthy defenses
- “The hope of psychotherapy, shared human experience, and psychedelics is to be able to take those defenses down so we can have an experience of self that reflects who we truly are which the vast majority of the time involves acknowledgment of the things we’re ashamed of, our vulnerabilities, the things that we have insured ourselves against which are often the very things that keep of away from happiness”

## How current society may be contributing to the increasing amount of suffering [25:00]

- Peter has only recently come to realize that a child who experiences trauma can develop into an [adaptive child](https://recoveryhelpnow.com/2010/12/25/591/) (an adolescent that is trying to protect the wounded child), and if left untreated that adaptive child shows up in the adult body, as opposed to a functional adult
- During Peter’s time at [Bridge to Recovery](https://www.thebridgetorecovery.com/) (more about this at 44:00 and 1:11:15), he came to realize about himself that “oh my god, all of that achievement, all of that perfectionism, all of those things I was chasing, it’s basically a kid trying to protect you”
- Now that so many of our [basic needs](https://en.wikipedia.org/wiki/Maslow%27s_hierarchy_of_needs) are being met we now have the “luxury” of worrying about being happy and finding fulfillment

Is this environment contributing to the increasing number of adaptive adults?

- Paul suspects that indeed we are making it worse for ourselves in ways we haven’t intended
- We’ve made more opportunity for ourselves, but this great opportunity has also given us the ability to run away from the things that plague us
- A prime example is how many of us are driven to be powerful and successful.
- Part of this desire is to put us in a position to provide for our families and help our communities
- But a significant aspect of the “strength of the fuel in the tank” is running from something such as vulnerability
- Nothing wrong with ambition, but we internalize that as “must be perfect, must achieve more” but when is it enough?
- “The modern world doesn’t help us define what we are striving for”
- The world constantly reminds us of our vulnerability leaving us striving for more (money, power, prestige, titles, influence) and it never gets turned off
- “And when we’re honest with ourselves…we can’t frame [the constant striving] as a drive *towards* something…it’s a drive *away* from something”
- “We run away from our problems, and we don’t even know what our problems are”

## The ubiquity and impact of untreated trauma [31:45]

- Paul speculates, “I have come to believe that 80% of what I treat is trauma…80% of what ails me, what ails you, what ails the world, is trauma”
- Manifestations of trauma:
  - Anxiety
  - Depression
  - Panic attacks
  - Substance abuse
  - Overeating
  - Cutting
  - Gambling
- “The root of what ails people it is self-evident”
- Referring to the shortcomings of the field of psychiatry, Paul says that doctors don’t really try to understand the problem they just give medicine and move on to the next. “We’ve stepped away from really trying to understand people”

## The rising rate of suicide, parasuicide, and “accidental” death [35:30]

- Paul says it’s hard to look at suicide rates and levels of general misery and say it’s not getting worse
- Peter mentions the recent [Wall Street Journal article](https://www.wsj.com/articles/cdc-finds-rise-in-suicide-rates-across-the-u-s-1528417378) which showed a 30% increase in the rate of suicide over a decade (or maybe 2 decades)
- Part of Peter’s approach to longevity is figuring out what is going to kill you and to try to back away from that
- When pouring over actuary tables to see mortality trends, how are they shifting, where are we winning and losing progress, most of his energy is focused on 3 things:
  - Cardiovascular
  - Cancer
  - Neurodegenerative
- But the only “disease” that shows up in every decade (other than birth to 9 years) is **suicide**
- Accidents also showed up in every decade however the nature of the accidents are so different from decade to decade that they can be counted together
- Paul questions how many of these “accidental” deaths are “parasuicidal” (basically someone not caring about their life enough to be appropriately cautious)
- Top 3 causes of accidental death:
  - Automotive
  - Falling
  - Accidental ingestions => How many of this last one aren’t really accidental?
- If you were to count reported suicides (which by themselves are strikingly high) and parasuicides, the number would be shocking, says Paul
- Trauma either pushes you to end your life, or leads you down a longer path of destruction so it might lead to an “accident”
- Paul compliments Peter’s ability to understand that mental health underlies so much of what causes mortality, sickness and death (i.e., depression is correlated with more cardiovascular disease, accidents, addiction, etc. and how trauma and stress impact those things)
- Paul believes that more than 50% of what everyone treats (any doctor) is ultimately resting in misery inside of that person that Paul would attribute to trauma: these traumas may not even get acknowledged when they happen but even something “small” like the loss of pet can be a symbol of instability in their lives that 25 years later they are still playing over and over in their head

## Types of trauma, why we minimize it, and Peter’s introduction to Bridge to Recovery [44:00]

- Paul convinced Peter to visit the [Bridge to Recovery](https://www.thebridgetorecovery.com/) (BtR), a facility that specializes in healing trauma
- Peter encourages anyone who feels like they need someone to talk with to [give them a call](https://www.thebridgetorecovery.com/contact)
- Peter was resistant to going because his inner voice was saying things like, *what could be wrong with me, I’m successful, I’m not an alcoholic* (i.e., no overt signs of pathology)
- But Peter learned a ton and got a lot out of just the initial screening call, when the interviewer apparently hit a button which caused a strong reaction from Peter
- Paul says finding this button and causing reaction illuminates shame and fear
- Peter says the semantics of the word “trauma” made him not want to go, he says it’s common for our skin to get so thick that people develop patterns to deal with it (for Peter, it was minimizing his past traumas)
- 5 roots of trauma (learned at BtR)
  - Abuse (physical, emotional, sexual, spiritual)
  - Neglect
  - Abandonment
  - Enmeshment
  - Witnessing of tragic events
- Everyone has experienced at least 1 of these if not multiple
- “The most intense experience of my life which is 13 hours per day of group therapy”
- For Peter, the single most powerful way to let his guard down… one counselor said to him ‘if this had happened to your son, Reese (4 yr), would you think that that was okay?’
- One thing to minimize an event that happened to yourself, but to your kid? Not so easy

## Triggering shame and fear, childhood trauma, and why trauma doesn’t care about time [48:00]

- When psychiatrists examine someone for emotional pain it is analogous to an examination by a physician looking for physical pain, you poke around and look for a reaction
- If you get to where it hurts, the person has a reaction, and what it tells us is where there is *shame and fear* (like the interviewer did with Peter)
- Shame and fear is an aroused affect, something created in you without your volition, certain things make us feel something that we don’t have any control over
- Trauma is not really about what happened, but what does it make you feel?
- When a 7-year-old, for example, experiences trauma they lack the capacity to recognize “what’s happening to me is wrong” so they tend to blame themselves which creates a sense of shame that can last forever
- In both physical pain and emotional trauma, people feel less pain if the event “makes sense” otherwise it just seems senseless and sadistic and people that have experienced senseless trauma have long-term consequences which can trigger shame and fear in the future
- Paul says very common to see a trigger as a person caring for a child and when that child reaches the same age as their personal traumatic event they are triggered because they are actually still in the throes of that event
- The brain does care about the clock so it does not matter one bit how long ago trauma was if it instilled terror, shame, a sense of responsibility
- Untreated trauma can often prevent us from living longer because the internal stress can not only lead to suicide but also can contribute to cancer, cardiovascular disease, etc.

## The impact of the brain on the body, and overcoming trauma with self-awareness [55:00]

Peter and Paul collaborated on a patient

- Peter fixed her nutrition, tweaked a bunch of things, fixed her hypothyroidism
- She was extraordinarily compliant, however, they just couldn’t seem to fix certain things (inflammation, insulin resistance, weight loss), and she had the “metabolism of a slug”
- One day Peter remembered the patient talking about how her Dad died and it occurred to him that this very well could have been a traumatic event
- Peter thought about the Zucker rats experiments where if they got lesions in parts of the hypothalamus, it could alter their metabolic rate
- Peter sent the patient to Paul and over the next 6 months she lost about 30 lbs, without changing anything else, and looked like a different person
- Paul has an “utter reverence” for the impact of what the brain can do to the body.
- Paul says, “we don’t appreciate how much of an impact things that are tormenting us inside can have”

Paul’s patient who overcame trauma with self-awareness

- Intelligent, educated person, working $10/hr job, could be running a company
- Paul asked how often he has negative self-talk such as “I suck” and he answered: “hundreds of times” per day
- Paul has reason to believe that saying profoundly negative things over and over to yourself can have a dramatic effect on everything including your brain, endocrine, immune system, vasculature, etc.
- This person wasn’t assaulted or sexually abused, so no trauma right? Wrong
- They found the trauma, which happened when he was under 10 years old, addressed it and it changed everything for him

“The reality, and what we view as truth, that we’re living in is often not apparent to anyone around us, nor is it apparent to ourselves…if we make it apparent we can make some decisions about it.”

## How to recognize and stop the cycle of shame transference [1:04:30]

- Peter brings up the concept of shame transference that he learned from reading the book, [I Don’t Want to Talk About It:](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) “one of the most important books I’ve ever read”
- In many cases it takes a number generations it takes for shame to work itself out (shame transferencethrough trauma) and can be practically infinite until it is understood so that we can intervene
- You think you can protect your kids from trauma but comes out in an orthogonal way, meaning you don’t automatically become an alcoholic if your father is one, the trauma isn’t always the same root cause
- Example, a parent might not have had many rules as a child and was allowed to roam free and this could have lead them to traumatic situations, and as a parent they overcompensate and become controlling which pushes their kids to rebel, which leads to possible trauma for their kids, and so on
- Peter trying to get deep with his patients because he’s starting to realize that without knowing this about them so much of what they are trying to do become futile
- A lot of times, human suffering happens with a fizzle and not a bang, and the person who doesn’t have a strong sense of self will just languish and be burdened with regret, and we just don’t talk about it or educate ourselves and we just let it perpetuate
- Why don’t we talk about these things? What are we guarding against? Why do we feel ashamed if we’re not perfect or the best?
- A lot of it is based on the lie of *what doesn’t kill us makes us stronger*, “That. Is. A. Lie.”
- In Paul’s experience that bad things that don’t kill us tend to make us weaker, and if we don’t acknowledge these things we languish
- Sure we might be driven to achieve more but we are miserable in the process, because the hurt part of us is what we’re still living in, but we’re finding a way to not look that way
- We are fascinated by cultural things (such as movies) where people are “looking someway, strong and powerful, but being weak and vulnerable…this is because we often identify with this way of being”
- Paul says most of his patients are just struggling with the same stuff that Paul is…Paul just knows how to help them, the same way that Paul might go to an accountant to help him with something Paul doesn’t understand

## Peter’s profound experience at Bridge to Recovery, and the importance of finding shared experiences with others [1:11:15]

- Very high achievement is a marker for a person that might be defending against something, one of the reasons Paul thought Peter should to [Bridge to Recovery](https://www.thebridgetorecovery.com/) (BtR)
- Making ourselves healthy is difficult, it involves misery, tears, and exposing things we’re ashamed of
- Peter says his days at BtR “hurt more than [swimming the Catalina channel](https://www.youtube.com/watch?v=yMQFd9q07Zo)”
- Paul believes a sense of community and connection with others is important for healing which is why he picked BtR for Peter because he knew he would be with others that may not look like they have much in common on the surface but in reality, they have similar life experiences
- In addition to 13 hours of meetings with therapists, Peter had to go to a different 12 step meeting every night (AA, Al-Anon, CODA, NA, SA, or SLAA).
- “This was a different level of exhaustion,” says Peter
- Paul points out the level of magnitude of what’s going on inside of you when this happens compared to say the fact that Peter could work 24 hour days as a surgeon, no problem
- Peter surprised with how much he got out of these 12 step meetings and was struck by the vulnerability of people: “I think that is an antidote to shame”
- Peter has come to understand that part of what he enjoyed about the 12 step meetings was the fact that he was just able to listen, he didn’t have to give advice, or try to prove his value to others, he could just listen and understand we are all just vulnerable humans
- Peter says it feels similar to the experience he had [when volunteering at North Kern State Prison](https://peterattiamd.com/coreymccarthy/), “In a moment of redemption all that matters is where you are at that moment”
- Peter describes his time at Bridge to Recovery as “an unbelievable shared experience, we are all the same”

## How to identify and deal with our own personal trauma [1:19:00]

Start by taking stock of how are we trying to separate ourselves from other people

- So using Peter as an example, Peter’s desire to “stand out” and be a high achiever, is that, he needs to *not feel ashamed* as opposed to wanting to feel superior
- Shame can drive good things such as Peter’s expertise, and giving value to others, but these traits are also driven by the need to separate ourselves
- So in Peter’s case, he is doing something by reflex which is the opposite of what he needs, which is to relate to others and be part of the humanity around him, to feel that he’s a human that suffers just like others around him, whether they are “like me” or not
- A community of people with shared experiences takes away the unique stigma of the things that you are suffering from, but his reflex as a driven person is to differentiate himself, which is what guarantees loneliness

Find a way to express your emotions with people

- It’s vitally important not to try to separate yourself from others based on age, sex, socioeconomic status
- Paul used to have a clinic that was running groups around addiction and they were adamant not to separate people by type of addiction or by age or socioeconomic status, even though people would ask for that all the time
- People didn’t realize that the very thing they were asking for was going to stand in the way of them getting help
- Paul gave Peter this same advice when going to BtR and told Peter, you absolutely need to be around people you think you’re different from because you’re really not so different

## Finding meaning in struggle, why we are less happy than ever, and the impact of an isolated society [1:25:30]

Peter has been profoundly impacted by the late [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace)

- Recommends [This is Water](https://www.youtube.com/watch?v=8CrOL-ydFMI) commencement speech
- David tragically took his own life 3 years after this speech
- Peter plays the audio for Paul of the interview of David by Terry Gross (1997) a year or 2 after David wrote [Infinite Jest](https://www.amazon.com/Infinite-Jest-David-Foster-Wallace/dp/0316920045/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- “I have a sense that an enormous part my generation…is an extremely sad, sort of lost generation, which when you think about the material comforts and political freedoms that we enjoy, is just strange.”—David Foster Wallace

Is suicide a symptom of civilization? Are we simply less happy than previous generations or is it that we have greater expectations that are unmet?

- So complicated, but we are wired to survive “as long as we see meaning in survival”
- Not to glorify struggle, but there is something around struggle that gives meaning
- In today’s society is can be difficult to determine your own value given the endless metrics we can look at (achievement, success, what other people think of me, relationship with family and friends, money, wealth, power?)
- But our ancestors could more easily value themselves, *Are the sheep safe? Do I have food? Roof over my head?* Something concrete about that
- “We see value to our struggle if we see meaning…and for a long time we still saw greater meaning but not so sure we do as much now, things are more nebulous… ‘Do I really matter? What am I doing? What do I stand for?’”
- Book recommendations on this topic: [Man’s Search for Meaning](https://www.amazon.com/Mans-Search-Meaning-Viktor-Frankl/dp/080701429X/ref=sr_1_3?s=books&ie=UTF8&qid=1536777130&sr=1-3&keywords=man%27s+search+for+meaning&dpID=41jNJ1FrUlL&preST=_SY291_BO1,204,203,200_QL40_&dpSrc=srch) by [Viktor Frankl](https://en.wikipedia.org/wiki/Viktor_Frankl), “If you don’t have meaning why would you struggle to survive?”

Our lack of a sense of community leaves us more susceptible

- Unfortunately, many people find little meaning in their struggles nowadays and it is exacerbated by our lack of community
- Our ancestors would go through struggles together such as a famine, that was nature, and everyone went through it together
- This lack of a shared sense of community leads to a “tremendous sense of isolation”
- Book recommendation for this topic: [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Sebastian Junger

## What steps can we take as a society to make an appreciable impact on the rising sense of desperation and misery? [1:43:15]

First, we need more places where people can come together in order to:

- Have a shared experience and a sense of community
- Facilitate human connection
- Get educated about the basics of what’s going on inside of people
- Support each other emotionally and financially
- “If we’re gonna survive our own progress…we’re going to do things around mutuality and community support…and where people who have something can help people who don’t”

Secondly, we need to recognize that some of the things we do through our drive to achieve success and stand out from others, is actually what makes us lonely

- Peter and Paul fantasize about the idea of creating a close-knit tribe with their med school colleagues (to all live on the same block) and they believe this feeling of closeness is a human need that seems to be missing from most people’s lives
- Peter puts a premium on spending time with his close male friends because he believes this shared connection with others, rather than just your spouse or family, is vitally important
- *Paul says it all comes back to trauma:* you think you’re too busy to meet up with friends, you might fall behind on your career, miss a business opportunity, etc. and if so, you might lose your edge and become less powerful, and less successful, (which your past trauma says you need to be to feel a sense of self-worth)

## Resources, book recommendations, and things you can do [1:56:15]

First step is to take stock of one’s inner dialogue:

- Reflect on what you are saying to yourself
- Talk to people that are close to us and talk more openly
- Talk to professionals (whether you think you have no need for psychotherapy) because it’s a way of understanding ourselves better
- “Every damn human on the planet should have psychotherapy”
- Consider a 12 step meeting just to experience the feeling of shared humanity
- “Take stock of what’s inside of you and connect with people around you”

Books and literature:

- [The Plague](https://www.amazon.com/Plague-Albert-Camus/dp/0679720219/ref=mt_paperback?_encoding=UTF8&me=&qid=) by Albert Camus (a way of potentially framing the things inside of us)
- [Short stories](https://www.amazon.com/dp/B003TU1ODK/ref=dp-kindle-redirect?_encoding=UTF8&btkr=1) by Katherine Mansfield (invokes the “realness” of being human)
- [Anton Chekhov](https://en.wikipedia.org/wiki/Anton_Chekhov) (short story writer Paul enjoys)

“Compassion for themselves is what ultimately can lead somebody to take that first step to getting help.”

§

§

## Selected Links / Related Material

- **The wounded and adaptive child**:[The Wounded Child, Adaptive Child & Functioning Adult](https://recoveryhelpnow.com/2010/12/25/591/) **|** ([recoveryhelpnow.com](https://recoveryhelpnow.com/)) [25:00]
- **The place where Paul sent Peter to learn about and get help for past trauma**: [Bridge to Recovery](https://www.thebridgetorecovery.com/) [25:00, 44:00, 1:11:15]
- **WSJ article about rising suicide rates**: [CDC Finds Rise in Suicide Rates Across the U.S.](https://www.wsj.com/articles/cdc-finds-rise-in-suicide-rates-across-the-u-s-1528417378) | Jeanne Whalen ([wsj.com](https://www.wsj.com/)) [35:30]
- **Zucker rats**: [Adipose tissue metabolism and genetic obesity: The LPL hypothesis](https://experts.umn.edu/en/publications/adipose-tissue-metabolism-and-genetic-obesity-the-lpl-hypothesis) (Greenwood et al., 1981) | [56:00]
- **Rats and VMH lesions**: [THE SPONTANEOUS ACTIVITY AND FOOD INTAKE OF RATS WITH HYPOTHALAMIC LESIONS](https://www.physiology.org/doi/abs/10.1152/ajplegacy.1942.136.4.609) (Hetherington and Ranson, 1942) | [56:00]
- **Book on shame transference, one of the most important books Peter has ever read**: [I Don’t Want to Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684831023/ref=mt_hardcover?_encoding=UTF8&me=&qid=) by Terrence Real | (amazon.com) [1:05:30]
- **Video of peter swimming the Catalina Channel**: [Peter Attia crossing Catalina Channel](https://www.youtube.com/watch?v=yMQFd9q07Zo) | Peter Attia (youtube.com) [1:16:30]
- **Peter’s profound experience volunteering at North Kern prison**:[Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude (EP.12)](https://peterattiamd.com/coreymccarthy/) | (peterattiamd.com) [1:18:30]
- **Powerful commencement speech by David Foster Wallace**:[This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) | Jamie Sullivan (youtube.com) [1:25:45]
- **1997 interview of David Foster Wallace by Terry Gross**: [David Foster Wallace: The ‘Fresh Air’ Interview](https://www.npr.org/2015/08/14/432161732/david-foster-wallace-the-fresh-air-interview) | (npr.org) [1:29:30]
- **Book by David Foster Wallace**: [Infinite Jest](https://www.amazon.com/Infinite-Jest-David-Foster-Wallace/dp/0316920045/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by David Foster Wallace | (amazon.com) [1:29:30]
- **Book about finding meaning in struggle**: [Man’s Search for Meaning](https://www.amazon.com/Mans-Search-Meaning-Viktor-Frankl/dp/080701429X/ref=sr_1_3?s=books&ie=UTF8&qid=1536777130&sr=1-3&keywords=man%27s+search+for+meaning&dpID=41jNJ1FrUlL&preST=_SY291_BO1,204,203,200_QL40_&dpSrc=srch) by Viktor Frankl | (amazon.com) [1:34:30]
- **Book highlighting our desire for a sense of community**: [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Sebastian Junger | (amazon.com) [1:34:50]
- **Recommended reading by Paul**: [The Plague](https://www.amazon.com/Plague-Albert-Camus/dp/0679720219/ref=mt_paperback?_encoding=UTF8&me=&qid=) by Albert Camus | (amazon.com) [1:58:45]
- **Recommended reading by Paul**: [Short stories](https://www.amazon.com/dp/B003TU1ODK/ref=dp-kindle-redirect?_encoding=UTF8&btkr=1) by Katherine Mansfield | (amazon.com) [1:59:20]

§

## People Mentioned

- [The Godfather](https://en.wikipedia.org/wiki/The_Godfather) [4:45]
- [Peter Rosenbaum](https://news.stanford.edu/news/2007/october10/med-rosenbaum-101007.html) (Paul’s professor at Stanford) [33:50]
- [Kate Spade](https://en.wikipedia.org/wiki/Kate_Spade) (ubiquity of suicide) [35:30]
- [Anthony Bourdain](https://en.wikipedia.org/wiki/Anthony_Bourdain) (ubiquity of suicide) [35:30]
- [Robin Williams](https://en.wikipedia.org/wiki/Robin_Williams) (ubiquity of suicide) [1:33:20]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (writer and philosopher that Peter admires)[1:25:40]
- [Terry Gross](https://en.wikipedia.org/wiki/Terry_Gross) (interviewed David Foster Wallace in 1997) [1:29:30]
- [Viktor Frankl](https://en.wikipedia.org/wiki/Viktor_Frankl) (Holocaust survivor, wrote *Man’s Search for Meaning*) [1:34:30]
- [Anton Chekhov](https://en.wikipedia.org/wiki/Anton_Chekhov) (short story writer Paul enjoys) [1:59:30]

§

![](https://peterattiamd.com/wp-content/uploads/2018/09/Conti-pic-image-polaroid-300x205.jpg)

##### Paul Conti, M.D.

Dr. Paul M. Conti is a graduate of Stanford University School of Medicine. He completed his training at Stanford and at Harvard, where he served as Chief Resident. He then worked in private practice while serving on the medical faculty at Harvard. He was named as one of Oregon’s Top Psychiatrists in 2008, his first full year of practice in Oregon. Dr. Conti is a general psychiatrist, treating all aspects of both mental illness and the impact of life stressors. His practice includes use of medications and psychotherapy, and he also routinely treats complex cases, co-occurring alcohol and drug issues, and does neuropsychiatric assessments. In addition to clinical treatment, Dr. Conti provides business-related and legal consulting services. [[pacificpremiergroup.com](https://www.pacificpremiergroup.com/meet-our-team/)]