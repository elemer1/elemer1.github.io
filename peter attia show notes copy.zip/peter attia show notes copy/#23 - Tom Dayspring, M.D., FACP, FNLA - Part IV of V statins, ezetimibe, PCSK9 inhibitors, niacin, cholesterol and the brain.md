# #23 – Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain

**Source:** [https://peterattiamd.com/tomdayspring4/](https://peterattiamd.com/tomdayspring4/)

---

##### Check out our 5-part series with Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology:

- *(October 15, 2018)* [Part I of V: An introduction to lipidology](/tomdayspring1/)
- *(October 16, 2018)* [Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](/tomdayspring2/)
- *(October 17, 2018)* [Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](/tomdayspring3/)
- *(October 18, 2018)* [Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](/tomdayspring4/)
- *(October 19, 2018)* [Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](/tomdayspring5/)
- *(September 21, 2020)* [**FOLLOW-UP:** The latest insights into cardiovascular disease and lipidology](/tomdayspring6/)

In this five-part series, Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology, and one of Peter’s most important clinical mentors, shares his wealth of knowledge on the subject of lipids. In Part IV, Peter and Tom review the history and current use of drugs to prevent cardiovascular disease. They also discuss why some drugs appear to be more effective than others, an in-depth conversation about niacin, cholesterol and brain health, and the futility of using CKs (creatinine kinase) and liver function tests to identify adverse effects in statins, to name a few topics in this episode.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomdayspring4/the_Drive_public.png)

Play

#23 - Tom Dayspring, M.D., FACP, FNLA – Part IV of V: Statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain

#23 - Tom Dayspring, M.D., FACP, FNLA – Part IV of V: Statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain

1x15s30s

0:002:00:05

We discuss:

- Bile acid sequestrants and statins [2:00];
- Ezetimibe (Zetia) [15:00];
- PCSK9 inhibitors [27:30];
- Fibrates [41:00];
- Fish oil, DHA, and EPA [1:01:00];
- Niacin [1:05:15];
- PCSK9 inhibitors [1:23:45];
- Cholesterol, statins, and the brain [1:30:00];
- Elevated creatine kinase (CK) and liver function tests (LFTs) on statins [1:50:30]; and
- More.

§

## Show Notes

## Bile acid sequestrants and statins [2:00]

Peter Attia: So, while we’re on that topic, let’s go back and talk about the drug. So, we just finished with kind of one very niche story, but when it became pretty clear that there was an association, a strong association, frankly, between cholesterol and heart disease, you now had another target, because as you said, you know, if we went back in time 50, 60 years, if you were astute enough, you would have your patient stop smoking, you would manage their blood pressure. What was the first drug that was specifically brought to market to target cholesterol?

Tom Dayspring: Well, niacin has been used ad infinitum, forever, without a lot of data, but they know it changed certain metrics. They were measuring total cholesterol, HDL cholesterol, and the only form of niacin available back then was immediate release, a pretty much intolerable drug for most people, but you could find some people who could take the massive doses needed for that. So that was around.

Tom Dayspring: Believe it or not, when I was coming up and total cholesterol was the only measurable thing and they knew that if it was 400 or something, you were probably in trouble, they gave Neomycin to those people-

Peter Attia: Neomycin the antibiotic?

Tom Dayspring: Yeah, which interrupted the hepatobiliary bile acids recirculation of cholesterol, and it lowered cholesterol, anyway. No outcome evidence with it. But along came the bile acid sequestrants, which we hinted on, will make you excrete bile acids, which therefore, you have to use up your endogenous cholesterol to make new bile acid, so you will lower your cholesterol metrics that you’re looking at, and in one crazy long outcome trial, it did seem to work. They fudged a lot of statistics, I think, in retrospect, on it, and it didn’t have the type of statistical methodology-

Peter Attia: This is the LRC ([JAMA, 1984](https://www.ncbi.nlm.nih.gov/pubmed/6361299)).

Tom Dayspring: So, there was a little proof that not only what Framingham said is true, cholesterol is a risk marker, risk factor, depending on how you want to label it, but lowering it does reduce clinical events. To me, the tragedy of that is for the next 20 to 30 years, the only thing that the pharmacological industry focused on was cholesterol as their metric of, “That’s all we’ve got to do. We’ve got to find stuff that lowers cholesterol metrics, or improves cholesterol metrics in one or the other direction”, and bile acid sequestrants do raise HDL cholesterol a milligram or two, which turns out to have some statistical significance.

Peter Attia: Potentially without any physiologic significance.

Tom Dayspring: Correct, and it’s a minuscule thing, so who knows? So, that led to just investigation cholesterol metrics everything else and all of a sudden this guy discovers a fungus that has got a property that lowers, really potently, cholesterol, and that was the statin group, Akira Endo, a mycologist over there in Japan, who unbelievably, has not gotten a Nobel Prize yet. There’d be no statins without him bringing it to the table.

Tom Dayspring: Statins lower LDL-cholesterol dramatically, pretty low doses. They seem to be safe. All the, after LRC, the FDA needed was if you got a product that didn’t harm anybody and it’s lowering LDL-cholesterol, welcome aboard, so several statins got approved starting in 1987 with lovastatin, [brand name Mevacor] being the first statin to come on the market.

Tom Dayspring: Guys like me who were well into believing, yes, lowering LDL-cholesterol, those are the only metric we have now, and it’s good, people seem to do better, became very aggressive statin people and the story I told earlier, where we used to see MI’s like crazy in our heyday, we stopped seeing them anymore. So we had at least anecdotal belief that these things were working, and low and behold, pharma knew, ultimately, they were going to have to do serious outcome trials, and the first group of people they studied were Swedish guys who survived an MI and had an LDL-cholesterol of 190 ([Lancet, 1994](https://www.ncbi.nlm.nih.gov/pubmed/7968073)).

Peter Attia: So these patients had FH.

Tom Dayspring: In retrospect, they’re FH patients. It’s the definition, one of the definitions of FH. And giving them a dose of simvastatin got you 25-so-percent reduction in clinical events, so outcome data, bingo. Great drug. And right behind them was Bristol-Myers Squibb, who had the much weaker statin, pravastatin, sold originally as the branded Pravachol. “Let’s study Irish men who have not had a clinical event, but also, their LDL-cholesterol is 180, 190”, so more FH Irishmen ([Shepherd et al., 1995](https://www.ncbi.nlm.nih.gov/pubmed/7566020)).

Peter Attia: So you’re going from secondary prevention FH, basically, to primary prevention FH.

Tom Dayspring: Yeah. And low and behold, reduced virtually every atherothrombotic clinical event.

Peter Attia: Do you remember what the NNT was for that group and what the duration of the trial?

Tom Dayspring: You know, some of it had to do with the those with the highest risk down in the 20’s, you know? It was very good for both of them. It was a little [lower] in the 40’s because they were sicker people.

Peter Attia: I’m surprised the NNT could be that low in primary prevention.

Tom Dayspring: No, it was probably 40-50 in West of Scotland Study [WOSCOPS].

Peter Attia: But still.

Tom Dayspring: But no, it was good. These are nightmare primary preventions.

Peter Attia: How long were these trials? Five years? Six years?

Tom Dayspring: They were five years ([Ford et al., 2016](https://www.ncbi.nlm.nih.gov/pubmed/26864092)). Some of them went a little longer, some a little less, but five year trials, you know. So, and significant p-values correlated with the LDL-cholesterol levels. In retrospect, you know, in sub-cohorts, they did measure apoB, which supports apoB lowering-

Peter Attia: But this is an important point to make I’ve learned a lot from you, I’ve learned a lot from Ron, I’ve learned a lot from Allan, I’ve learned a lot from everybody in this space, but if there’s one person who really got me to understand the limitations of clinical trials, it’s Allan, with his long view of this disease.

Tom Dayspring: Oh, yeah.

Peter Attia: You know, I’ve told this story before, but Allan’s the guy who bought me my very first copy of [Stary’s pathology textbook](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?ie=UTF8&qid=1526578233&sr=8-1&keywords=stary+atherosclerosis), and, you know, is really the guy that got me looking at these autopsy pictures of kids, and realizing, “Hey, buddy, this disease starts when you’re born”. So the thing that I think most people misunderstand when it comes to lipid-lowering trials is they’re always handicapped.

Tom Dayspring: Very much.

Peter Attia: They’re behind a loaded gun, which, it’s pointing directly at them, which says, “We’re only going to give you five years to impact the course of a disease that has been going on for 50 years until now”. You take a bunch of 50 year-olds and you put them in a trial where you’re going to study them until they’re 55, you have five years to try to move the direction of a ship that’s been setting its course for 50 years.

Tom Dayspring: Nowadays, because of the cost, they would never give you five years to prove anything works. You’d have to prove it a lot sooner.

Tom Dayspring: So you better have a miracle drug.

Peter Attia: And we’ll talk about the miracle drug, which is a PCSK9 inhibitor, which there’s few things I enjoy debating with people more-

Tom Dayspring: And last but not least, that’s why you don’t put mortality in this equation. It takes a long time to die for for a drug to improve mortality metrics.

Peter Attia: Well not only that. We’re never powered to study mortality.

Tom Dayspring: Correct.

Peter Attia: I mean, it’s just, it’s so difficult.

Tom Dayspring: So it’s meaningless what a lipid modulating drug does to mortality. Meaningless, unless you’ve got a randomized blinded, controlled 30-year trial. Then I might say, “What’s wrong?”

Peter Attia: I agree completely. So, again, I guess I’m sort of humbled by blind luck sometimes, which is, we look back with the benefit of knowledge, so it’s not to disparage those that came before us, but they didn’t have a clue what was going on. They didn’t have a clue about the complexity.

Peter Attia: So, let’s go back and talk about statins. So, statins inhibit HMG-CoA reductase. That is an enzyme that is prior to the bifurcation of the cholesterol synthetic pathway.

Tom Dayspring: Yeah. It’s still a flat lipid molecule at that point.

Peter Attia: That’s right. You inhibit that, and we’re going to talk about a whole bunch of great things, but there was a drug you taught me about a few years ago, an esoteric drug that inhibited delta-24 desaturase. That drug lowered cholesterol. What was the name of that drug again?

**[10:00]**

Tom Dayspring: Triparanol ([Jepson, 1962](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1896661/)).

Peter Attia: Triparanol. So Triparanol comes along-

Tom Dayspring: Yeah. 24 carbon.

Peter Attia: It did not allow you to turn desmosterol into cholesterol. Now, that’s at the very bottom of this pathway.

Peter Attia: The penultimate molecule into the ultimate step, and all of a sudden, you inhibited that with this drug. Cholesterol levels went down. FDA approved it.

Tom Dayspring: Well, what would go up?

Peter Attia: Desmosterol went up.

Tom Dayspring: Desmosterol. And there was at least a congenital disease called desmosterolosis. I don’t know if they even knew about that back then. We know about it now. That maybe would have been a flag.

Peter Attia: So, if I recall correctly, about three or four years after this drug was approved, because this is an era when you could approve a drug just by showing it lowered cholesterol, the drug was pulled off the market in the late ’60’s.

Tom Dayspring: Yeah, because atherosclerosis was occurring ([Corcoran, 1961](https://www.semanticscholar.org/paper/Coronary-atherosclerosis-status-of-MER-29-Corcoran/7ebe345787927614bba403c2e0522558bf6dc392); [Rheingold, 1968](https://scholarship.law.berkeley.edu/cgi/viewcontent.cgi?referer=https://www.google.com/&httpsredir=1&article=2831&context=californialawreview)), cataracts were occurring. And it turns out desmosterol turns out to have other roles in the body. It’s a potent cell membrane signaling molecule involved with inflammatory pathways, so God knows what else you’re doing by perturbing desmosterol levels in cells, you know? So, you live and learn. So, there’s one endpoint that’s getting better. Another endpoint that you didn’t know anything about, biomarkers getting worse and it’s probably doing some bad things.

Peter Attia: And therein lies the sort of humility of drug development, right, which is you’ve got this synthetic pathway, at first glance, you have two things that are similar: a statin, which inhibits one enzyme in the pathway, this other drug that inhibits another enzyme in the pathway, and yet, one seems to be okay and one seems to be not okay.

Tom Dayspring: And there have been several other cholesterol squalene synthase inhibitors that have failed for one reason or another. And the statistics are probably worse, where if I say, “999 out of 1,000 drugs don’t come anywhere close to a commercial success,” it’s probably much smaller than that.

Peter Attia: So it seems to me that there’s a couple things that the statin had going for it, which maybe, at the time, weren’t realized. The first is it’s higher in the food chain, meaning it’s higher on the synthetic pathway. So, if you are backing things up, they are less.

Tom Dayspring: Yeah, there is recovery time, other enzymes and other pathways.

Peter Attia: Yeah, they’re less like cholesterol. Oh, there’ll be more acetyl-CoA, more acetoacetyl-CoA or whatever. The other thing, and I don’t know if this is true, although I’ve heard it speculated on, but truthfully, I’ve never seen the data with my own eyes: do statins have selectivity for the liver?

Tom Dayspring: Sure ([Toth and Dayspring, 2011](https://www.ncbi.nlm.nih.gov/pubmed/21999163)).

Peter Attia: So that would be another unintended benefit, right?

Tom Dayspring: At least it’s been theorized, because the pharmacokinetics of a statin, let’s face it, the real place you want to inhibit cholesterol synthesis is not, per se, in cells, but in the liver, because that’s the tissue that can upregulate the most LDL receptors to get rid of your LDL particles. So I’m not really interested in stopping cholesterol synthesis in other tissues in your body because they can get rid of it.

Peter Attia: In fact, in an ideal world, you wouldn’t want to inhibit cholesterol synthesis in a single tissue outside of the liver.

Tom Dayspring: Yeah. I mean, I would if I knew that cell was producing excess cholesterol, but even it was, that cell can get rid of it through those other pathways and it would ultimately make its way back to the liver, so as long as I can enhance LDL receptors. By the way, which is primarily the only pathway that’s ever worked with drugs to reduce clinical events safely is expressing in one way or another more LDL receptors, statins, ezetimibe, bile acid sequestrants, PCSK9 inhibitors.

Peter Attia: That’s a very important point to make. What you’re basically saying is the only drugs that have ever shown to both reduce cholesterol, but more importantly, reduce events, have either been in isolation or in compounds, or in combination, where they are enhancing clearance.

Tom Dayspring: Pretty much. I mean, some of them do effect production of the apoB particles a bit, but it’s mostly enhancing clearance. That works, so if you can do that safely, and only a clinical trial can prove you’re not hurting anybody – as we’ve shown, some trials haven’t worked out, and I’ll make a case for weaknesses the niacin trials. And niacin does nothing to an LDL receptor, that we know about, so if niacin’s working to lower apoB, which it does, it’s through other mechanisms not proven to reduce clinical events.

Peter Attia: When they first put statins out there, obviously it was known that they were inhibiting cholesterol synthesis, did they also understand the effect they were having on the LDL receptors?

Tom Dayspring: Sure. I think even why they went into that area was the Goldstein Nobel Prize winning publication of the discovery of the, Brown and Goldstein, the LDL receptor ([Brown and Goldstein, 1976](https://www.jstor.org/stable/1742011?origin=JSTOR-pdf&seq=1#page_scan_tab_contents)). They knew that wow, there’s a pathway that if we can enhance, cause over-expression of LDL receptor, it’s probably going to be good. So, their hypothesis generating their genetic studies, even, on the LDL receptor. The bile acid sequestrants were first. That’s how bile acid sequestrants work, they upregulate LDL receptors to bring more cholesterol to the liver so the liver can make more bile salts. So, let’s get better LDL receptor expression drugs, and statin fell right into that pathway, without seemingly disrupting anything else.

## Ezetimibe (Zetia) [15:00]

Tom Dayspring: Of course, PCSK9 works on LDL receptor half-life, ezetimibe through a less potent pathway, but still expresses LDL receptors than do the statins. And so, they work.

Peter Attia: Though, ezetimibe’s main mechanism of action is in the gut.

Tom Dayspring: I’ll argue with you on that because where I talked about cholesterol absorption. Now, Peter talked about the Niemann-Pick C1 Like protein, which enhances the absorption of sterols, including cholesterol in the gut, and that’s ezetimibe’s main area of action. So, you do reduce entry of cholesterol into the enterocyte, but remember, cholesterol gets into your liver too, and when you think, “Oh, how does cholesterol get into your liver?” Because the liver de novo synthesized it or you’ve got all these particles bringing cholesterol back to the liver through the direct and indirect cholesterol transport pathways ([Phan et al., 2012](https://www.dovepress.com/ezetimibe-therapy-mechanism-of-action-and-clinical-update-peer-reviewed-article-VHRM)).

Tom Dayspring: There’s another pathway by which the liver acquires cholesterol. The liver has an interface with the biliary system, and we have always known, of course, that’s how the liver pumps bile salts into the bile. That’s how the liver excretes free cholesterol; it pumps it into the bile, which brings it down to your gut. But if the liver needs cholesterol in a pinch, what is a super-saturated body fluid full of cholesterol in your body? Your bile. Super cholesterol-rich.

Tom Dayspring: The liver can pull cholesterol back, efflux it, so-to-speak, from the bile back into the liver. Why? Because what is also expressed at the hepatobiliary surface, the Niemann-Pick C1 Like protein. So, ezetimibe has two areas where it acts: it blocks the intestine from internalizing cholesterol, but it prevents the liver from internalizing cholesterol from a biliary source. Put them both together, you’re depleting the liver of more cholesterol. And, the liver needs cholesterol. There’s a sterol sensor, the sterol regulatory element-binding protein, which is a nuclear transcription factor that turns on your genes that make LDL receptors.

Peter Attia: So this is interesting, Tom. I mean, the beauty of doing these podcasts is I’m also learning as we’re doing them, right? And this is an enormous insight to me that I now remember you once telling me about this, but it was just one of those things where I was, like, drinking from a fire hose, and clearly, this detail left me. I’m generally not a huge Zetia fan, Zetia or ezetimibe. I just generally think it’s kind of too impotent for, you know, real curiosity, and sort of reserve it for situations where patients can’t really tolerate statins much and can’t afford PCSK9 inhibitors and all these things. Historically, the way I’ve decided on who’s a great Zetia candidate or not is looking at phytosterols, or looking at other proxies of absorption. And I’ve argued, by the way, that the trials that suggested Zetia were not that valuable. In monotherapy, it’s never been shown to reduce clinical events.

Tom Dayspring: No, they never did a monotherapy clinical trial.

Peter Attia: Oh, they didn’t even do a mono.

Tom Dayspring: I think it would work, if you picked the right person.

Peter Attia: Well, that was always my argument.

Peter Attia: Which was it might have been a mistake in patient selection; you didn’t select hyperabsorbers. But what you’re saying would suggest that that would dilute my argument, right, because if it only worked at the Niemann-Pick C1 Like 1 transporter, the argument would be target your hyperabsorbers. But if it also works at biliary cholesterol, it shouldn’t matter that much, should it?

Tom Dayspring: No, but yeah, no, that’s part of hyperabsorption, because remember, if you’re pulling it back into the liver, you’re not depleting the cholesterol of a pool of cholesterol.

Peter Attia: But is the liver also then going to be a dominate source, where we’ll see sitosterol, campesterol, etc.?

Tom Dayspring: The final body preservation way, God forbid, phytosterols make it into your chylomicrons, or your HDL’s, and I can make the case that if they ever get into a cell, they’re going to injure that cell, but the chylomicrons are going to deliver it to the liver first, before it goes out in a VLDL. So, if you’re over-absorbing phytosterols, a lot of them do make their ways back to the liver, and the liver recognized them instantly. Using your analogy, “That stupid bouncer in the intestine let you in. That Niemann-Pick and the ABCG5/G8 let you in. We’re getting ready. We’re the backup police.”

Peter Attia: So now you’re the VIP lounge bouncer.

Tom Dayspring: Right. So, boom. Out you go again. “Now, I realize those dopes may let you in again, but you’re gonna come right back here, and I’m getting you out again. So, great analogy, Peter, the VIP bouncer.

Tom Dayspring: So, who’s to say, taking out or reducing the functioning of the Niemann-Pick C1L1, and I think it’s in both areas. Merck knows this. That’s too much education to give. Let’s just tell him it blocks cholesterol absorption.

**[20:00]**

Tom Dayspring: The gut would make sense to most people. Most people, including lipidologists, don’t even know the liver’s involved in the process. So it was like advanced lipid study, we don’t have to confuse people with that. I’ve written a number of articles on it, Peter Toth and I, I think, did one of the world-class articles on the mechanisms of it.

Peter Attia: Yeah, what year was that? [2011.] We gotta make sure we link to that one ([Phan, Dayspring, and Toth, 2012](https://pubmed.ncbi.nlm.nih.gov/22910633/)).

Tom Dayspring: I’m bad with my years, but probably, I don’t know, 2010, something like 2008. But it’s really, with great diagrams, of course showing you and explaining MOA is.

Peter Attia: And that’s Toth, T-O-T-H?

Tom Dayspring: Yeah, Peter Toth. Certainly one of the mentors in my life. Of course, Peter and Michael Davidson and Kevin Maki had me write the chapter in the book, [Therapeutic Lipidology](https://www.amazon.com/Therapeutic-Lipidology-Contemporary-Cardiology-Davidson/dp/1588295516), on Phytosterolemia.

Peter Attia: And Davidson’s at Northwestern, right?

Tom Dayspring: He’s at University of Chicago. Look, very early on, probably because I was just such a good educator on lipids, lipoproteins, and statin mechanization; I was very early in Merck’s investigation of cholesterol absorption, and became a very effective educator on that, too. Therefore had great contact with a lot of the world class scientists. The Swedes who all invented all these absorptions markers and tests.

Tom Dayspring: So I have sub-specialties in lipidology, and sterols is one of them.

Peter Attia: Why do you think that the Zetia combination in the statin trials? The main trial with Zetia was with and without simvastatin, correct? Sorry, simvastatin with and without Zetia.

Tom Dayspring: The reason why Zetia has taken so many damn hits is: Merck’s poor thinking of the type of trials that let’s bring to market to show that this is a great drug. And instead of just doing the damn outcome data, even doing a select outcome trial in the right person, primary prevention; as well as of course through your secondary prevention trials. Even do that first if you want to. If that fails, you’re not going to do anything with it. But they wanted to just get so much to market: what’s the easiest thing to do? IMT.

Tom Dayspring: So it’s taking people with, evaluating a lot of lipid abnormality, carotid intimal thickening, which is an ultrasound measurement of the thickness of your carotid artery, which has some correlation with subclinical atherosclerosis and clinical events. And that’s unarguable. And therefore, they’re at risk, they have lipid abnormalities, let’s give them, you know, they’re on a statin because we have to give them statins if their LDL metric is out of whack. Let’s give them on half of the group ezetimibe, and the other half placebo as ezetimibe. And let’s follow their IMT’s, we only have to do that for a year or two, and we’ll see IMT progression in one arm and no IMT progression in the other.

Tom Dayspring: Only did that, virtually every lipid parameter, including apoB, got better. Inflammatory markers got better. And the IMT didn’t change whatsoever.

Peter Attia: Meaning: simvastatin had the same IMT as simvastatin plus ezetimibe?

Tom Dayspring: Right. In a short time. Of course we now know that what happens to IMT with any drug has virtually no relationship to clinical outcomes. So that’s not a tool you should be using to follow up and say: look. It’s like the coronary calcium score. It’s not the tool you should be using to demonstrate the efficacy. They should’ve looked at: but look at this apoB reduction beyond what’s in the statin can do? Look at the triglyceride reduction, look at the CRP reduction beyond what’s in the statin.

Peter Attia: Or, oxLDL.

Tom Dayspring: Anything. At least say: that doesn’t mean anything. But they had already polluted the mind that IMT was the best way to check a drug.

Peter Attia: So in other words, obviously nothing trumps a hard outcome. If you can reduce MACE, that’s the way to go. I’m sorry, Major Adverse Cardiac Arrest.

Tom Dayspring: Taking a shortcut.

Peter Attia: But, they picked the wrong shortcut, is basically what it comes to.

Tom Dayspring: Amen.

Peter Attia: There were better shortcuts you could’ve taken.

Tom Dayspring: And who did that turn off bigtime? The imagist’s of the world. The cardiologists. Who instantly dismissed ezetimibe as the world’s most useless drug. Most cardiologists don’t even know what apoB is. And never mind—look, this is a potent thing. I hinted to you, I was very much involved with the raloxifene, the first SERM [selective estrogen receptor modulator] that came to the market. As good an apoB lowering drug as ezetimibe is. Which might have portended great cardiovascular benefit to the serum raloxifene, which I believe it still has. In fact, we have some. They did a big cardiovascular outcome trial ([Barrett-Connor et al., 2006](https://www.ncbi.nlm.nih.gov/pubmed/16837676)), where was: no, it didn’t hurt anybody, but it didn’t reduce events. But if you looked at the primary prevention people in that trial, it did lower events ([Collins et al., 2009](https://www.ahajournals.org/doi/abs/10.1161/circulationaha.108.817577)) (Figure 1). Now, post-hoc, hypothesis-generating data. But, an eight percent, a five percent lowering of apoB mattered. So, I think the right trial done with ezetimibe and outcomes it would matter.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-101.png)

**Figure 1. RUTH trial.** Note that although this is post-hoc data, raloxifene an apoB lowering rug reduced events in THE primary prevention group (age < 60).

Peter Attia: But we’re never going to know. And this gets to a really interesting point, when it comes to PhRMA’s challenge of studying atherosclerosis today. The industry is now going to always be a victim of the success of statins. It is unethical to take high-risk patients and take them off statins, despite what the Internet wants to tell you that statins are evil and all that nonsense. Which I don’t want to get into. But, if you actually have any modest understanding of how these drugs work, they absolutely save lives. Especially when directed at the right patients at the right times. What that means is: you want to study another drug, you’re adding it to a statin. You are not doing it in mono. You don’t get to do the study of Zetia versus placebo. It’s not ethical.

Tom Dayspring: No.

Peter Attia: If you’ve picked the right patient.

Tom Dayspring: Could you think of a reason it would be ethical to do such a trial?

Peter Attia: Yes, you take a bunch of highly, highly statin intolerant patients.

Tom Dayspring: Okay, so that would be one, which they’re never going to do, for a variety of reasons. But here’s another, and Merck did two big outcome trials where they could use–you didn’t necessarily have to give a patient a statin. They took people with significant aortic stenosis. Of the belief, because: calcium and there’s cholesterol in those aortic valves, and if we could lower cholesterol in people with aortic stenosis, we’d reduced morbidity related to that. And we don’t have to give them a statin, because statins failed to reduce outcomes in people with aortic stenosis. Those trials were already done. So, they took the SEAS trial ([Rossebø et al., 2008](https://www.ncbi.nlm.nih.gov/pubmed/18765433)) (Figure 2), aortic stenosis ezetimibe, and lowered it, and guess what? Did nothing to endpoints related [to aortic stenosis]. Because they’re enrolling people who need surgery, for God’s sakes.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-102.png)

**Figure 2. SEAS trial.** In SEAS, a trial designed to look at reducing aortic stenosis-related events, statin plus ezetimibe reduced ischemic events (secondary endpoint) compared to statin plus placebo.

Peter Attia: Then again, that just, that kind of stuff just breaks my heart. It doesn’t anger me, it breaks my heart.

Tom Dayspring: But again, post-hoc analysis: they did reduce the ischemic events in that trial with ezetimibe. So, MI’s went down, as a secondary endpoint, but that’s post-hoc analysis.

Peter Attia: And they got lucky. They didn’t power for that.

Tom Dayspring: No.

Peter Attia: They may or may not be legit.

Tom Dayspring: Correct. So you’d have to do another whole trial do that again. So, they were hoping to sneak by without doing. The next thing they did was: statins had failed to reduce clinical events in people with chronic renal failure. Statins didn’t work. So, let’s give them a statin plus ezetimibe. So, you had the SHARP trial ([Baigent et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/21663949)) (Figure 3). They had pretty bad GFR’s, so everybody: two groups got a statin, but the one group got a statin and ezetimibe. And the statin-ezetimibe group reduced events. So. But, a statin- ezetimibe works. And then of course they really had to wait for the acute coronary syndrome and IMPROVE-IT trial (Figure 4), to really convince the cardiologists that: yes a little bit of extra apoB lowering, at least in that type of horrendously risky people, matters. And we now have had that replicated with the PCSK9.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-103.png)

**Figure 3. SHARP trial.** In SHARP, statin plus ezetimibe reduced major atherosclerotic events. Previously statin monotherapy trials failed to improve endpoint in CKD patients.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-104.png)

**Figure 4. IMPROVE IT trial.** IMPROVE-IT revealed that statin plus ezetimibe reduced events compared to statin monotherapy in acute coronary syndrome patients adding more prove that lower is better with respect to LDL metrics.

Tom Dayspring: A great point you made lately: God knows how long the money to do that in IMPROVE-IT trial. They really had extended a couple of extra years to reach statistical significance. Which turns some of these loudmouths on the Internet dismissive because of that now. But it’s a miracle in people that are aggressively treated with statin that you’ve reduced their LDL-C to way, way down. That just by lowering it a little bit more, you can get extra event reduction. And I would never downplay that. I think it’s miraculous that it worked. I think it’s why it’s miraculous PCSK9 inhibitors work in trials where they’re enrolling you, where you’re LDL-C is 70, for god’s sakes, because you’re on a statin or statin-ezetimibe.

Peter Attia: So, that to me, is one of the single most impressive things. Again, we don’t know if this is going to be true in ten years. Again, all facts have a half-life. But from the moment we were sitting here today having this discussion, the fact that the FOURIER trial ([Sabatine et al., 2017](https://www.ncbi.nlm.nih.gov/pubmed/28304224)), could take patients, who had an average LDL-C of 92 milligrams per deciliter on statins. That means they are at the tenth percentile of the Framingham population, on a statin. You are going to add either a placebo, or a PCSK9 inhibitor, in that case it was Repatha [generic name is evolocumab]. You’re going to study them for less than two and a half years? And you’re going to even have the nerve to suggest that might reduce an event? And oh, it did?

Tom Dayspring: And if it doesn’t, you’ve just wasted billions of dollars of our money. What bean-counter allowed that trial to proceed?

Peter Attia: I had been following this story, even before I became interested in lipids, just out of interest in the novelty of: you see a natural experiment, which is PCSK9 hyperfunctioning, PCSK9 hypo-functioning, MR drug. It just became a beautiful, elegant model.

Tom Dayspring: Which in real life takes decades to express itself.

Peter Attia: This all took a decade. I remember thinking, especially once I got interested in lipids: on the one hand being excited, and the other hand thinking: there’s no goddamn way this trial can work. You could not reduce events in 2.2 years. And they did, and of course: this is how naïve I am, and this is why, whenever people ask me for advice, friends will say: hey, should I invest in this company or that company?

**[30:00]**

Peter Attia: My advice to them is: don’t listen to a single thing I say. Because, you’re asking a question: will the market value something, which I have no input on. I can provide you plenty of input on whether it makes scientific sense, but you have to talk to somebody with a different skill set to understand if that’s an investable thesis.

Peter Attia: So, I remember Amgen kind of got hammered when the trial came out, because people thought: eh, that wasn’t enough of an improvement. Which I thought, it’s amazing. In reality and fairness to the market, I think what the market was basically saying is: if you did the math, based on that trial under those circumstances, it would be a million dollars or more to save a life. Well. That’s a fair question for the market to assess. But if you look at it from a scientific standpoint, that you could take that patient population, and achieve that outcome. I think it’s one of the most remarkable things in cardiovascular medicine. And, to your point, it doesn’t even speak to the patients that I have on PCSK9 inhibitors. My patients who take PCSK9 inhibitors are patients whom prior to this drug, we were flailing with what? Maybe some niacin, maybe some mono-therapy, Zetia; maybe the smallest dose of Livalo that a human could tolerate, and getting woefully inadequate coverage.

Tom Dayspring: Yeah, so that’s, as you know, you’re doing that off FDA label, because they would want a trial.

Peter Attia: They’re paying out of pocket for it.

Tom Dayspring: People who can afford it. But, it’s certainly the genetic models tells them you’re doing smart there. I would say, as you know, here are certain nutritional therapies that can send your LDL particle count off the roof, and people are dismissing that as a meaningless biomarker now, because if you do this diet, biomarkers x, y, and z and maybe even your waistline looks better. But apoB, LDL-P doesn’t matter in them. Everything single thing that’s ever been done, genetically or properly done clinical trial shows it does matter.

Tom Dayspring: In an individual, can I say yes it matters in you, it does not? No. But if I want to follow the bulk of the data, it matters over time. So, maybe if I sent you LDL-P off the chart for two years it doesn’t matter. But do I want to do this for the next 15 years? If you’re a young person on a type of nutritional program that sends that through the roof? Is that wise?

Tom Dayspring: Are you going to be mad at me in 20 years or 15 years, because I put you in the CCU? I don’t know.

Peter Attia: How many Nobel Prizes have been awarded within the field of lipid science? At least three, right?

Tom Dayspring: Well, certainly you’ve got the LDL receptor, and you’ve got two for cholesterol, and I’m not guaranteed on other lipid things, there might be. I’m not a Nobel historian.

Peter Attia: No, but it’s interesting, right? I guess there are a handful of discussions I have with patients that I find frustrating. Some of them are frustrating because I have the same discussion over and over again, and I’ve written about the topic, and the patient just won’t read what I’ve at least written, or at least take the time to read or listen to a lecture to then come back and ask a question. So that’s sort of frustrating for a different reason.

Peter Attia: But few things frustrate me more than having to discuss things where the patient’s baseline of knowledge is the Internet. Which obviously, signal to noise ratio on the Internet is so low. All the signal can be found there, but the noise of course is so great, that you just don’t know. But it’s these discussions around cholesterol and statins that I find most disturbing. In some ways it’s party the fault of the PhRMA industry I think. They have to take some responsibility for this, which is: in an effort to get these drugs into the majority of people who need them, there’s been a need to simplify the message. And when you simplify things, especially things as complicated as this field, you will undoubtedly make mistakes. You will undoubtedly create confusion.

Peter Attia: So now we have a system where: most physician’s don’t understand enough to actually explain to their patients why they’re putting them on statins, and which patients may or may not even be good statin candidates. Something I want to come back to, because you brought it up, and I think it’s worthy of its own sort of thread that we’ll go down. Which is this whole brain issue. It’s a totally separate issue, but it’s this idea of failing to educate patients and physicians has allowed, basically, call it a militia of Internet noise that is just completely ungrounded in science. It’s just completely disconnected.

Tom Dayspring: And you’ve already mentioned one example. There are several others where a drug has come to market and some PhRMA developed it. So, therefore, you castigate every drug that’s ever been invented, as: they’re all poisons.

Peter Attia: Even though we just illustrated, right, you can take two drugs that inhibit two enzymes, and get completely different results.

Tom Dayspring: Not a biomarker, but different outcomes.

Peter Attia: And so, I always try to tell patients, although it probably falls on deaf ears: you’ve got to think of every drug like you think of a tool, right? If you had a general contractor, and he had a hammer, a screwdriver, a drill, a level, a nail, a screw, et cetera; you would want to have the most tools in the tool belt. That’s the first condition. The second condition is: you’d want to know when to use each tool, and what it’s limitation was. In that sense, one view which is: statins should be in the drinking water, and the other view, which is: statins cause everything. From diabetes, Alzheimer’s disease to global warming. Both of those views are so idiotic, that it’s very difficult for me to process that. I basically stopped engaging on Twitter with any of that discussion.

Tom Dayspring: You’ve got to get rid of those people very quickly, or you just get annoyed all day long. This is what it ultimately comes down to, and it’s the way you practice: you’ve got to individualize everything. So, anybody who says statins belong in the drinking water, that’s no public health solution to anything. Or, nobody should ever take it: that’s absurd. You’ve got to pick and choose your patients properly. This is why, in the latter part of my career, I’ve developed so much more into biomarkers and other risk-assessment tools, because the better we can define an individual’s risk to any disease that he might be prone to, we can attack that disease through many mechanisms. Part of it is you’ve got attack apoB. If you don’t, good luck. But, the more you understand, that’s where biomarkers and really not understanding these pathways that you talk about, but a lot more clinical chemistry. The average clinician has no clue how a laboratory reports a given concentration of anything to them. I’d like to go into triglycerides, because everybody thinks the whole world: people had no clue how laboratories assay triglycerides, and maybe later we can talk about that.

Peter Attia: One of the things that I’ve been pleased with, is: once I got back into medicine, I realized I didn’t know that stuff. And I have been really fortunate, every lab I have reached out to, to come and actually come to the lab and see how it works, including THD [True Health Diagnostics]. They’ve all opened the doors, and said: come on in, Peter.

Tom Dayspring: Oh they’re more than happy.

Peter Attia: And they over-do it, I love it. They literally will walk me from every station to every–this is where the specimen arrives. So you can see where the FedEx box dumps off the specimen. This is how we take it out, this is how it’s handled, this is boom, boom, boom. All the way to: here are the magnets where we’re doing the NMR. And I’ve got Precision Analytics has also been great; I went up and spent two days with them a few years ago. I agree, again, not every physician I think has the luxury of time, because they’re clinically so much busier than I am. So I certainly don’t fault physicians for not doing that. But I do wish there was a way to make that sort of experience more available to physicians; because the more you understand how these tests are done, the more you understand what your blind spots can be.

Tom Dayspring: Yeah, I was doing that for a while when I had more of a net presence with full lectures, which I don’t do anymore. Or they’re not available on the net anymore. But just one other thing, like I told you: most people are clueless that labs don’t measure triglycerides, they measure glycerol in your blood. They calculate that into triglycerides. But when you get in LDL-cholesterol or a total. Let’s talk about LDL-cholesterol. The platform that’s analyzing the sterol in that particle has no difference. Does it know whether it’s sitosterol, campesterol, desmosterol, cholesterol? No. All it knows is it’s a sterol.

Peter Attia: So it just knows it’s not a stanol.

Tom Dayspring: It’ll measure a stanol, too, but they would likely be a small part of it. So, LDL-cholesterol is really: LDL-cholesterol, plus LDL sitosterol, plus LDL desmosterol, LDL-campesterol. And the other 48 then, whatever other stanozolol may have made their way into your body too. So they don’t know that. A person with phytosterolemia large part of that LDL-cholesterol value is a-

Peter Attia: Is the phytosterol.

Tom Dayspring: They don’t even know: if phytosterol are injurious, and I can make that case; if I did a one-hour lecture to you using proper slides, you would be pretty convinced: I want phytosterol not in my body. Ezetimibe is the only way to keep them out there. Wherever you’re going next, my final word on ezetimibe would be: if you’re a big believer in this reverse cholesterol transport process, which I’ve certainly expounded on now, what is the number one pharmacological agent, that increases that amount of cholesterol that’s winding up in your toilet bowl, because it’s in your stool? That would be at the best, reverse cholesterol transport, because the final common pathway to reverse cholesterol transport is: it’s out of the body. ezetimibe by far. So, I can make the case that if I wanted a lipid-lowering drug, and the drinking water is first line, it would be ezetimibe, not a statin.

**[40:00]**

Peter Attia: And very controversial.

Tom Dayspring: Yeah. Look, the FDA would put me in a lunatic asylum and so would these so-called evidence based guys. If you’re analyzing this from a cholesterol homeostatic pathways, it’s great drug.

Peter Attia: Yeah. Well, we’ll come back to all drugs.

Tom Dayspring: Most of the time we do have to lower apoB, a lot more than ezetimibe could ever do by itself.

Peter Attia: I want to come back to niacin from a trials perspective. So let’s take a break right now, and then we’ll come back and we’ll pick it up with, I want to talk about the fibrates. And then obviously I want to talk about niacin, through a clinical trial standpoint, and then we’ll get into the PCSK9.

## Fibrates [41:00]

Peter Attia: We had sort of more or less finished talking about ezetimibe, also known as Zetia, so we’ll use this as an opportunity to go into the next drug. So, Tom, that was pretty insightful stuff on Zetia, also known as ezetimibe. Let’s move to another class of drugs that doesn’t get a lot of use. I can probably count on two hands the number of times I’ve prescribed it. Which is: fenofibrate, or more broadly it’s class of fibrates. What the heck are these drugs, how do they work, and when should we use them?

Tom Dayspring: Well, if you practice in the United States, you do have two choices: you have fenofibrate, and you have gemfibrozil. And they’re both out there; both can be attained generically nowadays, so fenofibrate still comes in branded forms.

Peter Attia: That’s the Trilipix.

Tom Dayspring: That’s one of them, there are other branded forms available out there. Gemfibrozil is a pro-drug, it has to be converted into the active fibric acid, whereas Fenofibrate is the active form right away. It’s a little more bioavailable. It’s kind of interesting, for the purists of the world, gemfibrozil has a monotherapy outcome trial, given to veterans with coronary artery disease who had low HDL cholesterol and high triglycerides ([Rubins et al., 1999](https://www.ncbi.nlm.nih.gov/pubmed/10438259)) (Figure 5). And it reduced events as much as a statin did in any trial. So, there’s outcome evidence.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-105.png)

**Figure 5. VA-HIT trial.** In VA-HIT, the fibrate gemfibrozil significantly reduced CHD death and nonfatal MI in veterans with CAD and low HDL-C, with what was at the time considered unremarkable baseline LDL-C.

Peter Attia: Is it independent of triglyceride level?

Tom Dayspring: Well, it’s independent, although they enrolled people. But many of them, the triglyceride levels were certainly not at super high levels. But it was mostly low LDL cholesterol, and virtually all of those people have some degree of triglyceride elevation. But, they tried to recruit people with, at the time, was considered a normal LDLcholesterol.

Peter Attia: Which trial was this?

Tom Dayspring: It was called the Veteran’s Affairs High-Density Lipoprotein Intervention Trial.

Peter Attia: Oh, VA-HIT. I didn’t realize that was VA-HIT. Okay.

Tom Dayspring: Yeah, that was gemfibrozil. And remember, gemfibrozil already had outcome data from the Helsinki trial ([Frick et al., 1987](https://www.ncbi.nlm.nih.gov/pubmed/3313041)) (Figure 6), too; so this would be the second trial. No, fenofibrate did come along with a couple of big trials ([Ginsberg et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1056%2FNEJMoa1001282)), but it missed the primary outcome, but hit some secondary outcomes for a whole lot of reasons enrolling people, heavy concomitant use of statins, nobody in any gemfibrozil trial was ever polluted by people sneaking in statins with it at the same time. Clearly whatever fibrates do, they do it differently than statins. And the question is: can it contribute to a statin? But those trials weren’t designed to do that, but they were so polluted by statin use.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-106.png)

**Figure 6. Helsinki Heart Study (HHS).** HHS was a primary prevention trial of patients with elevated Non-HDL-C and the fibrate gemfibrozil reduced events.

Peter Attia: I just want to clarify what you mean: I know what you mean, but I want the reader or the listener, rather, to understand. When you say ‘polluted by’, what we’re talking about is: statins are so potent, that when you include them in trials, you are making it much harder for a new drug or compound that’s being investigated to show its effect. Because you’ve effectively raised the bar much higher for what needs to be done.

Tom Dayspring: Sure. You’ve taken out one path, you’re trying to prove with a certain class of drug, that via these mechanisms, it works. And then all of a sudden, you’re getting rid of all the apoB particles, via the statin, so, harder for another drug to show efficacy. The statin is not given in a randomized fashion here. Somebody takes it, somebody don’t, some doc says you take this, don’t take it.

Peter Attia: So that’s the bigger problem scientifically, of course the counter argument is: look, ethically, we don’t want someone getting randomized to no medication. Then the second issue is: if the statin is the standard of care, and therefore in the community that’s the way these drugs are going to be used, with or without statins: that’s the way they should be tested. All these are fair points. But when you ask a true efficacy question, versus an effectiveness question: the cleaner you can ask that question, the better. And there’s not cleaner way to ask it, then to not have another drug involved.

Tom Dayspring: Sure. And by the way, when most trials were done, it was not standard of care, that you had to be on a statin. So they were legitimate trials that were ethical.

Peter Attia: Whereas with the PCSK9 trials, it was standard of care: you couldn’t have a no-statin arm in those trials.

Tom Dayspring: Right. That being said, these are all factors that go into the post-hoc, at least, interpretation of some of these trials. But anyway, so gemfibrozil worked. And it’s kind of interesting: you couldn’t explain the benefit of gemfibrozil in the VA-HIT trial, even though it did raise HDL cholesterol. It was like a milligram and a half increase. And it lowered triglycerides, but not to a significant extent, so why did it work? Or where there other pleiotropic type effects of fibrates? Doing something that we weren’t measuring with any biomarker? Some of that is probably true.

Tom Dayspring: But then, at least in a cohort of it, they did a post-hoc analysis using NMR, this was Jim Otvos who did this. And he found out that the benefit of the gemfibrozil in the VA-HIT trial could be easily explained by what it did to LDL particle count, which fibrates do lower in certain patients. Depending on the cause. And it raised the HDL particles, which had a statistically significant tie into the clinical endpoint. That was the first trial, showing anything that raising an HDL metric in a clinical trial maybe, if you want to do an HDL metric, it’s HDL particle count.

Peter Attia: Can we make sense of that, in light of what we spoke about, I don’t know, 20 to 30 minutes ago? Which was: raising HDL cholesterol, without paying any attention to particle number or particle size, is so noisy and at least is likely to be counterproductive as it is productive. Here, you had two pieces of information. Of the three, at least; which is: you had more particles, you didn’t change the cholesterol content in total, so you could make some inference. Again, not necessarily correct, but you could at least have a better guess that you could make about the clearance of cholesterol through HDL. But of course, then you have to make the assumption about the size of the particle, correct?

Tom Dayspring: Yeah, but very interesting; in an Enamora analysis, whereas HDL particle (HDL-P) went up, it was almost all small HDL particles. And for years, people have been running around, saying: the small HDL’s are bad and the big HDL’s are good, and there was serious evidence that: boy, what BS that is (Figures 7 and 8). So, fibrates help de-lipidate HDL particles. If you’re in the old school, hey you’re increasing reverse cholesterol transport, because the fibrates help regulate the scavenger receptor, B-1, which would de-lipidate your HDL. So of course your HDL’s would become smaller, and then the small HDL’s could theoretically, traverse back into the arterial wall, pull cholesterol out of your sterile-laden foam cells, the histopathologic marker of the plaque after re-genesis.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-107.png)

**Figure 7. VA-HIT comparing LDL parameters.** VA-HIT post hoc lipoprotein data showing CV risk of the veterans was far better correlated to LDL-P by NMR than to cholesterol metrics or apoB.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-108.png)

**Figure 8. VA-HIT data.** VA-HIT post hoc lipoprotein data showing CV risk of the veterans also related to the concentrations of HDL particles (using NMR) and the highest risk was in those with reduced HDL-P and increased LDL-P.

Tom Dayspring: By the way, on a side note; when we talked about the complexities of the reverse cholesterol transport process, one pathway I didn’t mention, it’s a sub-sub pathway, something called—Dan Rader coined this term years ago—macrophage reverse cholesterol transport. He used to make the case: the only aspect of the RCT that matters as far as atherosclerotic clinical outcomes is de-lipidating the foam cells in your artery wall of cholesterol. And that’s really the job of an HDL. It can get into the artery wall very easily.

Peter Attia: There’s another ABC that facilitates that.

Tom Dayspring: There’s a couple of them. There’s ABCA1, which will lipidate small lipid-poor HDL particles; but there’s ABCG1, which will lipidate big, mature HDL particles. So you have two ABC sterol efflux transporters in the surface of macrophages, that can pull cholesterol, efflux cholesterol, out of the macrophage, into a big or a small HDL, which can then return to the plasma and the small one that esterifies it becomes a mature one and gives it to LDL [via CETP-mediated exchange], which returns it to the liver. So, macrophage RCT, which is certainly an incredibly functional aspect of what HDL does, has absolutely no relationship to the serum HDL cholesterol level. So again, how do I know, I can’t use HDL-C as a metric to tell me I’m delipidating plaque in your artery wall; but I can have some confidence that if I’m using a fibrate, that’s one of the things I’m doing if you do have plaque in your arterial wall, and who doesn’t. You know?

Peter Attia: So why do you think the fibrates work best in patients with a higher triglyceride level?

Tom Dayspring: Because they’re main mechanism: look, so they modulate HDL particles; but triglycerides has a lot to do with HDL remodeling too; but fibrates mostly stop the synthesis of the LDL particles, triglyceride-rich LDL particles in the liver, by [reducing] triglyceride pools in the liver.

**[50:00]**

Remember, what determines the lipidation of apoB in your liver: all humans make two tons more of apoB than they ever have a prayer of lipidating and changing into an apoB particle. The vast majority of your apoB gets catabolized. Because it’s unused. So people are always: well, what produces apoB? Nothing. Your liver makes way more apoB than any human can ever use.

Peter Attia: Why do we think that is?

Tom Dayspring: I don’t know. People just assume: hey, if you’re making too much of something, you’ve got to be increasing the codependents. Except the one component we make too much of and never use is apoB.

Peter Attia: Yeah, I wonder why, teleologically, would be the case. That we would make orders of magnitude more apoB than we could ever want to export.

Tom Dayspring: Abetalipoproteinemia is death. So, you have to make apoB particles. They transport energy, they transport phospholipids, they transport fat-soluble vitamins, the big particles. So, you can’t not have apoB particles in your plasma.

Peter Attia: So you think it’s just a margin of safety that is so big, it’s not even?

Tom Dayspring: Yeah. They just make far more than we ever use. So, it’s very easily catabolized. So, you have a lot of it. But, what determines the creation of the VLDL particle in the liver, it’s the lipid pools. How much lipid is available to attach to apoB, and create a circular, spherical particle that’s going to be ejected by the liver. And that comes down to the cholesterol pool and the triglyceride pool. And triglyceride is the stored energy in your liver [as cholestryl ester]. And cholesterol is stored in your liver. So, cholesterol, I think I mentioned before, binds to the cholesteryl ester, binds to the, or free cholesterol, binds to the apoB first. Some of the cholesterol will be esterified even in the circulation, some in the liver; via that ACAT [and LCAT] enzyme. Then once you get the little primordial spherical of the LDL, then triglycerides are transferred in using MTTP, microsomal triglyceride transfer protein, and now you’ve got a real VLDL ready to be shipped out. As it passes through something called the space of Disse, which is a little space between the hepatocytes and the plasma; other apoproteins join there.

Tom Dayspring: But believe it or not, many of them, as soon as that nascent VLDL, or whatever you want to call it, enters plasma, a ton of the apoproteins just leave your HDL particles. One of the functions of HDLs, remember I told you is to transport proteins. They transport a ton of these proteins that are involved with lipoprotein catabolism. So C-II jumps off of HDLs, E jumps off of HDLs and goes right onto the surface of a VLDL, if it was not put there as it passed through the space of Disse, and they all determine the catabolic fate of that VLDL particle.

Tom Dayspring: So fibrates, through several mechanisms ([Dayspring and Pokrywka, 2006](https://link.springer.com/article/10.1007/s11883-006-0032-x)), inhibit an enzyme involved with the synthesis of triglycerides, it’s adding fatty acids to glycerol. Fibrates are a potent inhibitor of that, seemingly just stop triglyceride production, fibrates. Omega-3 fatty acids work in a similar way. They deplete the hepatic pool of triglycerides and you’re gonna make less VLDL particles. Remember, a fibrate is not gonna blow away your LDL-P like a statin does, but it’s gonna have a 10, 15% reduction, in part depending on the triglyceride richness [of the lipoprotein particle], not the serum triglyceride level, but the triglyceride richness of the core so that’s one.

Peter Attia: Now where’s the backup of free fatty acids? Because at some point if you’re not synthesizing as much triglyceride.

Tom Dayspring: You still have enough fatty acid. You’re absorbing fatty acid, your adipocytes store them.

Peter Attia: But is there a hepatic backup of fatty acids?

Tom Dayspring: De novo synthesis.

Peter Attia: So in other words, this would not decrease NAFLD. Because at first blush, you’d think, “Well, a fibrate should be able to reduce fatty acid, to reduce fatty liver.”

Tom Dayspring: It was thought that for years, but it’s just never been proven in a trial that alone would do it. Whereas, ezetimibe has more data on reducing fatty liver ([Takeshita et al., 2011](https://www.journal-of-hepatology.eu/article/S0168-8278(11)60870-2/abstract)) than fibrates do and most people all blame fatty liver on triglycerides. It’s sterols that really cause a large part of the lipotoxicity ([Puri et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17654743); [Wouters et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/20114046); [Van Rooyen et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/21703998)) that results in injury to hepatocellular, the cells in your liver. There’s a lot of animal data on ezetimibe eradicating fatty liver, because they deplete the cholesterol pool in your liver. It’s not all fatty acids and triglycerides that are causing fatty liver, sounds like it is, but I’d say toxic disease, it’s a lipotoxic disease and it’s not all fatty acids.

Peter Attia: Although the fatty acids must play a significant role. I shouldn’t say must, but would suggest it because when you look at some of the preliminary data now that’s coming out with fructose elimination, meaning without restricting any other macro or micro. It seems that glucose is not that relevant, even fatty acid composition, not that relevant, if you completely restrict fructose.

Tom Dayspring: Well, fructose is a major stimulus for synthesis of the triglyceride.

Peter Attia: Of the triglyceride, but not to my knowledge, I don’t know where it would fit into the cholesterol synthetic pathway, right?

Tom Dayspring: Yeah, but look, it’s a lipotoxic disease. One of the major lipids that’s causing hepatocellular toxicity is cholesterol. It’s just not all fatty acids. I’m not implying there’s no role of fatty acids or fatty acid synthesis, triglyceride synthesis related to fructose, but it’s not all just somehow ignore cholesterol and you’re gonna get rid of fatty liver.

Tom Dayspring: You can’t even separate the two because if you have a lot of triglycerides, you’re gonna have a lot of the apoB particles that are the cause of that sterol toxicity.

Peter Attia: Yeah, that’s probably the bigger issue. It’s very difficult to desegregate them once triglycerides are elevated. So really, the ideal candidate for fenofibrate is gonna be someone with an elevated apoB and an elevated triglyceride.

Tom Dayspring: If you look at, even if you take the two positive gemfibrozil trials, and the failure of fenofibrate in a couple of trials easily explained if you look at things, and basically they enroll people that didn’t have insulin resistance or triglyceride-rich lipoproteins and gave them a fibrate. So they designed a clinical trial where nobody in their right mind would ever give that person (i.e., someone that didn’t have elevated triglycerides nor low HDL-C) fibrate for a bunch of reasons, but they were diabetic, but without hypertriglyceridemia.

Peter Attia: Wait, they were diabetic?

Tom Dayspring: Yeah. FIELD trial was 100% diabetics and so they figure it’s a no-brainer, fibrates, because of so many things that they do will improve outcomes. Maybe they would have, but the FIELD trial was so polluted by statin, unauthorized use of statins, inappropriate use of statins. Remember, you’re in a clinical trial. You’ve got the trialist watching you, but you’re going to your own private doctor. And they were nervous at the time because the statin data was coming in and it was almost, it was getting to the point where you’re a bad doctor if you don’t give a statin to somebody with a lipid disorder, so they said, “I know you’re in a trial, we don’t know what you’re getting, but I’m sorry, I’m not happy with your LDL-cholesterol. Take this statin.”

Tom Dayspring: We can always guess, if we could have kept it as a pure trial of fibrate, if it would have worked in diabetics, but that’s just opinion. It didn’t work, but it did work in everybody who had an increase in triglycerides and low HDL cholesterol. It worked, and that’s where the outcome reduction was ([Elam et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/21102326)). Very interesting, which no other lipid drug has ever done, it reduced several microvascular endpoints in those trials too, retinopathy, amputations, peripheral neuropathy, renal disease, even though fenofibrate can raise creatinine a little bit, GFR improved, and renal outcomes improved. What other drug you can give a person that will lessen his chance of a diabetic retinopathy if he’s a diabetic? Nothing. Now it’s post-hoc, it’s secondary, well that wasn’t planned, that was secondary outcome, so the trials weren’t designed to prove that, so they were a hypothesis. You’d have to theoretically go back and do that before the FDA would ever give you approval, but kind of interesting data.

Tom Dayspring: I’ve always made the case what? Fibrates reduce amputations, neuropathic ulcers [and BK amputations], improve renal disease, save your eyes, why the hell are you not on a fibrate if you’re a diabetic? Again, using that type of data and people use drugs for far less data than that. These are big, huge trials and all of those endpoints have published or analysis of those secondary endpoints (renal: [Davis et al., 2011](https://link.springer.com/article/10.1007/s00125-010-1951-1); [Bonds et al., 2012](https://www.ncbi.nlm.nih.gov/pubmed/22450889); microvascular: [Hermans, 2011](https://journals.sagepub.com/doi/abs/10.1177/1479164111407783); retinopathy: [Keech et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17988728); [Gerstein et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3631868/); amputations: [Rajamani et al., 2009](https://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(09)60698-X.pdf); uric acid and gout: [Waldman et al., 2018](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(18)30029-9/fulltext)).

Peter Attia: What are the main side effects of fenofibrate?

Tom Dayspring: Not a heck of a lot. It’s a pretty well tolerated drug. Anybody can get any number of any side effects with it or so. People used to be afraid of the increase in creatinine until in the FIELD trial, in a large number of patients, were doing creatinine clearance. So it was a muscular buildup of creatinine and had nothing to do with GFR or renal clearance of it, but there’s nothing much. There are some drug-drug interactions.

Peter Attia: The fenofibrate and ezetimibe, they’re both very well tolerated, certainly more tolerated than statins.

Tom Dayspring: They really are and you can make the case, at least in a diabetic, which is probably gonna be, especially with what we know now, the patient is gonna wind up on a fibrate, now most lipidologists wouldn’t use it until you “statinize” somebody or “statinize” them and “ezetimize” them, go their apoB as good as you can get it, it’s still not there or triglycerides, which is what they’re looking at, too bad in my mind, but they’re looking at that and it’s still high.

**[1:00:00]**

That is the persons that were helped, at least in post-hoc analyses of every single fibrate trial, including the VA-HITthere and all the fenofibrate trials. That’s pretty much where it’s reserved to, people with these identifiable hypertriglyceridemia patients or so.

Tom Dayspring: We’re not talking about people with triglyceride of 400 or 4000 where pancreatitis comes into play. We would probably all use a fibrate and a lot of other stuff there like omega-3 there on hopefulness that it would reduce the incidence of pancreatitis, not proven yet, but you would attack that degree of hypertriglyceridemia. The real world is people with triglyceride between 130 and 300, that insulin resistant world which we’ve already clearly defined as an apoB disorder so that’s why your statin, statin/ezetimibe is your first line drugs there.

## Fish oil, DHA, and EPA [1:01:00]

Tom Dayspring: But if you didn’t normalize that with your statin or statin/ezetimibe or indeed triglyceride were still high, so you’re presuming there still are triglyceride rich lipoproteins, whatever they may be, they might be remnants, they could be LDLs that are triglyceride rich. Especially in the lipidology community who are way more familiar with fibrates, although it’s sadly a disappearing drug that even younger lipidologists come on board have never been taught anything about and they don’t go back and re-read, so it’s the older guys like me who grew up through all those trials, have lectured on them, have written on them, really have a better understanding of it than a younger lipidologist, and that’s unfortunate because we’re gonna have a potentially effective drug for a certain amount of people is just not gonna be used anymore. They’re apt to use a fish oil instead, because it lowers triglycerides and it’s so easy to tell somebody to take a fish oil. They’re not gonna go home and read potentially scary stuff on the Internet where they might with a fibrate or something.

Peter Attia: Oh no, they’re gonna still read it.

Tom Dayspring: Yeah. I guess on everything you’re gonna read some crazy stuff on the Internet. Tragically, to me.

Peter Attia: When you say fish oil, is it more the EPA that’s having the effect on triglyceride?

Tom Dayspring: No, EPA would have more an effect on apoB but DHA is the triglyceride. There’s some recent new data published on that. DHA is just more potent on C-III than is EPA. I personally think you ought to give both. If the primary reason you’re gonna throw a fish oil, a prescription fish oil product at somebody is I need extra apoB lowering, yeah, then I would give high dose EPA, but I monitor omega-3 levels in everybody, so not everybody can convert EPA to DHA. DHA is just as crucial for a lot of reasons. Your brain sure wants it. I will measure, oh my God, I’m giving you a lot of EPA, but you’re one of the people who can’t convert it to DHA so then I would-.

Peter Attia: Give you DHA.

Tom Dayspring: Give you some DHA or you take the high strength EPA and you throw in a lesser strength EPA, DHA combo tablet which is how you get it. As far as I know, there’s no DHA only tablet, whereas EPA only tablets are certainly in the prescription realm.

Tom Dayspring: So fine if you want to lower apoB, you can stick with your apoB, but where is my evidence that if I use whatever fish oil therapy I want to use, I’m improving microvascular disease? I have pretty serious evidence that I’m doing that at least with fenofibrate.

Tom Dayspring: The other thing, although they’re both available generically, sometimes these little drug [insurance, 3rd party payer] companies, they’ll force gemfibrozil on you. The real reason, when you ask me are there are any side effects about fibrates, and I did say the word drug interactions. Fenofibrate has a serious drug interaction with Coumadin so you have to lessen the Coumadin dose there. We’re using a lot less Coumadin.

Peter Attia: We’re using much more Eliquis these days.

Tom Dayspring: So that’s becoming less of a big worry, but God forbid somebody’s on Coumadin and you didn’t know that and you threw big dose fenofibrate at them. You call me up with a lot of bruises because you potentiate the anticoagulant. Gemfibrozil though raises statin levels through the roof. There’s much more incidents of myositis and rhabdomyolysis when you use gemfibrozil with a statin and there’s none of it with fenofibrate. If you want to use a fibrate, I strongly encourage you, because it is generic nowadays, to use fenofibrate because you’re gonna be using it with a statin in the vast majority of cases, so you don’t have that worry, the muscular worry. Those are the two big things you better know about fibrates.

Tom Dayspring: Most of the lipidologists at least were somewhat schooled on fibrates and are gonna use it in people where the triglyceride parameter is still high. I think if we had better metrics of triglyceride rich lipoproteins, maybe VLDL remnants or people who have high LDL triglyceride levels, and they would likely be people who have apoC-III on their LDLs, we have some other evidence that I want a fibrate on board, see VLDL effects ([Hiukka et al., 2007](https://link.springer.com/article/10.1007/s00125-007-0751-8)), that’s where that’s gonna get used but that’s not your average person. If he wants into the average doctor, the doc’s gonna be chasing LDL-cholesterol, or non-HDL cholesterol if they’re a little more astute and they’re gonna stop there.

## Niacin [1:05:15]

Peter Attia: I want to come back to, I made a note here to come back to VLDL remnants. I got another question on that. But, I do want to finish our tour of drugs. The next drug to then get into we’ve already kind of talked about a little bit, but I want to come back to it because I know you have a strong point of view on it, and I’ve got to be honest, I’m a little bit ambivalent. I don’t know the last time I prescribed this drug, but just from an intellectual standpoint, I’m always interested in these drugs for people who can’t go down a mainstream route and that drug of course is niacin. I don’t think there’s anybody out there that says, “Hey, niacin is first line.” I don’t think anybody would argue that.

Peter Attia: I think the question is you take a statin intolerant patient who’s got normal triglyceride, who maybe doesn’t respond particularly well to monotherapy Zetia, who can’t afford a PCSK9 inhibitor and doesn’t meet the regs for approval, are these patients who should be on niacin? I’ll go back to where we were earlier. Niacin exists in an immediate release in a time release form.

Tom Dayspring: Two types of time release forms.

Peter Attia: Oh, I didn’t even realize that.

Tom Dayspring: Intermediate release and sustained release.

Peter Attia: So Niaspan, the AbbVie [formerly called Abbott] version.

Tom Dayspring: That’s intermediate. That’s a prescription only product which are not gonna get covered by anything.

Peter Attia: I learned that the hard way because I had a patient that was on it a few years ago and he got a bill for like, they wanted $3,000 for it. For B vitamins. It’s ridiculous.

Tom Dayspring: But if you somehow believe in niacin or want to give it a trial, immediate release and you got to give it three or four times a day at massive doses, you’ll flush your brains out most people. You’re gonna take it because you’re not flushing and niacin isn’t working.

Tom Dayspring: But the sustained release is cheap. You can get sustained release, but the biggest problem was in clinical trials, niacin being the toxic drug it is, there’s way more hepatotoxicity with sustained release niacin than there is with the short release or the extended release where there’s no hepatotoxicity.

Peter Attia: So first of all, niacin became interesting as you talked about, because it’s been known for a long period of time it lowers cholesterol. It lowered LDL cholesterol.

Tom Dayspring: Yeah, and better yet raised HDL cholesterol. That’s what everybody always focused on, everybody. Since low HDL cholesterol is a risk factor, we now know apoB related, but whatever, therefore if low HDL cholesterol is bad, raising HDL cholesterol has to be good and niacin is the best product you had at the time.

Tom Dayspring: So trials were done with niacin and it was kind of funny because I listened to the podcast you and Ron Krauss was kind of cool because you made the case a little bit for niacin, Ron did, but at the end as you just said, you’re ambivalent to it, and even Ron says, “I don’t use it much anymore.” You maybe wind up, okay, it’s a fourth line drug if everything else has failed. All right, I’m not gonna smack you around too much if you say that. And you can’t prescribe a PCSK9 inhibitor because of cost, all right. But, I think at the end of your podcast, go back and listen, you both admit it. You don’t use the darn drug anymore.

Peter Attia: But I think the difference is, and this is where I’d love to hear your take, I think Ron’s point of view was the niacin trials may have failed for the same reason. The discussions we talked about earlier which was overly “statinized” patients. Now, you kind of had a different point of view on that, right?

Tom Dayspring: No, niacin has one trial designed to use niacin as a monotherapy. It was that big Coronary Drug Project, which was a multi-prong therapeutic trial where they randomized people to a bunch of drugs. One group was given solely thyroid hormone. Thyroid hormone lowers LDL-cholesterol and all they did was kill people by with coronary disease you give them thyroid hormone.

Tom Dayspring: You make them hyperthyroid. So that drug failed. They used a primitive fibrate, clofibrate, and there was some question of a mortality adversity there so that was hit number one. Nobody in America uses clofibrate anymore. It’s probably still available in Europe, I don’t think anybody uses it. Fibrate arm of that trial failed. They used estrogen given to men, because, hey, women don’t get heart disease because they have high estrogen levels. If we just gave estrogen to men, they wouldn’t get heart attacks and they had to immediately stop the trial by precipitating heart attacks in men by prescribing estrogen.

**[1:10:00]**

Peter Attia: The only thing that would make that funnier was please tell me they gave it orally.

Tom Dayspring: They did.

Peter Attia: Oh God.

Tom Dayspring: That was about the only form they had back then. Anyway, so yes. Then they had a niacin, immediate release niacin arm. Now you know in a clinical trial world, if you go down to the FDA and you just put a drug through a clinical trial, it better be empowered or better not have been much toxicity, and you better come in and have hit your primary endpoint, because what will the FDA never, ever allow you to discuss? A secondary endpoint. If you fail the primary endpoint, you have a failed drug. All you’ve done by improving some secondary endpoint is generated a new hypothesis. Let’s go back and do a trial on those people.

Tom Dayspring: What was the primary endpoint in the Coronary Drug Project? Favorite endpoint that people today love, mortality. Guess what niacin did to mortality (Figure 9)? It worsened it, not statistically but you could say it was no but it was certainly going in the wrong direction.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-109.png)

**Figure 9. HATS trial.** Dosages of the various therapies used in HATS – note there was not any niacin monotherapy arm and with the lipid changes were seemingly very favorable. The niacin used was the extended-release formulation (Niaspan).

Tom Dayspring: Did I care when they did the secondary analysis? But wait a minute, myocardial infarctions were done. It was like me telling you in an aortic stenosis trial, but hey, Zetia reduced myocardial infarctions but it didn’t reduce aortic.

Peter Attia: But in fairness, was the trial powered for mortality or was it powered for MI?

Tom Dayspring: No, it was powered, mortality was the only endpoint in all the arms of those trials, that’s what they were looking back at then. [Figure 12]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-110.png)

**Figure 12. CDP data.** The primary outcome of the CDP was all cause mortality – Niacin failed to improve it. In any clinical trial when the primary endpoint is missed, secondary endpoints have no meaning beyond being hypothesis generating.

Peter Attia: All cause mortality or coronary mortality?

Tom Dayspring: No, it was all cause mortality. I don’t know.

Peter Attia: That’s kind of amazing, because that’s very unusual.

Tom Dayspring: You’re talking about a trial in the 1960s, early trials. How they picked endpoints. So don’t come and preach to me that it hits secondary endpoints.

Peter Attia: But wait a second. Why is it that niacin failed this trial in the ’60s and it was only three or four years ago that basically the payer said, “We’re no longer paying for it.”

Tom Dayspring: Well, because we’ve had a lot of other trial data that’s come down since then where other types of niacin and probably better designed trials also failed to reduce any endpoints, so the evidence became overwhelming. Show me a damn trial where it works and then maybe we’ll give you, we’ll pay for it at least. The FDA would never give an indication that a primary endpoint data or so. Then the other thing they did with that Coronary Drug Project is they published, like 10, 12 years later, the most ridiculous post hoc analysis done on questionnaire sent to people who they could round up, who they discovered you were in the original trial, small number and lo and behold, mortality was improved in that group of people, coronary mortality. There we have evidence that niacin improves coronary mortality.

Peter Attia: The problem is the selection bias.

Tom Dayspring: It’s still that type of post hoc analysis. It wouldn’t even be published today. It would be laughed at if you ever submitted it to a journal. I don’t think a drug company would even send the Coronary Drug Project to a journal nowadays. I mean, they almost have to nowadays. No trials, they tried to hide them in the end, but it got published and thank God it did. We learned a lot about a lot of drugs in that trial. There was no evidence in a trial designed to prove niacin reduced coronary heart disease, at least the level one evidence.

Tom Dayspring: Angiography got introduced and they could start doing regular angiograms, quantitative angiogram where you’re basically looking at the lumen of an artery and seeing how much plaque may be extruded into the lumen. You’re doing nothing to what plaque may be existing in the coronary artery walls and in that trial using quantitative angiography, they did see a statistically significant improvement in the lumen of arteries in people with coronary artery disease who took niacin. That’s the HATS trial [HDL Atherosclerosis Intervention Trial] (Figure 10). It’s a small, well under 100 people, given niacin. No statins or anything.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-111.png)

**Figure 10. HATS trial data.** The CV event reduction seems impressive – to the point of being ridiculous: but of course a trial of so few people for such a short time is not empowered to investigate CV outcomes.

**Note from Tom Dayspring:** Niacin has been in several angiographic trials combined with fibrates, statins and antioxidant vitamins. All showed angiographic improvement and although NONE were powered to prove it, there was event reduction in the patients aggressively treated with niacin combination therapy.

**CLAS (Cholesterol-Lowering Atherosclerosis Study)**: Niacin + colestipol (a bile acid sequestrant) improved arteriograms ([Blankenhorn et al., 1987](https://jamanetwork.com/journals/jama/article-abstract/366621);).

**FATS (Familial Atherosclerosis Treatment Study)**: looked at 146 patients using niacin and a BAS (colestipol) or a statin or all 3. There was no niacin only group. There was angiographic improvement and although not empowered a reduction in clinical events ([Brown et al., 1990](https://www.ncbi.nlm.nih.gov/pubmed/2215615)).

**HATS (HDL Atherosclerosis Treatment Study)**: 160 patients divided into 4 groups placebo, niacin + statin, niacin + antioxidants + statin, antioxidant only group. There was no niacin only arm. Although the trial was nowhere near empowered to look at clinical events there was a 90% reduction in the niacin + simvastatin group compared to placebo. The antioxidant by itself did nothing and added no additional benefit when used with niacin+simvastatin ([Brown et al., 2001](https://www.ncbi.nlm.nih.gov/pubmed/11757504)).

Tom Dayspring: They come to this conclusion it was a 90% event reduction. Not only did we see a fraction of a millimeter increase in the lumen, and by the way, at that rate it would have taken you 200 years to open up the artery, seriously, to hemodynamic blood flow, but in this small cohort, in a trial absolutely not empowered to look at clinical outcomes, there were less coronary events in this trial. That got extrapolated through a lot of disingenuous marketing of people saying, “Oh, look at this.” Nothing ever gives you that type of outcome reduction in niacin, 90% event reduction.

Peter Attia: I’m sorry, just want to make sure I understand that. I’m actually not even familiar with the HATS trial. This had 100 subjects in it?

Tom Dayspring: Yeah, 98\*, something like that.

\* **Note from Tom Dayspring**: Actually was 146, divided into 4 groups [placebo (#34), niacin + simvastatin (#33), antioxidant vitamins (#39), niacin + simva + antioxidants (40)].

Peter Attia: So 50 in each arm? It was a one to one randomization?

Tom Dayspring: No. I think they just did the angiograms on people and they put them on niacin [assigned them to 1 of 4 groups, two of which had used niacin] and they did a repeat angiogram.

Peter Attia: So 100 people with a crossover. Basically you were your own control.

Tom Dayspring: Yeah. What your baseline arteriogram was and your follow up. [No crossover was done.]

Peter Attia: I don’t want to get into a lecture on shitty science, but I can’t help myself. To be clear, there’s no placebo group here.

Tom Dayspring: Right. [There was a placebo group (got nothing), but no niacin-only group.]

Tom Dayspring: They were looking at angiographic changes from a drug.

Peter Attia: No, understood, but there’s a performance bias here. Every patient in that trial knows that they are being given a compound that is supposed to make them better.

Tom Dayspring: Yeah, and are given other advice, too.

Peter Attia: But the point is, you have no idea of knowing if they’ve changed any other behavior that may or may not contribute to an improvement, notwithstanding, the bigger issue I would have with that trial, which is that the millimeter change of an angiogram doesn’t actually tell us anything.

Tom Dayspring: We now know it’s meaningless.

Peter Attia: About the vulnerability of plaque or true events.

Tom Dayspring: Of course not. You certainly can’t use those type of numbers of people [i.e., so few] to generate outcome data. They did it, it was disingenuous for them to do it, it’s absurd for anybody to ever talk about it, but they did it. Look, we were in our infancy on these drugs. We’re learning as we go along. It’s easy for us to say that now on everything. There were three or four other niacin angiographic trials that sort of indicated, “Oh the images look better when we follow up on these people and HDL cholesterol is going up so what else could it be?” That HDL, that HATS trial, was so impressive to people that they said the only way we really can prove this is to do a giant randomized prospective blinded trial where we give niacin added to whatever else, get this HDL raising on top of we’re already giving drugs that lower LDL-cholesterol.

Peter Attia: Was this AIM-HIGH ([Boden et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/22085343)) (Figure 11)?

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-112.png)

**Figure 11. AIM-HIGH findings.** AIM-HIGH was the second (CDP being the first) randomized, blinded outcome trial investigating niacin’s effect of reducing adverse CV outcomes. This trial was started because of the findings in the smaller HATS investigation. There was no benefit of adding to a statin or statin plus ezetimibe, despite better lipid changes in those using niacin.

Tom Dayspring: AIM-HIGH was the first. There’d been no AIM-HIGH if there wasn’t this HATS angiographic trial first. That was the whole premise to let’s spend money on the AIM-HIGH trial, because, and now we are in the statin era where you do have to give everybody a statin, so we’ll make everybody’s LDL-cholesterol perfect, and by the way if a statin doesn’t do it, we’ll add ezetimibe to it also, so we will get LDL-C perfect, but HDL-C is still gonna be low so we’re now gonna add niacin.

Peter Attia: I think is Ron’s real point which is when you look at that trial, which was really then using niacin to increase HDL-C in an already optimized LDL patient, you missed an opportunity to actually ask.

Tom Dayspring: You didn’t miss it, because here’s what happened. In that trial, niacin made the apoB go lower than statin and ezetimibe did by themselves so you got additional serious apoB lowering and no outcome reduction.

Peter Attia: How much lower did it get?

Tom Dayspring: Another 10, 15%. Here is a drug that is drastically further lowering apoB, atherogenic particles, it’s raising that as I now call it stupid metric, HDL cholesterol, but it’s not working. Well, I just think anything I believe works because it lowers apoB. Why didn’t niacin? Because it’s got to be doing something bad that’s aggravating your arteries and you give me a drug that causes acanthosis nigricans in human beings, pathognomonic of insulin resistance, why would I ever give that drug to a human being? Niacin causes, worsens, and the only person who you’re probably gonna wind up giving niacin to is probably insulin resistant, identified by triglyceride-HDL abnormalities. You’re giving niacin.

Peter Attia: And it makes them worse.

Tom Dayspring: I could read off 15 other well-known side effects with niacin.

Peter Attia: I don’t think anybody would dispute that.

Tom Dayspring: Why did it fail, even though it lowered apoB, beyond what a statin, ezetimibe can do?

Peter Attia: It’s a very interesting point, and I guess the only, if I could wave a magic wind, the only other question I’d have, which is purely intellectual, again, I don’t really think niacin has a place anymore. Could the wash on mortality despite the reduction in apoB be explained by the worsening of insulin resistance?

Tom Dayspring: Could be explained by something.

Peter Attia: No, but I’m saying like that would actually be an interesting thing to try to quantify.

Tom Dayspring: Could be explained by GI bleeding well-known to do that. It could be explained by all sorts of hematologic parameters disruption, platelet reactivity with niacin, well-known, and a bunch of other things that niacin has been implicated in. To me, every time you use a drug, you’re using trial data benefits versus risk and I see some benefits to niacin. I don’t think the HDL is a benefit, but lowering apoB, I’m gonna always consider that a good benefit, but if nothing is happening, there’s something adverse going on which I don’t understand. Look, they took that extended release product off the market in Europe based on this trial. In the United States it’s still here, but they just made it unaffordable so they don’t want you using it. Immediate release niacin is you’re basically prescribing a vitamin at a mega dose. [Figure 13]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-113.png)

**Figure 13. CDP warning.** Here was a warning from the authors of the CDP way back in 1975 that caution is required before using niacin in a secondary prevention scenario.

**[1:20:00]**

Tom Dayspring: One other little aside, because I know there’s people, “Oh, take niacin,” remember these trials were done with massive pharmacological doses of niacin. They didn’t take a multivitamin with niacin in it, which has nothing to lipids or lipoproteins, so if you want to be a niacin player, in the Coronary Drug Project, immediate release niacin was 4 g a day. Try that.

Peter Attia: Wait, so those patients took 1 gram, four times a day?

Tom Dayspring: Yeah. [Correction: was actually 1 gm, 3x/day]

Peter Attia: For years.

Tom Dayspring: They worked their way up to it. They got them on pretty high doses, I will say, in those days. Kudos to the docs in these trials.

Peter Attia: Kudos to the patients for tolerating it.

Tom Dayspring: Yeah. Listen, if you get not only flushing but massive pruritus can occur when you use immediate release. It’s a scary phenomenon to a layman who experiences that who hasn’t been warned. I remember a call I got early in my practice, like at 2:00 in the morning, the guy thought he was gonna die. He had dialed 911 because he just had an extensive pruritic reaction and he felt his whole body was on fire. If he would have had a swimming pool, he would have jumped into it, because he just thought his body was burning up. I just said, “You’re gonna think I’m crazy. Chew two aspirins and just call me back in an hour. It will be gone.” I forget whether he did wind up in the ER or not. Now that’s an extreme reaction, but it occurs.

Tom Dayspring: Look, I took niacin a couple years myself on some of the beliefs, before we knew a lot of this, because I could not tolerate a statin or statin, ezetimibe and I had an apoB issue and I hadn’t learned about intermittent fasting or followed a low carb diet at that time. Unfortunately, niacin didn’t even lower the apoB in me. It did nothing, but I tolerated it for whatever reason. But it did nothing and who knows what it did to my insulin resistance.

Peter Attia: Niacin sort of grew out of favor with patients, even before the final trial. I think just the exacerbation of insulin resistance became sort of problematic.

Tom Dayspring: By the way, the last trial ([NEJM, 2014](https://www.nejm.org/doi/full/10.1056/NEJMoa1300955)), they did another trial, because it was a branded product, they took that extended release niacin but they combined it with an anti-itch compound and aha, so everybody can tolerate niacin now. They added it to a statin, that was the Heart Protection Study THRIVE [The Heart Protection Study 2–Treatment of HDL to Reduce the Incidence of Vascular Events (HPS2-THRIVE-2)] and it was basically a duplication of the AIM-HIGH trial. Nice increase in HDL cholesterol, further reduction in apoB (Figure 14).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-114.png)

**Figure 14. HPS-THRIVE-2.** HPS-THRIVE-2 was the third major randomized, blinded, controlled study using niacin (administered with an anti-flush medication called laropiprant) that failed to show any clinical outcome benefit.

Peter Attia: Slight decrease in apoB.

Tom Dayspring: Zero outcome change. A lot of toxicity ([Eur Heart J, 2013](https://academic.oup.com/eurheartj/article/34/17/1279/444301)). Much of the toxicity is just aggravating glucose. Europe decided that’s it so they took that combo pill off the market (Figures 15 and 16). I’m sure you can still get immediate release niacin in Europe, but you know it’s a vitamin for God’s sakes, but a mega dose. I just don’t like people out there who want to extol niacin, fine, but don’t start telling niacin has a lot of data. It’s got zero data [i.e., data the FDA or Guidelines would recognize]. These are the same people who bash fibrates who do have two large randomized prospective trials, Helsinki and VA-HIT with fibrates and yet they never consider a fibrate. They always tell you, “Oh, niacin’s the better drug.” At least in the FIELD trial, fenofibrate had all these microvascular-, there’s no prayer niacin reduces diabetic retinopathy, amputations, kidney disease, but yet there was that battle.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-115.png)

**Figure 15. HPS-THRIVE and niacin.** HPS-THRIVE documented the downside to niacin use.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-116.png)

**Figure 16. HPS conclusions and warnings.**

Tom Dayspring: People bashed fibrates, hold them to the high standard of you’ve got to hit your primary endpoint and they never held niacin. To be honest with you, that’s what Ron Krauss did in that study. I understand what he’s talking about. There is some data if you want to extol it, but it’s not the type of data you and I use anymore.

## PCSK9 inhibitors [1:23:45]

Peter Attia: We’ll go from the step child to the poster child, which we’ve already kind of alluded to which are Repatha [i.e., evolocumab] and Praluent [i.e., alirocumab]. These two PCSK9 inhibitors and I’ll just give a little bit of background, obviously. What’s the name of the fellow up in Toronto who actually discovered this?

Tom Dayspring: I thought it was in Texas, Hobbs, Helen Hobbs, who’s the first person who discovered the PCSK9 expression ([Cohen et al., 2005](https://www.ncbi.nlm.nih.gov/pubmed/15654334)).

Peter Attia: Sorry, I mean the actual family of PCS, the PCS family.

Tom Dayspring: PCS. Look, there’s at least 10 members in the family and they’ve been around forever.

Peter Attia: I think because I grew up in Toronto I have fondness for remembering anything that anyone from Toronto did but we’ll figure it out in the show notes. I could be making all this up but I do think there’s a guy in Toronto who actually discovered this family of proteins, but you’re right.

Tom Dayspring: Helen Hobbs did the genetic evaluation ([Lambert et al., 2016](https://ohsu.pure.elsevier.com/en/publications/the-biology-of-pcsk9-inhibition-some-unanswered-questions)) and its gain of function, loss of function.

Peter Attia: And the gain of functions were discovered first, correct?

Tom Dayspring: Yeah ([Abifadel et al., 2003](https://www.ncbi.nlm.nih.gov/pubmed/12730697)).

Peter Attia: So, I’ll explain this really quickly and briefly, you can expand upon it. PCSK9 degrades LDL receptors so if you have a gain of function, you are more rapidly degrading LDL receptors on the liver, you’re going to have a decrease in your clearance of LDL, you will have higher LDL. These patients had very high events. In fact, these patients make up what? Five to ten percent of what we would diffusely refer to as familial high cholesterol.

Tom Dayspring: Correct. It’s one of the many.

Peter Attia: There’s like 2000.

Tom Dayspring: On one of your podcasts, people don’t understand FH could be a thousand different disorders.

Peter Attia: Yes. FH is a phenotype.

Tom Dayspring: And they’re not all autosomal dominant. Some are heterozygote disorders of various genes, but the phenotype is an LDL-cholesterol above a 190.

Peter Attia: And then you fast forward to about 2004, 2005 ([Cohen et al., 2005](https://www.ncbi.nlm.nih.gov/pubmed/15654334)), maybe it was 2006, but even I remember this. And again this was before I became a lipid wannabe. But I would still read the New England Journal of Medicine just because it’s sort of interesting. And there the discovery of the hypo-functioning PCSK9 folks. And I really do remember this and I’m surprised I remember it given that it wasn’t-

Tom Dayspring: Actually discovered in African Americans first. In, I believe, the Jackson trial.

Peter Attia: That’s exactly right.

Peter Attia: And these were folks who were walking around with an LDL-cholesterol between 10 and 30 milligrams per deciliter and they were completely event free. Not a 100 percent but significant reduction.

Peter Attia: Dramatic reduction. And the reductions I believe we actually went back and did a calculation to see if their reductions, how congruent they were with some of the more recent mendelian randomization. And they’re very similar, and it’s not surprising because that’s effectively how you would model a lifetime exposure reduction.

Peter Attia: The thing that interested me because I remember at the time like many people I’m sure, I sort have this concern which is, well, if your LDL was low that must mean you can’t make hormones, it must mean that you’re gonna get some other awful disease. And so the interesting thing to me was those people didn’t have any of those other phenotypes. They didn’t seem to have deficiencies, or deficits as a result of that. And of course I think that trial was what was the catalyst for Amgen, Sanofi and these other companies to start working on these drugs.

Tom Dayspring: Yes, and by the way they since studied in these people where they blown away LDL-cholesterol [to concentrations of] 10 in 15 there’s been zero effect on reproductive hormones or adrenal cortical hormones ([Blom et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/26228031)).

Tom Dayspring: Goes back to what I just told you, those glands synthesis all the cholesterol they need and they get it from HDLs. None of them are waiting for an LDL to show up with cholesterol to keep them functioning. So it’s all the nonsense you get when you go to a health food store or gym where the guy tells you, “You gotta raise your HDL cholesterol or something. You’re helping your testosterone level.”

Tom Dayspring: If you deplete testosterone, because, God forbid actually taking a statin, you’re screwing up your testicular function ([Stanworth et al., 2009](https://care.diabetesjournals.org/content/32/4/541)). You’re not.

Peter Attia: There doesn’t seem to be any evidence of that.

Tom Dayspring: So that put into perspective. So the genetic model is if you got an LDL cholesterol of 10 and 20 nothing’s gonna be wrong with you and you’re certainly going to have far less coronary heart disease. And when you talked about lost of function that means your LDL receptor half life is much longer.

Tom Dayspring: We didn’t get into it before we told you the liver makes LDL receptors. Theoretically any cell could. If your liver expresses an LDL receptor how long does it stay there for? Two, three days.

Tom Dayspring: And it grabs your apoB particle it brings it into an endosome but then the LDL receptor travels back to the surface, grabs another: those of you old enough if you used to watch the Addams Family on TV it’s like “Thing’s” hand coming out of a box. It’s the LDL receptor, grabs something and pulls it in, but Thing’s arm comes right back out again.

Tom Dayspring: But in some people that LDL receptor might be metabolized in the endosomes/lysosomes and then it can’t go back to the surface and PCSK9 is a major determinant of how quickly you recycle your LDL receptor or you do not recycle it.

Tom Dayspring: So by putzing with the expression of that enzyme we can give you much further expression [i.e., half-life] of your LDL receptor, and as you said enhance clearance of your apoB particles, including not only your LDLs which are 90 to 95 percent. But you’re clearing remnants also.

Tom Dayspring: So for those who believe or remnants are the bad guys, that’s not a reason not to use the PCSK9 it’ll get rid of them also ([Dadu and Ballantyne, 2014](https://www.nature.com/articles/nrcardio.2014.84); [Bays et al., 2017](https://www.ncbi.nlm.nih.gov/pubmed/28862926)).

## Cholesterol, statins, and the brain [1:30:00]

Peter Attia: Now we’re going to come back to this because I want to talk a little bit about the brain and you alluded to it earlier but I don’t want derail us now so I’m saying this just as much to remind me as to remind you.

Peter Attia: You can come up with multiple ways to lower LDL. And when I say LDL I’m talking the actual particle number. You can inhibit the synthesis of cholesterol which in turn also activates the clearance. Or you can just go directly after the clearance. So the former would be how a statin works, the later would be how a PCSK9 inhibitor works.

**[1:30:00]**

Tom Dayspring: Yeah, you can also make the evidence that if you’re depleting the cholesterol in the liver you’ll make a few less either LDL particles or VLDL precursors which would contribute to a lowering of apoB and that is a small part of both the MOA of ezetimibe and the statins, in fact most of it is clearance.

Tom Dayspring: But you are producing less particles too.

Peter Attia: But this is an area where I do probably have a slightly different view from the mainstream lipid world which is, there’s a favorable hypothesis which is the zero LDL hypothesis ([Masana et al., 2018](https://www.ncbi.nlm.nih.gov/pubmed/29398429)).

Tom Dayspring: Well you can’t make LDL zero.

Peter Attia: What they’re basically arguing is the lower you drive LDL the better. And I do take a little bit of issue with that because I think it depends how you lower it and it also it depends on what you define as better or worse. If you’re talking about lowering LDL reduces the risk of atherosclerosis, I think that’s pretty clear, but at some point my concern has always been if you lower LDL through cholesterol synthesis inhibition a lot, do you impact other organs? Namely the brain.

Tom Dayspring: Well you don’t know. Remember when you’re measuring whatever LDL metric, it’s what’s floating around your plasma, the only place I’ll make that’s irrelevant. You’re not measuring cellular cholesterol based on an LDL-cholesterol, so you tell me what your LDL cholesterol level is, I have really no clue are your cells synthesizing or not synthesizing, exporting, effluxing, or whatever to particles that carry cholesterol, but as I think as we indicated earlier in our talk today it is integral. Cells do have to make cholesterol so you certainly wouldn’t want to stop cholesterol synthesis in probably any cell in your body because the cell membranes if nothing else requires it.

Tom Dayspring: And we talked about the brain certainly it’s the only way it has cholesterol is it makes it. So if we did know we were inhibiting cholesterol synthesis in the brain would you be really that comfortable with that? And if you were is there certain limits where I wouldn’t mind reducing it a little bit but how much? Because that brain really needs it and the brain has no other source of cholesterol.

Peter Attia: Nowadays with the exception of patients who have been on a statin for a long period of time, when it comes to patients that are relatively new to statins, there are really only a handful we’re really looking at today. Lipitor [i.e., atorvastatin] and Crestor [i.e., rosuvastatin] are doing the lion’s share of the work. For some patients who are very sensitive we’ll use Livalo [i.e., pitavastatin] or we’ll use pravastatin but we’re not doing much in the way of simvastatin or any of these older drugs correct?

Tom Dayspring: No. If you’re following guidelines what you’re doing is prescribing high-potency statins or at least moderate intensity statins. So if you want to follow the guidelines the only choices you have are rosuvastatin or atorvastatin, Lipitor or Crestor at a 40 milligram or above those for atorva or a 20 milligram or above those for rosuva. If you’re stuck they would allow you to sneak simva 40 milligrams into there but that’s at best a moderate dose statin. 80 milligrams of simva have been taken off the market.

Peter Attia: Well the side effects are quite high with simva.

Tom Dayspring: Well simva because of a variety of pharmacokinetics reasons has a ton of drug-drug interactions. And we’re in a polypharmacy world where there is far less with a atorva and infinitely less with rosuvastatin and then the pitavastatin you mentioned, Livalo.

Tom Dayspring: But I would make the case that if you want the statin that has the most data then you’re gonna do good. It would be pravastatin, and pravastatin is very cheap. It’s almost free if you go to a drug store for it.

Peter Attia: It’s just not that potent right? Even at 80 milligrams.

Tom Dayspring: But if you use the outcome trials they got the exact same 25 percent reduction as any atorva or rosuva ever did. So again, Bristol used to explain it to magical mystery pleiotropic effects of pravastatin. But I would make the case that alright if apoB LDL is your goal-

Peter Attia: I would also argue though that patients are sicker today. I think patients are more metabolically ill today than they were. Meaning I think the Crestor trials have a higher bar to cross than the Prava but then again that’s just my bullshit speculation.

Tom Dayspring: Oh I think the lipid level enrollments with the West of Scotland [WOSCOPS] were twice as horrific as any rosuvastatin trial.

Peter Attia: They were, but they had FH. So these are patients who weren’t necessarily metabolically ill.

Tom Dayspring: I understand what you’re saying. So the end of this discussion because I got a lower apoB.

Tom Dayspring: Unless somebody is incredibly statin sensitive and there are ways of predicting statin responsiveness or hypo-responsiveness. If you want to just routinely pick for rosuvastatin go down that path, I’m all for you-

Peter Attia: So what do we know about CNS penetration of the statins?

Tom Dayspring: Well we’ll get to that and, look, I jumped on rosuvastatin bandwagon because being a giant pravastatin guy because it’s one of the what I would call hepato-selective statin. It’s hydrophilic, it goes right into the liver, it doesn’t need transporters. So you don’t need much of the drug to get in the liver and inhibit cholesterol synthesis and upregulate LDL receptors. So rosuvastatin 5 milligrams is all a lot of people need. You don’t need 40. They want to use 40 because in the trial that’s the dose they used where they got heart attack reduction but since it all comes back to apoB reduction, use whatever it takes to get your apoB down in my mind. That’s not how the guidelines exactly figure out how to do it. They like to give level one star rated evidence or so.

Tom Dayspring: Mine is a lesser degree of evidence. So you pick. So they get in, the other drugs are not as hydrophilic so the only way they get into the liver is various receptors pull them in. There’s a whole variety of transporters that pull molecules into the liver. But they’re subject to interference with a ton of other drugs that may be in your system or other molecules so you don’t have the clean pharmacokinetics like you do with pravastatin or rosuvastatin.

Tom Dayspring:That being said you’re talking and you want to introduce the brain into the discussion, now all statins can get into the brain, they can cross the blood brain barrier. But the statins that cross it much easier are the lipophilic statins because they have to pass a lipid membrane, the blood brain barrier.

Tom Dayspring: So atorvastatin and simvastatin get into the brain more easily than do lovastatin, simvastatin, atorvastatin.

Peter Attia: Wait say that again.

Tom Dayspring: The lipophilic statins is easier to cross the blood brain barrier and enter the CNS ([Shah et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1007%2Fs11883-014-0466-5)).

Peter Attia: Are the two biggest.

Tom Dayspring: And lovastatin would probably be the worst.

Peter Attia: Whereas pravastatin would be less.

Tom Dayspring: Pravastatin would be far less, as would rosuvastatin. You have that pharmacokinetics sort of a water soluble statin is probably more in the class of rosuva and pravastatin.

Peter Attia: And what about Livalo?

Tom Dayspring: Livalo would be the same. So yeah, non-lipophilic statin. So if you’re worried about statins getting into the brain you might want to chose the hydrophilic ones or so, but the only concern I might have is well if those statins are getting into the brain it’s great to [inhibit] those cholesterol synthesis in a liver I’m going to upgrade LDL receptors. I don’t know that I want to do it in every cell in the body but I’m probably not. I know I’m not with any of them totally inhibiting cellular synthesis of cholesterol.

Tom Dayspring: But the brain is way more dependent on cholesterol. And then we have studies of people with Alzheimer’s disease and other cognitive [issues], their brains [are] depleted of cholesterol to variable degrees.

Peter Attia: Now Tom I’m just gonna stop you right here because if I had dollar for every time I had a brutal argument with a cardiologist about this point. Because up until this point in the discussion if you’re a card carrying lipidologist or a cardiologist who really understands lipids you’re kinda on board. You’re in the camp of let’s lower LDL, but I do get patients from time to are more than at their LDL goal. Meaning their LDL-cholesterol is 40 milligrams per deciliter. Their LDL particle number is 500 nanomole per liter.

Peter Attia: These are people in primary prevention but let’s assume they have a calcium score of 800 or something. They’re very high risk. But I look at that I say well gosh their desmosterol is unmeasurable.

Tom Dayspring: Well you’re advancing the discussion here so let me continue down this pathway.

Tom Dayspring: So if cholesterol synthesis is so crucial for the brain, man I need a biomarker of brain cholesterol synthesis. Now very interesting we talked about two pathways of cholesterol synthesis one that desmosterol Bloch pathways, the other is the lathosterol the Kandutsch-Russell pathway.

Tom Dayspring: Well it turns out the Bloch pathway predominates in the brain. So should I do spinal taps and measure CSF desmosterol in these people?

Peter Attia: I’m gonna go with no.

Tom Dayspring: Yeah. It’d be a tough sell. “Oh by the way don’t leave I’m gonna come back and do a quick spinal tap on you today.”

Peter Attia: “Hey we’ll just wait there in the waiting room.”

Tom Dayspring: Or imagine even trying to do a clinical trial where that was what you’re trying to prove and enrolling people into that? Isn’t going to happen.

Tom Dayspring: So people know we can measure desmosterol in the blood and there’s lots of articles correlating that with cholesterol synthesis as there is with lathosterol.

Tom Dayspring: And you can make the case in peripheral cells, maybe even a lathosterol is a more dominant pathway. They’re probably both at play, but also the desmosterol is much more important in younger, newborns and youth, rather than older people.

Peter Attia: I didn’t know that.

Tom Dayspring: Yeah. So maybe that’s a critical patient, if for whatever reason want to give a statin to a really young FH patient.

Peter Attia: Well I’ve been involved in one of those cases.

**[1:40:00]**

Tom Dayspring: So here’s what we know, when people with these mild cognitive impairments or various dementia have low [tissue] cholesterol when you wind up autopsying their brains, they do have low desmosterol in their cerebral spinal fluid ([Sato et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3276481/); [Wisniewski et al., 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3557460/)). Suggesting that part of their impairment or cholesterol depletion in the brain is their brain isn’t synthesizing as much cholesterol and in a nice trial where they’ve done this: they did do spinal taps on the people in the trial, measured CSF desmosterol and the measured serum desmosterol (Figure 17).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-117.png)

**Figure 17. Plasma desmosterol levels in controls, mild cognitive impairment (MCI), and Alzheimer’s disease (AD) patients.** Study linking reduced desmosterol (a marker related to cholesterol synthesis) in patients with mild cognitive impairment and Alzheimer’s disease. These patients were not on statins.

Peter Attia: What was the correlation?

Tom Dayspring: Identical. So it [i.e., the correlation] was very high in there. So now all of a sudden a serum desmosterol level becomes a biomarker of brain synthesis of cholesterol.

Tom Dayspring: And there are what is by far, it’s not even close, the biggest reason that a brain has suppressed desmosterol cholesterol synthesis. It’s statin use.

Tom Dayspring: So I would make the case-

Peter Attia: Hang on I’m gonna pause here because I know what you’re gonna say and I agree but I’m gonna give you the counterpoint before you even start so you can color your commentary.

Peter Attia: The heterogeneous population based data, say statins reduce Alzheimer’s disease.

Tom Dayspring: Nothing serious suggests that. I mean yeah you want to start looking at-

Peter Attia: Which is not to say that the trials are using that as an outcome, it’s just that we’re not seeing an increase in Alzheimer’s disease in the statin trials.

Tom Dayspring: Dementia is a multifactorial disease. There’s a lot of things that contribute to dementia. So in general do the vast majority of people take statins wind up demented? No absolutely not, not any evidence that is shown that at least from the cumulative statin trials or so, but are there certain individuals where that is?

Tom Dayspring: And by the way in these trials where they measure low both serum and CSF desmosterol guess what there was a significant increase incidence of? Alzheimer’s disease, and mild cognitive impairment. So yes this is all at the hypothesis level, it’s looking at a biomarker not clinical end point trials but that’s enough evidence to me to say if I’m going to give you a statin, for a variety of reasons, I’d much rather give you a baby [i.e., low-dose] statin. Plus ezetimibe and by the way, baby statin plus ezetimibe gives you the exact same apoB reduction as does the gorilla [i.e., high-dose, high-potency] statin, the megadose of it, but I think with a lot of other additional benefits the ezetimibe brings and certainly less potential side effects, and certainly less cholesterol synthesis suppression including the brain.

Tom Dayspring: So if I were giving you massive doses of your favorite gorilla statin per guidelines and I simply measured serum desmosterol on your next visit, and it was low that tells me I’ve stopped the synthesis of cholesterol too much.

Peter Attia: So Tom, you are the only other person in this space who will entertain this discussion with me. I mean I just can’t tell you how many times I get into debates with other lipid folks who say that is complete and utter nonsense, and they point the absence of a huge upsurge in Alzheimer’s disease in the statin trials. To which I say the following, one I am sympathetic to what you are saying because I realize that all of the anti-statin rhetoric out there is so illogical and they throw everything in the sink, like oh my God it causes diabetes. Well does it? Yeah in a small small subset of the population we’re going to see a slight uptick in the risk of diabetes especially with atorvastatin. Does that mean statins cause diabetes and it needs to be avoided as a result of that? No.

Tom Dayspring: Of course not.

Peter Attia: Do a subset of patients end up getting muscular pain? Of course, it’s probably 5 to 10 percent. It might even be a bit higher depending on the nature of the trial, but what I think is really going on here, this is my hypothesis. Alzheimer’s disease as you said a second ago is multiple diseases. It is not a disease.

Tom Dayspring: We’re talking cognition here.

Peter Attia: But even if you talk about Alzheimer’s disease, even if there’s a final common pathway or a set of pathognomonic features that define the disease, I think there are several ways to get there. There is a metabolic way that people get there that is probably explained by the increase incidence we see in cognitive impairment and Alzheimer’s disease in patients with diabetes and insulin resistance.

Peter Attia: But there’s also a vascular component that I don’t think gets nearly enough attention. There’s a guy named [Jack de la Torre](https://liberalarts.utexas.edu/psychology/faculty/jcd2658), I reached out to him recently to interview him for my book, and he’s on a research sabbatical in Spain for two years, so I’ll probably interview him by telephone, but I would like to eventually have him on the podcast. But he’s done some of the most impressive work at looking at this sort of vascular hypothesis of Alzheimer’s disease.

Peter Attia: My hypothesis is this. On average, you take a group of patients with terrible dyslipidemia, you give them a statin, you improve their vascular complications which include atherosclerosis, and you’re probably actually reducing Alzheimer’s disease in those patients. In other words all things coming are you better at being in the 90th percentile or the 10th percentile of apoB with respect to Alzheimer’s disease? You’re better off being in the 10th percentile.

Peter Attia: However I think to your point, there’s going to be a subset of patients in which you go too far. These are patients who don’t synthesis a boatload of cholesterol. They’re probably hypo-synthesizers to begin with and you “statinize” the hell out of them and you’re increasing their susceptibility.

Peter Attia: Now again, the problem with everything I just said is it takes more than a tweet.

Tom Dayspring: Yeah. And for anybody who throws it in your face, there’s no evidence of that in any statin trials, say “Oh my God, I’ve read the FDA package insert of every single statin that’s on the market and cognitive impairment is listed as a potential side effect of every single statin. Did the FDA just make that up? No. It’s been seen in clinical trials.” [Figure 20]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-118.png)

**Figure 20. NLA Statin Safety Report: statins and neurologic disease.**

Peter Attia: Did the FDA make this link? Because I’m talking about papers. There are actually papers that show and we will absolutely link to this ([Sato et al., 2012](https://www.ncbi.nlm.nih.gov/pubmed/22203775)) because I think this is one of the better papers. It’s about six years old, but it looks at desmosterol as a continuous variable. So in the same way you might look at PSA as a continuous variable it can be anything, and try to decide the question, at what cut off does having a high PSA suggest that you have a high enough risk of prostate cancer. But using desmosterol as a continuous variable and using the statistical technique called receiver operating characteristic curve production. They showed that once desmosterol fell below 0.5, the AUC, the area under the curve of the receiver operating characteristic was somewhere between .8 and .87 depending on the study and depending on gender.

Peter Attia: And again, maybe it’s more detailed than people want but the higher that number which varies basically between .5 and 1. One is a perfect study. There’s no such things as a diagnostic test with a 1. Zero-point-five is a coin toss. When you get into the .8 territory that’s a very powerful predictor.

Tom Dayspring: Correct. And so I think it’s careless to dismiss that as potential player, we’ve given you a lot of plausibility and there’s even more.

Tom Dayspring: If you tell me you are a doctor who has prescribed a lot of statins, and look I was in practice 37 years, 20 of which I was writing as much statins as anybody. If you tell me you’ve never seen cognitive impairment in a patient you start on a statin, you’re a liar, or you’re a fool, or you’re not questioning your patients when they come back because it does occur.

Tom Dayspring: I don’t know a lot of reasons it could occur. And looks who doesn’t have a day where you wake up thinking I’m a little foggy today for some [reason].

Tom Dayspring: So we’ve now got a plausible explanation why it happens. If the real reason you’re prescribing a statin is apoB reductions, I got a lot of ways of getting your apoB to go without maximizing a statin.

Tom Dayspring: So in my mind if desmosterol is below a certain population percentile cut point, I’ve inhibited cholesterol synthesis probably, I probably get no bang for the buck on further LDL or particle lowering, apoB lowering by having you continue to take that. I clear apoB further by stopping cholesterol absorption back into the liver and the intestines with an ezetimibe that does nothing to [inhibiting] cholesterol synthesis. A PCSK9 inhibitor. And in most people baby statin and ezetimibe will give you the exact same apoB reduction of your gorilla statin and we have CV outcome evidence in the improvement trial that ezetimibe and statin for the guys “I gotta see outcome data.” You got it.

Tom Dayspring: Therefore I use it as a tool to monitor statin therapy on most people. And also these people would argue, I will bet as much money as I have in my bank account they’ve never they couldn’t even tell you what desmosterol is, they’ve never read anything about the cholesterol synthetic pathway and they don’t know what they’re talking about.

Peter Attia: In the end I think this is such a contentious topic because we’re getting so nuanced on something now and the world has lost its appetite for nuance. People want to know, statins are good? Or statins are bad. And everything we’ve just said says, it depends. Right?

Peter Attia: It depends on how you use them. You can give too much of these things. That doesn’t mean they’re bad. Because what we’ve also done, and I realize and I’ve been very deliberate about this because I think it’s important to show both sides of this, we’ve also given the statin deniers and the statins conspiracy theorist a great ammo, which is “A-ha, if Dayspring and Attia are sitting there bashing statins and talking about mild cognitive impairment.” And they take that discussion out of context they’re going to say, “Well statins should be outlawed.”

**[1:50:00]**

Tom Dayspring: Yeah but of course any reasonable doctor if a patient came in complaining of statin or cognitive impairment, they pretty much stop all drugs because that’s the first explanation [i.e., suspicion]. A drug is causing it. So it’s not like I’d continue to force you to take the statin if you were cognitively impaired ([Rojas-Fernandez et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacl.2014.02.013)).

Peter Attia: I mean if the listener is sort of saying what the hell is the takeaway from this? I think it’s a couple things. One is statins are not bad. Statins are still the mainstay backbone of anti-lipid therapy. Be thoughtful about which ones you use. Tom I have moved more to Crestor over Lipitor though I still use Lipitor quite a bit. And in many ways I’m sort of slowly migrating patients who seem to have now difficulty from Lipitor to Crestor.

## Elevated creatine kinase (CK) and liver function tests (LFTs) on statins [1:50:30]

Peter Attia: Two, I’m actually going back and using pravastatin much more than I used to. I’m surprised at how much I find myself reaching for pravastatin in a patient who has a slight CK bump, even they’re not complaining of pain. If they’re getting a CK bump, their CK goes from a baseline of 50 to 300, even if they’re asymptomatic I don’t like it so I’m going to switch.

Tom Dayspring: By the way I would chip in, that CK elevation has nothing to do with statin toxicity or- silly biomarker to follow.

Peter Attia: You think so?

Tom Dayspring: Totally. And evidence would totally support that ([Rosenson, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24793443)).

Peter Attia: Well I know it doesn’t correlate that wel.

Tom Dayspring: Not at all. First of all before you ever do that make sure you have a baseline CK because a lot of people especially African Americans, not even working out they just have high CK levels African Americans.

Peter Attia: I didn’t realize that.

Tom Dayspring: You know when you should stop a statin [in an asymptomatic patient]? When there’s [a large elevation] of CK. Then you might start to worry. So there’s any number of guidelines issued on statins, it’s not a biomarker that is of any use to you. And all you do by doing CK is when somebody goes from 50 to 300 they get the bejesus scared out them and they stop their statin when there’s no reason. [Figure 18]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-119.png)

**Figure 18. NLA Statin Safety Report.** No need to follow hepatic aminase in patients using statins and no need to stop them even with a tripling of aminase levels.

Tom Dayspring: The reason you should stop a statin is if they’re having myopathic symptoms, aches or weakness. Then I don’t care what they’re CK levels is.

Peter Attia: I did not realize that.

Tom Dayspring: And I’ll get some info to you on that.

Peter Attia: Please.

Tom Dayspring: So stop monitoring CK and if they come in and tell you, “Peter, I’m feeling pain.” Or you somehow are doing some muscular strength test thing or they tell you I don’t get out of the chair as much. Possibly a muscle weakness. Stop the darn statin.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-120.png)

**Figure 19. NLA Statin Safety Report.** No need to monitor CK levels in patients using statins. A baseline level may be useful.

Peter Attia: Well those are the easy cases.

Tom Dayspring: Yeah but don’t use CKs to dictate your statin therapy.

Peter Attia: Yeah. Again I think the point here, I can’t imagine giving any lipid lowering therapy without being able to measure phytosterol, stanols and desmosterol.

Tom Dayspring: So I’m with you there. Most lipidologist would not be but hey just have not studied the data like they should.

Tom Dayspring: And even if what we’re talking about is pure hypothesis what harm would you be doing by lessening the dose of a statin and substituting a little ezetimibe? Or if they could afford it, you could make the case if it was free as pravastatin, let’s just use PCSK9 inhibitors for God sakes because whatever other minor side effects of statins, I don’t think we’ve seen much with PCSK9.

Peter Attia: The skeptic will counter that Tom and say, “But we only have three and a half years of data with these drugs.”

Tom Dayspring: So right now we’re not gonna use that except for people who can afford it or are nightmare patients where a third partner will finally pay for it or so. So it’s not like docs are gonna run out tomorrow and start injecting everybody with a PCSK9 inhibitor, they’re not because there’s handcuffs on them. But there’s no handcuffs on you using generic ezetimibe to a baby statin.

Tom Dayspring: You have to buy on to LDL-C is not your best surrogate of atherogenic lipoproteins. apoB or LDL particle (LDL-P) is and if that’s your real goal of therapy then you got a lot of options available to you.

Peter Attia: Now the one thing I used to use the combo lowest dose statin possible coupled with ezetimibe if there was some evidence of even mild elevation of phytosterol and stanol. One thing I’ve noticed and again I’ve been a little delinquent. I don’t think I’ve gone back and looked at the trials. Did the trials show an increase in transaminases with that combo?

Tom Dayspring: No. You’d have to look back at SEAS where they use the simvastatin and ezetimibe and IMPROVE-IT, yeah.

Peter Attia: I don’t know what it is. I keep seeing these ASTs double.

Tom Dayspring: Again I will tell you there’s not a package insert in the world that tells you, you should even be following aminase levels to judge statins at anything going on in the liver as a result of the statin. There’s no correlation whatsoever ([Bays et al., 2014](https://www.sciencedirect.com/science/article/pii/S1933287414000737); [Calderon et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/20360293)).

Tom Dayspring: So I think I’m repeating them all the time because maybe it’s a biomarker of fatty liver or something else but not a statin toxicity. It’s not. So don’t ever let a patient stop being because they’ve doubled their AST, ALT, GGT, you’re measuring level on the statin not related to anything.

Tom Dayspring: And you got great medical legal safety because that’s what the guidelines are telling you to do. There’s not a statin in the world that they’re [i.e., the warnings to routinely monitor] all out of the package insert that you should be following liver function tests.

Peter Attia: Yeah, again, I think part of the problem is like you, I’m going to follow liver function test regardless. I have a very different view of how these things should be.

Tom Dayspring: It’s part of your chemistry profile that you’re probably doing on every patient every time so you’re gonna see them, but be prepared when the patient calls you up in a panic that’s not in your differential diagnosis of why the aminases are changing.

Peter Attia: I don’t know, Tom.

Tom Dayspring: It’s been looked extensively Peter.

Peter Attia: I’m gonna go back and look at this.

Tom Dayspring: I’ll send you entire documents where they’ve analyzed all the data in the world on the liver and statin therapy. It’s inconsequential ([Bader, 2010](https://www.ncbi.nlm.nih.gov/pubmed/20445507)) (Figure 18).

![](images/tomdayspring4/null-119.png)

**Figure 18. NLA Statin Safety Report.** No need to follow hepatic aminase in patients using statins and no need to stop them even with a tripling of aminase levels.

Peter Attia: But I’ll give you a silly example which is, I have seen the following at least four times. You take a patient, they’re on a statin, there’s no other change, and the only thing you do is you add Zetia and then their next blood test their transaminases have doubled. And then the only thing you do is stop the Zetia and it returns to baseline.

Tom Dayspring: Alright. So something is happening, but is a doubling of transaminases of any concern to you?

Tom Dayspring: So fine if you want to stop it and see, go ahead, and if that’s gonna occasionally limit how much ezetimibe you’re gonna use in a patient, okay, figure out how else to lower apoB.

Tom Dayspring: So fine, I understand there are things that’ll come into play in an individual patient.

Tom Dayspring: But the data doesn’t support it.

Peter Attia: That’s my point.

Tom Dayspring: But you’re making an individual decision.

Peter Attia: That’s my point. You’ve got to be able to make an individual decision.

Tom Dayspring: Just don’t generalize.

Peter Attia: Which is what we’re saying with the desmosterol level. Again I think most patients, again if someone’s listening to this and they’re freaking out because they’re like what the hell are these guys talking about, we are not saying that statins are causing dementia, what I’m saying, I’ll let Tom clarify for himself, there are going to be a subset of patients who’s risk of dementia does go up with a statin, and it’s our job if we’re prescribing those drugs to know exactly who those patients are.

Peter Attia: And to the best of my reading of the literature plus understanding the nature of the biology, it’s probably the patients in whom we overly suppress synthesis for whom they don’t make that much to begin with.

Tom Dayspring: And suppress cellular synthesis which has nothing to do with the amount of cholesterol you measure in the blood.

Peter Attia: Great point.

Tom Dayspring: Cholesterol synthesis is not affected, per se, by PCSK9 inhibitors. Ezetimibe is interesting. If you go with an ezetimibe monotherapy, you’ll actually get a little reflex increase in cholesterol synthesis and vice versa. If you go with statin monotherapy, you’ll hyperabsorb cholesterol.

Peter: Vice versa with the statin.

Tom Dayspring: There’s a little bit of physiologic homeostasis going on here, too.

Tom: But that’s not changing levels to these toxic levels.

Peter Attia: One of the times when I like using Zetia, is if I’ve got a patient who really needs a statin, because when you just look at their numbers you get this sense that this is an LDL clearance deficiency, but you want to boost their synthesis a little bit. You do it concomitant with the Zetia and you’ll sometimes get that reflex.

Tom Dayspring: And I argue with clinicians, too, who are doing sterol testings. Tom, I identify my hyperabsorbers, and I surely make sure ezetimibe is onboard my apoB lowering therapy in that patient. But I will make the case for you, even if you do those markers, and you’re a normal absorber of cholesterol, but you have an apoB problem. Even by taking a normal absorber of cholesterol and making them a hypo absorber, the genetic model is they live longer if they have genetic loss of function of NPC1L1 protein. Even in a patient who’s not hyperabsorbing cholesterol, you do get additional apoB lowering. Maybe not at the same magnitude, but you get it. And you’re changing them into their genetic model of longevity, maybe. You’re certainly keeping phytosterols out of them.

§

§

## Selected Links / Related Material

**The LRC**: [The Lipid Research Clinics Coronary Primary Prevention Trial results. I. Reduction in incidence of coronary heart disease](https://www.ncbi.nlm.nih.gov/pubmed/6361299) (JAMA, 1984) [3:45]

**The 4S trial**: [Randomised trial of cholesterol lowering in 4444 patients with coronary heart disease: the Scandinavian Simvastatin Survival Study](https://www.ncbi.nlm.nih.gov/pubmed/7968073) (4S) (4S, 1994) [6:00]

**WOSCOPS study (men with FH, primary prevention)**: [Prevention of coronary heart disease with pravastatin in men with hypercholesterolemia. West of Scotland Coronary Prevention Study Group](https://www.ncbi.nlm.nih.gov/pubmed/7566020) (Shepherd et al., 1995) [6:30]

**WOSCOPS**: [Long-Term Safety and Efficacy of Lowering Low-Density Lipoprotein Cholesterol With Statin Therapy: 20-Year Follow-Up of West of Scotland Coronary Prevention Study](https://www.ncbi.nlm.nih.gov/pubmed/26864092) (Ford et al., 2016) [7:15]

**Pathology textbook**: [Atlas of Atherosclerosis Progression and Regression](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?ie=UTF8&qid=1526578233&sr=8-1&keywords=stary+atherosclerosis) by Herbert C. Stary [8:00]

**Triparanol**: [MER-29 (Triparanol) in the Control of Hypercholesterolæmia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1896661/) (Jepson, 1962) [10:00]

**Triparanol**: [Coronary atherosclerosis status of MER-29](https://www.semanticscholar.org/paper/Coronary-atherosclerosis-status-of-MER-29-Corcoran/7ebe345787927614bba403c2e0522558bf6dc392) (triparanol) (Corcoran, 1961) [10:45]

**Triparanol**: [The MER/29 Story–An Instance of Successful Mass Disaster Litigatio](https://scholarship.law.berkeley.edu/cgi/viewcontent.cgi?referer=https://www.google.com/&httpsredir=1&article=2831&context=californialawreview)n (Rheingold, 1968) [10:45]

**Rosuvastatin (membrane transporters that make some (the hydrophilic) statins more hepato-selective at lower doses)**: [Drug safety evaluation of rosuvastatin](https://www.ncbi.nlm.nih.gov/pubmed/21999163) (Toth and Dayspring, 2011) [12:15]

**Discovery of the LDL receptor**: [Receptor-mediated control of cholesterol metabolism](https://www.jstor.org/stable/1742011?origin=JSTOR-pdf&seq=1#page_scan_tab_contents) (Brown and Goldstein, 1976) [14:15]

**Cholesterol transport pathways and ezetimibe**: [Ezetimibe therapy: mechanism of action and clinical update](https://www.dovepress.com/ezetimibe-therapy-mechanism-of-action-and-clinical-update-peer-reviewed-article-VHRM) (Phan et al., 2012) [15:45]

**Chapter on phytosterolemia Tom wrote**: [Therapeutic Lipidology](https://www.amazon.com/Therapeutic-Lipidology-Contemporary-Cardiology-Davidson/dp/1588295516) edited by several authors [20:00]

**Article on ezetimibe Dayspring and Toth collaborated** **on**: [Ezetimibe therapy: mechanism of action and clinical update](https://pubmed.ncbi.nlm.nih.gov/22910633/) (Phan et al., 2012) [20:00]

**Raloxifene**: [Effects of raloxifene on cardiovascular events and breast cancer in postmenopausal women](https://www.ncbi.nlm.nih.gov/pubmed/16837676) (Barrett-Connor et al., 2006) [24:15]

**Raloxifene**: [Effects of the Selective Estrogen Receptor Modulator Raloxifene on Coronary Outcomes in The Raloxifene Use for the Heart Trial](https://www.ahajournals.org/doi/abs/10.1161/circulationaha.108.817577) (Collins et al., 2009) [24:15]

**SEAS trial**: [Intensive lipid lowering with simvastatin and ezetimibe in aortic stenosis](https://www.ncbi.nlm.nih.gov/pubmed/18765433) (Rossebø et al., 2008) [26:00]

**SHARP trial**: [The effects of lowering LDL cholesterol with simvastatin plus ezetimibe in patients with chronic kidney disease (Study of Heart and Renal Protection): a randomised placebo-controlled trial](https://www.ncbi.nlm.nih.gov/pubmed/21663949) (Baigent et al., 2011) [27:00]

**FOURIER trial**: [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pubmed/28304224) (Sabatine et al., 2017) [28:30]

**VA-HIT**: [Gemfibrozil for the secondary prevention of coronary heart disease in men with low levels of high-density lipoprotein cholesterol. Veterans Affairs High-Density Lipoprotein Cholesterol Intervention Trial Study Group](https://www.ncbi.nlm.nih.gov/pubmed/10438259) (Rubins et al., 1999) [42:00]

**Helsinki Heart Study (HHS)**: [Helsinki Heart Study: primary-prevention trial with gemfibrozil in middle-aged men with dyslipidemia. Safety of treatment, changes in risk factors, and incidence of coronary heart disease](https://www.ncbi.nlm.nih.gov/pubmed/3313041) (Frick et al., 1987) [42:45]

**ACCORD**: [Effects of combination lipid therapy in type 2 diabetes mellitus](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1056%2FNEJMoa1001282) (Ginsberg et al., 2010) [42:45]

**Fibrates in metabolic syndrome and diabetes**: [Fibrate therapy in patients with metabolic syndrome and diabetes mellitus](https://link.springer.com/article/10.1007/s11883-006-0032-x) (Dayspring and Pokrywka, 2006) [52:45]

**Ezetimibe and fatty liver**: [868 EFFICACY OF EZETIMIBE FOR THE TREATMENT OF NON-ALCOHOLIC FATTY LIVER DISEASE: A RANDOMIZED, CONTROLLED TRIAL](https://www.journal-of-hepatology.eu/article/S0168-8278(11)60870-2/abstract) (Takeshita et al., 2011) [54:00]

**NAFLD**: [A lipidomic analysis of nonalcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pubmed/17654743) (Puri et al., 2007) [54:00]

**NASH**: [Intrahepatic cholesterol influences progression, inhibition and reversal of non-alcoholic steatohepatitis in hyperlipidemic mice](https://www.ncbi.nlm.nih.gov/pubmed/20114046) (Wouters et al., 2010) [54:00]

**T2D & NASH**: [Hepatic free cholesterol accumulates in obese, diabetic mice and causes nonalcoholic steatohepatitis](https://www.ncbi.nlm.nih.gov/pubmed/21703998) (Van Rooyen et al., 2011) [54:00]

**Fibrates in ACCORD**: [Role of fibrates in cardiovascular disease prevention, the ACCORD-Lipid perspective](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6067007/) (Elam et al., 2011) [57:30]

**Fibrates, renal, FIELD**: [Effects of fenofibrate on renal function in patients with type 2 diabetes mellitus: the Fenofibrate Intervention and Event Lowering in Diabetes (FIELD) Study](https://link.springer.com/article/10.1007/s00125-010-1951-1) (Davis et al., 2011) [57:45]

**Fibrates, renal, ACCORD**: [Fenofibrate-associated changes in renal function and relationship to clinical outcomes among individuals with type 2 diabetes: the Action to Control Cardiovascular Risk in Diabetes (ACCORD) experience](https://www.ncbi.nlm.nih.gov/pubmed/22450889) (Bonds et al., 2012) [57:45]

**Fibrates, microvascular, FIELD & ACCORD**: [Non-invited Review: Prevention of microvascular diabetic complications by fenofibrate: lessons from FIELD and ACCORD](https://journals.sagepub.com/doi/abs/10.1177/1479164111407783) (Hermans, 2011) [57:45]

**Fibrates, retinopathy, FIELD**: [Effect of fenofibrate on the need for laser treatment for diabetic retinopathy (FIELD study): a randomised controlled trial](https://www.ncbi.nlm.nih.gov/pubmed/17988728) (Keech et al., 2007) [57:45]

**Fibrates, retinopathy, ACCORD**: [Diabetic Retinopathy, Its Progression, and Incident Cardiovascular Events in the ACCORD Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3631868/) (Gerstein et al., 2013) [57:45]

**Fibrates, amputations, FIELD**: [Effect of fenofibrate on amputation events in people with type 2 diabetes mellitus (FIELD study): a prespecified analysis of a randomised controlled trial](https://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(09)60698-X.pdf) (Rajamani et al., 2009) [57:45]

**Fibrates, uric acid and gout, FIELD**: [Effect of fenofibrate on uric acid and gout in type 2 diabetes: a post-hoc analysis of the randomised, controlled FIELD study](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(18)30029-9/fulltext) (Waldman et al., 2018) [57:45]

**Fibrates and VLDL effects**: [VLDL effects Long-term effects of fenofibrate on VLDL and HDL subspecies in participants with type 2 diabetes mellitus](https://link.springer.com/article/10.1007/s00125-007-0751-8) (Hiukka et al., 2007) [1:05:00]

**Podcast with Ron Krauss**: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia (peterattiamd.com) [1:08:00]

**CLAS, Niacin + colestipol (a bile acid sequestrant) improved arteriograms**: [Beneficial Effects of Combined Colestipol-Niacin Therapy on Coronary Atherosclerosis and Coronary Venous Bypass Grafts](https://jamanetwork.com/journals/jama/article-abstract/366621) (Blankenhorn et al., 1987) [1:05:00]

**FATS**: [Regression of coronary artery disease as a result of intensive lipid-lowering therapy in men with high levels of apolipoprotein B](https://www.ncbi.nlm.nih.gov/pubmed/2215615) (Brown et al., 1990) [1:13:45]

**HATS**: [Simvastatin and niacin, antioxidant vitamins, or the combination for the prevention of coronary disease](https://www.ncbi.nlm.nih.gov/pubmed/11757504) (Brown et al., 2001) [1:13:45]

**AIM-HIGH**: [Niacin in patients with low HDL cholesterol levels receiving intensive statin therapy](https://www.ncbi.nlm.nih.gov/pubmed/22085343) (Boden et al., 2011) [1:16:45]

**HPS2-THRIVE**: [Effects of Extended-Release Niacin with Laropiprant in High-Risk Patients](https://www.nejm.org/doi/full/10.1056/NEJMoa1300955) (NEJM, 2014) [1:22:00]

**HPS2-THRIVE, toxicity**: [HPS2-THRIVE randomized placebo-controlled trial in 25 673 high-risk patients of ER niacin/laropiprant: trial design, pre-specified muscle and liver outcomes, and reasons for stopping study treatment](https://academic.oup.com/eurheartj/article/34/17/1279/444301) (Eur Heart J, 2013) [1:22:30]

**Discovery of PCSK9 expression**: [Low LDL cholesterol in individuals of African descent resulting from frequent nonsense mutations in PCSK9](https://www.ncbi.nlm.nih.gov/pubmed/15654334) (Cohen et al., 2005) [1:24:00]

**Biology of PCSK9 inhibition**: [The biology of PCSK9 inhibition: Some unanswered questions](https://ohsu.pure.elsevier.com/en/publications/the-biology-of-pcsk9-inhibition-some-unanswered-questions) (Lambert et al., 2016) [1:24:30]

**Gain of functions of PCSK9 discovered**: [Mutations in PCSK9 cause autosomal dominant hypercholesterolemia](https://www.ncbi.nlm.nih.gov/pubmed/12730697) (Abifadel et al., 2003) [1:24:30]

**PCSK9 inhibitors**: [Effects of Evolocumab on Vitamin E and Steroid Hormone Levels: Results From the 52-Week, Phase 3, Double-Blind, Randomized, Placebo-Controlled DESCARTES Study](https://www.ncbi.nlm.nih.gov/pubmed/26228031) (Blom et al., 2015) [1:27:15]

**Statins and testosterone**: [Statin Therapy Is Associated With Lower Total but Not Bioavailable or Free Testosterone in Men With Type 2 Diabetes](https://care.diabetesjournals.org/content/32/4/541) (Stanworth et al., 2009). [1:27:45]

**Review of PCSK9 inhibitors**: [Lipid lowering with PCSK9 inhibitors](https://www.nature.com/articles/nrcardio.2014.84) (Dadu and Ballantyne, 2014) [1:29:30]

**Review of PCSK9 inhibitors**: [Alirocumab Treatment and Achievement of Non-High-Density Lipoprotein Cholesterol and Apolipoprotein B Goals in Patients With Hypercholesterolemia: Pooled Results From 10 Phase 3 ODYSSEY Trials](https://www.ncbi.nlm.nih.gov/pubmed/28862926) (Bays et al., 2017) [1:29:30]

**Zero-LDL hypothesis**: [Clinical and pathophysiological evidence supporting the safety of extremely low LDL levels-The zero-LDL hypothesis](https://www.ncbi.nlm.nih.gov/pubmed/29398429) (Masana et al., 2018) [1:30:15]

**Alzheimer’s and desmosterol**: [Identification of a new plasma biomarker of Alzheimer’s disease using metabolomics technology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3276481/) (Sato et al., 2012) [1:36:30, 1:40:15]

**Effects of different statins on cognitive function**: [Impact on cognitive function-are all statins the same?](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1007%2Fs11883-014-0466-5) (Shah et al., 2015) [1:36:30]

**Alzheimer’s and desmosterol**: [Alzheimer’s Disease: Brain Desmosterol Levels](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3557460/) (Wisniewski et al., 2013) [1:40:15]

**Statins and cognition**: [An assessment by the Statin Cognitive Safety Task Force: 2014 update](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacl.2014.02.013) (Rojas-Fernandez et al., 2014) [1:50:00]

**Muscle safety and statins**: [An assessment by the Statin Muscle Safety Task Force: 2014 update](https://www.ncbi.nlm.nih.gov/pubmed/24793443) (Rosenson, 2014). [1:51:00]

**Statins and liver**: [An assessment by the Statin Liver Safety Task Force: 2014 update](https://www.ncbi.nlm.nih.gov/pubmed/20360293) (Bays et al., 2014) [1:54:15]

**Statins and liver enzymes**: [Statins in the treatment of dyslipidemia in the presence of elevated liver aminotransferase levels: a therapeutic dilemma](https://www.ncbi.nlm.nih.gov/pubmed/20360293) (Calderon et al., 2010) [1:54:15]

**Statins and liver**: [The myth of statin-induced hepatotoxicity](https://www.ncbi.nlm.nih.gov/pubmed/20445507) (Bader, 2010) [1:55:30]

§

## People Mentioned

- [Akira Endo](https://en.wikipedia.org/wiki/Akira_Endo_(biochemist)) (biochemist) [4:00]
- [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss) (one of Peter’s lipid mentors) [7:30]
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman) (one of Peter’s lipid mentors) [7:30]
- [Michael Brown](https://en.wikipedia.org/wiki/Michael_Stuart_Brown) (cholesterol Nobel Laureate) [14:15]
- [Joseph Goldstein](https://en.wikipedia.org/wiki/Joseph_L._Goldstein) (cholesterol Nobel Laureate) [14:15]
- [Peter Toth](https://www.cardiometabolichealth.org/peter-toth.html) (wrote an [article](https://pubmed.ncbi.nlm.nih.gov/22910633/) with Tom) [20:00]
- [Michael Davidson](https://www.lipid.org/about) [20:30]
- [Kevin Maki](https://www.mbclinicalresearch.com/about-us.html) (clinical investigator) [20:30]
- [Jim Otvos](https://en.wikipedia.org/wiki/Jim_Otvos) (NMR) [45:45]
- [Dan Rader](https://www.med.upenn.edu/apps/faculty/index.php/g5165284/p17778) (HDL) [48:00]
- [Helen Hobbs](https://utswmed.org/doctors/helen-hobbs/) (loss of function PCSK9 discovery) [1:24:00]
- [Jack de la Torre](https://liberalarts.utexas.edu/psychology/faculty/jcd2658) (Alzheimer’s as a vascular disease) [1:44:30]

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring-300x300.jpg)

##### Thomas Dayspring, M.D., FACP, FNLA

Thomas Dayspring, MD, FACP, FNLA is the chief academic officer for True Health Diagnostics, LLC. He provides scientific leadership and direction for the company’s comprehensive educational programs. Dr. Dayspring is a fellow of both the American College of Physicians and the National Lipid Association. He is certified in internal medicine and clinical lipidology.

Before relocating to Virginia in 2012, Dr. Dayspring practiced medicine in New Jersey for 37 years. Over the last two decades, he has given over 4,000 domestic and international lectures, including over 600 CME programs on topics such as atherothrombosis, lipoprotein and vascular biology, biomarker testing, and women’s cardiovascular issues.

Dr Dayspring is an Associate Editor of the Journal of Clinical Lipidology. He has authored or co-authored numerous manuscripts published across leading journals such as the American Journal of Cardiology, the Journal of Clinical Lipidology, and several lipid-related book chapters. He was the recipient of the 2011 National Lipid Association President’s Award for services to clinical lipidology. [[truehealthdiag.com](https://truehealthdiag.com/leadership/thomas-dayspring/)]

Disclosures:

- Employed full time for last three years by True Health Diagnostics, LLC, which provides biomarker diagnostics and clinical services to clinicians, patients, and healthcare organizations
- 2017: small consulting project for Abbvie

Tom on Twitter: [@DrLipid](https://twitter.com/Drlipid)