# #75 – David Light: Zantac recall due to cancer concerns – what you need to know

**Source:** [https://peterattiamd.com/davidlight/](https://peterattiamd.com/davidlight/)

---

In this episode, David Light, CEO of [Valisure](https://valisure.com) (the company which alerted the FDA to the Zantac cancer concerns), explains the story behind the recent recalls by manufacturers of ranitidine, a common heartburn medication, sold under the trade name Zantac, due to a potential link to increased cancer risk. David breaks down all the evidence, the role of his unique pharmacy company which tests all its drugs before being dispensed to consumers, and the reason behind the FDA’s tempered reaction to the alarming study results. David makes the argument that Zantac/ranitidine is an inherently unstable molecule which explains the grossly excessive amounts of NDMA (a probable human carcinogen) as opposed to just a contamination for which there could be numerous causes. Finally, David and Peter both provide recommendations for what to do if you or someone you know is currently taking Zantac/ranitidine.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidlight/the_Drive_public.png)

Play

#75 - David Light: Zantac recall due to cancer concerns – what you need to know

#75 - David Light: Zantac recall due to cancer concerns – what you need to know

1x15s30s

0:001:37:30

We discuss:

- The impetus for starting Valisure, a unique online pharmacy that tests all its medications [6:45];
- The story behind the recall of valsartan, and the role which Valisure played [24:30];
- Testing Zantac: The shocking results from Valisure’s initial testing with major potential cancer implications [36:00];
- NDMA – the probable human carcinogen found in Zantac/ranitidine [48:45];
- The epidemiology question: Are we inferring too much from epidemiology? What can we take away from the existing studies? [53:30];
- The staggering results from the 2016 Stanford study, why it didn’t alarm more people, and how Valisure found the missing biological link [1:01:30];
- Alerting the FDA, the FDA’s tempered response, and question of contamination vs. inherent instability [1:07:30];
- How confident is David that the elevated levels of NDMA being found in ranitidine are not due to instrumentation, human error, or temperature contamination? [1:24:15];
- The massive risk being taken by the FDA by not doing more to keep ranitidine away from consumers [1:25:15];
- If someone is taking Zantac/ranitidine, what should they do? What else do they need to know? [1:27:45]; and
- More.

§

## Show Notes

## The impetus for starting Valisure, a unique online pharmacy that tests all its medications [6:45]

Here is [Peter’s interview with Katherine Eban](https://peterattiamd.com/katherineeban/) about the generic drug market

- This was upsetting for Peter
- Changed the way he prescribed drugs
- He now exclusively uses one pharmacy who they trust
- Before prescribing anything, Peter will look to see if the manufacturer has had any interaction with the FDA

**Valisure**

David is the CEO and co-founder of [Valisure](https://www.valisure.com/)

- Valisure is an online pharmacy that is attached to an analytical laboratory where all medications are chemically validated before being dispensed to consumers (the first pharmacy to ever do this)

> “you don’t buy food without looking at the nutrition label and seeing what’s in it, but where is that for your medications?”

*Why is this necessary? Isn’t the FDA doing this?*

- the FDA is not doing chemical testing on the vast majority of medications that are out there
- 80% of drug products in the United States are manufactured in either India or China … and then **self-reported** to the FDA
- And there is a lot of fraud in those countries evidenced by Katherine Eban’s work

**How Valisure was started**

- A friend called David one day and was telling him about all these problems he was having with his anti-convulsive medications
- Every once in a while, he’d refill it and just have this terrible month, get all these side effects and relapses sometimes and just felt very different from how he felt otherwise
- His doctors admitted to him that generics are made different between manufacturers
- And, generics are allowed to vary in their bio-equivalents by 45% from one another

*⇒ The solution?*

- To actually have medications chemically tested at the end of the supply chain
- And then decide if we want to actually dispense them
- So in 2015, David and [Adam Clark-Joseph](https://www.valisure.com/about-us/) (the friend who called him) started to look into this situation as a **technology problem**

Developing the tech

- Spent the next several years developing core technology, a spectroscopy-based approach
  - GC-MS, a [gas chromatography mass spectrometer](https://en.wikipedia.org/wiki/Gas_chromatography%E2%80%93mass_spectrometry)
- Essentially applying lasers to pharmaceutical analysis so that we can do some of the most difficult and costly components of this analysis in a much higher throughput
- But also in a much easier to use machine while still maintaining high precision
- Eventually got ISO accreditation

Once the tech was ready…

- The brought it to pharmacies and manufacturers to see if they wanted to use it
- They recognized there was an issue with medications but said “it’s not our problem”
- And David also realized there was a disincentive for them to be testing their drugs

At that point…

- David and team realized that they had to attach this technology to a pharmacy
- They already had the infrastructure to do it
- So they built out the online pharmacy component
- Launched Valisure in late 2018

*How to make valisure economical?*

- The testing process does eat into their profit margins
- Valisure spreads out their costs by buying large batches of medications
- They spend spend zero money on things like marketing

*Peter’s realization that there is an issue with generic drugs*

- Peter experienced a few cases of patients responding different to various manufacturers of the “same” generic medication
- It wasn’t until after he switched them to a new generic did the patient respond to the meds
- This was the beginning of Peter realizing there was a big issue here
- He talks more about this in his [discussion with Katherine Eban](https://peterattiamd.com/katherineeban/) (starting at 2:12:00)

*When setting out to solve this issue, what did David expect to find?*

- David started investigating whether the issues Adam described were more pervasive than just Adam’s case
- He [found a study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2996138/) that alarmed him which showed that simply refilling antiepileptic medication was associated with an over twofold increase chance of getting a seizure
- In [Bottle of Lies](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781), Katherine Eban tells the story of doctors from the Cleveland Clinic realizing there was [something wrong with the heart failure medication/diuretics](https://www.bostonglobe.com/ideas/2019/05/24/ideas-katherine-eban-these-pills-could-kill-you/d4gYXkoMR24n1uoLUkbnqJ/story.html)
- So at that point, David knew there was a problem (at least in specific types of drugs)
- However, he never suspected it would be so prevalent as they have found so far

> “I don’t think we had quite predicted just how much we’d be finding and how quickly.”

*What is David’s background that allowed him to come into this space and actually innovate?*

- Molecular biologist by training at Yale University
- Spent a lot of time in the field of DNA sequencing
- Biotech is essentially developing complex tools for analysis of complex problems
- Spent 8 years most recently at a company called Ion Torrent as one of the original technology founders there and head of Chemistry R&D
- [Ion Torrent](https://www.thermofisher.com/us/en/home/brands/ion-torrent.html) is now the number two DNA sequencing technology in the world
- David was well positioned to develop some new technology
- Originally, they saw this problem as something to be solved with tech
- which is how they saw this problem originally being solved)
- Just something to plug into the existing system
- Eventually, they had to bring in some more folks to enable the pharmacy side to work as well

## The story behind the recall of valsartan, and the role which Valisure played [24:30]

In the summer of 2018,

- Peter got a call from a patient who was taking a medication called [valsartan](https://en.wikipedia.org/wiki/Valsartan) for blood pressure (aka angiotensin II receptor blocker, or ARB)
- That patient had read something concerning about valsartan in the news

*The valsartan/losartan/ARB situation:*

- Valsartan, losartan, and various other ARB medications have been recalled over the last year
- “*… a very clear and visible case of how the system can go wrong and how many cracks there are in it.*”
- The global supply chain is **self-reported**
- It has a lot of visible fraud that’s happened in the past
- What happened with valsartan was there was a manufacturing change to save some money in China
- (or other places overseas that are making a variety of these different active pharmaceutical ingredients)
- And by having this manufacturing change, they were creating all sorts of impurities
- One of those impurities was NDMA ([*N*-Nitrosodimethylamine](https://en.wikipedia.org/wiki/N-Nitrosodimethylamine))
- It’s considered a probable human carcinogen
- It’s even used in animal studies to [induce cancer](https://en.wikipedia.org/wiki/N-Nitrosodimethylamine#Toxicity)
- This issue was going on for years before it was discovered
- And even as recently as Sept 2019 they were [recalling losartan](https://www.fda.gov/safety/recalls-market-withdrawals-safety-alerts/updated-torrent-pharmaceuticals-limited-expands-voluntary-nationwide-recall-losartan-potassium-0)

*What did Valisure find?*

- At Valisure, they have incorporated a nitrosamine assay to check drugs for NDMA and other carcinogens and impurities
- Valisure discovered that one of the changes made during switch of manufacturers was the solvent they were using
- They started using this solvent called DMF, dimethylformamide
- A solvent is basically something that you’re dissolving different components of chemistry into in order to make a reaction (You could think of it like cooking)
- Different solvents can create variations in the end product
- DMF is itself a carcinogen
- Valisure found that **two-thirds of the manufacturers that were making valsartan that we actually looked at their batches at the time had hundreds of nanograms to over 100,000 nanograms of this DMF containment**
- Valisure then filed a [citizen’s petition](https://www.regulations.gov/document?D=FDA-2019-P-2869-0001)
- The petition essentially said that not only is there NDMA, but there is DMF as well in the end product because the solvent isn’t being cleaned off

> “It certainly underscores the importance of checking everything, and also checking every single batch. I mean, we had manufacturers that were clean sometimes, and then another batch had not only very high levels of DMF, it even had levels of NDMA that were violating the FDA rules, so it certainly underscores the pervasiveness of the problem and certainly in certain areas.”

**David’s explains what GMP means**

GMP, standing for Good Manufacturing Practices

- Anything that’s under FDA purview that touches the manufacturing process is required to be under GMP
- It’s there to make sure that things are very well documented and done consistently
- and any errors or problems or manufacturing changes (like changing over your solvent)
- checking for contaminants
- When you are actually following the GMP system, it’s supposed to catch these kinds of issues
- But it relies on self-reporting and a subsequent inspection
- But they’re **not actually checking the chemistry of what’s in the pill**

*Is there any evidence that any of the companies involved in the production of angiotensin receptor blocker drugs such as valsartan and losartan actually were criminally negligent?*

- Either is certainly possible
- It could have been maliciously covered up by a manufacturer, or
- It could just be that they were saving a few pennies per pound of these kinds of solvents and just didn’t bother to look

*Why do we have the FDA if not to ensure that every pill that goes in a person’s body comes from a batch that has a certificate that demonstrates what’s actually in it (and not in it)?*

- Much of what the FDA is doing is looking at **new drugs** and the billion dollars that goes into developing something new
- A lot of what the FDA oversight is about is going through that GMP process and looking over a bunch of paperwork that’s being **self-reported** by the industry
- The bottom line is that they have limited resources
- The FDA even admits that
  - there’s an unacceptably high occurrence of problems
  - no normal formal means for quality surveillance except through inspections
    - and inspection findings have not been a reliable predictor of the state of quality

> “At Valisure … [we] saw this as further underscoring of industry should be stepping in and doing more. Why don’t we actually analyze every single batch at the end of the supply chain? FDA doesn’t seem to have the resources to be able to do something like that, but in the core of a new business model with some new technology and everything else, we thought we could do it.”

##

## Testing Zantac: The shocking results from Valisure’s initial testing with major potential cancer implications [36:00]

[**Ranitidine**](https://en.wikipedia.org/wiki/Ranitidine) **(sold as brand name Zantac)**

- Used for the treatment of heartburn, peptic ulcer disease, gastroesophageal reflux disease, and Zollinger–Ellison syndrome
- It’s an H2 blocker, which means that’s one of their three ways that you can reduce the acid secreted by the stomach
- and this is one of those ways is you can actually block the H2 receptor on the type of gastric cell that makes hydrochloric acid
- The prescription ranitidine in 2016 was roughly 15 million
- Also one of the most common over-the-counter medications used by millions of Americans and folks all over the world
- the safety profile of ranitidine was considered so high that it is one of the only drugs prescribed to women while they were pregnant, and given to infants for similar stomach issues.

*How did David and Valisure became interested in ranitidine?*

- Valisure was checking batches of medication as per usual
- They put ranitidine through its testing and were **floored by the results**
- They were seeing **millions** of nanograms of [NDMA](https://en.wikipedia.org/wiki/N-Nitrosodimethylamine) in a single dose
- The FDA permissible exposure to NDMA is **96**
- David’s first thought was there was a mistake
- But they kept rechecking and finding the same thing
- They even bought Zantac from local pharmacies and found the same thing

*What was David’s first thought after seeing these results*?

- The drug itself must just be so incredibly unstable that it’s directly forming NDMA
- There’s no other way to get millions of nanograms except if the molecule itself was reacting with itself and forming it

The standard dose of ranitidine is 75-150 milligrams

- When testing a 150 milligram pill, they find at least 1.5 million nanograms of NDMA
- 1.5 million nanograms = 1.5 milligrams
- That means at least 1% of the pill is a potential carcinogen

One thing that makes it even worse…

- The NDMA molecule is a lot smaller/lighter than the ranitidine molecule
- So, the molar conversion or the conversion of a ranitidine molecule into an NDMA molecule is actually even more efficient than that one percent
- The numbers are suggesting 10% or so conversion of the ranitidine molecule into NDMA in an incredibly short period of time

Valisure is using a [GC-MS analysi](https://en.wikipedia.org/wiki/Gas_chromatography%E2%80%93mass_spectrometry)s

- This means you heat the drug up to 130 degrees celsius for 15 minutes
- At the heat and time, it is benign for practically any other drug that we’re looking at and is part of the **FDA standard protocol**
- “*But 15 minutes of exposure and you’re getting around a 10% conversion into NDMA? That’s incredible instability.*”

##

## NDMA – the probable human carcinogen found in Zantac/ranitidine [48:45]

How big a molecule is it?

- Just a few atoms
- It’s a couple nitrogens and carbon
- Tiny

What is the mechanism by which it causes cancer in animal models?

- NDMA basically sticks to DNA and modifies it in a way that causes cancers
- if it’s a carcinogen, the definition is it changes the DNA in a way that the DNA in that cell no longer responds to appropriate cell cycle signaling.
- So, now you have growth of a cell that can be unregulated as opposed to regulated.

How well is this documented?

- extremely well documented in almost every clinical model (obviously other than humans)
- used actively as a control for [inducing cancer in mice and rats](https://en.wikipedia.org/wiki/N-Nitrosodimethylamine#Toxicity)
- **In-vitro** means it causes cancer in a petri dish where you take the cells out,
- and if something does that, that’s interesting
- but it’s a lot more interesting if it can cause cancer inside the animal itself and that’s called **in-vivo**

What dose of NDMA becomes a problem?

- Hard to say because we are just extrapolating from animals
- The [FDA believes](https://www.fda.gov/drugs/drug-safety-and-availability/laboratory-analysis-valsartan-products) that:
  - ~17,000 nanograms or so of NDMA
  - Taking it consistently for four years
  - Would result in **one additional cancer case in 8,000**

## The epidemiology question: Are we inferring too much from epidemiology? What can we take away from the existing studies? [53:30]

- Peter points out the [flaws with epidemiology](https://peterattiamd.com/ns002/)
- Especially when you see weak [hazard ratios](https://en.wikipedia.org/wiki/Hazard_ratio) and try to infer causality
- He says epidemiology is most helpful when something is NOT there
- In other words, when epidemiology says there’s no association between X and Y, it becomes a lot easier to say there’s much less likelihood that there’s a causal relationship between X and Y
- This leads to the question… I*f NDMA is problematic, there should be a good collection of body bags, shouldn’t there*?

In the [citizen petition](https://www.regulations.gov/docket?D=FDA-2019-P-4281) to the FDA, Valisure included links to interesting epidemiology studies

- [One study](https://www.ncbi.nlm.nih.gov/pubmed/14973090) found a link between ranitidine and bladder cancer
- An even [more important study](https://www.ncbi.nlm.nih.gov/pubmed/26992900) found over 40,000 nanograms of NDMA in the urine of patients taking one pill of Zantac

Furthermore,

- Valisure is working with [Lior Braunstein](https://www.mskcc.org/cancer-care/doctors/lior-braunstein)
- Lior is working on the question of the possible link between use of ranitidine and increased incidences of cancer

Peter’s two cents…

- What it really suggests is if there is an increase in the risk of human cancers from the use of this, it’s not going to be as drastic as something like **smoking and lung cancer**
- With smoking, the hazard ratios varied somewhere between 8X and 14X
- When you don’t need statistics to see the answer, that’s usually a scary thing
- You didn’t need complicated statistical models to tease out the relationship between tobacco and lung cancer
- Now, that does NOT mean ranitidine/Zantac doesn’t increase cancer risk
- It just means that it might be very difficult to detect signals and tease out things like lifestyle factors
- It becomes easier if a very rare cancer sudden becomes not so rare (i.e., lung cancer and smoking)

This leads to the questions…

1 | *How big of a problem is this?*

- we don’t know how big a problem this is
- and to me that’s the fair answer because the study hasn’t been done
- We haven’t looked at the cases and the controls, meaning the people who have taken it from the people who haven’t

2 | *What are our blind spots?*

- but the magnitude problem and the blind spot problem really come down to…
- we will not know the answer until we figure out which type of cancers …
- Because, if it increases the risk of a very rare cancer, I suspect it would have shown up.

In summary…“How big of a problem is this?”

- Answering the question of “*How big of a problem is this?”* is going to take years to really get down to what is the total impact for real
- but “*I can’t imagine it’s going to be zero*” says David
- And “*anything greater than zero, multiplied by the millions of people taking it for 40 years, is a tragedy*”
- \*Especially when there is **no shortage of substitutes** that are equally efficacious (if not better)

## The staggering results from the 2016 Stanford study, why it didn’t alarm more people, and how Valisure found the missing biological link [1:01:30]

**The results from the** [**2016 Stanford study led by Bill Mitch**](https://www.ncbi.nlm.nih.gov/pubmed/26992900) **were staggering**:

- One pill of 150 mg
- Given to subjects over night
- Urine the next day found ~40,000 nanograms of NDMA

But it’s even worse than it sounds, says David…

- “It’s actually at least 100 times worse because the renal clearance of NDMA…is often one percent or less. That’s because NDMA sticks to DNA and your body is full of DNA, and it’s reacting all over your body, and so very little of it is actually expected to make it to the urine. So, really what those results were suggesting is that **somewhere around four million, or millions, of nanograms of NDMA are being exposed in your body with a single pill of Zantac**.”

*So, why didn’t that study get more attention?*

- The [2016 Stanford study](https://www.ncbi.nlm.nih.gov/pubmed/26992900) that came from [Professor Bill Mitch](https://profiles.stanford.edu/william-mitch)
- He’s an environmental scientist and he’s been looking at this ranitidine problem himself for 17 years
- His [first papers](https://www.liebertpub.com/doi/10.1089/109287503768335896) published in 2002-2004 were concerned about where does NDMA come from when it’s in drinking water and coming out wastewater treatment plants
- The field of environmental science is much more obscure than medical community papers
- So, it probably was being dismissed/overlooked

Finding the missing biological link

- When Valisure started looking into this issue, “*we really we were just connecting the dots over 37 years of research*”
- What was very clear also in Bill Mitch’s 2016 paper was that there was some sort of **missing biological link**
- Valisure essentially found that biological link
- They identified an enzyme, DDAH1, which grabs on to a molecule and it breaks off this DMA group
- Once you break off a DMA group, it’s **very easy to form the NDMA** in the body with nitrate that circles in your body
- Valisure looked at this enzyme and did computational modeling to find that it seems that the ranitidine molecule fits extremely snugly in this enzyme
- and that at least gives a potential biological mechanism for forming millions of nanograms throughout the body, even outside of the stomach

> “*We essentially had now that biological link, and the chemistry side, and then all the way into the full body clinical study that Bill Mitch did that makes a very compelling story that ranitidine is just a toxic molecule in the human body.”*

## Alerting the FDA, the FDA’s tempered response, and question of contamination vs. inherent instability [1:07:30]

Valisure confidentially reached out the FDA in June because of how alarmed they were by their findings

They then filed a [citizen petition](https://www.regulations.gov/docket?D=FDA-2019-P-4281) on 9/13/2019

The FDA made their own [announcement](https://www.fda.gov/news-events/press-announcements/statement-alerting-patients-and-health-care-professionals-ndma-found-samples-ranitidine) as well on 9/13/2019

- They announced they had found NDMA at low levels
- Made some references to barely exceeding those that’s in food
- Like “no big deal”
- David says they were quite “taken aback” by this weak announcement

Admittedly,

- The info in the citizen petition, while it had a ton of compelling information, it was lacking the upcoming results from the ongoing study by [Lior Braunstein](https://www.mskcc.org/cancer-care/doctors/lior-braunstein) which will hopefully complete the picture
- “*all these things even just by themselves are so incredibly concerning that, even though we didn’t have the epidemiology done yet, we definitely felt it should be published.*”

*Does the FDA have the authority to pull all forms of ranitidine off the US market?*

- David believes they do
- At the very least have the authority to request manufacturers recall it
- (but they did neither)

Canada, on the other hand, stopped manufacturing and recalled the drug

- Here is the [statement from Health Canada](https://www.newswire.ca/news-releases/information-update-health-canada-requests-that-companies-stop-distributing-ranitidine-drugs-in-canada-while-it-assesses-ndma-some-products-being-recalled-821911993.html)

Roughly, 30 countries have recalled or banned ranitidine, here’s just a few:

- Canada
- Italy
- France
- Germany
- Kenya
- Libya
- Bangladesh
- Saudi Arabia
- Pakistan
- South Korea (they even [published some of their own findings](https://pulsenews.co.kr/view.php?year=2019&no=769561))

**Contamination vs. inherent instability**

- The unfortunate things that happened out of the [FDA’s original statement](https://www.fda.gov/news-events/press-announcements/statement-alerting-patients-and-health-care-professionals-ndma-found-samples-ranitidine) is that it made this whole thing just sound like a *contamination*
- And if that is how they understood the situation, it might explain why stronger action wasn’t taken
- However, this is an **inherent problem with the drug**, not a simple contamination, says David
- Some countries (e.g., Canada) realized that **this is an inherent problem of instability with the drug (**and therefore stop all manufacturers, stop all distribution)
- Others were just banning *certain* manufacturers that they believed to have some level of contamination of NDMA
- A [great article out of India](https://theprint.in/theprint-essential/explained-why-india-us-havent-recalled-acidity-drug-ranitidine-but-france-canada-have/299418/) discussed have the difference between a contamination vs. inherent instability of ranitidine and why certain countries have banned it and others have not

**The FDA challenges Valisure’s testing method**

⇒ The FDA released an [updated statement](https://www.fda.gov/drugs/drug-safety-and-availability/fda-updates-and-press-announcements-ndma-zantac-ranitidine) on 10/2/2019

- Said they were going to continue to test ranitidine
- Not saying there is nothing wrong
- But they did specifically challenge Valisure’s testing method saying, “*That method is not suitable for testing ranitidine because heating the sample generates NDMA.*”

David turns this around and says…

- Yes, even just some heat, ranitidine does indeed generate NDMA ⇒ A low heat which is “*benign for practically all these other molecules is enough to generate NDMA*”
- That heat could be happening anywhere
  - In transit;
  - In a hot car;
  - or anywhere else; and
  - It could directly degrade this molecule, not just into falling apart, but into **falling apart directly into NDMA**

Recreating the human body conditions and then testing

- Even in their [citizens petition](https://www.regulations.gov/docket?D=FDA-2019-P-4281), Valisure points out that heat may cause the generation of NDMA
- But they were using the **FDA method** of 15 minutes at 130 degrees Celcius which was causing an incredibly efficient reaction of generating NDMA from ranitidine
- Valisure then modified that particular protocol to *mimic the human body*
- They created a “stomach fluid”
- Still using the GC-MS, they turned the temperature down to human body temperature (37 celcius)
- And tested again and found 300,000 nanograms of NDMA in one tablet of Zantac

![](https://peterattiamd.com/wp-content/uploads/2019/10/Screen-Shot-2019-10-10-at-1.07.44-PM-1024x386.png)

**Figure 1. Conditions tested in Valisure’s laboratory produced high levels of NDMA from ranitidine. NDMA was detected in conditions of simulated gastric fluid with sodium nitrite, which is found in certain foods and produced by bacteria in the stomach.** Image credit: [Citizen Petition from Valisure, LLC](https://www.regulations.gov/document?D=FDA-2019-P-4281-0001)

- [Bill Mitch](https://profiles.stanford.edu/william-mitch) did something similar and found similar results
- Not to mention…
  - Turning down the GC-MS temperature lowers the sensitivity, in other words…
    - Instead of being sensitive down to 25 nanograms at the FDA protocol of 130 degrees C
    - When you take it down to body temperature, now you’re at 100 nanograms of sensitivity

A note on trying to recreate biology:

- This is basically impossible in a lab
- The real test is to give people the pill and see what happens
- This is just what Bill Mitch did in his study when he found NDMA in their urine

About [Bill Mitch’s study](https://www.ncbi.nlm.nih.gov/pubmed/26992900), Peter asks…

*-Is this person peeing out some byproduct of ranitidine that then further decays to NDMA?*

*-Or, are they just peeing out straight NDMA?*

*-If they are, then the temperature should make very little difference in how much you detect, correct?*

- David points out that they asked Bill those questions
- Bill created some significant controls to control for the instrumentation in some follow up testing and still found 40,000 nanograms of NDMA

## How confident is David that the elevated levels of NDMA being found in ranitidine are not due to instrumentation, human error, or temperature contamination? [1:24:15]

“As a proper scientist, I can never be 100% on anything, of course, but the data is just overwhelming. And the other part of this is. . .this isn’t some life-saving drug that there’s no alternatives for where we say, ‘You know what? We’re 99% sure, but there’s one percent that maybe we’re a little bit off here and people depend on this for their lives, and let’s think about that versus the fact that they may cause some cancer over time.’”

##

## The massive risk being taken by the FDA by not doing more to keep ranitidine away from consumers [1:25:15]

Peter points out the asymmetric risk that the FDA is taking by NOT recalling and/or stopping production of ranitidine

On the one hand,

- Valisure (and the many others) could end up being wrong
- The testing method was faulty or something
- The human epidemiologic data that tracks the cases and the cohorts may end up showing that Zantac is totally fine
- In that case, the FDA will have been correct in not recalling the drug
- W*hat’s the UPSIDE in that situation*? ⇒ it’s not that big

Conversely,

- The ongoing epidemiology could come out in a few years and reveal that ranitidine increased cancer by 2.5X
- And when the FDA was notified of this, they did nothing
- That DOWNSIDE is *infinitely* greater than the UPSIDE of having done nothing.
- That’s a **very asymmetric downside**

## If someone is taking Zantac/ranitidine, what should they do? What else do they need to know? [1:27:45]

**First**, if you are taking Zantac/ranitidine, switch to an alternative [H2 blocker](https://en.wikipedia.org/wiki/H2_antagonist) or [proton-pump inhibitor](https://en.wikipedia.org/wiki/Proton-pump_inhibitor)

**Secondly**, make sure to properly dispose of ranitidine

- Because another potential downside of all of this is that everybody’s flushing it and it’s going into the water system, and then being converted to high levels of NDMA in drinking water, and now you have another potential crisis
- \***Do NOT throw it in the trash can**\*
- \***Do NOT flush it down the toilet**\*
- It’s got to be **disposed of as toxic waste** (meaning, returned to the pharmacy or a facility that does medication disposal)

Pharmacies that will take your medication back (and offer a refund):

- Walmart
- Sam’s Club
- Kroger

⇒ Here is the [article](https://www.usatoday.com/story/money/2019/10/02/walmart-halting-zantac-sales-over-possible-cancer-link/3839963002/) about it

§

## Selected Links / Related Material

### **Links specifically highlighted by David Light:**

**Valisure FDA Citizen Petition on ranitidine**: [Requests FDA to issue a regulation, revise industry guidance, and request a recall and suspend sales of ranitidine from the US market and take such other actions listed in the petition](https://www.regulations.gov/docket?D=FDA-2019-P-4281)

**Valisure page on ranitidine discussion, news, citizen petition, summary of findings, etc**: [Valisure Detects NDMA in Ranitidine](https://www.valisure.com/blog/uncategorized/detection-of-ndma-in-raniditine/) | (valisure.com)

**Stanford University clinical study on ranitidine by Zeng and Mitch**: [Oral intake of ranitidine increases urinary excretion of N-nitrosodimethylamine.](https://www.ncbi.nlm.nih.gov/pubmed/26992900) (Zang et al., 2016)

**Memorial Sloan Kettering Cancer Center researching ranitidine and took it off their formulary**: [Leading Cancer Center No Longer Offering Zantac to Patients](https://www.bloomberg.com/news/articles/2019-10-02/leading-cancer-center-no-longer-offering-zantac-to-patients) | Anna Edney (bloomberg.com)

**Health Canada’s 9/17/19 announcement**: [Information Update – Health Canada requests that companies stop distributing ranitidine drugs in Canada while it assesses NDMA; some products being recalled](https://www.newswire.ca/news-releases/information-update-health-canada-requests-that-companies-stop-distributing-ranitidine-drugs-in-canada-while-it-assesses-ndma-some-products-being-recalled-821911993.html) | (newswire.ca)

**South Korean Regulator’s Findings**: [Korea bans sales of Zantac and other ranitidine drugs after carcinogen alert](https://pulsenews.co.kr/view.php?year=2019&no=769561) | Seo Jeong-won and Kim Hyo-jin (pulsenews.co)

**Indian article on the confusion between “contamination” and fundamental toxicity of ranitidine**: [Explained: Why India, US haven’t recalled acidity drug Ranitidine but France & Canada have](https://theprint.in/theprint-essential/explained-why-india-us-havent-recalled-acidity-drug-ranitidine-but-france-canada-have/299418/) | Priyanka Pulla (theprint.in)

### **All links and related material:**

**Peter’s interview of Katherine Eban about the generic drug industry**: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) | Peter Attia (peterattiamd.com) [6:45]

**David’s unique pharmacy that tests all it’s drugs**: [Valisure](https://www.valisure.com/) | (valisure.com) [6:45]

**Example of self-reporting system problems**: [Boeing 737 Max](https://en.wikipedia.org/wiki/Boeing_737_MAX) | (wikipedia.org) [6:45]

**Katherine Eban’s book about the corrupt generic drug industry**:  [Bottle of Lies: The Inside Story of the Generic Drug Boom](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781) by Katherine Eban | (amazon.com) [6:45]

**Study that alarmed David that showed that simply refilling antiepileptic medication was associated with an over twofold increase chance of getting a seizure**: [Refilling and switching of antiepileptic drugs and seizure-related events](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2996138/) (Gagne et al., 2010) [6:45]

**Katherine’s article about two doctors at the Cleveland clinic who noticed patients on cardiac drugs were stabilized on the brand and then became unstable when they were switched to the generic and in some cases heart transplant patients were suffering organ rejection from a generic**: [These pills could kill you](https://www.bostonglobe.com/ideas/2019/05/24/ideas-katherine-eban-these-pills-could-kill-you/d4gYXkoMR24n1uoLUkbnqJ/story.html) | Katherine Eban (bostonglobe.com) [6:45]

**David spent 8 years as the head of chemistry and R&D at**: [Ion Torrent](https://www.thermofisher.com/us/en/home/brands/ion-torrent.html) | (thermofisher.com) [6:45]

**One of the “most potent carcinogens known to man”**: [*N*-Nitrosodimethylamine (NDMA)](https://en.wikipedia.org/wiki/N-Nitrosodimethylamine) | (wikipedia.org) [24:30]

**September 2019 recall on losartan**: [Updated: Torrent Pharmaceuticals Limited Expands Voluntary Nationwide Recall of Losartan Potassium Tablets, USP and Losartan Potassium / Hydrochlorothiazide Tablets, USP](https://www.fda.gov/safety/recalls-market-withdrawals-safety-alerts/updated-torrent-pharmaceuticals-limited-expands-voluntary-nationwide-recall-losartan-potassium-0) | (fda.gov) [24:30]

**Valisure found that two-thirds of the manufacturers of valsartan had anywere from hundreds to over 100,000 nanograms DMF, which is a probable human carcinogen**:  [Fourth Carcinogen Discovered in Heart Pills Used by Millions](https://www.bloomberg.com/news/articles/2019-06-18/fourth-carcinogen-discovered-in-heart-pills-used-by-millions) | Anna Edney (bloomberg.com) [24:30]

**Valisure’s citizen petition filed with the FDA about DMF found in valsartan**: [Citizen Petition from Valisure, LLC.](https://www.regulations.gov/document?D=FDA-2019-P-2869-0001) | (regulations.gov) [24:30]

**NDMA is used to induce cancer in lab animals**: [N-Nitrosodimethylamine: Toxicity](https://en.wikipedia.org/wiki/N-Nitrosodimethylamine#Toxicity) | (wikipedia.org) [48:45]

**FDA statement estimating that if 8,000 people took the highest valsartan dose (320 mg) containing NDMA from the recalled batches daily for four years, there may be one additional case of cancer over the lifetimes of the 8,000 people**: [Laboratory analysis of valsartan products](https://www.fda.gov/drugs/drug-safety-and-availability/laboratory-analysis-valsartan-products) | (fda.gov) [48:45]

**Valisure FDA Citizen Petition on ranitidine**: [Requests FDA to issue a regulation, revise industry guidance, and request a recall and suspend sales of ranitidine from the US market and take such other actions listed in the petition](https://www.regulations.gov/docket?D=FDA-2019-P-4281) | (regulations.gov) [53:30, 1:07:30]

**2004 paper by National Cancer Institute found a link to bladder cancer when looking at prescription antacids, which were both ranitidine and cimetidine at the time**: [Peptic ulcer disease and the risk of bladder cancer in a prospective study of male health professionals.](https://www.ncbi.nlm.nih.gov/pubmed/14973090) (Michaud et al., 2004) [57:00]

**Stanford University clinical study on ranitidine by Zeng and Mitch**: [Oral intake of ranitidine increases urinary excretion of N-nitrosodimethylamine.](https://www.ncbi.nlm.nih.gov/pubmed/26992900) (Zang et al., 2016) [1:01:30, 1:07:30]

**Bill Mitch’s first papers in 2002-2004 were concerned about NDMA in drinking water**:  [N-Nitrosodimethylamine (NDMA) as a Drinking Water Contaminant: A Review](https://www.liebertpub.com/doi/10.1089/109287503768335896) (Mitch et al., 2004) [1:01:30]

**Valisure identified the enzyme DDAH1 which grabs on to a molecule and breaks off a DMA group which then is very easy to form NDMA**: See page 4 of the [citizen’s petition](https://www.regulations.gov/docket?D=FDA-2019-P-4281) | (fda.gov) [1:01:30]

**FDA’s statement regarding NDMA and ranitidine on 9/13/19**: [Statement alerting patients and health care professionals of NDMA found in samples of ranitidine](https://www.fda.gov/news-events/press-announcements/statement-alerting-patients-and-health-care-professionals-ndma-found-samples-ranitidine) | Director – Center for Drug Evaluation and Research Janet Woodcock M.D. (fda.gov) [1:07:30]

**Health Canada’s 9/17/19 announcement**: [Information Update – Health Canada requests that companies stop distributing ranitidine drugs in Canada while it assesses NDMA; some products being recalled](https://www.newswire.ca/news-releases/information-update-health-canada-requests-that-companies-stop-distributing-ranitidine-drugs-in-canada-while-it-assesses-ndma-some-products-being-recalled-821911993.html) | (newswire.ca) [1:07:30]

**South Korean Regulator’s Findings that a minimum 2800 nanograms of NDMA and up to 32,000 nanograms of NDMA in ranitidine**: [Korea bans sales of Zantac and other ranitidine drugs after carcinogen alert](https://pulsenews.co.kr/view.php?year=2019&no=769561) | Seo Jeong-won and Kim Hyo-jin (pulsenews.co) [1:07:30]

**Indian article on the confusion between “contamination” and fundamental toxicity of ranitidine**: [Explained: Why India, US haven’t recalled acidity drug Ranitidine but France & Canada have](https://theprint.in/theprint-essential/explained-why-india-us-havent-recalled-acidity-drug-ranitidine-but-france-canada-have/299418/) | Priyanka Pulla (theprint.in) [1:07:30]

**FDA’s updated statement in Oct. 2019 challenging Valisure’s testing method**: [FDA Updates and Press Announcements on NDMA in Zantac (ranitidine)](https://www.fda.gov/drugs/drug-safety-and-availability/fda-updates-and-press-announcements-ndma-zantac-ranitidine) | (fda.gov) [1:07:30]

**Walmart, Sam’s Club, and Kroger pharmacies are offering a refund on Zantac and other ranitidine products**: [Walmart and Kroger also halt sales of Zantac, generic ranitidine over possible cancer link](https://www.usatoday.com/story/money/2019/10/02/walmart-halting-zantac-sales-over-possible-cancer-link/3839963002/) | Brett Molina (usatoday.com) [1:27:45]

§

## People Mentioned

- [Katherine Eban](https://twitter.com/katherineeban?lang=en) (investigator of the generic drug industry, wrote Bottle of Lies, previous guest on The Drive)
- [Adam Clark-Joseph](https://www.valisure.com/about-us/) (David’s business partner and co-founder of Valisure)
- [Lior Braunstein](https://www.mskcc.org/cancer-care/doctors/lior-braunstein) (leading the current epidemiology study on ranitidine, [Lior’s publications](https://www.ncbi.nlm.nih.gov/pubmed?cmd=search&term=lior%20braunstein))
- [William “Bill” Mitch](https://profiles.stanford.edu/william-mitch) (2016 ranitidine paper)
- [Teng Zeng](https://mitchlab.sites.stanford.edu/teng-zeng) (2016 ranitidine paper)
- [Kaury Kucera](https://www.linkedin.com/in/kaury-kucera-055b83b9/) (chief scientific officer at Valisure)

§

![](https://peterattiamd.com/wp-content/uploads/2019/10/David-Light-500x500.jpg)

##### David Light

Founder and CEO of [Valisure](https://www.valisure.com/), an online pharmacy that is attached to an analytical laboratory where all medications are chemically validated before being dispensed to consumers.

David is a biotech entrepreneur and scientist. A graduate of Yale University, David studied molecular biology and has worked in a variety of scientific and business roles at start-ups like Synthetic Genomics, 454 Life Sciences, and Ion Torrent. At Ion Torrent, David developed and deployed key technologies that led to its $725M acquisition and ran its flagship technology programs through development and global commercialization.