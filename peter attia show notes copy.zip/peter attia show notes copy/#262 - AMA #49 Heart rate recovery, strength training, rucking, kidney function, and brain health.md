# #262 – AMA #49: Heart rate recovery, strength training, rucking, kidney function, and brain health

**Source:** [https://peterattiamd.com/ama49/](https://peterattiamd.com/ama49/)

---

In this “Ask Me Anything” (AMA) episode, Peter addresses follow-up questions related to recent conversations around exercise, kidney function, and brain health. He begins with the topic of exercise, covering aspects such as starting rucking, transitioning from muscle building to maintenance, the optimal order of lifting weights and cardio, and exploring heart rate recovery. Shifting gears, he delves into the realm of kidney health, discussing the most effective blood tests to measure kidney function, desired levels, the natural decline with age, and the crucial role of maintaining a high glomerular filtration rate for longevity. Additionally, he discusses the importance of managing homocysteine levels and alcohol consumption for brain health.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #49 show notes page](https://peterattiamd.com/ama49). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Topics: exercise, kidneys, and brain health [1:30];
- Rucking: advice for beginners, proper load, packs, and shoes [4:30];
- Rucking for women, bone health, using a treadmill, zone 2, and more [11:45];
- Building vs. maintaining: when and how to transition from the goal of building muscle and strength to focusing on maintenance [16:00];
- Should you lift weights before or after a cardio session? [24:00];
- Heart rate recovery: defining heart rate recovery and how it relates to cardiovascular fitness [28:45];
- How to measure heart rate recovery, and what is considered a “good” heart rate recovery [33:15];
- How kidney health and function typically measured [42:30];
- Differentiating between creatine and creatinine [48:15];
- The cystatin C blood test as a practical way to assess kidney health [52:45];
- How kidney function impacts lifespan and the five stages of kidney disease [59:15];
- Slowing the decline of kidney function [1:08:15];
- The main drivers of kidney disease [1:11:15];
- The importance of managing homocysteine levels for brain health [1:14:00];
- The relationship between alcohol consumption and brain health [1:21:30]; and
- More.

§

The Peter Attia Drive

Heart rate recovery, strength training, rucking, kidney function, and brain health

§

## Show Notes

§

## Topics: exercise, kidneys, and brain health [1:30]

**For today’s AMA, going to cover a few different topics**:

- Exercise​​
  - Rucking – advice for beginners, what weight to use, how to know when to ratchet it up, what shoes to wear, and more
  - When and how to thinking through your goals of building muscle and strength versus maintenance
  - Should you lift before or after cardio, what one is “better”?
  - Questions on heart rate recovery – what it is and why it’s relevant
- Kidneys
  - Most effective and practice ways to measure kidney function
  - The desired levels to look for
  - The natural decline with age and how to combat it
  - And the crucial role of maintaining a high glomerular filtration rate for longevity
- Brain health
  - Answering follow up questions from [AMA #46](https://peterattiamd.com/ama46/) such as…
  - The importance of managing homocysteine levels for brain health
  - The relationship between alcohol consumption and brain health — is any amount of alcohol “good” for the brain?

## Rucking: advice for beginners, proper load, packs, and shoes [4:30]

⇒ Peter has already [discussed](https://peterattiamd.com/michaeleaster/) with [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) how he enjoys rucking for its physical and mental benefits with as well as on [AMA #39](https://peterattiamd.com/ama39/)

***What weight should people start at when they’re going to ruck?***

- It’s completely dependent on the fitness and health of the person.
- One end of the spectrum as little as just walking with an empty backpack
- For others, they might start with 10% of their body weight
- But you don’t really need to go beyond about a third of your body weight
- The true answer is highly dependent on the terrain—how flat it is, how uneven it is—all of these things make it obviously more or less difficult
- The first few times you go out there, it’s hard to overstate how foreign it can feel on your shoulders, on your traps
- And you don’t want to overdo it, for a couple reasons
  - 1) there’s just a risk of getting injured
  - 2) you want to enjoy this
- When in doubt start with a low weight, and if you come back from a ruck and you felt like there was no additional stress then just add incremental weight the next time and so on

**How to add weight and rucking packs [7:00]**

***Do you recommend everyone gets a waistband to go with a ruck bag?***

- There are very different styles of rucking
- For instance, some people who really prefer to have all the weight in their shoulders and they don’t want to have any of it on their waist

There’s really three things to consider when using a rucking pack of backpack

- 1 – The waistband strap that allows you to, if you cinch it down correctly, it allows you to keep more of that weight on your hips
- 2 – On the front of a backpack, there’s a little strap that keeps the straps of the pack more or less tight
- 3 – Then there are the straps that are pulling on your shoulders
- Most people benefit from a hip belt because it is advantageous to put more of the weight on your hips than on your shoulders

For Peter personally, he actually doesn’t even buckle the small strap that joins the shoulder straps

- He likes to have as little weight as possible on his shoulders and as much weight as possible on hips hips
- He creates this feeling by cinching down a lot on his hips and it’s actually loose on his shoulders
- That said, there is no right way or wrong way to do this, but you want to get a feel of what works for you

⇒ Peter uses the [GORUCK](https://www.goruck.com/?utm_source=google&utm_medium=cpc&utm_term=&utm_campaign=17932761006&utm_content=&pos=&gclid=Cj0KCQjwtO-kBhDIARIsAL6LorfaZ513DmADQG0w8aTLad2B8evnth_0PaHKNfUP1updXqwGPHWUdEIaAnR1EALw_wcB) packs

**Shoes for rucking [8:45]**

⇒ Peter [spoke to Irene Davis](https://peterattiamd.com/irenedavis/) about minimalist shoes

\*\*\*

*What would you recommend for people who are going to ruck maybe on a little more of a terrain?*

*Is that something that they can do with a minimalist shoe?*

*Do you want a shoe with more support?*

- Peter’s thinking has actually evolved here
- He used to think doing everything in a minimalist shoe was beneficial
- But now he thinks more in line with “When I’m asking a great deal of myself, the risk-reward trade off isn’t worth it”
- He no longer uses a minimalist shoe for rucking
- Instead he uses a [boot made by GORUCK](https://www.goruck.com/collections/footwear) — “*By no means the only boot you have to go on. But what I like is it’s got an eight millimeter drop, so it’s a little bit easier on your Achilles than a flat shoe, which is a minimalist shoe and it provides a little bit of support*.”
- In summary, “*I do wear a somewhat supported shoe, but if you saw it, you’d still think it’s relatively mild*”

What does Peter hunt in?

- Hunting is similar to rucking except the terrain is typically even much worse and you may be carrying far more weight
- In that situation, he’s wearing the most supportive boot he can wear, because he doesn’t always get to see where his feet are going down if it’s dark and all sorts of things that like

> “Playing the long game means ‘run fast on the straightaway and slow on the curves’ a little bit. And therefore, when I have much more control over what I’m doing, such as when I’m lifting weights and walking around the house or walking around town, I can afford to be in a more minimalist shoe. And when the stakes are higher, I want to provide some support.” —Peter Attia

## Rucking for women, bone health, using a treadmill, zone 2, and more [11:45]

***Is there a benefit to women engaging in rucking in terms of bone density?***

- Any load-bearing activity is beneficial
- The greater the load, the greater the benefit — So walking is reasonably better than swimming or cycling, but rucking is better because you’re under more load.
- That said, rucking is good enough alone — “if we’re really in the business of increasing bone mineral density, you really have to lift weights”
- We have to think about bone health across the entire body, and simply put, when you’re picking up and carrying heavy things, when you’re pressing, when you’re pulling, when you’re lifting, all of those things with weight are going to have the greatest impact on bone stress and it’s that stress on the bone that leads to the remodeling that strengthens it.
- “*So I think of rucking as an adjunct to that, but not the primary mover. And I just wouldn’t want anybody rucking thinking, ‘Now I can check the box of bone health.’ I don’t think it’s sufficient*.”

**Rucking and zone 2 on treadmill**

*With a treadmill, with tweaking the weight on your back, how high the treadmill is, could you also do Zone 2 rucking as an activity?*

- You totally could
- On flat ground, it’s harder to hit zone 2 on flat ground is hard once you get to a certain level of fitness

How Peter gets to zone 2 while rucking outside (i.e., not on a treadmill)

- But one way you can get into zone 2 while rucking is if you start to “shuffle run” —you’re not actually running, but you’re moving quickly
- The “shuffle run “ is much easier on your knees because you’re not picking your feet up very high like you would in a running gait
- It’s hard to describe, but imagine just keeping your knees bent and shuffling your feet forward as fast as you can go
- Peter will sometimes go to a local track and do quarter-mile “shuffle runs” in a rucking pack

On a treadmill, however, you can reach zone 2 much easier by adjusting the incline

- you might want to set it to two and a half to three miles an hour and then just slowly start to play with the incline

## Building vs. maintaining: when and how to transition from the goal of building muscle and strength to focusing on maintenance [16:00]

***At what point do you make the switch from building strength to maintaining it?***

- Unfortunately there’s no straightforward answer because it really depends heavily on your training age, your background, etc.
- Peter, for example, is way beyond the point where he would be aggressively trying to add strength
- Conversely, Peter has many patients who are his age (50 yr), however, they spent the first 49 years of their life not being very physically active
  - For these are people who are starting at such a deficit that they are in an **absolute building phase**
  - Peter is trying to put as much muscle mass and strength on these people as possible
  - And that because everybody’s coming down (in muscle and strength) for the most part by the time they are in their 70s

The real question is: *Are you someone who can just try to plateau your way into your 70s or do you need to build up into your 70s?*

- Peter considers himself a “glider” that’s probably already flying at a reasonable enough height
- But some people, their glider might be really low, they have to get a little bit higher

The next question for people is one about *preexisting conditions and injuries* and things like that

- Peter, for instance, did a ton of squatting and deadlifting as a young person and as a consequence he suffered injuries while doing those things
- So today, Peter views those activities not as the primary means by which he will get stronger or add muscle mass (although those things are true), but instead he views them (especially the deadlift) as auditing tools for a correct movement patterns
- In fact, on a day he prepares to deadlift, he audits his warm up sets and may even make the decision to lift only light weight or not do it at all that day if something feels “off”

**Final point to make**: You can’t negate the effect of other physiologic stress on your training

- So when your sleep is poor or when you are under psychological stress, those things bring more baggage into the gym than Peter ever realized when he was younger and he’s now much more aware of that
- “*And as a result of that, I’m much more flexible in what I expect of myself. So I think that’s another important component of how we train in middle age and beyond*.”

**Understanding body comp with DEXA**

- DEXA scans can help people see whether they are someone who needs to put on muscle (or take off fat)
- FFMI, fat-free mass index, and ALMI, appendicular lean mass index, are great metrics and they are age adjusted
  - It was discussed on a previous AMA (see [AMA #40](https://peterattiamd.com/ama40/) and [AMA #44)](https://peterattiamd.com/ama44/) that Peter wants people in the top 25% of the population for their age and sex
- So when a patient shows up within the 25th percentile as opposed to the 75th percentile, Peter says “No problem. Within three years, we can absolutely get you to the goal.” — this person is in a building phase
- Peter, by contrast, is in the 95th percentile, so he just wants to maintain and do so without getting injured

For himself, Peter says…

- “For me, there’s a far greater emphasis in my training on movement patterns than on adding size and strength because what’s going to get me into trouble as I age are chronic injuries.”

For patients in the 10th percentile of ALMI:

- The first order term is just getting them bigger and stronger
- But you have to do that in a mindful way that doesn’t cause injury along the way, but you don’t necessarily have to micromanage every other little detail of their movement patterns

## Should you lift weights before or after a cardio session? [24:00]

**Peter mentioned previously that he normally will lift weights AFTER cardio on days that he does both strength and cardio**

*Why is that? Are you worried about glycogen stores? Do you ever switch it up and lift before cardio?*

*What’s your rationale for that and how should people think about that based on what you’re choosing?*

- Contrary to popular belief, there is really not much of a difference about which of these you do
- Multiple meta-analyses show that for the vast majority of people, there is no interference effect of lifting and cardio, but for some subsets, there may be a small effect on hypertrophy.
  - Studies: [Eddens 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5752732/), [Lundberg 2022](https://link.springer.com/article/10.1007/s40279-022-01688-x), [Schuman 2021](https://link.springer.com/article/10.1007/s40279-021-01587-7), [Petre 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8053170/)

*Talking about Peter’s personal strategy about lifting after cardio…*

- He first points out a few caveats
- 1) There’s only one day a week where he’s doing a lift and a cardio session on the same day
  - He’ll do an hour of Zone 2 and an hour and a half of lifting (always in that order)
  - Zone 2 is first thing in the morning, and then sometimes in the afternoon he’s doing weights
- 2) It’s also important to know that’s always an **upper body** lift
  - In short, he’s not really going into the gym with any level of fatigue, because first of all, it’s a Zone 2 workout so by definition, that shouldn’t be taxing the living hell out of you
  - Additionally, he almost always does Zone 2 on a bike, so if anything it is just his *lower body* that may a little bit depleted

*What would happen if he did lift lower body after a tough cardio workout?*

- On Sunday, for example, he will do Zone 2 followed by a VO2 max, so that’s a day that smokes his lower body
- If he went out a did a lower body lift immediately following that, there’s no doubt it would compromise the lift—therefore he would likely not get as strong (or as much hypertrophy) because he would be going into the workout compromised
- So you have to basically ask the question, “*Which master are you trying to please?*” and use some common sense

***What about insanely high level athletes?***

- When Peter trained at a really high level, he would always do the thing that mattered most first.
- So when he was a swimmer, he would never lift before a swim workout (“and there were at least three days a week when I had to do both on top of each other, just based on my schedule”)
- It would never occur to him to go in the gym and lift and then jump in the pool for a 90-minute workout
- Instead, it would always be: crush that 90-minute workout and then go to the gym, and whatever you have left over, you’re going to put in the weight room
- And did those exercises suffer a little bit? ⇒ “*Of course, they did, but I’m prioritizing the event that which I was training for, which was the swim*.”

> “If you have the luxury, as I do, of exercising every day, you have plenty of time to do both. You don’t really have to double.” —Peter Attia

## Heart rate recovery: defining heart rate recovery and how it relates to cardiovascular fitness [28:45]

**Heart rate recovery (HRR) questions**: *What is it? Is it important? What’s a “good” heart rate recovery?*

**Defining HRR**

- As its name suggests, it’s the rate at which your heart rate comes down from a high level of exertion

The [original study](https://www.nejm.org/doi/10.1056/NEJM199910283411804?url_ver=Z39.88-2003) was done more than 20 years ago

- The study used something called a Bruce protocol (one of the manners that is used to stress people for a cardiac stress test)
- They took 2,400 patients and put them through a Bruce protocol, which means they ran them until they were symptomatic (out of breath, having EKG changes, or chest pain, etc.)
- What they measured was, “What is your heart rate at the peak level you’re at? And then what is it one minute later following an active recovery?”
- The active recovery was walking very slowly, 1.5 miles an hour at a very slight grade, 2.5%, which is almost a negligible grade
- They followed these people for six years
- The average age of these folks was 57 years plus or minus a decade

What this study found:

- A very strong relationship between subsequent risk of death, all-cause death and heart rate recovery
- The more your heart rate was able to recover, the greater number of absolute beats you were able to drop, the lower your odds were of dying
- So people who had abnormally low heart rate recovery, defined as less than 12 beats in the minute, were at the highest risk
- And anything beyond 25 to 30 beats per minute recovery in a minute was considered excellent.

![](https://peterattiamd.com/wp-content/uploads/2023/07/f1-ama49.png)

**Figure 1. Relative risk of death vs. HRR.** Credit: [Cole et al., 1999](https://www.nejm.org/doi/10.1056/NEJM199910283411804?url_ver=Z39.88-2003)

- on the Y axis is the relative risk
- on the X axis is the heart rate recovery
- For about every nine-beat-per-minute improvement in heart rate recovery, you’re going to see approximately a twofold reduction in the risk of death
- You just don’t see many things in human biology with hazard ratios so big where you’re just taking sequential 2X jumps in improved risk or reduction of risk than something like this
- And again, this is all-cause mortality which is just an enormous predictor

*The question is, Why?*

- The best explanation here is that heart rate recovery is really an assessment of your autonomic nervous system
- We know that a dysfunctional autonomic nervous system, especially an autonomic nervous system that can’t fire the parasympathetic system, it can’t do the resting part of the system, this is going to be manifested by:
  - a higher resting heart rate
  - a lower heart rate variability
  - and of course, a lower heart rate recovery
- In many ways, heart rate recovery is the bridge between the activation of the sympathetic system, which is important
- You do need to be able to fire up the cardiovascular system on demand, but you have to be able to relax it when that demand is pulled away

**Using HRR as a metric with patients**

- In the past six months, Peter and team have started using heart rate recovery as one of the things they pay much closer attention to in patients
- They pay attention to these other things like resting heart rate very much, but this is now another metric that we think is very important

**HRR can be improved**

- The good news is this can be trained
- This is not something where your genes are set in stone and you’re stuck with what you’re stuck with
- When Peter sees patients that come in incredibly deconditioned, they have high resting heart rates and they have horrible heart rate recoveries, and as they train, those things get better

## How to measure heart rate recovery, and what is considered a “good” heart rate recovery [33:15]

***When should people be measuring and testing their heart rate recovery after what type of intensity?***

- This needs to be very high intensity—close to peak heart rate
- Think of this as like an elastic band: “*How much elasticity is in the system? How much recoil is in the band?*”
  - If you really want to know how much recoil is in the rubber band, you got to actually pull the rubber band and pulling the rubber band to its reasonable limit is your max heart rate or close to it
  - what you’re looking for is how much from that peak does it return to another length
  - if it’s a rubber band that has very poor elasticity, you’re going to pull it out and it’s not going to come then that much
  - you want to make sure you at least stress the system enough and get that heart rate to 90 to 95% of your maximum before you do this test
- Now, if you take people who are lower fitness, you don’t need to push them that hard either
  - The fitter a person is the closer you need to go to maximum heart rate
  - But if you take a person who’s deconditioned, we just go to about 85 or 90% of predicted heart rate max and test them there
  - That’s generally a safer place to do it, and frankly, it’s less painful.
- The data would suggest that you can also do this at 30 seconds to 2 minutes, and you just have to adjust your parameters for what you’re looking for

**What’s a ‘good heart rate recovery’? And ways to measure it? [35:45]**

*Is judging a good heart rate recovery something where you want to see it drop down below a certain number?*

*Is it percentages?*

*How should people who are now going to go measure maybe after a VO2 workout, Zone 5 workout, how should they measure it and what should they look for?*

- You’re actually NOT looking for a percent or threshold
- You’re looking for an **absolute** number of beats per minute.
- And you can’t really do this without a heart rate monitor
- Wrist-based monitors are inferior and not worth doing (i.e., sports watches are not sufficient)
- You need a chest strap heart rate monitor (gold standard) and/or a forearm band (almost as good if you have a good one and you set it up right)

Let’s go back to what we know

- If after 1 minute of reaching your max HR (or close to), you’re not able to recover 15 beats per minute, there’s a problem
- In other words, if your max heart rate is 160 and you go into a very easy active recovery (go from sprinting to walking slowly) and you can’t get from 150 to at least 135, definitely there’s a problem
- when you look at the [data](https://www.nejm.org/doi/10.1056/NEJM199910283411804?url_ver=Z39.88-2003), the lowest risk (the top 20% of people) are getting in the range of 30 to 50 beats per minute within a minute

***More data on HRR***

- If you’re looking at different recovery windows, say a two-minute recovery instead of a one-minute recovery, we obviously would expect a much higher heart rate recovery
- The top 25% of people are going to be able to get about 59 beats per minute for a 2 minute recovery window
  - This is in a population of people who were average aged 45
- The top 25% at one minute found 23 beats per minute of recovery
  - These people were 57—so this does start to trail off a little bit with age.

[The Framingham Offspring Study](https://pubmed.ncbi.nlm.nih.gov/12372572/)

- This study measured heart rate recovery after submaximal treadmill exercise testing (this is not quite a Bruce protocol, but this is pushing people very hard)
- They were pushed to 85% of age and sex-predicted maximal heart rate

\*Side note\*

- For different people, 85% feels very different.
- Peter says, “So personally, I’m not a huge fan of submaximal tests in me because 85% of my acquired or realized max heart rate is not that strenuous to me”
- “So I go through a lot of pain once I hit about 90% or 86% of max heart rate and then I quickly get into a lot of pain”
- “But for some reason I’m not in that much pain at 85% of max, but I have a very low max heart rate. So that’s probably why.”

In this [study](https://pubmed.ncbi.nlm.nih.gov/12372572/),

- They looked at people who were middle-aged, 43 plus or minus 10
- They went to this submaximal effort at 85%
- They measured one minute postexercise and the top quintile here, so the top 20%, were associated with a 46% lower risk of cardiovascular events and a 39% lower risk of cerebral vascular events compared to all else, meaning the other 80%.
- What were those numbers?
  - for men, that was in one minute, a 46-beat-per-minute recovery
  - For women, 47 beats per minute recovery at one minute
  - Pretty high recoveries, because remember, that spring or that elastic band wasn’t pulled intensely, 85% is not 95%.

**The takeaway**

- Heart rate recovery is very highly associated with mortality, probably as a really good proxy for autonomic function or dysfunction
- It can be measured at one minute or two minutes and it can be improved significantly with regular exercise
- “*[Heart rate recovery] is one of the metrics that we should care about just as we care about VO2 max and just as we care about resting heart rate*.”

## How kidney health and function typically measured [42:30]

**Kidney function**

- The kidney in many ways, along with the liver, are unsung heroes that don’t get enough attention
- They are miraculous pieces of physiology and when they go wrong, it’s a disaster
- Your kidneys are these two little tiny things that, directionally, probably weigh 2% of your total body weight
- Yet, each time your heart beats, 20 to 25% of that blood is going to the kidneys and they are filtering everything that are bad for us
- Most importantly, they are regulating our balance of water and our balance of electrolytes
- The glomerulus is the unit of the kidney that is responsible for this filtration
- Blood enters and exits glomerular unit, but what happens while the blood is in that glomerular unit is a lot of movement of water and and electrolytes like sodium, potassium, magnesium, etc.
- To estimate or measure this, the glomerular filtration rate is the functional unit of the kidney
- Just as if we were measuring the functional capacity of your heart, we would look at ejection fraction. We would look at how much blood can the heart pump every time it beats or what fraction of the blood and we could take that to something called cardiac output, so how fast can it beat and what does it eject each time
- When it comes to the lungs, if we want to understand the function, we look at things like pulmonary function tests. We look at how much air can the lungs expel, what’s the speed at which they can expel and we also look at gas exchange parameters
- And when it comes to the kidney, we want to understand how this **glomerulus** is working

**Measuring kidney function**

- Now to measure the glomerular filtration rate is very difficult, it requires using radioisotopes and so we’re not going to talk about that
- What we are going to talk about is how can you **estimate** the glomerular filtration rate (eGFR)
- If you get a lab blood test done, you should be able to find your eGFR on there if the right blood tests have been ordered
- The first way and the most common way that this is measured is using something called creatinine
- If you have a basic metabolic panel or a complete metabolic panel, you may notice something that says CR
- CR is short for creatinine and creatinine is a breakdown product of creatine phosphate
- Creatine phosphate is something that is a very important part of energy demand in a very, very short time
- We talk about these two energy systems that people are quite well aware of, the aerobic and anaerobic system or the oxidative and phosphorylated system, but we often forget the creatine phosphate system as well
- Creatine is a molecule that is a phosphate donor and it plays a very important role in phosphate liberation during explosive short, quick movements
- Creatine as a supplement
- Peter takes creatine monohydrate supplement (5g) every day and that creates more of a pool for his phosphate donation
- Creatine phosphate is absolutely associated with a slight improvement in physical performance and cognitive performance
- In any case, creatinine levels are being produced by the body and you’re excreting it
- if your kidneys are not functioning well, it excretes less creatinine, and therefore, creatinine accumulates in your blood

**In summary**: when we measure creatinine in the blood, we’re getting a decent indication of your kidney function, because the higher the creatinine, the less is being filtered, therefore, we estimate your GFR to be lower

## Differentiating between creatine and creatinine [48:15]

- Creatinine and creatine are two similar words often confused.
- Creatine is predominantly found in muscular tissue and is involved in energy metabolism.
  - We take creatine supplements to help our muscles and this muscular creatine and phosphocreatine go back and forth quickly—the phosphocreatine donates its phosphate, it quickly gets reshuffled back to creatine
  - The reason we supplement creatine is to create a bigger pool to have more phosphate donors

![](https://peterattiamd.com/wp-content/uploads/2023/07/f2-ama49.png)

**Figure 2. Major routes of Creatine (Cr) metabolism. Most (up to 94%) of Cr is found in muscular tissues. The muscular Cr and PCr (phosphocreatine) are nonenzymatically converted at an almost steady rate (∼2% of total Cr per day) to creatinine (Crn), which diffuses out of the cells and is excreted by the kidneys into the urine. Because the amount of creatinine generated is relatively constant, serum creatinine levels in the blood can indicate abnormal kidney function but may give incorrect estimates in patients with higher amounts of muscle mass who exercise, or patients with sarcopenia.** Credit: [Wyss et al., 2000](https://journals.physiology.org/doi/full/10.1152/physrev.2000.80.3.1107)

- A small amount of creatine and phosphocreatine gets converted to creatinine (like 2% per day), which is excreted by the kidneys in urine.
  - If your kidneys are working well, you’re getting rid of it. If your kidneys are not working well, you’re accumulating it
- And because the amount of creatinine generated from creatine is relatively constant, serum creatinine levels can indicate kidney function, but it can be influenced by various factors.

![](https://peterattiamd.com/wp-content/uploads/2023/07/f3-ama49.png)

**Figure 3. CKD-EPI Creatinine Equation (2021).** Credit: [kidney.org](https://www.kidney.org/content/ckd-epi-creatinine-equation-2021)

- It’s important to do what’s called a sensitivity analysis, which is something you always want to do with an equation
  - So if the equation says, “A is equal to a function of X. Plug in a value for X
  - Now change the value for X by 5% and run the equation again and see how much A changed
    - Did A change by 5%? Did it change by 1%? Did it change by 20%?”
  - in other words, “Is this function amplifying or dampening the effect of X on A?
- When you do this, you realize that your EGFR, this estimated GFR, is quite sensitive to the serum creatinine level
  - As such, if your creatinine level is variable for reasons beyond kidney function, it basically becomes a measure where you can be misled
- This is a long-winded way of saying “we do not rely on creatinine at all for our estimates of GFR”
- A basic metabolic panel will tell you CR and your eGFR, but Peter ignores this

**Examples of how CR levels and eGFR numbers can mislead**

- It tends to really overestimate renal function
- A patient who really, really lacks muscle mass or someone on a really low protein diet who has very low muscle mass will actually have an artificially low creatinine level
- More commonly, people with lots of muscle mass, people who exercise a lot, so therefore they have more creatinine, you get a higher level of serum creatinine and so their GFR looks significantly worse than it is

## The cystatin C blood test as a practical way to assess kidney health [52:45]

**Cystatin C blood test**

- As an outpatient, the blood test that’s available to anybody and everybody is something called a cystatin C

But first, let’s restate the problem here:

- creatinine (CR) is used because it’s very cheap and it makes sense theoretically and for some people it’s accurate
- But there are too many edge cases: high muscle mass athletes, low muscle mass sarcopenia, high protein, low-protein diets

And it’s worth pointing out: it’s unclear if creatine supplementation affects creatinine levels significantly

- Especially the way people take it today because most people today don’t do a loading dose of creatine (which was common years ago)
- So we really don’t think five grams a day is enough to move the needle

**Back to the cystatin C test**

- Cystatin C is a protein secreted by most cells in the body at a constant rate
- Just like a creatinine, cystatin C gets filtered in the glomerulus
- Once it gets filtered out via the blood, it’s reabsorbed and destroyed by the renal cells, so a little bit of it ends up in the urine
- Blood levels of cystatin C are a reasonable approximation for GFR because there’s a constant rate of production and a variable rate of elimination depending on filtration rate
- Why it’s a better proxy than CR is that cystatin C doesn’t really change with musculature or diet or any of these other factors.
- About six or seven years ago, Peter just completely abandoned creatinine as a manner in which he tracked eGFR and now he using cystatin C
- \*Side note about race/ethnicity: race plays a significant role in eGFR when using creatinine—African American versus non-African American has a completely different adjustment or different formula for eGFR based on creatinine levels (That’s not the case with cystatin C)
- With cystatin C, it doesn’t matter your age, race, sex, muscle mass levels, protein consumption, etc.

***Why isn’t everyone using cystatin C over CR if it’s such a better measure?***

It’s a combination of several factors, says Peter

First, a lot of people just don’t know the difference

- People aren’t necessarily aware of how limited creatinine is and how much it’s influenced by these other factors
- So a person whose creatinine is 1.2 might look like they have a GFR of 64 when in reality, by cystatin C, their GFR is actually 95
- That’s a very common scenario and it might be that most people think, “Well, whether you’re 64 or 95, it’s ‘normal.’ So who cares?”
  - In a moment we’re going to discuss why that’s not the case. A GFR of 65, depending on your age, may not be normal even though it’s technically not into what we call “chronic renal insufficiency”

Secondly, cost plays a role

- There’s no question it’s cheaper to get a creatinine—you basically are getting CR for free with a basic metabolic panel or it’s $1-$5 as a standalone
- Conversely, cystatin C does not come with a standard test, and a standalone is about $4-$17
- Both are cheap though, so this might not be a big factor

Third reason: The kidney doesn’t get enough attention until people are in real trouble

- People assume that there’s two states of kidneys, which is, “It’s all fine,” and, “Oh boy, you need to see a nephrologist.”
- In reality, we need to think about the kidneys in a much longer timeframe and start asking the question, “How good do we expect your kidney function to be for a given age, given that we know it’s going to decline with age?”
- The same way we think of apoB exposure: If a person has a very high apoB in early life, it’s not as much of an issue as if they have it in midlife where they’ve had a chance to accumulate more damage as a result. So there’s an inevitability of decline.
- Similarly
  - You want a very high VO2 max when you’re young
  - You want high strength when you’re young
  - You want high muscle mass when you’re young
  - All these things will naturally decline with age

> “You want to have a reserve of kidney function as you plan for a long life.” —Peter Attia

## How kidney function impacts lifespan and the five stages of kidney disease [59:15]

***How does kidney function also affect lifespan? What do we know about that and the levels it should be at?***

First point:

- A young healthy adult, below age 50, should have an eGFR of at least 90
- Now, what’s going to happen? ⇒ It’s going to steadily decrease somewhere between 6 and 10 units per decade starting in your fifth decade
- For example, if a completely healthy person has an eGFR of 100 when they’re 40 years old, it could be as low as 60 by the time they’re 80 years old

Secondly:

- People do not describe it as chronic kidney disease until the GFR falls below 60
- But this is why you should be concerned if a 40-year-old has an eGFR of 80
- That 40 year old is likely to have problems as he ages

![](https://peterattiamd.com/wp-content/uploads/2023/07/f4-ama49-1024x388.png)

**Figure 4. For Caucasian men, the average GFR in the elderly might be diagnosed as CKD, but is simply a response to aging.** Credit: [Wetzels et al., 2007](https://www.kidney-international.org/article/S0085-2538(15)52697-5/fulltext)

\*\*\*

**There are five stages of kidney disease**

Stage 1

- A GFR above 90, but with other signs of kidney damage, the most common of which is protein in the urine
  - Once a year, Peter will do a test on patients where they measure the amount of protein in the cup of urine
  - Protein in the urine is a sign that the kidney’s not working well
  - It’s breaking down because protein should not be coming out in your urine at all , so if it is, there’s a problem

Stage 2

- A GFR of 60 to 89 combined with protein in the urine

*How concerned should someone be?*

- That depends largely with age
- if you have somebody with a GFR of 65 and they’re 30, that’s a four alarm fire
- If you have somebody with a GFR of 65 who’s 90, we would be high-fiving them
- what you do in these stages is really look for causes and get after them as quickly as possible

Stage 3

- This is where you start to get into what’s called chronic kidney disease (CKD)
- A GFR between 30 and 59
- At this point, you have to start restricting protein intake
- You also have to start paying attention to things that people with a higher GFR take for granted
  - For example, if you got a CT scan, you would have to be very careful about the use of iodine-based contrasts.
  - You would also have to be very careful about hydration status and things of that nature

Stage 4

- When GFR is between 15-29
- At this point, a patient has severe kidney damage
- They have to be under the very close care of a nephrologist
- they have to be completely mindful of any medication or supplement they take
- They’re going to be on a low protein diet at this point
- Not only would they not be able to use iodine contrast in a CT scan, you wouldn’t even be able to use something like gadolinium, which is nowhere near as toxic for an MRI

Stage 5

- GFR under 15
- At this point, a patient is going to require dialysis, and depending on their age and other health metrics, will be placed on the transplant waiting list

Additional points:

- Any doctor, if they see a person whose GFR is below 30, is going to be alarmed and take action and get that patient to a nephrologist
- “*What amazes me is how many times we see patients in the 40s and 50s and even 60s if they’re not very old and we think, “Eh, yeah, it’s fine,” and in reality, it’s not fine*.” says Peter

**How deadly is stage 4 or 5 of kidney disease [1:05:15]**

It’s staggeringly deadly, says Peter

Two stats:

- 1) if you look at the mortality associated with chronic kidney disease, it’s actually the [sixth leading cause](https://pubmed.ncbi.nlm.nih.gov/19641489/) of death in the United States—it kills nearly 4% of people
- 2) Another much more shocking [statistic](https://pubmed.ncbi.nlm.nih.gov/19641489/): The risk of death in the next year for a 20-year-old who’s receiving dialysis is the same as that of the average 80-year-old

**What leads to kidney transplants?**

- This is an especially dangerous place to be, and fortunately, kidney transplantation saves the lives of many
- But nevertheless, remember, when a person receives an organ transplant, they’re still on a lifetime of immunosuppressive meds, which renders them susceptible to other medical complications
- Furthermore, you have to ask, “Why is the person getting the kidney transplant?”
  - Now, sometimes the reason, especially if it’s a 20-year-old, when they’re getting a kidney transplant, it’s usually because of a disease that attack the kidney.
  - But as we get older and older, it becomes more of an issue
    - In other words, the mortality goes up because the underlying condition is less likely to be, say, an autoimmune disease and more likely to be hypertension and diabetes, which are the two biggest diseases that take a toll on the kidney.
    - In the case of hypertension and diabetes, even if you rescue the patient with an organ transplant, you still have to address the underlying thing that was leading to the kidney damage in the first place

## Slowing the decline of kidney function [1:08:15]

***How can one increase, or slow the decline, of kidney function?***

There are several things that lead to an acute reduction of GFR that are entirely reversible

- One example would be patients who are given a drug that is nephrotoxic toxic to the kidney
  - You would usually notice this because their creatinine would start to rise
  - The answer is you stop the drug
- Another example of very reversible kidney damage is in the case of rhabdomyolysis (rhabdo)
  - You would see patient goes out and runs a marathon, doesn’t hydrate properly and the breakdown of muscle is so significant that it basically overwhelms the kidneys and they end up in acute renal failure
  - But with enough IV fluid and supportive care, a lot of times those patients get fully, fully better

Kidney damage is much less reversible in cases of chronic renal insufficiency related to hypertension/diabetes

- That said, there’s one [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3862566/) that looked at patients with chronic renal insufficiency and 15% of those patients were able to show some improvements in GFR
  - But the improvement is quite slow which is better than a decline, of course
- However, Peter doesn’t want people to hear that and think “Well, it’s okay. I can wait until my GFR is 30 before I think about it.”
- No, you want to take the posture here that this is a one-way street, even though it’s not fully a one-way street
- And therefore, when Peter sees a patient who’s in their 40s and their GFR is in the 60s, he is very alarmed because he’s not assuming he’s going to get it higher, but we have to stop whatever it is that’s driving this precipitous decline that is age inappropriate
- And the two most common things that we’re looking at here are **blood pressure** and **glycemic control**

## The main drivers of kidney disease [1:11:15]

**How prevalent is chronic kidney disease?**

- Chronic kidney disease is indeed an epidemic
- The CDC [estimates](https://www.cdc.gov/kidneydisease/publications-resources/ckd-national-facts.html) that about 15% of US adults have some level of chronic kidney disease
- Most tragically, a lot of these people ([as many as 9 out of 10](https://www.cdc.gov/kidneydisease/publications-resources/ckd-national-facts.html)) don’t know it
- It’s sort of similar with what the drivers of the disease are—most people aren’t really aware of their hypertension unfortunately

**Drivers of kidney disease**

- The two leading causes of chronic kidney disease in the US are high blood pressure and metabolic dysfunction/insulin resistance/type 2 diabetes
  - Diabetes is the driver of about [30 to 50% of chronic kidney disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7068620/#:~:text=Globally%2C%20common%20causes%20of%20CKD,for%20early%20identification%20and%20treatment.) and that’s true worldwide
  - Hypertension probably accounts for [25 to 30%](https://www.ahajournals.org/cgi/doi/10.1161/HYPERTENSIONAHA.110.150722) of it
  - So together, essentially 70% of chronic kidney disease is explained by hypertension and type 2 diabetes or glucose dysregulation on the way to type 2 diabetes
- The rest of the causes, the other 30% of causes of chronic kidney disease, are basically a grab bag of different diseases
  - Certainly autoimmune inflammatory diseases like either autoimmune diseases like lupus or inflammatory diseases called glomerular nephritis or glomerular nephritis
  - Also, while less common in the US, but there are certain parasitic infections that can cause damage
  - Furthermore, on at least three occasions, Peter has seen patients who have damaged their kidneys using herbal remedies of sorts
    - You’ve got to really be careful with unregulated supplements

## The importance of managing homocysteine levels for brain health [1:14:00]

See AMA about brain health: [AMA #46](https://peterattiamd.com/ama46/)

\*\*\*

**Homocysteine and brain health**

[VITACOG Study](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0012244)

- This study asked the question of: “What happens if you give patients who have early MCI, so mild cognitive impairment, high doses of B vitamins to lower homocysteine? Does that have an effect on the brain?”
- Study had about 168 people that were over 70 years of age with mild cognitive impairment, split equally between treatment and placebo
- Treatment was given high doses of B vitamins—800 micrograms a day of folic acid and 500 micrograms a day of B12, along with 20 milligrams per day of B6
- For what it’s worth, Peter typically gives patients a little bit more than that to the tune of 25 to 50 mg of B6 (depending on homocysteine) and they start at about that level of folic acid as well
  - Peter prefers the brand called [Jarrow](https://jarrow.com/) which is combined methyl folate, methyl-B12
- The study results showed a dose dependence to this as well—the greater the improvement, i.e. reduction in homocysteine, the greater the reduction in the rate of atrophy in the subjects
- The top quartile of patients were those with the highest rate of atrophy were people that had a homocysteine level above 13 micromole per liter

What is Peter’s cutoff for homocysteine in patients?

- Peter is pretty aggressive — he wants to see patients below nine for a homocysteine level
- And Peter uses the methylated B vitamins plus B6 in an unmethylated format to get patients to nine in as much as they’re able to be compliant with the medication

**Managing homocysteine levels as it relates to cardiovascular disease [1:18:15]**

In addition to monitoring homocysteine levels for the brain, there is some benefits as it relates to cardiovascular disease as well

- There are these two molecules called ADMA and SDMA (asymmetric or symmetric dimethylarginine)
  - They’re derivatives of L-arginine and they’re metabolic byproducts of continual protein modification
- Now, ADMA directly and SDMA indirectly inhibit an enzyme called nitric oxide synthase
  - So ADMA directly inhibits the endothelial nitric oxide synthase in the endothelium
  - SDMA competes with intracellular absorption of the nitric oxide precursor arginine, which then results indirectly in a decreased nitric oxide production via intracellular deficiency of arginine
- The point here is homocysteine inhibits an enzyme that degrades ADMA, so it causes ADMA to accumulate in the cell
- W*hy is this a problem*?
- Because nitric oxide is one of the most important molecules as it pertains to endothelial function
- In fact, it’s so important, actually the elucidation of this resulted in the awarding of a [Nobel Prize](https://www.ahajournals.org/doi/10.1161/01.cir.98.22.2365)
- So we understand the importance of nitric oxide for vascular health and anything that impairs nitric oxide is generally going to be bad for vascular health
- So again, the chain of events is an enzyme called nitric oxide synthase converts arginine to nitric oxide and ADMA directly inhibits that process, SDMA indirectly inhibits it and homocysteine impairs the breakdown of ADMA.
- Peter used to measure ADMA and SDMA in all of his patients, but now he is just measuring homocysteine level and trying to keep them as low as possible

## The relationship between alcohol consumption and brain health [1:21:30]

***Is there a recommended amount of alcohol consumption that’s good for brain health?***

- This is unequivocally clear: there is no amount of alcohol that is beneficial to the brain

Peter admits that the portion of the previous AMA on this topic may not have been clear enough

- His goal was to present all the data in a non-biased way, including the epidemiology that said, “Hey, low alcohol consumption,” which they defined as one to two drinks per day, “isn’t that bad.”
- That said, these studies have so much in the way of confounding factors between the non-consumers and the low consumers, that it’s very easy to explain why these studies exist
- These studies, despite their attempts to correct for socioeconomic status, levels of education, access to better healthcare, better dietary patterns, social constructs, so people who drink in social settings versus those who don’t, all of these things become very difficult to correct for and they create a lot of noise in the low-resolution state where you have relatively minor changes
- On the other hand, the epidemiologic studies make it crystal clear that if you’re drinking five drinks a day, your health is going to hell in a hand basket, however, epidemiology is far, far too blunt a tool to offer any meaningful insight at these low levels of alcohol consumption (i.e., never drinker vs a few drinks a week)

So instead, we look at things that like the Mendelian randomizations and other mechanistic studies

- And the short answer is basically that even moderate levels of alcohol consumption are indeed [associated](https://www.bmj.com/content/357/bmj.j2353) with adverse brain outcomes and that includes hippocampal atrophy
- In other words, there’s no protective effect of light drinking, i.e. somewhere between one and four drinks a week when compared to complete abstinence
- Peter’s only argument was that the destruction of your brain is relatively minor at one to four drinks per week, and therefore, one has to just decide, “*We’re trying to balance between lifespan and healthspan. And part of health span might be enjoying the occasional drink*.”

§

## Selected Links / Related Material

**Episode of The Drive with Ethan Weiss**: [#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.](https://peterattiamd.com/ethanweiss2/) | Peter Attia (peterattiamd.com) [3:15]

**AMA episode of The Drive about blood pressure**: [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/) | Peter Attia (peterattiamd.com) [3:15]

**AMA episode of The Drive about brain health**: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) | Peter Attia (peterattiamd.com) [4:00, 1:14:00, 1:21:30]

**Episode of The Drive discussing rucking**: [4:30]

- *Episode with Michael Easter*: [#225 ‒ The comfort crisis, doing hard things, rucking, and more | Michael Easter, MA](https://peterattiamd.com/michaeleaster/) | Peter Attia (peterattiamd.com)
- *AMA episode*: [#223 – AMA #39: The Centenarian Decathlon, zone 2, VO2 max, and more](https://peterattiamd.com/ama39/) | Peter Attia (peterattiamd.com)

**GORUCK pack for rucking**: [goruck.com](https://www.goruck.com/?utm_source=google&utm_medium=cpc&utm_term=&utm_campaign=17932761006&utm_content=&pos=&gclid=Cj0KCQjwtO-kBhDIARIsAL6LorfaZ513DmADQG0w8aTLad2B8evnth_0PaHKNfUP1updXqwGPHWUdEIaAnR1EALw_wcB) [8:30]

**Episode of The Drive with Irene Davis where they discussed minimalist shoes**: [#128 – Irene Davis, Ph.D.: Evolution of the foot, running injuries, and minimalist shoes](https://peterattiamd.com/irenedavis/) | Peter Attia (peterattiamd.com) [8:45]

**Episodes of The Drive with Andy Galpin where they discussed how different people have different body types**: [18:30]

- [#239 ‒ The science of strength, muscle, and training for longevity | Andy Galpin, Ph.D. (PART I)](https://peterattiamd.com/andygalpin/) | Peter Attia (peterattiamd.com)
- [#250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)](https://peterattiamd.com/andygalpin2/) | Peter Attia (peterattiamd.com)

**Episodes of The Drive discussed body composition including FFMI and ALMI**: [22:00]

- [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com)
- [#242 – AMA #44: Peter’s historical changes in body composition with his evolving dietary, fasting, and training protocols](https://peterattiamd.com/ama44/) | Peter Attia (peterattiamd.com)

**Meta-analyses that demonstrate that, outside of a little bit of a difference in hypertrophy, there’s no real interference of cardio on lifting weights**: [24:30]

- [The Role of Intra-Session Exercise Sequence in the Interference Effect: A Systematic Review with Meta-Analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5752732/) (Eddens et al., 2018)
- [The Effects of Concurrent Aerobic and Strength Training on Muscle Fiber Hypertrophy: A Systematic Review and Meta-Analysis](https://link.springer.com/article/10.1007/s40279-022-01688-x) (Lundberg et al., 2022)
- [Compatibility of Concurrent Aerobic and Strength Training for Skeletal Muscle Size and Function: An Updated Systematic Review and Meta-Analysis](https://link.springer.com/article/10.1007/s40279-021-01587-7) (Schumann et al., 2021)
- [Development of Maximal Dynamic Strength During Concurrent Resistance and Endurance Training in Untrained, Moderately Trained, and Trained Individuals: A Systematic Review and Meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8053170/) (Petré et al., 2021)

**The original study on heart rate recovery**: [Heart-Rate Recovery Immediately after Exercise as a Predictor of Mortality](https://www.nejm.org/doi/10.1056/NEJM199910283411804?url_ver=Z39.88-2003) (Cole et al., 1999) [29:00, 34:30, 37:45]

**The Framingham Offspring Study which measured heart rate recovery in middle aged subjects and looked at mortality data**: [Heart rate recovery after treadmill exercise testing and risk of cardiovascular disease events (The Framingham Heart Study)](https://pubmed.ncbi.nlm.nih.gov/12372572/) (Morshedi-Meibodi et al., 2002) [40:00]

**Episode of The Drive with Layne Norton where they discussed creatine as a supplement**: [#235 ‒ Training principles for mass and strength, changing views on nutrition, creatine supplementation, and more | Layne Norton, Ph.D.](https://peterattiamd.com/laynenorton3/) | Peter Attia (peterattiamd.com) [47:15]

**Chronic kidney disease is the sixth leading cause of death in the United States**: [Public health consequences of chronic kidney disease](https://pubmed.ncbi.nlm.nih.gov/19641489/) (Weiner et al., 2009) [1:05:30]

**The risk of death for a 20-year-old who’s receiving dialysis is the same as that of the average 80-year-old**: [Public health consequences of chronic kidney disease](https://pubmed.ncbi.nlm.nih.gov/19641489/) (Weiner et al., 2009) [1:05:45]

**Study that looked at patients with chronic renal insufficiency and 15% of those patients were able to show some improvements in GFR**: [Renal Function Can Improve at Any Stage of Chronic Kidney Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3862566/) (Weis et al., 2013) [1:10:00]

**The CDC estimates that about 15% of US adults have some level of chronic kidney disease**: [Chronic Kidney Disease in the United States, 2023](https://www.cdc.gov/kidneydisease/publications-resources/ckd-national-facts.html) | (cdc.gov) [1:11:15]

**Diabetes is the driver of about 30 to 50% of CKD**: [Prevalence of Chronic Kidney Disease and Associated Factors among Patients with Diabetes in Northwest Ethiopia: A Hospital-Based Cross-Sectional Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7068620/#:~:text=Globally%2C%20common%20causes%20of%20CKD,for%20early%20identification%20and%20treatment.) (Alemu et al., 2020) [1:11:45]

**Hypertension likely accounts for 25 to 30% of CKD**: [Prevalence of Chronic Kidney Disease in Persons With Undiagnosed or Prehypertension in the United States](https://www.ahajournals.org/cgi/doi/10.1161/HYPERTENSIONAHA.110.150722) (Crews et al., 2010) [1:11:45]

**VITACOG Study that asked the question, “*****What happens if you give patients who have early MCI, so mild cognitive impairment, high doses of B vitamins to lower homocysteine?*****”**: [Homocysteine-Lowering by B Vitamins Slows the Rate of Accelerated Brain Atrophy in Mild Cognitive Impairment: A Randomized Controlled Trial](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0012244) (Smith et al., 2010) [1:15:15]

**The elucidation of nitric oxide as one of the most important molecules as it pertains to endothelial function resulted in the awarding of a Nobel Prize**: [Nobel Prize Awarded to Scientists for Nitric Oxide Discoveries](https://www.ahajournals.org/doi/10.1161/01.cir.98.22.2365) (Ruth SoRelle, 1998) [1:19:45]

**A 2017 prospective study in BMJ found over a 30-year follow-up period that alcohol, even when consumed at moderate levels was associated with adverse brain outcomes, including hippocampal atrophy**: [Moderate alcohol consumption as risk factor for adverse brain outcomes and cognitive decline: longitudinal cohort study](https://www.bmj.com/content/357/bmj.j2353) (Topiwala et al., 2017) [1:23:45]

§

## People Mentioned

- [Ethan Weiss](https://profiles.ucsf.edu/ethan.weiss) [3:15]
- [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [4:30]
- [Irene Davis](https://twitter.com/IreneSDavis) [8:45]
- [Jake Muise](https://mauinuivenison.com/pages/about-us) [11:00]
- [Andy Galpin](https://www.andygalpin.com/our-team) [18:30]
- [Layne Norton](https://www.instagram.com/biolayne/?hl=en) [47:15]

§