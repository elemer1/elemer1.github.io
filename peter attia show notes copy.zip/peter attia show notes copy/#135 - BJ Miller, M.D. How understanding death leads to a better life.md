# #135 – BJ Miller, M.D.: How understanding death leads to a better life

**Source:** [https://peterattiamd.com/bjmiller/](https://peterattiamd.com/bjmiller/)

---

BJ Miller is a hospice and palliative care specialist on a quest to reframe our relationship with death. In this episode, BJ begins with how his own brush with death radically shifted his perspective and ultimately forged his path towards palliative care and helping patients integrate and understand their life in a meaningful way. BJ recounts several moving stories from his patients, which reveal important lessons about overcoming the fear of death, letting go of regret, and what’s most important in life. He discusses the major design flaws of a “death phobic” healthcare system. Furthermore, he makes the case that seeing death as a part of life allows us to live well, as opposed to living to evade death itself. He concludes with a discussion around physician-assisted death as well as his hopes around the use of psychedelics to reduce suffering in end-of-life care.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/bjmiller/the_Drive_public.png)

Play

#135 - BJ Miller, M.D.: How understanding death leads to a better life

#135 - BJ Miller, M.D.: How understanding death leads to a better life

1x15s30s

0:001:54:43

## We discuss:

- BJ’s accident leading to the loss of his limbs and his experience inside a burn unit [3:00];
- Coping with his amputations—being tough, the grieving process, and the healing properties of tears [14:30];
- Going from art history to medical school: the value of a diverse background in medicine [28:15];
- How BJ’s new body liberated him [40:00];
- How losing his sister to suicide and his disillusionment with medicine altered his path [47:15];
- Discovering his path of palliative care—distinct from hospice—in medicine [55:30];
- Our complicated relationship with death, and how acknowledging it can release its grip and improve living [1:02:15];
- The different distinctions around the fear of death, and how BJ helps his patients negotiate fears [1:10:00];
- The major design flaws of a “death phobic” healthcare system [1:14:15];
- Common regrets, the value of time, and other insights from interactions with patients in their final moments of life [1:23:00];
- The story of Randy Sloan—a case study of playing life out [1:33:45];
- Hastening death with physician-assisted dying: Legality and considerations [1:39:45];
- The use of psychedelics in end-of-life care, and what BJ is most excited about going forward [1:45:45]; and
- More.

§

## Show Notes

## BJ’s accident leading to the loss of his limbs and his experience inside a burn unit [3:00]

**Life-altering event**

- Shortly after Thanksgiving in 1990, BJ was in college at Princeton at the time
- He was out having a drink with friends and climbed on top of a non-operating commuter train as a goof
- He got too close to the electrical line above the train the electricity entered through his metal watch on his my left arm and then ground down causing an explosion
- He ended up **losing both legs below the knee and his left arm below the elbow** and spent months in the burn unit
- What does he remember from the night?
- Very little, doesn’t remember getting shocked
- His first memory was being awkwardly loaded onto a helicopter as the paramedics were trying to vent the heat from his body (With electrical burns, you burn from the inside out, so you’ve got all this heat running around in your system and it’ll keep burning you)

**Life inside the burn unit**

> “*It is another world that I’ve always struggled to impart to people what it’s actually like in there. It is a wholly unnatural place. I mean, nature is completely kept at bay*.” —BJ Miller on the working conditions inside a burn unit

A burn unit is a very different place that requires specialized doctors and nurses

- The grotesque nature of the disfiguration of the skin
- These dressing changes several times per day on a patient require incredible sterility at the bedside
- Even the smell of burned tissue is a very foreign odor to people

Risk of infection

- Infection is very often the thing that kills people, hence all the sterility
- Someone might look just fine, but their survival odds can be quite low because their body is so susceptible to infection
- There is no touching allowed (hard for BJ and his parents)

## Coping with his amputations—being tough, the grieving process, and the healing properties of tears [14:30]

**Why the need to amputate limbs?**

- When [fasciotomies](https://en.wikipedia.org/wiki/Fasciotomy) are performed initially, it’s with the hope of salvaging the limbs
- They came to the realization trying to salvage the limbs was actually going to threaten BJ’s life due to infection

The conversation with the surgeon

- One night, BJ had a memory of the conversation regarding amputation with the surgeon
- When he awoke the next morning, he was in a daze and remembers thinking, “Thank god that was just a dream.”
- In his hazy state, BJ managed to extubate himself, put out the central lines in this neck, get out of bed and start to walk to the bathroom
- About halfway there, the catheter line ran out of slack and it yanked on the [Foley](https://en.wikipedia.org/wiki/Foley_catheter), “***that’s a pain that I won’t soon forget***.”
- At that point, clarity hit him—he knew at that point that the amputation conversation wasn’t a dream

> “It was instantaneous that I realized this wasn’t a dream. And all the relief that I had experienced moments ago in the other direction just immediately went away, and I was very, very clear where I was and what was happening to me. Instantaneously. It was a wild, wild moment I won’t soon forget.” —BJ Miller

![](https://peterattiamd.com/wp-content/uploads/2020/10/photo-of-BJ-bjmiller-750x1024.png)

**Figure 1. Photo of BJ’s new body.** Image credit: [dailymail.co.uk](https://www.dailymail.co.uk/health/article-7267961/30-ways-good-death-Advice-doctor-came-terrifyingly-close-dying-himself.html)

**BJ’s process of mourning the loss of his limbs**

- His conscious mourning process was delayed, he thought the thing to do was to pick yourself up, be tough, and get back on the horse, “*The less you acknowledge what’s gone on, the better. The tougher you are, the faster you’ll be functional again*.”
- *Weird level of immediate acceptance*: BJ’s mom has been disabled due to polio her whole life, so in his first conversation with her was almost an excitement to be able to relate with her, “now we have so much more in common”
- It wasn’t a thorough acceptance, “It was where I wanted to be, but it wasn’t really where I was.”
- He was on autopilot in a way

*First time he let it out—*

- A nurse one day urged BJ to let his real feelings out, told him she was sick of him not taking this seriously and acting too cheery, “This is a big, big deal. You’re not being real.”
- BJ began to cry, like a dam had been broken, “***It was the most magical thing.***”
- *Tears as a form of anesthesia?* BJ had a fascinating moment when crying, **he felt no physical pain**
- It was a fascinating moment, and the beginning of a long process of months and years of mourning and grieving

*What was the underlying source of BJ’s sadness and tears?*

- **A release of the physical pain**: “I had just been literally gritting my teeth and trying to feel or act as strong”
- **Shame and embarrassment**: The sorrow came a bit from embarrassment for doing this and putting his parents through so much pain
- **Fear of going through life disabled**: would ever have sex again, what women were going to think of me, what my friends would think of me, he has seen the cruelty towards diabled people before
- Very low on the list was the “Why me?” questions: if anything, he felt guilty for having too perfect a life before that

## Going from art history to medical school: the value of a diverse background in medicine [28:15]

**How the death of his sister altered his path**

- BJ had a sister who was 4 years older than him
- He really looked up to her and found her to be a very insightful person, “Wild, brilliant, fascinating, just intense person.”
- BJ says he “chased her moods around. Anything she told me, I took at face value. I mean, she owned me in so many ways as her younger brother.”
- Turns out she was also very troubled
- Roughly 10 years after BJ’s accident, his sister committed suicide
- At the time, BJ was in medical school and this event precipitated his decision to leave medicine

**How BJ decided to go into medicine**

- While in recovery, BJ said it was “like a torture chamber interspersed with incredible boredom”
- He spent a lot of time pondering questions of meaning and identity in a way that was very relevant and therapeutic and practical: “*What am I now? Am I less of a person? Do I have less to offer the world*?”
- He was looking for **meaning-making**—
  - i.e., how humans work with pain, how did humans work with things they can’t control
- This led to his fascination with art — It’s kind of a stunning impulse that human beings have—“*That was lighting up for me as very important and telling and that maybe, maybe the art world had something to teach me*.”
- He returned to Princeton and switched his major to **art history**

**\*Advice for college students on what to study prior to med school:**

- Peter’s general advice: **Anything but pre-med**
- Peter values a diverse background
- And most of everything you study in pre-med, you’re going to pick up in medical school anyway
- BJ agrees, “If you’re going to go into the healing professions, the clinical professions, you better find a way to delve into why life is amazing and horrifying”
- questions around meaning and identity have been “crowded out” of healthcare
- BJ says he really, really loves the notion of people who study humanities then going into the healing professions

⇒ Peter gave his thoughts on this topic in [AMA #3](https://peterattiamd.com/ama03/) and the [episode with David Epstein](https://peterattiamd.com/davidepstein)

*The medical field benefits from physicians with a wide range of backgrounds—*

- Medicine needs all of the above: People who have probably gone incredibly deep on a very narrow subset of science, engineering backgrounds, humanities backgrounds, etc.
- Pre-med is not bad, says BJ: “Just make sure you actually love it. Just make sure you love the nuts and bolts so you’re not just doing chemistry just as a means to the end of medical school. You find something to study that actually cultivates you loving something—I think that’s a major, major distinction—that could be engineering, that could be art, that could be chemistry.”

## How BJ’s new body liberated him [40:00]

> “One of the ways to get through something in some real ways to let yourself be changed by it.” —BJ Miller

**Deciding to pursue medicine**

- After graduating with an art history degree, BJ decided to go to medical school
- BJ’s goal was NOT to not get back to where I was before the injuries, but rather let those experiences and lessons shape his path forward in a positive way
- Medicine lit up as a way to put these experiences to use—
  - “*I could apply these lessons into a therapeutic application of studying perspective and meaning-making*.”
  - “*I was actively looking for an outlet where my injuries weren’t something that someone would look past or forgive, but were actually in some way something of an advantage*.”

**How did BJ’s injuries liberated him**

- Growing up, BJ had a sense that his life was almost too easy based on how others around him had it rough (mom with polio, sister with mental health issues)
  - *“My problem was I didn’t really have anything to complain about. I knew that life was really, really hard for many, many people and internally my life was hard*.”
- After his injuries, he almost felt more comfortable in his new body— “*I got the body that much more mirrored how I felt inside;* ***fragmented, broken, confused, unintegrated, different***.”
- This mental process of accepting his new body, that it was the “right” body for him, really removed the sense of regret and second guessing he otherwise would’ve felt

## How losing his sister to suicide and his disillusionment with medicine altered his path [47:15]

**His sister’s suicide**

- After his sister’s suicide, she was diagnosed as having textbook [bipolar disorder](https://en.wikipedia.org/wiki/Bipolar_disorder)
- But even leading up to her death, she had everyone fooled including BJ, his parents, and even her therapist of 10 years—“*she was a master manipulator*”
- Before her death, BJ believed his sister was right about everything, “*I saw Lisa was the standard. She was right. Everyone else was wrong*.”
- His sister’s death led BJ to consider leaving medicine—he was demoralized that he was someone who wanted to heal people and yet he completely missed his sister’s diagnosis right under his nose

**How BJ found his path in medicine**

- BJ has originally thought his path was going to be rehabilitation for people with traumatic injuries
- But soon into his residency he realized he hated it
- The whole idea of rehabilitation bothered him—
  - It was so mechanical had nothing to do with the personal transformations
  - The goal was  to get people back to where they were before the injury
  - “*I just don’t believe is true.* ***It’s importantly untrue***.”

**How his relationship with fear had changed**:

- After his injuries, he was much less afraid of failure

> “*I had a totally different relationship with fear. I saw falling as a skill*.” —BJ Miller

**Ready to leave medicine**:

- Going into medical school, he had promised himself he wouldn’t get stuck in something he didn’t like, life is too short
- He had also begun to be disillusioned with medicine–where the practice of medicine isn’t necessarily jiving with the ideals that you bring into it
- The dean talked him into doing his internship and he reluctantly agreed
- It was at that time that he stumbled into [palliative care](https://en.wikipedia.org/wiki/Palliative_care), “*And that’s where everything changed*”

## Discovering his path of palliative care—distinct from hospice—in medicine [55:30]

**Discovering palliative care**

- BJ thought he understood what hospice was—simply where people go for the final days of lif
- Then one day he stumbled into an elective called “palliative care” at the Medical College of Wisconsin
- Dr. David Weissman was the oncologist there

On this day, BJ witnessed a conversation that was a transformative moment for him:

- Dr. Weissman was having a conversation with a woman and he was trying to convey the serious nature of her heart condition
- It was type of tricky conversations that medicine traditionally doesn’t handle very well—very emotional, psychologically loaded content
- “He’s talking to her like a human being, not hovering over her like a superior, someone who’s there to fix her. It was beautiful.”
- The **magic momen**t came when he looked at the patient in the eye and said, “When you die…”
- BJ was moved by how Dr. Weissman “dared to acknowledge this woman’s death”
- And on her face was not shock or anger, but relief
- At that point, BJ knew that THIS was what he had been looking for

In the world of palliative care…

- Illness, disability, death are normal, they’re not anomalous
- It’s not just the angle of the joint it was concerned with, but the angle of the **thoughts** and the way that we see ourselves
- The words we choose to describe our place in the world and how we either suffer for those words or how we really can find ourselves doing something more therapeutic

> “I’m not here to fix people, I’m here to be with people as they find their way and to deal with things that they can’t control. That was the hook for me.” —BJ Miller

**Difference between palliative care and hospice**

Palliative care in BJ’s words—

- Palliative care is simply the interdisciplinary pursuit of the quality of life
- Within the context of serious illness palliative care is that mode of care which helps you feel as well as possible—Emotionally, physically, spiritually
- There is nothing in the definition of palliative care that makes it that you need be dying anytime soon—Death is included in this, but it’s not the focus.
- The thing that we treat in palliative care is suffering, not disease

Hospice care in BJ’s words—

- Hospice is a subset of palliative care—it is essentially palliative care that’s applied at the end of life
- That is a huge distinction — yet because many think palliative care and hospice are the same, nobody wants to talk about palliative care because of all the baggage around death

Suffering is the consequence of conflating these terms—

- The consequence of conflating the two is that people suffer for years where they could get a lot more support through palliative care

> “They think [palliative care] is only relevant if you’re dying soon, and nothing could be farther from the truth.” —BJ Miller

## Our complicated relationship with death, and how acknowledging it can release its grip and improve living [1:02:15]

**Our complicated relationship with death**

- Even though all of us are going to die, it seems we don’t live like that is a reality
- We are almost in denial, or just have an inability to look at death
- BJ says it understandable and that we should cut ourselves some slack
- We are wired to run away from death
- We’re also the only species who is aware of our own eventual mortality
- It’s quite a predicament we humans have, it’s a huge subject for us to wrap our heads around

*A victim of our own success*—due to advancing technologies and medicine, we’ve been able to extend lifespan and forestall death

- So now that sense of urgency is lessened
- Put all that stuff together and we’ve conspired to set up a pretty tricky relationship to this piece of our nature

> “*People die much more miserable than they need to because they haven’t dared to look at this thing called death before it’s too late.*” —BJ Miller

**Life is precious specifically** ***because*** **we die**

- Thanks to our technology, you can kind of live forever by some very reduced definition of life
- Once you look at death and really accept it as a reality, two things happen:
  - 1) You many realize it’s not so terrifying afterall
  - 2) Once you come to terms with the fact that your time is limited and therefore precious, it has a secondary effect of helping you really, really appreciate what you have

> “*The fact that it ends is what makes it precious*.” —BJ Miller

**We can do both**

- We don’t have to pick between maximizing our lifespan and accepting death
- Instead, we can figure out a way to live the best life possible and the longest life possible
- As long as we think it’s either life or death, that either you love life and try everything you can do to extend it, or you love death and just completely accept that it’s going to come today
- These false dichotomies are the problem

## The different distinctions around the fear of death, and how BJ helps his patients negotiate fears [1:10:00]

**The different types of fear of death**

Many of BJ’s patient present with a fear of death, but there’s an important distinction—

- Are you afraid of the dying process?
- Or are you afraid of being dead?

In the former,

- there are medications to help the body come down for a “gentle landing” (i.e., not suffer in physical pain)
- So if that’s your fear, BJ offers his patients reassurance

If you fear is about being dead – what happens next, leaving your family behind, missing out, etc.

- In this case, there is no clear “answer”
- But “*as a fellow traveler, I can accompany you there. We can think about that together. We can talk about it and then* ***we can make a life that responds to that big question***.”

Examples:

- If someone is worried about “judgement day”, then the solution is to help them behave differently in the time they have left
- If someone’s fear is not living forever, “*my favorite means to living forever is to think about the world beyond yourself; invest yourself in the world beyond yourself so when your self dies, that thing you love keeps going.*”

> “This is where it gets really, really fascinating, the relationship between self and other and what to do about that. Religious thinking, spiritual pursuits, this is what can open up when you admit that you’re freaked out to be dead.” —BJ Miller

Peter’s personal fear is around leaving his family behind, and missing out on the future generations

- BJ’s point is that you CAN live through those things, but you have to make the investment, it doesn’t happen automatically
- The irony is that you have to do it while you’re still alive and well, you can’t wait until your last moments

**Palliative care should really begin much earlier in life**

- “It’s such a shame that we forestall and keep it at bay when it’s this thing that could help us so, so much.”
- “Whether actually a palliative care referral or a palliative care mindset, but one way or another finding our way into this subject while we’ve got plenty of road in front of us, is absolutely the right, best way.”

## The major design flaws of a “death phobic” healthcare system [1:14:15]

**The big design flaw of medicine**

- The overarching design flaw is that the system is focused on disease, not on the people dealing with disease
- The second you make it about the person living with the disease, not the disease itself, you welcome in all sorts of things into the mix beyond just their physiology and anatomy:
  - Their social, emotional, and spiritual lives
  - You’ve welcomed your humanness into the mix as a clinician being relevant beyond just your technical skills
    - This can help with doctor burnout
    - It also helps with the expectation management—doctors can not be expected to work miracles: “*We know that at some day everyone’s going to die and that that’s not a failure for us*.”

> “Once we align healthcare with the human condition and with serving human beings, so much of the trouble will work itself out.” —BJ Miller

**Palliative care should be apart of everything**

- Given that 100% of patients die eventually, you’d think that palliative care would not need to be a specialty, it would be baked into how all of medicine works.
- The healthcare system itself can’t keep doing what it’s doing and can’t keep death the enemy, because it’s going to lose that war again and again and again.

**The wrong strategy and misaligned resources**

- Peter says we’ve taken the wrong strategy in a war that probably ought to be deemed more of a truce
- We’ve put our resources in the wrong place
- medicine is very good is on acute care and really bad with chronic care
- And it has nothing to do with healthy life to prevent acute or chronic issues
- And it has nothing to do with death
- So, *why do we keep doing that*?
  - In many cases, we don’t know what to do to prevent the condition
  - And even the ones that we do understand, like obesity, we don’t really have the infrastructure to help with prevention
- In med school, for example…
  - There isn’t a single course on dying
  - Not a single course on nutrition or exercise or stress management
  - Or the psychology of eating and our relationship to food and how you can help patients make better choices with nutrition and things like that
    - Frankly physicians aren’t compensated for those types of things—You just don’t have the billable structure in which you can do these things
    - Instead we focus on the drugs as our main tools, and drugs just aren’t good for the chronic conditions

**Summarizing the 3 design flaws of healthcare:**

1 – We’re death phobic and we see ourselves as victors when we cure something

- But chronic illness by definition is something that we can’t fix
- This presents doctors with a sense of failure, which becomes an emotional barrier to developing it further

2 – The busy-ness of medicine

- Medicine is a series of transactions, which can work in acute care
- But with chronic care, you’ve got to learn to live with it so illness and health becomes protracted over time
- Therefore chronic care becomes an experience, yet we’re wired for transactions so we don’t have the systems and structures in place to be cultivating experiences together with our patients.

3 – Reimbursement: Doctors are incentivized away from thinking about care over time

## Common regrets, the value of time, and other insights from interactions with patients in their final moments of life [1:23:00]

**Common regrets from hospice patients**

- BJ has had many of these intimate deathbed moments
- Of course, he sees the common regrets like wishing they had spent more time with family that at work
- But in most cases, the patient is dying from a chronic illness so they’ve had some protracted period of time to think about our death specifically
- By the later stages of their life, their regrets show up more often in wishing as:
  - I wish I had dared to love more.
  - I wish I hadn’t been so afraid.
  - I wish I had just let myself be myself.
  - I wish I hadn’t been so hard on myself or criticized myself.
- The commonality is that **they wish they had let themselves come to terms with death earlier in their lives, because it would have changed the decisions they made**

**This is the freedom of coming to grips with death**:

- If “failure” is guaranteed, the pressure is OFF to live perfectly (always being a good person, eating veggies, not smoking, etc.”
- In parallel, the pressure is ON to take life seriously and be yourself

**A liberating force**

- “The only thing I have to lose is **wasting my time**, so I’m not going to waste my time. I’m going to take this stuff seriously. I’m going to say what I want to say to people. I’m going to do what I want to do.”
- Accepting the inevitability of death is a way of forgiving yourself for “failing”

> “In this way, it can be a real liberating force… and the regrets have something to do with not coming to that place sooner.” —BJ Miller

**Addressing the dying wishes of patients**

- BJ works with the [Dream Foundation](https://www.dreamfoundation.org/)—an organization that helps make those wishes come true
- Visiting the Grand Canyon, for example
- “It’s beautiful” says BJ
- Helping fulfill those wishes is SOME of BJ’s job, and when it’s practical to do so, “It’s fun. It’s great work. It’s powerful. It’s delightful and it’s stunning.”
- However, BJ finds himself more commonly helping patients see themselves in the world in such a way that they can **let go of those things that they never got to**, because they realize the things that they’re not going to get to is a very long list.
- “*On a developmental level, you’ve got to find a way to come to terms with all the things you’re not going to get to do. That’s where I spend a lot of my time*.”

**Are people become enlightened and hyper transcendent at the end of life?**

- Oftentimes, patients are so heavily medicated that they’re not really even able to communicate much with their loved ones—It’s the price we’ll pay to keep them comfortable
- The last day or two of life is not necessarily the greatest time to be digging into someone’s soul
- But it’s not an either/or situation—meaning take drugs and be out of it but pain free  OR don’t take drugs and be in pain but be lucid
- Intractable pain is a great route to delirium—when your body is an absolute agony is a pretty quick psychotic experience

**Threading the needle with palliative care**:

- Palliative care doctors can often “thread a needle” and get someone comfortable enough, but not so overly medicated that they can’t interact
- But in the very final moments of life, you’re not having big philosophical conversations
- This is the best argument as to why **there is no time like the present to say what it is you want to say to people who matter**

> “There is no time like the present to say what it is you want to say to people who matter.” —BJ Miller

## The story of Randy Sloan—a case study of playing life out [1:33:45]

**Meeting Randy Sloan**

- BJ had a dream of riding a motorcycle which was a challenge given his amputations
- Randy Sloan was a young mechanic who gladly took on the challenge of fitting BJ on his own bike
- After modifying the bike, BJ had a “beautiful moment” where he was able to ride off into the sunset on his own

![](https://peterattiamd.com/wp-content/uploads/2020/10/BJ-Miller-on-bike-1024x763.png)

**Figure 2. B.J. Miller on the motorcycle that Randy Sloan helped make for him.** Image credit: [nytimes.com](https://www.nytimes.com/2017/01/03/magazine/one-mans-quest-to-change-the-way-we-die.html)

**Randy’s diagnosis**

- Not much longer, BJ got a call from Randy’s mother who told BJ that Randy had been diagnosed with an extremely rare cancer called [mesothelioma](https://en.wikipedia.org/wiki/Mesothelioma)
- Randy had only a few weeks to live from the moment of his diagnosis

![](https://peterattiamd.com/wp-content/uploads/2020/10/Randy-Sloan-859x1024.png)

**Figure 3. Randy Sloan.** Image credit: [nytimes.com](https://www.nytimes.com/2017/01/03/magazine/one-mans-quest-to-change-the-way-we-die.html)

**Palliative care for Randy**

- Randy immediately moved into the [Zen Hospice Project](https://zencaregiving.org/) where BJ worked at the time where he played out the rest of his life
- BJ had the sobering conversation with Randy that there was nothing that was going to help them at this point, except for love
- In that conversation, BJ asked Randy, “what are you most proud of in yourself?”
- Without hesitation, Randy replied, “***I want everybody I ever come into contact to know that I love them***.”

From there the next steps became clear:

- We need to keep you as comfortable and conscious as possible for what time you have
- Let’s get you into this hospice house and out of the charade of treatment
- Let’s treat your symptoms and open up your door and get as many people in here as you want

And that’s what he did…

- He just had a steady stream of visitors.
- “H*e became this radiant beam of love for what time he had and just made sure to love as many people as he humanly could*.*”*
- “T*hat became his legacy. And he died smiling and quickly.”*

## Hastening death with physician-assisted dying: Legality and considerations [1:39:45]

**Legality of assisted dying**

- [Physician-assisted dying](https://en.wikipedia.org/wiki/Assisted_suicide) (aka euthanasia) has been legalized in a handful of states (See list of states [here](https://en.wikipedia.org/wiki/Assisted_suicide_in_the_United_States))
- The process includes writing a letter for approval, there’s a 2 week wait, you have to have two physicians involved, etc.
- This is in place as a fail safe so that people don’t do something in a moment of weakness—
  - “It’s almost like once you pierce the veil of indefinite life, which people really long for, on some levels think they long for, then all of a sudden they’re terminal. And then they can’t die soon enough.”
  - It’s the ‘*quit before getting fired impulse*’, says BJ

*In the case of someone like Randy…*

- BJ says if hastening death was an option for Randy, he could imagine him taking that route given that the world was falling apart so quickly and it was just too painful mentally and physically for a little while there for Randy to “see straight”
- But the realization that Randy had a mission to sort of prove love, to show love, to be love, he then had a reason to keep going
- Rather than choose assisted dying, Randy had a lot more final moments with friends and **he had the pride of playing his body all the way out**

> “A meaningful life, a good life, is not the absence of suffering. Suffering teaches us too much. It’s too important of a vehicle for us actually. A full life requires it.” —BJ Miller

**BJ has nothing against those who choose to hasten death**

- For some people, it is exactly the right decision—but only when it is seen as a meaningful response, not a flight from suffering, but a moving towards something meaningful—And for some people that final act of will is very meaningful
- But more often, what ends up being more meaningful for people is:
  - Being more than their pain and suffering
  - Letting their body play itself all the way out and dealing with and adapting every moment along the way
  - And letting themselves **grow right up until the moment of their death**
- “T*hat’s actually a more meaningful pursuit for the bulk of people*.”

> “In general, I’d rather feel something—even if it’s pain—than feel nothing. Anesthesia is a way, numbness is a way to die before we have to die. That seems to be a bigger tragedy to me than is death in the first place.” —BJ Miller

## The use of psychedelics in end-of-life care, and what BJ is most excited about going forward [1:45:45]

**Therapeutic psychedelics**

- [Psilocybin](https://en.wikipedia.org/wiki/Psilocybin) has been [shown](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5367557/) to help with depression in patients with cancer
- [MDMA](https://en.wikipedia.org/wiki/MDMA) is currently being [used to treat PTSD](https://maps.org/news/media/6786-press-release-fda-grants-breakthrough-therapy-designation-for-mdma-assisted-psychotherapy-for-ptsd,-agrees-on-special-protocol-assessment-for-phase-3-trials)
  - Check out the [Rick Doblin episode](https://peterattiamd.com/rickdoblin/) for more on this topic
  - Also see [this article](https://www.stripes.com/feel-good-drug-ecstasy-one-step-closer-to-approval-as-ptsd-treatment-1.445361) about a soldier who overcame PTSD with MDMA
- Ketamine is also proving to be a [therapeutic for depression](https://www.fda.gov/news-events/press-announcements/fda-approves-new-nasal-spray-medication-treatment-resistant-depression-available-only-certified)

**Psychedelics in end of life care**

- These same substances are being researched for anxieties around the fears of death in a patient population dealing with terminal illness or serious illness

⇒ BJ says the [psilocybin data](https://www.researchgate.net/publication/278689788_Use_of_the_Classic_Hallucinogen_Psilocybin_for_Treatment_of_Existential_Distress_Associated_with_Cancer) is the most exciting:

- People who are gripped by a fear of death, gripped by a sense of meaninglessness and not belonging and not feeling connected come out of **one sessions** losing their fear of death, feeling part of something larger than themselves, having a totally different relationship to fear
- The effect lasts for a months suggesting it’s not just an acute chemical response

“*We don’t have anything remotely like this to offer in medicine*.” say BJ

**What is BJ most excited about?**

- BJ is most excited about conversations, like this one with Peter, that are moving the conversation beyond just medicine
- One of the great things that happens when we focus on the person is that people in the field of medicine can become part of something larger than ourselves
  - Physicians can partner with architects and artists, designers, and other disciplines
  - Or even [death doulas](https://en.wikipedia.org/wiki/Death_midwife) and quasi medical folks and the alternative and integrative medicine folks.
  - All of a sudden, we are part of a much larger family working on behalf of something much larger than even medicine

> “Death has become a medical issue. It doesn’t belong there. Suffering and death are way bigger than medicine. . .medicine doesn’t have to carry all that water by itself. People are going to start taking care of people and not handing themselves over to doctors to do the trick.” —BJ Miller

§

## Selected Links / Related Material

**BJ’s TED Talk**: [What really matters at the end of life | BJ Miller](https://www.youtube.com/watch?v=apbSsILLh28) | TED (youtube.com) [1:15]

**Peter explaining the value in a major other than pre-med for college students considering med school**: [35:15]

- *At 38:00 in this AMA episode*: [#26 – AMA #3: supplements, women’s health, patient care, and more](https://peterattiamd.com/ama03/) | Peter Attia (peterattiamd.com)
- *At  1:41:15 in this episode*: [#96 – David Epstein: How a range of experience leads to better performance in a highly specialized world](https://peterattiamd.com/davidepstein/) | Peter Attia (peterattiamd.com)

**Organization that helps bring dying wishes to fruition**: [Dream Foundation](https://www.dreamfoundation.org/) | (dreamfoundation.org) [1:29:00]

**Hospice where BJ worked**: [Zen Hospice Project](https://zencaregiving.org/) | (zencaregiving.org) [1:37:15]

**States that have legalized some form of physician assisted dying**: [Assisted suicide in the United States](https://en.wikipedia.org/wiki/Assisted_suicide_in_the_United_States) | (wikipedia.org) [1:40:00]

**Research on psilocybin for depression in patients with life-threatening cancer**: [Psilocybin produces substantial and sustained decreases in depression and anxiety in patients with life-threatening cancer: A randomized double-blind trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5367557/) (Griffiths et al., 2016)[1:45:45]

**MDMA is being used to treat PTSD**: [PRESS RELEASE: FDA Grants Breakthrough Therapy Designation for MDMA-Assisted Psychotherapy for PTSD, Agrees on Special Protocol Assessment for Phase 3 Trials](https://maps.org/news/media/6786-press-release-fda-grants-breakthrough-therapy-designation-for-mdma-assisted-psychotherapy-for-ptsd,-agrees-on-special-protocol-assessment-for-phase-3-trials) | (maps.org) [1:46:00]

- Check out the Rick Doblin episode for more on MDMA for PTSD: [#65 – Rick Doblin, Ph.D.: MDMA — the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species](https://peterattiamd.com/rickdoblin/) | Peter Attia (peterattiamd.com)
- Soldier who overcame PTSD with MDMA: [‘Feel-good drug’ Ecstasy one step closer to approval as PTSD treatment](https://www.stripes.com/feel-good-drug-ecstasy-one-step-closer-to-approval-as-ptsd-treatment-1.445361) | (stripes.com)

**Ketamine recently approved for depression**: [FDA approves new nasal spray medication for treatment-resistant depression; available only at a certified doctor’s office or clinic](https://www.fda.gov/news-events/press-announcements/fda-approves-new-nasal-spray-medication-treatment-resistant-depression-available-only-certified) | (fda.gov) [1:46:30]

**Psilocybin can help with fear of death with one guided session**: [Use of the Classic Hallucinogen Psilocybin for Treatment of Existential Distress Associated with Cancer](https://www.researchgate.net/publication/278689788_Use_of_the_Classic_Hallucinogen_Psilocybin_for_Treatment_of_Existential_Distress_Associated_with_Cancer) (Grob et al., 2013) [1:46:45]

§

## People Mentioned

- [Randy Sloan](https://www.nytimes.com/2017/01/03/magazine/one-mans-quest-to-change-the-way-we-die.html) [1:33:45]

§

![](https://peterattiamd.com/wp-content/uploads/2020/10/bio-image-bjmiller-500x500.png)

##### BJ Miller, M.D.

BJ Miller is an author, [TED speaker](https://www.ted.com/talks/bj_miller_what_really_matters_at_the_end_of_life?language=en), and physician. He specializes in hospice and palliative medicine treating hospitalized patients with terminal or life-altering illnesses. In his work in end-of-life care, he seeks to connect art, spirituality and medicine, and thinks deeply about how to create a dignified, graceful end of life for his patients.

BJ currently works with [Mettle Health](https://www.mettlehealth.com/) which helps those facing challenging diagnoses improve their quality of life by addressing physical, emotional, social, and spiritual needs.