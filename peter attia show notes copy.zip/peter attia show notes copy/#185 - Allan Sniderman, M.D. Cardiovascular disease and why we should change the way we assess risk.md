# #185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk

**Source:** [https://peterattiamd.com/allansniderman/](https://peterattiamd.com/allansniderman/)

---

Allan Sniderman is a highly acclaimed Professor of Cardiology and Medicine at McGill University and a foremost expert in cardiovascular disease (CVD). In this episode, Allan explains the many risk factors used to predict atherosclerosis, including triglycerides, cholesterol, and lipoproteins, and he makes the case for apoB as a superior metric that is currently being underutilized. Allan expresses his frustration with the current scientific climate and its emphasis on consensus and unanimity over encouraging multiple viewpoints, thus holding back the advancement of metrics like apoB for assessing CVD risk, treatment, and prevention strategies. Finally, Allan illuminates his research that led to his 30-year causal model of risk and explains the potentially life-saving advantages of early intervention for the prevention of future disease.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/allansniderman/the_Drive_public.png)

Play

#185 - Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk

#185 - Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk

1x15s30s

0:002:02:13

## We discuss:

- Problems with the current 10-year risk assessment of cardiovascular disease (CVD) and the implications for prevention [4:30];
- A primer on cholesterol, apoB, and plasma lipoproteins [16:30];
- Pathophysiology of CVD and the impact of particle cholesterol concentration vs. number of particles [23:45];
- Limitations of standard blood panels [29:00];
- Remnant type III hyperlipoproteinemia—high cholesterol, low Apo B, high triglyceride [32:15];
- Using apoB to estimate risk of CVD [37:30];
- How Mendelian randomization is bolstering the case for ApoB as the superior metric for risk prediction [40:45];
- Hypertension and CVD risk [49:15];
- Factors influencing the decision to begin preventative intervention for CVD [58:30];
- Using the coronary artery calcium (CAC) score as a predictive tool [1:03:15];
- The challenge of motivating individuals to take early interventions [1:12:30];
- How medical advancement is hindered by the lack of critical thinking once a “consensus” is reached [1:15:15];
- PSK9 inhibitors and familial hypercholesterolemia: two examples of complex topics with differing interpretations of the science [1:20:45];
- Defining risk and uncertainty in the guidelines [1:26:00];
- Making clinical decisions in the face of uncertainty [1:31:00];
- How the emphasis on consensus and unanimity has become a crucial weakness for science and medicine [1:35:45];
- Factors holding back the advancement of apoB for assessing CVD risk, treatment, and prevention strategies [1:41:45];
- Advantages of a 30-year risk assessment and early intervention [1:50:30];
- More.

§

## Show Notes

**\*Pre-show notes\***

- Allan is a senior scientist at the Research Institute Of McGill University Health Center and the Edwards Professor of Cardiology and Professor of Medicine at McGill University
- He’s the director of the Mike Rosenbloom Laboratory for Cardiovascular Research at Royal Victoria Hospital in Montreal
- He was elected a fellow of the Royal Society of Canada in 2009
- He’s also been an enormous mentor for Peter over the past 10 years; he’s certainly, one of the 3 or 4 people I would count that has nearly single-handedly provided him with the education that he uses to help understand cardiovascular disease
- Peter has included him in some of the things I’ve written about. And also he’s been mentioned a number of times on previous podcasts featuring no less than Tom Dayspring and Ron Krauss
  - [The straight dope on cholesterol – Part VIII](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-viii/)
  - [The straight dope on cholesterol – Part IX](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-ix/)
  - [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/)
  - [Measuring cardiovascular disease risk and the importance of apoB](https://peterattiamd.com/measuring-cardiovascular-disease-risk-and-the-importance-of-apob-part-1/)
  - The Drive podcast episodes:
    - [#03 – Ron Krauss, M.D.: a deep dive into heart disease](https://peterattiamd.com/ronkrauss/)
    - [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/)
- His memberships are probably too numerous to mention, but a few of them include the Royal College of Physicians and Surgeons in Canada, the American College of Cardiology, the American College of Physicians, the Canadian Cardiovascular Society, the American Society for Clinical Investigation, the American Federation for Clinical Research and a number of others
- In this episode we  go very deep on cardiovascular medicine
- Our discussion doesn’t begin in the way I intended, in the first 10 or 15 minutes, Allan lays out some of the most clear, yet complex concepts that you’ll ever hear anybody talk about with respect to apoB and risk management
  - Don’t be dissuaded by how complicated the first 10-15 minutes of this podcast are
  - Instead, sit tight and this episode will walk you through the journey of what apoB is and why it is a superior metric for predicting risk of atherosclerosis relative to the far more commonly used metric, LDL cholesterol
    - And the metric that is better than LDL cholesterol, but still inferior to apoB, which is non-HDL cholesterol
- This episode will also go into great detail about the role of triglycerides, HDL cholesterol, total cholesterol, et cetera, in the understanding of and prediction of cardiovascular disease
- This episode will get into some of the interesting exceptions, i. e., disease states where not knowing apoB poses an enormous blind spot
- This episode will talk about the challenges that face people like Allan, as they try to disseminate the most leading edge and cutting edge science on this topic in an environment that is really wed to guidelines and consensus-based recommendations that don’t necessarily incorporate all of the best evidence
- This episode will explain some concepts like Mendelian randomization and how that’s been used to further bolster the case for apoB as the superior metric for risk prediction
- Coronary artery calcium scoring will also be discussed
  - This  is obviously an important tool used by many physicians, and it’s important to understand how it’s useful and what its blind spots are

## Problems with the current 10-year risk assessment of cardiovascular disease (CVD) and the implications for prevention [4:30]

**Understanding atherosclerosis/ cardiovascular disease**

- Peter has referenced books Allan gave him numerous times
  - [ApoB in Clinical Care](https://www.amazon.com/ApoB-Clinical-Care-Jacqueline-Graaf-dp-9036809797/dp/9036809797/ref=mt_other?_encoding=UTF8&me=&qid=1635354887) by  Jacqueline de Graaf, Patrick Couture, and Allan Sniderman
  - [Atlas of Atherosclerosis Progression and Regression](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1) (Encyclopedia of Visual Medicine Series) by Herbert C. Stary (2003)

![](https://peterattiamd.com/wp-content/uploads/2021/11/f1-allansniderman-687x1024.png)

**Figure 1. Book cover Herbert Stary’s Atlas of Atherosclerosis Progression and Regression showing plaque rupture “rings”.** Image credit: [Amazon.com](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538?ie=UTF8&ref_=asap_bc)

- Peter asks him why he gave him this last book
  - Atherosclerosis, it’s a disease in the **tissue**, yet almost everything that lipid people talk about is in *plasma*
  - One must understand the natural history of the disease to learn how to construct a strategy to prevent it
- Although much of Allan’s work has been on apoB, the more important part has been on understanding how the natural history of atherosclerosis should direct a prevention strategy
  - What this leads to is that every major guideline in the world bases their selection of subjects for statin prevention on the ten-year risk of disease
    - This was a huge step forward in 1980 and 1990
    - But it fundamentally *makes prevention of premature disease almost impossible*

**Problems with the 10-year risk approach**

- When one plugs in the numbers to calculate a patient’s risk for any of the risk algorithms, one expects the output to be the patient’s risk of cardiovascular disease (CVD) *but it isn’t*
  - The American College of Cardiology [ASCVD Risk Estimator Plus](https://tools.acc.org/ASCVD-Risk-Estimator-Plus/?_ga=2.155406269.702326460.1635355961-1875985647.1635355961#!/calculate/estimate/)
  - The calculation is driven by the age and sex of the patient
  - Things like cholesterol and blood pressure contribute minimally to the actual calculation of ten-year risk
    - So if the patient is 35, there isn’t a risk calculator for them
    - If the patient is 40, everyone’s risk is low at age 40
    - It isn’t until age 55 or 60 that the risk gets over the threshold for the American Prevention Guideline treatment
      - So prevention really starts at 55 to 60, but **almost half of all infarcts and strokes occur before the age of 60**
- [Stary](https://www.medschool.lsuhsc.edu/pathology/faculty_detail.aspx?name=stary_herbert) and colleagues established that for the first three decades or so of life, the disease gets a foothold in the artery, but it’s only in the fourth decade that one starts to develop the lesions that can actually precipitate a clinical event
  - Risk is low, yet the event rate is high — *How could that possibly be?*
- Allan says the answer is “stunningly obvious” — Allan has published on how this can be explained; there are 2 problems:
  - 1) There are a ton more people under 60 than over 60; so the *rate* of events is low, but the *absolute* number of events is high
  - 2) Say a patient gets to their 60’s without a cardiac event, but the disease was developing and extending during their 30’s-50’s
    - So by the time a doctor tries to prevent an event, the disease is well advanced in the arteries
  - These are the 2 fatal flaws in the 10-year risk approach
    - Published in *JAMA Cardiology* in 2018, [A Long-term Benefit Approach vs Standard Risk-Based Approaches for Statin Eligibility in Primary Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6583050/)
- Risk is a good concept but Allan realized doctors should be selecting people based on *causes* of CVD
- For example, if Peter’s risk is 4.1%, what does this number mean?
  - Is *his* risk 4.1%?  ⇒ No, it means 4.1 people out of 100 will have an [infarct](https://en.wikipedia.org/wiki/Myocardial_infarction)
    - But within this category, there is tremendous variance in real risk
    - Not everyone is at 4.1; some are higher; some are lower; some are dead on
- The philosopher [AJ Ayer](https://en.wikipedia.org/wiki/A._J._Ayer) (known for [logical positivism](https://en.wikipedia.org/wiki/Logical_positivism)) was actually darn good on probability
- There’s a real challenge predicting singular events
  - One is either going to have an infarct in the next year or not; it’s not really a probability
  - If one algorithm said a patient has a 10% risk and another one said a patient has a 15% or 20%, whether they have an infarct or not, both algorithms were right because they said there was sort of a chance the patient would have an infarct
    - There is also a far greater chance that the patient won’t have an infarct
- When the advice is to treat patients with a risk abouve 7.5%, that means 92.5% of the time nothing will happen to these patients
  - That’s not a great incentive for helping people understand what’s truly going to happen

**A 30-year model of risk that focuses on cause of CVD**

- What Allan has done is develop what’s called a **casual benefit model**
  - Published in *Clinical Science* in 2012, [The Causal Exposure Model of Vascular Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3244267/)
  - Published in *JAMA Cardiology* in 2017, [The Benefit Model for Prevention of Cardiovascular Disease: An Opportunity to Harmonize Guidelines](https://pubmed.ncbi.nlm.nih.gov/28793137/)
  - With a measure of non-HDL or apoB, risk can be projected for over 20-30 years
  - For a 30-year-old, the period of time they should care about is up to at least 60
  - For example, this model could predict that a 35-year-old has a 30% chance of stroke before age 65
    - This is a number that has meaning
    - Now a second calculation can be made to determine how much the risk can be reduced by starting treatment at age 35 or how much the patient would lose by starting at age 45 or age 55
- When Allan gave Peter the book on atherosclerosis he was starting his own journey on trying to construct an alternative to the present risk model in which with the help of my colleague here at McGill, [George Thanassoulis](https://rimuhc.ca/-/george-thanassoulis-md), and [Michael Pencina](https://scholars.duke.edu/person/michael.pencina) from Duke, and [Karol Pencina](https://connects.catalyst.harvard.edu/Profiles/display/Person/130449) from Harvard we have done
  - Published in *JAMA Cardiology* in 2017, [The Benefit Model for Prevention of Cardiovascular Disease: An Opportunity to Harmonize Guidelines](https://pubmed.ncbi.nlm.nih.gov/28793137/)
- Peter remembers from pathology class in med school something the professor said, “*No doctor has more experience with what it is to have heart attacks than pathologists because 50% of the people who have a heart attack die on their first heart attack.*“
  - So 50% of people who have a heart attack, their first presentation is death
  - It’s a very sobering fact
  - He doesn’t think this is true today, but it was 25 years ago
  - Maybe now one third of first events are fatal; sobering nonetheless
- The [textbook](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1) went through, in great detail, the pathological staging of [atherosclerosis](https://en.wikipedia.org/wiki/Atherosclerosis); it was also littered with autopsy sections of [coronary arteries](https://en.wikipedia.org/wiki/Coronary_arteries) from people who had died for other reasons
  - Notably, many of these people who died from other causes, but their coronary arteries were studied in autopsy, these people were quite young
    - A 26-year-old male victim of a gunshot wound; or a 27-year-old female who died in a motor vehicle accident, etc.
  - Looking at their coronary arteries, one realizes they already have atherosclerosis; they have oxidized [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)-bearing particles engulfed by [macrophages](https://en.wikipedia.org/wiki/Myocardial_infarction#Atherosclerosis) and thickened [intima](https://en.wikipedia.org/wiki/Tunica_intima)
    - While they may not have calcification in their arteries yet or the types of plaque that would rupture within the ensuing weeks or days or months, they nevertheless had atherosclerosis
    - Now what Peter’s professor said some 20 years earlier made sense
- Allan remarks that cardiologists are so used to looking at angiograms
  - “Oh, there’s a LAD lesion”
    - A lesion in the [left anterior descending artery](https://en.wikipedia.org/wiki/Left_anterior_descending_artery)

> “Well, there’s an LAD lesion, but the whole damn artery is diseased. And when you destroy the normal architecture of the artery, you can’t restore it.” – Allan Sniderman

- Much of statin prevention therapy is to prevent complication of disease not actually prevent disease
- [Statins](https://en.wikipedia.org/wiki/Statin) lower apoB particle number; that’s how they work
- With fewer apoB particles in plasma, fewer get into the arterial wall, fewer get trapped

## A primer on cholesterol, apoB, and plasma lipoproteins [16:30]

**Cholesterol**

- [Cholesterol](https://en.wikipedia.org/wiki/Cholesterol) is a fat lipid
- It’s a critical element in cell structure; it’s in all cell membranes
  - The amount that’s in the cell membrane is determinative of the function of the membrane
- All the cells in the body can synthesize cholesterol
- Only the liver can really break it down in any amount and excrete it
- When we eat, we absorb cholesterol and fatty acids in the form of triglycerides, and they get resynthesized in the intestine into particles
  - Cholesterol and triglycerides cannot be transported because they don’t mix with water, they’re not soluble
  - [Triglycerides](https://en.wikipedia.org/wiki/Triglyceride) are fatty acids tacked onto a glycerol backbone; see the structure of a triglyceride in the figure below

![](https://peterattiamd.com/wp-content/uploads/2021/11/f2-allansniderman-1024x306.jpeg)

**Figure 2. A triglyceride is made by attaching 3 fatty acids to a molecule of glycerol**. Figure credit: [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:220_Triglycerides-01.jpg)

- Fats have to be put in particles like soap bubbles, there are a variety of different particles
  - All are considered [lipoproteins](https://en.wikipedia.org/wiki/Lipoprotein#Plasma_lipoprotein_particles)
  - Lipoproteins transport fats and cholesterol in the blood
  - The outside (or shell) of the lipoprotein is hydrophilic and contains proteins (apolipoproteins), phospholipids, and cholesterol
  - Chylomicrons are one example, shown in the figure below
  - Other examples are the apoB lipoproteins, shown several figures below
- There are a few large particles that carry fat and cholesterol from the intestine; they’re called [chylomicrons](https://en.wikipedia.org/wiki/Chylomicron)

![](https://peterattiamd.com/wp-content/uploads/2021/11/f3-allansniderman-1024x818.jpeg)

**Figure 3. Chylomicrons transport triglycerides, cholesterol, and other lipids.** Image credit: [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:2512_Chylomicrons_Contain_Triglycerides_Cholesterol_Molecules_and_Other_Lipids.jpg)

- These particles have a protein called apoB-48 on the outside surface
  - This protein gives the particle structural integrity
  - There are also a bunch of other proteins
- These chylomicrons go to skeletal muscle, adipose tissue, and the heart
  - Here the fatty acids are liberated from the triglycerides and rapidly taken up by these three tissues
  - The particle that’s left is now much smaller because most of the triglyceride has been taken out of it
  - Now it goes to the liver and drops the cholesterol off

- The cholesterol we eat in the diet tends to reduce the synthesis of cholesterol in the liver
- The liver gets inundated with fatty acids and cholesterol from all over the place, chylomicrons, HDL, LDL particles
  - The figure below shows chylomicrons carry dietary fats and cholesterol to the liver; additionally the liver takes up LDL and IDL, which carry cholesterol and triglycerides

![](https://peterattiamd.com/wp-content/uploads/2021/11/f4-allansniderman-826x1024.png)

**Figure 4. Lipids are transported in different lipoproteins.** Figure credit: [Wikipedia](https://en.wikipedia.org/wiki/Lipoprotein#Metabolism)

**ApoB lipoproteins**

- There’s a system to regulate the mass of cholesterol and triglyceride in the liver; and that’s the VLDL apoB system
  - ApoB refers to [apolipoprotein B](https://en.wikipedia.org/wiki/Apolipoprotein_B); different apoB proteins are found in the lipoproteins listed below that transport fat and cholesterol in the blood
  - [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) is one type of  [lipoprotein](https://en.wikipedia.org/wiki/Lipoprotein)
  - There are lipoproteins of various sizes (see the figure below), ranging from large to small diameter:
    - [Chylomicrons](https://en.wikipedia.org/wiki/Chylomicron) (largest diameter, 75-1200 nm)
    - [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein)
    - [ILDL](https://en.wikipedia.org/wiki/Intermediate-density_lipoprotein)
    - [LDL](https://en.wikipedia.org/wiki/Low-density_lipoprotein)
    - [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein) (smallest diameter, 5-15 nm)

![](https://peterattiamd.com/wp-content/uploads/2021/11/f5-allansniderman-1024x325.png)

**Figure 5. Plasma lipoproteins that contain apoB.** Figure credit: [Hypertriglyceridemia and cardiovascular risk: a cautionary note about metabolic confounding, Figure 1](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6027915/)

- VLDL particles have a molecule of apoB-100, which is twice as long as apoB-48; and that gives a structural integrity to the particle
- VLDL removes triglyceride and cholesterol from the liver to maintain the balance in the liver (see the figure above)
  - The triglyceride, just as in the case of chylomicrons, gets dropped off in adipose tissue and skeletal muscle, and cardiac muscle
  - The VLDL particle gets smaller and more cholesterol-rich; and it eventually becomes an LDL particle
- The LDL particle is a cholesterol-rich particle with relatively little triglyceride in it; see the figure below

![](https://peterattiamd.com/wp-content/uploads/2021/11/f6-allansniderman-871x1024.png)

**Figure 6.  Composition of a LDL particle.** Image credit: [Biochemistry, 5th edition, figure 26.16](https://www.ncbi.nlm.nih.gov/books/NBK22336/)

- When cholesterol is measured in the blood, the total cholesterol is the cholesterol in the VLDL particle + the LDL particle + the HDL particle
  - The HDL is the “good guys”
  - The non-HDL part of cholesterol is the massive cholesterol in VLDL particles and LDL particles
- This tells a lot, but is it enough?
- Consider this example: 2 people have the same LDL cholesterol (125), one tends to have larger LDL particles and one tends to have smaller LDL particles
  - In order to carry the same amount of cholesterol, there has to be more of the little ones than big ones; so their LDL cholesterol is the same
  - Is there any difference in their atherogenic risk?  YES
    - The one with the increased number of particles has higher atherogenic risks because any cholesterol in the artery only got there within an apoB particle
    - Cholesterol doesn’t just get in the artery, it gets there within an apoB particle (either VLDL or LDL); that gets into the arterial wall and gets stuck there
      - This is the cause of atherosclerosis
      - There are lots of things that contribute to multiplying or diminishing the cause, but that’s the cause, sticking of an apoB particle within the arterial wall
      - And because cholesterol gets in there within the particles, knowing the number of particles is more important even than knowing the cholesterol level

**History of measuring cholesterol**

- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (in the 1950s) was potentially one of the first people to measure total plasma cholesterol
  - In the late ‘50’s the connection between high cholesterol and increased risk of cardiovascular disease (CVD) became known
- For example, if someone’s cholesterol measures 200 mg/dL, this tells the sum total of cholesterol in all of the lipoproteins
- Stratify people at the bottom 5% and people at the top 5% of total cholesterol level
  - For example, at the bottom end are individuals with 100 mg/dL and on the top end are people whose total cholesterol is more than 200 mg/dL
  - There’s a stark difference in their risk of CVD
- The amount of cholesterol a person ate does not seem to predict their serum level of total cholesterol
- Other dietary factors, saturated fat intake, for one, seem to predict that difference in cholesterol levels
- 15 years later that [Fredrickson](https://en.wikipedia.org/wiki/Donald_S._Fredrickson), [Levy](https://en.wikipedia.org/wiki/Robert_L._Levy_(cardiologist)), Lees, and others would start to fractionate those lipoproteins and realize that, well, actually there’s different versions (VLDL, LDL, HDL, etc)
  - Published in *NEJM* in 1967, [Fat Transport in Lipoproteins — An Integrated Approach to Mechanisms and Disorder](https://www.nejm.org/doi/10.1056/NEJM196702022760507?url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0pubmed)
- Later the nuances that some of the lipoprotein particles contain apoA versus apoB was discovered
  - [ApoA](https://en.wikipedia.org/wiki/Apolipoprotein_A1) is on HDL
  - [ApoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) is on: chylomicrons, VLDL, ILDL, and LDL

## Pathophysiology of CVD and the impact of particle cholesterol concentration vs. number of particles [23:45]

Peter asks: *When did it become clear that there was a discordance between the cholesterol concentration in the LDL particle and the number of LDL particles?*

- Bob Lees had a paper in *Science* in 1970; he measured LDL apoB (the number of LDL particles) and showed it had no clear (or exact) relation to plasma triglycerides or to cholesterol
  - [Immunoassay of plasma low-density lipoproteins](https://pubmed.ncbi.nlm.nih.gov/5424796/)
- Ron Krauss and colleagues (including Sniderman) showed in the [John Gofman](https://en.wikipedia.org/wiki/John_Gofman) tradition that there were important differences in the size of plasma LDL
  - And these are related to differences in the amount of cholesterol mass per particle
  - Published in the *Journal of Lipid Research* in 1982, [Identification of multiple subclasses of plasma low density lipoproteins in normal humans](https://www.jlr.org/article/S0022-2275(20)38178-5/pdf)
  - Published in *PNAS* in 1983, [Composition and distribution of low density lipoprotein fractions in hyperapobetalipoproteinemia, normolipidemia, and familial hypercholesterolemia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC391230/)

**Particles can be more important than cholesterol for predicting risk of CVD**

- Allan’s first clinical paper looked at a bunch of patients with coronary angiography; they compared people with clean coronaries to people with diseased coronaries
  - There was a little difference in triglyceride
  - There was a difference in cholesterol
  - But there was a marked difference in apoB
  - Published in *PNAS* in 1980: [Association of coronary atherosclerosis with hyperapobetalipoproteinemia [increased protein but normal cholesterol levels in human plasma low density (beta) lipoproteins]](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC348323/)
    - In collaboration with [Peter Kwiterovich](https://www.hopkinsmedicine.org/news/media/releases/johns_hopkins_pioneer_in_pediatric_lipid_disorders_dies) from Hopkins
  - This was one of the first, clinically solid observations showing that particles could be more important than cholesterol
- Since 1980 even more evidence shows that particles are more important than cholesterol
  - But, this hasn’t moved the American guidelines
  - The figure below shows as the concentration of apoB particles in the bloodstream increases, the number of particles trapped within the arterial wall also increases thereby advancing the atherosclerotic process

![](https://peterattiamd.com/wp-content/uploads/2021/11/f7-allansniderman-592x1024.png)

**Figure 7. Increased plasma concentration of apoB leads to increased particles trapped within the arterial wall.** Figure credit: [Particles and Cardiovascular Disease: A Narrative Review, figure 5](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7369156/)

- There are a handful of studies that show that non-HDL cholesterol may be equal to apoB
- There are more studies that show apoB is better
- Allan developed a way of looking at it called *discordance analysis* to identify people who had

1. A high non HDL (which is the total cholesterol on the apoB particles) and a low apoB (total number of particles)
2. Or low non-HDL and high apoB

- Review published in 2014, [Discordance analysis and the Gordian Knot of LDL and non-HDL cholesterol versus apoB](https://pubmed.ncbi.nlm.nih.gov/25340478/)

> “So if you’re a cholesterol maven, you got a bet on that one with a high non- HDL. If you’re an apoB aficionado, you bet on the one with the lower non-HDL, higher apoB. They all show it’s apoB.” – Allan Sniderman

**Comparing metrics of non-HDL cholesterol and apoB**

- The mechanism is the same for high non-HDL cholesterol and high apoB
- Some people argue that VLDL particles are more atherogenic than LDL particles
  - Allan thinks they’ve got a long way to go to prove that
- People argue that there are problems with the apoB assay and its expense
  - However, the apoB assay was standardized back in 1994
  - The measurement of HDL cholesterol is not standardized; this is also true for the measurement of LDL and triglycerides
- Peter had this argument recently with another physician about the cost of measuring apoB; he called the lab and asked about the cash price for the apoB test
  - It was $2.50
  - In Allan’s hospital it costs $2
  - The cost argument has been used without documentation as a killer argument
    - Of course there were labs that charged way too much too

## Limitations of standard blood panels [29:00]

- Doctors get a report of 5 numbers: total cholesterol, triglycerides, non-HDL-C, LDL-C, HDL-C
  - What can they do with that; everything is based on LDL
  - In reality, the other 4 numbers are doing nothing

**Calculated and measured LDL, amount of cholesterol versus number of particles [29:45]**

- For example, a patient’s labs report 140 mg/dL LDL
  - This is an estimation; it’s almost always a calculation
  - There are at least eight different methods to calculate LDL cholesterol
    - They don’t all give the same answer
- LDL cholesterol can also be measured directly
  - That assay has never been validated in disease patients
  - No one has ever published a paper showing that it’s more accurate in terms of disease identification than calculated LDL cholesterol
- There’s no question that the number of LDL particles is a more accurate index of risk than the LDL cholesterol
- **VLDL-C** is a cholesterol that’s in the very low density lipoprotein particles
  - These particles that come out of the liver
  - This cholesterol is atherogenic, there’s a lot of triglyceride in that particle
- **High triglycerides**: there’s no question that people with high triglycerides are at increased risk of heart disease
  - The people with the high triglycerides that are at increased risk of heart disease have a higher number of LDL particles and VLDL particles
    - It’s the particle
    - When triglycerides are measured, what is measured is just measuring a blob of liquid in a bunch of particles, and one needs to know the number of them
  - Extremely high triglycerides carry an increased risk of pancreatitis
  - Allan hasn’t seen any solid evidence that triglyceride itself is pro-atherogenic

> “What’s atherogenic is the cholesterol inside the VLDL particles, it’s the number of those particles that get into the wall” – Allan Sniderman

## Remnant type III hyperlipoproteinemia—high cholesterol, low Apo B, high triglyceride [32:15]

- In general, all Allan needs to know to estimate CVD risk is the apoB level, expect for 1 complication
- There is a disorder called [remnant type III dysbetalipoproteinemia](https://en.wikipedia.org/wiki/Familial_dysbetalipoproteinemia) (or [hyperlipoproteinemia](https://rarediseases.org/rare-diseases/hyperlipoproteinemia-type-iii/))
  - This is a very specific, highly atherogenic condition
  - It manifests with high triglycerides, high cholesterol, but low apoB
    - When lipids and apoB are measured, this can be recognized
    - Doctors don’t routinely measure apoB
- The pathophysiology of remnant type III, of how a person can have high cholesterol, low apoB, and high triglycerides
  - In normal metabolism as the [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) particles get broken down sequentially as a triglyceride is removed and they get converted to LDL particles, as shown in the figure below
    - The liver will remove some of these LDL particles

![](https://peterattiamd.com/wp-content/uploads/2021/11/f8-allansniderman.jpeg)

**Figure 8. VLDL particles are sequentially broken down to ILDL then LDL.**  Image credit: [Pathogenesis of type III hyperlipoproteinemia (dysbetalipoproteinemia): questions, quandaries, and paradoxes, Figure 1](https://www.jlr.org/article/S0022-2275(20)32417-2/fulltext)

- In remnant type III hyperlipoproteinemia this process breaks down for reasons that are not well understood

- From the age of 30, 35, or 40 people develop high triglycerides and high cholesterol because the VLDL particles aren’t being broken down to LDL particles
  - This process stalls and VLDL particles circulate a long time in the blood
  - While they’re circulating, cholesterol gets deposited into them and they become very, very cholesterol rich
- These people have a very high risk of coronary disease, peripheral vascular disease
- This syndrome is more common than [familial hypercholesterolemia (FH)](https://www.ncbi.nlm.nih.gov/books/NBK174884/), the one that gets all the press
- Remnant type III hyperlipoproteinemia is much easier to treat than FH
- Remnant type III hyperlipoproteinemia cannot be diagnosed in the US because apoB is not measured
  - The technology that we used to use to diagnose it, it’s all gone
    - Nobody uses it anymore, it’s old fashioned
  - It can be diagnosed based on the triglycerides, total cholesterol, and apoB
  - Allan developed an algorithm to diagnose it, published in 2018: [The spectrum of type III hyperlipoproteinemia](https://pubmed.ncbi.nlm.nih.gov/30318453/)
- The phenotype of this patient is they have relatively few particles, but they have so much cholesterol because the VLDLs are so large and so cholesterol full
- It’s unclear why this condition is so dangerous, given the relative lack of particles
  - There are 40 or 50x as many of these particles as compared to normal
  - One can’t use just apoB to make this diagnosis

**The need to measure both Lp(a) and apoB**

- When Allan follows a patient (who doesn’t have remnant type III hyperlipoproteinemia), he uses just 1 number, apoB
- Peter discusses an example where 3 people all have the same apoB concentration but have very different risks of CVD; the patients differ:
  - 1) Very, very high [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)), resulting in a much higher risk of CVD
  - 2) Normal phenotype
  - 3) Type III hyperlipoproteinemia (as just discussed), resulting in a much higher risk of CVD

- #1 & #3 have more atherogenic particles on a particle per particle basis

- Allan agrees, #1 & #3 have more particles that contribute to clinical events
- In his practice he measures Lp(a) and apoB
  - He measured Lp(a) once
  - When Lp(a) is high, but apoB is normal, Lp(a) may not add that much risk
  - When Lp(a) and apoB are both high, it’s a double whammy

- These patients have many cholesterol-rich VLDLs, despite a normal apoB
  - Their triglycerides are also elevated, they are in VLDL particles
- They usually respond very well to [Statins](https://en.wikipedia.org/wiki/Statin) and/or [fibrates](https://en.wikipedia.org/wiki/Fibrate)

## Using apoB to estimate risk of CVD [37:30]

- Allan and colleagues made up an algorithm (the [ApoB app](https://apob.app/about)) to get the diagnosis of any atherogenic ApoB lipidemia
  - The app works from the web, [ApoB.app](https://apob.app/)
  - Plug in plasma levels of: (1) total cholesterol, (2) triglycerides, and (3) apoB
- Part of the argument against apoB, people say it makes things too complicated
  - When a doctor explains to a patient they have a lot of bad cholesterol, they get it
  - When a doctor reviews how well a patient is doing on statins, if their triglycerides were high to begin with, they are unlikely to normalize; HDL is unlikely to normalize
  - If their apoB is good, they’re good
    - ApoB is Allan’s target of therapy because it’s the total number of atherogenic particles
    - The figure below shows the relative numbers of apoB particles in plasma after a meal

![](https://peterattiamd.com/wp-content/uploads/2021/11/f9-allansniderman.jpeg)

**Figure 9.  Relative numbers of apoB particles in plasma after a meal.** Figure credit: [Particles and Cardiovascular Disease: A Narrative Review, figure 2](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7369156/)

- Nordestgaard had a paper recently in the *Journal of the American College of Cardiology* on discordance analysis of non HDL cholesterol in apoB
  - It showed that apoB was a more accurate index on statin treatment than on HDL cholesterol
  - Published in 2021, [Apolipoprotein B and Non-HDL Cholesterol Better Reflect Residual Risk Than LDL Cholesterol in Statin-Treated Patients](https://pubmed.ncbi.nlm.nih.gov/33736827/)
    - Peter comments, “*this is a great paper*”
  - Peter finds it easier to explain to patients what apoB is than to explain what non-HDL is

> “It’s interesting to me that with all the emphasis that so many of the lipid guidelines have put on non-HDL cholesterol, they all still say LDL cholesterol. The American guidelines clearly state apoB and non-HDL are better than LDL, but the world has remained.” – Allan Sniderman

- Allan doesn’t understand why the lipid world has been so resistant to change
  - And he’s pessimistic that it will change any time soon
  - In Europe, the 2019 guidelines were very pro apoB

> “The evidence from Mendelian randomization, the newer technologies, Mendelian randomization, they’ve just been a slam dunk for apoB.” – Allan Sniderman

## How Mendelian randomization is bolstering the case for ApoB as the superior metric for risk prediction [40:45]

- In the conventional ways of taking things apart with [prospective observational studies](https://en.wikipedia.org/wiki/Prospective_cohort_study) (like the [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study)) there’s a limited amount of the certainty of the conclusions because of confounding that can’t be dealt with
  - This study takes measurements at age 20 and then follows someone for the next 30 years
  - A lot of things change in 30 years
    - The inferences are probable but not causal
- [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) allows one to come a lot closer to causality
  - For example, one can identify groups of genes that are associated, where changes in the gene are associated with a little lower cholesterol or a little higher cholesterol
  - When one lumps together a bunch of those different genes that can have different makeups, one can see fairly substantial differences in cholesterol
  - This allows the study of information on somebody that’s fixed at birth to answer the question, is that associated with a difference in outcome?
- What a number of Mendelian randomization studies have shown is that apoB includes all the information in triglycerides, LDL cholesterol, and even HDL cholesterol; it sums them
- [George Davey Smith](https://en.wikipedia.org/wiki/George_Davey_Smith) (one of the founders of Mendelian randomization) is the author of a number of Mendelian randomization saying apoB incorporates and therefore beats triglycerides and LDL cholesterol
  - Published in *JAMA* in 2017, [Association of Genetic Variants Related to CETP Inhibitors and Statins With Lipoprotein Levels and Cardiovascular Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5710502/)
  - This is a huge level of information that isn’t even mentioned in almost any of the guidelines
- There are caveats in Mendelian randomization
- To summarize, when following a cohort prospectively, the way the Framingham cohort was followed (or the [Framingham offspring](https://en.wikipedia.org/wiki/Framingham_Heart_Study) or the [MESA cohort](https://en.wikipedia.org/wiki/Multi-Ethnic_Study_of_Atherosclerosis), or any of these cohorts have been followed), one can take a bunch of people and measure their apoB or their LDL-C or whatever metric, it is that one is trying to determine if it in fact has a *causal relationship* to the disease of interest
  - This cohort can be followed over decades
  - It has been demonstrated that the people with higher apoB, higher LDL-C, higher non HDL-C, and lower HDL-C all have a higher risk of developing atherosclerosis over time

> “It’s hard to say that that’s causal just based on that information, because over the ensuing 20 years that you follow them, they are free to make other choices that may impact those variables of interest and other variables.” – Peter Attia

- The Mendelian randomization attempts to get around that by saying at the time of conception, we all get randomized to a set of genes
- If one can identify which genes map to which phenotype (and one can figure out the genes that mapped to the phenotype of our interest, namely driving up or down a variable of interest such as apoB) then there’s no worry about the confounders that occur in between, because the genes can’t change
- Now when a difference in outcome is observed, it’s much more likely to be causally related to the phenotype of interest because the gene has not changed that underlies it

- Allan notes that HDL cholesterol was the total rage because the epidemiological evidence couldn’t be clearer
  - Peter recalls that the Framingham study demonstrated that low HDL-C was 4 times more predictive of cardiac events than high LDL-C
  - Allan agrees that the difference is definitely multiples
  - Further it is known from [CETP inhibitors](https://en.wikipedia.org/wiki/CETP_inhibitor), that *one can’t manipulate HDL and change outcomes*
  - That’s one of the elements of demonstrating an overall causal relationship
  - The Mendelian randomization shows HDL is not causal
    - Whereas they also show that apoB and cholesterol are causal
- In the past 10 years, it’s an incredible technical advance in being able to examine questions and look at numbers of people that would be unimaginable in conventional studies
  - The Mendelian randomization studies involve hundreds of thousands of people because they’ve got these huge data banks with genes and those numbers can around the confounding of things
  - There are huge numbers, but it’s like any methodology, no method is perfect
  - This one can mislead you too, particularly when you’ve got a sequence of associated variables
    - For example, people showed using mendelian randomization (MR) that triglycerides were “*causal or associated with increased risk*”
    - But when one takes into account the non-HDL cholesterol or the apoB, it disappears
    - When there is a linked metabolic chain, one has to be careful to go to the end of it, to get to the real actor, not Act One leading… get to the real [personae dramatis](https://en.wikipedia.org/wiki/Dramatis_personae)
- Peter notes his surprise that HDL didn’t demonstrate causality (at least at the first order) because there’s no doubt that phenotypically, the high triglyceride and low HDL phenotype is so associated with metabolic syndrome
  - High triglyceride and low HDL make up 2 of the 5 criteria of [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome)
- Allan notes that HDL is an incomplete description
  - It’s like  describing yourself as six feet tall, not telling the weight, and asking about BMI

> “You cannot characterize any phenotype without the apoB” – Allan Sniderman

- How can the system be evaluated without counting the number of atherogenic particles?
  - They could be normal, they could be high or the patient could have a type III
  - There is no phenotype without putting an apoB in there
- They’re lipoprotein particles, they’re disorders of lipoprotein particle metabolism
  - Of course the triglycerides and cholesterol are important; but this information is incomplete without apoB

## Hypertension and CVD risk [49:15]

**Factors that increase formation of arterial plaque**

- In terms of pathophysiology, the apoB bearing particle wreaks havoc in the artery wall many, many years before clinical events are observed
  - There are other factors that can amplify or exacerbate this
    - 1) Smoking
    - 2) Hypertension
      - Do these factors carry a greater risk for atherosclerosis than apoB?
- In the last 30 or 40 years there have been almost an infinite number of basic science studies on hypertension
- Hypertension is having higher blood pressure than what is normal
- What strikes Allan is the lack of discussion about the pathophysiology of hypertension
- But the basic science that goes on in rats, is healthier than ever; and he doesn’t know of anything that’s come out of that basic science that’s been clinically useful in the last 30 years
- The drugs prescribed to treat hypertension work

> “Where is the disease that produces that higher blood pressure? Is it resistance? We don’t have a clue.” – Allan Sniderman

- To Allan, it’s the same thing as much of the debate in lipids about apoB; it can be likened to the drunk looking for the key under the light because this is where the light is, not where he lost the key
- Allan thinks hypertension arises from the loss of elastins in the proximal aorta, and that causes systolic hypertension
  - He doesn’t think it’s complicated
  - Now, what could accelerate this process?
- The literature on hypertension focuses on peripheral arterial tone and complex metabolic studies in sophisticated animal models, as well as some renal studies
  - It’s all [miasma](https://en.wikipedia.org/wiki/Miasma_theory) for him

**Mechanism**

- Allan explains the role of proximal aorta in hypertension as he sees it
  - The proximal aorta is elastic; if one looks at a flow curve (a hydrostatic pressure curve) when a patient is young it’s rounded because as the left ventricle ejects blood rapidly into the aorta, the aorta expands and absorbs some of that energy
    - Recall that wind castle that they’ve mentioned in school, but the energy is partially captured, partially regained; but the wall isn’t battered; the wall can give way
    - Imagine if those elastic fibers start to go, then the walls stiffen; now when the left ventricle ejects blood, the pressure goes up more rapidly and it falls more rapidly in diastole
      - This could be why systolic hypertension occurs while diastolic pressure is normal
  - He suggests looking at factors like cardiac output again (which used to be studied way back when) or factors that alter the behavior of the proximal aorta
    - He believes these are much more likely to be involved
  - With hypertension there is a driving force to push particles into the wall
  - With hypertension, the wall thickens up and it gets harder for particles to go through
    - The response of the wall changes, and this leads to the increase in blood pressure
- Peter asks about damage to the endothelium
  - Allan doesn’t understand endothelial dysfunction, but he knows the endothelium is critically important
  - It functions abnormally and how that fits into the overall pathology, he doesn’t know
  - Allan bets apoB particles are part of the process inducing endothelial dysfunction, but he doesn’t  know that clearly, experimentally
- Does it make sense to compare hypertension to apoB?
  - They both seem to play a causal role in CVD
  - Is one more causal than another or is that a silly question because they’re not binary and static?
    - Allan thinks this is not the right question
- Blood pressure goes up with age; hypertension involves a large part of the population
  - It seems that hypertension is becoming part of the aging process
  - Humans are lasting a lot longer than we were probably designed to
  - There is this repetitive injury to the proximal aorta, and it gets a little progressively less able to deal with it
    - So by the time a person is 50, somewhere around 60% have higher blood pressure; the figures are staggering
- ***Does ApoB rise with age?*** Yes, but not that much
- When one looks at people at age 35, one can accurately categorize the group they belong to at age 35
  - If one is  high at age 35, they’ve got about a 95% chance of staying high; 5% will go out of the high zone; they won’t go low, low
  - If one has high blood pressure at age 35, he would expect anything is going to move them down
    - This is why he thinks blood pressure is a good signal for when to start thinking about treating people
  - Some people go from low toward high, but the majority don’t
  - For people with high blood pressure, about 90% remain high

**Gender differences**

- Peter has seen women experience dyslipidemia as they go through menopause; this is something men men wouldn’t experience over that same decade or even five-year transition
- Allan notes that apoB goes up with menopause
  - He would like to see more data on this
  - The science has been held back because people don’t measure apoB

[56:45]

**Current trends**

- The incidence of coronary disease is going up in the last five years
  - Despite statin therapy
  - That’s due to obesity and diabetes
- There are many reasons that treatment is not succeeding as well as it should
  - The complexity of the lipid phenotype of the lipid model is part of the answer
  - Peter notes that there is a greater and greater portion of the population that is being undiagnosed or being underdiagnosed because doctors are treating their LDL-C
    - And what Allan suggests is that LDL-C is lower than their risk actually is because their apoB is higher
    - This is because doctors are trying to quantify lipoproteins based just on lipids; this is not adequate; it doesn’t capture all the information it should

> “Trying to quantify lipoproteins based just on lipids is not adequate. You’re not capturing all the information that you should.” —Allan Sniderman

## Factors influencing the decision to begin preventative intervention for CVD [58:30]

**Factors that influence the decision for intervention**

- Allan doesn’t know what it is about smoking that drives risk of atherosclerosis so much
  - It does though, and it drives treatment decisions
- Allan believes people with high apoB levels should be treated because they have a longer-term risk of CVD
- Smoking gets one up in the category to have their life saved; bad behavior gets one closer to having their life saved
  - It’s in the risk calculators, see the figure below
  - The risk goes up for a smoker
    - It changes the prioritization
    - Bad behavior increases risk so one gets more medical attention

> “I think bad behavior is our responsibility to help people deal with, but I don’t think it should put you to the head of the line for preventive therapy.” – Allan Sniderman

- Peter would argue that there is not line; anyone who wants preventative therapy should be getting it
  - Are these resources limited?
- Allan feels patients are not given the information they deserve
- He published a paper in *Circulation* in 2000
  - [The Expected 30-Year Benefits of Early Versus Delayed Primary Prevention of Cardiovascular Disease by Lipid Lowering](https://www.ahajournals.org/doi/epub/10.1161/CIRCULATIONAHA.120.045851)
  - It assessed the costs of delaying intervention starting at age 35, 45,  and 55 for patient’s whose non-HDL is low
  - The gains of starting lipid-lowering treatment at age 35 are quite small
  - The gains here are with 35-year-olds who have high non-HDL
    - Physiological and epidemiological knowledge suggests about 20% of the population are at high risk at age 35 and should consider intervention
  - Part of the information patient’s need to know is how much is gained now versus how much is lost by waiting
    - This is why these methods of calculating benefit are so important
- What fraction of the population has relatively normal apoB, relatively normal triglycerides, and yet has accelerated atherosclerosis through some combination of yet to be identified polygenic risk factors?
  - Atherosclerosis can run in families even when there’s no obvious cause
    - They don’t have FH (familial hypercholesterolemia)
    - The don’t have Lp(a)
    - Their apoB is around the 50th percentile of the population
    - Yet, they are disproportionately afflicted at a young age, all having first events before age 60
  - This question needs more research
  - Allan would **look at factors that affect the trapping apoB particle within the arterial wall**
    - He thinks [Kevin John Williams](https://medicine.temple.edu/kevin-williams) from Philadelphia, they’ve done an amazing job in putting this all together
- Family history of CVD does factor in Allan’s decision for intervention; but if the apoB is low he would be less inclined to treat
  - An apoB around the 50% percentile in patients with a family history would make him more antsy; higher they are, the more antsy he gets
- A lot of these decisions at the individual level, actually, aren’t that difficult when one is speaking to a particular patient because they have their own objectives and goals
- Medications have risks associated with them
- Allan doesn’t think we fully understand the relationship of statins and diabetes
  - Statin therapy is amazing, but it’s not at no cost
  - When he talks to an individual human being, it’s easier to make clinical decisions individually than to write rules for groups

## Using the coronary artery calcium (CAC) score as a predictive tool [1:03:15]

- The [coronary artery calcium score (CAC)](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan)
- Coronary calcium is an important step forward in cardiovascular imaging
- It uses x-ray techniquest to accurately and safely determine whether there’s calcium (bone) in the coronary arteries
- Calcification is a feature of advanced atherosclerosis
- There’s very strong evidence that people who have coronary calcification are at higher risk of a heart attack or stroke than people who do not have coronary calcification
- There are several facts to consider:
  - 1) The frequency of a positive coronary calcium goes up as we age (so does the risk of disease)
    - All American men by age 60 are at high risk according to current guidelines; women are five to 10 years later

- At age 60 the CAC test isn’t helpful

- In most people arteries become substantially transformed in bad ways by age 60
- But in people younger than 60, this can give extra information that is helpful, should the doctor be on the cusp of treatment
- This test would be for the patient who wants more information to help them decide about intervention

- 2) There is a problem with the corollary, if the coronary calcium is negative concluding that the patient is okay

- From Allan’s interpretation of the literature, coronary calcification is associated with advanced disease
- When people have a heart attack, they don’t just have one little area of their arteries that are abnormal; that’s simply the area where the plaque broke or the endothelium eroded, but the whole artery is diseased
  - This means there’s a chance of an event a cm down or a cm closer
- If a patient has high apoB, the fact that their coronary calcium is negative doesn’t mean they don’t have a lot of disease and that the disease isn’t developing at a rapid rate; it could be there
- There’s an argument saying, if the coronary calcium is negative, nothing’s going to happen to in the next five or 10 years
  - Maybe this is true; but the disease is developing and doctors can’t make the disease go away
  - Doctors can modify the effects of the disease, modify the consequences

- For a patient who has been treated and their LDL, cholesterol, and apoB levels are brought low, remember that they still have an artery that is destroyed; they’re going to have a substantial number of events
- [John Wilkins](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=16809), and [Don Lloyd Jones](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=16679) from Northwestern, they have a paper in *JAMA* but it’s terribly complicated (they’re Allan’s friends so he can be honest)
  - Published in 2021, [Novel Lipid-Lowering Therapies to Reduce Cardiovascular Risk](https://jamanetwork.com/journals/jama/article-abstract/2782198)
  - They find that waiting for coronary calcium before starting treatment is a bad idea
- Allan is conservative when it comes to protecting patients
  - He wants to give  them the option to have the best outcome possible when they appear to be in danger
  - So he wouldn’t use a negative coronary calcium to change his clinical decision for patients who have high apoB or another cause of vascular disease present
  - He thinks CAC is a good test, but has relatively limited utility for him
- Peter uses a 2 x 2 matrix to explain this to patients; he considers the patient’s age and CAC score
  - A 70-year old who has a calcium score of 50 doesn’t tell him much
  - An older patient with a calcium score of 0 who is adamant about not getting treatment; this is an easier decision to accept
    - It would be fortunate to have a calcium score of 0 at age 73 with an apoB of 140 mg/dL

- On the flip side of things is a young patient who has a positive calcium score; really that’s a 4-alarm fire
  - Allan agree’s, treating this patient is a no-brainer
- Regardless of apoB, for a patient under 50 who has a speck of calcium in their coronary arteries, that’s utterly unacceptable
  - Allan agrees; if it’s positive, it’s only going to go up
  - Peter notes it says something about the entire system, that might be the one area in the middle of the patient’s left, anterior descending artery where it’s at an advanced stage, and calcium is laid down

> “It’s like looking at the concrete that’s been poured over Chernobyl and trying to infer what’s going on in the 10 miles around Chernobyl. It’s all bad.” – Peter Attia

- Where Peter finds the most challenge is with the group think that says if a person’s calcium score is zero then no treatment is needed
- This gets back to Allan’s paper looking at the 30-year risk and causal model
  - Published in *JAMA Cardiology* in 2018, [A Long-term Benefit Approach vs Standard Risk-Based Approaches for Statin Eligibility in Primary Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6583050/)
  - Published in *Circulation* in 2020, [The Expected 30-Year Benefits of Early Versus Delayed Primary Prevention of Cardiovascular Disease by Lipid Lowering](https://www.ahajournals.org/doi/epub/10.1161/CIRCULATIONAHA.120.045851)
  - He mentions briefly at the outset the example of a 45-year-old person for whom their apoB is higher than they should be; their calcium score is expected to be zero and it is; here the calcium score didn’t really add much information to decision-making
    - When someone is at 7.8% risk, it’s tough to absorb in a meaningful way
    - If the risk was 30%, 1 in 30, that starts to be truly meaningful

## The challenge of motivating individuals to take early interventions [1:12:30]

- How does a doctor get someone excited about a 5% risk of an event in the next decade, if the patient is 50?
  - Well, 2 things are wrong  here
  - 1) The doctor/ patient shouldn’t be thinking about just age 60 (think age 80); a 50-year-old would be expected to live a minimum of 30 more years
  - 2) 5% is not much to get excited about

- Put this risk in a different context, tell a 50-year-old there is a 5% chance in the  next decade they will die on a commercial plane
- How will they change their behavior?
  - Allan says he wouldn’t stop flying, because there is a 95% chance he won’t die
  - Peter’s point is that 5% is a bigger risk than people realize
  - The treatment of not flying in an airplane for 10 years is far more of a burden than treatment to lower lipids
  - Risks can be combated
- Allan asks what the confidence intervals are on that number of 5%
  - Let’s say +/- 2%
  - Allan asks where he’s seen this number
  - Pretend it’s at the population level (one can’t have this number for the individual level)
- Allan’s point is that confidence intervals for risk are never published
  - When scientists get any result, they get the range of possible results to let them know how accurate the prediction is
  - If the number is 5% and the confidence interval is 4.5 to 5.5 by maybe the confidence interval is 0 to 70

> “I’m saying we’ve got an industry that captured clinical care, that doesn’t include error.” Allan Sniderman

- Peter agrees, it seems almost impossible to believe that the error or confidence level is not reported
- Allan remarks that doctor’s have become less critical

## How medical advancement is hindered by the lack of critical thinking once a “consensus” is reached [1:15:15]

> “This process of forming opinion in medical care, this appeared over the last 30 or 40 years, has damped down the essential element of science, which is, challenge different viewpoints.” – Allan Sniderman

- The contention of ideas
- The creation of an experiment to say this is the right way
- Or someone with a different view creates a different experiment
- Science is a democratic activity where differing views are legitimate and have a chance to contend
  - He’s not saying every crazy theory has an equal, because it doesn’t

Peter asks “*who is the arbitrator of what’s a legitimate differing hypothesis?*”

- In science, it’s called the experiment
  - That is what’s different about science, an experiment is done to test a hypothesis
  - If the hypothesis is sustained, one can continue to hold the hypothesis
  - If the hypothesis falls, then one must reframe their understanding
  - Experiments are a tool to gain understanding
- Experiments are not as easy as it sounds
  - Methods could become complicated
  - Statistics used to analyze data are complicated
  - Conclusions drawn may or may not be correct; error occurs
- When Allan was a medical student, the major medical meeting of the year was in Atlantic city and the big professors would have different views and they would argue them out
  - It was a contentious open battle
- Then evidence-based medicine came along
  - It has lots of plusses, such as the use of [randomized clinical trials](https://en.wikipedia.org/wiki/Randomized_controlled_trial)
  - But it allowed the belief to develop that knowledge is easy to assess; and it’s not
    - It’s not easy to assess experiments all the time
    - Some of them are straightforward; most of them actually aren’t

> “And it’s important that we acknowledge the uncertainty and say, well, maybe there’s another way of looking at this that’s even better” – Allan Sniderman

- Tools like statins were developed; and there’s very good evidence they can save lives
- This process of consensus came along saying, this is too complicated for regular doctors, and it is; they don’t have the time to analyze all the evidence
- So we’ll analyze the evidence for them and write it out in a way that tells them what’s the best we can do now
  - There’s a lot of good in that, but there’s potential weakness
  - Allan thinks a lot of the weakness is happening because one view becomes the conventional view, and it hangs on longer than it should

**Science is about change**

> “If we’re still saying the same things we said 30 years ago, it could be a problem because we should have learned how to say it better, more accurately.” – Allan Sniderman

- In these consensus conferences the recommendations are unanimous
  - The Supreme Court isn’t unanimous often; there’s a majority view and a minority view
  - It could turn out that over time the wisdom of the minority view become apparent
- Any process where the decisions become larger than the individuals who propose them has a weakness
  - For example, the American College of Cardiology, the American Heart Association, and about 30 other groups are actually about 100 people
    - They’re good people, but cloaked in the anonymity of the group they become impervious to criticism, even when there’s obvious inadequacies
    - And that’s not science
    - If someone published a paper, someone else can do an experiment and try to overturn the paper or confirm it
- But with the guidelines, they’re the judgement cast in stone until the next group of guidelines
  - Depending on which people write them, it can influence what one sees
- Peter would add even more complexity to it, which is if one goes through the critical steps are for the elucidation of knowledge:

- 1) The formation of a hypothesis
- 2) Designing an experiment to test that hypothesis
- 3) Conducting that experiment
- 4) Analyzing the results of that experiment and interpreting it

- These are quite discrete steps
- Any one of these steps offers infinite ways to do it wrong and a relatively few great ways to do it right

## PSK9 inhibitors and familial hypercholesterolemia: two examples of complex topics with differing interpretations of the science [1:20:45]

**Trials of PSK9 inhibitors**

- For example, yesterday Peter was discussing lipids with a friend and the [FOURIER trial](https://en.wikipedia.org/wiki/Evolocumab) (that looked at one of the two [PCSK9 inhibitors](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target))
  - Published in the [New England Journal of Medicine](https://www.nejm.org/doi/10.1056/NEJMoa1615664?url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0www.ncbi.nlm.nih.gov) in 2017
  - The drug is [Repatha](https://www.rxlist.com/repatha-drug.htm) (generic name Evolocumab)
  - This trial demonstrated that for patients who were on a very high level of statins and had a very low LDLC (their average LDLC was in the neighborhood of 70 mg/dL), over a 5-year period they had a reduction in cardiac revascularization, but no change in mortality
  - The point is, how can these drugs be tolerated?
  - Why are insurance companies paying for these drugs, people using them, doctors prescribing them when there is no demonstration of a reduction in mortality?
  - Peter sometimes confuses the ODYSSEY trial (with the [other PSCK9 inhibitor](https://en.wikipedia.org/wiki/Alirocumab)) with the FOURIER trial
    - Phase 3 results of the ODYSSEY trial were published in [The Journal of Clinical Lipidology](https://www.lipidjournal.com/article/S1933-2874(14)00331-6/fulltext) in 2014
  - These studies were short and on a group of patients who were already heavily statin-ized so Peter thinks it’s a miracle they showed anything at all
    - These patients are already walking around with a LDL-C that is 5th percentile of the population then they are given another agent to lower LDL-C to the 1st percentile
    - Plus this is a disease that takes at least 4 decades to take hold and they are only studied for 5 years
    - It’s amazing any difference was observed
    - In the ODYSSEY trial though, patients started out with a higher level of LDL-C so there was potentially a greater risk reduction
  - Peter and his friend debated these trials; 2 smart people looking at a well done experiment with reasonably legitimate statistics but they have a different lens for what the disease is and therefore draw different conclusions
    - How can consensus resolve that difference?
    - How can this debate be refereed?

- Allan contends, “*We can only understand as individuals, there is no such thing as a group understanding, we can’t get beyond ourselves*”

**Familial hypercholesterolemia**

- Allan is currently writing a paper about [familial hypercholesterolemia (FH)](https://www.ncbi.nlm.nih.gov/books/NBK174884/)
  - There is study showing that patients with this disease who have a genetic abnormality are at  much, much, much, much higher risk than people with similar LDL cholesterol, but without the genetic abnormality
    - This study has been accepted by everybody as being well done and decisive, and I mean by everybody
    - This compares 2 patients, phenotypically identical but one  has the genetic abnormality of FH and the other does not have this genetic abnormality
    - This study reports that patients with FH carry a risk not present in patients with the [wildtype](https://en.wikipedia.org/wiki/Wild_type) [allele](https://en.wikipedia.org/wiki/Allele); their risk is 3-5-times increased, or 300%
      - Both Allan and Peter find this unbelievable
  - Allan read read the study many times and finally he thinks they made a mistake in their methodology
    - This is what Allan’s current paper is about
  - He will write up his interpretation and findings and subject it to review and criticism
    - Since he is saying that every authority in the field is wrong, he thinks his chances are slim that this will receive a positive reception
    - But the error in methodology is so simple and decisive that he thinks he is right

> “We have to continue to think and discuss with ourselves” -Allan Sniderman

- Everyone believed HDL cholesterol until they didn’t
  - How many dissenters were there until everybody said it was obvious, there was nothing there
  - A [review from 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4829575/) discusses the lack of reduction of cardiovascular events after increase of HDL-C ([niacin](https://en.wikipedia.org/wiki/Niacin#As_lipid-modifying_medication) intervention)
- We are all human beings; we search for validation, but real science isn’t about that
  - It turns out the world is a very slippery thing to get your mind around

## Defining risk and uncertainty in the guidelines [1:26:00]

**Risk**

- Risk is the number of events per standard number of people over a defined period of time
- If the risk is 5%, that is 1 in 20 per standard group of people
  - This is why Allan said risk is low if you’re under 60, the number of events per hundred people is low
    - But the number of hundred people is a lot larger than over 60; that’s why the absolute number of events is so high
      - This difference in words means a tremendous difference in action

> “So a difference of words, tremendous difference in action, because it means I don’t use the 10 ten-year risk model” – Allan Sniderman

- This has been published and reproduced by other investigators, but the guidelines have not changed and that is wrong

**Guidelines**

- When Allan looks at the guidelines, he can look at the literature on an issue
  - He has enormous respect for people who serve to create the guidelines
  - He can tell you who wrote the guideline
- There was a recent guideline from Europe that was negative about apoB
  - One paper cited, just one paper and that became the guideline
- Allan is not talking about throwing out the process
  - The process of reviewing knowledge in a group is positive
  - He’s saying to watch out for the process
  - It needs to include a multiplicity of views to avoid bad decisions

> “And if you don’t think we can’t make bad decisions, just look at all the bad decisions the politicians and the business guys make. We’re no different.” – Allan Sniderman

- Peter asks about consensus, if a more heterogeneous group of views and greater diversity of priors was brought together then they would probably never arrive at a unanimous decision
  - Allan sees nothing wrong with this
- Think of the doctor who has to see 40 patients in a day, will never listen to this podcast, let alone read the show notes of this podcast; they literally just want to know what to do in the moment with the person sitting in front of them
  - Currently doctors look to the guidelines which are unanimous, expert run, and revised often enough that it gives one the feeling that they’re keeping up with the science, right?
  - Every five to 10 years, a new guideline will come out
    - Now it’s going to be this complicated, legal document, that’s like reading the dissents and reading the in-favors
    - Peter’s not saying this shouldn’t be done, but how does it translate to the field?
- Allan relates that the guidelines now are totally miserable; talk about legal documents
  - There is a summary and that’s what doctors typically read, the 1-page executive summary
- Allan gets this rebuttal all the time, that the guidelines have to be dumbed-down because the doctor who sees 40 patients isn’t going to read it and do anything otherwise
  - Allan doesn’t think most doctors are dum; he thinks they’re caring and want to do a good job
  - Allan thinks the field needs to learn more about how to present information
  - He doesn’t think the truth should ever be compromised because when one does it says “*I’ve got to do this in order to get to here*”; and that’s not right
    - Use Afghanistan as an example, “*I can’t think of anybody right left or center who thinks that the process getting in and throughout it represents the best efforts of the minds of America*”
  - Problems happen when the options have to be boiled down to get a one-liner
    - A one-liner is not real life

> “And if we’re going to learn to make decisions that are to present information with our patients we’re going to have to learn how to deal with doubt, that’s what it’s all about” – Allan Sniderman

## Making clinical decisions in the face of uncertainty [1:31:00]

**Dealing with uncertainty**

- Peter notes that doctors are not trained to be comfortable with uncertainty
  - Allan thinks they are; this is what medicine is all about
- Peter concedes that uncertainty is acceptable for things that can’t be measured
  - Take for example a a surgeon in the ER evaluating a patient for appendicitis long before the days when everyone had a CT scan (in the ‘50’s  and ‘60’s)
  - A purely clinical diagnosis is needed
  - The surgeon knows that 7% of people in their lifetime are going to have appendicitis
  - The pre-test probability on this person in the ER is probably much higher than 7% because they are presenting with the signs and symptoms of appendicitis
  - There’s an asymmetry in the decision; 2 wrong decisions can be made here: operating on the person without appendicitis and not operating on the person with appendicitis
    - Decision making has to be calibrated around that uncertainty so that one mistake is more likely than the other
    - Most physicians are very good at doing this
  - Somehow that doesn’t translate into the type of uncertainty he thinks is necessary to do what Allan suggests
    - Which is rather than give people a unanimously agreed upon consensus that is so distilled down to simplicity that it borders on being incorrect, present a range of thoughts on the subject and acknowledge that ones doesn’t know which is correct
- Allan notes the differences in audience: practicing family doctor, practicing internist, academic internist (they are experts in the field)
- At a minimum there needs to be a range of opinion in the experts in the field
  - Allan doesn’t think this is currently the case
- When there is doubt, alternate views should be published
  - He’s not sure this is currently the case
- People write about weak recommendations but they are also always unanimous
- What happens to discussion with 5 people in a room? Doctors and experts are no different
  - The one with the loudest voice can carry the day
  - The one who claims the greatest expertise in the area can carry the day
  - This is how a document is produced that is difficult to read
  - The documents read like they did 20 years ago, with minor modifications
  - This is wrong

> “What’s our problem, who are we here for? Ourselves, or our patients and the truth” – Allan Sniderman

**The need for better communication of complex ideas**

- - Allan thinks things can be written clearly so people [doctors] can read and make informed choices
    - At the end of the day, what the current state of the guidelines are sayings is that “*people are too stupid to make a real choice*”
      - Allan thinks there is a better way
  - When Allan has treated patients and made recommendations, were they always the right ones? Of course not.
    - They were what he thought was best to advice
    - He can’t claim they were always right
  - But in knowing that he could be wrong, he calibrated the safest way through for the patient
    - Algorithms can help

- But when doctors treat just by algorithms, then that isn’t clinical medicine

- Advanced healthcare professionals can take the algorithms, and work within them and around them, and everybody’s doing a good job

> “But we’ve got to respect the fact that our understanding is limited. And that science requires different views to contend equally. And then we need to write the truth.” – Allan Sniderman

## How the emphasis on consensus and unanimity has become a crucial weakness for science and medicine [1:35:45]

**Problems with consensus when understanding is limited**

- Peter asks if he’s seen an acceleration of forcing function around a uniformed voice
  - The past 18 months with COVID, has really amplified what Allan’s describing
  - Peter thinks there are lots of dissenting views out there for how COVID could be managed, the potential efficacy for repurposed drugs
  - Truthfully, he’s struggled to wade through the literature on this stuff
- One can always find somebody who’s made it their mission to understand how this drug or that drug, or this intervention or that intervention, is the solution to the problem
  - There’s no denying that such people have been pretty roundly silenced before this
  - It begs the question, should the field be paying more attention to these views?
  - And when do these views become so fringe and marginal that they’re actually harmful?
    - Allan agrees, fringe views can become harmful
- Allan contends that the first level of discussion should be amongst experts
  - Importantly, it is here that views that are so divorced from experimental evidence, that they’re not serious views can be called out
- Allan is not talking about legitimizing any possible view because it’s a possible view
  - He is saying that people were pointing out different aspects of a complex problem, and they might put a little more emphasis here, but the result would be that everyone understands more clearly that there are a series of choices involved, and it’s challenging to go through them
- Here’s an example of a decision, made in real time, that’s a real challenge – in Canada, there was a much longer period between the first and second COVID vaccination
  - So more people got their first dose before the second one was given out
  - No one can be sure this is the right decision in the moment, but it has to be made and dealt with
  - The decision was made in the open, so everyone knew what was being done
  - Allan is good with that process, because he knows what happening, and the outcome can be assessed
    - He’s not good with someone just shrieking
- Allan’s against silencing debate; he doesn’t buy the argument that “*because we can’t have somebody shrieking, we can’t have any debate. That’s wrong, that’s totally wrong*”
  - This leads to mistakes happening where they don’t have to happen
- The responsibilities doctors have to make recommendations to their patients are so awesome, there is a need for doctors to be humble and say to each other “*okay, give me your best shot, I’ll give you my best shot; we’re colleagues, we’re not enemies*”
- Allan disagrees with lots of people because he has a scientific viewpoint, but they’re not his enemies
  - There are have ways of discussing this
    - If he’s in the room, he can say, “*hey, you said that, I’ll show you line 26 in your paper, which contradicts you; and he has to respond in front of other people*”

> “That’s what I believe in; the testing of the argument in a jury of your peers” – Allan Sniderman

**Less discussion of alternate views**

- The culture in science is being watered down
  - It’s not the same today as it was 30 years ago
  - Allan thinks this is the crucial weakness
- As he judges by the product coming out of the committees forming guidelines, discussion of differing viewpoints inside the room is not occurring
- People get attached to views because there’s emphasis on consensus and unanimity
  - People may not want Sniderman in the room because he’s going to argue for apoB
  - Allan contends they can deal with him; he’s not hard to deal with
    - They can say, “o*kay, I heard you, but here’s what’s wrong with your argument*”
      - Not what’s wrong with “*you personally*”
- Peter asks what has changed to make ideas more personal
- Allan thinks people are invested
  - People used to become known for their own science; now if someone is on the guidelines, that’s their science
  - One becomes prominent because they are on the guidelines, not that they did the science
- There is so much science that’s done
  - Clinical trials for example; they are wonderful, but they are limited tools
- Allan thinks the composition of the committees needs to be re-examined
- He thinks one should be able to criticize what comes out
  - For example, apoB is Allan’s thing
  - He wrote a critique of the 2018 American Guidelines
    - Published in the *Journal of Clinical Lipidology* in 2019, [Did the ACC/AHA/AACVPR/AAPA/ABC/ACPM/ADA/AGS/APhA/ASPC/NLA/PCNA cholesterol guidelines get apoB right?](https://pubmed.ncbi.nlm.nih.gov/31229023/)
    - How many references in the guideline were there on the comparison of apoB and LDL cholesterol, and non-HDL cholesterol?
      - 4, 2 from Allan and 2 from an opposing group
    - This is just 1 issue; the guidelines dealt with a whole bunch of issues
    - This is not adequate; it wouldn’t get a passing grade in school
    - Space is not the limit for dealing with these issues anymore; anything can be put on the internet for those who want to read it
- What is reprehensible to Allan is not knowing what going on inside the room where the guidelines are made
  - Was there a full discussion?
  - This process didn’t occur when he was younger; contending ideas could contend more easily

## Factors holding back the advancement of apoB for assessing CVD risk, treatment, and prevention strategies [1:41:45]

**ApoB didn’t make it in the guidelines**

- He doesn’t think apoB is going to be utilized because there is a group of people who just aren’t interested, and this is sad
  - The guidelines present it as a cost issue
  - But apoB bills the insurance company for $4 and the cash pay is $2.50
    - This is not a cost issue but an awareness issue on the part of physicians
    - The guidelines must have failed to actually look at the cost
- Allan feels that criticism of the guidelines are not accepted by the community, “*because the guidelines are the guidelines*”
  - Peter replies that his next paper can be a survey of the laboratory cost of apoB and the average Medicare reimbursement rate across the US
    - Is this a valuable exercise?
    - Allan thinks it is
  - Allan did a cost analysis on apoB, “*I think using a charge of $10, and looking at the cost of care; and I think it contributed 0.01% of the cost of care, something like that, okay?*”
  - Peter thinks that the concept that at $10 test changes the cost of care is idiotic
    - The US is spending infinitely more than it should (and more than anyone else) on healthcare
    - 10 years ago in the United States, our healthcare spending was $7,000 per person per year; he doesn’t see how it’s less than $10,000 per person per year today in the US
      - Even if the apoB test cost $100 (which is 20-times the actual cost), so what?
      - Atherosclerosis is the number one killer of men and women; it kills women at a rate that is more than 10 times that of breast cancer
      - Allan agrees, and this is his frustration, his sadness
- The American College of Clinical Chemistry, the European Clinical Chemists, have a series of reports saying apoB can be measured more accurately than LDL cholesterol or non-HDL cholesterol, no question
  - Allan’s review of this topic published in 2021, [Update on apolipoprotein B](https://pubmed.ncbi.nlm.nih.gov/33870931/)
  - [2019 European Guidelines](https://air.unimi.it/retrieve/handle/2434/706264/1393408/European%20Heart%20Journal%202020_41_%20111.pdf) [2019 ESC/EAS Guidelines for the management of dyslipidaemias: lipid modification to reduce cardiovascular risk](https://air.unimi.it/retrieve/handle/2434/706264/1393408/European%20Heart%20Journal%202020_41_%20111.pdf)
- Is that in any of the guidelines, accuracy of measurement? No.
  - Allan relates this is what is hard to deal with, “*when you say you’re criticizing the guidelines, maybe it’s just you, who are you? You’re a nobody, which is true.*”
  - But this is a laboratory test; surely, the quality of the measurement is something that should be mentioned

> “The diagnosis of type III, can’t be done without apoB. So any hypertriglyceridemia patient needs an apoB, not done, not mentioned type III.” Allan Sniderman

- Allan feels that his work won’t help people and this makes him sad
  - Peter replies, “*For a guy who understands uncertainty, and probability, and risk, you’re using awfully black and white language right now. “It’s not going to happen,” with what certainty can you say that?*”
- Peter relates this to a beautiful story about a guy hitting a stone
  - The mason who’s hammering away on the stone for 10,000 strikes, and on the 10,001st strike when he hits the stone, it finally fractures. Now, to the person watching it, it was that 10,001st strike that fractured the stone. But of course, the stone mason knows that it was that strike, plus the 10,000 that came before it.

> “And so you just have to accept the non-linearity of the advancement of knowledge” – Peter Attia

- Peter thinks Allan is too close to this issue to see this
- Further, at the end of the day, these consensus statements are largely political
  - They’re more based on: who someone is, and who they know, and how long someone has been on the committee, rather than the strength of the evidence
- Peter thinks the truth generally wins in the end, in science
  - He wouldn’t be surprised if in 10 years (or so) everyone will look back on this like HDL-C
  - It wasn’t long ago that people thought HDL-C was everything
  - Today, thanks to CTAP trials ([clinical trial advisory panel)](https://www.nia.nih.gov/research/blog/2016/05/clinical-trials-advisory-panel-good-start-clinical-trial), the MR’s, people know:
    - a) HDL-C is much more complicated than we ever thought
    - b) This is probably not something we should be trying to manipulate in an effort to improve outcomes
- Allan hopes Peter is right, he will pick himself up and keep fighting
- To quit when one has a new observation that is different or startling is wrong

> “Part of this is for yourself just to see, can you understand what looks like chaos? Is there any pattern to what looks like there’s no pattern?” – Allan Sniderman

- How does blood sugar and lipids combine to hurt us?
  - Allan feels privileged to look at these questions and publish his thoughts in a manuscript; so few people ever have that privilege
  - Published in *JAMA Cardiology* in 2016, [The Enigma of Glucose and Lipid Metabolism](https://pubmed.ncbi.nlm.nih.gov/27437884/)
- Peter has known Allan for over 10 years, and he thinks one of Allan’s strengths is his insatiable curiosity about things that are “theoretically outside of your lane”
  - They have exchanged many emails about insulin resistance as well as everything related to lipids
- He thinks part of Allan’s success is the breadth to which he has thought about this problem
  - This is why Allan has been able to spot patterns that are not obvious to others

## Advantages of a 30-year risk assessment and early intervention [1:50:30]

- The [Framingham risk calculator](https://framinghamheartstudy.org/fhs-risk-functions/cardiovascular-disease-10-year-risk/) takes into account: age, smoker, HDL-C, blood pressure
  - This gives a 10-year risk
  - If the 10-year risk is below 5% there is no need to treat; the gist of it is to carry on as normal
- Peter practices medicine in a very different way because he has a different goal
  - His objective is for a person to live as long as possible, disease-free
  - He is also influenced by people like Allan who have taught him how long it takes for this disease to take hold
- Consider this analogy, imagine there was a calculator that told you how much money you should be saving for retirement, but it could only predict 10 years into the future
  - It wouldn’t be a very useful tool, because a 30-year old isn’t going to be retired in 10 years

**How Allan came to the 30-year model**

- The length of this model is partially utilitarian; 30 years was the longest stretch for which they had reliable data
- The period of uncertainty is greatest between age 30 and 55 or 60
  - This is  where the 10-year falls down
- He originally used models based on 10-year risk and saw that these were going to miss most premature disease
  - If one simply lowered the risk, instead of 5% use 2.5%
  - The problem is, this is not cost-effective
  - This is multiplying the number one needs to treat more than if one starts off with the cause
- Now categorize patients by apoB or non-HDL cholesterol
  - High apoB is about 25% of the population
    - Over 30 years, this group has a 30% event rate
    - This is a lot; it’s not just the apoB that’s doing it
    - Other drivers are: age, weight, blood pressure
  - ApoB or non-HDL cholesterol can be measured with much less error than the risk can be predicted
- The variable that Allan knows, that Michael Pencina calculated, count for about 20% of the variance in risk
  - That’s a small number

**Communicating risk and intervention options to patients**

- From a utilitarian perspective, by stretching out and using the idea of cause and precision of measurement, Allan can group patients
  - He can then present a patient with what is known about the group, and they can make their decisions
  - Some patients say “thank you, I’ll pass”; they’ll come back in 6 months or a year and he can have the same discussion again
    - Allan didn’t lose anything
    - The patient has lost that time, but these decisions that can be revisited
    - Patients are free agents; they can start and stop therapy

> “It’s up to us to present our arguments and continue to present them as we frame them to… what we think is their best interest, and the best we can do” – Allan Sniderman

- Allan maintains contact with his patients; he makes sure they know they can change their mind
  - He can show them progress
  - If their apoB started at 120 and went down to 60, he knows they’re taking the medication
  - Patients can appreciate the extent of the change that has occurred; and this works
- Peter finds it helpful to explain that [nonlinearity](https://en.wikipedia.org/wiki/Nonlinear_system) is not innate to us
  - This is not intuitive to somebody who hasn’t fiddled with numbers a lot or spent time looking at things that compound
  - Even if one were just to look at a risk-based model that was short-term, there’s a significant benefit to reducing risk from 4% to 2% over a decade
  - Even though that might only mean there’s a 2% risk reduction over the next decade, the amount that amplifies over 2, 3 and 4 decades is amazingly counter-intuitive, just in the way it is, when one thinks about saving for retirement
    - If one is 30-years-old when they start saving for retirement and they have an option to generate a return of 7% and another options that generates a retire on 9-10%, this will not yield an enormous difference by the time they are 40, but it does by the time they are 70
    - Do the math and see how easily one can literally double the  nest egg based on a relatively small change upfront

> “So I think that’s also part of the issue here is, just understanding what compounding does, and how it works in your benefit when you’re talking about investing. But understanding how it works against you, when you’re talking about a disease like atherosclerosis.” – Peter Attia

**The advantage of early intervention**

- Allan agrees, starting earlier pays off later
- When one begins later this is essentially an effort to modify the disease that’s already present
- When on begins early, this actually stops the disease from developing
  - Stopping a lesion from developing is 100% success

> “Trying to treat, modify through one process, a complex set of outcomes at this end, much less likely to succeed. So stopping disease is perfect prevention.” – Allan Sniderman

- ApoB is a causal driver of atherosclerosis; realize it’s necessary but not sufficient
  - Peter thinks this is important because
  - Necessary but not sufficient, creates a lot of confusion in medicine, doesn’t it?
    - *Necessary*, means, there has to be apoB particle traffic a lipid into an artery wall, and without it, atherosclerosis doesn’t develop
    - *Sufficient*, means, if this is the only thing to happen then atherosclerosis occurs
  - ApoB alone is *not sufficient* for causing atherosclerosis
    - Peter knows tons of patients who’ve made it to their 90s with high apoB and don’t have disease
- From a prevention standpoint, it’s easier to go after something that *necessary* because blocking that is helpful
  - Comparatively, once the disease has already taken hold, the problem is multifactorial and involves slowing the advancement of disease

§

## Selected Links / Related Material

**Peter has written about Allan Sniderman:**

- [The straight dope on cholesterol – Part VIII](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-viii/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (June 26, 2012) |  [1:30]
- [The straight dope on cholesterol – Part IX](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-ix/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (July 12, 2012) |  [1:30]
- [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (June 27, 2016) |  [1:30]
- [Measuring cardiovascular disease risk and the importance of apoB](https://peterattiamd.com/measuring-cardiovascular-disease-risk-and-the-importance-of-apob-part-1/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (December 22, 2019) |  [1:30]

**Episodes of The Drive podcast that mention Allan Sniderman:**

- [#03 – Ron Krauss, M.D.: a deep dive into heart disease](https://peterattiamd.com/ronkrauss/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#19 – Dave Feldman: stress testing the lipid energy model](https://peterattiamd.com/davefeldman/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology](https://peterattiamd.com/tomdayspring1/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#21 – Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](https://peterattiamd.com/tomdayspring2/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#23 – Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](https://peterattiamd.com/tomdayspring4/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#52 – Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone – two topics that are surprising interrelated](https://peterattiamd.com/ethanweiss/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]
- [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology](https://peterattiamd.com/tomdayspring6/) | The Drive hosted by Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:30]

**Books by Sniderman that Peter referenced**:

- [ApoB in Clinical Care](https://www.amazon.com/ApoB-Clinical-Care-Jacqueline-Graaf-dp-9036809797/dp/9036809797/ref=mt_other?_encoding=UTF8&me=&qid=1635354887) by  Jacqueline de Graaf, Patrick Couture, and Allan Sniderman (2015) | [5:00]
- [Atlas of Atherosclerosis Progression and Regression](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1) (Encyclopedia of Visual Medicine Series) by Herbert C. Stary (2003) | [5:15]

**Risk algorithm to calculate risk of CVD**: [ASCVD Risk Estimator Plus](https://tools.acc.org/ASCVD-Risk-Estimator-Plus/?_ga=2.155406269.702326460.1635355961-1875985647.1635355961#!/calculate/estimate/) | American College of Cardiology | [6:45]

**Comparing the standard, 10-year risk approach to a 30-year causal model for determining CVD intervention**: [A Long-term Benefit Approach vs Standard Risk-Based Approaches for Statin Eligibility in Primary Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6583050/) | *JAMA Cardiology* (George Thanassoulis *et al.* 2018) | [9:15, 1:10:45]

**New algorithm to predict risk of cardiovascular disease (casual Benefit model)**:

- [The causal exposure model of vascular disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3244267/) | *Clinical Science* (A Sniderman *et al.* 2012) | [11:45, 1:10:45]
- [The Benefit Model for Prevention of Cardiovascular Disease: An Opportunity to Harmonize Guidelines](https://pubmed.ncbi.nlm.nih.gov/28793137/) | *JAMA Cardiology* (G Thanassoulis, M J Pencina, and A D Sniderman 2017) | [11:45, 12:30; 1:10:45]

**1967 paper that separated plasma lipoproteins according to density**: [Fat Transport in Lipoproteins — An Integrated Approach to Mechanisms and Disorders](https://www.nejm.org/doi/10.1056/NEJM196702022760507?url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0pubmed) | *New England Journal of Medicine* (D S Fredrickson, R I Levy, and R S Lees 1967) | [23:30]

**Bob (Robert) Lees 1970 paper in** ***Science*** **measuring plasma LDL ApoB**: [Immunoassay of plasma low-density lipoproteins](https://pubmed.ncbi.nlm.nih.gov/5424796/) | *Science* (R S Lees 1970) | [24:00]

**There are important size differences in LDL**: [Composition and distribution of low density lipoprotein fractions in hyperapobetalipoproteinemia, normolipidemia, and familial hypercholesterolemia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC391230/) | *PNAS* (B Teng, *et al.* 1983) [24:30]

**LDL may contain different amounts of cholesterol mass**: [Identification of multiple subclasses of plasma low density lipoproteins in normal humans](https://www.jlr.org/article/S0022-2275(20)38178-5/pdf) | *Journal of Lipid Research* (R M Krauss and D J Burke 1982) | [24:45]

**Allan’s first clinical paper on LDL with Kwiterovich**: [Association of coronary atherosclerosis with hyperapobetalipoproteinemia [increased protein but normal cholesterol levels in human plasma low density (beta) lipoproteins]](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC348323/) | *PNAS* (A Sniderman *et al.* 1980) | [25:00]

**Review of discordance analysis**: [Discordance analysis and the Gordian Knot of LDL and non-HDL cholesterol versus apoB](https://pubmed.ncbi.nlm.nih.gov/25340478/) |  *Current Opinion in Lipidology* (A D Sniderman *et al* 2014) | [26:30]

**Algorithm Allan developed to diagnose Remnant type III hyperlipidemia**: [The spectrum of type III hyperlipoproteinemia](https://pubmed.ncbi.nlm.nih.gov/30318453/) | *Journal of Clinical Lipidology* (A Sniderman *et al.* 2018) | [34:45]

**Nordestgaard recent paper used discordance analysis and found ApoB is a more accurate index on statin treatment**: [Apolipoprotein B and Non-HDL Cholesterol Better Reflect Residual Risk Than LDL Cholesterol in Statin-Treated Patients](https://pubmed.ncbi.nlm.nih.gov/33736827/) | *Journal of the American College of Cardiology* (C D L Johannesen *et al.*  2021) | [38:45]

**George Davey Smith used mendelian randomization analysis and found apoB levels were a better predictor of cardiovascular events than LDL**: [Association of Genetic Variants Related to CETP Inhibitors and Statins With Lipoprotein Levels and Cardiovascular Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5710502/) | *JAMA* (B A Ference *et al.* 2017) | [43:00]

**Sniderman’s publication about delayed lipid-lowering intervention**: [The Expected 30-Year Benefits of Early Versus Delayed Primary Prevention of Cardiovascular Disease by Lipid Lowering](https://www.ahajournals.org/doi/epub/10.1161/CIRCULATIONAHA.120.045851) | *Circulation* (A Sniderman *et al.* 2020) | [1:00:00]

**Paper suggesting waiting for coronary calcium before starting intervention is a bad idea**: [Novel Lipid-Lowering Therapies to Reduce Cardiovascular Risk](https://jamanetwork.com/journals/jama/article-abstract/2782198) | *JAMA* JT Wilkins and DM Lloyd-Jones 2021) | [1:07:00]

**Papers looking at 30-year risk and a causal model for preventing cardiovascular events**:

- [The Benefit Model for Prevention of Cardiovascular Disease: An Opportunity to Harmonize Guidelines](https://pubmed.ncbi.nlm.nih.gov/28793137/) | *JAMA Cardiology* (G Thanassoulis, M J Pencina, and A D Sniderman 2017) | [11:45, 12:30; 1:10:45]
- [The Expected 30-Year Benefits of Early Versus Delayed Primary Prevention of Cardiovascular Disease by Lipid Lowering](https://www.ahajournals.org/doi/epub/10.1161/CIRCULATIONAHA.120.045851) | *Circulation* (M Pencina *et al.* 2020) | [1:10:45]

**FOURIER clinical trial results**: [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.nejm.org/doi/10.1056/NEJMoa1615664?url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0www.ncbi.nlm.nih.gov) | *New England Journal of Medicine* (M S Sabatine *et al.* 2017) | [1:21:00]

**Odyssey clinical trial results**: [Efficacy and safety of alirocumab, a monoclonal antibody to PCSK9, in statin-intolerant patients: Design and rationale of ODYSSEY ALTERNATIVE, a randomized phase 3 trial](https://www.lipidjournal.com/article/S1933-2874(14)00331-6/fulltext) | *Journal of Clinical Lipidology* (P M Moriaty *et al.* 2014) | [1:21:45]

**Review discusses the lack of reduction of cardiovascular events after increase of HDL-C (with niacin)**: [Niacin Therapy, HDL Cholesterol, and Cardiovascular Disease: Is the HDL Hypothesis Defunct?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4829575/) | *Current Atherosclerosis Reports* (P Mani and A RohatgiI 2015) | [1:25:30]

**Allans editorial about the omission of apoB from the guidelines**: [Did the ACC/AHA/AACVPR/AAPA/ABC/ACPM/ADA/AGS/APhA/ASPC/NLA/PCNA cholesterol guidelines get apoB right?](https://pubmed.ncbi.nlm.nih.gov/31229023/) | *Journal of Clinical Lipidology* (A Sniderman 2019) | [1:41:00]

**Allan’s review of reports on the accuracy of measuring ApoB, LDL, and non-HDL**: [Update on apolipoprotein B](https://pubmed.ncbi.nlm.nih.gov/33870931/) **|** *Current Opinion in Lipidology* (A Sniderman *et al.* 2021) | [1:44:30]

**European guidelines**: [2019 European Guidelines](https://air.unimi.it/retrieve/handle/2434/706264/1393408/European%20Heart%20Journal%202020_41_%20111.pdf) [2019 ESC/EAS Guidelines for the management of dyslipidaemias: lipid modification to reduce cardiovascular risk](https://air.unimi.it/retrieve/handle/2434/706264/1393408/European%20Heart%20Journal%202020_41_%20111.pdf) | *European Heart Journal* ( F Mach *et al.* 2020) | [1:44:30]

**Allan’s manuscript on how blood sugar and lipids combine to cause harm**: [The Enigma of Glucose and Lipid Metabolism](https://pubmed.ncbi.nlm.nih.gov/27437884/) | *JAMA Cardiology* (N J Pagidipati, M Pencina, A D Sniderman 2016) | [1:49:15]

**Framingham risk calculator**: [Cardiovascular Disease (10-year risk)](https://framinghamheartstudy.org/fhs-risk-functions/cardiovascular-disease-10-year-risk/) | Framingham Heart Study (2018) | [1:51:00]

**Pathogenesis of type III hyperlipoproteinemia**: [Pathogenesis of type III hyperlipoproteinemia (dysbetalipoproteinemia): questions, quandaries, and paradoxes](https://www.jlr.org/article/S0022-2275(20)32417-2/fulltext) | *Journal of Lipid Research* (R W Mahley, Y Huang, and S C Rall Jr 1999)

**Comparison of the benefit-based model to the conventional risk-based model for determining statin intervention**: [Individualized Statin Benefit for Determining Statin Eligibility in the Primary Prevention of Cardiovascular Disease](https://pubmed.ncbi.nlm.nih.gov/26945047/) | *Circulation* (G Thanassoulis *et al.* 2016)

**Review of the use of plasma lipids and apoB to estimate cardiovascular risk**: [Hypertriglyceridemia and cardiovascular risk: a cautionary note about metabolic confounding](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6027915/) | *Journal of Lipid Research* (A D Sniderman 2018)

**Role of apoB in the pathophysiology of cardiovascular disease**: [Apolipoprotein B Particles and Cardiovascular Disease: A Narrative Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7369156/) | *JAMA Cardiology* (A D Sniderman *et al.* 2019)

**Relative importance of lipids, systolic blood pressure [SBP], diabetes mellitus, and smoking on risk of cardiovascular events**: [Quantifying Importance of Major Risk Factors for Coronary Heart Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6433489/) | *Circulation* (M Pencina *et al.* 2019)

**Lipoprotein(a) is an important metric for assessing cardiovascular risk**: [Risks of Incident Cardiovascular Disease Associated With Concomitant Elevations in Lipoprotein(a) and Low‐Density Lipoprotein Cholesterol—The Framingham Heart Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7726982/) | *Journal of the American Heart Association* (M Afshar *et al.* 2020)

**Editorial on prevention of CVD**: [Clinical reasoning and prevention of cardiovascular disease](https://pubmed.ncbi.nlm.nih.gov/33992590/) | *Journal of Clinical Lipidology* (A Sniderman, M Pencina, and G Thanassoulis 2021)

**ApoB is associated with risk of myocardial infarction and may be the primary driver of atherosclerosis**: [Association of Apolipoprotein B-Containing Lipoproteins and Risk of Myocardial Infarction in Individuals With and Without Atherosclerosis: Distinguishing Between Particle Concentration, Type, and Content](https://pubmed.ncbi.nlm.nih.gov/34773460/) | *JAMA Cardiology* (N A Marston *et al.* 2021)

**Allan’s most recent commentary on the utility of using apoB as a metric for cardiovascular risk**: [Apolipoprotein B vs Low-Density Lipoprotein Cholesterol and Non-High-Density Lipoprotein Cholesterol as the Primary Measure of Apolipoprotein B Lipoprotein-Related Risk: The Debate Is Over](https://pubmed.ncbi.nlm.nih.gov/34773457/) | *JAMA Cardiology* (A Sniderman, A Navar, and G Thanassoulis 2021)

§

## People Mentioned

- [Tom Dayspring](https://www.pri-med.com/globals/faculty/d/dayspring-thomas?refurl=www.google.com) [1:30, 4:45]
- [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss) [1:30, 24:30]
- [Herbert C. Stary](https://www.medschool.lsuhsc.edu/pathology/faculty_detail.aspx?name=stary_herbert) (Professor of pathology and author of textbook on atherosclerosis) [5:15, 8:00]
- [AJ Ayer](https://en.wikipedia.org/wiki/A._J._Ayer) (philosopher known for logical positivism) [10:45]
- [George Thanassoulis](https://rimuhc.ca/-/george-thanassoulis-md) (collaborated with Allan to develop the benefit model to prevent cardiovascular disease) [12:45]
- [Michael Pencina](https://scholars.duke.edu/person/michael.pencina) [12:45, 1:54:00]
- [Karol Pencina](https://connects.catalyst.harvard.edu/Profiles/display/Person/130449) [12:45]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (1950’s physiologist who said saturated fat contributes CVD) [22:15]
- [Donald Fredrickson](https://en.wikipedia.org/wiki/Donald_S._Fredrickson) (separated plasma  lipoproteins according to density in the 1960’s along with Levy and Lees) [23:30]
- [Levy](https://en.wikipedia.org/wiki/Robert_L._Levy_(cardiologist))  (separated plasma lipoproteins according to density in the 1960’s along with Fredrickson and Lees) [23:30]
- [John Gofman](https://en.wikipedia.org/wiki/John_Gofman) tradition [24:30]
- [Peter Kwiterovich](https://www.hopkinsmedicine.org/news/media/releases/johns_hopkins_pioneer_in_pediatric_lipid_disorders_dies) (collaborator from Hopkins) [25:00]
- [George Davey Smith](https://en.wikipedia.org/wiki/George_Davey_Smith) (a founder of Mendelian randomization) [42:45]
- [Kevin John Williams](https://medicine.temple.edu/kevin-williams) (cardiologist at Temple University) [1:01:45]
- [John Wilkins](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=16809) (cardiologist at Northwestern University) [1:07:00]
- [Don Lloyd Jones](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=16679) (cardiologist at Northwestern University) [1:07:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/11/allan-sniderman.jpg)

##### Allan Sniderman, M.D.

Allan Sniderman obtained his MD from the University of Toronto in 1965 and then moved to Montreal, where he did his clinical training in Internal Medicine and Cardiology at McGill University. In 1971, he went to the University of California at San Diego to study lipoprotein metabolism with Dr. Daniel Steinberg. He returned to McGill and, with the passage of time, became the Edwards Professor of Cardiology and a Professor of Medicine at McGill University.

With colleagues within and outside McGill, he began and has continued a series of studies, which identified the commonest dyslipoproteinemia associated with coronary artery disease- hyperTg hyperapoB. Study of the pathophysiology of hyperTg hyperapB led to studies of the regulation of hepatic apoB secretion and the uptake and release of fatty acids by adipose tissue. He has conducted an extensive series of epidemiological studies, which have demonstrated apoB to be superior to LDL-cholesterol as a marker of the risk of vascular disease. His current research interests are: to understand the regulation of plasma LDL, to create simplified but advanced diagnostic algorithms to recognize and treat those with and those at high risk of vascular disease, and to develop new models to determine the absolute value of different strategies to identify and treat those at risk of vascular disease.

Dr. Sniderman, father of five, grandfather of four, is a committed, but not very skilful, golfer. His most joyful moments have come from learning with his students and colleagues.

Allan D. Sniderman, MD, is the Edwards Professor of Cardiology and Professor of Medicine at McGill University. He is Director of the Mike Rosenbloom Laboratory for Cardiovascular Research at Royal Victoria Hospital in Montreal and was elected a Fellow of the Royal Society of Canada in 2009. [[McGill University Health Centre](https://www.cardiomuhc.ca/allan-sniderman)]