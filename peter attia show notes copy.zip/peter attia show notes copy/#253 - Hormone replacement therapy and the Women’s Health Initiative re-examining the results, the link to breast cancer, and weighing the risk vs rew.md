# #253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.

**Source:** [https://peterattiamd.com/joannmanson/](https://peterattiamd.com/joannmanson/)

---

JoAnn Manson is a world-renowned endocrinologist, epidemiologist, and Principal Investigator for the Women’s Health Initiative (WHI). In this episode, she dives deep into the WHI to explain the study design, primary outcome, confounding factors, and nuanced benefits and risks of hormone replacement therapy (HRT). JoAnn reflects on how a misinterpretation of the results, combined with sensationalized headlines regarding an elevated risk of breast cancer, led to a significant shift in the perception and utilization of HRT. From there, they take a closer look at the breast cancer data to separate fact from fiction. Additionally, JoAnn gives her take on how one should weigh the risks and benefits of HRT and concludes with a discussion on how physicians can move towards better HRT practices.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/joannmanson/the_Drive_public.png)

Play

#253 ‒ Hormone replacement therapy and the Women's Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.

#253 ‒ Hormone replacement therapy and the Women's Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.

1x15s30s

0:001:20:48

## We discuss:

- The Women’s Health Initiative: the original goal of the study, hormone formulations used, and potential confounders [4:15];
- Study design of the Women’s Health Initiative, primary outcome, and more [16:00];
- JoAnn’s personal hypothesis about the ability of hormone replacement therapy to reduce heart disease risk prior to the WHI [26:45];
- The relationship between estrogen and breast cancer [30:45];
- Why the WHI study was stopped early, and the dramatic change in the perception and use of HRT due to the alleged increase in breast cancer risk [37:30];
- What Peter finds most troubling about the mainstream view of HRT and a more nuanced look at the benefits and risks of HRT [45:15];
- HRT and bone health [56:00];
- The importance of timing when it comes to HRT, the best use cases, and advice on finding a clinician [59:30];
- A discussion on the potential impact of HRT on mortality and a thought experiment on a long-duration use of HRT [1:03:15];
- Moving toward better HRT practices, and the need for more studies [1:10:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Dr. JoAnn Manson, she is a Professor of Medicine and the Michael and Lee Bell Professor of Women’s Health at Harvard Medical School, Professor in the department of Epidemiology, and Chief of the Division of Prevention Medicine at Brigham and Women’s Hospital
- She is also a physician epidemiologist, endocrinologist, and the Principal Investigator (or co-PI) of several research studies including the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative), other studies such as the cardiovascular component of the [Nurses’ Health Study](https://en.wikipedia.org/wiki/Nurses%27_Health_Study), the vitamin D and omega-3 trial known as [VITAL](https://en.wikipedia.org/wiki/Vitamin_D_and_Omega-3_Trial)
- Her primary research interest include randomized clinical prevention trials of nutrition and lifestyle factors related to heart disease, diabetes, cancer, and the role of endogenous and exogenous estrogens as determinants of chronic disease in women
- JoAnn has received numerous honors including the American Heart Association’s Population Research Prize, their Distinguished Scientist Award, and their the Research Achievement Award
  - Election to the Institute of Medicine of the National Academies (National Academy of Medicine)
  - Membership in the Association of American Physicians (AAP)
  - Fellowship in AAAS, and so many other awards
- She has published more than 1200 peer-reviewed articles in the medical literature, and is the author or editor of several books and textbooks
- She serves as the Editor in Chief of Contemporary Clinical Trials and is the past President of the North American Menopause Society
- She is one of the most highly cited researchers in the history of published research
- She is one of the physician’s who is featured in the National Library of Medicine’s exhibition, *History of American Women Physicians*
- In this episode, we spend the entire conversation focusing one of her main projects ‒ The Women’s Health Initiative (she was one of the Principal Investigators)
- In this discussion we speak about the reasons for the study, the questions being examined, the study design (inclusion/ exclusion criteria)
- We then go into the nuances of the study, including why it was prematurely stopped and how it was interpreted
- The most important part of this discussion is what the implications are for someone today listening to this
- Hormone replacement therapy (HRT) is potentially one of the most controversial bits of medicine today
  - Peter makes the point to JoAnn that the misinterpretation of the Women’s Health Initiative some 20 years ago may be one of the greatest missteps of medicine (and the medical press) in the past several decades
- Peter makes no bones about his bias in this podcast, which is that the fears of hormone replacement therapy are completely overblown and are generally being propagated by people who are not familiar with the literature
  - This is why he wanted to sit down with JoAnn
- He could think of no better person to sit down with and go through the details of this study than the person who is more familiar them than anyone else

## The Women’s Health Initiative: the original goal of the study, hormone formulations used, and potential confounders [4:15]

**What is the** ***h-*****index, and how is it calculated?**

- The [*h-*index](https://en.wikipedia.org/wiki/H-index) is calculated from the number of publications you have that are highly cited
  - If, for example, you have an *h-*index of 100, that would mean that you have at least 100 publications that have 100 or more citations each
  - An *h-*index of 200 would be 200 publications that each have at least 200 citations that are referenced in other publications
    - These are epic *h-*indexes
    - A person with a *h-*index of 100 has done 10 people’s lifetime work in their lifetime
- Last time Peter checked, [JoAnn’s *h-*index](https://scholar.google.com/citations?user=QK07bYEAAAAJ&hl=en) was 305
  - She’s in the top 3 *h-*index rankings in the history of biomedical science
  - JoAnn clarifies, “*It means I have wonderful colleagues in collaborations going on throughout the world*”

**The goal of the Women’s Health Initiative (WHI)**

- JoAnn was one of the principal investigators on the WHI
- Looking back, 20 years later, this study wasn’t interpreted in the best way, from a public health perspective
- This was a randomized experiment designed in the early 1990s to test what was being found in the Nurses Health Study and other epidemiologic studies
- In the 1980s and 1990s there were several large *observational* studies of women on hormone therapy
  - Compared to women not on hormone therapy, they tend to have lower rates of heart disease in those studies compared to women not using hormone therapy, less cognitive decline, lower all-cause mortality

> “*We often say that observational studies of this nature cannot prove a cause and effect relationship, but they can generate hypotheses to be tested in randomized clinical trials*”‒ JoAnn Manson

- Before the randomized clinical trials were launched in the early 1990s, there was already an increasing practice in clinical medicine to prescribe hormone therapy for the express purpose of trying to prevent heart disease, cognitive decline, and other chronic diseases
  - This was a trend not only in recently menopausal women, or when women had hot flashes and night sweats and were in early menopause
  - Many clinicians were starting to prescribe these hormones for women who were well over a decade, 10, 20, 30 years after the onset of menopause

***It was very important to understand whether this practice of prescribing menopausal estrogen therapy or estrogen plus progestin therapy was advisable when used for prevention of chronic diseases***

- This was a very different question from, “*Does hormone therapy reduce hot flashes, night sweats, and should women in their 40s, early 50s who are just starting to go through menopause take hormone therapy to treat those symptoms?*”
- It was accepted that hormone therapy is effective for treating hot flashes and night sweats
  - It’s actually FDA approved for that purpose
  - It has an indication for treatment to reduce hot flashes and night sweats
- But the question of its use for prevention of heart disease, stroke, cognitive decline, other chronic diseases had never been tested in a randomized clinical trial, and that was the **goal** of the [Women’s Health Initiative (WHI)](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative)
- Despite the fact that the epidemiology suggested benefits in all of those arenas, people who listen to this podcast are no strangers to the different types of biases that can creep in
  - Like the [healthy user bias](https://peterattiamd.com/ama30/)—It could easily be the case that the women who were provided hormones had access to the type of physicians who maybe were more knowledgeable or provided better care
- There was no doubt that an RCT was going to be essential to elucidate the causality here

**The history of hormone formulations [11:00]**

- The idea of replacing estrogen in menopausal woman began in the 1960s
- The most common formulations were [conjugated estrogen](https://en.wikipedia.org/wiki/Conjugated_estrogens) with and without [medroxyprogesterone acetate](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate)
  - Women who had a hysterectomy could use estrogen alone, but women with an intact uterus needed to take what we call a [progestogen](https://en.wikipedia.org/wiki/Progestogen)
- Progestogen counteracts the effect of estrogen on increasing the thickness of the uterine lining, the [endometrium](https://en.wikipedia.org/wiki/Endometrium)
  - If women who have an intact uterus take estrogen alone, they have a very high risk of developing endometrial cancer
    - Early on, they will just have proliferation and of the lining of the uterus and increased of vaginal bleeding related to taking estrogen without the progestogen
- Those two formulations (conjugated estrogen with and without medroxyprogesterone acetate) were very commonly used, and they had been extensively studied in the observational studies where the results had looked very promising for a lower risk of heart disease and cognitive decline all cause mortality

***It was important to test the formulations that had contributed so much to the observational study findings***

**Potential confounding factors of observational studies**

- Women who were taking hormone therapy in the observational studies tended to be a higher socioeconomic status, more highly educated, and more health conscious
  - These may have contributed to their lower risk of chronic diseases
- However, it’s also important to note that in observational studies, the women who were being prescribed hormone therapy were still largely women in early menopause
  - Hormone therapy was started in early menopause, even if they continued into mid and later menopause
  - That’s ***another important perhaps biological difference*** between the women in the observational studies and women in randomized trials, in the Women’s Health Initiative (WHI)
- The ***average age of participants in the WHI was 63***, or more than a decade past onset of menopause when the hormone therapy was being started

**Do we know if the age of menopause is moving over time?**

- We know that girls are getting their periods earlier and earlier, even over just two decades
- JoAnn doesn’t know if that has been rigorously studied
- The average age of menopause is 51, and that has stayed relatively constant for quite a while

**Why were c**[**onjugated equine estrogen**](https://en.wikipedia.org/wiki/Conjugated_estrogens) **and** [**MPA**](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate) **synthetic progestogen the dominant forms of these hormones used in the 80s and in the 90s, which of course then became the precursor for the epidemiology?**

*Do we know why there was not just a bioidentical estradiol and progesterone?*

- One theory is that a pharmaceutical company developed the conjugated estrogens
- Originally, they derived from the pregnant mare’s urine
  - This is true even for many of the forms today
- This pharmaceutical company really became the dominant force in terms of hormone therapy
- Synthesis of estradiol from plants is a more complicated process that really did not get going on a large scale until more recent decades
- For quite a long time (more than 50 years), only conjugated estrogen available

## Study design of the Women’s Health Initiative, primary outcome, and more [16:00]

**How many lead investigators were on the WHI?**

- In the overall Women’s Health initiative there were initially 16 clinical centers and then expanded to 40 clinical centers for most of the duration of the WHI
- There were actually 40 Principal Investigators throughout the country

**Were women who were having vasomotor symptoms excluded?**

- No
- It’s a common misconception that women could not have hot flashes to participate in the WHI
- Women who had very severe hot flashes self-selected out of the study because they wanted to be on hormone therapy, and at the time the assumption was that hormone therapy would have some very favorable effects
  - They were already taking hormone therapy for their severe hot flashes
- Women were *not excluded* on the basis of the severity of her symptoms, presence/ absence of hot flashes/ night sweats
- The majority of the women in the study (especially those in the younger menopausal ages) did have at least mild or moderate high flashes
- The average age of participants was 63

**What were the exclusion criteria?**

- Women could not have a prior history of breast cancer, endometrial cancer, or any other estrogen-sensitive cancers
  - If they had a cancer, it could not be an estrogen-sensitive cancer, and it had to be more than 10 years previously
- Women could not have a recent heart attack or stroke or any of those major clinical cardiovascular events
  - Although a very small percentage of the women did have a more remote history of heart attack, stroke, bypass surgery, that type of clinical history
- For the most part, the women were healthy in terms of past history of cardiovascular disease, cancer, other conditions
- They were certainly *allowed* to have diabetes, hypertension, high cholesterol, and many of the more common health conditions that women will have and men will have in midlife
- They were not excluded for smoking, though we had a small percentage less than 10%
- Osteopenia, osteoporosis was not an exclusion
  - Women were not selected on being required to have osteoporosis or osteopenia, but they had a broad range of bone health similar to what you would expect in the usual population for women age 50 to 79
- Women with a family history of breast cancer or uterine cancer were allowed to participate
  - Many women did self-select out of the study for that reason, but they were not excluded on the basis of their family history

**Was there a limit as to how long they could be out of menopause before enrollment?**

- No, the criteria were based on age ‒ women age 50-79 (mean age of 63)
  - Peter remarks, “*Wow. Amazing diversity of age… three decades*”
- Some of them had gone through menopause in their early to mid-forties
- Some of them had even had hysterectomy with ovaries removed in their forties or much earlier in life

**What fraction of the women had previously been on the exact same drugs that they were going to be potentially randomized to and was there a required period of washout?**

- Very good question
- About 25% of the women in the estrogen plus progestin trial had prior use of hormone therapy
  - Close to 50% of the women with hysterectomy and in the estrogen alone trial had some prior use of estrogen therapy
- Overall, looking more specifically at the percentage of women in the trial who had hot flashes/ night sweats at the time of enrollment,about 45 to 50% had some symptoms
  - Mostly mild or moderate hot flashes or night sweats
- A little over 50% did not have any hot flashes or night sweats at the start of the trial

**How many women are enrolled in this trial?**

- A little over 27,000 in the two trials combined
- In the estrogen plus progestin trial, close to 17,000
- In the estrogen alone trial close to 10,000

**Why were there two trials?**

- If a woman has a uterus, she must receive progestin along with the estrogen
  - That’s the E + P trial that we’ll talk about
- If a woman has had a hysterectomy, then estrogen alone is sufficient, there’s no risk of [endometrial hyperplasia](https://en.wikipedia.org/wiki/Endometrial_hyperplasia) because there is no endometrium
  - That’s the E alone trial
- Each group has its own placebo for a total of 4 groups
  - 5,000 E only, plus 5,000 randomized one to one
  - 8,500 for the E + P and 8,500 placebo for that group

**What was the primary outcome?**

- The primary outcome for both trials was coronary heart disease with the primary safety outcome because of concern about breast cancer

> “*The two really key outcomes of the trial were coronary heart disease and breast cancer*”‒ JoAnn Manson

- This was incidence of breast cancer, not mortality of breast cancer
  - Confirmed by medical record review
- For coronary artery disease (CAD) the primary outcome was coronary events
  - Heart attacks (either not-fatal or fatal CAD)

**What was the study powered to detect on either of these?**

*What was the power analysis suggesting a difference that was anticipated?*

- The prior hypothesis as that there would be benefit for heart disease and that there would be overall many favorable effects of these hormones on chronic disease outcomes
- It was powered to detect an important clinical reduction such as a 20% reduction in heart disease

**What fraction of the women were taking lipid lowering therapies?**

- Peter notes that in the early to mid-90s hormones were being used as a preventive treatment for ASCVD
  - Today few physicians would consider that
  - Now, a person who is at risk is going to be managed much more critically with respect to blood pressure and lipids
- 7% of the study population was taking statins at the start of the study
  - Later in the trial, during the intervention phase, it was over 25%
    - A very large increase in stan use during the trial and with longer follow-up
    - These percentages got very high, 40-50%
  - This was in the paper published in [JAMA in 2013](https://jamanetwork.com/journals/jama/fullarticle/1745676) (table of baseline characteristics) and in [JAMA 2016](https://jamanetwork.com/journals/jama/article-abstract/2526647)
  - They’ve published repeatedly on the use of many medications for chronic health conditions

## JoAnn’s personal hypothesis about the ability of hormone replacement therapy to reduce heart disease risk prior to the WHI [26:45]

**In the early to mid-90s, what was known about oral estrogen as far as its impact on coagulability and blood viscosity? What was known at that time?**

- It was understood that oral estrogen goes directly through the portal circulation to the liver and has a direct effect on the liver in increasing the synthesis of clotting proteins
  - That was understood at that time because similar to oral contraceptives, it had been seen in observational studies that both oral contraceptives and postmenopausal hormone therapy were associated with an increased risk of deep vein thrombosis and even pulmonary embolism
- But it was believed to be relatively rare, and that the benefits for heart disease and for other chronic diseases would outweigh those risks of thrombosis

**What was your personal hypothesis going in?**

*What did you think was happening mechanistically to explain the observational data?*

*Did you believe the observational data?*

*Did you think that they were being confounded heavily?*

- She thought there was at least a small amount of confounding because it was clear that women taking hormone therapy tended to have a higher socioeconomic status, tended to have better access to medical care and to have somewhat more favorable lifestyle behaviors, be more health conscious
  - Many of these factors were considered in the data analysis
  - It’s not like the observational studies were just looking very crudely at associations
- There was adjustment for many of these lifestyle factors and socioeconomic status in some of the studies, but a benefit, a risk reduction for her disease did tend to persist even after those adjustments
- Women in early menopause who are transitioning from having their natural premenopausal estrogen exposure, and studies suggested that this estrogen exposure was **cardioprotective** favorable
  - In terms of risk factor status, in terms of dilating the blood vessels to the heart, and increasing blood flow to the heart
  - And was one of the reasons why women started to have heart disease 10+ years later than men
- JoAnn thought that it was likely that starting estrogen in early menopause would translate into at least a slightly lower risk of heart disease
- But she was skeptical from the very start that the magnitude of risk reduction seen in the observational studies (40-50% lower risk of heart disease) would stand up to a randomized clinical trial assessment of this question
- She thought it was likely to be a small reduction
- She wasn’t sure whether that benefit might be offset by other risks that would be identified
- Overall, she thought there’s likely to be some confounding going on in the observational studies

## The relationship between estrogen and breast cancer [30:45]

**What was your thinking with respect to the relationship between estrogen and breast cancer?**

- Peter notes that the classical teaching in medical school in the mid-90s was that estrogen causes breast cancer, but on the surface, some of the assumptions are a little hard to understand in the same way that there has historically been the assumption that testosterone causes prostate cancer
  - Except for the observation that men with the highest levels of testosterone (younger men) have lower rates of prostate cancer (than men when they’re older)
  - As long as 15 years ago, it was demonstrated that the lowest levels of testosterone were associated with the most aggressive forms of prostate cancer
- Peter wonders how similar the data are for estrogen and breast cancer
- He notes that most women get breast cancer in menopause and not prior to menopause
  - They’re getting even estrogen-sensitive breast cancer at a time when they have their lowest levels of estrogen
- There was an expectation that there would be at least a modest increase in risk of breast cancer with giving either estrogen plus progestin or estrogen alone

***The most surprising finding in terms of breast cancer was no increased risk of breast cancer was seen with estrogen alone***

- Even though the observational studies had suggested that both estrogen plus progestin and estrogen alone would be associated with increased risk of breast cancer
- There were many, many observational studies suggesting that hormone therapies are associated with increased risk of breast cancer
  - But the thinking tended to be that these are estrogen receptor positive breast cancers, and they tend to have a more favorable outcome
  - The thinking was that breast cancer mortality would *not* be appreciably increased
- In the observational studies, there was always that concern that differences in mammographic screening patterns could be contributing to greater detection of breast cancer among women taking hormone therapy because most doctors would not continue to prescribe the hormone unless the woman was having regular mammography and showed a normal mammogram without concern about a lesion
  - So, mammography also could have been contributing ‒ more frequent mammography in women on hormones versus women not taking hormone therapy could have contributed somewhat to the increased risk in the observational studies

***This was why it was important to look at this question in a randomized clinical trial with uniform surveillance for breast cancer with a mammogram being required every year***

***→ There was an increased risk of breast cancer with estrogen plus progestin***

**Hormone therapy led to denser breasts developing over time**

- Breast density was looked at in a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6059178/) of mammograms, several hundred women whose mammograms were examined, and there was a change in increased breast density
- Breast density is known to be a risk factor for breast cancer
- The increase in breast density was greater with estrogen plus progestin than with estrogen alone
- What was really surprising, although there was this 25-30% increase in risk of breast cancer seen with estrogen plus progestin, there was no increase in breast cancer seen with estrogen alone
- And with longer follow up, there was the emergence of a **reduction in breast cancer** (close to a 20% reduction) seen with the conjugated estrogen
  - The view was that this may be something specific to conjugated estrogen, which is a relatively weak estrogen and may have certain properties similar to [tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen), where it may be both serving as an estrogen and an anti-estrogen
  - ***Importantly, we cannot assume that this finding with conjugated estrogen will necessarily apply to all formulations of estrogen alone and certainly will not apply to the combination of estrogen plus progestin***
- Peter adds, “*I wouldn’t come to that as my first* [*Occam’s razor*](https://en.wikipedia.org/wiki/Occam%27s_razor) *conclusion because the same conjugated equine estrogen was used with the MPA that found a clinically irrelevant, but statistically significant increase in the incidence of breast cancer. In other words, I wouldn’t conclude from the differences in those two arms that it was the conjugated equine estrogen that was unusually beneficial.*”
  - Joann’s not concluding

**Was MPA the difference?**

- Yes, it’s the [MPA](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate), but the only way to look at the role of the estrogen is in the estrogen alone trial because in the estrogen plus progestin trial, is given a combined pill and you can’t disentangle
- Every woman in the trial was taking the combination
- JoAnn completely agrees, “*The increased risk of breast cancer seen with estrogen plus progestin was mostly attributable, if not entirely attributable to the progestin (to the medroxyprogesterone acetate)*.”
- Of course, the question has been raised ‒ would other types of progestogen (such as the bioidentical micronized progesterone) also lead to an increased risk of breast cancer?
  - There are some observational studies that suggest less increase in breast cancer with that particular formulation of a progestogen
  - However, we have no large scale randomized clinical trials that have done head-to-head comparisons or even really tested long-term the effects of other formulations of progestogen on breast cancer risk

***The most prudent, cautious approach is to assume that at least with longer duration of treatment with estrogen plus progestin, there will be an increased risk of breast cancer***

## Why the WHI study was stopped early, and the dramatic change in the perception and use of HRT due to the alleged increase in breast cancer risk [37:30]

***The E+P arm (***[***CEE***](https://en.wikipedia.org/wiki/Conjugated_estrogens) ***+*** [***MPA***](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate)***) was stopped after 5.6 years (3.3 years early) on the basis of the increased risk of breast cancer together with no reduction in heart disease***

- Remember, the primary endpoint was reduction in heart disease
- And an overall unfavorable risk benefit ratio as shown through the global index, which looked at all of these chronic conditions

**Peter recalls that the dropout rate was a little bit unusual in the placebo arm of the E+P group in the first, second, third year relative to the final year**

- The dropout rate was substantial in all hormone therapy trials
- People dropout because the trial requires a lot of effort to take a medication that is not being prescribed for your health (it’s just part of a study), and they don’t know if they’re taking an active drug or a placebo
  - All trials have some dropout over time in terms of compliance adherence with study medications
- The women who had an intact uterus and were taking estrogen plus progestin, some of them continue to have some vaginal bleeding, and some of them did not want to continue to have those symptoms
  - They may have had some breast tenderness or other symptoms that caused them to drop out
- Women dropped out of the placebo arm as well
  - Study pill fatigue will set in any randomized trial
- The participants in the WHI were extraordinarily dedicated, and JoAnn cannot imagine any group being more committed to women’s health

**Do you think the answer might have been different if the trial had gone on for its originally planned length of time (8-9 years)?**

- Peter remembers the headline at the time was “*The study of estrogen causes breast cancer*”
- He uses it as a great teaching example when he talks about the [difference between relative and absolute risk](https://peterattiamd.com/ns001/)
- The relative risk difference in the [CEE](https://en.wikipedia.org/wiki/Conjugated_estrogens) + [MPA](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate) group relative to placebo or versus placebo was 24- 25% (a little higher), and on the surface that sounds incredibly startling
- But the absolute risk increase was 0.1% (one case per 1000)
  - Peter remembers that the women in the placebo group were getting breast cancer and an incidence of 4 cases per 1000, and the women in the CEE + MPA group were getting it at 5 cases per 1000
    - This was about the opposite that was seen in the CEE along group versus placebo (though it didn’t reach statistical significance at 5.2 years; it took a longer follow-up to see that reduction)

**What is your recollection of that time, how much did this headline capture the imagination and fear of the world?**

- The medical community was shell shocked
- There was a [sea change](https://en.wikipedia.org/wiki/Sea_change_(idiom)) in clinical practice, a seismic shift in clinical practice

**Two major things changed**

- There was a dramatic reduction in use of hormone therapy by 70 to 80%
  - So, women who were being prescribed hormone therapy in the past for prevention of chronic diseases, prevention of heart disease, stroke, cognitive decline, those women were no longer being prescribed hormone therapy, *and that was a positive thing*

***The WHI showed that when hormone therapy is used for prevention of chronic disease purposes in women who have average age of 63 (in women in mid to later menopause), on average, the risks outweighed the benefits***

- But the **unfavorable change in clinical practice** was that the results were *extrapolated* to women in their 40s and 50s who were taking hormone therapy for treatment of bothersome, even distressing hot flashes, night sweats, and were in generally good health
  - They were being denied hormone therapy to relieve these symptoms

***That was an inappropriate extrapolation of the findings; that was a negative outcome***

> “*Women never should have been denied hormone therapy for the treatment of bothersome, distressing hot flashes, night sweats to improve their quality of life, especially generally healthy women in early menopause who have such low absolute rates of adverse events*.”‒ JoAnn Manson

- Even in the overall cohort with an average age of 63, most of the **adverse events** were relatively rare
  - Such as one extra case of breast cancer or heart attack or blood clot per 1000 women per year
  - It’s still important and it can add up with longer term use; however, it’s a low absolute risk

***JoAnn thinks the results were blown out of proportion, especially in terms of the use of hormone therapy for an FDA approved indication of treatment of hot flashes and night sweats among women in early menopause who had even lower absolute risks than one extra case per thousand women per year***

## What Peter finds most troubling about the mainstream view of HRT and a more nuanced look at the benefits and risks of HRT [45:15]

**How this changed the paradigm around hormone replacement therapy (HRT) among physicians**

- What Peter finds most troubling when he speaks to physicians today is, unless they are really, really steeped in this world (most aren’t), they can’t reiterate what JoAnn just said
  - The only thing they seem to understand, the enduring legacy of the WHI, is that hormones (in particular estrogen) cause breast cancer
  - HRT is synonymous with breast cancer
- He adds, “*There are really two enormous inaccuracies in that that are so inaccurate that they’re almost a parody*”
  - 1 – Nothing about this study suggested that estrogen is causing breast cancer
    - If anything, this study suggested MPA is causing breast cancer based on the fact the group that was only receiving estrogen had a reduction in the incidence of breast cancer while the group that received estrogen + MPA is the group that saw this small, potentially statistically significant (but potentially clinically insignificant) increase in breast cancer
  - 2 – Most doctors and patients who are contemplating HRT don’t recognize that this study only found an increase in breast cancer to the tune of 1 case per 1000, but no difference in mortality
- He wonders what the cost of that was

**Is that a charitable interpretation of the WHI?**

JoAnn points out two caveats:

- 1 – We cannot assume what was found with conjugated estrogen will apply to all other formulations of estrogen
- There is very strong evidence from several lines of biology that **estrogen plays a role in breast cancer**, including the fact that when women have their ovaries removed, it lowers their risk of  development of breast cancer, lowers the risk of recurrence
- There is quite a bit of evidence that estrogen does play a role in breast cancer
  - And this was actually also known even before the WHI, many of the observational studies had linked hormone therapy to an increased risk of breast cancer
  - The higher estrogen, for example [estrone](https://en.wikipedia.org/wiki/Estrone) would be specifically the type of estrogen that is associated with increased adiposity in postmenopausal women and is linked to a higher risk of breast cancer
- JoAnn agrees, when you’re talking about conjugated estrogen, it’s the combination of estrogen + [medroxyprogesterone acetate](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate)
  - It may be specific to that particular progestin, we don’t know
    - We have very limited research in terms of randomized clinical trials, large scale studies of other formulations of progestin
  - In terms of **breast cancer mortality**, the [results](https://jamanetwork.com/journals/jama/fullarticle/195120) in the WHI are very close to a statistically significant increase in breast cancer mortality with estrogen + progestin (it doesn’t quite make statistical significance)
- On the other hand, the conjugated estrogen alone was associated with a statistically significant *reduction* in breast cancer mortality
- So, really **diametrically opposite effects** of the combination with the medroxyprogesterone acetate of the estrogen with the medroxyprogesterone acetate versus the conjugated estrogen alone

***JoAnn thinks that the absolute risks are still low, and that is a very important point to emphasize that we are talking about one extra case per thousand women per year***

**Breast cancer risk considerations**

- For a woman who starts out with a **high baseline risk** because of the strong family history or other risk factors, this would certainly be something she would want to avoid
- But for a woman in early menopause at usual risk of breast cancer who would derive the **benefits of symptom relief**, this would be a risk that she would probably be willing to accept
  - She’s suffering from disrupted sleep, very bothersome hot flashes and night sweats that interfere with her day-to-day activities
  - There is an understanding that all medications have some risk and that she could be monitored closely with mammography and breast exams
  - Usually there would not be a fatal form of cancer

**Other cancers reported in the WHI**

- Overall, the WHI did *not* see any significant increase in total invasive cancers with either estrogen + progestin or estrogen alone
- Interestingly, with the combination estrogen + progestin, they saw a significant *reduction* in endometrial cancer, uterine cancer developing over time, and colorectal cancer also seemed to be at least borderline reduced ([*JAMA* 2013](https://jamanetwork.com/journals/jama/fullarticle/1745676))

> “*I think the clinical message and the message for the public is that hormone therapy has very complex effects*.”‒ JoAnn Manson

**The nuanced benefits and risks of HRT [51:15]**

- HRT has a complex matrix of benefits and risks that vary according to a woman’s age

**Consider the patient when deciding about hormone therapy**

- Consider her time since menopause, her underlying health status
- Decision making about hormone therapy really has to be individualized, personalized, and women themselves play such an important role in the shared decision making
- Many women will say, “*I do not want to take hormones no matter what.*”
  - And even if a woman’s at low risk and the doctor clinician may think that they really should consider hormone therapy, that’s the woman’s decision and you respect it
- Other women may want to take hormone therapy even though they know that there may be X, Y, or Z increased risk because their symptoms are so bothersome
  - Their sleep is being disrupted
  - They are not able to have work productivity
  - Their day-to-day activities are affected, their quality of life is really impaired

***It is very important that women be able to help make that decision together with their clinician, that they share in that decision making***

- For Peter, the only issue he would highlight is the scenario where the physician thinks HRT is the right thing to do, and the patient is in a fear mode of saying “*No way do I want HRT, it’s going to cause breast cancer*”
  - The patient is experiencing vasomotor symptoms, the patient already has osteopenia and their bone mineral density is only going to decline with time
  - He argues that’s a very ill-informed decision
  - They should be able to make whatever decision they want, but that doesn’t mean it’s a good decision based on good data
    - Because in reality, it’s not based on data

**Peter’s takeaway**:

- He thinks the data discussed don’t make a very strong case for avoiding HRT outside of select circumstances
- He worries that the last 20 years of women entering menopause have been put into two categories
  - 1 – Either there are women who really want HRT, but they can’t find physicians who will give it
  - 2 – There may be a physician who understands the data at the level discussed here, but the patients themselves have been so frightened off by misinterpretations of the data

**The conversation has to take place**

- It is important for clinicians to be informed themselves about benefits and risks and be able to discuss this in a very knowledgeable way with the patient
- JoAnn’s view is that if a patient feels strongly that she doesn’t want to take hormone therapy, she’s going to have a lot of fear and anxiety surrounding use of hormone therapy, and that will affect her overall wellbeing
  - Maybe her mother developed breast cancer while she was on the hormones, whether or not it was directly due to the hormones
  - That’s a factor in the benefit/ risk equation

***She advises not to push someone by just showing that the absolute risks because their emotional wellbeing is a very important part of the equation***

- She does agree that we need to emphasize absolute risks, that ***absolute risks are low and that there are better candidates and there are worse candidates***

**It’s amazing how the pendulum has swung**

- In the 1980s, 1990s, the perception was that hormone therapy was good for all women
  - Women were being routinely started on hormone therapy
- Then after the WHI in the early 2000s, the pendulum was in the opposite direction that hormone therapy is bad for all women
- Now the pendulum is coming to rest in a more appropriate place where hormone therapy is good for some, but not all women

**The best candidates for HRT**

- The best candidates are women in early menopause who have moderate to severe or bothersome hot flashes and night sweats and are in generally good health
  - Those are women who will derive quality of life benefits and have very minimal absolute risk from hormone therapy

## HRT and bone health [56:00]

**What if the pendulum didn’t go so far as to say women can’t and shouldn’t under any circumstance have HRT because they’re going to get breast cancer?**

- Peter has thought about how many women have missed out on HRT since the WHI was first [published](https://jamanetwork.com/journals/jama/fullarticle/195120) in 2002
- He assumes this is somewhere between 4-5 million women
- If you assume that HRT will cause additional cases of breast cancer, this shift reduced breast cancer by about 4,500 cases over the last 22, 23 years
- However, HRT reduced the incidence of hip fracture by about 1.5% in absolute terms (that’s remarkable)
  - Even though hip fracture is not a primary outcome
- There were benefits for other cancers as well, such as endometrial cancer with estrogen + progestin

**The problem in the argument of using HRT for bone health**:

- Women in their 40s and 50s have a low risk of osteoporotic hip fracture
  - They may have a hip fracture from a traumatic incident, but it’s not likely to be related to osteoporosis
- It’s when they get into their late 60s, 70s, 80s that they’re more likely to have the osteoporotic fractures
- If we were to treat women from early menopause into their 70s, 80s, that would be very long duration of hormone therapy use, which would lead to an increased risk of breast cancer (especially combination hormone therapy)
- And once women go off of hormone therapy, bone loss is very rapid

***All of the benefits to the bones in terms of preserving bone mineral density that dissipates very quickly within a matter of a few years after stopping hormone therapy***

- If a woman is taking hormones in her 40s and 50s and then she stops, let’s say at age 60, by the time she gets to the age where her risk of hip fracture is very substantial (in her 70s and 80s), she’s really *not* going to have a persistent sustained benefit from the hormone therapy
- JoAnn has looked within the group at high risk of osteoporotic fracture, whether they had a favorable overall favorable outcome in terms of the global index combination of all of these outcomes with hormone therapy

***Overall, there really was no group of women irrespective of their risk of osteoperotic fracture, who had a clearly beneficial risk ratio from estrogen + progestin when used for chronic disease prevention***

- Again, this does not mean that it isn’t a very effective treatment for hot flashes and night sweats, and that women in early menopause would have a favorable risk profile, taking into account the quality of life benefits

## The importance of timing when it comes to HRT, the best use cases, and advice on finding a clinician [59:30]

- It’s so important for women to understand that the absolute risks of these hormones are much lower in early menopause than in later menopause
- The risk of having adverse events on hormone therapy is lower in younger women, women in early menopause

**JoAnn saw some signals for benefit of HRT in women in their 50s**

- The youngest women in the study were 50 to 59
- Those women tended to do quite well in terms of heart disease and heart attack rate compared to the women on placebo
- There was a signal for benefit, and also a signal there for favorable outcomes in terms of all-cause mortality

***Overall, there were favorable signals with estrogen alone in the younger women and also lower risks of adverse events suggesting that in a woman who’s had a hysterectomy, if she’s symptomatic with hot flashes, night sweats, the benefits of treatment are likely to outweigh the risk***

- This was true even for the combination of estrogen + progestin
  - Despite what may be a small increase in risk of breast cancer, the benefits are likely to outweigh the risk, for the purpose of treating bothersome, disturbing, hot flashes, night sweats, disrupted sleep and impaired quality of life

> “*Women should not shy away from the use of hormone therapy and should discuss the option, weigh the benefits and risk carefully with their healthcare provider, and see if it’s the right decision for them*”‒ JoAnn Manson

**Finding a clinician**

- If you have trouble finding a clinician, go to the [North American Menopause Society website](https://menopause.org/)
  - You can put in your zip code and [find clinicians in your area](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx) who have this expert training
- JoAnn is an endocrinologist, and she knows that many endocrinologists have the training to talk about hormone therapy with patients

***Many clinicians have had limited training in use of hormone therapy, and it may be helpful for women to seek out a clinician who has had some additional training in menopause management and hormone therapy pros and cons***

**Non-hormonal medications for management of menopausal symptoms**

- And for women who are not good candidates, the good news is that there are non-hormonal options as well
  - They’re not quite as effective as the menopausal hormone therapy for treating hot flashes and night sweats
- Some of the antidepressant medications, [SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor), [SNRIs](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor), some of the [Gabapentinoid medications](https://en.wikipedia.org/wiki/Gabapentinoid), these medications have been found to be quite effective
  - They provide 40, 50% reduction in hot flashes and night sweats
- There’s a new medication that may be approved by the FDA fairly soon that works entirely in the brain in terms of making women less sensitive to the changes in temperature and has a very beneficial effect in terms of preventing hot flashes and night sweats

## A discussion on the potential impact of HRT on mortality and a thought experiment on a long-duration use of HRT [1:03:15]

Peter asks, “*If a woman stays on estradiol for the duration of her life (say from age 50 to 80), we accept that there’s going to be an increase in the incidence of breast cancer, though it doesn’t seem to translate to a difference in lifespan.*

*But on the flip side, we are reducing her risk of fracture during a very dangerous window. So, the incidence of fracture saved is about 1.5% percent, and the mortality of that once she reaches 65, the one-year mortality, depending on the series is 15-30%.*

*So, even if we just want to do this on the basis of mortality, apples to apples, it doesn’t even appear close, does it?*”

- Data published in [JAMA 2017](https://jamanetwork.com/journals/jama/fullarticle/2653735) show all-cause mortality results by age and time since menopause (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/05/f1-joannmanson-649x1024.png)

**Figure 1. WHI mortality outcome during the intervention phase according to age group at randomization**. Image credit: [*JAMA* 2017](https://jamanetwork.com/journals/jama/fullarticle/2653735)

- WHI did see that the younger women (in their 50s) taking either estrogen alone or estrogen + progestin had signals for about 30% lower mortality
  - Though it was not statistically significant in either trial individually
- Yet the women who were older (70-79), randomized to estrogen alone had a hazard rate 22% higher risk of all-cause mortality
  - It was not quite statistically significant (just at the border of being significant)
  - With estrogen + progestin, the effect was actually quite neutral (almost completely null)

***Estrogen alone seemed to be a tad worse in women age 70-79 while it was a tad better in women age 50-59***

**JoAnn’s takeaway ‒** ***So, again, timing is everything when it comes to the all-cause mortality results***

- There are favorable signals for the hormone therapy for women age 50-59 (earlier in menopause)
- The results are neutral for age 60-69
- But in age 70-79, there is a bit of a signal that estrogen alone may be linked to a small increase in risk of mortality

**Peter’s thought experiment on the mortality benefits of HRT gained from improved bone health**

*If a woman started HRT at the appropriate time (during the transition from perimenopause to menopause) and she stays on HRT for 30 years, what is the benefit of lower hip fracture risk on mortality?*

- By Peter’s calculation it’s a 15x reduction in mortality
- He feels that hip fracture such an underappreciated cause of mortality in both men and women over the age of 65
- And estrogen is hands-down the most important hormone as it pertains to signal transduction from the strain gauge within the muscle to the [osteoblast](https://en.wikipedia.org/wiki/Osteoblast) and [osteoclasts](https://en.wikipedia.org/wiki/Osteoclast)
- He points out, “*Even if you accept a slightly higher incidence of breast cancer, it’s being more than dwarfed by the reduction in the hip fractures that they will be sustaining 15 years after beginning*”
- The magnitude of that difference is so great, and that’s where the discussion is very confusing for people because they only see one thing which is breast cancer, and they don’t see it through the nuanced lens that we’re talking about it
- JoAnn points out that there has been excessive focus on one isolated outcome (breast cancer) when what really matters is the overall health of the woman
- Effects of HRT on mortality was quite neutral overall
  - In younger women, there was a signal for some reduction in risk
- But, a randomized trial has never been done that would look at 30 years of hormone therapy treatment starting in early menopause and continuing into mid to later menopause

***The reality is we don’t know whether the benefits would outweigh the risks***

**Taking hormones for decades**

- Some women will make the choice to continue to take hormone therapy into middle to later menopause because they started in early menopause, and they did well on hormones
  - Whey they try to reduce the dose or stop, they feel hot flashes coming back and so they end up taking these hormones well into their 60s, 70s, even longer
- In the observational studies, this looks like it has a relatively favorable benefit risk ratio
  - However, keep in mind, this is a very select group of women who are choosing to stay on hormone therapy long-term because they’re doing extremely well with it and they’ve tolerated it well, and they haven’t developed any of these interim events such as a heart attack, a stroke, a blood clot in the legs or lungs or breast cancer, other estrogen sensitive cancers
  - We’re selecting for healthier women

***Overall, we just don’t know what a randomized trial would show with long-term hormone therapy, but there is a risk that the risk would outweigh the benefits***

- The WHI showed an increased risk of stroke with both estrogen alone and estrogen + progestin
- There was cognitive decline and increased risk cognitive decline among the women 65 and older, although that was not the case in the younger women
- We just don’t know how the pattern of benefits and risks would change with longer duration once you get into 15, 20, 25 years of treatment

## Moving toward better HRT practices, and the need for more studies [1:10:00]

**Do you think we’ll ever get another RCT to look at better HRT practices?**

- Peter notes that [CEE](https://en.wikipedia.org/wiki/Conjugated_estrogens) and [MPA](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate) have largely fallen out of favor (he’s never seen a woman take those), but most women are using the [Vivelle-Dot](https://www.rxlist.com/vivelle-dot-drug.htm) or one of the [topical FDA patches which are pure estradiol](https://en.wikipedia.org/wiki/Estrogen_patch)
  - Most women these days are taking [micronized progesterone](https://en.wikipedia.org/wiki/Progesterone_(medication)), which is a bioidentical progesterone
  - Or women are foregoing oral progesterone altogether and using a [progesterone coded IUD](https://en.wikipedia.org/wiki/Hormonal_intrauterine_device), which seems to offer the same degree of local endometrial protection without any of the systemic effects (for women who can’t tolerate that)
- Peter comments, “*In some ways, the entire cluster of insights from the WHI are less relevant today given that the drugs that were tested aren’t the drugs that are in mass adoption*”
- JoAnn thinks it’s a good trend to move toward the transdermal estradiol and the micronized progesterone (FDA-approved) as opposed to the oral conjugated estrogen + medroxyprogesterone acetate
- Keep in mind that we really don’t know the long-term benefits and risks, but based on other terms of clinical outcomes such as heart attack, strokes, different forms of cancer, and all cause mortality
  - But it makes sense based on how these different formulations affect clotting, affect biomarkers for clotting and cardiometabolic health, blood pressure, all of those parameters

***JoAnn thinks there’s reason to use the transdermal and the micronized progesterone preferentially over the older formulations***

**We need more randomized trials of these formulations that are now in more common use**

- Especially looking at mammographic breast density to see if there’s less suggestion of a future risk in breast cancer based on the change in breast density
- Another large-scale trial on the magnitude of the WHI looking at women in early menopause would be extremely expensive
  - In order to have similar numbers of health outcomes and robust power to look at health outcomes, it would have to be at least 40-50,000 women randomized in their 50s and followed for 7-8 years
  - There also may be rapid changes in formulations over time, and so there would be a similar risk that the results might become obsolete by the time they are available
    - As Peter suggested the case is for conjugated estrogen + MPA
- Keep in mind that even though the WHI was testing the most common formulations at that time in the early 1990s, it did put an end to a practice of prescribing hormone therapy among women in later menopause for the purpose of preventing strokes and heart attacks and cognitive decline
  - Which actually were found in the WHI to be **adversely affected** by hormone therapy
- Also, women were *not* getting the benefits for **quality of life** once they were in their late 60s, 70s, because they were not having any hot flashes, night sweats, disrupted sleep
  - So they weren’t getting the benefits and they were getting these adverse outcomes

***It’s important to acknowledge that the WHI did put an end to what was an unfavorable practice;***

**The problem was that the WHI results were “over extrapolated”**

- The results were extrapolated to women in early menopause, taking hormone therapy for the hot flashes, night sweats
- It’s really important for women to understand that the WHI results are really not intended to discourage a woman who’s having disruptive sleep, very severe significant symptoms to discourage her from seeking help and seeking hormone therapy as one of her options for treatment
  - For a women in early menopause and generally good health, the benefits are likely to outweigh the risk

**Key message ‒ women in early menopause should take these symptoms seriously**

- Make sure they find a clinician who will take these symptoms seriously and discuss their treatment options, review with them the pros and cons
- If they are not finding that clinician, they need to go outside their current system and find a clinician who can help them to do that
  - There are many clinicians out there who are knowledgeable in menopause management, knowledgeable in hormone therapy decision making, who can help them to make the best choice for themselves
  - Search The North American Menopause Society, find a menopause practitioner [website](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx)

**Peter’s takeaways**

- There’s a lost generation of women who entered menopause and were denied HRT due to the ignorance of their physicians and the irresponsibility of the media
  - Women like his mother and mother-in-law who were entering menopause just as the WHI was coming to its conclusion and who suffered unnecessarily
- The pendulum is swinging, and he would like to believe that there aren’t women that are suffering that way today
- He has always respected JoAnn and continues to do so because he feels like she is one of the few people who was such an important part of the WHI who has been able to look back at that and acknowledge its limitations
- Her thinking seems to have evolved over time (at least through her writing), and that’s not a property that is necessarily inherent to everyone at her position
- She’s doing more good today by speaking out on the limitations of the WHI

§

## Selected Links / Related Material

**Fraction of women in the WHI who were taking statins**:

- [Menopausal Hormone Therapy and Health Outcomes During the Intervention and Extended Poststopping Phases of the Women’s Health Initiative Randomized Trials](https://jamanetwork.com/journals/jama/fullarticle/1745676) | *JAMA* (J Manson et al. 2013) | [26:00]
- [The Potential for Postrandomization Confounding in Randomized Clinical Trials](https://jamanetwork.com/journals/jama/article-abstract/2526647) | *JAMA* (J Manson, C Shufelt, & J Robins 2016) | [26:00]

**Breast density increases with hormone therapy**: [Mammographic Density Change With Estrogen and Progestin Therapy and Breast Cancer Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6059178/) | *Journal of the National Cancer Institute* (C Byrne et al. 2017) | [34:00]

**Women’s Health Initiative, initial results**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women: Principal Results From the Women’s Health Initiative Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/195120) | *JAMA* (J Rossouw et al. 2002) | [48:45, 56:00]

**Other cancers reported in the WHI**: [Menopausal Hormone Therapy and Health Outcomes During the Intervention and Extended Poststopping Phases of the Women’s Health Initiative Randomized Trials](https://jamanetwork.com/journals/jama/fullarticle/1745676) | *JAMA* (J Manson et al. 2013) | [50:30]

**Find a clinician for HRT**: [The North American Menopause Society](https://menopause.org/) | [Find a Menopause Practitioner](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx) | [1:01:45]

**Mortality data from the WHI (18-year follow-up)**: [Menopausal Hormone Therapy and Long-term All-Cause and Cause-Specific Mortality: The Women’s Health Initiative Randomized Trials](https://jamanetwork.com/journals/jama/fullarticle/2653735) | *JAMA* (J Manson, et al. 2017) | [1:04:15]

***NY Times*** **article on menopausal hormone therapy**: [Women Have Been Misled About Menopause](https://www.nytimes.com/2023/02/01/magazine/menopause-hot-flashes-hormone-therapy.html) | Susan Dominus, *The New York Times* (February 1, 2023)

§

![](https://peterattiamd.com/wp-content/uploads/2023/05/bio-joannmanson.jpeg)

##### JoAnn Manson, M.D.

JoAnn Manson earned her Bachelor of Arts degree from Harvard. She went on to Case Western Reserve School of Medicine for her MD, then returned to Harvard School of Public Health to earn her MPH and DrPH.

Dr. Manson is an endocrinologist, epidemiologist, and Principal Investigator of several research studies, including the Women’s Health Initiative, the cardiovascular component of the Nurses’ Health Study, the VITamin D and OmegA-3 TriaL (VITAL), the COcoa Supplement and Multivitamin Outcomes Study (COSMOS), and others. Her primary research interests include randomized clinical prevention trials of nutritional and lifestyle factors related to heart disease, diabetes, and cancer and the role of endogenous and exogenous estrogens as determinants of chronic disease. Currently, she serves as the Chief of the Division of Preventive Medicine at Brigham and Women’s Hospital. She is a Professor of Medicine and Michael and Lee Bell Professor of Women’s Health at Harvard Medical School, and she is a Professor of Epidemiology at Harvard T.H. Chan School of Public Health.

Dr. Manson has received numerous honors, including the American Heart Association’s (AHA) Population Research Prize, the AHA’s Distinguished Scientist Award, AHA invited lectureships (Ancel Keys and Distinguished Scientist lectures), election to the Institute of Medicine of the National Academies (National Academy of Medicine), membership in the Association of American Physicians (AAP), fellowship in AAAS, the Woman in Science Award from the American Medical Women’s Association, the Bernadine Healy Award for Visionary Leadership in Women’s Health, and the Massachusetts Medical Society awards in both Public Health and Women’s Health Research. She served as the 2011-2012 President of the North American Menopause Society.

Dr. Manson has published more than 1,200 articles and is the author or editor of several books and textbooks. She was also one of the physicians featured in the National Library of Medicine’s exhibition, History of American Women Physicians. [[Brigham and Women’s Hospital](https://prevmed.bwh.harvard.edu/joann-e-manson-md-dph/)]