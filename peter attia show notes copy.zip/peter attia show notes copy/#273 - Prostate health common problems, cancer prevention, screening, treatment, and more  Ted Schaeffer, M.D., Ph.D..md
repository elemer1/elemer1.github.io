# #273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.

**Source:** [https://peterattiamd.com/tedschaeffer2/](https://peterattiamd.com/tedschaeffer2/)

---

Ted Schaeffer is an internationally recognized urologist who specializes in prostate cancer. In this episode, Ted delves deep into the realm of prostate health, starting with strategies for vigilance and effective management of the issues that can arise with aging, including urinary symptoms, prostatitis, pelvic pain, and prostate inflammation. Ted sheds light on the popular drug finasteride, renowned for its dual purpose in prostate shrinkage and hair loss prevention, as well as the contentious topic of post-finasteride syndrome. Ted then shifts to the topic of cancer, explaining how androgens, genetics, and non-genetic factors contribute to the pathogenesis of prostate cancer. He provides valuable insights into cancer screening, examining blood-based screening tools like PSA and the use of MRI in facilitating biopsies and their interpretation. Finally, he explores the various treatment options for prostate cancer, including surgical interventions, androgen deprivation therapy, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tedschaeffer2/the_Drive_public.png)

Play

#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.

#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.

1x15s30s

0:003:29:17

## We discuss:

- Changes to the prostate with age and problems that can develop [3:45];
- Behavioral modifications to help manage nocturnal urinary frequency and other lower urinary tract symptoms [8:30];
- Pharmacologic tools for treating nocturnal urinary frequency and lower urinary tract symptoms [16:30];
- Surgical tools for treating symptoms of the lower urinary tract [26:15];
- HoLEP surgery for reducing prostate size [32:30];
- Prostate size: correlation with cancer, and considerations for small prostates with persistent symptoms [40:30];
- Prostatitis due to infection: symptoms, pathogenesis, and treatment [46:45];
- Prostatitis caused by other factors besides infection [58:45];
- How to minimize risk of urosepsis in patients with Alzheimer’s disease [1:05:00];
- Prostate cancer: 5-alpha reductase inhibitors, how androgens factor into pathogenesis, and more [1:10:00];
- Post-finasteride syndrome [1:18:15];
- The relationship between testosterone and DHT and the development of prostate cancer over a man’s lifetime [1:26:30];
- How genetic analysis of a tumor can indicate the aggressiveness of cancer [1:35:15];
- Pathogenesis and genetic risk factors of prostate cancer, and the use of PSA to screen for cancer [1:37:45];
- Non-genetic risk factors for prostate cancer [1:45:45];
- Deep dive into PSA as a screening tool: what is PSA, definition of terms, and how to interpret results [1:56:30];
- MRI as a secondary screening tool and the prostate biopsy options [2:13:15];
- Ted’s ongoing randomized trial comparing different methods of prostate biopsy [2:24:00];
- Determining when a biopsy is necessary, interpreting results, explaining Gleason score, and more [2:27:00];
- Implications of a Gleason score of 7 or higher [2:46:45];
- Metastasis of prostate cancer to different body locations, treatment options, staging, and considerations for patients’ quality of life and survival [2:53:30];
- How prostate cancer surgery has improved [3:09:30];
- Questions to ask your neurologist if you are considering prostatectomy for cancer [3:21:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- The guest this week is Ted Schaeffer
- Ted is an internationally recognized urologist, prostate cancer oncologist, author, and speaker
- He is the chair of the department of urology at the Feinberg School of Medicine, the urologist in chief at Northwestern Memorial Hospital, and the program director of the GU Oncology program at Northwestern
- Ted has published more than 400 publications emphasizing at risk populations, diagnosis, treatment outcomes, and the molecular biology of lethal prostate cancer
- He is the co-author of a new book [*Dr. Patrick Walsh’s Guide to Surviving Prostate Cancer*](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1538726866/ref=sr_1_4?crid=E70A0SEF22CV&keywords=Dr.+Patrick+Walsh%E2%80%99s+Guide+to+Surviving+Prostate+Cancer&qid=1695059493&sprefix=dr.+patrick+walsh+s+guide+to+surviving+prostate+cancer%2Caps%2C237&sr=8-4)  (available October 3, 2023)
- In addition to his work at Northwestern University, Ted is also a consultant to a variety of individuals who are going through various aspects of prostate cancer and prostate care
  - You can learn more about these services on his [website](https://tedschaeffermd.com/)
- Ted was a guest in [episode #39](https://peterattiamd.com/tedschaeffer/) in February 2019, and a lot has changed since then
- In this episode we talk about all things related to the prostate
- We discuss the problems that can arise with the prostate as you age
  - Including urinary symptoms, and an increase in frequency of going to the bathroom at night
- We talk about prostatitis, pelvic pain, and prostate inflammation
- We talk about a very popular drug finasteride used to both shrink the prostate and prevent hair loss and something called post-finasteride syndrome
  - Along with concerns people have around this controversial diagnosis
- We move on to talk about prostate cancer
  - We talk about how androgens work
    - How testosterone and DHT work
    - How they related to prostate size
  - How genetics and non-genetic factors, factor into prostate cancer and its pathogenesis
  - We discuss the blood-based screening tools that are at our disposal for prostate cancer: PSA, free PSA, PSA-density, and PSA velocity
  - We talk about how we use MRI to facilitate biopsies and what biopsies mean
  - We talk about how to interpret a biopsy and how does that tell us which patients should and shouldn’t undergo prostate removal
  - We talk about prostate cancer treatments: surgical interventions and androgen deprivation therapy
- Peter wants to highlight, “*Prostate cancer is the second leading cause of cancer death in men… I believe it’s also one that is also highly preventable, and as such I think it is very important for everyone to listen to this because unfortunately, it’s very unlikely that you’ll go through your life not being touched by this or knowing someone who is.*”

## Changes to the prostate with age and problems that can develop [3:45]

**What the prostate gland is and what it does**

- Let’s start at the beginning
  - It’s worth assuming that a lot of people didn’t hear the first podcast, and those that did probably don’t remember much
- A lot has changed in four years [since the [previous podcast with Ted](https://peterattiamd.com/tedschaeffer/)]
- The [prostate](https://en.wikipedia.org/wiki/Prostate) is an exocrine gland, and it’s part of the reproductive system
- It sits just below the bladder in men (shown below)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f1-tedschaeffer2.png)

**Figure 1. The prostate and nearby organs**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Prostate)

- The prostate is a dimorphic organ, it does not exist in women
  - It develops in utero in response to fetal androgens
- It produces 50-60% of the components of semen
- It’s used in reproduction in all mammals

**When you think about things that start to go wrong in the prostate, most men might think of prostatitis**

- Inflammation, infection, benign enlargement that leads to obstruction and the neoplasm
- The prostate is an organ that sits in line with the urinary tract
- The urinary tract in men has a dual purpose
  - 1 – It’s used for reproduction
  - 2 – It’s used to eliminate all the urine
  - Because of that shared functionality, you can develop problems in one or the other of those two disease systems and they result in symptomatic issues
- A lot of problems that men will experience are related to the prostate
  - Even at a young age, but particularly as they age
  - It’s absolutely true that in younger men you can develop infections in the urinary tract, and they can be problematic and difficult to solve if they involve the prostate
  - If you develop an infection (classic bacterial or potentially viral or other kinds of causes) you can get inflammation in the prostate, which can result in long-term pain
    - That’s one of the things Ted sees when young men come in with prostatitis
- The prostate evolves and changes as we get older, different issues arise
  - They can result and impact your urinary function, because it’s a shared system of elimination of semen and of urine

*Prevalence of prostate problems*

- As we get older, 50-60% of men at age 50 and older will have issues with lower urinary tract dysfunction, and those almost always directly relate to the prostate in some way or another
- By age 60, it’s 75-80% of men will have lower urinary tract symptoms

**Lower urinary tract symptoms**

- These include: weak stream, hesitation or slowness in getting your urinary stream started, urgency to go to the bathroom, increased frequency to go to the bathroom
- Symptoms are related to two things:
- 1 – ***Functional obstruction of the urethra*** (that’s the tube we urinate through, the tube that comes out of the tip of the penis)
  - The first part of that tube passes right through the middle of the prostate
  - So as the prostate enlarges, it can compress that channel, and that can result in a weak stream; it can result in dribbling and straining
- Above the prostate is the bladder, and the bladder is a bag (a storage device) that is muscular
- As the diameter of the urethra narrows with increasing [prostate] size, *that muscle will have to work harder*
  - Compliance will go down
  - And when the compliance of the bladder goes down, the capacity can go down and the increased urgency to go to the bathroom will go up (because it’s less stretchy)
- 2 – ***As we get older, parts of the prostate will grow***
- Oftentimes, that growth of the prostate results in narrowing of the channel
  - That can commonly lead to thickening of the bladder wall, and then that results in a whole constellation of urinary symptoms, which can be managed
    - Many, many men have them

## Behavioral modifications to help manage nocturnal urinary frequency and other lower urinary tract symptoms [8:30]

**The first steps in the medical management of lower urinary symptoms**

- This is an area where the surgeon (urologists) does both the medical management and the surgical management
- Urology is one of the more unique specialities in that they do a lot of diagnosing, then medically managing, treating surgically, and then survivorship for almost all of the conditions that they take care of
- 1 – ***Behavioral modifications***
- Educating people that if you increase your fluid intake, you’re going to have increased urinary output
- In addition to regulating what you drink, it’s *when* you drink it and *what* you’re drinking
- For example, a lot of people come in with symptoms of nighttime urinary frequency
  - You can modify this a lot with education saying, “*Hey, don’t drink two glasses of water right before you go to bed. And if you get up in the middle of the night because you have to urinate, don’t drink another glass of water when you get up to urinate.*”
- What’s in the fluids is also important, especially caffeine
  - There are some fluids that have natural [diuretic](https://en.wikipedia.org/wiki/Diuretic) properties (like caffeine)
  - Drinking something that’s a diuretic, you’re going to produce more urine and that will result in more urinary symptoms within two to four hours after taking that fluid in

**Advice:** ***Ted often advises patients to keep a diary of what they’re drinking and when they’re urinating (a voiding diary)***

- A voiding diary will map out when you’re drinking and urinating (timing and volume of both), and then the urologist can go from there
- This is the first step in mapping out behavioral modifications
- If you’re sensing that they may be **urinating much more at night** than you would anticipate after you’ve done these different behavioral modifications, there are **hormonal deficiencies** that can result in increased urinary production at night

**What if a guy comes to you and is upset about the frequency with which he’s waking up to pee at night? Is there a norm?**

- The medical term for that is [nocturia](https://en.wikipedia.org/wiki/Nocturia)
- Both Peter and Ted are 50 years old, and Peter notes that 5 nights a week, he doesn’t get up to pee
  - Two nights a week, he gets up to pee once, and that’s probably more tied to the timing of his fluid intake than prostate-specific symptoms

*What is normal for a 50-60-year old?*

- There’s a lot of variability in terms of what you can expect based on the age of the individual
- There’s a naturally secreted hormone ([antidiuretic hormone, ADH](https://en.wikipedia.org/wiki/Vasopressin)), and in younger decades of life, it has a surge of release around 7:00 or 8:00 at night
  - Antidiuretic hormone prevents you from diuresing (or producing) more fluid
- Peter adds that **alcohol** inhibits antidiuretic hormone, which is why alcohol before bed is a great recipe for having to get up and pee for two reasons
  - You get the fluid in the drink, and then you get a molecule that inhibits the release of antidiuretic hormone
  - The classic example is beer, because it’s a high-volume intake
- We have natural diurnal release of antidiuretic hormone, and that [diurnal](https://en.wikipedia.org/wiki/Diurnal_cycle#Semi-diurnal_cycle) variation is attenuated per decade as we get older
  - The peak of antidiuretic hormone goes down per decade, and that can then normalize your 24-hour urine production
  - For example, when you’re in your twenties or thirties, you would produce, let’s just say 80 or 90% of your urine during waking hours
  - During the nighttime when you have high levels of antidiuretic hormone, you’re not going to produce as much urine and your kidneys and your body will save that extra fluid for the morning when you get up

**Is there a biologic explanation for the attenuation of antidiuretic hormone as we age?**

- It is certainly seen in aging populations in general, in both men and women
- Why that is, is unknown
- There are other factors that are also similarly consistent among aging individuals, male or female
  - Like the resiliency of the [tight junctions](https://en.wikipedia.org/wiki/Tight_junction) in your capillaries, your vascular system ‒ it’s less resilient and less tight as we get older
    - Even if it’s subtle and not fully appreciable, you have some capillary leak
    - As you lie down when you’re sleeping at night, that fluid will leave the extracellular space, enter the intravascular space, and your kidneys will read that as increased fluid
- When Ted has patients with urinary symptoms, he does a full body assessment, because one of the main drivers of nighttime urinary frequency or one of them that particularly tracks with age is just [peripheral edema](https://en.wikipedia.org/wiki/Peripheral_edema)
  - Peter clarifies, “*Meaning people who have a lot of peripheral edema, in nighttime you get basically reversal of some of the third spacing?… It’s almost like they have an IV drip that’s taking fluid from their interstitial space into their vascular space. It’s like they’re drinking at night.*”
    - Yes
- One non-medical modification is [knee-high TED stockings](https://en.wikipedia.org/wiki/Compression_stockings) for people who are having symptoms
- The other thing that is a main issue related to nocturnal urinary frequency is [sleep apnea](https://en.wikipedia.org/wiki/Sleep_apnea)
- Sleep apnea will produce symptomatic profound urine production and nocturnal urinary frequency, and it can actually result in profound nighttime urinary incontinence
  - This is related to the regulation of antidiuretic hormones
  - There are profound whole-body side effects from it
  - For a subset of men, this is a good way to encourage them to get their sleep apnea diagnosed and treated

## Pharmacologic tools for treating nocturnal urinary frequency and lower urinary tract symptoms [16:30]

**pharmacologic tools**

- In Peter’s practice, they use a very low dose of [desmopressin](https://en.wikipedia.org/wiki/Desmopressin) (0.2 mg) before bedtime
  - This is a synthetic version of the antidiuretic hormone
  - They will prescribe this for the guy who is getting up at night to pee but doesn’t have a particularly enlarged prostate or other clear explanation
  - A theoretically a contraindication or a concern would be [hyponatremia](https://en.wikipedia.org/wiki/Hyponatremia), as you would increase plasma volume and therefore dilute sodium
- There are very straightforward frontline medical management pharmacologic agents to manage lower urinary tract symptoms
  - An [alpha-blocker](https://en.wikipedia.org/wiki/Alpha_blocker): that’s a class of compounds that are very specific to prevent activation of a set of smooth muscles isolated mostly in the prostate and somewhat in the seminal vesicles

*Take a step back and look at the embryology of the prostate*

- The prostate developed from the urogenital sinus, and there’s mesenchymal and epithelial components of that
- So there’s a lot of smooth muscle within the prostate
- The smooth muscle exists within the prostate in part to help with ejaculation
  - It’s like a pump
  - When you’re having an orgasm and the pump squeezes, the prostate will squeeze, and that will result in emission of the fluid
- What you can do for individuals who have lower urinary tract symptoms is **relax the smooth muscle within the prostate** [with an alpha-blocker]
  - You have this tube going right through the middle of the prostate (that’s the urethra)
  - Theoretically, this will enhances the diameter of the prostatic urethral channel, and that could then result in relaxation and improvement in urinary symptoms
  - It works quite well for most people
- Originally, this was noted because of the first class of alpha-blockers were used for blood pressure control, and one of the side effects was profound hypotension (until you titrated up the dose and so forth)

***Alpha-blockers are selective in that they relax those muscles within the prostate without dropping blood pressure***

- The newest generation are even selective to the smooth muscle within the prostate and not the [seminal vesicles](https://en.wikipedia.org/wiki/Seminal_vesicles)
  - So the seminal vesicles in the prostate grow up right next to each other
    - For example, when you do a [radical prostatectomy](https://en.wikipedia.org/wiki/Prostatectomy), you take out both organs; they’re attached to each other
  - The seminal vesicles dump into the prostatic urethra
  - The second generation, third generation alpha-blockers would paralyze (or prevent contraction) of the prostatic smooth muscle; so you would have improved urinary symptoms

**Does it impede ejaculation?**

- The more targeted alpha-blockers would, but the newest classes of these medications really focus only on the prostate
  - And there is less impact on the volume of seminal emission

**Would you only use these third-generation alpha-blockers? What are they called?**

- [Alfuzosin](https://en.wikipedia.org/wiki/Alfuzosin) is the one Ted usually goes to
- There’s another 3.5-generation medication called [silodosin](https://en.wikipedia.org/wiki/Silodosin)

> “*Alfuzosin and silodosin are the two newest medications that are third generation that result in less impact on sexual dysfunction, specifically less impact on semen production, but have really, really outstanding efficacy in terms of relaxing the prostate and improving urinary symptoms*.”‒ Ted Schaeffer

**Why are drugs that block the conversion of testosterone to DHT (5𝛼-reductase inhibitors) used to treat nocturnal urinary frequency?**

- Peter remembers doing urology rotations in med school (even in residency), a common drug used to treat this was [Proscar (generic finasteride)](https://en.wikipedia.org/wiki/Finasteride)
  - It blocked the conversion of testosterone to DHT
- There are specific indications where you would think about utilizing a [5𝛼-reductase inhibitor](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_inhibitor) for men with lower urinary tract symptoms
  - It’s a second-line treatment
  - If you have urinary symptoms, and you’ve failed behavioral modifications, then we would do an alpha-blocker [this is the first-line treatment]
  - If an alpha blocker is working, but not to the extent that the patient’s satisfied and the individual patient has a large prostate over 70 grams [then a 5𝛼-reductase inhibitor is considered]
    - You can diagnose that on an ultrasound or MRI
    - A good urologist can diagnose that on a rectal exam (Ted thinks about things like small, medium, and large)
- A [5𝛼-reductase inhibitor](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_inhibitor) (finasteride or dutasteride) has been shown to reduce the likelihood of urinary retention and reduce the need for surgical procedures in prospective randomized trials
  - In general, they’re recommended for the big, beefy prostates
- They decrease the size of the prostate by 20-30%, but it doesn’t happen immediately

***Using a 5𝛼-reductase inhibitor, it takes 6 months to feel better and see a size reduction in your prostate, but when you take an alpha-blocker, you feel better within a week***

- **Caution**: with the 5𝛼-reductase inhibitors, your [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen) numbers will decline
  - PSA is an androgen-related product, so when you reduce the amount of that potent androgen, you’ll reduce the value of PSA (by about half)
  - So it’s critical that patients are aware of their PSA numbers
  - This drug could potentially mask pathology
  - It’s a useful drug, but not something Ted uses often because it requires very active monitoring and has limited efficacy
- There are also a lot of potential issues one can experience while taking 5𝛼-reductase inhibitors
  - So Ted is cautious to use them
  - He reaches for an alpha-blocker
- If the alpha blocker is working in terms of improving the outlet obstruction symptoms (that’s strength of the stream, how fast can you empty) but patients still have a significant urinary bother (increased urinary frequency, urgency to go to the bathroom), then you can either do an [antimuscarinic](https://en.wikipedia.org/wiki/Muscarinic_antagonist) or an [M3](https://en.wikipedia.org/wiki/Muscarinic_acetylcholine_receptor_M3) agonist (which is the newest class in that category)
  - These really help relax the muscles in the bladder and significantly impact the symptomatology for people with predominantly what we would call “storage” symptoms
  - You can have “obstructive” symptoms, and alpha-blockers work great for those

**Are “storage” symptoms frequency?**

- Frequency, urgency
- If you have a thick bladder, the compliance is poor, it doesn’t stretch well, it just always feels full
- Those are things that can be very, very nicely addressed with these agents
- Antimuscarinics are dangerous, you need to be careful when using them, because in aging individuals they are associated with worsening of dementia and other kinds of neurologic cognitive acuity

***The M3 agonists has the same net effect but are much cleaner, much less side effects***

- The antimuscarinics were just older drugs
  - We could put those in the same category as the 5𝛼-reductase inhibitors

**Are women as susceptible to urgency and frequency from the same underlying pathology?**

- Peter notes that when women go through [menopause](https://en.wikipedia.org/wiki/Menopause), estrogen withdrawal alone can produce those symptoms [menopause discussed in [episode #259](https://peterattiamd.com/sharonparish/), hormones discussed in [episode #256](https://peterattiamd.com/endocrinesystem/)]
  - There the treatment is clear: estrogen replacement

*Given that women don’t have a prostate and therefore don’t have something abutting their bladder in the same way as men, is there a role for using M3 agonists in treating symptoms of urinary frequency and urgency?*

- Yes, prescription frequency of these medications is much, much higher in women
- They are used to treat the classic [overactive bladder](https://en.wikipedia.org/wiki/Overactive_bladder)
- Women will have bladder symptoms that are also similar in men
- Men have a thousand to one more often obstructive symptoms, because the urethra in a woman is very short (it’s 4 cm long)
  - The urethra in a man is 25 centimeters long on average
  - So the obstructive symptoms are much more prevalent in men, and so that’s why frontline treatment is always an alpha-blocker

***For men that have a good response with an alpha-blocker, but are still bothered by symptoms, the next drug to add is an M3 agonist***

## Surgical tools for treating symptoms of the lower urinary tract [26:15]

- Adding drugs is always a balance because at some point you have to ask, “*How old is the patient? How significant are their symptoms?*”
- There are highly effective ways to manage these issues surgically, and most can be done just simple outpatient surgery

> “*We have outpatient surgical procedures that can basically fix this for life with no medications*.”‒ Ted Schaeffer

- 25 years ago, Peter learned about the [TURP (transurethral resection of the prostate)](https://en.wikipedia.org/wiki/Transurethral_resection_of_the_prostate),a kind of Roto-Rooter job

**Anatomy of the prostate as it relates to age-related changes and surgery**

- The prostate develops from the urogenital sinus
- The prostate as we mature, in response to androgens and estrogens, it develops into different zones or different regions
- The peripheral zone, which is outlying the prostate gets bigger as we mature
  - **Analogy**: think about an orange, the orange peel is the *peripheral zone* and the pulp of the orange is a *transitional zone* of the prostate
- It’s not just a testosterone-driven thing, but when there’s more estrogens around ‒ estrogen with testosterone can result in hypertrophy (increasing in size) of the transition zone
  - That is what causes all the urinary symptoms in individuals
  - In rare exceptions an aggressive cancer is what’s causing it

**There’s a variety of MIST procedures (minimally invasive surgical procedures) that can address these urinary symptoms**

- You can introduce steam into the transitional zone tissue that can effectively kill all the smooth muscle and reduce to some extent the kind of hypertrophy of the epithelial cells
- You can surgically resect it transurethrally
  - Going through the natural orifice; no incision
- You could suspend it surgically
  - There are tethers that you can put in place that tent open the urethra

***The mainstay, the gold standard is to remove the tissue (via*** [***TURP***](https://en.wikipedia.org/wiki/Transurethral_resection_of_the_prostate)***), which can result in profoundly improved urinary symptoms***

- TURP (transurethral resection of the prostate) has evolved in that it can now be done with irrigation that is with normal saline
  - Traditionally, to maintain a monopolar current, you had to use water, because you would not want the sodium to disrupt that current
  - Now, a modern TURP is a bipolar TURP

**Explain to folks why you need an irrigant when you’re doing this procedure**

- This is a kind of Roto-Rooter procedure, but you’re technically removing bulky tissue in the urethra that’s circumferentially surrounding the prostatic urethra
  - Peter summarizes, “*Using the natural orifice of itself, you have to expand the diameter of this thing by actually getting rid of prostatic tissue in the transitional zone*.”
- In the traditional TURP, you scrape out small portions (usually 1-2 gram size little scoops of tissue) with a hot knife (it’s shaped like a loop)
  - So you core out little loops of tissue
  - And when you do that, you (A) have bleeding and (B) the tissue collapses on you
    - It’s like a cave, the tissue keeps falling in on you
  - So you have to suspend it open with the irrigant and you have to use the irrigant to better visualize what you’re doing
- Traditionally the irrigant was water
  - It tented open the tissue
  - Putting it under pressure, you could have water move into the intravascular system and you could get something called [post-TUR syndrome](https://en.wikipedia.org/wiki/Transurethral_resection_of_the_prostate#Acute_complications), which is basically where you made the patient profoundly hyponatremic
    - You diluted their sodium too much, and that’s very dangerous
    - You would have significant neurologic issues and so forth
- 15 years ago, they started redesigning the devices so you could irrigate with saline
  - Therefore, if there was flow of fluid from the procedure into the intravascular space, the fluid is [isotonic](https://en.wikipedia.org/wiki/Tonicity#Isotonicity)
  - That prevented issues you could have with post-TUR syndrome
- All the new MIST (minimally invasive surgical techniques) compared themselves in terms of efficacy to TURP
- Ted has a partner at Northwestern, [Dr. Amy Krambeck](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=50492)
  - Peter has sent a couple patients to her
- Amy does a procedure called [HoLEP (holmium laser enucleation of the prostate)](https://www.nm.org/conditions-and-care-areas/urology/benign-prostatic-hyperplasia/treatments#tabs_accord)
- So the TURP is effectively scraping out little one gram chunks of tissue
- If you have a 100 gram prostate, your goal is to get it down to 15 grams
  - Even less than normal
  - A normal prostate for a man who is 40-50 is between 20-30 g, but it increases in size as we get older
- People can have profound urinary symptoms with prostates as small as 35 g
  - People often assume because you have urinary symptoms that you actually have this gigantic enlarged prostate, but that’s not true
  - The smaller prostates can typically be well-managed with medication
- Ted moves to surgical treatment when prostates get larger

***The gold-standard historically is TURP; it’s now bipolar TURP (so it can be done safety)***

- A good surgical procedure is effective for life, but they’re not all like that
  - If less tissue is removed, or if you don’t remove any tissue, you’re more likely to need secondary treatment

## HoLEP surgery for reducing prostate size [32:30]

> “*My partner Amy Krambeck is really one of the pioneers in modern HoLEP surgery*.”‒ Ted Schaeffer

- If you think about the orange analogy, a TURP or any of those other procedures is basically trying to scrape out the pulp one little chunk at a time
- Amy will go in and she’ll get in the plane between the peel or the rind of the orange and she’ll take it all out in one piece
  - She pushes it into the bladder, and then there’s a morcellator that then chomps it into little tiny pieces that you then remove through the urethra

**Peter’s summary of traditional TURP**

- Using the orange analogy, if you’re doing a TURP, you’ve got a pencil hole going through the orange
- You’ve got to put a hollow pencil into that pencil hole and literally one tiny, tiny thimble at a time pull out little sacks of pulp one by one by one by one by one by one by one
- Ted points out that when you’re doing that, you’re disrupting the architecture of the orange
  - There are lots of blood vessels that exist within the transition zone itself
  - It bleeds a lot

**With HoLEP (Amy’s procedure)**

- She shaves into that natural tissue plane, and there’s not as much bleeding
- She somehow manages to take that whole pulp minus the peel, and shove it into the bladder
  - When it’s in the bladder, now isolated, she can break it apart (she’ll morcellate it apart)
- The HoLEP procedure was developed and originally described by a New Zealand urologist, and it was limited for a long time by laser technology
- Amy has developed the latest version with lasers that are higher energy and more precise

***Couple HoLEP with an experienced surgeon and the outcomes are spectacular***

**What are the patients who would not be considered candidates for that procedure? Is there a contraindication to that?**

- If you’re talented enough (like Amy), you can do it in anybody
- The smaller the prostate, the less distinct the differentiation is between the the peel of the orange (peripheral zone) and the pulp (transitional zone)
  - It requires more skill to do a HoLEP in a smaller gland than in a bigger gland
- When the prostate is really, really big, the adenoma is very well-formed and it’s easier to get into that plane
  - A large prostate would be >80 g (that is the threshold for doing a TURP)
- It takes a long time to do a TURP, but Amy can do a 200 g prostate in about 20 minutes [using the HoLEP technique] (she’s spectacular)

**Tell me about what that patient goes through post procedure**

- Peter assumes it’s an outpatient procedure, and they go home that day

*Do they have a catheter in place?*

- No
- Peter remembers from his urology rotations, the catheter management on that patient with a bag full of bloody water and urine coming out for days and days and day
  - It’s a relatively small price to pay for the ultimate relief you’re going to get

*How is it that this patient leaves the office without a catheter?*

- It has to just do with what you do at the end of the procedure, how well you’re controlling the bleeding
- The big difference in HoLEP, is when you’re in that distinctive plane between adenoma and peripheral zone, the vessels are much more discreet
  - Whereas in a TURP, there’s these sinuses and so forth
- Peter finds the analogy of the orange perfect, “*If you try to peel an orange from the inside, ripping apart, you’re going to get orange juice all over your hands, whereas if you’re taking the skin off, it’s …*”
- [With TURP] you remove less tissue, it’s bloodier, it’s less elegant

**Ted’s big picture summary:** ***if people are on medication and they have progression, you can start talking about minimally invasive surgical procedures (these are quick, in-office procedures), but the less you do, the less durable and less effective it is over time***

**There are procedures where you can tent up the prostatic urethral channel called** [**UroLift**](https://www.urolift.com/)

- Basically temporary relief
- Ted would *only* even consider those in individuals who could not tolerate the medications

***Ted never recommends it because it never works and can cause a lot of pain***

- You put these clips and you’re tethering things up
- It prevents effective high-quality MRI
- There’s lots of limitations
- But people who listen to your show may be offered these things
- Next step up would be to basically use **steam** to ablate the prostatic cells
  - This desiccates the cells, and that can result in pretty good symptomatic relief

**Do patients require general anesthesia for this?**

- No
- For [UroLift](https://www.urolift.com/), you can do it in the office
- For this procedure called [Rezum](https://www.rezum.com/home.html), you can do that in the office with local anesthesia
  - It’s uncomfortable for patients, but it can be done there, or it can be done under twilight
  - It is a step more in terms of intensity in what you feel
  - Those individuals go home with the catheters
    - There is lots of edema and lots of swelling when you do that procedure, so they require a catheter for several days to a week
  - Steam creates inflammation even though it’s cauterizing, and if you don’t leave the catheter in, they’re going to get a urinary obstruction that will close their urethra

**Effective surgical therapies for the patient with a prostate <70-80 grams**

- Rezum would be the next step up in terms of invasiveness
- Then you could always go to this traditional TURP or bipolar TURP
- HoLEP was originally developed to handle the bigger prostates, which traditionally when Peter and Ted were training at Hopkins, an open simple prostatectomy would be used
  - That’s where you open the patient up from above, just below their belly button
  - You open up the bladder and then you manually, with your finger, carve out that inner pulp of the orange, leaving the peel of the orange behind
  - The reason you leave the peel behind in that procedure is because it’s not a cancer, you don’t need to risk injuring the neurovascular bundle on the outside (we’ll discuss prostate cancer later)
- Everything around the outer peel of the orange is all the important real estate
  - The urinary sphincter muscle and all the nerve tissue that goes to the sphincter and also goes to the cavernosal bodies that trigger erection
- Now that procedure’s evolved and can be done minimally invasively with the robotic procedure, and that was really emerging as a standard of care
- Then the super talented surgeons like [Amy Krambeck](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=50492) came along and can do a 200, 400, 600 gram prostate

**Can you just show me what a 400 g prostate looks like?**

- A 400 g prostate is a large grapefruit whereas a normal prostate is a golf ball
- An orange would be 100 g, a big grapefruit is 400 g
- Operating on a 400 g prostate used to be a procedure that was technically very difficult to handle with an open robotic simple prostatectomy
  - Amy Krambeck can do three of those in a day and be done by noon

**When a guy has a 200-400 g prostate, is that virtually all genetic?**

- Yes, you see that a lot where it runs in families
- What is underlying that overgrowth is not well studied
  - Should the NIH put their research dollars behind why men get big prostates? Probably not

## Prostate size: correlation with cancer, and considerations for small prostates with persistent symptoms [40:30]

**Is there any correlation with prostate size and cancer?**

- Yes

***The bigger the prostate, the less your chance of developing aggressive cancer is, and we’re not sure why that is***

- It may have to do with variations in the balance of hormones
  - Large prostates grow in response to not an increase in testosterone, but more of an even ratio of T to E (testosterone to estrogen)
  - So as your testosterone declines (with age), the T can go down, but estrogen remains pretty stable or can go up
    - Peter adds that if you have metabolic syndrome, estrogen will rise
- Ted believes it’s more hormonal for the prostate to grow as men age

**Peter’s takeaway:** ***classic thinking has proved false, that testosterone is causing prostate cancer***

- It’s more nuanced than that, and it may be more related to the relationship of testosterone and estrogen
  - A declining testosterone in the presence of a rising estrogen would be a more favorable endocrine milieu for prostate cancer than the younger phenotype which is higher testosterone to estrogen
- Ted explains, “*As you’re aging and if you have metabolic syndrome, your testosterone levels will go down, your estrogen levels will go up, and that can result in prostatic growth, but it’s typically more adenoma growth in the transition zone causing lower urinary tract symptoms.*”
  - [Benign growth](https://en.wikipedia.org/wiki/Benign_tumor)
  - That somehow is protective, either the size or just the ratio
  - That difference in ratio of T to E is somehow protective for developing later onset prostate cancer

> “*In my mind, you’re locked in and your code is effectively set in stone in your thirties and forties, in my opinion, for prostate cancer*.”‒ Ted Schaeffer

- Age 30-40 is when your estrogen levels are very low and your T levels are higher

***Ted believes it’s the T to E ratio that is responsible for prostatic enlargement much more than the development of any prostate cancer***

**To close the loop on surgical procedures for lower urinary tract symptoms, what is the floor for HoLEP?**

- For someone as talented as Amy, the smallest prostate she would do that procedure on is 25-30 g
- For anybody who needs a surgical procedure, that’s her go-to technique
- Below that size, there’s not a lot of transitional zone tissue

***The other key take-home message for listeners: if you are developing profound urinary symptoms and you have a small prostate, you have to start looking for other sources***

- And by definition, you’re not responding to two classes of drugs (discussed earlier)
- You have to worry about cancers
  - Not prostate cancer but [urothelial carcinoma](https://en.wikipedia.org/wiki/Transitional_cell_carcinoma) (which is a cancer in the lining of the bladder or urethra)
- Urothelial carcinoma is also seen in young women
  - A classic board exam question: a young woman comes in with urgency, frequency, you neglect to look at their urine for cancer cells and they can have a cancer in the lining of their urothelium that’s causing all those urinary symptoms

**Peter’s takeaway:** ***a small prostate that is unresponsive to medical management, and the patient has persistent symptoms ‒ you better do urinary cytology***

- Ted agrees, you need to do a workup to rule that out for sure
- There can be other central nervous system diseases that can result in urinary symptomatology, but in general, as a urologist, you have someone coming in with those symptoms, you really want to start understanding, well, what else could be going on?
- Those individuals may have had a history of prostate infection, like a bacterial infection or may have had a viral infection
  - That can result in prostatitis and inflammation in the pelvic floor itself, and that can result in all those symptoms

> “*You can have as your canary in that coal mine that you have urgency frequency, but it’s not at all attributed to a large prostate. It’s not attributed to drinking too much fluid… there’s a lot of potential issues*”‒ Ted Schaeffer

- If you take away the attribution of a urothelial carcinoma, then you have to start saying, well, what are the other causes?
- There’s a lot of potential issues that can be addressed that can cause that inflammation that has unknown etiology to what incited it causing that urgency, frequency, urinary bother

**Does every city have an Amy? What’s the frequency of surgeons of that skill?**

- Northwestern is probably in the top five urology institutions in the US
- There are probably 10 HoLEP surgeons that are on her par
- Yes, it requires a lot of skill to do the small prostate, but also handling these very, very large prostates in individuals who are incredibly frail and older who were told, “*You’re too old for a surgery*”
- Ted was on call a couple weeks ago and there was a 95-year-old gentleman who came in from another major hospital who was having bleeding from their prostate that was more than one unit of blood a day transfusion
  - He was told there wasn’t anything they could do for him because he was too old and too frail
  - It was a Saturday, Ted connects him to Amy; it was a hospital to hospital transfer
  - She does the HoLEP
  - He had a 450 g prostate and she takes out 400 g of tissue
  - They left the guy with a catheter because they just weren’t sure, and he went home

***Talented surgeons like Amy (which are hard to find) really can transform people’s quality of life***

## Prostatitis due to infection: symptoms, pathogenesis, and treatment [46:45]

- For many men, prostatitis is their first brush with pelvic floor discomfort and a symptom associated with the prostate
- Peter remembers having a brush with this about six years ago, and Ted helped him out
  - “*This is part of the problem when you start to play doctor to yourself, so all of a sudden I start having some discomfort when I’m peeing and I do all the usual stuff, I check was it an infection? None of the above.*”
  - He didn’t have a [urinary tract infection](https://en.wikipedia.org/wiki/Urinary_tract_infection) or an [STD](https://en.wikipedia.org/wiki/Sexually_transmitted_infection) or anything like that
  - It wasn’t unbearable pain, just uncomfortable to void
    - He’s heard people describe certain infections feel like razor blades are coming out
- Peter talked to Ted and he started asking a bunch of questions
  - Have you been traveling a lot?
  - Are you a little constipated?
- One thing led to another and the diagnosis in Ted’s mind (playing doctor over the phone) was thinking this is prostatic inflammation

**Walk us through the pathology of prostatic inflammation**

> “*I wish I could tell you in the next five minutes what the pathology was because the short answers we do not know*.”‒ Ted Schaeffer

- We call this constellation of symptoms [chronic pelvic pain syndrome](https://en.wikipedia.org/wiki/Chronic_prostatitis/chronic_pelvic_pain_syndrome)
  - This is a bucket we put a lot of different things into
- You can have pelvic pain and discomfort if you have a large prostate and it’s obstructing your urinary tract
  - That one we talked about, you can manage that pretty easily
- Other things that can cause pelvic pain and discomfort:
- 1 – Acute bacterial infection (that’s a classic)
  - Ted feels good if he finds this because he knows we have a solution
  - The inflammation and discomfort and pain that results after that may take much, much longer to resolve
- 2 – You can have a non-bacterial inflammation that could be viral
  - Although no one’s really ever isolated specific viruses
- 3 – There’s pelvic floor dysfunction that is outside of the urinary tract
  - That pelvic floor function could be in the anus and in the rectum, having to do with dysfunctional voiding or elimination in the rectum
  - It could have to do with dysfunctional elimination between the bladder and the urinary or urethral sphincter
    - Those are common in kids

**Anatomically, we failed to mention the proximity of the rectum to the prostate**

- They are adjacent to each other
- The rectum and the prostate effectively developed from the [cloaca](https://en.wikipedia.org/wiki/Cloaca)
  - Cloaca is the embryonic sewer
  - That’s where all the waste in a fetus would go into and out of
  - And then it’s divided anteriorly and posteriorly into the urogenital sinus and then what becomes to anus and the rectum
- The rectum and prostate are intimately associated with each other and there is actually a lot of **cross innervation**
  - So if you have inflammation in the gut, in the rectum, and in the anus, you can result in irritation and inflammation in the prostate
- There also can be translocation of bacteria between the rectum and the prostate
  - So when they were talking about Peter’s individual situation, Ted said, “*Are you traveling? Are you constipated?*”
    - We think that that can result in maybe some increased transmural translocation of bacteria
- To this day, Peter still doesn’t really know what the problem was
  - When he travels, he goes to great lengths to make sure his bowel habits are regular, but it’s still difficult
  - He’s out of routine
  - He doesn’t know if it’s dehydration or what it is
  - It might also be parasympathetic sympathetic balance
  - He thinks there are lots of reasons
  - ***Most people he talks to as patients will say they get constipated when they travel a lot***

**Constipation, urinary retention, and difficulty voiding**

- Physical pressure on the prostate can make it much more difficult
- The classic presentation for a man with urinary retention is post-procedural
  - If you have a hip or a knee [surgery], **anesthesia** can shut your gut down and you can get constipated
  - Some of the different cough and cold medications can do the same thing
- In general, Ted thinks of travel constipation from changes in your bowel function
  - And even if you doesn’t make you go into urinary retention, it affects how you urinate and so forth
- Ted’s [father](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=13362) wrote a very important [paper](https://www.nejm.org/doi/full/10.1056/NEJMoa0803240) in the *New England Journal of Medicine* 15 years ago that Peter refers back to quite a bit
  - Peter was following the algorithm of that paper when he got back to New York when this was going on circa 2016, and he went through that diagnostic procedure

**Walk us through that diagnostic procedure**

- Peter feels when you’re dealing with something so complicated, it is important to get some diagnostic specificity because the treatments do differ
- In his case, once the treatment was identified, the fix was on

*If you’re concerned that someone has an infection in their prostate or seminal vesicles, the workup is to distinguish that from a bladder infection*

- The bladder is right next to the prostate
- This workup was described by the Stanford urologist [Tom Stamey](https://med.stanford.edu/news/all-news/2015/09/thomas-stamey-expert-on-prostate-cancer-and-psa-test-dies-at-87.html)
- You would capture urine as it comes out the urethra in different phases, and therefore you could track where that urine came from
  - It’s a **four-step process**:
  - 1 – Capture urine immediately after you start voiding
    - That would then capture and wash out any bacteria within the urethra, the long channel between the bladder and the tip of your penis
    - That first few cc of urine gives you a sense for is there any bacteria growing in the urethra (urethritis)
  - 2 – Wait a couple seconds and then capture urine midstream coming out from the bladder, and then you could then determine if there an infection in the bladder
  - 3 – Then what you would do is you would tell the patient to pause, you would do then a rectal examination and you would press on the prostate, pressing on the prostate vigorously so that you could effectively in some ways replicate what happens in an orgasm (that is where the smooth muscle squeezes the fluid out of the prostate)
    - When you do a vigorous rectal exam, you’re trying to push the fluid into the urethra
    - You can sometimes just actually capture that prostatic secretion by itself (we call that [EPS or expressed prostatic secretion](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2720443/#:~:text=EPS%20represents%20the%20fluid%20being,across%20all%20prostatic%20disease%20states.))
    - You can send that off for an evaluation for any bacteria in it
    - You don’t always get that fluid out
  - 4 – Send the patient to the washroom and have them capture urine coming out of the urethra, at the beginning of the flow, right after a vigorous exam
    - That will capture the fluid that was in the prostate.
    - And then you can just complete the void
- What you can do is look for where there are cultures showing any bacteria
- For example: cultures are clean in the initial void (VB 1) and clean in VB 2 (that would be the bladder), but having bacteria in the EPS (the prostatic fluid itself) or VB 3
  - That would tell you that there’s an infection within the prostate
- The **key thing** is that standard labs will call an infection if they see bacteria that’s growing more than 105 (more than 10,000+) bacteria in that sample
  - If you’re worried about having an infection in the prostate, you would need to lower that threshold to 102-103 (100-1000 bacteria), because that should be completely sterile
- The prostate is a hostile environment for bacteria to persist
  - It’s very acidic
  - It’s thought that it can be somehow a barrier to developing infection in a man in the bladder
    - Remember, pre-modern medicine, if you as a man would develop an infection in your bladder, it’s life-threatening
    - If it goes into the kidneys or it goes into the blood, you get urosepsis and you often will die
- People think, “*What’s the prostate for?*”
  - It’s used for reproduction, but it’s also may be used as a natural barrier to keep bacteria from going all the way into the bladder, to help prevent UTIs

**Do women have any such thing? Women are much more susceptible to UTIs because of their short urethra.**

- An infection in the bladder of a woman can also track to the kidney
- But in general, there’s limited stasis of urine in a woman’s bladder because the urethra is so short and you can evacuate or empty the bladder so effectively in a woman
- Whereas in a man, as you get older and your prostate gets larger; if you retain urine that’s infected with bacteria

**Peter’s takeaway:** ***so all things equal, women are less likely to develop urosepsis kidney infections based on the fact that it’s easier for them to evacuate the bladder if there’s an infection***

- Ted points out, “*It’s by decade. So young men, they’re the least likely to get any urinary tract infection period. But as men get older, their chances of developing a urinary tract infection equal that of a woman.*”
- You could argue because of the urinary stasis that infection in a man is much more life-threatening early on in their disease course than a woman

***The probability that you would develop an infection in the kidneys is probably the same between a man and a woman***

- But remember, if you have a man who’s older who has a bladder infection, that can go into the blood, but it also can go into the prostate, and as we were alluding to in our discussion of working up somebody for a prostatic infection, clearing an infection in the prostate is very, very difficult and very challenging

***So you have to do the specific Stamey four glass test, you have to rule out any infection in the prostate***

- It’s rare to pick up infection in the prostate, but it’s possible
- The other place that you want to look for an infection is in the [seminal vesicles](https://en.wikipedia.org/wiki/Seminal_vesicles) (shown below)
  - You see this in very unusual cases

![](https://peterattiamd.com/wp-content/uploads/2023/09/f2-tedschaeffer2.png)

**Figure 2.** Image credit: [Cleveland Clinic](https://my.clevelandclinic.org/health/body/22433-seminal-vesicle)

- The seminal vesicles produce about 50% of semen

***You can get a bacterial infection in your seminal vesicles, and unless you’re looking for that infection, you’ll never clear that person because it’s kind of very isolated from any continuity of the urinary tract***

- It can result in pelvic pain, can result in persistent issues of infection
- Ted does that very specific test to rule out infections in the urinary tract that are related to the prostate or the seminal vesicles

***The poor-man’s version of that test is to send off a semen sample for bacterial testing***

- If you have an infection in the prostate or in the seminal vesicles or the genital tract, then we know how to treat that with antibiotics
- Antibiotics will address the infection and most of the time address the pain and discomfort associated with those symptoms

## Prostatitis caused by other factors besides infection [58:45]

**The issue is that there are many people who have discomfort that is not associated with bacterial infection**

- It could be viral
- It could be just inflammation
- When Ted sees somebody who is complaining of prostatic pain, he always wants to feel the muscle in the pelvic floor
  - When you do a rectal exam and you feel kind of straight posterior, you’re feeling just the prostate
  - If you just move your finger laterally, you’re in the pelvic muscle
    - Oftentimes you won’t feel much of anything
    - But in a man who has pelvic pain syndrome, it feels like a guitar string
    - You’ll feel bands of muscle
    - Think about when you tweak your traps, you have those bands of muscle you can feel with your hands
    - But the good thing about that is you can go get a massage and you can work it out
    - That same thing happens in the pelvic floor muscles
- When Ted is dealing with the patient who has pelvic pain, he tries to treat their symptoms based on where the pain is coming from
  - If it’s prostatic, he uses things like [alpha-blockers](https://en.wikipedia.org/wiki/Alpha_blocker), potentially [Cialis](https://en.wikipedia.org/wiki/Tadalafil) is another one to treat symptoms that are associated with that discomfort
  - If they have a lot of tightness in their pelvic floor, he sends them for [myofascial release](https://en.wikipedia.org/wiki/Myofascial_release) (it’s transrectal, myofascial release; it sounds barbaric)
    - Peter has seen this change a guy’s life, and the same for women
    - Ted agrees

**The patient’s that are difficult are the ones that we don’t know what’s causing the pain**

- It can be related to food too
  - He will have patients keep a diary of what they are eating
  - The female equivalent of this would be [interstitial cystitis](https://en.wikipedia.org/wiki/Interstitial_cystitis) where you’d say, “*What foods trigger it for you?*”
    - Because it can be triggered and irritate the bladder, and that’s causing the pelvic discomfort
- It’s important to take a thorough history
- The NIH has a very good [online questionnaire](https://www.usrf.org/questionnaires/Prostatitis_NIH_Symptom_Index.html) to help you kind of tease out where the symptoms are coming from

*Is it common in young men?*

- No, but it’s more common if a young man’s seeing a urologist to have that than [BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia) or something
- Obviously the most common thing for a young man to come see us for is [ED](https://en.wikipedia.org/wiki/Erectile_dysfunction)

***This kind of pain definitely something that we can address***

- Peter has seen a number of men who go through the diagnostic workup, there is not infectious agent whatsoever, but a simple prostatic massage (such as one on an ailing muscle) alleviates the problem
  - It’s a very anti-inflammatory process
  - We don’t know why it works for some people

**The other classic thing Ted hears about is, “*****I have chronic prostatitis*****”**

- That’s a very specific diagnosis ‒  it’s a bacterial infection that you can’t clear
- It’s almost impossible to have that
- These patients will take an antibiotic for 30-60 days and it makes them feel better
- This scares Ted a lot because anything like a potent antibiotic has a lot of downstream consequences
  - You’ve got to be careful of changing your gut flora
- These patients say as soon as they feel this discomfort they take a [Cipro](https://en.wikipedia.org/wiki/Ciprofloxacin), [Levaquin](https://en.wikipedia.org/wiki/Levofloxacin), or [Bactrim](https://en.wikipedia.org/wiki/Trimethoprim/sulfamethoxazole), and they feel better
  - Because these are powerful antimicrobial agents, these antibiotics are profoundly anti-inflammatory too
  - ***For these patients, Ted will transition them out of popping these month-long runs of antibiotics and get them on an anti-inflammatory***

**Is there a particular NSAID that you find works better?**

*Does Celebrex even work? (Peter finds it’s not as potent)*

- Ted sticks with the more potent ones
- He likes [naproxen](https://en.wikipedia.org/wiki/Naproxen)
  - It’s [BID dosing](https://www.rxlist.com/bid_on_prescription/definition.htm)
  - It can be a little hard on your stomach
- Ibuprofen is incredibly potent, but at taking the right dose three times or four times a day can be hard

*What about* [*meloxicam*](https://en.wikipedia.org/wiki/Meloxicam)*?*

- Ted hasn’t used it, but theoretically, it should work
- People have different sensitivities or efficacies with these different ones
- Ted starts with naproxen, and he’ll use that with a little bit of an anxiolytic because some anxiolytics relax a lot of your muscles and help relax the pelvic floor muscles (rectum, bladder, prostate, and pelvic floor muscles)

***Ted doesn’t like people taking long-term antibiotics for prostatitis unless they have a difficult infection to clear***

- Peter recently sent a friend to Ted who was in this boat
  - He believed he had bacterial prostatitis once a year, and that triggered Peter’s thinking that maybe that’s not what this is, and maybe we need to go down a different path
- There are individuals who we can’t put our finger on what’s causing the symptoms
- [Ted’s father [Anthony Schaeffer]](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=13362) still has an active research lab, he’s the world’s authority on prostatitis and pelvic pain
  - He’s still at Northwestern, and he has an ongoing clinical trial for people
- He believes that a lot of the discomfort and pain has to do with [mast cell](https://en.wikipedia.org/wiki/Mast_cell) dysfunction
- He has a [clinical trial](https://www.feinberg.northwestern.edu/sites/urology/research/clinical-trials.html#) [[Anthony Schaeffer is the co-investigator](https://www.scholars.northwestern.edu/en/projects/mast-cells-in-male-pelvic-pain-and-lower-urinary-tract-dysfunctio-5) with [Praveen Thumbikat](https://www.feinberg.northwestern.edu/sites/urology/faculty/profile.html?xid=17389)] where he’ll actually see individuals, he’ll do an [EPS](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2720443/#:~:text=EPS%20represents%20the%20fluid%20being,across%20all%20prostatic%20disease%20states.), he’ll look at their voided fluid, he’ll assess them for different markers for **mast cells**
  - If they’re high, he’ll put them on mast cell inhibitors in a clinical trial and it’s quite effective

***There is hope for these individuals because there is a subset of men who we see that, and it has a huge impact on their quality of life***

## How to minimize risk of urosepsis in patients with Alzheimer’s disease [1:05:00]

- Peter notes that we’ve talked at length now about two of the big problems associated with the prostate, and while both can be an enormous threat to quality of life, they’re not a threat to the length of life

**A question Peter gets asked a lot is, “*****How does somebody actually die from Alzheimer’s disease?*****”**

- They usually don’t die from Alzheimer’s disease, they usually die from something else that is brought on by the Alzheimer’s disease
- One of the classic cases you see is [urosepsis](https://en.wikipedia.org/wiki/Pyelonephritis) (tragic)
- This is because a man with Alzheimer’s disease may have a catheter in him because he is unable to video on his own, and that dramatically increases his risk for infection
  - He is also less responsive to the signs of an infection
  - He’s not attentive to the fact that it’s burning when he pees and because of his age and his immunologic reserve, what starts out as a urinary tract infection on day one is a lethal case of urosepsis on day four

> **“***This is kind of one of the grim reapers of older men*”‒ Peter Attia

- Ted points out, “*As men age, and particularly if you have concomitant other significant medical issues, your frailty goes way up. And so any little insult to your body can do it. And obviously classic things are aspiration pneumonia.*”
  - [Cellulitis](https://www.cdc.gov/groupastrep/diseases-public/cellulitis.html) is another cause, if you’re not moving around
- There is a lack of awareness, and it requires a very astute caregiving family (or cohort of individuals) to notice subtle changes
- Obviously if you can pick up an infection early, then it doesn’t necessarily have to spread and it won’t be so symptomatic

**If you could speak to someone listening to this who’s caring for an elderly patient (male or female) who is in the throes of dementia, what can a caregiver do on this particular front?**

*Is there anything they can do to minimize the risk of a kidney infection or a bladder infection turned into systemic sepsis?*

- Good hygiene is key
- Monitor the individual’s voiding history
- We would prefer for people to void on their own (and many people can)
- Many times people have catheters in place for convenience of the caregiver, and so if you can keep hardware out of somebody, that’s obviously very effective
- If the individual can’t void and they’re having trouble with that, then intermittent catheterization is what we endorse and recommend (where you just place a catheter temporarily)
  - This poses less of a risk than constant catheterization
    - It’s a little counterintuitive to think about doing a cath on somebody three times a day for 60 seconds each, but if it’s done with perfectly sterile technique, that’s better than having a catheter 27/7
    - We know if you leave a catheter in place by 48 hours, the bacteria has crawled up the tubing and into the bladder
  - Minimizing the dwell time of a foreign body is better

***Intermittent catheterization is a profound way to reduce the changes that you develop any urosepsis***

- It is possible to have bacteria in the urine using intermittent catheterization
  - But that doesn’t mean that you failed with that technique because if you’re continuously emptying the bladder, you can never get overgrowth
    - And never get enough urine with bacteria in it to pose a problem

***Ted often sees*** [***dehydration***](https://peterattiamd.com/hydration-in-the-elderly/) ***in individuals as they’re aging, and dehydration is a key underappreciated contributor to all these medical conditions***

- Peter adds that older people lose their relationship between thirst and hydration status
- People with Alzheimer’s forget to drink, and so if you have bacteria in the urine, but you keep the concentration at 10 bacteria per mL ‒ that’s not going to be a problem
  - But if you’re dehydrated and you have more concentrated urine, and there’s the same amount of bacteria with less urine, you could have significant issues

> *“As we age and you have these comorbidities, a good caregiver is critical. Oftentimes in medicine, they’re paid the least. It’s really an important role that you have*.”‒ Ted Schaeffer

**Tips:**

- Get these individuals up and walking around
- Remind them to drink
- If they have a catheter, you want that changed every month or three weeks
  - A good urology practice has a whole team of nurses that do this for their cohort of patients, and they’ll get an idea of the cadence for that individual
- Try to stay away from using a catheter if at all possible

## Prostate cancer: 5-alpha reductase inhibitors, how androgens factor into pathogenesis, and more [1:10:00]

- Peter notes, “*Prostate cancer is the second leading cause of cancer death for men behind only lung cancer, and so in order it goes for men, it’s lung, prostate, colon, pancreas. The thing that stands out to me is we have great tools of detection for prostate cancer. Based on that, I guess it’s a little surprising to me that it is still the second leading cause of cancer death in men.*”
- He hopes to get a better sense of what an individual can do to flip the odds in their favor
- You’ve probably heard Peter say he doesn’t think anybody should ever die of colon cancer because we have remarkable tools of detection and a very predictable pathogenesis
  - Where disease develops from a polyp to an adenoma to a carcinoma, and we can detect the presence of the adenoma because it is outside the body effectively
- When Ted first met Peter, that would be the [Halstedian](https://en.wikipedia.org/wiki/William_Stewart_Halsted#Achievements) theory for how cancer would spread
  - Stepwise from a localized noninvasive, to an invasive tumor, to a regionally advanced, and then metastatic lesion
  - The colon follows that algorithm pretty well
  - There are always outliers; there are also sessile polyps that are difficult to detect
- Ted explains, “*Prostate cancers follow a similar Halstedian theory of spread as opposed to* [*Bernard Fisher*](https://en.wikipedia.org/wiki/Bernard_Fisher_(scientist)#Chairman_of_NSABP) *and the Fisherian spread.*”
  - Which is the breast cancer model

***There were on average 250,000-260,000 new diagnoses of prostate cancer last year, and a lot will follow the Halstedian model of spread***

- If you model it:
  - 250,000-260,000 new diagnoses
  - 34,000 deaths
  - **Conclusion**: on average, we are picking up cancers but ***the ratio of cancers diagnosed to cancer death is pretty favorable***
    - Much better than other cancers
    - About 95% of people diagnosed with adenocarcinoma of the pancreas will die within five years

***What gets Ted up in the morning and excited is to understand and identify what it is about the individuals who develop prostate cancer that is localized and doesn’t have a lethal potential, and how do we better attack those subset of individuals that will ultimately die from their prostate cancer***

- Lots of progress has been made since Ted was last on the podcast [4 years]

**Explain how androgens work, where are androgen receptors, and how do they factor into the pathogenesis of prostate cancer?**

- It’s a good exercise to understand where the prostate actually comes from
  - It comes from the urogenital sinus
- The prostate is a sexually dimorphic organ, and in the response to androgens, around week 10 or 11 in a developing human fetus, there’s a surge of testosterone from the gonad
  - And that surge of testosterone results in the development of this ductal network
  - It’s an exocrine gland and it develops out of this structure

*How big a surge in testosterone?*

- Peter knows it’s more significant than a little boy is born with, they’re born with very low testosterone
- Boys have three peaks of testosterone lots of testosterone in utero, lots at birth, and then at puberty
  - Puberty is the highest
- It’s not just [testosterone](https://en.wikipedia.org/wiki/Testosterone) levels that matter, it’s also the level of intracellular [dihydrotestosterone](https://en.wikipedia.org/wiki/Dihydrotestosterone)
- In the [urogenital sinus](https://en.wikipedia.org/wiki/Urogenital_sinus), the [mesenchyme](https://en.wikipedia.org/wiki/Mesenchyme), those are the things that eventually turn into muscle and connective tissue
  - They contain [androgen receptors](https://en.wikipedia.org/wiki/Androgen_receptor) that then send a paracrine signal to the epithelium
- Peter wants to back up and make sure people understand this ‒ testosterone is a complicated molecule derived from [cholesterol](https://en.wikipedia.org/wiki/Cholesterol)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f3-tedschaeffer2.png)

**Figure 3. The structure of testosterone and cholesterol**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Testosterone)

**Explain what an androgen receptor is and where it sits**

- The androgen receptor is a very fluid molecule that basically sits in the cytosol of a cell (outside the nucleus)
- The androgen receptor is a [transcription factor](https://en.wikipedia.org/wiki/Transcription_factor), so it turns on a variety of different genes within a cell
  - **Ted explains it like this to patients**: think about in your house, if you have a circuit breaker and you turn on the circuit breaker and every light in the house goes on
    - That’s what a transcription factor does
- The androgen receptor is a transcription factor and it needs to be in the nucleus of the cell to flip those switches
  - It sits in the cytoplasm, and it needs to translocate to the nucleus and then bind to the DNA of our cells
    - It only does that once testosterone or dihydrotestosterone binds to it in the cytoplasm
    - When it’s bound, it has a conformational change that permits it to enter the nucleus
- Dihydrotestosterone (DHT) has a much stronger, higher affinity for the androgen receptor
  - It’s about 10x more potent, so 1 molecule of DHT is the equivalent of 10 molecules of testosterone
- That conversion of testosterone to dihydrotestosterone does not occur anywhere in your body
- BTW, women have an equal distribution of androgen receptors, as do men, but they don’t typically have androgens around
  - Peter adds that a woman will probably have 5% of the androgens (testosterone) that a man will have
  - Theoretically at birth or in utero, women have an equal distribution of androgen receptors
- [5𝛼-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase) is tissue specific ‒ men have it predominantly in their hair follicles and prostatic tissue
- If you have the same amount of testosterone floating around in your blood, it will have one effect (when it’s not converted to DHT)

***But if that same testosterone molecule hits a hair follicle or the prostate, it’s converted into a very potent androgen (DHT) through 5𝛼-reductase, and that can then have a much more potent effect in terms of the subsequent effect of the androgen receptor***

- Peter clarifies, “*If a male has a normal testosterone level, but he’s taking a 5𝛼-reductase inhibitor, which lowers the conversion of testosterone to DHT, young guys will take this all the time to prevent hair loss. (These are the most common drugs that are used to prevent hair loss)… So, it seems to me like he’s short-changing his androgen receptor potential. He’s short-changing the ability to experience testosterone.*”
  - Yes, Ted agrees
  - Part of the story, that we didn’t finish here is that DHT in the hair will damage the follicle (it’s leading to baldness)

***By taking a 5𝛼-reductase inhibitor, you end up with is less intraprostatic DHT, and actually more intraprostatic T because you can’t convert it***

- You normally would convert T to DHT, and that’s true in the hair follicle also

## Post-finasteride syndrome [1:18:15]

**There’s significant pathology associated with taking finasteride**

- We used to think that it was predominantly in those main structures: follicles of your hair, prostate, etc
- But now we know it actually has a profound potential impact centrally in your nerve system, and it can affect your sex drive and your sex performance

**Until a few months ago, Peter had never heard of** [**post-finasteride syndrome**](https://en.wikipedia.org/wiki/Finasteride#Post-finasteride_syndrome)

- The brand name of finasteride is [Proscar](https://en.wikipedia.org/wiki/Finasteride), and it’s taken 5 mg per day
- It has a cousin, [dutasteride (brand name Avodart)](https://en.wikipedia.org/wiki/Dutasteride), and that’s taken 0.5 mg per day
  - It’s theoretically more potent because it blocks 5𝛼-reductase I and II
- The 1 mg per day of finasteride is called **Propecia** (the branded version), and is used for hair loss
- The first thing Peter remembers Ted telling him about was it’s a little bit of a scam that these drugs are taken daily because their [half-life](https://en.wikipedia.org/wiki/Biological_half-life) is quite long
  - If you took a single finasteride 5 mg dose, it would  hang around in your system for a week or two
  - It’s a generic drug, so it costs nothing
  - Ted hasn’t figured out why it was reformulated at the 1 mg dose in the new patent/ new indication, as you could probably just take a single 5 mg of finasteride once a week and that would be the same as taking 1 mg every day
  - The pharmacologic half-life is 5-6 hours but the biologic half-life is 10-14 days
    - This means the drug is cleared quickly from the [blood](https://perfecthairhealth.com/how-long-does-finasteride-stay-in-the-bloodstream/) but remains in the [tissue](https://academic.oup.com/jcem/article/89/5/2179/2844345) for much longer
- The long half-life is the least of the problems associated with finasteride

**Describe what post-finasteride syndrome is**

- It’s a variety of symptoms that men will complain of after taking either the [BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia)-dosing or the hair loss-dosing of these medications

***Decreased sex drive, impotence, and inability to ejaculate, and there’s a lot of other associated findings with it like depression, change in your affect***

**What do you think is the approximate frequency of this post-finasteride syndrome?**

- There is debate on this
- Some people would say 5%, some people would say 15%
- About ***1 in 10 guys*** will have appreciable issues with it, and it’s not just young men, it’s older men too
- This is why ***Ted never uses finasteride*** in his practice
  - In part because the efficacy is limited in terms of managing lower urinary tract symptoms
  - And because the side effects from it, this post-finasteride syndrome are real
- The duration of these symptoms can be highly variable
  - Some people will stop the medication and they’ll have resolution within a couple of weeks once the drug washes out
  - But there are people that Ted knows who have it permanently
- Peter recalls caser reports of the guy who goes to see the hair doctor, they put him  on finasteride, he experiences all of these symptoms
  - They’re horrible and because he’s 25-30, he stops taking the drug and the symptoms never come back
  - Ted agrees, these instances are rare but they are real and associated with this drug

**Is there any sense of what predicts susceptibility to this?**

- Let’s assume the frequency of post-finasteride syndrome is 1 in 10 and we want to avoid it at all costs because we never know if it’s reversible
- It’s a post hoc diagnosis
- Ted hasn’t seen a high quality study that took 100 or 500 men and really tried to evaluate what it was that would predict that association

***Ted doesn’t recommend a 5𝛼-reductase inhibitor for use in any man, BPH or otherwise***

- If you’re taking it for **hair loss**, there’s a lot of really effective therapies that you can do
  - Hair transplant works very well, and Ted knows people who are very satisfied with it
- Ted experienced hair loss at a very young age, so he know what that feels like
- Understanding the spectrum of alternatives is really important because when young guys go to these pop-up shop clinics, they don’t understand the long-term effects

***In addition to post-finasteride syndrome, finasteride halves your PSA value if you take it for 1-2 or 2-3 years***

- After five years, it reduces your PSA number by about 2.5x
- Ted is concerned about this as a prostate cancer biologist and doctor that treats people with prostate cancer
- If you stop the medication, your PSA will rise

***The biggest issue is not whether or not it suppresses your PSA, it’s the lack of awareness that it does this amongst patients and providers***

- If you’re going to some men’s health clinic for your finasteride for your hair loss, you may not mention it to your internist
  - And usually when you start this for hair loss, you maintain it for life
- The classic case Ted sees every other week is a guy whose PSA is rising on finasteride
  - This is a warning sign that there is a cancer, likely an aggressive prostate cancer, and guys and physicians aren’t aware of it

**Hypothetical scenario of PSA changes that are a warning sign for prostate cancer**

- A man begins taking finasteride at age 25 when his PSA is 0.5
- 20 years later his PSA goes between 0.5 to 1, to 2, to 4
  - That’s 4 years where his PSA is doubling
  - This indicates a really bad problem before it’s anywhere near being on the radar of the patient or their internist
- It’s Ted’s opinion that you’ve got to be very, very careful with these medications, particularly taking them that long
- Peter adds, “*This says nothing about the other issue, which is not having DHT probably isn’t a good thing if you’re in the business of taking advantage of your androgen receptors. You’re taking away the most potent androgen in the body, and androgens do really good things.*”
  - Ted agrees
    - The extreme examples are individuals with no testosterone
    - This is something that is induced in men with advanced prostate cancer
  - ***Having testosterone around is just critical for everything from metabolic health to structural health… really for everything (mood and a whole bunch of other things)***

## The relationship between testosterone and DHT and the development of prostate cancer over a man’s lifetime [1:26:30]

- When a man is in his 20’s (18-30), he has the most testosterone and presumably DHT in his body, and we don’t see these guys getting prostate cancer
- Similarly, we don’t see women getting breast cancer when their estrogen is at their highest either
  - We know that story is more complicated
- When you have men with metastatic prostate cancer or untreatable prostate cancer, hormone deprivation therapy is a core treatment

**How do we reconcile those two observations?**

- There’s a time dependent covariable here
- There’s lots of things that testosterone does at a cellular level
  - ***Testosterone impacts repair of damage to the DNA***
  - All these different things that people don’t fully appreciate
- When you go through your surge of testosterone, if your puberty peak is age 18 or age 25, you begin to reset the functional code
  - So, you’re born with your DNA, but it’s not really for the most part, what’s in your DNA that matters
  - It’s the [epigenetic changes](https://en.wikipedia.org/wiki/Epigenetics) that result in the RNA transcription that really is the most important thing
  - You begin to mark and see differences in terms of the epigenetics of different genes within an androgen responsive organ that then sets the stage for your potential risk for developing prostate cancer
- There is a correlation between testosterone and subsequent future diagnosis of prostate cancer, but it’s just one of the many factors that plays a role
- So, if you don’t have any testosterone, you’re not going to get prostate cancer because you won’t have a prostate (that’s the obvious one)
- Ted thinks there’s a correlation between T and being a healthy male
  - And part of being a healthy male is a potential risk for developing prostate cancer

**Peter remembers during his residency a paper came out that found men with lower testosterone were at risk for higher grade prostate cancers**

- The teleologic explanation was: if you are developing prostate cancer in the presence of low androgens, you have cancer that’s very sensitive and therefore is probably much higher grade

*Is that still kind of the thinking, or has the thinking evolved significantly?*

**Transcriptome analysis of prostate cancers can differentiate luminal-like prostate cancers from basal-like prostate cancers, which relates to its dependance on androgens and ability to metastasize**

- Ted just published a [paper](https://onlinelibrary.wiley.com/doi/10.1002/cac2.12467) on this where they looked at 100,000 prostate cancer [transcriptomes](https://en.wikipedia.org/wiki/Transcriptome)
  - They did this in partnership with a company called [Veracyte](https://www.veracyte.com/) (originally it was called Decipher)
  - Ted did this with the founder [Elai Davicioni](https://it.linkedin.com/in/elai-davicioni-7b82a727)
  - They looked at their database of now 140,000+ prostate cancer transcriptomes
- In this study, they asked a simple question: if you take prostate cancers and you do AI-based hierarchical clustering just looking for patterns, do you see different types of cancer (not grade or stage) from the perspective of the transcriptome of prostate cancer?
  - The answer is yes, **you see two general themes**
- You see (1) luminal-like prostate cancers and (2) basal-like prostate cancers
  - And within that subclassification of luminal/ basal, there are effectively aggressive luminals and aggressive basals, and then less aggressive ones

**Back to the role of androgens**

- If you look back at embryonic development, at what happens in the prostate in a mouse (or rat) when you begin to take away testosterone and give it back?
  - You see the prostate grows in response to testosterone and estrogens
- But if you castrate a mouse (all of the luminal cells) post maturity, you develop a normal prostate
- If you castrate a mouse or a rat with a prostate, it will regress
- Analogy: think about it like a plant in the middle of a drought, it looks dead, but there’s roots that are still alive
  - Those roots that are still alive in the prostate are predominantly basal cells
- If you give that prostate back its growth fuel (testosterone or DHT), then it will regrow a new prostate
  - The basal cells can begin to repopulate
  - You’ll also get a proliferation of these luminal cells that will then form the big, bulky, meaty prostate that we think about (the BPH portion of the prostate)
- We believe in prostate cancer that luminal cells (and the luminal cells in development) are exquisitely sensitive to testosterone/ androgens
- The basal cells are the ones that form more basal-like tumors, which are very, **very aggressive**
  - These are the cells that survive the drought, the cells that survive in the absence of effectively any testosterone at all

**When Ted looks at somebody with prostate cancer, he looks at:**

- Their grade
- Their stage
- But also at the genomics of their tumor ‒ what’s the biology of their tumor?
  - Because they may have a big bulky, luminal, proliferating luminal tumor, but he knows (A) it’s exquisitely sensitive to testosterone suppression, which is something that he has in my back pocket, and (B) it’s less likely to start spreading to other parts of the body

**Why is that? Because it’s on the basal side?**

***No, if it’s a luminal-type tumor, it’s more dependent on that testosterone-rich microenvironment with the DHT around***

- It doesn’t do as well theoretically living in the bone marrow when it metastasizes to the bone or the lymph nodes
- Peter finds this counterintuitive
  - On the on hand, it’s a more aggressive, locally bulky tumor
  - On the other hand, it’s less likely to survive metastatic spread
- The distribution of a luminal differentiated tumor in a localized state is about 40%

***If you take tumors that are metastatic, less than 10% are luminal differentiated***

- They just don’t have the capacity to survive and spread to other parts of the body

***Whereas a basal tumor, which is by nature able to survive in the absence of testosterone and/or uses alternate growth pathways to testosterone because it’s not dependent on it, those tumors are more capable of spreading to other parts of the body***

**Peter’s takeaway‒** This is a great tragedy. It means that the prostate cancers that are most likely to kill you, which by definition are the ones that spread, are also the most capable of thriving in a low testosterone environment.

- That’s right, and therefore these are the least hurt by androgen deprivation
- Ted has been working on this thesis for a decade with [Elai](https://it.linkedin.com/in/elai-davicioni-7b82a727)
  - They [published](https://onlinelibrary.wiley.com/doi/10.1002/cac2.12467) this year, and lots of other interesting studies are coming out that support this idea
- This is why Ted is very comfortable with a patient who has a low testosterone (either during the process of being diagnosed with their cancer or in their recovery phase) being on testosterone supplementation
  - Because he knows that if they were to develop a recurrence of their cancer, it’s most likely a **luminal type**, and we can exquisitely modulate that tumor with testosterones
- It’s a big step in a different direction

***It really helps to understand the biology of a localized cancer that has the capacity to spread (lethal potential); understanding the molecular underpinnings is key to knowing how to attack it; that’s precision medicine***

## How genetic analysis of a tumor can indicate the aggressiveness of cancer [1:35:15]

**Analysis of 100,000 transcriptomes from prostate tumors has given an insane amount of insight**

- Once a patient has a diagnosis, you can get the [transcriptome](https://en.wikipedia.org/wiki/Transcriptome) information
  - It’s provided to the providers, it’s not commercially available
  - It’s not provided commercially because you have to be cautious about how you interpret that data and what you advise the patient
    - Until we have more information from clinical trials about what a particular molecular phenotype means for (A) how you treat their new diagnosed, localized [cancer], or (B) potentially if they have a recurrent disease, how you should better treat it
    - Those trials are now in process or are just being built based on some of this work

**Does that mean that someone listening to this who has a biopsy of their prostate, their physician will get this information back but won’t necessarily know how to interpret it?**

- If a patient gets a biopsy of their tumor and they have **genomic testing** with [Decipher Veracyte](https://www.veracyte.com/diagnostics/prostate-cancer) (which Ted doesn’t have any conflicts [of interest] with), they will then get a simple **readout of how aggressive is their tumor**
  - It’s a molecular [Gleason score](https://en.wikipedia.org/wiki/Gleason_grading_system)
  - In addition to measuring those 21 different genes that consist of the Decipher score, they capture the whole transcript over that tumor, and you can get access to what they call the **grid report**, which gives you this whole deep dive into what’s the biology and nature and phenotype of that particular tumor
    - Ted looks at this to then say, “*Okay, this patient on paper perhaps has an X or a Y or Z, but the molecular phenotype of the tumor is favorable or it’s not favorable. I’m going to alter what I recommend to the patient based on that.*”
    - It’s experimental use only, so to speak
    - It’s the future of precision medicine
- Ted’s [paper](https://onlinelibrary.wiley.com/doi/10.1002/cac2.12467) and many, many others provide the platform through which all clinical trials in prostate cancer are now reliant on
- A **Decipher score** is used as a entry criteria, as a predictor for intensification or deintensification of therapy, and is part of almost all clinical trials going through the NIH right now

## Pathogenesis and genetic risk factors of prostate cancer, and the use of PSA to screen for cancer [1:37:45]

- Ted talked earlier about the transition zone and the peripheral zone, the orange analogy
  - The orange peel is the *peripheral zone,* and the pulp of the orange is a *transitional zone* of the prostate

**Do most prostate cancers develop in the peripheral zone?**

- Yes

**Would a man who is undergoing prostate tissue removal for BPH have a lower risk of prostate cancer because they have just shed 80% of their prostate?**

- It doesn’t necessarily change their risk for developing prostate cancers in the future
- However, it changes your ability to monitor them for the development of prostate cancer
  - The PSA blood tests have often been criticized, but it’s a very powerful tool, and it just depends on how you use that blood test to identify people at risk for potentially having prostate cancer

> “*There are a few things that annoy me more than people who harp on how bad the PSA is, which to me means no, it’s how bad you are at using it. The PSA is a remarkable test.*”‒ Peter Attia

**Nuances of using PSA to screen for prostate cancer**

- The issue arises from this overlap in the PSA test because it’s not prostate cancer specific, it’s prostate specific
- When Ted’s partner, Amy Krambeck, does a [HoLEP](https://www.nm.org/conditions-and-care-areas/urology/benign-prostatic-hyperplasia/treatments#tabs_accord) and takes out 90% of your prostate, that reduces 90% of the PSA producing cells
  - The PSA should be below 1, but it makes the test way more sensitive for Ted to follow for a future potential risk of developing prostate cancer

***The specificity of the tool changes based on how much prostate tissue you have***

- The PSA test is actually exquisitely sensitive in young men to their future risk for developing prostate cancer because they have such limited amounts of transition zone tissue and the bulk of their prostate is just peripheral zone

**Why is it that the cells in the peripheral zone are susceptible to becoming neoplastic, as opposed to the cells in the transitional zone?**

- We don’t know
- It’s unfortunate because as the name implies, it’s in the periphery, and **what’s just outside of the prostate** is the high price real estate of: the nerves for erection, the nerves for urinary continence and the muscles for urinary continence
  - That has a big impact on how we manage prostate cancer
  - That’s what results in a lot of the potential side effects that occur

***But in general, in young men, PSA is a very potent way for us to initially screen someone for their prostate cancer risk***

**Good PSA numbers**

- The median PSA for a 40 year old is 0.5
- The median PSA for a 50 year old is 1

***If your number’s over those age adjusted medians, you need to just take action***

- Do you need to have a prostatectomy? No
- If your numbers are over those you should consider annual (or every other year) intensive follow-up
- It doesn’t mean you have prostate cancer, but being over the median means you have a much higher risk in the next 20-30 years of developing prostate cancer

**The problem discussed earlier: a lot of guys are on 5𝛼-reductase inhibitors, and now their PSA numbers become very difficult to interpret**

- Yes, they become difficult to interpret and follow
- For these men, their PSA is going to be very, very low, and you may miss an early blip

**Tangent on finasteride and dutasteride use in veterans**

- There’s a great [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6503564/) published out of the group at UCSD looking at finasteride and dutasteride use in veterans
- They asked the question: *is use of dutasteride and finasteride associated with more prostate cancer lethalities?*
  - It’s hotly debated about whether or not the drugs actually induce more aggressive cancers
- If you just take that as a more public health issue, the answer was glaringly yes ‒ there was a huge increased risk of death from prostate cancer in men on finasteride, dutasteride
- Why? Because of neglect
  - You don’t know your numbers are rising
  - Your internist has no idea that your PSA of 4.0 isn’t really 4.0, it’s 10
    - It’s because you’ve been on the meds for 10 years

**Peter’s takeaway ‒** ***we certainly don’t know if 5*****𝛼*****-reductase inhibition impacts prostate cancer biology, but it impedes detection***

**How many cases of prostate cancer are associated with** [**germline genes**](https://en.wikipedia.org/wiki/Germline_mutation) **that we know are drivers, for example, the equivalent of a** ***BRCA*** **mutation in breast cancer?**

- It is very limited
- There are a class of proteins that fix homologous recombination defects, and those [HDR](https://en.wikipedia.org/wiki/Homology_directed_repair) classes of molecules include [BRCA1 and BRCA2](https://en.wikipedia.org/wiki/BRCA_mutation)
  - The actual protein complex that fixes double strand DNA breaks is really, really big, and there’s lots of different genes that fit within that protein complex that fixes a double strand break
    - That’s what BRCA1 and BRCA2 do classically
- The most potent of the different genes in that grouping of HDR molecules for men is *BRCA2*

***Stats: about 1% or less of the general population have a*** [***BRCA2***](https://en.wikipedia.org/wiki/BRCA2) ***deficiency (BRCA1/ BRCA2 deficiency)***

- Those men are at **increased risk** for developing breast cancer and prostate cancer
- And if they develop prostate cancer, it’s a **more aggressive disease course** and you have to be very, very careful

***But it’s very rare, <2% of localized prostate cancer diagnosis are attributable to a germline genetic alteration***

- There are [somatic mutations](https://en.wikipedia.org/wiki/Somatic_mutation) in those same pathways seen within the tumor that are attributed and related to cancer aggressiveness and progression of cancer
- Classically, the way Ted thinks about prostate cancer in general terms is:
  - You can have localized prostate cancers, and these are these lower grade lesions on average, localized prostate cancers with lethal potential
    - An **LCLP** is a **L**ocalized **C**ancer with **L**ethal **P**otential
- The general genetic trait associated with that transition from localized to LCLP has something to do with the [PTEN](https://en.wikipedia.org/wiki/PTEN_(gene)) AKT [pathway](https://en.wikipedia.org/wiki/PI3K/AKT/mTOR_pathway)
  - That doesn’t mean you have a lethal tumor if you have PTEN loss
  - Instead it suggests that lots of other mischief can go on within the tumor
- We know that loss of [*p53*](https://en.wikipedia.org/wiki/P53) is associated with lethal prostate cancer (lethal cancer in general)
- Amplification of [*myc*](https://en.wikipedia.org/wiki/Myc) is another one

**Is** [***KRAS***](https://en.wikipedia.org/wiki/KRAS) **another gene associated with lethal potential?**

- Less so, but yes *myc*, *p53*, and *KRAS* are classic marker of lethal cancers

## Non-genetic risk factors for prostate cancer [1:45:45]

- Peter remembers from his training that African-American men are at high risk

**Why are African-American men at high risk for prostate cancer?**

- No one knows
- There’s a great [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8148035/) published by [Chris Haiman](https://keck.usc.edu/faculty-search/christopher-haiman/) at USC, and they looked at genomic risk through [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) in individuals who did or did not develop prostate cancer
  - They looked at a ton of individuals, around 235,000 guys

**How did they know what SNPs to look at?**

- There’s been lots of work in single nucleotide polymorphisms (SNPs) and risk for prostate cancer, and then this paper was a refreshed look at saying: how many SNPs are actually out there associated with risk of developing prostate cancer?
  - It’s somewhere around 250 or 260
- They developed a **genomic risk score** based on how many SNPs you had and your likelihood or probability of developing prostate cancer
- What they showed was that although there’s no difference between SNP profiles in men of African ancestry, there was an enrichment for that same group of SNPs in black men and an enrichment in men who were diagnosed with prostate cancer at a young age
- They could look genomically where their ancestry was and Caucasians or non-black men
- So, why is it that there’s an enrichment of these different portfolio of SNPs in black men, and why is there an enrichment in the younger men?

***We don’t know, but it doesn’t appear as though the tumors are profoundly different from a genomic perspective***

- Ted had a series of grants to look at somatic alterations in prostate tumors between black and white men with lethal tumors
- They found a difference in the cell cycle gene pathway, but these are single percentile differences

**So what exactly is driving the development of more prostate cancers in black men than white men?**

- At this point it is thought to be environmental
  - So what is their exposure to epigenetic changes?
  - What is their exposure to smoking?
  - In general, in urban populations of black individuals, there’s more smoking
    - It correlates with the food deserts
    - All these different kinds of epigenetic factors

**Peter’s takeaway ‒** ***so it may not actually be hard-wired… that’s great news***

- Ted explains, “*People would bundle that under this umbrella of social determinants of health, but you can actually begin to really begin to connect those two ends of what are the social determinants and then what is the impact on the SNPs and the epigenetic changes that occur.*”
- A great future project would be to look at these exposures: high smoking, high pollution, poor foods, epigenetic changes that occur when men have a surge in testosterone in their 20s
  - That last one begins to hard-wire that person’s cells for future development of prostate cancer

> “*I spent a decade looking for the smoking gun, the heritable germline change. There are some out there, but they’re not very big guns.*”‒ Ted Schaeffer

- What he found is not big enough to be associated with that change
- But this [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8148035/) by Chris and his team really begins to provide more insight
- It gives you a sense of why are there different subpopulations of individuals that have different risks
- It’s likely just enrichments for these single nucleotide polymorphism (SNP) changes
  - If you had the highest let’s say decile or quartile of SNPs, you had about a fivefold increased risk of developing prostate cancer compared to the average man
    - Which is the same fold increase as if you’re *BRCA2* deficient

***So having a poor genomic risk score is just as potent as having deficiency in BRCA2, which we know is not good***

**What is the penetrance of BRCA2 and BRCA1 for prostate cancer?**

- Lifetime risk is somewhere on the order of 60-70%
- Ted would definitely do intensive screening for them, but it’s not a guarantee
- Women are highly penetrant and at a very  young age, that is not true for men on average
- Peter notes that it’s not unreasonable for a woman to undergo a prophylactic mastectomy if she has a deficient copy of the *BRCA* gene

*Are any men considering prophylactic prostatectomy?*

- Not at this point
- The difference is we have very powerful screening tools
- This gets back to Halsted versus Fisher
- Screening tools work just as well in individuals who are *BRCA* deficient

***We have much better tools to detect prostate cancer with a blood test***

- So their tumors may be more aggressive when they’re diagnosed, but we have very powerful tools to (A) identify them early and (B) monitor them once they’re picked up
  - So it doesn’t necessarily change that paradigm, which is different for breast because you have to wait until you have a visible lesion
    - A visible lesion on mammogram is 40 or 50 million cells
    - Peter would guess it’s closer to a billion cells (a centimeter)
    - Either way, it’s a ton of cells
- Peter is hopeful that with breast cancer, we’re going to get more resolution on detection soon with liquid biopsies and cell-free DNA [discussed further in episodes [#267](https://peterattiamd.com/keithflaherty2/) and [#213](https://peterattiamd.com/maxdiehn/)]
  - This is not essential for prostate cancer because they have a very good biomarker

**Is there an inverse relationship between the frequency of ejaculation and the development of prostate cancer?**

- Yeah, there’s an [epidemiologic study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5040619/) that shows that men who were ejaculating more than 20 times a month had a lower risk of developing prostate cancer
- Ted has never thought about encouraging increased ejaculation as a preventative strategy
  - We have no further insight than that study
  - But it’s a win-win. Right?

**Other risk factors besides ancestry**

- Ancestry is a huge risk factor for prostate cancer, bigger than many other cancers
  - West African ancestry is the most significant risk factor
  - Ashkenazi Jewish individuals have a much higher chance of harboring founder mutations in *BRCA1* and *BRCA2*
  - When Ted takes a family history, he always says, “*What’s your personal history of prostate cancer?*”
    - If you have a first-degree relative with prostate cancer: father, uncle, or brother
    - Your grandfather is *not* considered in the family history
    - The number of individuals and the age that they were diagnosed increases your fold-risk of being diagnosed significantly [shown in the table below]
    - Those at high risk should have intensive monitoring

![](https://peterattiamd.com/wp-content/uploads/2023/09/f4-tedschaeffer2.png)

**Figure 4. Risk of developing prostate cancer is increased when first-degree relatives have been diagnosed.** Image credit: [*Dr. Patrick Walsh’s Guide to Surviving Prostate Cancer*](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1538726866/ref=sr_1_4?crid=E70A0SEF22CV&keywords=Dr.+Patrick+Walsh%E2%80%99s+Guide+to+Surviving+Prostate+Cancer&qid=1695059493&sprefix=dr.+patrick+walsh+s+guide+to+surviving+prostate+cancer%2Caps%2C237&sr=8-4)

- **Smoking** is associated with the development of more aggressive prostate cancer
  - Smoking is classically linked with lung cancer, bladder cancer, and urothelial carcinoma
  - Not necessarily more prostate cancer, but a younger age of onset and more aggressive cancer

**What’s the youngest patient you’ve ever seen with prostate cancer?**

- 34
- Ted will never forget that gentleman; he’s still alive now
- Ted has subsequently diagnosed young men with prostate cancer and then later treated their fathers
  - So they had their cancer before their father, which is also mind-boggling

**Tell me about prostate cancer in this 34-year old. Was there some freak gene?**

- This was early in Ted’s career at Hopkins, back when they lacked an understanding of the genetic risks
  - He would love to go back and pull his tumor and sequence the whole thing
- This man wanted to get a $250 discount on his health insurance for the year, so he got routine screening through his work, and they picked up a PSA that was like 10, and he was age 34
  - And it wasn’t from an infection
- The median age of diagnosis for prostate cancer is 68

***Early prostate cancer is at age 50, and this would be a criteria for doing genetic screening***

**Does type 2 diabetes and metabolic disease also increase the risk of prostate cancer**

- They do
  - Also the aggressiveness and likelihood and probability of recurrence
- As it does breast cancer, endometrial cancer, and a number of cancers

**Other things have never been follow supported with any decent follow-up studies (either increased or decreased risk of developing prostate cancer)**

- Different products in the skin of grapes, broccoli, tomato

## Deep dive into PSA as a screening tool: what is PSA, definition of terms, and how to interpret results [1:56:30]

**Explain what PSA is, where is comes from, and how we use it**

- [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen) is a protein
- It exists to aid in the liquefaction of semen, so it’s produced by the prostate
  - It exists there to liquify the semen to help in the process of fertilization
- If one were to measure PSA in semen, it would be very, very high
  - If you looked at PSA in the semen, it would be, I don’t know, 100,000 ng/mL of PSA in semen
- It should *not* exist in the blood
  - But a certain percentage of PSA made in prostatic epithelial cells leaks into the bloodstream
- When we do a PSA blood test, we’re measuring the PSA that has leaked into the bloodstream from a prostatic epithelial cell
- Now, most of the PSA that leaks into the bloodstream is bound to other proteins (mostly [antichymotrypsin](https://en.wikipedia.org/wiki/Alpha_1-antichymotrypsin))
  - It can bind to a family of 3, 4, or 5 different prostatic proteins
- Ted points out, “*Proteins don’t come out finished. They grow into their final state, and they grow by shrinking. They get things snipped off of them as they’re maturing and going through that process.*”
- PSA gets snipped into smaller and smaller forms as it evolves in the  normal development of its exocrine function
- If you have a benign prostatic epithelial cell, a lot of its PSA will be fully processed and ready to go in the ejaculate, and if it leaks into the bloodstream, it can float around freely
  - You can measure it in an assay, and it’s what we call **free PSA**

***Fully processed PSA can float around in the bloodstream freely (that’s free PSA), while a lot of the unprocessed or incompletely processed PSA is bound to protein (antichymotrypsin is the most common one and what is considered when doing a measurement)***

- **Total PSA** is mostly measuring bound PSA and some free PSA
- A **ratio** is used to help discriminate against PSA that’s in the bloodstream that may have leaked from a cancer cell or may have leaked from a benign epithelial cell
- There are other siblings of PSA that are also produced in prostatic epithelial cells in response to androgens

- They can also leak into the bloodstream, and we use those in some advanced PSA-based blood testing

***But in general, when we are measuring PSA, we are measuring the amount of PSA that’s leaked from a prosthetic epithelial cell into the bloodstream***

**We can refine the PSA value by saying how much is there and how much is free**

- If we have **high amounts of free PSA** (30% for example), then we can have good reassurance that most of the PSA in the blood that you’re detecting is from benign cells

***When most of the PSA that you have in your blood is bound, very limited amounts of free PSA, that’s a strong marker that there’s something going on (cancer cells are leaking PSA into the bloodstream)***

- Other byproducts, other types of free PSA or other sibling molecules to PSA are called HK3 (human kallikrein 3), human kallikrein 2
  - These are part of more advanced PSA tests like the [4Kscore](https://4kscore.com/what-is-the-4kscore/) or the [Prostate Health Index (phi)](https://www.beckmancoulter.com/products/immunoassay/phi)
    - These are both mathematical equations that predict probability of aggressive cancers, but they’re built off of looking at not just the PSA itself, but the PSA and how much other types of processed PSA exist as well

**Does the amount of free PSA we would want to see to be assured of a benign nature of PSA vary by age and absolute PSA level?**

- Yes, it does
- So we begin to use the free PSAs and the free PSA ratios and all those things when PSAs have crossed over a certain threshold

*If your PSA is 1, we can’t even get a lab to check the free PSA*

- That’s right because we know if you’re screening someone and your PSA is 1, then the probability you have a prostate cancer that’s lethal is incredibly low
- They don’t have the assay set up to check it
- Some labs will not do that secondary default testing unless it’s over 4, for example (or over 2.5)
- Ted’s lab is set up to do everything at levels as low as 2, but in general, the idea is if your PSA is below 2, the probability you have a lethal prostate cancer is less than one in a million (so we don’t have to worry about that individual)
- We really want to use the percent-free PSA to discriminate individuals who have elevated PSAs
  - To discriminate between elevated because of BPH and elevated because of a cancer
- Yes, as you get older, your prostate enlarges, and you can have a proportional rise in total PSA in your bloodstream just because your prostate is bigger and is leakier
  - But you can easily tease that out by looking at the percent-free PSA

***If the percent free PSA is over 18 to 20, then you can rest pretty well-assured that that’s likely not coming from some aggressive bulky tumor***

- As we talked about, metabolic syndrome causes your prostate in large part to grow just because of the androgen to estrogen ratio

**What about with prostatitis, when we see these huge spikes in PSA?**

- Everything goes up in those cases

*But does the free still remain disproportionately high?*

- Ted doesn’t use free PSA in people because he’s tracking it
- He’s literally looking for trends for coming back down to a new baseline

**Let’s talk about two other ways we use the PSA, the density and the velocity. How do those work?**

- For many men, as you age, your prostate gets bigger, and your PSA can concordantly rise
- What we look at is the ratio of the PSA value to the prostate volume, and that is called **PSA density**
- Ted tells patients “*We want a PSA to be about 10% of the volume of the prostate (or less) to be in a safe range, so if your PSA is 4, and your prostate is 40 grams (which is about average size for a 60, 65-year-old guy), that’s a PSA density of 0.1. We know that that is correlated with a low risk of having an aggressive prostate cancer.*”
- When Ted is looking at someone’s case, he want to know what their PSA density is
- If the **PSA density in a young man is >0.1**, he gets a little worried
- In an average age person, if the **PSA density is >0.15**, he wants to do additional testing

***PSA density predicts the likelihood that you’d ever be diagnosed with prostate cancer; it predicts the aggressiveness of a cancer if your diagnosed with it, and it actually predicts your outcome if you have a prostate cancer ‒ the*** ***higher your PSA density, the more significant your disease will be***

> “*The higher your PSA density, the more significant your disease will be*”‒ Ted Schaeffer

- The **faster that your PSA density rises** is a canary in the coal mine to say you need additional evaluation
  - It doesn’t mean that you have prostate cancer
  - Ted has had patients whose PSA went from 1 to 5, and it came back down because they had a flare-up or inflammation in their prostate that made their PSA go up
    - Oftentimes we don’t know why
- Whenever somebody comes to see him with an elevated PSA, the first thing he always does is recheck it because there can be a transient rise in the PSA
  - He always orders **advanced PSA-based testing** that involves looking at the percent-free PSA, and then other things like [-2 proPSA](https://pubmed.ncbi.nlm.nih.gov/15533620/#:~:text=Pro%20PSA%2C%20the%20precursor%20of,with%20prostate%20cancer%20(PCa).) for the [Prostate Health Index (phi) test](https://www.beckmancoulter.com/products/immunoassay/phi) or the [4Kscore](https://4kscore.com/what-is-the-4kscore/) (which basically looks at different kallikreins and their ratios)
- Peter and Ted discussed these test in great detail on the [first podcast](https://peterattiamd.com/tedschaeffer/), so they won’t re-explain them here

***It surprises Peter that the official screening guidelines for prostate cancer don’t make any recommendation on the use of PSA testing other than something benign like, “Every patient should discuss this with their physician,” which is a real cop-out of what we should be doing***

- Ted points out that the American Cancer Society, the American Urology Society, and the National Comprehensive Cancer Network are a little more progressive
  - They suggest that you should talk about the risks and the benefits of screening
  - They skirted around the idea of how do you properly screen for it and don’t get into details upfront
- If you’re reading the AUA guidelines or the American Cancer Society guidelines, you already have a leg up on the average internist because an average internist is just looking at general things they learned in med school or the US Preventative Services Task Force, which is too general and too vague
- Ted refers everybody to the [National Comprehensive Cancer Network’s Prostate Cancer Screening guideline](https://jnccn.org/view/journals/jnccn/21/3/article-p236.xml) that basically says that every man at age 45 should have a baseline PSA ***because changes over time are key***
  - Changes are critical, and you want to know where you are in relationship to the median
  - So a 45-year-old man’s median PSA is between 0.5 and 0.7
  - Understand your median PSA and then if your PSA is below 1, you can get rechecked in 2-4 years

**It doesn’t cost anything to do a PSA test. Why wouldn’t we do this every year?**

- The argument against it is that there can be natural variations
  - If you’re a smart physician, you’re going to pick up on that
  - For example: if it goes up from 0.7 to 1.5, then you’re going to recheck it and it’s still in a safe range

*Isn’t that all the more reason to do frequent testing if there’s natural variation because it also means that if you’re testing infrequently, you’re more likely in the presence of natural variation to miss what the actual trend is?*

**Peter’s thought experiment with colorectal cancer screening and PSA monitoring**

- Imagine you had a low-cost zero risk colonoscopy that you could do on somebody every month
- Would you eliminate colorectal cancer?
- Yes, there’d be no such thing as colorectal cancer
- The third leading cause of cancer death is gone if you have that
- Now, the reason we don’t do that is they’re not free, and they’re not risk-free
- Similarly imagine you had a continuous PSA monitor you could slap on somebody’s arm (just like we have a continuous glucose monitor), and you could, for free, measure their PSA over their lifetime
- Peter would argue there would be no such thing as lethal prostate cancer
  - Provided you had the AI engine and the physician to monitor this, you would know
  - Johnny rode his bike, Johnny had sex, Johnny had a prostate infection
  - You would very quickly be able to pick up signal from noise

***Ted doesn’t disagree; it’s just a matter of how frequent, and what is considered to be intensive PSA testing***

- Annual PSA testing is very intensive
- Trials of screening for prostate cancer with the PSA test every 2-4 years showed it reduced deaths by 20-25%
  - That’s the baseline
- Peter’s point is, “*We can do better… it’s still the second leading cause of cancer death.*”
- Ted adds, “*The real question is, were those men that ended up dying of their prostate cancer offered early screening or not? We don’t know that.*”
- Another question Peter has, “*Could you get that with* ***prostate density****?*”
  - This involves a little more an an investment to know the prostate size
  - You could have for the cost of less than a pack of gum, one blood measurement that tells your PSA, free PSA, and PSA density (that’s really powerful)
- The [4Kscore test](https://4kscore.com/what-is-the-4kscore/) costs $1000
  - You don’t need to do it if you know PSA, free PSA, and PSA density (which is very inexpensive)
- The PSA density you can get off an ultrasound

**People would argue that percent-free PSA gives you some strong correlation between the size**

- Yes, Ted agrees
- Peter is pushing back because he sees prostate cancer similar to colorectal cancer ‒ with the existing technology, there is no reason for people to be dying of these cancers
  - Unlike pancreatic cancer where he doesn’t see a clear step on the horizon for elimination
    - Or breast cancer in women
- Ted points out, “*The deaths from prostate cancer with PSA screening have plummeted*”
- But still, 35,000 men died last year
  - How many of them would have been saved with traditional screening?
- Ted is trying to defend the rule makes that made these rules that he was not involved with
- This idea of baseline PSA testing at age 40 on a population health level, came about from bank serum [testing] out of Sweden
  - They were able to model that pretty well to understand the overall lifetime risk for developing or dying from prostate cancer
  - If your PSA at age 40 or 50 is below the median, then your lifetime risk is very low
  - This is the best they could come up with
- Ted is not disagreeing ‒ there’s no reason why you should not get your PSA tested at an early age, understand your baseline, and track it over time
  - This is what he does

**Patient’s need to take ownership of this**

- Peter and Ted have both witnessed this
- They have seen tragic cases where individuals who have no medical training (but who listen to this podcast, for example), have **diagnosed their own prostate cancer**
  - Even when their physicians have said, “*There’s nothing wrong with you based on advanced metrics such as PSA velocity and PSA density*.”
  - For Peter, that is infuriating and heartwarming at the same time.
- Ted adds, “*Many of those cases that we share are not like the subtle one in a thousand cases. They’re the ones that are obvious.*”
- The mindset of the individual patient also matters because there are some patients that don’t want to be proactive and progressive about how they monitor their health

***We have to balance knowing early with overreaction and overtreatment of a potential issue that may arise; there’s subtly to it ‒ it can be done well***

## MRI as a secondary screening tool and the prostate biopsy options [2:13:15]

- There are people on the other side of this discussion saying, “*PSA should never be done. It’s an awful test. It leads to a bunch of unnecessary misery for men because they’re getting unnecessary biopsies.*”
- Peter adds, “*Let’s squash that nonsense*”

- This might have been true 50 years ago, but in the year 2023, in the hands of a competent physician, that’s categorically untrue

**What can we do with an MRI to check if we suspect prostate cancer based on blood-based biomarkers?**

*What can we do to increase the probability that performing a biopsy will be worth it?*

- Order a MRI
- It is surprising and appalling to Ted that he sees second opinions in his office weekly where the patient has never had any pre-biopsy MRI
  - This is absurd
  - It is approved by all insurances (when the PSA level is >4)
    - In Ted’s practice they get [phi testing](https://www.beckmancoulter.com/products/immunoassay/phi), and it’s well calibrated over 2, so they order an MRI when the PSA is >2
  - MRI is covered by insurance at any PSA value

***MRI should be done before any biopsy***

- A [prospective randomized trial](https://pubmed.ncbi.nlm.nih.gov/34237810/) published in the *New England Journal of Medicine* used advanced PSA testing (Stockholm-3, a European-only test; they did not use 4K or phi)
  - They recommend doing an MRI when the advanced PSA test is abnormal
  - If the MRI has a suspicious lesion, perform a [biopsy](https://en.wikipedia.org/wiki/Prostate_biopsy) of the whole prostate (not just the lesion)
  - This reduced prostate biopsies by 50% and enhanced detection of clinically significant disease by 11%
  - Ted’s question to practitioners, “*Why are you not doing that?… it happens all the time*”
- Ted compares a typical 3T MRI to a high resolution Google map of the prostate
  - 3 Tesla, moderate power MRI, it doesn’t need any endorectal coil or any of that
- The **key parameters Ted looks at** (T2 images) are diffusion-weighted imaging and dynamic contrast enhancement
  - Those are the three components of a multiparametric MRI
- However, there are great radiologists, scientists (like [Raj](https://peterattiamd.com/rajpaulattariwala/)) who have shown that you don’t necessarily need the contrast, and that on average a T2 and the diffusion-weighted imaging are nearly as good
  - Not identical, but nearly as good at evaluating the prostate for any risky lesions
- MRI is not perfect, and it will miss small, low-grade prostate cancers

***MRI is a screening tool to help identify bulky, higher-grade, higher risk tumors***

**What to look for on the MRI report**

- You can look at your MRI report ‒ as part of the [21st Century Cures Act](https://www.fda.gov/regulatory-information/selected-amendments-fdc-act/21st-century-cures-act), every patient can look at their entire medical record
- A well done MRI should contain the size of the prostate
  - So you can get the PSA density
- It tells you if there’s a suspicious lesion and the degree of suspicion
  - This is called the [PI-RAD score (for Prostate Imaging RAD score)](https://radiopaedia.org/articles/prostate-imaging-reporting-and-data-system-pi-rads-1?lang=us)
    - It goes between 1 and 5
  - A RAD score of 1 and 2 are considered to be BPH lesions, and they’re not cancer
  - ***Worry about a RAD score of 3, 4, and 5***
    - Recommendation: biopsy that samples the spot and systematically (i.e. the peripheral zone in the area mapped around that lesion)

**How easy is it for you to see this and make this determination?**

*For example, when you look at the MRI and you see the lesion in presumably the peripheral zone, how easy is it for you to then go and actually physically do the biopsy and know that you’ve hit it as opposed to miss it?*

**There’s skill involved with doing an MRI-targeted biopsy**

- You use an ultrasound for guidance, and ultrasounds are not great
- Traditional standard ultrasounds, which are very high resolution, are not great at identifying lesions with the efficiency that a MRI is
  - Granted, they have time to think about and look at the images
- What Ted typically does is take the MRI images, and you either cognitively (with your brain) or with the computer assistance, overlay the suspicious area on the MRI with the real-time ultrasound
  - This is a [transrectal ultrasound](https://en.wikipedia.org/wiki/Transrectal_ultrasonography)
- You associate the suspicious area in the MRI with the transrectal ultrasound overlay
- Now, you can do the prostate biopsy one of two ways
- 1 – Pass the needle right alongside the ultrasound probe
  - That’s a transrectal biopsy
  - Then you can follow the track of the needle as it goes in alongside the ultrasound probe through the rectal mucosa into the prostate
  - It’s a very effective way to pick up prostate cancers
  - The [trial](https://pubmed.ncbi.nlm.nih.gov/34237810/) Ted talked about (the [Stockholm3 trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8096373/)), that’s the technique that they used
  - The limitation of doing that is you always introduce a small amount of rectal flora (bacteria from your rectum) into the prostate when the needle passes from the rectum into the prostate
    - To prep for the procedure, you’ll do an enema to decrease the volume of stool and bacteria in the rectum, and then you also will take an antibiotic
    - With modern antimicrobial prophylaxis, you can reduce infection after prostate biopsy to around, depending on the series, between 1-4%
    - Peter thinks this rate of infection is still pretty high
- 2 – The other approach that you can use is you can do a percutaneous biopsy
  - The ultrasound probes in the rectum
  - It’s looking up at the prostate, but the needle is inserted percutaneously through the skin in the space between the rectum and the scrotum
    - That’s usually around 4-5 centimeters of space
    - In that space, you can actually place a percutaneous needle guide, and then, from that, you can then actually target the biopsy
  - Peter asks, “*In other words, you’re not pulling the needle in and out each time?*”
    - You are
    - You have a short needle guide, a trocar, that goes through the skin so you can establish your trajectory, and then, from there, you can with ultrasound guidance put the needle exactly into the suspicious lesion
    - The trocar say in one time
- The original way that we did prostate biopsies was with the percutaneous approach
  - Back in the old days, over 100 years ago, if you had a suspicious bump on your prostate, you’d make an incision there and you’d cut it out
  - That was the original way that they did prostatectomies as well
- Downside to this second approach
  - You could systematically sample the prostate with that approach, and historically it has been very morbid because what they would do is they would place a two-millimeter grid along the perineum, and they would make between, let’s say, 20 and 30 individual pokes into the perineum and into the prostate
    - That was how you can deliver radioactive seeds or radioactive pellets
    - That approach was also used to do biopsies
  - That results in significant edema and swelling in the prostate and significant bleeding
  - And urinary retention rates after that approach were very high, 15, 20%
  - And it’s very painful; you can’t do it awake
- [Matt Allaway](https://urologyassociatesmd.com/urology-associates-dr.allaway.html) is a urologist in western Maryland, he’s a Schaeffer family friend and a very innovative guy, and he said, “*There has to be a better way than doing transrectal, bringing bacteria into the prostate, and there has to be a less painful way than doing this grid.*”
- Matt created a percutaneous approach where you can basically have a single trocar on the right, go through the skin, single trocar on the left, go through the skin, and you can navigate and sample all areas of the prostate
  - He’s been doing this for a decade now, and nod to him, he’s an entrepreneurial guy
  - He created a company ([Perineologic](https://perineologic.com/aboutpl-2/)) with his product, and it’s the gold standard for how you do that today

## Ted’s ongoing randomized trial comparing different methods of prostate biopsy [2:24:00]

**What percentage of your biopsies are done with the trocar versus transrectally?**

- Ted likes the transperineal approach
- But in a nod to just not adopting things with closed eyes and saying, “*It’s better*,” they are in the midst of completing a 16-institution, randomized trial that explores whether or not transperineal prostate biopsy is actually “better” than transrectal prostate biopsy
  - The primary endpoint is infection
    - Modern, contemporary infections with transrectal between 1-4%
  - Ted thinks their approach to prevent infections transrectally is very good, and they’re probably more in the 1% range
- When a transperineal approach is used (and [Matt Allaway](https://urologyassociatesmd.com/urology-associates-dr.allaway.html) has published a lot on this), you can do that without any antibiotics, and the infection rate is less than one in a thousand

**You’re presumably powered to show a difference in that direction?**

- That’s a lot
- The NCI reviewed their power calculations and said, “*This is the appropriate power to detect a difference*.”
- Ted is looking at the data right now, and he thinks they will end up having 0% infections in the transperineal prostate biopsies, but the question is: will we have done enough transrectals to statistically show a difference?

**Will there be secondary outcomes that look at detection?**

- Yes, the other endpoints for the study are pain and side effects
- The transperineal biopsy with the old grid approach was 15% retention
  - Meaning, a catheter and terrible
- When done properly, the side effects are minimal, and then we use a lot of medication to do our blocks

**Do you use a pudendal nerve block?**

- Yeah, we do a [pudendal nerve block](https://en.wikipedia.org/wiki/Pudendal_anesthesia), and we use [lidocaine](https://en.wikipedia.org/wiki/Lidocaine)
  - We use buffered lidocaine because lidocaine, when it comes out of the vial, is a pH of about five
    - They put a little bicarb in so you don’t have that pinching burn

**The transperineal prostate (TP) biopsy approach**

- There is some discomfort, but it’s tolerable
- It’s done in the office, awake
- The most important thing is cancer detection
- For this trial they have 16 centers
- There’s two other ongoing trials
  - Not to just say that we’re the only one
  - There’s a trial out of a limited number of centers out of Syracuse
    - They finished their study, and they’re looking to get their paper published
- And then there’s a large study in the UK
- But Ted’s group is going to be the first to publish a multicenter, large, prospective trial
- He thinks it will show that a TP biopsy is 0%
  - It will show that they’re slightly more uncomfortable
  - They haven’t fully analyzed the cancer detection yet but are excited to do that

## Determining when a biopsy is necessary, interpreting results, explaining Gleason score, and more [2:27:00]

**Who needs a prostate biopsy?**

- Somebody with abnormal blood testing first gets an **MRI** (it’s worth it)
- Those who *don’t* need a MRI: Men who have bilateral hip replacements (an MRI is effectively useless)
  - PSA density can be calculated with an ultrasound ‒ it’s fast and cheap
  - Men with a single hip replacement: a good radiologist can read their MRI effectively
  - If somebody has profound anxiety and they need general anesthesia for something, we’ll be nuanced about whether or not we think an MRI might make sense,
- ***If the MRI shows a suspicious lesion (a RADS 3, 4, 5), then you need a biopsy (independent of PSA density)***
- If your MRI shows no lesion, but a high PSA density:
  - In a young man (under 60) with a PSA density of more than 0.1 or 0.12
  - If you’re older (over 65 or 70) with a PSA density is 0.15
  - If you have a PSA density that’s below that threshold and you have a high PSA, low percent free PSA, you need a biopsy in Ted’s opinion

**Ted clarified how to proceed in men with a high PSA density by email:**

- His recommendations for him are to first recheck a PSA
  - A [prostate health index (phi)](https://www.beckmancoulter.com/products/immunoassay/phi) blood test provides improved specificity across a range of sensitivities for PSA
- If the phi blood test is in one of the 3 upper quartiles of risk for cancer (>27) on biopsy then he’ll recommend an MRI
- If the PHI test is in the lowest quartile of risk, he’ll consider deferring an MRI and/or a prostate biopsy
- If we order a multi-parametric MRI it will show us one of 3 things:
  - 1 – We may find a lesion in the prostate
    - And if it is scored between 3 and 5 on a 5 point RADS scale then Ted would recommend a biopsy (systematic and targeted sampling)
  - 2 – The MRI may show a small prostate in relation to the patient’s PSA (i.e. high PSA density)
    - This would be another indication to perform a prostate biopsy, even in the absence of a lesion
  - 3 – The MRI could show an enlarged prostate with no lesions (i.e. low PSA density, <0.10) at which point we could defer a prostate biopsy

**Outcome of prostate biopsies**

- Ted shared a slide with Peter a couple of months ago showing the outcome of biopsies by PI- RADs and PSA density ‒ it’s mind-boggling (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f5-tedschaeffer2.png)

**Figure 5. Outcome of prostate biopsies by PI-RADS and PSA density (PSAd)**. Image credit: [*European Urology Oncology*](https://pubmed.ncbi.nlm.nih.gov/32972896/)

- **PSA density** is a huge variable in terms of impacting probability of having cancer when you sample a suspicious lesion and/or the volume or bulk of aggressiveness of that particular lesion
  - RAD 3, 4, 5, you need a biopsy unless your PSA density is incredibly low (like 0.02)

***If you have a negative MRI and a high PSA density, we will often suggest a biopsy for you; while if you have a negative MRI and a low PSA density, we’ll say you’re likely can be monitored***

- Ted has the good fortune of having a partner who’s a brilliant guy, [Ashley Ross](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=47812)
- He analyzed and built a neural network real-time [predictor of absolute risk of having prostate cancer](https://rossnm1.shinyapps.io/MynMRIskCalculator/)
  - Using all the Northwestern Medicine patients who had had [phi](https://www.beckmancoulter.com/products/immunoassay/phi), MRI, and a biopsy
    - He looked at the outcomes of 1600-1700 MRI biopsy-linked cases
    - That number has now grown because it’s always learning
  - There’s some selection bias because we didn’t include people who didn’t have a biopsy
  - More specifically, he looked at prostate cancers that would require treatment
  - This is the [MyNM Risk Calculator](https://rossnm1.shinyapps.io/MynMRIskCalculator/)

> “*A lot of things have changed about how we think about these different cancers*”‒ Ted Schaeffer

- If you undergo a prostate biopsy, the answer is not just yes/no for cancer, there’s a lot of subtlety

**The Gleason score, pattern, and sum**

- Effectively, when a pathologist looks at a biopsy sample under the microscope, they’re describing the pattern of the cancer gland
- The prostate is an exocrine gland that produces semen
- There’s an architecture of the gland or the duct that a normal prostate has, so think about it like a branching tree
- When you develop a cancer, it’s an abnormally developed branch, and so the pathologist will score how abnormally developed that duct or that branch is, and that score is what ends up being the [Gleason score](https://en.wikipedia.org/wiki/Gleason_grading_system)
- If you have a cancer, the pathologist tells us what the individual branch looks like and what’s the pattern (that will be the **Gleason pattern**)
  - The patterns today are pattern 3, pattern 4, and pattern 5
- What we get in the **summation report** is, how much pattern 3 cancer a patient has, how much pattern 4 cancer, and how much pattern 5 cancer (that’s the **Gleason sum**, which is also referred to as the **Gleason score**)
  - Common ones would be 3+3=6 and that means that the pathologist only saw abnormal glandular patterns that were pattern 3

**Does the pathologist always report the highest scores that they see?**

- They’re reporting the most common pattern they see first, that’s the first number, and then the second most common pattern of cancer that they see is number two

*This is on both sides?*

- They report a score for every sample

**What are the typical number of samples that should be done in a decent biopsy?**

- It’s 12 systematics, so that’s right side, left side, an every-five-millimeters approach
- Plus, you sample the target
- The recommended number of samples for a target is usually three
  - So two is inadequate because the needle can bend, it can deflect
  - Sometimes, the needle is going in 20 centimeters beyond your hand, so you have to account for the deflection
  - You can track it, but the idea is you do it three times

**A prostate biopsy requires skill and training**

- There is a potential for “user error”
- There’s skill involved with doing the biopsy
- Ted and Ashley host a course where they provide training in how to do a proper, good transperineal prostate biopsy
- And there’s a skill involved by the pathologist when they report it out
- The recommendations are that you declare the Gleason score that’s the sum of the most common and the second most common cancer

**Presumably, some of these core samples come back with no cancer in them. Is that just reported as nothing?**

- The report no cancer
- Peter confirms, “*So it’s no cancer or at best three, three*”
- There are some rare variants that are not cancer and they’re not benign, and the pathologist will tell us about them
  - For example: prostatic atypia, but that’s uncommon especially in the era of MRI-targeted biopsies only (Ted wouldn’t worry about that too much)

**Are you only biopsying the peripheral zone?**

- They only biopsy where the lesion is, but most prostate cancers originate in the peripheral zone [back to the orange analogy, this would be in the orange peel]
- 12 systematic biopsy spots of the peripheral zone

**How thick is the peripheral zone?**

- It depends on the size of the prostate
- In a young man, it’s about 4-5 mm thick
- In a guy who has a big prostate, let’s say a 100 g prostate, the total peripheral zone volume does not change in a man over time
  - It gets compressed and thinned out (particularly if you have benign prostatic overgrowth, BPH)
    - That makes it harder to biopsy, and that’s where skill definitely plays a role
    - Peter notices that this is totally different from breast biopsies, thyroid biopsies, and things like that
- Back to the analogy of the orange: you’re having to biopsy the skin of the orange
  - If it’s a small orange, the skin is a certain thickness (which is relatively thin)
  - As the orange gets bigger, you have to preserve the same amount of skin so it gets thinner and thinner

**What do you do with these Gleason scores?**

- You look at the score and the distribution (or the volume of the score) to determine what the next steps for the patient are
  - Did the biopsy demonstrate prostate cancer?
  - If it demonstrated prostate cancer, is it the kind of prostate cancer that we need to treat right now or is it the kind of prostate cancer that we can safely follow or monitor over time?

**Hypothetical patient who has a lesion in the periphery with a Gleason score of 3**

- That’s a [Gleason score](https://en.wikipedia.org/wiki/Gleason_grading_system#Score_descriptions) of 3+3=6
- That’s the least aggressive type of prostate cancer when you look at it under the microscope
  - It has a very favorable prognosis
- For those prostate cancers, the thought process should be, “*I need to find some data that will convince me that this cancer requires treatment*,” because the recommendation on average is that these cancers can be monitored.

*Does that mean a 3+3 can’t spread or metastasis unless it progresses (to a 3+4 for example)?*

- That’s been explored with one major caveat, it’s been explored in surgical series
  - A huge bias is already introduced there
- If you look at a [radical prostatectomy series](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3421030/) in men who had Gleason 6 prostate cancer, there’s a large series by [John Epstein](https://www.hopkinsmedicine.org/profiles/details/jonathan-epstein) at Hopkins and also [Scott Eggener](https://biologicalsciences.uchicago.edu/faculty/scott-e-eggener-md) at University of Chicago, they both showed that there was no lymph node metastasis in men with Gleason 6 prostate cancer

**Peter’s takeaway ‒** ***any man who underwent a prostatectomy with a Gleason 3+3, had lymph node negative disease (and therefore presumably never went on to get metastatic disease), they never had a recurrence***

- At the time of their surgery, they never had a recurrence

**What’s the longitudinal data on those folks? Do we know that they’re free of disease?**

- They do very well
- The probability that they would die from prostate cancer is very, very low
- But they could have a local recurrence and that could result in subsequent problems, a need for additional secondary therapies.
- On average, we know that a Gleason 6 prostate cancer that is of low volume can be safely monitored
- These men had cancer surgery but we have now evolved to manage them
- A Gleason score 6 was the person that Ted operated on in Hopkins when he was in training
  - At that time they thought their cancer required immediate treatment

**This is very different from the colorectal cancer model**

- In colorectal cancer, you have an adenoma that’s polyp, and it comes out
- You have a carcinoma in situ, and it comes out

***The difference is: in the colorectal model, you can easily resect the adenomatous polyp with minimal or no side effects (done with a colonoscopy) ‒ it’s the morbidity of the prostatectomy***

> “*In the positive light of things, urologists have been very progressive and have been at the forefront of doing surveillance for tumors that have not yet established or declared that they have lethal potential*”‒ Ted Schaeffer

**For every 100 men who have a Gleason score of 3+3, how many want to have their prostate removed?**

- It’s rare that Ted will offer his surgical services to that person because sometimes the patients don’t fully understand what the potential ramifications for their side effects may be
  - Surgical risks
  - Radiation risks
- Ted will jump through a lot of hoops to look for reasons to reassure the patient, that they do not have an aggressive lethal cancer
  - And most of the time he is successful

*Example of a Gleason 6 prostate cancer*

- It’s low volume, between 1 and 4 cores (the most common Ted finds)
  - Between 1 and 4 samples of a systematic biopsy or a lesion targeted with MRI (considered 1 region)
- If you did 5 samples of an MRI suspicious RADS 4 lesion and all 5 samples came out Gleason 6, they would call that **one area of visible cancer**
- In those situations, generally this is somebody who can have their prostate cancer followed because, at this time, their tumor does not have the lethal potential to spread to lymph nodes or other parts of their body
  - And all kinds of therapy to treat it carry more morbidity than just leaving it in place and just monitoring it
- Peter is amazed, this is really precision medicine
  - Both as the patient and the physician, you have to have a very high degree of certainty that you didn’t miss a 4, that that wasn’t a 3+4
    - Patients often say this to Ted, and he tells them: we don’t just assume that you only had 6
    - With MRI-targeted biopsies, we know the chances of reclassification (change in the grade of the tumor at the time of prostatectomy) is low (about 10%)
- Historically when Ted and Peter were residents at Hopkins, a guy like the Gleason 6 would come in and he would go out with a Gleason 8 because there was no MRI and no MRI targeting

***The precision of the biopsy today is much better and, therefore, we can provide much better assurance to the patient about their Gleason grade***

- This doesn’t mean we assume the patient is going to be fine for the rest of their life
- We do active, intensive monitoring
  - PSA testing every six months
  - Closely following that PSA if it changes is helpful

**Do you repeat the MRI independent of a change in PSA in those patients once they’re a 3+3?**

- Yes
- If they had an MRI pre-biopsy, he will track them
- They have low-volume, low grade-prostate cancer
- If their PSA is stable at six months and their MRI is not concerning (everything looks good), then he will not repeat the biopsy and will recommend a confirmatory biopsy at one year
- Alternately, if you come in with low-grade prostate cancer like the patients we took care of 25 years ago at Hopkins and you have not had an MRI before your biopsy:
  - You immediately get an MRI because Ted wants to know what else is going on in there
  - He wants to know your density and he wants to know if there’s a lesion that was missed
- If on that MRI after your initial diagnosis has a RADS 4 or 5, you go to immediate biopsy
- If the MRI shows that you have a RADS 3, but let’s say a really, really high PSA density, again, Ted has concerns that the biopsy quality was poor, you go to immediate biopsy

> “*I endorse active surveillance. We do a lot of testing in these individual patients to make sure that, when we’re recommending surveillance, we’re recommending it for low-volume, low-grade prostate cancer.*”‒ Ted Schaeffer

**What percentage of these men will go the rest of their life without a prostatectomy?**

- All things equal, for a hundred patients who show up with suspicious-enough PSA that they get an MRI, see a RADS 3, 4, 5 and then they get a biopsy
- They now have a high degree of confidence they’re 3+3, meaning: they’re down the active surveillance pathway
- Ted can’t answer this
- There is data on 5, 10, and 15 years out
- If you have Gleason 6 prostate cancer and you enroll in active surveillance, the question is: what would be the trigger to recommend a treatment?
  - Effectively if your cancer is becoming more aggressive or your tumor becomes bulky

***The chances that you would have a more aggressive cancer develop in the first five years of surveillance is 12.5%***

- Peter asks, “*Is  that independent of whether you’re a RADS 3, 4, 5? We didn’t really talk about that.*”
  - It’s all comers
- This is [Ballentine Carter’s](https://www.hopkinsmedicine.org/news/articles/2019/11/the-h-ballentine-carter-md-prostate-research-and-innovation-fund) active surveillance [cohort](https://pubmed.ncbi.nlm.nih.gov/31918957/) from Johns Hopkins
  - He started in in 1996 and found there was a 12.5% chance that you’d have a change in the grade of your cancer
  - Overall, about 30-35% of men in the first 5 years of entering surveillance will go on to subsequently have definitive treatment
    - About 12.5% of guys, it’s because there’s a change in the grade, it becomes more aggressive looking and, the other guys, a variety of factors
    - They have increasing bulkiness of their tumor
    - They may develop concomitant urinary symptoms, and they want it all addressed at one time, etc.
- In general, Ted tells people there’s a 12.5% chance that you really need to do something because there’s a change in the grade
  - The risk is around 2- 3% risk annually, and that holds for 10 years
    - Meaning you add 2-3% per year after 5 years, so you’re up to 20-25
- The chance that a cancer progresses under surveillance to become incurable is 0.1% (1 in 1000 guys)
  - That’s Ballentine Carter’s [data](https://pubmed.ncbi.nlm.nih.gov/31918957/), and it’s changed how we treat and think about prostate cancer

## Implications of a Gleason score of 7 or higher [2:46:45]

- A pathologist will report what they see under the microscope
  - How much pattern 3 there is
  - How much pattern 4, pattern 5
- The Gleason score is a Gleason sum, so a Gleason 7 tells how much pattern and how much pattern 4 you have
  - It’s a blended scotch, not a single malt scotch
  - The blend is what matters the most
- The most important factor is how much pattern for you have
  - You can has as little as <5% pattern and as much a 99% pattern 4
  - If you have 100% pattern 4, you don’t have a Gleason 7, you have a Gleason 8
- The percentage of pattern 4 tells you two things:
- 1 – How good the pathologist who read it is
  - If he’s not telling the percent of pattern 4, then Ted doesn’t believe anything he’s reporting
- 2 – How much pattern 4 is there by both percentage and millimeters
  - Ted wants to know how long the tumor is
  - Remember the biopsy needle is 15 mm long
    - It’s a Tru-Cut biopsy needle around 18, 16 gauge
    - It’s not small, it’s a decent-sized sample
- If Ted has a patient with a single biopsy core that has 10% prostate cancer (that’s 1.5 mm of prostate cancer), and he has 5% pattern 4 ‒ he will send it off to [Veracyte](https://www.veracyte.com/diagnostics/prostate-cancer) for Decipher testing
  - Think about how little disease that is that has potential issues with lethality
  - 70% of the time, those small volume Gleason 7 tumors genomically are minimally aggressive
    - They behave more like a 6
- But the more millimeters of pattern 4 you have in your biopsy (in total), the more Ted would push to do treatment
- In the big picture, if they’re exclusively pattern 3 disease on average ‒ surveillance until proven otherwise
- If there is a smidge of pattern 4 (1-2 mm in total) ‒ maybe surveillance would work
  - Ted would have a very thorough detailed discussion, age, other issues in their life, determine their life expectancy, etc.
- If you’re 75 and you have 2 mm pattern 4, and you’re an average US male, maybe you don’t need to aggressively treat at that time
  - You need to aggressively monitor

> “*The more millimeters of pattern 4 you have, the more you’re going to be talking about active treatment. That’s the essence of how much prostate cancer management has changed in the last five years.*”‒ Ted Schaeffer

- A Gleason 7 that needs treatment is a perfect surgical candidate

**What about a Gleason 8**

- By definition, everything looked at is a 4

*Is there such a thing as a 3+5?*

- Yes, the science geeks have looked at it
- Effectively, it behaves like a 4+4=8
  - You treat them all the same
- You treat anything that’s an 8 or higher the same way.
- You can have a pattern 4+5 that would be a Gleason 9
- A Gleason 10 is pretty rare, but pretty bad
- If you’re pattern 4+3=7
  - So if you’re more than 50% pattern 4, you’re Gleason 4+3=7, we generally bundle those together with the 8s and the 9s

***If you have a lot of pattern 4, you need treatment***

- Then the discussion becomes whether or not single modality treatment is effective at treating and curing that individual man of their prostate cancer
  - This is on average a Gleason 8
- **Analogy** of a dandelion weed on your front lawn: ***the higher the Gleason score, the higher the probability that that person can have deep roots in their tumor extending outside the prostate, potentially, into the perirectal fat and beyond***
  - Additionally, you have a higher probability that that dandelion can go to seed and those seeds can float off to the lymph nodes

**When you have a higher-grade prostate cancer, you need to do a couple of different things in your workup**

- The one key thing is to do is a PET [PSMA scan](https://en.wikipedia.org/wiki/PSMA_scan)
  - PSMA is [prostate-specific membrane antigen](https://en.wikipedia.org/wiki/Glutamate_carboxypeptidase_II) whose expression is enriched in prostate cancer cells
  - It is the most sensitive and specific way to determine the extent of disease in a person with high-grade prostate cancer
  - It’s a PET scan, but instead of using [FDG](https://en.wikipedia.org/wiki/Fluorodeoxyglucose_(18F)) is uses a PSMA-specific radio ligand
    - Because prostate tumors are not FDG-avid

**It’s a functional metabolic test as well?**

- You stage somebody’s prostate cancer with a PSMA scan and then, from there, you develop a treatment plan
- Let’s say you have the prostate area only (or prostate plus lymph nodes), then you start thinking about your initial definitive therapy and potentially multimodal therapies to aggressively treat this aggressive lesion
  - This depends on the patient, their age, the bulk of their tumor, etc.
  - Ted will talk to these patients about radical prostatectomy as an option
- About 20-25% of Ted’s practice are patients that present with very bulky (potentially super bulky), aggressive lesions
  - In those individuals, he’ll have an up-front conversation that he doesn’t think that surgery alone will be effective at completely curing them of their prostate cancer
  - Vis-a-vis breast cancer treatment, colorectal cancer treatment, surgery is an important component of the initial therapy
  - He’ll do surgery and he’ll follow that up with a radiation-based approach
  - This is a patient where the PET scan doesn’t reveal any activity in the bone

## Metastasis of prostate cancer to different body locations, treatment options, staging, and considerations for patients’ quality of life and survival [2:53:30]

**Does prostate cancer metastasize to places outside of the bone besides the local invasion?**

- The lymph nodes are the most common place
- It follows a Halstedian trajectory most of the time

*But does it follow periaortic lymph nodes, the way testicular does?*

- Yeah

*Can it go into the lung?*

- It can be in the [thoracic cavity](https://en.wikipedia.org/wiki/Thoracic_cavity), yes
  - In the [mediastinum](https://en.wikipedia.org/wiki/Mediastinum), [supraclavicular](https://en.wikipedia.org/wiki/Supraclavicular_lymph_nodes), so yeah
- And then it will go to bone

**Why bone?**

- The microenvironment of the bone starts to mimic the microenvironment of the prostate

**Are there androgen receptors there?**

- No, but (1) the milieu and other growth factors that prostate cells may need to grow are there, number one
- And (2)  the bone marrow filters all your blood, so if you have circulating tumor cells, they’re going to be trapped
- Peter points out, “*Isn’t it interesting how few cancers do that besides breast and prostate? Think about colon cancer, pancreatic cancer, all of these other cancers.*”
- Ted suggests that advanced colon cancer is on that is trapped in their mesenteric blood spread, so you’re picking them up more regionally
  - It might just be that the colon is so concentrated towards the liver
  - The load of circulating tumor cells in the colon are filtered by the liver
  - But it’s not uncommon to see colon cancer go to the lung
- Prostate goes to the long and everywhere else, but the lymph node is the most common site of metastasis
  - Equivalent or second is bone

**From a staging perspective, do we use typical TNM staging for prostate cancer and if so, if it’s only in the lymph nodes, is it considered?**

- It’s considered stage 4
- For [AJCC](https://www.cancer.org/cancer/types/prostate-cancer/detection-diagnosis-staging/staging.html) that would be stage 4 at diagnosis if it’s in pelvic lymph nodes

*Is that considered M0 or M1?*

- We call that regional, but it’s stage 4
- It’s scary to have someone have stage 4, but prostate cancer in the pelvic lymph nodes is still curable
  - The devil is in the details

**Localized versus metastatic disease**

- The big differences in prostate cancer overall for the listers: 95-96% of prostate cancers are diagnosed with a localized
- Then there are people who have M1 disease and you can have M1a, M1b
  - It’s just the extent of the metastasis
- If you have lymph node-only disease, it’s rare, but if it’s picked up at the time of your initial diagnosis, it’s less curable than if you subsequently develop lymph node disease in your follow-up in survivorship monitoring

***In general, the vast majority of people who have lymph node only disease can live 10 years***

- The question: are they cured or not? That’s debatable
- We have this blood test that tells us exactly what’s going on, but they can live 10 years

**Treatment of metastatic prostate cancer [2:56:15]**

*Is the treatment prostatectomy plus radiation?*

- If you look at the data, there’s never been a randomized trial that explores which one’s better, but the best way to control lymph node disease is probably with radiation
- The role of surgery is to debulk the bulky tumor
- A lymph node metastasis is probably 40 or 50 million cells at a minimum, and so why not enable the radiation to be more effective by just debulking it?
- On average, radiation is more effective at controlling that local disease extent than surgery

**Side effects from radiation**

- Peter points out, “*The morbidity of radiation is not trivial, not just from the nausea and the sickness that can come from the treatment, but at least in the few cases I’ve seen of patients many years out, the rectal bleeding that normally gets better but not always right?*”
- The main side effects when you’re considering treatment with radiation would be urinary, sexual, and then kind of GI
- GI meaning rectal, rectal irritation, rectal bleeding
  - The rectal side effects that you’re describing are mostly historical because there are a lot of new technologies that really minimize that
  - For example, you can put in place hydrogel using the percutaneous approach we talked about for the biopsies
    - When the hydrogel warms up, it thickens
    - You put it in the plane between the prostate and the rectum and you elevate the prostate between 5-10 mm off the rectal wall and it gives the radiation oncologist this window to radiate the prostate effectively without damaging the rectum and it reduces side effects substantially
- The urinary side effects with radiation on average are a kind of burning the prostate, so you’re going to have these lower urinary tract symptoms that we talked about at the beginning of the podcast
  - They’re always intensified and amplified
  - They typically persist for the duration of the treatment plus about a two-month lag after that

**The other newest and most exciting way to deliver radiation is with MRI guidance**

- Historically you are placing fiducial little gold seeds and you line up the radiation and you just assume it was going to hit the prostate most of the time
- Then CT guided radiation was developed where you do a quick CT scan and for that day you line up the radiation fields with the CT scan, but it’s not real time
- Now there is MRI guided prostate radiation
  - We do MRI to see prostate cancers because it provides way more resolution (not CT scans), so you can theoretically resolve the prostate much better
  - And now there’s a single MRI guided linear accelerator that does intra fractional modifications of the dosage based on subtle movements
  - So if you take a deep breath or there’s a little rectal gas, it will capture it between the fractions of radiation delivered and alter the trajectory of the beam
    - This trial called the [MIRAGE study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9857817/) (it was done at UCLA), and they showed that there was almost zero rectal side effects from it
- The other really, really cool thing about radiation is that when you have an MRI and you have a big RADS lesion (let’s say you got a RADS 4, RADS 5), theoretically you can boost that lesion with tremendous precision if you have an MRI guided linear accelerator
  - Because it’s so visible on MRI

**The field of radiation oncology is evolving and they’re doing a lot of spectacular things**

- 1 – Time gating is huge
- 2 – Using and boosting the MRI visible lesions is huge from a cancer control perspective and also from a patient morbidity perspective
- However, the MRI linear accelerators are very expensive
  - Ted has one at Northwestern, but they’re not widely available
- You can do this [spaceOAR](https://www.spaceoar.com/about-spaceoar-hydrogel/how-spaceoar-hydrogel-works/?utm_source=google&utm_medium=cpc&utm_campaign=uro-ph-us-spaceoar-dtp&utm_content=nf-cs-spaceoar_brand-spaceoar_brand-651995397243-txt&gclid=CjwKCAjwgZCoBhBnEiwAz35RwvpVDcfPAbQ9NG5FuUrTBg8LGvFH5MTvr8apMlSZhH-AvMWHvJtpqRoCT6MQAvD_BwE): that’s the gel that basically separates the prostate from the rectum, and that’s been shown to reduce the toxicity of radiation treatment a lot
  - It’s good, and it raises the field and the competition for us to think about ways to do better less morbid prostatectomy

**Systemic Therapy**

- Peter notes, “*The mainstay of this is androgen deprivation therapy. We’ve already talked about the morbidity of that*.”

*Are there other synthetic agents or anything that looks promising?*

- Peter recalls the surge in immunotherapy to treat epithelial tumors
- Ted points out that after localized therapy, androgen deprivation therapy is considered as a radiation sensitizer
- It is known that when you have a higher grade tumor (Gleason 8 or 9 like we talked about) that radiation alone is not going to effectively cure that patient of their prostate cancer
- We know we can deliver radiation sensitization with androgen deprivation
- [Androgen deprivation](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy) induces double strand DNA breaks, and that’s the whole purpose of radiation itself is to induce those breaks

***Androgen deprivation makes the cells even more susceptible to the radiation***

- Ted uses androgen deprivation routinely
- One of the things that radiation oncologists have to work on is either intensifying the androgen deprivation (in cases that are very aggressive) or deintensifying androgen deprivation (in cases where maybe the patient would not benefit from it)
  - There is a series of trials exploring this now
  - The way that they’re determining that is with the  [Decipher®test](https://www.veracyte.com/diagnostics/prostate-cancer)
- Ted typically uses androgen deprivation therapy in two spaces:
- 1 – To augment and enhance the results of radiation based treatments
- 2 – In individuals who have more advanced prostate cancers
- For individuals who are are going to have radiation for their localized or locally aggressive prostate cancers, they will often get a course of antigen deprivation therapy (ADT)
  - The course of antigen deprivation typically ranges between 6 and 24 months, depending on the bulk of the tumor and the aggressiveness or Gleason score of the tumor
  - That ADT was typically delivered with an [LHRH agonist](https://en.wikipedia.org/wiki/Antihormone_therapy#LHRH_Agonist)
    - After getting an LHRH agonist, first you get a surgeon testosterone, then it shuts the system down
    - The problem with that is that it is given as a depot that lasts a long time
    - It’s helpful for the patient, but the probability that the patient would ever recover normal testosterone is very low because of the long-term effects on the hypothalamic pituitary axis, it just gets shut down (and/or because as you know in the aging male that it’s fragile to begin with)
- The good news for men who are getting a short course of ADT is that there are oral LHRH antagonists that are out there (they’re a pill), and their half-life is much shorter and they have been shown to effectively suppress testosterone to the same levels as an LHRH agonist
  - Their half-life is so short that people can have a rapid testosterone recovery, and they do

***For people who are going to get radiation treatment, who need a radiation sensitizer with ADT, we will typically use an oral LHRH antagonist because it’s rapid on and rapid off***

**The mainstay systemic therapy for metastatic prostate cancer is androgen deprivation therapy (ADT)**

- For individuals who are diagnosed with prostate cancer that progresses to a metastatic state or individuals who are diagnosed with prostate cancer that’s metastatic at the time of diagnosis, those individuals need to go on systemic therapy and the mainstay of systemic therapy is androgen deprivation (ADT)
- That is based off of Nobel Prize winning work from [Charles Huggins](https://www.uchicagomedicine.org/forefront/news/charles-b--huggins-md-1901-1997) out of University of Chicago
- That mainstay of therapy has not changed
- What has changed is the synthetic molecules that we use in addition to traditional LHRH agonists or antagonists to further suppress testosterone levels
- One example is [CYP17 inhibitors](https://en.wikipedia.org/wiki/CYP17A1_inhibitor): that’s a molecule called [abiraterone](https://en.wikipedia.org/wiki/Abiraterone_acetate)
  - Androgens are made from cholesterol molecules and you can inhibit a specific enzyme in the androgenic pathway (CYP17), and you can then prevent production of not just testosterone but other androgens, and not just in the testicle but within the adrenal glands and systemically
  - It results in a more profound, deeper suppression of testosterone androgen production
  - That is now recommended as first line therapy for people with metastatic prostate cancer

**What’s the median survival for men diagnosed with metastatic cancer to bone?**

- Let’s talk about distant metastasis with and without ADT
- What Peter is really getting at is given the morbidity of ADT, are there men who say, “*Okay, my median survival if I do nothing is 12 months versus my median survival is 16 months if I do ADT. It might not be worth an extra four months of life if I have to live sans androgens.*”

***The median survival for someone with newly diagnosed prostate cancer that refuses treatment is probably on the order of two to three years***

- The median survival for somebody who goes on traditional ADT only (LHRH agonist/ antagonist) is between 48 and 50 months (about double)
  - You can add a year or two of life
  - But there are effects on the quality of life: impact on metabolic syndrome and overall health
- Remember when prostate cancer is metastatic, it starts taking over your bone marrow, and you can develop [aplastic anemia](https://en.wikipedia.org/wiki/Aplastic_anemia) (which is brutal)
  - So if you can mitigate that

**How do men die from prostate cancer? What are the final stages of life?**

- Pathologic fracture, aplastic anemia because of bone marrow replacement
- It’s other organ dysfunction because the tumor takes over for it
  - Renal failure is classic one too from local tumors
- Tumor lysis and things like that
- New ADT (androgen deprivation therapy) agents such as [abiraterone](https://en.wikipedia.org/wiki/Abiraterone_acetate) or his other class of agents which are competitive binders of androgen receptors
  - They will bind the androgen receptor, tether it in the cytosol, and prevent the ligand binding domain from binding the DNA in the nucleus, among other mechanisms
  - Those are the amides: [enzalutamide](https://en.wikipedia.org/wiki/Enzalutamide), [apalutamide](https://en.wikipedia.org/wiki/Apalutamide) and [darolutamide](https://en.wikipedia.org/wiki/Darolutamide)
    - They’re related and they’re much more evolved cousins to finasteride and dutasteride, but they’re very potent

***Abiraterone and this other class of novel hormonal therapies (enza, daro and apa), they will effectively extend the life of a patient an additional 24 months on average compared to just traditional ADT alone***

- These medications are taken together
- If you currently have someone with newly diagnosed metastatic prostate cancer, the median survival time is 7-8 years
  - This depends a little on the situation they are in when diagnosed
  - There is a different outcome for newly diagnosed de novo metastatic versus you had your prostate cancer treated and then you develop metastatic disease

***The men who are newly diagnosed de novo, they have a much shorter life expectancy three to five years compared to somebody who already had their cancer treated***

- For someone who had their cancer treated, then it progressed to the bone or lymph nodes, they have a much longer life expectancy (on average) because of the bulk of disease and lead time bias in terms of detection

**Non-hormonal therapies**

- They are always evolving
- The newer ones like the amides have some toxicities (enzalutamide and apalutamide
  - They have issues with seizures
  - They have issues with overall sleepiness and alertness
- Darolutamide is the newest agent in that family, and it’s much cleaner
  - There’s less cognitive effect since it doesn’t cross the blood-brain barrier very well
  - No seizure side effects
- Abiraterone is pretty well tolerated, but it has an effect on aldosterone production
  - So you have to monitor people’s blood pressures while you have them on those drugs

***While there are toxicities with the treatment, on average people can have a longer lifespan and a relatively good health span while on these medications***

## How prostate cancer surgery has improved [3:09:30]

**What is different today in the surgical practice, your surgical practice than say four years ago? How has it evolved?**

- Last time Ted and Peter spoke in great length about the evolution of this operation from the way Ted learned it in his residency [[episode #39](https://peterattiamd.com/tedschaeffer/)]
  - Now they have transitioned to a robot

*When was the last time you did an open procedure?*

- In 2016
- Today it would be almost unheard of that a patient would have a prostatectomy without a robot

*What are you doing today to make that operation better?*

- Lots of things
- Surgery is always a balance of maximal exposure so that you can see everything with minimal exposure to preserve all the structures around whenever you’re removing
- Prostate cancer surgeries evolved in a similar way
- Historically, the robotic procedure was developed and really mimicked the open surgical procedure
  - Which basically maximally exposed the prostate within the deep pelvis
  - It’s in a very small tube
- Analogy for the tennis players out there, the deep pelvis is like the inside of a tennis ball case, the kit where you get the three balls, it’s very narrow, very small space, and you enter that space at the top of that case and you’re operating at the bottom
  - That’s why it’s such a hard procedure to do
- We used to expose all the structures around the prostate to see it and delineate it from those structures
- Ted’s technique has evolved so that he maximally preserves all those structures around the prostate and operates in an even smaller hole
- There is [fascia](https://en.wikipedia.org/wiki/Fascia), which for the average listener is effectively like the Kevlar or the Gore-Tex of our entire body
  - It provides resiliency and strength to the structures
  - It keeps them in place
  - And the prostate is surrounded by a tremendous amount of fascia
  - When fascia gets really, really thick, we refer to that as a ligament or a tendon
  - So the prostate has fascia, it has ligaments that support the prostate in the deep pelvis
- Historically and robotically we would always open up and disassemble that fascia to expose the prostate, and then we sew it back together and hope that people were okay
- Ted and the elite prostate surgeons in the world have developed techniques to do a pelvic fascia-sparing surgery, leaving all the fascia that surrounds the prostate alone
  - The purpose is to mitigate the very real side effects of this surgery around erectile function and incontinence
- You’re always balancing your outcomes functionally with your outcomes from a cancer control perspective
  - You want to get all of the cancer out, because you can maximally preserve all these structures in the fascia the tissues but leave a lot of cancer behind
    - And then, what’s the point of the procedure
- 60 years ago you could get all the cancer out surgically, but the problem was the morbidity as you were guaranteed to be incontinent and impotent
  - 100 years ago, we were not picking up prostate cancer early enough
  - 100+ years ago, the first prostatectomy was a pelvic fascia-sparing prostatectomy
    - It was done in the perineum where all of the fascia that supports the prostate was left in place
    - It was bloody, and you couldn’t see what you’re doing
- The robot enables you to have no bleeding and enables you to see what you’re doing very, very well

**Where are the ports? Where do you gain access for this surgery?**

- You gain access to the prostate typically through the abdominal compartment
- You have a central port at the belly button and then typically use a couple ports around at the level of the belly button, more lateral to it that you insert your instrumentation
- *Usually* the procedure is done trans-peritoneal, meaning you put the ports into the peritoneum where the intestines live, and then you kind of exit the peritoneum and you do the procedure extra-peritoneal (outside of the peritoneum)
  - Outside of the peritoneum, in the deep pelvis is where all the fascia is there supporting the prostate and the structures around it
- *Now* when Ted does the procedure, he does pelvic fascia sparing
  - He’s been doing this for 2.5 years now
  - When he looks at his results, he has not impacted cancer control at all
    - Some of the early surgeons who did pelvic fascia sparing left a lot of cancer behind (you don’t want to do that)
- Ted tracks his data, and he has excellent cancer control numbers (data margin rates) while maximally preserving the structures around the prostate
- Back to the orange analogy: you have your orange and the pulp of the orange is not cancer, but the outer peel is cancer
  - And just adjacent to that outer peel are nerves for erectile function, nerves for innervation of the urethral sphincter, and the urethral sphincter itself
  - All of those structures are supported by pelvic fascia
- We now leave all those structures in place and do the procedure through an even smaller space, this requires a learning curve to adapt to it
- But with that approach, you can really effectively eliminate urinary incontinence in almost everybody
  - And more importantly, the rapidity with which urinary control comes back is outstanding

**What do you tell a patient today?**

- Ted tell patients his data
- If the cancer is contained within the prostate, with this procedure there is a 4-5% chance that they’ll have a positive margin

***So there is a 95-96% chance that this operation will be successful from a cancer perspective, and a 4-5% chance that they will need another surgery to get some of the cancer out***

- It’s a little bit more subtle that that
- A measure of surgical skill is: are you taking out the prostate and all the prostate cancer (if the cancer’s contained within the prostate)
- So about 4-5% of the time Ted makes a little nick or pokes a little hole in the side of the prostate and exposes some cancer
  - It doesn’t mean that they’re going to have a recurrence, but it’s a sign of technical skill
  - In an average surgical series, it’s more like 15 or 20%
- Ted tells patients:
  - At 10 days after the procedure there is a 55% chance that we will take your catheter out and you’ll be dry with no leakage
  - At 1 month, it’s a 66% chance that you’ll be dry with no leakage
  - At 3 months, it’s a 95% chance
  - This is what anterior fascial sparing surgery has done
- Some patients will still wear a pad or liner a day for insurance

**What about erectile function?**

- Anterior fascial sparing surgery has transformed urinary recovery substantially
- With this technique, you can also do less damage to the nerve tissue
  - You leave it in sight, it stays attached to the rectum and the fascia around it
  - There is still neural trauma, and the biggest hurdle that we have in urology in neurologic oncology is really optimizing our neural preservation
    - Surgeons are reliant on neuroscientists to help them find neuroprotective agents they can deliver pre-surgery to minimize that trauma
- The nerves utilized for erection are unmyelinated, so they don’t really exist in a cable or bundle
  - They are a kind of individual nerve fiber
  - They’re very sensitive to stretching, pulling, and tugging
- The probability that people would recover erectile function is much better when you do anterior fascial or pelvic fascial sparing surgery

***But overall, the probability that they recover erectile function is highly dependent on the Gleason score (i.e. the aggressiveness of the tumor and the extent of the tumor)***

- Because if you have a high-grade prostate cancer, there’s a 60-80% chance that that cancer is growing into the nerve tissue on the side that the tumor exists on already
- So we don’t often think in absolutes like 100% resection of nerve or 0% resection of nerve, but we have to titrate the dissection surgically to incorporate any potential nerve tissue that may have cancer in it

**Surgical techniques are evolving and trials are starting soon**

- The nice thing and the exciting thing is that we are moving into a space where there are going to be **imaging agents in real time**
  - Think about PET-PSMA, they are now linking PET-PSMA to near infrared based tracers
  - So you can actually flip a switch and do near infrared imaging in real time during a prostatectomy to look for residual cancer
  - You could maximally spare nerves and look at the tumor to see if is there any tumor left behind
- Lots of things that are evolving in surgery that will help advance us in identifying precisely where the tumor is and where it is not

**If a Gleason 3+4 patient comes to you, and it’s high enough forward that you’re going to operate on him, what are you telling him?**

*Peter assumes most of these patients will be on* [*Cialis*](https://en.wikipedia.org/wiki/Tadalafil) *postoperatively*

- This is a 65-year-old guy who didn’t require Cialis before surgery
- Ted would tell him there is a 65-75% chance they will recover erection sufficient for intercourse with Cialis onboard
  - Within 24 months
  - Because that neuropraxia is a 24-30 month process

**For the guys who don’t get it back, they’re going to be looking at other therapies for erectile function, pumps and things of that nature?**

- There are injectable medications
  - [Prostaglandins](https://en.wikipedia.org/wiki/Prostaglandin_E1) are very effective, and they bypass the nerves and/or implantable devices
- [See [episode #260](https://peterattiamd.com/mohitkhera/) for further discussion of therapies for erectile dysfunction]

**For the 65-year old guy who is on Cialis before surgery. What is his recovery on Cialis?**

- It’s going to be 10-20% less good [45-55% will recover erection with Cialis on board]

**What if this same guy has a Gleason score of 4+4?**

- It depends on where the tumor is
- The nerve bundles are in that kind of posterior lateral portions of the prostate
  - Think about 5 and 7 o’clock, the bulk of them
  - So if you have an anterior tumor at 1 o’clock, then we can do full nerve sparing
- Peter notes this is the kind of nuance that comes into the diagnosis

**Prostaglandins have been a game changer because it lessens the need for perfect recovery of erectile function postoperatively**

- Ted uses [prostaglandins](https://en.wikipedia.org/wiki/Prostaglandin_E1), an injectable medication in patients for 1-2 years when the nerve function is recovering
  - It’s an injection at the base of the penis into the cavernosal body, right at the vascular bundle
  - That injection will trigger an erection

**What prevents that patient from getting** [**priapism**](https://en.wikipedia.org/wiki/Priapism)**?**

- The dosage of the medication
- You start out low and you titrate high
  - That re-oxygenates the penis, helps maintain penile length
  - If you’re attempting intercourse, it would prevent any kind of potential microfracture like you had talked about with [Mohit Khera](https://www.drmohitkhera.com/about/) [in [episode #260](https://peterattiamd.com/mohitkhera/)], with potential scarring and plaque formation
- Ted strongly advocates for prostaglandins for all the patients
  - It helps with their recovery and helps them with their sexual function in the meantime

## Questions to ask your neurologist if you are considering prostatectomy for cancer [3:21:45]

- We’ve talked about many key points throughout this episode
- 1 – When the urologist did the biopsy, did he do an MRI beforehand?
  - This means he’s up-to-date with modern medicine
- 2 – When the pathologist read the specimen, did they specify the percent pattern 4?
  - That means that the pathologist at that institution is up-to-date
- 3 – What is the urologist practice that’s offering a radical prostatectomy?
  - Is the scope of the practice prostatectomy only, or do they do everything?
  - Ted firmly believes (and there’s strong data to suggest) that if you are a prostatectomy-only practice (like his) that you’re dedicated to and focused and thinking about the operation and all the subtleties we’ve talked about over the last couple of hours that are related to the surgical outcome
    - So if you’re a jack of all trades, then Ted doesn’t recommend that you go to that person for their prostatectomy
    - When Ted’s patients have kidney stones, he doesn’t treat them; he send them to his partners because they do a better job
    - All Ted does is prostatectomy
- 4 – What are the outcomes of the urologist?
  - What are their surgical margin rate and rate of functional recovery?
  - Ted tries to set appropriate expectations because sometimes physicians will say there is 100% chance of erectile recovery, but that’s not accurate
- There are a limited number of urologists doing the fascial sparing procedure
  - It’s always evolving in terms of how many people are out there doing it
  - There’s a learning curve, it’s a harder procedure, and it takes longer to do it

**How long did it take to do a prostatectomy without fascial sparing and how long does it take you now?**

- It takes Ted about 45 minutes longer with fascial sparing
- His average surgical time was maybe 90-120 minutes before and now he adds 45 minutes
  - It’s worth it to do that
- There are a bunch of videos on the Northwestern Medicine Urology [YouTube channel](https://www.youtube.com/@nmurology2444/search?query=fascial%20sparing) that show how you can learn the procedure (for those surgeons out there)

**What are you most excited about in the next five years in the field of prostate cancer?**

- Integration of precision medicine
- Ted has been passionate about precision medicine and incorporated it in his practice for over a decade
- Understanding the molecular subtypes and phenotypes of an individual’s tumor is going to be incredibly powerful and it’s going to change how we think about and manage individual patients
- Not only recommending treatment for the local licensees
- Ted thinks we’re going to discover that they are exquisitely radiation-sensitive tumors and those that are radio-resistant
  - We know that there are tumors that are exquisitely sensitive to androgens and those that are inherently androgen-resistant
  - We’ve never ever looked [for radiation sensitive/ resistant tumors] or thought about it before, but now we have in our hands the power to do that, and that’s going to change everything
  - We’ll see the benefits of those studies in the next five years

§

## Selected Links / Related Material

**Ted is co-author on a recent book on prostate cancer**: [*Dr. Patrick Walsh’s Guide to Surviving Prostate Cancer*](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1538726866/ref=sr_1_4?crid=E70A0SEF22CV&keywords=Dr.+Patrick+Walsh%E2%80%99s+Guide+to+Surviving+Prostate+Cancer&qid=1695059493&sprefix=dr.+patrick+walsh+s+guide+to+surviving+prostate+cancer%2Caps%2C237&sr=8-4) by Patrick Walsh, Janet Worthington, and Edward Schaeffer (October 2023) | [1:30]

**Ted’s website and his work as a consultant to people needing prostate care**: [TedSchaefferMD.com](https://tedschaeffermd.com/) | [2:00]

**Previous episode of** ***The Drive*** **with Ted Schaeffer**: [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) (February 4, 2019) | [2:00, 3:45, 2:05:45, 3:09:45]

**Paper by Ted’s father on prostatitis**: [Alfuzosin and Symptoms of Chronic Prostatitis–Chronic Pelvic Pain Syndrome](https://www.nejm.org/doi/full/10.1056/NEJMoa0803240) | *NEJM* (J Nickel et al. 2008) | [51:30]

**Online NIH questionnaire to identify source of prostate pain**: [NIH Chronic Prostatitis Symptom Index](https://www.usrf.org/questionnaires/Prostatitis_NIH_Symptom_Index.html) | Urological Sciences Research Foundation | [1:01:00]

**Anthony Schaeffer’s clinical trial investigating the role of mast cell dysfunction in prostatitis**: [Mast cells in male chronic pelvic pain and lower urinary tract dysfunction](https://www.feinberg.northwestern.edu/sites/urology/research/clinical-trials.html#) | Northwestern Department of Urology (2023) | [1:04:15]

**Analysis of 100,000 prostate cancer transcriptomes**: [Transcriptomic analyses of localized prostate cancers of East Asian and North American men reveal race-specific luminal-basal and microenvironmental differences](https://onlinelibrary.wiley.com/doi/10.1002/cac2.12467) | *Cancer Communication* (M Chua et al 2023) | [1:29:45]

**Genomic testing of prostate cancer biopsy**: [Decipher® Prostate Genomic Classifier](https://www.veracyte.com/diagnostics/prostate-cancer) | Veracyte (2023) | [1:36:45]

**Association between use of dutasteride and finasteride and prostate cancer lethalities**: [Association of Treatment With 5α-Reductase Inhibitors With Time to Diagnosis and Mortality in Prostate Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6503564/) | *Jama Internal Medicine* (R Sarkar et al 2019) | [1:41:45]

**Comparison of SNPs in men who did and did not develop prostate cancer**: [Trans-ancestry genome-wide association meta-analysis of prostate cancer identifies new susceptibility loci and informs genetic risk prediction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8148035/) | *Nature Genetics* (D Conti et al 2021) | [1:46:15, 1:49:30]

**Epidemiologic study found lower risk of developing prostate cancer in men who ejaculated more than 20 times a month**: [1:52:00]

- [Ejaculation Frequency and Subsequent Risk of Prostate Cancer](https://jamanetwork.com/journals/jama/fullarticle/198487) | *JAMA* (M Leitzmann et al 2004)
- [Ejaculation Frequency and Risk of Prostate Cancer: Updated Results with an Additional Decade of Follow-up](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5040619/) | *European Urology* (J Rider et al 2016)

**Advanced PSA tests**: [2:00:45]

- [The 4Kscore Test](https://4kscore.com/what-is-the-4kscore/) | 4Kscore (2022)
- [Prostate Health Index (phi)](https://www.beckmancoulter.com/products/immunoassay/phi) | Beckman Coulter (2023)

**National Comprehensive Cancer Network’s Prostate Cancer Screening guideline**: [NCCN Guidelines® Insights: Prostate Cancer Early Detection, Version 1.2023](https://jnccn.org/view/journals/jnccn/21/3/article-p236.xml) | *Official Journal of the National Comprehensive Cancer Network* (K Moses et al 2023)| [2:07:15]

**MRI recommended when the advanced PSA test is abnormal** : [2:15:30]

- [MRI-Targeted or Standard Biopsy in Prostate Cancer Screening](https://pubmed.ncbi.nlm.nih.gov/34237810/) | *NEJM* (M Eklund et al 2021)
- [Prostate cancer screening using a combination of risk-prediction, MRI, and targeted prostate biopsies (STHLM3-MRI): a prospective, population-based, randomised, open-label, non-inferiority trial](https://pubmed.ncbi.nlm.nih.gov/34391509/) | *Lancet Oncology* (T Nordstrom et al 2021)

**PI-RAD score**: [Prostate Imaging Reporting & Data System (PI-RADS)](https://radiopaedia.org/articles/prostate-imaging-reporting-and-data-system-pi-rads-1?lang=us) | Radiopaedia (2023) | [2:18:15]

**Prostate biopsy technique created by Matt Allaway**: [Perineologic: Better, Safer, Prostate BiopsyTM](https://perineologic.com/) (2023)| [2:24:00]

**Outcome of prostate biopsies by PI-RADS and PSA density**: [Combined Use of Prostate-specific Antigen Density and Magnetic Resonance Imaging for Prostate Biopsy Decision Planning: A Retrospective Multi-institutional Study Using the Prostate Magnetic Resonance Imaging Outcome Database (PROMOD)](https://pubmed.ncbi.nlm.nih.gov/32972896/) | *European Urology Oncology* (U Falagario et al 2021) | [2:28:45]

**Risk predictor for prostate cancer**: [My nMRIsk Calculator: Optimizing Detection of Clinically Significant Prostate Cancer](https://rossnm1.shinyapps.io/MynMRIskCalculator/) | Northwestern Medicine | [2:30:00]

**Landmark studies, radical prostatectomy series in men who had Gleason 6 prostate cancer (or higher)**: [2:37:45]

- [Do adenocarcinomas of the prostate with Gleason score (GS) ≤6 have the potential to metastasize to lymph nodes?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3421030/) | *The American Journal of Surgical Pathology* (H Ross et al 2012)
- [Metastatic potential to regional lymph nodes with Gleason score ≤7, including tertiary pattern 5, at radical prostatectomy](https://pubmed.ncbi.nlm.nih.gov/27496532/) | *BJU International* (M Diolombi and J Epstein 2017)

**Ballentine Carter’s long-term outcomes of prostate cancer**: [Active Surveillance of Grade Group 1 Prostate Cancer: Long-term Outcomes from a Large Prospective Cohort](https://pubmed.ncbi.nlm.nih.gov/31918957/) | *European Urology* (J Tosoian et al 2020) | [2:45:15]

**MIRAGE study of MRI guided radiation therapy**: [Magnetic Resonance Imaging–Guided vs Computed Tomography–Guided Stereotactic Body Radiotherapy for Prostate Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9857817/) | *JAMA Oncology* (A Kishan et al 2023) | [2:59:45]

**YouTube videos of fascial sparing prostatectomy**: [NM Urology](https://www.youtube.com/@nmurology2444/search?query=fascial%20sparing) [search fascial sparing] (2023) | [3:24:45]

§

## People Mentioned

- [Amy Krambeck](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=50492) (Professor of Urology and Chief of Endourology and Stone Disease at Northwestern; pioneer of modern HoLEP surgery) [31:00, 1:39:30]
- [Anthony Schaeffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=13362) (Ted’s dad and Professor of Urology at Northwestern) [51:30, 1:04:00]
- [Thomas (Tom) Stamey](https://med.stanford.edu/news/all-news/2015/09/thomas-stamey-expert-on-prostate-cancer-and-psa-test-dies-at-87.html) (founding chair of Stanford’s Department of Urology) [48:30]
- [Praveen Thumbikat](https://www.feinberg.northwestern.edu/sites/urology/faculty/profile.html?xid=17389) (Professor of Urology and Pathology at Northwestern; Anthony Schaeffer’s scientific partner) [1:05:00]
- [Elai Davicioni](https://it.linkedin.com/in/elai-davicioni-7b82a727) (Co-Founder of Decipher and now Medical Director of Urology and Senior Vice President of Scientific and Clinical Operations at Veracyte) [1:30:00, 1:34:15]
- [Christopher (Chris) Haiman](https://keck.usc.edu/faculty-search/christopher-haiman/) (Professor of Population and Public Health Sciences and AFLAC Chair in Cancer Research at USC) [1:46:15]
- [Rajpaul Attariwala](https://ca.linkedin.com/in/raj-attariwala-md-phd-fanm-frcpc-23b4636) (Radiologist, MRI expert, and guest on [episode #61](https://peterattiamd.com/rajpaulattariwala/)) [2:17:00]
- [Matt Allaway](https://urologyassociatesmd.com/urology-associates-dr.allaway.html) (Urologist) [2:23:30]
- [Ashley Ross](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=47812) (Associate Professor of Urology at Northwestern Medicine) [2:30:00]
- [Jonathan (John) Epstein](https://www.hopkinsmedicine.org/profiles/details/jonathan-epstein) (The Reinhard Professor of Urologic Pathology at Johns Hopkins) [2:37:45]
- [Scott Eggener](https://biologicalsciences.uchicago.edu/faculty/scott-e-eggener-md) (Bruce and Beth White Family Professor of Surgery-Urology at The University of Chicago) [2:37:45]
- [Ballentine Carter](https://www.hopkinsmedicine.org/news/articles/2019/11/the-h-ballentine-carter-md-prostate-research-and-innovation-fund) (former Professor of Urology at Johns Hopkins)  [2:45:15]
- [Charles Huggins](https://www.uchicagomedicine.org/forefront/news/charles-b--huggins-md-1901-1997) (Nobel Prize winner and former Professor of Surgery at t heUniversity of Chicago, expert in prostate cancer) [3:04:30]
- [Mohit Khera](https://www.drmohitkhera.com/about/) (Professor of Urology at Baylor College of Medicine and [previous guest](https://peterattiamd.com/mohitkhera/) on the podcast) [3:21:45]

§

![](https://peterattiamd.com/wp-content/uploads/2023/09/bio-image-tedschaeffer2.jpeg)

##### Ted Schaeffer, M.D., Ph.D.

Edward (Ted) Schaeffer graduated from the University of Chicago in 2001 with his M.D. and Ph.D. He completed his internship in general surgery followed by a residency in urology at Johns Hopkins. He is a board certified urologist with an active practice specializing in prostate cancer.

Dr. Schaeffer is Chair of the Department of Urology at Feinberg School of Medicine and Program Director of the Genitourinary Oncology Program at the Robert H. Lurie Comprehensive Cancer Center of Northwestern University. His globally recognized prostate cancer [research](https://www.cancer.northwestern.edu/research/membership/profile.html?id=6cc14a9069084ee44bc0f6dec58fcc5c) focuses on at-risk populations, diagnosis, treatment outcomes, and the molecular biology of lethal prostate cancer. [[Northwestern Medicine](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261)]

Twitter: [#EdwardSchaeffer](https://twitter.com/EdwardSchaeffer)

Website: [TedSchaefferMD.com](https://tedschaeffermd.com/)