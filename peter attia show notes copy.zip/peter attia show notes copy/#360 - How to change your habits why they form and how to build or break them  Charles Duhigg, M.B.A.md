# #360 ‒ How to change your habits: why they form and how to build or break them | Charles Duhigg, M.B.A

**Source:** [https://peterattiamd.com/charlesduhigg/](https://peterattiamd.com/charlesduhigg/)

---

Charles Duhigg is a Pulitzer Prize-winning journalist and best-selling author known for distilling complex neuroscience and psychology into practical strategies for behavior change, performance, and decision-making. In this episode, Charles explores the neuroscience behind habit formation, including how cue-routine-reward loops drive nearly half of our daily actions and why positive reinforcement is far more effective than punishment. He explains how institutions like the military and Alcoholics Anonymous engineer environments to change behavior at scale, as well as discussing the limits of willpower and how to preserve it by shaping context. The conversation also covers the real timeline of habit formation, how to teach better habits to kids, the role of failure and self-compassion in lasting change, and the power of social accountability. Charles further discusses how cognitive routines enhance productivity and creativity, how to gamify long-term goals through immediate rewards, why identity and purpose are often the strongest forces behind sustainable behavior change, and the potential of AI to power habit change.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/charlesduhigg/the_Drive_public.png)

Play

#360 ‒ How to change your habits: why they form and how to build or break them | Charles Duhigg, M.B.A

#360 ‒ How to change your habits: why they form and how to build or break them | Charles Duhigg, M.B.A

1x15s30s

0:002:13:10

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- How Charles’s background in journalism and personal experiences led to his interest in habit formation [A: 3:15, V: 1:20];
- The science behind reinforcement: why positive rewards outperform punishment in habit formation [A: 10:15, V: 9:06];
- How the military uses habit science to train soldiers using cues, routines, and rewards [A: 17:15, V: 16:59];
- Methods for creating good habits and eliminating bad ones: environmental control, small wins, rewards-based motivation, and more [A: 24:00, V: 24:36];
- How parents can teach kids to build habits and strengthen willpower [A: 32:15, V: 33:45];
- How adults experience changes in motivation and cue effectiveness over time, and why willpower must be managed like a finite resource [A: 34:30, V: 36:09];
- Keys to successful habit change: planning for relapse, learning from failure, and leveraging social support [A: 38:00, V: 40:05];
- Advice for parents: praise effort, model habits, and normalize failure [A: 47:45, V: 51:16];
- The time required for making or breaking a habit [A: 50:45, V: 54:45];
- The different strategies for creating new habits vs. changing existing ones, and the crucial role of cues and reward timing [A: 55:15, V: 1:07:15];
- How to create habits around long-term goals when the rewards are delayed (like saving money) [A: 1:01:45, V: 1:17:54];
- How to stick with good habits that offer no immediate reward: designing reinforcements and identity-based motivation [A: 1:11:15, V: 1:24:06];
- The potential for AI to provide social reinforcement [A: 1:16:45, V: 1:24:06];
- Mental habits: how thought patterns and contemplative routines shape deep thinking, innovation, and high-stakes performance [A: 1:23:30, V: 1:31:36];
- How cognitive routines boost productivity and habit formation, but may stifle creativity [A: 1:35:15, V: 1:44:50];
- Contemplative routines: using stillness to unlock deeper productivity and creativity [A: 1:40:45, V: 1:51:15];
- How habits reduce decision fatigue and enable deep, high-quality productivity [A: 1:44:15, V: 1:55:25];
- New research that reveals the power of environment and social feedback in habit formation [A: 1:49:45, V: 2:01:31];
- How AI may transform work, identity, and our sense of purpose [A: 1:53:45, V: 2:05:51];
- The potential of AI-powered habit change, and the essential—but often lacking—element of motivation [A: 2:02:30, V: 2:16:27]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Charles Duhigg is a Pulitzer prize winning journalist and the author of several best selling books including [*The Power of Habit*](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)*,* [*Smarter Faster Better*](https://www.amazon.com/Smarter-Faster-Better-Productive-Business/dp/081299339X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80), and most recently, [*Supercommunicators*](https://www.amazon.com/Supercommunicators-Unlock-Secret-Language-Connection/dp/0593243919/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)
- He is one of the most trusted voices on the science of behavior change, performance, and decision making
- He is known for translating complex, psychological and neuroscience research into actionable insights that improve everyday life
- Peter wanted to have Charles on the show because habits are the foundation for integrating nearly everything we talk about on this podcast when it comes to improving lifespan and healthspan
  - Whether it’s exercise, nutrition, sleep, or emotional regulation
  - If the behavior doesn’t stick, the benefits won’t accrue

In this episode, we discuss

- The neuroscience of habit formation
- How cue, routine, reward loops govern nearly half our daily behaviors
- Why understanding this loop is integral to behavior change
- Why positive reinforcement is 20x more effective than punishment
- How to harness rewards to build lasting habits
- How the military, Alcoholics Anonymous, and behavior change research structure environments to transform behaviors at scale
- Willpower as a finite mental muscle
  - How it gets fatigued
  - How environment shapes its effectiveness
  - How to preserve it for when it matters most
- The myth of 21 days to form a habit
- The truth about timeline, relapse, and learning through failure
- Building better habits with your kids
  - Teaching them how to identify cues and rewards
  - Modeling failures as data for learning
- The power of social accountability and coaching in habit change
- Why self judgement is counterproductive to lasting success
- Creating cognitive routines that foster deeper thinking, productivity, and innovation
  - Featuring lessons from elite pilots, parents, and writers
- How to gamify long-term goals like saving money or taking blood pressure medication using short-term rewards and narrative cues
- The relationship between identity, purpose, and behavior; and why meaning is often the most powerful habit reinforcer of all

## How Charles’s background in journalism and personal experiences led to his interest in habit formation [A: 3:15, V: 1:20]

- In many ways, Charles is kind of the “OG guy” when it comes to talking about habit formation
- It’s hard to believe that it’s been 13 years since his amazing book on the subject matter [[*The Power of Habit*](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)]
- Peter probably read it 8 years ago, but it’s a topic that is relevant regardless of what you do
- For Peter’s job and how he tries to help people, it really comes down to knowing what to do and then putting it into practice

**Give folks a bit of a sense of your background and maybe even how that factored into you taking an interest in the topic of habits**

- Before Charles wrote [*The Power of Habit*](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80), he had been a business and science reporter for quite a while
- He decided to become a journalist after he went to Harvard Business School, and he got his MBA
- About halfway through business school he realized it’s a lot more fun to write about business than to do it; so he decided to become a journalist
- One of the things that he noticed as he was writing, are 2 experiences that got him interested in habits
  - He was working at the *New York Times* at that point
  - Because he had spent time overseas in Iraq during the war, he had reported on a bunch of different things
- 1 – When he was in Iraq, he was embedded with a unit that was right outside of Baghdad, he was talking to a major, and he asked him, “*How do you train soldiers to become soldiers?*”
  - Because one of the things that you see in a war zone in particular is that the behaviors are so deeply ingrained
  - The goal is to ingrain a set of behaviors that so that if a bomb goes off, everyone around you knows exactly what to do in that moment, and they react automatically
  - The major described the military as “*A giant habit change machine*”
  - They teach young recruits who maybe don’t have any self-discipline, who maybe are prone to emotional upheavals
- 2 – When  he came back to the US, he was thinking about this to himself, “*If I’m so smart and so talented…*”
  - Why can’t I get myself to lose weight?
  - Why can’t I get myself to go running in the morning every day?
  - Why is this such a struggle for me when I’m so good at other things?

***He realized it was because he had not learned and studied how habits function in his own habits***

> “*Once I learned that, I had the tools to change how I behave automatically, which is of course the most important component of our behavior because it’s what we do every day*.”‒ Charles Duhigg

**What year did you get back to the US from Iraq?**

- Charles was in Iraq from 2003-2004; he got back at the end of ‘04, beginning of ‘05
- He was at the *LA Times* and he started working at *The New York Times* in ‘06

**What did you start writing about? When did you pick that thread up again?**

- He was writing for the business section at *The NY Times*, and he wrote a [piece](https://www.nytimes.com/2008/07/13/business/13habit.html) about the science of hand washing, which was really fascinating

*There’s been really interesting research, particularly out of the United Kingdom, about: How do we incentivize people in developing nations to wash their hands?*

- A lot of this was sponsored by [Unilever](https://www.unilever.com/), the soap company
- They found that people in poor communities (particularly in India and Pakistan and in other parts of Asia) would buy soap, and then they would save the soap for special occasions
  - It was like something you gave to a guest when they came over
  - It was something that you used before you went to mosque or for prayer
- As a result, they weren’t washing their hands every day
- Of course, we know that using soap actually correlates with preventing a lot of diseases
- A number of researchers in the UK took this on to try and figure out: How do we create hand washing habit using soap?

***What they discovered was, you need to focus on the reward***

- Unilever, in all the advertisements, would talk about the benefits you got from using soap: that if you used soap disease would go down
  - That was not influential
- 1 – It was too abstract
- 2 – You’re trying to educate people who don’t think that they’re at an education deficit

**⇒** We see the same thing in the United States around vaccine resistance and other things, telling people, “*Oh, you don’t know enough. I’m going to tell you the truth*.” ‒  that almost never works

***What you have to do is you have to create incentives where you get an immediate reward for that behavior***

- What they did is they actually changed the scent of the soaps
  - They made the scent of the soaps less powerful because it seemed less like a perfume, less like a fancy thing
- Then they ran these ads where they equated washing your hands with taking care of your children, not necessarily your own health, not your own cleanliness
  - When I wash my hands with soap, I can feed my children
  - They were creating that sense, that identity reward that says, “*By doing this, you’re a good parent*.”
  - And that changed everything
- Peter is always intrigued by this type of problem

**How long did it take them to figure out that that was the unlock?**

*Was this iterative? What type of research did they have to do?*

- It took them years
- It took a really sustained exposure
- What’s interesting is part of this research and where it came out of was trying to understand the neural roots of **disgust**

**⇒** Disgust is a really, really powerful instinct that all humans have, and they really wanted to understand how do we capitalize on disgust as a negative reward?

- They spent years on this, but like everything that ends up having widespread change, it really paid off enormous dividends

Peter asks, “*When you say they, who are the types of people? Are these behavioral economists? Are they psychologists, sociologists?*”

- There’s a woman named [Val Curtis](https://en.wikipedia.org/wiki/Val_Curtis#) who in particular led a lot of this research
  - Charles believes her background is in sociology
- This was during the heyday of behavioral economics when [Danny Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) and others, [Amos Tversky’s](https://en.wikipedia.org/wiki/Amos_Tversky) work was really getting noticed for the first time and was making its way into other fields

***They brought in a lot of the behavioral economists and psychologists***

This points to something interesting: some of the most exciting research that’s happening right now is this interdisciplinary research

- There tend to become these silos within universities
- When you look at what’s really interesting that’s happening, it tends to be the people who are stepping outside of those silos

## The science behind reinforcement: why positive rewards outperform punishment in habit formation [A: 10:15, V: 9:06]

**A framework for understanding motivation to change habits**

- The way Charles described it a moment ago, it was more avoidance of negative that got the job done
- Peter thinks of this as a 2×2: positive and negative, giving (carrot) and taking away (stick)
  - An example of taking away: disgust is bad, and we’re going to remove disgust

*What does the science tell us about that foursquare?*

A bit of context

- About 40-45% of what we do every day is habits
- This comes from research by [Wendy Wood](https://en.wikipedia.org/wiki/Wendy_Wood_(psychologist)) at USC

**⇒** Every habit in our life has 3 components:

- 1 – There’s a **cue**, which is like a trigger for that behavior to start
- 2 – There’s a **routine**, which is the behavior itself, what we think of as the habit
- 3 – Then there’s a **reward**
  - Every habit in your life delivers a reward, whether you’re aware of it or not
  - There are negative rewards, and there are positive rewards

***Negative rewards and positive rewards act very differently, and to be most powerful, often we have to put them in combination with each other***

**Understanding negative rewards**

- You would think that the threat of something unpleasant happening would be the most powerful negative reward
  - Peter, if you don’t run today, I’m going to hit you with a cane
- That’s actually not what the science tells us

***What the science tells us is that the best way to use negative rewards is to establish the pain and punishment prior to the behavior and then remove the tension of it afterwards***

- Example: when Charles was in Iraq, one of the things that he learned about was the extraordinary interrogation techniques that were used by the military
  - Stories came out ‒ they would take people and terrorists, and if they weren’t giving them information, they would put them in a little box and lock them up in this physically uncomfortable position
  - That’s not actually what happened
  - What happened is the person was put in a box and told, “*I will let you out of the box if you give me the information I want*.”

***The presence of a negative reward or a punishment is much more powerful when we feel it than when we anticipate it***

**⇒** The problem is, negative reinforcement is about 1/20th as effective as positive reinforcement

Charles explains, “*I have to hit you with a cane 20 times to equal the motivation that you’ll feel if I let you have a really nice smoothie after you go for that run.*”

- We define effective as: likely to produce the desired outcome
- Peter would’ve guessed this is ½ [not 1/20] ‒ that’s a staggering difference
- It sometimes gets complicated by scale because you might really hate getting hit by a cane a lot more than you enjoy drinking a smoothie
  - But we know that if those two things are comparable in your head, I’m going to have to hit you 20 times to equal the motivation you’ll find from drinking that smoothie
  - And that’s a normal distribution
- There’s different behaviors and different tolerances among individuals

***The reason why this is important is because when there are negative rewards or punishments available to us in the environment, then we should take advantage of those***

An example from handwashing

- If I know that you feel a sense of disgust, and I can take advantage of that to help you build a habit of washing your hands, I should go ahead and do so
- But that’s not enough on its own
- I have to pair it with a positive reward where I’m creating a scent in that soap that makes you feel like you’re clean, that makes you feel like you’re doing something virtuous
- I have to re-emphasize to you, you’re doing this for your kids: every time you wash your hands with soap, you are a good parent
- The problem with the flowery scent: it’s too associated with luxury
  - You need a scent that smells a little bit more medicinal to believe that it’s doing its job

**Thinking about motivation through the lens of parenting**

- Parenting is probably the first thing that comes to many listeners minds when we think about the words: reinforcement, positive and negative reinforcement
- Your child is misbehaving
- Bedtime routine is a disaster
- They don’t want to brush their teeth or whatever it is
- There’s a punishment that you could allocate for that behavior
- You could say, “*Look, Johnny, if you don’t go to bed now, you do not get to play Xbox tomorrow*.”
  - That’s a punishment
- There’s a reward, which is, “*If you do this thing, I’m going to give you an extra 15 minutes of playing Xbox tomorrow*.”

**Is it safe to say that offering 15 minutes of extra Xbox is significantly more likely to produce a desired outcome?**

- Absolutely
- Any parent listening knows this, right?
- We’re talking here about permanent behavior change
  - We don’t want them just to brush their teeth tonight
  - We want them to brush their teeth every night

***A positive reward, positive reinforcement is going to be much more powerful at ingraining that habit in their life while a negative reward, it might work tonight***

**Do you have a sense of why this is, from an evolutionary perspective? Because this seems awfully hardwired**

- Charles doesn’t know the answer to that; he’s not sure anyone does

*The hypothesis on this*

**⇒** Our brain tends to over notice negative outcomes

- And that’s good because that means that something can kill us, we’re going to avoid it
- As a result, we actually are very good at discounting that reward very quickly
- We have a very accurate mental representation of how painful a reward is going to be and whether we should avoid it or not
- Our sense of a negative reward, negative reinforcement is very finely tuned

***Our sense of positive reinforcement is not as finely tuned, and as a result, there’s an opportunity there to take advantage, to kind of arbitrage that difference within our brain where when I give you a positive reward, you actually enjoy it more than you ought to***

**Slot machines are a great example**

- The way that a slot machine gets you hooked is they give you a consistent stream of rewards every 10, 15 minutes, every 10, 15 pulls, and then they mix into that intermittent unexpected rewards because that unexpected reward gives me that dopaminic reaction

***That reward sensation is much, much bigger than the actual prize that I’m gettin***g

- Slot machines take advantage of it in a negative way
- But we can take advantage of it in a positive way and say, “*If I give you a reward, you’re going to love it even more than you’ll hate that punishment.*” And that gives me an opportunity

## How the military uses habit science to train soldiers using cues, routines, and rewards [A: 17:15, V: 16:59]

*How did you come to understand the ways in which a myriad set of behaviors (because as you said, a soldier is able to do so many things that basically become autonomic that might be very counterintuitive) that might be counter to the value of your own life [are instilled]?*

- Moving this direction as opposed to that direction under threat
- Or training people to kill, which many people have a natural reaction to not kill

*The military pays very, very close attention to teaching cadets to respond to cues*

- Let’s talk about the behavior that you do when a bomb goes off
- The thing about a bomb going off is that a bomb going off is a little bundle of cues, and we need to talk about which cues you should pay attention to and which ones you shouldn’t, which should trigger an autonomic behavior

In Iraq, the issue with bombs (IEDs) going off, was dust

- When there was an explosion of dust, that is when you should react, and we’re going to practice that
- So we’re going to take you out into the field, and we’re going to use ordinance that does not actually produce sounds, that does not produce fire
  - We’re going to put stuff in the ground that creates a huge cloud of dust, and we’re going to train you to react to that
  - Because we have found that dust is a more predictable and reliable indicator of when you should behave than the noise of an explosion or being able to see the fire
  - The noise could be coming from anywhere; it could be a false alarm
- Oftentimes it’s overwhelming
- It can be hard to tell where an audio stimuli is coming from
  - It can overwhelm you and kick in that “fight of flight instinct” that we’re trying to avoid
- A visual stimuli in this context is very recognizable

***The first thing the military does is they pay a lot of attention to cues, and they think really, really hard about that training***

- In Charles’ book, [*Smarter, Faster, Better*](https://www.amazon.com/Smarter-Faster-Better-Productive-Business/dp/081299339X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)*,* there’s a chapter about boot camp for Marines, and it’s probably the most scientifically well-fined tuned training you will find on Earth
- The Marines train hundreds of thousands of people every year

*The other thing that they pay a lot of attention to is how do we reward that behavior in a way that will make it automatic?*

- Charles mentioned that a habit is a cue, a routine, and a reward ‒ that’s known as the **“habit loop”**
- What happens in our brain to form that habit loop
- The basal ganglia’s job is essentially to make habits
- Because without those habits, we can’t evolve
  - We just spend too much time in cognition

A dramatically oversimplified explanation of habit formation:

- What the [basal ganglia](https://en.wikipedia.org/wiki/Basal_ganglia) helps encourage is it takes that cue, that routine, and that reward, and it puts them in a kind of circuit where the neural synapses connecting the behavior centers of those three items becomes thicker and thicker and thicker
- Which means that as a result, an electrical impulse can travel down that synapse faster
- Back to the military example: if I’m the general, my goal is to take these soldiers and to change their brain so that when they see smoke, they react immediately
  - Which is they pull out their gun, they look for the threat, they go through the mental checklist of, look for these 5 things
  - And then I **want to have a reward for them that’s predictable and consistent**
- In that situation, there’s not a natural reward; I have to create that reward
  - So one of the things that I do is I have them train as a unit, and as soon as they all take position, they all say to each other, “*Good job, good job. I’m in position. Good job, good job, good job*.” ‒ they’re all positively reinforcing each other
- That becomes a reward that can build this behavior, which is why looking at the unit or the platoon is so important in how we train soldiers is because ***oftentimes, the rewards that are reinforcing our habits are “social rewards” that we’re getting from other individuals***
- Let’s say it’s the first day they’re going through this drill and two of the guys fall out formation, they failed to get in position
  - The absence of being able to say good job, is that sufficient, or is there also a punishment of, “*Hey, you two guys, you were in the wrong spot. Let’s go do it again.*”

Drill sergeants have a certain reputation to uphold about yelling at people but it’s not really doing that much

- It’s helping people correct
- Instead of creating a wicked feedback system, it’s creating a good feedback system where I’m learning very quickly
  - It’s actually me seeking out that reward
- One of the things that you’ll find, if you look at surveys of why people fight, inevitably they will say, “*I joined because of patriotism, and I stayed in the military because of camaraderie.*”

***Because of camaraderie, because of the guys next to me. I couldn’t go home. I have to take care of them ‒ that’s really encouraged by the military and it becomes the dominant, overwhelming, positive reinforcement is that you act for your fellow soldiers***

- And when one of them turns to you and says, “*Good job, good job*,” what he’s really saying is, “*You helped protect me, and I’m going to help protect you*.” And that feels amazing.

**Can you instill this in anyone?**

Peter asks, “*When you think about the number of people that make it through the various forms of training, whether it be Marines, special forces elsewhere, etc., are they screening for the capacity to be able to form these habits, or is their point of view that we can basically instill this in anyone provided some basic set of criteria of aptitude or psychological wellbeing is present?*”

- It’s the latter

> “*The science tells us this is true, humans are habit machines. We literally have evolved a brain that is fantastic at making habits*.”‒ Charles Duhigg

- We literally have evolved a brain that is fantastic at making habits, and so we can take almost anyone, and we can teach them to be a good soldier
  - Assuming a baseline physical readiness and mental capacity
- Now, some people are going to be elite soldiers; some are going to become special forces
  - They might have an aptitude where they’re more comfortable with willpower
  - They’re more comfortable with grit
  - They’re more comfortable experiencing discomfort, and so they might be able to create habits faster
  - They might understand, it’s intuitively or through learning, how to affect their habits
- But we can do this with anyone
- Charles is curious, when someone comes to Peter, and they are showing a habitual behavior that you think is negative (that they want to erase, and you want to erase), “*Are there some people whom you believe it’s just not going to happen? I can’t help this person?*”
- Peter thinks this is an area where he personally doesn’t have enough expertise, and therefore he’d be hesitant to judge the success or lack thereof for a patient
  - He doesn’t think he’s a good enough coach

## Methods for creating good habits and eliminating bad ones: environmental control, small wins, rewards-based motivation, and more [A: 24:00, V: 24:36]

**The framework Peter uses when talking to patients about habits**

- Peter has a very, very basic framework on habit
  - Which is one of the reasons he’s excited about this discussion
  - He’s is looking to bring many more insights into what we do
- Broadly speaking, there are additive and subtractive habits
- 1 – So if you’re smoking, if you’re drinking too much, I want to take away something, a **habit of removal**
- 2 – Conversely, let’s say you don’t exercise at all or you barely exercise and we want to increase the amount of exercise you do, we want to add that thing in [**creating a habit**]
- Peter has 2 different strategies for how to do that
- For #2 [creating a habit], it comes down to **default environment manipulation**
  - If a person wants to eat less junk food, you have to actually take some pretty significant steps to reduce the amount of junk food that is around you
  - It sounds obvious, and sometimes it’s very difficult to do because if you don’t control your environment, it’s hard
  - If you do control your environment, it’s easier
  - If you’re in an intermediate state where you have kids and the kids eat a lot of junk food, but you don’t want to be eating the Mini Wheats all the time, then it gets a little tougher
  - But you can exert willpower for briefer stints, for example, when you’re at the grocery store and you have to make the decision of what to buy
- Taking an easy example: if you live alone, you’re a single person, you control the food environment in your house, and that might mean one hour a week you have to control your willpower when you’re in the grocery store
  - If you do that, it gives you the luxury of being surrounded by healthy choices for the other 167 hours a week
  - That willpower muscle, you can either use it for other things or you can relax
  - You just have to flex it briefly
- On the other end of the spectrum, and again, this has always been Peter’s way of doing things
  - He doesn’t think it’s unique because he’s read other people talk about the exact same idea
- When adding new habits with people, we tend to **start very small, and the win is basically defined by showing up**, not by any performance
- Peter recently had a discussion with a patient who said, “*I hate doing cardio, Peter. I love strength training. I love being in the gym, but this whole Zone 2 thing you want me to do, it’s so painful.*”
  - The patient said, “*But Peter, you’ve convinced me. I know I need to do this. I just don’t want to.*”
  - Peter said, “*No problem. All I want you to do this week is three 15 minute sessions on a stationary bike. I don’t actually care how many watts you’re pushing. I don’t want you to wear a heart rate monitor. I don’t want to track anything other than time. Can you get on for 15 minutes? I want you to pick your favorite podcast… and even if at the end of 15 minutes you want to ride more, don’t. Just get off. I want you to do that three times, and then let’s discuss that in a month*.”
    - This tends to be a productive way to do it
    - Then you can start to increase the duration and add other parameters around performance
    - But if you try to go from nothing to 4 hours of Zone 2 a week, it’s not going to work
- There’s a researcher, [Katie Milkman](https://oid.wharton.upenn.edu/profile/kmilkman/) at Wharton University of Pennsylvania who studied this quite extensively: **How do we link a reward to the behavior so that you’re experiencing the reward during the behavior?**
- She uses audiobooks much like Peter uses podcasts
  - And when she was doing this research, it was right when [*Harry Potter*](https://en.wikipedia.org/wiki/Harry_Potter) had come out
  - She loves Harry Potter, and so she made a rule: she can only listen to the Harry Potter audiobook when she’s on the stationary bike
  - She found that it just completely transformed her attitude towards doing this behavior that she previously really did not like
- Peter has 2 or 3 podcasts that he’s addicted to and he only listens to them when he’s doing Zone 2 training indoors
  - He looks forward to listening to these podcasts even where he really doesn’t feel like getting on a stationary bike
- Charles’s guess is that in addition to giving yourself a reward during that behavior, you’re also rewarding yourself afterwards
- For Peter, the reward after is the feeling

**How this pertains to exercise**

- [Anna Lembke](https://profiles.stanford.edu/anna-lembke) talks about how, for many people, the discomfort of exercise creates that imbalance in dopamine homeostasis, such that post-exercise, many of us experience that subtle shift where we actually have, if not a euphoria, certainly a better feeling
- For Peter, no matter how lousy he feels or how uninterested he is (and it’s usually that he’s just too busy and wants to do work for another hour) he knows that he’s getting this reward after of how he feels

> “*What’s interesting is what the research tells us that’s very real, that runner’s high is a real thing*.”‒ Charles Duhigg

- Anyone who once didn’t exercise and now does exercise, who’s listening knows this intuitively: the first couple of times that we tell someone to exercise, they do not anticipate the runner’s high and as a result, it’s a difficult motivating factor
- Charles’ mom hates exercise, and he always says, “*You’re going to feel so good afterwards.*”
- She says, “*You know what? I just don’t feel good afterwards.*”
  - Now, she actually does feel good afterwards, but she tends to forget it
  - She engages in [hyperbolic discounting](https://en.wikipedia.org/wiki/Hyperbolic_discounting) very actively around this positive reward
- One of the things that happens when we start exercising is that we convince ourselves that we’re going to feel better afterwards
- An **extrinsic reward**, like giving myself a nice smoothie, congratulating me, calling Peter, and he tells me you did such a good job for getting on the bike three times this week
- That external reward moves to an **internal reward** where it’s the feeling of accomplishment, and it’s the runner’s high, the euphoria that I’m getting that motivates my behavior

***But I have to learn the value of that intrinsic reward because you usually can’t convince me of it without me having experienced it***

**Are there attributes of these people that would allow you to predict who is more likely to be successful in forming a new habit?**

- If you were to consider a group of 10 individuals who are similar in most observable ways externally
- You want all of them to create a new habit in a domain that is entirely foreign to them

*Does* ***willpower****, which might form the basis of the initial activation energy (for lack of a better word), getting over that hump the first few times, does that factor into it?*

- (truthfully, Peter doesn’t understand the science of willpower)
- There are certainly behavioral characteristics that make it easier for some people to understand how to change their habits and adopt new habits
- There does not seem to be a great deal of evidence that there’s genetic reasons to predict that
  - Some researchers will say there are slight genetic variations
  - We think that some people are more prone to willpower than others are, but it’s so small and insignificant in comparison with the behavioral training that you have
    - The environment that you’ve grown up in
  - Low heritability
- If you have parents who teach you willpower habits
- If you’re someone who is an athlete, and so you have a team that’s taught you how to push yourself a little bit harder when pushing yourself is hard, you already have an intuitive sense of how to adjust your own habits

**⇒** As a result, if you’re in a room with someone who has none of that background, they’ve never played on a team sport, their parents let them do whatever they wanted, it’s going to take me longer to change that second person’s habits because I’m going to have to train them more, and the training just takes time

***Success in forming new habits has low heritability but high environmental and behavioral exposure as a child***

## How parents can teach kids to build habits and strengthen willpower [A: 32:15, V: 33:45]

**What do those of us with young kids need to do to enable our kids to become the type of adults who can make behavior changes and create better habits?**

> “*The single most powerful thing we can do is we can teach them how willpower works and to build willpower habits, because a willpower habit actually doesn’t tax the metaphor of the muscle (willpower muscle) that exists inside our head*.”‒ Charles Duhigg

- Angela Duckworth has done a lot of research on this
  - Many listeners are familiar with because of [Grit](https://www.amazon.com/Grit-Passion-Perseverance-Angela-Duckworth/dp/1501111108)

***One of the things that’s really powerful is to explain and demonstrate to kids how to diagnose the habit loop (cue, routine, and reward) so that they can begin editing their own habits***

- Charles has a 14-year-old and a 17-year-old, and one of the things that he does is he’s very ostentatious in how he rewards himself for hard behavior
  - This is actually kind of counterintuitive because we’re dads ‒ we’re supposed to be stoic
  - We go out, and we run a half-marathon, and it’s no big deal
- He does the opposite: he goes out for a 4-5 mile run, comes home, and says to the kids, “*Oh man. That was a hard run, but I pushed through it. Now you know what I’m going to do? I’m going to have this really yummy smoothie I’ve been looking forward to. For the next 15 or 20 minutes, I’m just going to lay on the couch and enjoy myself because I feel so good right now.*”

***What he’s trying to model for himself is giving yourself a reward***

**⇒** Focusing on that reward is a powerful way to reinforce or change your own behavior

- He’ll do the same thing with cues
- Oftentimes, some of the cues he uses for exercise or for other things aren’t visible to his children
  - Because he’s putting my running shoes next to his bed so he sees them when he wakes up in the morning, and they don’t understand the significance of that
  - Or he’s engaged in a ritual before he starts writing that they don’t see
- So he will be very explicit with them and say, “*I need to start writing in 15 minutes. Here’s what I’m going to do for the next 15 minutes to get ready for that*.”

***He’s teaching them, think about the cues in your life, think about the rewards in your life ‒ if you focus on those 2 things, you can create almost any routine, any behavior that you want or change any behavior that you want***

## How adults experience changes in motivation and cue effectiveness over time, and why willpower must be managed like a finite resource [A: 34:30, V: 36:09]

**Peter’s insights**

- The cues in that sense are just as important for the positive behaviors as the negatives
- Many of us probably associate cues with negative, meaning be aware of the cue
  - If I’m trying to quit smoking, what’s my cue to smoke?
  - How do I need to spot it in advance?
- It’s funny, Peter doesn’t know that he really thinks of cues on his positive behaviors
  - He knows they’re there, he’s just now even aware

Charles asks, “*What do you do before you work out?*”

- Make an electrolyte drink
- Okay, so that’s a proceeding behavior.
  - It’s a ritualized behavior that’s become a cue for you
  - It’s not a negative cue
- Does it feel like a little sense of anticipation as you’re making it like, I’m going to go work out?

Peter explains, “*No, because interestingly, and people will be so surprised to know this about me, but at least for the past year or two, I feel I’m so busy that I don’t have the desire to work out until I’m in the gym… Or on the bike.*”

- It used to be that Peter couldn’t wait to work out, but something has happened in the last 2 years where he really has to kick himself into the gym
- Once he’s 15 minutes in, he feels great, and he’s delighted to be there (there’s nowhere he’d rather be)
- But the 15 minutes before he goes into the gym, which includes making that drink, extracting himself away from my computer and doing his warmup ‒ that is actually, it feels like pure willpower
  - He benefits from enough muscle memory of doing this his whole life

*Charles posits a hypothesis*

- That preceding behavior of making the electrolyte drink and doing the stretches, that was a very ineffective cue at one point in your life, and the effectiveness of that cue has diminished over time
- But you found other cues, which is that one of it might just be a sense of anticipation that you’re going to feel good after 15 minutes
- It might also be that you know that you’re going to listen to a podcast
  - The cue of hitting start on the podcast is what gets your head in that place where you can start exercising and then experiencing…
  - Peter only listens to a podcast for Zone 2 training
    - He can’t lift weights and concentrate on something else, so he listens to music which doesn’t get him excited

***Charles observes: that would suggest you are using more willpower in the gym, because that muscle (like all muscles) gets stronger the more we practice using it, but it also gets fatigued in the short term***

- This in an inexact metaphor, but we can think of willpower as a muscle
- This is why if you look at data on **when accidents happen in surgery**, they most often happen when a surgeon has been either in his/her second or third surgery or when it’s a very long surgery
  - They’ve been using their willpower for so long, they get fatigued
- If you look at the number of **affairs** that happen among lawyers and doctors, they most often happen when someone has been at the office after 9:00 or 9:30
  - For years people thought, oh, you get to the evening and it’s kind of romantic
  - No, it’s that after 9 or 10 hours of exerting your willpower in your office, your guard is down, your muscle is weaker
  - So when someone comes up and they kiss you, instead of pushing them away, you kiss them back

***Thinking about our willpower muscle, both strengthening it but also protecting it when we need it (recognizing when you’re vulnerable), is critical to being able to be the people that we want to be***

- Peter relates this to being vulnerable to falls

## Keys to successful habit change: planning for relapse, learning from failure, and leveraging social support [A: 38:00, V: 40:05]

**A less extreme example: I want to stop smoking**

- [James Prochaska](https://en.wikipedia.org/wiki/James_O._Prochaska) at the University of Rhode Island has spent his whole career studying smoking cessation
- The data that we have on smoking cessation is enormous, it vastly outpaces almost everything else

**⇒** [Nicotine](https://en.wikipedia.org/wiki/Nicotine), as you know, is an addictive substance, but we’re only addicted to nicotine for about 100 hours after our last cigarette [about 4 days]

- By that point, nicotine is out of our bloodstream
  - Peter didn’t know this, that 4 days after you smoked your last cigarette (or had your last exposure to nicotine), you no longer have a physiologic  need for nicotine
- We don’t have a physical dependency on nicotine, and yet we all know people who smoked for years, quit, and they crave a cigarette a decade later after they have breakfast in the morning

***You still have the cue and you remember the reward ‒*** ***the habit loop still exists in your brain***

- If you have a cigarette with every morning cup of coffee, as soon as you pick up that cup of coffee, your brain is craving that nicotine
- That feels just like an addiction, a physical addiction
- In fact, it’s in some ways more powerful than a physical addiction
- What Prochaska did is he looked at how people quit smoking, and this gets to the point Peter was raising before about learning

**⇒** Prochaska found that on average a smoker needs to quit 7 times in order to actually quit

- A committed smoker, somebody who’s been smoking for years, they will give up cigarettes 7 times before it actually works
- Which raises this interesting question: What is happening in those 7 times?
  - Why 7 instead of 4? What’s happening?

*This first time you give up smoking*

- Research tells us that the first time you give up cigarettes, you focus on **willpower**
  - You say, “*I’m going to resist these cigarettes. I’m throwing them out. I’m going to change my environment a little bit.*”
- But all those cues are still there, the craving for the reward is still there, and when my willpower gets taxed
  - My mother-in-law comes to town
  - I’ve had a really tough day at work
- ***When my willpower muscle has been exercised all day, that’s the moment that I give in*** and I pick up a cigarette and I say, “*To hell with it, I’m going to start smoking again.*”

Peter asks, “*Just to be clear, what happens when you have that first cigarette? Why can you not on that first cigarette go, ‘Hey, it was just a lapse. I’m exhausted. Tomorrow’s a new day’?*”

- It’s because you don’t have a plan
- You’re caught off guard by this relapse, and as a result it tends to shake our faith in ourselves, even if it’s almost subconscious
  - It tends to shake our faith in ourselves that we can’t quit
- Now, that’s the first time

*How Peter talks about this with patients*

- Often he’s not dealing with something that’s as binary as smoking
- Let’s just say it’s exercise: we’ve set a plan that you’re going to do something for 30 minutes every day, and then you’re going to have that day when you don’t

***What we tend to spend a lot of time coaching on is absolutely positively under no circumstance do you judge yourself for that day ‒ the next day, just get back on the horse and don’t let 1 bad day be 2, and then it’s fine***

- What we see is a lot of times a person will go 6 days of their routine, they miss a day, they beat themselves up, and then they’re done
  - They’re like, “*Well, forget it. I screwed up*.”
- It can happen in the reverse

*Charles explains why this makes sense*

- We’re talking about rewards, positive rewards and negative rewards
- I miss a day and I start beating up on myself, I’m flooding my brain with **negative rewards**, with recriminations, with feelings of shame

***My brain pays attention to what gives me positive rewards and negative rewards, and it’s saying, “This exercise thing, it’s a sucker’s game, because even if I feel good for a couple of days… I’m going to feel terrible when I miss it.”***

Charles agrees with Peter, “*You cannot engage in that self-blame.*”

- This poor smoker, his mother-in-law who nags him comes into town; his willpower is exhausted after dealing with her all day
  - He sneaks outside in shame and lights up
- You do that once, you do that twice, you do it 3 times

**What’s happening around the 3rd or 4th time someone gives up smoking**

- (this is what gets to your exerciser as well)
- Suddenly people stop looking at it as a moral lapse and they start looking at it as a scientific experiment
  - Okay, here’s the data that I’ve observed
  - I do a pretty good job of avoiding cigarettes until something really stressful happens

***I need to, ahead of time, figure out when that stressful thing occurs, what am I going to do instead of smoking?***

- Because if I don’t have a plan in place (what’s known as an **implementation intention**), I’m going to pick up the cigarettes
- Here’s my plan: instead of beating up on myself, I’m going to **write down** that the next time my mother-in-law comes to town, I am going to have some sweet candy in the house (because I know I’m going to have an urge to put something in my mouth), I’m going to want some type of quick boost reward, and sugar can provide that to me (the novelty of taste)
  - I’m going to have that candy in my house, and when she’s driving me crazy, I’m going to walk over, pick up a piece of candy, and go outside and eat it

Charles explains, “*The reason why it takes 7 times to quit smoking or the reason why your clients and your patients have these moments of willpower failure, is because instead of looking at that as a failure, we have to look at ourselves as scientists who are conducting experiments and paying attention to the data.*”

- Charles’ wife is a scientist, so he knows that if every experiment that a scientist does succeeds, they’re a terrible scientist

***The goal is to figure out where it succeeds and where it fails and learn from the failures ‒ we have to look at our own lives that same way***

- We have to say, “*I meant to go run today and I didn’t. Let me try and figure out why and then I’ll come up with a plan for the next time. Next time this obstacle emerges, I know what to do without having to worry about it.*”

**Do you think people are able to do that on their own, or is this the enormous opportunity to coach a person through that (to create an accountability partner)?**

- The coach wants to hear about it when you fail just as much as when you succeed
- When you fail, they’re going to direct all of the inquiry towards, “*What did you learn?*”
- Right, this is incredibly powerful because it’s going to speed up that feedback loop

**There are people who quit smoking on their own without ever talking to another person about quitting smoking**

- They’re absolutely the outliers, and it’s taking them longer to actually quit than someone who takes advantage of the **social aspect of habit formation**
  - Where I know that I can get rewards and I can get learnings from other people in my life more effectively than I can find it in myself

**Take alcohol as an example**

- AA is such a well-studied and interesting model
- There are lots of people who engage in what’s known as “spontaneous recovery” where they will try and quit drinking and they’ll relapse ‒ eventually, they stop drinking

**⇒** But people who engage in AA, because it’s basically habit replacement, those people end up quitting drinking much faster

- We all have the capacity to do this on our own

***When we do it in an environment where we know that we’re taking advantage of the cues and rewards that makes the behavior change easier, it goes faster and it feels better***

*What is the overall success of AA for alcohol abstinence?*

- Peter points out that AA does not support harm reduction ‒ it’s really about abstinence
- Charles doesn’t know
- AA is very extensively studied, but because it’s anonymous, we don’t have double-blind studies
  - We don’t have a lot of longitudinal data

***That being said, the estimates seem to be that for about 40% of people who come into AA, they can achieve lifelong abstinence (if that’s their goal)***

- 40% isn’t great, that still means 60% of people [continue drinking], but it’s pretty good for behavior change

**⇒** What’s interesting about AA (much like the military) is it’s built around asking people to **identify the cues and rewards in their life**, and then changing the behavior that corresponds that old cue by **finding a new behavior** that delivers something similar to that old reward

- The reason why there’s 10 principles of AA is because there’s 10 commandments in the Bible
- [Bill W](https://en.wikipedia.org/wiki/Bill_W.) (the guy who came up with AA) had no training in psychology or science whatsoever
- The thing that makes AA successful is that when you walk in, you stand up and you say, “*My name is Charles and I’m an alcoholic.*”
  - Then at some point you tell your story

***When you’re telling your story, you’re reminding yourself of all the cues that prompt you to drink***

- One of the steps is to make amends
  - I go to all the people that I’ve wronged, and that teaches me what those cues are

Charles explains, “*I’m learning, I’m looking at my life as a scientist.*”

- Oftentimes the reward for drinking is a relaxed socialized experience
  - So when you go to an AA meeting, you have a relaxed socialized experience, absent alcohol, but you’re talking to other people, you’re communing with other people
  - The same thing you get at a bar
  - AA is a habit change machine that doesn’t have to express itself that way
- Peter doesn’t know much about AA, but the little bit he knows suggest that people go for life
  - They might not go as frequently
  - He knows people that have been sober for 20 years that are still going to a meeting twice a week
- Oftentimes people will develop a habitualized behavior around AA and they keep up with that habit for life
  - Just as frequent, and actually more frequent, is that people will commit to AA, they say 90 meetings in 90 days
  - They’ll commit to AA at the beginning and then it will taper down over time
  - They’ll start going to one meeting a week and then one meeting a month, and then they move to a new place and they don’t know where the new meeting is

***What they have learned is when I’m in that moment where I think I’m going to relapse, where my willpower muscle seems tired, where the cues around me are prompting me to drink, I’m going to go to a meeting instead of go to a bar***

- Even if I’m not going to AA consistently, if it’s ingrained in my psychology as a way to avoid drinking, it’s very, very powerful and I can activate that anytime in life

## Advice for parents: praise effort, model habits, and normalize failure [A: 47:45, V: 51:16]

- Peter assumes that a lot of these seeds are sown in how we’re raised
- Peter thinks Charles’ kids are getting a master class because they’ve got a parent who’s one of the world’s experts in it
  - Charles adds, “*They would say I’m a little heavy-handed, but thank you for that.*”
- People always ask Peter, “*What do you want for your kids?*”
  - He doesn’t have any aspiration for what he wants them to be professionally

***You want your kids to be well-adjusted and happy, but it’s hard to imagine them doing that if they don’t have some command and control over themselves***

- You could argue that this is one of the most important things that we want our kids to have, and yet Peter doesn’t feel like we have any adequacy in the training for it

**This is one of the reasons why Charles wrote** [***The Power of Habit***](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)

- He wanted to empower parents to teach their own kids this, to recognize things in their own life
- A number of us understand some aspect of this intuitively
- A lot has been written about the “growth mindset,” [Carol Dweck’s](https://profiles.stanford.edu/carol-dweck) work out of Stanford [she wrote [*Mindset*](https://www.amazon.com/Mindset-Psychology-Carol-S-Dweck/dp/1400062756/ref=tmm_hrd_swatch_0)]
- One of the things that she emphasizes is teaching children a **sense of agency**
  - That when you bring home an A on your report card, instead of saying, “*Oh, you’re so smart,*” which is something you don’t have control over, to say, “*Oh, you must have worked really, really hard*,” because that’s something you do have control over them
  - Reinforcing their sense of agency

***When we do that intuitively or deliberately, one of the things that we’re doing is we’re teaching our children that they have control over their habits***

- You went and you worked really hard to get that A, you developed a habit of studying, you used your willpower

***Parents can positively reinforce that by recognizing it***

- Whereas if you say, “*You must be really smart, you got that A*,” you’re not positively reinforcing your belief that you can change your behavior

Charles explains, “*In addition to explaining to kids and being ostentatious, showing off the cues and rewards in our own life and how we change our own habits, the way that we give rewards to our children also reinforces for them whether they believe that they are in control of their willpower or not*.”

**The other side of that is how do we handle our own failures in front of them?**

- Do we even admit our own failures?
  - There’s a model of fatherhood from the 1950s that you don’t burden your family with your ups and downs ‒ Dad’s a steady rock

***All the research tells us one of the best things you can do is if you screwed up, [is to talk about it and what you learned]***

- Charles tries to do this all the time, he comes home and is like, “*Oh man, I called this guy today and I just completely screwed up this interview*,”
  - Because he wants them to know
- Then he says, “*But the thing I realized from it is that next time I call, I need to have something to eat before I call because that’s going to help me*.”

> “*I’m modeling for them a failure is not a failure. A failure is a data point and I’m a scientist about my own life.*”‒ Charles Duhigg

## The time required for making or breaking a habit [A: 50:45, V: 54:45]

**What do we know about the length of time or the amount of friction it takes to create a habit and the difficulty in breaking it?**

- For example, if it takes a long time to really create a habit around exercise or meditation
  - Let’s pick something new, not an easy thing to do, but let’s say over years and years and years, you take a lot of time to build that muscle memory up
- Peter assumes that’s creating some sort of physiologic headroom that makes it much harder for you to erode that down
- Yes, Charles agrees
- What’s happening when you’re meditating is there’s these **neural pathways** that connect (the synapses associated with the cue and the routine and the reward), and they’re becoming thicker and thicker and thicker over time

**⇒** What’s interesting is they almost never become significantly thinner

- So if you develop a meditation habit and then you stop meditating, your life changes, the cues
- When you come back to meditation, you will fall back into it much more quickly than the average person

Charles explains, “*We know that creating habits (both good and bad) creates this neural pathway that we need to be conscious of.*”

***But to your question of how long does it take, the answer is we actually don’t know***

- There’s this myth, this old wives’ tale that it takes 21 days to build a habit and it takes 30 days to break a habit

***Research tells us that there is no number because different people have different thresholds and different kinds of habits have different timelines associated with them***

- If you want to create a habit of eating chocolate, you can probably do it in a couple of days
  - It’s an immediate positive response if you like chocolate, it’s something you enjoy, the cues are plentiful around you, you just put chocolate bars in your house
- But if you want to build an exercise habit, it’s going to take a little bit longer

**⇒** Here’s the important thing, regardless of how long it takes to build that habit or change a habit, every day you do it, it will get a little bit easier

- You might not feel that increase in ease the first couple of days, but what’s going to happen is I’m going to push myself to exercise day 1, day 2, day 3, I’m going to relapse on day 4 (I’m going to not do it), but instead of beating up on myself, I’m going to look for the science
  - What went wrong here?
  - What’s my plan for next time?
- Then I get to day 12, or I get to day 20, or I get to day 365, and it occurs to me, exercising is really easy for me now
  - I hardly even think about it
  - It just happens almost automatically

**What about the negatives? Is someone who has been smoking a pack a day for 20 years going to have a harder time quitting compared to someone who has been smoking a pack a day for 1 year?**

- Probably, because it’s a much more ingrained behavior
- But this is where **individual differences** come into play significantly, because if the person who’s been smoking for 1 year, if they’re an athlete, if they’ve worked on other habits in their life, if they’ve **strengthened that muscle around habit change**, they might be able to rely on that to give up smoking
  - Whereas the 20-year smoker doesn’t

***But in general, the longer and more consistent a behavior becomes, the more reinforced it becomes in our brain***

**Let’s assume both of these individuals are able to quit smoking, it’s 5 years later, and both of them are at a bar and they both light up a cigarette. Are they both equally susceptible to relapse or is the 20-year person more susceptible because his neural connections are more hardwired?**

- There’s a lot of compounding factors there
- So when the 20-year smoker lights up his cigarette, we’re focusing on the habit loop associated with nicotine use, but there’s probably other habit loops that he has developed over time
  - Which is he might feel a much more intense sense of shame over smoking than the one-year smoker
  - He might have emphysema or developing health problems, and those are creating mental habits for him that are countervailing the positive reinforcement of the nicotine
- The answer to your question is it’s really hard to say universally

***What we do know is that the more consistent a reward (whether it’s a reward that rewards a positive behavior or a negative behavior, the more consistent that reward and the more consistent that cue), the faster the habit will take hold and the stronger the grip it’ll have on us***

- But when we’re trying to change it or create a new habit, there’s so many other variables that we can’t predict how long it’s going to take, but we do know that any habit can be changed

## The different strategies for creating new habits vs. changing existing ones, and the crucial role of cues and reward timing [A: 55:15, V: 1:07:15]

**Is there a rule of thumb that says, on average, it is more or less difficult to break habits than to create habits?**

- The science doesn’t address that question

**What we do know is that it takes a different technique to build a new habit than to change an old habit**

- If I want to build a new habit, if I want to start running, what I need to do:
- 1 – I need to sit down, come up with a cue
- **All cues fall into one of 5 categories**
  - 1 – Time of day
  - 2 – A particular place or environment
  - 3 – A certain emotion you feel
  - 4 – The presence of certain other people
  - 5 – It’s the preceding behavior that’s become ritualized
- 2 – Come up with a reward

*For example*

- If I want to start running, and I’ve never run before; I’m going to take advantage of as many of those as I can
- My plan is set my alarm for 7:00
- I want to be out the door by 7:30 running
- I’m going to put my running shoes and my running clothes on my floor next to my bed so I see them when I wake up
  - It’s super easy to put them on; I know what I’m going to wear
- I’m going to ask my friend Jim to meet me on the corner, we’re going to run together
- I’m creating as many cues as I can

***If you can tap into all 5 cues, you’re in the money***

- Some of them are going to stick
- Then when I get home, I have already decided what **reward** I’m going to give myself
  - I’m going to have a nice long shower, I’m going to drink a smoothie, I’m going to take 15 minutes to check social media or whatever else delights me

***That’s how we build a new habit: we choose a cue and we choose a reward and we link it to a behavior we want to encourage***

**For a bad habit, a habit that we want to extinguish, our nomenclature is incorrect**

- We often talk about breaking a bad habit, but because that neural pathway exists in our brain, I’ve smoked for 20 years, I can’t just extinguish those neural connections

*What I need to do is instead of thinking about breaking that habit or extinguishing it, I have to think about changing that habit*

- In that case, what I do is I **identify the cue** that prompts this behavior I want to change
- I **identify the reward** that that behavior is giving me

Charles explains, “*I’m going to simply insert a new behavior that corresponds to that old cue that delivers something similar to that old reward, and I’m going to let my brain eventually shift, keep the habit loop inside my head, but change the behavior, the routine.*”

- Peter loves this framework

**Peter’s takeaway on how to create a new habit**

- This has so much applicability, wanting to do something new
- You’ve identified what the behavior is, that’s the thing
- The playbook is pretty straightforward
- 1 – I’ve got to come up with as many cues as possible
  - If I’m going to do single cue, it’s not that likely I’ll succeed out of the gate
  - But boy, you get 5 of them, 4 out of 5 of them, it’s great
  - Obviously, some of them are more than others

Peter adds, “*I know for our patients, the cues that tend to be very powerful are other people. People never want to let people down, so we always think that one of the most powerful cues is an accountability partner. Sometimes we have people that literally hire trainers for the sole purpose that they don’t want to be embarrassed that they’ve not shown up. It’s the only reason for having-*”

- This describes Charles
- Play around with the different cues and figure out which ones work for you

**Then how do you help a person think about how to gauge the magnitude of the reward?**

- Here’s an area where you could get a little extreme
- Peter is not going to embarrass himself with examples of things he’s done in this department, but his wife could tell stories of how he can reward himself at times

The first thing to do is to say, “*I have to give myself a reward*,” which is actually harder than it sounds

- So if you think about how most people start exercising, instead of having a reward like, I’m going to take a nice shower or I’m going to drink smoothie
- They go for a run and they get home and they’re late
  - Now I’m rushing
  - I’m taking as quick a shower as I can because I’ve got to throw breakfast on the table for the kids and I’m running late to take them to school

***I’m actually punishing myself for exercising, and my brain pays attention to that punishment and says, “I don’t want to exercise anymore. This is a sucker’s game.”***

Charles explains, “*The first and most important step is to actually recognize, I have to reward myself, and I have to create the time or the space or the resources to let myself have that reward and enjoy that reward.*”

The next question that you asked, how big should it be?

- One of the things that we know is that one of the most powerful impacts on this is **how immediate that reward is**
- In general, if I give myself a reward right away, if I eat sugar and it tastes good, it gives me that boost as soon as it hits my tongue, that’s going to be a more powerful reinforcement than if it’s something where I’m working out every day and 3 weeks from now my muscles are going to be stronger

***The more immediate we can make the reward at first, the better***

- We can oftentimes have a smaller reward if it happens quickly than having to have a bigger reward that comes later in time

A really important point

- What happens with rewards is, if a behavior becomes a habit, they almost always move from extrinsic to intrinsic [reward]
- At first, the reward I’m giving myself is I’m letting myself have a smoothie, and that smoothie might not be that healthy
  - Peter is very curious about this smoothie, Charles brings it up a lot
  - Is there something going on in Santa Cruz?
  - Charles loves smoothies; he puts peanut butter in his smoothie and it erases all the healthiness (because he already has protein powder in it and doesn’t need any more protein)
    - But he’s increasing the magnitude of the reward

***Over time, what’s going to happen is your craving for that smoothie is going to go down as your brain begins to realize, “Oh, actually when I run, I feel great afterwards.”***

- I feel endorphins, I feel dopamine, I feel these endocannabinoids ‒ there’s this super good feeling in my head
- Your brain starts saying, “*I don’t actually need the smoothie. I don’t crave the smoothie quite as much. I don’t need that smoothie because I just feel good afterwards. That’s the reward.*”

**⇒** The reward has moved from extrinsic to intrinsic, and that’s a really important transition because that means the behavior becomes self-reinforcing without external rewards

- The smoothie kind of makes sense after the run because you are glycogen depleted ‒ that’s the perfect time to have a smoothie
  - You’re most insulin sensitive, you actually can dispose of glucose the most easiest

## How to create habits around long-term goals when the rewards are delayed (like saving money) [A: 1:01:45, V: 1:17:54]

**I’m 3 years out of college, and I technically make enough money that I could start putting money into my 401K**

- I just don’t want to
- I know my employer matches, and I know that it’s leveraged dollars, and I know all the intellectual reasons why
  - It’s going to pay off in 40 years
- But the truth of the matter is, if I start putting money into this 401K, I have less money to buy things now

***It’s hard for me to get excited about 40 years from now***

*How would you coach me into making that decision, especially around the cues and the rewards?*

- There’s been a bunch of research on this, particularly out of researchers at University of Pennsylvania Wharton
- What they did is they went into a series of communities in South America, they asked this exact question, “*How do we get people to save more, increase their savings rates, when we know that the reward for savings is oftentimes far off in the distance, particularly if you’re low-income?*”
  - The reason why they were in South America is because they wanted people who are in a cash-based economy, where there wasn’t a lot of credit cards
- They had 2 groups
- A **control group** ‒ they set up a box for them that they could put savings into
  - They said, “*We’d like you once a week to come in and save some money. By the way, we’re going to tell you all there were good reasons to save. You should save because eventually you want to send your kids to college or you want to buy that new truck, and we’re going to help you. We’re going to help you. We’re going to have a saving device for you.*”
- The **experimental group**, they do the exact same thing, except there is a secretary who works in that bank who every single time someone comes in and they put money into that box
  - They say, “*Man, this is the fourth week in a row you’ve come in. I’m so impressed to see you. Your kids are going to go to college, they’re going to be amazing kids. I just think about someday in the future, they’re going to buy you a new home. You are a great parent*.”
- Results: in the experimental group, the savings rate went up over 40%
  - They were saving 40% more money than the first group

**⇒** There was not a bigger payoff, simply someone positively reinforcing

***What happened there? It’s a long-term behavior, but we need short-term rewards***

- The researchers were manufacturing a short-term reward in the form of **social reinforcement**

*Peter proposes adding another group to this experiment*

- Add a **third group** that gets the same reinforcement for a period of time, and then the secretary goes away after X number of months to see if the shift from extrinsic to intrinsic maintains the same savings rate?

**What is the period of time that you need to remove the extrinsic reward and make it intrinsic?**

- Charles thinks it would probably depend on the type of habit we’re talking about and the type of individual

***There’s not one answer***

- We do know that at some point it will move from extrinsic to intrinsic

**⇒** One of the things we do know is that **social rewards** actually become intrinsic much faster

- If I start working out, and I know that Peter’s going to tell me I’m doing a great job and I look forward to that, eventually that sense of pride that I feel, I’m just going to get it without you having to tell me I’m doing a great job
- Social reinforcement, social rewards, a sense of pride, particularly mental habits become intrinsic much, much faster

***That’s something we can leverage ‒ we can use those social rewards to move extrinsic to intrinsic***

**What other ways are there besides social reinforcement to reward very long-term behaviors like savings?**

- Charles has used a spreadsheet for 7-8 years now
  - He uses websites that consolidate all of his financial information (Simplifi, Ming, Vanguard)
  - Once a week, he updates his spreadsheet ‒ it takes about 15 minutes
  - He creates a brand new set for this week, inputs all the numbers: his bank balance, his Vanguard balance, his private equity balance
  - Then he looks at whether it’s gone up or down

Charles shares, “*I love it. I look forward to this*.”

- Peter points out: but many times it’s going down because you’re based on the stock market
- When it’s going down, Charles tends not to do this because he doesn’t want to be reminded of it
  - He’ll wait another 4 or 5 days

Peter asks, “*What is the frequency at which you save money? Do you have an automatic every one week or every month, I am automatically, mindlessly, without thinking about it putting X dollars into-*”

- Any new money that comes in goes immediately into his Vanguard account, and he’s never taken money out of that account

**What is it specifically, Charles, that you are getting rewarded by if the number isn’t monotonically going up? What is giving you the joy?**

- Charles feels a real sense of responsibility and a relief from tension

***We mentioned before that one of the most powerful rewards is relieving tension***

- I put you in the box and I tell you, “*If you give me information, you can come out of the box. I’ll remove the tension.*”
- For Charles, when he went to [HBS](https://www.hbs.edu/) and he became a journalist, he was the lowest paid member of his class for the next 7 years
- Charles started a company before he became a journalist
- He used to sell blood in order to make payroll

Charles shares, “*Money insecurity for me is a real thing. To look at that spreadsheet and say, ‘Oh, it went down by 2% this month, but it’s okay because that number in the bottom is still big enough that I don’t have to worry,’ that relief of tension is enough of a positive reinforcement to make saving a really positive experience for me*.”

The other thing Charles does in that spreadsheet

- He tracks: how much money he made in the last year
  - How much money he made in the last 2 years
  - How much money he made in the last 3 years
- He has those numbers right next to what his total net worth is
  - Because even if his net worth goes down this week because the market took a tumble, those numbers, 1, 2, 3 years ‒ those are still positive
  - He just looks at those and thinks, “*I made that much in 3 years.*”

**Do you play other scenarios forward like, and this is how much money I’m saving for being able to help my kids go to college or one of these other activities?**

*Or do you start to reverse engineer, and at this rate, I will be able to work for free, I’ll be able to do whatever I want work-wise and not be dependent on a paycheck by age X?*

***That’s exactly right, Charles is creating anticipation for future rewards ‒ it’s very intrinsic, and it’s surprisingly powerful***

**Do you remember the first extrinsic thing you had to do?**

*Was the spreadsheet exercise sufficient initially as the sole extrinsic motivator?*

- That’s a good question; Charles has to think back because it’s been so long now
- It was for Peter
  - He’s a spreadsheet junkie
- He remembers as he was finishing medical school and starting residency, his first real paycheck
- He was making $32,000 (it’s not like you were rolling in money), but he remembers doing the math and Hopkins was going to match his 403B (it’s the same as a 401K)
  - He remembers thinking, “*It’s free money, you’ve got to take it*.”
- It became a game to him (he gamified it) ‒ how little he could spend
  - It was a little embarrassing
  - He technically didn’t need to spend money on food because he could eat all the crap in the hospital for free
  - He didn’t actually have to buy clothes because he could be in scrubs 24/7
- He had this huge budget that he would line item
  - Repayment of student loan
  - Truck loan
  - Rend
  - It was relatively finite
- Most of his discretionary money could go into savings
- He made that spreadsheet and he obsessed over it
- It’s interesting that Charles says he was the same way
- Charles loves that Peter just said, “*I gamified it.*”

> “*The way games work is that it delivers rewards to us. That’s why we play a game. It has a reward schedule.*”‒ Charles Duhigg

- The way Peter gamified it, is he came up with a spreadsheet
  - Because you can’t play a game without a game board
  - You need some way of keeping track of whether you’re winning or losing
  - You created for yourself a game board where you could gamify savings
- Peter never thought of it that way
- He assumes people have already figured out a way to do this for young people
- There must be someone out there who is cracked the code on gamifying savings
  - If so, Charles has not found them
  - There’s a lot of companies trying

Charles explains, “*I think the reason why it was so powerful for us is because we felt a sense of agency and choice over it. We came up with this model. We thought about what works for us. And even though we were both using spreadsheets, I’ll bet you our spreadsheets were pretty different.*”

- They were probably measuring different things
  - Investing in different things
  - Getting rewards from different things
- Charles was focused on returns while Peter was return-agnostic
  - Peter was focused on contribution (how big he could make that number)
  - What went to Vanguard was out of Peter’s hands
- Charles observes there was probably something about Peter’s psychology and his own psychology where that contribution, that sense of willpower and of sacrifice feels very, very rewarding to Peter
  - That might feel less rewarding to Charles, where a sense of over time returns is rewarding
- It could be age related too
- Charles thinks it probably was and asks if Peter is return sensitive now
  - Yeah

## How to stick with good habits that offer no immediate reward: designing reinforcements and identity-based motivation [A: 1:11:15, V: 1:24:06]

- This is in many ways the mainstay of health habits
- Some things that we want people to do for health provide both short-term and long-term value, and it’s easier for people to anchor to the long-term value

An easy example of that would be, “*Hey, Sally, look, you’re 30 pounds overweight. And I have to be honest with you, I don’t particularly care that you’re 30 pounds overweight from the standpoint of your weight, but you’re also very insulin resistant as a result of it. And I know that if you can lose 30 pounds, it’s actually going to improve your health. You’re going to become more insulin sensitive, your risk of diabetes, cancer, heart disease is going to go down. This is what I care about*.”

- Sally might agree in the abstract with all of that, but for her at age 30, being 30 lbs. lighter is all about looking good in a bathing suit
- Here you have a situation where both Peter and the patient can care about the same outcome, but for different reasons
- The way to address this is to make changes in diet, changes in exercise, and there’s a win for them both
  - In 6 months, she’s going to have the body she wants
  - And he’s going to have the number he wants to feel confident that her risk of chronic disease is down

**But for some things, it’s very difficult to find the short-term win, and you have to grind away at doing something for a long period of time**

*Taking medication is a simple example*

- It’s not a huge ask, but you’d be amazed
- If you’re not familiar with this, you might already be familiar with the literature on compliance of medication use
  - It’s shockingly low
- Let’s take something that you don’t even feel ‒ the medicine truly has no bearing on how you feel, which is **blood pressure medication**
- Even though the mainstay of therapy for blood pressure is weight loss and exercise, elimination of sleep apnea and things like that, there’s still a sizable portion of the population that has what’s called [essential hypertension](https://en.wikipedia.org/wiki/Essential_hypertension)
- No matter how much they fix their weight and they exercise, they just have hypertension
- If you don’t fix it, you’re really setting them up for the risk of: heart attack, stroke, and even Alzheimer’s disease
- Peter will ask a patient to take this medication twice a day and check their blood pressure 3x a week at home so they know it’s working and see if they need to adjust it up or down
- He might be able to get 50% of people to do that

*How can I create a reward around that? What type of reward would you envision?*

- This is a key question and a really interesting one
- Charles begins by talking about what’s been done, and afterwards he wants to ask Peter what he has done and what he has found that works

One of the interesting things that’s happened in the last 5 years is that vitamin use has gone up significantly

- More people are taking vitamins now than before, and researchers have looked at why
- What they discovered was the big thing that changed vitamin use is making them gummies because you can put a little bit of sugar on the exterior of a gummy

**⇒** What they’re doing is they’re creating an immediate reward for eating that vitamin ‒ they’re incentivizing the behavior

Let’s take teeth brushing

- There’s a whole chapter in [*The Power of Habit*](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80) about the history of tooth brushing
  - If you went back 100 years or so, turn into the last century, what you saw is that there were tons of toothpaste companies and almost nobody had a tooth brushing habit
- This one guy comes up with a formula for how to get people to brush their teeth
  - What he does is he adds a little bit of mint to the toothpaste so it makes your gums tingle when you use it
- That’s actually a pain response, but what he’s saying is when you brush your teeth, you’re actually doing something good ‒ you can feel it working
  - You can feel it on your gums doing its job
  - You’re protecting your teeth

**⇒** He’s creating a positive reward even out of a pain response

***The number one thing we can do is we can try and manufacture a short-term positive reinforcement, some type of positive reward that’s going to incentivize that behavior***

- That’s not possible with everything

***The next thing that we could do is we can work on people building a mental habit associated with that behavior that does deliver a reward***

- Savings is a great example
- Taking my heart medication
  - If I’m taking heart medication and it’s kind of a pain, the pill’s dry
  - It’s like taking it with fish oil, and you get this weird fish burp all day long
  - There’s all these negative reinforcements
- What do I do in order to incentivize that behavior? Every time I take that pill, I think to myself, “*You know what? I’m going to be around for my grandkids*.”
  - I’m creating a link inside my head by exploring the why
  - That gives me a positive reinforcement
  - I feel a sense of responsibility: “*I’m a responsible person. I’m going to be there for my kids.*”
- That’s an exceptional intrinsic reward in the long run

Peter asks, “*Would you lead with that?*”

- Absolutely

*Is that strong enough as an extrinsic first 90-day version?*

- It’s going to take willpower

***The thing about rewards is that we usually have to experiment with them because we’re often very bad at anticipating how rewarding a reward is going to be***

- There’s some people who say, “*I’m going to go for a run and then I’m going to have a kale smoothie.*”
  - That’s not a reward
  - They don’t realize how disgusting kale is
  - That’s why Charles puts peanut butter in it

> “*We have to experiment with rewards to try and figure out which reward is salient for me.*”‒ Charles Duhigg

- For Charles it’s thinking about his kids
  - Thinking, “*I’m a responsible dad. I’m taking this pill. I’m doing it for my sons. I’m going to be there for them.*”
  - That is a very salient reward
  - For someone else, it might not be
- Everyone has to find that thing

***The way we find it is we experiment with different rewards and we see which one sticks***

## The potential for AI to provide social reinforcement [A: 1:16:45, V: 1:24:06]

- We’re in this era of AI, and AI chatbots and AI agents
- Charles already talked a lot about how social reinforcement is huge
- Going back to the experiment he described in South America: 40% increasing savings by simply having that woman there to just tell you what a good job you were doing when you were saving

**Has it been demonstrated that an AI agent can be as rewarding as a human being?**

- The research is so nascent on this
- Charles’ latest [book](https://www.amazon.com/Supercommunicators-Unlock-Secret-Language-Connection/dp/0593243919/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80) is actually about the science of communication, and this question of AI has come up a lot
- He also covers AI for *The New Yorker* now
- This question of whether an AI system can be as good a conversationalist as another human, we don’t really know
  - We’re only two years into the generative AI experiment

**⇒** What we do know is that I can create a reward for myself that’s built around this ritualized behavior within AI

- If I create that spreadsheet and I feel a sense of accomplishment from filling it out, I can get the same sense of accomplishment by getting into a ritualized behavior with AI
  - “*Hey, AI, you told me that I should run two miles today and I ran two miles*.”
  - We know that it’s going to respond by saying, “*Good job. You’re doing a great job. You’re thinking about your health for the long term.*”

Charles asks, “*Now, is the power there the AI system?*”

- The AI system can automate it, but the real question is, do I invest in the pride I feel from being told that by an AI?
- For some people the answer is yes
- For other people, the answer is going to be no

Charles explains, “*The answer to your question is, yeah, AI is great because AI can help automate certain rewards. It can automate certain behaviors. But whether that reward is salient to me, whether that behavior is salient to me, really depends on me. And I have the power to choose.*”

**Peter has already figured out a way to use AI as a reward for himself and his kids**

- They love to do Q&A sessions with ChatGPT
  - Just go down the rabbit hole of: What is the most valuable baseball card ever sold?
  - What was the PSA on it?
  - Okay, but why was Mickey Mantle’s worth less than Babe Ruth?
- Charles points out that all of those questions could be asked of Google
  - Before ChatGPT, you could have done a Google search

Charles asks, “*What is it about doing it with ChatGPT that feels more pleasurable to you?*”

- Great question, and Peter agrees it’s correct that Google today is mostly powered off [Gemini](https://gemini.google.com/app)
  - If you’re using the right version of Google, you’re actually getting Gemini to do the work, and it’s using a great version of Gemini
- Peter’s favorite thing he likes to do with [ChatGPT](https://chatgpt.com/) or with [Grok](https://grok.com/) (or whichever one, all the agents are really good) is he like to ask history questions
  - Because he was an engineer in college, and even though you had the option to take electives, he didn’t take any (he just took more math)
  - So he didn’t learn about history
  - And because he grew up in Canada, he really knows nothing about US history
- When he’s talking to an AI, it’s like having a private tutor
  - That’s assuming the hallucinations aren’t so bad
- It’s really exciting to say, “*Can we talk about this part of the Civil War?*”
  - What was it about Gettysburg that was the turning point?
  - And then ask really complex questions like what would’ve happened if this had happened instead of that? And how pivotal was this battle?

Peter shares, “*And so, yes, that for me is like a drug. Sitting down, spending an hour talking with a chatbot about that type of a topic. And also, I think part of it is the talking. It’s: I can talk and I can listen.*”

Here’s what Charles is hearing and Peter can tell him if this is right

- When you and I are in conversation right now, our bodies and our brains are changing to match each other
  - Our heart rates are matching each other
  - Our breath patterns are matching each other
  - The neural activity in our brain
- There’s a guy named [Yuri Hassan](https://hassonlab.princeton.edu/people/uri-hasson) at Princeton who’s done amazing research on this
- Our brains are looking more and more similar
- And because our brains have evolved to be good at communication, to be a prosocial species, we both feel a dopaminic response to that
  - We feel good after a good conversation
- Now, if you’re having a conversation with AI, do you have that same matching?
  - Maybe, maybe not
- But we do know that I’m in the habit of feeling good when I have a good conversation

***Even if I’m having a good conversation with a chatbot, I’m going to get some of those glimmers of the same great feeling I get from talking to Peter***

- And that’s going to make that conversation easier for me and more natural, and feel more fun
- Peter thinks there has to be something there
- He wonders if it is in how much it triggers the proximity to what is real

*A silly example of why Peter thinks there’s something to that*

- With ChatGPT, you get to pick the voice you’re talking to
- Peter has tried them all out
  - He doesn’t remember the name of the one he’s using, but it’s a British guy
- He doesn’t know what it is about discussing history with a British guy, especially when you get into World War II history
  - If you want to talk about World War II history with an older British man, it’s awesome, it’s fantastic
  - Peter doesn’t think it would be nearly as enjoyable if he was talking about it with someone that didn’t conjure up whatever image of wisdom he’s gleaning out of this
    - Like with some 16-year-old San Diego surf chick
    - It could be the exact same information, but there’s an auditory component to it that’s lighting you up in a way
- Charles thinks that’s playing on old habits Peter has
  - Communication habits
  - You listen to someone with a British accent and you just think they’re smart
  - BTW, Charles knows lots of British journalists who are not that smart
  - Peter agrees, “*It’s the old trick though. As Americans, we think it’s metaphysically impossible to have a British accent and not be brilliant.*”
- AI is taking advantage of these mental habits

## Mental habits: how thought patterns and contemplative routines shape deep thinking, innovation, and high-stakes performance [A: 1:23:30, V: 1:31:36]

**We don’t recognize our mental habits as habits, because they’re happening inside our brain**

- And they are incredibly powerful
- They make you believe that a chatbot is more intelligent if it has a British accent than if it has a San Diego accent
- These mental habits make Charles believe that when someone cuts him off in traffic, a perfectly appropriate response is to get angry
  - Which does not benefit him, does not change the situation
  - Charles knows that he should be zen about it
  - It compels him to behave a certain way

> “*We’ve talked a lot about behavioral habits today, but most of the habits that exist in our lives are mental habits*.”‒ Charles Duhigg

- Peter read read something the other day, which didn’t surprise him one bit: we have an average of 47 thoughts per minute (almost 1 per second)
  - Anybody who has meditated will know this
  - If you don’t meditate or you haven’t spent some time doing mindfulness meditation, you would think that’s impossible

Peter continues, “*We’ve got this crazy thing that is just a thought-generating machine that we can’t control, but thoughts are not thinking*.”

**What translates us from thoughts to thinking? How do we form better habits or reformat maladaptive habits around that?**

- Charles gave a great example of the reaction to getting cut off ‒ an anger reaction

***The way that we can influence our mental habits is that we have to deliberately choose to figure out what the cue is, and then we have to give ourselves a reward afterwards***

**⇒** Mental habits operate by the same principle as behavioral habits or physical habits, but it’s a little bit more tricky

**Innovation is a mental habit that’s studied**

- Why do some people manage to innovate on demand much better than others?
  - We can all be innovative, but some people they need the muse to strike (it takes them years)
  - And there’s other people you walk in and you say, “*Hey, look, I need 30 great ideas by tonight*,” and they can sit down and they knock them out
  - So, what’s happening there?
- When researchers have looked at the lives of serial innovators, what they found is that the most important part of that is that oftentimes the people who are really good at it have built up what’s known as a **contemplative routine** to spur that innovation
- These contemplative routines can be something like every week I sit down and I reflect on all the good ideas I had last week just for 30 minutes, and I try and think of good ideas for next week
- Or the contemplative routine can be, whenever anyone asks me to come up with 30 ideas, the first thing I do is I go take a walk, and I just think about it in my head
  - I’m not writing anything down
  - I’m not committing myself to anything
  - I’m just letting it percolate a little bit
- Charles has a routine that he knows works for him to spark contemplation

***When you think about it, when it comes to mental routines and when it comes to mental habits, and when it comes to success, the most successful people throughout history are the people who can get themselves to think most deeply***

> “*Making the right choice is so much more powerful than executing really well on the wrong choice.*”‒ Charles Duhigg

**In a fast-paced world like today, the question is: How do we get ourselves to think more deeply?**

- This is the killer app for our brain

***The way that we get ourselves to think more deeply is to build these contemplative routines that we automatically fall into, because those contemplative routines push us to think more deeply***

**An example Charles described in** [***Smarter Faster Better***](https://www.amazon.com/Smarter-Faster-Better-Productive-Business/dp/081299339X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)

- [Qantas Flight 32](https://en.wikipedia.org/wiki/Qantas_Flight_32) was an Airbus A380 that took off from Singapore to Sydney in the early 2000s
  - Perfect takeoff
  - The captain was a great captain
- About 10 minutes into the flight, one of the fan blades and one of the jet engines detaches, and it punches this enormous hole in the wing
- It also hits another fan blade, and that fan blade explodes, and it was like the shrapnel from a bomb going off inside the plane wing
- There’s 14 major systems that are needed to keep a plane aloft
- Within about 12 seconds, 12 of those systems had gone offline
  - No hydraulics, no fuel, no measurements on anything
- The captain (a guy named [Richard de Crespigny](https://en.wikipedia.org/wiki/Richard_de_Crespigny)) has to figure out how to land this plane safely
- This is the worst mid-air mechanical disaster in modern aviation
- So, what does he do at that moment?
  - There’s all these alarms going off inside the cockpit
  - There’s all these red flashing things on his board
  - The computer is telling him you have to do these 10 things
  - And as soon as you do those 10 things, you have to do 5 more things
- What he does is he takes his hands off the controls for a second, he closes his eyes and he says to himself, “*I’m telling myself a story about the plane that I’m flying. And the story in my head is the Airbus A380. And it’s really complicated because I have to think about fuel lines. I have to think about hydraulics. I have to think about brakes. You know what I’m going to do? I’m going to change the story inside my head. I’m going to change the mental model that I’m using on where to focus, and I’m going to pretend I’m flying a Cessna*.”
  - A [Cessna](https://en.wikipedia.org/wiki/Cessna) is the plane that he learned to fly on
  - It’s the plane he feels most comfortable in
  - He actually announces this to air traffic control and to the other pilots, and they freak out (why is this guy talking about flying a Cessna? He’s in an Airbus A380)
- That moment of contemplation allowed him to access that muscle memory, those habits of flying, and he lands the plane safely
- They touch down, all 469 passengers get off, about half an hour later
- There’s not one injury on board
- Now, they’ve tried to recreate this landing again and again in simulators almost every single time it crashes

*What did Richard de Crespigny do differently? Why was he able to land that plane?*

- Charles asked him, and what he’ll tell you is he’ll tell you he actually doesn’t know or remember exactly what he did in the moment

***But by changing that mental model in his head, by engaging in this contemplative routine, which felt supernatural to him to say, ‘I need to be in charge here. I need to stop reacting. I’m going to choose to pretend I’m flying a Cessna,’ that unlocked all of these learned habits of safe flying that allowed him to land that plane***

**Tell me more about him outside of the airplane**

*What kind of a man was he? What were his pastimes?*

- Peter finds this story so impossible to imagine, that he can’t believe he’s a normal guy
- He is not a normal guy
- He was trained to fly by the Australian military, Australian Air Force
- And anyone who’s learned to fly in the military, they know that a huge part of it is learning technical skills
- But a huge part of it is also learning these mental habits

**⇒** In particular, learning how to train your focus based on building mental models

- And the way that a mental model works is as we go through life, everything we do, there’s a little story inside our head that we’re telling ourselves, and our brain is comparing that story to what’s actually happening to help us figure out what to pay attention to
- There’s so much that I could pay attention to right here
  - There’s bright lights, there’s your expressions, there’s a camera, there’s wood paneling
- I need to figure out where to actually focus

***What my brain does is it creates a mental model where it says the story of right now***

- Right now is that I’m having a conversation with Peter, so I’m going to focus on Peter
- I’m going to be very, very attuned if something changes unexpectedly in your demeanor
  - And very unattuned if something changes outside to the light because it doesn’t matter to me right now
- When you’re learning to fly in the military, they tell you be really deliberate about how not only you build mental models, but how you challenge your mental models
- The morning before before Qantas Flight 32 took off, Richard de Crespigny did this thing that he did before every single flight
  - He’s in the shuttle from the hotel to the airport, and he turns to his co-pilots and he says, because he’s the captain, he says, “*What’s the first words out of your mouth if we lose engine two? Where are your eyes going to go first? Where are they going to go second? What are you going to do with your hands? If we lose engine three, how are your words going to change?*”
  - In other words, what he’s doing is he’s saying, “*Tell me a story about how we will react if there is an emergency.*”
- If you listen to the cockpit recordings from when that hole appeared in the wing, what you hear is you hear all these pilots talking to each other in calm, collected voices
  - There’s not an ounce of panic in their voice
  - It’s as if they had practiced this a thousand times because of course they had
  - They had practiced it in those rides from airports or in the simulator
- That’s not the only thing that de Crespigny did
  - The thing that made de Crespigny special is that when he would ask his co-pilots to tell him those stories, he would argue with them, “*That’s what you’re going to say first after engine two? Why are you going to say that? Why shouldn’t we say this? You’re going to move your hands left and then right? Let’s talk about why not right and why not left?*”

***He was in the habit of challenging his own mental models and other people’s mental models, and that challenge is what allowed him in the panic of that moment [to change the story inside his head]***

- Imagine you’re flying a plane and all of a sudden all your alarms light up
- It’s so easy to become reactive
- It’s so easy to fall into: I’m going to do what the computer’s telling me
  - I’m not going to think about this
  - I’m not going to challenge the story inside my head
- But he’s in the habit because he practices it with other people of challenging not only their stories, but his story

Peter asks, “*What fraction of pilots are behaving that way?*”

- In military trained, a huge fraction
- There’s a really interesting study out of South Korea, that in some cultures, there’s too much deference given to the captain
- As a result, they’re engaging in less challenging of each other’s mental models, and there’s been a lot of interventions to try and change that
- Peter recalls the [tragedy](https://en.wikipedia.org/wiki/Tenerife_airport_disaster) on Canary Island: it was the KLM flight that was at fault, and everybody died on that flight
  - The captain was the most impressive captain in their entire fleet
  - He was not heeding input from less senior people in the cockpit
- There was an [Air France flight](https://en.wikipedia.org/wiki/Air_France_Flight_447) from Brazil, and we have the cockpit recording of what happened there
  - If you listen to it, there was nothing wrong with a plane the entire time
- It was that the pilots became what’s known as **“tunnel focus”**
  - All I do is I pay attention to the most obvious inputs, and I stop challenging that story in my head of what’s going on
  - They actually caused the plane to stall and then it fell into the ocean
  - Tunnel focus happens all the time

**Have you interviewed** [**Sully Sullenberger**](https://en.wikipedia.org/wiki/Sully_Sullenberger)**?**

- No
- Charles spent a lot of time talking to [Richard de Crespigny](https://en.wikipedia.org/wiki/Richard_de_Crespigny) ‒ they’re both very similar
  - These guys are engineers
- You talk to de Crespigny, he’s not a guy you’d go have a beer with (he is really difficult to talk to)
  - First of all, he believes there’s a process for everything, and there’s a right answer and there’s a wrong answer
  - When Charles brings something up, he’ll be like, “*Nope, you got that exactly wrong. Let me tell you where you got it wrong*.”
  - This instinct to challenge mental models is so ingrained in him that it comes out all the time
  - They actually have this expression in the Australian air community, and there might be in the US too, that when someone’s a really good pilot, they’re known as an “asshole pilot” because they’re so uptight, they’re such an asshole
    - They challenge everything you say
    - They’re always picking a fight with you about whether you’re doing the right thing
    - That guy’s an asshole, but he’s a great pilot as a result
  - It means you don’t want have a beer with him, but you definitely want him flying your plane

## How cognitive routines boost productivity and habit formation, but may stifle creativity [A: 1:35:15, V: 1:44:50]

**What are some less dramatic examples of how this manifests in the lives of those of us who don’t carry in our hands the lives of 400 passengers?**

Charles asks Peter, “*What do you do to get ready for each week? A process you go through or what is it that you do?*”

- Every Friday afternoon, Peter makes a list of everything he’s going to accomplish on Saturday and Sunday
- And every Sunday he makes a list of everything he’s going to accomplish Monday through Friday

***So, he has 2 lists: a 5-day week list and a 2-day weekend list, and they include the most important things that have to be done***

- These don’t include things that are automatic
  - He doesn’t write his workouts and stuff because those are on cruise control
- But it can be anything as mundane as
  - Got to go to Dick’s Sporting Goods and get a set of baseballs
  - Need to finish working on this newsletter
  - Need to prepare for this podcast
  - Need to take my daughter here

***It’s how he organizes the blocks of the week***

Charles asks, “*And why does that feel good to you? You would end up taking your daughter anyways… There’s something about that list that’s a contemplative routine for you. What reward is it providing?*”

- Peter really enjoys checklists and checking things off a list
  - It’s weird, this has always been the case, even in high school
  - There’s a dopamine hit that he’s getting
- He draws a box and writes what he’s going to do
  - Then if it’s in progress, it gets a single line through the box
  - Then when it’s fully done, it gets the X through the box
- For example, if one of the things was connect with Charles this weekend
  - Let’s say he calls you tomorrow and we talk for 5 minutes, but then you have to run
  - Peter would put us half slash through it, which is, all right, we partially connected, but we haven’t fully connected
  - So he knows that he still has to come back to it and connect with you
  - And if he doesn’t, then it goes on the next list of the week or something like that

*What Charles loves about this*

- There’s a need for **cognitive closure** that all of us feel

**⇒** The research on people who’d make to-do lists find that 60% of people when they’re writing a to-do list, will write down something they have already completed because it feels so good to check it off

- Peter used to do that; he stopped doing it about 20 years ago
  - He used to take great pride in sneaking in a couple wins out of the gate
- That need for cognitive closure, it can push us to do the laundry when we don’t need to do the laundry because we just want to feel some sense of accomplishment

You have actually redirected it through a cognitive routine to be a very positive influence in your life

- I’m going to create the goals that I actually want to accomplish

***I’m going to create a system where I can satisfy that need for cognitive closure, and I’m going to have a tracking device in order to do it***

- The reason why that’s useful is because you have a **routine** around it
- You have this cognitive routine that on Friday afternoons, you’re doing the weekend list
  - On Sunday, you’re doing the week ahead list

**Charles’ cognitive routine**

- Every day when he comes home from work, he tells my wife about his day in excruciating detail, and she is bored to death by it
  - She does not care how this interview went or what came out of this meeting
  - But he’s not doing it for her
  - He’s doing it for himself because as he’s describing his day, he’s paying attention to:
  - This went well (why did it go well?)
  - This didn’t go as well (what do I need to do differently next time?)

Charles explains, “*I have a cognitive routine of describing my day to my wife that provides me with a dividend*.”

- And she understands that; she tunes him out
- She knows Charles is describing the day for his benefit
- And she does the same thing to him, and sometimes he tunes out what she’s saying about her day

**Peter sometimes worries**

- That he’s too rigid in having these lists (especially the weekend list)
- Would his life be better off without it?
- Even though he would have to give up some productivity, because sometimes he gets a little dogmatic
- Charles thinks that’s a really good instinct and worth experimenting with

**Charles’ approach to writing**

- The way Charles writes articles for *The New Yorker* is he will write an outline that’s almost as long as the article itself ‒ just to make sure he understands
  - He does this with books too
  - He writes it as a narrative letter to his editor
- He does all the reporting, then he puts it aside and just writes his editor a letter saying, this is what I think I’m going to say
  - It’s easier because the stakes are very low and he doesn’t have to return to the reporting
  - If something goes wrong, it’s okay
- This has worked really well for him, particularly in writing books and long form pieces
- But he thinks it’s negatively impacted his creativity

Charles explains, “*There’s something about having more options and having that sense of risk that sometimes pushes you to figure out how to say something in a new way or pushes you to figure out how to say something in a fun way that didn’t occur to you before.*”

- Charles plays a lot with rigidity and freedom in trying to find that right balance
- He guesses that Peter does this too
- Charles listens to the show and there’s some questions that Peter asks everyone
  - And there’s some lines of inquiry that Peter goes down that are clearly the right line of inquiry
  - But then sometimes Peter asks a question that comes out of nowhere or asks something that’s unexpected that causes the guests to say something they didn’t anticipate they were going to say

***Charles thinks intellectually, Peter is engaging in that same exploration versus exploitation process that’s at the core of all information gathering***

## Contemplative routines: using stillness to unlock deeper productivity and creativity [A: 1:40:45, V: 1:51:15]

- Let’s go back to this **contemplative routine** idea because the first thing that came to Peter’s mind when Charles described it is going back to something that [Ryan Holiday](https://ryanholiday.net/about/) wrote about, [*Stillness Is the Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0)
  - [the subject of episodes & [#90](https://peterattiamd.com/ryanholiday/) & [#101](https://peterattiamd.com/ryanholiday2/)]

**Have you read that book?**

- Charles is a huge fan of Ryan
- [*Stillness Is the Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0) is Peter’s favorite book that Ryan has written
  - It’s the one he’s gifted the most, and a book he goes back to reread
- Peter shares making stillness time is something his brother does so well
  - He’s very disciplined about time to think

Charles asks, “*Tell me how he does that… If I was watching him, what would it look like?*”

- On the surface, you would think it’s quite selfish
- He’ll say, for the next 2 hours, he’ll tell his wife and his kids, “*I need to be left completely alone and I need to go for a walk with no phone, with no anything. I’m going to walk in the fields*.”
  - He lives on a farm. And he’s like, “*And I’m going to just be with my thoughts and with nothing else. And then I can come back and do my best work.*”
  - He forces that in
- Peter is convinced that all of us could do better work if we did that, and yet he struggles to do it
- He falls into the trap of thinking about how much more he could get done in those 2 hours
- He doesn’t have 2 hours to be still

[*Cal Newport*](https://calnewport.com/) *has done a lot of work on this*

- One of the mistakes that we make is that we look at some types of activities as being unproductive because they don’t yield immediate dividends
  - This is just a cognitive heuristic that we fall into
- This is part of the whole habit system
- It’s about building those habits to recognize deep productivity, deep work
- One of the things that happens to Charles is that he says, “*If I go take a walk in the woods for 2 hours, what do I have to show for it? Whereas, if I sit down and I pound through these emails for 2 hours, my inbox is half the size it used to be. It feels really like an accomplishment.*”
- Of course, all that does is create more emails for himself, and it turns out half of those he could have ignored
- What he needs to do is to train his brain
- And my brain oftentimes doesn’t believe him
  - He knows intellectually taking that walk in the woods is going to yield dividends, that he’s going to be able to do better work
  - But there’s part of his brain that looks at his stated preferences (what he believes and wants to be true) and another part of his brain that looks at revealed preferences (How do I actually behave?)
  - And that revealed part of my brain is saying, “*You never take walks. You always sit down and do your email. You must think that doing email is more valuable than taking a walk.*”
- So Charles has to convince himself that revealed preference is part of my brain
  - Now the walk is really good
  - If I take this walk, I’m going to get more work done, I’m going to be able to get through those emails faster because I’m going to hit delete on more of them
  - This actually is a productivity enhancer
- We have to hack our own brains sometimes
- We have to remind ourselves of a reward

***Oftentimes the salience of a reward increases simply because we tell ourselves it is a reward, and we have to take advantage of that to try and sometimes play with our own brain because we’ll act sometimes in not our best interests***

## How habits reduce decision fatigue and enable deep, high-quality productivity [A: 1:44:15, V: 1:55:25]

**What do you think is the relationship between productivity and habit?**

*How implicit and how explicit is it?*

- Charles thinks it’s huge
- To be clear, oftentimes the things that we do out of habit are not the productive things, but our habits can set us up to be productive

***The most important element of productivity is deep thought because making the right choice, making the right decision, spending my time on the right task right now yields many more dividends than simply getting something done***

- It’s the difference between productivity and busyness

**So the question is, how do I set myself up to make better choices?**

- Charles builds habits that give him not only the time and space to make a choice, but the prompts to make a choice because there’s a lot of times that he’s going to avoid making a choice if I can
- His brain doesn’t like making choices
  - It costs energy, it feels like it’s depleting me
- His brain is going to say, “*Oh, you walked in the cafeteria, don’t get the salad. Just get the sandwich you get every single time. You know you’re going to like it*.”

***So how do I build a habit that allows me the space to make that choice and the prompt to make that choice?***

- That’s why habits are so important, it’s not because they make us productive, it’s because they allow us to be productive

**Say more about the decision fatigue**

- That’s something many people listing can relate to
- Peter has become much more aware of it in himself recently, and he doesn’t think it’s age-related per se
  - It’s complexity-related
  - The more things he’s juggling, the more he finds himself unable to make simple decisions
  - And how internally frustrated he gets sometimes when he’s asked to make decisions

There are 2 things happening here

- Decision fatigue is real
- Hundreds of studies show that the more decisions you have to make in a day, the more fatigued you get
- There’s some elements that play into this
- 1 – The first is structuring decision design
- So [President Obama](https://en.wikipedia.org/wiki/Barack_Obama) in one interview said that the most important habit that he developed when he was president is he bought 12 of the same suits and shirts
  - So every morning when he woke up, he knew exactly what he was going to put on
  - There’s no other options in his closet
  - He just has to grab one of them
  - He said the reason why is because the day was so exhausting with decisions and each of the decisions he made was so important that he had to preserve his ability to make decisions and avoid that fatigue

***So the first thing is how do we design our decisions so that we’re only having to make the important ones and we’re making the less important ones automatic things that we don’t have to make a choice***

- 2 – The second thing that happens there is that decisions are harder to make in a “hot state” than they are in a “cold state”
- So if you’re hungry and you go into the cafeteria, it’s going to be a lot harder for you to choose that really healthy salad over that really tasty sandwich because you’re in a “hot state”
- Now, in a “cold state” that morning when you just had breakfast, if you say, “*My implementation intention is I’m going to eat a salad today when I walk in, that I know which salad I’m going to get*,” it’s a lot easier to make that decision

What Charles thinks is happening

- 1 – You don’t have a  mental heuristic in place to say, “*I’m going to curate the decisions I have to make,*” and you probably do now
- But the first time it comes up, you don’t have the heuristic
- The heuristics is: when my wife asks me where to go to dinner, I’m just going to choose one of them
  - I’m not even going to think about which one is the best one
- I’m going to create a decision structure for myself that allows me to focus on the most important decisions and ignore the smaller ones
- 2 – Secondly, I’m going to ask her not to ask me to make that decision at the end of the day when I’m exhausted and I’ve been making choices all day long.
- I’m going to say, “*Look, I’m in a hot state right now. I can’t think about where to go to dinner. I’m thinking about other stuff. But if you ask me two hours from now after I’ve had a beer and I’ve started watching TV, I think I’ll be ready to answer that question.*”
- Peter agrees that’s the obvious answer, and yet he often feels that he should be more gracious
  - He feels embarrassed and obnoxious that he would have to say that
  - Charles jokes, “*It’s very Canadian of you that you feel a sense of guilt around telling someone you can’t make the choice right now.*”
- Part of our brain, our self-definition becomes rooted in success instead of failure
  - Particularly for successful people
- We are the type of people who have been successful because we make good decisions, and so we beat up on ourselves when we can’t make a decision
  - We beat up on ourselves when we have a human frailty or a human weakness
- But you know this from training athletes, the key is not to not have frailnesses

***The key is to recognize your frailnesses, plan for them, and strengthen your behavior around the frailness***

- Every single one of us makes bad decisions, and if our self-definition is I’m someone who every time everyone asks me a question, I can give them the right answer, then we’re setting ourselves up for failure

## New research that reveals the power of environment and social feedback in habit formation [A: 1:49:45, V: 2:01:31]

- It’s been 12 years since you wrong what Peter thinks is the most authoritative text on habit creation [[*The Power of Habit*](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)]

**How much have you stayed up to date on the science of habit?**

*How much has changed in the last 12 years?*

*If you were to rewrite that book today, what are two or three things that you think might be different or that were just outright missing?*

- Charles has tried to keep very current on the literature around it and the fundamentals haven’t changed

**⇒** The fundamentals have been true for thousands of years about a cue or routine and a reward, how our brain works and forms habits

***What has changed is our understanding of how much influence we can have over those cues and rewards by influencing our environment***

- Charles mentions another author: [David Epstein](https://davidepstein.com/david-epstein-about/)
  - He’s a wonderful writer
  - He was on the podcast [[episode #96](https://peterattiamd.com/davidepstein/)]
- He talks a lot about current research, looking at environments where we have a lack of resources and environments where we have a lot of resources

**⇒** Environments where we have a lack of resources oftentimes produce better outcomes, but not all resources are created equal

- If I tell you, “*You have a time limit on coming up with a new idea and your time limit is 5 minutes*,” that’s not going to be helpful
- But if I tell you, “*Peter, you can’t spend more than 2 days on this*,” that is helpful

Charles explains, “*What we’re learning a lot about is how to use constraints, how to create what are known as ‘wicked environments’ where the feedback is ambiguous, it takes a long time to arrive, and it’s not being delivered in a social context versus helpful contexts or good contexts where the feedback is immediate, it’s very, very clear, and it’s being delivered to me oftentimes in a social context, which reinforces it.*”

- We’re learning a lot about how these different environments influence our ability to act in different ways
- This is at the core of [behavioral economics](https://en.wikipedia.org/wiki/Behavioral_economics)

**⇒** We’ve known for a long time that the decision architecture matters, that environment matters, but what we’re learning is we can get much more precise

***If Charles were writing*** [***The Power of Habit***](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80) ***today, one of the things he would include is a chapter on thinking much more deliberately about your environment***

- Not just, I’m going to put apples on my desk so that when I have a craving to eat something, I eat one of those apples instead of a donut in the break room
- But also I’m going to structure my day so that I make my most important decisions in the morning because I know that that’s when my decision-making is strongest
- I’m going to structure my day so that I go and I take a walk in the afternoon because I know that if I do that, I’m going to do better work that evening

***One of the things that we are learning is our environments matter much more than we thought they did, and it’s worth paying attention to that***

**Do we have a greater sense of appreciation for the social component today than we did then?**

- Peter points out that it was strong and well-understood then, but it almost seems that we just understand the power of social influence
  - Maybe it’s just coincident with social media
- Absolutely
- And that’s actually one of the reasons Charles wrote [*Super Communicators*](https://www.amazon.com/Supercommunicators-Unlock-Secret-Language-Connection/dp/0593243919/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80), because what he came to realize is that when we focus on habits, we tend to focus on ourselves

***But most of our most important work, both for ourselves and professionally, is work that we do in conjunction with others***

- The value of my life and your life is largely based on the conversations we have with our spouses and our kids
  - That’s whether we feel good or bad

***Charles realized that by focusing on habits exclusively, he’s missing this incredibly important part of what makes people successful and happy: How do we interact with other people?***

- We are living in a golden age of understanding communication like never before because of advances in neural imaging and data collection
  - We can see inside people’s brains as they’re having a conversation, we know what’s happening there
- And we’re learning a tremendous amount about what kinds of social reinforcement are positive and which kinds aren’t
- And which kinds are powerful, more powerful than other kinds

## How AI may transform work, identity, and our sense of purpose [A: 1:53:45, V: 2:05:51]

**You are always in a state of learning. Is there something that is brewing as the next evolution in your thinking?**

- The next book he wants to write is about AI
- He thinks AI is really, really interesting and important
- He interviews a lot of guys who say, “*AI is going to change every single part of life. It’s going to revolutionize everything.*”
  - Charles doesn’t agree

**⇒** Charles invites listeners to reach out to him if you think there’s something he should know about

- He thinks there’s a lot of humanness that’s really important to us

***He does think that AI has the same potential that the First Industrial Revolution and the Second Industrial Revolution had, that the wide adoption of the internet had***

**⇒** What’s interesting is if you look at the history of nonfiction literature, what you see is that there were these moments of real discovery and someone wrote a book that explained to us how to think about it

- One of Charles’ favorite examples is [The Right Stuff](https://www.amazon.com/Right-Stuff-Tom-Wolfe/dp/1250338352/ref=tmm_pap_swatch_0)
  - Many people have seen the [movie](https://en.wikipedia.org/wiki/The_Right_Stuff_(film)); the [book](https://en.wikipedia.org/wiki/The_Right_Stuff_(book)) is fantastic

***What he’s really writing about is: he’s not writing about the science of the Apollo missions; he’s writing about the psychology of the people who are designing those rockets and are getting on those rockets***

- His basic question is, what kind of a person is willing to strap themselves to a rocket before we knew that this was safe and easy and send themselves into space before we knew we could survive there?
  - Why? Why is someone willing to do that?
  - Why are people competing for the opportunity to do that?

***He found a lot of interesting answers, and Charles is wondering if we’re too early in the process of AI to have any takeaways***

**Questions about AI**

- Why do some people see the world differently in a way that allows them to develop these generative AI systems and other AI systems that are so potentially transformative?
- And most importantly, how will it change how the rest of us think?
  - How will it change our definition of self?
  - How will it change how we work?

***Those are really interesting questions and what Charles is hoping to write about in his next book***

- There’s probably going to be a lot of lessons in it about how we ought to behave

**What do you think about the importance of purpose to our species?**

- Charles thinks it’s incredibly important
- Here we get a little mystical because we don’t know why purpose seems to light up so many parts of our brain, but we know that it does

***We need a why, that story that’s inside our head, that mental model that tells us what to pay attention to and what to do next***

- We are a storytelling species
- We look for correlative links in life
  - I told this one funny joke, and so the girl fell in love with me
  - I started running every single day, and then I got in better shape and I was able to give up smoking
  - That might be correlation and not causation, but we look for those causal links (we want them to exist)

**⇒** We make sense of the world by telling ourselves a story about the world

*At the core of most stories is the why*

- Why is the knight getting on his horse and going to fight the dragon?
  - There’s got to be some reason for it
  - There’s got to be some motivation
  - He wants to win the hand of the princess
- Why do you remain faithful to your spouse?
  - There’s temptations all around
  - Our biology tells us that we should probably not be faithful, but there’s a why there that’s at the core of our story

***The reason why that story is so important is because it’s our self-identity, it is how we make sense of ourself as an individual in this world***

- If we had to reinvent our self-identity every morning, it would be exhausting
- That’s actually what schizophrenia is
- One of the contemporary ways of looking at [schizophrenia](https://en.wikipedia.org/wiki/Schizophrenia) is: it’s someone who has biochemically a more difficult time telling themselves a consistent story from day to day, and it’s awful

***The purpose (that why) is so important because it grounds us in our story and that tells us who we are***

Peter observes, “*Many of the stories then about AI’s power and potential is that many of us will not be necessary from at least a work perspective*.”

- Let’s just assert that there’s some truth to this
- Peter would put himself and his career near the top of the list of things that could be outdone

**So what do we make of a world in which many people no longer have a professional why?**

*Is it something that could be substituted with a personal why?*

- In other words, is there a world in which I’m no longer necessary in any way, shape or form for any of the things I do?
  - AI will do a better job at podcasting
  - AI will do a better job at doctoring
  - AI will do a better job at everything I do
  - My kids will be too old to need me as a parent
  - I’ll become so obsessed with chess that that will become my “why.” Does that work?

Charles suggests 2 things

- 1 – We’ve always had this concern

**⇒** There’s always been this concern that each technological leap forward will mean that work disappears and it’s never come true ‒  it just means that work changes

- 2 – At this point, Peter doesn’t need to work for the paycheck (he’s got enough money), but he chooses to work
  - You call it work, but it’s also stuff that you would probably do in your spare time, even if it was uncompensated
  - He enjoys it
  - He doesn’t take ads for this podcast
  - He’s made a decision, this is a hobby
    - A very impactful, very successful hobby
  - It’s not work, but you define it as work
  - You feel a sense of obligation to it because it fulfills a purpose for you

> “*I am not worried about AI spreading and us losing our ability to create purpose.*”‒ Charles Duhigg

*Is that a contrarian view or do you think most people would share that view?*

- Peter asks this not knowing the answer
- If you were in Silicon Valley, it would be a contrarian view
- But a lot of the people who work on AI, they are not very close to normal life
  - They’re not living the lives that Charles and Peter live
  - They’re possibly rightfully worried about issues that we don’t worry about quite as much

***Among the broader population (particularly among scholars), Charles’ view is more in the mainstream, that there’s a recognition that this hand-wringing over losing the need for work has always existed with us***

- Elevator operators ‒ basically, elevators have been taken over by AI
  - Really dumb AI, but it’s an AI
  - It used to be that every elevator you got on there had to be someone there who stopped it at the right floor
- There are not people walking around right now who say like, “*Oh man, if I could only be an elevator operator, my life would be so much better,*” because they found something else to do
  - They found something that was equally meaningful to them

> “*Our human ability to find purpose and manufacture purpose and create purpose is infinite*.”‒ Charles Duhigg

***As we move into a new world with different technological challenges and different technological opportunities, we will find that purpose***

- Because the truth of the matter is maybe someday AI can raise your kids
  - Maybe your kids get old enough and they don’t call you anymore and say, “*Hey, dad, I need your advice on this.*”
  - But they still need you as a dad
  - They’re still going to mourn you when you pass away
- There is something elemental and human about being human, and that can’t be taken from us

**Do you think AI needs to internalize the value of human life for us to be able to coexist with it, or is there an actual risk, an existential risk to our species if AI doesn’t understand our uniqueness?**

- Charles has no idea
- There’s certainly some people who are smarter than him who feel like they can answer that question more authoritatively and say:
  - Yes or no. It’s a huge risk to us. It’s going to kill all of humanity
  - There’s other people who say actually AI is such an alien, when it eventually does reach this point of [AGI](https://en.wikipedia.org/wiki/Artificial_general_intelligence) (or super intelligence)
  - Or the moment where [Skynet](https://en.wikipedia.org/wiki/Skynet_(Terminator)) becomes real, that it’s such an alien form of thinking and form of cognition and form of sentience that it won’t really care about us the same way we don’t really care about ants
  - There’s people on both sides of this

***The answer is: “I have no idea. I actually don’t even know what AI actually is. Defining AGI, artificial general intelligence is really, really hard.”***

**Charles doesn’t know how AI is going to be exploited**

- Right now we use AI to have fun conversations about history with our kids
- But if you think back to the internet, when the internet first started, nobody thought that the really important, financially productive, and that an impactful way to use it would be to sell everything through one store and to allow people to basically shout at each other on social media

**⇒** It wasn’t the technology that gave rise to those either advances or weaknesses ‒ it was people like [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) seeing the world in a new way that the technology empowered

***We’re not at the stage yet where people are seeing the world in a new way because of AI, but they’re going to, and they’re going to use it in ways that surprise us that we can’t anticipate***

- Charles adds, “*And until they start doing that, I don’t know that I can answer your question.*”

## The potential of AI-powered habit change, and the essential—but often lacking—element of motivation [A: 2:02:30, V: 2:16:27]

**The potential for AI help with behavior change**

- One of the most exciting things Peter would love to see AI have a huge impact on is one of the things that we as humans have the biggest challenge with: behavior change
  - Encouraging and helping people to change behaviors
- If there is an AI agent that can be the most powerful tool for behavior change, as powerful as having you stand next to a person 24/7 as their behavior coach, then you really change lives

*The real question is: Do we have the data for how to do this under perfect circumstances that can serve as training data through this vehicle?*

- Because if you take a step back and ask, is the [LLM](https://en.wikipedia.org/wiki/Large_language_model) platform the right platform?
- Peter thinks the answer is yes for this application
  - We can debate whether the LLM is the right platform for all applications of AI
  - It may or may not be, but given the [transformer](https://en.wikipedia.org/wiki/Transformer_(deep_learning_architecture)) in 2017, that took us down this path, he has to believe it’s the right platform for this problem
- So now the question becomes, do we have enough training data?
  - Do we know what the solution space looks like?
  - Do we have the data to train it?

***And if so, then it comes down to how important is an actual human in this element versus the words***

- Charles adds 1 more element to this formula: the solution space assumes that delivering the knowledge is the bottleneck
  - I need something to deliver me the right knowledge at the right moment, very, very easily
- Peter thinks this depends on how you define knowledge
- He was thinking about this more broadly
  - Let’s say I need help changing my habits
  - You standing next to me, you will provide me with knowledge, you’ll provide me with accountability, you’ll provide me with reassurance

Charles suggests there is a step before that: Are you actually motivated to change?

- If you say, “*Sure, I’d love to lose 10 pounds, but it doesn’t really matter that much to me.*”
- It doesn’t matter how much I stand next to you, how much positive reinforcement I give you

***If you don’t have fundamental motivation to make that change, it’s probably not going to happen (or at least not in a profound and lasting way)***

And so now the question becomes: Can AI generate motivation in me to change?

- AI can certainly deliver the information to me
- It can certainly deliver the positive reinforcement
- It can certainly deliver all the subsequent parts of the formula
- Can AI generate motivation in me to change?

**What fraction of people who fail to make change fail because that is missing or because all of the coaching, cuing, behavior modification that follows is missing?**

Charles asks, “*How many copies of your book have you sold at this point?* [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=219J49N5H94OZ&dib=eyJ2IjoiMSJ9.P2oZuRwhOizmZb9mpYCQtGehQj744u4m8vkQr8LFXzneQmMcb6RJmXlwwbRs8lcoFM3twc5ZrAL8A6qcznOiR0Rxg3AhLAH2Qr0mjbvKz1Pm3px2z9Mp8Pvrl_QbjW0UZD1UbZZb9ZmG3oqhqQAePk8R_7d48EHthueu4j-ll8D0TI0fk84BRit7f5E4C_HKoT8zcfMro845D74LR9CON41VsdA-2G3L17v4CLmTrlg.LGK89k2Dd3-RTkp8aDKMPLlcYsJS0j7ijlRE3Z73bjw&dib_tag=se&keywords=outlive+peter+attia&qid=1752155140&s=books&sprefix=outli%2Cstripbooks%2C142&sr=1-1)*?*”

- Almost 3 million
- That’s 3 million people who have gotten fantastic information
  - Maybe some didn’t read it, as long as they bought the book

*How many of those 3 million do you think made the change that they wanted to make after reading the book?*

- Peter would like to believe that many people have made a change, but probably very few have made every change
- Charles suggests that the people who are picking up that book, they’re motivated to begin with
  - It’s selection bias out of the gate

***Charles thinks this motivation question is the most important one***

- It’s the inception question
- It’s a necessary prerequisite
  - It’s not sufficient on its own, but it’s a necessary prerequisite
- There’s a lot of people who pick up [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=219J49N5H94OZ&dib=eyJ2IjoiMSJ9.P2oZuRwhOizmZb9mpYCQtGehQj744u4m8vkQr8LFXzneQmMcb6RJmXlwwbRs8lcoFM3twc5ZrAL8A6qcznOiR0Rxg3AhLAH2Qr0mjbvKz1Pm3px2z9Mp8Pvrl_QbjW0UZD1UbZZb9ZmG3oqhqQAePk8R_7d48EHthueu4j-ll8D0TI0fk84BRit7f5E4C_HKoT8zcfMro845D74LR9CON41VsdA-2G3L17v4CLmTrlg.LGK89k2Dd3-RTkp8aDKMPLlcYsJS0j7ijlRE3Z73bjw&dib_tag=se&keywords=outlive+peter+attia&qid=1752155140&s=books&sprefix=outli%2Cstripbooks%2C142&sr=1-1) (and Charles includes himself in this) who say, “*I really want to do everything Peter tells me. I want to be super healthy. I want to work out every day. I want to live forever.*”
- And I read the book and I say, “*I’m going to do this,*” but I have motivation for 15% of it (or 20% of it, or 50% of it)
- But then on the other 50%, I don’t have the motivation yet

*The question is, how do I generate that motivation?*

- It’s not your job to generate the motivation for me
- You can give me the argument, you can tell me why this is important and you’re persuasive, and maybe that will motivate me but ultimately you’re delivering me the information I need once I’m motivated
- That motivation part is a real question

**Now let’s look at someone like Tony Robbins**

- [Tony Robbins](https://en.wikipedia.org/wiki/Tony_Robbins) delivers the motivation
- If you listen to what Tony Robbins says about financial stuff, his advice is not the most sophisticated advice on the planet
  - Charles thinks the world of Tony Robbins
  - He’s had a huge impact on people’s live

***His ability to motivate people is incredibly sophisticated, and as a result, he’s changed a lot of lives***

Peter asks, “*What do you think is the element of that? And does it work uniformly or is there a susceptibility? Is there a subset of people for whom that style of motivation works?*”

- We know that there are people for whom that style of motivation works and other people for whom it doesn’t
- It might just be taste
- It might just be habituation
- Peter remembers a really funny meme of him where he’s getting this guy to [roar like a lion](https://youtu.be/Yp8DFPtG2xw?si=TVqsgSocaD5zbu_b&t=394)

- There’s a subset of people for whom that roaring like a lion is going to change his life (it totally works)
- And then there’s a subset of people that look at that and think, “*Yeah, not for a million dollars.*”
  - That doesn’t change anything
  - That’s not going to change anything
  - I’m going to be demotivated because this seems so silly

Charles adds, “*That being said, anyone who’s listening, you should go to a Tony Robbins thing. Even if you don’t believe it or enjoy it, it’s just the spectacle of it is amazing. What he does on a stage is really astounding*.”

**What do we know about the science of creating this motivation?**

*Do we know that there are some people for whom the way he delivers a message is the turnkey to make this happen?*

- If Peter listens to him give a talk, it makes a ton of sense
  - It’s very inspiring
- Tony might get you to realize you need to quit smoking, but quitting smoking is hard
  - Coming up with a plan for that is hard

***They’re both necessary and neither is sufficient***

- Charles agrees

**⇒** One of the things that we do know about motivation is much like rewards, it tends to be very different from person to person

***The only way to really figure out what motivates you is to experiment***

Charles asks Peter, “*What motivates you to work out every day?*”

- It’s many things
- There’s the cognitive piece of it, which is Peter really, really believes what he preaches daily: “*Exercise as a tool, is the single most important tool in both magnitude and direction at lengthening life and improving quality of life.*”
  - So in as much as he wants to live longer and live better, exercise is as important, if not more important than anything he could do

*Would those same motivations have worked on you when you were 20 years old?*

- No, it wasn’t even on Peter’s mind when he was 20

***Right. As a result, what we need as motivation changes over time***

- It changes from situation to situation, the environment, the choices we make
- So it’s not like we can say this one form of motivation is the right form of motivation
- What we can say is motivation is really important, we know that motivation has certain characteristics
- But we also know that it is something that is incredibly adaptive in people’s lives and that they find motivation from different sources throughout the course of their life
- Peter thinks that’s a really good point: “*What got you here yesterday isn’t going to get you there tomorrow necessarily.*”
- Charles just turned 50, Peter is 52; they’re in the same place

Charles shares, “*For the first time, that road is really realistic*.”

- Peter has written so eloquently about it
- Peter shares that he is long past that ‒ he might have 30 years left on Earth
- It’s real, and that also has an impact

***What motivates you 20 years from now might be different from what motivates you today, but what’s important is if you’re paying attention and nurturing that motivation***

- If you’re conducting experiments to see what does motivate you and what doesn’t motivate you

***It’s when we stop thinking about it that we get in trouble***

**Closing thoughts**

- Peter found this conversation super interesting (Charles too)
- Peter read [*Super Communicators*](https://www.amazon.com/Supercommunicators-Unlock-Secret-Language-Connection/dp/0593243919/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)last spring when it came out
- What he wanted to talk about today was a book Charles wrote 12 years ago [[*The Power of Habit*](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80)]
  - Peter would recommend everybody read everything Charles has written, but this is, in some ways the book that can have a greater impact on people’s lives
  - It’s an exceptional book, and Peter hopes that we’ve spurred people to go back and try to apply it
- In many ways, what Charles wrote about is the book end of what Peter is trying to write about

***Peter is trying to write about what you need to do, but at the end of the day, if you can’t create habits around these things, it is difficult***

---

## Selected Links / Related Material

**Charles books**:

- [The Power of Habit: Why We Do What We Do in Life and Business](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80) by Charles Duhigg (2012) | [1:00, 3:30, 48:45, 1:14:30, 1:46:31, 2:10:45]
- [Smarter Faster Better: The Secrets of Being Productive in Life and Business](https://www.amazon.com/Smarter-Faster-Better-Productive-Business/dp/081299339X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80) by Charles Duhigg (2016) | [1:00, 19:15, 1:27:15]
- [Supercommunicators: How to Unlock the Secret Language of Connection](https://www.amazon.com/Supercommunicators-Unlock-Secret-Language-Connection/dp/0593243919/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80) by Charles Duhigg (2024) | [1:00, 1:17:15, 1:52:45, 2:10:45]

**The science of handwashing**: [Warning: Habits May Be Good for You](https://www.nytimes.com/2008/07/13/business/13habit.html) | Charles Duhigg, *The New York Times* (July 13, 2008) | [6:30]

**Book by Angela Duckworth**: [Grit: The Power of Passion and Perseverance](https://www.amazon.com/Grit-Passion-Perseverance-Angela-Duckworth/dp/1501111108) by Angela Duckworth (2016) | [32:45]

**Carol Dweck’s book**: [Mindset: The New Psychology of Success](https://www.amazon.com/Mindset-Psychology-Carol-S-Dweck/dp/1400062756/ref=tmm_hrd_swatch_0) by Carol Dweck (2006) | [49:00]

**Ryan Holiday’s book**: [Stillness Is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0) by Ryan Holiday (2019) | [1:41:00]

**Episode of *The Drive* with David Epstein**: [#96 – David Epstein: How a range of experience leads to better performance in a highly specialized world](https://peterattiamd.com/davidepstein/) (March 9, 2020) | [1:50:30]

**Nonfiction book about the psychology of people involved in space flight**: [The Right Stuff by Tom Wolfe](https://www.amazon.com/Right-Stuff-Tom-Wolfe/dp/1250338352/ref=tmm_pap_swatch_0) (first published in 1979, 2024 edition) | [1:54:30]

---

## People Mentioned

- [Val Curtis](https://en.wikipedia.org/wiki/Val_Curtis#) (1958-2020, British scientist and director of the Environmental Health Group at the London School of Hygiene and Tropical Medicine, expert in human behavior who worked to improve hygiene and sanitation) [9:30]
- [Daniel (Danny) Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) (1934-2024, Israeli-American psychologist best known for his work on the psychology of judgment and decision-making as well as behavioral economics, for which he was awarded the 2002 Nobel Memorial Prize in Economic Sciences together with Vernon L. Smith)  [9:45]
- [Amos Tversky](https://en.wikipedia.org/wiki/Amos_Tversky) (1937-1996, Israeli cognitive and mathematical psychologist and a key figure in the discovery of systematic human cognitive bias and handling of risk) [9:40]
- [Wendy Woods](https://en.wikipedia.org/wiki/Wendy_Wood_(psychologist)) (UK-born psychologist who is the Provost Professor Emerita of Psychology and Business at [USC](https://en.wikipedia.org/wiki/Wendy_Wood_(psychologist)), expert in habits and behavior change) [11:00]
- [Katherine (Katie) Milkman](https://oid.wharton.upenn.edu/profile/kmilkman/) (James G. Dinan Endowed Professor and Professor of Operations, Information and DecisionsWharton University of Pennsylvania, expert in decision making and behavior change) [27:15]
- [Anna Lembke](https://profiles.stanford.edu/anna-lembke) (Professor of Psychiatry and Behavioral Sciences at Stanford University, expert in addiction, author of [*Dopanine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)) [28:45]
- [Angela Duckworth](https://angeladuckworth.com/about-angela/) (The Rosa Lee and Egbert Chang Professor at the University of Pennsylvania and faculty co-director of the Penn-Wharton Behavior Change for Good Initiative., author of [*Grit: The Power of Passion and Perseverance*](https://www.amazon.com/Grit-Passion-Perseverance-Angela-Duckworth/dp/1501111108)) [32:45]
- [James Prochaska](https://en.wikipedia.org/wiki/James_O._Prochaska) (1942-2023, Professor of Clinical and Health Psychology at the [University of Rhode Island](https://web.uri.edu/cprc/meet/james-prochaska/), developed the Transtheoretical Model of Behavior Change)  [38:00]
- [Bill W](https://en.wikipedia.org/wiki/Bill_W.) (Founder of AA) [46:00]
- [Carol Dweck](https://profiles.stanford.edu/carol-dweck) (Professor of Psychology at Stanford University, expert in self-regulation and behavior, author of [*Mindset*](https://www.amazon.com/Mindset-Psychology-Carol-S-Dweck/dp/0345472322)) [49:00]
- [Yuri Hassan](https://hassonlab.princeton.edu/people/uri-hasson) (Professor of Psychology and Neuroscience at Princeton University, expert in understanding how the brain processes human face-to-face communication) [1:21:30]
- [Richard de Crespigny](https://en.wikipedia.org/wiki/Richard_de_Crespigny) (Australian Qantas pilot and author who was in command and successfully landed Qantas flight 32 after engine failure) [1:28:00, 1:34:15]
- [Sully Sullenberger](https://en.wikipedia.org/wiki/Sully_Sullenberger) (retired aircraft pilot, diplomat and aviation safety expert; successfully landed US Airways Flight 1549 in the Hudson River) [1:34:15]
- [Ryan Holiday](https://ryanholiday.net/about/) (Media strategist and author of [*Stillness is the Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0) and other books) [1:41:00]
- [Cal Newport](https://calnewport.com/) (Computer Science Professor at Georgetown University who writes about the quest to find depth in a distracted world) [1:42:30]
- [David Epstein](https://davidepstein.com/david-epstein-about/) (author of New York Times best seller [*Range: Why Generalists Triumph in a Specialized World*](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._EWE5k4hm_YEga2VmqLcA9-3l1u3sKZ4-cO0PqZ7gQKjITpb_bVHb9FCF3DHOi_C.1_9koyTX0wfVPDbWfUE-osRP52Len16JsOiUi5MqXT4&qid=1752093190&sr=1-1)) [1:50:30]
- [Tony Robbins](https://www.tonyrobbins.com/the-story) (Author, coach, and motivational speaker) [2:06:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/07/p49_Charles_Duhigg.jpg)

##### Charles Duhigg, M.B.A

Charles Duhigg earned an undergraduate degree in history from Yale and an MBA from Harvard Business School. He worked as a staff writer at *The Los Angeles Times* where he reported from Iraq about American military operations. He then worked as a reporter for *The New York Times,* and it was during this time that he won the 2013 Pulitzer prize in explanatory journalism for “The iEconomy,” a series that examined the global economy through the lens of Apple. Charles has also received The George Polk award, the Gerald Loeb award, the Investigative Reporters and Editors Medal, the Scripps Howard National Journalism award, the Robert F. Kennedy Journalism Award, and other honors. Today, Charles writes for *The New Yorker* magazine.

Charles is a Pulitzer prize-winning journalist and the author of [*The Power of Habit*](https://www.amazon.com/Smarter-Faster-Better-Productive-Business/dp/081299339X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80), which spent over three years on bestseller lists and has been translated into 40 languages, [*Supercommunicators*](https://www.amazon.com/Supercommunicators-Unlock-Secret-Language-Connection/dp/0593243919/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80), also a bestseller published in 2024, and [*Smarter Faster Better*](https://www.amazon.com/Smarter-Faster-Better-Productive-Business/dp/081299339X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.GKvpwBdYV3i8PY9-0c4ZsMNMWwzYcPEZ-MmMYnbrEKx3jTrpl8bDoZ253XyfQ6gRa6SF3pg_ljY7fyVKpatXM58I_QfNhLrzfY3pLwyGJ9VA6ufI2dDYZ_h5E8ousnad3nZRUC9JC4FOZeX1vRuxW2MtMYtN83UUwtGvdhiAt5EofRJtORv2jeW0IVJFrZJnNN1Q4tpWdLClr2OnM-zsTVzHczIzaAixzCwFqjpMKhw.NSQIPcFJd1Sgx7AwW-oT7g4AGW--LySZQI682OCkT80), a third bestseller. [[Charles Duhigg](https://charlesduhigg.com/about/)]

Facebook: [Charles Duhigg](https://www.facebook.com/charlesduhigg/)

Instagram: [@charlesduhigg](https://www.instagram.com/charlesduhigg/?hl=en)

LinkedIn: [Charles Duhigg](https://www.linkedin.com/in/charlesduhigg/)

Newsletter: [*The Science of Better*](https://charlesduhigg.com/newsletter/)

Substack: [The Science of Bette](https://charlesduhigg.substack.com/)r

Website: [CharlesDuhigg.com](http://charlesduhigg.com)

X: [@cduhigg](https://x.com/cduhigg?lang=en)