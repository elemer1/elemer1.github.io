# #248 ‒ OUTLIVE book: A behind-the-scenes look into the writing of this book, motivation, main themes, and more

**Source:** [https://peterattiamd.com/outlivepodcast/](https://peterattiamd.com/outlivepodcast/)

---

After more than six years of research, planning, and writing, Peter’s book, [*Outlive: The Science and Art of Longevity*](https://peterattiamd.com/outlive/), is officially available as of March 28th. In this episode, Peter sits down with co-author Bill Gifford to provide a behind-the-scenes look into the writing process, including the motivation for making it happen, how the book evolved over the course of the writing process, and why certain topics were chosen (and omitted). Additionally, they discuss how the book is structured and touch on a few of the book’s main themes to give potential readers an idea of what they can expect.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/outlivepodcast/the_Drive_public.png)

Play

#248 ‒ OUTLIVE book: A behind-the-scenes look into the writing of this book, motivation, main themes, and more

#248 ‒ OUTLIVE book: A behind-the-scenes look into the writing of this book, motivation, main themes, and more

1x15s30s

0:001:41:42

## We discuss:

- The meaning of the book’s title and subtitle [3:00];
- Finding the right art for the book cover [9:00];
- Who is Bill Gifford, and how did he get involved in the book? [16:15];
- How Peter’s writing evolved over the six years it took to write this book [25:00];
- The structure of the book and what people can expect to learn [29:00];
- How the writing of the book and the podcast interviews have shaped Peter’s thinking and approach to translating science [32:45];
- Making the book stand the test of time despite the constant evolution of science and medicine [36:00];
- Objective, strategy, and tactics [39:30];
- Exciting possible progressions in science and medicine over the next decade [42:15];
- What is holding back “medicine 3.0” from being the norm? [46:00];
- How the book compares to the podcast in terms of technicality and readability for the layman [49:00];
- Motivation to write the book and insights into challenges around the writing process [57:15];
- Peter’s decision to be the reader for the audiobook [1:10:30];
- The many painstaking last-minute changes and edits that brought the book together and made it better [1:19:00];
- Peter and Bill’s favorite parts of the book [1:27:30];
- The incredible team of people supporting the book [1:31:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- This is a special episode of *The Drive*, after more than six years of planning and background research, writing, editing, rewriting, rewriting, rewriting, Peter’s first book, [*Outlive: The Science and Art of Longevity*](https://peterattiamd.com/outlive/), is coming out tomorrow on March 28th
- Today he is joined by co-author Bill Gifford to answer a lot of questions posted over the past few months, about the book
- This conversation is really a discussion around the book and a behind-the-scenes look at the past six years that it took us to write this book
- It includes a lot of details around the process that Peter hasn’t really spoken about elsewhere, and he addresses why it took so long
- For those of you that end up buying the book and reading it, we hope this discussion will prove useful
- This podcast will provide a lot of the background and hopefully explain why Peter and Bill wrote about what they did and why they omitted certain things
- Before we get to the episode, as cheesy as this probably sounds, Peter wants to thank everyone who’s listening for all your support, “*Without you, there wouldn’t be a podcast… And frankly, without a podcast, this book wouldn’t be half as good.*”
- As Peter notes in the acknowledgement section of the book, the best part of the podcast is that he is forced to prepare in great depth to interview someone or to be interviewed in response to the AMAs
  - In doing that, he is generating knowledge that he’s able to translate into this book
- This is the first time we’ve ever done a podcast with three people in person
- Nick Stenson collected a ton of questions from the audience on wanting to understand the process of the book, who Bill is, what the cover means, what is talked about, etc
  - He’s going to ask the questions, and it should be a fun way to learn more about the book

## The meaning of the book’s title and subtitle [3:00]

**Peter, how’s the voice doing? Do you want to tell people how the book tried to kill you through your voice?**

- It’s 80% back to normal
- The book has tried to kill us in many ways, but most recently, between reading the book for audiobook, getting a virus, having a hectic travel schedule to try to do some podcasts, Peter developed the worst case of [laryngitis](https://en.wikipedia.org/wiki/Laryngitis) and a [pharyngeal](https://en.wikipedia.org/wiki/Pharynx) abscess
  - That caused his vocal cords to stop working
  - But he has enjoyed not speaking for two weeks; it was amazing how many things he got to tune out

*How did the family take that? Did they use it to their advantage?*

- They loved it
- It was funny, the first couple of days everybody else got very quiet in response to Peter being quiet
- This was one of the few times social media turned out to be insightful and helpful
  - After Peter posted the second [video](https://www.instagram.com/p/Cozo0cIDxWT/) of his direct [laryngoscopy](https://en.wikipedia.org/wiki/Laryngoscopy), someone astutely commented, “*Hey Peter, by the way, don’t whisper… Whisper is a bad form of foundation. It’s actually teaching you the incorrect movements. Either don’t speak or speak normally, but at the lowest volume possible.*”
  - This made a lot of sense because his throat was starting to hurt from all the whispering
- Peter has been talking very quietly, and his boys are not quiet, but they got quiet in response to him being quiet
  - He’s got to figure out a way to do this enduringly
  - The quieter you are, the quieter they are back

**We understand “Outlive” and what that means, but where does the “The Science and Art of Longevity” come from, and why was that so important to include in the title?**

- The title was an evolution
- The first title Peter had in mind was *The Longevity Manifesto*, which was an awful title and got scrapped immediately
- The working title during 2016 was *The Long Game*
  - That was quickly replaced by *Outlive*
- Outlive is very evocative and simple, and it’s an action
  - It could mean different things to different people ‒ you’re going to outlive your expectations or outlive your parents or your grandparents
  - The idea is, your fate is not set in stone

*Why was “Science and Art” chosen for the subtitle?*

- Peter felt that there were two things that needed to be communicated
  - 1 – the study of human longevity is part science and part art, but the **science** should come first
    - That’s why Peter wanted to flip that order and say it’s the science and art of longevity
    - The book makes a pretty good case for where the application of both science and art come into play
    - If this were a book about mouse longevity, it could just be the science of longevity because in mice you can do all of the definitive experiments and answer all these questions
  - 2 – In humans, as is readily apparent, we will never know definitively what the answers are, and therefore we always have to have some art involved

**Peter often says longevity has two components: Lifespan— how long you live, and the healthspan—how well you live.**

***Why wasn’t lifespan or healthspan used in the title?***

- Peter thinks “outlive” encompasses both
- And to Bill’s earlier comment, “*Outliving is more than about the chronological years of life. It’s about the quality of life as well.*”

## Finding the right art for the book cover [9:00]

**Can you explain the cover art?**

- There were two things that in the back of Peter’s mind that were enormous stressors as they got closer and closer to the finish line, in the spring of 2022
- At that time, the book was 190,000 words so they knew it was going to be cut down
- But the two stressing questions in Peter’s mind were:
  - 1 – How could this book be represented in a cover?
  - 2 – Who was going to read this book for the audiobook?
- In the summer the publisher gave them a checklist of things to do for the book to come out in March
- Peter has very strong opinions about everything, but couldn’t even offer an opinion on the cover
  - All he could say was, “*I want it to be elegant… timeless. I don’t want it to be too busy*”
  - He’s a font fanatic, so he understood the fonts he wanted but had no sense artistically of what was wanted
- In August Bill sent an email to [Rodrigo Corral](https://rodrigocorral.com/about)
  - Bill’s sister is a book designer, and Rodrigo is revered in those circles
  - They looked at some of his designs, “*And it really kind of pops*”
- While this was happening, the publisher was also churning out designs
- Bill contributed a lot of things to this project, and the single most important thing he contributed was being adamant that they engage with Rodrigo
  - In October, they were trying to decide on a design and had settled on one that Peter felt was a solid 7 out of 10, and Bill was adamant, “*This is bullshit, man. We’ve worked way too hard on this book to have a 7 out of 10 cover. We go and get Rodrigo and it doesn’t matter how much it costs and it doesn’t matter how much it slows the process down, we do it.*”
  - Peter agreed, he didn’t want to regret this; so they reached out to Rodrigo
- They had a long call with Rodrigo, and just talking with him about the book illustrates what makes great artists great
  - Rodrigo didn’t have a chance to read the whole book
  - Within three days he threw up 30 covers that were all totally different
  - They were all evocative of this concept of longevity and outliving, living better, etc.
- Bill was telling Nick about the Korean cover of his book [*Spring Chicken*](https://www.amazon.com/Spring-Chicken-Young-Forever-Trying/dp/1455527440/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=); it portrayed a fat guy on a beach chair frying an egg
  - And that’s supposed to mean longevity
  - There are many ways the cover can go off the rails
- The cover below wasn’t Peter’s favorite at first, but it was in his top 6

![](https://peterattiamd.com/wp-content/uploads/2023/03/f1-bookepisode.png)

**Figure 1. The book cover** .

- Rodrigo sent over 30 covers, and Peter and Bill each picked their top five or six; they both chose this cover
  - There wasn’t a bad cover in the list of 30
- Originally it had a different font, and this threw Peter off the first time round
- They ultimately decided this was the winner
- Peter wishes he could tell you that the blue, green, yellow, pink all signifies something
  - It signifies a keyhole that you’re walking through
  - It’s a passage, but it also looks like a target
  - There’s a very subtle theme in this book about lots of metaphors that revolve around archery
- Bill showed it to various people and everybody liked it for a different reason
  - It’s like an aura
  - The little guy is going into the beyond, into the future
- The little guy was an important part of the design

> “*It was different things to different people, and that spoke to the art side of it, science and art*”‒ Bill Gifford

- Peter thinks he drove everybody insane with all the font changes he made
  - He is fanatic about fonts
  - For example, the comma in San Serif looked crude so he wanted to use a different font for just the comma
    - This made sense to Rodrigo but everyone else was like, “*Jesus Christ*”

## Who is Bill Gifford, and how did he get involved in the book? [16:15]

**How did Bill Gifford get involved with the book?**

- Bill got connected with Peter at the end of 2017; out of the blue, Peter sent him an email
- Bill knew who Peter was
  - In the course of researching his book about longevity ([*Spring Chicken*](https://www.amazon.com/Spring-Chicken-Young-Forever-Trying/dp/1455527440/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)) he had read Peter’s insane [13-part series](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-i/) about [cholesterol](https://peterattiamd.com/category/diseases/cholesterol/page/4/)
- Bill thought he was done with longevity, but this seemed interesting
- When Bill was a kid, while other kids’ dads were throwing the football (or baseball) around, his dad took him to the library
- He eventually became a writer; he loves writing and words
  - At one point in college, he thought he would be a poet
  - He realized he liked connecting with people through writing, and he evolved from general journalism into writing  more and more about scientific and medical topics, sports performance, doping and cycling, etc.
- Like Peter, when he because a certain age he realized he is not the guy he was 10 years ago and became interested in the process of aging
  - It’s a big sort of biological mystery; it’s super fascinating, and it’s not been solved
- Bill ended up writing about longevity
- He writes a lot about athletes too, and found himself writing about older athletes like [Phil Mahre](https://en.wikipedia.org/wiki/Phil_Mahre) (the skier who came back to racing when he was 50)
  - Phil competed against 22-year-olds
  - That kind of longevity fascinates Bill as well

**What caused Peter to reach out to Bill?**

- Peter was working with an agent in 2016, and the book got sold to a different publisher
- He was working on the book nights and weekends while doing his day job, and was finally ready to submit the first part of the book (just under 40,000 words)
  - He submitted it to his agent, who submitted it to the publisher
  - By this point, the editor who had bought the book had left
  - Another editor comes on, but she doesn’t have as much invested in the book, and gives Peter a very lukewarm response
- The editor had two huge criticisms ‒
  - 1) the book was too technical
  - 2) there was no narrative—It was mostly a scientific treatise on the subject matter
- Peter’s agent and publisher both suggested bringing on a co-author to help make it a better book for the layperson to read
- So every week that Peter was in New York, he was meeting another author
  - What would usually happen is they would send him one of their books; he would skim it and sit down with them
  - He went through five or six, but none of them got his book
- So Peter asked [Bob Kaplan](https://www.linkedin.com/in/bobckaplan) for ideas, and he suggested looking for somebody who’s written about what Peter finds interesting, and the first thing Peter remembered was [Bill’s piece for *Bloomberg* on rapamycin](https://www.bloomberg.com/news/features/2015-02-12/does-a-real-anti-aging-pill-already-exist-#xj4y7vzkg) (in 2015)
  - Most articles on this topic were so simplistic and missed the point, but this was a very good article
  - Peter said to Bob, “*This is the guy, because he already gets it.*”
- Somehow Peter got Bill’s email, and they met up for dinner on the Upper East Side one day in late 2017
  - Peter sent him the proposal to read, around 5,000 words; it had the central ideas of part one
- Bill comments about writing, “*Starting is super hard, and then keeping going is even harder, and then figuring out that you’re done, is the hardest of all.*”
- Peter had a start on the book at the time they met; he had no idea how hard this project would be
  - It was so much more time-consuming than anything he could have imagined
  - He remembers in the early days, spending a lot of time in front of a whiteboard in his office, outlining the pillars, the foundations, the frameworks
- The structure that emerged in the final book in 2018/2019 was basically three big sections that are important and build on the others
- Version one of the book was pre-Bill, version two was written from the beginning of 2018 through the beginning of 2020
- Bill remembers in their initial meeting Peter ordering about half the menu at the Turkish restaurant
  - This was when Peter was eating just one meal a day, about 3000 calories at dinner
  - Bill knew, “*Whatever this is going to be, it’s not going to be dull*”

**When Bill came onboard, they had the basic template for what the book was going to be**

- About 25% Peter’s manifesto
- The basic biology of aging, rapamycin stuff, mechanisms and hallmarks of aging (molecular/ cellular-level stuff)
- Maybe 5% tactics
  - Peter didn’t want any tactics, maybe in an appendix
  - Now there is 200 pages on tactics
- *What did the publishers say when you said, I’m actually not going to tell anyone what to do in this book?*
  - “They were apoplectic” says Peter

## How Peter’s writing evolved over the six years it took to write this book [25:00]

**What do you think was so hard about the process?**

*Was it translating the science into something that was more of a story?*

*Was it figuring out how to verbalize the frameworks?*

*Was it just getting what was in your head cohesively on paper?*

- Peter loves writing; he’s been blogging for as long as he can remember, but that is a very different style of writing
  - Bill mentioned Peter’s [series on cholesterol](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-i/); you don’t have any constraints when you’re blogging
  - You can go as deep as you want to go because you are attracting an audience of similar weirdos who are going to go as far down the rabbit hole as you will take them
- It was a big struggle to switch from the writing style he used for his blog to the final version of the book
  - Bill tolerated a lot of things Peter was writing; he made footnotes like. “*All right, I really want to delete all of this.*” Or, “*Let’s put this in a footnote.*”
  - Three years later, Peter was the one deleting those footnotes, realizing it was gratuitous and doesn’t matter that much

***Peter’s writing underwent a remarkable evolution***

- For example, Peter wondered if he needed to explain extracorporeal circulation of the liver in a particular section and Bill would point out, “*I don’t think that’s really important*.”
  - For Peter, understanding the portal blood flow was important for understanding why glycogen gets there
  - Bill assured him, “*There are seven people who give a shit about that.*”
  - So they would make it a footnote and Peter would be pissed, but two years later he was the one deleting it
  - Bill points out, “*You have to know it though, to be able to write intelligently*”

***You get into the weeds and you have to know all the weeds to write well about science, but then you have to leave a lot of stuff out***

- Peter remembers when he was writing his first (or second) scientific paper
  - You do a lot of experiments, most of which don’t make it into the paper
  - [Dan Powell](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8186734) was one of the postdocs in the lab with Peter, and he said, “*You just have to learn how to kill your babies. You’re going to throw out 90% of this.*”
- It was hard for Peter to get to the point of being okay with the reader not knowing all the stuff below the surface, just appreciating the piece of the iceberg above

> “*Ultimately the readers will determine if we’ve struck that balance correctly*”‒ Peter Attia

- Peter thinks they did; this became readily apparent when he read the audio version of the book because when you’re reading it out loud, it’s very different from when you read it during editing
  - You’re reading it much slower, and you realize the unnecessary interruptions of endless footnotes that are incremental in what they’re adding
- Nick recalls Peter saying that practically none of the first iteration of the book made it into the final version
  - Not in direct content
  - In spirit, some of it made it to the final version

## The structure of the book and what people can expect to learn [29:00]

**The structure of the book**—**3 main parts**:

**Part 1** sets up the structure of the book, conveys the frameworks

- As a reader you understand the problem statement
- This explains what longevity is *and* isn’t
- It also explains something called [**medicine 3.0**](https://peterattiamd.com/ama41/), which is the vehicle through which you pursue longevity

> “*You can’t solve or even attempt to solve complicated problems if you aren’t asking the right questions and you don’t have the right frameworks.”* —Peter Attia

**Part 2** is the most technical part of the book; it gets into the scientific underpinning of everything, coupled with “*Get to know your opponents*”

- A big part of the book is trying to figure out how to live longer
- They argue convincingly that a person reading this book who puts these principles into practice is really thinking about elongating their life by 5-10 years
  - But to do that you really have to understand what are the things that are coming to take your life, and this is covered in part 2

**Part 3** is focused on how to put this into practice

- Peter initially didn’t want to write this section, but it turned out better than he ever could have imagined
  - Bill notes, “*It organically evolved and kept growing and changing*”

Back to **part 2**…

- Both Bill and Peter were fascinated by **centenarians**, and hammering out that chapter was a revelation ‒ it’s not a big mystery how these people live to 100 when most people live to 80
  - They get heart disease much later, if at all; and the same is true for cancer and neurodegenerative disease
  - That’s the ballgame, you’ve got to figure out how to delay all those diseases, which Peter calls horsemen
- They didn’t contemplate writing those chapters at the beginning before they decided you have to know your enemy/ opponent
- The first version they wrote together (the second version of the book) was much heavier in the molecular science of aging
  - It went really deep into [autophagy](https://en.wikipedia.org/wiki/Autophagy), [nutrient-sensing](https://en.wikipedia.org/wiki/Nutrient_sensing) pathways, etc.
- Ultimately they pivoted more toward the insight that ***there are two completely different strategies to live long***
  - 1 – Extend the period of time you live once you have a disease; this is everything **medicine 2.0** does
  - 2 – Extend the time you live without a disease; this is **medicine 3.0**
    - For #2, you have to know everything about these diseases

> “*We have to figure out a way to drag out the time you live without a disease and you can’t play that game if you don’t know everything about these diseases. You have to become so intimately familiar with each of the horsemen.*”‒ Peter Attia

- There is a very robust chapter on each of those horseman (heart disease, cancer, and neurodegenerative disease)

## How the writing of the book and the podcast interviews have shaped Peter’s thinking and approach to translating science [32:45]

**Do you think how you practice medicine and what you talk about on the podcast and weekly newsletters would evolve to what it is if you didn’t write the book?**

- They help each other for sure; you can’t write well if you don’t think well
- The relentless process of streamlining and figuring out how to get to the point sooner have an impact
- A lot of what’s written in there comes out of conversations Peter has with patients
  - He walks them through their cardiovascular disease risk
  - He gives the same talk to patients constantly and often records them; it has been helpful to go back to those recordings and remember what worked
- Bill notes that Peter started the podcast six months into the book-writing process (June 2018), and he noticed that it gradually made Peter more cognizant of how to communicate science and medical topics
  - Peter is a very data-driven, mathematical guy
  - Doing the podcast allowed him to learn how to  introduce these subjects in a more user-friendly way than simply presenting the numbers and facts straight-up
- Peter remember in the summer of 2017 when he was working on version one of the book, he was effectively podcasting without podcasting
  - He was flying around interviewing people ‒ [David Sabatini](https://www.davidmsabatini.com/), [Matt Kaeberlein](https://dlmp.uw.edu/faculty/kaeberlein), meeting with postdocs in their labs, recording interviews with them
  - Other initial interviews for the book also ended up being podcasts, examples are [Iñigo San Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) and [Rick Johnson](https://som.cuanschutz.edu/Profiles/Faculty/Profile/9426)
- Bill recalls Peter excitedly recommending he listen to a lot of those interviews
  - These fed into both the writing of the book and the evolution of thinking behind the book

## Making the book stand the test of time despite the constant evolution of science and medicine [36:00]

**How do you think the book will stand the test of time?**

**Secondly, how did your mindset evolve over the six years it took to write the book?**

- There were changes in science during those six years as well as personal things for Peter which influenced what made it in the book
- Mostly the emphasis of certain things changed over this time
  - For instance, at the outset of writing, Peter placed more of an emphasis on **nutrition** more than **exercise** as one of the important levers we have at our disposal; but now his view on this has flipped
  - He now thinks exercise has a bigger impact than nutrition, certainly for positive benefits
  - Nutrition can have a pretty big negative impact, but once it’s corrected, it doesn’t have an enormous upside
  - Whereas exercise has an enormous downside in its absence and an enormous upside in its presence
- The book written five years ago would not have had anything about **emotional health**
  - There’s not a lot on it, but there is something; and Peter thinks it’s relevant

**How Peter tried to make the book stand the test of time**:

- The book is very framework-focused, which lends to a more timeless piece because frameworks are scaffoldings upon which to place information and substitute information
- The **frameworks** are relatively timeless as a strategy, for example, “*Delay the time that you do not have disease*”
- We’re going to learn different things about these diseases in 10 years
- For example, Peter hopes liquid biopsies will be a lot more valuable in 10 years than they are today
  - That’s going to completely change our approach and our efficacy of cancer screening
    - If you can detect cancer much earlier, treating it is a whole different thing
  - You’ll have a different tactic that you’ll use in a toolkit to go about the strategy, but the goal is still the same
- People who have listened to the podcast for a long time will recognize that Peter talks about things in a different way as he learns more information
  - A natural reaction is for people to be frustrated and wonder why he said something different before and what changed his mind
- Furthermore, the book focuses heavily on **objective, strategy, and tactic**
  - The initial version of the book had zero tactics; instead, Peter focused heavily on the objective and strategy
  - His reasoning for initially not wanting to include tactics was that as new information comes in, the tactic may change but the objective and strategy does not

## Objective, strategy, and tactics [39:30]

***How does Peter think about that objective, strategy, tactic?***

- There is a whole chapter in part one on the simple concept of **defining the objective**
  - It’s amazing how often this is ignored and how many people struggle to define their objective
  - People often think, “*I’m taking these 27 different supplements because I’m hacking my whatever*,” but they can’t tell you their objective
- Strategy is important, and each chapter opens with a quote
  - One of Peter’s favorite quotes is from [Sun Tzu](https://ctovision.com/quotes/sun-tzu-strategy-without-tactics-is-the-slowest-route-to-victory-tactics-without-strategy-is-the-noise-before-defeat/), “*Tactics without strategy is the noise before defeat*”

***The book goes to great lengths using lots of examples to really help a person understand the difference between a strategy and then the tactics that they employ***

- The tactics are the most malleable things here
  - They’re the things that are going to change the most and have already changed the most

*Examples of how tactics can change*:

- Think about the emphasis Peter used to place on **fasting**; this is totally different today
- Also, Peter is positive that there is some set of drugs that he will be taking in 10 years (that he’s not taking today); additionally, there probably something he is taking now that in 10 years he’s going to say, “*The evidence for this sucks, I’m not going to do it*”
  - If he can’t take that and anchor it back to a strategy, all he’s really doing is just a bunch of random things that aren’t in concert
    - I.e., The reason he would take this drug (or wouldn’t take that drug) is because it feeds into one of the three overarching principles that guides the subjective
- Bill notes that Peter is able and open to changing his mind, “*One of the things I noticed early on is you’re not a dogmatic person if you get information or a new interpretation of the existing data that causes you to see something differently. And fasting is a big one*.”
  - Bill was relieved that Peter’s view on fasting changed because he knew he was going to have to do one to be able to write about it, and he wasn’t looking forward to it
  - While there are situations where fasting makes sense, Peter now thinks that fasting *isn’t* something that everybody needs to be doing

## Exciting possible progressions in science and medicine over the next decade [42:15]

*What are you really excited about in terms of progress in the next 10 years?*

- Peter mentioned liquid biopsies and cancer detection, and he takes a very aggressive posture on **cancer screening** for the reason Bill stated earlier ‒ the earlier you catch cancer, the better your odds are at treating it while it remains local
- There are two camps on this:
  - 1 – Are you of the mindset that we will come up with systemic cures for cancer regardless of size and stage in the next couple of decades?
  - 2 – Or do you think it is more likely that we will get better and better at finding cancer when it is smaller and smaller and treating it with existing therapies?
- These two don’t have to be mutually exclusive, but which one do you think is more likely?
  - Peter thinks #2 is more likely
- Goal #1 don’t get cancer, goal #2 if you do get cancer, catch it as early as possible, and goal #3 are new promising therapies
  - For goal #3, the progress of [cancer immunotherapy](https://en.wikipedia.org/wiki/Cancer_immunotherapy) is exciting; Peter thinks, “*We are right on the verge of unlocking the next layer of immunotherapies*.”

What else is Peter excited about in the cancer space over the next 10 years? ⇒ if we could **reprogram immune cells**

- This is too soon for prime time
- Reprogramming an immune cell would be a game changer, and it would be much easier than reprogramming your heart/ liver because of how easily we can access those cells
- If we could epigenetically reprogram T-cells, it would be a totally different game when it comes to cancer therapy and cancer incidence

Bill is excited about **developments in neurodegeneration, treatments** for Alzheimer’s disease or Parkinson’s disease for which there is no effective treatment

- Peter hopes there will be better data on **prevention**; currently in Peter’s practice they take a “kitchen sink” approach
  - There are 3-4 things where the data is clear that these factors reduce your risk of dementia ‒
    - i) exercise
    - ii) management of lipids
    - iii) sleep, and
    - iv) not having diabetes
  - There are 27 other things for which the data are not yet clear, and it would be great to have more clarity around that

## What is holding back “medicine 3.0” from being the norm? [46:00]

- The book talks a lot about the difference between medicine 2.0 and 3.0 and why 3.0 is not the norm

**Why is the traditional view of cancer screening different from the view presented in the book?**

- This is asking two different questions
- The question and solution proposed in the book is at the *individual level*
- The outside view is at the *population or societal level*

There was a recent [study](https://www.nejm.org/doi/full/10.1056/NEJMoa2208375) published in the *New England Journal of Medicine* that got a lot of attention in Europe; it looked at **colonoscopies**

- A large group of people were randomized into two groups
  - One group received the standard of care, which was don’t do anything
  - The next group was recommended to have a colonoscopy in the next decade
- At the end of the decade, the rates of colon cancer and colon cancer mortality and all cause mortality were compared between the two groups
  - There was nothing to write home about, the relative and absolute difference in colon cancer and colon cancer deaths, while statistically significant, didn’t seem very clinically significant
  - Opponents of colonoscopy said, “*Look, this is proof-positive that colonoscopies don’t save lives*.”
  - Peter points out, “*No, it’s proof-positive that telling people to maybe get a colonoscopy once every 10 years, when by the way, I think less than 40% of them actually did, probably doesn’t save lives*.”
  - Peter writes about this study in a [newsletter](https://peterattiamd.com/colonoscopy-and-acm/)
- The approach to colonoscopies that Peter takes is very different; he is 50 and has already had three colonoscopies
  - He gets one every three years and will continue to do so
  - Does he suggest that everyone get a colonoscopy every three years? No
  - There’s an enormous cost to this because his insurance company doesn’t pay for most of these (they paid for one)
  - There are risks of bowel preps; in an older person there is risk from the electrolyte abnormalities that come from those
    - Peter wouldn’t want his 86-year-old dad getting a colonoscopy under any circumstance, “*That ship has sailed. The bowel prep alone could injure him, let alone the sedation of it.*”

> “*What I’m suggesting is that everybody think about their own risk reward trade-off and decide what’s the cost benefit analysis.*”‒ Peter Attia

- One has to be very thoughtful and measured in how they think about doing these things

***The long answer to this question is ‒ when people talk in blanket statements like “Cancer screening is bad,” they’re generally speaking through the lens of policy and population***

## How the book compares to the podcast in terms of technicality and readability for the layman [49:00]

**How does the book compare to the podcast in terms of technicality? Will the layman be able to get as much out of the book as a MD PhD?**

- Sometimes on the podcast, it can get technical, it can really get into the weeds
- Bill notes that both he and Peter are fascinated with the technical details, they can go down these “rabbit holes” of technical details
  - He calls this the alphabet soup, when you start streaming together a lot of acronyms (APOE, PSN, etc.)
- Bill thinks of the podcast as Peter’s playground to go deep with scientists, and it’s tremendously valuable

***The book is considerably less technical than the podcast***

- The book covers a lot more ground, so they can’t go too deep on any one topic
  - Bill recalls the recent [episode on HDL](https://peterattiamd.com/danrader/); it was super interesting but mind-bogglingly complicated, and the book didn’t have the time or need to go that deep
- Peter notes that the cardiovascular section is pretty detailed
  - They were trying to add enormous value in writing this
- There are a lot of “me-too” books out there on this subject, meaning just another book that is literally adding no value, just saying the same thing
  - There is no chapter in the book that would check this box
- Peter thinks the chapter on atherosclerosis probably goes deeper than the editor would have wanted, but ***you don’t need to necessarily understand every word of it to understand what to do about it***
- But if you do want to go deeper, the book talks about:
  - [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein) and how HDL functionality is not captured by measuring HDL cholesterol and HDL particle number and apoA concentration, etc.
  - It talks about what [Mendelian randomizations](https://en.wikipedia.org/wiki/Mendelian_randomization) have taught us (and have not) with respect to HDL
  - And this is probably a little more technical that the average person would want

***Overall, this book is very readable by a person who is curious. And I agree that it is definitely a notch below the technical depth of what we often do in our podcasts.***

- It’s not meant to be a textbook, but they wanted people to learn more than they expected (without realizing that they’re learning)
  - The atherosclerosis chapter is a good example of that because everybody knows about “good and bad cholesterol” and in that section they really go deep to disprove the idea that there is such a thing as good and bad cholesterol

**In the writing process, how often was Bill trying to keep Peter in check (in terms of the scientific aspect) by bringing in stories?**

- The book could be four times as long if it went into all the detail that you could go

*Where in the writing process did you decide that this topic deserves a deep dive while another topic does not? Was there ever disagreement about that?*

- Bill has always thought about it through the lens of the reader
- There was a healthy tension between Peter and Bill on this, but never once did they have a disagreement that was about ego
  - They had lots of disagreement about content, what the reader needs to know
  - It wasn’t about, “*I want to put this in because it’s mine*.”
- There’s a **backstory** ‒ the book basically got killed in 2020, it was left for dead
  - It got revised with a new publisher (Penguin), new editor, whole new process (which began in 2021)
  - Their editor (Diana) was relatively hands-off;she was more of a conceptual editor as opposed to a line editor
- Between Peter and Bill, it took about six months to get the right voice and register
  - To determine, “*Who are we writing this book for?*”
  - Initially, Peter was not clear on who the book was for; he began writing it like he would a scientific article
- They ended up settling on writing it like it was for T*he New Yorker/The New York Times/ The Wall Street Journal*
  - Half-way in between a scientific article and *USA Today*
- Once Peter read the book out loud, he realized it was absolutely written the way it should be
  - He realized that he dodged a bullet because he was given the advice by [Sam Harris](https://www.samharris.org/about), “*Do not do your edits silently. When you are editing this book, read it out loud.*”
    - Which Peter never did because he never had the time
    - Bill agrees, this is good writer’s advice
  - As Peter got closer to the reading, his anxiety was peaking because he never did this exercise
- There were a lot of last-minute edits that came out of reading the book out loud
  - Around 400
  - Not only line edits, but discussion of new studies (such as [tau](https://en.wikipedia.org/wiki/Tau_protein) deposition in women)

Finding the thread that pulls the reader through the book:

- The feedback from the first version was not just that it’s so technical, but there was no story, no protagonists, no journey, nothing to follow
- One of Diana’s insights was, “*What’s the thread that pulls the reader through the book?*”
  - They were there, they just had to expose them and let them shine

## Motivation to write the book and insights into challenges around the writing process [57:15]

**What makes you think that you’ll never write another book?**

- Peter often says this is the only book he’s ever going to write

- Even Bill jokes that he doesn’t think this is the only book Peter is going to write

*How do you not write another book in 10 years, on an update to all of this?*

- If Peter is being reasonable, he could never say never
- A couple of things would have to be true for him to write another book
  - 1 – He would have to have something to say
    - The writing process is so difficult; he doesn’t understand how people write a book in a year
    - The drive to need to say something has to be great enough to overcome the unbelievable inertia required to write a book
  - 2 – He would have to be at a different place in his life than he is today
    - He would not want to work on something so difficult on nights and weekends; the price he has paid for that is too high
    - If he was not working 24/7 then he could write it during the daytime; that just means his life would look different than it does today
      - His kids would be older
      - He would not be working as hard on his practice or other things
      - Writing would not be his hobby

**Did you want or need to write this book?**

- There’s obviously no shortage of books on health, books on longevity, etc.
- It’s hard to speak to the motivation at the outset, when Peter began in 2016 (2 years before beginning the podcast)
  - It never occurred to him at the time to have a podcast
  - Maybe if he had the podcast then he wouldn’t have thought to write a book because in some ways, a podcast is an easier way to communicate
- Going back to February of 2020 when this project was nuked (the publishers fired him)
  - Nobody wants a book about longevity during a pandemic
  - Peter was so frustrated; he felt bad that he had wasted so much of Bill’s time (2 years at this point) and would not have a book to show for it
  - Personally, Peter didn’t care; he didn’t need a book
  - Peter and Bill probably didn’t talk for 9 months
- In late 2020 when [Michael Ovitz](https://en.wikipedia.org/wiki/Michael_Ovitz) asked him about the book and asked for a copy
  - He read it in two weeks, which is saying something, because it was pretty long
  - He said, “*Look man, this has got to be published*”
- At this point in time, Peter was clearly “out of the ring;” he had the podcast and wasn’t looking for things to do
- Why did he come back to the book? He thinks it comes down to some of the stuff he wrote about in the last chapter

***Peter had a strong desire to come to peace with some of his demons and a strong desire to put this material out there; he doesn’t think the want found it’s why until the beginning of 2021***

- The book would have looked a lot different (and not as good) had it not gotten fired by the old publisher, had it not been for COVID, had it not been for all the crises that emerged

**Bill, during the nine months of silence, did you ever think the book would see the light of day?**

- Deep down, he knew it would because there had been so much work that went into it, and there was so much that’s original and interesting and amazing
- He felt like it would be a tragedy if it wasn’t published, and he was kind of depressed and sad for a while
- Bill was very glad when Michael Ovitz called and wanted to see it
- It was interesting watching Peter become a writer
  - He talked about working on nights and weekends, and just being tortured by this thing hanging over his head
  - He wanted it to be good, perfect
- One of the **stages of the writing process** is deciding that the whole things sucks
  - There are all kinds of stories about writers throwing all their manuscripts in the fire
- Then you think you’re done, after finishing the first draft
  - Peter sent Bill an espresso machine when they finished the first draft, but Bill knew they weren’t done (not even close)
- Finishing the first draft is like running the first half of the marathon
  - Don’t put the sticker on your car because you’ve got to run the other half of the marathon before you’re done
- Like a marathon, anyone who’s run ro swum one of those knows that the physiologic halfway point is not the actual halfway point
  - Peter and his wife just rant a marathon, and in training, it was all about training for the physiologic hits
  - In that 26 miles, you don’t physiologically hit the half point until 20; so you’ll hurt as much in the last 6.2 miles as in the first 20
- The same was true for the writing process; what they did in the last nine months was more valuable than the previous five years
- Bill kept telling Peter, “*You’ve got to trust this process… It’s going to get a lot better in the last six months than in the first however many years*”

**The final push to finish the book**:

- Peter remembers July of 2022, they were on a pretty tight deadline
  - This was when Penguin said, “*This book has to come out in March.*”
  - So the manuscript needed to be final by the first week of September, and they were six months away from that, and there were still gaping holes in this thing
- Peter was having a feeling that he had not had since he was on a very difficult swim in 2008/2009, where he was in the water and nothing was going well
  - This was early on after he tore his [labrum](https://en.wikipedia.org/wiki/Glenoid_labrum)
  - He was in so much pain, and the current was moving in the wrong direction
  - These things are very psychological (in running or cycling), and once your brain is hurting, nothing goes right
  - He remembers, at one point, realizing he still had seven hours to swim, and every stroke, felt like someone was sticking a dagger into his shoulder
  - A part of him was like, “*I don’t want to do this anymore. I just don’t want to do this.*”
  - He thought about quitting for at least an hour; all he had to do was put his hand up and touch the boat, and he would be disqualified, but he didn’t
    - It  didn’t change anything in his shoulder, he was still going to need surgery regardless
- He came back to this feeling in July of 2022; he remembers talking about this with his wife (Jill), “*In the next six weeks, we will have to work so hard to get this thing submitted, and we don’t have a choice now… I’m so torn right now because I am so tired. I don’t want to do anymore. I know that our publisher would accept this right now as is, because it’s good enough, but in my mind, it’s not good enough… I’ve never wanted to quit so bad.*”
  - Everything would have to revolve around the book for the next six weeks
- Peter is glad he didn’t quit
- Bill notes that one thing they share in common is, perfectionism
  - He would go through every single sentence asking, “*Is this the best way that this sentence can be cast? Are these in the right order? How are we structuring this?*”
  - He spent most of the summer doing that; it felt like a pretty deep hole

> “*Deadlines are good because nothing would be finished without a deadline.*”‒ Bill Gifford

- The book got a lot better, more readable
- The proverbial darkness before the light (August/ September) was really hard
- That’s when every person was trying to tell Peter, “*You have to trust how much this is going to converge at the end*”
- Peter’s blood pressure has always been normal, but in August it was higher with this book deadline looming

## Peter’s decision to be the reader for the audiobook [1:10:30]

**What made you ultimately decide to read it?**

Peter had some good reasons for not wanting to read it

- 1 – He knew it would be hard for him
  - He’s not a great out-loud reader
  - He has mild dyslexia, certainly when it comes to spelling
  - When he reads to his kids, even Reese who is eight catches mistakes, words he’s flipping back and forth
- 2 – He knew he would be in a recording studio for two weeks
  - He did some quick math, figured out how long it took to read one page and multiplied it by the pages that were in the book
  - He also knew that the one week of the year where he winds down (between Christmas and New Years), he was going to be in the recording studio all day, every day
  - He felt exhausted; he needed a week to recharge; he didn’t need two extra weeks of work
- 3 – When [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) was in town visiting over the summer, he was beginning the process of recording for his audiobook, and he had a sound engineer set up a studio in Peter’s basement
  - He was beginning to do his read and stayed with Peter for a couple weeks
  - One day he suggested that Peter go in the studio with his engineer and read a bit to see how it goes
  - Peter did and it was pretty rough; the feedback was, “*There’s no intonation in your voice. You sound like a robot reading that*.”
- On the flip side, someone suggested spending an afternoon together to do some coaching
  - Maybe it was [Staci Snell](https://www.penguinrandomhouse.com/authors/61920/staci-snell/), a freelancer who works for Penguin who would be the producer/director of the audiobook
  - In November, she came over and they read for two hours, and she coached Peter on reading
- She game some amazing tips that seem so self-evident, but they made a difference
  - 1 – ***Read slower***
  - Peter should have known this because he consumes nearly all of his books in audio first and listens to them at 1.8-2x
  - 2 – She commented, “*You’re not present when you’re reading. It’s clear to me how bored you are of this book, and I can’t blame you for it. You’ve read every word 1000 times, but your boredom is showing in your reading.*”
    - ***A good reader reads this like it’s the first time they’ve seen these words***
    - And the slower you read, the easier this is
- A couple days before starting to read the audiobook, Peter had a session with one of his therapists; he talked about how worried he was about this reading process
  - His therapist (Katie) asked him to write down the reasons why he was doing this
  - Peter identified three reasons
  - 1 – The listeners of the podcast will expect this and deserve it
  - 2 – A pet peeve of Peter’s when he’s listening to technical book that are not read by the author is how many mistakes there are when things are read incorrectly (for example, misreading causal and saying casual)
  - 3 – Right now his kids are old enough to appreciate this book; none of them are going to read it any time soon, but one day they will, and one day they might want to listen to it
    - Imagine if Hemingway had read some of his audiobooks and now distant relatives could listen to him read it; that would make it more valuable
- Bill notes that there are a lot of stores about Peter’s early life and medical career
  - Dramatic ER stories
  - Peter’s story is embedded throughout the book, especially in the last chapter
  - He thinks Peter had to read it, he just didn’t realize it

**Are you glad you read it?**

- 100% glad he did; zero regret on that
- He’s glad with the way it turned out
- Having Staci in his ear for the whole thing was incredible; he couldn’t imagine if he had to do it with somebody else
  - Staci should add a before and after section on her website about her work with Peter; the difference was dramatic

## The many painstaking last-minute changes and edits that brought the book together and made it better [1:19:00]

**You mentioned earlier how reading the book caused you to make some edits**

- Peter thinks that’s the closest Bill and Diana came to wanting to kill him
- Before they turned the book over to Penguin (back when was in the old version that died), it was a very similar structure to the way it is now, just a much longer, less elegant version
- The end of the book, the 17th and final chapter had an ending that Peter loved
  - But Bill was ambivalent, and Diana hated it, she was like, “*I don’t get it, this sucks.*”
  - So they took it out months before the reading
- When Peter had finished reading the whole book, he said to Staci, “*Hey, Stacy. Do you want to see the alternative ending?*”
- She reads it and is in tears; she thought it was beautiful
- So Peter went back in the booth and read it
- Later that day Peter emails Bill and Diana, wanting to add another page and a half to the manuscript
  - The details of those conversations were not pleasant; the answer was, “*Oh, hell no.*”
  - And they wouldn’t have an audio version different from the written version
- Once the audio version was edited, Peter forwarded it on to Bill
  - He found it moving

***The last chapter evolved the most of any chapter in the book***

- They had got to a place where it was working and that part had dropped out, but then decided as a compromise to leave it in the audiobook as the “[Stanley Kubrick](https://en.wikipedia.org/wiki/Stanley_Kubrick) director’s cut”
- Bill remarks about the print version, “*The last few paragraphs of the book and especially the last line, is something that sticks with me. I think about that every day… when I walk the dogs. ‒ ‘****What am I going to do today? How am I thinking about this day and the week to come?****’ and that line sings in my head. I’m glad it’s there*.”
- Peter thinks the compromise captures the best of both worlds
  - It would have been logistically impossible to shove it in at the end because of how it changes the pages of the book, etc.
  - Having it in the audiobook is an elegant way to do it
- Bill was glad on some level that Peter was making little line edits and stuff because it makes it better
  - There’s always stuff you can find
  - Bill did a lot of things that Peter probably didn’t notice

> “*It got so much better. There is a huge sprint at the end to just make this thing sound right.*”‒ Peter Attia

- When they got the PDFs from the publisher to proofread, Peter and Bill both went to town on it
- The industry standard is to do three passes on the PDF final copy
  - It’s expected that you might find some mistakes on the first round of passes
  - By the third round, there’s none
  - They got up to six or seven passes on a PDF
- The people at Penguin Random House were incredibly patient and worked very hard to accommodate all of the last minute changes
- Nick remarks, “*They also now understand why we say with you, the only thing you do in moderation is moderation.*”

***What happened the first day in the recording studio****?*

- There were two recording studios to choose from in Austin; Peter chose the one closer to his house
- The first day he goes in, he sits down and jumps right into it; he’s reading the book in chronological order
  - Peter hears a weird little hissing sound, and asks the engineer about it
    - He could hear it too, but it wasn’t being picked up on the recording
  - Peter got through the introduction and chapter one; the sound was getting louder but still wasn’t being picked up on the mic
    - Peter knew this couldn’t be right
  - Finally, he’s one paragraph away from finishing the third chapter (at the end of the day) and the engineer goes, “*You know what? I think we are picking it up… I think it’s a grounding issue.*”
  - It turns out they ended up having to go to the other studio because they couldn’t record there
  - The engineer assured Peter they would be able to fix the recording from that day, but they could not
- In a weird way, Peter thinks this was good, because he was a better reader by the end of that first day
  - It was a free practice run

## Peter and Bill’s favorite parts of the book [1:27:30]

**Looking back at everything that ended up in the book, do you have a favorite chapter?**

- Bill compares this to picking a favorite child
- There are **four core chapters about the horsemen diseases** (metabolic disorders, atherosclerosis, heart disease, cancer, and Alzheimer’s disease)
  - They were not in the original plan
  - It was a huge heavy lift to try and understand each of these disease processes; it took a huge amount of research and time spent with [Bob Kaplin](https://www.linkedin.com/in/bobckaplan) (the research guru for the book)
  - It was an intense experience and Bill feels a real sense of accomplishment about how those chapter came out
- The chapter that improved the most was the final chapter
  - From where that started to where it ended is probably Bill’s favorite chapter
  - He didn’t like that chapter initially
  - Early discussions they had with michael, he suggested it should be a separate book
- There are section of various chapters that Peter really liked

> “*The insights that come out of the atherosclerosis chapter are so important and probably have the potential to save more lives than anything else*”‒ Peter Attia

***Peter doesn’t pull any punches in his views on how we are mistreating atherosclerosis and why it does not need to be the leading cause of death***

- Earlier version of this chapter didn’t get to the point quick enough
- They had too much that didn’t matter in them
- Pivoting to the causal stuff was a very late edition to the book; it’s a much more insightful way to talk about it, and Peter is very proud with how that turned out
- The three chapters on **exercise** speaks to the importance of exercise in this book
  - As late as July/August of last year they were trying to do too much; instead, they focused on what they could do in a book
  - This is not a how-to exercise book (picture book of every step), and at one point they were trying to do all of that in writing
  - The incredible level of detail just wasn’t making sense; you can’t explain these things in writing
  - Restructuring to make a page of videos to explain some of these things was a big “aha moment”
- When Peter looks at how those **three chapters coalesce around the centenarian decathlon in the marginal decade**, he’s really proud

## The incredible team of people supporting the book [1:31:30]

**How many people were involved in the writing of this book?**

- [Bob](https://www.linkedin.com/in/bobckaplan) did the heaviest lifting; the [EndNotes](https://en.wikipedia.org/wiki/EndNote) on this book are probably more than 500
- The other thing that had to be done was all the **fact checking**
  - Peter took the wise advice from other authors who had written scientific books ‒ you can’t rely on a publisher to fact check your book
  - You need an independent person to come in and do scientific fact checking
  - Vin Miller was one analyst that did a lot of that work because Bob was too close to it at the time
  - At a much later version they had Bob go back and fact check certain things
- Peter adds, “*God bless Bob because this is long after Bob had left, he came back and did a night/ weekend. He was the guy that organized the EndNotes. And that was another thing that just gave me chest pain*.”

> “*It should go without saying, people are going to find mistakes in this. It’s impossible that we got it all right… every EndNote perfectly.*”‒ Peter Attia

- There will be a citation they got wrong
  - That’s why you have second and third editions to books
  - Folks should let us know when they see those things and we’ll do that
- Bill spent a lot of time putting his head together with Diana on Zooms when Peter was off doing things, working out the literary side of the book and how to structure it
  - How to make different chapters move better
  - Bill worked very closely with Diana and Bob
  - He would ask Bob to help him understand how [APOE](https://en.wikipedia.org/wiki/Apolipoprotein_E), and boom a gDoc would appear the next day with tons of sites and studies; Bob was great with that
- They spent weeks talking about the caloric restriction studies in monkeys (see the selected links section)
  - Peter was glad they stayed in the book, he was really worried that the Bethesda Wisconsin monkeys were going to get chopped
  - They found a great place for them in the book, and it’s a fantastic story to tell
- Peter put a lot of folks in his **acknowledgements**
  - It’s pretty unusual that an author will read the acknowledgements in the audio book, but there was no hesitation in his mind about this when he finished the book
  - It’s a very sincere, heartfelt thank you to a lot of people who have played an enormous role in his broad education on this topic, which has been going on for more than a decade
  - He mentions every single person he ever sent a chapter out to for technical feedback and review, and he was humbled by the incredible feedback he received
- The podcast basically started as a research tool for the book

> “*Every technical chapter, has been reviewed by a technical expert in that field*”‒ Peter Attia

**Did you read the footnotes in the audiobook?**

- Peter took a “hit or miss” approach on the footnotes; some of them he read, and some of them he didn’t
- The true footnotes in the bottom of the page, they took 98% of them out
  - And of the remaining ones, some of them didn’t flow with the text
- Peter tried to put himself in the mindset of the listener, and if the footnote was so tangential that it would be difficult to get back into the book, he didn’t read it
- There were some funny tangents that didn’t need to be read
  - For example, one about making all your dates read [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman); Peter definitely didn’t read that one in the audio book (he doesn’t even know if it stayed in the printed version)
  - [Stephen Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg), Peter made them read [*The Transformed Cell*](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491) about immunotherapy

**In summary**

- Peter notes, “*We should do a book AMA at some point*”
- Peter has been on a few podcasts already for the book, and in the coming months, he will be on many podcasts
- This was a unique opportunity to talk about something that otherwise we’d probably never talk about
- Bill offers a little behind the scenes comment, “*It was an honor and a pleasure to work with you. And I’ve learned a lot obviously. But as far as thinking and rethinking about these issues, [it] was an exciting adventure, and a little tough to get it on the page sometimes and get it just right. But I’m proud, I hope you are too, proud of what we have come up with.*”
- Peter is glad someone suggested back in 2017 that he find someone to write the book with, “*I think this is the best book I could have ever been a part of. Thank you, Bill.*”

§

## Selected Links / Related Material

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia & Bill Gifford (March 2023) | [1:00]

**Bill’s previous book**: [Spring Chicken: Stay Young Forever (or Die Trying)](https://www.amazon.com/Spring-Chicken-Young-Forever-Trying/dp/1455527440/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Bill Gifford (February 2015) | [7:00, 13:15, 17:00]

**Peter’s blog on cholesterol**: [The straight dope on cholesterol – Part I](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-i/) | Peter Attia, peterattiamd.com | [16:45, 25:30]

**Bill’s article on rapamycin in 2015**: [Does a Real Anti-Aging Pill Already Exist?](https://www.bloomberg.com/news/features/2015-02-12/does-a-real-anti-aging-pill-already-exist-#xj4y7vzkg) | Bill Gifford, *Bloomberg* (February 12, 2015) | [20:45]

**Previous episodes of** ***The Drive*** **with David Sabatini**:

- [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 13, 2018) | [35:00]

**Previous episodes of** ***The Drive*** **with Matt Kaeberlein**:

- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 20, 2018) | [35:00]
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 13, 2021) | [35:00]
- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/mattkaeberlein3/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 12, 2022) | [35:00]

**Previous episodes of** ***The Drive*** **with Iñigo San Millán**:

- [#85 – Iñigo San Millán, Ph.D.: Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 23, 2019) | [35:30]
- [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 28, 2022) | [35:30]

**Previous episodes of** ***The Drive*** **with Rick Johnson**:

- [#87 – Rick Johnson, M.D.: Metabolic Effects of Fructose](https://peterattiamd.com/rickjohnson/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 6, 2020) | [35:30]
- [#194 – How fructose drives metabolic disease](https://peterattiamd.com/rickjohnson2/) | Rick Johnson, M.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 7, 2022) | [35:30]

**Recent study in the** ***NEJM*** **about colonoscopies**: [Effect of Colonoscopy Screening on Risks of Colorectal Cancer and Related Death](https://www.nejm.org/doi/full/10.1056/NEJMoa2208375) | *NEJM* (M Bretthauer et al. 2022) | [46:45]

**Newsletter about the previous study on colonoscopies**: [Confusion over results of a recent colonoscopy trial](https://peterattiamd.com/colonoscopy-and-acm/) | A Misic, K Birkenbach, & P Attia, Peter Attia MD (October 15, 2022) [46:45]

**Recent episode of** ***The Drive*** **on HDL**: [#240 ‒ The confusion around HDL and its link to cardiovascular disease](https://peterattiamd.com/danrader/) | Dan Rader, M.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 30, 2023) | [50:15]

**Caloric restriction studies in monkeys**:

- [Caloric restriction delays disease onset and mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) | *Science* (RJ Colman *et al.* 2009) | [1:34:00]
- [Impact of caloric restriction on health and survival in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3832985/): the NIA study | *Nature* (JA Mattison *et al.* 2012) | [57:00]

- [Caloric restriction reduces age-related and all-cause mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988801/) | *Nature Communications* (RJ Colman *et al.* 2014) | [57:00]
- [Caloric restriction improves health and survival of rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/) | *Nature Communications* (JA Mattison *et al.* 2017) | [57:00]

**Steven Rosenberg’s book on cancer immunotherapy**: [The Transformed Cell](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491) | Steven A. Rosenberg and John M. Barry (1992)

§

## People Mentioned

- [Rodrigo Corral](https://rodrigocorral.com/about) (leading creator in conceptual design and art for books, brands, and more) [10:45]
- [Phil Mahre](https://en.wikipedia.org/wiki/Phil_Mahre) (World Cup alpine ski racer) [18:15]
- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan) (analyst, writer, former head of research for Attia Medical) [20:30, 1:28:30, 1:31:30, 1:34:30]
- [Daniel Powell](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8186734) (Professor of Pathology and Laboratory Medicine and Scientific Director of Immunotherapy, Division of Gynecologic Oncology at the Perelman School of Medicine, University of Pennsylvania) [27:45]
- [David Sabatini](https://www.davidmsabatini.com/) (scientist, expert in regulation of growth size and cancer metabolism)  [35:00]
- [Matt Kaeberlein](https://dlmp.uw.edu/faculty/kaeberlein) (Professor, Director of the Healthy Aging and Longevity Research Institute at the University of Washington) [35:00]
- [Iñigo San Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) (Professor of Medicine, University of Colorado Anschutz Medical Campus, expert in metabolism) [35:30]
- [Rick Johnson](https://som.cuanschutz.edu/Profiles/Faculty/Profile/9426) (Professor of Medicine – Renal Med Diseases/ Hypertension at the University of Colorado Anschutz Medical Campus) [35:30]
- [Sam Harris](https://www.samharris.org/about) (Author, podcaster, neuroscientist, philosopher) [55:15]
- [Michael Ovitz](https://en.wikipedia.org/wiki/Michael_Ovitz) (Businessman and philanthropist) [1:01:15]
- [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) (influential record Producer) [1:12:15]
- [Staci Snell](https://www.penguinrandomhouse.com/authors/61920/staci-snell/) (a voice-over actor who narrates audiobooks) [1:13:00]
- [Stephen Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) (Head of Tumor Immunology at the National Cancer Institute) [1:37:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/03/bill-bio-pic-500x500.png)

##### Bill Gifford

Bill Gifford is a veteran magazine writer and editor who writes about extraordinary athletes and cutting-edge health science. After growing up mostly in Washington, D.C., he returned after college to become a staff writer for the legendary *Washington City Paper*, for a salary paid in beer, rice and beans. He then moved to Philadelphia to write and edit for *Philadelphia Magazine* for several years. Continuing north along I-95 to New York, he worked as features editor and then “editor-at-large,” the world’s best job title, for *Men’s Journal.* His freelance work has appeared in *Outside* magazine, where he is a longtime contributing editor, as well as *Bicycling*, *Wired*, *Bloomberg Businessweek*, *Slate*, and others, as well as in *Best American Sportswriting*. His first book, [*Ledyard*](https://www.amazon.com/Ledyard-Search-First-American-Explorer/dp/0151012180/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), is a biography of the 18th-century explorer, writer, entrepreneur and bon vivant John Ledyard. His latest, [*Spring Chicken*](https://www.amazon.com/Spring-Chicken-Young-Forever-Trying/dp/1455527440/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), is a personal investigation into the science of aging. [[amazon.com](https://www.amazon.com/stores/author/B00NB4VX76/about?ingress=0&visitId=fd89f619-668a-4274-af3b-0a7bcebdf0f7&store_ref=ap_rdr&ref_=ap_rdr)]

Instagram: [billgifford](https://www.instagram.com/billgifford/?hl=en)

Twitter: [@billgifford](https://twitter.com/billgifford?lang=en)