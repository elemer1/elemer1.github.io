# #237 ‒ Optimizing life for maximum fulfillment | Bill Perkins

**Source:** [https://peterattiamd.com/billperkins/](https://peterattiamd.com/billperkins/)

---

Bill Perkins is one of the world’s most successful hedge fund managers and entrepreneurs, and the author of the bestseller, [Die With Zero](https://www.diewithzerobook.com/welcome). In this episode, Bill unpacks the Die With Zero philosophy which challenges conventional thinking related to the balance between health, wealth, and time—the three variables important for fulfillment. Bill makes the case that we should strive for maximum net fulfillment rather than net worth (or even health). He argues that we need to optimize our life to have memorable experiences before it’s too late and that most people are over-saving and under-living. Bill also explains how one can apply the principles in Die With Zero to break out of “autopilot” and optimize their life to achieve maximum net fulfillment.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/billperkins/the_Drive_public.png)

Play

#237 ‒ Optimizing life for maximum fulfillment | Bill Perkins

1x15s30s

0:001:43:41

## We discuss:

- Bill’s upbringing, background, and first job on Wall Street [3:15];
- A missed experience and feeling of regret that shaped Bill’s thinking [14:15];
- Thinking in terms of time, and the relationship between money, time, and health [17:00];
- Solving for net fulfillment and allocating your time based on the seasons of life [27:15];
- How Bill thinks about risk, opportunity costs, and the difference between fear and risk tolerance [35:30];
- Optimizing for fulfillment, finding purpose outside of work, and more [41:45];
- Thinking about the order of experiences you want to have based on seasons of life [50:00];
- Bill’s unique perspective on philanthropy and a more impactful way to give money away [54:45];
- Applying the principles in ‘Die With Zero’ to maximize fulfillment [1:04:00];
- How to break out of living life on autopilot [1:14:30];
- When should your net worth peak? [1:18:00];
- Taking calculated risks [1:21:30];
- Bill shares a lesson from his incredible birthday [1:25:15];
- How Bill’s philosophy has evolved since writing Die With Zero [1:34:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Bill Perkins is a hedge fund manager, a very successful natural gas trader and entrepreneur, and author of the book, [*Die With Zero: Getting All You Can From Your Money and Your Life*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1)
- Over the past year, Peter has read 3 books that seemed in some way connected to different sides of a similar theme‒ quality of life
  - [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=sr_1_1?crid=4HZNLM7MWDD&keywords=from+strength+to+strength+arthur+brooks&qid=1669829821&sprefix=from+stre%2Caps%2C117&sr=8-1) by Arthur Books
  - [*Four Thousand Weeks*](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/0374159122/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669829962&sr=8-1) by Oliver Burkeman
  - [*Die With Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1) by Bill Perkins
- After reading Bill’s book, Peter realized they had about 4 friends in common (at least 2 or 3 of whom were mentioned in the book), and it made it easy to reach out to him about being on the podcast
- In this episode we talk about Bill’s background, his upbringing, and the genesis of the philosophies in his book
- From there, we talk about the overarching philosophy of this book‒ we have these 3 important resources‒ time, health, and experiences, and we use money as a conduit or a tool to trade between those
  - If that doesn’t make a lot of sense now, it will when we talk through it
- Throughout this interview, Bill makes the argument that no matter at what level of wealth you are, most people are not focusing correctly on time
  - Time is the most important asset that we have
  - We need to optimize our life to have experiences throughout our life instead of waiting until the end of life to do everything (which is really what most of us do)
- Throughout this, we talk about the importance of understanding risk
  - Including the opportunity cost of making or not making decisions
- We talk about the risk reward matrix and thinking about regret and regret minimization
- We talk about the dangers of living life on autopilot when it comes to work and fulfillment
- For as much as this podcast dives into the science of longevity, any longtime listener knows that Peter is equally interested in the manners of emotional health and quality of life, and to live a long life without appropriate happiness or quality of life or shared experiences is not really to live at all
  - That’s why a book like this is just as important to Peter as books about the hardcore science of longevity
- The insights that Bill shares in this interview will help anyone think through how they’re spending and allocating their time no matter what level of wealth they have

## Bill’s upbringing, background, and first job on Wall Street [3:15]

**Impact of Bill’s book on Peter**

- When Peter posted on Instagram about 3 books he’s read in the last 12 months, he didn’t expect it to have such an impact on how he thinks about things
- Even though they are completely different books, they have a unifying theme about improving the quality of life
- Peter doesn’t remember who recommended [*Die with Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1), he just remembers thinking it sounded interested
  - He ordered it and then just couldn’t put it down
  - He made his wife read it
  - He bought many copies of it (as well as the other 2 books mentioned earlier) and started handing them out like a triplet copy

**Bill’s background**

- Bill grew up in Jersey City, New Jersey
- His degree is in engineering, but he doesn’t want people to be impressed that he’s an engineer
  - He barely graduated; he was a super slacker
- He played football at the University of Iowa
  - A defensive back, but was mostly on the bench
  - He was a walk-on
  - He was trying to get a scholarship, he had a partial scholarship
  - He broke his leg at the growth plate, and that ended his football career

**Bill’s first job**

- He was lost after graduation and was really an underachiever at the time
- His godfather gave him the talk, “*What are you going to do with your life?*”
  - At this point he knew he didn’t want to go into engineering
    - It was a cookie cutter life without any kind of entrepreneurial spirit in it
    - You work on a subsection of a chip, here’s your career path, etc.
  - It was unattractive and “seemed like death”
- At the time Bill saw the movie [*Wall Street*](https://en.wikipedia.org/wiki/Wall_Street_(1987_film)) and realized he wanted to go work in stocks, he wanted to be rich
- His godfather recommended a firm in commodities that was looking for screen clerks
  - This was 1991
- Bill got an introduction and was shown around the trading floor
  - People are yelling and screaming and they’re kind of in casual wear and it’s like Trading Places and all this energy
  - He thought, “*Wow, if that guy can be rich, so can I*”
  - They didn’t hire him then but he hung out downstairs every day calling, “*Can I come up? Can I become a peon here?*”
  - Finally after 3 days they let him become a peon
- This job was checking trades and sneaking sandwiches on the floor for traders
  - It’s literally the worst version of the mail room
- The system in the old days was where guys would yell and scream across a pit and write their trades on a pick card and also in their trade book, and they’d throw the pick cards into a center
- There’s a guy with glasses and a giant net and all these cards would go to him
  - He would catch them, put them down the chute, and they would be entered into a computer system
- Bill’s job was to check the traders log versus the computers log
  - And your name becomes your trader
  - So if your trader was, “Why Not” or “S&M”, that was your name
  - Clerks are running around the floor going, “*Why Not, S&M, Why Not*.”
    - If you’re Why Not you’re like, “*Why Not here. Over here. I’m selling 5 lots of 54.80, not 3 lots of 54.80*”
  - If you know the same trade, then it’s a simple process to correct it in the system
    - And if you don’t, you’re like, “*No, no, I definitely know only 3 lots*,” then you go to the traders immediately and they reconcile it
- That was the system, running around all day checking trades
- This was in Four World Trade Center (back when the World Trade Center was there)

**How much were you learning business at this job?**

- Peter can imagine one could take a job like that and not actually learn what’s happening, what the machine is doing
- This is when he decided to “turn it on” and learn every single thing there is about this business
  - He was reading books at night about trading, about the oil business, about options, about whatever
  - He was a sponge and as diligent as he could possibly be as a 20-year-old
  - He was really trying to make himself invaluable no matter where he was

**Were you living in Manhattan at the time?**

- No
- He first lived at home with his mom, which completely cramped his style
- He started driving a limo at night to makes ends meet

**What were you getting paid in that first job?**

- Sub $16,000 a year
- But he was getting raises very quickly because he made himself valuable
- He would work at night and would make more money driving the limo on a daily basis
  - Traders would be drunk and tip you
- He wasn’t there for the current income but the future income
- He got an apartment with another clerk named Jason Ruffo who had a studio on the Upper West Side
  - Jason put up a wall by the kitchen and kind of made this small room in this studio
  - It was living in like a pizza oven type space
  - But it was great because he was in New York City out of his mom’s house
- Gradually he got into that life of what he calls a “buppie” (black urban professional)
  - You know, buppies and yuppies?
- And that was the beginning of his journey

**Was your dad in the picture at this time?**

- His parents were divorced
- His dad was older and in poor healthy in Jersey City
- During this time he’d had multiple strokes
- Bill is fairly stubborn but his dad was stubborn to the extreme
  - The doctor says don’t do this… all the things you would tell him not to do and you need to be doing…
  - His dad was like, “*Ah, the hell with that*.”

**Had your parents gone to college?**

- His dad did
- He got a scholarship to the University of Iowa
- He was a real badass with no intentions of going to school
- He walked by a football field when he was a kid in high school and was like, “*I want to do that*.”
  - The coach was like, “*You don’t know anything about football*”
  - His dad says, “*It seems like it’s about hitting people and I know how to hit people*”
  - So they gave him some raggedy uniform, he comes out for a practice, and in the next practice he has a brand new uniform
  - He’s all everything, gets recruited to go to University of Iowa to go to college (in 1959)
- His mom finished college while Bill was a preteen or late teens
- He had the benefit of 2 college educated parents

**How much did your parents understand your drive, your aspirations in this new role?**

- This was in contrast to his not achieving his potential in high school and college
- Now all of a sudden, he’s hustling, working 2 jobs, reading, learning

*Were they privy to that sort of metamorphosis in you?*

- They saw it later
- He was the kid that didn’t take out the garbage
- Bill always says, “*Don’t tell your parents your dreams because they’ll just piss on them, because they’ve seen you at your worst and your failures as you’re growing. They have this kind of image of you when you were the caterpillar not the butterfly*.”
- Bill remembers the time when he got a raise and did the calculation and was like, “*Holy shit, I make more money than my mom. I’ve made it… I’m real, I’m legit. I’m a buppie*.”
- It wasn’t until he got recruited to go to Houston and started buying the assets that adults start buying, and paid his mom back for something he did when he was a teenager that she didn’t know about, that his parents realized his transformation
  - He was driving his mom’s car (a stick Toyota) and his friend Pete Thibold wanted to learn how to drive stick
  - Long story short, he hits the gas instead of the clutch, spins the car out, the back of it spins around and hits a telephone pole; the trunk pops up and it has this big giant dent
  - Bill tells his mom this story that they went to go get pizza and parked it and then a truck must have hit it on the side or bumped it and went on
- He felt guilty about this lie to his mom about he car and said, “*One day I’m going to pay for this car in spades*”
- And so one day he gave his mom $40,000 and explained, “*Mom, remember that time the car had that brown mark on it and we told you it was a truck? Well, this is what really happened*.”
- She just laughed and said, “*I knew something was strange about that, the story fit but there was something strange about that.*”

## A missed experience and feeling of regret that shaped Bill’s thinking [14:15]

**Jason’s trip**

- In his book, Bill writes about the different point of view he and his roommate had on future earnings and how this impacts what you do with your time
- He tells the story about when Jason took the trip
- Bill doesn’t know if their views were very thought-out or simply wired-in
- He was head down like, “*I’ve got to make it, I’ve got to become a trader. I’ve got to have my head down. I’m saving money. I’m really, at this point in my life, super diligent trying to convince my boss to get on the bus program to save money, writing down every single nickel that I bought, etc. I’m really focused on my career trajectory*.”
- Jason worked at another firm
- If you look at the old pictures, all the phone booths are right next to each other
- So Jason is right next to Bill even though he is not at the same firm
  - They were all crowded into one area
- Jason’s view was, “*I’m going to go backpacking through Europe for a couple months*.”
  - He was going to borrow money from a loan shark
- Bill thought that was insanity
  - He told him, “*You’re going to miss out. What if they hire another screen clerk and your job’s not there when you come back? How are you going to pay this guy back? If you don’t pay him back this is not like penalty and interest, this is like knees and ankles*.”

> “*I just didn’t get it… I wasn’t thinking about die with zero and certain experiences belong in a certain period of your life*”‒ Bill Perkins

- Bill was on this autopilot of trying to be successful and make money at that time of his life
- Jason went backpacking, came back, and had a screen clerking job at the same firm
  - It wasn’t noticeably different
- Bill had moved up a little bit but he also wasn’t noticeably different
- However, Jason came back richer
  - He came back with stories and experiences and romance and lifelong friends
- In the beginning Bill felt that maybe he missed out and as time went on, he really regretted not joining him on that trip
- When it finally came time for him to go to Europe and have this backpacking experience, he was too bougie
  - He had money and wasn’t going to stay at youth hosts
  - It was a different experience
- Bill realized, “*The type of experience he [Jason] had was for that time in your life. And the type I experienced, even though it was wonderful, it was not as rich as his experience because the time had passed me by. It’s one of my big, big, big regrets in life.*”

## Thinking in terms of time, and the relationship between money, time, and health [17:00]

**How did you start to formulate this understanding about these different types of resources (time, money, experiences, people you meet) that would ultimately become the thesis of this book?**

- It happened slowly, over time
- Even when he got to the exchange, he was in a hurry to get rich
- He had this bias, this belief, “*Yeah, there’s rich guys here but they’re old. What can they possibly do with the money?*”
- At 21, he was an ageist; he couldn’t imagine the use of a million dollars when you’re 40
  - What are you going to do? Buy a nicer car to drive your kids around?
  - It didn’t seem like they did fun things
- Bill was wrong about that, but he was right about the utility of money over time
- He read this book that transformed his understanding of what money is, called [*Your Money or Your Life*](https://www.amazon.com/Your-Money-Life-Transforming-Relationship/dp/0143115766/ref=sr_1_1?crid=3O7PFNA8V46PG&keywords=your+money+or+your+life&qid=1669834520&sprefix=your+money+or+%2Caps%2C96&sr=8-1)
  - It had these exercises to get you to look at how you spend your hours from going to work, getting ready for work, the things you spend on work, and really figuring out what your true hourly wage is after tax
  - It helped him figure out what an hour of his time (his life) was worth
  - It has you not think of everything in money but in time

***He got this idea that he’s exchanging his life for certain things, and that hit him hard***

**Is this before you went to Houstin?**

- Yes
- The 2 things he got out of this book was, “*I want a lot of money and I’m going to become this very frugal person*”
- There is a movement called [FIRE (financial independence retire early)](https://en.wikipedia.org/wiki/FIRE_movement), and this book is like the bible to them (a precursor to the FIRE movement)
- Bill became an early FIRE guy, he was going to save his way to riches then retire early

**Did you know what you wanted to do when you retired?**

- After Bill read this book, he went on another version or autopilot
- He didn’t think about the big picture of everything, but certain concepts were coming to him

***Bill realized, “I exchange hours in my life for money and that money is used for the things I want. Let’s take the abstract of money out of it and look at what hours of my life are being exchanged for.”***

**You start to think of the difference between using money for activities or trips versus things**

- One is an experience and one is a thing
- Bill didn’t think about it quite like this at the time but in a more intuitive way
- When you start to think about things in time
  - 3 hours for a shirt versus going here and having a sandwich and hanging out with my friends (or whatever it is)
  - You really get in touch with your values because it’s not an abstract
    - Abstract is when you’re in a casino and they give you chips, it’s not money
    - You’re tipping $ 25, you’re throwing let it all ride, because it’s so abstracted from money
    - It’s an abstraction on an abstraction
  - By removing that abstraction, you get closer to your values
- Peter puts it in perspective, “*Imagine that you have $25 chips, you figure out your hourly wage after tax is $25 an hour. Every time you flick a chip it’s like I gave an hour of my life, boom, boom, boom*.”

***Bill realized, when you start thinking about things in terms of hours of your life and you have finite hours, you start to really get closer to your values***

- You can still be on autopilot but you’re closer.
- At the exchange, most people thought, “*What is it all for? What do I want? I’m here to get rich, but why?*”

**Did you have that discussion with people who were your peers (presumably on the same treadmill), or with people who were already rich but still presumably killing themselves trading their health for wealth?**

- No, this was a conversation Bill had with himself, reading books and asking himself, “*Why? What do I want?*”
- He remembered conversations he’s had throughout his life
  - There was a college football player named Dwight, and Bill was trying to do engineering and they were debating something
  - Dwight said, “*Listen, you might want a picket fence and a wife and something like that and that life, I don’t want that life. I don’t want that cookie cutter life. That’s fine for you but that’s not my path*.”
  - Bill thought about it, “*Do I really want that?*”
  - There were certain things that Dwight said he didn’t want
    - But Bill was actually working for these things, thinking that this was his path, but then he realized he didn’t want that
- Bill realized, “*I’m pretty hardheaded. It takes a while for these things to seep in*.”
- Peter thinks at such a young age (22, 23, 24), it’s pretty remarkable for Bill to be having these thoughts
- It took a while for it to percolate into some sort of action plan

> “*Everyone says I want to be rich before I’m 30 or rich before 40, no one’s out there saying I want to be rich before I’m 86. So intuitively, there’s something about the utility of money that it’s not as valuable to you later on in life*.”‒ Bill Perkins

- Peter adds, this is one of the games he often plays with his patients, he asks them if they would trade places with [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett) or [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger)?
  - Everyone says, “*Of course not*”
  - Peter replies, “*What do you mean of course not? Warren Buffet’s worth a hundred billion dollars. How would you not trade places with him?… Okay, so would you rather have not a penny to your name and be 20 or have a hundred billion dollars and be 90? No other difference. I’m not going to stipulate anything else.*”
  - He’s never met a person who wouldn’t take being a broke 20-year-old
  - Warren still appears healthy, he’s cognitively intact; so this speaks less to health
  - It’s about having only 10 years of life left (at age 90) versus having 80 years of life left (at age 20)

***When you face it in such stark terms, only then does the average person start to realize how precious time is***

- Bill also thinks Warren Buffet can’t sprint, dunk a basketball, go wakeboarding‒ there’s a lot of other things that have to do with enjoyment
- These are the types of things he has thought about
- He’s thought about spending hours of his life to acquires experiences
  - Whether it’s going on a walk or being able to choose to go on a walk or go get a sandwich or buy a shirt or whatever
  - If he’s exchanging hours of his life and he doesn’t acquire these experiences, he’s pretty much wasted hours of his life

> “*You don’t want to leave anything on the table*”‒ Bill Perkins

**Bill’s summary**:

- In the game of life when you die you don’t want to leave chips on the table
  - You want to use all your resources before you die
  - Inherent in that is your choices, your experiences
    - Those experiences are what make you you
    - Those are the things that fulfill you
    - And everybody’s going to be different
  - Consequently, having more of it and enjoying more of it will lead to a more fulfilling life
- If you’re solving for **fulfillment**, you don’t care about the money
  - You care about the things you want, the experiences you want to have
- 1 – One of the things you come to quickly is that you need to use up all your resources before you die
- 2 – The second thing you come to is the fact that your resources (particularly money) are less valuable to you when you’re older
  - Then you start to think there must be a curve
  - Because if you’re going to end at zero, is it this kind of rectangle shape that just goes down? Is it a 45 degree angle slip or is there some sort of curve?

**Bill’s thinking about the usefulness of money at different ages in life**

- What Bill likes to do to understand certain things is think of zero and think of infinity
- Let’s run it all the way back to one-years-old; how useful is money? It’s not that useful to you
- Now, run it all the way forward to age 96 on your deathbed, how useful is money to you? Not that useful
- So clearly there’s some sort of ramp up of utility and then a decline of utility
- He became obsessed with finding what that curve was because he realized, “*This is it. If you’re making more money for delayed gratification later in life, you approach infinity, you’re actually wasting your time. You should be spending down your assets at a certain point*.”

***There’s an inflection point where not a number, but a date where your wealth should be going down in order to get the most fulfillment***

**Is that standard thinking/teaching within the wealth management community?**

- No, but it is a standard problem
- If you look at JP Morgan or other wealth managers, one of the biggest problems they have is accumulation
  - Getting people to spend down their assets, they’ve been saving
  - People hit retirement, and their net worth is going up into their 70s
  - When’s the party?
  - It’s okay that you’re saving, but what are you saving for?
  - When are you going to use up all your resources?

## Solving for net fulfillment and allocating your time based on the seasons of life [27:15]

**One stats from the 2008 financial crisis that stuck with Peter**

- A good friend of Peter’s ([Jim Lambright](https://en.wikipedia.org/wiki/James_H._Lambright)) was at the time president of Ex-Im Bank when the [TARP program](https://en.wikipedia.org/wiki/Troubled_Asset_Relief_Program) began
  - He was close with [Hank Paulson](https://en.wikipedia.org/wiki/Henry_Paulson) and had already spent a lot of time in China so he had government clearance
  - Hank brought in Jim Lambright and [Neil Kashkari](https://en.wikipedia.org/wiki/Neel_Kashkari) to run TARP
- Jim was trying to understand how bad this was going to be
  - What was this going to mean for the average person?
- One day Jim called Peter with a stat he couldn’t believe (he can’t remember it exactly)
  - Directionally, the question was‒ **was what fraction of people in the United States could not produce $1,000 with 3 days notice?**
    - Meaning they didn’t have that excess liquidity of a $1,000
  - The number was in the ballpark of 30%
    - This is high
    - Peter wonders what this number is today

**Does Bill’s thinking apply to the person who is 40-years-old, who has a net worth of $50,000 and available liquidity of $1000?  This is the person who is planning to work until 65 or 70, then collect social security.**

- It applies in different ways
- In his [book](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1), Bill has come up with **3 variables important for fulfillment**‒ your wealth, your health, and your time
- You’re not solving for maximum wealth (or even maximum health or maximum time)
  - You’re solving for net fulfillment; that’s your purpose

***Look at the total arc of your life, and given the resources you have, how do you allocate them?***

- Everybody wants to talk about money and resources, but there are decisions that you make even without money
  - Whether you go on a walk with your daughters
  - Do you play cards with your friends late at night, do you tuck your kids in at night, or you go hang out with the boys?

**The value of your time [29:30]**

- In his book, Bill talks about the seasons of life
- Certain activities transfer nicely to the next **season of your life** (from 20 to 30 to 30 to 40 etc.), and some of them don’t transfer well
  - Some are less enjoyable, and some don’t transfer at all
- One of the things Bill would say to this 40-year-old is, “*What’s your survival number? Have you calculated that at retirement? Are you surviving retirement? Are you in serious negative dire straits?*”
- And once you’ve calculated how much you need to work and save (plus social security) to get your survival number, the rest of your money is for experiences

***How do you allocate your time?***

- Is it the cruise at 70, or is it the ski ship right now?
- And that’s going to be different for every single person

***What fulfills you?***

- Is it a shirt?
- Or to go play in this chess tournament (pay the entry fee)
- And for people with zero money, you still have an allocation game to play (you still have your health and your time)
  - You can still decide, “*Hey, I’m going to sit down and watch friends, or I’m going to go hang out at my mom’s house and make a meal and spend time with them because I’m only going to see them 20 times before they’re gone.*”

***So this type of thinking about allocating your resources at the proper place, getting off autopilot holds at all wealth levels***

- It doesn’t hold at all health levels because if you have zero health, you have zero, you’re done, it’s over
- But it holds at all wealth levels
- With that type of thinking (to maximize fulfillment), and knowing that you have seasons of your life that your body decays, your attitudes change
- You realize you need to get things in the right order and use your resources properly, to help you have a more fulfilling life
- This is true whether you have zero money or a hundred million dollars
- There are many people with zero who are having a way more fulfilling life than Warren Buffet
- Peter notes, “*It’s a very non-linear problem,*” and examines these 3 variables
  - On the surface, one might think it’s a Min/Max game
  - You always want **maximum health**
  - If you could preserve your healthspan and lifespan indefinitely, but the cost was to work on your health every minute of the day, you wouldn’t want that
- Bill agrees, “*There’s no amount of money you can pay me to do 10 years in* [*sing sing*](https://en.wikipedia.org/wiki/Sing_Sing) *[prison]. Not at this age.*”
- Certain people are always just **delaying gratification**, and Bill relates this to being in jail
  - It’s a version of doing time
  - Maybe you shouldn’t be doing time at this point in your life
- People absorb information in different ways
  - You can say it in all kinds of different ways and then they finally go “*Aha, got it*”
  - And how Peter framed this just now really spoke to Bill

> “*Life is like Tetris. You got to get the order right in order to get the high score of net fulfillment.*”‒ Bill Perkins

- In his book, Bill talks about different time buckets and different phases of life
  - You have leisure, job/ career, experiences you want to have
  - All at different times in your life (20-25, 35-40, 50-60, etc.)
- You realize that going to clubs and strip clubs and hanging out should happen before you get married (not after)
- Reading books to your kids must be in the bucket of when they are young, because they’re not going to want him reading to them when they’re in college (or even 13, 14)
- This is one of the errors Bill made as a parent, he didn’t want to spend too much time with them
- But then he realized, “*Wait a minute, maybe I should have been doing this activity instead of that activity*”
  - This was the die with zero thinking to optimize your life

**Bill’s thought experiment on fulfilling experiences**

- You’re up in heaven and you have choices between buckets of experiences and God says, “*Take as much as you want*”
- You’re throwing in everything, and you’re like, “*I want to have sex 30,000 times, and I want to climb Kilimanjaro, and I want to play hockey. I want to be in a high school team and I want to do…* *I want to meditate and do yoga*.”
- Then God goes, “*Great, I’m going to let you have all those experiences, but there’s one trick, you got to get the order right.*”

***What this means is, if you don’t get the order right, if you save certain experiences to the 80 to 86 bucket, you don’t get it***

- When you’re 21 and you don’t go backpack it with your friend at youth hostels, etc., then you don’t get that experience (or it’s not as fulfilling)

**Bill’s advice**:

- What do you want out of your life?
- Get off autopilot
- What resources do you have, and how do you optimize to get the most out of it?

## How Bill thinks about risk, opportunity costs, and the difference between fear and risk tolerance [35:30]

**How do you think about your own risk tolerance?**

- Peter notes, there’s a caveat the listener needs to understand at this point, which is what you do for a living today
  - Bill is an energy trader among other things (he does many things)

*Is it safe to say that the majority of the wealth you’ve created came through your ability to understand how natural gas moves and how to trade on that?*

- Yeah, the majority of Bill’s wealth came from predicting the future of natural gas prices
- Peter had one of Bill’s closest colleagues on the [podcast](https://peterattiamd.com/johnarnold/), [John Arnold](https://en.wikipedia.org/wiki/John_D._Arnold) (nicknamed “The King of Gas”)
- Peter asks‒
  - Do you look at a guy like John and say he has a high-risk tolerance?
  - Do you look at someone like yourself and say you have a high-risk tolerance?
  - Or do you feel you’re completely in control of calculated risks and that’s why they net out to be positive?
    - In other words, are you less swayed by short-term volatility because your methodology doesn’t feel like gambling?
- The best traders Bill has seen have been pretty stoic about things
  - They think very robotically about the expected outcome
  - They don’t seem to be disturbed about negative outcomes

**Tell folks what expected outcomes mean because they want to understand the probabilities**

- If you place a bet and the payout is 1 in 4, but the odds are 50/50, half the time you’re going to get 4x your money and half the time you’re just going to lose 1x your money
  - That’s positive expected outcome; you’re going to make money
  - But remember 75% of the time you’re going to lose… No, half the time you’re going to lose (the odds are 50/50 while the payout is 1 in 4)
    - A lot of people can’t deal with that
    - A lot of people need 4, or 5, or 7 positive events (emotionally, psychologically) for every negative event; and in trading that just doesn’t exist
- In trading if someone is right half of the time, they’re pretty good
- Think about the casino’s edge in blackjack, it’s maybe 51
  - In blackjack it’s 0.07 or 0.09; in craps it’s 0.03
  - They’re wrong a lot of the time but with the law of large numbers, they ultimately make a bunch of money

***But if your emotional calculus is different such that you need a greater ratio of being right, then you’re not going to make it because stress clouds your thinking and your judgment***

**What do you say to a person who is very risk averse? How do you help them think through the difference between fear and risk tolerance?**

- A risk averse person never wants to have the chance of losing something
  - For them loss aversion is a greater motivator than gain
- 1 – First he wants to break down what they are actually afraid of
- Many times people say the bad thing is not as bad as they imagined in their head
- Often it’s really the fear of judgment more than fear of the actual thing
  - What they can’t survive is the shame that they got it wrong
- There is a lot of fear disguised as, “*I can’t risk these dollars*”, but Bill thinks you can
- 2 – Bill also tries to get them to focus on the cost of inaction and the opportunity cost
  - People usually focus on the monetary cost of losing
  - By talking about the opportunity cost, he gets them to see the asymmetry of the risk
  - Bill’s fear is reversed, he fears missing out on the opportunity costs and not getting the max
- A lot of people fear running out of money, he fears wasting his life

***Bill is more worried about looking back and realizing, “Shit, I wasted my only ride that I had,” than running out of money***

**A framework to view risk**

- One of Peter’s patients was about to do something Peter thought was a significant health risk
  - It was a very unique opportunity
  - But the patient acknowledged the risk and explained he was acting from a regret-minimizing framework not a risk-minimizing framework
- For Bill it’s all about risk and reward; it’s about what fulfills you
  - If he really loved cigarettes, he’d smoke them
  - If he really loved skydiving, he’d do it all the time
    - He went twice, but it was diminishing returns
  - Some people like to ride motorcycles, but for him it’s not worth the risk
    - He has a physical risk tolerance around 1 in 10,000 (if it’s more dangerous than that, he doesn’t want to do it)
- He thinks about things from a minimization algorithm
  - When a chess computer plays you, it has a regret minimization algorithm
  - What it is solving is to win the game

> “*In the game of life, what I’m solving for is regret minimization; I’m solving for net fulfillment. I want the highest score in net fulfillment*.”‒ Bill Perkins

- Bill doesn’t want the highest money or even the highest health
  - He doesn’t want to run 3 hours a day to be in the top 0.5% (the top 3% is great enough)
  - He’ll give up the tail end of his life
- How does he optimize time?
- He is solving for net fulfillment
- You have to think it through
  - It’s okay if you’re nervous about risk, going heliskiing/ skydiving/ riding motorcycles
  - As long as you’re off autopilot, then it’s fine

## Optimizing for fulfillment, finding purpose outside of work, and more [41:45]

**How variable do you think people are in their stratification of what encompasses net fulfillment? Do you think people are even deliberate about what that means?**

- Bill thinks people have the ability to articulate that early in life but get habituated out of it
- We all go into autopilot; we all have this default mode network
  - It helps us survive
  - It helps us drive without thinking
- When you first learn how to drive, everything is happening fast and you have to deliberate think about everything you are doing
  - Then all of the sudden, it goes into default mode network and it’s easy
- This also happens with work
  - You need to work to survive but it’s hard at first, but then you’re in the groove and you’re constantly working

***Somewhere along the way with the abstraction of going to work to make money to survive and get the things we want, we forget about the things we want***

- We just go to work to work, to make more money, to go to work, to make more money, and the things we want either get pushed for ahead or forgotten about because we’re an autopilot
- This is good in the respect that it makes us good at our jobs, but we’re forgetting why we did this in the first place
  - People aren’t like, “*I really wanted to be a plastic salesperson. I really love selling plastics, more and more plastics, and piling up numbers in a bank account*.”
  - Those numbers in a bank account were really meant for, “*I want to hang out with my buddies, and I want to go skiing, and I want to get married, and I want to donate to this charity, and I want to do X, Y, and Z.*”
  - But we forget about that, and we’re not even thinking about when is the best time for it to happen
    - Instead it’s, “*Ooh, I’ll eventually do it, or when I get more*”

> “*We’re completely out of touch of what we want… the concept of enough, what that means for us, and the concept of when*”‒ Bill Perkins

**The time and focus people devote to work**

- Peter had a discussion with a patient yesterday who runs a hedge fund, and not surprisingly, given the economic climate we’re in, hedge funds are not doing particularly well (especially long hedge funds)
- This guy doesn’t need to be working, even though he is having a down year
  - He could return all the capital to his investors and manage his own capital indefinitely, or do nothing
  - Instead he said, “*What would I do? I’d sit around for 3 months and it would feel really nice to have no stress for 3 months, and then I’d be bored out of my mind*.”
    - So he keeps going
- Bill asks his friends, “*Why do people do this?*”
- Bill is very aggressive with his friends, attaching their walls as they put them up
  - He tells them, “*You have made your work your god*”
    - Work is how they meet people
    - They eat around where work is
    - They’ve given up learning how to socialize and meet their neighbors, they haven’t exercised those muscles in years
    - Everything is some kind of work or work related

***So when you take work away, people don’t know what to do***

**Without work, people don’t know what they want**

- Their dreams have left them
- They haven’t thought about that ski trip, or hanging out with their buddies, or whatever
- Because they haven’t worked out those muscles
- Bill tells people that once they start working those muscles, they will have plenty to do
  - “*You’ve let autopilot and habit put you in poor health in these other activities. You’re in poor health on how to meet people and socialize outside of work. You’re in poor health on where to go eat lunch (except for the places near work or wherever you go). You’re in poor health on trips that are not business trips. You’re in poor health thinking about what fulfills you and discovery*.”

**Discover what you want**

- A lot of life is discovery, you get exposed to it and discover what you want
- Nobody comes out of the womb like, “*I don’t like onions, and I love chocolate, and I want to go to Japan, and I love F1*.”
- A lot of people are in the familiar habituated routine
  - They are a rat on a wheel that doesn’t even need cheese anymore; it just runs in the wheel

**How do we differentiate that from people where a big part of their work is their fulfillment and sense of purpose beyond the money making part of it?**

- Peter puts himself in this category
- But if you consider a person who works in a widget factory, and they don’t even know what the widget plugs into, they just need a job
  - If they inherit a big sum of money tomorrow, they would happily quit the widget job
  - But maybe they’d get bored and want to start volunteering and do something they really enjoy
- For other people, the job is doing 2 things‒ it’s providing money for all the things you need and it’s also providing a sense of purpose (and therefore fits into their fulfillment)
- Peter things this can be very slippery, and he works harder than he should
  - He knows he’s failing in this equation even though he’s fulfilled by this and wouldn’t want to not do this
  - But he’s doing too much of it
- Bill pushed back hard on his friends about this, and he can’t know, only they can know
- The heroin addict is happy on heroin
  - You tell them they have a heroin problem
- Really think about what in your job fulfills you
  - Is that outside in the world  and the purpose in that?
- Are you balanced according to what you want in this time period in your life?  In the future time period?
  - This is a very personal thing
- Be honest, be off autopilot, really unplug for a moment and think about it

***You’ve only got one life.  You only have this time period once.  You’ve only got this level of health at this time.  Are these the experiences you want?  Is this really how you want to allocate your time at this period?  Is this the maximum/ optimal thing for you to do?***

- Bill can’t tell you how to live your life, but he can tell you how to optimize your life
  - What thought process and what steps you should go through
  - What things you should be considering in order to get the most fulfillment out of your life
- Maybe you come to the conclusion that you are at the perfect balance of work, and the money that is piling up, you are going to use it later
- But maybe you realize you can dial it back
  - You’re kids are only going to be this age at this time
  - Maybe you should take a family trip and unplug and go on safari with them because that’s going to give you a lifetime of memory, dividends, and discussion points, and connections, etc.
  - Maybe you’d rather have that time with them now and not later when you’re in a hospital, old
  - Maybe you want the memories and the time to spend with them now and not at the tail end of life

***The important thing is thinking about optimizing your life is going to lead to a more fulfilling life***



## Thinking about the order of experiences you want to have based on seasons of life [50:00]

- This is the part of the book that resonates with Peter, thinking about his kids
- His kids are separated in age
  - His daughter is 14 and the boys are 8 & 5
- So he now knows what it’s like to have a teenager
  - He understands all the things you give up when your kid is a teenager
  - His daughter is an amazing kid, but the reality is that she doesn’t want to be around him
- Conversely, the boys can’t leave him alone
  - It’s tempting to say, “*I wish they would just leave us alone*”
  - But the reality is in 6 years, you’d kill to be back in this situation

***So having that perspective of understanding the seasons makes it infinitely more easy to appreciate your current situation***

**Peter’s college experience**

- Peter remembers how hard he worked in college; he couldn’t have worked harder
  - He had 1 night off (Friday), when he only worked till 9 PM, and from 9-11 he would go and  do laundry
  - That was his way to take a little time off
  - Otherwise, it was 6 hours a day of work outside of class
  - He thinks of all the things he didn’t do in college
  - His only memories of college are pure misery, “*I hated every minute of college*”
  - He didn’t have the “college experience”, but a lot of good came out of that
    - This set him up for the next thing, and the next thing, etc.
  - But he could have traveled
  - He could have saved all the money he was making tutoring and done something different

**This reminds Bill of something he read his senior year in college, the “*****50 things You Need To Do Before You Graduate*****”**

- He had the biggest regret when he read that list
- He thought, “*I’ll never going to be able to do this, I’m not going to do this*.”
- Some of them were simple‒
  - Write an angry letter to newspaper, go skinny dipping at lake (Bill actually did that after reading this)
  - Do this college prank, do whatever, things that would be fun and didn’t necessarily cost you money, but they were things to do to have a college experience (and not necessarily do them all)
- He did maybe 3 or 4 and he realized, “*Why was I so on autopilot in my way? Didn’t think about, okay, you got 4 years here, good, good grades, good study, but you want to get this out of it, you want to do this out of it, you want to have this college experience, etc.*”

**Think about the order of experiences you want to have**

- We go on autopilot so much that we don’t think about the periods in our lives (even this year)
- We don’t think about the experiences we want to have this year
  - With this person
  - With yourself‒ with your spirituality, your health, your travel, your leisure, your job
- We don’t think about, “*How am I going to optimize and how does that fit into the Tetris game of my entire life? Am I doing it right? Maybe this experience that I’m saying goes here, actually goes further out in my life*.”
- When Bill was trying to get the book published, one of the publishers she does exactly what he talks about in the book
  - She really liked running but had an injury
  - Now she does hiking and she really likes concerts and music
  - She goes on a vacation with a friend every year
  - There’s this very expensive opera that she wants to go and see
  - She and her friend decided that they are going to pull forward going on hiking trips to this mountain, etc. and trips of sitting in operas, etc. they were going to push into the future
    - To maximize their fulfillment
    - If they got that order wrong and went to the opera first, then they might not get to hike this mountain
- This kind of thinking fits into every aspect of your life
  - College, first job, pre-married, married, before kids, kids that are toddlers, kids that are not toddlers
  - Bill thinks that type of thinking is really helpful, and Peter has been lucky because experience has taught him about the seasons with his kids
- Bill learned this the hard way, that your kids don’t want to be with you when they’re 13
  - You forget that you didn’t want to be around your parents when you were 13

## Bill’s unique perspective on philanthropy and a more impactful way to give money away [54:45]

**Story of a woman who dies and leaves a large gift**

- This is one of those secret millionaire stories
- There’s a secretary and when she died, she had $10 million of Tootsie Roll stock (or whatever)
- This woman worked at a law firm, saved her money, and lived by all accounts, a very frugal life
- When she died, she gave a multimillion dollar gift to education, charitable education
- Everybody thought this was such a great thing

***Bill’s perspective was different‒ when you’re dead, the money isn’t yours, and your bequeath would have been much better off receiving the money earlier***

- Giving much earlier, even at a lower sum is better
  - The return on charitable investment will be greater than any investment returns
- He can’t get into her head and determine if it’s charitable
- It appears to be a tip on the way out
- The money has to go somewhere
  - It could go to the IRS to redistribute the way they see fit (usually into wars and stuff)
  - But when you die, the money is not yours, it’s gone

***Life is urgent, life is now. And I argue that the return on investment in your charitable endeavors is greater than any return in the market you can get.***

**John Arnold’s decision to make giving money away his full-time job**

- Peter thinks this is interesting and relates it to their mutual friend [John Arnold](https://en.wikipedia.org/wiki/John_D._Arnold)
- 10 years ago (before he was 40-years-old) he decided to change his full-time job to giving his money away
  - He was a titan of natural gas trading
- He decided, “*I’ve been solving the problem of natural gas long enough. I have more money than I’ll ever spend or need. And I really want to dedicate my neurons to solving other problems*.”
- He takes an analytical approach (a database driven approach) to solving some of society’s ills
- The fact that he’s solving some problems and trying to get ahead of some of these intractable problems at such a young age is awesome
- Bill even argues with John that he did it too late
  - He was on autopilot with his job (trading)‒ “*What are you working for?… What’s the money for? What can’t you buy?*”
- To a certain extent, money can become a detriment to your value system
  - An exaggerated example would be to have [Maroon 5](https://en.wikipedia.org/wiki/Maroon_5) play in your backyard every day, but you don’t want to ruin your kids by spending money and consuming it that way
- There’s all kinds of consumption that you don’t want to have, because you don’t want your kids to have that

**Money can become a negative**

- You really worked too long for it, because you’re working for money that you cannot spend
- So now you could start giving away and having an impact on the other things you want to do

**Being thoughtful and strategic about giving away money**

- John exemplifies how to give money away thoughtfully
  - Spending time with him, Peter realized how hard it is to give money away strategically and thoughtfully
    - This is why he suspects John and Laura set themselves up with 50 years to give
    - There’s still a pretty good chance they won’t be able to give it all away
- They’re being effective about giving away money
  - They want to solve problems, database decisions
- But it takes time
  - You have to invest the time to try something out to see if it works
  - And if it does, double down
  - If it doesn’t, learn why not and pivot

***If you wait until the end of your life to give away a billion dollars, it won’t be effective***

- There is also the compounding issue if you wait to give
- Another layer to this‒ giving early allows you to have a chance to learn from what that money did and make corrections
  - This allows for more thoughtful giving
- Bill can’t say enough about the [Laura and John Arnold Foundation](https://en.wikipedia.org/wiki/Arnold_Ventures_LLC), about the way they’re going in and helping people and solving problems

**Why giving money to people who are important in your life might not be the right strategy**

- Peter comments that one of the reasons he gave his wife [Bill’s book](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1) to read was the discussion of the idea of giving people in our lives money at some point
  - You think, “*That’s a person that was really important in my life or in our lives, and maybe we leave them X amount of dollars at some point*”
- Bill replies, “*The same laws of physics that govern my body and the utility of money over time for me applies to my kids*”
  - Or relatives, or anybody

**The utility of money follows a curve**

- This depends on how healthy one is, etc.
- Bill used to have people on his will to give money to when he died that were close to his age, but then he realized, “*Wait a minute, I’m going to give my money to a 72 year old. Wouldn’t it be better if I gave them less money now? Let them spend it and apply it because the utility of money for them is drastic.*”
- The day before you die, I cannot pay you anything, I cannot get you to delay gratification
  - That’s what savings is, right? You’re delaying gratification
- If you take it from it the day before you die, to 2 days before you die, to right now‒ there’s this curve, this compensation you need for delayed gratification
- Bill adds, “*It makes no sense for me to be leaving money to 65 year olds and 62 year olds*”
- He wants to give it to them when the money will have the most impact, when they’ll have the most utility of that money
- The will has a purpose‒ if you die early, you’ve got to distribute the money
- But really before you die, if you live a normal life, there should be nothing left to give because you should have already given it away
- When Peter read this part of Bill’s book, this realization was such a gut punch
  - One example is kids
  - Peter and his wife have people in their life that they value so much, and they have always said, “*We want to give them X number of dollars at this point in time.*”
- Bill agrees, if he had a good year, there are people he would give money to
  - He’s not going to wait until he’s dead

***The maximum tax free gift you can give per year per person is $15,000***

- Bill had a list of 30-50 people to give $15,000

**Why did Bill write this book?**

- He wrote it to save his own life
  - He didn’t want to waste his life
  - He wanted to get the most net fulfillment
- After he wrote the book he thought, “*That applies to everybody. If I’m going to do something nice and give something or leave something to somebody, it’s now.*”

**Bill’s summary**:

- When you’re giving somebody money, you’re really giving them life energy
  - You’re giving the ability to make choices
  - You’re giving them fulfillment.
- So waiting till they’re 96 on a deathbed, they can’t really convert that into fulfillment
  - You really didn’t give them what you wanted to give them
- So when you look at their curve of their life, you can find the maximum insertion point
- For example, getting $5,000 at age 33 is like getting $150,000 at age 86
  - Actually, it’s more impactful because there’s more going on in life, more choices
  - The cumulative effect when they’ve had that experience, not only do they enjoy the experience at that point but they also get dividends from the experience
    - They talk about with their friends, they become more interesting
    - They get memory dividends associated from that experience
  - Whereas if you give it to them at 96, they enjoy it once they consume it (if they can even do it), and then they die

## Applying the principles in ‘Die With Zero’ to maximize fulfillment [1:04:00]

**How do you help a person do the math?**

- This is where Bill’s background as an engineer and trader come into solving what becomes a mathematical set of equations, where you have certain variables you need to understand

**Hypothetical 50-year-old**

- A 50-year-old who is firmly planted on the treadmill of autopilot
  - Their kids are in middle school and high school
  - They realize how much money they need for their kid’s college
  - They have a mortgage payment and a good job
  - They have a fuzzy notion that they’re going to work another 15-20 years
- 1 – Bill’s 1st question is, “*What do you want?*”
- This person has kind of let go of their interests
  - Before they had kids, they loved traveling; they hiked the Grand Canyon down to the Colorado River and back up
  - Once the kids came, they put their head down and worked
  - They want to make sure their kids don’t have debt when they go to college
- 2 – Bill’s 2nd question, “***What’s reality and what’s fear-based thinking?***”
- Bill follows up with, “*Why don’t you go traveling with the kids?*”
- It’s a pain in the ass, and it’s expensive
  - A friend of their kids went on an African Safari a year ago
    - It was amazing but today that trip would cost $30,000
  - Bill asks, “*Are you on track to die with $30,000? 50,000?*”
  - They hope so
- 3 – Bill asks, “*Would you rather consume that $30,000 now and have this experience with your kids etc.? Or would you rather have $30,000 left over when you die?*”
- They want to be safe. What if they’re wrong? How do they know?
- 4 – Go through the hard numbers to look at risks and ways to mitigate them
  - It’s like do you have insurance?
  - If you lose your job, what is safe?
  - What do you envision yourself doing in retirement that you can’t afford?
  - What bad thing that might happen can we *not* buy an insurance policy for?
  - Is it long-term care insurance?
    - If you get that while you’re young, it’s actually pretty cheap
- 5 – Bill asks, “*What’s the something happening that you’re worried about?*”

**When you do that with people, how often are they able to articulate clearly what they are afraid of, versus it being just a fuzzy notion?**

- It’s a lot of it is a fuzzy notion
- He keeps pushing and pulling it out, the “*What if this happened?*”
- He goes over medical insurance
  - People try to act as their own insurance agent, with a client of one; and that’s very difficult to underwrite
  - As a client of one, they don’t understand the odds of bad things happening
- What they tend to do is put it in this big giant fear bucket of insurance premium, and they just work and save and save and save, to think that they have the notional to cover all these bad things happening
- Bill points out it cost $25,000 a night for his dad to be in the hospital
  - Insurance didn’t cover that
  - He’s only got X number of days
  - You’re not saving
  - For some things, you shouldn’t be the insurer
  - If you’re actually afraid of that and that’s important to you, you need to buy the insurance policy where they have the lower large numbers and their edge is 6% or 8%
  - And on top of that, you don’t even know the odds

**Comparing risk**

- Compare the risk of a scenario where this bad thing happens to the risk of not doing the thing you want to do now
  - The risk of NOT doing that trip
  - What does that look like on your deathbed, when you know you could have gone on the safari and had this wonderful time with your kids and connected with them and something to talk about forever and expanded your worldview
  - Was it worth the $30,000?
  - Was it worth you trying to play insurance agent?
- These are thematic conversations not hard number conversations
- The model is an abstraction
  - The variables we’re talking about are infinite
  - We have to abstract and abstract and abstract
  - The model tells you direction, but the magnitude may be off
- For you as a person, “*What’s your survival number?*”
  - Think about surviving, not thriving, “*What do you need*”
    - These are your choices
- Think about what the choices cost
  - The experiences you want to have in your life plus the 20-30% discovery
- Maybe all your experiences go in the 50 bucket
  - You didn’t realize it, but your actually inadvertently pushing them in the 70 bucket
    - And you’re not going to have them
- This is what Bill tries to get people to think about, “*Are you going to have $30,000 trips in your lifetime?*”
  - Then, when is the optimal time to have this trip and with whom?
- If it’s not a $30,000 trip, think of a different type of activity that will get you the same fulfillment (or close to it)

***The bigger point is, is there a trip that you think you will take, near the end of your life and you’re holding back on taking it now?***

- People often say, “*Well I’m saving because of just in case*”
- Bill’s response is, “*You’re not the best insurance agent, you’re actually the worst insurance agent. You don’t know the odds. You can never have the* [*notional*](https://www.investopedia.com/terms/n/notionalvalue.asp)*. And the edge, the premium that you’re extracting from yourself and that edge is your own life. You have to give up hours of your life to have this insurance premium, [this] is way, way more than just paying the insurance company.*”
- For people worried about running out of money, he suggests getting an [annuity](https://en.wikipedia.org/wiki/Annuity)
- If you’re worried about long-term health and getting sick, get [long-term care insurance](https://en.wikipedia.org/wiki/Long-term_care_insurance)

*There’s an insurance policy for a lot of things people are “saving” for or worried about.  Mitigate the risk with professionals.  Let’s get you living your life.*

**Breaking out of the “rat race” of work**

- Peter thinks this problem is pretty logical, and it’s easy to understand why a person would think “*I have to save for a rainy day*” because that’s ingrained into being a responsible person
- There is a far less logical reason that people forego doing things when their young (middle age in their working life), and that’s because they’re so busy making money
- Bill thinks, “*That’s the rat in the wheel with no cheese.*”
  - You get the rat to run in the wheel by giving them cheese
  - Pretty soon you don’t have to give them cheese, they see the wheel and just start running
  - The reward is no longer the goal, it’s just to do the thing

*How do you help somebody break that?*

- That’s the hardest one to break, because they’ve been brainwashed into thinking, “*This is what I want to do*”
- Bill asks them, “*Where do you socialize? Where do you eat? Where do you eat lunch?*”
- Often people say they like the people they work with; they like hanging out; they don’t want to quit work
- He suggests quitting work and going on a vacation with these people
- You can still visit these people at night and play bingo games
- The people don’t go away just because you don’t show up at work
- You can actually spend more quality time with the people at work if you exercise that muscle
  - But they don’t know how to invite people over to their house or out to an event
- It’s a very long conversation of you can do this, you can do that
- Bill has to break it down brick by brick and show them how they got habituated and how they haven’t exercised these other muscles
  - And how they can replace it
  - And realize work is not the unique thing to get the things you’re getting out of work
    - It’s actually a bastardization of it
    - It’s minimizing those experiences
  - You’re not actually getting the most quality time with your coworkers in the working environment
  - You’re not getting the most mental exercise out of work (or what ever it may be that you say you are getting)

> “*It’s really hard because people will be extremely, extremely resistant. Change is painful.*”‒ Bill Perkins

- Think about going to the gym when you haven’t worked out in forever
- Just to develop the muscle to do something that is fulfilling is a process
- You have to show them the reward, that **life is rich, it’s fat, it’s wonderful**

## How to break out of living life on autopilot [1:14:30]

**Habits are powerful**

- One of the biggest cliches ever, is the person on their deathbed who says, “*I wish I didn’t work so hard*.”
  - Yet many of us still work too hard
- One of the things Bill took away from the habit books (like [*Tiny Habits*](https://www.amazon.com/Tiny-Habits-Changes-Change-Everything/dp/0358362776/ref=sr_1_1?crid=64FKLPWY6KAW&keywords=tiny+habits&qid=1670006738&sprefix=tiny+habits%2Caps%2C117&sr=8-1) by BJ Fogg) is that habits are extremely powerful
  - See also this [previous podcast](https://peterattiamd.com/jamesclear/) on building and changing habits
- We get habituated in many different ways, for good or bad
  - If you have the snacks in your house and you eat 200 calories a day in 2 years, you gain about 40 pounds
    - How did that happen?
- The same is true for fulfillment
  - How did I forget?
  - How did my life pass me by?
  - How did I not go on these trips?
  - How did I not have these experiences?
  - How did I not call my mother?
  - How did I not say I love you to these people, even pick up the phone?
    - Because my habits took over and it just absorbed my life
- Bill talks with his friends about the good of habits that keep you healthy
- But some habits that we use to be successful, they take away from other things

**Breaking out of autopilot**

*Has this been a struggle for you, that habits that help you be successful take away from other things?*

- Oh yes
- He wrote this book for himself, the first life he wanted to save was his own

> “*Put your life mask on first*”‒ Bill Perkins

- He is just as guilty as the next person of being on autopilot
- He has to constantly remind himself that he’s going to die
  - That life isn’t forever
  - This period ends
  - These seasons with my daughters end
  - These seasons with my startups end… all these things
- He has to think about “*What do I want? How do I balance them? What’s optimized?”*
- Sometimes he doesn’t get it exactly right, but it’s better than if he was completely on autopilot
- Then sometimes he realizes, “*Oh shit, I was on autopilot. Why didn’t I think about this?”*

**What helps jar you out of autopilot?**

- 1 – The death clock
  - Bill uses a [calendar of 4,000 week](https://4kweeks.com/products/poster)s and you mark off each week
  - It’s a very visceral representation that life is finite
    - Not only will you die somewhere around here, but this period is going to end
  - He sees it every day; it’s a constant reminder
- A lot of times when people go on vacation, and knowing that the vacation ends on Friday, this motivates you to do all these things
  - You actually get more out of the trip knowing it’s going to end
  - As opposed to living obliviously until all of the sudden, it’s time to go, and you forgot to do the things you really wanted to do

***When you know life is going to end, it becomes more urgent***

- This is true even for segments in your life
- When you know your early-50s are going to end, it becomes more urgent
  - You become more deliberate, you get off autopilot
- Bill used to use countdown calendars for other things too
  - Christmas
  - His daughter’s 16th birthday
    - How is he going to pry experiences out of his daughter, because once she gets a car she’s, “*See ya, deuces*”
  - Till the job
  - The 15 year anniversary
- The 4,000 week calendar is an alarm that wakes him up out of autopilot

## When should your net worth peak? [1:18:00]

**How do you help somebody think about when their net worth should peak?**

- From this conversation, Peter thinks net worth probably needs to peak a lot sooner than it currently does
- The default for most working people is that net worth peaks sometime after retirement (or around the time of retirement)
- But for most people there’s a mismatch between when they’re hitting **peak net worth** and when they’re hitting peak **capacity to utilize net worth**
  - Bill agrees, it’s a massive mismatch
- Bill wishes he had known Peter before, because one of the things he wanted to know about was **frailty curves**‒ bone density, lung capacity, and what activities become less enjoyable first
  - This determines a lot of when your net worth should peak
  - He estimated this was somewhere in your 50s
- When he went to [St. Petersburg](https://en.wikipedia.org/wiki/Saint_Petersburg) and climbed the 211 steps (it was 11 steps to walk around the banister), there were lots of tour busses coming in
  - Not one person that was elderly climbed the 211 steps
  - So it was a different St. Petersburg for them
    - They didn’t have the same experience
    - He got more out of St. Petersburg
  - He’s not saying it wasn’t a wonderful trip for them, but they probably pushed St. Petersburg too late in life

**Bill asks why people’s net worth is still going up at age 72**

- Part of it is asset appreciation is going faster than they can spend it
- But the real answer is they can’t spend it down
- Life has passed them by
- They no longer have the attitude or aptitude to do this
- You’d be surprised how many people die in those cruise ships trying to swim when they get to St. Thomas
  - They think their life’s going to be like a Carnival commercial
  - Bill thinks that Carnival commercial will kill most Americans
  - They’re having heart attacks going down those slides
- Peter thinks if you spend a little more time on your health, you would buy yourself a bigger runway to utilize your wealth on these experiences
- Bill thinks this is particularly true for Americans

**Why is Bill’s book the most successful in Japan?**

- Bill thinks you’ll get value out of this book in the way of thinking, even if you have zero wealth
- Japan has a **savings problem**
  - Japan saves, saves, saves, then they die and they give the money to the next generation. They save, save, save
- Bill asks, “*Well, what generation actually has fun?*”
- So, he’s really counter to the culture there
- One of the criticisms of the book is there are so many people that have zero and are trying to make ends meet
  - Bill thinks they can still get value out of this, about getting the Tetris of their life
  - But maybe a book about building wealth or how to make dollars might be more useful to them
- In Japan, it’s the opposite
  - They are also healthier
  - If you walk around Japan, it’s an older country, but they’re around, they’re moving, they’re doing things, they’re having activities, they’re enjoying life
- Look at the obesity epidemic and the lifestyle of Americans
  - Their ability to consume experience deteriorates way, way faster and way earlier than the Japanese

## Taking calculated risks [1:21:30]

**Thinking about risk, what’s the mantra of the energy trader or the gas trader?**

- The name of the game is to stay in the game
- Sort of like Simon Sinek’s book [*The Infinite Game*](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1670009030&sr=8-1)
  - It’s not about winning
  - It’s about being able to keep playing over and over and over again
  - Inherent in that is never making a bet or a trade that can completely wipe you out and take you out of the game

***It’s really about taking prudent risk/ reward and then*** [***stopping out***](https://www.investopedia.com/terms/s/stoppedout.asp#:~:text=Stopped%20out%20is%20a%20term,be%20triggered%20automatically%20or%20manually.) ***when you can***

> “*Life is risk. You can get hit by a bus, a meteor can hit you, you can get some sort of crazy infectious disease*.”‒ Bill Perkins

- You’re not going to live in a bubble; you’re going to take calculated risks

**The key is taking prudent risk/ reward decisions**

- In trading, we’re optimizing for profits
- Bill doesn’t smoke, the rewards are not great enough
- He did go skydiving
  - The first time, the reward was great
  - The second time it was half as great
  - He didn’t do it the third time because the risk was the same and the reward wasn’t
    - The reward was going down and the risk was still the same
- We look at everything on a risk reward basis
  - The likelihood of dying
  - If things go awry, can we get out?
  - Have I sized my position?
  - Is the liquidity there?
  - All these things are going on all the time

**How do you think about this now in terms of the seasons of the person’s life? Are there certain seasons where certain risks make sense, be it financial risks or?**

*Bill’s example of physical risk*

- He has cartilage disappearing in [L3-L4](https://www.spine-health.com/conditions/spine-anatomy/all-about-l3-l4-spinal-segment#:~:text=The%20L3%2DL4%20motion%20segment%20includes%20the%20following%20structures%3A,front%20compared%20to%20the%20back.) (bones in his spine are hitting each other), and he’s advised against doing impact things
- He was 50 years old in the islands and guys asked him to go wakeboarding
- At first he didn’t want to go; he wanted to loaf on the beach
- Then he thought about it for a second and realized he didn’t have many wakeboarding times left
  - He’s not going wakeboarding at 60 because of this degenerative back thing, it’s going to be more dangerous for him, etc.
- He realized if he was to wakeboard, it is now
  - How many times is he going to be in warm water with his buddies where there’s a wakeboarding boat ready to go in the next 2 years?
- It didn’t hurt; he actually jumped a wake too
- Afterwards there was a little tension in his back and he was very conscious about stretching and being careful
- Now he wake surfs; it’s the low impact version of the sport
- But the last time he went wakeboarding, the risk was worth the reward
  - There was no other time
  - As he gets older, wakeboarding is much more dangerous
- He realized the speed of the sport makes a difference
  - 10 mph versus 12 mph is only 2 mph different, but it’s a 44% difference in the force
  - Because force = MV2

## Bill shares a lesson from his incredible birthday [1:25:15]

**What year was it that you had that incredible birthday?**

- 45, this is the one he talks about in the book
- But he’s had incredible birthdays since then

**You spent a lot of money.  Did you have second thoughts about it?**

- He went to [St. Bart’s](https://en.wikipedia.org/wiki/Saint_Barth%C3%A9lemy)
  - He thinks it’s the best island in the Caribbean
  - He had his honeymoon there

***As you become successful, one of the experiences you want to have is to be around your friends and have shared experiences with your friends***

- Bill coaches people to lose their attachment they have to pay, and think about what’s most important to you
  - Get off autopilot
  - Have shared experiences
- It is worth it to Bill to have friends and family around, but it gets expensive
  - You have to rent out hotel rooms
  - Plan entertainment, etc.
- Some of these people have their own lives, complications, and conflicts
  - Some won’t be alive or you may drift apart
- So Bill decided this is the time he wanted to do this
- He had a heavenly experience walking on the beach
  - Having his mother come out of her beach house
  - His friends are hanging on the balcony looking down
  - It’s beautiful, the birds are out, etc
  - He sees all the people he loves and they are doing fun activities
- He imagines this is what heaven is like, having this experience

> “*I realized that that’s what I was working for. I was working to create these experiences. These are the things that fulfill me*.”‒ Bill Perkins

- When he was planning it he felt, “*Oh shit, this is a lot of goddamn money*”
- He wondered if he was doing the right allocation because you never know if you get it exactly right
  - Nobody gets it perfectly balanced
  - But this was the right direction

**Peter’s wedding**

- This reminds Peter of when he and his wife got married in 2004
- They got married at a golf club
- They didn’t have two nickels to rub together; the whole thing cost less than $20,000
  - But that was an obscene amount of money for them at the time
- It was amazing because everybody they cared about in their lives was there (almost 200 people)
- At one point, he grabbed his wife and walked out onto a balcony
  - They could see everybody
  - He said, “*Do you realize that this is one of only two times in our life that we will be surrounded by everyone who’s meaningful to us who’s alive? And the only other time it’s going to occur, we’re going to be dead. We’ll be in the casket, we’ll be at our funeral. So, we got to really take this in.*”
- Peter realizes now there was a huge error in his logic
  - This was totally untrue, that didn’t have to be true at all
  - You can create that anytime you want
  - You can decide for no reason to bring everybody in life who matters together
    - For a birthday party
    - Or just a party
- Bill replies, “*Most of my life is finding excuses to throw parties. We get on autopilot waiting for certain events like weddings or funerals or special anniversaries.*”
- Instead we could think about designing a trip to a bowling alley or something
  - It could be low cost
  - You could have a picnic wiffle ball game

**Laser tag**

- One of the thinks Bill wants to do is get laser tag guns for his group called “Cool Awesome People”
- He wants to create this experience, “*I’m going to kick some ass on laser tag and shit talk. But I’m also going to connect and have a good time with people.*”
- The startup will be expensive, but after the initial cost, they could do it all the time
- It doesn’t have to be laser tag, it could be wiffle ball at the park
  - You could have a wiffleball league
  - Low cost, somebody bring sandwiches
  - You’re creating memories

> “*Design your life. Think about what you want out of it and make it happen.*”‒ Bill Perkins

**At that birthday party when you were 45, how many people were there?**

- 180?
- They took out the Taïwana Hotel and some of another one

**How much time did you get to spend with each person?**

- They were there for a week
- Whoever wanted to spend time with him, got to spend time with him
- Maybe he doesn’t get to talk to you, but he gets to enjoy you enjoying yourself
  - This is one of his favorite things when he throws a party
  - He feels like, “*I’m having the best, I’m watching [the best] fucking movie of my life right now. I am in an immersive theater of people I love, doing the thing they want to do*.”
- Bill is antisocial, he doesn’t like to talk that much in front of people and gets awkward sometimes
- He really enjoys watching people he loves have a good time

**Peter’s wife’s reaction to the book**

- After she read the book, one of her first thoughts was, “*I’ve never had a birthday party*”
  - The last one was when she was 7-years-old
- She also wanted to throw a party for Peter, to get everybody under one roof for his birthday
  - But Peter wouldn’t find this enjoyable because he’d be the center of attention and feel an obligation to give everybody the same amount of attention
  - For him, having a dinner with 5 friends is infinitely more enjoyable
- Peter adds, “I *guess what bums me out is I feel like I wouldn’t even know how to appreciate a party.*”
- Bill on the other hand, loves to enjoy people meeting, socializing, and connecting
  - At his wedding, there were friends that didn’t know each other but loved meeting these great people
  - He likes to throw parties, make people have fun and create environments for them to loosen up and enjoy each other
  - Watching them interact is enjoyable for him
    - Even though he might be just sitting there smiling, not really talking

**Can you enjoy a party as much if you are the host than if you’re at somebody’s party?**

- It depends
- It’s not always the same; sometimes you’ve got to solve problems
  - Someone can’t get in
  - The ice maker is broken, etc.
- But he’s rather be at a party and watch everyone have a good time than go to the movies
- He’d rather be in an immersive theater; the [McKittrick Hotel in New York and Sleep No More](https://mckittrickhotel.com/sleep-no-more/#/) is the best
  - Even though he only had a small conversation; he met a person; it was very fulfilling

## How Bill’s philosophy has evolved since writing Die With Zero [1:34:00]

**What year did you finish writing** [***Die With Zero***](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1)**?**

- It was supposed to come out in 2020, so probably 2019

**In the three years-ish since you’ve written the book, has your thinking changed in anything? Have you evolved? Are you more nuanced in anything that you wrote about?**

- Bill didn’t come up with this formula, this life cycle hypothesis, this counterfactual regret minimization algorithm where he’s solving for net fulfillment
  - These ideas were out there
  - Anybody could have written this book
- It’s how he presents it so it hits the widest audience
  - So it hits them viscerally and they actually apply it
- He thinks about the deeper layers of it, and sometimes he goes into each variable‒ **wealth, health, and time**
  - “*What’s the maximum level of health I should be?*”
- He’s not writing a health book but is looking at how to optimize this, the interplay between time and health
  - “*How much time do I really want to spend on a Peloton? How much time do I really want to do regimented eating all the time and being a pain in the ass?*”
  - “*How many chocolate chip cookies do I want to eat before I die and just suffer*”
- He wants a fulfilling life and thinks deeply about these things (that’s the cartoon version of this)
- He wrote the basic macro formula, but it’s very fulfilling to see what other people have done with this
  - Financial planners have built these spreadsheets looking at your returns, the things you like to do, etc
- Bill is mostly applying it socially
- At Bill’s wedding he said to somebody, “*Probably no one in this room will see each other more than 50 times, and most of us will probably only see us 20 times in our lives*.”
  - There were 117 people at his recent wedding
- This made him think, “*I don’t want 20. I’m going to throw parties*”
- He’s taken to throwing parties, and he takes social things very seriously because he thought about what fulfills him

**What Bill finds fulfilling**

- Socializing and seeing his friends have a good time is at the top
- Travel is a big one
- Charity is another big one
- His kids’ money is their money; it’s already taken care of in a trust
  - They’ll get their money when they’re somewhere between 26-33, because that’s the optimal time for them when they’re mentally mature and at physical maturity (not in decline)
- He wants to give his kids a roadmap

**Bill’s view on money**

- One of the biggest mistakes a lot of people make is assigning some sort of good or bad to money
  - It’s not the money that’s good or bad
  - The Bible says, “*It’s the love of money that is good or bad*”
- Money is a tool, much like a hammer and saw and nails
  - Do hammers and saws build houses?
  - No, you need to know how to use those tools
  - People build those houses

***So, does money make you happy? No, but if you know how to use the tool of money, it can make you happy or it can make you miserable.***

- He doesn’t want to tell his kids what to do, but teach them how to use the tools
- He wants to give them the instruction manual and help them become a little bit proficient on how to use the tolls and that’s it, his job is done
- He has so many friends that try to control people from the grave, that use money as a control mechanism

**Bill’s desire for his kids**

- Bill is very big on following your dream
- His Dad always tried to get him to be an attorney
- You shouldn’t push your dreams on your kids; they have their own life and it’s their adventure
- Bill wants to see his kids set up with the tools to choose their own adventure
  - He might not agree with that adventure, but he’ll be happy if they’re fulfilled

**Parting thoughts**

- Peter is grateful for this book because it has caused him to rethink a lot of what he’s been doing
  - He’s been thinking about the problem of optimizing these variables (wealth, health, and time)
- He’s confident people are going to pick up this book and find a similar magnitude of value
- Bill wrote the book to save lives
- He thinks when you read his book and get off autopilot, you will get more choices, more experience, more life
  - This is what motivates him
- Peter believes we are all going to die in a relatively short order, and anything that changes our experiential existence for the better is part of living

§

## Selected Links / Related Material

**3 books Peter has read this year about quality of life**:

- [Die With Zero: Getting All You Can from Your Money and Your Life](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1) by Bill Perkins (July 28, 2020) | [0:45, 1:15, 3:45, 15:45, 1:34:00]
- [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=sr_1_1?crid=4HZNLM7MWDD&keywords=from+strength+to+strength+arthur+brooks&qid=1669829821&sprefix=from+stre%2Caps%2C117&sr=8-1) by Arthur Brooks (February 15, 2022) | [1:15, 3:45]
- [Four Thousand Weeks: Time Management for Mortals](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/0374159122/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669829962&sr=8-1) by Oliver Burkeman (August 10, 2021) | [1:15, 3:45]

**Book that transformed Bill’s understanding of money**: [Your Money or Your Life: 9 Steps to Transforming Your Relationship with Money and Achieving Financial Independence: Fully Revised and Updated for 2018](https://www.amazon.com/Your-Money-Life-Transforming-Relationship/dp/0143115766/ref=sr_1_1?crid=3O7PFNA8V46PG&keywords=your+money+or+your+life&qid=1669834520&sprefix=your+money+or+%2Caps%2C96&sr=8-1) by Vicki Robin, Joe Dominguez, and Mr. Money Mustache (December 10, 2008, originally published in 1992) | [18:00]

**Episode of** ***The Drive*** **with John Arnold**: [#125 – John Arnold: The most prolific philanthropist you may not have heard of](https://peterattiamd.com/johnarnold/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 24, 2020) | [36:00]

**Book about the power of habits**: [Tiny Habits: The Small Changes That Change Everything](https://www.amazon.com/Tiny-Habits-Changes-Change-Everything/dp/0358362776/ref=sr_1_1?crid=64FKLPWY6KAW&keywords=tiny+habits&qid=1670006738&sprefix=tiny+habits%2Caps%2C117&sr=8-1) by BJ Fogg (January 19, 2021) | [1:14:30]

**Previous episode of** ***The Drive*** **about habits**: [#183 – James Clear: Building & Changing Habits](https://peterattiamd.com/jamesclear/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 8, 2021) | [1:14:30]

**Book about an infinite mindset**: [The Infinite Game](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1670009030&sr=8-1) by Simon Sinek (October 15, 2019) | [1:21:45]

§

## People Mentioned

- [John Arnold](https://en.wikipedia.org/wiki/John_D._Arnold) (one of the greatest gas traders, founded a hedge fund,  youngest billionaire in the US, now a philanthropist) [36:00, 56:30, 59:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/01/bio-image-billperkins.png)

##### Bill Perkins

“The Last Cowboy” according to the Wall Street Journal, Bill Perkins is one of the world’s most successful hedge fund managers and entrepreneurs. After studying electrical engineering at the University of Iowa, Bill trained on Wall Street and later moved to Houston, TX where he made a fortune as an energy trader. His professional life also includes work as a Hollywood film producer, producing *Afterlife* (2009), *Unthinkable* (2010), and *The Baytown Outlaws* (2012). Perkins is currently the CEO of BrisaMax Holdings, a consulting services firm based in the U.S. Virgin Islands.

Now at age 52, Bill views his career as an engine for personal growth and spends his time exploring the world, savoring his relationships, and taking in all that life has to offer.

[*Die With Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1) is a labor of love project. Bill has been developing the principles outlined in the book since his first job making $16,000 a year in the 90’s as a screen clerk for the New York Mercantile Exchange. [[diewithzero.com](https://www.diewithzerobook.com/welcome)]

Instagram: [@billperkins](https://www.instagram.com/billperkins/)

Twitter: [@bp22](https://twitter.com/bp22)