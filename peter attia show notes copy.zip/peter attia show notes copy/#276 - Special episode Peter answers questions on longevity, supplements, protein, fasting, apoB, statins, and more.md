# #276 ‒ Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more

**Source:** [https://peterattiamd.com/peter-faq/](https://peterattiamd.com/peter-faq/)

---

In this special episode of The Drive, Peter discusses a variety of topics, breaking away from the typical deep-dive format to explore a wide range of common questions submitted by listeners. Peter tackles subjects like the viability of living to 120 and beyond, addressing some of the optimistic theories regarding achievement of this remarkable feat. Peter then shares his drug and supplement regimen while emphasizing how individualized these protocols need to be. The conversation also touches on lowering apoB, the long-term use of statins, the myth of good vs. bad cholesterol, the complexities of nutrition research, the quest for the ideal diet, and Peter’s strategies for hitting daily protein goals. Peter finishes with a discussion about his favorite health-tracking wearables, the role of CGM in non-diabetics, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/peter-faq/the_Drive_public.png)

Play

#276 ‒ Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more

#276 ‒ Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more

1x15s30s

0:001:19:15

## We discuss:

- Overview of topics and previous episodes of a similar format [2:45];
- The viability of living to 120 and beyond: addressing some of the optimistic theories [4:45];
- The potential of mTOR inhibition as a mid-life intervention, and longevity potential for the next generation [13:30];
- A framework for thinking about geroprotective drugs and supplements in the context of a lack of aging biomarkers [17:00];
- Supplements Peter takes and how his regimen has changed in the last year [26:15];
- Pharmacologic strategies to lower ASCVD risk, the limitations of statins, nutritional interventions, and more [36:15];
- Misnomers about cholesterol [48:00];
- Why nutritional research is so challenging, some general principles of nutrition, and why Peter stopped doing prolonged fasts [50:45];
- Optimizing protein intake [59:45];
- Wearables for sleep and exercise, continuous glucose monitors (CGM), and a continuous blood pressure monitor on the horizon [1:04:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- This is a special episode of *The Drive* set up like an AMA where Nick asks Peter questions
- This will be an episode available to everyone (different from most AMAs)
- Peter hasn’t seen the questions beforehand, and as such, whereas most AMAs go an inch wide and a mile deep, here will will go a mile wide and a foot deep
- For this conversation, the team pulled some of the most common questions that we are asked
  - Including some that traditionally Peter can’t stand answering
- We end up talking about why Peter doesn’t think people are currently going to be able to live to 120, 150 or 180
  - Some of the claims you see out there all the time
- We talk about what supplements Peter takes and why you shouldn’t just blindly follow him by taking the same thing
- We talk about how to lower your [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) with and without medications
- We talk about how Peter thinks about taking statins over a long period of time and what we know about other [ASCVD](https://en.wikipedia.org/wiki/Coronary_artery_disease) modulating drugs today or in the pipeline
- We also talk about:
  - Why there’s no such thing as good or bad cholesterol
  - Why nutrition research is so hard
  - How Peter thinks about the question of “*What is the best diet?*”
  - How Peter hits his protein targets throughout the day
  - What his current favorite wearable is
  - What the role for [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor) is in non-diabetics and much more
- If you’re not a subscriber, this episode will hopefully give you some insight into our AMAs, although the format here is a little different

## Overview of topics and previous episodes of a similar format [2:45]

- Today’s episode is going to be kind of like an AMA style but the entire audio/video will be available to everyone
- There have been popular episodes in this format in the past such as:
  - [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/)
  - [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/)
- In this case, the team instead pulled some of the most frequently asked questions that have come through the website including questions Peter traditionally doesn’t like to answer

## The viability of living to 120 and beyond: addressing some of the optimistic theories [4:45]

*Why do you think it’s important to act and live like we might only get to 90-years-old?*

- This is a bit of a complicated question

*Why does Peter not have confidence in biohacking your way to 120, 150, 180?*

- He doesn’t think we have the tools to address the underlying aspects of the aging of biology that are relentlessly pushing us towards the end of our lives
  - That’s not a depressing statement; it’s just an obvious reality, right?

***There are things about us, as we age, that we have the capacity to reduce the rate of change on (we can slow them down), but he’s seen no real evidence that we can reverse them in a meaningful way***

- It’s true that there are some people out there claiming they’ve got their aging clock, and it shows that even though their birth certificate says they’re 60, they’re really 35
  - We could put some time into explaining why that’s *not* correct
- The long and short of it is we don’t have any evidence that we can take the diseases of aging and erase them, or that we can take the underlying processes of everything from defects in mitochondrial function, defects in protein folding and misfolding, changes in DNA breaking and repair, breakdown in nutrient sensing, all of these pathways
  - Peter hasn’t seen any evidence that we can undo that

**So then what would you have to believe?**

- If you’re going to believe someone my age (50) is going to be around in 70 years, you have to believe that in the next dozen years or so, someone is going to come up with a way to completely halt aging and/or reverse it
  - In other words, it’s not going to be any good if this happens 50 years from now, because in 50 years, Peter probably won’t be here
- Peter spends a lot of his time looking at this type of literature, looking at at this technology
- He hasn’t seen many examples where there’s a bigger mismatch between what is actually happening scientifically and what is being talked about in the press, on social media, on podcasts
  - That chasm is enormous
  - What’s really happening is nowhere near the sci-fi that’s being portrayed
- Peter has confidence that what’s actually happening is more a representation of reality—which is that these things are **not** a decade away
  - And that’s why he takes this point of view

**Why does all of this matter?**

- Because if you knew that this was as good as it’s going to get…
  - And by the way, Peter doesn’t think it is
  - He thinks there are incremental things that are going to make a difference, even in the lives of people more his age
- If take the view that this is as good as it gets, it would motivate you to be more serious about *using the tools that we have today* for primary and secondary prevention of disease
  - For optimizing and maximizing lifespan and healthspan
  - If for no other reason, you would do that as a hedge against the enormously long odds that something dramatic and miraculous is going to happen in the next decade or two

**When you were talking early on about diseases, were those diseases what you call the four horsemen from your** [**book**](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1695992657&sr=8-1)**?**

- Yes
- You still have to have a strategy that says, how are you not going to die of ASCVD, cancer, neurodegeneration/ dementia, and [metabolic disease]
- The only one where Peter can see a pretty clear path to delay it significantly would be **ASCVD**
  - And that’s if you take really dramatic steps early in life
  - Instead of talking about what we think of as primary prevention, think of ultra-primary prevention
  - Treating people in their 30s
  - Making sure a person never ever walks around with an [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) over 30 or 40 mg/dL
  - Making sure a person doesn’t even spend one year with mild hypertension
  - Making sure a person is always metabolically healthy
  - If you do that, you would not get atherosclerosis in a normal lifespan
- But we don’t have that degree of certainty for pushing off cancer indefinitely
- Nor do we have that degree of certainty for pushing off neurodegeneration indefinitely, dementia, sarcopenia, or arthritis
  - Sarcopenia and arthritis are not as interesting to think about because they don’t rise to the level of the horseman, but they matter a lot
  - Physical frailty is a really, really, really big one

**If you manage to not die of heart disease, cancer or neurodegeneration, dementia, and you’re willing to train really hard, Peter thinks there’s a path to be physically robust as a centenarian**

- But he doesn’t see a path to doing that at 120 or 150, unless there is a significant technological breakthrough that would basically allow us to rewind
  - And maybe this is a different/longer discussion
  - And that’s a little off topic, but it really gets into:
    - What does it mean to age at a cellular level?
    - What is the role of the epigenome in regulating our genetic code?
  - Nick knows that has been talked about a little bit in the [episode with David Sabatini and Matt Kaeberlein](https://peterattiamd.com/davidsabatini-mattkaeberlein/), and so maybe we’ll pull questions from there and do a future AMA diving into that a little deeper

**Nick’s takeaway**:

- We will succumb to the same diseases that will kill us
- Your goal with Medicine 3.0 and prevention is still to put that off as far as possible, but that doesn’t mean you’re going to put it off until you’re 120-years-old
- The goal is to really live as robustly as possible and avoid those [diseases] as long as you can, but still more in the traditional lifespan, as opposed to the 150 year old lifespan

> “*I think that taking all of the steps that I talk about in the book could seriously add a decade to life*.”‒ Peter Attia

- Peter thinks you can live 1.5-2 decades longer, but we’re not talking about adding 30-50 years to lifespan

***What is more interesting and more important (whether your adding 5, 7, or 10 years to your lifespan), is reducing/compressing the period of morbidity late in life***

- People should fixate on, “*How do I not be really, really frail both physically and cognitively in the last decade of my life, what Peter calls the marginal decade?*”
- Peter doesn’t feel like he has as much control over the question, “*Will I live till I’m 85, 90, or 95?*”
  - There are some elements of bad luck that factor into that

**What Peter feels like he has more control over when he’s in his marginal decade**:

- Can he still go for a ruck?
- Will he carry 80 lbs on said ruck? (no way)
  - He might be able to carry 10-20 lbs
- Will he be able to swim half a mile in a pool? (yeah)
  - Will he be able to swim it as fast as he can now? (no chance)
- Could he sit on the floor and get up on his own?
- These are the things he talked about in the centenarian decathlon ([episode #261](https://peterattiamd.com/training-for-the-centenarian-decathlon/))

***Those are the things we want to relentlessly fixate on, because Peter thinks most people would rather live to 90 and die of a heart attack while swimming in the ocean (but otherwise be in remarkable shape) than live to 120 and spend the last 30 years unable to do much***

## The potential of mTOR inhibition as a mid-life intervention, and longevity potential for the next generation [13:30]

**What are a few of those things that could help someone even at age 50 live longer?**

- We are really in early days of understanding what **pharmacologic inhibition of mTOR** can do
  - Discussed on the recent [podcast with David Sabatini and Matt Kaeberlein](https://peterattiamd.com/davidsabatini-mattkaeberlein/)
  - There’s really a lot of promise with this approach in virtually every other model species outside of humans
    - And that doesn’t mean it will work in humans, but it’s very interesting
- Peter thinks if we had better biomarkers…
  - That’s something that can happen in our lifetime
- That’s a very promising strategy when you consider that animal models show that pharmacologic inhibition of mTOR using rapamycin (or its analogs) even applied late in life, still provided lifespan and healthspan improvement
  - Very few other interventions have shown to do this when applied late in life

**For someone who’s listening who is maybe 50, but they have a son or a daughter who is 10-years-old. How do you think that 40 year time scale differs as you look at a 10-year-old’s potential lifespan today compared to your 50-year-old lifespan today?**

- - Peter doesn’t know, but he’s that guy
    - He has a 6-year-old, a 9-year-old, and a 15-year-old
    - He often thinks about, “*What’s the difference between me and them in terms of their runway versus mine, vis-a-vis the types of technological breakthroughs that we’re interested in?*”
  - What Peter is most interested in: selective and high fidelity, high precision modulation of the [epigenome](https://en.wikipedia.org/wiki/Epigenome)
  - He simply doesn’t have a way to predict the pace of that type of innovation
  - Not to be a doomsdayer, but even though his kids have a longer horizon for good things to happen, they also have a long horizon for bad things to happen

- ***For bad things, he can’t help but think about nuclear war***

**How would Peter rank the possible bad things that could happen to our kids?**

- Biological terrorism is the single greatest threat to our species
  - Simply based on the low barriers to entry and the ease with which there’s proliferation
- You could debate, “*What’s the greater threat to our species?*”
  - Is it nuclear war?
  - Is it climate change?
  - Is it biological warfare?
- The point being here, they have just as much time to be exposed to really bad things that could obliterate our species as good things that could extend the life of our species
- Peter doesn’t know how to handicap the pros and cons on that

## A framework for thinking about geroprotective drugs and supplements in the context of a lack of aging biomarkers [17:00]

**The lack of biomarkers for aging is frustrating**

- When you look at protective molecules and if these things are working or not, we don’t really know because we lack biomarkers

> “*One of the most important things to understand when you are using some sort of intervention is, do you have a biomarker to know if you’re doing it correctly?*”‒ Peter Attia

*Think of really basic things that most people don’t even consider as an intervention: e.g., nutrition*—

- How would you know if you’re eating too much?
  - Do you have a biomarker for it? (sure, there are lots)
  - One biomarker might be your weight
  - Another biomarker might be your waist circumference, your insulin level, your glucose level, your average glucose
  - You get deeper and deeper down this, and you start to realize that how much you eat, you have a way of getting feedback from the system that tells you if you need to correct this
- The same is true for exercise
- The same is true for sleep
  - There might not be a lab value that is specific to sleep, but there are clearly ways to get feedback to know if you’re sleeping too much or not sleeping enough

*If you think about it through the lens of taking exogenous molecules*

- You take a drug like [lisinopril](https://en.wikipedia.org/wiki/Lisinopril) (an ace inhibitor for lowering blood pressure), how do you know if you’re taking the right amount?
  - You measure your blood pressure
  - Let’s say you get started on a dose of lisinopril when you’re starting blood pressure was 135/ 85, and all of a sudden, it’s 115/ 75
    - That says the drug is working
    - Are you symptomatic? (That’s another biomarker in a sense)
      - No, you’re not lightheaded (Great, everybody wins the game)
  - If your blood pressure goes too low and/or you’re symptomatic (which is probably the bigger issue), then you’re taking too much
    - You have to dial the drug back
  - If you’re taking the drug and your blood pressure comes down but doesn’t come down enough, that’s more feedback
    - Dial the drug up
- So you have this sort of input output ability with every drug
- The same is true with drugs for diabetes, with drugs, for lipids
- With cancer drugs that you take, you can look and see if the tumor is shrinking/ growing
  - You have somebody getting feedback

The problem when it comes to geroprotection is that is a broad category where we are not targeting diseases specifically

- Instead, we’re targeting the underlying mechanisms of aging, and we can’t measure it
- We take a supplement that we believe is geroprotective, and we don’t know if it’s working
  - Are we taking enough?
  - Are we taking too much?
  - Maybe if you’re really lucky, you might find a side effect that tells you you’re taking too much
    - But do we really want to be in the game of pushing things to the point of seeing overt side effects?

**As unsexy as the world of diagnostics and biomarkers are, they are a very important problem**

- Biomarkers is not a place where people like investing money
  - There’s not an enormous amount of capital being thrown at the problem
- Biomarkers are important in humans if we’re interested in studying geroprotection
- The very first time Peter went on a long diatribe on this was back when he was really, really obsessed with trying to understand the perfect routine for fasting (circa 2018, 2019, 2020)
  - He was very frustrated that as much as he was trying to study this in himself and doing every sort of blood analysis under the sun
  - He had no way of knowing if his fasting protocol of 7-10 days of water only once a quarter, 3 days, once a month
    - Was that too much? Was that too little? Was that doing anything? No idea.
  - To this day, Peter has no idea if his fasting provided any benefit at all
    - He doesn’t know how to measure it
  - He could certainly pont to some negative things it did
    - It probably cost him 20 lbs of muscle over 6 years
    - Maybe that was a worthwhile trade-off given some other benefits, but how would he know

***Peter hopes more resources will be poured into this problem, because otherwise, it’s going to be very difficult for us to move further in understanding what works in humans***

**Peter has often talked about his analogy of, “*****Are you picking up a gold coin or a penny? Are you picking it up in front of a train or a tricycle?*****”**

- This relates to drugs and supplements
- Based on everything that Peter just said: a lot of this is kind of a guessing game, and we don’t really know
- We need to anchor it to another framework to try and figure out, “*What are the risks and what are the potential rewards? What are we willing to do and not do?*”
- Peter explains this is nothing more than a very simple matrix of risk and reward (shown in the figure below)
- Putting obvious concrete examples in the corners of the matrix makes it easy to remember

![](https://peterattiamd.com/wp-content/uploads/2023/10/f1-peterfaq.png)

**Figure 1. Matrix of risk and reward**.

- As you go from higher risk, you would expect and demand higher reward

**Thinking about risk and reward: a story about teenagers playing chicken with a train**

- Peter is embarrassed to say this because it speaks to just how stupid teenage boys are and how much of a miracle it is that our species still exists with the utter lack of judgment that exists in the presence of young boys
- When he was in high school, one of the favorite games to play when they would get off the train:
  - They would immediately jump under the train and see who could lay the most coins on the train track, and then get out as quickly as possible so that once the train started rolling, you could see how many coins got flattened
    - Just think about the abject stupidity of this game
  - Another game that was tragically very popular when he was young was playing chicken in front of the subway in Toronto
    - Who could be the last guy out
    - Very sadly, the younger brother of one of his friends in high school did not make it out
    - He was killed by a subway playing a stupid game of chicken
    - Talk about incredibly high risk for no reward

**How do we apply that to interventions?**

- We’re talking about this through the lens of supplements
- We have to acknowledge that there’s a great uncertainty with many of these things, and therefore we should ask ourselves, “*How can we handicap the risk based on human data, animal data, safety data, efficacy data as far as reward? And where on that matrix do we place this intervention?*”
- If you’re going to take (fill in the blank) some fancy supplement that some internet guru is telling you he’s making with his own proprietary blend of crushed bird feathers and testicular juice, ***do you want to take that risk?***
  - Because it’s hard for Peter to imagine the reward is really there

**When Peter’s patients show him their laundry list of supplements**

- He walks them through a framework about thinking through it
- One of these is, “*Where are you on the risk/ reward matrix?*”

## Supplements Peter takes and how his regimen has changed in the last year [26:15]

- Peter hates talking about this, only because he notices that it tends to show up online and becomes, “*Well, if Peter does this, you should do this, or something like that.*”
  - There’s not context to it, and therefore nobody understands the rationale and clinical history

**Daytime supplements**

- Peter takes [**EPA**](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) **and** [**DHA**](https://en.wikipedia.org/wiki/Docosahexaenoic_acid)**,** [**fish oil**](https://en.wikipedia.org/wiki/Fish_oil)
  - He’s doesn’t have any affiliation with any of these companies, but likes to give a shout-out to companies he thinks sell good products
  - He uses [Carlson’s](https://carlsonlabs.com/the-carlson-omega-3-difference/) EPA and DHA
    - He can never remember the name, something like super EPA (it’s the highest EPA version they have)
    - He takes 4 capsules a day which is roughly 2 g of EPA (and probably 1.5 g DHA)
- The reason he takes that much is he’s treating to a dose
  - He’s treating to a red blood cell membrane concentration of EPA and DHA of about 12%
    - That’s a blood test you would do to use as a biomarker of taking too much or too little
- He takes **5,000 IU of** [**vitamin D**](https://en.wikipedia.org/wiki/Vitamin_D) (but is blanking on the brand)
  - This is one of those things where he thinks the risk is insanely low
    - This is really a tricycle, and he’s not sure what he’s picking up (more than a penny but less than a gold coin)
    - If he was walking down the street, and there was a kid riding a tricycle towards him and he saw a $5 bill, he would pick it up
- Peter thinks most of the studies on vitamin D have been very poorly done, and we do need to do a podcast on this
  - Having looked very critically at the vitamin D literature, which is insanely underwhelming, Peter thinks it is almost assuredly the result of very lousy studies that add no value to our understanding of the problem
    - The dosing has been wrong
    - The duration has been wrong
    - The compliance has been wrong
    - The targeting has been wrong
    - So we truly have no idea
- Peter takes [SlowMag](https://slowmag.com/our-products/slowmag-mg-muscle-heart/) (brand) [magnesium L-threonate](https://en.wikipedia.org/wiki/Magnesium_L-threonate) through [magnesium oxide](https://en.wikipedia.org/wiki/Magnesium_oxide)
  - That is a slowly and completely absorbed form of magnesium
  - He’s trying to get up to **1 g of total magnesium** in his system a day
  - He takes 2-3 every day
- He takes [**methylfolate**](https://en.wikipedia.org/wiki/Folate#Dietary_recommendations) **and** [**methyl B12**](https://en.wikipedia.org/wiki/Methylcobalamin) ([Jarrow brand](https://jarrow.com/collections/methyl-b-12))
  - Here we have biomarkers: you can measure B12 levels, but more than a anything he’s measuring [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) levels
  - He’s taking the methylated versions of these to keep homocysteine below 9
  - He takes 1 a day, a standard dose
  - Jarrow makes two strengths and he takes the lower one because his [*MTHFR* gene](https://en.wikipedia.org/wiki/Methylenetetrahydrofolate_reductase) variant is reasonable at methylation
- He takes [**vitamin B6**](https://en.wikipedia.org/wiki/Vitamin_B6)**, 50 mg 3x a week**
  - He used to take this every day, but has seen some people develop a sort of neuropathy as a result of taking too much
    - Peter has never experienced any symptoms from it
  - After doing a litting digging, he realized we don’t need nearly as much B6 as he thought
  - B6 helps with homocysteine, you just have to be careful that you’re not overdoing it
- He takes a [baby](https://en.wikipedia.org/wiki/Aspirin#Dosages) [aspirin](https://en.wikipedia.org/wiki/Aspirin#) a day
  - The evidence for the use of baby aspirin in cardio-protection is pretty weak
    - This is kind of a soft call
    - There’s not an evidence-based reason why he should take a baby aspirin
  - There’s even some evidence to suggest that once you get significantly older, unless your risk of cardiovascular disease is significantly high (in which case, the benefits of it are clear), but they’re outweighed by the **bleeding risks** that are associated with aspirin use
    - In particular, if you fall and hit your head, that becomes a bigger liability
  - Baby aspirin use falls in and out of favor over time
  - Given that Peter is very young, relatively speaking to these study populations and not really at risk for a bleeding injury, he thinks of this as picking up like $1 or $2 in front of a tricycle

***He is always happy to reevaluate the use of any supplement in the presence of new data***

- He also takes **Athletic Greens**, [AG1 drink](https://drinkag1.com/campaign/d35ct-offer-immunity-v5/en?gclid=CjwKCAjw69moBhBgEiwAUFCx2FFFrcvJv1FHh_f2Jd_Kz19FFLygR3nTYXx5v4fsDdTFa7WOMyyZnBoCGR0QAvD_BwE&gclsrc=aw.ds) in the morning
  - Disclosure: Peter is an investor in that company and an advisor
- Along with this, he also takes a **probiotic called glucose control** made by a company called [Pendulum](https://pendulumlife.com/products/pendulum-glucose-control-2-og?utm_source=search&utm_medium=google&utm_campaign=132401569592_0a0a33abe6ddb35abab93336335b48e3&utm_term=pendulum%20glucose%20control&gclid=CjwKCAjw69moBhBgEiwAUFCx2HFi0MRYxU7OPjVZnEWDiBZdhCOLMoiQoYX70pUOZZSg2a2Ylyou2BoChSoQAvD_BwE)
  - He takes 2 in the morning with his AG1; that’s the first thing he consumes in the morning

**Supplements Peter takes at night**

- He takes **600 milligrams of** [**ashwagandha**](https://en.wikipedia.org/wiki/Withania_somnifera)
  - He recently switched to the [Solgar](https://www.solgar.com/products/sfp-ashwagandha-root-extract-vegetable-capsules/) brand
- He takes **2 g of** [**glycine**](https://en.wikipedia.org/wiki/Glycine) ([Thorne](https://www.thorne.com/products/dp/glycine) brand)
- He takes [magnesium L-threonate](https://en.wikipedia.org/wiki/Magnesium_L-threonate), mentioned earlier ([Magtein](https://magtein.com/products/magtein-orginal-formula) brand)
  - Anytime you’re buying magnesium L-threonate, just make sure it has Magtein in it
    - You could buy it from any different company, but they have to have the Magtein proprietary combination as they’re the only people that have the license to make L-threonate
- Occasionally for travel, he will take [Jarrow’s](https://jarrow.com/products/ps-100-100-mg-softgels) [**phosphatidylserine**](https://en.wikipedia.org/wiki/Phosphatidylserine)
  - It comes in 100 mg capsules or gel caps, but for some reason he likes the gel caps better
  - If he’s on a long flight where he’s trying to overcome a significant time zone, he will usually take about 400 mg
  - This has been tested readily up to 600 mg

**What percent of the same supplements and the same doses were you taking a year ago?**

- A year ago he was not taking the pendulum probiotic
  - That’s something he’s only been taking for a couple of months
  - He’s doing an experiment there, which is looking at average blood glucose
  - The reason he’s taking this particular probiotic is he thinks this is the most rigorously tested and validated probiotic out there
  - In a small but [double-blinded randomized clinical trial](https://drc.bmj.com/content/8/1/e001319.long), it demonstrated a 0.6% reduction in hemoglobin A1C in people with type 2 diabetes in only 90 days, which is pretty interesting
  - It also was demonstrated that it caused about a 30% reduction in postprandial glucose AUC (area under the curve); meaning when you gave people a glucose challenge, and then measured and plotted a graph of their glucose response and looked at the area under that curve, the people who had been taking this Pendulum glucose control probiotic had a 30% reduction in that
    - Meaning they had become more insulin sensitive
  - Peter is a couple of weeks away from doing a blood test on himself to see if he’s had any improvement in glycemic markers in response to that
- He was not taking ashwagandha a year ago
  - He had taken it a long time earlier, but just came back to it
  - He found a slightly more potent version of it
- He was taking a different brand of fish oil
  - Before he had used Carlson’s in the past, and had switched to Nordic Naturals
  - Now, he’s switched back
  - He finds Carlson’s to be a slightly more robust product
  - The Nordic Naturals ones, for some reason, every third bottle had a broken capsule in it, and once a capsule breaks in the bottle, it just totally destroys the remaining of the capsules
    - It was just happening too frequently, and Peter was kind of aggravated by it
- He doesn’t think he was taking a baby aspirin a year ago
  - That’s something he’s done on and off over periods of time
- Probably the same with vitamin D; it’s possible he wasn’t taking vitamin D a year ago
- Vitamin B6 dosing has changed, as mentioned earlier

## Pharmacologic strategies to lower ASCVD risk, the limitations of statins, nutritional interventions, and more [36:15]

**Rapamycin and metformin**

- The most common drugs asked about are [rapamycin](https://en.wikipedia.org/wiki/Sirolimus), followed by [metformin](https://en.wikipedia.org/wiki/Metformin)
  - We won’t get into those too much here because of that [podcast](https://peterattiamd.com/davidsabatini-mattkaeberlein/) with David and Matt
  - Peter and Andrew recently did a [journal club](https://peterattiamd.com/andrewhuberman2/) where Peter focused on metformin
  - Just for time’s sake, we’ll kind of punt those to those other resources

Outside of that, questions around drugs that we get asked the most about are those within the realm of ASCVD

- As Peter mentioned earlier, that’s a disease that we have some chance to really stop and to really delay the onset of it if we take early interventions

***How do you lower your apoB, and what’s realistic with and without pharmacology?***

- W*ithout* pharmacology, exercise has no meaningful impact on [ASCVD risk factors](https://peterattiamd.com/understanding-cardiovascular-disease/) through lipoproteins (but it reduces risk in other ways)
- If you’re just talking about managing [*lipoprotein*](https://en.wikipedia.org/wiki/Lipoprotein) *risk*, **pharmacology is the most potent way** to do it

- Nutrition is a far less potent than pharmacology but not insignificant
- On the nutrition front, you basically have two levers to pull
  - 1 – You can dramatically reduce **carbohydrates**, which will lower **triglycerides**
    - And all things equal, the lower triglycerides, the lower the [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) burden because you have to traffic fewer triglycerides with the cholesterol
  - 2 – The other way to do it is to dramatically cut saturated fat
    - In a **high saturated fat diet**, what typically happens (in addition to an increase in cholesterol synthesis), is the liver, through something called the [sterol regulatory binding protein](https://en.wikipedia.org/wiki/Sterol_regulatory_element-binding_protein) says, “*I don’t need any more fat brought in. I don’t need any more cholesterol brought in.*”
      - So it downregulates [LDL receptors](https://en.wikipedia.org/wiki/LDL_receptor)
      - So it pulls fewer LDL out of circulation, and **LDL will skyrocket**
    - So the reverse is true—if you cut saturated fat, the liver is going to want more LDL coming in
      - It will upregulate LDL receptors and pull more LDL out of circulation
  - ***If you were on a really low carbohydrate, really low saturated fat diet, you would indeed lower your apoB***
    - Would you lower it to the levels that are necessary to make ASCVD irrelevant? ⇒ For most people, probably not
    - Would that be a diet that, for most people, is sustainable long-term? ⇒ That’s probably a very individual decision
    - For someone like Peter who has very low triglycerides, he doesn’t go out of his way to eat saturated fat, but he’s also not restricting it either

**Peter’s apoB levels and how it shapes his pharmacologic strategy**

- Peter’s apoB at baseline is about 90-100 mg/dL (that’s his normal level)
  - This is in line with where the average person is
  - But this is far too high for someone who (A) has a genetic predisposition to ASCVD and (B) for somebody who wants to take this ASCVD off the table
  - Peter’s personal **target for apoB is 30-40 mg/dL**, and this requires pharmacology

**3 drugs Peter takes to lower his apoB**

- 1 – A PCSK-9 inhibitor called [Repatha](https://en.wikipedia.org/wiki/Evolocumab)
- 2 – A combo drug called [Nexlizet](https://en.wikipedia.org/wiki/Bempedoic_acid/ezetimibe) (which is bempedoic acid and ezetimibe combined into a single pill)
  - The mechanism of action of [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe) is it blocks the [Neimann-Pick C1-Like 1 transporter](https://en.wikipedia.org/wiki/NPC1L1) in both hepatocytes and enterocytes of the gut
  - It prevents non esterified cholesterol from coming back into the gut after you’ve recirculated it through your liver and into bile
  - So it prevents you from reabsorbing your cholesterol
  - Of the three drugs he’s taking, that’s far and away the *least potent*
- 2 – [Bempedoic acid](https://en.wikipedia.org/wiki/Bempedoic_acid) is a pro-drug
  - What that means is by itself, it is inactive
  - So when you ingest it, it goes to the liver and it gets activated
  - In the liver, it is a cholesterol synthesis inhibitor
    - It acts on a different enzyme from statins
  - What makes bempedoic acid special is that it only inhibits cholesterol synthesis in the liver
    - Whereas statins (which are very potent inhibitors of cholesterol synthesis) do so throughout the body because they don’t have this pro-drug trick
  - When the liver senses less cholesterol, it increases LDL receptor expression on its surface and pulls more LDL out of circulation
    - So that’s how both statins and bempedoic acid work work indirectly
    - The difference is bempedoic acid is less potent than a statin, and more selective in that way

***The combination of those three drugs will keep Peter’s apoB negligible, and equally importantly, there are no side effects associated with that for him personally***

- Lipid management is one of Peter’s favorite topics and he always tells patients, “*We have tools today that we couldn’t even fathom 20 years ago*.”

**Statins**

- 20 years ago, if you needed to have your apoB slammed, there was only one way to do it, which was megadose of statins

> “*I don’t believe any patient needs to be on a megadose of a statin today. We just have too many other tools.*”‒ Peter Attia

**Concerns about megadoses of statins**

- The efficacy curves show that statins hit their maximum efficacy at about a quarter dose
- For example, if you look at [Rosuvastatin](https://en.wikipedia.org/wiki/Rosuvastatin), you’re getting 85% of its maximum apoB reduction at 5 mg
  - Roughly 85%, you hit the maximum
  - This is a drug that is typically dosed up to 40 mg; so once you hit 10 mg, there’s no need to go any higher
    - Because all you’re really doing is buying side effects, and you’re getting very little in the way of increased efficacy

***Peter is very quick to pivot patients off statins if they can’t get great efficacy with no side effects at low dose***

**For drugs like statins, if you can get the efficacy at the low dose, do you have any concerns for younger people (in their 30s, 40s, 50s) taking those drugs for a long period of time?**

- Yes and no
- It depends on the alternative
- There are some people who poo poo the side effects of statins and say they are non-existent (which is ridiculous)
- There are well-documented **side effects of statins,** at least three that shouldn’t be ignored:
  - 1 – Muscle aches
  - 2 – Elevations of transaminase or liver function tests
  - 3 -Insulin resistance
  - All of these are relatively small, but they’re not zero
  - Two of the three are objectively measurable so *Why would we ignore that?*
  - Peter really likes when you have objectively measurable side effects
- Peter would say that if a young person is in a situation where perhaps they can’t afford bempedoic acid, Nexlizet, or PCSK-9 inhibitors (to be clear, those drugs are expensive and statins are not), your alternative might be to go on a statin
- At least go through the trouble of trying to find the right statin that produces the fewest side effects
  - Probably [pitavastatin (brand name Livalo)](https://en.wikipedia.org/wiki/Pitavastatin) or [rosuvastatin (brand name Crestor)](https://en.wikipedia.org/wiki/Rosuvastatin) are probably the best places to go
  - But it’s also so highly individualized that you just have to try a couple until you find the ones that are doing the best without any collateral damage

**Do you think PCSK9-inhibitors are any closer to being more widely available (lower cost)?**

- Peter thinks so because now they are available through different mechanism
- There is a shot that can be administered once every six months [[inclisiran, brand name Leqvio](https://en.wikipedia.org/wiki/Inclisiran)]
- The twice monthly shots that he takes for a PCSK9-inhibitor have already come down in price by more than 50% since that drug came out 8 years ago
- Peter expects there will be continued price pressure on these drugs as more and more other drugs become available

**A drug in the pipeline for people who have high** [**Lp(a)**](https://en.wikipedia.org/wiki/Lipoprotein(a)) [44:45]

- Anywhere from 8-20% of people have high Lp(a)
- We’ve talked about Lp(a) on the podcast in the past [episodes [#210](https://peterattiamd.com/benoitarsenault/) and [#255](https://peterattiamd.com/johnkastelein/)]
- Peter hasn’t been following anything for the last few months, so he doesn’t have anything new to say on this since he last spoke about it
- There is a [drug](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9781646/) that is an antisense oligonucleotide that disrupts the process of DNA making RNA to make apo(a)
  - It interrupts the synthesis of the protein that turns an LDL into an Lp(a)
  - The drug worked very well in [phase II](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Summary) studies, which don’t have clinical hard outcomes
    - The outcome is just, is the biomarker improving?
    - There was a complete obliteration of Lp(a), and there were no side effects over the short haul
  - So what matters now is the phase three III study, which is ongoing, and that’s testing the more important question: does eliminating Lp(a) via this mechanism reduce major adverse cardiac events?
    - The answer to that question will determine whether or not this drug is approved and therefore becomes available
- It is unlikely for Peter to imagine that this drug will be approved to treat patients with primary prevention
  - Because the manner in which it’s being tested understandably, is for secondary prevention, and this is very common in drug development
    - You first test the drug, the clinical indication is in the highest risk patient, so you get the answer relatively quickly
- So this is a trial that is looking at people who have already had major adverse cardiac events, and it’s basically seeing can we prevent subsequent events?
  - And if the answer is yes, the drug gets approved for that use case
- It would still be able to be used by anybody for primary prevention, but it’s not likely that an insurance company would pay for that yet

**What’s a traditional timeline for drug development to go from that first use case, which is the most urgent to that primary prevention?**

- The rule of thumb is 1 decade and 1 billion for a drug to go from [IND](https://en.wikipedia.org/wiki/Investigational_New_Drug) to FDA-approval
- Once a drug is approved by the FDA, anything can be done with it
  - It can be used off-label
- In the case of statins, they were very quickly employed for primary prevention, probably even before primary prevention trials were published, because the drugs weren’t that expensive
- The only reason this is an issue here is we do not expect this drug to be cheap

**Anything else you want to say on the drug supplement category before we move on?**

- Only that Peter can’t believe we wasted how many ever minutes we wasted talking about that

## Misnomers about cholesterol [48:00]

**Why it’s nonsensical to use the phrase ‘good cholesterol and bad cholesterol**’

- Peter made a [YouTube](https://youtu.be/eod36TNGcUI?si=FMfoQG30JxEwrqBU) about this [discussed further in [episode #229](https://peterattiamd.com/understanding-cardiovascular-disease/)]
- The term originates from the differentiation between [low density lipoprotein (LDL)](https://en.wikipedia.org/wiki/Low-density_lipoprotein) and [high density lipoprotein (HDL)](https://en.wikipedia.org/wiki/High-density_lipoprotein)

*Where there’s a grain of truth*

- LDL, or low density lipoprotein (which is not cholesterol) ‒ LDL is the carrier molecule
  - It’s the low density lipoprotein
  - It’s the boat or the submarine that carries cholesterol
- LDLs are bad, and HDLs (high density lipoproteins) are good
- But HDL and LDL are *not* laboratory measurements
  - There’s no such thing as an LDL or an HDL that you can check at a lab
- You can measure the content of cholesterol within the LDL, that’s called **LDL-C**
- Similarly, you can measure the content of cholesterol within the HDL, that’s called **HDL-C**
- When you have a [basic lipid panel](https://en.wikipedia.org/wiki/Lipid_profile), and it says your HDL is 50, if you read the fine print, what it’s actually saying is your HDL-cholesterol concentration is 50 mg/dL

> “*Don’t say that your LDL is 120. Say that your LDL-cholesterol is 120 mg/dL.*”‒ Peter Attia

- Peter thinks it’s very important to be accurate in our nomenclature

***The reason that saying there’s ‘good cholesterol’ and ‘bad cholesterol’ is nonsensical is because cholesterol is cholesterol is cholesterol ‒ the same molecule of cholesterol inside the HDL is present inside the LDL***

- What’s bad about the LDL is that the LDL traffics cholesterol into the artery wall where it will get retained and oxidized and lead to the process of atherosclerosis
  - Whereas the HDL will not do that
  - That’s the fundamental difference
- We should really never say good cholesterol and bad cholesterol because it’s highly inaccurate, and it only reflects a lack of understanding of what one is talking about, which is why it certainly would be a **red flag** if a doctor ever said that

## Why nutritional research is so challenging, some general principles of nutrition, and why Peter stopped doing prolonged fasts [50:45]

**The difficulty with nutritional epidemiology and trying to understand which diet is ‘best’**

- We could spend an hour on that question, which Peter doesn’t have the appetite for
- It comes down to the complexity of the organism in question, which is us, and the complexity of the intervention, which is eating
  - So it’s really the worst of both worlds
- We can study something as complicated as nutrition in a simple organism that can be put in a cage where you can control everything, and where lifespan is short enough that you can actually measure how inputs affect outputs on a reasonable timescale
- But to be clear, even studying the effects of nutrition in a confined environment using more complicated organisms (such as rhesus monkeys, as was the case in the [NIA Wisconsin experiments](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/) from the late 1980s)
  - That’s an experiment that could never be replicated
  - It took north of 20 years to do an experiment in rhesus monkeys where you could still have perfect control over what they ate, and it’s not entirely clear what the answer was
  - [discussed further in [episode #222](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/)]
- That was an experiment that sought to test the question, “*Does caloric restriction extend life?*”
- And the answer turned out to be it depends if your monkey lives in Wisconsin or Bethesda, Maryland (of course Peter is being tongue and cheek)
- That study did answer the question if you knew how to read the study
  - He won’t get into that because he thinks there’s a whole chapter devoted to that in the [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1695992657&sr=8-1) to the long and short of why it’s so difficult to study
- When you study it in humans, you can do controlled experiments in a research setting, but by definition, they can’t tell you anything about health in the long-term sense
  - Because it would be almost impossible to confine humans for more than a month or so and control everything they ate

***One can do those types of experiments to understand very precise mechanisms of action, but those rarely translate to a clear understanding of health***

- If you want to understand what happens over the course of 1 year, 3 years, 5 years, 10 years…
  - By definition you would have to do that outside of a hospital, and you have to do it with patients being able to eat what they want
- There are some historical exceptions to this rule
- For example, the [Minnesota coronary study](https://www.bmj.com/content/353/bmj.i1246) was a 7 year study that was… the actual intervention was probably probably closer to maybe 3-4 years
  - It was done on patients in a nursing home
  - There, you had the interesting situation where you had patients who were relatively old and therefore at high risk for ASCVD, but the investigators had complete control over what those patients ate because every meal was being provided to them

***That experiment was rather interesting in that it did not yield what the hypothesis suggested***

- [discussed further in [episode #224](https://peterattiamd.com/donlayman/)]
- Peter thinks there’s lots that could be learned from that potentially,
- This is is why nutrition in humans tends to rely heavily on epidemiology where you are looking for patterns without doing an experiment, without randomization

**How Peter advises his patients**

*Are you still trying to manage their nutrition/diet, not by putting everyone on the same diet, but monitoring what that patient is doing and how to get the best metabolic health for them?*

- Peter thinks most important parameter for determining metabolic health is **energy balance**
- Even the “best diet,” if it’s in excess of energy balance, will produce poor metabolic health
  - Regardless of what you think the best diet is, if you think it’s a keto diet or a paleo diet or a low carb diet or a Mediterranean diet or a vegan diet, take any version of those and consume them to excess to the point where you are no longer in energy balance, and you are accumulating adipose tissue that leaks out of the subcutaneous space and gets into the liver, gets into the viscera, you’re going to be unhealthy

> “*Take any version of those and consume them to excess to the point where you are no longer in energy balance, and you are accumulating adipose tissue that leaks out of the subcutaneous space and gets into the liver, gets into the viscera, you’re going to be unhealthy.*”‒ Peter Attia

- Peter always thinks people are majoring in the minor and minoring in the major on nutrition when they start to fight in dietary tribes on this stuff

**There are some general principles**

- In Peter’s clinical experience, patients with profound **insulin resistance** tend to respond better to **carbohydrate restriction** as the best tool to reduce total intake
  - You have to create a caloric deficit in those patients, and they respond better to carbohydrate restriction than they do straight caloric restriction or fat restriction

***Ultimately, it matters most that you can find something that is manageable and sustainable over the long haul***

- None of this matters if you can adhere to the perfect diet for three months, and then you can’t
- It’s better to have a 7 out of 10 diet in terms of quality and perfection that you can sustain indefinitely than a 10 out of 10 diet that you can only sustain for 3-6 months.

**Why should we not just look to populations with longer lifespan and attribute their longevity to their diet?**

- There are different populations around the world who will traditionally live longer

*Do you associate their longevity with their diet? Is that a mistake for people to do?*

- It’s a complicated question because there are probably too many factors that contribute to why these populations live a long time
- Take for example, the Okinawa in Japan, they are unquestionably a very long lived people
- Although Peter has read recently, not as long lived as the current generation of Okinawan adopt a more western lifestyle (inclusive of diet), a lot of those things seem to go away
- This suggests that it might not just be the diet that is responsible for the benefits that these cultures are bestowed with

**What are some of the other things that could factor into that?**

- We could certainly look at activity level, exercise level, sleep, stress, social connections, lack of other toxic elements in the environment
- The same exercise is true when you look across all of these populations

**Diverse diets associated with long-lived populations**

- The other reason that it’s very difficult to say there’s any one perfect diet is when you look at these different populations and pockets over the past a hundred years, that have popped up and have been studied who seem to outlive others (even in relative proximity to them), their diets are actually quite diverse
- What does that tell us if you have people in Japan and people in Switzerland and people in this part of Africa and people in this part of the Arctic or whatever where you see reasonable pockets of longevity, but their diets are relatively diverse, *it might be interesting to look at what’s missing from all of the diets or what do they have in common in their absence, or what do they have in common in their presence?*

**Peter’s takeaways**

- It suggests that there’s probably a pretty robust nature within the human to manage a variety of different dietary conditions
- It comes down to correct energy balance and that a person stays metabolically healthy (so they’re active, they’re sleeping well, their cortisol levels are not through the roof)
- Our diets are problematic in this country, but just changing the way people eat alone won’t turn us into “a blue zone”

**You hinted earlier that you are no longer doing longer fasts. Why is that?**

- There are several reasons why Peter isn’t doing longer fasts
- One of the most logically relevant reasons is he doesn’t travel anymore and he doesn’t feel like doing it
- He used to only do long fasts when traveling
  - It was easier to be fasting when he was in New York and not at home

***This also speaks to the fact that he doesn’t have a clear sense of what the benefit of it is***

- This is one of those things where Peter reserves the right to completely change his mind
- If he had a biomarker that could convince him that a 7-day fast even once a year was meaningful to rewrite some negative process in the body, he would happily make that sacrifice again
- But in the absence of knowing that, the cost is a bit high right now

## Optimizing protein intake [59:45]

- We just did a premium email that looked at the pros and cons of protein
- When you look at protein and aging, it seems like it’s a bit controversial in the sense of what people will recommend

**How much protein should a young person eat?**

*If someone’s under 50 (age 30 or 40), do you think it’s important that they err on the side of caution and eat less protein based on the research?*

*Or do you still think no matter what age you are, protein is so important and that everyone should be getting as much as possible of it?*

- It depends on how much **muscle mass** that person has
- If you have **an individual who’s over nourished and adequately muscled** (so they’re overweight), but they actually have a sufficient amount of muscle mass, and they need to go into a caloric deficit
  - We would certainly tolerate a little bit of a protein deficit in that individual, not because it’s necessary, but because ***it’s easier to hit caloric targets if you are able to relax your protein targets***
  - In other words, if for example you need to be in a caloric deficit and hold 1 gram of protein per pound of body weight, that becomes really challenging
    - If you could be at 0.6-0.7 g of protein per pound of body weight, the caloric deficit is much easier
- Conversely, if **a person is over nourished and under muscled**, we have to tow that fine line of ***keeping protein high*** because that person needs to be putting on muscle as they’re losing fat
- Peter doesn’t find the data convincing that says people <50-years-old having an increase in mortality associated with a high protein diet
  - ***He thinks that mortality is easily attributed to caloric excess as opposed to protein excess***
- There are enough other confounders there that it’s [increase in mortality is] really a proxy for poor health than it is a proxy for high protein
- Furthermore, the absolute mortality in people below 50 is so low in terms of absolute amounts that even a slight increase in the relative amount is trivial

***Finally, it’s very important when people are still able to put on muscle, that they put on as much as possible, because once you’re in the over 50 category, you’re kind of clawing on for dear life and trying to keep as much of that muscle as possible***

- Peter doesn’t want people entering middle age with a muscle deficit
- This goes back to our original question: even if someone comes up with the solution for cancer and Alzheimer’s disease and all of these other things, you still have to ward against frailty

> “*You still have to make sure that you enter that marginal decade physically robust, and most people don’t come close to it. They’re really, really under muscled late in life.*”‒ Peter Attia

**How do you eat so much protein in a day?**

- Peter has the luxury of being at home, so he has more control over what he eats than if he was back on the road
- He goes through a lot of venison
- [Maui Nui](https://mauinuivenison.com/collections/venison-snacks?gclid=Cj0KCQjw1OmoBhDXARIsAAAYGSH_TzkccmZd-A5aLqp9sCVnHWJZhcNe9oOJwhISqu6K2ZL9WojizYQaAoQeEALw_wcB) makes a really good venison jerky stick (full disclosure: Peter is an investor in Maui Nui)
  - There’s no garbage in it, just natural flavor
  - Peter loves the taste
  - Each stick has about 9.9 g of protein (it says 9 grams but it’s actually 9.9 g)
- Peter thinks of each venison jerky stick as 10 g of protein, and he will eat 5-10 of those a day, representing 1-2 high protein snacks
- He gets the rest of his protein in food
- He hasn’t been doing much on the protein shake front because the jerky sticks are quicker and easier than making a shake
- He would use a high quality [whey protein](https://en.wikipedia.org/wiki/Whey_protein) shake if necessary

***Peter targets between 150-180 g of protein per day, spread over 4 meals/snacks***

## Wearables for sleep and exercise, continuous glucose monitors (CGM), and a continuous blood pressure monitor on the horizon [1:04:45]

**What is your current favorite wearable, or just a device that tracks things for you?**

*Peter has been using something called* [*Morpheus*](https://trainwithmorpheus.com/) *lately*

- It’s got two heart rate monitors
- It’s got a chest strap and a wrist strap, not a wrist, a forearm strap
- It’s got an app that in the morning, you lay down and put the heart rate monitor on, and you answer four questions
  - 1 – How long did you sleep last night?
  - Peter checks his [eight sleep score](https://www.eightsleep.com/) for how long he slept
  - 2 – How well did you sleep?
  - He looks at his eight sleep score and gets a sense of the quality of his sleep, and then he enters that
  - 3 – How do you feel?
  - 4 – How sore are you?
- Then he does a two minute lay down with the heart rate monitor on, and it measures heart rate and respiratory rate and heart rate variability
- And then it spits out a readiness score, and it provides training zones via heart rate for the day
- For the past 6 months, Peter has been doing an experiment where every time he does a zone 2 workout, he’s using the heart rate that it predicts
  - He’s riding to his [RPE](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion), and then he compares the lactate at the end of that ride to the predicted heart rate from Morpheus to the RPE heart rate
  - Overall, it tracks pretty darn well, better than he would’ve expected
  - The reason Peter is doing this is to see if this could be a good tool for patients to use who might not be as clued in to their own RPE, and who clearly don’t want to check their lactate levels

**Do you use any of that data for anything outside of zone2?**

*Are you using it for how hard you’ll push that day lifting or anything like that?*

- No
- Certainly, that’s how they would suggest you use it
- Peter doesn’t wear it outside of his [zone 2 or VO2 max training](https://peterattiamd.com/exercising-for-longevity/)
  - He doesn’t wear it in the weight room
  - He doesn’t wear it rucking, in large part because he hates wearing heart rate monitors in general
    - He doesn’t find them comfortable
    - He can sort of tolerate it when he’s on a bike, but he doesn’t want to be rucking with one or lifting with one
- It’s probably the case that it would be an even better predictor of his training if it could see him across the day
  - If it could see him train in every workout, it would probably be an even more effective tool
  - It would understand where he is in terms of overload

**Are you still using** [**CGMs (continuous glucose monitors)**](https://en.wikipedia.org/wiki/Continuous_glucose_monitor) **a lot with your patients?**

- Yeah, it’s a great tool
- Looking at a person’s [OGTT (oral glucose tolerance test)](https://en.wikipedia.org/wiki/Glucose_tolerance_test), sometimes it’s a slam dunk  that the person isn’t super metabolically dialed in
  - Sometimes, a person has type two diabetes by OGTT criteria, even if not by A1C criteria
  - But there are a lot of people in the middle
- A CGM  is a great way that you can glean more information and really dial in treatment for a patient

**There was some controversy way back when on if CGMs were still useful for people who are non-diabetics. Have you changed your opinion on that?**

- Not one bit

**What are some** **of the things you look at? How do you use a CGM?**

- **Average blood glucose** is the most important metric we care about because that’s the one for which we have the most data
  - We know all cause mortality data as it relates to hemoglobin A1C
    - [Hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) is a measurement that’s used to impute average blood glucose; this is a very, very close proxy
  - Knowing your average blood glucose on CGM and knowing your A1C are highly comparable, and therefore by proxy, the lower your average blood glucose on CGM, the lower your all cause mortality

***Because it is abundantly clear that the lower your hemoglobin A1C, even outside of the diabetic range, the lower your all cause mortality***

- The other metrics we look at are:
  - What’s the standard deviation?
    - So all things equal, do you have less variability in your glucose than more?
  - How big are the spikes you’re seeing?
    - This is the least important if the first two are reasonable
    - If a person’s average blood glucose is 98 mg/dL with a standard deviation of 16 mg/dL, it doesn’t really matter what kind of spikes they have because they’re clearly not going to be too many, unless they’re using insulin
- You could obviously arrive at those numbers the wrong way

***Fixating on average blood glucose and standard deviation are probably the most important things***

**When you wore one, do you recall what caused the biggest spike you ever saw?**

- No
- Peter’s buddy took him to a vegan restaurant in New York once, and the food was amazing
  - But by definition, it was all basically carbs
  - He remembers the dessert was so incredible
  - His CGM afterward was 180, and that might be the highest he’s ever seen

**Do you think we’re any closer to continuous blood pressure monitors?**

- Absolutely

*How far out do you think that is?*

- Nick recalls Peter talked about how important this is from the episode with [Ethan Weiss](https://peterattiamd.com/ethanweiss2/) and the [AMA on blood pressure](https://peterattiamd.com/ama48/)
- The [Aktiia device](https://aktiia.com/) works at least as well as an automated cuff
  - This device is not yet FDA-approved, but it is approved by the similar governing bodies in Europe
  - It’s a bracelet that you wear that optically measures a signal in your wrist, and every 2 hours it gives you your average blood pressure
    - Over the course of a day, you’ll get 12 blood pressure readings

***In general, automated cuffs aren’t nearly as good a manual cuffs***

- Peter doesn’t see any difference between this device and your favorite automated cuff
- With that said, Peter adds, “*I really hope that this device gets approved in the US because we’ll certainly have every one of our patients wearing this, and it would do away with ambulatory blood pressure cuffs, which are cumbersome and difficult to use and low compliance and artificial.*”
- Any listener/ viewer in EUrope would have access to this

**What do you think the rough time frame is for this to become available to people in the US?**

- It’s entirely dependent on the FDA
- It’s possible it doesn’t get approved at all if the FDA is difficult to work
  - Peter hopes that’s not the case

**Any other wearables that you’re excited about, whether they’re close to being here or even in the long term, like 10 plus years?**

- Peter would always welcome **continuous lactate monitoring** during exercise
  - That would really, really make zone two training enjoyable for him, as opposed to having to do finger pricks all the time
  - It’s the most accurate way to really understand what’s happening
- To be able to monitor lactate levels while exercising, especially doing cardio training

[***Heart rate***](https://en.wikipedia.org/wiki/Heart_rate) ***and*** [***RPE***](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) ***are just approximations for what you’re really interested in***

- Peter would also love to be able to do his VO2 max workouts with a continuous lactate meter, so he could actually watch lactate rise and clearance on each subsequent set
  - To know if as he’s fatiguing, is he really just breaking down metabolically as much as anything else?

§

## Selected Links / Related Material

**Previous episodes of The Drive in a similar format**: [3:00]

- Looking back on the first 100 episodes: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/) | Peter Attia (peterattiamd.com)
- Looking back on episodes 100-200: [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/) | Peter Attia (peterattiamd.com)

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1695992657&sr=8-1) by Peter Attia and Bill Gifford (March 2023) | [9:00, 52:30, 1:14:45]

**Episode of** ***The Drive*** **with David Sabatini and Matt Kaeberlein**: [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023) | [11:00, 13:45, 36:30]

**Episode of** ***The Drive*** **about the centenarian decathlon**: [#261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.](https://peterattiamd.com/training-for-the-centenarian-decathlon/) (July 10, 2023) | [13:15]

**RCT of Pendulum probiotic glucose control**: [Improvements to postprandial glucose control in subjects with type 2 diabetes: a multicenter, double blind, randomized placebo-controlled trial of a novel probiotic formulation](https://drc.bmj.com/content/8/1/e001319.long) | *BMJ Open Diabetes Research & Care* (F Perraudeau et al 2020) | [34:15]

**Episode of** ***The Drive*** **where Peter discusses metformin as a possible geroprotective drug**: [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers](https://peterattiamd.com/andrewhuberman2/) (September 11, 2023) | [36:30]

**Episode of** ***The Drive*** **where Peter explains risk factors for ASCVD and cholesterol**: [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/) (October 31, 2022) | [37:15, 48:30]

**Episode of** ***The Drive*** **about Lp(a)**: [45:00]

- [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/) (June 13, 2022)
- [#255 ‒ Latest therapeutics in CVD, APOE’s role in Alzheimer’s disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.](https://peterattiamd.com/johnkastelein/) (May 22, 2023)

**Antisense oligonucleotide drugs for Lp(a)**: [Targeted Treatment against Lipoprotein (a): The Coming Breakthrough in Lipid Lowering Therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9781646/) | *Pharmaceuticals* (B Sosnowska et al 2022) | [45:15]

**NIA Wisconsin experiments on nutrition in rhesus monkeys**: [51:45]

- [Impact of caloric restriction on health and survival in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3832985/): the NIA study | *Nature* (JA Mattison *et al.* 2012)
- [Caloric restriction reduces age-related and all-cause mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3988801/) | *Nature Communications* (RJ Colman *et al.* 2014)

- [Caloric restriction improves health and survival of rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5247583/) | *Nature Communications* (JA Mattison *et al.* 2017)

**Episode of** ***The Drive*** **that discussed the NIA Wisconsin experiments**: [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022) | [51:45]

**Minnesota coronary study**: [53:15]

- [Test of effect of lipid lowering by diet on cardiovascular risk. The Minnesota Coronary Survey](https://pubmed.ncbi.nlm.nih.gov/2643423/) | *Atherosclerosis* (I Frantz et al 1989)
- [Re-evaluation of the traditional diet-heart hypothesis: analysis of recovered data from Minnesota Coronary Experiment (1968-73)](https://www.bmj.com/content/353/bmj.i1246) | *BMJ* (C Ramsden et al 2016)

**Episode of** ***The Drive*** **that discussed the Minnesota coronary study**:  [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) (September 26, 2022) | [53:15]

**Maui Nui venison jerky stick**: [Venison Jerky](https://mauinuivenison.com/collections/venison-snacks?gclid=Cj0KCQjw1OmoBhDXARIsAAAYGSH_TzkccmZd-A5aLqp9sCVnHWJZhcNe9oOJwhISqu6K2ZL9WojizYQaAoQeEALw_wcB) | MAUINUI (2023) | [1:03:00]

**Morpheus heart rate monitor**: [Train smarter recover faster](https://trainwithmorpheus.com/) | MORPHEUS (2023) | [1:05:00]

**Previous episode of** ***The Drive*** **on zone 2 and VO****2** **max training**: [#206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more](https://peterattiamd.com/exercising-for-longevity/) (May 9, 2022) | [1:07:00]

**Episodes of** ***The Drive*** **on blood pressure**: [1:11:15]

- [#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.](https://peterattiamd.com/ethanweiss2/) (March 20, 2023)
- [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/) (June 12, 2023)

**Blood pressure monitor available in Europe**: [Take control of your heart health](https://aktiia.com/) | AKTIIA (2023)

§