# #33 – Rudy Leibel, M.D.: Finding the obesity gene and discovering leptin

**Source:** [https://peterattiamd.com/rudyleibel/](https://peterattiamd.com/rudyleibel/)

---

In this episode, Dr. Rudy Leibel, an expert in Clinical Molecular Genetics and Genomics at Columbia University, discusses his role in the remarkable scientific story of discovering leptin. He also gets into the genetics of obesity, as well as a broader discussion of the causes and effects of obesity, energy expenditure, and metabolism.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rudyleibel/the_Drive_public.png)

Play

#33 - Rudy Leibel, M.D.: Finding the obesity gene and discovering leptin

#33 - Rudy Leibel, M.D.: Finding the obesity gene and discovering leptin

1x15s30s

0:002:20:29

## We discuss:

- Rudy’s background, interest in obesity, and trying to understand the role and impact of adipose tissue [4:15];
- Finding the first evidence of leptin by studying obese mice [23:30];
- Zucker rats, and the push/pull theories of obesity [34:45];
- A breakthrough in obesity research, and closing in on leptin [45:45];
- Understanding leptin in humans [1:03:30];
- What Prader–Willi syndrome teaches us about body weight regulation [1:09:45];
- Leptin and the broad condition of obesity, metabolic consequences of weight reduction, and Peter’s self-experiments [1:18:00];
- How is appetite being regulated? [1:29:45];
- Are there epigenetic consequences of being obese? [1:37:00];
- What makes low-carb diets so effective at obesity reduction? [1:46:15];
- What did Rudy believe 10 years ago that he no longer believes to be true? [1:55:15];
- Rudy’s dream study of the FTO gene [1:57:15];
- What the hell does insulin resistance actually mean? [2:08:30]; and
- More.

§

## Show Notes

## Intro

Peter Attia: Hey, welcome to this episode of [The Drive](https://peterattiamd.com/podcast/). On this episode, I interview an amazing scientist and a very dear friend, Dr. Rudy Leibel. Rudy’s a professor at Columbia University where his work has focused primarily on type 2 diabetes and obesity. I’ve known Rudy for quite a while, probably about six years now, maybe a little longer. We worked together very closely back at the [Nutrition Science Initiative](https://nusi.org/) where he was one of the very important collaborators in one of the more theoretical experiments that we did. Rudy and I have always just had a ton of fun just hanging out over great meals and great wine and great beer talking about science. And so I thought it might be fun to try to reproduce some of those discussions here.

Peter Attia: A couple of things. First, we recorded this on a Friday afternoon on the Upper East Side and you’ll probably notice a little more noise than usual just on account of the street noise. So apologies for that. Second point is we spend quite a bit of time, probably about the first hour and 10, hour and 15 minutes just talking about the discovery of [leptin](https://en.wikipedia.org/wiki/Leptin) for which Rudy played arguably the single most important role. Obviously many people played a role in the discovery of leptin, but in many ways Rudy was sort of the chief architect of that and certainly inside of the scientific community he is largely regarded as that though unfortunately history may write that story a little bit differently.

Peter Attia: So for those of you listening to this who don’t really really get off on geeky science and knowing the nuts and bolts of all of the experiments and how one found this gene and the difference between a [southern blot](https://en.wikipedia.org/wiki/Southern_blot) and a [northern blot](https://en.wikipedia.org/wiki/Northern_blot) and a [DNA sequence](https://en.wikipedia.org/wiki/DNA_sequencing), you might just want to skip to about an hour or 15 when we get to the other stuff. But that said, if you really are interested in science, I think there’s a lot to be gained from listening to these discussions because that’s certainly something that I plan to do a lot of is interview scientists and part of that is kind of understanding their stories. Again, a lot of what we talk about in this post is technical. I’m hopeful that in the show notes we’ll be able to provide a lot of sort of the necessary glossary to make it a little easier to ingest.

Peter Attia: I don’t do a great job. I apologize of trying to clarify terms. Occasionally, I remember that not everybody knows what [hyperphagia](https://en.wikipedia.org/wiki/Polyphagia) means and I explained that that means eating too much. But again, apologies for that and just look to the show notes if you want clarification on anything. We get into a lot of discussion around obesity, the genetics of obesity and the regulation of obesity. How much of this is regulated centrally meaning in the brain versus peripherally, everywhere outside of the brain. We talk a lot about energy expenditure and for those of you who are really interested in this science, Rudy gives a great explanation of the two techniques that are used to measure energy expenditure known as [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry) and [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water).

Peter Attia: We talk about a number of genes that are known to predisposed to obesity, some very acutely and some very crudely like the [FTO gene](https://en.wikipedia.org/wiki/FTO_gene), and we of course talk a lot about insulin resistance, which in many ways is sort of a bit of a paradox because on the one hand if you’re insulin resistant, you technically shouldn’t be able to get fat. But of course many insulin resistant people are able to get fat. They do accumulate adipose tissue. What else can I say about this? I guess those are kind of the most important things I’d say to guide you. So in summary, if you really don’t want to hear about how Leptin was discovered, skip to an hour and 15. If you do, sit back and relax.

Peter Attia: The other highlight of this was it was the first time I ever gave Rudy a [Topo Chico](https://www.instagram.com/peterattiamd/p/BlRG-YRhEed/). He loved it and I think I’ve got another convert. So anyway, hope you enjoy this and without further ado, here is my lovely discussion with the amazing Dr. Rudy Leibel.

## Rudy’s background, interest in obesity, and trying to understand the role and impact of adipose tissue [4:15]

Peter Attia: All right Rudy, how are you?

Rudy Leibel: I’m very well, thank you.

Peter Attia: Thanks so much for trekking over to the East Side.

Rudy Leibel: Thanks for inviting me.

Peter Attia: This will be one of the first times in a while that we hang out without a drink, including my [favorite beer](https://www.instagram.com/peterattiamd/p/Boc8J86h_6j/), which you’re one of the few people I’ve shared it with. I don’t tell anybody what that beer is because … And I just found 19 bottles of it in Florida last week, so I’m pretty psyched about that. I’ll continue to share with you of course.

Rudy Leibel: Still in Florida?

Peter Attia: No, it’s actually in San Diego right now. Yeah, just arrived. There is so much I want to talk about, I almost don’t even know where to begin. I’m guessing that a number of the people listening to this won’t actually know who you are necessarily, but I think by the end of this they’ll be super interested in learning more about you. During the introduction, I will have explained sort of a lot of stuff about you, but tell me a little bit about what you do and more importantly why you do it.

Rudy Leibel: I’ve been very interested since past 30 years or so in the biology of the regulation of body weight in both animals and humans, but the studies of animals are designed primarily to shed light on what’s the basis for the control of body weight in humans. I’m a physician and have been interested in the clinical problem of obesity for even longer than I’ve been doing research on it and I have taken over the years various approaches beginning with studies of human adipose tissue aspirated using various needles from various subcutaneous depots in humans, meaning around the rear end and in the front of the abdomen.

Rudy Leibel: And then became very interested in the genetics of obesity and have done some studies trying to identify various genes that are related to that and continue to do so and have also done a large number of studies in mice designed to look at this problem. And very recently, or at least within the past 5 or 10 years, have begun to focus on the use of stem cells to try to understand, again, the biology of brain cells that regulate body weight and the cells in the pancreas that produce insulin. Because obesity and diabetes go hand in hand clinically and this is not an accident. They’re very tightly related in a number of really very interesting ways. So my studies of obesity have led more or less inexorably towards the study of diabetes as well. So now my laboratory really does some of both.

Peter Attia: And you’re at Columbia now, you were at Rockefeller before that. But originally you were in Boston, correct?

Rudy Leibel: That’s correct. My clinical training,  I’m trained as a pediatrician and an endocrinologist and that training took place in Boston at both the [Massachusetts General Hospital](https://en.wikipedia.org/wiki/Massachusetts_General_Hospital) and [The Children’s Hospital](https://en.wikipedia.org/wiki/Boston_Children%27s_Hospital). And then for five or six years I worked at both the Massachusetts General and a community hospital in the Boston area, The [Cambridge City Hospital](https://en.wikipedia.org/wiki/Cambridge_Hospital), again doing both general pediatrics and some endocrinology.

Peter Attia: So what got you interested in obesity?

Rudy Leibel: I was interested in obesity or at least in the part of the brain that regulates body weight even as a medical student. We didn’t study it specifically. It wasn’t emphasized, the role of the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus), which turns out to be very important in that regard. But I had the opportunity as a medical student, actually a first year medical student to work at the [Walter Reed Army Institute of Research](https://en.wikipedia.org/wiki/Walter_Reed_Army_Institute_of_Research) with a neuroscientist named [Harvey Karten](https://profiles.ucsd.edu/harvey.karten). He was a physician who was interested  actually in the study of bird brains and he took me on for a summer, actually it ended up being two summers to work in his laboratory primarily helping with [histological studies](https://en.wikipedia.org/wiki/Histology) of the bird brain.

Rudy Leibel: But the laboratory that he was in was run by a man named [Walle J.H. Nauta](https://en.wikipedia.org/wiki/Walle_Nauta) to who was recognized at the time and subsequently perhaps even more so as one of the great neuroanatomists with regard to the hypothalamus. So actually I was indoctrinated a bit just by hanging around the other people who were working there, including [Dr. Karten](https://profiles.ucsd.edu/harvey.karten) in terms of the importance of the hypothalamus in a number of areas of physiology.

Peter Attia: Where does the hypothalamus sit in relation to the [pituitary](https://en.wikipedia.org/wiki/Pituitary_gland) or even more grossly other main structures in the brain?

Rudy Leibel: I think you can sort of picture it as lying between or being triangulated in the sense or at the crosshairs of a line drawn between the eyes and the side of the forehead and it’s situated just above the pituitary gland, if you know where that is.

Peter Attia: Which is sort of behind the [optic chiasm](https://en.wikipedia.org/wiki/Optic_chiasm).

Rudy Leibel: Yes, that’s correct. And it’s a very small organ or at least it’s a very small part of the brain, about the tip of the small finger, but does play a role in the regulation of many  important physiological functions including things like blood pressure, body temperature, and from my point of view, very importantly body weight and also increasingly apparent that it plays an important role in blood sugar control as well. So it’s been known for many many years as being a critical part of the brain, the so-called vegetative brain, not under conscious control work that’s gone  on over the past 30, 40, 50 years has increasingly raised the level of sophistication with which we understand the function of that part of the brain.

Peter Attia: About 21 years ago, or maybe 20 years ago, whenever it was, but early in medical school I remember when we did neuroanatomy, the professor said, “If you have to sacrifice any part of your brain and you’re sort of prioritizing, the last thing you want to sacrifice as the hypothalamus. If you’re only allowed to keep a couple of square centimeters of brain, keep the Hypothalamus.”

Rudy Leibel: I mean, we could get into the weeds on exactly-

Peter Attia: That’s a poor man’s problem when you’re-

Rudy Leibel: That’s right. I think that would be important. The other thing you’d want to hang onto is the part of the brain that regulates respiration because even with the hypothalamus, if you’re not breathing, you’re not going to get very far. But I agree.

Peter Attia: I think he was excluding the brain stem.

Rudy Leibel: I understand. The hypothalamus is right up there.

Peter Attia: Yeah. At some point I want to come back to what I want to have you tell us all about [Zucker rats](https://en.wikipedia.org/wiki/Laboratory_rat#Zucker_rat), because that’s sort of what got me interested in this idea of how can this part of the brain when subjected to so many different types of insults and lesions produced so many, I mean seemingly held in disparate phenotypes that seems so out of whack. But before we go there, let’s go back to you’re a junior pediatrician schlepping along, taking care of overweight kids and we’re in the what, the late seventies? What time of year is this? What time of your life is this?

Rudy Leibel: Yeah, we’re in the mid-’70s.

Peter Attia: So there’s not that many obese kids, are there?

Rudy Leibel: They are plenty.

Peter Attia: Still in back then, yeah?

Rudy Leibel: Oh yeah.

Peter Attia: Okay. So what are you doing for them? How are you helping them?

Rudy Leibel: So back in that day, the conventional view was that obesity was largely due to imbalances of hormones that these potentially in addition to whatever other sort of behavioral issues might be implicated. But almost in all children with obesity were referred if it was significant and severe enough to either an endocrinologist or a psychiatrist. That was sort of the bifurcation point for referral of these children though I don’t think either the endocrinologist or the psychiatrist really could do very much for these children. I certainly couldn’t and it was an evening in the Fall in the city of Cambridge in a small office that I used for the very small number of referrals that I actually saw.

Rudy Leibel: Most of my time was spent with the medical students trying to teach them various aspects of pediatrics. But one evening I saw a young boy about seven or eight years old with his mother and examined him, weighed him and so forth and determined it’s quite clear that he was very obese. He had no other stigmata of the sorts of things that we looked for meaning  very severe problems with [thyroid](https://en.wikipedia.org/wiki/Thyroid) or [adrenal gland](https://en.wikipedia.org/wiki/Adrenal_gland), which can sometimes reduce severe obesity and he didn’t have any of the stigmata of the single genetic type of disorders that were known about at the time like [Prader-Willi syndrome](https://en.wikipedia.org/wiki/Prader%E2%80%93Willi_syndrome) or [Bardet–Biedl](https://en.wikipedia.org/wiki/Bardet%E2%80%93Biedl_syndrome).

Rudy Leibel: And I said to the mother, your son has severe obesity. I can’t tell you what the etiology of it is, it’s clear that there’s something going on. There’s problems that we don’t really fully understand or understand very well at all and my only advice is to try to restrict the number of calories that he eats and increase his physical activity, which is I think unobjectionable advice in any circumstance like that. And the mother turned to the boy and said, “Randall, let’s get out of here. This doctor doesn’t know shit.”

Peter Attia: I love that you remember his name.

Rudy Leibel: Oh yes, I do remember his name. And she took him by the hand and they left and I remember sitting behind the desk and thinking to myself, “Randall’s mother, you’ve got a point.” And it was that experience actually I’d been interested in some of the physiological aspects of obesity and adipose tissue. It led me to decide that if I was going to do anything about this, I was going to have to train  myself to do the kind of research that might be helpful in terms of understanding the disease and it was shortly after that, that I actually moved to New York, The Rockefeller to begin to try to do those kinds of experiments.

Peter Attia: Yeah, that story which obviously we’ve discussed before and I get such a kick out of it, but at the same time it’s actually a remarkable example of something that medicine is a privilege. It gives you a privilege and it’s up to you to do anything with it, which is patients generally provide the appropriate physician with the right level of humility. And I think, look, it’s a testament to you that you sort of could reflect on what Randall’s mom said because I think there are other people who couldn’t. There are other people who could say, “Well, screw you. That’s the advice I’ve got and that’s the best I can do.” And wouldn’t skip a beat kind of moving on.

Peter Attia: But when I talk to a lot of great physician-scientists, that seems to be the one thing that they all have in common. They may have many things in common, but this one is important, which is it’s the ability to sort of pause in your tracks and say, wait a minute, there is a clinical situation and I cannot for the life of me explain it and I have to know the answer. It’s so amazing that one chance encounter like that basically altered the entire course of your career and put you on this path to do some really amazing stuff as we’ll I think discuss in the next hour or so.

Rudy Leibel: I think you’re probably right that one of the great privileges about medical education is that it does give you a very broad perspective on the human condition, if you want to call it that. All the way from psychological issues to very fundamental biological ones and physicians as a group do have this as you pointed out, rather unique opportunity to look at a problem that afflicts human beings sometimes at the level of basic metabolism and endocrinology, other times more to more systemic or even social level. And I’m sure we could name some of the names of people who have operated all these levels. But I think you’re right, I’ve always felt that it was really somehow an enormous opportunity and a gift to be able to pursue this down to the level that I’ve been able to do in the past 30 years or so.

Rudy Leibel: And I must say in addition to whatever my  previous training and experience did to make that possible, I also have to acknowledge that my family was very supportive in terms of allowing me to basically back out of a more classical sort of academic medical track and retrain myself to the level that I thought was required in order to do this research. So we basically moved from a very nice home in Brookline, Massachusetts to an 800 square foot apartment in Manhattan with my wife and two small children and lived there for 15 or 16 years while I sort of got my act together.

Peter Attia: There’s plenty of great research that can happen at Harvard. Why did you come to New York?

Rudy Leibel: I came to New York actually after looking around in the Boston area for someone who could mentor me in this kind of activity and it turned out there were, I mean there’s some interesting stories about that, but  the advice that I got from the people who were not in a position to help me in the way that I thought I needed help was that I might consider going to the Rockefeller and working with a physician-scientist named [Jules Hirsch](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(15)00112-9/fulltext), who at the time was very interested in the biology of adipose tissue from a number of perspectives.

Rudy Leibel: And I had actually communicated with Dr. Hirsch in the literature by commenting on some of the work that he had done with regard to adipocytes and signals that might come from adipocytes that affect potentially food intake and body weight. This was an area that he was quite interested in and I was too based on some of the thinking I had done about it while I was in the training in Boston. And he and I actually had had a communication in the literature on some of the work that he had done. And I went actually to visit his laboratory and while I was in New York for an entirely different reason and it was very shortly after that I moved.

Peter Attia: Which is another great example of the types of common threads we see in great scientists, whether they be scientists or physician-scientists, which has mentorship, right? Again, every person I talked to who’s done something remarkable in science can point to mentors, a mentor or mentors, and obviously, for you, Jules was probably the most important mentor, I’m guessing.

Rudy Leibel: That’s right. I had very important other mentors in the area of clinical medicine and  the one who trained me in endocrinology an individual, again, a physician-scientist more clinically oriented named [Jack Crawford](https://news.harvard.edu/gazette/story/2006/05/john-douglas-crawford-ii/) himself was very interested in the role of body fat and it’s interaction with other physiological systems in the body, most notably the onset of puberty. And it was he that actually put me in contact with another scientist at Harvard named [Rose Frisch](https://en.wikipedia.org/wiki/Rose_Frisch), who also was very interested in  why, for example, young women who lost weight as a result of Anorexia or more commonly in her experience due to very vigorous physical training for things like distance running or bicycling, swimming became [amenorrhoeic](https://www.dictionary.com/browse/amenorrhoeic).

Rudy Leibel: In other words, their period stopped and Rose was very curious about why this was and whether there was a communication between fat and parts of the brain that regulate the [gonadal access](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93gonadal_axis), which is the hypothalamus again. And I remember having many conversations with Rose about where the signal might be coming from. She thought it actually might be coming from adipose tissue, adipose sites in the bone marrow, and was always encouraging me to study bone marrow as a source of whatever this signal might be.

Peter Attia: So what year did you arrive at Rockefeller?

Rudy Leibel: 1978.

Peter Attia: At that point in time, was the adipose tissue, was an adipose cell, was this regarded as an inert sort of storage depot for fatty acid or was it considered an endocrine organ? What was the state of thinking about fat?

Rudy Leibel: At that time the view of the role of adipose tissue was very strongly in the direction of this sort of former characterization that you made, which is that it was a passive depot for fat in the form  of storing free fatty acids as triglycerides so that they were hydrophobic so that you could pack a lot of calories into an organ or into a cell without having a lot of water there. So it’s very efficient way of storing energy. Actually, as you know, up to probably around nine calories per gram and its role as a signaling device or an endocrine organ was really people were thinking  about it, but there was no firm evidence in this regard other than I think the increasing sense that the size of the adipose mass was doing something to the levels of circulating insulin. That somehow insulin rises when the fat mass rises and the mechanism or the relationship with-

Peter Attia: Not the other way around? Was it clear which direction?

Rudy Leibel: So at the time, I think the view was pretty much that as fat mass increases, the concentration of insulin rises to meet the consequences of so-called insulin resistance, which occurred not only in adipose tissue, but maybe more importantly in liver and muscle. And so that there was some relationship between fat mass and this endocrine, but fat mass as a secretory organ itself of molecules that might have some of these effects, was really a pretty new idea that nobody really had any direct, at least at the time, evidence for.

## Finding the first evidence of leptin by studying obese mice [23:30]

Peter Attia: Obviously we’re going to get to the story of [leptin](https://en.wikipedia.org/wiki/Leptin), which I think is just another great example of incredible persistence and incredible focus and drive. But obviously before getting to the punchline which occurred several decades later, what was your first insight into a hormone that would go on to be leptin? Where did you first figure that there was something that was being secreted by fat cells?

Rudy Leibel: I think the first evidence in this regard, or at least some of the most important evidence, came from experiments that were done by an investigator at the [Jackson Laboratories](https://en.wikipedia.org/wiki/Jackson_Laboratory) in Maine named [Douglas Coleman](https://www.jax.org/give-to-jax/make-a-gift/helix-fund/signature-societies/douglas-coleman-society/douglas-coleman-bio#). And Coleman was a biochemist physiologist who was interested in some of the rare mouse mutations that lead to very severe obesity and he was one of the first to study the [ob/ob or obese mouse](https://en.wikipedia.org/wiki/Ob/ob_mouse), which was a spontaneous mutation that arose in the Jackson colony and he also was one of the close students of another mutation that arose there a number of years later in the so-called diabetes or db gene.

![](https://peterattiamd.com/wp-content/uploads/2018/12/Fatmouse-ob-ob-mouse.jpg)

**Figure 1. Comparison of an** ***ob/ob*** **mouse (left) and a normal mouse (right).** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Ob/ob_mouse)

**Coleman and ob/ob and db/db mice**: [Douglas L. Coleman, 1931–2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4218972/) (Coleman, 2014) [28:00]

**Coleman and ob/ob and db/db mice**: [Diabetes, a new mutation in the mouse](https://www.ncbi.nlm.nih.gov/pubmed/5918576?dopt=Abstract) (Hummel et al., 1966) [28:00]

Peter Attia: So what was the phenotype of this ob/ob mouse?

Rudy Leibel: The ob/ob mouse was-

Peter Attia: That’s not to be confused with the [Obi-Wan Kenobi](https://en.wikipedia.org/wiki/Obi-Wan_Kenobi) mouse. That’s a very different phenotype.

Rudy Leibel: That’s correct. Yeah. The ob/ob mouse was noted to be very severely obese, very early in life. So these animals were clearly obese by the time shortly after weaning, which is three or four weeks of age.  You could tell that they were obese and if you left them alone and let them eat as much as they wanted, they would eat up to the point of becoming pretty heroically obese, meaning these animals could reach weights of 70 or 80 grams. Whereas a normal so-called wild-type mouse at maximum weight would be somewhere around 40 or 50 grams. Much later in life an ob mouse could get up to 60 or 70 grams very early in life. The animals were infertile.

Peter Attia: So how did they keep breeding them?

Rudy Leibel: So the way they would breed these animals is breed the parents, the heterozygous animals that were able to generate-

Peter Attia: So get two heteros to make homos.

Rudy Leibel: Correct.

Peter Attia: So the phenotype centered around [hyperphagia](https://www.merriam-webster.com/dictionary/hyperphagia)?

Rudy Leibel: It centered around two phenotypes actually that Dr. Coleman was able to show. Primarily the obesity was due to hyperphagia, but he also was able to demonstrate by a mechanism-

Peter Attia: Sorry, I should just clarify for listeners, that means excess of appetite.

Rudy Leibel: Yes, by excess food intake. That was the primary cause of their obesity. But he also, by using a technique called peer feeding where he would only feed the animal the amount that a normal weight animal would eat. That those animals tended to store more of their excess calories as fat. We sometimes refer to this as partitioning. And by another set of experimental maneuvers was able to show that their metabolic rate was slower. So these animals had what you might call a trifecta for obesity. They ate more, spent less, and whatever they stored was preferentially stored as fat. And these are fascinating animals. I mean people tried for many years to figure out what was wrong with them and they had many metabolic consequences of their obesity, but nothing about their physiology necessarily pointed to what the primary mechanism was where the genetics clearly indicated that this was a single gene or very likely to be a single-

Peter Attia: And this of course, is long before you’ve got your [PCR technology](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) that can very easily help you sequence this. So two questions though, lifespan was what?

Rudy Leibel: Lifespan was not severely affected actually. They could live to a fairly normal lifespan, somewhat shortened.

Peter Attia: Two and a half, three years?

Rudy Leibel: Not quite, they don’t last quite that long,  but certainly up to 18 months or two years. Important to note because of the question of whether fat makes something or not. Coleman not only observed these ob mice, but also the second mutation that arose later at the Jackson lab and was named the diabetes mouse. That’s because that animal looked a lot like an ob mouse, but got diabetes very early in life. Unlike the ob mouse, which seemed to be obese but not necessarily particularly diabetes prone. And it was clear that the mutation in the gene, again, another single gene that caused the diabetes mouse was not the ob gene, it was on a different chromosome.

Rudy Leibel: Coleman was able to show that. So here you had animals that looked a great deal like each other, at least in terms of the overeating and the low energy expenditure. One was prone to get diabetes and the other not. And what Coleman ultimately did was to join the circulation of the ob mouse to a wild-type animal and the DB or diabetes mouse to a wild-type animal, usually-

Peter Attia: So like a live [parabiosis](https://en.wikipedia.org/wiki/Parabiosis).

Rudy Leibel: That’s the technical term for it, is a parabiosis. And he showed that if you hooked an ob mouse up to a wild-type mouse in this way, that the ob mouse would correct its hyperphagia,  it’s excess food intake and actually begin to lose weight.

**Parabiosis experiment, on genetically obese Zucker rats**: [Body composition of lean and obese Zucker rats in parabiosis](https://augusta.pure.elsevier.com/en/publications/body-composition-of-lean-and-obese-zucker-rats-in-parabiosis) (Harris et al., 1987) [44:45]

**Zucker rats produced a factor that inhibited appetite but could not themselves respond to it**: [Is leptin the parabiotic “satiety” factor? Past and present interpretations](https://www.ncbi.nlm.nih.gov/pubmed/22889986) (Harris, 2013) [44:45]

Peter Attia: So something presumably in the wild-type mouse, some humoral factors, some hormones, something must have been missing in the ob/ob mouse that when given to it corrected its phenotype.

Rudy Leibel: Correct.

Peter Attia: And then what happened when you did the parabiosis with the db mouse?

Rudy Leibel: With the db mouse, you got the opposite situation where the wild-type animal began to lose weight and actually stopped eating and would die of starvation basically. Whereas the db mouse just went merrily on its way eating and remaining obese. So, Coleman thought based on these two experiments that maybe the ob mouse was missing something that the wild-type mouse produced and the db mouse that looked an awful lot like an ob mouse was missing the ability to respond to whatever that molecule or molecules were, that were required to regulate body weight. And this was around the time that it was becoming clear that hormones had receptors that were specific to those. Hormones like thyroid, insulin, growth hormone. **So, Coleman hypothesized that the ob mouse was missing what we refer to as the** [**ligand**](https://en.wikipedia.org/wiki/Ligand)**, the circulating hormone, and the db mouse was missing the receptor for it. And it turns out that Dr. Coleman was right.**

Peter Attia: Everything you’ve just said was known by what point in time?

Rudy Leibel: I would say by the late 1970s.

Peter Attia: Okay, so just as you’re coming on the scene, the whippersnapper who doesn’t know shit.

Rudy Leibel: Yes.

Peter Attia: The guy up in Jackson up in Maine knows this, and you can’t wait to get all over this.

Rudy Leibel: Correct. So I began by actually studying adipose tissue to see whether there was something that might be regulated by adipose tissue that would fit in this sort of general category of something that might produce a signal or might be related to the anatomy of the adipose tissue. At the time, Jules Hirsch was particularly interested in the fact that it appeared that what happens when people get obese is that their fat cells expand up to a sort of maximum size and then new fat cells begin to appear. Whether they were made de novo, or had been resting  in the area of the other adipocytes wasn’t clear at the time, but what happens as people get more and more obese is that more and more fat cells are recruited so that if you look at a very obese individual, they have what is referred to in the literature as [hyperplastic](https://en.wikipedia.org/wiki/Hyperplasia) adipose tissue. They have more fat cells and Jules had actually figured out a way to count the fat cells of a human being and you can look under a microscope and see how big the fat cells are. So, he was very interested in what it is that permits a big fat cell to call up, if you will, the other fat cells that are going to be needed once it reaches a critical size and whether these fat cells were generating something that might act like a signal.

Peter Attia: Are there any [organelles](https://en.wikipedia.org/wiki/Organelle) inside a fat cell?

Rudy Leibel: Oh yeah. A fat cell has the complete repertoire of organelles that any other cell does.

Peter Attia: It’s got a “regular” nucleus. It’s got mitochondria.

Rudy Leibel: Yeah. It’s got the whole-

Peter Attia: It’s just its [cytoplasm](https://en.wikipedia.org/wiki/Cytoplasm) is dominated by these [lipid droplets](https://en.wikipedia.org/wiki/Lipid_droplet).

Rudy Leibel: It’s designed to be able to hold these huge lipid droplets, but otherwise is a perfectly respectable cell. Has all the other components. And what Jules had been doing along with another investigator in the lab, guy named [Irv Faust](https://www.ncbi.nlm.nih.gov/pubmed/?term=Faust+IM%5BAuthor%5D), was extirpating adipose tissue from rats. They were working primarily with rats, although there were some other mice around. I’d actually seen those when I was at Harvard and Boston. Endocrinologists who trained me, talked to me about them, but Jules and Irv we’re extirpating adipose tissue depots from rats and looking to see what happened and one of the things that they were struck by is that when they took a fat pad out, if they waited long enough and just let the animal eat whatever wanted to eat, it would eat its way back up to restoring that fat pad.

Peter Attia: Through de novo creation of more fat cells. Or by?

Rudy Leibel: You leave the capsule of the depot there and it is able to generate new fat cells and they fill up and they don’t fill up to three times the size that they were before, they go right back to the appropriate size for that depo. And one of the things that Jules and Irv were very interested in is how does the animal know that it should eat a little bit more to be able to generate the fat that’s been extirpated?

Peter Attia: And did this experiment only work when you started with obese rats or did it work if you took a lean rat as well?

Rudy Leibel: It worked with lean rats just as well. As a matter of fact, most of the work they did was with lean rats or not genetically obese.

## Zucker rats, and the push/pull theories of obesity [34:45]

![](https://peterattiamd.com/wp-content/uploads/2018/12/Rat_diabetic-zucker.jpg)

**Figure 2. A Zucker rat, bred for obesity.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Laboratory_rat#Zucker_rat)

Peter Attia: Now, speaking of rats, you explained to us what the ob/ob and the db/db, db/ob, but about the [Zucker rat](https://en.wikipedia.org/wiki/Laboratory_rat#Zucker_rat) which preceded a lot of this stuff but had some interesting and similar features. Right?

Rudy Leibel: Right. So the Zucker rat was discovered or identified, if you will, by a woman named Lois Zucker, the rat’s named after her and her husband, and it had characteristics very similar to these mice that we were talking about. The ob and the db mice. They were hyperphagic. They appeared to have a little bit lower energy expenditure and would become hugely obese. I mean, these animals got up to heroic size.

Peter Attia: We’re going to include some pictures of the Zucker mice in this, in the notes.

Rudy Leibel: The Zucker rats.

Peter Attia: That’s right, sorry. The Zucker rats in this show.

Rudy Leibel: They got very obese and many, many studies were done of the Zucker rat trying to, again understand what the mechanism behind its obesity was. Again, it appeared to be due to a single gene. In other words like the ob or db mouse, there was a single mutant gene. When the animal had two copies  of the abnormal or low activity gene, the animals will become very obese and one of the reigning hypotheses about the Zucker rat, again at around the late 70s, early 80s, was that the fat itself was making too much of an enzyme called [lipoprotein lipase](https://en.wikipedia.org/wiki/Lipoprotein_lipase) and this is an enzyme which is produced by adipose tissue, by adipocytes, which breaks  down circulating triglycerides and allows the free fatty acids that are released to be taken up by the adipocytes and the glycerol backbone, so to speak, remains in the circulation.

Rudy Leibel: So the idea was that the Zucker rat for some reason had hyperactive lipoprotein lipase and the adipose tissue was acting like a vacuum cleaner. In a sense, it was sucking up the circulating fat, the triglyceride and storing it, and that’s how the animals got obese. And in association with that observation was the idea that may be the process of sucking up substrate from the circulation does something to drive or increase food intake. So, this model was often referred to as a pull model for the development of obesity. That is that the adipose tissue was actually acting as a pulling mechanism for substrate, which was in turn affecting food intake, so the animal got fat that way.

**Pull model of fuel partitioning and obesity**: [Obesity Pathogenesis: An Endocrine Society Scientific Statement](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5546881/) (Schwartz et al., 2017) [37:15]

Peter Attia: The animal was effectively starving even though it stored an unbelievable amount of energy. It was disproportionately taking those circulating metabolic fuels and putting them into storage so that if you buy this idea that something is sensing energy availability that would naturally drive the hyperphagia. Right?

Rudy Leibel: Correct. And the other model, the one more consistent say with the ob or the db mouse was the so-called push model, which is that fat cells were being filled up because the brain itself had was pushing the substrate. So, this was this was these push-pull models were very much discussed in terms of what they said about where the primary mechanisms might be for the control of body weight. Was it they adipose tissue that was basically begging for more fuel and sucking it in and causing the animal to eat that way? Or was there something going on primarily in the brain that was influencing the food intake and the adipose tissue was being packed from the outside.

Peter Attia: And like all good problems in medicine, there’s examples of both that are quite elegant, right? I mean that’s sort of the challenge of this is when you look at this in experimental models, you could find very elegant examples of each. Correct?

Rudy Leibel: You could find elegant examples that pointed in the direction of both of these. It was interesting. I mean it was the whole issue of lipoprotein lipase, suggested that again, this model, the Zucker rat that was used to support this idea that the LPL was, as it was referred to, was critical in this regard, but it was known that individuals who had total lipoprotein lipase deficiency and there are such individuals on a genetic basis, had very, very high levels  of circulating triglyceride. I mean, these can be life-threatening in terms of the levels that are reached, but they had perfectly normal adipose tissue. So this suggested that maybe LPL wasn’t critical or an absolute-

Peter Attia: Meaning you would expect those patients to have sky high triglycerides and be emaciated.

Rudy Leibel: Yes, and they weren’t, and they aren’t. So, this was already sort of question about the lipoprotein lipase.

Peter Attia: And we know that those patients were completely deficient in LPL?

Rudy Leibel: Yes.

Peter Attia: Does that mean they had no LPL on their muscle cells as well?

Rudy Leibel: So, the individuals who are totally deficient in LPL have no LPL on any cell type.

Peter Attia: It’s hard to imagine how they functioned. Does that mean they’re completely dependent on glycolysis?

Rudy Leibel: They are able to take up the fatty acids. They don’t need the LPL to break down the triglyceride. They do fine. I mean in terms of being able to … There’s nothing wrong with their manipulation or movement of fatty acid and that’s probably why they have normal adipose tissue and normal muscle. So it’s interesting, the history of this and just to mention this, we now know what the Zucker mutation is and one of the earliest experiments I did at Rockefeller or one of the relatively early experiments is, we tried to map the position of the Zucker obesity gene in the same way that we were already trying to map  where and ultimately clone the ob and db gene for pretty obvious reasons at this point that we wanted to figure out what the signal and whether there was a receptor for this. And as part of this work, a student who worked with me named [Gary Truett](https://www.semanticscholar.org/author/Gary-E.-Truett/4224728) made a map of the position of the Zucker gene, which we did by crossing the Zucker rats with another strain of rats so that we could make what’s referred to as a genetic map.

Peter Attia: And tell me how that works. Because everything I’ve ever done with genes came after we had the luxury of real-time PCR. My generation had it so easy. You guys, when I hear stories about people doing positional gene stuff 40, 50 years ago, I’m like, wow, that’s incredible. So, tell me a little technically like what were you actually doing to positionally isolate that?

Rudy Leibel: So, the way these experiments are done, it’s pretty much the same principle  is that you take, in the case of rats or mice, which you have this luxury, you can cross one strain of mouse or rat to another strain of mouse or rat, and then look for signposts of genetic variation along the entire genome of the animal. And each strain has different [sequences of DNA](https://en.wikipedia.org/wiki/DNA_sequencing). The major differences are in the so-called [noncoding region](https://en.wikipedia.org/wiki/Non-coding_DNA). Some of the differences are in coding regions  and back then we used a technique called [southern blotting](https://en.wikipedia.org/wiki/Southern_blot) to look for basically putting down signposts on the DNA of an animal to figure out where the differences between the strains resided and by monitoring the obesity of the animal and knowing which strain was actually carrying the gene that we didn’t know what it was, but we know what strain it came from. In this case,  the Zucker strain. We could actually mark the DNA of these animals that had been interbred and figure out where the Zucker chromosome, the Zucker genetic markers were segregating is the formal term for this along with the level of obesity of the animal, so we would look for correlation of region which has the Zucker genetic variation with the obesity  of the animals because if you do these crosses in the way that I describe-

Peter Attia: You’re going to get a spectrum.

Rudy Leibel: You’re going to get some obese, you’re going to get some non-obese animals and then by relating where the sequences are corresponding to the strain from which you know the obesity gene must’ve come. You can actually narrow the region of the genome down to the area that must contain the gene. I mean-

Peter Attia: And this was a qualitative assessment, not so much a quantitative assessment. Right?

Rudy Leibel: So, the quantitative assessment is, is the animal obese or not obese? You absolutely have to get this right because the obese animal has in this particular model, two copies of the mutant gene that’s producing the obesity and if it’s not obese it either has one or zero copies and you need to be absolutely clear what the phenotype is, so to speak, of the animal is, and then if you put these markers down, these signposts down,  you can define an interval in which that gene must reside. So, it’s actually, in a sense it’s quantitative at the level of the-

Peter Attia: So the best you could do is say this is on, you know, 17p or 17q. That’s the level of resolution you can get out of this?

Rudy Leibel: Yes.

Peter Attia: What happened when they did a parabiosis with the Zucker rat? Did anyone do that?

**Parabiosis experiment, on genetically obese Zucker rats**: [Body composition of lean and obese Zucker rats in parabiosis](https://augusta.pure.elsevier.com/en/publications/body-composition-of-lean-and-obese-zucker-rats-in-parabiosis) (Harris et al., 1987) [44:45]

**Zucker rats produced a factor that inhibited appetite but could not themselves respond to it**: [Is leptin the parabiotic “satiety” factor? Past and present interpretations](https://www.ncbi.nlm.nih.gov/pubmed/22889986) (Harris, 2013) [44:45]

**Zucker rats have a single gene mutation of the extracellular domain of the leptin receptor**: [Rat obesity gene fatty (fa) maps to chromosome 5: evidence for homology with the mouse gene diabetes (db)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC52392/) (Truett et al., 1991) [44:45]

**Mutations in the leptin receptor**: [Phenotypes of mouse diabetes and rat fatty due to mutations in the OB (leptin) receptor](https://www.ncbi.nlm.nih.gov/pubmed/8584938) (Chua et al,., 1996) [44:45]

Rudy Leibel: There have been parabiosis experiments done with rats, but they’ve generally done these in a slightly different way from the way you asked the question, and those studies have again supported the idea that the Zucker rat may be overproducing like the db mouse, the product which is suppressive of food intake. And as a matter of fact, when we were trying to clone these genes, I actually took blood out of Zucker rats and  injected it into db mice to see whether or not I could slow down their food intake because at one time we were worried that we might not be able to get the gene by mapping and would have to try to isolate the product out of the blood of an animal. But the Zucker rat studies supported the idea that the same as the mice.

## A breakthrough in obesity research, and closing in on leptin [45:45]

Peter Attia: So, we’ll fast forward now into the late 70s, early 80s. You’re working mostly now in the lab. Your clinical responsibilities have shrunk significantly, right?

Rudy Leibel: So, at the time I was doing these experiments, I had some experiments still going on, no clinical practice at all, but I was studying humans in the clinical research center at Rockefeller, looking at the effects of weight loss and weight gain on energy metabolism in these individuals. Again, beginning to try to understand what it is that’s regulating body weight in a human. The idea being that in you, if you reduce the body weight of a human down by 10 or 20 percent, what happens to them metabolically that might be consistent with some of these things that had been seen in mice that would suggest that again, in humans, there’s regulatory pathways that are there in order to regulate the amount of stored energy.

Rudy Leibel: So, my time was basically split between doing these studies of humans who were in the clinical research center for long periods of time when we would study the metabolic consequences of perturbing their body weight. The other was spent trying to identify these genes to try to clone the genes.

**Review including weight perturbation studies**: [Molecular physiology of weight regulation in mice and humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2682360/) (Leibel, 2009) [47:00]

Peter Attia: So how did that progress through the 80s as you were working to try to identify specifically the ob/ob gene and again, the reason you were pretty confident that it was a single gene was just based on the breeding pattern?

Rudy Leibel: Yes. The breeding pattern clearly indicated that this was a single.

Peter Attia: It was sort of [Mendelian](https://en.wikipedia.org/wiki/Mendelian_inheritance).

Rudy Leibel: Yes, absolutely Mendelian. So-called autosomal recessive Mendelian, as is the db mouse and the Zucker rat. So, what we did is what I basically described for the rats.

Peter Attia: Why was it harder for the mice?

Rudy Leibel: To clone the gene?

Peter Attia: Yes.

Rudy Leibel: It was not harder.

Peter Attia: Oh, it was not?

Rudy Leibel: No, I think it was equally difficult. What I was describing is when we didn’t actually sort of finish that part of the compensation,  we did make a map of where the Zucker gene was located in the rat, but we didn’t clone the gene out of the rat at that time. And what that experiment showed that was interesting, apropos this lipoprotein lipase hypothesis, is that the Zucker gene was in a part of the rat genome entirely separate from where the LPL gene was located. So, from that experiment alone, we knew that it couldn’t be LPL as the causal mechanism of the Zucker rat. We didn’t know what it was, but we could clearly identify what it wasn’t because if the gene is not in the location that is segregating with the phenotype, it’s not the gene. This was hard for people I think to understand, or at least to accept at the time. There were still, I think was not full appreciation of what an experiment like that represents, which is basically an unequivocal falsifying experiment.

Rudy Leibel: That is if it isn’t in the place where the gene must be, then it can’t be the gene. I mean, it’s a syllogism.

Peter Attia: Yeah, and you don’t get a lot of those in science.

Rudy Leibel: No, you don’t.

Peter Attia: Especially in biology.

Rudy Leibel: Right. And so this early on, this was one of the proofs that at least we knew one gene that it wasn’t. And then to sort of back then to your question, we used a very similar strategy, an identical strategy with the mice. We crossed the mice, two strains that were different from the strain on which the mutation existed, and by doing that we’re able to make maps of the region where the gene was located and I was actually known for other reasons. Coleman had figured it out. He knew which chromosome these genes were on, so we at least had that as a sort of initial guide, but what the gene was or how it worked was obviously entirely unknown.

Peter Attia: What was Coleman’s training?

Rudy Leibel: Coleman was trained as a biochemist at the University of Wisconsin, I think, and we actually consulted with Dr. Coleman. Doug, very early on, matter of fact, very early on in the process about which strains of mice might be appropriate as so-called counter strains, that is mice that would be used to enable these maps to be made and he was extremely helpful. He used to come down and we would talk to him, go visit him at Jackson at least one occasion, met with him in Philadelphia.

Peter Attia: So, he loved the collaboration.

Rudy Leibel: He was very encouraging of that. He always said, you know, that he wasn’t sort of *au courant* with regard to the tools of so-called molecular genetics, but in fact I and [Jeff Friedman](https://www.rockefeller.edu/our-scientists/heads-of-laboratories/1163-jeffrey-m-friedman/), who was the other sort  of PI on this project, neither of us was an expert in molecular genetics, so we sort of had to train ourselves to do this as did the students who worked with us on this project.

Peter Attia: So when did Jeff enter the lab?

Rudy Leibel: I got to know Jeff because he rotated as a resident actually at New York hospital through Jules lab to work with another investigator there, so I got to know him when he rotated through, but he and  I started this project after he entered the Ph.D. program. He was a physician and then went on to get a Ph.D. at Rockefeller in a different laboratory, but he and I started the project to clone these genes together.

Peter Attia: About what year was that?

Rudy Leibel: 1985 or 1986, I guess. 86 probably.

Peter Attia: What were the major steps that took place starting around the mid-eighties that were kind of like the essential. I mean, I think one of the things that’s just hard for people, I think, to understand is how much you have to fail in science. I mean, it sounds simple, right? We want to clone a gene and yet in that era, that was very hard to do.

Rudy Leibel: Right. There were efforts underway at around the same time to clone the gene for [Huntington’s disease](https://en.wikipedia.org/wiki/Huntington%27s_disease) and [cystic fibrosis](https://en.wikipedia.org/wiki/Cystic_fibrosis), [muscular dystrophy](https://en.wikipedia.org/wiki/Muscular_dystrophy), to name a few.

Peter Attia: Other single gene-

Rudy Leibel: Other single gene disorders,  and for a number of reasons. Genes that are on sex chromosomes may be a little bit easier to handle in this regard, but the same tools were being used, the so-called southern blotting, putting down markers across the genome, using this rather tedious technique of having to put the DNA down on a blot of some kind and then exposing it with radioactively tagged reagents to be able to find these individual markers.  This was a tedious process. One thing that helped with the mice is that there existed a chromosome in mice, so these are called [Robertsonian chromosomes](https://en.wikipedia.org/wiki/Robertsonian_translocation) in which you have two chromosomes joined to each other and there was a so-called Robertsonian chromosome that had both chromosome four and chromosome six of the mouse attached to each other.

Rudy Leibel: We knew based on Doug Coleman’s work that the ob gene was on chromosome six and the db gene was on chromosome  four and one of the students who came to work on this project, very early, young man named [Nate Bahary](https://hillman.upmc.com/find/providers/nathan-bahary-15020), who came over from New York hospital as a medical student and spent time on this project and then went on to get a Ph.D. working on it. He took glass needles, if you can believe this, and dissected out under a microscope the rough regions of the chromosome six and four that we knew must have  the gene in them and made from those needle dissected chromosome fragments, other markers that we could put down on the DNA from these mice that we had intercrossed to make a finer and finer map of the region in which the gene must reside. And otherwise, this was identical to the Zucker strategy in which we very carefully looked at, see whether a mouse was obese or not.  And again, these Mendelizing phenotypes. But we had to be absolutely sure what the phenotype of the mouse was. And then we could use the DNA from the obese animal to make a finer and finer map around the region where the gene must reside.

Peter Attia: I don’t even understand how that would work. What resolution of a microscope would you need to be tweaking chromosomes?

Rudy Leibel: Chromosomes aren’t that small. I mean you can see a chromosome quite easily with a high powered microscope.

Peter Attia: Just a light.

Rudy Leibel: Yeah.  Light microscope. But having the steady hands and the patience to be able to do this was quite an achievement. I would say was sine qua non, without which this project wouldn’t have been done at the time. We didn’t have the tools. Some of the ones that you already mentioned available. So, we had to try to identify additional signposts, if you will, in the region of the two genes that we were primarily interested in. That is the ob and the db gene.

Peter Attia: At the time you’re basically thinking, look, we’re looking for a gene for a hormone. We’re probably looking for a gene for a receptor. So a ligand receptor. Did you have an expectation that those would be on the same chromosome or would that be completely unnecessary?

Rudy Leibel: No, we knew that they absolutely weren’t.

Peter Attia: No, no. I knew you knew that they weren’t, but would you expect that, for example, like in thyroid is [T4](https://en.wikipedia.org/wiki/Thyroid_hormones) and [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone) or T4 and TR, the [thyroid receptor](https://en.wikipedia.org/wiki/Thyroid_hormone_receptor) or TSH and TSR, are they necessarily-

Rudy Leibel: No.

Peter Attia: No? There’s no relationship.

Rudy Leibel: No. So, the function doesn’t require that the genes be in proximity to each other and if they are, it’s almost always just a coincidence.

Peter Attia: Got it. So, what was the kind of critical breakthrough that led to the cloning of this gene?

Rudy Leibel: So what was done basically was to make the map as fine as we could using the reagents that I mentioned to you, and some others that we were able to  get hold of and using computer programs to put these data together in such a way as to be able to generate as fine a map of the region around this gene is we could, and then what was done was to go into the region that must contain the gene, and begin to look for expressed, meaning that the DNA was transcribed, transcripts that were being read off of this  part of the DNA and by taking the transcripts that came off and putting them against various organs from the ob or the db mouse would look for transcripts that were specifically altered in the animals that were mutant for the gene, so you would expect, you might ordinarily expect maybe the level of the gene that we were looking for would be very low in the organ that was affected.

Rudy Leibel: Again, even though we know now it was adipose tissue and there was certainly reasons to think that might be where the ob gene was. When we did these experiments, we actually looked at every organ in the animal. Brain, thyroid, muscle, adipose tissue, anything we could get our hands on. We actually dissected out almost everything out of a mouse to look to see where the deficiency, or the excess might be. Sometimes genes  transcripts are overexpressed, although they’re not functionally competent and actually at a visit to the Jackson labs, when Doug Coleman was a retiring, one of the investigators there asked me if I would like to have, or we would like to have, mice that appeared to have the OB mutation but a different mouse. So, the original mutation occurred in the mouse that was identified at Jackson, the early 1950s, this was a new mutation that had arisen and almost certainly wouldn’t be identical to the one that had arisen earlier.

Peter Attia: But was similar in phenotypes?

Rudy Leibel: Absolutely identical in phenotypes. So, I got those mice and we took them to Rockefeller.

Peter Attia: What did you call them?

Rudy Leibel: 2Js. So, the ob, the first mutation we referred to as 1J, that’s just the nomenclature, and the second one was ob 2J, and we took the ob, the organs out of the 1Js,  and the 2Js, and ran these transcripts against them using the technique called [northern blotting](https://en.wikipedia.org/wiki/Northern_blot) at the time.

Peter Attia: Not to be confused with [Western blot](https://en.wikipedia.org/wiki/Western_blot).

Rudy Leibel: Not to be confused with Western blotting. So, northern blotting is looking actually at RNA. It turned out that the 2J was extremely valuable animal because those animals didn’t express any of what turned out to be the Leptin transcript, whereas the 1Js actually overexpressed it, but it was functionally inadequate, functionally inactive, but the transcript was increased again, for reasons having to do with molecular biology of how these systems work, but when we saw that there was one animal that had a very low level and the other very high. This was a smoking gun, so to speak. This was the evidence that that piece of the genome was actually a part of the ob gene.

Peter Attia: So, ultimately where did this ligand, where did it show up?

Rudy Leibel: The ob gene showed up almost solely, virtually solely in adipose tissue. Fully consistent with the idea that adipose tissue was producing something that was picked up in Doug’s parabiosis experiments.

Peter Attia: Which chromosome?

Rudy Leibel: Chromosome six of the mouse, it’s chromosome seven of the human. We actually knew that because we could put the orthologs of the mouse genes down on human DNA and so, just like we did with the Zucker rate, we actually knew where the gene was in humans.

Peter Attia: Do mice have 23 pairs of chromosomes?

Rudy Leibel: They have, yes, 23.

Peter Attia: 23, including the sex?

Rudy Leibel: Yeah.

Peter Attia: So what name was given to this?

Rudy Leibel: It’s referred to as the ob gene or the name that was given to the protein is leptin, which was, the name was chosen because that suggested that whatever this was, it had an effect to lighten the body weight of an animal.

Peter Attia: So, now you have it that fat cell secretes leptin, and the ob mouse can’t make leptin, correct?

Rudy Leibel: Correct.

Peter Attia: And the db mouse makes all the leptin in the world.

Rudy Leibel: This wasn’t known at the time because the first gene to be cloned was the ob gene and the fact that the db gene was the receptor, was actually learned in two ways. One, by taking the ob protein and putting it down on what’s called an expression library from part of the brain, the [choroid plexus](https://en.wikipedia.org/wiki/Choroid_plexus).

Peter Attia: Wait, sorry, to interrupt one thing, I apologize. Did they ever do parabiosis between the ob and the db?

Rudy Leibel: Yes. That was done as well.

Peter Attia: Okay. ‘Cause that would, that should fix the ob.

Rudy Leibel: It did.

Peter Attia: But not the db.

Rudy Leibel: Correct.

Peter Attia: Okay. Which is another great and elegant example that one of them had the ligand deficiency, the other had the receptor deficiency.

Rudy Leibel: Mm-hmm (affirmative).

Peter Attia: God, Mendelian genetics are freaking awesome, when they work.

Rudy Leibel: Yeah, so that was one of the reasons for using these animals is that you could use the genetics to really help to narrow down the region where these genes had to be located. If it were a polygenic disturbance, it’s a whole different order of business. Basically, the db gene was, or the protein that was nominated  to be the db gene, was pulled out of a library of, what’s called an expression library of choroid plexus by using the ob protein as a probe to see what it stuck to and that gene that was pulled out of the choroid plexus in that way, we then took and mapped into the db crosses that we had and showed that that nominated gene mapped  right in the right place for the db gene.

Peter Attia: Which was on chromosome four in the mouse?

Rudy Leibel: Right, correct. And it also turned out that that gene, the db gene, leptin receptor, is the mutant in the Zucker rat. Which we showed by cloning the gene then out of the Zucker rat, knowing where it was.

Peter Attia: So this was hailed as one of the most important insights and breakthroughs in all of obesity research. This was what, 199-

Rudy Leibel: 4.

Peter Attia: 1994

Rudy Leibel: Mm-hmm (affirmative). And then the db gene a year or two later.

**Rudy’s experiment that showed the db gene to be the mutant in the Zucker rat**: [Phenotype of the obese Koletsky (f) rat due to Tyr763Stop mutation in the extracellular domain of the leptin receptor (Lepr): evidence for deficient plasma-to-CSF transport of leptin in both the Zucker and Koletsky obese rat.](https://www.ncbi.nlm.nih.gov/pubmed/9032111) (Wu-Peng et al., 1997) [1:03:00]

## Understanding leptin in humans [1:03:30]

Peter Attia: What was your expectation at the time? What type of hope did you hold out for the discovery of the gene but perhaps more importantly, the protein that it coded for?

Rudy Leibel: There were different schools of thought with regard to what this protein actually did. I think one view was that if you saw this as a protein that suppresses food intake, which it definitely does in an ob mouse, if you give it to an ob mouse, you can basically, quote, cure the animal. And if you give it in very high doses to a mouse, it will suppress its food intake. So one view was that this was a weight suppressing hormone. The other view, which was taken by [Jeff Flier](https://en.wikipedia.org/wiki/Jeffrey_Flier), who was at Harvard at the time, later became dean, he’s still at Harvard, [Streamson Chua](https://www.einstein.yu.edu/faculty/10242/streamson-chua-jr-/) who was working  on this project, or had worked on it, and myself, was that the protein was actually more important in its deficiency state as a signal to the brain that you didn’t have enough energy to survive under circumstances of a fast or to have enough energy on board to successfully complete a pregnancy.

Rudy Leibel: So one view was that very high levels would normally suppress body weight, although it was hard to imagine at the time-

Peter Attia: Evolutionarily, that was not a natural state.

Rudy Leibel: Right. That’s correct. That’s we were wondering right from the beginning, why would nature invent something that would-

Peter Attia: Right, it makes more sense that nature would say, here’s a hormone that if it’s low, is a kick in the pants to eat.

Rudy Leibel: That’s correct.

Peter Attia: Or, and maybe other things. Maybe prevent you from getting pregnant.

Rudy Leibel: Yes, and that’s, I think turned out to be the correct model for how this hormone, its primary mechanism of action is that it is there to tell the brain that you don’t have enough fat and in an ob mouse, you don’t make  the hormone leptin so the brain thinks you don’t have any fat and in the db mouse, it doesn’t receive the signal from the perfectly adequate amounts, actually high levels, of leptin so that the animal, again, thinks that it’s starving.

Peter Attia: Are there human conditions that mimic the ob and db condition of the mice?

Rudy Leibel: Yes. So there are humans, there are a handful of humans, who have mutations of the ob gene and are obese and have many of the phenotypic characteristics of ob mouse-

**Humans with leptin mutations**: [A mutation in the human leptin receptor gene causes obesity and pituitary dysfunction](https://www.ncbi.nlm.nih.gov/pubmed/9537324) (Clement et al., 1998) [1:05:45]

Peter Attia: And these are patients that you’ve cured with this, you give these patients leptin and you cure them.

Rudy Leibel: Yes. They’re curable by giving leptin and they are a handful, again, of individuals with leptin receptor mutations, which are comparable.

**Humans with leptin mutations**: [A mutation in the human leptin receptor gene causes obesity and pituitary dysfunction](https://www.ncbi.nlm.nih.gov/pubmed/9537324) (Clement et al., 1998) [1:05:45]

**Humans with leptin mutations**: [Congenital leptin deficiency is associated with severe early-onset obesity in humans](https://www.nature.com/articles/43185) (Montague et al., 1997) [1:05:45]

**Humans with leptin mutations**: [Effects of recombinant leptin therapy in a child with congenital leptin deficiency](https://www.ncbi.nlm.nih.gov/pubmed/10486419) (Farooqi et al., 1999) [1:06:00]

Peter Attia: How do you help those patients?

Rudy Leibel: Those, the leptin won’t help. You can’t treat them with leptin. And there is no effective intervention for those people at this time, although there are drugs that are being developed that are designed to act downstream of some of the actions  of leptin that might, if you could rectify the activity there, for example, at a receptor called the [melanocortin 4 receptor](https://en.wikipedia.org/wiki/Melanocortin_4_receptor), that would presumably or possibly help to rectify the phenotype of those individuals although at present it’s not a proven effective intervention. It might turn out to be.

Peter Attia: Wasn’t long after the discovery of leptin that, what drug company came in?

Rudy Leibel: [Amgen](https://en.wikipedia.org/wiki/Amgen).

Peter Attia: Amgen obviously bought the rights to do this, thinking this could be a blockbuster obesity drug.

Rudy Leibel: Mm-hmm (affirmative).

Peter Attia: Turned out not to be because unless you had a leptin deficiency, it didn’t seem to help much, right?

Rudy Leibel: Correct. There was a major trial of the use of leptin as a therapeutic agent in obese individuals and neither the obese individuals or the lean individuals, who were in the study as controls, responded very much to raising blood levels as much as ten-fold above where they were normally located in those individuals.

**Leptin trial in humans**: [Recombinant Leptin for Weight Loss in Obese and Lean Adults — A Randomized, Controlled, Dose-Escalation Trial](https://jamanetwork.com/journals/jama/fullarticle/192037) (Heymsfield et al., 1999) [1:07:00, 1:09:00]

**Leptin trial in humans**: [Leptin as a Therapeutic Agent—Trials and Tribulations](https://academic.oup.com/jcem/article/85/11/4000/2852288) (Mantzoros and Flier, 2000) [1:07:00, 1:09:00]

Peter Attia: I just did a blood draw, I’ve been doing a blood draw on myself every seven days, ’cause I’m doing … you know me, that’s just the shit I do. So my leptin level last Friday was two, or less than two. The cut off was two. I have a low level of leptin. If you gave me enough leptin to raise my serum levels to levels that I rarely see clinically, when I check leptin levels on patients, which I always do. I always want to see leptin, I want to see [adiponectin](https://en.wikipedia.org/wiki/Adiponectin), I wanna see insulin, I wanna see [FFA](https://en.wikipedia.org/wiki/Fatty_acid#Free_fatty_acids), etcetera. It’s very unusual that I’ll see a leptin level, even in an overweight patient, more than about 40 or 50. So if you took me, and you gave me that much leptin, do you think it would regulate or depress my appetite in any way?

Rudy Leibel: Well, first of all, your leptin is low now because you’re not eating.

Peter Attia: Oh, this is even … this is back when I was eating too.

Rudy Leibel: Right. Leptin is very highly correlated with body fat, at any level of body fat, if you stop eating, if you restrict calories, the level of leptin will drop by at least-

Peter Attia: Within what period of time?

Rudy Leibel: Within 12, 18 hours it’ll drop by 50% or-

Peter Attia: So if we check a leptin level on a patient in the morning, following a 12 hour fast, we can assume that that’s about half what their fed leptin level is?

Rudy Leibel: Well 12 … it depends on what they’ve been eating. 12 may be a little short in that context so to be safe, I would say 24.

Peter Attia: Okay.

Rudy Leibel: But it’ll start down within 12 hours. So a 12 hour fast will give you a leptin level which is not what it would be if you were to draw it when the patient is-

Peter Attia: So let’s say my fed level is two or three or four, my fasting level is less than two. If you injected me with enough leptin, such that, let’s just say that my level was now 100. The level that you would see in the highest fed, obese patient. What would that do to me?

Rudy Leibel: Based on the studies that have been done, the so-called leptin trial, not very much.

**Leptin trial in humans**: [Recombinant Leptin for Weight Loss in Obese and Lean Adults — A Randomized, Controlled, Dose-Escalation Trial](https://jamanetwork.com/journals/jama/fullarticle/192037) (Heymsfield et al., 1999) [1:07:00, 1:09:00]

**Leptin trial in humans**: [Leptin as a Therapeutic Agent—Trials and Tribulations](https://academic.oup.com/jcem/article/85/11/4000/2852288) (Mantzoros and Flier, 2000) [1:07:00, 1:09:00]

Peter Attia: So interesting.

Rudy Leibel: You might have some, at least in some of these individuals there was some reduction in body weight, but not very significant.

Peter Attia: Through the mechanism of reducing intake?

Rudy Leibel: Yeah, primarily, apparently. Yes. Although, there weren’t detailed formal studies of food intake done in those experiments.

## What Prader–Willi syndrome teaches us about body weight regulation [1:09:45]

Peter Attia: Now, going back to the DBs, who obviously in many ways have a worse problem. Earlier you alluded to [Prader-Willi](https://en.wikipedia.org/wiki/Prader%E2%80%93Willi_syndrome), what is the genetic defect in Prader-Willi, and what’s the phenotype?

Rudy Leibel: So Prader-Willi is a genetic disorder in which, rather than having a single gene affected, there’s a region of the genome which is, in most instances, not all, but the majority of instances, deleted. So there’s a region of chromosome 15 in which there is a large deletion that is a region that has normally 20 or so genes in it and when deleted, when the paternal, the father’s copy of this interval is deleted, the individual becomes, has a very characteristic phenotype. The maternal, the mother’s copy, is not expressed. This is called an imprinted region of the genome, which again, for technical reasons, the only one chromosome expresses the genes from that interval and in the Prader-Willi region, the maternal genes are silenced, so they’re there but they’re not expressed and if you-

Peter Attia: So the mom can be a silent carrier?

Rudy Leibel: A mom could be a silent … *carrier* is not the right term. Almost all of these individuals are, all of these individuals are the result of spontaneous deletions that occur after conception. So it’s not transmitted-

Peter Attia: So it’s sort of polygenic, and you can have … so the one example that is in my world that I get is [familial hypercholesterolemia](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia), it’s a phenotypic description. There are at least 2000 known mutations, distinct mutations, that can produce the same phenotype. So in that case, no one really … I don’t want to say nobody cares but it’s a lot less interesting to try to map out each and every one of the genes that can lead to familial hypercholesterolemia, it’s more important to understand the phenotype and how to treat it. I’m guessing Prader-Willi’s not quite that diverse, but is it safe to say, if I’m understanding you correctly, that you could have two patients with Prader-Willi that will have different genes?

Rudy Leibel: There are rare instances of Prader-Willi in which the number of genes deleted, rather than being that large interval that I mentioned, include only three genes, but they’re still in the region which is deleted in the large deletion patients. So-

Peter Attia: So they’re necessary and sufficient genes?

Rudy Leibel: Yes. We think that those, that smaller region, probably has the necessary and sufficient genes, although again, there’s debate in the field about this. The children though, who are affected with this disorder have very characteristic phenotypes. They actually don’t grow well, they don’t feed well, early in life they actually have failure to thrive. They’re floppy and hard to feed and not very responsive, in terms of ingestive behaviors and then, for reasons that are entirely unknown at this point, between the ages of four or five, three years of age, they become hyperphagic. They, again, drive to eat becomes very, very strong.

Peter Attia: These are some of the most tragic stories I’ve ever heard. These children, who I’ve never taken … I’m not a pediatrician so I’ve never taken care of them, but I talk to parents of children, they have to lock the refrigerators. I even had one parent tell me that they actually have to lock the bathroom because the child is so hungry,  so hyperphagic that he would go into the bathroom to try to eat out of the toilet.

Rudy Leibel: It’s true that in the majority of instances, these children require very close scrutiny of their access to food and in many instances, the parents or the caretakers have to resort to locking up whatever food is in the, would otherwise be available to the children. But I think it’s important to point out that there are ways of managing this disorder,  which has other characteristics. There are many endocrine disturbances that go along with it, including, actually growth hormone deficiency. And administration of growth hormone to these children and various other interventions that require a great deal of parental attention, no doubt about that, some of the severity of the disease is manageable at a clinical level, with very high levels of scrutiny by the people who are taking care of them. So that not all children with Prader-Willi will necessarily become hugely obese or suffer the consequences of severe obesity.

Peter Attia: This is one of those things where I hope, I know there are folks out there trying to raise money to do clinical trials in this because, anecdotally, again, there are these very interesting stories. The first I ever heard of this was probably four years ago. I was giving a talk, I don’t even remember where it was, it was in Chicago, but I can’t even recall the audience. But afterward, a woman came up to me … and I was giving a talk about, I don’t know, longevity. It wasn’t an obesity-specific talk or anything like that, but a woman came up to and introduced herself and said her son had Prader-Willi and was going off the rails, et cetera and at about the age of seven or eight, she put him on a ketogenic diet and it corrected the phenotype, including the cognitive, developmental part, which often accompanies this. She then, since that time, had formed a support group and you had more and more of these parents that were putting their Prader-Willi kids onto ketogenic diets. Again, it’s very difficult to draw much of a conclusion when you don’t have controlled data and you have obviously the selection biases that go into these things, but it struck me as very interesting. Do the Prader-Willi kids, are they [hyperinsulinemic](https://en.wikipedia.org/wiki/Hyperinsulinemia)?

Rudy Leibel: They are hyperinsulinemic to the level that would be anticipated based on their degree of adiposity. And  in some research that we’ve done very recently using some of the stem cell techniques or at least using stem cells that I alluded to much earlier, we’ve got some evidence that suggests that one of the major consequences of deleting this region of [chromosome 15](https://en.wikipedia.org/wiki/Chromosome_15) by mechanisms that are somewhat complicated, influence the expression of an enzyme  called [proconvertase 1](https://en.wikipedia.org/wiki/Proprotein_convertase_1) and this enzyme is critical for the processing of many of the hormones and neuropeptides that made in the body.

**Stem-cell based approaches to obesity**: [Stem Cell-derived Hypothalamic Neurons in the Elucidation of the Pathogenesis of Human Obesity: A New Frontier](https://2017.obesityweek.com/schedule-overview/keynote-speakers/) | Rudy Leibel (obesityweek.com) [1:15:30]

**Stem-cell based approaches to obesity**: [PC1/3 Deficiency Impacts Pro-opiomelanocortin Processing in Human Embryonic Stem Cell-Derived Hypothalamic Neurons](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5312251/) (Wang et al., 2017) [1:15:30]

Rudy Leibel: Virtually all hormones and [neuropeptides](https://en.wikipedia.org/wiki/Neuropeptide) are made as prohormones, that is precursor hormones, that are then processed by proconvertase 1 and that is what produces or generates the mature form of the hormone or neuropeptide.  And we think actually, that the phenotype, many of the phenotypes of the Prader-Willi patients may in fact be due to a deficiency or underactivity of proconvertase 1, which is not in the interval where this deletion occurs, but is influenced downstream by one or another of the genes in that interval. And it’s relevant in the question of insulin, because insulin is processed by proconvertase so some of the-

Peter Attia: That’s where the c peptide gets cleaved off the prehormone.

Rudy Leibel: That’s correct. Some of the hyperinsulinemia of the Prader-Willi might be proinsulin and proinsulin has biological activity but much lower than native insulin and so if this turns out to be the case, then it might be possible to rectify some of the Prader-Willi phenotypes by being able to increase the activity of  proconvertase 1, pharmacologically or by other means.

## Leptin and the broad condition of obesity, metabolic consequences of weight reduction, and Peter’s self-experiments [1:18:00]

Peter Attia: So there’s all this incredible work, all this incredible molecular biology and molecular genetics that’s identified leptin deficiency, leptin receptor deficiencies, the cluster of defects that lead to Prader-Willi, and yet the question is, how much do these things tell us about the more broad condition of obesity that afflicts, I don’t even know the stats, I don’t really keep track of this stuff anymore. But, I don’t know, what,  a third of Americans are probably obese now?

Rudy Leibel: Mm-hmm (affirmative). So I’ll tell you an interesting perspective on that question, is, and I mentioned it earlier while we were doing the efforts to clone these genes, I was studying patients in the clinical research center, with Jules Hirsch, [Mike Rosenbaum](https://www.columbiadoctors.org/michael-rosenbaum-md#about-michael-rosenbaum), longstanding associates, and what we were doing is looking at the metabolic consequences of weight reduction and showing that if you reduce the body weight of a human  by 10%, 20%, you get a reduction in energy expenditure, which is greater than what you would predict from the loss of just body size or that their-

**Maintenance of reduced body weight in humans**: [Models of energy homeostasis in response to maintenance of reduced body weight](https://www.ncbi.nlm.nih.gov/pubmed/27460711) (Rosenbaum and Leibel, 2016) [1:19:00]

Peter Attia: In other words, their metabolic rate didn’t reduce just to support the new, reduced weight, it reduced even further which would almost try to return them to a heavier weight.

Rudy Leibel: Yes. Right. So they had a disproportionate reduction in energy expenditure and some of the data suggested that the major change in energy expenditure was not in resting metabolic rate but in the energy cost of low levels of physical activity, of muscle work so to speak, but at very low levels of activity. And we went on to show that, as you would expect based on a lot of what we’ve been talking about, the leptin levels were low in these individuals, low but proportional to the reduced amount of body fat.

Rudy Leibel: So one hypothesis that we had  is that this reduction in energy expenditure was in fact a reflection of the fact that the body was sensing the reduction in leptin and interpreting that as a starvation state, that is, for that individual, that new lower body weight represented a threat, if you will, to survival or reproduction and we’ve done experiments subsequently in which we’ve injected leptin into those individuals. None of them has a genetic lesion of the leptin gene, they’re just weight reduced, normal individuals. We’ve put leptin back into them by injection to raise the blood level back to where it was before they lost their body weight. So these are very low doses of leptin, and that intervention will restore their energy expenditure back to where it was before they lost the body weight, even though they’re now still maintaining the lower body weight.

Peter Attia: So put this in some quantitative terms for me. That infusion of leptin gave them how many more kcal per day in energy expenditure, all things equal between movement activity, et cetera. You talking about 100 kcal a day, what kind of a delta are you producing?

Rudy Leibel: 2 or 300 because these are big people to start with.

Peter Attia: That’s huge. That’s a huge delta.

Rudy Leibel: Right. And we could show that that effect is primarily being conveyed through skeletal muscle. What happens is that the muscle becomes less efficient if you wanna think about it that way, after the leptin administration.

Peter Attia: So there are two ways that we broadly, in the research setting, measure energy expenditure, [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry) and [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water). Can you spend a second explaining each of those?

Rudy Leibel: Indirect calorimetry is really classical physics, in which the rate of oxygen consumption and the rate of carbon dioxide are measured in a number of ways, the most  frequent is to put a mask or hood over the head of the individual in whom the measurement is made and simply use gas sensors and flow meters to quantify the amount of oxygen consumed and CO2 released and from that information one can quite easily calculate how many kcals of energy are being expended to correlate, to account for the amount of oxygen consumed and the  CO2 produced. And by looking at the ratio of those two, one can even get an indication of the kind of fuel that’s being burned to support the metabolic rate.

Peter Attia: I’ll just spit it out so folks can … and we’ll link to all of this stuff, but the RQ, or the [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient), is the ratio of [CO2](https://en.wikipedia.org/wiki/Carbon_dioxide) produced, or [vCO2](https://medical-dictionary.thefreedictionary.com/VCO2), divided by the amount of oxygen consumed, or the [vO2](https://en.wikipedia.org/wiki/VO2), and that’ll vary between typically  about 0.7 and 1, right?

**Peter explaining respiratory quotient**: [Peter Attia – An Advantaged Metabolic State: Human Performance, Resilience & Health](https://www.youtube.com/watch?v=NqwvcrA7oe8) | IHMC (youtube.com) [1:22:30]

Rudy Leibel: Correct.

Peter Attia: You can see it outside of those ranges, but lower it is, the more they’re partitioning and drawing from fat, the higher it is, the more they are drawing from glycogen.

Rudy Leibel: Correct.

Peter Attia: And if I still remember my [Weir coefficients](https://en.wikipedia.org/wiki/Weir_formula), energy expenditure is something to the effect of 3.94 times the vO2 plus 1.11 times the vCO2.

Rudy Leibel: Well, your memory is better than mine. I can’t recite you the Weir equation off the top of my head.

Peter Attia: You know it’s really funny, about five years ago, I asked [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) to send me the derivation of it and it was so great to get this page, two pages of differential equations so I could go through and actually see how the Weir coefficients were described. Which, of course, then led to the inevitable question that you and I have talked about in the past, which is, do those coefficients hold in the presence of radically dietary change? Such as a very, very low fat, high carbohydrate diet, or the opposite.

Peter Attia: So then, if that’s how indirect calorimetry works, and of course, by the way, these things happen in [metabolic chambers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5916490/), that’s the ultimate way to do it, right? Where you can put a person into a room and the room itself has all of these sensors embedded in it.

Rudy Leibel: Correct. Right, and that’s exactly the same principle, but there the individual is not restricted, in terms of their motion, other than in the room that they’re in so you can get exactly the same information but over a much longer period of time, you can do it for days.

Peter Attia: There was a point when I wanted to build one of these at my home. I was obsessed with knowing every …  I wanted to know my vO2 and vCO2 almost every minute of the day and then I found out it would cost at least $5 million to build one and realized I couldn’t build one, but I thought, boy, if I ever make enough money to build one of those, that’s a great, fun … that’s fun for the whole family, if you really stop to think about it. Who wouldn’t want to go sit in the metabolic chamber on the weekend, just kickin’ it, watching football?

Rudy Leibel: We just built one of these actually at Columbia and it’s quite a, your right, it’s not only expensive but requires a great deal of attention to things like leaks and air flow and-

Peter Attia: You know I broke one once.

Rudy Leibel: Doing what?

Peter Attia: You’ll recall, I used to spend time in these chambers and I guess I exceeded the level of CO2 production that it was calibrated for because I was on my bicycle and I was riding pretty vigorously and the CO2 sensor broke and it’s one of those things where you don’t get a big, red flag, it was just after the fact, the data didn’t make sense and this is where you appreciate what you’re  saying, which is the engineering in this thing is amazing. And so you gotta pour through the longest spreadsheets in the world to start to look for where the mistakes are, but it’s really beautiful stuff, and there’s not many of these in the country. There’s, obviously Columbia has some, NIH has some, TRI has some, Pennington has some, Baylor has some, not many.

**Peter explaining respiratory quotient and his experience in a metabolic chamber**: [Peter Attia – An Advantaged Metabolic State: Human Performance, Resilience & Health](https://www.youtube.com/watch?v=NqwvcrA7oe8) | IHMC (youtube.com) [1:22:30, 1:25:00, 1:29:15]

Rudy Leibel: Like you said, they’re tricky to construct and require a high level of attention to their maintenance and operation.  It’s not just like going down in your basement and measuring your RQ with-

Peter Attia: So how does [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) work, which I also have had the privilege of ingesting?

Rudy Leibel: So doubly labeled water is a technique which uses two isotopes of water, which is H2O. In one, the oxygen is a heavier version of the normal, or the more prevalent oxygen molecule and the other,  the hydrogen is a heavy atom, as opposed to the more prevalent kind of hydrogen in the environment. And what you do, is you can give these as a mixture, you have to know exactly how much of each one you’ve given, but you can give this as a drink, basically, of what amounts to heavy isotope labeled water and then look at the relative concentration of these two isotopes. You can do it in blood, you can do it in urine, we often do it in both, and the difference in the rate of excretion of the so-called O18 water, the heavy isotope of water, which is oxygen is born out both in urine, but also in the expired air of an individual as carbon dioxide, and the H2O, which comes out by non-respiratory means, you can actually  get a measure of how much CO2 the individual is producing and you can use that and the nature of the diet that the individual is on to back calculate from what would be the RQ back to the oxygen consumption.

Peter Attia: So you would use the FQ (food quotient) basically?

Rudy Leibel: Yes, correct.

Peter Attia: So the FQ is, if you stuck the person’s food into a bomb calorimeter, burned it, that would produce the RQ. So the limitation of this is, a couple things. One, the patient’s gotta be weight stable. This starts to fall flat when they’re losing or gaining tremendous amounts of weight. And two, you have to have a pretty darn good idea what they’re eating.

Peter Attia: So each of these methods, ingenious and completely distinct, both have huge limitations. The former, of course, requires an artificial environment, they don’t get to be free-living and you can’t really study them for that long, but the latter, where they can be free-living and you can study  them for two weeks at a time with a single ingestion of the doubly labeled water, you better make sure that they’re not gaining and losing weight, and you better make sure you know exactly what they’re eating and in an ideal world, it better be the same thing almost every day, right?

Rudy Leibel: And, in general, because of the issues that you just mentioned, I think most investigators in this field prefer, at least in terms of its nominal accuracy, the room calorimeter  over the doubly labeled water, but the doubly labeled water does have the virtue, as you pointed out, of being applicable over much longer periods of time so that you can get integrated idea of how much an individual is expending over literally days or even weeks. What’s sometimes done is to re-dose the individual at some point in the experiment and simply continue it.

Peter Attia: When I did this, I did several days in several chambers and then separately did DLW. I was kind of amazed at how closely they overlapped. Of course, it was hard to replicate my chamber activity in the real world because there’s so much more movement outside of the chamber but they were surprisingly in line. Which is interesting ’cause at the time I was on a ketogenic diet, which there’s a lot of things that could be changing there.

**Peter explaining respiratory quotient and his experience in a metabolic chamber**: [Peter Attia – An Advantaged Metabolic State: Human Performance, Resilience & Health](https://www.youtube.com/watch?v=NqwvcrA7oe8) | IHMC (youtube.com) [1:22:30, 1:25:00, 1:29:15]

## How is appetite being regulated? [1:29:45]

Peter Attia: So wanna go back to something that we got into a little bit, but to me  it’s one of the most fascinating discussions/debates, which is the idea of appetite being regulated centrally versus peripherally and you and I have had some incredible dinners having these discussions and I’ve always found your perspectives to be interesting because I think few people are more qualified to talk about that in that they know so much about both. I mean in many ways, Leptin, at its inception was really viewed as a peripheral way to regulate appetite. So, let me explain what I mean by that for the listener. When you’re hungry, is this all being driven by what your brain is saying? Is it possible that somewhere outside of the brain, which we refer to as the periphery, your liver, your fat cells, your muscles, the level of blood glucose that’s circulating, is there some other signal? You know, it’s kind of interesting that here we are in the year 2018 and it’s still not entirely clear where appetite is regulated. How has your thinking on this topic evolved through your own immense knowledge of both the central and peripheral components of appetite? You want to take a sip of that Topo Chico before you try to answer that? For the listener, I’ve introduced Rudy to Topo Chico today, so he’s one sip into it. He declared it the finest bottled water.

Rudy Leibel: I would describe the system, from a high altitude, as the following; that they are  CNS, [central nervous system](https://en.wikipedia.org/wiki/Central_nervous_system) mechanisms. They are not all in the hypothalamus, but many of them are, and many of those that aren’t do interact with the hypothalamus and that that can be regarded, that organ or set of cells can be regarded as the integrating center for basically the reception of signals that are of relevance to how an organism ought to respond to its  environment in terms of food intake, and also for control of some of the aspects of energy expenditure that are not necessarily under voluntary control such as [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system) and what’s coming into that system is I think broader than we had originally anticipated. So, clearly leptin is an example of a hormone that’s secreted from adipose tissue, but there are many other peptides actually, or hormones that come out of adipose tissue.

Rudy Leibel: There are neural signals that are now being identified. That is nerve born signals that look like they’re coming out of and going into adipose tissue, that may be playing a much more important role than we had sort of previously appreciated. The [gastrointestinal tract](https://en.wikipedia.org/wiki/Gastrointestinal_tract), which for obvious reasons is a very relevant aspect of the system.  Originally, was, I think regarded pretty much the way that adipose tissue was. As a tube that absorbed your calories and didn’t really participate actively in the regulation of that aspect of biology. Clearly, the advent of various surgeries for control of body weight have indicated that that sort of premise is incorrect. That is that there are very powerful influences of the gastrointestinal tract, which are brought out by  some of the surgeries that are done and it’s now very clear that the gastrointestinal tract at many levels is communicating with the brain both by-products that it secretes and by direct neural input probably primarily, but not entirely by the [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve) into the brainstem and then further up into the brain.

Rudy Leibel: So, just taking that as a sort of very broad picture.  It’s much clearer now that there is no sort of single, definitive part of the biology of an individual which is dictating this very complex system. It’s really a product of the interaction of these peripheral signals as you referred to them, including metabolites such as glucose and free fatty acids and so forth, and the central nervous system. Not just a hypothalamus, but areas of the [brainstem](https://en.wikipedia.org/wiki/Brainstem) and the [amygdala](https://en.wikipedia.org/wiki/Amygdala), the [frontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex). There’s many other areas of the brain that interact with these signals to influence both the behaviors and the unconscious, if you will, the vegetative responses that ultimately go into the regulation of body weight. So I think it’s obviously a very complex and overdetermined system and it’s that way because it is absolutely critical to survival. So,  it’s not surprising in a way that it’s as complex as it is.

Rudy Leibel: But I think what it clearly does is it introduces all sorts of possibilities for mischief with regard to body weight regulation. Starting in the frontal cortex where decisions are made, at least with regard to some aspects of this. All the way down into the colon where you’ve got large numbers of bacteria that are producing things, metabolites and molecules themselves  that again, we’re only just beginning to understand, so we’re not only talking about a regulatory system that has all of these elements, but a bunch of organisms literally living within us that are influencing it in ways that I don’t think we’ve really fully understood. The miracle is actually when you think about all the ways that it could go wrong, that it doesn’t go wrong anymore than it actually does and it looks to me like the major  problem in terms of the obesity that you referred to earlier that’s increasing has to do a great deal with the environment and what people are being exposed to.

Rudy Leibel: That’s very novel with regard to the system. I mean this system was not designed for the regulation of metabolism and body weight in an environment in which with a cell phone you can bring literally as many calories as you want into your living room without getting up off your behind. So we’re dealing with an organism which has it’s very complex and beautiful system designed to regulate various aspects of the biology which is now in an environment which is entirely, at least in many regards, novel to the system and it fails in the sense that there’s a lot more obesity than there was prior to the environment that we’ve been able to create,  but it’s not totally dysregulated. I think people are just now regulating their body weight at somewhat higher levels than they were in other circumstances.

## Are there epigenetic consequences of being obese? [1:37:00]

Peter Attia: Again, I don’t follow those statistics. Just not something I’m paying huge attention to, but are the rates of obesity plateauing or are they still increasing or does the curve concave up or concave down?

Rudy Leibel: So several years ago it looked like the rates were either slowing down or level.  Now it looks like maybe they’re continuing to inch up, but not as rapidly as they were, say a decade ago. So there’s been some relenting of the rate of increase, excuse me, in obesity in both adults and children, but it looks like it’s still rising. Although at a lower rate.

Peter Attia: Do you have concern that there are [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) implications of this that 10,000 years ago the prevalence of obesity, again,  largely probably driven by the environment that made it pretty hard to become obese, not just in terms of food availability, in terms of absolute calories, but presumably the types of calories that were available. I mean, I think my recollection is at 10,000 years ago, nothing came in a package, right?

Rudy Leibel: As far as we know.

Peter Attia: So, we didn’t have pop tarts. We didn’t have breakfast cereal, we didn’t have orange juice, we didn’t have French fries and whatever else are the culprit potentials. So, if Johnny got a set of genes that were slightly suboptimal, Johnny Jr. probably got some of those suboptimal genes, but there was nothing being imprinted on the genome that was being transmitted to generations and I mean, what do you think about this idea that we could be reaching kind of a dangerous point in evolution of our species were children, maybe during critical windows of development,  if exposed to, again, in my opinion, it’s probably a lot of this sort of really highly refined crap, high amounts of fructose that we’re seeing with the [NAFLD](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) that this is setting them up for a real problem later in life. It’s going to make it a lot harder not just for them to lose weight one day, but also for their offspring. Is there any evidence of that?

Rudy Leibel: I think there is evidence. I’m not so sure I would use the term imprinting that has sort of specific biological meaning and implications. I mean we could talk about that in a minute, but if what you’re saying is, are there perhaps critical periods of development in a child in which if the child is caused to become more obese than he or she might be in some other environment, that will leave a mark on the regulatory system that will then cause that individual  to want to sustain or maintain a higher body weight? I think the answer is probably, or at least possibly, yes. That is that there may be critical periods in human development. Certainly. I think the data are also available to some extent in animal studies that suggest that if you manipulate body weight or some of these systems at critical periods of development, you end up with an animal which is more likely to be obese as an adult than if you hadn’t done that and exactly what the molecular and neuroanatomical or other physiological consequences of that manipulation are that lead to the maintenance of a higher body weight.

Rudy Leibel: This is obviously a critical area of study. It’s actually something that people in my lab are quite interested in. That  is whether we can impose by dietary or other manipulations, a higher body weight or a higher sustained body weight in an animal by early manipulations either by diet or endocrine manipulations and I think the answer is probably yes, but what is the consequence of that in terms of the regulatory elements that we were talking about? We don’t yet know. Another aspect or another perspective on this is the following question. If you manipulate the metabolism of a pregnant animal or human, what are the consequences of that on the developing brain or physiology of the fetus?

Peter Attia: I mean there’s evidence now that a mother who is hyperinsulinemic or has [gestational diabetes](https://en.wikipedia.org/wiki/Gestational_diabetes) is increasing the child’s risk of obesity. Is that not the case?

**Diabetic mothers and childhood obesity and diabetes**: [High blood sugar during pregnancy ups risk of mother’s type 2 diabetes, child’s obesity](https://www.nih.gov/news-events/news-releases/high-blood-sugar-during-pregnancy-ups-risk-mothers-type-2-diabetes-childs-obesity) | NIH (nih.gov) [1:41:30]

Rudy Leibel: There are data that suggest that-

Peter Attia: It’s registry data, so it’s hard to know, but-

Rudy Leibel: That obesity in a pregnant woman does confer by, again, by mechanisms that we don’t understand, higher risk of obesity in her offspring.

Peter Attia: Although I’d love to see it stratified by hyperinsulinemic versus non-hyperinsulinemic obesity because I feel like I remember reading that it also seems to be dependent on the gestational stage. In other words, like when the  Dorsal and ventral buds of the pancreas are forming, which I can’t even remember when that is, maybe week seven, eight, nine, something like that. Those are very critical windows, right? That’s when islet cell formation is taking place and nutrient exposure or insulin exposure during that period of time could have a more profound effect than say late in the third trimester where perhaps it’s not as effective. Again, very. I mean, I don’t follow this literature so I don’t want to sound like a complete moron and the last time I really paid attention to this stuff was probably four years ago and it was again largely registry-based data, so very difficult to know cause versus effect.

Rudy Leibel: Again, the literature, as you sort of implied, is wildly on this point, but I’ll just tell you about a couple of experiments actually that we’ve done. One, to answer or to address this question of hyperinsulinemia in a dame, in a pregnant animal, and its effects on the fetus. We were able to do an experiment in which we were interested in separating the issue of high body weight and adiposity from the effect of insulin itself. And so we actually used a genetic model of hyperinsulinemia and were able to make the dames hyperinsulinemic without being obese. So, these are perfectly normal body weight dames that were very hyperinsulinemic and the pups that they were carrying. Some of those pups had no abnormality of any insulin-related genes. So, they were what we would call wild-type pups being incubated in a hyperinsulinemic dame, and we were very interested to see what the consequences would be on the metabolism and body weight of these animals, and very interestingly, these animals showed transient elevations of body weight and body fat when they were in what I guess we would describe as adolescent period of  a mouse which tended to revert back to normal over time. You could definitely see an effect in the body weight and metabolism of the mouse, but it appeared to be transient.

**Body weight and insulin resistance**: [Respective Contributions of Maternal Insulin Resistance and Diet to Metabolic and Hypothalamic Phenotypes of Progeny](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3234171/) (Carmody et al., 2011) [1:43:15]

Peter Attia: And to be clear, the mother was euglycemic.

Rudy Leibel: And mother was euglycemic.

Peter Attia: Euglycemic but hyperinsulinemic. That’s a tough needle to thread my friend.

Rudy Leibel: Again, it’s the power of genetics. So we could do that. So, these kinds of experiences, we also looked at the brains of these animals and there were some very subtle differences in the way the hypothalamic cells, the numbers of different types of hypothalamic cells, which suggested, in sort of support of the inference of the implication of your question. There are consequences of these metabolic states of the dame that can influence the subsequent development of the pup, even if the pup doesn’t have the genetic etiology that led to the derangement, if you want to call it that, in the dame. We’ve more recently  been doing some experiments along these lines, looking at Leptin in a similar way, and again can see evidence of influence, long-term influence of manipulations of Leptin in this way, which again suggests that these transient periods of exposure at various levels, or various periods of development can have long-term consequences for organisms that don’t themselves have any primary abnormality of these genes or their functions. So, I think this probably supports the notion that there are things going on in the environment that are not reversible. Once the environment is necessarily reversed, that is the exposure to the environment may change the biology in such a way that even when the insult, if you want to call it that, is removed. The biology is permanently impacted.

## What makes low-carb diets so effective at obesity reduction? [1:46:15]

Peter Attia: We’ve spent a long time talking about low carbohydrate diets. You were part of one of the studies that was funded by [NuSI](https://nusi.org/) and while the study that you were a major part of it was not a diet study, so it wasn’t really looking at diets, it used diets as a tool to ask questions.  Clinically, we know that low carbohydrate diets are very effective. I think it would be very difficult for people to dispute that at this point in time. The interesting question, if you’re Rudy Leibel, is why? What do you think? Why do these diets seem so effective for so many people? Let’s not even get into the fancy stuff about the diabetes reversal and stuff like that where I think the results are especially pronounced, but just in terms of obesity reduction. Why do you think these things work?

**NuSI study Rudy Leibel was involved with**: [Energy expenditure and body composition changes after an isocaloric ketogenic diet in overweight and obese men](https://academic.oup.com/ajcn/article/104/2/324/4564649) (Hall et al., 2016) [1:51:00]

Rudy Leibel: I guess my view of this is that to the extent that diet composition has an effect on body weight, which clearly it can, that this is the result of the interaction of the components of the diet with aspects of the regulatory control of food intake and I guess the way I described this is the sort of [hedonic](https://www.merriam-webster.com/dictionary/hedonic) aspects of the food that’s being ingested will influence the drive to ingest that particular food. I think individuals differ in terms of their sensitivity or susceptibility to diets and different composition, and there clearly are some individuals who when fed or offered or impose diets that have pretty radical compositional differences will respond very well. In other words, there are people who respond well to high carb diets. There are people who respond well to low carb diets. I think that it’s primarily some aspect of the hedonics of these diets.

Rudy Leibel: If you want to call it that. That’s driving the favorable response. I know, and I’m sure you and I have discussed this many, many times. There are individuals who view the diet composition as having, in addition to what effects I just described, also an impact on energy homeostasis itself, meaning that the composition of the diet can influence the degree of caloric expenditure per unit of calories ingested. I’m not a sort of strong proponent of that view. I guess I try to remain agnostic about it, but my bias, if you want to call it that, from my experience, is that’s right. Diet composition can have an effect on body weight. It doesn’t do so by affects primarily or maybe at all on energy expenditure per se, but can have pretty striking effects on an individual’s desire to eat those calories delivered in that form.

Peter Attia: And so there’s two ways to think about that, right? If again, if you leave the energy expenditure side away on the intake side, is it the case that a low carbohydrate diet, as you say, it’s purely a hedonic issue? People just, when they are on these diets, they’re just not as hungry because I don’t know, the food is not as diverse or not as palatable. An alternative viewpoint is they eat a lot less because they’re eating themselves more. In other words, the way I try to explain this to my patients when we’re talking about nutrition is, you want to differentiate between exogenous and endogenous calories, so most people walk around, if their weight is stable, purely subsiding on exogenous calories, but if you want to lose weight, by definition, you must start to consume endogenous calories.  You have to start eating yourself, and this gets back to the question of the regulation of body weight peripherally. If you are eating yourself, can the CNS figure that out and say, Hey, we’ve got all this lipolysis going on.

Peter Attia: We’re liberating all of this fat out of a fat cell. That’s energy. Fantastic. I will program the system, you need less exogenously, so those are two kind of very different ideas, right? The one is just, hey, this food is boring and doesn’t taste great. I am just going to eat less of it. Personally, I don’t find that theory as appealing because having worked with so many patients that do this, if that were the case, I’d suspect they’d be more hungry, but yet they don’t seem to be very hungry, which is I think for most people, the only thing that’s intolerable over long periods of time, is hunger. You look back at the [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys), starvation experiments and those guys weren’t really liking what they were eating. Like what? Maybe 1,600 calories a day, but they were losing their minds,  right? I mean these guys lost their minds on 1,600 calories per day.

Peter Attia: So starvation is clearly an unacceptable state in the long run. I gotta be honest with you. I’m glad I don’t work on this problem. I’m much more interested in just trying to figure out this other easy problem of longevity, but this obesity thing is a real bear because at the same time, as much success as I’ve seen for people on low carbohydrate diets, I also know that they don’t work for everybody and therein lies the challenge  of why? Why would something … I mean, again, it’s a naive question in the sense that you’ve just spent the last two hours explaining some of the most complex biology of obesity, why should everyone respond to the same treatment, but it does, it really frustrates me that there are certain patients in which no matter what one does or no matter what they do, you know, I think patients that try really, really hard and can’t lose weight, I find that to be a very frustrating  clinical problem.

Rudy Leibel: So, I guess maybe I should rephrase the way I answered your question and that is to say that I believe that the composition of the diet can influence aspects of ingestive behavior. I emphasized the hedonic aspect, but I’m certainly open to the possibility that if you feed a diet of divergent composition, you will definitely have some influence. I mean this is well documented on the substrates that are in the circulation as a result of feeding that diet. Those substrates themselves, metabolites, you were mentioning fatty acid, but many other things change, may themselves have effect on the drive to eat. I’m sympathetic to that idea and exactly in any given individual who does or doesn’t respond to a specific diet, which of the mechanisms, whether it’s occurring at the level of the taste of the diet or some of the metabolic consequences of the diet.

Rudy Leibel: I would say to the extent that somebody is successful in losing weight on that diet, A, they have to be a negative energy balance. That is there’s no way that they can eat the number of calories that they’re expanding and lose weight. So, they need to be in negative energy balance and I mean that’s just a given. And then the mechanism by which the diet composition influences the success of their ability to sustain a hypocaloric state. Which as you pointed out, is uncomfortable. I’m open to the possibility that it could be at any level of the sort of neural circuitry that regulates food intake. It could be very proximal in terms of taste aspects, but it could also be some of the mechanisms that you mentioned. I think that’s perfectly reasonable. How that works as you pointed out, is a tough nut to figure out and I think like you said, there are individuals who respond very well to diets of quite divergent composition but they have to be taking less calories than they are spending.

Peter Attia: Right. And that’s an easy thing to do mathematically. It’s a very hard thing to do clinically because again, I think patients can tolerate a lot,  but I don’t think people can tolerate hunger for very long. I think to ask somebody to be constantly hungry is a losing proposition and that’s why I believe clinically low carbohydrate diets seem to be more satiating and again, whether they’re satiating because of something in their composition or whether they’re just satiating because you end up eating more of yourself. I mean, I’ve seen lots of patients who, and this has even been published, who on 1,600, 1,700 calories a day of a ketogenic diet, seemed completely fine. And yet, Ancel Keys’s patients at 1,400, 1,500, 1,600 calories of basically very high carbohydrate diet, very low-fat diets, lost their minds.

**The starvation study led by Ancel Keys in 1994-1995**: [Minnesota Starvation Experiment](https://en.wikipedia.org/wiki/Minnesota_Starvation_Experiment) | ([wikipedia.org](https://www.wikipedia.org/)) [1:55:45]

## What did Rudy believe 10 years ago that he no longer believes to be true? [1:55:15]

Peter Attia: What did you believe 10 years ago that you don’t believe today to be true?

Rudy Leibel: I think over the past decade the field of, sort of, neuroscience of body weight regulation or ingested behavior and energy expenditure has expanded the role of other elements in the central nervous system beyond what began as our very intense focus on the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus). Partly that’s historical, and for reasons having to do with attractability of some of the cell types and mechanisms in the hypothalamus. I would say the biggest change in my thinking about this has been that these supra-hypothalamic aspects of the central nervous system, again, starting with the cortex and working down have a much stronger, I think, ultimate impact on this regulatory system than the way I perceived it a decade ago.

Rudy Leibel: What this does is it opens up, I think, a lot of very interesting aspects of the biology that maybe we weren’t either capable of, or didn’t focus on adequately. Part of which, actually, is in response to the points you were just raising. That is what is the effect of diet composition on hunger, and so forth. It’s almost certainly an aspect of this sort of view of the broader central nervous system impact on ingestive behavior than just the hypothalamus.

Rudy Leibel: My mentor, Jules Hirsch, I think who unfortunately passed away.

Peter Attia: He passed away about four years ago?

Rudy Leibel: Yeah. Three years ago. He would agree with this. I mean, he always, I think, was suspicious of focusing slavishly, if you will, on the hypothalamus as the center for all of this. He always, I think, had a much broader perspective on some of the psycho-affective aspects as he would describe them of ingestive behavior. I think he would see the sort of flowering of a broader view of some of these regulatory aspects of food intake to other parts of the central nervous system, he would say, “I told you so,” and he was right. I think.

Peter Attia: He’s looking down at you saying that.

Rudy Leibel: Yeah, he’s probably saying a lot of other stuff, too.

## Rudy’s dream study of the FTO gene [1:57:15]

Peter Attia: If we could wave a magic wand, and, not only were resources unlimited, but more importantly, any of the technical considerations that make this type of study challenging were just ameliorated. What’s the dream experiment you would want to do? If you got one more shot at this, you could spend the rest of your career doing a dream experiment with infinite resources, infinite subject participation, screw the ethics there’s no IRB, you’ve got a bunch of clones out of West world. You can do whatever the hell you want. What experiment do you want to do? Once to take your final kick at this problem?

Rudy Leibel: There is a gene that was identified, now, 10, 12 years ago.

Peter Attia: [FTO](https://en.wikipedia.org/wiki/FTO_gene)?

Rudy Leibel: Yes.

Peter Attia: You tested me for this.

Rudy Leibel: Yes.

Peter Attia: I was negative.

Rudy Leibel: Right. It was identified by [Mark McCarthy](https://www.ndm.ox.ac.uk/principal-investigators/researcher/mark-mccarthy) and some other investigators in Great Britain as sending the strongest genetic signal for obesity, or elevated body fat. Not severe effect, but the strongest statistical signal ever detected in humans. It remains the same. The prevalence of the variants that are associated with higher body fat are very high in the general population. So there are a lot of these variants that are of this gene that are contributing to human obesity. Not of the severity, certainly, of the OB or the monochord four receptor.

**Discovery of the FTO gene**: [A common variant in the FTO gene is associated with body mass index and predisposes to childhood and adult obesity.](https://www.ncbi.nlm.nih.gov/pubmed/17434869) (Frayling et al., 2007) [2:03:15]

Rudy Leibel: There are various schools of thought about how this gene is doing it. The interesting thing is that the variation in the gene that is conferring the risk of obesity is variation in what we call non-coding part of the genome. As people will know, a small fraction of the genome, 2 or 3 percent, actually encodes the proteins that are made that we’ve been talking about, actually. The rest of it is regulatory parts and elements that we don’t understand very well. The variants that are implicated for the FTO gene actually occur-

Peter Attia: Are in this non-coding segment.

Rudy Leibel: … in the non-coding region. We know exactly where they are. It’s not a mystery where they are, but they are in non-coding. They’re in the first [intron](https://en.wikipedia.org/wiki/Intron) so to speak of this gene.

Rudy Leibel: The mechanism by which this very, very common variant leads to subtle increases in body fatness in a large number of individuals. To me, this is a very intriguing question. There is some that view the effect as being conveyed through what’s called [browning of adipose tissue](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5274505/), increasing the energy expenditure of adipose tissue. There are others, like myself, who think it’s affecting central nervous system circuits that affect food intake. The mechanism,  at least in terms of the central nervous system, is really unknown. The primary phenotype that’s seen in these individuals, who do or don’t have what we call the risk variants, is food intake. If you measure their food intake very carefully in a lab, you can see that the individuals with the variants will eat slightly more. They actually may have a slight preference for fattier, higher fat foods, than individuals who don’t … but what, exactly, is going on in the central nervous system is not clear.

Rudy Leibel: They have actually in one study pretty characteristic functional magnetic resonance imaging differences among individuals who do or don’t have this variant, but the mechanism is unknown. This is something which has intrigued me now for eight or 10 years. That’s the experiment I would love to do. I mean, we’re actually trying to do it, but …

Peter Attia: Tell me specifically what the actual experiment is … but before you do that, I want to make sure I’m … and this is going to be an oversimplified analogy, but what you’re basically saying is there’s a genetic marker, effectively, that creates or identifies those who are predisposed in a high nutrient environment to overeat.

Rudy Leibel: Mm-hmm (affirmative).

Peter Attia: Even though our ancestors would have had these genes, the reason … Or, never mind our ancestors. Even though 100 years ago, or 50 years ago, this gene still existed, probably at the same prevalence. You didn’t have the food environment to pour fuel on that fire. Just to push back a little bit, isn’t that like saying, “we’ve got all these people getting lung cancer. It only started when they started smoking. Only one-in-ten of these smokers are getting lung cancer. There’s a gene that might be predisposing them to lung cancer.” You’re basically saying, I want to look at the problem of, why are certain people susceptible to an environmental trigger …

Rudy Leibel: Mm-hmm (affirmative)-

Peter Attia: … versus what’s the environmental trigger. In the case of smoking, it was so obvious. It was the Goddamn cigarettes. In the case of obesity, it’s a little more complicated.

Rudy Leibel: Correct.

Peter Attia: What’s the experiment you would do?

Rudy Leibel: The experiment that I would do, and, actually, we’re trying to do these now, is to actually look in animals, in whom the variants of the genes that we think are affected by this. Even though the intronic region is not encoding anything, we think it’s affecting genes that do encode something. We think we know, at least, what one of those genes is, and what I would like to see it, what the consequences of these variants are on the functional activity of the system that we think is mediating the effects of these genes. Again, for reasons, that are quite technical, I think that one of the major impacts of this gene, or these variants in this gene, is actually on the structure of the nervous system. I think their impact is occurring early in the development of the brain. What it’s doing is changing the circuitry, slightly, in a very, maybe subtle, way. Probably a subtle way that favors the increased food intake that you just described.

Rudy Leibel: The implication of this is very relevant to some of the things we were just talking about earlier. That is, can the environment impose permanent signatures on the feeding circuit, so to speak. This is, I think, a prime candidate, in that regard, and the virtue of the FTO study that we’ve been talking about, is that we know, at least, enough about the genetics and some of the mechanisms that we can design the experiments primarily, but not totally,  in mice to be able to look precisely at where the changes are occurring.

Rudy Leibel: We now, just coming online, or the tools to look at the circuits, as they are acting physiologically. We can activate these circuits in the brain of an animal by using various neurophysiological and neuro-genetic techniques that will, I think, permit us to see where the structural consequences of the variants reside. My guess is that that would give us an insight into the prevalent genetic susceptibility, or one of the prevalent genetic susceptibility.

Peter Attia: What would we do with that information? Let’s assume you had all of that information. How does that take obesity from 35 percent to five percent?

Rudy Leibel: You’re asking somebody who is not an epidemiologist. Some of us do what we know how to do …

Peter Attia: When you’re a hammer, you look for a nail.

Rudy Leibel: … or what we do best. When you’re a hammer you look for a nail.

Rudy Leibel: I’m a hammer looking for the nail of whether or not I can show a gene, which alters the structure of the central nervous system, in a developing organism in such a way is to make it susceptible to the environment. The animals that we have studied, where we have manipulated this gene, definitely are sensitive to the environment in the sense that they will choose, or eat, more of a high-fat diet than a normal diet-

Peter Attia: How many such [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) are there in humans?

Rudy Leibel: There are, at least, a half a dozen SNPs in the first intron-

Peter Attia: In the first intron, alone?

Rudy Leibel: … but that’s where they all are.

Peter Attia: That’s where they all are.

Rudy Leibel: That’s where they all are.

Peter Attia: What is the prevalence in, to the best of our knowledge, of people today who have at least one of these SNPs in that first intron?

Rudy Leibel: 60 percent.

Peter Attia: 60 percent of the population would be at least somewhat susceptible to obesity?

Rudy Leibel: Yeah. Which is … sort of fits with what we see because the effect size of this genetic variation is not on or off. It just widens, I think, or increases, the susceptibility to whatever it is in the environment that’s doing this.

Peter Attia: Are there pharmacologic things that could be done to combat this?

Rudy Leibel: We don’t know what it is, so we don’t know-

Peter Attia: Because we don’t know what the pro …

Rudy Leibel: Right.

Peter Attia: It’s so much more complicated because it’s non-  coding.

Rudy Leibel: Correct, but that’s what fascinates me about it. I think it’s producing something in the central nervous system, which is structural, in consequence, at least, in part, and that’s why I’m fascinated by it … because, what’s this means is, if you have this predisposition, it may change the nature of your central nervous system structurally in such a way as to make you either more or less …

Peter Attia: If you take, just hypothetically, an animal that’s born with these introns,  with this pattern of introns, and you could magically use [CRISPR](https://en.wikipedia.org/wiki/CRISPR), and you could delete them, and edit them, and make them a wild-type again, do you fix the phenotype? If not, that would certainly point to something early on in neurologic development, right?

Rudy Leibel: Yes, you do. We can do that kind of-

Peter Attia: You’ve done that experiment?

Rudy Leibel: Yeah. We’ve also done experiments-

Peter Attia: I’m sorry, it did or did not fix the pheno-

Rudy Leibel: It fixes it.

Peter Attia: Okay, so that means that it’s has an influence that transcends development, right?

Rudy Leibel: That is part of development because the fix occurs at the level of the fertilization of the-

Peter Attia: Oh. You’ve never fixed it post?

Rudy Leibel: Not fixed it post.

Peter Attia: Okay.

Rudy Leibel: Right.

Peter Attia: Rudy, you’re never gonna stop working, are you?

Rudy Leibel: If I gotta figure this out, I’ll have to stay at it for a little bit longer.

## What the hell does insulin resistance actually mean? [2:08:30]

Peter Attia: There are a lot of other things I wanna talk with you about. Maybe we’ll just spend a couple minutes … There’s something else I wanna talk about which is, the most complicated topic ever … insulin resistance. What the hell does insulin resistance mean? How can an insulin resistant person be fat when, by definition, insulin needs to tell the adipocyte to take up the free fatty acid as triglyceride? Does insulin resistance mean insulin resistance of the muscle? Insulin resistance of the liver, but insulin insensitivity of the adipocyte? What does that mean?

Rudy Leibel: The metabolic disposition of glucose, for example, is obviously, or maybe not so obviously … it’s not primarily via adipose tissue. Glucose, when it gets into the circulation and is removed or taken up, it’s …

Peter Attia: … mostly in the muscle.

Rudy Leibel: Yes. It’s mostly in the muscle. To the extent that insulin resistance is functionally denominated by elevated blood glucose …

Peter Attia: It would seem to be the muscle as the primary defect?

Rudy Leibel: It would seem … to be the muscle, which is the primary defect. The mechanism of the insulin resistance of muscle, this is an area that’s not one that I work in, primarily, but there are appears to be that what’s going on at the distal end of the insulin resistance path is that the glucose transporters are not getting to the surface. They’re not responding to insulin the way that they do when a non-insulin resistant person.  When the insulin transporters, the glucose transporters, don’t get to the muscle, don’t get to the surface of the muscle cell, they can’t transport glucose.

Rudy Leibel: At a molecular level, depending on exactly whose model of this you look at, there’s something wrong with the transmission of the signal from the insulin receptor…

Peter Attia: …into the cell, to send the GLUT transporter out.

Rudy Leibel: Right. Exactly what that defect is, again, depends on who you talk to, or what mechanism invoked. That appears to be, at least on one level, the primary problem.

Peter Attia: What’s happening in the liver? When we do an [oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test), the reason we do it for such a short period of time, relatively speaking, aside from who wants to keep a patient in the lab forever is, you pretty much eliminate the de novo glycogenesis, or you eliminate DNL, right? You’re basically looking at uptake by muscle, but there’s some being taken up by the liver.

Rudy Leibel: Mm-hmm (affirmative)-

Peter Attia: I don’t know if I understand fully, aside from capacity, right … The liver has a relatively small capacity for glycogen relative to the muscles. What else determines that partitioning of how much glucose is in the bloodstream is going into the muscle versus the liver? Then, ultimately, anything that exceeds those capacities will then undergo DNL, then to a lipogenic pathway … will produce, in addition, free fatty acid.

Peter Attia: Again, what does it mean to be insulin resistant in the liver?

Rudy Leibel: It’s interesting. The liver, if you wanna look at it this way, there’s two major metabolic things going on. There’s a lot of things going on in the liver, but as far as what we’re talking about, one is the ability to make lipid, to synthesize lipid, and the other is the ability to make or take up glycogen, to release or take up glycogen. They are differentially sensitive to insulin suppression or enhancement if you wanna look at it that way.

Rudy Leibel: What happens, just again, at a biochemical level, is you can get insulin resistant in the liver to the suppression of gluconeogenesis while you maintain sensitivity to the effect of insulin on the-

Peter Attia: De novo lipogenesis pathway. That’s the worst outcome.

Rudy Leibel: Yes, but that’s what happens. That’s the stake in many-

Peter Attia: How is that regulated?

Rudy Leibel: … in many individuals who have issues with regard to insulin homeostasis, if you wanna describe it that way.

Peter Attia: For the listener,  what we’re basically saying is the doomsday scenario would be your muscles become resistant to the signaling of insulin, and they don’t put these GLUT transporters up there, and you don’t bring glucose into your muscles …

Rudy Leibel: Okay, but why that happens, actually, in other words, what is it about becoming obese that is actually doing something to skeletal muscle.

Peter Attia: What if it’s the reverse?

Rudy Leibel: It may be. Again, this is an area of somewhat hot debate, but one possibility, I guess, is that  there’s something that happens to adipose tissue when you store whatever for that individual is in excess amount of lipid that’s producing another molecule, or some other mechanism that by which muscle is effected with regard to its insulin sensitivity.

Rudy Leibel: The other possibility, which I think, again, many people think is at least partly relevant, is that when you increase the amount of lipid in your adipose tissue,  you also increase the amount of lipid in your muscle, the fat that’s in your muscle, actually, the marbling of your own muscle. That itself has an effect on glucose homeostasis. There’s a whole …

Peter Attia: What does Gerald Shulman think of this? Doesn’t he have an idea that it starts in the liver? Isn’t that his view?

Rudy Leibel: Gerald Shulman has done a lot of work on the mechanism by which insulin affects glucose transport in muscle. I don’t wanna speak for him, in terms of what he thinks about this, but he certainly is one of the people who, I think, has advanced the field, in terms of understanding why, for example, ambient fatty acids seems to suppress glucose uptake in muscle. This was originally described by Randle

**Shulman and insulin resistance**: [The pathogenesis of insulin resistance: integrating signaling pathways and substrate flux](https://www.jci.org/articles/view/77812) (Samuel and Shulman, 2016) [2:18:45]

Peter Attia: Just to be clear, that’s not Randall, the patient?

Rudy Leibel: That’s correct. Not that Randall.

Peter Attia: You didn’t know shit about …

Rudy Leibel: Right. It’s spelled differently,  also.

Rudy Leibel: What Gerald Shulman has done to advance our understanding of a very, I think, compelling mechanism by which high levels of ambient fatty acid themselves might suppress insulin signaling. Some of that fatty acid could, in fact, come from lipid that’s stored in the muscle, as opposed to lipid or fatty acids that are in the circulation.

Peter Attia: … but there are these two different phenotypes, right? When you look at Cahill’s 40-day fasted subjects, their free fatty acids were through the roof. Their insulin was very low. Their glucose was very low, their ketones were very high.

**Cahill’s starvation study**: [Liver and kidney metabolism during prolonged starvation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC535723/) (Owen et al., 1969) [2:19:45]

**Cahill’s insulin infusion, noted in**: [Chapter 26 of Cerebral Metabolism and Neural Function: Alternate Fuel Utilization by Brain](https://coconutketones.com/wp-content/uploads/2016/10/CahillGF_CerebMetabolism.pdf) (Cahill and Aoki, 1980) [2:19:45]

**Cahill’s insulin infusion experiment**: Metabolic effects of insulin, glucagon, and glucose in man: Clinical application (Aoki and Cahill, In Endocrinology, edited by DeGroot et al., p. 1843, New York: Grune and Stratten, 1979) [2:19:45]

Peter Attia: It’s interesting to know, would you call them insulin sensitive or insulin resistant, right … because, probably, if you challenged them with glucose immediately, they would have hyperglycemia. Physiologically their muscles probably would, in the short moment, say, “hey. I don’t want this stuff … “

Rudy Leibel: Right.

Peter Attia: …”Save every gram of that for the brain,” but, presumably, if you re-fed them carbs for three days, they’d probably be as insulin sensitive as they’d ever been.

Rudy Leibel: Right.  This is one of the reasons why … I think you’re right, but I think, maybe, what Schumann or Randall would say is that the reason for the lack of response to transportive glucose is that the system has now been down-set by virtue of the high ambient free fatty acids, and it may take some time to-

Peter Attia: Interesting. You’re thinking that could be the short term signal.

Rudy Leibel: Correct. That takes time. That’s why, again, I don’t do this for a living, you would know this … why people are encouraged not to restrict their carbohydrates prior to having a glucose tolerance test, for example …

Peter Attia: Right.

Rudy Leibel: … because you can manipulate the system in a way that you just mentioned.

Peter Attia: Rudy I could sit here and talk about this stuff all night long, but your wife will probably be pissed off that I kept you here all night. Maybe not. Maybe she’s actually enjoying the fact that you’re-

Rudy Leibel: Maybe she’s glad I’m here.

Peter Attia: Yeah. This has been super interesting. You’re really one of the most thoughtful people I’ve ever spoken to on this topic, and I think there are a lot of areas where we don’t necessarily see eye-to-eye clinically. Which, again, that sounds like a much more harsh statement than it is. I just think we look at the world a little differently on some level, but …

Rudy Leibel: Yeah. I’m a hammer.

Peter Attia: You’re a hammer looking for a nail.

Rudy Leibel: Just saying.

Peter Attia: I’m kind of a general contractor, looking for everything in sight. I think it’s interesting. I think your FTO example is a great example. If I were tackling this problem, and I’m glad I’m not, I’d be wanting to understand the environmental trigger. Is it the cigarette that’s causing lung cancer? You’re trying to solve a different problem, which is, ”  why is that only some people get lung cancer when they smoke,” and those people, before the adage of, the invention of cigarettes, would’ve never got lung cancer, but now that these cigarettes are here, probably can’t do much about it. Let’s figure out who they are.

Rudy Leibel: Not just for that reason. Just as an intellectual question, I find it very intriguing … but knowledge of whatever would lead a person who smokes not to get lung cancer, it would be very nice to know what that is.

Peter Attia: Yep.

Rudy Leibel: That …  whatever that biology is for many, many reasons, not just related necessarily to lung cancer.

Peter Attia: Yeah.

Rudy Leibel: I see the issue of the consequences of genetic variant very prevalent in the population which predisposes some individuals to the environmental consequences, and others not. If we knew what that mechanism is, there’s no reason to believe that, at some point, we might not be able to manipulate it. Not only in service of those who have the genetic variant, but others who might benefit from the knowledge of the circuitry.

Peter Attia: Yep. That makes a lot of sense. You’ve given me some great pearls, over the years. I remember, I think it was one night at dinner, when you, me, Mike Rosenbaum were playing patty cakes, and it somehow came out that in your 10 to 20 percent weight-reduced subjects, a little bit of T3 could overcome some of the deficit. I remember having this “eureka moment” because I was like, “wait a minute. All these patients  I see that lose weight have a reversed T3 spike. That would exactly explain why giving them T3, rather than T4, would address the problem.” You give a patient with high reversed T3, T4, you’re making them worse, but you give them T3 you can bypass it.

Peter Attia: I’m incredibly grateful to you, to your work, and for your friendship. Thank you very much for that.

Rudy Leibel: My pleasure. Thank you.

§

§

## Selected Links / Related Material

**Nutrition Science Initiative, non-profit founded by Peter and Gary Taubes**: [NuSI](https://nusi.org/) | (nusi.org) [1:00, 1:51:00]

**A gene that may predispose humans to obesity**: [FTO gene](https://en.wikipedia.org/wiki/FTO_gene) **|** ([wikipedia.org](https://www.wikipedia.org/)) [3:30, 2:02:30]

**Peter’s favorite beverage:** [Topo Chico](https://www.topochicousa.net/) **|** ([topochicousa.net](https://www.topochicousa.net/)) [4:00, 1:31:00]

**Peter’s favorite (and secret) beer**: [@peterattiamd](https://www.instagram.com/peterattiamd/p/Boc8J86h_6j/) | (Instagram) [4:30]

**Coleman and ob/ob and db/db mice**: [Douglas L. Coleman, 1931–2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4218972/) (Coleman, 2014) [28:00]

**Coleman and ob/ob and db/db mice**: [Diabetes, a new mutation in the mouse](https://www.ncbi.nlm.nih.gov/pubmed/5918576?dopt=Abstract) (Hummel et al., 1966) [28:00]

**Pull model of fuel partitioning and obesity**: [Obesity Pathogenesis: An Endocrine Society Scientific Statement](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5546881/) (Schwartz et al., 2017) [37:15]

**Rudy’s experiment that showed the db gene to be the mutant in the Zucker rat**: [Phenotype of the obese Koletsky (f) rat due to Tyr763Stop mutation in the extracellular domain of the leptin receptor (Lepr): evidence for deficient plasma-to-CSF transport of leptin in both the Zucker and Koletsky obese rat.](https://www.ncbi.nlm.nih.gov/pubmed/9032111) (Wu-Peng et al., 1997) [40:30, 1:03:00]

**Parabiosis experiment, on genetically obese Zucker rats**: [Body composition of lean and obese Zucker rats in parabiosis](https://augusta.pure.elsevier.com/en/publications/body-composition-of-lean-and-obese-zucker-rats-in-parabiosis) (Harris et al., 1987) [44:45]

**Zucker rats produced a factor that inhibited appetite but could not themselves respond to it**: [Is leptin the parabiotic “satiety” factor? Past and present interpretations](https://www.ncbi.nlm.nih.gov/pubmed/22889986) (Harris, 2013) [44:45]

**Zucker rats have a single gene mutation of the extracellular domain of the leptin receptor**: [Rat obesity gene fatty (fa) maps to chromosome 5: evidence for homology with the mouse gene diabetes (db)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC52392/) (Truett et al., 1991) [44:45]

**Mutations in the leptin receptor**: [Phenotypes of mouse diabetes and rat fatty due to mutations in the OB (leptin) receptor](https://www.ncbi.nlm.nih.gov/pubmed/8584938) (Chua et al,., 1996) [44:45]

**Review including weight perturbation studies**: [Molecular physiology of weight regulation in mice and humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2682360/) (Leibel, 2009) [47:00]

**Rudy’s experiment that showed the db gene to be the mutant in the Zucker rat**: [Phenotype of the obese Koletsky (f) rat due to Tyr763Stop mutation in the extracellular domain of the leptin receptor (Lepr): evidence for deficient plasma-to-CSF transport of leptin in both the Zucker and Koletsky obese rat.](https://www.ncbi.nlm.nih.gov/pubmed/9032111) (Wu-Peng et al., 1997) [40:30, 1:03:00]

**Humans with leptin mutations**: [A mutation in the human leptin receptor gene causes obesity and pituitary dysfunction](https://www.ncbi.nlm.nih.gov/pubmed/9537324) (Clement et al., 1998) [1:05:45]

**Humans with leptin mutations**: [Congenital leptin deficiency is associated with severe early-onset obesity in humans](https://www.nature.com/articles/43185) (Montague et al., 1997) [1:05:45]

**Humans with leptin mutations**: [Effects of recombinant leptin therapy in a child with congenital leptin deficiency](https://www.ncbi.nlm.nih.gov/pubmed/10486419) (Farooqi et al., 1999) [1:06:00]

**Leptin trial in humans**: [Recombinant Leptin for Weight Loss in Obese and Lean Adults — A Randomized, Controlled, Dose-Escalation Trial](https://jamanetwork.com/journals/jama/fullarticle/192037) (Heymsfield et al., 1999) [1:07:00]

**Leptin trial in humans**: [Leptin as a Therapeutic Agent—Trials and Tribulations](https://academic.oup.com/jcem/article/85/11/4000/2852288) (Mantzoros and Flier, 2000) [1:07:00]

**Stem-cell based approaches to obesity**: [Stem Cell-derived Hypothalamic Neurons in the Elucidation of the Pathogenesis of Human Obesity: A New Frontier](https://2017.obesityweek.com/schedule-overview/keynote-speakers/) | Rudy Leibel (obesityweek.com) [1:15:30]

**Stem-cell based approaches to obesity**: [PC1/3 Deficiency Impacts Pro-opiomelanocortin Processing in Human Embryonic Stem Cell-Derived Hypothalamic Neurons](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5312251/) (Wang et al., 2017) [1:15:30]

**Maintenance of reduced body weight in humans**: [Models of energy homeostasis in response to maintenance of reduced body weight](https://www.ncbi.nlm.nih.gov/pubmed/27460711) (Rosenbaum and Leibel, 2016) [1:19:00]

**Peter explaining respiratory quotient and his experience in a metabolic chamber**: [Peter Attia – An Advantaged Metabolic State: Human Performance, Resilience & Health](https://www.youtube.com/watch?v=NqwvcrA7oe8) | IHMC (youtube.com) [1:22:30, 1:25:00, 1:29:15]

**Diabetic mothers and childhood obesity and diabetes**: [High blood sugar during pregnancy ups risk of mother’s type 2 diabetes, child’s obesity](https://www.nih.gov/news-events/news-releases/high-blood-sugar-during-pregnancy-ups-risk-mothers-type-2-diabetes-childs-obesity) | NIH (nih.gov) [1:41:30]

**Body weight and insulin resistance**: [Respective Contributions of Maternal Insulin Resistance and Diet to Metabolic and Hypothalamic Phenotypes of Progeny](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3234171/) (Carmody et al., 2011) [1:43:15]

**Weight perturbations and leptin**: [Weight Perturbation Alters Leptin Signal Transduction in a Region-Specific Manner throughout the Brain](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0168226) (Morabito et al., 2017)

**NuSI study Rudy Leibel was involved with**: [Energy expenditure and body composition changes after an isocaloric ketogenic diet in overweight and obese men](https://academic.oup.com/ajcn/article/104/2/324/4564649) (Hall et al., 2016) [1:51:00]

**The starvation study led by Ancel Keys in 1994-1995**: [Minnesota Starvation Experiment](https://en.wikipedia.org/wiki/Minnesota_Starvation_Experiment) | (wikipedia.org) [1:55:45]]

**Discovery of the FTO gene**: [A common variant in the FTO gene is associated with body mass index and predisposes to childhood and adult obesity.](https://www.ncbi.nlm.nih.gov/pubmed/17434869) (Frayling et al., 2007) [2:03:15]

**Shulman and insulin resistance**: [The pathogenesis of insulin resistance: integrating signaling pathways and substrate flux](https://www.jci.org/articles/view/77812) (Samuel and Shulman, 2016) [2:18:45]

**Cahill’s starvation study**: [Liver and kidney metabolism during prolonged starvation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC535723/) (Owen et al., 1969) [2:19:45]

**Cahill’s insulin infusion, noted in**: [Chapter 26 of Cerebral Metabolism and Neural Function: Alternate Fuel Utilization by Brain](https://coconutketones.com/wp-content/uploads/2016/10/CahillGF_CerebMetabolism.pdf) (Cahill and Aoki, 1980) [2:19:45]

**Cahill’s insulin infusion experiment**: Metabolic effects of insulin, glucagon, and glucose in man: Clinical application (Aoki and Cahill, In Endocrinology, edited by DeGroot et al., p. 1843, New York: Grune and Stratten, 1979) [2:19:45]

§

§

## People Mentioned

- [Harvey Karten](https://profiles.ucsd.edu/harvey.karten) (neuroscientist) [8:00]
- [Walle J.H. Nauta](https://en.wikipedia.org/wiki/Walle_Nauta) (neuroanatomists, hypothalamus) [8:45]
- [Jules Hirsch](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(15)00112-9/fulltext) (a pioneer in obesity studies, Rudy’s mentor, [recently passed away](https://www.nytimes.com/2015/07/30/science/jules-hirsch-pioneer-in-obesity-studies-is-dead-at-88.html)) [18:30, 31:30, 1:18:30, 2:01:45]
- [Jack Crawford](https://news.harvard.edu/gazette/story/2006/05/john-douglas-crawford-ii/) (body fat and puberty, mentor to Rudy) [19:45]
- [Rose Frisch](https://en.wikipedia.org/wiki/Rose_Frisch) (leptin, anorexia and weight loss) [20:00]
- [Douglas Coleman](https://www.jax.org/give-to-jax/make-a-gift/helix-fund/signature-societies/douglas-coleman-society/douglas-coleman-bio#) (helped Rudy identify a mutation in the ob and db gene in mice) [24:00, 49:30]
- [Irving Faust](https://www.ncbi.nlm.nih.gov/pubmed/?term=Faust+IM%5BAuthor%5D) (worked with Jules Hirsch) [33:00]
- [Lois M. Zucker](https://en.wikipedia.org/wiki/Laboratory_rat#Zucker_rat) (Zucker rats) [35:00]
- [Theodore F. Zucker](https://en.wikipedia.org/wiki/Laboratory_rat#Zucker_rat) (Zucker rats) [35:00]
- [Gary Truett](https://www.semanticscholar.org/author/Gary-E.-Truett/4224728) (student of Rudy’s, mapped position of the Zucker gene) [41:00]
- [Jeff Friedman](https://www.rockefeller.edu/our-scientists/heads-of-laboratories/1163-jeffrey-m-friedman/) (worked with Rudy on project to pinpoint leptin) [50:45]
- [Nate Bahary](https://twitter.com/gioncologist?lang=en) (used glass needles to dissect chromosomes in search of leptin) [53:20]
- [Jeff Flier](https://en.wikipedia.org/wiki/Jeffrey_Flier) (21st dean of Harvard Medical School) [1:04:00]
- [Streamson Chua](https://www.einstein.yu.edu/faculty/10242/streamson-chua-jr-/) (believed that leptin was actually more important in its deficiency state as a signal to the brain that you didn’t have enough energy to survive) [1:04:00]
- [Mike Rosenbaum](https://www.columbiadoctors.org/michael-rosenbaum-md#about-michael-rosenbaum) (change to metabolism during weight loss) [1:18:30, 2:23:00]
- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (sent Peter the derivation of the Weir coefficients) [1:23:00]
- [Leslie Sim](https://www.mayoclinic.org/biographies/sim-leslie-a-ph-d-l-p/bio-20054596) (studies anorexia) [1:48:00]
- [Lori Zeltser](https://www.ihn.cumc.columbia.edu/profile/lori-zeltser-phd) (experiments on hypothalamic manipulations that can lead to an anorectic type mouse phenotype) [1:49:30]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (starvation experiments) [1:55:45]
- [Mark McCarthy](https://www.ndm.ox.ac.uk/principal-investigators/researcher/mark-mccarthy) (identified the FTO gene) [2:03:15]
- [Gerald Shulman](https://medicine.yale.edu/bbs/people/gerald_shulman.profile) (insulin) [2:18:30]
- [Philip Randle](https://en.wikipedia.org/wiki/Philip_Randle) (ambient fatty acids suppress glucose uptake in muscle, [Randle cycle](https://en.wikipedia.org/wiki/Randle_cycle)) [2:19:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (40-day fast study) [2:19:45]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/12/rudy-leibel-2017-pic-2x1-500x420.jpeg)

##### Rudolph Leibel, M.D.

Dr. Leibel’s research focuses on the genetics of obesity and noninsulin-dependent diabetes. His laboratory has mapped, cloned, and identified mutations in the obese and fatty genes in rats, mice, and, more recently, in humans. The obese gene encodes leptin, an adipose derived hormone responsible for regulating body weight, whereas the fatty gene encodes the leptin receptor. Currently, his research group is defining the physiological bases by which this and related signaling networks regulate body size and composition. For example, changes in leptin production following reduction in body fat might play a role in the metabolic changes that accompany weight loss in humans. Dr. Leibel’s laboratory is also working to isolate additional rodent genes that influence body weight and the susceptibility to noninsulin dependent diabetes mellitus in the context of obesity. Laboratory members have extended their genetic studies to search for similar obesity and diabetes related genes in human families. [[columbia.edu](https://www.ihn.cumc.columbia.edu/profile/rudolph-l-leibel-md)]