# #226 ‒ The science of happiness | Arthur Brooks, Ph.D.

**Source:** [https://peterattiamd.com/arthurbrooks/](https://peterattiamd.com/arthurbrooks/)

---

Arthur Brooks is a social scientist, professor at Harvard University, a columnist for The Atlantic, and the bestselling author of [From Strength to Strength](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=). In this episode, Arthur explains how intelligence changes as we get older, and how to take advantage of this to maximize our happiness and success. He distills truths about the meaning of happiness and its three main components: enjoyment, satisfaction, and purpose. He goes into detail about many of the keys to a happy life, including the importance of cultivating virtuous relationships. On the flip side, Arthur warns of the dangers of social comparison, “success addition,” and the four worldly idols—money, fame, power, and pleasure—that drive many of us. Additionally, Arthur provides examples of exercises that can guide one in the right direction, overcome fear, and cultivate habits that can lead to a happier life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/arthurbrooks/the_Drive_public.png)

Play

#226 ‒ The science of happiness | Arthur Brooks, Ph.D.

1x15s30s

0:001:40:05

## We discuss:

- Insights from Arthur’s career as a professional French horn player [2:15];
- A radical shift away from music to a Ph.D. in quantitative policy [12:00];
- Personal experience with shifting intelligence: fluid vs. crystallized intelligence [16:45];
- An epiphany from a chance encounter on an airplane that shaped Arthur’s thinking [22:00];
- The three main “macronutrients” of happiness [25:00];
- Exploring the “purpose” component of happiness [29:00];
- The importance of having a partner and true friendships [32:00];
- The makeup of a true friendship, and why men tend to struggle with making real friends [36:45];
- The “satisfaction” component of happiness and the importance of “wants management” [42:15];
- The tyranny of social comparison [47:45];
- Insights into happiness through Chinese art, and the concept of a “reverse bucket list” [51:45];
- An exercise demonstrating the importance of relationships with others and the need to work on them [55:30];
- The four main idols that drive us: money, fame, power, and pleasure [1:01:15];
- Success addiction, workaholism, and their detriment to happiness [1:04:00];
- A radical approach to overcome fear—the antithesis to love and happiness [1:14:00];
- Ancient Hindu advice for the perfect life [1:26:30];
- The end result of getting caught in the 4 idols [1:31:45];
- The complexity of happiness [1:33:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Arthur Brooks is a social scientist, Harvard professor, best-selling author, columnist at *The Atlantic*, and host of the podcast *How to Build a Happy Life with Arthur Brooks*
- He’s the author of 12 books, including his most recent book, the *New York Times* bestseller, [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- In this episode we focus the conversation on happiness
  - How we define happiness
  - Including enjoyment, sense of purpose, and satisfaction
- We also talk about friendship, companionship, and envy
- We talk about the dangers of having a success addiction
- Happiness can be a much harder concept for people to address and “fix” than many other things we talk about on the podcast, such as poor sleep, high ApoB, or low muscle mass or strength
- Arthur is so eloquent in how he talks about this complex problem, that we can all learn a lot from his words
- There are 3 books Peter has read this year that are not technical book, that have had a really profound way of getting him to think about the quality of life, and this is one of them
  - The other 2, hopefully he’ll be interviewing the authors of them as well
  - But for now we’ll focus on [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

## Insights from Arthur’s career as a professional French horn player [2:15]

- This is the first time we’re doing a repeat podcast
  - The last time we were in person and had a great conversation for a couple hours only to learn that we hadn’t turned the sound on
- They had a nice conversation about happiness, longevity, and living a prosperous, flourishing life
- Peter turned Arthur onto [Ghia](https://drinkghia.com/), which he has been drinking ever since
  - It’s nice to be able to talk about things where the company has no idea you’re promoting it (Peter pays full retail for Ghia)

- Peter went back and read [Arthur’s book](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) to prepare for this podcast
- The thing that resonates with him the most is the discussion of the 4 stages of life (we’ll come back to at the end)
  - He thinks about his transition from the 2nd to the 3rd

**Arthur’s many “lives” – starting with being a musician**

- Arthur has lived many lives, his first was a musician
- Arthur is a social scientist, he teaches behavioral science but he started in classical music
- He wanted to be the greatest French horn player in the world
- He started on violin at age 4, piano at 5, and took up the French horn at 8
- He had a natural ability for playing the French horn, and so he did it a lot
  - He did it to the exclusion of nearly everything else
- And when it came time to go to college, he had one successful run at a year in college and then became a professional musician because that’s really what he wanted to do
- At age 19 he dropped out/ was kicked out of college and went on the road as a classical musician
- He played chamber music for 6 years all over the world
- Then he went to Barcelona where he was in the symphony orchestra
- His plan was to become a French horn soloist playing great concerti of the greatest composers
  - It didn’t work out that way
- In his mid 20s he was in decline as a performer
  - His technique was getting worse
- In his late 20s he began taking college classes by correspondence
  - He finished a month before his 30th birthday
- He completed his master’s degree at night
- He finished his French horn career at 32 and started his Ph.D. in social science

**What is the arc of a French horn player and how many exceptional French horn player talents can be consumed by the world?**

- If we were talking about baseball, there are hundreds of people who can be good enough to make a living at it
- For classical musicians, there’s about a 95% unemployment/ underemployment rate in the industry
- And it’s not like professional sports, people are not getting rich
  - The great soloists, the great opera singers, the great conductors are pretty wealthy
  - But orchestra musicians are earning a middle class/ upper middle class income, but they’re not really very money motivated
- There are probably about 100 really great orchestras in the world and each one has a principal French horn player and also 4 other French horn positions
- There are a handful of other people making a serious living in playing chamber music
- There are usually about 1-2 French horn soloists in the world at any given time
  - There are not that many people making a living at it
  - And there are a lot of people who are trying, so it’s weird

***What kind of commitment was necessary to get to that level?***

- Arthur was practicing 5-6  hours a day, plus playing in every ensemble he could possibly find

> “*I was basically doing it to the exclusion of almost everything else in my life*”‒ Arthur Brooks

- It was like being an athlete where you practice as much as you can without doing damage to the musculature
  - There’s negative returns if you overtrain
  - You can get all kinds of repetitive stress injuries
- Further, in the time that you’re not actually actively practicing, you’re listening to music, you’re learning the repertoire, you’re thinking about what your craft actually is
- So the result of it is you’re doing it almost every hour of the day

***What distinguishes the best French horn player in the world from the hundredth best?***

- Mostly accuracy
- The French horn has a problem of physics, in so far as that the mouthpiece is smaller than a trumpet mouthpiece, but the tube is as long as the tuba (which is the largest of the brass instruments)
- So by physics, it should actually play in the low register, but by mouthpiece, it should actually play in the high register
- The result of that is the harmonic structure is very close together and it’s very easy to miss notes
- This is the reason why the principal French horn player in the orchestra misses a lot of notes
- It’s just really, really hard to be accurate
- The greatest, greatest, greatest, have some uncanny ability
  - It’s sort of like Nolan Ryan who was able to hit a postage stamp at 98 miles an hour of the fastball when he was 40
  - That’s the kind of difference that you get, the freakish microscopic differences
- You probably wouldn’t notice the difference if you’re not a big classical music buzz and especially if you’re not really into the French horn

***What is the typical age when a French horn player peaks?  What did Arthur notice was changing in his mid-20s?***

- Arthur peaked and declined early
- He has researched this subsequently as a social scientist
- He knew casually that brass players and classical musicians in general tend to peak in  terms of their physical qualities, their ability to dominate the instrument in their late 30s, and you start to see a little bit of drop off in their 40s and 50s
- The greatest players in the world, the greatest piano soloists will still be touring and playing beautifully in their 70s, but they’re not what they once were
- Peak usually happens in the late 30s to early 40s
  - Then it’s a slow decline
- He was declining much earlier and it had to do with a microscopic tear in on of his lips
  - This was an injury that wasn’t well known at the time
  - But surgery can repair it
- Arthur went on to something that is touching a lot more people and has more possibility of doing something positive in the world

> “*Within what seems like a tragedy at the time, there’s all kinds of opportunity*”‒ Arthur Brooks

## A radical shift away from music to a Ph.D. in quantitative policy [12:00]

**Why did you go back to night school in secret for your bachelor’s and master’s degrees?  Why were you ashamed?**

- Classical musicians think nothing else matters
- It’s more of  a cult than a profession
- Arthur’s oldest son went to Princeton and his younger son is in the Marines, those are cults too
- Arthur remembers hanging around with this group of brass players when he was probably 28, and this woman who hung out with them (also a French horn player) said, “*I’ve got an announcement… I decided I’m going to leave the business. I just got a full scholarship to the University of Miami, the medical school. I’m going to become a surgeon.*”
  - To them she quit her French horn playing career to settle for becoming a lifesaving doctor

**What did you study for your bachelor’s?**

- Economics
- Though he intended to get his degree in some area of the humanities, maybe even composition
  - He was a pretty avid composer
- When he took an economics class, it just opened his eyes
- With statistically based social sciences, he felt like he had a crystal ball
- He could see things about the world and he could actually analyze behavior in ways he didn’t even think was possible
- His mind was blown at the whole world of information, at being able to generate information
- He finished his bachelor’s degree completely by correspondence

***At what point did you formally hang up your French horn and pursue the PhD?***

- After finishing his bachelor’s, he went to the local state university at night and did a 1-year master’s degree
- At that point it was fish or cut bait, so he left music and started his Ph.D.

**Focus of his Ph.D.**

- He completed a Ph.D. on quantitative policy analysis in 4 years
- He was doing mathematical modeling and applied microeconomics for public policy
- At the same time he was working as a military operations research analyst for the Rand Corporation
  - He was doing theater level combat modeling for the Air Force
  - He was doing large scale, early artificial intelligence algorithms to link computers up together to simulate battle situations across a lot of scenarios
- He was learning a lot of math modeling
  - This was critically important for him because mathematics and statistics were a real area weakness for him
  - So it was important for him to beef up these skills

***What did you do after you finished your Ph.D.?***

- Arthur was 34 when he finished his Ph.D.
- He taught at Georgia State University in Atlanta for 3 years
- Then he was able to secure a position at Syracuse University, which for public policy is the best school in the country
- He taught public administration and economics there for 7 years
- He wrote academic journal articles, highly technical writing papers that were mathematically so complex that now at age 58, he can’t read them
  - This speaks a lot to the changing structure of the prefrontal cortex and our ability to learn and perform at different phases of life

> “*What are we good at then and what are we good at now?*”‒ Arthur Brooks

## Personal experience with shifting intelligence: fluid vs. crystallized intelligence [16:45]

**From Syracuse University he went to AEI**

- Arthur became the CEO of [American Enterprise Institute (AEI)](https://en.wikipedia.org/wiki/American_Enterprise_Institute): a think tank in Washington, DC
- A think tank is like a university without students
  - It’s completely dedicated to high quality academic research, but in the service of better public policy
- It’s one of the oldest think tanks in the world
- It was started in 1938 to pull the US and world out of the Great Depression using the tools of the American free enterprise system
- They brought together the greatest economists, foreigh policy experts, experts in health and education
- During his time as CEO there he had 300 employees and had to raise about $15 million a year in philanthropy
  - His job was like running for the Senate and never getting elected
  - For 10 years, it was an 80 hour a week CEO job (kind of a slog)

**Changes Arthur noticed during his years at AEI**

- He noticed about halfway through that his skills were kind of changing
  - He was getting worse at certain things and better at other things
  - He didn’t understand why that was
- He was getting worse at thinking up brand spanking new, clever ideas
- He was getting much better at explaining things

***He was becoming as a better teacher but worse as a classic innovator***

- When he first came to AEI, he was developing new programs and coming up with new big policy and research ideas
- About halfway through, he was noticing that he was really good at was synthesizing everybody else’s ideas and putting them together into a relatively compelling argument about how we should do things

***Fluid intelligence vs. crystallized intelligence*****: Arthur’s observations led him to questions and research on intelligence**

- It occurred to him that there was probably more to it than that, so he got to work on where this was going to lead in his own life, such that he could exploit my own strengths
- He started looking at the research on different forms of intelligence as people get older
- He read work of a lot of social psychologists who did intelligence work in the 60s-70s (and older)
  - The [work](https://www.oxfordbibliographies.com/view/document/obo-9780199828340/obo-9780199828340-0207.xml) of [Raymond Cattell](https://en.wikipedia.org/wiki/Raymond_Cattell) shows early on we have a **fluid intelligence**, which is largely our innovative capacity based on working memory where we can do a lot of things alone and come up with brand new ideas based on limited background
  - Later in life, we’re less good at that, but we’re much better at synthesizing ideas
    - We have a vast library, much less working memory, but a much better vocabulary, pattern recognition, and ability to synthesize ideas of other people which is called **crystallized intelligence**

**Characteristics of fluid intelligence**

- Fluid intelligence tends to peak in the late 30s

- - This is why a lot of classical musicians peak in their late 30s
  - It’s not just about writing mathematical formulas
  - It’s about doing a lot of things that make you great with your 10,000 hours of practice
- Fluid intelligence decline in your 40s and 50s

**Characteristics of crystalized intelligence**

- Crystallized intelligence gets better through your 40s, 50s, 60s
- It’s your teaching/ explaining capacity
  - Your pattern recognition
  - Your management of other people
- Crystallized intelligence stays high in your 70s and 80s
- When Arthur realized this, he started making a plan to exploit crystallized intelligence for the rest of his career
- This led him to quit his CEO job to do what he does now
  - Which is writing, speaking, teaching, using his creative capacities to mix ideas together about happiness (his main area of focus and research)

![](https://peterattiamd.com/wp-content/uploads/2022/10/f1-arthurbrooks-1024x702.png)

**Figure 1.** Theoretical description of the age patterns of fluid intelligence and crystalized intelligence. [[source](https://ebp-projects.isr.umich.edu/P01/papers/Willis2014.pdf)]

**Peter says that the first time he encountered these terms (fluid and crystallized intelligence) was about 4 years about in an** [***Atlantic*** **piece Arthur wrote**](https://www.theatlantic.com/magazine/archive/2019/07/work-peak-professional-decline/590650/)

- When Arthur first wrote that piece, he was doing this research for himself
- That article was one of the 50 most read articles of the entire year of all publications in the world
- So he wrote it up in a [book (*From Strength to Strength)*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) over the next couple of years (published in February of 2022)
- The terms fluid and crystallized intelligence were coined by [Raymond Cattell](https://en.wikipedia.org/wiki/Raymond_Cattell)
  - He was a social psychologist
  - His findings were replicated
- Then social psychology expanded the neuroscience literature
- Neuroscientists have started to replicate these 2 curves and have found some of the neurophysiological reasons for these strengths

## An epiphany from a chance encounter on an airplane that shaped Arthur’s thinking [22:00]

**A story about an older man from the opening of Arthur’s Book,** [***From Strength to Strength***](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

- In an [Atlantic article](https://www.theatlantic.com/magazine/archive/2019/07/work-peak-professional-decline/590650/), Arthur tells the story about a time when he was on a long flight from LA to DC, working on his laptop
- He heard a guy tell his wife that he might as well be dead
  - His wife was consoling him, he was very disconsolate
  - Arthur was thinking this was somebody who hasn’t lived up to his own personal standards, he hasn’t had the opportunities or pursued the education or started the business and now it’s kind of near the end
  - He could tell by their voices that they were elderly
- Arthur was curious and when the lights went on at the end of the flight, everyone stood up and he turned around
- It was one of the most famous men in the world
  - He was not controversial, not some actor or politician
  - This is somebody who was justifiably considered a hero by many millions of people for his achievements, his accomplishments in the 1970s, 1980s, and before that as well
  - Evidently, he is living a life of regret because those times are long past

> “*I got this window into his soul*”‒ Arthur Brooks

- When they were leaving the plan and the pilot is thanking everyone for flying United he sees this guy behind Arthur, recognizes him and says, “*Sir, you’ve been my hero since I was a little boy*”
- Arthur turns around and sees this guy beaming with pride and joy
  - He thinks to himself, “*Which is the real guy?*”
  - Then he has a selfish thought, “*How can I not be that first guy?*”
- At the time Arthur is about halfway through his time as a CEO
  - He thought that he would do good work, things would get better, then it would stop
  - But what does that mean?
  - What is the end goal?
  - He remembers feeling a kind of existential crisis about it
  - He was thinking about it a lot during this time
- Arthur is trying to do a lot with his life
  - He’s not going to be the hero on the plane
  - He trying to live to the max, have a contribution, achieve a lot (which has some pathologies attached to it)
    - He [writes](https://bigthink.com/smart-skills/addiction-to-success/) about this in his research about success addiction and workaholism, and the neuroscience behind those addictions
- He wonders what he can do so that the rug is not pulled out from under him such that he tells his long suffering wife (Ester) on a plane in 30 years, “*I might as well be dead*”
- This is what led to the research project that became this book

## The three main “macronutrients” of happiness [25:00]

**Define happiness**

- Arthur teaches a class at the Harvard Business School called *Leadership and Happiness in HBS*
  - It explains what happiness is and how you get it
- By the time his graduate students reach him, a lot of them are realizing that the world’s promises are empty
  - ***The money, power, pleasure, and fame that are supposed to bring you undying happiness are false promises***
  - They can be instrumental to getting what you want, but they can’t intrinsically give you the satisfaction you desire
- There is a competitive system to get into elective classes, and this one fills in 9 seconds
  - There’s hundreds of people on the waiting list for this class
- On the first day he asks students “*What is happiness?*”
- They say many things‒ “*It’s that feeling I get on Thanksgiving*”
  - “*Wrong. Happiness is not a feeling any more than your Thanksgiving dinner is the smell of the turkey. The feeling of happiness is evidence of happiness.*”
- Happiness is measured in all sorts of ways, both complicated and simple
- One thing we know of people who are really happy, they have a lot of happy feelings
  - They have a lot of satisfaction and contentment with their lives
  - They’re getting abundance and balance across 3 dimensions
- If he asked, “*Hey, Peter, what is the Thanksgiving dinner?*” Peter would say “*Well, it’s carbohydrates, proteins, and fat.*”
  - These are the 3 macronutrients of all food
- Forget lifespan, let’s talk health span and happiness span

> “*Let’s get our literal macronutrients in order for health span and let’s get our happiness span in order with the macronutrients of happiness*”‒ Arthur Brooks

***The 3 macronutrients of happiness are:***

- *1 –* ***enjoyment***

- *2 –* ***satisfaction, and***

- *3 –* ***purpose***

- *You need these in balance and abundance to be a happy person*

**More about the 3 dimensions of happiness**

- This is different from unhappiness
  - Happiness and unhappiness are not opposites, they’re different phenomena
- So we’re just talking about happiness here
- 1 – To be a truly happy person, you need to **enjoy** your life
  - And that requires not pleasure, “*it’s pleasure plus elevation*”
  - It’s pleasure plus metacognition
  - Thanksgiving dinner fills your belly and tastes good, that’s pleasure
  - But the experience that you have of consuming the Thanksgiving dinner with other people and having a memory, that can last forever, that’s enjoyment
- 2 – **Satisfaction** is super fleeting and troublesome
  - As Mick Jagger says, “*I can’t get no satisfaction*”
  - The truth is you can’t keep satisfaction
  - Arthur has participated in the literature on the problem with satisfaction
  - “*It’s the joy and reward for a job well done and a goal met. That elation from actually meeting a goal*.”
- 3 – **Purpose**, “*is meaning in life*”
  - He talks a lot about the coherence, the significance, the direction, the meaning of meaning
  - And it gets back to a lot of the great philosophy, but we can also measure it
  - He has **a few diagnostic questions** that he asks for clients who come to him who lack purpose in their life
    - Why were you born and for what are you willing to die?
    - If you can’t answer one or both of those questions, you have a serious meaning problem

## Exploring the “purpose” component of happiness [29:00]

**His kids are the one thing Peter has a real purpose for, that he would die for in a second and think nothing of.  Is it bad that he doesn’t have a higher purpose than that?**

- This depends on what the higher purpose means
- The happiest people, they all have a transcendental understanding of life
  - They have an understanding of **life bigger than themselves**
- The most miserable people, the people who lack happiness and have a lot of unhappiness, they’re focusing on me, me, me
- Philosophers talk about the “I self” and the “me self”
- The “**I self**” is outward looking
  - Its observational, sort of Zen
- The “**me self**” is reflective of the outside world
  - It has a lot to do with social comparison
  - It has a lot to do with the micro circumstances‒  my job, my money, my career, my friends, my house, my mortgage, my commute, me, me

**A transcendental understanding of life is key to a happy life**

- Because you need peace
- You need perspective
- You need to zoom out
- When the Dali Lama says, “*You are 1 in 7 billion,*” what he’s saying is not that you’re insignificant or you’re a speck
  - What he’s saying is that you need to stop focusing on yourself so you can actually get some relief once in a while
- So that might be the higher purpose, but it’s just a transcendental purpose and understanding of something bigger than yourself

**Kids**

- One of Peter’s greatest fears about aging is less about the physical changes of aging and more about the kids being out of the house
- It’s like a two-edged sword, it’s so enjoyable to have young kids around even though it’s hard
- He can’t imagine how quiet a house would be without them
- He’s not sure how enjoyable life would be when they’re gone
- Recently he posted something on Instagram that he found really depressing‒ a chart of the fraction of time that people spend with others in their life over the course of their life (shown in the figure below)
  - So the X-axis is time and the Y-axis is % spent with each entity and its various curve
  - The one that just depressed the hell out of him was time with your kids (shown in green), it plummets once they turn 18

![](https://peterattiamd.com/wp-content/uploads/2022/10/f2-arthurbrooks-1024x724.png)

**Figure 2.  Who we spend time with across our lifetime.**  Image Credit: [Our World in Data](https://ourworldindata.org/time-with-others-lifetime)

- Arthur has 3 kids, they’ve grown up
- His youngest is 19, in Spain in college
- He knows how the empty nest works
- There were times when it’s a lot of Legos on the ground and there’s a lot of chaos that comes from little kids
- He and his wife said, “*What’s it going to be like when they actually grow up and move out?*”
- It is very different, it’s very disconcerting, and it’s kind of new to them

## The importance of having a partner and true friendships [32:00]

- The key, one of the most important things for a happy life is a **partnership** with somebody who will be the last person on whom you lay your eyes as you take your dying breath

***A companionate love that is your wife‒ that turns out to be much more indicative of your happiness than actually developing and having a continuing relationship with your kids, because your kids are turning into different people every single year***

- A relationship with your kids is super fun and interesting, but that’s not actually the key
- The people who suffer the most from **empty nest syndrome**, are the one with one other bird that they don’t like very much
- One of the things he talks about with his students is the **goal of your marriage** is not passion, it’s friendship
  - You must be close friends, ideally best friends, with your spouse, such that when your kids grow up and they move away and then you have your grandkids…
- Arthur’s oldest son is married so he may have grandkids soon
- But he’s going to be with his wife (Ester) until death do us part
  - So that has to be the juice of the relationship, where the love that actually makes true happiness

> *“And love truly is the great secret to happiness*”‒ Arthur Brooks

**How do we reconcile then a person who chooses not to have a partner?**

- There are some people (introverts) who do really, really well on their own
- Loneliness is not the same thing as solitude
- Isolation and solitude are very, very different phenomena
  - They’re neurocognitively different phenomena
  - They affect the brain in different ways
- Isolation is always bad, but solitude is not
- As a matter of fact, we all need solitude at different levels
- Peter adds, “*You can be lonely in a relationship and you can be in solitude and not be lonely.*”
- Arthur agrees, one of the greatest predictors of divorce is partners who are lonely while living together
- This gets back to the big danger of the empty nest syndrome‒ “*The only thing you have in common is your kids and that one point of commonality disappears, and you’re sitting across the table blinking at each other during dinner, not talking because you literally don’t have anything to talk about*”

**Successful couples**

- It’s critically important for couples to have something in common besides their kids
  - Practicing religion together
  - Practicing interests together
  - Reading the same things
  - On the same philosophical journey together
- Arthur advises couples that they should develop philosophical interests in common
  - It’s got to be something bigger than, “*Did you change his diaper?*”
    - That’s not something you have in common forever
  - The gold standard is that your kids are like, “Ah, mom and dad are talking about [Kierkegaard](https://en.wikipedia.org/wiki/S%C3%B8ren_Kierkegaard) again,” or whatever
- The companion to this in terms of love is that for most truly happy people, as they get older the companionate part of their relationship with their spouse becomes greater while the passion part is not as high as it used to be
  - That’s healthy, normal, and actually advisable, because it’s more sustainable over the long run

**Some people are very happy and they don’t have a spouse**

- What do they have in common?
  - Very, very close, personal lifelong friends
    - These are people who know your secrets, who would take your 2:00 AM phone call, and that you talk to a lot

> “*So here’s the key, if you don’t have a spouse, you need real friends*”‒ Arthur Brooks

- Now, that doesn’t mean that if you’re married you don’t need close personal lifelong friends
- Men are horrible at real friendships
  - They’ve got lots of deal friends, but no real friends, especially if they’re really successful in business
- So you got to work on these things for sure, for a lot of reasons besides the fact that it’s just healthy and good
- You also might, at some point, be left alone if you’re widowed and you don’t want to be alone in the world under those circumstances
  - That’s really corrosive
  - One of the reasons why men do so poorly when they lose their wives to death is because a lot of them don’t have real friendships to backfill any of this need in their soul

## The makeup of a true friendship, and why men tend to struggle with making real friends [36:45]

**What differentiates deal friends from real friends?**

- This is an [Aristotelian](https://en.wikipedia.org/wiki/Aristotle) notion, believe it or not
- We do a lot of this stuff in our mathematical social sciences
- But all the things that we do in behavioral, social sciences now is we’re just exposing the ancients to empirical scrutiny
  - We’re just testing whether or not Aristotle was right, which he always is
- Aristotle wrote a lot about friendships and the escalating levels of friendship in terms of the satisfaction and virtue they bring to our lives
- At the lowest level are **friendships of transaction**
  - These are friendships where people work together
  - For example, you’re a shirt manufacturer and you’ve got a guy who sells you cloth
  - You’re probably really friends; you like him, he likes you
  - You take care not to offend each other
  - But if you stop making shirts, you’re probably not going to continue that relationship
- Above that are **relationships of admiration or beauty**, where you admire each other
  - That’s a really good thing too, but that’s dependent on a particular quality
- The perfect friendship is the **friendship of virtue**
  - It’s just inherently satisfying
  - You like being together
  - Frequently, it’ll revolve around a third kind of useless thing, like baseball or building birdhouses or whatever
  - And it’s that third thing that is the focus, but what you’re doing in parallel is developing a very beautiful friendship, a very positive link
  - These real friendships are intrinsically satisfying and they’re frequently focused on the cosmic third thing
  - It doesn’t have to be useless, one of Arthur’s closest friends is in Atlanta, and they have the same religion
    - They talk about that a lot
    - Their discussions about that are quite deep
    - And he also wants to know what’s going on with my marriage and my kids
    - The bottom line is he knows my secrets

***What is it about men that makes it harder for us to have those really deep friendships? [38:30]***

- Peter notes that his mother has many deep friendships but he doesn’t think his father has even 1
- There’s some generational differences between men and women, and there are probably some intrinsic differences as well
- The generational differences largely have to do with the fact that in conventional family setups, the dad was super hard working
  - He probably was busting his pick all the way through your childhood
  - He put you through college
  - And he knew that he was gone all day and that if he went down to goof around with his buddies after work, he was stealing from his family, and so he came home

***The truth was that his intimate relationships were in his family and his business relationships were at work, and there was a firewall between the two such that he had adequate time to spend with his family***

- So that was a very traditional situation

- Meanwhile, the mom was making sure that you kids were properly brought up and you had friends, and she knew your friend’s mothers, and the result was that she was reinforcing friendship relationships and therefore getting better at them

**The distressing thing is that friendship is a skill that requires practice**

- It’s like a muscle and it will atrophy
- You can get worse and worse at friendships
- Arthur will meet these 60 year old guys (just a little older than he is), and they’ll be like, “*What do you want me to do, call up some other dude and ask for a play date?*”
  - They don’t know how to do this
  - They haven’t had a real friend since college
  - And ever since then, they got married and had a family and worked really, really hard, and now they’re lonely

***The answer is, you have to actually learn how to make and maintain friends, real friendships***

- And that’s a skill that a lot of men lose because of our traditional social circumstances

**Example case:** ***What do you say to the 60-year old guy who is divorced (or a widower), his kids are grown up, and he hasn’t had an intimate friendship with somebody in 40 years?***

- This is not easy, says Arthur
- You have to do the work like anything else
- We know that there’s enough emotional plasticity in the brain, and that we can learn all kinds of new skills
  - People can’t be as good playing the cello starting at 70 as if they started at 7, we know that to be a fact
  - But you can get plenty good at stuff, and that includes social skills, but you have to be committed to doing the work
- It’s going to take time
  - It took your wife years and years and years and years to build up her friend group
- You actually have to start putting in the work
  - 1 – That has to do with actually making yourself available and vulnerable to other people
  - 2 – That means actually hanging out with other people and taking the time
  - A lot of guys will be like, “*I don’t want to go have dinner with some guy*”
  - 3 – Well, you got to go have dinner with some guy, and you actually have to ask that other guy questions about his kids and be interested in that other person
- This sounds obvious, but these are skills that a lot of men have lost or never really cultivated over the course of their lives
- Arthur has been coaching people on this now for a couple years, since this research started to get some prominence
  - You can go through these basic social skills and they’re sort of mystifying to a lot of guys
  - But once they do it, he’s seen case after case of amazing progress from people older than him

## The “satisfaction” component of happiness and the importance of “wants management” [42:15]

**Why is satisfaction included when it is so fleeting?**

- Peter cannot think of a single goal (including ones that took years), where the movement he achieved it he wasn’t thinking about the next goal in 5 minutes
  - That’s a depressing thought
- Arthur replies, “*Well, you’re not a typical case, Peter. And part of the reason is because you’re doing an unusual and an unusually difficult success-oriented thing. Not only are you working for your own success, you’re working for your client’s success. You’re an addict for your success and you’re an addict for other people’s success*.”
- For the typical person, they are not thinking about their achievements in exactly the same way or the same scale as Peter
- Most people have sources of satisfaction, which is a reward for getting to the end of the day
  - It feels like a real reward to get through the week and to get to Saturday and to be able to relax
  - Those are real sources of satisfaction
- You can blow that up to the point where your version of Saturday is some huge business milestone
  - For example, your podcast now has 200,000 weekly downloads
  - This is just so out of proportion to the ordinary experience
- Now, that doesn’t mean that the ordinary person can master satisfaction and get it in a reliable way either
- We all fall prey to the problem of, “*I can’t keep no satisfaction*”, and there’s a reason for this
- It is extremely joyful to be rewarded, to achieve a goal, even a little goal
  - Our brains light up like Christmas trees
- We all understand [dopamine](https://en.wikipedia.org/wiki/Dopamine) these days
  - Dopamine of course is a neuromodulator, not of pleasure, but of anticipation of reward
  - Arthur adds, “*And what it does is it says, you’re going to get satisfaction if you get this thing and you’re going to get it forever. Dopamine is a liar. Mother Nature’s a liar. She’s horrible. Mother Nature basically says that new car smell, it’s going to last forever. And you always believe it, which is why we do what we in social science call, get on the hedonic treadmill.*”
  - Hedonic means feeling, and the treadmill is obviously a metaphor, so we can run and run and run and run, but it moves against us
  - We think we’re going to get satisfaction and we’re going to keep it, and we actually don’t, so we run for the next one
- Now, fortunately, ordinary people get a next Friday and a next Friday and the next Friday
- But if you’re doing this and your main objective is the next big financial milestone, something out of proportion to the ordinary human experience, then it becomes quite tyrannical
  - It becomes something that you really can’t keep up with
- There’s a reason that Mother Nature does this, every biological and even emotional process is subject to **homeostasis** (in which we go always back to our baseline)
  - If you’re on the treadmill this morning for good cardiovascular health and you want your pulse to be at 135 or 140, you don’t want it to be there a week from now, because you’d die
  - With homeostasis, in 15 minutes or 30 minutes after you get off the treadmill you go back to your baseline pulse rate
  - That’s for a good and proper health
- The same thing happens emotionally
  - If you get elation from a job well done, it’s going to leave so that you can be ready for the next set of circumstances
  - It’s going to go away very quickly
  - That’s why you can’t keep no satisfaction
  - It’s so that you won’t be just staring at the delicious berries on the bush with joy in the Pleistocene while the saber-toothed tiger is sneaking up behind you and you’re not aware of it

***You need to be ready for the next circumstantial whatever’s going on in your life, and that’s how homeostasis works. That’s why you can’t keep no satisfaction.***

- A life without those moments of satisfaction is dull and it’s gray, and that’s one of the key parts of major depressive disorders called [anhedonia](https://en.wikipedia.org/wiki/Anhedonia)
  - Anhedonia means the inability to get this feeling of satisfaction and the anticipation of the reward
- You need satisfaction, but the paradox is you can’t keep it

**The need to stop managing your haves and start managing your wants [47:00]**

- One of the things that Arthur talks about is for people like Peter, who has this outsized understanding of what satisfaction is going to be, is how you can crack that code, how you can dominate the matrix in a different way

***Stop managing your HAVES and start managing your WANTS***

- In other words, your satisfaction is what you have divided by what you want, and you need to manage the denominator of your satisfaction fraction, as opposed to the enumerator
- Full-on **wants management** can be a game changer for a guy like Peter, for anybody for that matter, but it’s a less serious issue for a lot of people
- Arthur predicts that without a wants management strategy, Peter will be running from thing to thing to thing
  - And as your haves go up, your wants will go up by more
  - And paradoxically your satisfaction will decline, which pulls down your overall happiness

## The tyranny of social comparison [47:45]

**How much of the wants deals with comparison versus intrinsic need to one-up yourself?**

- Take Peter for example, a great source of satisfaction in his life has historically come, from athletic achievement
  - When he was a cyclist, it was certain milestones he wanted to be able to hit
  - When he was a marathon swimmer, it was certain swims he wanted to be able to do
  - Believe it or not, there’s less comparison to others in some of those things, depending on how you define your metrics
  - You might say, “*I want to be able to climb* [*Mount Palomar*](https://en.wikipedia.org/wiki/Palomar_Mountain) *in a certain amount of time,*” which is a long climb (20 miles or something)
  - Those don’t feel like they’re heavily dependent on comparison to others
  - But yet there are a number of other things where you can’t ignore what’s happening to others
    - This could be income or some other measure of professional success
    - They joked about the idea you could literally be worth $100 million, but if your peer group is worth a billion, you might actually find yourself feeling poor
    - It makes no sense to those of us that are miles beneath that

Peter asks: “*But how do you untangle those two types of objects of satisfaction? One that is purely intrinsic, one that is pure comparator, and yet both of whom could easily put you on a hedonic treadmill? Is there a difference?*”

- Arthur points out, “*They’re in a hierarchy of what will bring you enduring satisfaction*”
- Even when you are comparing Peter with Peter, Peter time zero with Peter time one, that’s still a tyranny
  - It’s just not as bad a tyranny as comparing yourself with somebody else
  - Such as counting your social media followers‒ I don’t care if I have 200,000 downloads, as long as I have more than so and so…
- Peter notes, “*The problem with the former is whether it’s playing something on the French horn or swimming, those tend to rely on (going back to)* ***fluid intelligence****.  What we’ve just established, that that’s probably going to peak in your 30s, so whether it be athletic achievements or whatever, they’re probably going to start going down.*”

**The tyranny of social comparison**

Arthur agrees and adds, “***There is nothing good about social comparison***”

- We do it because we have to, to understand who we are and where we’re going
- We’re part of a society, so there’s a natural fabric of comparisons that are happening all the time, but actually trying to understand your own self worth in comparison to other people, is really the worst tyranny
  - It leads to **envy**
- [Joe Epstein](https://en.wikipedia.org/wiki/Joseph_Epstein_(writer)) who’s the great essayist says, “*Envy is the only deadly sin that’s not even fun*”
  - It’s just misery
- Arthur’s dad was a really funny guy, he used to joke, “*It’s not enough to win, son, your friends have to lose too, right?*”
- It’s horrible because it actually tears other people down
- In [Dante’s *Inferno*](https://en.wikipedia.org/wiki/Inferno_(Dante)), down at the bottom of Mount Purgatory that he finds Satan, and Satan is actually half frozen in a block of ice and twisting in agony in this ice and he’s keeping the ice solid because of the wind from his wings where he is fruitlessly trying to get away and is in such agony he doesn’t even notice the narrator of the *Inferno* going down to the bottom of Mount Purgatory

> “*This is analogy, envy isn’t fire. You’re frozen, it’s awful.*”‒ Arthur Brooks

- Envy is so bad there are 2 commandments against it
- 2 types of comparison‒
  - 1 – When you’re comparing yourself with yourself, that’s just looking for progress
  - 2 – Comparing yourself to others
- For #1, mathematicians will say that all of happiness is in the first derivative
- Progress, off the baseline is what you want, and that’s really good
- The problem is that’s insidious too, because that’s also on the treadmill

> *“The true master will be getting intrinsic enjoyment from the thing that she or he is doing, and that’s the goal that we should all be going for. “ —Arthur Brooks*

##

## Insights into happiness through Chinese art, and the concept of a “reverse bucket list” [51:45]

***The way to get intrinsic enjoyment in what you’re doing is through “wants management”***

- Arthur likes the metaphor of, instead of adding brush strokes to the canvas of your life, start thinking of your life as a sculpture where you have to chip away until you find the true Peter

**Arthur’s experience in the National Palace Museum in Taiwan illustrates the art of chipping away**

- This houses greatest collection of Chinese art and artifacts in the world, from the paleolithic into the present
- Never go to a museum by yourself because you’ll remember nothing
- Go with somebody who will show you 10 things
- Arthur hired a guy for this; he was a philosopher and expert in both Eastern and Western Art
- Arthur was looking at this 2 ton block of Jade, carved intricately into a village scene
- He remarked, “*Even if I’d never seen any Chinese art in person and I were not in Taiwan, if I were in Dayton right now, I’d know this is Chinese. How?*”
- His guide replies, “*Oh, it’s just the whole philosophy is different between Western and Eastern art.*”
  - Western art uses the metaphor of starting with nothing and then creating something
  - In Eastern art, the idea is starting with everything there and chipping away until you reveal it
- Now, this is true in music too
- Arthur has studied [Hindustani classical music](https://en.wikipedia.org/wiki/Hindustani_classical_music)
  - For example, [Raga](https://en.wikipedia.org/wiki/Raga)
- He studied [Tabla](https://en.wikipedia.org/wiki/Tabla), which is the North Indian classical drumming
  - The ensemble will be as small as it needs to be, such that nothing is extraneous
- Whereas in a Western orchestra, a symphony orchestra, there’s 85 people cranking at a hundred decibels
  - Such that in the east they’ll say, I can’t even hear the music of a symphony orchestra, because there’s too much going on
- It’s the same kind of metaphor
- The first part of your life is usually a canvas
- By the time you’re 45, if you’re successful person, that canvas is full
  - It’s like a [Jackson Pollock](https://en.wikipedia.org/wiki/Jackson_Pollock), add one more brush stroke and it probably gets worse
  - It’s just dense and dark at that particular time

***You’ve got to move to the metaphor of the block of Jade that you chip away until you actually find the beautiful thing that’s in you***

**The goal for the second half of life (certainly after 45 years old) is each year having less**

- Each year, getting rid of more relationships that are extraneous, more possessions, more ambitions, more experiences
- A practical way of doing this is with a bucket list
- Arthur is a very ambitious guy
  - He’s gone from career to career, he tried to do a lot with his life

> “*I had a bucket list, all the things that I wanted.  All it did would make me feel like a loser.*”‒ Arthur Brooks

- It’s like all these things that are unfulfilled
  - It kept him fired up, to be sure
- But now he has a **reverse bucket list**, where he makes a list of all of his worldly cravings and ambitions
  - And he might get them and he might not
- He’s making a conscious metacognitive commitment to not be attached to the things on that reverse bucket list
- He’s not attached to his opinions in the same way that he was, my political views
  - Or political views
  - Or ambitions that will show him that he’s Mr. Big along the way
- Arthur adds, “*It might happen, it might not happen. But when I make a commitment consciously to detach myself from those things, it’s like chipping away*.”

***It’s very, very effective for helping you with a wants management strategy, such that you can have a big fulfilling life that’s enviable by any outward standard, but at the same time, not be chained to it in this insidious success addiction that brings so many successful people so much unhappiness***

## An exercise demonstrating the importance of relationships with others and the need to work on them [55:30]

**A hypothetical normal guy wants…**

- He feels he can’t be happy until he gets a promotion, and once he gets there, it’s going to be great
- Or he just wants to pay off his mortgage, right now it’s a bit of a chain
  - Once the mortgage is paid off, he will be able to take off a month every summer and go anywhere
- Peter notes, “*When you get all those things, you’re not going to feel that much different for very long. But more importantly, how would you spare him the agony of spending the next 5 years pursuing that only to find out he’ll be right where he is now?*”
- There is **an exercise** Arthur does with his MBA students, they are on average 27-28 years old
  - He does the same exercise with people who are his age (58)
  - Peter is 49
- Imagine yourself in 5 years; you’re 54 years old
  - You’re going to be in really good health
  - You’re going to be working really hard
- Okay, now, imagine that you’re happy
  - You know what it means when you’re happy; you know how it feels when you’re happy
- Put in order the 5 things in your life that explain why you’re most happy, in order and think about it carefully
  - It’s not the stuff that you *wish* would make you happy
  - It’s not the things that *might* make you happy
  - It’s not the things that never have, but *could* somewhere make you happy
  - It’s the things that you really realistically know *will* make you happier in 5 years than you are today, in order
- Arthur predicts, “***I guarantee you that 1, 2,and 3 are going to be about your relationships. And only the bottom of the list is going to be about human achievements.***”
- Next question‒ what’s your strategic plan for aggressively managing 1, 2, and 3 as opposed to leaving them up to chance?
- How much of your time are you spending on 4 and 5 and even things that are not on the list as opposed to 1, 2, and 3?

***What is your strategic plan for fortifying your friendships, your marriage, your spiritual walk, the relationships with your children, your relationships with your parents, all that stuff?  Those are the biggies.***

- That’s how you think about it
- Say you got the promotion
  - Congratulations
  - You’ve got extra money
  - You might say, that’s a good way for me to have better relationships because I’ll be able to go out of town with my family
- Do you really think that that month away is going to be the game changer for you to have the perfect marriage?
- Or should you be thinking, great if you get the promotion, more power to you
- Do you think you should be thinking more aggressively and strategically about **how to improve your marriage today**?
  - How can you improve your marriage today?
  - It probably has a lot more to do with paying attention to your wife
  - It probably has a lot more to do with actually trying to get interested in many of the things that she’s interested in
- It’s not rocket science, we actually know how to do this
- But if it turns out to be that mystifying, maybe get some help

> “*Manage the things that really will be what you know will bring you the greatest happiness.  Don’t leave those things up to chance*.”‒ Arthur Brooks

**What fraction of people have enough introspection to come up with that list?**

- Peter notes that 1, 2, and 3 have to do with your physical and emotional health, and if that’s out of order then nothing else really matters
- He asks, “*Do you get the sense that when you pose this question to your students, that all of them are able to arrive at that conclusion?*”
- It depends on how deeply seriously they take the question
- If you ask it in a breezy, informal way, half the students will have these **extrinsic motivations** about money, power, pleasure, and fame
  - And half of them will have **intrinsic motivations** about relationships and love
- But if you ask them to think very, very deeply about it, almost all of them wind up in the intrinsic category of love and relationships
- Usually the top, especially for people in their late twenties is their romantic lives
  - The second is their family and friends, this is a big category.
  - The third is that they want to have children
    - They don’t know when, and they don’t know how, but that’s something that they want

**Put in the work**

- You need to be focusing strategically on treating your romantic life, the way that you would a startup
  - With the same seriousness
  - You need to be putting in the time, the work
- Arthur talks with his students about actually how to do that
  - What the barriers typically are
  - There’s a lot of science and there’s a lot of good practices behind that
- And when you ask them to do the work, they will focus in on those 3 areas
- Now, if you say, “*Why weren’t you paying attention to those things?*”
  - They’ll say, “*I don’t know how to manage those things. I came to the Harvard Business School to learn how to be successful in my career. I didn’t learn how to be successful in dating. So, professor, how do I do that?*”
  - And it turns out that there are ways to do that, but you have to take it seriously and put it in the work

## The four main idols that drive us: money, fame, power, and pleasure [1:01:15]

The 4 “idols”

1. Money
2. Fame
3. Power
4. Pleasure

**Fame**

- Arthur says that **fame** is a funny one because most people listening will think, “*I don’t want to be famous*”, but they want to be admired by other and have some prestige
  - That’s localized fame
  - To be known and admired by the right people
  - It’s exactly the same phenomenon philosophically and psychologically

*How much of the pursuit of this is nature versus nurture?*

- There’s a lot of research on that
- Most of the philosophy and even the evolutionary psychologists would suggest that we’re hardwired to be looking for money, power, pleasure and fame, because that gives us fitness in the mating market
- Who gets mates?
- Somebody who’s got a bigger cave, more flints, more animal skins, more Buffalo jerky piled up in the corner, and is actually known by more people than he or she knows
  - This gives you **mating fitness**
- And so the results is this would become an imperative; it would become hard wired
- There is all kinds of evidence of this
- You actually find that when people are at their base nature, when they’re being distracted, they will go for these particular rewards over much more intrinsic, more satisfying rewards having to do with love
- We see this in our consumer patterns
- Neuroscience research talks about it, how it will illuminate our brains, how it will stimulate the most dopamine
  - The most dopamine comes from these not very satisfying rewards, but nonetheless, the ones that we’re supposed to go for
- Now, here’s the key thing to keep in mind‒  mother nature wants you to pass on your genes
  - Mother nature wants Peter Attia to have a hundred kids, but of course you don’t want that
  - You want 3 and you want to have a lifelong partnership with 1 wife
  - And that means that you can’t live the hippie motto of, “*If it feels good, do it*.”
    - That is the motto of useful idiots
    - By the way, there’s other stupid mottos like, “*If it feels terrible, treat it and make it go away,*” because suffering is really important in a full life too, it turns out

> “*The key thing to keep in mind is that mother nature, she doesn’t care if you’re happy*”‒ Arthur Brooks

- We don’t select on happiness
- We select on biological fitness to mate, to pass on our genes

***And so the result is, if you follow, “If it feels good, do it,” you’re going to be chasing a whole lot of very fleeting rewards for what you think is enduring satisfaction. And you’re going to have your hedonic treadmill speeding at a terrifying velocity, and you won’t even know how to get off it. You need to get in charge of your own life, this is the bottom line.***

## Success addiction, workaholism, and their detriment to happiness [1:04:00]

**Arthur wrote in** ***The Atlantic*** **a couple months ago about** [**happiness**](https://www.theatlantic.com/family/archive/2022/03/chasing-happiness-leads-to-dissatisfaction/629427/) **and** [**success**](https://www.theatlantic.com/family/archive/2020/07/why-success-wont-make-you-happy/614731/)**, noting that the happiest people weren’t necessarily the most successful**

- Some data suggest that a little bit of sacrifice in happiness led to greater success
- People who are tremendously successful in worldly terms
  - Money, power, fame, the admiration of other people
- We can define success in different ways, but this is not what we’re talking about here
  - Having a lifelong marriage, where you’re in love with your spouse, that’s unbelievably successful
  - Believing like you have found spiritual transcendence
  - Living for the good of other people
- These people are making cost-benefit calculations systematically that are not in their own happiness favor, typically
  - They’re making sacrifices to their own happiness for some reason

**This is one of the things Arthur has looked at in his research‒ why, why, why?**

- As a social scientist, Arthur finds it really beneficial to go out and talk to humans
- He was interviewing an unbelievably successful woman on Wall Street
  - She was a billionaire from business startups
  - She had epic success after success and was very well known
- She confessed she was missing decisions, people were doubting her
- At the same time her and her husband were just kind of roommates, she had a cordial relationship with her adult kids, she was starting to get bad blood work back from her doctor, she thought she was probably drinking too much, she couldn’t sleep right
- She asked him, “*What are you doing?*”
- Arthur replied, “*You don’t need a nerd from Harvard to tell you what to do. You told me you’re a billionaire, step back from your company, take a souvenir in it, go onto the board, whatever, get to know your husband, reestablish a relationship with your kids, start to take care of your drinking problem. Become a client of Peter Attia, I don’t know.*”
- He asked her why she doesn’t do these things
- She thought about it and replied, “*I guess I’d prefer to be special than happy*”

***This is the hallmark of addiction***

- Arthur used to be a musician, he’s met a lot of addicts
  - He’s met a lot of alcoholics  and they will confess that before they got clean and sober they preferred to be high than happy
    - They all said that
  - They knew they’d be happier when they were finally beyond this thing, but wanted to get high one more time
- [William Burroughs](https://en.wikipedia.org/wiki/William_S._Burroughs) called it, “*The red, the blood in the hypodermic needle before you actually put down the plunger and it gives incredible pleasure to people*”
- They say just one more time, and that’s what that lady was saying to him

***That’s a success addiction, that is absolutely implicated in the dopamine system and that is like any other behavioral addiction that a lot of very worldly, successful people fall prey to, a lot of people listening to us***

- You have to ask yourself, “*Is this a pathology that I’m actually feeding by actually trying to get this edge?*”

**There’s a lot of literature on workaholism**

- Workaholism is an ancillary addiction to success addiction
- People work really, really hard, the payoff, the cookie that you get, the dopamine is just driving you to is‒
  - The promotion
  - The raise, the dollar
  - The compliment
  - The adulation on social media
- People that are going to be sacrificing their own happiness decisions for these success metrics

**What would the world look like today if no one was pursuing being special over being happy?**

- Peter asks, “*How much of the modern marvels of this world do we owe to the backs of people  who sacrificed their own happiness for the innovation that allows us to be doing what we’re doing right now?*”
- Arthur has thought about this, “*For me to say, you and I should break our success addiction, therefore the world would be better if nobody had a success addiction, it’s the fallacy of composition*”
- Here’s a metaphor for it‒ it’s to basically say, since I get home faster if I go a 100 miles an hour down the freeway, it would be better if everybody drove a 100 miles an hour on the freeway
- What you find is that many of the greatest innovators, composers, creative intellects, these were people that absolutely sacrificed their happiness
  - They were deeply, deeply unhappy
- There’s a huge literature that shows the [ventrolateral prefrontal cortex](https://en.wikipedia.org/wiki/Ventrolateral_prefrontal_cortex) is stimulated in depressives in a way that makes them highly creative
  - There is good brain science that shows the people who are suffering from mood disorders tend to be disproportionately creative and they do a lot
  - [Van Gogh](https://en.wikipedia.org/wiki/Vincent_van_Gogh) was not the outlier, it turns out
- There’s a lot of weird people in Silicon Valley that have a lot of untreated maladies, and they’re doing a lot
- It is true, that the world has been propelled by a lot of unusual people with unusual goals
- Arthur concludes, “*I don’t know if I were the divine, how I would create the universe. I don’t know how I would designate people in society. I don’t know whether I would make people sacrifice their happiness for the greater good of the whole. I’m just not sure whether there’s a success martyrdom that’s going on here.*”
- Peter adds, “*My two cents having none of the data and none of the insights that you do is that we are probably a lot better off for people who have made enormous sacrifices.*”
  - Think about the great physicists, the great mathematicians‒  [Newton](https://en.wikipedia.org/wiki/Isaac_Newton), [Gauss](https://en.wikipedia.org/wiki/Carl_Friedrich_Gauss), [Euler](https://en.wikipedia.org/wiki/Leonhard_Euler)
  - These people made untold sacrifices in terms of the pain that they endured as a result of their genius
- Arthur agrees

> “*But there’s one thing that I want to emphasize, which is that the misery is not inevitable*”‒ Arthur Brooks

- This is one of the reasons he’s done his work
- He’s not asking people to not be successful, ambitious, or not to work hard
- He’s asking them to dominate it, such that you’re not playing to your most innate drives, so that you can be successful and happy
  - This is a pretty small group of people, but they are there
- Arthur writes in his [book](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) about the case of [Johann Sebastian Bach](https://en.wikipedia.org/wiki/Johann_Sebastian_Bach), the greatest composer who ever lived, who died surrounded by the people who loved him and who revered him
  - The reason is because **he got on his second curve**, he dedicated his work to other people
- He didn’t say, “*Forget it. I’m not going to write anymore music*”
- He said, “I*‘m going to write music. And I’m just going to detach myself from the ego of having this enormous audience of people who will say that I’m the greatest composer ever, and I’m going to do it for humanity and to glorify God and to refresh the soul of other people. And if it’s really successful in commercial terms, it is. And if it isn’t, that’s okay too.*”

***In other words, be really ambitious, but detach yourself from the worldly idols and think about how you can use your success in service of other people. And that’s the hack, that’s the work around, that’s actually the glitch and the success on happiness matrix, is when you become other focused, you can be a success machine and also happy.***

- Peter agrees and adds, “*Just because that’s what got us here today as a civilization, doesn’t speak to the individual choice that we all have*”
- An example from Peter’s practice is his thinking on cancer screening for an individual
  - This is based solely on the individual
    - This is really all about individual risk, individual cost and what the reward potentially is
  - It would be a totally different question if he were in charge of creating a cancer screening program for everyone in the country
    - When you start to talk about it at a societal trade-off level, it’s a much more complicated problem
    - Now you have to look at quality adjusted life years and all these other metrics, and you have to balance a budget to basically do this

**Peter’s takeaway‒** ***just because everything we said is probably true, it doesn’t mean that any one individual doesn’t have the potential to make a choice to live in less misery or to be happier***

- Arthur agrees and adds, “*I believe you don’t even have to sacrifice the success, but you do have to go against your worldly urges in a very big way*”
  - Not the urge for success, but against your worldly urge to pursue the success for a particularly idolatrous reason
- This is the point that’s made by philosophers and theologians forever, “*When you do things in service of others, to lift other people up, to bring other people together, then you can become unbelievably successful*”
  - You can become the [Dalai Lama](https://en.wikipedia.org/wiki/Dalai_Lama), [Desmond Tutu](https://en.wikipedia.org/wiki/Desmond_Tutu), [Mother Teresa](https://en.wikipedia.org/wiki/Mother_Teresa), [Albert Schweitzer](https://en.wikipedia.org/wiki/Albert_Schweitzer)
  - What do all of those people have in common?

***The key distinction that allowed them to wiggle their way into the both happy and successful quadrant was they were doing this in service of their fellow women and men***

## A radical approach to overcome fear—the antithesis to love and happiness [1:14:00]

**Arthur** [**wrote**](https://www.theatlantic.com/family/archive/2020/06/how-get-comfortable-professional-decline/612637/) **recently in** ***The Atlantic*** **about the mortality paradox, we cannot conceive of not being here**

- Peter thinks about this so much, “*How difficult is it for us to imagine the world with us not in it because every experience we have is only through our eyes, only through our senses*”
- The **mortality paradox** has to do with the fact that as big brained mammals, we’re able to understand that we’re going to die intellectually, but what we can’t conceive of is the idea of not existing
  - Those are 2 different phenomena, they’re 2 different cognitions
  - One you can really understand, the other that you can’t
- And the fact that those 2 things are in tension creates a lot of fear, uncertainty, real discomfort, real cognitive dissonance, and discomfort in people
  - The result is they’re trying to work through that their whole lives
- There are several approaches:
  - 1 – Resolve to never die (unrealistic)
  - 2 – Try to understand the concept of not existing
  - 3 – Say, “*I will always exist, notwithstanding the fact that I’m going to die*”
  - Many philosophies and religions address this
- But this all leads to people’s fears

**Fear is the opposite of love**

- People talk to Arthur a lot about what they’re most afraid of
- Part of the reason is because the main focus of his happiness work is love, and **love and fear are opposites**
  - Love and hatred are not opposites
  - Hatred is downstream from fear
    - This is a philosophical principle from [Lao Tzu](https://en.wikipedia.org/wiki/Laozi) and [St. John the Apostle](https://en.wikipedia.org/wiki/John_the_Apostle)
    - It’s also a neurocognitive regularity where you find that’s how the brain works
  - You tend to find that love neutralizes fear, and fear can turn off love and every other feeling like a switch, because of the way that the brain is designed
- So in thinking about love, Arthur needs to actually understand fear
- He asks people what they’re afraid of
- The main focus of his work in happiness is the subject of love
- If you want to know one thing about how to be happy, ***happiness is love, full stop***

> “*Love is the nuclear fuel rods of happiness*”‒ Arthur Brooks

- There’s a ton of longitudinal data that shows this
- Data on people in their 80s and 90s who are really happy, if you look back in their 20s, 30s, 40s, and 50s‒ ***what they all have in common is strong relationships that they were cultivating and working on***
  - Real love relationships in terms of romance and family and real friends
  - Not just the old friends

**If you want to understand what turns off love in your life, understand what you’re afraid of**

- When people tell Arthur they have too much fear in their life, he says “*Well, you need more relationships*”

> “*We need more love to neutralize the fear*”‒ Arthur Brooks

- Everybody has a death fear
- Most people say, “*I’m not afraid of dying*”
  - If you lived right, you’re not afraid of dying
- But everyone has a **death fear**, and  it has to do with the extinction of how you understand yourself
- That gets back to the mortality paradox
- The idea of not existing has some manifestation in almost everybody’s life
  - It may be, I’m afraid of becoming irrelevant
  - I’m afraid of being forgotten
- Arthur’s mother was in early stage dementia when she was in her mid-50s.
  - She lived for another 15 years
  - It was a really bad ending
- For Arthur, his death fear is loss of the functioning of his brain
  - It doesn’t matter how strong his muscles are
  - For him to be able to make a living and support his family, employees, etc., he needs his brain

***Everybody has something like this, whether it’s really ego related or skill related; everybody’s got their mortality terror***

> “*This is one of the things that we need to dominate if we want to be happy*”‒ Arthur Brooks

**An exercise to help with fear**

- Here is an exercise Arthur gives to  his students
- 1 – Figure out what your death fear is
  - This requires some serious reflection
- For most of his students at Harvard, it is a fear of failure
  - They are super high performing
  - They never had any academic failure
- Most of his students are a success machine
  - They start off very objectified by their parents
  - Parents will say, “*You’re the special one. You’re successful. You always get A’s, you’re a hard worker, get it done*.”
  - They see themselves as high performers, and they’re very bright and they’re very hard working and the result is they don’t experience any failure in school
  - For Arthur, if he got a B on an exam, who cares
    - He flunked out of college

***But these kids have never experienced failure so it feels like a mortal threat because it’s a threat to who they think they are***

- So whether their death fear is failure, or cognitive decline, or being forgotten, or being irrelevant, or actually dying, the technique for getting beyond this is really all the same
- 2 – The [Maranasati](https://en.wikipedia.org/wiki/Mara%E1%B9%87asati) meditation
  - This is a 9 part death meditation that [Theravada Buddhist](https://en.wikipedia.org/wiki/Theravada) monks in Sri Lanka, and Thailand, and Vietnam all undertake
  - In this they often contemplate photos of corpses in various states of decay, and they’ll say, “*That is me. And that is me.*”
  - They imagine themselves decaying, dying and then a rotting bloated corpse
  - It’s super graphic; it’s unbelievable and that’s the point
- What you’re trying to do is what psychologists would call **exposure therapy**
- You’re exposing yourself to the inevitable truth
- Why? **Because it loses its terror when it becomes familiar**
- So what Arthur makes his students do is a 9 part meditation on their own failure, catastrophic failure, by their own terms, which is not necessarily human catastrophic failure
- He remembers the first time he did this, he went through all the steps with his students
  - 1 – I’m falling behind my colleagues at school
  - 2 – I graduate, but just barely
  - 3 – I’m not getting the jobs that my friends are getting and that people thought I was going to get
  - 4 – I’m finding my career is not what I thought I was going to be
  - At some point he added‒ I think my parents feel sorry for me
    - And a student starts crying because that’s the nerve
    - There’s always this point in the death meditation

***So figure out what death means for you, where this mortality paradox really has teeth.  Then actually put together the exposure therapy of walking yourself through the emotion experience of this failure and you will be free***

- You can’t do it just once
- You have to do it again and again, because you fear is deeply rooted in a lot of your experience
- But once you’re exposing yourself to that again and again, it has an incredible therapeutic impact
- Peter notes the importance of first taking some time to be really thoughtful about what your fears are
  - He guesses that some people may have more than one, so they might need to do this exercise twice
- Arthur agrees, we probably all have multiple fears and they change throughout life
  - When he was 20 years old, he wasn’t afraid of cognitive decline
- You have to be comfortable with this inevitability, the mortality paradox
- The inability to process these 2 competing ideas, it’s terrorize you, paralyze you, it’ll be a problem

**What is the optimal dose of exposure?**

*For someone who is afraid of spiders and realized they needed to be exposed to spiders, how often would they need to do this?*

- There are psychologists and psychotherapists who deal with this with different kinds of phobias, and they find that different people need more or less frequent exposure
- Arthur’s little girl (she’s now 19), they adopted her from China when she was a baby
  - She had never been held and she was undernourished
  - When she came to live with us, she was afraid of a lot of stuff
  - One of the things she was really, really afraid of was dogs
  - She would see a dog outside and she would just scream
  - They wanted to solve this and did so by getting a dog
    - But they didn’t just throw the dog in the room with her
    - They kept the dog apart
    - After about 3 days, she was not afraid of the dog anymore
    - After about 6 weeks, she loved all dogs and that was it, forever
- Other people who have lived with a phobia all their lives require a more strenuous and thorough intervention, and one that’s more frequent

**Advice for exposure therapy/ meditation**

- Monks literally have pictures of 9 stages of decaying corpses
  - They stand in front of each one of the picture each day and say, “*That is me*”
  - They want this to become completely trivial and familiar
- This is a good one for all of us because we’re all going to die

***But the thing that really is holding you back, your version of the death meditation, think about it, contemplate it, write it out and expose yourself to it as much as you need to***

- You’ll know when you’re getting the benefit
- Contemplate each step for 2 minutes and to do that each day for 3 weeks
  - By the end of 3 weeks Arthur was like, “*Yeah, I’m going to fail. Ha, ha.*”
- Peter adds, “*So not a big commitment. Look, it’s 20 minutes a day for 3 weeks.*”
- Arthur points out that if it’s a really entrenched problem, it’s going to take a lot longer than that
  - Plus [cognitive behavioral therapy](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy)
  - Plus drugs
- But he has found his students are afraid of failure, and we can get over it pretty quick

## Ancient Hindu advice for the perfect life [1:26:30]

**The 4 Āśramas**

- Arthur describes himself as an Indiaphile
- The [4 Āśramas](https://en.wikipedia.org/wiki/%C4%80%C5%9Brama_(stage)) divide life into about 25 year chunks
  - These are quarters of a perfect, well-balanced life in [vedic philosophy](https://en.wikipedia.org/wiki/Vedas)
  - This is ancient Indian wisdom
  - These ideas are probably 5,000 years old.
- Arthur has studied with a lot of these very deep Hindu masters in Southern India
- Every time he goes to India, he tries to sit at the feet of one of these masters and they’ll say, “*You’re Christian, right?  You think all these things that we used to think 4,000 years ago.”*
- He went to India specifically to study the ashrams with a wonderful guru in a place called [Palakkad](https://en.wikipedia.org/wiki/Palakkad_district) in Southern India, on the border between Kerala and Tamil Nadu (which are these 2 Southern states)
- He asked the guru (Sri Nochur Venkataraman) about these ashrams (ideally 25 years each)
  - The odds of getting to 100 are 1 in 6,000 in the United States
  - They are a lot lower than that in India
- So the point is not to be dogmatic about turning 50
- What we’re really talking about is just these chunks of life
- 1 – The first phase of life is called **Brahmacharya**, which is the student life
  - It means the time when you’re learning, when you’re absorbing, when you are a sponge for human capital and ideas
- 2 – Then around age 25 you enter **Gṛhastha**, which is typically when a man would get married and start a household
  - This is called the householder phase and that’s career, and marriage, and children, and success, and sexual relationships, and all of these worldly rewards of money, power, pleasure, and fame
  - That’s when you get addicted to those worldly rewards of money, power, pleasure, and fame
  - And it’s fun, and it’s good, and it’s hard, and it’s tiring
- In the west it’s different; we talk about 1 hard transition from kid to adult
  - From Brahmacharya to Gṛhastha
- In India, they talk about the difficulty of the **second adolescence**
  - This is the passing out of Gṛhastha into the third phase around 50, which is called Vanaprastha
- 3 – **Vanaprasha** is from age 50 to 75 and that’s a really critical and very interesting phase
  - It’s hard to get into because it requires wanting less
  - It requires chipping away
  - It requires a reverse bucket list
  - Vanaprastha comes from two Sanskrit words, van and prastha, meaning to retire into the forest (obviously, metaphoric)
  - The whole point is to retire away from a lot of the parts of Gṛhastha
  - You’re still going to work, you’re still going to do your thing, but you’re going to have a different focus
  - You’re going to be focused on teaching and on other people
  - This is very second curve
  - This is where it all comes together
- This is what Arthur tries to do with his work‒ take Eastern or Western philosophy and wisdom and mix it up with neuroscience, with historical regularity, and with modern experimental social science
  - And it all has to be consistent
  - If it’s not all consistent and there’s one part of that’s not quite right, then he’s onto the wrong comprehensive story

**How these ancient Hindu stages of life together with the happy successful quadrant**

- You are passing into your second curve (which is also Vanaprastha, 1 of the ashrams), retiring into the forest, where you are the teacher
  - You are becoming less involved in your own success, but more involved in the success of other people
  - Now that might carry you to great glory
  - But it’s not primarily for that, if you’re going to be in the happy, successful quadrant
- The twist is, there is another goal ahead of you, a big goal
- 4 – The last Āśrama, which is 75 years old and beyond, called **Sannyasa**
- People who’ve studied Eastern philosophy or Hindu thought know what a Sannyasa is
- A Sanyasi is somebody who is an enlightened one
- But it simply means somebody in the Āśrama of Sannyasa
- This is where you’re fully dedicated to spiritual enlightenment
- In ancient times, Hindu men of some means at age 75 would take leave of their families and go to the Himalayas and sit at the foot of their master until death
  - Arthur is not suggesting this
- The point is, “***The fruit of my old age requires a lot of training.  The intellectual and philosophical and spiritual transcendental fruit of my life requires this elite training****.*”
  - Which takes place in Vanaprastha (stage 3)
- You can’t show up to the Olympics, 60 pounds overweight, expect to swim the backstroke, having not swam in months
  - It can’t be done
  - You have to train for it
- According to these Hindu philosophers, it takes 25 years of elite spiritual and intellectual and transcendental training to get to that point later in life

## The end result of getting caught in the 4 idols [1:31:45]

**Arthur, if you go back in time to that plane ride from LA to DC, and let’s just imagine you’ve somehow found yourself alone with this gentleman, once you’ve figured out who he was and processed all he had to say, what would you say to him?**

- He wouldn’t intrude on his privacy to begin with, because he was overhearing a conversation about the most intimate things in his life with his wife
  - Which is one of the reasons I haven’t divulged to a single soul, the identity of that man of the plane, because it’s not important
  - It could anybody, practically, under very similar circumstances
- By the way, he has Googled him since then
  - The man has divorced that woman already, and it’s not his first wife
  - The whole point is what he’s been hungering after, panting after, lusting after, is what he had in Gṛhastha (on his first curve, fluid intelligence)
  - He wants back what he had in his idols of money, power, pleasure, and honor

**But if you were asking for particular advice…**

- He would talk about the 1 thing that he’s really missing, which he’s evidently really missing

***The fruit of his life should be his enlightenment based on love, on faith, and family, and friendship, and service to other people. Those are the habits of the happiest people.***

- This is what people do who are maximizing their happy span
- Your ambition to go back in time is going to lead you to misery
- You need to move forward into the bonds of love
  - That should be your rightful claim, as a person later in life

## The complexity of happiness [1:33:30]

- Peter reacts, “*I think this is a harder thing to fix than a lot of the things that I talk about*”
  - Taking somebody who lives on a hedonic treadmill and getting them to adjust, to decrease wants, to make the type of strategic changes that are in keeping with what ultimately will bring them happiness is difficult

**Does Arthur think this is difficult?**

- He has contemplated that a lot
- When he was doing work for the Rand Corporation on combat modeling, using huge computer systems to look at an unbelievable number of simulations and contingencies
- What he found was that all of the easiest problems to solve (which can be very hard, but they’re solvable) are what mathematicians call **complicated problems**
  - Those are problems that take a lot of computational horsepower, but once you solve the problem, you can replicate the solution over and over again with great accuracy, like creating a jet engine where every single jet flies and almost none of them ever crash or fail
  - Now it took a long time to do that
  - He calls this the toaster problem‒ it wasn’t long ago that there were no toasters
    - But now you can get a $20 toaster that will last for many years and it makes great toast
- The bigger problems, the problems that really bedevil us, the problems of human life and the essence of human life are mostly **complex problems**
  - Those are the problems where we understand the nature of what winning means very easily, but there’s so many inconceivably high number of permutations that they can’t be solved
  - These are not toaster problems
  - They’re cat problems
    - Cats are complex, not complicated
    - You know what they want, scratches and warmth and kibble, a box to poop in, but you don’t know what they’re going to do next, ever
- All of life’s really interesting things, that make life life, they’re complex problems

> “*Love is a complex problem. Love is a cat, not a toaster*.”‒ Arthur Brooks

- The problem we have in life today, the problem with tech is they are trying to clove our complex problems of love using complicated engineering solutions
  - You’re lonely, here’s Facebook
  - That’s like saying, “*You want a cat, here’s a toaster*”
- These complex issues are insoluble, and we’re looking for a similaracrom for a solution
- And when it comes down to saying, “*Just love more,*” it’s insufficient, and that’s why it’s so hard
- And so what I’ll do, when I can’t get my cat, is I’ll just try to be contented with a toaster
  - And it doesn’t work
  - And that’s what leads to a lot of the heartbreak of ordinary life

Peter remarks, “*That’s literally one of the most remarkable explanations I’ve heard for… Certainly I’m familiar with complex and complicated problems, but this application of it is probably one of the most helpful I’ve heard, so I appreciate that.*”

§

## Selected Links / Related Material

**Arthur’s podcast**: [How to Build a Happy Life](https://www.theatlantic.com/podcasts/how-to-build-a-happy-life/) (renamed How to Start Over) | *The Atlantic* | [1:00]

**Arthur’s most recent book**: [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur C. Brooks (2022) | [1:00, 2:15, 21:15, 1:11:00]

**Fluid and crystallized intelligence**: [Your Professional Decline Is Coming (Much) Sooner Than You Think](https://www.theatlantic.com/magazine/archive/2019/07/work-peak-professional-decline/590650/) | Arthur Brooks, *The Atlantic* (July 2019) | [20:30]

**Success addiction**: [We need to kick our success addiction](https://bigthink.com/smart-skills/addiction-to-success/) | Arthur Brooks, *Big Think* (June 28, 2022) | [24:45]

**The happiest people aren’t the most successful**:

- [What the Second-Happiest People Get Right](https://www.theatlantic.com/family/archive/2022/03/chasing-happiness-leads-to-dissatisfaction/629427/) | Arthur Brooks, *The Atlantic* (March 31, 2022) | [1:04:00]
- [‘Success Addicts’ Choose Being Special Over Being Happy](https://www.theatlantic.com/family/archive/2020/07/why-success-wont-make-you-happy/614731/) | Arthur Brooks, *The Atlantic* (July 30, 2020) | [1:04:00]

**The mortality paradox**: [The Best Way to Handle Your Decline Is to Confront It Head On](https://www.theatlantic.com/family/archive/2020/06/how-get-comfortable-professional-decline/612637/) | Arthur Brooks, *The Atlantic* (June 4, 2020) | [1:14:00]

**Arthur’s rules for happiness**: [A Happiness Columnist’s Three Biggest Happiness Rules](https://www.theatlantic.com/family/archive/2022/07/pillars-of-happiness-from-100-lessons-on-how-to-be-happy/670586/) | Arthur Brooks, *The Atlantic* (July 21, 2022)

**Satisfaction and habits to overcome dissatisfaction (a reverse bucket list)**: [How to Want Less](https://www.theatlantic.com/magazine/archive/2022/03/why-we-are-never-satisfied-happiness/621304/) | Arthur Brooks, *The Atlantic* (February 8, 2022)

**Death meditation**: [The Best Way to Handle Your Decline Is to Confront It Head On](https://www.theatlantic.com/family/archive/2020/06/how-get-comfortable-professional-decline/612637/) | Arthur Brooks, *The Atlantic* (June 4, 2020)

**Arthur’s website**: [Arthur C. Brooks: Live a Better, Happier Life](https://arthurbrooks.com/) | Arthur Brooks (2022)

§

## People Mentioned

- [Raymond Cattell](https://en.wikipedia.org/wiki/Raymond_Cattell) (British-American psychologist who defined fluid intelligence) [19:00]
- [Joseph Epstein](https://en.wikipedia.org/wiki/Joseph_Epstein_(writer)) (American writer who was the editor of the magazine The American Scholar from 1975 to 1997) [50:30]
- [William Burroughs](https://en.wikipedia.org/wiki/William_S._Burroughs) (American writer) [1:06:45]
- [Van Gogh](https://en.wikipedia.org/wiki/Vincent_van_Gogh) (Dutch painter from the 1800s) [1:09:30]
- [Issac Newton](https://en.wikipedia.org/wiki/Isaac_Newton) (English mathematician, physicist, and astronomer) [1:10:15]
- [Carl Friedrich Gauss](https://en.wikipedia.org/wiki/Carl_Friedrich_Gauss) (German mathematician and physicist) [1:10:15]
- [Leonhard Euler](https://en.wikipedia.org/wiki/Leonhard_Euler) (Swiss mathematician, physicist, and astronomer) [1:10:15]
- [Johann Sebastian Bach](https://en.wikipedia.org/wiki/Johann_Sebastian_Bach) (German composer of music in the early 1700s) [1:11:00]
- [Dalai Lama](https://en.wikipedia.org/wiki/Dalai_Lama) (spiritual leader of Tibet) [1:13:30]
- [Desmond Tutu](https://en.wikipedia.org/wiki/Desmond_Tutu) (South African bishop, activist for human rights and anti-apartheid)  [1:13:30]
- [Mother Teresa](https://en.wikipedia.org/wiki/Mother_Teresa) (Catholic nun known for missionary work in India) [1:13:45]
- [Albert Schweitzer](https://en.wikipedia.org/wiki/Albert_Schweitzer) (A German/French polymath) [1:13:45]
- [Lao Tzu](https://en.wikipedia.org/wiki/Laozi) (ancient Chinese philosopher) [1:16:00]
- [St. John the Apostle](https://en.wikipedia.org/wiki/John_the_Apostle) (one of the 12 apostles of Jesus) [1:16:00]

§

![](https://peterattiamd.com/wp-content/uploads/2022/10/bio-image-arthurbrooks.jpg)

##### Arthur Brooks, Ph.D.

Arthur C. Brooks is the William Henry Bloomberg Professor of the Practice of Public Leadership at Harvard Kennedy School and Professor of Management Practice at Harvard Business School. Before joining the Harvard faculty in July of 2019, he served for ten years as president of the American Enterprise Institute (AEI), a public policy think tank in Washington, DC.

Brooks is the author of 12 books, including the national bestsellers: [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2022), [*Love Your Enemies*](https://www.amazon.com/Love-Your-Enemies-America-Contempt/dp/0062883755/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2019), [*The Conservative Heart*](https://www.amazon.com/Conservative-Heart-Happier-Prosperous-America/dp/0062319752/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2015), and [*The Road to Freedom*](https://www.amazon.com/Road-Freedom-Fight-Free-Enterprise/dp/046502940X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2012). He is a columnist for The Atlantic, host of the podcast [*How to Build a Happy Life*](https://www.theatlantic.com/podcasts/how-to-build-a-happy-life/), and subject of the 2019 documentary film [*The Pursuit*](https://arthurbrooks.com/the-pursuit/). He serves on the board of the Legatum Institute, a think tank in London.

Brooks began his career as a classical French hornist, leaving college at 19, touring and recording with the Annapolis Brass Quintet and later, the City Orchestra of Barcelona. In his late twenties, while still performing, he returned to school, earning a BA through distance learning at Thomas Edison State College, and then an MA in economics from Florida Atlantic University. At 31, he left music and earned an MPhil and PhD in public policy analysis from the Rand Graduate School, during which time he worked as an analyst for the Rand Corporation’s Project Air Force.

Brooks then spent 10 years as a university professor, becoming a full professor at Syracuse University’s Maxwell School of Citizenship and Public Affairs in his seventh year out of graduate school and occupying the Louis A. Bantle Chair in Business and Government. During this decade, Brooks published 60 peer-reviewed articles and several books, including the textbook *Social Entrepreneurship* (2008). [[Harvard Business School](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664)]

Twitter: [@arthurbrooks](https://twitter.com/arthurbrooks)

Instagram: [arthurcbrooks](https://www.instagram.com/arthurcbrooks/?hl=en)