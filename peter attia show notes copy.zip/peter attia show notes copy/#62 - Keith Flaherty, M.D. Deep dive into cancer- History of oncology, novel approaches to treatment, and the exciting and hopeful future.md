# #62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future

**Source:** [https://peterattiamd.com/keithflaherty/](https://peterattiamd.com/keithflaherty/)

---

In this episode, Keith Flaherty, director of clinical research and targeted cancer therapy at Massachusetts General Hospital, shares his vast wealth of knowledge in cancer starting with the history of treatment from chemotherapy to radiation to surgical therapy and where those methodologies seemed to have leveled off. He also walks us through the timeline of advancements (and lack there of) from when the War on Cancer was declared in the 1970s, through the sequencing of the entire human genome, and all the way to today. Keith dives into the topic of immunotherapy, probably the most exciting recent development in cancer therapy, and also provides us a rundown of his notion of a different approach to cancer that attacks all the essential pillars of cancer growth and survival. Finally, we talk a little bit about liquid biopsies, we discuss the roles of CRISPR and other potentially over-hyped therapies with respect to cancer. We also touch on stem cell therapy a bit, as well as some other common cancer-related questions such as the role of vitamin D and sun exposure in melanoma, and much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/keithflaherty/the_Drive_public.png)

Play

#62 - Keith Flaherty, M.D.: Deep dive into cancer—History of oncology, novel approaches to treatment, and the exciting and hopeful future

#62 - Keith Flaherty, M.D.: Deep dive into cancer—History of oncology, novel approaches to treatment, and the exciting and hopeful future

1x15s30s

0:002:57:28

## We discuss:

- Growing up around medicine, and finding a career that you love [7:30];
- Medicine as a career, limitations of the med school teaching approach, and the dynamic and accelerating field of medicine and technology [16:30];
- Explaining chemotherapy, radiation, and how a cancer develops [23:45];
- Surgical oncology, cure rate of solid tumors, and survival rate after tumor removal  [33:15];
- 25 years after the War on Cancer is declared, gene sequencing, and why Keith’s was fascinated by the HIV case study [37:15];
- Cancer immunotherapy: History, how it works, and why some cancers respond and others don’t [46:00];
- MHC complexes, and cancer cloaking mechanisms [56:00];
- Comparative biology of cancer: Why some cancer can evade immune detection better than others [1:03:00];
- What we learned from the Cancer Genome Atlas Project [1:07:00];
- Defining targeted therapy, HER2 breast cancer, chronic leukemia, and the translocation of chromosomes [1:12:00];
- Tumor protein P53, the most famous tumor suppressor gene and its ubiquity in cancer [1:17:45];
- Activated oncogenes, the RAS pathway, PI3 kinase, RAF gene, and Keith’s “aha moment” [1:24:15];
- Advice for starting your career as a scientist/clinician [1:37:00];
- Fusion-driven cancers, targeted therapy, and the Bcr-Abl/chronic myelogenous leukemia case study [1:39:45];
- Targeted therapy for fusion-driven solid tumors, adjuvant systemic therapy, and the HER2 breast cancer example [1:53:00];
- Advancing melanoma treatment, survival, and cure rates with BRAF-MEK combo therapy [1:59:15];
- The fundamental pillars of cancer growth and survival, and the toolkit we need to attack cancer from all angles [2:02:40];
- Peter’s clinical framework for thinking about cancer and how Keith might improve it, and how the biotech environment is hampering our ability to put together novel cancer treatments [2:05:00];
- How useful is CRISPR in terms of tumor suppressing? [2:16:15];
- Liquid biopsies as a therapeutic monitoring tool [2:18:00];
- Stem cell therapy: The efficacy and potential risks [2:25:15];
- Aging and cancer: Is cancer inevitable? [2:28:45];
- Vitamin D supplements, sun exposure, melanoma, and exercise [2:32:30];
- How and why Keith has straddled the line between science/research and industry/drug companies, and the importance of getting more voices of practitioners at the table [2:42:00]; and
- More.

---

## Show Notes

## Growing up around medicine, and finding a career that you love [7:30]

*Where are you from?*

- Born and raised in Baltimore
- Broke away to boarding school in Massachusetts for four years
- Connecticut for college, four years,
- then back to Baltimore, four years of medical school.
- Boston for the first time, three years of residency and
- then, Philadelphia for nine years, which was both medical oncology fellowship and my first faculty stint.
- And now, ten years ago, moved back up to Boston to Mass General.

*Growing up around medicine*

- Father and mother were physicians
- My father was an academic cardiologist for 25 years
- Mom was an academic psychiatrist, actually, really still is at the age of now

*When did you know you wanted to go into medicine?*

- Knew he wanted to “help” people is some way or another
- Didn’t want to go into the “business” world
- He also saw that both his parents were very passionate about what they were doing
- Eventually, medicine just seemed to stand out among the career options

**The fine line for parents**: “being home” vs. “setting an example” in terms of seeing them working on something with passion and discipline

- There’s something to be said when that child sees their mom or dad feeling incredibly passionate about what they’re doing
- For example, Keith’s wife ([Mira Kautzky](https://www.massgeneral.org/doctors/doctor.aspx?id=18717))
  - She’s an internist at Mass General
  - They watch her pour herself into the indirect care of patients through the electronic medical record and constantly reflect that she’s the hardest working person they know.
  - That kind of willingness to give, give, give outside of one’s personal time, family time, is related to this very nebulous notion of what it is that qualified as a satisfying career

**Keith feels luck to do what he does for a living**

- Keith feels like most people dislike their job and they’re just holding their breath trying to get to the weekend
- He says he is part of that small group of people who love what they do
- That said, his work/life balance has been “off the rails” in terms of working long hours and being over committed and trying to juggle way too many things
- However, he would also say that “it was exactly the optimal amount of chaos that one needs to really feel like you’re pushing on all fronts simultaneously”
- How do you both find the outlet and define the scope of a career that allows you to do that? ⇒ “*What a challenge!*”
- Keith believes the changing times will likely create an even bigger challenge for future generations

## Medicine as a career, limitations of the med school teaching approach, and the dynamic and accelerating field of medicine and technology [16:30]

Peter says, the path to “academic success”, non-academic clinical success, it’s still relatively unperturbed compared to so many other paths outside of medicine… *does Keith agree?*

- “I don’t see it that way” says Keith
- Keith sees how rapidly the technology and wealth of knowledge is accelerating
- Things like data generation, ability to produce high dimensional data, analyze it, try to make sense of it, raise hypotheses, test hypotheses, yet the cycle time is changing a lot, and the constituents that we now need to interact with are totally different
- The point I’m coming to… **I see medicine now as this terrifying arena in which to try to assemble a multi-decade long career**.

*How do you keep yourself relevant in a 40 year arc? Keith posits…*

- Here I am at 20 years, I feel like I’m an absolute dinosaur
- Keith wonders how the new generation of physicians and scientists will keep up with this rapidly accelerating progress

Peter’s take:

- Based on the way you’re describing it, Keith, I would say doctors coming out of training are hosed, because … **I think medical school might be one of the most anti-intellectual forms of higher education that exists**.
- Peter says even in undergraduate, law school, Ph.D. programs… you are encouraged to think creatively, and problem solve
- In other words, “I’m not sure medical school teaches you how to be a thinker or a problem-solver”

\***Tip**\*: don’t take pre-med prior to med school (i.e., study engineering, humanities, or something totally unrelated)

**Keith’s take on med school and beyond**:

- Medical school teaches information as fact
- When talking to people about cancer as a career, he tells them, “look, it’s so simple to find the boundary between what’s known and not known. There’s so much out there we don’t know and in any area of trying to understand physiology, pathophysiology, in the mode of cancer, you will so quickly get to that frontier.”

*And then, how do you operate in that frontier?*

- Once you’re there, how do you help the patient in front of you, the next wave of patients that are coming in the not too distant future, and then a full generation out?

- Investigation is the only way you can pose yourself as being helpful. And  I didn’t get that in medical school, sadly, even though I was at a fantastic environment for learning the archival version of medicine.

## Explaining chemotherapy, radiation, and how a cancer develops [23:45]

**Defining chemotherapy**

- It’s actually not hard to kill a cancer cell, it’s actually **very easy** to kill a cancer cell:
  - Bleach
  - Formaldehyde
  - “Go to Home Depot, most things on the shelf kill cancer perfectly.”
- Problem is, they kill **everything** perfectly
- The arbitrage is the following… it has to kill cancer, and **almost kill** (but not kill), non-cancer cells
  - That’s a narrow subset of things
    - And most of these things are targeting DNA
    - which means they’re targeting things that grow (i.e., hair loss from chemo)
- Side effects of chemo:
  - Hair loss
  - Sores in the mouth
  - Brittle nails
  - Rapidly dividing bone marrow cells

The filtering of the potential therapies…

- It was looking for what can kill a fast growing cell
- We could’ve come up with other hits, potentially, if the chemical diversity of probes that were used were broader
  - For example, we didn’t really look at metabolic distinction between them (i.e., The [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology)))

*A focus on fast-growing cancer cells*

- There are both fast-growing and slow-growing cancer types
- Then, within the cancer cell population, you’ve got faster and slower growing varieties there too
- But if you use “fast-growing” as your filtering mechanism… what you come up with are these **toxins to rapidly dividing cells**
- Keith uses the term ‘chemo’ to describe these toxins that go after fast-gowing cells
- Most people, however, say that all cancer therapeutic is chemotherapy

*Peter’s take on what he considers “chemo”:*

- I like to think of chemo as that type of chemical
- Immunotherapy use chemicals, but they’re totally different
- Metabolic therapies (e.g., PI3K inhibitor) I’m not really considering that chemo

**Lack of progress in cancer treatment**

- Nixon declared the [War on Cancer](https://en.wikipedia.org/wiki/War_on_Cancer) in 1971 ([**Watch the declaration on YouTube**](https://www.youtube.com/watch?v=lQYfC9kisHw))
- If you look at ten year survival for metastatic solid organ tumor from 1974 until 10 years ago…
  - [Seminoma testicular cancer](https://en.wikipedia.org/wiki/Seminoma) and [GIST](https://en.wikipedia.org/wiki/Gastrointestinal_stromal_tumor) cancer were just about the only success stories
- But if a woman had [metastatic breast cancer](https://en.wikipedia.org/wiki/Metastatic_breast_cancer) in 1971, and a woman had metastatic breast cancer 40 years later there is *shockingly little difference* **⇒ Median survival extensions of maybe six months to twelve months**

*For a cancer cell to even exist, it has to have overcome a heck of a lot to get to be clinically relevant…*

- Many of the common cancers (breast, colon, prostate, lung, pancreatic cancer) are perturbed at best by conventional chemotherapy

> “Some sub populations of those cancer cells will slow down and die with conventional chemotherapy, but many of them are pre-wired. They were hardy to begin with. They got there through a hard earned evolution under selective pressure of the immune system and adverse metabolic environment, and they used all the tricks up their sleeve to reprogram themselves to be able to survive in these harsh environments. You throw in another harsh environment reagent in the form of chemo, not surprisingly, these things were already basically hardwired to be able to survive yet another insult.”

- A clinically relevant mass has over a billion cells
- To get to that point…
  - you have to evade [T-cells](https://en.wikipedia.org/wiki/T_cell)
  - You have to grow your own vascular supply.
  - You have to overcome adverse metabolic conditions.
- “*These things are evolutionary warriors by this point.*”

**How a cancer develops (in Keith’s words)**

“There’s a random spinning of the combination lock where mutations are being acquired over time, through a variety of insults . . .or just bad replication technology, where the detection of errors, and the correction of errors is not perfect.

We accumulate mutations over time, some of which we can limit and control, some of which we can’t. The combination lock is just spinning, spinning. The combination has to be dialed in the right sequence just like when you’re opening your gym locker, or you don’t get cancer. You’ve got to get your tumor suppressor early and in the right order, before you’re activated oncogene comes along.

You’re randomly spinning a lock. You’re picking up lots of past permutations, not just true drivers, so these incidental mutations that happen here and there. As that’s happening, you finally click important components of the program. Along the way, some of those are actually mutations that are seen as foreign by the immune system.

If they’re too far out there, then they’re gone. It has to be a right kind of genetic alteration that will give the cell what it needs to be able to proliferate abnormally, to be able to sustain a lot of DNA damage as it accumulates, and not commit suicide as a consequence, and be able to handle all the other adverse features and filters of a tumor micro-environment that you enumerated.

> It has to be able to do all that, but it has to be below the radar, as in not detectable as overly foreign to the immune system. That’s a powerful insight that we only really picked up in the field within the past five years, this notion that this is not just a cancer cell co-opting its normal cells in the microenvironment in some cocooned way. There are a few cancers that do develop in what are called ‘sanctuary sites’ that aren’t subject to immune surveillance, but the vast majority are. So, that is a lot to have to overcome.”

**Radiation**

- Radiation is limited because it’s not systemic
- A great tool to locally control cancer
- But now you’ve basically reached an asymptote at the two of the three pillars

The 3 pillars of treating cancer

- i) chemo
- ii) radiation
- iii) surgery

## Surgical oncology, cure rate of solid tumors, and survival rate after tumor removal  [33:15]

Surgery is the third pillar for trying to treat cancer (and it may also [asymptote](https://en.wikipedia.org/wiki/Asymptote))

⇒ Example: [Whipple procedure](https://www.mayoclinic.org/tests-procedures/whipple-procedure/about/pac-20385054)—Removing the head of the pancreas–One of the most complicated surgical procedures for cancer

- That was an operation that used to carry a 50%, 30-day mortality (meaning you had a 50% chance of living through the surgery and the postoperative course)
- Today that’s 0.1% mortality at 30 days
- But **long term survival is still abysmal**
- See: [Whipple procedure: a review of a 7-year clinical experience in a referral center for hepatobiliary and pancreas diseases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4363458/)

*However, cutting out tumors can still help a lot*

- Colon cancer is the poster child for where cutting cancer out really makes the biggest difference (Even in metastatic disease)
- Other cancers, for example breast cancer, Peter and Keith are not so sure surgery helps “*if the die is cast long before the mastectomy is done*”

**Keith is still hopeful…**

*Cure rate of solid tumors*

- The cure rate of solid tumors that are amenable to surgery has never been less than 40% in Keith’s career (maybe even 50% he says)

*Circulating cancer cells in the blood*

- Circulating cells in the blood have a hard time surviving
- People think about a circulating cancer cell, and assume that it’s going to succeed, but it’s super hard to launch a cancer cell into the blood stream and actually have it find fertile soil
  - E.g., Lung cells aren’t supposed to live in the liver. It’s not a happy environment for them. The growth factors there aren’t their native ones so it’s a super challenging bit of biology to overcome
- *The point being…***there are a large number of patients who have curative outcomes from surgery who had seeding of distance organs, even successful microscopic deposits**

*What do you think it is about the removing of the “mothership” that harms the “satellite ships”?*

- Decades ago when surgery was curing patients, but we just assumed that it got it early, before any of it had ever traveled
- Now, more and more evidence suggests, no, you didn’t get it that early, but you got it early enough, because those [micrometastases](https://en.wikipedia.org/wiki/Micrometastasis) (micro-mets) that were established, they didn’t have all that it takes to become a problem
- Another wave of evolution was going to be needed in the **primary tumor** to be able to launch micro-mets that had all the skills to be able to…
  - i) set up shop in the first place
  - ii) live in a dormant state, for not just months, but years and even decades in some cases, and
  - iii) then make their way out again

## 25 years after the War on Cancer is declared, gene sequencing, and why Keith’s was fascinated by the HIV case study [37:15]

\*The [War on Cancer](https://en.wikipedia.org/wiki/War_on_Cancer) was declared by Nixon in 1971\*

**25 years later…**

- It’s the late ’90s and the scientific community is on the cusp of fully sequencing the human genome
- We certainly understood that cancers are initiated by genetic mutations (some genes that suppress tumors, and some genes that promote tumors)
- A justification for doing whole genome sequencing in cancer was that
  - We didn’t know what that sequence might look like across cancer.
  - We didn’t know what the *spectrum of genetically simple to genetically complex* cancers was
    - I.e., Do you need three mutations to get a cancer? Is eight somehow better a number? By that, I guess, I mean just look at a distribution of “ true drivers”
- In 1999, did we know if the average breast cancer had three, versus 30, versus 300 mutations?
  - No, and most importantly, we didn’t know how many were “true drivers”

[The Two Hit hypothesis](https://en.wikipedia.org/wiki/Knudson_hypothesis)

- [Knudsen](https://en.wikipedia.org/wiki/Alfred_G._Knudson) described it as…
  - i) The inactivation of the tumor suppressor gene (a gene when its function is disabled, cancer becomes more likely)
    - “Nearly all of the genetically inherited cancer types that people are familiar with, come from having an inherited alteration that partially or completely disables a tumor suppressor gene.”
  - ii) The activation of a tumor promoting gene (oncogene)
- So you’re born with two copies of each gene, and one of them is not working, of a tumor suppressor gene. Later on in life, just from a stochastic process, you only have to hit it once, not twice, which is far less likely. That’s why these are patients that are getting cancer in childhood and adolescence.
- And multiple of them over time, new, unrelated cancers, sometimes in the same organ (e.g., multiple colon cancers)

*However*… we now know

- - Even in the most genetically simple cases, we have plenty of evidence now that suggests that you get these genetic alterations that can dial the combination lock in the right way, but the simplest genetic defined cancers almost certainly have then an “epigenetic” (as in not hardwired) mutation alteration change as well where they occupy a different state of development compared to their normal cell counterparts (“state change”).

- *In other words…The mutations then cause epigenetic changes that allow genes to do things that its not normally able to do like become more hardy, makes it be able to survive insults, makes it be able to “travel” and become metastatic*

Using the HIV case study:

- At the time Keith was finishing school, [AZT](https://en.wikipedia.org/wiki/Zidovudine)s were starting to be used to treat HIV/AIDS successfully
- **Keith said his talking point was**…“*we need to find, in cancer, as many ‘AZTs’ as we need, as the initial foot in the door. We know we’re going to receive resistance in this much more complex entity that is a human cell that’s gone rogue, versus relatively simple virus. But it’s when we poke it with the AZT equivalents, we’re going to learn about how it is that it tries to adapt. That’s going to allow us to develop rational combination therapy exactly the way the HIV field does.*”
- “**I still say that in 2019. It still hasn’t really happened.**”

We have a lot of drugs that inhibit things, and few that **activate** things

- “If you think about cancer, and its genetic assembly then and now, we don’t know how to restore the function of something that’s lost, particularly if it’s wildly genetically disabled, to the point of even missing from the DNA of a tumor cell in some cases. We don’t know how to replace that. This was the hope of gene therapy, the dawn of my career, that we might be able to figure that problem out.”
- “We haven’t figured it out by a long shot. Inhibiting things that are activated, that has been where there has been success A, in all of medicine, and B, in oncology.”

## Cancer immunotherapy: History, how it works, and why some cancers respond and others don’t [46:00]

Localized therapy

- We’ve reached the limits of local therapy…
- Surgery and radiation work pretty darn well when they work, but there are not a lot of ways to make it better (other than we can continue to minimize their adverse effects)

Chemical chemotherapy (systemic treatment)

- For 25 years (’74 to ’99), we basically cured one additional cancer

**Immunotherapy:** Another idea for systemic type of therapy

- Once the mutations happen to cancer, they cease to be purely self…they start to display a little bit of non-self characteristic
- We have this branch of the immune system that is staggering effective at eradicating non-self things (namely viruses)
- In the ’90s, we had a number of people making progress using immunotherapy

*What did we know by the late ’90s about immunotherapy?*

- What had been recognized pathologically, decades before, was that there are some tumors that, at the time of surgery, are evidently visible to the immune system (because you can find a ton of immune cells infiltrating into them)

*What cancers were we seeing this in?*

⇒ Example, [melanoma](https://www.mayoclinic.org/diseases-conditions/melanoma/symptoms-causes/syc-20374884)

- Melanoma harbors just about the [largest number of mutations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3600117/) per cell of a tumor that succeeds in becoming a cancer
- They’re picking up so many mutations, these melanocytes, the precursors to melanoma, from ultraviolet radiation (The vast majority of which we think are useless to the formation of cancer)
- What’s the typical number of mutations in metastatic melanoma cell?
  - It’s high thousands… you’ll find multiple mutations per gene in a melanoma. So on a mutations per megabase and then scale that out to the-
- How many of those do we think are playing a functional role?
  - Five or six
- Infiltrating immune cells and T-cells that are the variety that can clear a virally infected cell, and can kill a cancer cell when they see that the internal contents being presented on the cell surface, by the so-called [MHC complex](https://en.wikipedia.org/wiki/Major_histocompatibility_complex), have enough difference from self
- Those that had the *most robust immune cell infiltrate*, were going to be **least likely to be life-threatening to the patient**

⇒ In other words,

- If you look at 100 patients and determine which people had the most TIL (tumor infiltrating lymphocytes) you could predict who’s going to be alive in 10 years

[**PD-1/PD-L1 inhibitors**](https://en.wikipedia.org/wiki/PD-1_and_PD-L1_inhibitors)**—The huge waterfall event in the immunotherapy:**

- When [PD-1/PD-L1 interactions were discovered](https://blog.dana-farber.org/insight/2019/05/the-science-of-pd-1-and-immunotherapy/) and then leveraged as a therapeutic
- That fraction of cancer patients who are one drug away from clearing their tumor with a PD1 antibody (e.g., melanoma with a ton of immune cell infiltrate)
- Yes, their cancer succeeded, but they had the immune system nibbling at their heels at every step of the way and **we just have to block this one** [**checkpoint inhibitor**](https://www.cancer.org/treatment/treatments-and-side-effects/treatment-types/immunotherapy/immune-checkpoint-inhibitors.html)

**The immune system**

- If you unleash the full immune system, it doesn’t just kill cancer cells, it kills a bunch of things
- The purpose of dampening effects on the immune system are that you don’t just mount an immune response and have it just take over your body
- These “brakes” exist for a reason

Consequences of turning it off (or way down)…

- We’re exposed to microbial pathogens that are trying to infiltrate all the time
- **Gut bacteria**: You wipe out someone’s immune system with chemotherapy (or bone marrow transplant), and those [bacteria that are living in the gut will infiltrate](https://www.ncbi.nlm.nih.gov/pubmed/26147207) ⇒ “This is a really active border zone that’s being policed all the time.”
- Chemotherapy weakens the immune system, for example

Consequences of turning it up systemically…

- In the case of [Interleukin 2](https://en.wikipedia.org/wiki/Interleukin_2), you saw a [systemic inflammatory response syndrom](https://en.wikipedia.org/wiki/Systemic_inflammatory_response_syndrome)e which was as life-threatening as the cancer
- You were teetering between the patient dies of what looks like sepsis versus the patient dies of cancer. You have to thread that needle.

Narrow immuno therapeutic index…

- The asymptote was reached very early
- What were the cancers that responded?
  - Melanoma, and
  - [Renal cell carcinoma](https://en.wikipedia.org/wiki/Renal_cell_carcinoma) (kidney cancer)
    - Kidney cancer, for reasons that we’re still trying to unpack, is very immunogenic
    - It is highly visible to the immune system.
    - When you diagnose a kidney cancer, at the time of surgery, the amount of infiltrating immune cells, active immune cells, so called cytolytic T cells that are churning out the enzymes that will kill their neighboring cancer cells
    - **RCC is an outlier**… If you look at mutation burden in relation to this immune recognition, there’s a very strong correlation across all of cancer, with a couple of outliers… renal cell carcinoma is an outlier on that curve
    - It’s immunogenic **without a high mutational burden**

> “But there’s a story here across cancer. . . there’s this whole issue of ‘what determines visibility to the immune system, versus invisibility?’”

For more, check out Keith’s paper: [Universes Collide: Combining Immunotherapy with Targeted Therapy for Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4258160/)

## MHC complexes, and cancer cloaking mechanisms [56:00]

> “Successful cancers have to find cloaking mechanisms. They will not succeed otherwise.”

**Major histocompatibility complex (MHC)**

- Cell surface proteins that have the opportunity to sample internal contents, protein fragments, etc.

MHC Class 1 and Class 2

- We each have a portfolio of them
- We inherit a massive diversity of these from our parents
- Class one and class two can hold different size protein fragments
- Class 2 can hold longer peptides that can see potentially bigger repertoire than Class 1

**⇒ House party analogy**

- MHC is the guy that got hired to help make sure the house party doesn’t get out of control
- He’s roaming around the house looking to try to figure out, do I need to take any of these guys outside to show the police?
- [T cells](https://en.wikipedia.org/wiki/T_cell) and other immune cells (the “cops”) are “interviewing” normal cells constantly in effectively all organs
- This surveillance process is happening and we think viral pathogens are what created the evolutionary pressure to evolve this system
- On that note, cancer couldn’t have been the excuse because it’s distributed across ages 40, 60, to 80 so there is not enough evolutionary pressure (i.e. we’ve already reproduced)
- When you get a sore throat, for example…
  - the pain you’re feeling in your throat is the inflammation…it’s the actual endothelial cells within your throat that are hurting, because a virus has got in there
  - The virus has hijacked your DNA replication system because it wants to survive and it can’t make its own DNA
- In the process, new proteins are showing up inside a cell so these little antigen presenters bringing this abnormal proteins (and normal proteins as well) to the surface to be reviewed by the T cells
- So the T cells, and other immune cells,  (the “cops”) then decides which proteins are okay and which ones need to be taken out
- Note: The differences in a peptide fragment or protein fragment, the **position of the abnormality** matters. If it’s in the middle, that’s able to be seen more efficiently.

**A point worth mentioning:**

If cancer is developing all these mutations and trying to become a cancer…

*-What might be a trick that you could use to try to evade the immune system?*

*-How about if you disable this machinery?*

*-And how about if you just don’t allow MHC complexes to be made?*

- It turns out [natural killer cells](https://en.wikipedia.org/wiki/Natural_killer_cell) don’t like that very much
- There’s this very primordial branch of the immune system that we think about innate immunity, adaptive immunity, as being primordial versus more modern “higher organisms” having them
- These natural killer cells, which are part of the more primordial immune surveillance machinery, if they see a cell not showing MHC complexes, that targets that cell for destruction

**How many cancers survive the onslaught of therapy**

*⇒ Activated immune system therapy*

- In trying to understand the features of cells that will survive the onslaught of an activated immune system after checkpoint therapy (e.g., PD-1 or [CTLA-4](https://en.wikipedia.org/wiki/CTLA-4))
- Some patients will clear their tumor, and they’re cured
- There are those who don’t clear their tumor, and they’re not cured (i.e., complete remission with a relapse or just a partial remission)
- Amazingly, if you look at the data with the [PD-1 antibodies](https://www.ncbi.nlm.nih.gov/pubmed/28213726)
  - 10% of cancer patients currently are getting a heroic benefit from that therapy
  - 20% do respond and get some benefit (tumor shrinkage)
- This activated immune system has just been raging, yet many cancers survive… h*ow do the cancers survive?*
  - They start to dial down their MHC complex *expression* through genetic and epigenetic means… just enough to satisfy the [NK cells](https://en.wikipedia.org/wiki/Natural_killer_cell), but no more

> “They find this new homeostatic setpoint, and this is true in metabolism, and other programs in cancer, that they find new setpoints under selective pressure of the onslaught, in this case of activated immune systems.”

*⇒ Oncogene targeted therapy*

- There is now more and more convergence (as opposed to divergence) that has been emerging in the cancer therapy resistance world
- Cancer that survives both immune system activation and oncogene targeting is the same sort of phenotype ⇒ i.e., cancers are adopting similar programs to be able to try to survive the onslaught, even from those two very different modalities

## Comparative biology of cancer: Why some cancer can evade immune detection better than others [1:03:00]

*Is it safe to say that the lethality of cancer is directly proportional to that evasion?*

- Pancreatic cancer and [glioblastoma](https://www.mayoclinic.org/diseases-conditions/glioblastoma/cdc-20350148) are examples of cancers that are not very immunogenic on the spectrum (i.e., meaning the immune system does not catch them and kill them very easily)
- At the time of diagnosis, if you take note of how much immune recognition is there and compare that to:
  - how much does that relate to how long someone lives
  - how likely they are to respond to immunotherapy
  - how likely they are to respond to even to conventional chemotherapy
  - You can splay cancer out, all cancer types, and there’s heterogeneity within cancer types as well (e.g., not all lung cancers are the same)
  - Looking at all that you can come up with some of these that are aggressive tumors, they’re not being seen adequately, so they’re not being slowed by the immune system in their evolution

*What is it about a pancreatic endocrine cell that would have it be so protected?*

- “This is a black box at the moment. What you’re asking is the fundamental comparative biology question in cancer.”
- The comparative biology questions are: *What are the building blocks, genetic, epigenetic, the metabolic features, and how did each of these tumors assemble themselves to be able to accomplish the various behaviors of cancer that make them lethal?*
- We have more black boxes in diseases like pancreatic cancer and glioblastoma

**Hormonally driven cancers**

“They are a unique entity”

⇒ Examples:

- Prostate cancer
  - Almost all hormonally driven, at least at its outset.
  - And it can evolve away from hormonal drive/dependence during its subsequent evolution.
- Breast cancer
  - A significant portion of breast cancer, but not all, is hormonally driven
- “Those cancers need to be considered separately because they’re still using an issue of origin dependent program of using the feeder, the hormone, to help achieve its purpose.”

**Keith summarizing the challenge of treating cancers that are not immunogenic**:

“If we had better insights into this, we would have more hypotheses moving towards therapeutics in these cancer types. But the have and have not spectrum in cancer is only getting wider. The advances that have been made in certain areas where we very clearly fingerprinted the top of the pyramid vulnerability, it’s not just about mutations. I mean really it is about other cancer programs that are at the forefront of that cancer/cancer type.

> The AZT equivalent has been worked out to dismantle that one program. Doesn’t cure everybody, but it helps patients directly, perturbs the hell out of that cell, and I still maintain the hope that secondary vulnerabilities are going to come from being able to have enough AZT-like primary interventions, or points of vulnerability.”

## What we learned from the Cancer Genome Atlas Project [1:07:00]

**Scary concept**: Some of these gene mutations may have no obvious, immediate, targetable quality. In addition to having no targetable quality, they also enable **epigenetic change** that itself is the problem, and *much more difficult* to target.

[Cancer Genome Atlas Project](https://en.wikipedia.org/wiki/The_Cancer_Genome_Atlas) (whole genome sequencing of large numbers of cancers)… *what did it teach us?*

- *The big discovery* was how commonly you will find, across cancer, driver genetic events (i.e., causative genetic alterations) in genes whose protein product [regulates chromosomal wellbeing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3767041/) (i.e., epigenetic regulators)

[**Chromosome**](https://en.wikipedia.org/wiki/Chromosome)

- Chromosomes are complicated,
- They’re dynamic in normal cells, and they’re **definitely** dynamic in cancer cells.
- Blueprint analogy:
- Certain cells in the body only need to read *one segment* of the blueprint to be able to do their job
- But each cell has the entire blueprint at their disposal
- Cancers like to **open up** the blueprints
- It’s the only way that a lung cell can figure out how to travel like a white blood cell… it has to open up the blueprint and see that part of it

**This discovery was huge because it showed**:

First, how cancers do it…

- They create this so-called plasticity, this ability to basically go from being a differentiated lung cell, into a less differentiated lung cell that’s not now able to do things that it’s normal lung cell couldn’t do
- In other words, It gives up some of its lung superpowers in exchange for greater pliability
- The blueprint is open, but not just wildly open, but very *strategically and purposefully*

We are just now developing chemical tools…

- To alter the function of these proteins to see what would happen: *Can you actually restrict the blueprint reading?*

⇒ Melanoma example:

- Melanocytes derive from the so-called neural crest (brain tissue and these pigment producing cells come from the same tissue type)
- What happens when you blast a melanoma with BRAF targeted therapy and a PD-1 antibody, and you’re shrinking tumors down (but not eradicating) the cells
- *What do those shrunken cells start to look like?*
  - They look like [neural crest cells](https://www.ncbi.nlm.nih.gov/pubmed/24441506)
  - In other words, they take a step back in the evolutionary, developmental path, and in doing so find **heartiness mechanisms** that allow them to survive an activated T-cell repertoire, allow them to have their dominant driver activated oncogene largely disabled, and be able to not only survive, but ultimately then begin again, growing and becoming life threatening.

**The theme across many cancers**

- Common principle is this so-called epigenetic state change, and the genetic determinants of it
- Many cancers have this component
  - Lung cancer, breast cancer, and other tumor types where there’s been substantial advances in terms of therapies, and real outcomes being achieved for patients

## Defining targeted therapy, HER2 breast cancer, chronic leukemia, and the translocation of chromosomes [1:12:00]

*How do you define targeted therapy, and what do you think is really our first great example of it?*

- Targeted therapy is simply that we “knew what we were doing from the beginning”
- None of the conventional chemotherapy drugs were known to be DNA binding or designed and engineered to be them
- But the target product profile, was spec’d out for everything that we call targeted therapy.

*So we actually had two versions of targeted therapy at work in the 90s*:

  1 [Epidermal growth factor receptor](https://en.wikipedia.org/wiki/Epidermal_growth_factor_receptor)

  2 [HER2/neu](https://en.wikipedia.org/wiki/HER2/neu)

- These two surface growth factor receptors had been discovered and cataloged in terms of their biologic function in many cancers in the 80s, and then antibody that could reach the cell surface component of these receptors were engineered and were being investigated in clinical trials.
- They weren’t causing heroic effects, as had been hoped, but those were definitely targeted therapies.
- They did end up moving the needle, and largely in combination with conventional chemotherapy, notably in the case of…
  - [HER2 targeted therapies in breast cancer](https://www.cancer.org/cancer/breast-cancer/treatment/targeted-therapy-for-breast-cancer.html)
  - [EGFR antibodies in colorectal cancer](https://www.cancer.org/cancer/colon-rectal-cancer/treating/targeted-therapy.html)

[**HER2 and breast cancer treatment**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4381787/)

A woman with HER2/neu, what’s the success rate?

- The naked antibodies produced a 10-20% response rate (tumor shrinkage by more than 50%)
- This is a notable benefit in a *pretty small fraction* of patients when given as monotherapy
- Conventional chemotherapy had a 30-40% likelihood of causing the same amount of regression
- When you combined HER2 therapy with chemo, you’re now producing 60+% response rates
- To clarify, these are mostly PR, partial response, and not CR, complete response
- Keith calls this discovery a “slow motion aha moment”

[**Translocation of chromosomes**](https://en.wikipedia.org/wiki/Chromosomal_translocation)

Keith calls this the “fast aha moment”

*The types of leukemias*:

- Acute or chronic
- Myeloid or lymphoid

Who gets the acute version?

- Children, mostly, because acute cancers take less “hits” to become cancer
- There is a [greater than 90% cure rate](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4771966/) using with multi-agent chemotherapy cocktails

Chronic leukemias

- Adults, more commonly, get chronic leukemias, but can also get acute leukemias that are more genetically complex than the kid’s versions (and therefore harder to cure with the same exact chemotherapy regimens)

⇒ One form of chronic leukemia, [Bcr-ABL](https://en.wikipedia.org/wiki/Bcr-Abl_tyrosine-kinase_inhibitor) translocated [chronic myelogenous leukemia](https://en.wikipedia.org/wiki/Chronic_myelogenous_leukemia)

- People could live with it for five to seven years
- If you replace their bone marrow (i.e., bone marrow transplanting) you could cure a minority population (maybe 40%)
- In the 1970s it was discovered that 95% of CML patients had a macroscopic chromosomal change ([Philadelphia chromosom](https://en.wikipedia.org/wiki/Philadelphia_chromosome)e)…  **the repositioning of one portion of a chromosome to another**

## Tumor protein P53, the most famous tumor suppressor gene and its ubiquity in cancer [1:17:45]

**Explaining chromosomes, base pairs, and genes**

*Chromosomes*

- We have 23 pairs of chromosomes
- Get one of each from each of our parents
- 22 look a certain way, and then XX or XY determines gender
- Range in size: Size difference relates to the amount of genetic content in each of them

*Genes*

- We have approx. 30,000 genes that actually code for a protein
- The [coding genes](https://en.wikipedia.org/wiki/Coding_region) only account for a small fraction of the total genes (~1.2%)
- We do not know the function of the vast majority of base pairs (at a minimum, they’re at least important “scaffolds”)

Mutations

- Individual genes, amongst the tens of thousands, vary enormously in their size, and therefore the amount of genetic code in them
- You can develop a mutation, either because of a replication error, or because of insult.
- So the larger the gene, the greater the probability it can acquire a mutation

**Tumor protein p53**

[TP53](https://en.wikipedia.org/wiki/P53) is the most famous tumor suppressor gene

- Approx. a couple hundred thousand base pairs
- Multiple [exons](https://en.wikipedia.org/wiki/Exon) that are separated by [introns](https://en.wikipedia.org/wiki/Intron)
- Exons are stitched together when the gene is transcribed into RNA (and introns are left out)
- We are starting to realize that introns matter more than we thought
  - That’s where all the regulating elements really largely reside
  - They’re not “junk DNA”

**P53 and cancer**

- [50% of cancers have genetic aberration of P53](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5233470/)
- Partly it’s just a really large gene, so you can pick up mutations in it seemingly relatively easily
- But it’s also a master regulator
- Tons of translated proteins that interact with the protein product P53
- In cancer, it is the most magnificent and well mapped out of these networks

*What is the function of P53?*

- It’s basically a sensing apparatus
- It’s trying to understand how bad things are in a cell
- How intact the DNA is
- How many mutations and insults
- How many of those exist, and are being repaired at any one time
- The DNA repair machinery is at work and it then feeds then into P53

*Does P53 possess the power to command apoptosis to directly?*

- **Yes**, P53 senses damage in a normal cell
- In a cell that’s becoming abnormal, it will monitor it
- If there’s *catastrophic damage*, then it’s P53 will decide to undergo a civilized cell death (apoptosis), rather than try to repair it
- **P53 is the master regulator in all cells** in the body

**Peter is suprised**: *So 50% of people who get cancer have a perfectly intact P53???*

- Yes, however… the likelihood that they will have a **genetic aberration** in one of the *inputs, or one of the outputs* of P53 is enormously high.
- In other words, **the gene P53, only 50% of the time is mutated, but that pathway is virtually always host to a mutation**

⇒ Example, [Retinoblastoma gene](https://en.wikipedia.org/wiki/Retinoblastoma_protein)

- Another famous, long-ago described *tumor suppressor gene*
- What was **not known** decades ago (but is known now) is that it [RB is actually “downstream”, or regulated by, P53](https://www.ncbi.nlm.nih.gov/pubmed/17080083)
- You will find cancers that if they don’t have the P53 mutation, they will have an RB mutation
- And its alteration will do much of what a P53 mutation will do

## Activated oncogenes, the RAS pathway, PI3 kinase, RAF gene, and Keith’s “aha moment” [1:24:15]

\*The “activated side” is where Keith has spent most of his career\*

Epidermal growth factor receptor and HER2

- These were the *early* discovery/therapeutic translation exercises
- To this day, we think is the biggest unit in terms of where the **activating events** happen
- We have drugs now in the growth factor receptor, [RAS, and RAS pathway system](https://en.wikipedia.org/wiki/MAPK/ERK_pathway)

Growing without growth factors

- The normal function of growth factor receptors is to literally receive growth factors
- *So in a cancer cell*, if you can figure out how to grow in a **growth factor independent** way… you’ll then be able to…
  - Survive very harsh environments, and
  - Replicate in an autonomous way meaning not governed by not just environment (in terms of nutrient availability, but even what your neighbors are telling you what you should and shouldn’t do)
- Example: Prostate cancer that grows without testosterone (this is “bad news” for the patient)

*Breast cancer: HER2-****positive*** (negatives are much more difficult and a different disease, basically)

- HER2 is genetically amplified which is massively increasing the number of surface growth factor receptors
- This is allowing them to actually complex together and signal for growth in the absence of the growth factor itself
- These growth factor receptors feed RAS

**RAS**

- - RAS comes in 3 forms:
    - [KRAS](https://en.wikipedia.org/wiki/KRAS)
    - [HRAS](https://en.wikipedia.org/wiki/HRAS)
    - [NRAS](https://en.wikipedia.org/wiki/Neuroblastoma_RAS_viral_oncogene_homolog)

- **[25+% of all cancers have a RAS mutation](https://www.cancer.gov/research/key-initiatives/ras)**

Where is RAS?

- RAS sits downstream of the growth factor receptors
- just on the inside of the cell surface

Can we drug it?

- We can’t drug it directly with an antibody
- Small molecule inhibitors have not been very effective

RAS has so-called “effector pathways”

- *How many*?
  - About 6 (although not much consensus on this)

What is downstream of RAS?

- RAS will activate other cascades and the two most famous are:
  - 1) [MAP kinase pathway](https://en.wikipedia.org/wiki/MAPK/ERK_pathway) (where Keith has focused his career)
  - 2) [PI3 kinase pathway](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase)

**PI3K pathway**

\*[Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) and [Craig Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson) have done a lot of work on PI3K\*

\*Metabolic regulation comes largely (but not completely) through the PI3 kinase pathway\*

[20% of cancers have PI3 kinase intrinsic mutation](https://www.ncbi.nlm.nih.gov/pubmed/15016963)s in one of the isoforms of PI3 kinase (most commonly [alpha](https://en.wikipedia.org/wiki/P110%CE%B1))

What is the mutation?

- It’s a “nasty little trick”
- It’s co-opting the metabolic regulation pathway
- It largely explains growth factor independence of cancers that have those mutations
- But these are *metabolic pathways* that are fundamental to **normal cells** as well

⇒ *And so where’s the therapeutic index, in terms of leveraging this observation?*

- This has been a major challenge
- At least one [positive result is in PI3 kinase mutant breast cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6014315/)

Common theme:

- When you activate an oncogene in cancer…
  - You will see that the downstream wiring diagram changes, and that pathway is now able to do more things than it could in its normal, non-mutated state
  - It’s what we mean by oncogene addiction… **oncogene addiction means that cancer really needs that activated oncogene** to be able to do not just one thing, like dry proliferation, but actually to alter other essential programs for cancer

⇒ Normal cells ⇒ They can break up the work between proliferation and metabolism (i.e., between MAPK and PI3K)

⇒ Cancer on the other hand…

- Melanoma, for example…
  - We call it a paradigmatic MAP kinase pathway activated tumor
  - It “cares” about the PI3 kinase pathway, but in a *secondary* way
- Breast cancer is the opposite, it “cares” more about the PI3K pathway

**Targeted therapy**

- It wasn’t until the early 2000s that the concept of targeted therapy was thought about
- We figured out this term **oncogene addiction**: This idea that by a cancer co-opting this one molecule, it’s actually now essentially using it to drive more components of cancer biology than you have thought in terms of the normal physiologic role of that molecule, and where there’s compensatory mechanisms and parallel processing that can happen in normal cells that make it not so dependent on that function of that one molecule.

In summary:

- 25+% of cancers have a RAS mutation.
- 20% of cancers have a PI3K mutation
- [8% of cancers have a BRAF mutation](https://www.ncbi.nlm.nih.gov/pubmed/12068308)

**BRAF**

- BRAF is intrinsic in the [MAP Kinase Pathway](https://en.wikipedia.org/wiki/MAPK/ERK_pathway) (aka Ras-Raf-MEK-ERK pathway)
- It’s the *most popular point of mutation* in that pathway

*What percentage of melanomas have a BRAF mutation?*

- About 50%

**2002 Nature paper:** [Mutations of the BRAF gene in human cancer.](https://www.ncbi.nlm.nih.gov/pubmed/12068308)

- Sequenced the RAF genes (not RAS, which is undruggable, unfortunately, still to this day)
- Why did they do this?
  - Because the MAP Kinase Pathway had been implicated as being relevant in cancer for a couple decades
  - And no one knew anything other than RAS mutations that can activate it (no one understood how and why the pathway could be co-opted by cancer cells)
- So a logical thing to do would be just go one bucket down from RAS to the molecule that RAS regulates, which is RAF
- Three isoforms of RAF
  - [c-RAF](https://en.wikipedia.org/wiki/C-Raf) (most understood at the time)
  - [BRAF](https://en.wikipedia.org/wiki/BRAF_(gene))
  - [ARAF](https://en.wikipedia.org/wiki/ARAF)
- ⇒ *The hypothesis*… These RAF genes are probably going to have some mutations and **c-RAF would be the one most likely** because it’d been the best studied up to that date
- ⇒ *The finding*… rarely do you see c-RAF mutation or ARAF mutation… **BRAF showed the most mutations**

- 8% of all cancer was the estimate when they sequenced 484 tumors

*Can RAS actually play a* ***causal role*** *in the mutation or is it more a function of the things that bug Ras bug BRAF?*

- In a cancer that has a RAS mutation, you will not find the BRAF mutation (and vice versa)
- RAS is sufficient, or BRAF is sufficient, to get activation of the pathway
- How they accomplish it varies and we don’t understand all the determinants of why certain cell types are more prone to picking up certain mutations as their means of activating certain pathways

**Why Keith chose to study melanoma**:

- Keith was at UPenn
- This aha moment in this paper was that 8% of cancers have BRAF mutations
- And 50% of melanoma had a BRAF mutation
- And the vast majority of those mutations affected a **single point in the gene**

Clarifying what “a single point” in a gene means…

- You have 23 chromosomes
- ~30,000 genes
- Therefore, you’ve got about 1,000 genes wrapping around each chromosome (you’ve got 23 pairs of those)
- Each gene could be anywhere from a few hundred to a few hundred thousand base pairs
- So you could get **one letter wrong out of 100,000**, and you change the function of a gene

Phosphorylation

- We have these pathways where one molecule alters another, alters another (however, we too commonly think of these as linear… one augmenting another followed by another… and not as systems where there’s side inputs into these pathways)
- When Ras itself is activated, it pushes RAF into a pair of molecules (dimers) and will facilitate their [phosphorylation](https://en.wikipedia.org/wiki/Phosphorylation) or activate molecular feature change that allows them to be active
- Kinases are a form of enzyme whose job is to add a phosphate group (a single fairly small molecular entity) to specific amino acid residues on its target
- So… Ras will activate RAF ⇒ RAF will activate MEK ⇒ MEK will activate ERK… all through phosphorylation events
- Phosphate residue additions are not the most important, but they’re a key facet of how the molecular machinery works inside of cells in terms of how to activate (or inactivate) these networks

⇒ Growth factor receptor related networks

- Right in the middle of the so called kinase domain, the part of BRAF that actually is basically responsible for latching a phosphate residue on MEK (its downstream substrate) … right in the middle of that domain is where these mutations happen in the vast, vast majority of cases
- “That discovery alone was just shocking”

*Was this discovery in the* [*2002 Nature paper*](https://www.ncbi.nlm.nih.gov/pubmed/12068308)*?*

- **Yes**… the distribution, if you will, of them being the 600 position mutations availing at the 600 position and the amino acid sequence, right in the heart of exon 15, which is in the middle of the Kinase domain
- The additional killer experiment that they did was to basically transfect that into a fibroblasts, so a normal cell and show that could transform them and make them proliferate
- In summary, the paper revealed… **the phenomenology that these mutations exist as well as this wild distribution (or non distribution) of this mutation piling up at this one position**

> “It was just this huge aha moment. And when you link that in melanoma with this couple decades worth of insights that the MAP Kinase Pathway really seemed to be important in this tumor and now you find these mutations sitting here right in the middle the pathway. That was just like the most drop dead obviously important thing in my view and a couple other people’s view but shockingly few other people at the time decided to take a complete left or right turn and focus on it. That was the dawn of my career.”

## Advice for starting your career as a scientist/clinician [1:37:00]

**Advice for the petrified (or even paralyzed) young trainee who’s thinking…**

- *How am I going to find my entry point?*

- Where am I going to find something to work on?

⇒ Keith would say…

“*Okay, you’re not waiting for something top secret that someone comes and whispers in your ear. What you’re waiting for is the Nature, Science, and Cell paper to be published that describes something that’s very important in an area that you’ve said for some intuitive reason that you have an interest in.*

*And trust me, the field is not going to drop everything that they’re doing, to go pursue that. But if you’re at the dawn of your career, you’re in the perfect moment to now actually build the knowledge base, meet the people who are the relevant players, assemble the knowledge, pull together the tools to actually start testing this hypothesis. Whether it’s your wet lab investigator or clinical investigator, it’s the same. I’ve never witnessed a case where someone’s been basically crowded out, or hasn’t been able to make a career in investigation by using that approach.*”

## Fusion-driven cancers, targeted therapy, and the Bcr-Abl/chronic myelogenous leukemia case study [1:39:45]

BRAF mutations were discovered in 2002…

*…Why did people studying melanoma ignore this finding?*

- Tumor immune interactions were a cooler thing in melanoma
- Melanoma has an inordinate number of mutations
- So this finding shows just one mutation (BRAF)… SO WHAT?!
- If there’s a cancer on earth where we’re poking that beast with a single drug approach (i.e., just antagonizing BRAF) is going to do nothing, melanoma is the example (this was the argument against caring about BRAF)

**Chronic Myelogenous Leukemia**

- Observed by [Peter Nowell](https://en.wikipedia.org/wiki/Peter_Nowell) decades ago… a characteristic event in CML (95% of cases) is this [massive chromosome shift](https://en.wikipedia.org/wiki/Philadelphia_chromosome)
- The rest of the DNA wasn’t shredded, it was just this one massive migratory move
- NOTE: This is striking large… you could literally see this migration under a microscope
- With CML, you had what appeared to be, at the chromosomal level, a genetically simple cancer where nearly always one big fragment migrated to join another big fragment

*⇒ What was at that juncture? Why were those two coming together?*

- CML is a white blood cell cancer
- To get chronic myelogenous leukemia, you needed this genetic migration thing to happen
- On one side of it is the [BCR gene](https://en.wikipedia.org/wiki/BCR_(gene))
  - and that gene is basically responsible for immunoglobulin reshuffling in white blood cells.
  - It’s a very dynamic, very active gene in white blood cells that they’re going to be able to do their immunologic job and create the relevant repertoire of foreign recognition.
  - Then the [BCR gene](https://en.wikipedia.org/wiki/BCR_(gene)) needs to be active to facilitate that program. Let me put it that way.
  - The [BCR gene](https://en.wikipedia.org/wiki/BCR_(gene)) is on one end of this migration event.
  - It’s not a doer in and of itself. It’s just a very active gene locus that’s just on, on, on, in white blood cells.
- On the other end is the [ABL kinase](https://en.wikipedia.org/wiki/ABL_(gene))
  - So, ABL kinase is a signaling molecule that’s inside of cells.
  - It’s not important in all cell types.
  - It’s important to a degree in white blood cells.
  - But this is a signaling molecule that does a lot of work inside of cells. It’s a kinase so it phosphorylates substrates.

⇒ [Bcr-ABL](https://en.wikipedia.org/wiki/Philadelphia_chromosome) (Philadelphia chromosome)

- BCR is stitched to ABL … it equates the Bcr-ABL translocation or fusion
- You now have a new gene product of these two genetic components being stitched together that otherwise wouldn’t have been (They are quite far apart from each other on chromosome 9 and 22)
- When they come together, you crank up the expression of ABL kinase

![](https://peterattiamd.com/wp-content/uploads/2019/07/philadelphia-chromosome.jpg)

**Figure 1. Philadelphia chromosome. A piece of chromosome 9 and a piece of chromosome 22 break off and trade places. The BCR-ABL gene is formed on chromosome 22 where the piece of chromosome 9 attaches. The changed chromosome 22 is called the Philadelphia chromosome.** Image credit: [cancer.gov](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/philadelphia-chromosome)

NOTE: ABL kinase is normal…

- *It’s not mutated* . . it’s expression is just jacked up to a preposterous degrees
- So now you have an enormous amount of ABL kinase being made in these white blood cells because the BCR locus is just being driven all the time in normal white blood cells
- BRAF, by contrast, has this activating mutation sitting right in the middle of the nucleotide substitution, resulting in an amino acid substitution that alters its kinase function (this is just normal ABL)

\*The first-line therapy for most patients with chronic myelogenous leukemia: [Bcr-Abl tyrosine-kinase inhibitors](https://en.wikipedia.org/wiki/Bcr-Abl_tyrosine-kinase_inhibitor)\*

**There are 3 types of mutation/genetic alteration:**

1. Amplification
2. Point mutation
3. Translocation, or fusion

*Do most fusions have this phenotype of “normal protein just doing more”?*

- “Precisely”
- And kinases are the ones that have been discovered, described and now drugged multiple times

A recent insight about fusion/translocation-driven cancers:

- Most tend to be genetically simple
- Point mutations, by contrast, happen in the sea of genetic complexity (melanoma being an example)
- But all BRAF mutations distribute across cancer types that are actually quite genetically complex (meaning there’s a lot of other genetic aberrations turning on and turning off other things)
- But these fusion driven cancers, they seem to get a lot of juice **out of that one genetic alteration**

**The first kinase inhibitors**

- The [first kinase inhibitors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4491790/) were created for CVD
- There are about 600 kinases and they’re highly related, but then there’s some that are more distant cousins than others
- And if you try to inhibit a kinase, it’s pretty easy to pick up inhibitory activity against another kinase because of their relatedness
- [Imatinib](https://en.wikipedia.org/wiki/Imatinib), for example, the first ABL kinase inhibitor, was not just an ABL kinase inhibitor (it was also a [c-Kit inhibitor](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4975146/) for gastrointestinal stromal tumor)

**\*NEJM papers in 2001 testing the BCR-ABL kinase inhibitor\***

**–**[Efficacy and Safety of a Specific Inhibitor of the BCR-ABL Tyrosine Kinase in Chronic Myeloid Leukemia](https://www.nejm.org/doi/full/10.1056/NEJM200104053441401) (Druker et al., 2001)

–[Activity of a specific inhibitor of the BCR-ABL tyrosine kinase in the blast crisis of chronic myeloid leukemia and acute lymphoblastic leukemia with the Philadelphia chromosome.](https://www.ncbi.nlm.nih.gov/pubmed/11287973)

- Patients with CML were responding to therapy in a phase one trial
- By the phase III trial, patients were having transformational responses
- These trials happened during Keith’s first year of fellowship and he was thinking… *“This is the future of cancer!”*

⇒ The objection to that big moment was…

- This is Chronic Myelogenous Leukemia…this is a genetically simple thing… this is barely cancer compared to pancreatic cancer or non-small cell lung cancer
- It worked with CML, *but why on earth would you think this is going to work in real cancers?*
- This trial was done on **stable phase CML**

- you have a translocation fusion, that does not even mutate the kinase involved
- You have this long period of time where people will have large numbers of these abnormal white blood cells circulating but not impairing their health in any significant way
- HOWEVER, given enough time to evolve, it will pick up more alterations and the rate at which alterations are picked up accelerates also and patients die of an acute leukemia like death
- So CML isn’t “real cancer” in this objection rendering frame here for a good long time, but it certainly becomes real cancer ultimately
- In other words, given enough time, stable CML will become deadly cancer

The [next paper](https://www.ncbi.nlm.nih.gov/pubmed/11287973) in this back to back NEJM papers:

- The same authors were reporting on the activity of Imatinib, the anti-tumor effects of Imatinib in patients with accelerated phase and blast crisis CML
- Same disease now allowed to genetically evolve and become more complex and certainly to pick up additional mutations beyond this foundational translocation event.
- What happened in those patients?
  - You got responses, but they weren’t durable
  - They lasted for months at best, weeks in some cases
  - In other words, you could poke it with a stick, but it would just “laugh its way right around” within a very short time and patients would succumb to their disease

**⇒ So you had a side of the debate that was saying**: “*Never again are we going to find such genetically simple cancers where you can get deep and durable responses from a single agent targeted therapy.*”

**⇒ Keith’s continuing excitement**: He didn’t feel so defeated by that argument because he was thinking… “well this isn’t going to be about one drug. This is cocktails.”

- Of course it’s going to take combinations
- *How high order a combination do we need?* ⇒ Well, that goes back to the building block argument. We still don’t know.

## Targeted therapy for fusion-driven solid tumors, adjuvant systemic therapy, and the HER2 breast cancer example [1:53:00]

**Solid tumors**

- Even in solid tumors, you will find subsets of them that are driven by these translocation fusion events
- They tend to be genetically simple where you get deep and durable responses.

*Example, HER2-positive breast cancer*

- In a metastatic situation: [Trastuzumab](https://en.wikipedia.org/wiki/Trastuzumab), the naked antibody, has the ability to [help a metastatic breast cancer patient live longer for a period of time (several months)](https://www.nejm.org/doi/full/10.1056/NEJMra043186)

*What is* ***adjuvant therapy?***

- Additional cancer treatment (systemic therapy) given after the primary treatment to lower the risk that the cancer will come back. Adjuvant therapy may include chemotherapy, radiation therapy, hormone therapy, targeted therapy, or biological therapy.
  - E.g., After surgery to remove a tumor, the surgeon says he got it all.. But the medical oncologist says we need to do chemo to make sure we treat the potential microscopic metastatic disease that still may exist (but we just can’t see it)

**Adjuvant use of HER2 antibodies CURES patients**:

Example,

- Take two groups of women that have HER2/neu positive tumors that are got their tumors surgically removed down to having no evidence of diseases
- Half of them get chemo by itself
- The other half get chemo plus HER2 antibodies
- Women tend to [reduce their risk of recurrence by ⅓ to ½ when taking HER2 antibodies](https://www.ncbi.nlm.nih.gov/pubmed/16236738?dopt=Abstract)

*How long do women have to continue adjuvant therapy?*

- With hormonally driven breast cancers, the treatment is long term
- It’s clear even that 10 years of therapy is better than 5 years of therapy in a population and hormonal therapy prevents relapse at least to a third to half
  - But when you see longer being better than shorter it tells you **you’re not eradicating in everybody, you’re suppressing in some people**
- Is there ever a reason to believe that some patients are being cured?
  - Absolutely.
  - But there’s some patients where disease is just being suppressed and maintained in a micro metastatic state from which they will not die, at least in the foreseeable future,

But the real question is… *Is single agent targeted therapy a tumor clearing treatment for very many cancer patients even when we use optimal next generation early detection methodology?*

- Only in only a fraction of cancer patients
- so we’re still going to need combination regimens to dismantle tumors in their fully complex way

## Advancing melanoma treatment, survival, and cure rates with BRAF-MEK combo therapy [1:59:15]

**Metastatic melanoma treated with BRAF inhibitor monotherapy**

- 9 months improvement in overall survival
- So you’re basically doubling the survival of patients with metastatic melanoma, **but not curing**

Bypassing BRAF

- Keith was seeing that the tumors were *working their way right around the drug* in the MAP kinase pathway
- They were **bypassing BRAF through c-RAF**, most commonly
- It was the easiest trick for the cancer… they didn’t need to develop mutations that resisted the drug itself (which is a theme in Bcr-Abl CML, and in other oncogene-driven tumors that are treated effectively with targeted therapy)
  - In contrast, in fusion-driven cancer in particular…they need to **mutate the actual gene that’s being targeted**, because they need that thing back on (so-called gatekeeper mutations
- But in these BRAF mutant melanoma…
  - You don’t see those mutations emerge
  - Because it’s too easy for these cells to rewire their way past BRAF through c-RAF

MEK

- Keith knew that there were available inhibitors of downstream MEK (the guy that BRAF turns on)
- Those drugs already existed but they weren’t shown to be useful on their own yet anywhere in cancer
- But MEK is right below BRAF and c-RAF.
- Keith and team decided to put those two together and try to intercept the bypass… **and it worked**

⇒ BRAF-MEK combination therapy

- Keith’s papers:
  - [Combined BRAF and MEK Inhibition in Melanoma with BRAF V600 Mutations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3549295/)
  - [Improved survival with MEK inhibition in BRAF-mutated melanoma.](https://www.ncbi.nlm.nih.gov/pubmed/22663011)
  - [Combined BRAF (Dabrafenib) and MEK Inhibition (Trametinib) in Patients With BRAFV600-Mutant Melanoma Experiencing Progression With Single-Agent BRAF Inhibitor](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4226803/)
- They found overall survival improvement to be as big as the BRAF inhibitor monotherapy
- In the adjuvant setting,
  - Prevents relapse by 50%
  - patients receive just one year of therapy and stop treatment
  - And there’s a persistent gap there in terms of cured patients

“This is melanoma we’re talking about, melanoma that will work its way around BRAF inhibitor monotherapy in … six months. You can wipe it out in the covert metastatic state, microscopic residual disease, a.k.a. adjuvant therapy, with that same regimen.”

## The fundamental pillars of cancer growth and survival, and the toolkit we need to attack cancer from all angles [2:02:40]

- There is some real kind of early detection, early treatment theme that is absolutely yet to be fully leveraged and realized because we’re still working on the early detection technology, blood-based mostly (but it’s coming)
- And then adjacent to that, even in some very early cancers, they are already genetically complex

**Fundamental pillars of cancer survival and growth**

- There are some fundamental pillars in **growth**
- And there are some fundamental pillars in **protection**
- We need a tool kit that “knows” which pillars they are hitting so we can stack them together (This is what [HAART](https://en.wikipedia.org/?title=HAART&redirect=no), highly active antiretroviral therapy, did with HIV)

> “We can’t keep hitting the same pillar and expect that we’re going to cure cancer. . .we need the activators of the immune system, we need the inhibitors of the activated oncogenes, we need the drugs that target epigenetic regulators, and we need the metabolic switch regulators.”

## Peter’s clinical framework for thinking about cancer and how Keith might improve it, and how the biotech environment is hampering our ability to put together novel cancer treatments [2:05:00]

\*Paper about the astronaut’s telomere length Peter mentioned: [The NASA Twins Study](https://science.sciencemag.org/content/364/6436/eaau8650)\*

**Peter clinical framework for thinking about cancer**

- Most people are afraid of Alzheimer’s disease above all else, because of the phenotype
- But when you think about probabilistically, most people are afraid of cancer
- The likelihood of getting cancer is somewhere between ⅓ and ½ (depending on gender)
- Peter says he tells patients cancer…
  - Cancer is the hardest to figure out
  - We are the least confident in our ability to reduce risk
    - Atherosclerosis, by contrast, we know more about, have tools in our kit to delay it’s onset, and although it is inevitable, you can push it back until your 100 if you get aggressive enough with it

⇒ Peter’s take:

- *Step 1*: **Try not to get cancer**
  - We know a handful of things that are increasing our risk for cancer, easy examples:
    - Don’t smoke
    - Avoid insulin resistance and obesity

![](https://peterattiamd.com/wp-content/uploads/2019/07/obesity-and-cancer-768x930.gif)

**Figure 2. Cancers associated with overweight and obesity.** Image credit: National Cancer Institute

- *Step 2*: **Look for cancer early**
  - This is a controversial topic
    - One side of spectrum says, the burden of disease is so strong that women should never have a mammogram, and should only see someone if they feel a lump (presumably to avoid false positives)
    - Peter’s side of the spectrum: No woman should ever present with breast cancer
      - Ignoring costs for a minute, Peter says you could layer a mammography (which has horrible sensitivity and specificity) with diffusion weighted imaging MRI and molecular screening, and in that case you should catch pretty much all cases of breast cancer
- *Step 3*: If cancer exists, **use therapies that go after multiple pillars simultaneously** (i.e., immune system, epigenetic regulators, growth factor receptors, metabolic)

For more on power of diffusion weighted MRI check on [Peter discussion with Dr. Raj Attariwala](https://peterattiamd.com/rajpaulattariwala/)

*How would Keith make Peter’s framework more robust?*

- What we’re missing is still a component to the toolbox to be able to actually knock out pillars
- We still need to diversify our toolbox
- We need to figure out how to marry diagnostics with therapeutics

**Marrying diagnostics with therapeutics**

- We need to understand the assembly process of cancer in a patient-specific way and being able to deploy those therapies (not an easy task)

⇒ Following the HIV example,

- We are chronically facing headwind in terms of getting there
- But HIV was able to do it… how?
  - There was a high level of advocacy for HIV
  - And because of the “lead blocking” that was done by the HIV advocacy community, we have a forward thinking regulatory environment in the United States
  - What allowed for the HIV treatment to come to fruition, was that the companies that decided to pursue an HIV treatment as a business model could create the toolbox **within their one company**
    - This made it easier economically and for the incentives to line up
    - Also, the “simplicity” of the HIV (i.e., the number of enzymes in its genome is massively smaller than most cancer) and therefore even within the umbrella of one company, you could see combination therapies being put together

**Keith explains how the current biotech environment is hampering our ability to put together novel cancer treatments**:

**Keith**: “So, 60% of drugs coming in the cancer pipeline now come from small biotech companies. It used to be that big pharma was the driver. And the phrase I often use is that, ‘Big pharma outsourced its R&D to risk taking, venture-backed, highly-specialized, small biotech companies.’ So you’ve got this distribution of where drugs are coming from that is a huge swathe of different firms, many of which have a single asset in the small biotech space.”

**Peter**: “What’s the sweet spot for big pharma? Is it between Phase II and Phase III?”

**Keith**: “Phase II. And that’s the acquisition moment. And if it’s not then, then it’s randomized Phase II/Phase III. The optimal moment, as you said, is kind of ‘where has enough risk been taken off the table?’ And where now you’ve got a commercialization opportunity.

Yes, there’s still innovation and incubation and new therapies coming out of big pharma, but as I said, it’s shrunk down to a small component.

The basic science, as you well know across all public, private domain, is in the public sector. The basic science, the stuff where you can’t guarantee any kind of return in terms of when you’re going to get an insight that you could turn into a potential therapy.

So, you’ve got this fantastic chaos of publicly funded biomedical research (e.g., NIH, [Howard Hughes](https://en.wikipedia.org/wiki/Howard_Hughes)), the world’s greatest by a long shot.”

**Peter**: “What percentage of the world’s pure exploratory science is funded in the United States?”

**Keith**: “90%. . .huge, huge, huge engine here is the public domain. Those discoveries then are out-licensed to small firms, over large firms, by a huge margin. . .You have these hubs of activity, of taking new discoveries, some of which come from outside of the United States even, but then are incubated into companies.

What I’m describing here is this very dynamic, very exciting, very purpose driven, expertise-heavy biotech sector, which is great for so many reasons, but I’m bringing it up as a complaint. . .I register it as a complaint because it’s distributed our toolbox so widely.

We live in a world right now where 0.37% of rational combinations of two cancer therapeutics that are still in investigational territory are finding each other in clinical trials. ([I published on this topic](https://cancerdiscovery.aacrjournals.org/content/6/9/956) a year and a half ago. It is a terrible sampling, mingling rate, terrible.)

We make new discoveries all the time in the academic domain that would suggest a new combination. You’ve got patients dying every day of that addressable cancer, by molecular subtype or whatever. The likelihood that you’re going to be able to launch a clinical trial to marry those two drugs when they exist in two firms **is that small**. That is a terrible problem.

And HIV didn’t have that problem. But because of the complexity of human cells, and therefore human cancer cells, the toolbox is being chaotically distributed. We need a way to change that. And we need a way for drugs to be able to be married in life threatening cancer in a rapid, rapid fashion.

It’s not an inertia problem in the culture, it’s not doctors, it’s not patients, it’s not academic medical centers, it’s not the regulatory environment. It’s not.”

**What we need**:

- We need novel cancer therapeutic investigation
- Actually getting incentives aligned to allow this dabbling to happen is a major, major impediment
- We need quadruplet therapy to dismantle most complex cancers if early detection is only going to get us so far.
- The therapy is ideally across all four pillars

## How useful is CRISPR in terms of tumor suppressing? [2:16:15]

*On the tumor suppressor side, does CRISPR offer any role?*

- This is gene therapy, you need to be able to deliver that to every last cancer cell.

*And how in the world do we do that? Is there a virus that can do this?*

- Not currently.
- 20 years ago, at the dawn of Keith’s career, he though gene therapy was almost ready, but 20 years later, we still don’t have it

The issues:

- The problem seems to be that every single cell is widely distributed and some of these cells are dormant (e.g., micromets) and they’ve lodged in distant sites. . . **this is a major, major problem**
- Also, when tumor suppressor genes are eliminated, you can always find a downstream [thing] that’s turned on as a consequence
- So, the issue is, can you find that point of drug ability, intervention to counter that?

## Liquid biopsies as a therapeutic monitoring tool [2:18:00]

*Is Keith bullish on* [*liquid biopsies*](https://en.wikipedia.org/wiki/Liquid_biopsy)*?*

- “For sure”

*What is a liquid biopsy?*

- It’s a non-invasive, cancer screening technique

Types of liquid biopsies in cancer:

1. [Circulating tumor DNA (ctDNA)](https://en.wikipedia.org/wiki/Circulating_tumor_DNA)
2. [Circulating tumor cells (CTCs)](https://en.wikipedia.org/wiki/Circulating_tumor_cell)

ctDNA

- A primary tumor with no microscopic metastatic disease (e.g., You have an adenocarcinoma in your colon and we know that it’s nowhere else)
- DNA (and RNA) is shed by cancer cells into the blood
- And with higher and higher resolution technologies, it can amplify that up and detect it as a signal
- Since we know where the genetic map is of all cancer, we can have those probes reasonably well in hand

**Will liquid biopsies reduce the risk of physical harm to a patient, and psychological harm (via reduction in false positives)?**

- Peter posits that If you could layer liquid biopsy on top of diffusion weighted imaging MRI, the best colonoscopy, the best mammography, etc…you can theoretically construct a point where you can catch every cancer prior to its clinical presentation

The common cancer deaths from solid tumors:

- Breast, colon, prostate, and lung
- These 4 make up ~80% of solid tumor cancer deaths

Tumor size

- If you could decide no one ever shows up with a tumor bigger than one centimeter, we could potentially double cancer survival
- The technology to start to see shed DNA from tumors (before they reach one centimeter)  in blood biopsies is in sight, says Keith

The P53 issue with a ctDNA

- 50% of cancers have P53 mutations… therefore finding a P53 mutation in blood tells you there’s a 50/50 chance you have cancer
- But where is it? What part of the body is it coming from?
  - Well, P53 means it could be **virtually any where** (if it’s even cancer)

**Circulating tumor cells approach (CTC)**

- The technology to find circulating tumor cells at a one centimeter or less is not ready (“I think it could get there” says Keith)
- Circulating tumor cells would be the favored approach because you can get the whole fingerprint out of a circulating tumor cell and know exactly where the tumor is (i.e., which organ)
- You therefore could focus every imaging methodology on that specific area

**Lineage mapping**

- This is an interesting developing component of the *circulating tumor DNA and exosomal RNA field*
- The genetic blueprint, when it’s folded up in a colorectal villus cell of the colon, the epigenetic alterations that occur in that cell are characteristic so that you can actually map where that fragment of DNA or RNA come from
- This work in progress as we speak (ongoing collaboration between Keith’s group and the [Broad Institute at MIT](https://en.wikipedia.org/wiki/Broad_Institute))
- There’s a **convergence of cell origin fingerprinting with genetic detection methodology**

**Blood biopsy as a therapeutic monitoring tool**

If we can locate a cancer with liquid biopsies, Keith thinks there’s an opportunity for systemic therapy and then a following up liquid biopsy to **monitor progress**

In other words…

- Can we motivate an immune response against the cancer?
- Or with oncogene targeted therapy?
- And then monitor the response using the same method?

Keith see liquid biopsy as not only an early detection tool, but also as a **therapeutic monitoring tool**

> “You can take a patient where you don’t know where their breast cancer is. . .but you don’t wait for it to emerge, you attack it when it’s still genetically simple. And you monitor that effect in blood so you know when to stop treatment, or you know when treatment is not proving effective [so you can] switch gears to something else because you’ve got a toolbox with different regimens in it.”

For more on liquid biopsies, check out [Peter’s conversation with DA Wallach](https://peterattiamd.com/dawallach/)

## Stem cell therapy: The efficacy and potential risks [2:25:15]

Peter asks Keith about his opinion on stems cells

- Peter says he has at least one patient using intravenous stem cell therapy
- His symptoms have improved dramatically
- But, given the lack of good evidence, Peter isn’t so sure the stem cells are that effective
- And Peter is a little worried about the risk that the stem cells could acquire a life of their own (and presumably turn cancerous)

*Is Keith concerned about this?*

- A truly wild type stem cell will find its home, find its niche, and its proper influences, and behave accordingly
- Unless it were to become a non-wild type through external manipulation outside the body or when it’s potentially fragile and capable of picking up aberrations that aren’t corrected
- But stem cells are notably hardy cells that can survive insults remarkably well and correct them
- “*A stem cell is particularly capable of detecting the damage, repairing the damage, taking its sweet time in doing so, and not spawning daughter cells until it’s got its house back in order.*”

Cancer stem cells

- Cancer stem cells are thought to be kind of the worst of the worst
- They’re these primordial cells in the cancer cell population within a given tumor that have found their way back in development towards a stem cell
- While they can’t divide, multiply, and proliferate quickly, but they can survive almost anything

Chemotherapy reversing cells to stem cell state

What [chemo] can do is it can prune the highly proliferative population of cancer cells leaving behind this more, “stem cell-like pool.”  (this is a contentious topic)

## Aging and cancer: Is cancer inevitable? [2:28:45]

[Age and cancer risk association](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4544764/)

- It’s impossible to deny the age-related association between age and cancer
- Cancer rates rise monotonically until the ninth decade or so…
- If you’re 50 versus 60, versus 70, you leap frog up in risk
- Almost exponentially, or at least quadratically, it’s not just linear

![](https://peterattiamd.com/wp-content/uploads/2019/07/Screen-Shot-2019-07-13-at-4.09.59-PM-1024x713.png)

**Figure 3. Cancer incidence with age.** Image credit: [theconversation.com](https://theconversation.com/why-are-we-more-likely-to-get-cancer-as-we-age-68149)

**Consider three hypotheses on why cancer risk goes up as we age**:

  1 As we get older, our genome is more susceptible to injury

  2  As we get older and we’ve accumulated more of these injuries, the probability that they can start to layer and stack, and you get the phenotype that’s not advantaged

  3 As we get older, the immune system loses some of its steam and therefore, the radar window in which you can detect cancer narrows

- Keith says it’s “all of the above.”
- You’ve just described very nicely what I call the inevitability of cancer
- We’ve got too many stochastic events accumulating and surveillance systems that are breaking down
- The two fundamental most important components, DNA damage repair and immunologic systems, begin to break down with age

*Why does some data show that by your 10th decade, your risk of cancer starts to go down?*

- Peter says, “my explanation is that atherosclerosis ratchets up faster than cancer, and it’s not that cancer is going down, it’s that heart disease is dominating”
- Keith: “There’s this competing risk issue that makes it look as though, if you make it long enough, then you don’t have cancer, then you’re just not cancer prone.”

## Vitamin D supplements, sun exposure, melanoma, and exercise [2:32:30]

**Brief synopsis of the Vitamin D/melanoma/sun exposure discussion**:

- The evidence that sun exposure and melanoma are associated in a **causal** way, from sun to melanoma, is strong ([here’s one study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3046902/))
- We also know that sun exposure increases the de Novo synthesis of Vitamin D in humans
- We also know that, from an association perspective…
  - Higher levels of Vitamin D port with good things happening…
  - Low levels of Vitamin D port with bad things happening
  - ([Here’s one study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5440113/))
- This has led people to suggest that we should be supplementing with Vitamin D
  - Because yes, you can get it by being out in the sun, but the risk of melanoma is going up, but we can just take it
  - It’s a fat soluble vitamin, it’s easy to administer
  - You can clearly achieve levels in the plasma that mirror that of the sun that should solve the problems
- Many doctors (Peter included) have historically normalized patient’s Vitamin D levels with supps

⇒ The problem, says Peter… is that the **clinical trials are lacking evidence**

- Multiple clinical trials are demonstrating that supplemental Vitamin D doesn’t really seem to help that much
- Peter says, “I’ve scrutinized many of these trials, and I can poke holes in all of them, but the body of evidence is becoming hard to ignore.”
  - Note: Exceptions to this include this [JAMA paper](https://jamanetwork.com/journals/jama/article-abstract/2730112) about supplemental Vitamin D in patients with colon cancer getting a legitimate benefit

Considering the available literature, Peter says that you could interpret that…

- The vitamin D that you take supplementary is not fixing the problem.
- The vitamin D that’s getting fixed in the sun is a [proxy](https://en.wikipedia.org/wiki/Proxy_(statistics)) for the good thing happening in the sunlight
  - Analogy: It’s like saying gray hair is a proxy of aging, dyeing your hair black or blonde isn’t fixing your aging.

Peter asks Keith: *Would you advocate we spend more time in the sun as a way to get our Vitamin D?*

- “No, I don’t go that far.”
- Keith says the confounder is **exercise ⇒** The huge confounder is all these people outside are exercising, and exercise (non sunlight or vit D) is what’s been giving them the benefit

*Is vitamin D beneficial at all?*

- Yes, Keith says vitamin D is beneficial, but the exercise that people are doing while outside is transcribing more of the benefit

*What Keith tells his patients who like to exercise outdoors:*

- If you must exercise outdoors, **avoid the middle of the day when the sun is most powerful**
- Do it in the early morning/evening (running, swimming, tennis)

> “My synthesis is, you exercise, and if your exercise means that you get a low enough UV exposure that you need supplementation, then supplement. And until proven otherwise, it’s those two factors that are why pure Vitamin D supplementation alone is never going to do it in a population where you’re not controlling for their exercise.”

[\*Study by David Fisher suggesting the sun might be addictive (in mice)](https://www.ncbi.nlm.nih.gov/pubmed/24949966)

- This finding suggests that we might be engineered to get out in the sun and there must be benefits from it… but the question is… *how much of the benefit is Vitamin D?*
- And the other part of this is that there would be zero “evolutionary pressure” towards preventing from getting melanoma because our ancestors did not live long enough to develop it
- In other words… [getting a lot of sun exposure] is a behavior that is maladapted for those who are going to live to be 60, 70, 80, 100 years old, but not maladaptive for people who are going to live to be 30 and die from predatory death or whatever the issue back in evolutionary time.

**Thought experiment**:

*If you could exercise indoors, never see the sunlight except through your window, and supplement Vitamin D… do you think you are doing as well, health-wise, as someone who does NOT supplement Vitamin D but exercises outdoors and attains the same Vitamin D level?*

- Yes… “that’s my hypothesis.”
- “The idea that there’s some other magical component of UV exposure. . .I’d say we lack the evidence to support that.”

## How and why Keith has straddled the line between science/research and industry/drug companies, and the importance of getting more voices of practitioners at the table [2:42:00]

\*The following is a scrubbed transcript from their conversation…

**Peter**: This interview has been great because I think there are tons of scientists, and scientists in training, that I know enjoy this podcast, and I think you’ve offered incredible advice to people across different levels of that spectrum, in particular those people reaching out who are in MD-PhD programs and they’re trying to straddle, ‘how do I balance research and clinical work?’. And though you are an MD, not an MD-PhD, from a functional standpoint, you are an MD-PhD, you are a clinician who predominantly does research.

You also do something that a lot of people haven’t figured out how to do and I’m curious as to what you’ve learned along the way, which is, you have a very rigorous academic, completely standalone credentialed existence, and at the same time, you really understand industry, you’ve been a huge part of industry, and you seem to run these two parallel tracks that . . .most people really struggle to live on both sides of that. They usually tend to be very good at one and mediocre at the other.

**Keith**: People [should be] cautious to believe that it would be a good idea to do it, that there’d be synergy in trying to live on both sides. That’s been the lesson I’ve learned over the past six years, which dates back to when I co-founded my first company in a series five.

**Peter**: Is that because of what you said at the outset, which is you were immediately focused on translational stuff, and if you were focused on basic science, for example, that synergy is a lot harder?

**Keith**: I think that’s right.

Yeah, I should back up a step and say that you can’t do the work that I do and not interact with industry. The drugs come from industry. We do not live in a world yet where academic entities or the National Institutes of Health produce investigational agents, take them through their measures, and then make them widely available. That *could* happen, actually there’s a part of me that has pushed and advocated for that day to come because I think it would help bend the cost curve in a major way, but park that one for a moment. That hasn’t been the world I’ve operated in.

I depend on Pharma, which means big companies and biotechs, to be aligned partners at least for much of the time that we work together. The misalignment totally comes, and when it comes we shake hands and part company. But my world has revolved around the fact that therapies come from companies, proto therapies, and then true therapies. Diagnostics kind of come from us, and diagnostics are 50% of the equation, they’re woefully undervalued yet a lot of our research, NIH funded research is about chronical biomarkers that are in their best form going to become diagnostics.

**Peter**: This is the world’s worst industry, right?

**Keith**: But you can’t direct a patient to therapy and use the phrase “precision medicine” without pairing it with the best diagnostic.

So this isn’t about diagnosing colon cancer, this is about diagnosing the molecular type, and what its therapeutic vulnerabilities are going be. And that could be ex vivo functional diagnostics, not just static diagnosis.

**Peter**: Shouldn’t that just be absorbed into the therapeutic world?

**Keith**: Right, not just the cost borne by the therapeutic world, but also the development and deployment as well. And that’s where it works, “companion diagnostics” are the success examples. It will still be the case that that therapy developing company marketed diagnostic and therapeutic world, will make 10 cents off the diagnostic, a billion dollars off the therapeutic, but if that’s what it took to get there, then they will do it.

They will also give the test away rather than bothering with the 10 cents. They will say, “Well, we readily recognize that we can’t protect this diagnostic space. Yes, we have IP in this very specific diagnostic method, but we’re going to get undercut by 10 to 100 others who are just going to come in and compete with us. That’s fine, because we still own the therapy.” And especially in a regulated environment, if certain companion diagnostics only link to that therapy, then the therapy developer still benefits.

The problem that I faced as an academic is the issue of alignment/misalignment around diagnostic therapy pairs. If you get to market in a broad population that is not biomarker selected, and you can get there, you know you’re treating some patients who aren’t getting benefit from therapy, you’ve seen it in phase one/two, you’re still seeing in phase three, but you’re having enough of the fact and enough of a subpopulation that you’re able to drive a result in an unselected population.

If you can do that, that remains in the current environment, the best version of success there is. It decreases the degree of difficulty in terms of having two moving parts in your development plan, both the diagnostic and therapeutic, and you get the broadest population. Admittedly, patients who aren’t getting benefit from therapy aren’t going to make a lot of money for you because in a cancer context they’re going get two months of treatment and stop, but still broad population, broad use, a clinician doesn’t have to think about doing more testing than they’ve already done, they just give this colon cancer patient the EGFR antibody… go back to the mid two thousands when that was the reality.

A light bulb went off over hundreds of people’s heads saying “downstream of the epidermal growth factor receptor is RAS, and in colorectal cancer, RAS is mutated in a substantial fraction of patients. I bet that if you have a RAS mutation downstream of the receptor, that tumor is not going to care about having the receptor blocked with the antibody.” A brief run through the lab confirmed that hypothesis. An attempt then to carve out the RAS mutant population from an approved Epidermal Growth Factor Receptor antibody was a **ground war that took years and years**.

The number of constituents, first the drug developer themselves, and then regulators joining them, stood in the way of the most obvious scientific hypothesis I’ve ever seen in my academic career, it was terrible. So this is what I’m getting the misalignment is that basically if you do this too late and you’re now carving out populations from an approved therapy, **disaster**, because then you’re relying on the diagnostic to be the business incentive generating tool to carve that population out and it doesn’t exist.

Now, if we had single payer health care and we had one ecosystem constituents talking about this, we could talk about the savings and not having patients getting effective therapy and we could align on who takes ownership and responsibility but that’s not the world we live in. So in the meantime, it’s a mad panic as an academic to try to translate the science and medicine with a diagnostic and therapeutic pair, prospectively, so that you get there at the finish line with a heroically effective therapy that’s benefiting 80+% of patients—you’re always going to be wrong in some fraction—but you’re almost nailing it in terms of assigning patient and true precision medicine way.

If you can do it prospectively, which is a mad panic because the cancer drug development has moved more quickly in recent years, you’ve got to now develop that diagnostic, show that your biomarker-positive and biomarker-negative population do and don’t benefit to the satisfaction of FDA in time to then have that diagnostic lock down ready to roll with its approval supporting dataset.

So, this is a long winded way of saying that I traveled this path enough times as a collaborator with industry and seen it go well and go poorly. I’ve also seen lots of decisions made in drug development, in terms of compromises in chemistry and shortcuts that are driven by artificial deadlines. Like…“Look, this program’s got to advance or we’re going to kill it” … either in a young company with venture capital backing. Or, in a big Pharma company that says “Look, we’ve got a huge pipeline. We’ve got teams competing against each other, we’ve got to widdle this pipeline down to best candidates, so we’re going to make some decisions next quarter. So you show me what you’ve got in terms of chemistry advances towards your development candidate and we’re just going to make a decision, I don’t care if you think in another quarter you could do better, we’re just drawing a line and making a deadline”. That’s the big company version.

I watched these things happen as an external collaborator for enough times in different compromises in what I thought bad decisions being made to say, “I think there’s an opportunity here to do what I’d say the best of academic medical work can be”, which is to lead by example. Go into companies as a founder, meaning with an idea, and try to do it the way that I think has the greatest integrity to the hypothesis that you’re trying to test.

Not everything’s going to work, that’s not the point, it’s just don’t make decisions for the wrong reasons, make them for the right reasons that the hypothesis is basically not held up and needs to be abandoned, you need to spend more time in optimization on the chemistry side, your regulatory path needs to be innovative because turns out that next generation sequencing is or isn’t being adopted in the way that you thought it would be. I’m touching on some real examples here. Being in the boardroom, being around the table, the smallest table where these decisions are made, I had no idea how satisfying that would be.

Do I suggest it for everybody?

Well… what I would suggest for everybody who cares about therapeutics related research. Lab investigators, but particularly clinical investigators is, you need to understand to the best of your ability how people’s worlds turn, you really need to develop that understanding. Otherwise you cannot be an effective constituent, you can’t be an advocate within your field for your current patients, for the future patients, next generation patients, patients worldwide who you’re trying to advocate for, you can’t do that if you don’t understand what’s constraining on the other side. That has been the lesson that I’ve learned.

So the fact that I was approached and offered serially to take light bulb moments and park them into companies, I couldn’t have seen that coming eight years ago. Clinical investigators didn’t have those opportunities. Should they have those opportunities? Well, you can imagine from what I’ve just said, absolutely. I’ve got mentees in my own group and mentees elsewhere in the country who I look at and say, “Oh, this field needs more people like you around a board table.”

The thing that I’ve learned, and I hope that all of my co-board members if they heard this would understand how much I’m saying this with a lot of respect and even affection. These are super bright people who have accomplished in multiple dimensions, but if they are not on MD, or MD-PhD, or even straight PhD in biomedical research, let’s say in cancer, there’s a component that they don’t see. Where if you’re able to provide that as a single person around a board of eight, that contribution can be disproportionate. Not on the financing side, not on domains that I’m not very clever about and certainly not very experienced about, learn to appreciate those things. This is a seat that is currently not filled.

I can only speak to cancer biomedical research in the private sector. This is a seat that’s not filled, it’s empty. There had been board seats held for basic investigators historically, but not the translational clinical investigator. And I’m not looking for more work, so this isn’t at all about me, but I’ve seen that as cancer science has become so much more translational, the opportunity unfolded for me and **I think it would be of a major benefit to the field for the private sector basically to engage more voices at the table of those who are involved in the truly applied science down to the patient level.**

So you’ve got stakeholder representation in those discussions. That includes the people who actually in the case of cancer hold the hand of a dying cancer patient, understand what the ramifications are, clinical trial decisions that are the most expedient path to approval versus the, let’s make this really stick and matter for patients, doing this through scientific advisory boards, ad hoc consulting, which is the whole rest of my travels before I got into the entrepreneurial mode of actually launching companies. Been there, done that, those meetings are held, they conclude and life goes on.

You don’t have a fiduciary responsibility.

That’s exactly it. All of these companies, every single one of them, every company I’ve interacted with in biotech/Pharma, they will all say that they are trying to move the needle for patients. This is their stated goal and I believed them. How do you do that if you don’t have in the room exactly as you say, invested responsible leaders of the company in the case of the board who actually have career long skin in that game?

**Best quote from this section**:

> “I think it would be of a major benefit to the field for the private sector basically to engage more voices at the table of those who are involved in the truly applied science down to the patient level.”

§

## Selected Links / Related Material

**The 2018 Nobel Prize in medicine and physiology for checkpoint inhibitors**: [Discovery of cancer therapy by inhibition of negative immune regulation](https://www.nobelprize.org/uploads/2018/10/advanced-medicineprize2018.pdf) | (nobelprize.org) [5:00]

**Keith is the editor in chief of the journal:** [Clinical Cancer Research](https://clincancerres.aacrjournals.org/) | (clincancerres.aacrjournals.org/) [4:45]

**The War on Cancer was declared in 1971:**

- *Wiki page*: [War on Cancer](https://en.wikipedia.org/wiki/War_on_Cancer) | (wikipedia.org) [5:45, 28:15, 37:15]
- *Video*: [From the Archives: President Nixon Signs the National Cancer Act](https://www.youtube.com/watch?v=lQYfC9kisHw) | Richard Nixon Foundation (youtube.com)

**Sequencing of the entire human genome:** [Human Genome Project](https://en.wikipedia.org/wiki/Human_Genome_Project) | (wikipedia.org) [5:45, 37:15]

**You take cancer cells, you establish this mind-blowing ability to grow them outside of a patient and create:** [Immortalised cell line](https://en.wikipedia.org/wiki/Immortalised_cell_line) | (wikipedia.org) [27:15]

**Testicular cancer and GIST are two of the rare success stories since the War on Cancer:** [28:30]

- [Seminoma testicular cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2943781/)
- [Gastrointestinal stromal tumor (GIST)](https://en.wikipedia.org/wiki/Gastrointestinal_stromal_tumor)

**Metastatic breast cancer…The decades following the War on Cancer have only improved median survival extensions of maybe six months to twelve months:** [Metastatic breast cancer](https://en.wikipedia.org/wiki/Metastatic_breast_cancer) | (wikipedia.org) [29:15]

[**Whipple procedure**](https://www.mayoclinic.org/tests-procedures/whipple-procedure/about/pac-20385054) **is one of the most complicated surgical procedures for cancer, which is removing the head of the pancreas, was an operation that used to carry a 50%/30 day mortality, meaning the surgery was … You had a 50% chance of living through the surgery and the postoperative course… today that’s 0.1% mortality at 30 days, but long term survival is still abysmal:** [Whipple procedure: a review of a 7-year clinical experience in a referral center for hepatobiliary and pancreas diseases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4363458/) (Saraee et al., 2015) [33:15]

**Knudson’s Two Hits hypothesis**: [Knudson hypothesis](https://en.wikipedia.org/wiki/Knudson_hypothesis) | (wikipedia.org) [39:15]

**RAS mutations occur in 25% of all cancers:** [A comprehensive survey of Ras mutations in cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3354961/) (Prior et al., 2012) [41:45]

**The HIV drug known as AZT:** [Zidovudine](https://en.wikipedia.org/wiki/Zidovudine) | (wikipedia.org) [42:30]

**HAART was introduced in 1996:** [Management of HIV/AIDS](https://en.wikipedia.org/wiki/Management_of_HIV/AIDS) | (wikipedia.org) [42:54]

**A mixture of bacteria created in the late 19th century as a treatment for cancer:** [Coley’s toxins](https://en.wikipedia.org/wiki/Coley%27s_toxins) | (wikipedia.org) [47:00]

**The PD-1/PD-L1 checkpoint inhibitor discovery:** [Immune checkpoint inhibitors to treat cancer](https://www.cancer.org/treatment/treatments-and-side-effects/treatment-types/immunotherapy/immune-checkpoint-inhibitors.html) | (cancer.org) [47:00]

**Melanoma harbors just about the largest number of mutations per cell of a tumor that makes it:** [A Landscape of Driver Mutations in Melanoma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3600117/) (Hodis et al., 2013) [48:15]

**T set of genes that code for cell surface proteins (e.g., T-cells) to come kill mutated cells**: [Major histocompatibility complex](https://en.wikipedia.org/wiki/Major_histocompatibility_complex) | (wikipedia.org) [49:45]

**Prognostic tool to use for quantification of in situ immune cell infiltrates, which appears to be superior to the TNM in colorectal cancer:** [Immunoscore](https://en.wikipedia.org/wiki/Immunoscore) | (wikipedia.org) [51:00]

**A type of checkpoint inhibitor therapy**: [CTLA-4](https://en.wikipedia.org/wiki/CTLA-4) | (wikipedia.org) [52:00]

**CTLA-4 blocking will produce lymphoproliferative overdrive that kills mice**: [Induction of autoimmune disease by deletion of CTLA-4 in mice in adulthood](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4855592/) (Klocke et al., 2016) [52:15]

**Gut bacteria and chemotherapy—Reducing the immune system with chemotherapy can cause major issues with gut bacteria**: [Chemotherapy-driven dysbiosis in the intestinal microbiome.](https://www.ncbi.nlm.nih.gov/pubmed/26147207) (Montassier et al., 2015) [53:00]

**Megadoses of** [**Interleukin 2**](https://en.wikipedia.org/wiki/Interleukin_2) **can cause** [**systemic inflammatory response syndrome**](https://en.wikipedia.org/wiki/Systemic_inflammatory_response_syndrome) **which was as life-threatening as the cancer**: [Safety and Efficacy of High-Dose Interleukin-2 Therapy in Patients With Brain Metastases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2424228/) (Guirguis et al., 2002) [54:00]

**Keith’s paper discussing the need to combine immunotherapy with targeted therapy**: [Universes Collide: Combining Immunotherapy with Targeted Therapy for Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4258160/) (Wargo et al., 2015) [55:45]

**The data with the PD-1 antibodies:** [1:01:44]

- [PD-1 and PD-L1 antibodies in cancer: current status and future directions.](https://www.ncbi.nlm.nih.gov/pubmed/28213726) (Balar et al., 2017)
- [Anti-PD-1: A Novel Immunotherapy](https://www.hopkinsmedicine.org/kimmel_cancer_center/centers/melanoma/research/anti_pd_1.html) | (hopkinsmedicine.org)

**Project to catalogue genetic mutations responsible for cancer using genome sequencing**: [The Cancer Genome Atlas](https://en.wikipedia.org/wiki/The_Cancer_Genome_Atlas) | (wikipedia.org) [1:07:30]

- [Outcomes & Impact of The Cancer Genome Atlas](https://www.cancer.gov/about-nci/organization/ccg/research/structural-genomics/tcga/history) | (cancer.gov) [1:07:30]
- [Genomic and Epigenomic Landscapes of Adult De Novo Acute Myeloid Leukemia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3767041/) (The Cancer Genome Atlas Research Network, 2013)

**Melanoma and neural crest cells**: [Neural crest stem cells in melanoma development.](https://www.ncbi.nlm.nih.gov/pubmed/24441506) (Shakhova, 2014) [1:10:45]

**HER2 breast cancer targeted therapy**: [Targeted Therapy for Breast Cancer](https://www.cancer.org/cancer/breast-cancer/treatment/targeted-therapy-for-breast-cancer.html) | (cancer.org) [1:12:30]

**Targeted therapy for colon cancer targeting Epidermal growth factor receptor (EGFR)**: [Targeted Therapy Drugs for Colorectal Cancer](https://www.cancer.org/cancer/colon-rectal-cancer/treating/targeted-therapy.html) [1:12:30]

**HER2 and breast cancer treatment**: [Systemic targeted therapy for her2-positive early female breast cancer: a systematic review of the evidence for the 2014 Cancer Care Ontario systemic therapy guideline](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4381787/) (Mates et al., 2015) [1:13:45]

**HER2 does better with chemo+HER2 anitbodies versus chemo alone**: [Traditional vs Targeted Chemotherapy in HER2-Positive Breast Cancer](https://www.cancernetwork.com/her2-positive-breast-cancer/traditional-vs-targeted-chemotherapy-her2-positive-breast-cancer) | Dave Levitan (cancernetwork.com) [1:14:30]

**The chromosome translocation in chronic myelogenous leukemia**: [Philadelphia chromosome](https://en.wikipedia.org/wiki/Philadelphia_chromosome) | (wikipedia.org) [1:15:30]

**Acute leukemias in children are easier to cure (greater than 90%):** [Continued improvement in survival of acute myeloid leukemia patients: an application of the loss in expectation of life](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4771966/) (Bower et al., 2016) [1:16:15]

**Tumor protein P53 is the most famous tumor suppressor gene of them all:** [p53](https://en.wikipedia.org/wiki/P53) | (wikipedia.org) [1:20:30]

**50% of cancers have genetic aberration in p53:** [P53 mutations and cancer: a tight linkage](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5233470/) (Perri et al., 2016) [1:21:15]

**RB1 “downstream”, or regulated by, P53 in retinoblastoma**: [Inactivation of the p53 pathway in retinoblastoma.](https://www.ncbi.nlm.nih.gov/pubmed/17080083) (Laurie et al., 2006) [1:23:45]

**More aggressive prostate cancers in men with lower testosterone levels than higher testosterone levels… if your prostate cancer can grow without testosterone, beware!**: [Testosterone and prostate cancer: an evidence-based review of pathogenesis and oncologic risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4647137/) (Michaud et al., 2015) [1:25:00]

**20% of cancers have PI3 kinase intrinsic mutations**: [High frequency of mutations of the PIK3CA gene in human cancers.](https://www.ncbi.nlm.nih.gov/pubmed/15016963) (Samuels et al., 2004) [1:27:15]

**PI3 kinase mutant breast cancer:** [The impact of PI3K inhibitors on breast cancer cell and its tumor microenvironment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6014315/) (Qin et al., 2018) [1:27:45]

**25% of cancers have a Ras mutation:** [A comprehensive survey of Ras mutations in cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3354961/) (Prior et al., 2012) [1:30:15]

**50% of melanomas have a BRAF mutation**: [The role of BRAF V600 mutation in melanoma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3391993/) (Ascierto et al., 2012) [1:30:30]

**Sequencing RAF gene showing BRAF was in 8% of all cancers:** [Mutations of the BRAF gene in human cancer.](https://www.ncbi.nlm.nih.gov/pubmed/12068308) (Davies et al., 2002) [1:30:30]

**The BCR-ABL translocation in 95% of cases of CML …a “massive chromosome shift” that you can see under microscope:** [Philadelphia chromosome](https://en.wikipedia.org/wiki/Philadelphia_chromosome) | (wikipedia.org) [1:41:00]

**First kinase inhibitor for CVD**: [Inner Workings: Tyrosine kinases, their discovery and impact](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4491790/) (Jessica Marshall, 2015) [1:45:30]

**The first ABL kinase inhibitor:** [Imatinib](https://en.wikipedia.org/wiki/Imatinib) | (wikipedia.org) [1:47:00]

**NEJM papers in 2001 testing the BCR-ABL kinase inhibitor (Imatinib)**: [1:48:45]

- [Efficacy and Safety of a Specific Inhibitor of the BCR-ABL Tyrosine Kinase in Chronic Myeloid Leukemia](https://www.nejm.org/doi/full/10.1056/NEJM200104053441401) (Druker et al., 2001)
- [Activity of a specific inhibitor of the BCR-ABL tyrosine kinase in the blast crisis of chronic myeloid leukemia and acute lymphoblastic leukemia with the Philadelphia chromosome.](https://www.ncbi.nlm.nih.gov/pubmed/11287973) (Druker et al., 2001)

**Trastuzumab extends survival of metastatic HER2 positive breast cancer:** [Trastuzumab — Mechanism of Action and Use in Clinical Practice](https://www.nejm.org/doi/full/10.1056/NEJMra043186) (Clifford A. Hudis, 2007) [1:54:00]

**Trial showing adjuvant use of HER2 antibody in combo with chemotherapy was better than just chemo**: [Trastuzumab plus adjuvant chemotherapy for operable HER2-positive breast cancer.](https://www.ncbi.nlm.nih.gov/pubmed/16236738?dopt=Abstract) (Romond et al., 2005) [1:55:45]

**Use of Imatinib for gastrointestinal stromal tumor for the fact that it’s a c-Kit inhibitor and c-Kit is mutated in two thirds of gastrointestinal stromal tumors:** [C-kit, GIST, and imatinib.](https://www.ncbi.nlm.nih.gov/pubmed/17607922) (Siehl et al., 2007) [1:58:00]

**Keith’s papers about BRAF-MEK combination therapy for melanoma**: [1:59:15]

- [Combined BRAF and MEK Inhibition in Melanoma with BRAF V600 Mutations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3549295/) (Flaherty et al., 2012)
- [Improved survival with MEK inhibition in BRAF-mutated melanoma.](https://www.ncbi.nlm.nih.gov/pubmed/22663011) (Flaherty et al., 2012)
- [Combined BRAF (Dabrafenib) and MEK Inhibition (Trametinib) in Patients With BRAFV600-Mutant Melanoma Experiencing Progression With Single-Agent BRAF Inhibitor](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4226803/)

**Science paper about the Astronaut Kelly’s time in space, A Year in Space?:** [The NASA Twins Study: A multidimensional analysis of a year-long human spaceflight](https://science.sciencemag.org/content/364/6436/eaau8650) [2:05:00]

**Age and cancer risk**: [Age and Cancer Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4544764/) (White et al., 2015) [2:31:15]

**Strong evidence that sun exposure and melanoma are associated in a causal way**: [Relationship between sun exposure and melanoma risk for tumours in different body sites in a large case-control study in a temperate climate](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3046902/) (Newton-Bishop et al., 2011) [2:32:00]

**Association between low levels of Vitamin D and chronic disease**: [Vitamin D and Chronic Diseases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5440113/) (Wang et al., 2017) [2:32:00]

**JAMA paper showing patients with colon cancer getting a benefit from supplemental Vitamin D**: [Effect of High-Dose vs Standard-Dose Vitamin D3 Supplementation on Progression-Free Survival Among Patients With Advanced or Metastatic Colorectal Cancer The SUNSHINE Randomized Clinical Trial](https://jamanetwork.com/journals/jama/article-abstract/2730112) (Kimmie et al., 2019) [2:34:30]

**David Fisher’s study suggesting the sun might be addictive (in mice)**: [Skin β-Endorphin Mediates Addiction to UV Light](https://www.ncbi.nlm.nih.gov/pubmed/24949966) (Fell et al., 2014) [2:38:45]

§

## People Mentioned

- [Mira Kautzky](https://www.massgeneral.org/doctors/doctor.aspx?id=18717) (Keith’s wife)  [14:15]
- [William Osler](https://en.wikipedia.org/wiki/William_Osler) (Canadian physician Keith thought was absolutely an Aristotelian figure)  [23:00]
- [Otto Heinrich Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) (German physiologist and Nobel laureate)  [27:00]
- [Henrietta Lacks](https://en.wikipedia.org/wiki/Henrietta_Lacks) (African-American woman whose cancer cells are the source of the HeLa cell line, the first immortalized cell line) [27:15]
- [Richard Nixon](https://en.wikipedia.org/wiki/Richard_Nixon) (declared war on cancer) [28:15]
- [Bert Vogelstein](https://en.wikipedia.org/wiki/Bert_Vogelstein) (Director of the Ludwig Center) [37:45]
- [Alfred G. Knudson](https://en.wikipedia.org/wiki/Alfred_G._Knudson) (American physician and geneticist, formulated the two-hit hypothesis)  [39:00]
- [Carl June](https://en.wikipedia.org/wiki/Carl_H._June) (American immunologist and oncologist) [46:00]
- [James P. Allison](https://en.wikipedia.org/wiki/James_P._Allison) (checkpoint inhibitors, American immunologist and Nobel laureate) [47:00]
- [Steven Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg) (American cancer researcher and surgeon) [47:30, 54:00]
- [Babe Ruth](https://en.wikipedia.org/wiki/Babe_Ruth) (called his shot, just like we did with “targeted therapy”) [1:12:30]
- [Lewis C. Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (PI3K, American cell biologist and biochemist) [1:27:00]
- [Craig B. Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson) (PI3K, American cell biologist) [ 1:27:00]
- [Peter Nowell](https://en.wikipedia.org/wiki/Peter_Nowell) (cancer researcher and co-discoverer of the Philadelphia Chromosome) [1:41:00]
- [Philip Abelson](https://en.wikipedia.org/wiki/Philip_Abelson) (American physicist) [1:44:15]
- [Brian J. Druker](https://en.wikipedia.org/wiki/Brian_Druker) (pioneer in CML with kinase inhibitors) [1:46:15]
- [Scott Joseph Kelly](https://en.wikipedia.org/wiki/Scott_Kelly_(astronaut)) (retired American astronaut) [2:05:00]
- [Howard Hughes](https://en.wikipedia.org/wiki/Howard_Hughes) (big in philanthropic causes notably towards health care and medical research) [2:12:45]
- [David Fisher](https://www.dfhcc.harvard.edu/insider/member-detail/member/david-e-fisher-md-phd/) (one of the preeminent melanoma biologists in the field) [2:38:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/07/Keith-Flaherty-bio-image-500x500.png)

##### Keith Flaherty, M.D.

Keith Flaherty is director of Developmental Therapeutics at the Massachusetts General Hospital Cancer Center and associate professor of medicine at Harvard Medical School. He also serves as editor in chief of the journal, [Clinical Cancer Research](https://clincancerres.aacrjournals.org/). He was previously a professor of medicine at the University of Pennsylvania. He is known for his research on targeted therapies for cancer, and in particular for his work on the melanoma drug vemurafenib. In 2013, Massachusetts General Hospital partnered with AstraZeneca to partner Flaherty’s research into developing a formula to identify vulnerabilities of tumors with AstraZeneca’s library of drugs.