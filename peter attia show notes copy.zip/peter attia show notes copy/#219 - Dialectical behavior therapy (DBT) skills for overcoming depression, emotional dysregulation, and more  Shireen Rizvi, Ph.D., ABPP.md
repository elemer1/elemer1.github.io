# #219 ‒ Dialectical behavior therapy (DBT): skills for overcoming depression, emotional dysregulation, and more | Shireen Rizvi, Ph.D., ABPP

**Source:** [https://peterattiamd.com/shireenrizvi/](https://peterattiamd.com/shireenrizvi/)

---

Shireen Rizvi is a Professor of Clinical Psychology and Psychiatry at Rutgers University, where she is also the Director of the Dialectical Behavior Therapy Clinic. This episode focuses specifically on dialectical behavior therapy (DBT), a skills-based technique which was originally developed to treat borderline personality disorder (BPD) and has since been adapted to treat depression and other mental health conditions, as well as to help people who have difficulty with emotional regulation and self-destructive behaviors. Shireen explains the origins of DBT and how its creator, Dr. Marsha Linehan, came to find a need for something beyond cognitive behavioral therapy (CBT) when attempting to treat patients with suicidal behavior. From there, Shireen dives into how DBT works to resolve the apparent contradiction between self-acceptance and change to bring about positive changes in emotional regulation, interpersonal effectiveness, mindfulness, distress tolerance, and more. She also provides examples for how one can apply specific skills taught with DBT such as accessing the “wise mind,” applying radical acceptance, using the “DEAR MAN” technique, and utilizing an emotion regulation skill called “opposite action.” Finally, she explains how the tenets of DBT offer benefits to anyone, and she provides insights and resources for people wanting to further explore DBT.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/shireenrizvi/the_Drive_public.png)

Play

#219 ‒ Dialectical behavior therapy (DBT): skills for overcoming depression , emotional dysregulation, and more | Shireen Rizvi, Ph.D., ABPP

#219 ‒ Dialectical behavior therapy (DBT): skills for overcoming depression , emotional dysregulation, and more | Shireen Rizvi, Ph.D., ABPP

1x15s30s

0:002:16:28

## We discuss:

- The basics of dialectical behavior therapy (DBT) and how it differs from cognitive behavioral therapy (CBT) [3:00];
- Treating depression with CBT: history, effectiveness, and how it laid the groundwork for DBT [8:15];
- Marsha Linehan’s inspiration for developing DBT [16:00];
- Explaining borderline personality disorder (and associated conditions) through the lens of DBT [20:00];
- How work with suicidal patients led to the development of DBT—a dialectic between change and acceptance [35:30];
- Details of DBT: defining the term “dialectical” and how to access the “wise mind” [44:30];
- Practicing mindfulness and radical acceptance in the context of DBT [51:00];
- Applying “radical acceptance” to tragic scenarios [1:02:00];
- The five domains of skills taught in DBT [1:07:15];
- Why Marsha chose borderline personality disorder as her focus when developing DBT [1:13:30];
- Is there any benefit in doing DBT for someone without a pathological condition? [1:15:45];
- The DEAR MAN skill of DBT [1:20:00];
- Adapting DBT skills for adolescents and families [1:31:00];
- Identifying vulnerability factors, increasing distress tolerance, and the impact of physical pain [1:33:45];
- The DBT chain analysis: assessing problem behaviors and identifying vulnerability factors [1:44:30];
- Why the regulation of emotions can be so challenging [1:50:30];
- The importance of mindfulness skills in DBT [1:53:30];
- Opposite action: an emotion regulation skill [1:57:00];
- Advice for those wanting to explore DBT [2:03:15];
- Finding a well-trained DBT therapist [2:08:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Shireen Rizvi is a [Professor of Clinical Psychology and Psychiatry at Rutgers University](https://gsapp.rutgers.edu/faculty/shireen-rizvi), where she also serves as the Director of the [Dialectical Behavior Therapy Clinic](https://gsapp.rutgers.edu/centers-clinical-services/DBT/dbt-ru-staff)
- She earned her doctorate in clinical psychology from the University of Washington, where she studied under [Dr. Marsha Linehan](https://depts.washington.edu/uwbrtc/our-team/marsha-linehan/), the creator of dialectical behavior therapy (DBT)
- Since joining the faculty at Rutgers in 2009, Shireen has taught courses and conducted research on topics including DBT, cognitive behavioral therapy (CBT), personality disorders, and trauma
- In this episode, we focus specifically on DBT
  - We cover the origins of DBT
  - How dialectical behavior therapy differs from its cousin cognitive behavioral therapy
  - We talk about how its creator Marsha Linehan came to find a need for something beyond cognitive behavioral therapy, both to help her and to help her patients talk about the structure of DBT
  - And how DBT is oriented as a skills-based technique
- We talk about something called wise mind, emotional mind, and reasonable mind, and how these things are connected
- We talk about radical acceptance
- We talk about different frameworks
  - For example, something like Dear Man, which anyone who’s done DBT will be familiar with as a framework for interpersonal interactions
  - We talk about one of Peter’s favorite ideas called Opposite Action
- We also discuss who can benefit from DBT
  - How it can help children
- How mindfulness plays a part of DBT
- How someone can find a well-trained DBT therapist
- Peter has a huge personal interest in this, because he’s been practicing DBT for 2 years
  - “*I think it’s safe to say, I feel like I’m barely scratching the surface of what this is about*”
- We have no delusion that listening to this podcast is going to offer you everything you need to know about DBT
  - It’s our hope is that for those of you who listen to this, who see that there might be some benefit in this technique, your curiosity might be piqued enough that you go out, watch the [educational videos](https://youtube.com/playlist?list=PLVlLbxLe1Eo6-YjpTfW0UbSOig_4FDac3) that exist on this, pick up a [workbook](https://www.amazon.com/Skills-Training-Handouts-Worksheets-Second/dp/1572307811/ref=pd_bxgy_img_sccl_1/134-1589977-4742414?pd_rd_w=IRmST&content-id=amzn1.sym.7757a8b5-874e-4a67-9d85-54ed32f01737&pf_rd_p=7757a8b5-874e-4a67-9d85-54ed32f01737&pf_rd_r=DSTS93GQQME7MAD7XBTT&pd_rd_wg=Qdx8G&pd_rd_r=633a63dd-0b2e-4c8e-a06e-f9df079d028b&pd_rd_i=1572307811&psc=1), work your way through it, and potentially find a therapist, if you think this is something could be helpful

## The basics of dialectical behavior therapy (DBT) and how it differs from cognitive behavioral therapy (CBT) [3:00]

**If Shireen was at a party and somebody asked her “*****What is DBT*****”, what would she say?**

- **DBT** stands for [dialectical behavior therapy](https://en.wikipedia.org/wiki/Dialectical_behavior_therapy)
- It’s a form of talk therapy that is largely inspired by [cognitive behavioral therapy (CBT)](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy)
- We often say that DBT is a form of cognitive behavioral therapy that was designed for individuals that have complex mental health problems
  - It was originally designed for individuals that are suicidal or self-harming, and who may meet criteria for a disorder called [Borderline Personality Disorder](https://en.wikipedia.org/wiki/Borderline_personality_disorder)
- At its simplest,it’s a form of cognitive behavioral therapy that was designed for more complex people or presentations, but then of course, there’s a lot more nuance beyond that

**How is cognitive behavioral therapy (CBT) different from dialectical behavior therapy (DBT)?**

- CBT is a class of talk therapy with features that distinguish it from other forms of talk therapy
  - CBT is present and focused on what is happening for people right now
  - Focused on what the patient is experiencing
  - Less focused on the patient’s history, childhood
  - Less focused on things that led to the problems the patient is experiencing
  - CBT is present-focused
  - CBT is focused on working with thoughts and behaviors  that go along with the problems that people experience
- In [CBT-I](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy_for_insomnia) the focus is on thoughts that contribute to insomnia
  - How can these be modified or changed to increase the likelihood of falling asleep or staying asleep?
  - What are the behaviors that you do that promote sleep?
  - What are the behaviors that you do that get in the way of sleep, and how do we modify that?
  - At its most concrete level, it is working with thoughts and behaviors that in the present are contributing to your problems right now
  - So, it’s very much an active problem-solving approach
- People may have the idea from watching TV/movies that the best therapy is one where you go in and talk about whatever is on your mind
  - CBT and DBT are more structured and guided than that
- CBT and DBT are evidence-based
  - Treatments are constructed in a way to allow their effectiveness to be measured
  - If something is found to not be effective, then it’s not likely to remain in the therapy
  - The goal is to be as empirical and scientific as possible

**How long has CBT been around as a discipline?**

- [Aaron Beck](https://en.wikipedia.org/wiki/Aaron_Beck) is the figure associated with the beginning of CBT
  - He died last year, at age of 100
  - He was in his 60s when he 1st started developing his form of cognitive therapy
  - Hew was trained as a psychoanalyst and found it wasn’t that useful for a lot of patients

*This prompted him to develop an approach that was more focused on changing the way people thought about themselves and others*

## Treating depression with CBT: history, effectiveness, and how it laid the groundwork for DBT [8:15]

[Marsha Linehan](https://depts.washington.edu/uwbrtc/our-team/marsha-linehan/) is the creator/ founder of DBT

- Originally Marsha set out to apply what might be considered standard CBT to folks who were chronically suicidal
- Perhaps beginning in the ’70s, she was receiving advanced training at Stony Brook in New York
  - At that time, Stony Brook was considered one of the premier places to learn and apply behavior therapy
  - In the ’70s, ’80s, it was really the heyday of [behaviorism](https://en.wikipedia.org/wiki/Behaviorism)
    - The idea was in many ways oversimplified

*The idea was that we could treat any mental health problem with behavior therapy in very few sessions, just by applying these standard principles of what we know about behavior change*

- Behavior therapy and CBT was mostly focused on treating anxiety disorders in those days
  - The idea was that you could have somebody who came into treatment with a fear of something (i.e., a phobia)
    - It could be something like a fear of heights or a fear of spiders, or it could be a fear of social situations, social anxiety
  - The behavioral therapy approach to this (or the CBT approach to this) would be to teach people **competing thoughts**
    - So, rather than thinking, “this thing will kill me”, I can learn to have thoughts like, “I can tolerate this”
    - This might be difficult, but I can handle it
    - This is not going to kill me
  - But those thoughts were only one part of it
  - The other piece of it was the more behavioral piece, which is **exposure**
    - Basically saying that how you’re going to get over your fear of spiders is not to talk about it every week for an hour with somebody, but is actually going to be coming into contact with spiders repeatedly over and over again, so that you learn that you can handle it
    - But you also learn that the feared outcome is not going to occur

Peter’s summary of CBT*: change your thoughts, and get exposure*

**CBT (cognitive behavioral therapy) for phobias and depression**

- Getting exposure is changing your behavior, because you want to run away or avoid, and instead CBT promotes coming into contact with something that you want to avoid
- What they were finding in these early days of applying CBT is people could go to a psychoanalyst and talk about their fears for months and years, and not necessarily do better with them
  - Psychoanalysis was the dominant paradigm of therapy in those days
  - This was almost exclusively a rich white person issue, this is who was receiving treatment for mental health problems back in those days, largely
- CBT comes along and says, sometimes we can do this in 1 session
  - Depending on what the fear is
  - There were people who would do a 3-hour session to “cure somebody of a phobia,” and finding that it worked

The next question was, ***how do we take those principles to something like depression?***

- This is what [Aaron Beck](https://en.wikipedia.org/wiki/Aaron_Beck) started to do with cognitive therapy more
  - Aaron Beck was noticing that people who have depression tend to think in very particular ways
  - They have negative interpretations of almost everything‒ about themselves, about their future, about others
- So, a cognitive behavioral approach to depression would be about working on changing those thoughts to be more balanced and evidence-based
- Then also, the behavior change that goes along with depression is usually about getting active
- When somebody is depressed, the tendency is to retreat, shut down, avoid
- The behavioral treatments for depression would be to get people activated, and to solve the problems that are causing the depression
  - Whether it’s unhappiness with a job, unhappiness with a relationship
  - And work on targeting the problems that are causing depression in a systematic way

**How successful was this form of CBT for depression?**

*How were they able to measure their results and determine if this intervention was better than the standard of care at the time?*

- The history of psychotherapy trials is largely based on a paradigm known as randomized clinical trials (RCTs)
  - Doctors would recruit individuals who meet certain inclusion criteria, for example the diagnosis for depression
  - Then you would randomize them to either say, receive 12 weeks of cognitive behavioral therapy or receive nothing or receive treatment as usual or standard of care
  - And then evaluate outcomes over time
- With things like depression and anxiety disorders, there are these standard measures that are popular within our field, where we have developed benchmarks for what we’re trying to get to, what might be considered a success
- In general, that trials for CBT for things like depression and anxiety are overwhelmingly positive
- Most of the trials, especially in the early days of comparing CBT to nothing or treatment as usual, found very large effects for CBT in those settings
- We will come back to Marsha recognizing that none of these treatments were 100% successful for everybody
- Further, when you look at these studies, and you see who were these studies done with (the inclusion criteria, meaning what allowed somebody to be in this study), they were often quite narrow
  - For example, with a depression study, the person might have to meet the criteria for a diagnosis of depression, but not have suicidal behavior
  - So, people with suicidal behavior may be excluded from a lot of those studies, which makes sense from a research point of view, in some context
  - But in other context, doesn’t make sense, because of course we know that a lot of people who experience depression are also suicidal

*So, if you’re removing suicidal people or not allowing suicidal people to be part of this research, then we don’t know, ultimately, if the treatments work for those populations*

## Marsha Linehan’s inspiration for developing DBT [16:00]

**Marsha, as a young girl was diagnosed with schizophrenia**

- [Marsha](https://depts.washington.edu/uwbrtc/our-team/marsha-linehan/) was treated with [electroconvulsive therapy](https://en.wikipedia.org/wiki/Electroconvulsive_therapy) and all sorts of things that are still used today
  - But today their use is probably not as frequently
  - Today they’re probably used with a bit more particular attention to the use case
- In the late ‘60s Marsha was a teenager and she received a lot of treatment
  - This was before CBT was really in the picture
- She was hospitalized for being suicidal and chronically self-injuring, doing a number of things to cause physical harm to herself as a way of relieving emotional intensity and overwhelming emotions
- At the time there were not many treatment options available
- The medical model was to treat with really strong [antipsychotic meds](https://en.wikipedia.org/wiki/Antipsychotic) or use something like electroconvulsive therapy
  - These are the treatments she was exposed to from a very young age
  - The types of therapy that she was receiving at that time were unlikely to be anything like the cognitive behavioral treatment we know today

**What was Marsha’s journey from a teenage girl who was almost institutionalized to getting an education, becoming a therapist, and creating DBT?**

- She has written about this in a [memoir](https://www.amazon.com/Building-Life-Worth-Living-Memoir/dp/0812994612/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1655904032&sr=8-2) as well as described it in a piece in which she, in the [*New York Times*](https://www.nytimes.com/2011/06/23/health/23lives.html), which was a piece where she kind of came out to the world as having been someone who experienced her own significant struggles with mental health
  - The *New Your Times* article came out in 2011
  - For most of her career, she was not forthcoming about this, her own personal struggle
    - She would only tell people that were close to her and her students
    - She would say she wanted DBT to be judged on its merit empirically
    - She did not want DBT to be judged on her personal story alone
- The earlier part of her history that she describes is a spiritual moment she had when she was in one of these institution
- The spiritual moment‒  she describes experiencing God in a very dark moment of her life
  - In that moment, she realized that she felt the love of God
  - And she felt that she could serve this purpose in life, which is to get out of hell, her own experience, and then to work to get other people out of hell
- That was how she took this spiritual experience and developed her life’s work
- This was in her late teens or early 20s

## Explaining borderline personality disorder (and associated conditions) through the lens of DBT [20:00]

**Was Dr. Marsha Linehan diagnosed at some point as having a borderline personality disorder or is that more retrospective from a perspective of looking back?**

*Was she misdiagnosed as having* [*schizophrenia*](https://en.wikipedia.org/wiki/Schizophrenia)*?*

- Shireen believes she probably was
  - This would have been before the criteria that we now know as [borderline personality disorder](https://en.wikipedia.org/wiki/Borderline_personality_disorder) was defined
  - Its definition would have started in the 3rd edition of the [DSM](https://en.wikipedia.org/wiki/Diagnostic_and_Statistical_Manual_of_Mental_Disorders), which came out around 1980
  - The criteria we have now was not the same as when she was receiving treatment
  - She probably had a number of diagnoses attributed to her
  - Borderline personality disorder may have been one of them, but that’s also the diagnosis they give to people when they don’t know how to treat them
- You still see this today
- But when people are unclear about how to explain someone’s problems, they get given almost every diagnosis in the book

**What is the criteria for borderline personality disorder today?**

- It is considered a complex mental health disorder
- There are 9 criteria of borderline personality disorder, as defined by the [DSM](https://en.wikipedia.org/wiki/Diagnostic_and_Statistical_Manual_of_Mental_Disorders)
- In order to meet criteria or to have the condition, you have to endorse 5 of the 9
- This means that it’s a really heterogeneous disorder, because there’s all these different combinations and different ways in which one can meet criteria
- One of the things that Marsha did was to restructure the different criteria, borderline personality disorder in a way that perhaps is more understandable, and also makes more cohesive sense
  - And to say that it’s a disorder of dysregulation across a number of different domains
- So, the core domain of dysregulation that we see in borderline personality disorder is what we refer to as **emotion dysregulation**
  - This is largely defined by people’s experience of emotions as feeling like they have very intense emotions
  - They don’t feel like they can control their emotions very well
  - Their emotions change very rapidly
    - That’s referred to as **affective lability-** that the emotions will go from intense sadness to intense shame, to fear, to joy, very quickly and seemingly without a lot of reason
- Other domains of dysregulation stem from emotion dysregulation, and include **behavior dysregulation**, so not having control over, or feeling like you don’t have control over your behaviors
  - This is associated with a lot of **impulsivity** and behaviors that go along with impulsivity
    - So, substance use, reckless spending, impulsive sexual behavior, impulsive driving, impulsive eating
  - Behaviors that are experienced as impulsive and potentially could cause problems for the person

**Is there overlap between borderline personality disorder (BPD) and bipolar disorder?**

- Peter notes, “*I’m guessing that’s what makes psychiatry so difficult, is you don’t have biomarkers. You don’t have imaging scans that give you diagnoses, right?*”
  - This is correct
- Yes, there is a lot of overlap between [Bipolar II disorder](https://en.wikipedia.org/wiki/Bipolar_II_disorder) and [borderline personality disorder](https://en.wikipedia.org/wiki/Borderline_personality_disorder)
- [Bipolar I disorder](https://en.wikipedia.org/wiki/Bipolar_I_disorder) is associated with longer lengths of either a pure manic state or a pure depressed state
- Bipolar II might have manic states, but it is shorter in duration or might not be super manic, not as high
  - So, that’s often really hard to discriminate from somebody who has borderline personality disorder
- Generally, what we’re talking about with BPD as opposed to bipolar, is that we actually see the mood changes happening more frequently within BPD than with Bipolar II
  - This is probably oversimplifying, but that’s what Shireen would look for if she was trying to assess the difference

**What are the challenges a person with BPD would face in the world?**

- Let’s assume this person has normal intelligence and physical capabilities
- They just have the 1 psychological issue

*How does it manifest when they’re in school?  In college?  If they get married?  If they have kids?*

- You rarely will see this condition in isolation of anything else
  - This speaks to one of the complexities of trying to study psychiatry—on average, people who meet criteria for BPD have 3-4 other mental health problems at the same time
  - So, they’ll also meet criteria for depression or an anxiety disorder or a substance use disorder

*Do these other mental health problems stem from BPD or are they independent?*

- This depends on who you ask
  - As somebody who is trained mostly behaviorally, Shireen would say **the diagnosis matters less than how we conceptualize these problems**
- Shireen agrees, you could say emotion dysregulation is central to all of those things, but the diagnostic system, as we currently have it, does not allow for that.
- How somebody with borderline personality disorder lives their life is complicated, and it ranges
- On one end of the continuum, we see people who have severe problems associated with BPD, such that they struggle to hold onto a job, so they don’t work, and they’re on disability or receiving social security
  - They can’t maintain relationships

*What is the fundamental issue(s) that are impairing them?*

- From a DBT perspective, it all comes back to ***difficulty regulating emotions***
  - If I experience intense emotions that I feel like I can’t control when I get angry, I lash out
  - When I get scared, I run away or avoid
- One of the criteria that goes along with BPD that you could see as tied with emotion dysregulation problems is what’s referred to as **fears of abandonment**
  - So, a person with BPD often will have a lot of fear that a person that they love or are close to will leave them
  - If I am in a relationship where I am afraid that the other person is going to leave me all the time, that may cause me to behave in ways that are frantic, chaotic, and actually paradoxically, have the effect of causing the other person to be more likely to leave
    - Texting the person, calling the person relentlessly, if a person doesn’t come home or call at the time that they say they will
    - Having the experience of feeling like I’m losing it, because I don’t know where that person is, or perhaps they’ve left me

> “*As a result, if I have BPD, I experience intense fear, intense shame, intense sadness*”‒ Shireen Rizvi

- Now I don’t know what to do with this intense behavior
  - I may self-injure as a way of relieving that emotional intensity
  - Or I may threaten suicide as a way of getting the person to come back to me
  - Maybe I’m doing this without even having awareness that, that’s the effect of my behavior
  - I just know that in this moment, I don’t know what to do
  - I feel entirely out of control, and I need to do something to fix it, in this moment

**What is the mortality of BPD?**

- Peter was very surprised to learn recently that [anorexia nervosa](https://en.wikipedia.org/wiki/Anorexia_nervosa) has probably the highest mortality of any psychiatric condition
  - He would’ve guessed depression
- As someone who studies suicide, Shireen reviews a lot of manuscripts and grant proposals, she gets into the weeds about this
  - She is saddened and amused when she sees people write about BPD and say, “This disorder has one of the highest rates of suicide”
  - Because if you look at it, it seems like every disorder has one of the highest rates of suicide

*She thinks we don’t know how to study this very well, honestly*

- We don’t know how to determine, of the people who die by suicide, what are the mental health conditions that they had?
- What is the relative risk according to these different disorders?

- One way she can answer is to say that another criteria fro BPD is repeated/ chronic self-injury or suicide attempts

***The mortality rate is very high for people with BPD***

- More than 75% of people, and in some studies 90 to 95% of people who meet criteria for borderline personality disorder, engage in self-injury or have made more than one suicide attempt in their lives
- This tells us a couple of things‒ on its own it’s considered a very high risk behavior, because people who engage in self-injury (even if they don’t intend to die) as a result could accidently die a

**What are some examples of self-injury?**

- Head banging or punching or hitting oneself
- There are multiple forms of cutting that include different objects to cut, but could also be people really intensely scratching themselves to the point where they draw blood
- Overdosing is considered a form of self-injury
  - You have to determine if this is with intent to die or not
  - There are people who overdose without intent to die as a way of hurting themselves
- More rare, but other forms of self-injury may involve ingesting toxic substances, etc.
- This has evolved over time
- We didn’t know how to study it very well over the years, because even in Shireen’s career, she feels like 20 years ago, when we were talking about self- injury, we were talking much more about things like cutting or burning
- As more people have become interested in studying self-injury, we’re finding out about other ways in which people cause harm to themselves
- Then, there’s all sorts of debates about whether this is considered self-injury or not, because some people might say I have binge eating or I overeat, and I do that intentionally, even though I know it’s causing harm to myself
  - Whether we classify that diagnostically as self-harm or not is one question
  - But whether a person considers themselves actively doing harm to themselves, that’s another question

**What is the male-female split in BPT?**

- This is another thing that has changed over time
- For a long time it was thought to be a female disorder
- More recent studies indicate there are roughly equivalent rates among men and women
- There is still a diagnostic bias for diagnosing women more often as BPD and not to diagnose men with BPD

*Does this mean that men are under-diagnosed and women are over-diagnoses, potentially?*

- Shireen thinks so
- A number of studies have shown men to be under-diagnosed
  - It appears that symptoms in men have to be more severe in order to receive the diagnosis than women
- She’s not sure if women are over-diagnosed
- A psychiatrist or medical professional usually bases the diagnosis of BPT on their view‒ is the person difficult in some way
  - As opposed to doing a diagnostic assessment

**Do twin concordance studies show a strong genetic component for BPT?**

*How much of BPT is genetic and how much is environmental (where life events trigger a susceptible individual to manifest the trait)?*

- Shireen doesn’t know the twin concordance value off the top of  her head
- There is a general understanding that there is a genetic component to this disorder
- The DBT framework is one that has a model for explaining how BPD develops, which we can probably get into, but that speaks to the fact that there is both a genetic and an environmental component to the development of the disorder

## How work with suicidal patients led to the development of DBT—a dialectic between change and acceptance [35:30]

- Marsha has this epiphany in her late teens or early 20s
  - She has literally come to Jesus
- This puts her on a different pat and potentially saves her life

**The journey from her spiritual epiphany to today**

- Marsha went on to get a degree in social psychology, and a social psychology PhD
- Shireen thinks one of the factors that led to Marsha being able to do this is that she’s hands down a genius,
- Marsha’s achievements probably occurred despite her really difficult experiences
- She had this amazing capacity that helped her in numerous ways, including in developing this treatment
- Not many people know that Marsha doesn’t have a degree in clinical psychology
  - But she got her social psychology degree
  - Then decided that she wanted to get clinical training
- This led her to a training experience at Stony Brook
  - Which is where they were doing a lot of work on theory and treatment related to cognitive behavioral treatments for a range of disorders
- At that time, nobody was studying cognitive behavioral treatment for suicidal populations
- Marsha decided she want to take what was known about CBT (that seems to be hugely effective for all of these disorders) and apply it to treating chronically suicidal individuals
  - The way she reports it is saying she wasn’t interested at that time in diagnosis, she just wanted to work with people who chronically experienced urges to die
  - That’s what she attempted to do and by her accounts this quickly blew up
  - This was the late ‘70s, early ‘80s

**How is she treating herself at this point?**

*How is she regulating her own emotions? Are the tools of CTB helpful for her own self-care?*

- This is a great question and Shireen is not sure about the answer
- What’s interesting is, Marsha took a lot of her own experiences and was able to translate that into cognitive behavioral terms
  - This led to the development of a lot of the skills in DBT that she developed for people
  - Whether she was thinking at the time about applying CBT to herself, Shireen doesn’t know,
    - But that’s what Marsha ended up doing by developing these skills
- Peter notes that Marsha becomes the index case even though she wasn’t necessarily thinking of it this way
  - She was working out the tools of “*how do you transition*”
- Peter compares this to what [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) did
  - Most people know him as a movie star in martial arts
  - He was far more relevant in creating a system of martial arts called [Jeet Kune Do](https://en.wikipedia.org/wiki/Jeet_Kune_Do)
    - This took what was useful (and discarded what what useless) from over 30 different styles of martial arts and created a new system with a very particular goal
- Shireen notes that Marsha’s work development treatment and work on herself was a very iterative process
  - Marsha constantly asked, “*Let me try this. Does this work? I’ll keep it. Does it not work? I’ll throw it out. If it works, what is it? How do I define it? How do I write about it in a way that other people can do it and put it all together in a package?*”
    - To do this speaks to how brilliant she was
    - What’s really exciting about treatment development work is this whole process of figuring it out as you go and then trying to replicate it and really using the client’s experience to say, *is this having the intended effect?*

**Back at Stony Brook, Marsha was finding out that the current form of CBT was not helping suicidal patients**

- Marsha would go into a season with somebody and ask them about the problems they’re experiencing that are causing them to feel suicidal
- The person would say, “*I hate my job. I hate my relationships. I don’t have any pleasure in my life*.”  Whatever those things are
- Marsha with a CBT lens would say, “*We can figure this all out. We’ll just take all of your problems, we’ll put them on the list, we’ll systematically go through each of your problems one by one, which we’ll solve. We’ll figure this out in no time.*”
- Marsha had all the hope in the world and the reaction she got was totally unexpected
- People said, “*You have no idea. You have no idea how bad my problems are. If you thought that these are things that are easy to solve, you are sorely misunderstanding the depths of my problem. You clearly don’t understand anything about me or my situation if you think that these are things that could be easily solved. More than that, if these were easily solved, I would’ve solved them a long time ago. You have no idea how much I’m suffering. You don’t get it.*”
- The next step for her was to say, “*Okay, that’s not working. I need to figure out what’s going to work*.”
  - She took the other perspective, and she said, “*Okay, what they’re telling me is that I don’t understand the depths of their problems, and maybe that’s true, and so what I need to do now is tell them and work with them to completely understand*.”
- This led her to approach sessions with people who are chronically suicidal in a different way
  - She would say, “*You’re right. Your problems are too difficult. You’ve had longstanding experiences with trauma. You’ve been treated terribly your whole life. You have a number of obstacles that may prevent you from getting the job that you want or the relationship that you want and* ***perhaps what we need to do is work on accepting your life as it is and finding joy in that, but accepting the life as you have it and let go of trying to solve all these problems****.*”
- Peter adds, “This is the epiphany that of course, anyone who’s done DBT knows, is **radical acceptance**.”
  - Shireen says it might have been the precursor to “radical acceptance” but it was missing something — *hope*.

**Hope**

- If patients should just accept a miserable life as it currently is, then there is no hope
  - They should just die
- This is what turned into the idea of this primary dialectic in this treatment

***DBT stands for Dialectical behavior Therapy, which is the dialectic between change and acceptance***

- Figuring out how do I (as a therapist, as a treatment provider) straddle this line, synthesize this, because both of these are important
- **We need to work on**
  - 1 – Solving the problems in your life that are causing you such distress and misery
  - 2 – Accepting your life as it is and accepting the things that we can’t change about our lives
- But how do we do that in a way that is palatable to the person on the other end and in a way that conveys hope that things could change?

***It’s about synthesizing those 2 elements and Shireen thinks it’s the synthesis of those elements that lead to things like radical acceptance and other components of the treatment***

## Details of DBT: defining the term “dialectical” and how to access the “wise mind” [44:30]

**Explain what dialectical means**

- Shireen was listening to an interview the other day where somebody said “*Humans don’t like contradiction*.”‒ that’s true
- She’s no expert in dialectical philosophy, as [Marx](https://en.wikipedia.org/wiki/Karl_Marx) initially wrote about it
- She’s more a student of dialectics as it informs her life and practice
- Dialectics is this understanding that there is contradiction and opposition and tension in everything and therefore we can’t avoid it and the more we try to avoid conflict and tension the more likely it is that we’re going to see conflict and tension

***Dialectics,*** *in the practice of DBT****, is the practice of recognizing tensions as they exist, polarization as it comes up, and then striving to find what is valid about both sides of the tension and seeking to find a synthesis, some new argument or new statement that recognizes and adopts the validity in the two opposing sides***

- Peter adds, “*If a person listening to this or watching this has ever gone through DBT, then they’re familiar with the workbook. You’re doing this in a very structured way, and one of the first images in the workbook is the two intersecting circles of wise mind and emotional mind.*” (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/08/f1-rizvi.png)

**Figure 1.  States of mind outlined in the DBT workbook.**  Image credit: [One Step to Mental Wellness 2020](https://www.onestep2mw.org/wise-mind-mindfulness-practice-accessing-our-inner-wisdom/)

- The reasonable mind and the emotional mind
- The wise mind is the intersection

**Is where these 2 minds intersect an example of dialectical synthesis?  Contrast the wise mind with the emotional and reasonable mind.**

- Yes,  a key illustration of dialectics at play is this notion of wise mind
- The **wise mind** is a skill in the workbook that we teach people as something we are striving to access more often in our lives

***Accessing the wise mind involves synthesizing these 2 tensions or polarizations known as the emotional mind and the reasonable mind***

- The **emotional mind** is the idea that a state in which we are completely controlled by our emotions
  - So when we’re angry, it could be lashing out at somebody
  - It could be engaging in physical violence
  - It could be threatening physical violence
  - It could be slamming doors
  - Could be quitting things
  - All the things that we might do when we’re being controlled by the anger we’re experiencing
- The **reasonable mind**, on the other hand, is when we’re controlled facts and logic
  - We’re not aware of, or experiencing, any strong emotion
- You could imagine, or you can envision the tension that exists between these 2 minds

***If you’ve ever been in an emotion mind and having an argument with somebody whose in a reasonable mind, or vice versa, that’s a recipe for a really strong conflict***

- That happens a lot
- It probably happens a lot across many people’s marriages where one person is in emotion mind, the other person is in reasonable mind and that’s a recipe for really strong conflict
- During a conflict, the wise mind is saying,
  - “*What’s valid about the emotion that I’m experiencing here?*”
  - What’s valid about the reasonable mind that I’m experiencing here?
  - and what is a synthesis?
- A *silly illustration of this*: You’re walking down the street and you pass by a pet store and in the window are a dozen puppies
  - The **emotional mind** takes over and says, “*I want all the puppies, every single one of them, because this one is cute for this reason, this one is cute for this other reason. Oh my God. They would be so happy together and I would be so happy if I had all these puppies in my life. I want them.”*
    - So the emotion mind says, *“Get all the puppies*.”
  - The **reasonable mind** says, “*Oh my gosh, dogs are so much work. You have to walk them three times a day. They’re expensive. You have to get all this equipment. You have to get a veterinarian. You have to restructure your time so that you spend more time with the dogs or not. You have to reimagine your whole life around that*.”
    - So the reasonable mind might say, “*No puppies. Puppies are never for you*.”
  - What does the **wise mind** say?
    - This is great about teaching the idea that the wise mind is *not a synthesis*
    - A dialectical synthesis is *not a compromise*
    - It’s not a halfway point because if I were to say that, then wise mind would say, get 6 of the puppies if there are 12, and that makes no sense as a compromise or as a synthesis because it’s not seeing the validity in both sides
  - So what would the **wise mind** be?
    - That would vary depending on the person
    - For some people, a wise mind decision would be to bring home a puppy
    - For other people, a wise mind decision would be to say, now is not the right time for me to have a puppy, but I am going to do X, Y, and Z in order to increase the likelihood that I can have a puppy in the future
    - The wise mind might be, I have the perfect scenario now, I can bring home two puppies and we will live happily ever after

**The DBT workbook**

- Peter notes how large the [DBT workbook](https://www.amazon.com/Skills-Training-Handouts-Worksheets-Second/dp/1572307811/ref=pd_bxgy_img_sccl_1/134-1589977-4742414?pd_rd_w=IRmST&content-id=amzn1.sym.7757a8b5-874e-4a67-9d85-54ed32f01737&pf_rd_p=7757a8b5-874e-4a67-9d85-54ed32f01737&pf_rd_r=DSTS93GQQME7MAD7XBTT&pd_rd_wg=Qdx8G&pd_rd_r=633a63dd-0b2e-4c8e-a06e-f9df079d028b&pd_rd_i=1572307811&psc=1) is, to think this is the work of 1 person is incredible

## Practicing mindfulness and radical acceptance in the context of DBT [51:00]

**Early insights Marsha had treating patients with CBT that led her to create another form of behavioral therapy, DBT**

- She realized  that pushing patients for change too hard resulted in disaster
- She recognized a need to find a middle ground to balance these 2 things

> “*Part of the lore of the story of DBT was that she was writing about this idea of balancing change and acceptance*”‒ Shireen Rizvi

- These were the days where she would write up notes, either handwritten or on a typewriter, and hand them over to a secretary who would type them up or revise them
- Marsha’s story is that her assistant who was working on typing this all up, came to her one day and said, “*My husband is a graduate student in philosophy. We were looking at this. And we think that what you’re describing actually is something that he studies and is called* [*dialectics*](https://en.wikipedia.org/wiki/Dialectic).”
- Marsha didn’t know anything about dialectical philosophy as she was iterating this treatment
  - This was one of those happenstance moments that came to her and then of course she sought out readings, descriptions of dialectical philosophy and saw, yes, that is exactly what she’s thinking
- That dialectical philosophy informs a lot of science and scientific thought
- It actually worked well within the paradigm of the development of cognitive behavioral treatments
  - That’s where DBT started to take form
- If you’re familiar with her books, you know that her original treatment manual that was published in 1993 and also the original skills workbook that was published in 1993, says on the cover [*Cognitive Behavioral Treatment for Borderline Personality Disorder*](https://www.amazon.com/Cognitive-Behavioral-Treatment-Borderline-Personality-Disorder/dp/0898621836/ref=sr_1_7?crid=9UBPYJ584305&keywords=Marsha+Linehan&qid=1655985614&sprefix=marsha+linehan+%2Caps%2C317&sr=8-7) (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/08/f2-rizvi.png)

**Figure 2. Marsha’s original  and updated skills workbooks.**  Image credit: [Amazon.com](https://www.amazon.com/s?k=Marsha+Linehan&crid=9UBPYJ584305&sprefix=marsha+linehan+%2Caps%2C317&ref=nb_sb_noss_2)

- The [newer edition](https://www.amazon.com/DBT%C2%AE-Skills-Training-Manual-Second/dp/1462533612/ref=sr_1_1_sspa?crid=9UBPYJ584305&keywords=Marsha+Linehan&qid=1655985782&sprefix=marsha+linehan+%2Caps%2C317&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUExWDNWQUpDWTVYN09UJmVuY3J5cHRlZElkPUEwOTI1MjY5MTBSUDZLVTBBUkhRUCZlbmNyeXB0ZWRBZElkPUEwOTg5NDcxM0ZUVEoxOVRDTFlHJndpZGdldE5hbWU9c3BfYXRmJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ==) says dialectical
  - She didn’t use the term dialectical for the first edition because the publishers told her nobody will know what this means and nobody will want it

**When did Marsha develop an interest in Zen philosophy and the practice of mindfulness?**

- Peter notes that mindfulness is an important muscle one develops as they move along their DBT journey
- Shireen thinks this was all happening around the same time
- Marsha grew up in a Catholic family and identified as a very religious person
  - At one point she thought she was going to become a nun
- Another reason why she didn’t make her story public early on is that she didn’t want the lesson to be‒ if you want to get better, you also have to have a spiritual experience
- Instead, she wanted to figure out‒ how do I operationalize this spiritual experience so that other people could experience it as well?
- This was going on in her mind at the same time she was interested in her own spiritual development and learned more about Zen and became a student of Zen Buddhism
  - And saw that they connected and came together
  - Because ultimately how she translated that personal experience is into this idea that you mentioned earlier of **radical acceptance**
    - *Can you radically accept this moment, this situation, yourself, exactly as it is*
    - And if you can experience that radical and complete and total acceptance, you can experience joy
    - She would say, “*You can crack open the moment of joy*”

![](https://peterattiamd.com/wp-content/uploads/2022/08/f3-rizvi.png)

**Figure 3.  Radical Acceptance**.  Image Credit: [Skyland Trail](https://www.skylandtrail.org/accepting-reality-using-dbt-skills/)

**An example of radical acceptance**

*Let’s say you’re going somewhere important (your kid’s sporting event or the airport), and if you miss it, it’s going to really wreck things.  You’re stuck in traffic, there’s nothing you can do, there’s an accident a mile ahead.  Your patient is in the car and you’re sitting with them.  They are getting very flustered at the situation.  Walk us through radical acceptance in this situation.*

- A precursor is that **when we’re experiencing suffering**, however you define that suffering, if you were to look at it more deeply, you would say the vast majority of the time that we’re experiencing suffering, ***it’s because we’re thinking about something that has already happened***
  - Ruminating, wishing it hadn’t happened, mulling something over, whatever it might be
  - Or you are thinking about something that may happen in the future
- And that actually, if you just experience this one moment and let go of the past and the future that alone might reduce your suffering a ton
- Well you could say you might experience pain in this moment, because this moment might be painful, but we’re not adding on
  - We’re not adding on all of these things that actually increase our suffering
- So in this moment, when you are stuck in traffic, you can’t undo the decisions that you made that got you to this point
  - Because of course we’re saying things like, oh, if only I had taken this other road, or if only I had left 15 minutes early
  - Or we think all these stupid people on the road, if only they had done something different, those are all fantasy thoughts because they’re all not reality of this moment

> “*So I would say, how we reduce our suffering in this moment is to say, I can’t change any of that for today in this moment. This is what it is.*”‒ Shireen Rizvi

- What happens, you’ll see actually I’m holding my palms up right now is I’m talking because I associate holding my palms up with this idea of willingly accepting this moment, which is, this is the moment that I’m in
  - It’s a surrender posture

***What happens if I accept that right now there is nothing I can do to change this?***

- The **other piece to this** is, and this is why it’s not just about acceptance because I would say if this is something that happens a lot, if you often find yourself in situations, whether it’s traffic, running late or something like that, then ***we absolutely want to figure out how to prevent this from happening as much in the future***
  - But in this moment when you’re there, you can’t do that

**Peter’s takeaway:** **In the moment of crisis, you don’t really want to be problem solving around how to avoid this the next time**

- Shireen agrees‒ when I’m at a 100 or a 90 of distress, I’m not going to be able to effectively plan how to avoid this crisis again in the future
- Peter notes, “*Much of what you’re saying sounds very familiar to anybody who has practiced* [*mindfulness*](https://en.wikipedia.org/wiki/Mindfulness) *or* [*Vipassanā*](https://en.wikipedia.org/wiki/Vipassan%C4%81) *or one of its derivatives in forms of meditation. We’ve had a couple of podcasts that have gone into that and the goal of the practice is to help you identify thoughts and to separate you from these thoughts*.”
  - [#34 – Sam Harris, Ph.D.:](https://peterattiamd.com/samharris/) The transformative power of mindfulness
  - [#72 – Dan Harris:](https://peterattiamd.com/danharris/) 10% happier – meditation, kindness, and compassion
  - [#139 – Kristin Neff, Ph.D.:](https://peterattiamd.com/kristin-neff-the-power-of-self-compassion/) The Power of Self-Compassion
  - The goal of the practice is to help you identify thoughts and to separate you from these thoughts

***There’s probably nothing in this exact moment that is particularly unbearable, but the thoughts are unbearable***

- If you let them go
  - Let go of the thoughts‒ I’m going to get to the airport, I’m going to miss my flight. Then I’m going to have to wait for another flight and I’m probably going to miss that too or they’re not going to be a good seat or whatever, and then I’m going to not get to where I’m going and maybe the whole trip, duh, duh, duh.
- Peter asks Shireen what she would say to a person who says, “*I understand that those thoughts, which are all future, are not happening to me now and I can just sit here right now in this car and frankly I could turn on music and enjoy the music for the moment, but that doesn’t change the fact that’s going to happen. It doesn’t change the fact that in an hour, I am going to get to the airport. I am going to have missed my flight*.”
- When they get to the airport, that’s a new moment and a new situation
- Part of it depends on your goal
  - So when you’re experiencing distress in that moment of being stuck in traffic and not having any control about that, what’s your goal?
  - If it’s to get to the airport in 2 minutes, sorry, that’s not a realistic goal
    - We’re going to have to let that one go
  - If it’s to problem solve what will happen when you get to the airport, is there something that you can do while you’re in the car? Possibly.
  - But if your goal is to, how do I make this moment more bearable because I can’t undo anything, then I think we have some other options available to us
    - Which could be distracting, doing something like music or some other forms of distraction that you could safely do in the context of your car

## Applying “radical acceptance” to tragic scenarios [1:02:00]

**Other examples where radical acceptance is harder**

- 1 – A person receives a terminal diagnosis
  - For example a young person is diagnosed with cancer and told they have 6 months to live
- 2 – A child drowns
  - This example is fresh in Peter’s mind because a close friend of his wife, her daughter drowned a year ago
  - It’s hard to imagine what they are going through and there’s nothing that will undo that

*How can radical acceptance allow (1) a person to come to grips with the fact that they have 6 months to live and (2) the tragedy of a parent losing a child?*

- Peter notes cognitively the person in (1) can figure out how to have the best 6 months and parents in (2) can be a great parent for their other children but he doesn’t know how he would cope with either situation

> “*So now let’s go from the sort of banal of traffic to the really heavy stuff of life*”‒ Peter Attia

- Shireen has thought about both of these things a lot
- One of the **misunderstandings about acceptance** is somehow this idea that if you accept something you don’t experience pain
- She wants to differentiate that **life is full of pain**, no matter how Zen and mindful you are, you’re going to experience pain and a lot of pain and we’re not trying to eradicate pain because actually without emotional we would have other problems
  - If we did not experience pain as you hear about your friend’s daughter, that would be a problem for you in a different way

> ***“We need to understand that pain is going to be a part of our lives and actually we cause a lot of problems for ourselves when we try to escape the experience of pain***.” —Shireen Rizvi

- When you ask, “*How can we ask somebody to radically accept this?*” Shireen would answer in part by saying, “*What’s the alternative?*”
  - The alternative is refusing to accept
    - How does that work? How do you do that? And how long can you sustain that for?
  - She would argue that the **refusal to accept** (or the denying reality) actually ends up taking a lot more mental resource and ultimately causing more problems for you in the long run
- From a DBT perspective, when we talk about practicing the skill of radical acceptance, we have another expression called **turning the mind**
  - This refers to the fact that practicing radical acceptance involves a very active process of continuously turning your mind towards acceptance

**A metaphor for understanding how to practice radical acceptance**

- The metaphor is that you’re at a fork in the road and one road is acceptance and another road is refusal to accept
- You’re going to come across the fork in the road possibly multiple times a minute
- What does it look like for you to say “I’m going to actively and willingly choose the road of radical acceptance?”
  - How can I turn my mind, my body, my soul towards acceptance?
  - For Shireen, a lot of it is actually asking myself that question of “***What’s the alternative? What other choices do I have?***”
  - And recognizing that **more suffering comes from refusing to accept**
- Peter adds, “*The fact that it’s referred to as radical acceptance versus acceptance, I think kind of highlights that it’s not easy.*”
- He also notes from his practice, there is a lot of backsliding
  - There’s a lot of, “*No, I don’t want to accept this today. I don’t accept this. I’m angry about this. I want to pout and have a little pity party about this*.”
  - And then maybe he experiences that and realizes that wasn’t very productive because now he actually feels worse

## The five domains of skills taught in DBT [1:07:15]

- Peter was introduced to DBT through [Andy White](https://andrewwhitephd.com/about/)
- Peter thinks the deliberate work you have to do in DBT is one of the reasons it works for him
  - You write, you have homework, you have to write out your emotions and your decisions and the trees‒ if you feel this, do you do this?

**How deliberate was the assigned work in Marsha’s system?**

*Does CBT have a similar workbook that she modified or did it come from other systems?*

- CBT is associated with doing homework, doing work in between sessions
- More standard cognitive therapy is associated with doing worksheets about your thoughts
  - What thoughts you have, what the evidence for your thoughts are,
- Doing work, doing worksheets, not shying away from the term homework as part of the treatment is very consistent with the CBT model
- Shireen remarks, “*You just reminded me… that one of the assumptions about borderline personality disorder from the DBT lens is that we use a skills-deficit model, which is to say that we believe that* ***people who end up with the constellation of problems associated with borderline personality disorder have an absence of certain skills and skillful behavior in their lives****.*”
  - And that absence could be a result of never having been taught it in the first place
  - Or having had effective behaviors, been punished out of them by their environment
  - This is the environmental piece that we’re talking about, but they don’t have
  - We all have certain deficits in some skillful areas
  - Peter adds to the idea that skills have never been modeled for you, a bigger problem is that you’ve don’t things incorrectly and never been corrected
    - So you’ve built all the muscle memory doing it wrong your whole life and you didn’t have parents there to say, “*Hey, that’s not how you do it. Do it this way*.”
    - Shireen agrees, “*And it’s a lot harder to unlearn a behavior than it is to learn a new behavior. We know that as a phenomenon*.”
- Marsha developed this book, we refer to as the skills training manual, that’s part of the treatment of DBT
- What DBT is probably most known for are the skills that are part of it
- These skills deficits are thought to exist in 5 different domains

**DBT teaches 5 domains of skills**

- So when we say someone has a **deficit in mindfulness**, it’s not that we’re referring to anybody who doesn’t practice Zen as having a mindfulness deficit, but ***it’s a deficit in the capacity to be aware of the present moment***
- 1 – **Mindfulness**
  - The capacity to be aware of the present moment

> “*Everybody has deficits in all of these areas at different times…that’s part of the beauty of DBT is that it can help so many people*”‒ Shireen Rizvi

- 2 – **Interpersonal effectiveness**, which could mean conflict with others
  - But also could mean deficits in knowing how to ask for something effectively
  - Deficits in knowing how to say no effectively
- 3 – **Emotional regulation**
  - Deficits in knowing how to label your emotions
  - What to do with emotions when you have them
  - How to prevent having intense and extreme emotions
  - How to change emotions
- 4 – **Distress tolerance**
  - How do you tolerate really stressful and distressing situations without doing anything to make the situation worse?
- 5 – **Self-management**
  - Deficits in self-management, which has to do with being able to do things you don’t want to do
  - Broadly speaking, this describes how some people can get up every morning at 6 o’clock and go exercise and eat a healthy breakfast and go to work, while other people snooze their alarm, 8-12 times, haphazardly eat breakfast, and sometimes get to work late
- DBT is designed as a treatment package to teach people the skills to overcome deficits in these different domains
- Peter wasn’t aware of the 5th domain, is this a more recent addition?
  - No, it’s in the original treatment manual from 1993
  - But Marsha’s thinking was that she didn’t need to create a whole other skills module for self-management because DBT therapists are going to infuse this throughout their entire treatment
  - This may have been a missed opportunity at the time because Marsha didn’t realize that many clinicians don’t know how to do this very well
  - Marsha was thinking this is where teaching people principles of behaviorism comes in
  - So you don’t see #5 in the skills manual unless you look
- Where you would see it (#5) now is in the set of skills that are referred to as the **walking the middle path skills**, which actually came out of the first adaptation of DBT for adolescents and their families
  - [Jill Rathus](https://behavioraltech.org/about-us/trainers-consultants/jill-rathus-ph-d-jill-rathus-ph-d/#:~:text=Jill%20Rathus%2C%20PhD%2C%20(PhD,DBT%20Clinical%20Research%20Training%20Program.) and [Alec Miller](https://www.cbc-psychology.com/cbc-staff/alec-l-miller-psy-d), who, along with Marsha, created the [adolescent version of DBT](https://www.amazon.com/DBT-C2-AE-Skills-Manual-Adolescents-Rathus-dp-1462533639/dp/1462533639/ref=mt_other?_encoding=UTF8&me=&qid=1655994042)
  - They took a lot of these principles of the self-management skills and created this 5th module of DBT skills called walking the middle path
  - They teach adolescents and their caregivers, their parents, these skills about how to manage your behaviors, how to learn behaviors, and more broadly, how to be more effective

## Why Marsha chose borderline personality disorder as her focus when developing DBT [1:13:30]

- Peter notes that DBT originated around a modified tool to help some of the people who are suffering the most

**Do you think somewhere in the back of Marsha’s mind she wasn’t just thinking “*****how do I make CBT better for the most recalcitrant depression, suicidal patients,*****” but she was thinking about BPD?**

*Is it fair to say that CBT historically has not been very successful for borderline personality disorder?*

- At the time Marsha was developing this treatment, we didn’t know
- There have been studies looking at whether the presence of borderline personality disorder interfered with outcomes for standard CBT
  - The data is mixed on that
  - Some studies show that the presence of BPD lead to worse outcomes
- Marsha didn’t know
- The reason that she gives for her pivot to borderline personality disorder as a population of interest is to get funding from the NIH
  - When she was first seeking research dollars, back in those days, you could only get research grants from NIH, if you identified a disorder of interest
  - She got grants to start randomized clinical trials of DBT
- She was interested in suicide and suicidal behaviors, and at the time she thought her choices, based on that behavior, was either depression or BPD
  - She didn’t want to focus on depression because there were already so many smart people doing depression research
  - She wanted to go into an area where there weren’t already a lot of people doing research in this area, and that’s why she chose BPD
- Shireen thinks there more to it than that
  - Marsha’s own experiences would lead one to assume that she also had specific interest in the emotion dysregulation piece that goes along with BPD and doesn’t necessarily go along with more standard depression

## Is there any benefit in doing DBT for someone without a pathological condition? [1:15:45]

**Is there any benefit in doing DBT for someone without real pathology?**

- Yes, and this is what is so fascinating about this treatment
- This was the treatment that was developed for what could have been termed the worst of the worst at the time
- And it’s a treatment that is actually for all of us
- Shireen has yet to meet a person who could not benefit from at least learning some of the skills
  - She’s yet to meet a person who hasn’t identified the skills as being something that could be relevant for them
- Now, whether they’re always willing to use them or apply them or want to do them, that’s a different issue
- But when she talks about what the skills are for, she gets universal agreement, that those skills could be useful to learn

> “*Those skills could be useful to learn*”‒ Shireen Rizvi

**Race cars as a metaphor for DBT**

- Peter loves cars and race cars
- A lot of people say, “*I don’t understand how there’s any value in a company like Mercedes or any of these companies participating in building race cars. It’s such an expensive proposition. It seems so gratuitous*.”
- But the trickle down effect and impact of that on street cars is remarkable in terms of  fuel efficiency, power, safety, etc.
- If you want to build a Formula One car, it’s basically a $400 million a year operation
  - Those cars are functioning at the absolute limit where every gram matters and the stakes are so high
- And if you take everything that you learn there and bring it down to the rest of us who aren’t driving Formula One cars, the benefit is enormous

**Peter’s experience with DBT [1:18:00]**

- DBT is a system that was conceived and validated on a sample set of people with real difficulties in regulating their emotions
- When Peter goes through the list of the DBT skills pillars, it’s like, check, check, check, check, check
  - He might not meet the diagnostic criteria for something in the DSM-5
  - But he has enormous problems with all of these things
  - He has staggering deficits of skills
- One of the first exercises that really illustrated that was something as simple as **identification of emotion**
  - He couldn’t identify an emotion that wasn’t anger
  - He found it very difficult to go beyond anger, to helplessness, sadness, hurt, fear, all of these other things
  - He and Andy must have spent three months with his homework just being, “*Okay, you’re going to get angry 16 times a day. 16 times a day, pull out this sheet and go through and figure out what else is going on*.”
    - That sounds maybe simple, but that’s learning a new language as well
- Shireen asks, “*What made you want to do that? Why not just stick with your experience of anger?*”
- Peter explains, “*What’s the alternative? Well, the alternative is you’re really alienating a lot of people. And I think watching my kids get older, and realizing I don’t want them to see me… I think I was just angry 24/7. I don’t think I really experienced anything that wasn’t anger*.”
  - He realized he needed to break this cycle
  - Because if every time he got cut off on the road, he’s screaming so much at the person who cut him off so much that you can see the droplets of his spit on the windshield
  - It’s not like he was actually yelling at my kids
    - But he doesn’t think kids can appreciate the difference
    - A 5-year-old doesn’t understand that just because daddy is yelling at the guy that cut him off, he’s not mad at him
    - Once Peter came to realize that, he decided, “*No, I don’t want to do this*.”

## The DEAR MAN skill of DBT [1:20:00]

**Shireen’s experience with DBT**

- She doesn’t have her own experience with borderline personality disorder or psychopathology
- She learned DBT as a grad student in her early 20
- It’s been a long time now that she’s been using and applying DBT
- She will still go in her head, when a difficult interpersonal situation is happening
  - She will walk through the steps in her mind of the DEARMAN skill‒ ***of how to ask for something and be effective*** (see the figure below)
- It’s been 25 years, but she still uses this skill
- She’ll be writing an email and will say, “*Wait, pause, edit.  Am I following the DEAR structure?  What can I take out? What am I adding on? What judgements are in here?*”
- She feels like she’s been a pretty skillful person for most of her life, yet she still benefits from  actively thinking about using these skills in her daily life
- Peter is still early in his journey
  - If 10 out of 10 is having all the skills and always employing them
  - And 1 out of 10 is not even knowing what a skill is
  - He’s in the 3-4 out of 10 range
    - He knows most of the skills and half the time he reaches for them correctly

**![](https://peterattiamd.com/wp-content/uploads/2022/08/f4-rizvi.png)**

**Figure 4. The “DEARMAN” skill.**  Image credit: [Skyland Trail](https://www.skylandtrail.org/)

- Acronyms are meant as mnemonics to help us remember things
- Sometimes people have a negative reaction to all the acronyms in DBT and that’s a fair criticism
- DEARMAN is a skill that’s in the **interpersonal effectiveness module**
- These are the skills that are designed to help you be more effective with other people in your life

***DEARMAN is specifically the skill on how to ask for something in a way that gets another person to give it to you***

- DEARMAN is also a skill on **how to say no**, to something in a way that gets the other person to accept your no
- DEARMAN walks you through these 7 sub skills to help you do that
  - It stands for *describe*, *express*, *assert*, *reinforce* (see the figure above)
    - That’s the D-E-A-R part, that’s basically what you say or write to ask for something
  - Then the MAN stands for *mindful*, *appear confident*, and *negotiate* (or be willing to negotiate)

**An example using the DEARMAN skill**

- Do you have a situation that is coming up for you where you need to ask for something or say no to something?
  - Peter’s daughter wants to get a 3rd earring
  - She has 2 piercings in her ears, and not she really wants to get a 3rd
  - He’s hoping to talk her out of it for a little longer
    - He has a fear that she’s going to damage her ears and have so many things hanging that it will stretch her ear lobes out, and one day she’ll regret it
    - He realizes it’s an irrational fear
- So the ask is to say, “*Will you postpone this decision for a while?*” Or, “*Will you take this off the table for a period of time?*”
- Peter adds that his wife thinks it’s reasonable, so now it’s become more of a negotiation
- His daughter is 13
- If Peter were to practice the DEARMAN, the first step would be to **describe** the situation without adding on any interpretations or judgment
- Peter could say to his daughter, “*Olivia, I understand that you want to now get a third earring.*”
  - Great, often this means exactly what you did, which is to keep it short

***Sometimes we have a tendency to go on and on about all of our reasons, but the more we do that, the more we lose the other person’s interest***

- Next would be to **express your feelings** about it
- Peter explains, “*I have some fear about you getting a third earring, because I worry that it would damage your ears. And this would be something that would bother you many years from now.*”
  - Shireen notes he would work on simplifying/ shortening this to simply “*I have fears that you would regret this if you did it*”
  - This was nice because Peter didn’t add on judgements, he didn’t say “*You shouldn’t do this*”
  - You want to focus on describing the facts and expressing your feelings about it
- Next is **assert** (the A), where you ask directly for what you want
  - Peter’s response, “*Olivia, would you be fine if we could postpone this decision until you’re older, maybe even out of high school?*”
  - Shireen advises to think about this prior to asking‒ what is it specifically that you’re asking for?
  - A more direct assert might be, “*Would you be willing to postpone this decision until after high school?*”
  - But it could be there’s other factors that might contribute to you asking it more tentatively or more firmly
  - What Shireen frequently tells patients (this doesn’t apply to this example) is that a lot of the time we don’t actually assert, we just want somebody else to read our minds or do what we want
    - Women often have more trouble with this on average than men, and there are loads of reasons for that
    - But actually asking directly for what you want is often really challenging for people
    - What people often do instead is just describe and express, then expect the other person to know what it is they want (and do it)
  - The aim of this skill is to get people to learn how to be more comfortable with asking and stating directly what it is that you want
- Next, the R stands for **reinforce**
  - You want to say explicitly, what’s in it for the other person? What reward could come their way by giving into your request or giving you what you want?
  - Which in a second, we can talk about whether or not this is manipulation
  - But in your dialogue with Olivia, what’s something that you could imagine reinforcing?
  - Peter adds, “*You play volleyball. You’re really good at volleyball. You’re playing year round now. And the more jewelry you have on, the greater your risk of injury. You get hit in the head with a* ball. That’s one more thing that could hurt. This is just one less thing to worry about.”
    - She’ll argue that she can just take the earrings out
    - Maybe she’s right
  - Or he might say, “*Optionality is a great thing. And by not doing it now, it doesn’t mean that you can’t do it tomorrow. You always have that option, but you can’t undo it once you have it.*”
  - Shireen agrees with Peter about all of these points
  - What Peter is doing is providing more evidence in favor of what he’s asking for
  - Think about reinforcing a reward she could expect if she were to say, “*Yes, dad, I won’t get another piercing.*”
    - It would be bribery, but bribery is what we do all the time
  - Peter adds, “*If you don’t do this, we could go shopping, and those new converse shoes you love, let’s get those instead*”
    - Peter never thought of it this way, he always thought of it as more of a theoretical reinforcement
    - Shireen adds, this can sometimes world but more often than not, it needs to be a tangible connection to this
  - Shireen provides a good fallback to asking somebody for something‒  is to say, “*If you do this, I would really appreciate it*.”
    - My appreciation of you and your behavior is a reinforcer
  - Peter notes that for his daughter, this is not high on the list of things for her
    - Exactly, so you have to think about the person you’re asking and what is most likely to work
    - You also have to think about, to a certain extent, how important is it for you to get this thing that you’re asking for?
    - If it’s really important for you to get it, then you might say, “*Oh, I don’t like buying her sneakers instead.*” But if that’s what worked, then we would say, “*It’ll be effective in this situation*”
  - Peter asks about the meta thing here, which is he’s teaching her by his behavior what is a more emotionally regulated way to handle this
    - The old version of Peter would have just said, “*No, I’m the parent.  You’re doing what I say. This is nonnegotiable*”
    - And if he was the kid who argued, he would have gotten the back of the hand to his face so she’s lucky for not pushing this discussion
    - Shireen adds in this old version, his daughter would go out and get the earring then try to hid it from him
    - Now Peter is trying to model something better and is looking into [DBT for adolescents](https://www.amazon.com/DBT-C2-AE-Skills-Manual-Adolescents-Rathus-dp-1462533639/dp/1462533639/ref=mt_other?_encoding=UTF8&me=&qid=1655994042)

## Adapting DBT skills for adolescents and families [1:31:00]

**Standard DBT for adults**

- If somebody were receiving DBT treatment, they would be coming to a skills training group once a week
  - Or receiving skills training individually, where they’d meet with a therapist who teaches them these specific skills
- They practice it, they come back, report it on their practice, and get feedback and coaching, etc.
- In a skills training group, you might have a number of adults together and you teach them all together and you assign homework, and you all talk about the practice and use of skills
- What was an amazing, a brilliant adaptation for DBT for adolescents, is that in your skills group is a multi-family skills group
  - Where you have the adolescents in the skills groups, but you also have the adolescent’s parents or caretakers in the skills group at the same time
  - And everybody is learning the skills altogether
  - And therefore the parents and caregivers have to practice the skills on themselves, not just for their adolescents

> “*We’re teaching everybody the skills, because the parents need the skills as much as the adolescents need the skills*”‒ Shireen Rizvi

**Is it sometimes easier for kids to pick up these skills than their parents?**

- Peter thinks it would be easier to come to DBT with no skills positive or negative, and then just learn the positive skills
- When you have decades of reinforced negative skills (anti-skills), you have to unlearn them and then build positive skills
- Sometimes yes, but there’s different levels of willingness and willfulness
- Many times adolescents are not there by choice
  - Their parents or school says they have to do this
- In some situations the adults don’t want to be there either, but there is generally more willingness

**The structure of DBT therapy for someone who doesn’t meet the criteria for any of the DSM-5s but is simply having difficulty interpersonally**

## Identifying vulnerability factors, increasing distress tolerance, and the impact of physical pain [1:33:45]

- One thing Peter realized was, so much dysregulation stems from interpersonal interactions gone bad
  - With your spouse, your child, your coworker, the person who cuts you off on the street
  - An interpersonal interaction that doesn’t meet your expectations (whether reasonable or not) can feed into emotional dysregulation
    - This can create an awful feed-forward loop that can lead to bad behaviors
    - Emotions and thoughts feed off each other and lead to behaviors
    - This seems like a path of how this goes wrong for many people
- Peter loves the idea of **distress tolerance**
  - One of the most interesting concepts considering it a window
  - This entire year, his distress tolerance window is about this thick and it’s all his own fault
  - He’s put way too many things on his plate
  - So there’s no buffer, there’s no margin for error
  - Even before this podcast was recorded, he was getting upset about some stupid video he had to record
    - He had to record it twice
    - It was supposed to be 2 minutes
    - The first time it took 2 minutes 20 seconds
    - Something so dumb shouldn’t bother him, but it did because he’s out of time
  - He finds that something like external factors will change your distress tolerance window
- For Peter,  being too close to the top is where he gets upset
  - For other people, it’s being too close to the bottom
  - Getting dysthmic or depressive versus getting irritable
- During good times‒ imagine being on vacation, for 2 weeks where nothing is going on, you don’t have to worry about email
  - If the restaurant forgot your reservation, it’s no problem, you’re fine to go somewhere else

**How can you make your distress tolerance window higher? Wider?**

- Everyone can benefit from this

*Where do you start?*

- This reminds Shireen of the importance of learning what makes us more vulnerable to negative emotions/ stress/ distress

> “*Another skill in DBT is to identify and understand what our vulnerability factors are*”‒ Shireen Rizvi

- Sometimes we can target or treat our vulnerability factors and our lives just go much more smoothly
- For example: when we have better sleep, when we remove some things from our list so we’re not stressed all the time
  - That can solve a number of problems
- This is one of the first things Andy asked Peter‒ “*Tell me what’s going on physically. Are you in pain? Are you sleeping? What are the other vulnerabilities?*”
  - Peter has been working with him for 2 years now
  - Andy asks him this question once a week
  - Peter thinks he’s trying to gauge what state h e’s in as a function of how many things are pressing on him
  - Shireen adds the question, “*In those moments, how able are you to receive info?*”
    - Like if you’re at 90 on a scale of zero to 100, you’re not taking in a lot, you’re not learning a lot
    - If you’re at that level, then we need to figure out how to get you regulated enough so that you could learn to do something differently
  - She thinks it’s great that he asked those questions
  - For herself, when she’s in physical pain, she can’t do much of anything
- Similarly, if you haven’t slept well in 2 nights, you can’t and you shouldn’t assume that you are at your best, in terms of your ability to receive both information and tolerate things
- Peter has had so many times when he’s been in pain and it’s made him more irritable

**What does Shireen do when she’s in pain?**

- Shireen admires people so much who have chronic pain conditions and are able to function in their lives, because she thinks that would be a challenge for her to learn how to navigate that
- When she’s experiencing pain that is a huge vulnerability factor for her
  - It makes her more irritable in general, much more likely to snap at people or to have less patience for things
  - This is true whether it’s a transient headache (that she knows will pass) or if she hurt her back exercising and she feels it every which way
- Recognizing this physical pain/ vulnerability and accepting it is important because she can’t just will it to go away
- In this situation she asks herself, “*So given that it’s a vulnerable time for me, is there a way that I can reduce demands on myself in other ways? Or is there a way that I can treat myself kindly in other ways to kind of offset the pain that I’m experiencing?*”
- Sometimes it’s learning to be more explicit and vocal as it relates interpersonal effectiveness
  - Because when we experience pain, it’s often entirely experienced within our bodies and other people may not even know that this is happening for us
  - So learning to say it out loud
    - Granted, it helps as your kids get older, you can say things, when they’re younger you can’t say as easily, “*Mommy has a headache… So I need to have a little bit of space from this conversation or this situation.*”

***Learning to recognize this as a vulnerability factor and then figuring out how to act more skillfully within this context to prevent the lashing out, to prevent irritability***

- Shireen’s experience is that whenever she acts out of anger, she almost always regret it and feels worse about herself afterwards
  - It’s almost a selfish process
  - It’s to help the other person by saying, “*I’m not going to get irritable with my kids,*” it’s to protect them, but it’s also to help her not feel so bad afterwards
  - Because her kids will recover, she’ll recover, but she doesn’t like how it makes her feel
- Peter knows the cycle of anger and shame and isolation well

**Peter’s experience with pain**

- One thing he’s observed in himself is, not all pain is created equal
  - Expected pain seems far less destabilizing than unexpected pain
- He had shoulder surgery recently
  - He doesn’t know why he wasn’t told how much it would hurt
  - So he didn’t want to take narcotics, etc
  - For 2 days the pain was so bad that he couldn’t sleep
    - He was literally sitting up in a chair, not sleeping for 2 nights
  - Even for that week, the pain was excruciating
  - It didn’t negatively impact him in terms of interactions
  - Knowing what he knows about how much pain can destabilize distress tolerance capacity, he would’ve thought well that would’ve thrown him over the edge, but it didn’t, because he realized he just had an enormous operation
- When he doesn’t expect the pain, it’s far more destabilizing from an emotional regulation standpoint
  - He’s had headaches that have lasted for 3 days due to some awful tension
  - No amount of Tylenol can make it go away
  - It’s not as bad as his shoulder pain, but he didn’t expect it
- It must be really frustrating for people with chronic pain because many are told by physicians either
  - There’s nothing we can do
  - This is in your head, and you should just ignore it
- Shireen agrees personally and professionally
- She noticed that Peter engaged in a lot of self-validation with regard to his shoulder surgery
  - Basically, saying, “Of course I feel this way. It’s okay to feel this way.”
- She thinks with the other pain that we experience, sometimes we’re actually **invalidating ourselves**
  - We might not realize that we’re doing this so explicitly
  - We’re saying, “*Why am I feeling this way? What’s wrong with me? How could this be happening?*”
  - We’re rejecting our experience

**Shireen’s example of dealing with pain**

- She’s tapering off a medication right now
- She didn’t realize, when I was prescribed this medication, how difficult it’s known to be to get off
  - And it was sort of a moment of weakness that she was prescribed this and decided to take it
  - Had she known how horrible it would feel to go off it, she never would’ve gone on it
- She’s really going kind of nuts with how much she’s micro dosing herself on this medication, because she starts to feel this withdrawal symptom
- She is realizing the point that Peter made‒ part of the suffering she is experiencing is about her thoughts
  - Thought of, “*Oh, what if this goes on forever? What if this doesn’t end?*”
  - Even when she realizes it’s not going to last forever, the subsequent thought is, “*But can I tolerate this for two weeks? Why can’t it just go away?*”

> “*This is the way in which we do have some control over the suffering that we experience, because we’re adding on all of these thoughts*”‒ Shireen Rizvi

- One of the mindfulness tricks Shireen loves to hear is, “*It’s okay to feel this*”
  - This relates to learning to be mindful and accepting of your emotions

***It seems so simple, but to say those words “It’s okay to feel this,” no matter what the “this” is, can be a really powerful experience***

- Even with pain
- Say it and notice the effect it has

## The DBT chain analysis: assessing problem behaviors and identifying vulnerability factors [1:44:30]

**Is it liberating to establish a patient’s vulnerabilities?**

- Going back to the beginning of the interaction between the clinician and patient, once you establish their vulnerabilities, this is a form of validation and can be liberating for people
  - Is it received that way?

**Peter’s summary:** *vulnerabilities are clear things that are going to make it more challenging for you to be understanding of others (or yourself) and to regulate your emotion, control your thoughts, and ultimately control your behaviors*

- Shireen agrees
- For a lot of people, understanding the vulnerability factors and determining ways to reduce their vulnerability is really critical

**What would Shireen typically do with somebody who first came in?**

- She’s used to working only with people who meet criteria for BPD and are usually on that more severe end of the continuum
  - She doesn’t have experience with people that are not as extreme
- She thinks for a lot of people learning about vulnerability factors is really important, but she puts vulnerability factors in the context of something done in DBT called **chain analysis** (illustrated in the figure below)
  - This is a way of assessing problem behaviors that people have that they want to change
  - A way of assessing it in order to figure out how to change it going forward
  - Vulnerability factors is an element of that chain analysis

![](https://peterattiamd.com/wp-content/uploads/2022/08/f5-rizvi.png)

**Figure 5.  Chain analysis.** Image credit: [Sensitive to Sound](https://www.sensitivetosound.com/treatment/dbt/)

- For example, if Peter were in treatment with her and one of the things we were working on is this target behavior of him exploding in anger at various points
  - They would identify a recent occasion in which that happened, and then do an assessment of what were all the factors, events, thoughts, behaviors that led up to that behavior?
  - Next, discuss the consequences of that behavior?
  - Consequences would be the chain that we assess as a way of ***identifying what can be modified in this chain going forward to make it less likely that that problem behavior is going to show up again?***
- What we’ve been talking about is addressing what happens actually *very early on in the chain of that vulnerability factor*
- And for some people, and in some situations, working on the vulnerability factor, changes everything that follows
- But there’s other events and circumstances where it’s not about the vulnerability factor or the vulnerability factor is just one element, but something happens in the environment, a **prompting event**, we would call it, perhaps that sets off the chain
  - And it doesn’t matter whether you got sleep or not the night before
  - Because whenever that prompting event happens, you’re going to explode in anger, right?

***So we want to work on vulnerability factors, but we also want to identify other critical elements along the path towards the problem behavior that we can address and behaviorally manipulate***

- Peter responds, “*When you state it that way, it’s really obvious because… nothing ever occurs in isolation*”
- He has yet to come up with an example in his life where he flew off the handle only because of what was happening in that moment
  - If that situation had occurred a day ago he would have barely gotten upset
  - It was literally 6 things that had happened, no one thing caused it but each thing made him more susceptible
    - Maybe there was this other thing that he didn’t deal with that upset him and he just buried it and went on
- He likens it to the [Challenger blowing up](https://en.wikipedia.org/wiki/Space_Shuttle_Challenger_disaster),
  - When you peel back the layers of the onion and go through the entire chain analysis for the Challenger (and all the previous space shuttles), you realize how inevitable this was… it was almost a foregone conclusion
  - But watching it as a spectator you would think “*Oh my gosh, how could that happen?*”
- Shireen explains that everything has multiple causes, and that is very hard to accept sometimes, and it’s also very hard to experience

- Especially in our dominant culture that wants us to believe that there are simple answers and there’s one person to blame or one root cause
- And it’s more complex than that
- “*There’s always multiple determinants of anything*” says Shireen
- We could dissect any behavior, any problem, and see the thousands or millions of causes that led up to that behavior

## Why the regulation of emotions can be so challenging [1:50:30]

- Peter has one of the pages he copied from his skills book that has so many notes in it
  - It’s about what makes it hard to regulate your emotions (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/08/f6-rizvi.png)

**Figure 6.  A page from Peter’s DBT workbook.**

- There are probably 30 or 40 pages that has stickies in, and this would be one of the 10 most important
- It’s just this great reminder

**What makes it hard to regulate your emotions?**

-Biology

- Let’s just acknowledge, there are biological differences between us., our brains are different
- Anybody who has more than 1 kid will recognize they are different, even if they’re raised identically

-Lack of skill: One thing discussed earlier is the lack of skill

- Either skills were not taught, good skills were pushed away, or bad skills were reinforced

- One interesting example going back to childhood is moodiness‒ ***your mood in the moment will alter your ability to regulate emotion***
- Peter can relate to **emotional overload**
  - The more pressure you have on you, whether self-imposed or otherwise, the more difficult it is.
- One emotional myth, mistaken beliefs about these things says “When I can’t regulate, it is almost always the case that at least 1 and typically 3 of these are happening.”
  - 3 of these really peg to childhood‒  the biology, the reinforcement of emotional behavior plus or minus skill, and the emotional myths
- Shireen adds, “*A lot of them are longstanding patterns and some of them are current and also contextual*”
- For example, there might be a person in your life,that when you display anger, gives in to everything you’re asking
  - This could be totally outside of your awareness
  - But that means that you’re more likely to have that anger response with that person, in that context, in the future
- A while before her husband, she had an ex-boyfriend who, when they would argue, if she started to cry, he would immediately back down
  - And this was outside of her that this was happening
  - She realized over time, she found herself crying a lot more than she ever had before
    - She’s not saying crying is good or bad
    - But she just noticed that was what was happening because in that context with that person, that behavior was being reinforced
  - She feels like this could happen so subtly and it’s so contextual
  - And this is why we’re sometimes different with different people
    - This is often pathologized‒ if you’re different with different people, there’s something wrong with you
    - That you have no core sense of identity or something
    - Instead, Shireen would say, it’s actually pretty normal
    - We’re different people because the context often calls for that, and it’s adaptive to be that way

## The importance of mindfulness skills in DBT [1:53:30]

- Peter notes that the first step of DBT is recognizing the thought
- Shireen notes that mindfulness is a skill that is central to everything

*Does she suggest people use a form of meditation that practices mindfulness, such as focusing on the breath or an object and bringing their attention back to that each time it wanders?*

- There is a debate within DBT
- Marsha used to say we needed to get all therapists to practice seated meditation for at least 20 minutes every day
- There’s a form of cognitive behavioral therapy called [mindfulness based stress reduction (MBSR)](https://en.wikipedia.org/wiki/Mindfulness-based_stress_reduction) used to help people with depression
  - This teaches people and helps them work up to a seated meditation
  - It also requires therapists who do MSBR to practice it that way
- Marsha was thinking, “*Do I need to require this?*”
- At the time, Shireen remembers thinking it was not practical for everybody
  - Think about a working mom or a single mom with 3 kids
  - It’s impractical to ask them to find time to do a 20 minute seated meditation
  - There have been many times in her life when it’s been impractical
- Marsha never ended up requiring this meditation but she would say therapists who practice DBT have to have a mindfulness practice
  - That could be anything under the umbrella of mindfulness
  - Yoga, mindful walking, mindful participation in various things

> “*When it comes to clients who are in DBT, we want them to strengthen their mindfulness muscle, absolutely*”‒ Shireen Rizvi

- If she has a client who is interested in learning to do a seated meditation, that’s amazing and she would support it
- For a lot of the clients she works with, that would be too big of a jump
  - For a lot of people who are in DBT who might be at that more severe end of the continuum, just sitting with themself and their thoughts and their minds without doing anything to change it for a minute could be excruciating

***She’s trying to build that tolerance, of course, but the mindfulness skills in DBT are much more concrete and practical and designed to be used in any moment, rather than designed to facilitate a more formal practice***

## Opposite action: an emotion regulation skill [1:57:00]

- Peter comments that there is so much in DBT, they can’t cover it in any comprehensive manner
- He wants to highlight a couple things he has found very helpful and have Shireen expand on them

**Explain what opposite action is and when we use it**

- Shireen did her dissertation on opposite action
- Opposite action is a skill that falls into the emotion regulation module

***Opposite action is a skill for changing an emotion that you don’t want to have***

- It’s simple in concept and hard to execute because simply put, it’s engaging in the opposite of what your urges are telling you to do
  - And that’s why it’s called opposite actions
- We know that from emotion science, and from our own experiences, that experience of emotions are associated with an urge to act in particular ways
  - So when we feel sad, we have an urge to retreat or withdraw
  - When we experience anger, we have an urge to lash out
  - When we experience shame, it’s to hide
  - When we experience fear, it’s to fight or flight

***What opposite action says is that when your emotion does not fit the facts of the situation, or is too intense for the situation, and you want to change it, a way to change it is to act opposite to your urges***

- For example, when I’m sad, instead of withdrawing, I activate
  - When I’m fearful, instead of running away, I approach the exposure we were talking about earlier
  - When I’m experiencing shame, rather than hide, I actually confront or disclose a
- So it is really hard to do, but you get better at it over time with practice
  - This has been Peter’s experience
- Peter has found 2 areas where opposite action is very helpful
  - 1 – Anger is a profound emotion that Peter is very familiar with
  - 2 – The other one, he hasn’t figured out what the underlying emotion is yet, , but it produces a phenotype of needing to isolate just a desire to completely isolate
- One interesting thing that if you would have told him 5 years ago, he would’ve never believed but it is remarkable‒ the ability of cold water to calm the  nervous system in moments of high fight of flight mode
  - That’s part of the opposite action effect
  - If he feels angry, he’s going to go and do something that’s really calming, which is take an ice shower or jump in the cold pool
    - Winters in Austin are nice, because they still have pools open and they’re really cold in the winter, but that’s harder
  - Those are harder to do as you probably can imagine when you’re at 9 out of 10 activation, and your desire is to scream or break something
    - It’s hard to then walk yourself back from that
- He has found opposite action to be remarkably helpful (and now his norm) for responding to feeling of want to isolate
  - He forces himself to go and play with his kids
  - He remembers the first time this happened about a year and a half ago
  - It was a Sunday morning, and for reasons he didn’t understand, he wanted to sit in the office and do work or exercise and just do his own thing
  - His wife said, “*Hey, we’re going to go to Barton Creek and play on the rock and throw rocks in the water and stuff*”
  - Normally he would have said, “*Absolutely not. I’m too busy. I’m overwhelmed, I need to just do this thing.*” and she would have accepted it
  - Instead he joined them, even though he didn’t want to go at all
  - They had this amazing time doing nothing, playing games like who could get across the creek without getting the most water in their shoes
  - On the way home they stopped and got burgers and fries
    - This was the last thing he wanted to do
  - They did everything he would never want to do but he felt great when he got home

***This was a key moment for him.  You do that enough times and you realize this really works****.*

- Peter thinks opposite action is really a remarkable tool
  - When he doesn’t want to engage with anybody, engaging with his family is the drug that gets him out of that feeling
  - A simpler example is smiling when you’re furious
    - “*And meaning it*” adds Shireen
- Marsha talks about opposite action as something that happens all the way
- We all know what a fake smile is and a fake smile while in your mind you’re thinking, “*Oh, what an asshole. I hate this person.*”‒ that’s not opposite action because that’s what we might say is half-assed
  - Opposite action is not going to work because your mind is still going to be angry

***What we’re talking about with opposite action is if we act opposite to our urges, we’re sending the feedback back to our brain to feel a different way***

- Shireen thinks a lot of people relate to the idea of doing opposite action, like what Peter said
  - But also when you’re feeling socially anxious, like you want to avoid going to the party or speaking up in class or at work because you’re anxious and maybe you have a long history of avoiding saying anything or doing anything because you’re anxious
  - So opposite action would be to say, throw yourself into that, go to that party even though you don’t want to, and then throw yourself into the party, which is what you described with your family
    - You could have gone along physically, but all the while been thinking, “*I need to be back home*”
    - Or he could be goofing around on his phone
    - Instead, he threw himself into where he was and that’s the critical piece

> “*It’s not just the moving your body there, it’s throwing your mind into it as well*”‒ Shireen Rizvi

## Advice for those wanting to explore DBT [2:03:15]

**What else do you think could be interesting for a person who’s never heard of DBT to understand or contemplate as a new skill they should learn?**

- In the news we’ve heard a lot about the mental health crisis we’re in right now
  - There are simply not enough mental health providers to treat all the need that’s out there
  - What that has meant on a practical level is that there are huge, long waiting lists for treatment everywhere
  - She doesn’t want to deter people from seeking out help when they need it
- Shireen doesn’t think everybody need full-on DBT
  - We don’t have the science yet
  - This is an area of research that she’s interested in‒ trying to figure out who needs the full package of DBT versus who can benefit from a lighter touch (or lower dose)
    - Because we want to be efficient in our mental health delivery
    - And we also want to reduce suffering of people on a mass level

**Is DBT something that can be done somewhat effectively on your own, meaning with manuals, with books, with videos online, versus the way you would work with people who are much sicker, where you have to be working with them directly in person?**

- This is what Shireen doesn’t know yet
- We have some assumptions, but Shireen doesn’t know if they are valid
- For example, if somebody is experiencing suicidal thought, they absolutely need some form of treatment
- COVID threw us into this new world that we weren’t expecting
  - For example, they had to start treating people who were suicidal virtually
  - From this, they were able to realize that this idea that we had to see people in person was a myth
    - There were reasons why we believed it
  - There doesn’t seem to be any added risk of seeing somebody through telehealth when they’re suicidal
- Shireen thinks a lot of our assumptions about what people need are assumptions that we don’t actually know a lot about

**Stepped-care model of DBT**

- She applied for some funding to do a stepped-care model of DBT
  - To start everybody with what we might call a low-dose intervention
    - For example, provide a videos of skills and see what percentage of people benefit from that alone, versus, what percentage of people don’t benefit enough and need something else
    - And then what can we add a slight step-up, maybe some phone coaching where you get a call with somebody once a week about how to apply the skills in your daily life, and then test it again
    - And then if you are not responding to that, maybe then you get offered the full package of DBT or something else
  - Through that study she hopes to identify what the sequences of care ar that are going to be most effective, that will help most people, and that can be disseminable
  - We don’t have a lot of knowledge about this

> “*I honestly believe that anybody could benefit from learning DBT skills*”‒ Shireen Rizvi

- So yes, she thinks it’s valuable for listeners to expose themself to some of these skills
  - Use videos or books to learn more about them (see the selected links section)
- See if the skills resonate with you and if you can apply them on your own
- And if you want to know more, if you’re struggling to apply it in your life, then that might be where you could reach out for help and find a DBT therapist

## Finding a well-trained DBT therapist [2:08:15]

- Peter notes that Shireen is an exception since she trained directly with Marsha
  - There are a lot of people who trained wit her, but that’s not scalable

*How is the field of DBT self-regulated or self-policed?*

- It’s been a long standing process to try to figure this out
- Mental health is really confusing in this way because there are so many ways in which a person can become a therapist
  - Hang a shingle outside the window and practice therapy
  - And that person can call themselves a DBT therapist, or a CBT therapist, or any therapist, and may not have the credentials or training to back that up
- Shireen always tells people to proceed with caution and to do your research when you’re looking into finding a mental health provide
- Marsha was against this idea of certifying DBT therapists for a long time
  - She didn’t want to have a regulatory role
  - She wanted people to learn DBT and to just get DBT out there
  - But then she was hearing more and more stories of people saying that they received DBT and it didn’t work
    - And then you ask them what happened in their treatment
    - And you hear details about their treatment that were clearly not DBT
    - And the worst case scenario is, somebody dies by suicide or has a terrible outcome, thinking that they’re getting DBT when they’re not
- A few years ago, Marsha started the [Linehan Board of Certification, LBC,](https://dbt-lbc.org/index.php) which has started a certification process for DBT therapists

***All people that are certified by LBC to be DBT clinicians are likely good DBT clinicians, because they’ve met all of these standards***

- But not all people who are not certified are bad DBT therapists, right?
  - Because there’s a number of DBT therapists who have just elected not to go through the process of certification
- If you’re first starting to think seriously about DBT you might start by looking up certified DBT therapists
  - But recognize that’s not the only criteria to use

**What other questions can a person ask to determine if the pedigree of the therapist is in line with the principle of DBT?**

*Another Marsha anecdote‒*

- Relatively early on, after the initial trials of DBT were put out showing that DBT was effective, insurance companies started getting interested and wanted to pay for DBT, but didn’t want to pay for non-DBT
  - They would call Marsha up and they would say, “*This person says they’re doing DBT, how do we know if they’re really doing DBT so that we can reimburse for the service?*”
  - She thought about it, and ultimately said, “***Ask the DBT provider if they’re on a consultation team***”
- This is oversimplified by far, but Shireen explains that one of the components of the full package of DBT in addition to individual therapy and skills training is that the DBT therapist, him or herself attends a weekly consultation team meeting with other DBT therapists
  - The consultation team meeting is a place where DBT therapists talk about their experiences delivering DBT with an aim towards improving their own adherence to the model and their motivation
  - It’s often called therapy for the therapist

**Reasonable questions to ask a potential therapist‒**

- 1 – To what extent does the therapist adhere to DBT principles?
- 2 – Is the therapist part of a DBT consultation team?

§

## Selected Links / Related Material

**Marsha Linehan’s memoir**: [Building a Life Worth Living: A Memoir](https://www.amazon.com/Building-Life-Worth-Living-Memoir/dp/0812994612/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1655904032&sr=8-2) by Marsha M. Linehan (2020) | [17:45]

**Article on Marsha Linehan’s struggle with mental illness**: [Expert on Mental Illness Reveals Her Own Fight](https://www.nytimes.com/2011/06/23/health/23lives.html) | Benedict Carey, *The New York Times* (June 23, 2011) | [18:00]

**Marsha Linehan’s DBT skills workbook**:

- [DBT Skills Training Manual, Second Edition](https://www.amazon.com/DBT%C2%AE-Skills-Training-Manual-Second/dp/1462533612/ref=sr_1_1_sspa?crid=9UBPYJ584305&keywords=Marsha+Linehan&qid=1655985782&sprefix=marsha+linehan+%2Caps%2C317&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUExWDNWQUpDWTVYN09UJmVuY3J5cHRlZElkPUEwOTI1MjY5MTBSUDZLVTBBUkhRUCZlbmNyeXB0ZWRBZElkPUEwOTg5NDcxM0ZUVEoxOVRDTFlHJndpZGdldE5hbWU9c3BfYXRmJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ==) by Marsha M. Linehan (2014) | [53:30]
- [DBT® Skills Training Handouts and Worksheets, Second Edition](https://www.amazon.com/Skills-Training-Handouts-Worksheets-Second/dp/1572307811/ref=pd_bxgy_img_sccl_1/134-1589977-4742414?pd_rd_w=IRmST&content-id=amzn1.sym.7757a8b5-874e-4a67-9d85-54ed32f01737&pf_rd_p=7757a8b5-874e-4a67-9d85-54ed32f01737&pf_rd_r=DSTS93GQQME7MAD7XBTT&pd_rd_wg=Qdx8G&pd_rd_r=633a63dd-0b2e-4c8e-a06e-f9df079d028b&pd_rd_i=1572307811&psc=1) by Marsha M. Linehan (2014) | [53:30]

**Episodes of** ***The Drive*** **that discuss mindfulness**:

- [#34 – Sam Harris, Ph.D.: The transformative power of mindfulness](https://peterattiamd.com/samharris/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 20, 2018) | [1:00:00]
- [#72 – Dan Harris: 10% happier – meditation, kindness, and compassion](https://peterattiamd.com/danharris/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 23, 2019) | [1:00:00]
- [#139 – Kristin Neff, Ph.D.: The Power of Self-Compassion](https://peterattiamd.com/kristin-neff-the-power-of-self-compassion/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 30, 2020) | [1:00:00]

**Adolescent version of DBT**: [DBT Skills Manual for Adolescents 1st Edition](https://www.amazon.com/DBT-C2-AE-Skills-Manual-Adolescents-Rathus-dp-1462533639/dp/1462533639/ref=mt_other?_encoding=UTF8&me=&qid=1655994042) by JH Rathus, AL Miller, and MM Linehan (2014) | [1:13:00]

**Linehan board of certification for DBT started by Marsha**: [DBT-Linehan board of certification](https://dbt-lbc.org/index.php) (2022) | [2:10:00]

**Shireen’s books**:

- [Chain Analysis in Dialectical Behavior Therapy (Guilford DBT Practice Series)](https://www.amazon.com/Analysis-Dialectical-Behavior-Guilford-Practice-dp-1462538916/dp/1462538916/ref=mt_other?_encoding=UTF8&me=&qid=1655899576) by Shireen L. Rizvi (2019) |
- [Dialectical Behavior Therapy in Clinical Practice, Second Edition: Applications across Disorders and Settings (2nd edition)](https://www.amazon.com/Dialectical-Behavior-Therapy-Clinical-Practice/dp/1462544622/ref=sr_1_1?crid=1O8M83XX425UQ&keywords=DBT+in+Clinical+Practice&qid=1655899620&sprefix=dbt+in+clinical+practice%2Caps%2C112&sr=8-1) by LA Dimeff, SL Rizvi, K Koerner, and MM Lineham (2020) |

**Shireen’s faculty webpage at Rutgers University**: [Dr. Shireen Rizvi, ABPP](https://gsapp.rutgers.edu/faculty/shireen-rizvi) | Rutgers Graduate School of Applied and Professional Psychology (2022)

**DBT resources from Rutgers University**:

- [Resources](https://gsapp.rutgers.edu/centers-clinical-services/DBT/resources) | Rutgers Graduate School of Applied and Professional Psychology: Dialectical Behavior Therapy Program at Rutgers University (2022)
- [DBT-RU: DBT Skills in 5 Minutes or Less](https://youtube.com/playlist?list=PLVlLbxLe1Eo6-YjpTfW0UbSOig_4FDac3) | YouTube (2022)

§

## People Mentioned

- [Marsha Linehan](https://depts.washington.edu/uwbrtc/our-team/marsha-linehan/) (Creator of DBT, Professor Emeritus at the University of Washington) [1:00, 8:15, 15:00, 21:45, 35:30, 52:30, 1:07:30, 1:54:15, 2:01:45, 2:08:30, 2:11:00]
- [Aaron Beck](https://en.wikipedia.org/wiki/Aaron_Beck) (father of cognitive therapy, Professor of Psychiatry at the University of Pennsylvania) [7:45, 12:30]
- [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) (martial artist) [38:30]
- [Karl Marx](https://en.wikipedia.org/wiki/Karl_Marx) (Contributed to dialectics, German philosopher and author) [45:00]
- [Andrew (Andy) White](https://andrewwhitephd.com/about/) (Clinical Psychologist with expertise in CBT, DBT, and mindfulness) [1:07:20]
- [Jill Rathus](https://behavioraltech.org/about-us/trainers-consultants/jill-rathus-ph-d-jill-rathus-ph-d/#:~:text=Jill%20Rathus%2C%20PhD%2C%20(PhD,DBT%20Clinical%20Research%20Training%20Program.) (Professor of Psychology and Director of the DBT Clinical Research Training Program at Long Island University) [1:13:00]
- [Alec Miller](https://www.cbc-psychology.com/cbc-staff/alec-l-miller-psy-d) (Clinical psychologist, co-founder and co-director of Cognitive & Behavioral Consultants) [1:13:00]

§

![](https://peterattiamd.com/wp-content/uploads/2022/08/bio-pic-rizvi.webp)

##### Shireen Rizvi, Ph.D., ABPP

Shireen Rizvi, Ph.D., ABPP, received her doctorate in clinical psychology from the University of Washington where she studied borderline personality disorder and Dialectical Behavior Therapy for more than five years under the mentorship of Dr. Marsha Linehan. She completed her predoctoral clinical internship at the Boston Consortium in Clinical Psychology and a NIMH postdoctoral fellowship at the National Center for PTSD at the Boston VA Healthcare System. Following this fellowship, she was Assistant Professor of Psychology at the New School for Social Research in NewYork City from 2006-2009 before coming to the Graduate School of Applied and Professional Psychology (GSAPP) at Rutgers University in 2009.

Shireen is board certified in Behavioral and Cognitive Psychology and in Dialectical Behavior Therapy.  She is the director of the Dialectical Behavior Therapy Program at Rutgers University.  Shireen is a Professor of Clinical Psychology at the GSAPP at Rutgers University, where she also holds affiliate appointments in the psychology department, School of Public Health, and the Department of Psychiatry. Dr. Rizvi serves as a primary mentor for students in both the Psy.D. and Ph.D. programs.  In 2017, She was presented with the “Spotlight on a Mentor” award from the Association for Behavioral and Cognitive Therapies (ABCT).

Shireen’s research interests include improving outcomes, training, and dissemination of Dialectical Behavior Therapy (DBT) for the treatment of complex and severe populations. Dr. Rizvi has received funding from the National Institute of Mental Health (NIMH), the National Institute on Drug Abuse (NIDA), Rutgers University, and the American Foundation for Suicide Prevention (AFSP) for her research. Her work has resulted in over 70 peer-reviewed articles and book chapters, as well as a sole-authored book entitled [*Chain Analysis in Dialectical Behavior Therapy*](https://www.amazon.com/Analysis-Dialectical-Behavior-Guilford-Practice-dp-1462538916/dp/1462538916/ref=mt_other?_encoding=UTF8&me=&qid=1655899576) and a co-edited volume, [*DBT in Clinical Practice* (2nd edition)](https://www.amazon.com/Dialectical-Behavior-Therapy-Clinical-Practice/dp/1462544622/ref=sr_1_1?crid=1O8M83XX425UQ&keywords=DBT+in+Clinical+Practice&qid=1655899620&sprefix=dbt+in+clinical+practice%2Caps%2C112&sr=8-1). [[Shireen Rizvi, ABPP](https://gsapp.rutgers.edu/faculty/shireen-rizvi) and [DBT-RU Staff](https://gsapp.rutgers.edu/centers-clinical-services/DBT/dbt-ru-staff)]

Twitter: [@DrShireenRizvi](https://twitter.com/drshireenrizvi)