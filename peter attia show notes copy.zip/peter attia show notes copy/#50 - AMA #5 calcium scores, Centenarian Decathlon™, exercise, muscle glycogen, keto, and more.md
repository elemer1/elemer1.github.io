# #50 – AMA #5: calcium scores, Centenarian Decathlon™, exercise, muscle glycogen, keto, and more

**Source:** [https://peterattiamd.com/ama05/](https://peterattiamd.com/ama05/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from readers and podcast listeners. Bob Kaplan, Peter’s head of research, asks the questions. If you’re listening on a podcast player, you’ll be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Coronary calcium score: what it means and how to interpret your results [1:15];
- How to train for the “Centenarian Decathlon” [18:00];
- Explaining the blood glucose response to various types of exercise [35:30];
- The Tabata protocol [43:15];
- Exercising on a ketogenic (or low-carb) diet: performance, muscle glycogen, adaptation, and more [49:30];
- The work of Dr. Gabor Maté and its impact on Peter [54:15];
- What’s the best book you’ve read in the past year? [55:45];
- What is “pattycakes?” [59:00];
- What is the latest and greatest of egg boxing [59:30]; and
- More.

§

The Peter Attia Drive

Calcium scores, Centenarian Decathlon™, exercise, muscle glycogen, keto, and more

§

## Show Notes

## Coronary calcium score: what it means and how to interpret your results [1:15]

- A coronary calcium score (CAC) is a CT scan that’s done dry (without any contrast)
- If you see something really, really bright white, it’s calcium

Scoring system

- You can actually get some anatomic detail, but not to the degree of understanding how much narrowing there is of the arterial lumen
- You *can* see which arteries: The left main artery, the circumflex artery, the left anterior descending, the right artery, the posterior descending artery, etc.
- The amount of calcification is then scored and ranked against a percentile
- It is certainly helpful especially in terms of being able to update your probability based on new information

The problem:

- People tend to think if they’re score is zero then they are at zero risk
- Unfortunately, that’s just categorically untrue
- A zero score actually means *actuarially (at the population level) a lower risk of a coronary event*
- What is a “coronary event”?  ⇒ A major adverse coronary event (MACE) = heart attack, stroke, or cardiac death
- Furthermore, [nearly 50%](https://www.ncbi.nlm.nih.gov/pubmed/23578355) of fatal MIs occur in non-calcified areas of coronary arteries
- Those data are also a bit misleading because many of those patients still had calcifications elsewhere

**Analogy: Bad neighborhood vs. a break-in**

> “The way I think of calcification is, it tells you how many times you’ve been broken into and what kind of repair you’ve done. . . A biomarker tells you how bad a neighborhood you live in.”

- *Example of a biomarker*: You do a blood test and their [Lp(a)](https://peterattiamd.com/lpa/) is high, or their LDL-p is high, and they have lots of inflammation, that says they live in a bad neighborhood. . .there’s a chance there’s going to be a “break-in.”
- A calcium score other than zero, tells you you’ve *already had an advanced lesion which* had *to be repaired* (i.e. you’ve already had a “break-in”)

![](https://peterattiamd.com/wp-content/uploads/2019/04/chd22.png)

**Figure 1. Herbert C. Stary’s stages of atherosclerosis.** Image credit: [Stary et al., 1995](https://www.ahajournals.org/doi/full/10.1161/01.CIR.92.5.1355)

For more on when and how heart disease begins [check out this article from Peter](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/)

**In summary**: *When you have calcification in a coronary artery, you’ve had real damage that has been  repaired. It is a marker of risk that suggests you need to be more aggressive your care. But when you have a score of zero, it doesn’t change the fact that you might live in a bad neighborhood, or the fact that you can have lots of arterial damage that just hasn’t shown up at the stage of calcification. You can have plenty of soft plaque that’s still there without calcification. That’s still an enormous marker of risk.*

**What Peter does with patients:**

Every case is different:

- Sometimes a CAC score is zero and he’ll stop there
- Other times, even if it is zero, Peter will order a [CT angiogram](https://www.mayoclinic.org/tests-procedures/ct-coronary-angiogram/about/pac-20385117) which pulls much more anatomic detail including the presence of soft plaque (but even there, you still can’t really see plaque that is vulnerable)

If a patient has coronary calcium score that is zero, AND their CT angiogram looks impeccable…

- That’s a much better sign than all is okay
- But… *Would you still treat a patient in that situation*?
  - That’s a hard question, but it also depends on your time frame
  - So, the younger a patient is with that finding, the *less confident* you are that they are one of the lucky people that seems largely immune from coronary artery disease
  - Peter finds **these tests more enlightening in older people vs. younger people**

*⇒ Example patient:*

- Woman in her 50s
- Very wonky lipid numbers
- Very complicated ApoE status
- Metabolically extremely fit
- “she’s just incredibly healthy but her lipid numbers couldn’t suck more”
- Peter is trying to decide: *How aggressive do we want to be in lipid management?*
  - If her CT angiogram comes back perfect, it would inform Peter of the following: “*There’s something going on in this woman where other factors that are equally important to the lipoprotein, the endothelial function, the immune response are working enough in her favor that she might not need to be managed very aggressively, despite the fact that she’s there.*”
  - In other words, “*she might live in a really bad neighborhood but she just happens to have a pit bull that’s in her front yard that’s kind of keeping the bad guys away.*”

**How to interpret the CAC score:**

*Is there a CAC score that tells you that you have atherosclerosis*?

- No, it’s not that black and white
- Atherosclerosis can be present even without a single shred of calcium.
- It is really a function of your age and gender

Percentile:

- The number is not nearly as important to me as the percentile
- It’s where do you stack up against your peers

*⇒ Example*: A calcium score of 6 for a 35 year old puts you in the 75-90th percentile so even though that is a tiny burden of calcium, that’s a significant problem. And a calcium score of 6 for an 80 year old means you have no calcium, even a calcium score of 6 to 10 for a 60 year old would be considered quite low. It has to be taken in the context of age.

*What about volume and density*?

- Peter says the [density of calcium](https://onlinelibrary.wiley.com/doi/full/10.1002/clc.22842) while on therapy may be more predictive than the total burden of calcium
- As of today…
  - When a patient has a calcium score of something that’s not zero, you put them on a statin
  - Over time, their calcium score expands (sounds like a negative) ⇒ But *provided they’ve been on a statin* it seems to be showing plaque stabilization
- On the contrary…recently data came out on PCSK9 inhibitors that said the opposite which is that patients on a PCSK9 inhibitor and also on statins saw a reduction in plaque calcification
- “*Truthfully, that just tells me there’s a lot we don’t know yet.*”

*What about using serial calcium scores prognostically?*

- “I find it difficult to use and not necessarily helpful to use serial calcium scores prognostically.”
- However, a recent patient shows this may not be totally correct thinking…
- Had a calcium score of 10 but over the course of 20 years it has gone from 10 to 40 to 170 to 650 to 1,500 to 4,000
- Very interesting case because this is a patient whose lipid levels are not horrible because he’s been medicated for a large part of this period of time
- He does not have an elevated Lp(a), but his family history is really significant for cardiovascular disease
- His father had his first MI in his 40s.
- For all intents and purposes, he looks like someone who would have an elevated Lp(a)
- Yet, he doesn’t which speaks to just the complexity of the disease
- “*There are undoubtedly other genetic factors…that we haven’t yet elucidated*.”

*Your score matters only in context with other factors*

- [MESA](https://www.mesa-nhlbi.org/) (Multi-Ethnic Study of Atherosclerosis) [has a calculator](https://www.mesa-nhlbi.org/MESACHDRisk/MesaRiskScore/RiskScore.aspx) for 10 year risk of CHD
- You can look at your risk and it takes into account age, gender, whether you smoke, blood pressure, etc.

**Four things that are out of whack when you’re getting atherosclerosis:**

- 1) Metabolism
- 2) Lipoproteins
- 3) Inflammation
- 4) Endothelium health
- If any of these are not functioning well, all of those things are going to predispose you
- And there are an infinite number of combinations of the above factors given how multivariate each of those things are

*Is calcification “bad”?*

- The calcium itself is not the problem… **it is that it tells you something bad has happened, if anything, the calcium’s probably doing more benefit than harm. It’s the fact that you have it that’s upsetting**
- Calcium is not a biomarker. It is a *backwards-looking piece of evidence* that you have disease and that damage has already occurred to the artery

**Exercise and CAC:**

[**JAMA study**](https://jamanetwork.com/journals/jamacardiology/article-abstract/2722746)

- The study found exercise led to lower all-cause mortality even with a higher CAC score
- But also a small *subset of extreme exercisers may be doing damage to their heart health*
- “I think in part this speaks to the ubiquity of mechanisms by which exercise is beneficial, but at the same time suggests that ‘look, there’s going to be a subset of either individuals and/or circumstances under which exercise can also be damaging to the heart.’”

The work of [James O’Keefe](https://en.wikipedia.org/wiki/James_O%27Keefe_(cardiologist))

- Illuminated the level of *the electrical system within the heart*
- The more often it is stretched and held for long periods of time in said stretch position, the more you are damaging the electrical architecture of it
  - That’s why we see a [significantly high incidence, almost 10X that of the general population](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3538475/) in highly, highly, highly trained athletes for dysrhythmia, atrial fibrillation being a common example
  - The endothelium is much an important part of this that if you’re damaging the endothelium, all other things being equal, you can still increase the risk of damage to the heart

*Should you stop exercising in light of this study?*

- You should NOT stop exercising in light of this study ⇒ “*There’s more nuance to this.*”
- Yeah. I would say, if I was an extreme exerciser and you have that CAC under 100 and the CAC over 100, all things being equal, I’d like to be in the under 100 group.
- But when you looked at the over 100 group and you compared them just about to any other, you would say, “I would love to have that type of associated risk,” even with the scores like that

## How to train for the “Centenarian Decathlon” [18:00]

- The body, in most people, will fail before the other systems (brain, heart, etc.)

⇒ This fact got Peter thinking, *how do we mitigate that?*

- Came up with this idea of **backcasting** (instead of forecasting) what I want to do in the end (the term backcasting being borrowed from [Annie Duke](https://twitter.com/AnnieDuke?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) who wrote [Thinking in Bets](https://www.amazon.com/Thinking-Bets-Making-Smarter-Decisions/dp/0735216355))

First question… “*If I want to live to 100, what do I have to physically be able to do to be satisfied with my life?*”

- Personally for Peter that means…
  - Being able to play with his potential future grandkids and even great grandkids
  - Shoot a [bow and arrow](https://www.instagram.com/p/Bq-Yud2AVuX/)
  - Lifting a 30 lb suitcase into an overhead bin
  - Among other basic [ADL](https://en.wikipedia.org/wiki/Activities_of_daily_living)

⇒ In total Peter listed **18 things he’d like to be able to do at 100,** below are some of them…

- Some of them seem trivial (i.e. get up off the floor with a single point of support (i.e. using just one arm)
- Able to drop into a squat position and pick up a child that weighs 30 pounds
- I want to be able to lift something that weighs 30 pounds over my head (i.e. a suitcase into an overhead bin)
- Get out of a pool without a ladder

Next question… *What are physical tasks that would approximate those things?*

⇒ Example: Picking up the 30-pound kid who comes running at you could be approximated by a 30 lb [goblet squat](https://www.youtube.com/watch?v=MeIiIdhvXT4)

![](https://peterattiamd.com/wp-content/uploads/2019/04/Goblet-Squat.jpg)

**Figure 2. The goblet squat**. Image credit: [xbodyconcepts.com](https://xbodyconcepts.com/how-to-squat-with-perfect-form-a-4-step-guide/)

⇒ Once you have the approximate exercise, begin working backwards from there while keeping in mind the inevitable fact that there will be a natural decline: *I want to be able to do these things at 100 ⇒ so I need able to do these things at 80 ⇒ this level at 60 ⇒ And I need to be able to do it at this level today*

**The framework =** Since everyone is different, with different limitation, it is hard to say what one should be doing today to reach their 100-year olympics, but rather, *it makes more sense to focus on the framework*

⇒ **Four components of exercise**:

1. Stability
2. Strength
3. Aerobic performance
4. Anaerobic output

Each exercise focuses on at least 1 of the 4

- Every one of the 18 things on Peter’s list touch at least one of those (many touch more than one)
- With the goblet squat, for example, it requires both strength and stability
- Also on Peter’s list is *being able to walk up three flights of stairs with 10 lb of groceries in each hand* (aerobic, and on the threshold of aerobic/anaerobic, also got strength)

**Stability**

- Where most **people start to fail first is stability**
- We were born with an innate ability to squat (Start to lose it in school years from all the sitting)

![](https://peterattiamd.com/wp-content/uploads/2019/04/squat-form-1024x991.png)

**Figure 3. “Wanna learn how to squat? Just ask a toddler. They won’t be able to ‘articulate’ their form, per se, but the visual is worth a thousand words. Here is my guy giving me a seminar today.”** Image credit: [@peterattiamd](https://www.instagram.com/p/Bp7Je3YgKYz/)

- The field of dynamic neuromuscular stabilization is built on the principle that there are ~14 movements that are completely innate to us and by the time we’re a 1.5 years or so we are able to do them all perfectly ⇒ basically all downhill from there and accelerated significantly by school
- Once you start sitting, that’s when we lose so much of that stability. We lose the ability to maintain tension through our pelvic floor and throughout the entire movement
- We lose our ability maintain tension throughout our entire “core” (referring to the diaphragm, the obliques, the transversalis fascia and the entire [pelvic floor](https://en.wikipedia.org/wiki/Pelvic_floor))

Peter’s two cents:

- Spend as much time as possible working on dynamic stability and static stability
- Static first, then dynamic
- Incorporate stability into your strength workouts (because at the age of 25 you can do a lot of dumb things and get away with it incorrectly but will start to impact you down the road)

**Speaking of stuff you can get away with when you’re young, here is Peter’s high school squat routine:**

- Once per week in high school, Peter did “breathing squats” (and dreaded them all week long)
- Take your best 10-rep weight
- You loaded it on your back and you do a rep
- At the top, you took *three of the deepest breaths you could take* (each breath taking 10 seconds so that takes 30 seconds)
- Then, do another rep until you get 20 reps
- The set takes about 10 minutes
- In the course of one year of doing that, Peter added over 100 pounds to his squat
- “*The only thing I’ve ever done since that rivals that degree of discomfort is an air bike Tabata.*”

⇒ *On a related note:*

- [Doug McGuff](https://www.drmcguff.com/) who wrote [Body by Science](https://www.amazon.com/gp/product/0071597174?ie=UTF8&tag=baye&linkCode=as2&camp=1789&creative=9325&creativeASIN=0071597174) is one of the proponents of “super slow training”
- He talks about lifting slow and basically accumulating time under tension of ~90 seconds “which is an eternity”

**Putting his checklist to the test**

- Peter would like to take his list of 18 things and put it in front of [on-going centenarian studies](https://www.einstein.yu.edu/centers/aging/longevity-genes-project/) to see how much of the checklist the centenarians can complete
- *⇒ How many could complete the whole checklist?*
- - “None of them.” says Peter
  - “Anybody who’s a centenarian today is a centenarian because of their exceptional genes. They haven’t hacked their way there.”
- In fact, on average, today’s [centenarians tend to smoke more, exercise less, and eat worse](https://healthland.time.com/2011/08/05/even-the-long-lived-smoke-drink-and-dont-exercise/)
- For those of us without exceptional genes, it’s going to require much more deliberate attention

> “So, what we’re really talking about is a completely new model, which is actually forcing your way to become a centenarian rather than just sort of gliding your way into it and therefore, I think it’s going to require much more deliberate attention around what your mind and body are doing at that point and time.”

The oldest humans

- [Jeanne Calment](https://en.wikipedia.org/wiki/Jeanne_Calment) lived 122 years
- [Sarah Knauss](https://en.wikipedia.org/wiki/Sarah_Knauss) lived 119 years

![](https://peterattiamd.com/wp-content/uploads/2019/04/KnaussGeneration.jpg)

**Figure 4. Sarah Knauss with her 95 year-old daughter, 73 year-old grandson, 2 of her great-granddaughters, and her great-great-great grandson.** Image credit: [nealirc.org](https://www.nealirc.org/Gerontology/OldestWoman.html)

## Explaining the blood glucose response to various types of exercise [35:30]

Peter’s 2012 article: [The interplay of exercise and ketosis – Part I](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-i/) (and here is [Part II](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-ii/))

*What does anaerobic mean*?

- At a high enough level of exercise, you are starting to exceed the demand for ATP that can be generated aerobically so you much switch to anaerobic
- When defining aerobic and anaerobic, people too often oversimplify by thinking “aerobic is with oxygen, anaerobic is without oxygen” but that is misleading
- It’s really about the **rate at which you need ATP**
- When you need ATP slow enough that you are able to generate it using oxidative phosphorylation, with either glucose or fat but fully running those molecules through the mitochondria and the electron transport chain. That’s called [aerobic metabolism](https://en.wikipedia.org/wiki/Cellular_respiration#Aerobic_respiration).
- When the demand for ATP is so high that you don’t have sufficient cellular oxygen to do that, you have to start using some of that glucose [anaerobically](https://en.wikipedia.org/wiki/Anaerobic_respiration), and doing something that’s much less efficient on an ATP basis to generate lactate (which itself is a great fuel)
- Side note: Lactate comes with a hydrogen ion and that is what’s causing the painful sensation

**Anaerobic activity raises your blood glucose**

- During that type of activity, the liver releases glucose into your bloodstream
- Peter tested which exercise could raise BG the most (3 way tie):
  - Swimming the 300 I.M.
  - 750-1,000 meter all-out on a rowing machine
  - Sprinting up a hill at a 6% incline
- He hit a peak glucose of 174 mg/dl ⇒ *“you look frankly diabetic at that point”*

*So what is that telling you?*

- Your liver is really overestimating how much glucose you’re going to need and it is shooting that out
- However, to put this in perspective:
- Let’s pretend you started at a glucose of 100 and you ended at a glucose of 200 (seems outrageous, right?) but… that’s only about an additional 5 g of sugar (or a single tablespoon) in your blood
- But at extreme levels of exertion, you’re probably at ~1,500 kilojoules of energy requirement, which is in the neighborhood of 25 calories per minute (that’s more than five grams of glucose in a minute)
- So it’s not that surprising that under such ridiculous physiologic circumstances, your liver’s going to err on the side of releasing as much glucose as possible

*Conversely, what’s happening in* [*zone 2 training*](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/)*?*

- Zone 2= the highest level of **aerobic output** you can generate (i.e. what’s the greatest speed you could run on treadmill, or wattage on a bicycle, while keeping lactate below a certain level)
- So if your lactate threshold is ~2 millimolar… your aerobic peak is the speed you can go without going over 2 mm of lactate
- At that zone 2 level, your blood glucose just generally starts to very slowly decline because you’re not really relying on it that much since you’re using fatty acid as well (you’re going to take the maximum efficient path to generate ATP)

## The tabata protocol [43:15]

- Peter and Bob will do tabata training on the [Schwinn Airdyne bike](https://www.schwinnfitness.com/schwinn-airdynes) (aka Satan’s tricycle)
- The [tabata protocol](https://en.wikipedia.org/wiki/High-intensity_interval_training#Tabata_regimen) was created by a Japanese researcher named [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata)

What is a true tabata protocol?

- 20 sec sprint
- Followed by 10 secs of recovery
- Repeated 8 times
- ~2 minutes or less

The origins of the stress response

- Bob compares the incredible stress response that is invoked during the tabata to the stress response many people get from the fear of public speaking ⇒ dry mouth, saliva is gone, an anticholinergic response
- [Robert Sapolsky](https://en.wikipedia.org/wiki/Robert_Sapolsky) (future podcast guest) has done much work in this area
  - He talks about the fight or flight response (and why zebras don’t get ulcers)
  - Humans have the luxury of **perceiving** stress so we have that same stress response to something like public speaking
  - What happens is we shut down our stomach acids and our GI tract and saliva in an attempt to conserve as much energy as possible
  - Next, the glucose gets released rapidly for energy because this must be a dire situation (i.e. a lion may be trying to chase us down and rip us to shreds)

Doing the tabata workout

- If done correctly, your effort level is well over your [VO2 max](https://en.wikipedia.org/wiki/VO2_max)
- For perspective, when Peter is doing tabata on “Satan’s tricycle” he said it’s [worse than doing a tabata with medicine ball slams or with deadlifting](https://www.instagram.com/p/BvuMjEKAC5d/) (to his surprise)
- Peter is trying to hold eight watts per kilogram of body weight during that 20 seconds (a very fit individual is holding over 10 watts per kilo) which is *far above what anyone could ever hold a VO2* max
- Bradley Wiggins ([who broke the world record in 2015 for holding 440 watts for 1 hour](https://www.wired.com/story/cycling-hour-record-almost-impossible/)) would probably tabata at 14 watts per kilo, estimates Peter

**Book rec from Peter**: [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866)

- By [Alex Hutchinson](https://twitter.com/sweatscience?lang=en)
- He says we have a central governor that makes it very difficult for us to go all-out for more than 10 seconds
- So even for a 20 second all-out sprint, we are hardwired to try to pace ourselves

Peter’s pet peeve about “tabata classes”

- Unless that class is 4 minutes long, you’re not actually doing a tabata
- Many of these classes claim to do multiple tabatas which makes no sense because after a single tabata “all you want to do is die”
- “You couldn’t do eight tabatas in a day if you’re doing them correctly.”

## Exercising on a ketogenic (or low-carb) diet: performance, muscle glycogen, adaptation, and more [49:30]

Glycogen when on a keto diet

- If you’re on a ketogenic diet, you have less glycogen than if you’re not
- Through muscle biopsies, [Volek and Phinney](https://blog.virtahealth.com/stephen-phinney-jeff-volek-science-ketosis-adaptation/) showed that ketogenic athletes have about 60% less muscle glycogen than non-ketogenic athletes
- Note: Phinney and Volek [write](https://blog.virtahealth.com/keto-adapted/) (2018): “But more recently, we [Phinney, Volek, and colleagues] [studied highly trained runners who had followed a ketogenic diet for 6 months or longer](https://www.ncbi.nlm.nih.gov/pubmed/26892521). Despite impressive weekly training mileage, **their glycogen levels had come all the way back up to those of a matched group of athletes following a high carb diet.** This implies that the body’s ability to produce and defend muscle glycogen via gluconeogenesis can become finely tuned, but that this takes much longer than 4-6 weeks to occur.”
- In terms of liver glycogen
  - Not physiologically possible to have zero liver glycogen
  - So even in starvation, you’re just turning all that glycerol into glycogen in the liver

The book: Endure (also mentioned above)

- Had great detail on ketogenic versus non-ketogenic athletes
- The case is pretty clear that you are going to perform better with carbohydrate in your system at **peak performance**, *especially anaerobically*
- It’s relative though…
- The less intense the activity, so the longer the distance (like an ultra-distance event) certainly a ketogenic diet can perform well
- But if you’re talking about real anaerobic (which by definition means glycogen-dependent activity), you’re going to perform better with more full glycogen stores

*Peter’s blog post*: [Ketones and Carbohydrates: Can they co-exist?](https://peterattiamd.com/ketones-carbohydrates-can-co-exist/)

- On a ketogenic diet, if energy demand is high enough and glucose turnover is fast enough, you can tolerate a fair amount of carbohydrates
- Peter’s personal record was eating ~650-850 grams of glucose in a day and staying in ketosis
- *How is this possible?* ⇒ His energy demand was so high that he was able to maintain production of beta-hydroxybutyrate and his muscles and body were “consuming” glucose at a high enough rate that the processes related to Bhb and glucose were not interfering with each other and shutting each other off
- \*But, if you’re an anaerobic athlete, “*I think you probably have to accept that a ketogenic state is not optimal for performance.*”

[**Phinney and Volek study**](https://www.sciencedirect.com/science/article/pii/S0026049515003340) **looking at metabolic adaptation to a low-carb diet**

- They showed it could take **many months** for the keto-adaptation
- Over time, it seems that the muscle and the heart can actually use fatty acids more, which can then divert more of the ketones to the brain

⇒ Other fascinating findings from their study:

 1) The keto-adapted athletes could handle higher levels of VO2 and still maintain a lower RQ where you’re using more oxygen (i.e. burning fat rather than glycogen)

 2) Also, “remarkably”, the glycogen replenishment in the low-carb athletes was about the same as the high-carb athletes

- How could this be possible?
  - First, glycerol going to the liver to replace the glycogen
  - Secondly, lactate can be turned into glucose through the [Cori cycle](https://en.wikipedia.org/wiki/Cori_cycle) ⇒ the lactate can go to the liver and then the liver spits out more glucose
  - So the speculation is that **lactate efficiency can be enhanced with a low-carb/keto diet**

## The work of [Dr. Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) and its impact on Peter [54:15]

- Peter would love to have him on the podcast
- Gabor is a psychiatrist in Vancouver, mostly dealing with addiction and taking care of patients with all sorts of substance abuses

**Gabor’s book about addiction**: [In the Realm of Hungry Ghosts](https://www.amazon.com/Realm-Hungry-Ghosts-Encounters-Addiction/dp/155643880X)

- Peter found it to be incredibly illuminating and informative
- Book talks both about the trauma that typically predisposes to addiction, but also the different natures of addiction

> “It really made me realize, man, if you’re a work addict, you don’t get to stand on your high horse and look down at the drug addict and think you’re any better than they are. You’re basically in the same boat. It’s just you have a totally different dopamine trigger.”

- Gabor has been on [Tim Ferriss’s podcast](https://tim.blog/2018/02/20/gabor-mate/)
- “*I would love to have him on [The Drive] at some point.*”

## What’s the best book you’ve read in the past year? [55:45]

Really tough question for Peter ⇒ “*It’s not so much about the book as it is where you are in your life and how that book is speaking to you.*”

**Non-fiction book recommendations**:

\*Note: Peter never reads fiction (other than [nutritional epidemiology](https://peterattiamd.com/ns002/))

[The Road to Character](https://www.amazon.com/Character-Thorndike-Press-Large-Print/dp/1594139377)

- By [David Brooks](https://en.wikipedia.org/wiki/David_Brooks_(commentator))
- “*Given where I was in my life when I read it, it was by far the most important thing I’ve probably read.*”

[I Don’t Want to Talk About It: Overcoming the Secret Legacy of Male Depression](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)

- By [Terrence Real](https://www.terryreal.com/about/)
- Read about a year ago (2018) and [Peter found it very powerful](https://www.instagram.com/p/BjxIGxtBrmV/)

## Can you share the recipe to the fabled Attia Curry? [56:30]

![](https://peterattiamd.com/wp-content/uploads/2019/04/bow-and-arrow-1024x759.png)

**Figure 5. Veggies ready to be stir-fried.** Image credit: [@peterattiamd](https://www.instagram.com/p/BlgsT4rB0Gr/)

- Labor-intensive to make : simple to eat
- Only 2 people who can eat as much in one sitting as Peter? ⇒ Apolo Ohno and Bob Kaplan

Ingredients:

- Super extra firm tofu
- Carrots
- Broccoli
- Squash
- “Just a bunch of vegetables”
- Small potatoes
- Rice
- High-fat plain greek yogurt
- Curry spice

Directions:

- Cook rice in a pot
- Cook potatoes in another pot
- Cook tofu in a pan with sesame oil and really spicy curry
- In a wok, start to cook veggies in the order of hardest to softest (i.e. carrots first and squash last)
- Once everything is ready, combine all ingredients into the wok
- **The final key piece**: mix together high-fat greek yogurt with curry to make a paste and add the paste to the whole thing and stir it up to coat the entire dish

> “The yogurt just grabs the flavor and covers it all.”

## What is “pattycakes?” [59:00]

**patty-cakes** (*noun*)

pat·​ty-cakes | \ ˈpa-tē-ˌkāks

*[Peter’s] definition of patty-cakes*: the act of goofing off (usually with a friend)

*Synonym*: grab-ass

*In a sentence*: I like to play pattycakes. You could argue that AMA is basically pattycakes.

## What is the latest and greatest of egg boxing [59:30]

- Egg boxing obviously needs no explanation but for a refresher [CLICK HERE](https://peterattiamd.com/egg-boxing/)
- Egg boxing champions now have champion belts
- 3 types of belts:
  - WBC
  - WBA
  - IBF
- “*Obviously, one day, you’d like to see those unified.*”

§

## Selected Links / Related Material

**Nearly 50% of fatal MIs occur in non-calcified areas of coronary arteries, those data are also a bit misleading because many of those patients still had calcifications elsewhere**: [Coronary calcification identifies the vulnerable patient rather than the vulnerable Plaque](https://www.ncbi.nlm.nih.gov/pubmed/23578355) (Mauriello et al., 2013) [3:15]

**Herbert C. Stary’s seven levels of atherosclerosis:** [A Definition of Advanced Types of Atherosclerotic Lesions and a Histological Classification of Atherosclerosis](https://www.ahajournals.org/doi/full/10.1161/01.CIR.92.5.1355) (Stary et al., 1995) [4:00]

**CAC scoring system that accounts for volume and density**: [Agatston Score](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan#Agatston_score) | (wikipedia.org) [8:30]

**CAC density and stabilization on statin therapy**: [The evolving view of coronary artery calcium and cardiovascular disease risk](https://onlinelibrary.wiley.com/doi/full/10.1002/clc.22842) (Thomas et al., 2018) [9:30]

**PCSK9 inhibition and statin therapy, effect on CAC**: [The annual rate of coronary artery calcification with combination therapy with a PCSK9 inhibitor and a statin is lower than that with statin monotherapy](https://www.nature.com/articles/s41514-018-0026-2) (Ikegami et al., 2018) [9:45]

**PCSK9 inhibition and statin therapy, effect on coronary plaque**: [Effect of Evolocumab on Coronary Plaque Composition](https://www.ncbi.nlm.nih.gov/pubmed/30336824) (Nicholls et al., 2018) [9:45]

**CHD risk calculator on MESA website**: [MESA 10-Year CHD Risk with Coronary Artery Calcification](https://www.mesa-nhlbi.org/MESACHDRisk/MesaRiskScore/RiskScore.aspx) | (mesa-nhlbi.org) [11:30]

**JAMA paper looking at CAC score and exercise**: [Association of All-Cause and Cardiovascular Mortality With High Levels of Physical Activity and Concurrent Coronary Artery Calcification](https://jamanetwork.com/journals/jamacardiology/article-abstract/2722746) (DeFina et al., 2019) [13:30]

**Peter swimming the Catalina Channel**: [Peter Attia crossing Catalina Channel](https://www.youtube.com/watch?v=yMQFd9q07Zo) | Peter Attia (youtube.com) [14:15]

**Extreme exercise may be bad for the heart**: [Potential Adverse Cardiovascular Effects From Excessive Endurance Exercise](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3538475/) (O’Keefe et al., 2012) [15:45]

**Book recommendation from Peter that coined the term “backcasting”**: [Thinking in Bets: Making Smarter Decisions When You Don’t Have All the Facts](https://www.amazon.com/Thinking-Bets-Making-Smarter-Decisions/dp/0735216355/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Annie Duke | (amazon.com) [20:00]

**Book by Doug McGuff that is a proponent of super slow training**: [Body by Science: A Research Based Program for Strength Training, Body building, and Complete Fitness in 12 Minutes a Week](https://www.amazon.com/Body-Science-Research-Strength-Training/dp/0071597174) by Doug McGuff and John Little | (amazon.com) [30:15]

**Centenarian studies**: [32:00]

- *Nir Barzilai’s study*: [The Longevity Genes Project](https://www.einstein.yu.edu/centers/aging/longevity-genes-project/) | (einstein.yu.edu)
- *Tom Perls’s study*: [New England Centenarian Study](https://en.wikipedia.org/wiki/New_England_Centenarian_Study) | (wikipedia.org)

**Centenarians tend to smoke more, exercise less, and eat worse**: [Even the Long-Lived Smoke, Drink and Don’t Exercise](https://healthland.time.com/2011/08/05/even-the-long-lived-smoke-drink-and-dont-exercise/) | Tara Thean (time.com) [33:15]

**Peter’s article about types of exercise and markers like glucose and lactate**: [The interplay of exercise and ketosis – Part I](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-i/) | Peter Attia (peterattiamd.com) [35:45]

**Michael Phelps breaking the world record in the 400 individual medley**: [Swimming – Men’s 400M Individual Medley Final – Beijing 2008 Summer Olympic Games](https://www.youtube.com/watch?v=FeUzMTD1zZE) | athleticgymnastics (youtube.com) [39:45]

**Satan’s tricycle**: [Schwinn Airdyne Exercise Bike](https://www.schwinnfitness.com/schwinn-airdynes) | ([schwinnfitness.com](https://www.schwinnfitness.com/)) [43:30]

**Bradley Wiggins broke the one hour record for cycling distance**: [The Insane Numbers Behind Cycling’s Most Masochistic Race](https://www.wired.com/story/cycling-hour-record-almost-impossible/) | Robbie Gonzalez (wired.com) [47:30]

**Book recommendation from Peter about exercise that describes a “governor” that forces humans to pace themselves even in a sprint**: [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) by Alex Hutchinson | (amazon.com) [48:00]

**Muscle glycogen content of athletes on a ketogenic diet about half of its prior level**: [Capacity for moderate exercise in obese subjects after adaptation to a hypocaloric, ketogenic diet](https://www.ncbi.nlm.nih.gov/pubmed/7000826) (Phinney et al., 1980) [50:00]

**Muscle glycogen content of athletes on a ketogenic diet about half of its prior level**: [The human metabolic response to chronic ketosis without caloric restriction: physical and biochemical adaptation](https://www.ncbi.nlm.nih.gov/pubmed/6865775) (Phinney et al., 1983) [50:00]

“**[But more recently](https://blog.virtahealth.com/keto-adapted/), we [Phinney, Volek, and colleagues] studied highly trained runners who had followed a ketogenic diet for 6 months or longer. Despite impressive weekly training mileage, their glycogen levels had come all the way back up to those of a matched group of athletes following a high carb diet**“: [Metabolic characteristics of keto-adapted ultra-endurance runners](https://www.ncbi.nlm.nih.gov/pubmed/26892521) (Volek et al., 2016) [50:00]

This implies that the body’s ability to produce and defend muscle glycogen via gluconeogenesis can become finely tuned, but that this takes much longer than 4-6 weeks to occur

**With enough exercise and activity you can tolerate much higher levels of carbs and stay in ketosis**: [Ketones and Carbohydrates: Can they co-exist?](https://peterattiamd.com/ketones-carbohydrates-can-co-exist/) | Peter Attia (peterattiamd.com)  [51:15]

**Phinney and Volek study looking at metabolic adaptations to a low-carb diet**: [Metabolic characteristics of keto-adapted ultra-endurance runners](https://www.sciencedirect.com/science/article/pii/S0026049515003340#bb0185) (Volek et al., 2016) [52:15]

**Book about addiction that Peter found “incredibly illuminating”**: [In the Realm of Hungry Ghosts](https://www.amazon.com/Realm-Hungry-Ghosts-Encounters-Addiction/dp/155643880X) by [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) | (amazon.com) [54:15]

**Gabor Maté on The Tim Ferriss Show**: [Dr. Gabor Maté — New Paradigms, Ayahuasca, and Redefining Addiction (#298)](https://tim.blog/2018/02/20/gabor-mate/) | Tim Ferriss (tim.blog) [55:30]

**Non-fiction books recommended by Peter**: [56:00]

- [The Road to Character](https://www.amazon.com/Character-Thorndike-Press-Large-Print/dp/1594139377) by [David Brooks](https://en.wikipedia.org/wiki/David_Brooks_(commentator)) | (amazon.com) [56:00]
- [I Don’t Want to Talk About It: Overcoming the Secret Legacy of Male Depression](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398) by [Terrence Real](https://www.terryreal.com/about/) | (amazon.com) [56:15]

**What is egg boxing?**: [Egg Boxing](https://peterattiamd.com/egg-boxing/) | Peter Attia (peterattiamd.com) [59:45]

§

## People Mentioned

- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) (co-host of AMA episodes, head of research for Attia Medical) [1:15]
- [Herbert Stary](https://www.medschool.lsuhsc.edu/pathology/faculty_detail.aspx?name=stary_herbert) (seven levels of atherosclerosis) [4:00]
- [Arthur Agatston](https://en.wikipedia.org/wiki/Arthur_Agatston) (Agatston Score) [8:30]
- [James O’Keefe](https://en.wikipedia.org/wiki/James_O%27Keefe_(cardiologist)) (electrical system of the heart, showed extreme exercise can damage the heart) [15:45]
- [Annie Duke](https://twitter.com/AnnieDuke?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (“backcasting”, [Thinking in Bets](https://www.amazon.com/Thinking-Bets-Making-Smarter-Decisions/dp/0735216355)) [20:00]
- [Doug McGuff](https://www.drmcguff.com/) (proponent of super slow training) [30:15]
- [Thomas Perls](https://en.wikipedia.org/wiki/Tom_Perls) (centenarian studies) [32:15]
- [Nir Barzilai](https://peterattiamd.com/nirbarzilai/) (centenarian studies) [32:15]
- [Jeanne Calment](https://en.wikipedia.org/wiki/Jeanne_Calment) (lived to 122) [33:45]
- [Sarah Knauss](https://en.wikipedia.org/wiki/Sarah_Knauss) (lived to 119) [34:15]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) (olympic swimmer) [39:15]
- [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata) (Tabata protocol) [43:30]
- [Robert Sapolsky](https://en.wikipedia.org/wiki/Robert_Sapolsky) (stress response, fight or flight) [45:15]
- [Bradley Wiggins](https://twitter.com/sirwiggo?lang=en) (one hour cycling record holder) [47:30]
- [Alex Hutchinson](https://twitter.com/sweatscience?lang=en) (wrote Endure) [48:00]
- [Tim Noakes](https://twitter.com/ProfTimNoakes?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (proponent of slow training) [48:30]
- Nick Stenson (Attia Medical) [49:30]
- [Jeff Volek](https://www.virtahealth.com/about/jeffvolek) (keto-adaptation) [50:00, 52:15]
- [Steve Phinney](https://www.virtahealth.com/about/drstephenphinney) (keto-adaptation) [50:00, 52:15, 53:45]
- [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) (wrote about addiction) [54:15]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (had Gabor Mate on his podcast) [55:30]
- [David Brooks](https://en.wikipedia.org/wiki/David_Brooks_(commentator)) (wrote [The Road to Character](https://www.amazon.com/Character-Thorndike-Press-Large-Print/dp/1594139377)) [56:00]
- [Terrence Real](https://www.terryreal.com/about/) (wrote [I Don’t Want to Talk about It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)) [56:15]
- [Apolo Ohno](https://en.wikipedia.org/wiki/Apolo_Ohno) (ate a bunch of the Attia Curry stir fry) [57:00]
- [Marvin Hagler](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler) (boxer) [1:00:15]
- [Randy “Macho Man” Savage](https://en.wikipedia.org/wiki/Randy_Savage) (WWF) [1:00:15]

§