# #64 – Zol Kryger, M.D.: Navigating the sometimes shady world of plastic surgery—understanding potential complications of common procedures and how to reduce your risk by choosing the right doctor and asking the right questions

**Source:** [https://peterattiamd.com/zolkryger/](https://peterattiamd.com/zolkryger/)

---

In this episode, board certified plastic surgeon, Zol Kryger, enlightens us about the frighteningly loose laws regulating the industry of plastic surgery, paving the way for a majority of cosmetic procedures being performed by doctors that are not board certified plastic surgeons. We talk about some of the very serious complications that can occur even in “minimally invasive” procedures, where the incidence rate is only increased by the flood of non-certified doctors who want to offer these procedures to augment their income. Fortunately, Zol provides listeners with a very specific list of important questions to ask a surgeon when considering any of the many cosmetic procedures available. We then go into the specifics of the most common procedures and the risk of complications for each of them, including breast augmentation, tummy tucks, liposuction, Brazilian butt lifts, botox and fillers, facial peels and lasers, and more. By the end of this episode, you’ll have a really clear understanding of what these risks are and how you can go about reducing those risks by choosing the right physician.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/zolkryger/the_Drive_public.png)

Play

#64 - Zol Kryger, M.D.: Navigating the sometimes shady world of plastic surgery—understanding potential complications of common procedures and how to reduce your risk by choosing the right doctor and asking the right questions

#64 - Zol Kryger, M.D.: Navigating the sometimes shady world of plastic surgery—understanding potential complications of common procedures and how to reduce your risk by choosing the right doctor and asking the right questions

1x15s30s

0:002:13:17

We discuss:

- Why Zol chose plastic surgery [7:30];
- The shockingly high percentage of plastic surgery being done by non-board certified doctors, and the laws that allow it to happen [11:20];
- 10 Questions to Ask Your Cosmetic Surgeon (PDF Download) [21:00];
- Complications: Why you must ask your doctor about potential complications and how they would deal with them [24:20];
- Zol’s first complication, how he dealt with it, and how having a partner to check your work is great for the doctor and patient [32:30];
- Breast augmentation: What you need to know—types of implants, complication rates, and Zol’s summary of the safest and most effective way to do it [39:10];
- Breast reconstruction following a mastectomy [1:06:30];
- Tummy tuck: how it’s done, biggest risks involved, scarring, and how it can address hernias and diastasis [1:13:00];
- Liposuction: How it works, the potential complications and risks involved, and the importance of choosing the right doctor in the “wild west” of liposuction [1:26:45];
- Butt lifts: Rising popularity, major risks, the frighteningly loose laws regulating the industry, and how the butt lift industry is eerily similar to the subprime mortgage crisis [1:37:00];
- What is it about plastic surgery (and not other segments of medicine) that compels (and allows for) untrained doctors to offer these procedures? [1:49:45];
- Peter asks Zol if he ever feels emotionally conflicted working in an industry that sometimes can feed off the vanity and insecurity of people [1:56:25];
- Does Zol ever turn down patients? [2:02:45];
- The risks involved with botox, fillers, facial peels, and laser treatments [2:07:45]; and
- More.

§

## Show Notes

## Why Zol chose plastic surgery [7:30]

How they met

- Zol was a classmate of Peter’s in medical school
- Zol (along with [Paul Conti](https://peterattiamd.com/paulconti/)) were one of the few people who knew from the start what they wanted to do with their degree

How Zol got into plastic surgery

- Influenced by his father who was a plastic surgeon
- The part of plastic surgery called [microsurgery](https://en.wikipedia.org/wiki/Microsurgery) got him most interested
  - Essentially microsurgery is using a microscope to connect tiny, fine structures like blood vessels and nerves and I was very attracted to the idea of doing this delicate surgery

Military history

- After high school in the United States, he went and volunteered to the [Israeli Army](https://en.wikipedia.org/wiki/Israel_Defense_Forces) and I spent three years in the Israeli Army
- Came back after that and went to university here and then medical school

## The shockingly high percentage of plastic surgery being done by non-board certified doctors, and the laws that allow it to happen [11:20]

Plastic surgery, then…

- Originally, plastic surgery was just one of the surgical subspecialties
- People first did a general surgery residency and then went and did a fellowship in plastic surgery

Plastic surgery, now…

- Now it has become its own residency so anywhere from six to seven years of training focused on plastic surgery with the first few years having an emphasis on general surgery

**People who do plastic surgery who are NOT plastic surgeons**

- Zol estimates that 90 to 95% of all plastic surgery done in the United States is done by someone who is NOT a board certified plastic surgeon
- “*It’s mind-boggling to me to think of how complicated some of the things we do are and to know that there are other specialists who are doing this* ***without really having any formal training in it****.*”

**Training in plastic surgery**

- 6 or 7 year program focused primarily on reconstructive surgery
- However, you don’t have to be trained in it to be allowed to do it

Laws in the US

- Any physician, once they receive their MD degree, can perform **any procedure** they want without any legal repercussions
- E.g., a family practice doctor can perform heart or brain surgery is they want
- Fortunately, he would be limited by the hospital not giving him privileges but he *could* just set up a facility in his own office

**Untrained docs doing Botox, liposuction, and more…**

> “Just in the greater Los Angeles area, hundreds and hundreds of physicians of all walks, gynecologists, ER doctors, general surgeons, family practice doctors, internal medicine, who have no training or no knowledge whatsoever just decide ‘I’m going to start doing Botox, I’m going to do fillers’. Then they purchase a laser, then they do liposuction, first office-based, then they are doing breast augmentation and other surgical procedures. It’s getting more and more common.”

*Consequences of doctors doing this*

- Many botched surgeries
- E.g., liposuction
  - A doctor will buy a new liposuction-type devices that use a laser or other type of energy to heat up the tissue and a lot of this is done as an office-based procedure
  - But without proper training, they can cause really irreparable damage
    - burning the skin
    - creating all sorts of contour irregularities that are just almost impossible to fix (“liposuction cripples”)
- ⇒ Actress [Tara Reid](https://en.wikipedia.org/wiki/Tara_Reid) is a classic example of this… she got [bad liposuction done on her abdomen](https://www.today.com/popculture/tara-reid-opens-about-plastic-surgery-wbna15421061)

**Does Zol believe that ONLY someone who trained in plastic surgery should do any of these procedures?**

- There are definitely things that other specialties (i.e., not trained plastic surgeons) that are trained well enough to do certain procedures:

⇒ For example, [ophthalmologists](https://en.wikipedia.org/wiki/Ophthalmology)

- They have a subspecialty called ocular plastic surgery where they learn a lot of eye surgery and I would be totally comfortable to refer patients with complex issues to oculoplastic surgeons to do eyelid surgery.

*But can they do a facelift?*

- **Some of them might be able to do that**, they have the training, they have the knowledge and the comfort. They know the anatomy. You have a subspecialty of ENT, ear, nose and throat, which is facial plastic surgery, they are well trained in that to do rhinoplasty, face lifts, any of the facial procedures.

*What about breast augmentation?*

- **Probably not**, they have absolutely no training on any part of the body below the neck

While it is possible to non-certified physicians to do certain plastic surgery procedures, you have to do your research

- And know the questions to ask
- Beware of someone who is offering a very low price

> “The average person out there who has very little knowledge, it’s difficult for them to make the decision. People think that plastic surgery is like buying a luxury item, like a Mercedes or a Rolex watch where it doesn’t matter if you go to the guy at the mall or if you order it online. A watch is a watch, a car is a car. It’s not like that at all. It should be approached no differently than. . .picking the right surgeon for heart surgery or brain surgery, picking the right doctor to treat any type of medical problem. You have to do your research and make sure you’re getting the right person.”

## 10 Questions to Ask Your Cosmetic Surgeon (PDF Download) [21:00]

\***Download printable PDF**: [Dr. Zol Kryger’s 10 Questions to Ask Your Cosmetic Surgeon](https://peterattiamd.com/wp-content/uploads/2019/07/Dr.-Zol-v5.pdf)

*10 Questions to Ask Your Cosmetic Surgeon:*

1. Are you board certified in plastic surgery? If not, what is your specialty of board certification?
2. At which hospitals do you have plastic surgery privileges?
3. Will my surgery be performed in an accredited surgery center?
4. If there is an emergency, what hospital does the center transfer patients to? Do you have privileges at that hospital?
5. Did you learn to do this surgery in your training? Or did you learn after your formal training?
6. How many of these surgeries have you done? How many do you perform per year?
7. Can I see photographs of patients who have had this exact surgery (a good result, an average result, and a bad result)?
8. What are the potential complications for my surgery, and how often does each one happen?
9. If there is a complication that requires additional surgery, how is it managed? Where will it take place and who pays the costs?
10. If I am not happy with the cosmetic result, what is your policy about revision and would pay for the revision?

## Complications: Why you must ask your doctor about potential complications and how they would deal with them [24:20]

In NY years ago, they started to provide a list of cardiac surgeons and listing their mortality rate

- While this seemed like a good idea…
- It incentivised physicians to NEVER take complicated cases for fear of their “score” being reduced
- This was a problem because you WANT a surgeon who has dealt with and worked through the most complicated cases

**In plastic surgery**: *how often do you see complication X and what is your protocol or path to deal with that?*

Zol says he divides complications into two parts:

- Early acute complications which happen immediately after surgery
  - these are primarily bleeding, infection, fluid accumulation, called a seroma
  - we would usually see in, for example, a tummy tuck
- Late complications
- The late complications are primarily aesthetic, so essentially you just aren’t happy with the result, you don’t like how it looks

You want to ask the plastic surgeon:

- what their incidences of each type of complication
- How often do you have to take someone back to the operating room for bleeding?
- How often do people get an infection after the surgery?
- And then IF that happens, **how do you manage it?**

**\*This a key point**\*

- *Someone like Zol…* I have my own operating room fully accredited operating facility so any complication that requires a return to the operating room, like bleeding for example, I have a facility to take care of this.
- *Somebody who doesn’t have a facility*… where they work at and they do everything in their office, if they have a complication that requires a trip back to the operating room, they’re stuck and the patient is financially stuck. I can do it at no charge for the patient and that’s sort of included in their cost.
  - \**This is probably the biggest source of lawsuits\**

*What happens if the doctor makes an error?*

- First of all, if there is an obvious error (bad scar, lopsided breast, etc.) this SHOULD be a no-brainer that the surgeon should correct
- “I’m a big, strong believer in admitting when you’re wrong. I think patients want that and that’s, in my mind, a sign of a good surgeon with humility.”

*What happens if it’s not an obvious “botch” but the patient isn’t necessarily happy with the result?*

- But in cases where the patient is simply “not happy” with the way it looks, you have to take it case by case
- For example, “the breast implants are too small, I want larger implants”
- In that circumstance, I might do it at no charge in terms of my fee, but I’ll make them pay for the new implants and the cost of the operating room and the anesthesia.
- \***These are all really key things to hash out ahead of time with the surgeon**.

Note: Patients don’t sue necessarily in proportion to the error, they sued in proportion to the lack of communication and the friction with the treating team: [To Be Sued Less, Doctors Should Consider Talking to Patients More](https://www.nytimes.com/2015/06/02/upshot/to-be-sued-less-doctors-should-talk-to-patients-more.html)

For more on complications and how doctors should deal with it see [Peter’s discussion with orthopedic surgeon, Eric Chehab](https://peterattiamd.com/ericchehab/)

## Zol’s first complication, how he dealt with it, and how having a partner to check your work is great for the doctor and patient [32:30]

**First complication Zol had during surgery**

- Very soon after completing training he inadvertently cut a blood vessel during a breast reconstruction
- He had to then spend a couple of hours under a microscope trying to repair a blood vessel the size of a toothpick
- It was all okay in the end

> “It’s extremely tough. It’s humbling because you have no one to turn around to. Like you said, there’s no attending physician who can bail you out.”

**Importance of having a good partner**

- Zol says he is fortunate to have a partner ([his brother](https://www.drkryger.com/plastic-surgery-information-thousand-oaks/surgeons/gil-kryger-md/)) who is also a plastic surgeon
- They can watch over each other’s shoulder and ask for advice in tricky situations

> “There’s a reason why two pilots fly the plane, each one knows how to do it alone, but when there’s another person double checking everything you do and offering a slightly different view and opinion, it makes a world of difference.”

## Breast augmentation: What you need to know—types of implants, complication rates, and Zol’s summary of the safest and most effective way to do it [39:10]

**Complication:** [**Capsular contracture**](https://www.plasticsurgery.org/news/blog/what-is-capsular-contracture-and-how-can-it-be-treated)

- Type of complication where the implant sits way too high up on the chest
- It’s the most serious, long-term complication from breast augmentation
- The incidence is anywhere from 2% to 8%

What causes the complication rate to vary?

- Quality of the surgeon
- Type of implant
  - Silicone implants have more complications that a saline implant
- Where the implant sits
  - The implants can go under the muscle or on top of the muscle
  - Implants put in under the muscle tend to have a lower capsular contracture rate because the muscle provides some sort of protection from it
  - Implants on top of the muscle have a higher capsular contracture rate

Why is it happening?

- Scar tissue… Anytime you put a foreign body inside of a human being, the body forms a reaction around it to wall it off, and that’s scar tissue… that’s called a capsule
- Normally it’s supposed to be soft and pliable like a balloon
- But if the body forms an abnormal capsule, it becomes hard and it contracts or squeezes down on the implant and causes pain and distortion

What are the resulting symptoms?

- Pain
- Displaces the implant up higher
- The side that’s contracted, the breast is very hard
- It looks strange
- Implant looks smaller because it’s being squeezed by this scar tissue

*How long after surgery does the complication develop?*

- Months or years, it varies greatly
- Most cases within 6 months

*What is causing it?*

- Not exactly sure
- The leading thought is that bacteria can cause it
- For example,
  - Woman will get a sinus infection, and then a few months later, they get capsular contracture
  - Or they had mastitis and then they get capsular contracture

*Most likely cause?*

- Probably due to bacteria that get in there **at the time of surgery**
- Complications that occur early on, such as bleeding or buildup of fluid, is an excellent medium for bacteria to grow in
  - If you have a woman who has a small hematoma, small amount of bleeding on one breast, that woman has a significantly higher risk of developing capsular contracture
    - Why? ⇒ That blood that’s bathing the implant is a great medium for bacteria to grow in.

\*Note: If a woman gets capsular contracture after her first augmentation, she is much more likely to get it again after a second surgery to try to correct it

**Complication: Rupturing implants**

- Saline implants notoriously start to leak after 10-15 years
- Silicone rarely rupture but it can happen (most of those cases the implant was damaged prior to being inserted)

**Complication:** [**Anaplastic Large-Cell Lymphoma (ALCL)**](https://en.wikipedia.org/wiki/Anaplastic_large-cell_lymphoma)

- Rare cancer seen in women with breast augmentation
- Very scary, and it is becoming more and more common
- It only [happens in implants that are “**textured”**](https://www.theguardian.com/society/2018/nov/26/rare-cancer-linked-breast-implant-used-by-millions-women-lymphoma)
- For some reason, the texturing triggers this autoimmune-type response, where they not only develop capsular contracture around the implant, but the body goes haywire and and develops this lymphoma
- With certain implants, the incidence rate is about 1 in 3,000 (used to be more like 1 in 300,000)

*Is there an advantage to textured implants?*

- “In my opinion, there is no advantage.” says Zol
- Initially it was thought there was a lower capsular contracture rate
- But Zol does not believe the data
- Zol says the studies done to show this were done by people who had a vested interest in showing textured implants were safe and better
- In fact, this [study showed that texture implants collect MORE bacteria than smooth implants](https://www.ncbi.nlm.nih.gov/pubmed/24675200), which would indicate a higher risk of capsular contracture

For more on the difference between correlation and causation, check out [Part II of Peter’s five-part Studying Studies series](https://peterattiamd.com/ns002/)

*Cost of textured?*

- About 20-25% more expensive
- Note: Surgeon makes more money based on the cost of the implant (so they might be incentivized to push the textured on you)

[Elizabeth Hall-Findlay](https://www.banffplasticsurgery.ca/about/dr-hall-findlay/)

- Zol tells a story about how she called out a panel of doctors, who were talking about the benefits of textured implants
- She showed a slide from the [Physician Payments Sunshine Act](https://en.wikipedia.org/wiki/Physician_Payments_Sunshine_Act) showing how much they each were paid by the implant industry to highlight the fact that they had an inherent bias

**Tear dropped shaped implant**

- Most implants are round
- Newer shape are tear drop
- The idea was that it looked more like a real breast
- These implants are textured bc it needs to hold it in place
- Round implants can “roll around” inside the breast without changing the shape

*Larger incision needed*

- Couldn’t go through the nipple area, had to do a large incision under the fold of the breast
- Well, there is less bacteria when going through there compared to the nipple area

Zol says the lower rate of capsular contracture with textured implants is likely due to the incision being made in a safer place that has less exposure to bacteria: [Relationship of incision choice to capsular contracture.](https://www.ncbi.nlm.nih.gov/pubmed/17994260)

> “I believe … that the lower rate of capsular contracture with textured implants is due to the incision being made in a safer place, that has less exposure to bacteria, and not because of anything inherent about the implants.”

*Do the tear drop implant even look more natural?*

⇒ An [interesting study](https://www.ncbi.nlm.nih.gov/pubmed/28027228) where they asked plastic surgeons to guess which women had round implants and which had shaped implants

- They were only right **50 percent of the time**
- In other words, it’s “*complete BS*”… the whole reason they were developed were to look more natural, yet you can’t tell a difference between tear drop and round
- Plus…they have disadvantages:
  - They are textured so they have the risk of this lymphoma
  - They’re more expensive
  - They’re harder and firmer to maintain their teardrop shape so they feel less natural when you touch them

***Should a woman with a textures and/or tear drop implant be worried?***

- Statistically, they should be fine, especially if they don’t have any issues now
- However, you should see your doctor every 6 months to make sure all is well
- No need to run and get them replaced

**SUMMARY on Zol’s thoughts for those considering breast augmentation**:

- Pick smooth implants and NOT textured
- Do round implants and NOT tear drop
- Use silicone and NOT saline
  - Silicone feels more natural, tend to look better, and won’t rupture as often
- Make the incision under the fold of the breast rather than through the nipple
  - The scar could be more visible, but the chance of capsular contracture goes down
- Place the implant behind/underneath the muscle as opposed to on top of it
  - Looks and feels more natural, and also better for mammogram imaging

## Breast reconstruction following a mastectomy [1:06:30]

Of all breast implants, Zol says about 25% of his cases are breast reconstruction after [mastectomy](https://en.wikipedia.org/wiki/Mastectomy)

The options:

- 1) You can use a woman’s own tissue
  - In the form of a flap where traditionally we take the tissue from the abdomen and make a new breast out of it.
  - You can use fat, and essentially just inject the fat in a series of treatments where you graft the fat into the site where the breast was
- 2) Implants
  - That is one situation where we might still consider to use teardrop shaped implant, because I think in a reconstructive patient, they’re one of the few situations where there still is some benefit.
  - That’s actually the only situation where I’m using the teardrop shaped implants, is for breast cancer reconstruction
  - Those women have a lot of monitoring and everyone’s on top of them because they’ve had breast cancer.
  - My concern with them is less about developing some type of lymphoma
  - I also think that because they’ve had a mastectomy their body’s ability to mount this autoimmune type response is lower, because their lymphatics have mostly been cut.

*Does it look better when you have a flap? Does it look more natural?*

- It does look more natural
- The main advantage is you never have to deal with an implant and the complications associated with the implant for the rest of your life
- You can’t reject your own tissue.
- It’s especially good for a woman who’s only doing one side where she has a natural breast, especially if it’s more of a flat, hanging breast on the other side. It’s hard to match that with an implant.
- If a woman’s doing both sides we’ll usually lean more towards implants, but again, it’s really on a case by case thing.

*And how often do women in that situation require tissue expanders, and is it often a multi-stage procedure? Or what’s the sequence of events from the mastectomy to the reconstruction?*

- One of the things that’s changed a lot in the field of breast cancer…
- when you go back to the beginning of the mastectomy, one of the great mentors and great surgeons, Halsted, he initially thought that you had to cut everything out for breast cancer and he would remove all the skin, all the breast and the muscle, and everything.
- Where we’ve come to today is doing a nipple sparing mastectomy where essentially a lot of women are candidates for removing the breast, but keeping all of the skin, including the nipple behind.
- In that case you can go directly to an implant reconstruction, because you’re not trying to manufacture new skin.
- In the case of women who have to have their nipple removed, so you’re removing a portion of the skin, you need to now restore skin that’s been removed in the mastectomy and that’s where a tissue expander comes in where we stretch out the skin and that’s a multi-step process that takes a few months until we put in a final implant.

**How does Zol support women going through this tough situation?**

*Do you find yourself dealing with the psychology of that? Dealing with a patient who’s going through the simultaneous loss of this tissue and the cancer risk, but then the loss of part of her physical image and femininity?*

“Yeah, absolutely. There was a woman who was part of my team, whether it was a nurse or a PA, was in the room with me with a breast cancer patient and the patient started to cry when we started to talk about her diagnosis and the treatment, and I sort of sat there a little uncomfortable, not sure what to do when she was crying, and the woman who was in the room with me, the nurse if it was, she grabbed a tissue and gave it to the patient and then hugged her.

And that episode really stuck in my mind, because it made me feel inadequate at the time and I didn’t know if it was because I was a man, or because I didn’t have breasts and hadn’t undergone breast cancer, or I didn’t have a family member who’d had breast cancer. I wasn’t sure what the reason was, I hadn’t receive the adequate sensitivity training, but I just felt inadequate to deal with it. And I think since that time I’ve become better at having developing the empathy and the understanding for what these women are going through. A lot of it has come through getting to know the husbands and the children and the parents, where I talk to them and spend time with them, and kind of get a better feel as the man what they’re going through. It’s a very complicated process, and a lot of good hospitals have social workers and psychologists that help the women.

We’re seeing more and more breast cancer in younger women these days, so it’s a very devastating thing. I mean, for a lot of women, they associate their femininity to a large degree with their breasts, and losing that has a profound impact on them.”

## Tummy tuck: how it’s done, biggest risks involved, scarring, and how it can address hernias and diastasis [1:13:00]

**What is a tummy tuck?**

- A tummy tuck is essentially a procedure that involves removal of all the excess skin in the abdomen below the belly button, in the central abdomen.
- It also typically involves tightening of the muscles that get stretched out as a result of pregnancy.
- 95% of tummy tucks are done on postpartum women who’ve had children, and their bodies have changed to a large degree after childbirth.

*What is a hernia of the belly button?*

- About 20% of women after pregnancy develop a hernia in the belly button
- The belly button was the site of your umbilical cord when you were in utero, so there was always an opening there, and it scars closed when you’re born, but it’s an inherent spot of weakness
- So, the act of pregnancy, where the abdominal wall is stretching and the pressure inside is building up as the uterus grows, can pop that open and a lot of women develop hernias (an “outie”)
- Note, **an untreated hernia can be life threatening**
  - That said, if a woman has no symptoms from it all, you don’t have to treat it… But once it starts to cause **pain or any other symptoms**, *it should be treated*

*What is diastasis?*

- It’s a separation of the rectus muscles ⇒ so the six pack muscles move aside and then there’s a gap in between
- It’’s similar to a hernia in that you have a weakened central area where stuff is pushing out against it
- In severe diastasis, you can literally see their intestines through their skin
- It does not have the same risks of an untreated hernia
- Instead of having the normal, flat stomach, your stomach is protruding outwards especially after a large meal (which may prompt your child to ask if you’re having another baby)
  - IMPORTANT NOTE: Never ask a woman if she’s pregnant unless you can literally see the baby crowning ⇒ [see bit from Brian Regan](https://www.youtube.com/watch?v=aqyBtK9jkD8)

*During a tummy tuck, it’s common for the following to be addressed*

- Diastasis
- Hernia
- C-section scar

**How are tummy tucks actually done?**

- We’re essentially lifting up all of the skin off the abdominal wall all the way up to the Xiphoid, so right up to the breast bone
- We’re exposing the entire abdominal wall… It’s basically like an anatomy text book. You’re staring at the whole abdominal wall with the skin lifted up.
- Then we do the muscle tightening, and/or the hernia repair
- Regarding muscle tightening…
  - Typically, we all have a line vertically down the center of our ab muscles that separates the left and the right side that creates about a **half an inch** gap
  - A woman with a diastasis will have **inches** between the left and right ab muscles
  - Not only are the muscles apart, the fascia has been stretched out, so the muscles, instead of being flat, are actually bulging outwards (mini beer belly)
- Note: About 5% to 10% of tummy tuck patients are men and all of them are massive weight loss patients coming for the skin removal

**Biggest risks of the procedure**

*The biggest risk* is fluid accumulation called [seroma](https://en.wikipedia.org/wiki/Seroma) after the surgery

- - The incidence is about 10%, 15%.
  - It usually requires drainage… only in rare cases will it go away on its own

- *As the plastic surgeon, do the drainage or does an interventional radiologist?*

- - We do everything in my practice… we manage all the complications
  - Occasionally we’ll send someone to an interventional radiologist if for example the fluid is one small specific spot and you need an ultrasound to see where it is and we need them to put in a special type of drain.
  - But, 95% of the time we’re managing it ourselves in the clinic
- D*oes a sermona typically resolve with the appropriate follow up drainage*?
  - Yeah, they usually do

*Is there a risk of bleeding?*

- Bleeding is a small risk
- In the cases where it happens are in the patients with larger blood vessels
  - E.g., Massive weight loss patients have very large blood vessels, and so it’s understanding when you need to tie off a blood vessel as opposed to just cauterizing it, and really being meticulous and careful
- Also patients with high blood pressure are at greater risk of bleeding

**Scarring complications**

- The main thing people complain about is the scars
- They’re unhappy with the appearance of the scar
- A lot of patients gain weight and stretch out and they end up with loose skin after the surgery

*Tension is the key*

- But the **tension** on a scar is a big contributor to how the scar’s going to turn out (the more tension, the more likely for poor scarring)
  - E.g., The area of highest tension is in the very center of the scar, and that usually is the area that scars poorly, whereas as you go out towards the side of the scar, towards the hip bone, the scar becomes more faint and less noticeable because there’s less tension there.

## Liposuction: How it works, the potential complications and risks involved, and the importance of choosing the right doctor in the “wild west” of liposuction [1:26:45]

Scary stats

- Zol estimates that 80 to 90% of the liposuction procedures are being done by **non-plastic surgeons** in an office-based setting
- There are anywhere from 20 to 30 devices out there that perform different types of liposuction so, doctors, non- plastic surgeons, are purchasing these devices and offering this to patients

Popular devices

- Cool Sculpting
  - You basically wave a “magic wand” over the person and it freezes the fat
- Devices that use heat
  - They have a lot of risks associated: burns, contour irregularities
- “*I’m not a believer in a lot of these technologies.*”

**Tradition lipo**

- Most board certified plastic surgeons do what’s called just traditional liposuction
- Essentially it is the movement of a cannula that causes the fat to break down
- And then you just suck it out

*What is a cannula?*

- a hollow, long, metal or plastic device that is inserted underneath the skin, into the fat. That’s what breaks the fat down and sucks it out

*Why doesn’t the fat just all uniformly come out when you suck it?*

- The fat is connected pretty well to the overlying skin
- There’s connective tissues on different parts of the body is connected to the fat to various degrees
  - For example, the fat on the soles of the feet and the palms is extremely strong and tough fat. The fat in the buttocks, where we sit, is also very rigid and fat. It’d be extremely hard to liposuction that.

*First you must break it apart:*

- You have to actually break it apart, and that’s whether it’s done with a form of energy or just the mechanical energy generated by the movement of the cannula that breaks the fat apart

**Complications**

- Many non-plastic surgeons are doing lipo
- This is key because you want someone who’s experienced and knowledgeable to not make errors but also someone who knows how to address the biggest complications

“A good surgeon knows how to take care of any complication they create.”

*Complication:* **Punctured organs**

- There are [multiple cases of puncturing lungs, liver, and intestine](https://www.medquestltd.com/surgeon-punctures-lung-liver-tummy-tuck-liposuction/)
- How??
  - The most common area of liposuction is the abdomen.
    - So, if someone is liposuctioning the upper abdomen, you obviously have to understand the anatomy (e.g., You have a ribcage there, so you have to stay above the ribs)
    - But, if you’re not paying attention, you’re not feeling and aware of what you’re doing, it’d be pretty easy to slip underneath a rib
    - If you go underneath the rib, the next thing you encounter there is the rectus muscle and then the diaphragm
    - Thin cannulas can just push right through the abdominal wall and into the next layer

> “Liposuction is a dangerous procedure if not done properly, and we see incredible complications and death rates from it.”

*Complication*: **Electrolyte problems from fluid shifts**

- There’s tremendous fluid shifts that happen after liposuction
- [Pulmonary edema](https://en.wikipedia.org/wiki/Pulmonary_edema), fluid in the lungs essentially
- When is this happening?
  - Mostly in the office setting rather than the operating room
  - Also, when the doc isn’t monitoring the patients during **and after** the procedure

*Another risk*: **Lidocaine toxicity**

- Another major risk with liposuction is [lidocaine toxicity](https://www.ncbi.nlm.nih.gov/pubmed/10320385)…overdosing the people with lidocaine (used to numb up the location of lipo)
- During lipo, you have to introduce fluid full of lidocaine into the area
- It also has epinephrine in it, so it causes constriction of the blood vessels to decrease the bleeding
- Interestingly, it takes about eight to 12 hours as a delay after the liposuction for it to see peak levels of the substances in the blood stream so these levels are occurring at home, and that’s when you have to really understand what you’re doing, what volumes you’re putting into the patient, making these calculations.
  - And a lot of the **people doing this in the office are not thinking about it, and that’s where they run into trouble**

**Reducing risk of complications**:

- Avoid very large volume liposuction
- When you’re trying to suck up more than about 10 pounds of fat at a time is what’s considered large volume liposuction, and that’s where the risks really go way up

*⇒ What are some people doing out there in the community?*

- Some docs are doing 20 pounds, 30 pounds of liposuction, eight hours of liposuction, all day long
- **Buyer beware**: “It’s the wild west. Like I said, anyone can do anything and there’s no laws or regulations governing what’s done. It’s buyer beware.”

**Cost of liposuction**

- Anywhere from $1000, if you’re just doing one limited area in an office-based procedure, up to $ 7000 to $8000, depending on going into multiple areas over several hours

*And what’s the range in price that you see between sort of highly trained dermatologists or plastic surgeon versus the people who are doing this with less training?*

- People with less training, who are not board certified plastic surgeons, are usually charging much less, especially if they’re doing things in the office.
- You can see a two to threefold price difference compared to someone doing it in the operating room with anesthesia

## Butt lifts: Rising popularity, major risks, the frighteningly loose laws regulating the industry, and how the butt lift industry is eerily similar to the subprime mortgage crisis [1:37:00]

- Zol says butt lifts are “*the real dangerous*” procedures
- It’s getting more and more popular due to social media (thanks [Kim Kardashian](https://www.instagram.com/kimkardashian/?hl=en)!)

*How many does Zol do a year?*

- 20 to 30
- But Zol knows a surgeon doing 7-8 per day!

**What is a butt lift?**

- it’s injecting fat into the butt to enlarge it
- That fat is liposuctioned from one part of the body and then injected into the butt
- There is no mechanical lift… it’s just like inflating a balloon

**The major risk**: A [fat embolism](https://en.wikipedia.org/wiki/Fat_embolism_syndrome) which has a high risk of fatality

- Inadvertently injecting fat into the veins in the butt will allow the fat to get transported to the lungs and causes a fat embolism
- There have been multiple deaths
  - Most of them in Florida
  - Some in South America
  - Some in California
- Autopsy will show their lungs full of fat that was basically transported from the veins in the butt where the fat was accidentally injected

*What are the chances of this happening?*

- Probably 1 in 1,000 (maybe more)

**The Asymmetry of Risk**

Peter’s rant on the asymmetry of risk…

- You might listen to this and think, “Well, 1:1000 is not that bad.”

**But consider the following example:**

- Peter has a patient who was experiencing pain in his calf that could indicate a pulmonary embolism
- Peter says, however, that listening to the patient, the probability that they have a pulmonary embolism is actually quite low, **but it’s not zero**

*Let’s assume there’s a 1% chance you they have pulmonary embolism (or even 0.1%)*

*-You still must consider the following*:

   1 The cost of doing something versus the cost of doing nothing

   2 The cost of being wrong in **both** of those situations

 ⇒ Doing nothing and being wrong:

- If you don’t go in to the ER and you end up having a pulmonary embolism, that cost is infinitely greater (though far less likely) than the other scenario

 ⇒ Doing something and being wrong:

- The cost of you going into the ER and NOT having a pulmonary embolism
- It costs you time and money
- But that’s a *finite* cost
- Whereas, the other one becomes an *infinite* cost (death)

**How the butt lift industry is eerily similar to the subprime mortgage crisis**

- Zol says it’s showing how tolerant people are of complications

[Recent expose done by USA Today about these Miami plastic surgery clinics](https://www.usatoday.com/in-depth/news/investigations/2019/04/22/felons-opened-plastic-surgery-businesses-where-women-died/3501970002/)

- They’ve had tremendous numbers of deaths and complications
- And yet, people just keep going back because they are so **price-conscious**
- These places will do it for cheaper than anywhere else will
- People have this idea that, if you’re a doctor, you’re safe, and you know what you’re doing, and you’re going to do the right thing
- If there’s a clinic, and it looks semi-clean, that they don’t need to worry.
- The problem is, the laws are not out there to 100% protect the patients.

*Laws and oversite*

- They’re actually in the process of [amending a lot of the laws in Florida](https://www.usatoday.com/story/news/investigations/2019/05/01/florida-passes-strict-controls-plastic-surgery-centers/3617669002/), which has just been way too liberal, in terms of what they allow to happen.

*Everything is driven by money*

You get these lobby groups…

Examples:

- 1 Optometrists do not have training to do surgical procedures, but they might lobby to allow them to do blepharoplasty (eyelid surgery)
  - They’re paying money to politicians, and then laws are getting passed, that allow them to do this.
- 2 Dentists who want to do facelifts.
  - They’re lobbying state legislators, to allow them to do facelifts.
  - I would argue that a dentist does not have training to do a facelift. They’re used to working through the mouth.
  - Now, you’re talking about working very far away from the mouth, using principles and techniques that they have no training in.
  - They just want the money. They’re doing this for the money, not for the benefit of the patient.
  - It’s not like patients are suffering because there’s not enough good facelift surgeons out there. That’s just not true.

> “Finances drives a lot of [who is allowed to perform these procedures], and **not necessarily patient safety.**”

*The groups that are trying to protect patient safety*… they don’t have the money and the backing, to pressure the legislators to do everything that is in the best interest of the patients

*Inadequate oversight*: When you look at the situation in Florida, you have surgery centers that are doing only plastic surgery, being owned by businessmen with long laundry lists of convictions and crime. They’re not doctors at all.

**BUYER BEWARE**

- These are guys who are just doing it for the money, and so it’s really buyer beware, and all of the burden falls on the patients to do their homework, and do their research.
- For a lot of uneducated, less sophisticated patients, they don’t know what to ask, they don’t know what to look for, and they’re the ones who are suffering.
- A lot of minority patients, they’re the ones who are suffering the brunt of these complications.
- In Miami, there’s a huge advertising blitz on Hispanic radio stations, and billboards in the inner city, where they’re specifically targeting less sophisticated groups, that they feel aren’t going to do the same amount of homework and research.

> “This sounds eerily reminiscent of the subprime crisis.” —Peter

**How Zol reduces risks**

*When doing the butt lifts, what steps does Zol take to reduce the risk of inadvertently cannulating a vein?*

- Zol says it all comes down to knowing the anatomy
- You have to know where the veins are, and how they move based on the position of the patient
- E.g., if you angle the table they are lying on it will change the position of their veins
- \*This is why it’s so important to have a trained plastic surgeon who knows the anatomy\*

“Understanding anatomy is really the key, which goes back to my point about why, if you didn’t train and learn the anatomy, it’s so difficult to do safe surgery.” qkt

## What is it about plastic surgery (and not other segments of medicine) that compels (and allows for) untrained doctors to offer these procedures? [1:49:45]

Zol points out that plastic surgery really is the only segment of medicine that has created an environment where non-trained people are getting away with practicing procedures which they are severely undertrained and the clients/patients don’t seem to care (or are ignorant to it)

**Thought experiment**: *Why is this problem not occurring in cardiac surgery, for example?*

First reason: **patient demand isn’t really driving cardiac surgery**

- Nobody wakes up and says, “I really want to have a coronary artery bypass today.”
- Or… “I’m not happy with my aortic valve, I got to get this thing switched out.”
- In other words, **patient demand isn’t really driving cardiac surgery** ⇒ It’s being really driven by the pathology
- The demand is not really coming straight from patient to ultimate practitioner

The second thing: **the complexity of the case**

- At the end of the day, you want to do a coronary artery bypass graph, you want to do a hip replacement, *that’s really complicated*
- A random doctor will never figure out how to do that without going through the formal training
- Whereas, in the end, liposuction is a relatively simple procedure… and the simpler the procedure, the more likely someone is to try to do it (on the contrary, not too many non-plastic surgeons doing deep flaps or breast reconstruction)

Third piece: **The hospital**

- There’s a huge divide between what happens in a hospital, and what doesn’t
- The moment you walk into an accredited hospital, the bar is just raised dramatically
- It would require outright fraud for a charlatan to be in there doing that

It’s really these three things put together:

1. What procedures can be done completely outside of the purview of a hospital?
2. What procedure can be done, that’s relatively simple to learn (at least to be able to fake it)?
3. What procedures are being driven by enormous patient demand where the patient comes directly to the practitioner?

“To me, it’s those three things, that have created this trifecta of disaster” says Peter

**Zol adds two more piece to the puzzle**:

1 *People think of plastic surgery like a haircut*

- In a lot of patients’ minds, plastic surgery is not in the same category as other types of surgery
- It’s more like getting a haircut, or getting your teeth bleached, or getting your nails done
- “Oh, I’m just going to go in for a little afternoon liposuction”
- People don’t think about it in the same way as they think of other surgical procedures

2 *The influence of money*

- The money is such a big part of it, because there’s so much money in this field
- When you get your knee replaced, your insurance is hopefully paying the majority of it
- In cosmetic surgery, patients are paying out of pocket for it

> “Other doctors, who are primarily insurance-based doctors (most physicians in America), see this lucrative cash-paying procedures, and they want a piece of it. They want to augment their income with it.”

## Peter asks Zol if he ever feels emotionally conflicted working in an industry that sometimes can feed off the vanity and insecurity of people [1:56:25]

**Peter’s question to Zol**:

- You’re in a profession which feeds off the vanity and insecurity of people…
- And there’s an economic incentive because this is how you make a living…
- But at the same time you may not even understand **why** someone wants a particular procedure because you may think they look perfectly fine…
- That said… if they plan to do the procedure regardless of your opinion, you feel as though you would certainly rather they do it with you because they would have a much higher probability of getting  home safely than they go to somebody else

*How do you process all of those emotions and thoughts?*

- “I think about it simplistically. I’m just helping people. People come to me with a problem, just like they come to any doctor with a problem. Psychiatrists see people with psychiatric problems, and the rest of the physicians see people with physical problems. It’s a combination of both. I’m like a psychiatrist with a knife, basically. I fix a lot of psychiatric problems with a knife.”

*Do you think you’re fixing them? Or is it just a bandaid?*

A key part of being a good plastic surgeon is understanding, ‘am I going to fix this problem with the knife, or is this a problem that requires some other type of treatment?’

**Example**: Take a girl who’s 18 years old. She just finished high school, she’s about to go off to college. She’s a beautiful girl, but she has a huge, giant nose. She’s completely self-conscious about this nose. If you did a photo manipulation with a computer program, and showed her a picture of her face with an altered post-surgical nose, she’s crying. She loves it.

“If you do surgery for that girl, you change her life. You help her in a profound way. She’s not excessively vain. She’s not psychologically ill. She doesn’t have mental problems. She looks in the mirror, and sees a nose that is way out of proportion to her face. She’s bothered by it, she’s been teased about it before. She compares herself to other people”

*The society we live in*

“Now, yeah, you could make an argument that we should live in a society where we don’t care about the size of people’s noses, and we don’t care about the way people look, but until that happens, which I doubt is happening anytime soon, people attach importance and value to the way they look. So, yeah, I think operating on that girl, I’m doing her a huge service. I’m helping her. There’s nothing wrong with that.”

*Quality of life*

“Quality of life is a really complex issue. There’s so many factors that go into it. It’s avoiding injury, it’s feeling healthy, it’s not having medical problems, it’s feeling good about yourself, it’s being able to do the things you enjoy. The list goes on, and on, and on. What I’m trying to do, is to contribute to quality of life. It’s just one aspect of quality of life. I always wonder, if you succeed with your goal to get people to live longer, we’re going to have a lot of really old-looking people walking around.”

## Does Zol ever turn down patients? [2:02:45]

- Zol says he turns down one patient per day, on average
- Zol says this is the hardest thing for a plastic surgeon to do because of the money involved

*Example of a very common patient he will turn down*: **An overweight patient who comes in for liposuction**

- Liposuction only sucks out subcutaneous fat
- But many people have a lot of visceral fat
- Also, liposuction can only pull out maybe 10 pounds effectively and safely
- Losing a lot of fat through diet and exercise has a better effect on the skin (less loose skin than lipo)

Zol says he focuses on health and well being with the patient

- The difference between losing 15 pounds through liposuction, versus losing 15 pounds through diet and exercise, is profound… “*They’re much better off.*”
- Zol will even show them the cost of the procedure and compare it to the cost of getting a gym membership, hiring a nutritionist, change your eating
- “*You’re going to be healthier. You’re going to look better. It’s a much better use of your money.*“

*Another type of patient he turns down*: [**Body dysmorphic disorder**](https://en.wikipedia.org/wiki/Body_dysmorphic_disorder)

- They are totally fixated on something
- They’ve had multiple surgeries
- There are a number of red flags that we look for.
- We have an acronym called SIMON, “avoid the SIMON” (Single Immature Male Overly Narcissistic)
- That guy should not have surgery, he needs counseling
- “I don’t have the skill and knowledge necessary to help you, in a way that is going to make you happy.”

Also, another example,

- “Anytime someone badmouths another plastic surgeon (especially one that Zol knows and respects), there’s a very low chance I’m going to ever operate on them.”

## The risks involved with botox, fillers, facial peels, and laser treatments [2:07:45]

**Botox, fillers, facial peels, and laser treatments**

- These are widely considered “minimally invasive”
- They are very popular because people want “cheap, and quick, and easy, with low risk, and very little downtime”

*However,* these procedures are **NOT without risk**

> “It’s just a golden rule, in surgery and in plastic surgery, if something has no risk, no recovery, no downtime, low cost, it has no result.”

*Examples*:

25 reported cases of [blindness from filler](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5300728/) injected near the eye

- The filler enters into an artery, and gets transported retrograde, and then flows into the retinal artery, and obstructs the retinal artery, and causes blindness
- It can come in whether it’s injected:
  - **Beneath the eye** (via an artery that comes out on the side of the nose, just below the inside corner of the eye, that if you get the filler in there, it can transport)
  - **Or into the forehead** (via an artery that comes out right above the eyebrow)

*Lasers and peels on the face*

- Patients can have [permanent pigment damage](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5418955/) from lasers and peels done on the face

[*Vampire facials*](https://en.wikipedia.org/wiki/Platelet-rich_fibrin_matrix)

- This is when people have PRP blood harvested and then spun and re-injected into their face (It’s not proven to actually work)
- There has been [several HIV cases from these vampire facials](https://www.webmd.com/hiv-aids/news/20190430/two-test-positive-for-hiv-after-vampire-facial) where machines are not adequately cleaned and processed, and so they’re contaminated with blood from another patient

**A good resource**: [The American Society of Plastic Surgeons](https://www.plasticsurgery.org/) (talks about every procedure and the risks of every procedure)

For more on facial cosmetic procedures, check out [Peter’s discussion with cosmetic surgeon, Brett Kotlus](https://peterattiamd.com/brettkotlus/)

> “Knowledge is power in these things, and to understand that there’s just no free lunch. You can’t just undergo one of these lunchtime procedures without risk.”

§

## Selected Links / Related Material

**Tara Reid’s botched surgery**: [Tara Reid opens up about plastic surgery](https://www.today.com/popculture/tara-reid-opens-about-plastic-surgery-wbna15421061) | (today.com) [16:30]

**Download PDF**: [Dr. Zol Kryger’s 10 Questions to Ask Your Cosmetic Surgeon](https://peterattiamd.com/wp-content/uploads/2019/07/Dr.-Zol-v5.pdf) [21:00]

**Peter’s convo with Eric Chehab about complications**: [#36 – Eric Chehab, M.D.: Extending healthspan and preserving quality of life](https://peterattiamd.com/ericchehab/) | Peter Attia (peterattiamd.com) [30:30]

**Research showing patients didn’t sue necessarily in proportion to the error, they sued in proportion to the lack of communication and the friction with the treating team**: [To Be Sued Less, Doctors Should Consider Talking to Patients More](https://www.nytimes.com/2015/06/02/upshot/to-be-sued-less-doctors-should-talk-to-patients-more.html) | Aaron Carroll (nytimes.com) [30:30]

**Anaplastic large cell lymphoma, a rare cancer seen in women who have breast augmentation with textured implants**: [Rare cancer linked to breast implant used by millions of women](https://www.theguardian.com/society/2018/nov/26/rare-cancer-linked-breast-implant-used-by-millions-women-lymphoma) | Hannah Devlin and Hilary Osborne (theguardian.com) [46:00]

**FDA reviewed data (in April 2019) on textured implants and decided to let them stay on the market**: [Statement from FDA Principal Deputy Commissioner Amy Abernethy, M.D., Ph.D., and Jeff Shuren, M.D., J.D., director of the FDA’s Center for Devices and Radiological Health on FDA’s new efforts to protect women’s health and help to ensure the safety of breast implants](https://www.fda.gov/news-events/press-announcements/statement-fda-principal-deputy-commissioner-amy-abernethy-md-phd-and-jeff-shuren-md-jd-director-fdas?utm_campaign=05022019_Statement_FDA%20statement%20on%20new&utm_medium=email&utm_source=Eloqua) | (fda.gov) [48:00]

**The Eurpean “FDA” has pulled a number of the textured implants off the European market**: [Allergan Suspends Sales and Withdraws Supply of Textured Breast Implants in European Markets](https://www.allergan.com/news/news/thomson-reuters/allergan-suspends-sales-and-withdraws-supply-of-te) | (allergan.com) [48:00]

**Study showing bacteria are 70 times more able to stick to the textured implant than to the smooth implant**: [In vitro and in vivo investigation of the influence of implant surface on the formation of bacterial biofilm in mammary implants.](https://www.ncbi.nlm.nih.gov/pubmed/24675200) (Jacombs et al., 2014) [50:00]

**In cases of this ALCL lymphoma, and in cases of capsular contracture, the capsules are full of bacteria**: [Bacterial Biofilm Infection Detected in Breast Implant-Associated Anaplastic Large-Cell Lymphoma.](https://www.ncbi.nlm.nih.gov/pubmed/26890506/) (Hu et al., 2016) [50:20]

**The Sunshine Act which essentially shows how much money every doctor in America has been paid from industry**: [Physician Payments Sunshine Act](https://en.wikipedia.org/wiki/Physician_Payments_Sunshine_Act) | (wikipedia.org) [52:30]

**Peter’s article about correlation vs. causation**: [Studying Studies: Part II – observational epidemiology](https://peterattiamd.com/ns002/) | Peter Attia (peterattiamd.com) [54:00]

**Zols says the lower rate of capsular contracture with textured implants is due to the incision being made in a safer place that has less exposure to bacteria, and not because of anything inherent about the implants**: [Relationship of incision choice to capsular contracture.](https://www.ncbi.nlm.nih.gov/pubmed/17994260) (Weiner, 2008) [56:30]

**Study revealing that plastic surgeons could not tell the difference between a woman who had round implants vs. a woman who had tear drop shaped implants**: [Comparing Round and Anatomically Shaped Implants in Augmentation Mammaplasty: The Experts’ Ability to Differentiate the Type of Implant.](https://www.ncbi.nlm.nih.gov/pubmed/28027228) (Rubi et al., 2017) [58:00]

**The two main companies making silicone implants**: [1:03:30]

- [Mentor](https://www.mentorwwllc.com/global-us/Breast.aspx)
- [Allergan](https://www.allergan.com/)

**Brian Regan’s bit about not asking a woman if she’s pregnant**: [Brian Regan – ‘When’s that baby due?’ and ‘Guessing gender wrong’](https://www.youtube.com/watch?v=aqyBtK9jkD8) | Steve Weaver (youtube.com) [1:17:45]

**Rising rate of C-sections in the US**: [Rate Of C-Sections Is Rising At An ‘Alarming’ Rate, Report Says](https://www.npr.org/sections/goatsandsoda/2018/10/12/656198429/rate-of-c-sections-is-rising-at-an-alarming-rate) | MICHAELEEN DOUCLEFF (npr.org) [1:19:45]

**A dermatologist invented modern day liposuction**: [History of Liposuction](https://lipo.com/liposuction-information/history-of-liposuction/) | (lipo.com) [1:30:00]

**Cases of puncturing lungs during liposuction**: [Surgeon Punctures Lung & Liver During Tummy Tuck Liposuction](https://www.medquestltd.com/surgeon-punctures-lung-liver-tummy-tuck-liposuction/) | (medquestltd.com) [1:30:45]

**Lidocaine toxicity from liposuction**: [Deaths related to liposuction.](https://www.ncbi.nlm.nih.gov/pubmed/10320385) (Rao et al., 1999) [1:34:15]

**Butt lifts can result in death from a fat embolism**: [Report on Mortality from Gluteal Fat Grafting: Recommendations from the ASERF Task Force](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5846701/#CIT0025) (Mofid et al., 2017) [1:40:15]

**Example of a woman who died of a fat embolism following a buff lift**: [New Details In Mother’s Death Following Butt Lift Procedure](https://www.nbcmiami.com/news/local/New-Details-Emerge-South-Florida-Mothers-Death-Butt-Lift-509875921.html) | (nbcmiami.com) [1:40:15]

**Recent expose done by USA Today about Miami plastic surgery clinics where they’ve had tremendous number of deaths and complications, and people just keep going back, because they are so price-conscious**: [Women seeking discount plastic surgery paid with their lives at clinics opened by felons](https://www.usatoday.com/in-depth/news/investigations/2019/04/22/felons-opened-plastic-surgery-businesses-where-women-died/3501970002/) | Michael Sallah and Maria Perez and Steve Reilly (usatoday.com) [1:44:00]

**Florida is in the process of amending the laws**: [Florida lawmakers OK sweeping changes to crack down on deadly cosmetic surgery facilities](https://www.usatoday.com/story/news/investigations/2019/05/01/florida-passes-strict-controls-plastic-surgery-centers/3617669002/) | Michael Sallah, Steve Reilly, and Maria Perez (usatoday.com) [1:44:00]

**Cases of blindness from filler injected near the eyes**: [Blindness After Facial Injection](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5300728/) (Askari Townshend, 2016) [2:08:20]

**Permanent pigment damage from lasers and peels done on the face**: [A review of laser and light therapy in melasma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5418955/) (Trivedi et al., 2017) [2:09:45]

**Reports of HIV from Vampire facials**: [Two Test Positive for HIV After ‘Vampire Facial’](https://www.webmd.com/hiv-aids/news/20190430/two-test-positive-for-hiv-after-vampire-facial) | Debbie Koenig (webmd.com) [2:09:45]

**A great resource for people considering plastic surgery**: [American Society of Plastic Surgeons](https://www.plasticsurgery.org/) | (plasticsurgery.org) [2:10:40]

§

## People Mentioned

- [Paul Conti](https://peterattiamd.com/paulconti/) (med school buddy) [8:30]
- [Eric Chehab](https://peterattiamd.com/ericchehab/) (talked about complications on The Drive) [11:00, 30:30]
- [Tara Reid](https://en.wikipedia.org/wiki/Tara_Reid) (actress with botched tummy tuck) [16:30]
- [Gil Kryger](https://www.drkryger.com/plastic-surgery-information-thousand-oaks/surgeons/gil-kryger-md/) (Zol’s partner and brother at his practice) [34:15]
- [Elizabeth Hall-Findlay](https://www.banffplasticsurgery.ca/about/dr-hall-findlay/) (called out the inherent bias of the doctors in the breast implant industry) [51:45]
- [Connie Chung](https://en.wikipedia.org/wiki/Connie_Chung) (NBC newscaster who brought women on to talk about silicone implants as the cause of their complications) [1:02:45]
- [William Halsted](https://en.wikipedia.org/wiki/William_Stewart_Halsted) (great mentor and great surgeon, founder of Johns Hopkins) [1:09:30]
- [Brian Regan](https://en.wikipedia.org/wiki/Brian_Regan_(comedian)) (comedian with the bit about never asking a woman if she’s pregnant) [1:17:45]
- [Rhonda Narins](https://www.narins.com/Our-Physicians) (dermatologist who was the first to offer lipo in the US) [1:30:00]
- [Kim Kardashian](https://en.wikipedia.org/wiki/Kim_Kardashian) (responsible for billions of dollars spent on butt lifts) [1:37:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/07/bio-image-for-zol-500x500.jpg)

##### Zol Kryger, M.D.

Zol Kryger, MD is a board certified Plastic Surgeon. He is a member of the American Society of Plastic Surgeons. Along with his brother, Gil Kryger MD, he founded the [Kryger Institute of Plastic Surgery](https://www.drkryger.com/).

He went to medical school at Stanford (with Peter) and then did his training in general surgery and plastic surgery at Northwestern in Chicago.

Dr. Kryger specializes in facial rejuvenation with fat grafting and the deep plane facelift and abdominoplasty with breast enhancement (the “mommy makeover”). Along with Gil, he has a strong interest in microsurgical procedures.

Zol grew up in Israel and after high school he served in an elite special forces unit of the Israeli Army specializing in reconnaissance.