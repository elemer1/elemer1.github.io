# #172 – Esther Perel: The effects of trauma, the role of narratives in shaping our worldview, and why we need to accept uncomfortable emotions

**Source:** [https://peterattiamd.com/estherperel/](https://peterattiamd.com/estherperel/)

---

Esther Perel is a psychotherapist and New York Times bestselling author who is an expert on modern relationships. In this episode, Esther describes how being a child of parents who narrowly survived the Holocaust shaped and influenced her perspectives and ultimately led to her to a career in therapy. She discusses how the generational differences in parenting, among other things, led to the rise of individualism with a focus on happiness and self-esteem to the detriment of our relationships and sense of community. Ultimately, the conversation focuses on the value of our relationships with others for one’s sense of wellbeing, ability to deal with past trauma, resilience, and even our lifespan. She uses real world case studies to emphasize the therapeutic value of creating healthy relationships with others and oneself, explaining how our relationships with others can be a mirror into our own maladaptive behaviors. Esther explains how our self-narratives, which are often shaped by past trauma, may negatively impact our relationships with others and our emotional health, and emphasizes the value in trying to change them when warranted. (You can find more information about Esther’s newest creation, Where Should We Begin: A Game of Stories with Esther Perel, [here](https://www.estherperel.com/where-should-we-begin-the-game).)

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/7be3O9ckZ1c)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/estherperel/the_Drive_public.png)

Play

#172 - Esther Perel: The effects of trauma, the role of narratives in shaping our worldview, and why we need to accept uncomfortable emotions

#172 - Esther Perel: The effects of trauma, the role of narratives in shaping our worldview, and why we need to accept uncomfortable emotions

1x15s30s

0:002:04:13

## We discuss:

- Esther’s background, adventures in hitchhiking, and how she ended up in the US [2:30];
- The lasting effects of the Holocaust on Esther’s parents [8:45];
- Grappling with a dark past and feeling alive again after trauma [16:45];
- How Esther came to understand her parents in a new light [23:15];
- Why Esther chose therapy as her career [30:00];
- Using the concept of sexuality to understand society, culture, and people [40:00];
- The significance of sexual revolutions, and the similarities of medical advancements and advancements in psychotherapy [50:15];
- The impact of the rise of individualism and the focus on happiness and self-esteem [56:00];
- Generational differences in parenting and changing role of fathers [1:09:15];
- How our narratives affect our sense of wellbeing and relationships with others, and the challenge of changing them [1:17:15];
- Generational effects of past trauma, and how relationships to others can be a mirror into your maladaptive behavior [1:30:30];
- The role of willpower in one’s ability change their behavior and improve their relationships [1:40:00];
- How your relationships impact longevity and the importance of being capable of sitting in uncomfortable emotions [1:43:45];
- Esther’s definition of resilience and the dangers of believing everything you think or feel [1:50:00];
- Questions about the human condition that Esther wants to explore [1:57:30]; and
- More.

§

## Show Notes

## Esther’s background, adventures in hitchhiking, and how she ended up in the US [2:30]

- Esther speaks 9 languages (and her English may have a slight New Jersey accent)
  - At school she was taught in Flemish, but at home her family also spoke French, Yiddish, German, and Polish
  - “And that just was the way it was, it’s the air that you breathe. Nobody made a big deal out of speaking all these languages and learning them”
- Grew up in Antwerp, Belgium
  - Her parents were immigrants who were both the sole survivors of the Holocaust in their families
  - They were were illegal refugees for about 5 years
- After high school Esther went to Hebrew University in Jerusalem
  - Finished her Master’s degree in expressive arts therapy at Lesley College in Boston and stayed in the US
  - She trained in family therapy at the Cambridge Family Institute and then worked at Mass Mental Health, a Harvard Medical School hospital (4:28)
- Between high school and college, at the time of the US bicentennial, Esther took a cheap cargo flight from Belgium and hitchhiked across the US with her boyfriend
  - “And I got invited into the homes of every kind of person that lives in this country, and the kindness of strangers, really, in ways that I probably would never have access to today”
  - She also hitchhiked in Mexico and from Mérida to Miami to Quebec and spent a summer in NYC in the late 1970s
- After studying in Boston she intended to experience NYC for one year, but she fell in love with the city (it was a place where she could “integrate the multiple parts of me”) and stayed

## The lasting effects of the Holocaust on Esther’s parents [8:45]

- All of her parents’ relatives died in the Holocaust: parents, siblings, nieces/nephews, etc.
  - Her father was one of 9, her mother one of 7, and all of their siblings were married with 7-10 kids, and all of them died
  - Each of one them lost about 200 relatives
  - They met on the Day of Liberation on the road where people were searching for others
- Peter asks how they survived: was it just luck? “The odds seem almost unimaginable” (9:35)
- They lived on the German side of Poland
  - The war started there in 1939 and lasted 6 years
  - Her mother hid in the woods for a year and then went to a labor camp so “at least she will wake up every morning in the same place”
  - Esther’s mother went to 9 different camps and her father to 14 over  the next 5 years
- They survived due to:
  - Luck (“I wasn’t selected every morning when they chose 1,000 people. Somehow they didn’t pick me”)
  - A strong will to live – maybe someone would be waiting for them at the end
  - Preserving their dignity and agency
    - “My mother describes mending her socks, folding her clothes, doing basic things that maintain their sense of humanity”
    - Her father created a black market for potatoes in the kitchen where he worked, feeding about 60 young people who survived because the food allowed them to keep working
      - “I think feeling that he could help others gave him a sense of agency, of mastery, of ‘I can do something here’”
- Esther is 12 years younger than her brother, and by the time she was born her parents ran a clothing store that they lived above
  - They were the immigrant family, but they were also part of the Jewish community where everyone had survived the Holocaust
  - She wondered why she didn’t have grandparents and aunts and uncles and why her parents had number tattoos
- Her parents were “peasant stock,” used to cold weather and hard labor, which made them better prepared to survive
- But Esther realized there are many details she didn’t ask about and doesn’t know: how did they get from one place to another?  Where did her mother find needles to mend her clothes?

> “Everything can disappear in a split second. Don’t ever think that what you have is there to stay and is yours. On the one hand, it prepares you for catastrophes, for disasters, for change. And on the other hand, you can never fully settle, you’re never fully calm, because you don’t know that the ground you sit on could not at any moment open up. That’s I think, probably the most important thing, is that sense of impermanence, the sense of loss … of not just people, but life, community, legacies, generations of stuff.” —Esther Perel

- Her parents wanted to do more than rebuild their lives
  - they loved life and parties, singing, and dancing
  - These experiences help Esther to understand both other people’s sense of loss and how one rebounds from it to love and celebrate again

## Grappling with a dark past and feeling alive again after trauma [16:45]

- Peter notes that it’s not only remarkable that Esther’s parents survived but also that they weren’t permanently scarred and managed to build a connected life
- Her mother sometimes had nightmares and “massive eruptions” and would check the door at night
  - At the time they called it “survivor syndrome” rather than PTSD
  - They certainly did not have access to modern treatments like [MDMA](https://en.wikipedia.org/wiki/MDMA)-assisted psychotherapy for [post traumatic stress disorder](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) (PTSD)
  - Her mother used spa treatments as therapy: [thalassotherapy](https://en.wikipedia.org/wiki/Thalassotherapy) (treatment with seawater), mud treatments, walking on wet grass, going from a hot bath to jets of frozen water

*⇒ See Peter’s newsletter:* [*MDMA for PTSD?*](https://peterattiamd.com/mdma-for-ptsd/)

> “I was interested in that very question: what made some people want to live? What feeds aliveness? What is this antidote to death or deadness? And I remember describing my observation between those who did not die and those who came back to life, those who could never trust and those who reconnected again, etc. I think …what my parents had was a strong sense of community.” —Esther Perel

- Survivors created a community
  - Many babies were conceived in the temporary DP camps because having children was a way of showing they were alive and could form a connection and there would be more of them
  - They came together in their collective, psychosocial trauma and had gatherings for people from the same town or camp
  - They could talk to each other in shorthand (“that camp was a bad camp”) and everyone knew the meaning behind it
  - But the native people in their new countries did not want to hear much about what they had been through
- Jews had other traumatic experiences in history and “came up with some of the most adaptive, resilient ways of going about things without ever seeing a shrink, without any access to mental health”
  - Her parents would talk with no affect about who had disappeared or been murdered in front of Esther as they played cards with their friends (today we would call it dissociation, which was a good natural defense)
  - The culture is collective in nature
  - Knew that being in nature was healing

## How Esther came to understand her parents in a new light [23:15]

- Esther recently wrote a [post](https://m.facebook.com/story.php?story_fbid=10158045097511711&id=161559836710&p=30) about Mother’s Day
  - There were both positives and negatives in Esther’s relationship with her mother, causing a feeling of ambivalence
  - Many people across cultures identified with Esther’s piece
- Her mother was superstitious and did not say good things to her children out of fear it would make them too proud
  - She saw her role as telling Esther what others would not, and she never said a good word to her
- Esther doesn’t think she could have written [*Mating in Captivity*](https://www.amazon.com/Mating-Captivity-Reconciling-Erotic-Domestic/dp/0060753633/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) when her mother was alive
  - Her mother challenged everything she did, so “I had to have confidence, one time for me and one time for her anxiety. … I had to have inside of me a sense that I knew that I can do it”
- Her dad was sweet, kind, and loving
- She later realized that her mother had to do a lot of the “dirty work” of parenting: the discipline and other less fun tasks
  - Her dad was able to act that way because her mom was forced into the disciplinarian role, allowing him to be the fun, kind one
  - Once she understood this, she began to see some of her dad’s faults too
- She experienced the ability to hold contradictory emotions at the same time
  - Ambivalence is the ability to say both “I love you, and I also have a lot of anger toward you”
  - Once she learned this, her mother no longer got under her skin
  - She would tell her mom she appreciated her trying to make Esther a better person, but she was where she needed to be and her mom should find someone else to improve
  - “I would laugh as I said it, instead of feeling the wrath mounting inside of me”

## Why Esther chose therapy as her career [30:00]

- Esther was first drawn to psychology
  - As a teen, she had a contentious relationship with her mother and was in a very traditional school system built around curriculum instead of students
    - She started to read authors who wrote about alternative theories in education and psychology: [Victor Frankl](https://en.wikipedia.org/wiki/Viktor_Frankl), [Bruno Bettelheim](https://en.wikipedia.org/wiki/Bruno_Bettelheim), [R.D. Laing](https://en.wikipedia.org/wiki/R._D._Laing), and [A.S. Neill](https://en.wikipedia.org/wiki/A._S._Neill)’s [book](https://en.wikipedia.org/wiki/Summerhill_(book)) about the [Summerhill School](https://en.wikipedia.org/wiki/Summerhill_School)
  - She wondered why she had dreams about Nazis when she personally had not gone through it
  - She wanted to disappear so her mother would think she had lost her and she could find out if her mother really cared about her
  - She wondered why she felt that way and started to get interested in psychology
- Realized she was good at it: friends confided in her because she could see what wasn’t visible in relationships
  - Others thought she should be an interpreter or journalist or lawyer, but she decided psychotherapy would be an interesting profession
- Her first job was at a hospital as an expressive arts therapist on the psychiatric unit because she had theater and puppetry experience
  - She worked with groups for two years, but she felt like the profession wasn’t valued and she was at the bottom of the totem pole
- Her colleague and now-husband [Jack Saul](https://ac4link.ei.columbia.edu/profiles/detail/43) suggested family therapy because it was more contextual, anthropological, and intercultural

> “I was writing about culture, religious and racial identity. … I needed a field that was more expansive. The revolution was to begin to think in systemic terms, away from the individual intrapsychic model into the interpersonal and societal or contextual model. That just opened up a gate for me.” —Esther Perel

- She had been doing sessions with patients and their families and was interested in the function the patient played in their family
  - Things are interconnected: feelings are related to family dynamics and intergenerational transmission
  - “You constantly are studying yourself as you are learning the paradigm”
- Peter reflects that in medicine, your residency is really the only training you get
- Esther says that in clinical psychology, you can continue to learn more modalities
  - For example, there were five schools of family therapy (including structural, strategic, feminist, and intergenerational) and it could take 10 years to learn them
  - Neuroscience has become important to learn now

> “Basically, if you are a curious person, in mental health and in psychotherapy per se, which is one practice of mental health, it is an endless, endless school.” —Esther Perel

- Psychology has [continuing education unit](https://en.wikipedia.org/wiki/Continuing_education_unit) (CEU) requirements, but there is an incentive to learn all the time
- First something is a new paradigm, then it becomes dominant for a decade or so, and then a new paradigm comes along
  - The time that someone enters the field has a large influence on what they do
  - “If I was in the late 19th century, I would have been a psychoanalyst. … It shows you the social construct of those fields. They are sciences and they are humanities, but they are also completely immersed in the context of the moment”
- Peter says CEUs on medicine are really just to maintain one’s license, but he doesn’t think they teach much valuable content
  - He prefers the ones outside his areas of expertise so he can learn something

## Using the concept of sexuality to understand society, culture, and people [40:00]

**Seeking mentors**

- Because her mother was so critical, Esther sought out mentors (“I was drawn to people who believed in me”)
  - She got to learn from incredible clinicians
  - In NY she met one of her main mentors, [Salvador Minuchin](https://en.wikipedia.org/wiki/Salvador_Minuchin)
  - He and another of Esther’s primary mentors have both died in the past 2 years

**Transitioned to outpatient clients with a focus on interracial couples**

- She switched to private practice as she was dealing with immigration and paperwork issues
  - He built up a practice and was also teaching at NYU
  - Because of her mastery of multiple languages, she had built up a specialty working with couples and families who were “mixed” in various ways: intercultural, interracial, inter-religious

**How the Bill Clinton scandal impacted Esther**

- When the Clinton scandal happened, Esther wanted a new topic to explore
  - She likes interdisciplinary topics that span theology, anthropology, sociology, and psychology
  - She was interested in what the Clinton scandal said about American attitudes towards sexuality, especially as a national political agenda
- An [article](https://web.archive.org/web/20141021042018/http:/www.estherperel.com/wp-content/uploads/2011/01/networker_perel.pdf) she wrote in 2003 talked about being at a conference and noting the differences in attitudes towards sexuality between Americans and non-Americans
  - Esther says Americans see sex itself as a risk factor while Europeans view sex as a natural part of human development and being irresponsible as the risk factor
  - She sees cultural differences on this issue in psychotherapy
- In the American model, sex was rarely discussed in couples therapy
  - the idea was that sexual problems are caused by relationship problems and thus to solve sexual problems you need to work on the relationship
  - Esther says this is sometimes true but not always
  - A conference about sexuality would not use words pleasure, sexual connection, or eroticism
  - When she read the psychology literature in other languages she found different ways of addressing sexuality
  - The way sexuality is viewed is a lens to understand more about a society

***How is sexuality a lens into society?***

- Esther sees sexuality is a vehicle to understand more about people, society, and culture
- Ester was influenced by [Octavio Paz](https://en.wikipedia.org/wiki/Octavio_Paz)‘s [*The Double Flame: Love and Eroticism*](https://www.amazon.com/Double-Flame-Love-Eroticism/dp/0151001030/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - Paz distinguishes sexuality and eroticism
  - analyzes how religion has intersected with sexuality
- Esther points out that a culture’s most rooted / archaic aspects are often related to the sexuality of women and children
  - While revolutions and radical changes also have to do with sexuality as related to industrialization and scientific developments

> “I think sexuality is a lens. It tells a story of the values, the behaviors, and the attitudes towards the body, towards pleasure, towards power, towards connection, towards the division of spirits and flesh, or mind and body, or all of those things.” —Esther Perel

- Historically, women in psychiatric hospitals labeled“hysterical” were often victims of sexual abuse, and in some ways it was safer for them to be in the hospital than to go back to where they’d be abused

**The impact of the development of birth control pills**

- Peter believes that the birth control pill “is one of the most underappreciated, highest [return on investment] ([ROI](https://en.wikipedia.org/wiki/Return_on_investment)), philanthropic developments ever”
  - Peter thinks the cost of developing it (in today’s dollars) was less than a hundred million dollars
  - A woman named [Katharine McCormick](https://en.wikipedia.org/wiki/Katharine_McCormick) partnered with a Harvard scientist named [Gregory Pincus](https://en.wikipedia.org/wiki/Gregory_Goodwin_Pincus) and funded much of his work

> “It’s one of the few things where there’s no ambiguity about the impact it had. So if you look at pre-birth control versus post-birth control, you look at the number of women that have advanced degrees, the average income of women. I mean, these things changed, not subtly, but logarithmically” —Peter Attia

## The significance of sexual revolutions, and the similarities of medical advancements and advancements in psychotherapy [50:15]

- Esther believes there were 3 key sexual revolutions:
  - 1) birth control,
  - 2) the gay rights movement, and
  - 3) the women’s movement
- Democratization of birth control
  - Did more than transform women’s education and work opportunities
  - Allowed separation of sex and reproduction, which was a first in human history
  - now we are separating anatomy from gender, which is another conceptual revolution
- The gay rights movement
  - “Once we were able to have sex before marriage, we basically began to queer our relationships”
  - Gay people now pursue traditionally straight goals like marriage
  - Depathologizing homosexuality and removing it from the DSM in 1973 was a huge change
  - Sexuality had long been organized around the notion of what is normal or acceptable
  - “The history of sexuality is a fascinating history of society and cultures”
- The women’s movement
  - Emergence of the concept that sexuality is not just a woman’s marital duty – it’s about desire
  - this is interconnected with the growth of capitalism
- [Michel Foucault](https://en.wikipedia.org/wiki/Michel_Foucault)’s [*The History of Sexuality*](https://en.wikipedia.org/wiki/The_History_of_Sexuality) is really about our attitudes towards children, women, old age, pleasure, agency, and religion
  - Similar to the history of medicine, it’s a lens into culture
  - “*It’s the history of so many things that is being mediated through the history of sexuality. That’s what I mean by it’s a lens into culture, but you probably could say the same thing about the history of medicine*.”

**How the genetic revolution changed how we saw each other [54:16]**

- Peter thinks there are three main eras in medicine
  - Started out very unscientific
  - Then science advanced and we developed germ theory (“perhaps the first and most salient advent within medicine”) and we could dismiss old ideas about things like bad humors
  - The genetic revolution and decoding the human genome was another key advancement
    - It was also a big step forward from a cultural standpoint (“we now realize how similar we all are”)
    - Advances in genetics also made us realize that genes are not as deterministic as we thought
    - The environment is very important, and differences between us are likely epigenetic or not modulated genetically
- Esther says psychotherapy is similar
  - Just as medicine looks at contextual factors like the environment and social class, psychology takes a non-essentialist view of a person
  - You are formed by your interaction with others in specific places at certain times
  - It’s the same paradigm as saying genes are impacted by multiple factors in the environment

## The impact of the rise of individualism and the focus on happiness and self-esteem [56:00]

- Peter mentions the [Felix Adler](https://en.wikipedia.org/wiki/Felix_Adler_(professor)) [quote](https://www.gutenberg.org/files/37697/37697-h/37697-h.htm) about the purpose of life being not happiness but worthiness
  - Esther says happiness cannot be a purpose, it is an outcome; “*it emerges out of something, it’s not the goal*”
  - The notion of happiness is cultural and historical
    - For a long time, life was seen as suffering and happiness was meant for the afterlife
    - “When did we bring happiness to earth?”
  - Esther met [Richard Layard](https://en.wikipedia.org/wiki/Richard_Layard,_Baron_Layard), the author of [*Happiness: Lessons from a New Science*](https://www.amazon.com/Happiness-Lessons-Science-Richard-Layard/dp/1594200394/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), who said that western parents now say they want most for their kids to be happy, which is a recent concept
  - Maybe it’s because we take so much for granted, like their health
- Contraception didn’t just change sexuality, it also changed what it means to have a child
  - An only child plays a very different role in the family than a child who is one of ten
  - When child mortality was high, the goal was simply to have them make it to age 5
  - Once child mortality improved, we looked at child development very differently and started developing theories of child attachment
- When you say “I want my kids to be happy,” it implies that it’s a given that they are healthy
  - Many parents would also say they want their kids to be good people, but they assume that if their kids feel good about themselves, they will be good to others
  - It’s a new paradigm for self-esteem rather than values to become the root of it

**The rise of individualism and the focus on self-esteem [59:45]**

- Peter wonders when the transition to a self-esteem-based worldview began
- Peter’s parents were also immigrants who did not think you should puff your chest out and never did not tell him how wonderful and special he was
  - [Bill Maher](https://en.wikipedia.org/wiki/Bill_Maher), one of Peter’s favorite commentators on this subject, notes that if a teacher complained about him to his parents, his parents assumed it was his fault
  - Now, if a teacher complains about a kid, the parents blame the teacher
  - Although there may be situations where the teacher is wrong, the trend is towards assuming the child is always right
- Esther thinks the rise of individualism goes hand-in-hand with modern economies and psychology
  - Traditionally, your identity and sense of belonging were assigned to you as part of a community
    - Big decisions like your occupation were made for you
    - We had much less freedom but also less uncertainty
    - “*You got your happiness or your sense of well-being from doing the things that were expected from you*.”
    - Being a good provider or caretaker and being respected in the community were sources of satisfaction
  - We moved to a system in which the individual becomes the center, says Esther
    - We now have a lot more freedom, but this comes with more uncertainty and self-doubt
    - You get to make the big decisions yourself but it’s hard to know what the right one is
- There were different stages of this transition to individualism
  - Begins with romanticism at the end of the 19th century
  - The 1960s are the beginning of the growth movement in modern psychology
    - The goal is no longer to stay connected to tradition and the past but to innovate and uproot oneself if it’s necessary to do more
    - If you’re 2 years old, you’re not just learning what others are doing by watching them but being asked what to want to eat or wear
  - This is a western model and very new in evolutionary history
- Peter uses an analogy of what happens when you introduce food that our evolutionary biology didn’t evolve for — E.g., Our bodies are not designed for the quantities of sugar we eat now; we might someday adapt to it but it could take a million years
  - Peter asks Esther whether this new focus on the individual self has similar negative evolutionary consequences?
- Esther says that we do actually know the consequences of how child rearing is creating strengths and vulnerabilities in our generation
  - We suddenly have a proliferation of work and research on the concept of grit because it’s not a trait many kids learn in childhood
  - “*There’s an absence of grit in growing up*.” says Peter
- Immigrant parents often adopt a mix of practices from their new culture and the one they came from
  - But even for non-immigrants, culturally we are also in transition in terms of child rearing

> “What does it mean to have a system in which there is one or two children for two parents who often are disconnected from their grandparents, live far away, have full-time jobs and need to assume all those roles? And if you add the pandemic to it and the confinement, you get a real picture of what those stressors are like.” —Esther Perel

- We now solicit the opinions and preferences of children and expect that adults will accommodate them
  - Parenting books are not written to make parents’ lives easier but to ask what the children need
  - [Benjamin Spock](https://en.wikipedia.org/wiki/Benjamin_Spock)’s books were a real transition point
  - Until about the 1960s, [Rousseau](https://en.wikipedia.org/wiki/Jean-Jacques_Rousseau)’s view that “your role is to shepherd this child through the pre-established stages of development” was common
  - We now believe child development is much more flexible and responsive to circumstances
    - We think playing Mozart to babies *in utero* will affect them
    - We expect childcare providers to do the same things the parents do (“need mass reproducible child rearing techniques”)
    - In this model, a lot more depends on the parents

## Generational differences in parenting and changing role of fathers [1:09:15]

- There are different narratives around who is responsible for one’s happiness

> “In an environment where you expect your parents to be attuned to you, if they are not, you will experience your aloneness, your isolation, your emotional disconnection very different than in an environment where the attunement of your parents is really not part of your expectation on an emotional level.” —Esther Perel

- Esther has a patient who feels that his father has been always critical of him and he could never be good enough for him
  - Esther wondered if this would have happened 100 years ago
  - Probably, but he would not have been able to speak to a therapist about it and would not have expected his father to apologize to him
  - 100 years ago, the father would have said it was not to make his son feel good about himself but instead to make him a responsible person who fulfills his role
  - There are different cultural expectations about the role of a parent
- There are also generational differences, especially about the role of fathers,  who are expected to take on much more of an emotional role now
  - Peter’s parents used to argue about his father’s absences from his sports games or school events
    - His dad worked 14 hours a day 6 days a week and 8 hours on the seventh day
    - He had no time and was incredulous that he would be expected attend such events
    - His father was not at Peter’s high school graduation, although he did attend Peter’s wedding and college and medical school graduations
    - He believed his duty towards his family was to work, which was likely an extension of the culture he grew up in where it was very harsh
  - Esther points out that Peter’s dad is like the majority of global fathers today
    - An idea was passed down that fathers did not need to be at their kids’ high school graduations
    - Peter will attend many more events as an American dad of his generation, but in other places only mothers are expected to attend kids’ events
  - When Peter visited his friends’ houses when he was growing up, he thought their dads were lazy because they were home for dinner or on weekends
    - Esther says both Peter and his dad were taught to think this way, and his father “needed some way to justify why he was working himself to the ground. If you want to get a man to work day and night, you have to make him feel that this is what real men do. This is what responsible fathers look like”
    - Esther notes it’s the idea that working is what driven people do (just like the name of Peter’s podcast)
    - As the son, Peter needs that narrative so he won’t ask why he doesn’t have the time with his dad that his friends do but instead feel proud of his hardworking father

## How our narratives affect our sense of wellbeing and relationships with others, and the challenge of changing them [1:17:15]

- Esther doesn’t believe you can really improve your life by focusing on your relationship with yourself only
  - Esther thinks “the very framework of bettering your relationship with yourself is in itself a cultural narrative”
  - In the last 50 years or so, the organizing principle changed from how I stand below God or how I act towards others to feeling good about myself
  - Her emphasis is the constant dual track between the intrapersonal and the interpersonal

> “I don’t fundamentally believe that one can know oneself without knowing oneself in relationships to others.” —Esther Perel

- But Esther recognizes that her relational thinking is itself a construct
- The narratives we use to give meaning and value to things always come from both collective meaning and our personal responses to them

**Developing and changing narratives about our lives [1:20:00]**

- Peter thinks people often show up at an office – both medical and psychotherapy – with a narrative
  - People don’t come to Esther to say they feel good any more than they go to the doctor for that – on some level there is an entrenched narrative that has failed
  - Esther says many couples come to therapy way too late, after things have become too entrenched, but it also doesn’t make sense to go too early
- Relationships are like stories that need a different perspective
  - Esther’s goal is that by the end of the first session they leave with another story – or at least knowing there can be another story
  - A large part of her work is reframing
    - If she feels like Peter isn’t interested and wishes he could stop the interview, she will get a knot in her stomach and her feelings will begin to impact how she acts
    - The narrative becomes her experience
    - She’d have a very different experience if she felt that Peter was very happy with how the interview was going
  - Peter asks if it matters which story is true
    - Esther says the reality is subjective – it’s whichever story she tells herself because her story is independent of what Peter is actually thinking
    - Reframing doesn’t mean saying that this narrative is more true, it means finding a narrative that works better

**The two most fundamental narratives rooted in trauma**

- The two most fundamental narratives rooted in trauma or neglect (having too much or too little of something):
  - Being unwanted or unloved or unappreciated
  - Looking for appreciation and acceptance

> “Those two are probably the most fundamental of our narratives and they are rooted in trauma and in neglect and in having had too much of something or too little of something. This is pretty much where trauma sits.” —Esther Perel

- They are all interconnected with fundamental questions like: Why am I here? Do people think of me when I’m not there? Do I exist inside others?
- “*It will influence my anger, my sadness, my loneliness*.”
- These narratives are also related to whether you feel a sense of agency and control over your life or you feel powerless to make changes
- “*The stories, thousands of stories, multitude of different stories can be brought back to these two fundamental pieces*.”

## Generational effects of past trauma, and how relationships to others can be a mirror into your maladaptive behavior [1:30:30]

- Many trauma-induced narratives are initially adaptive
- What is the adaptation for the narrative of feeling unworthy or unwanted?
- Esther gives the example of a father who was himself the child of Holocaust survivors
  - He says he makes sure his kids know how to take a train and bus by age 8 because he’s very protective
  - To many people that makes no sense, but it made sense to Esther because she is also a child of Holocaust survivors
  - To them, being protective means making sure the kids can survive without you
- Esther’s parents told stories so their kids would understand that in the camps, the vulnerable died
  - There’s a sense of unease when kids show vulnerability
  - There’s a mentality of “If you’re not dying, there is no reason to stay in your bed”
  - This was adaptive for Esther’s mom but not so much for her; she was raising her kids in very different circumstances
- Part of trauma healing is to understand that you are reacting as if  the past were happening right now and creating a new way of experiencing yourself that is not driven by the horrible things that happened to you in the past

> “Once you have an adaptation to cope with trauma, it selects, it’s reinforcing itself, it’s making you stronger and stronger and pushing you further and further. And you might miss the fact that it’s become maladaptive” —Peter Attia

- Relationships with others can be the mirror that shows you that your approach is now maladaptive
  - “you’re still holding an umbrella, even though there is no rain”
  - Not getting close to people was a reasonable adaptation during the war, but it also meant they were not close to their own children, who felt like they could never win their parents’ love or replace their dead relatives
  - Both sides need to understand why this dynamic happens
- Peter wonders why some people can transition to a new narrative and others can’t
- Peter gives an example from medicine
  - 100 women with breast cancer who all receive comparable care
  - You can predict how many will live and how many will not based primarily on the biology of their cancer
  - “I really do not believe that the person who lived wanted it more and the person who died gave up. I’ve seen too many people who fought like hell who died. And I’ve seen too many miserable sons of bitches who didn’t give damn who lived”
  - Survivorship in cancer comes down to luck and biology
  - It is true that the patient can do some things to help: nutrition, exercise, stress management, etc., but their will does not change the outcome
- So what does it come down to in psychology? Why can some people switch their maladaptive narratives while others can’t?
- Esther says it is a mystery: unlike Peter’s medical example, it’s not clear what the factors are

## The role of willpower in one’s ability change their behavior and improve their relationships [1:40:00]

- In interpersonal relationships, will does not exist only inside one individual
- They key to couples therapy is the moment when each partner becomes less interested in what the other one is doing wrong and more interested in how they can do better
  - For example, if one partner is able to recognize and articulate that they have not been able to be close to their partner because they have lost so many people that love feels transient and risky
  - Now things depend on not only this person’s recognition of the issue but also how the other person responds
    - Could be with anger (“NOW you’re telling me this?”) or “I need to sit and think about this for a while” or “But you haven’t acknowledged the effect this has on me” or “I wanted to hear you say this; I understand that is related to your past rather than anything I’ve done”
    - The will of the first person “is completely malleable and will change and express itself differently at the mercy of the response of the other person”

## How your relationships impact longevity and the importance of being capable of sitting in uncomfortable emotions [1:43:45]

- Peter says this factors into longevity in two ways:
  - Biochemically: in theory if your relationships are better you would have better hormone levels (e.g., cortisol)
  - But also, longevity has limited advantages if your relationships and thus the quality of your life is poor
- Peter reflects that he has recognized the importance of being able to sit with uncomfortable emotions
  - He would obsessively buy things or exercise
  - or even burst out in anger
    - as he discussed on his [podcast](https://peterattiamd.com/terryreal/) with [Terry Real](https://terryreal.com/about/), anger can in fact be quite numbing
    - it squelches feelings of inadequacy, loss of control, and sadness
  - The psychologist [Susan David](https://en.wikipedia.org/wiki/Susan_David) gave a [TED talk](https://www.amazon.com/Happiness-Memoir-Crooked-Little-Semi-Ever/dp/1250131561) about how dealing with uncomfortable emotions is the price of having a meaningful life
    - If you don’t feel uncomfortable emotions, you are essentially dead
    - Susan has been a guest on Esther’s training platform

> “The idea that this is what you feel and that doesn’t mean you have to act on it or do something or chase it away or make it disappear. This is your experience in this moment.” —Esther Perel

- Try to understand it, name it, put it in context, etc., rather than be contemptuous and judgmental of your inner life

- Esther finds it fascinating to see someone alone and then again with their partner
  - It’s a different story when things play out between two people
  - “It’s like I’ve just spent time in one room of the house and I didn’t even know there was a whole annex to that house”
  - It makes you understand the difference between the relational thinking that Terry teaches about and the individual perspective
- A mistake many people make is to only live in one, but the integration of the relational and individual perspectives is “where the nexus of my work sits”

## Esther’s definition of resilience and the dangers of believing everything you think or feel [1:50:00]

- Peter’s friend, the psychologist [Jim Kochalka](https://www.oncourseinternational.com/jim-kochalka/), said “You can’t believe everything you think. You can’t believe everything you feel. The mind is a very dangerous organ.”
  - mindfulness meditation teaches you that you are not your thoughts
  - You are not your feelings either: a lot of these narratives that we have about ourselves and others are surprisingly well-worn
- Esther says our thoughts and narratives are constructs
  - Sometime people’s minds try to convince them that they feel nothing and are not hurt
  - But they are frozen or trying not to show they’re upset or attached to someone
  - When someone insists they’re not hurt, they often are
- Susan David once said, “The key to resilience is the radical acceptance of all emotion”
  - Esther thinks that’s mostly true, but it is based on an individual definition of resilience as something internal, a personality trait

> “But resilience is also our ability to face adversity in a way that allows us to rebound and then to re-engage with life.” —Esther Perel

- Resilience is a combination of not only what was inside them but also community, luck, their experiences before the war, etc.
  - Sometimes resilience is not what’s inside you but what’s around you: an ability to ask for help and tap into collective resources
  - She gives an example of a boy who ran next door to call police when there was violence in his house
    - He felt like it was the ultimate betrayal to leave his mother with his father in that situation
    - His therapist reframed it by pointing out that it was more helpful to his mother for a 9-year-old to bring in police who could help much more than he could, so his leaving her to call was a loving act

> “Now, is it true? It only depends if the person bites, if they take that story in and that story replaces another story and gives them a completely different sense of what they did and what it meant and what the consequences were. Therefore, it is true.” —Esther Perel

- This is a different picture of resilience and shows the power of narrative – it’s not just accepting all emotions

## Questions about the human condition that Ether wants to explore [1:57:30]

- After a recent session Esther noted that it had taken she and her patient 3 years to reach that point
- Sometimes she wonders what more they can talk about, “and then we just open and stumble on something”

> “It’s less about what I want to learn about the human condition, as how deep can I go? How deep can we go in a conversation, in understanding the vast continent that is the human being?” —Esther Perel

- She is also very interested in why some people appear resilient while others don’t
  - How do people in seemingly dire circumstances end up being successful?
  - Many of them had someone in their lives (teacher, neighbor, family friend) who “saw that thing that nobody else was seeing” and taught or mentored them
    - those who struggle remained at the center of their life all the time
    - it’s about connection and relationships

> “It’s someone in your ecosphere that put that hand out and you took it. Many times people put the hand out, but the people don’t take it. Or they take it and then they let it go. And then they drown. They held it. They held it when there was absolutely overtly no reason to want to hold on to it. I find that a very important moment in our life. And many of us have had moments like this.” —Esther Perel

§

## Selected Links / Related Material

**A game designed by Esther designed to unlock the storyteller within**: [Where Should We Begin: A Game of Stories with Esther Perel](https://docs.google.com/document/d/1cHJVOSdX6DaHdJyQTKZ2QUfHvR-Zm-b-p7jeXmzvacQ/edit)

**Esther’s work mentioned in the introduction:**

- **Books**

- - - [The State of Affairs: Rethinking Infidelity](https://www.amazon.com/State-Affairs-Rethinking-Infidelity/dp/0062322583) (2017)
    - [Mating in Captivity: Reconciling the Erotic and the Domestic](https://www.amazon.com/Mating-Captivity-Reconciling-Erotic-Domestic/dp/0060753633/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2006)

- **TED talks**

- - - [The routines, rituals, and boundaries we need in stressful times](https://www.ted.com/talks/esther_perel_the_routines_rituals_and_boundaries_we_need_in_stressful_times) | TED Salon: DWEN (March 2021)
    - [Rethinking infidelity … a talk for anyone who has ever loved](https://www.ted.com/talks/esther_perel_rethinking_infidelity_a_talk_for_anyone_who_has_ever_loved#t-615) | TED2015 (March 2015)
    - [The secret to desire in a long-term relationship](https://www.ted.com/talks/esther_perel_the_secret_to_desire_in_a_long_term_relationship#t-5963) | TEDSalon NY2013 (February 2013)

- **Podcasts**

- - - [Where should we begin? A podcast for anyone who has ever loved](https://whereshouldwebegin.estherperel.com/)
    - [How’s Work?](https://howswork.estherperel.com/)

- **Talks at South by Southwest**

- - [Esther Perel on Workplace Dynamics](https://www.youtube.com/watch?v=0PqWQl2AJpQ) | SXSW 2019 (March 2019)
  - [Modern Love and Relationships](https://www.youtube.com/watch?v=5iu9_8Vsmtk) | SXSW 2018 (March 2018)

**Esther’s Mother’s Day post**: [For those grieving their mothers](https://m.facebook.com/story.php?story_fbid=10158045097511711&id=161559836710&p=30) | *Facebook* (May 9, 2021) | [23:15]

**Book Esther read on alternative education**: [Summerhill: A radical approach to child rearing](https://en.wikipedia.org/wiki/Summerhill_(book)) by A. S. Neill (1960) | [30:30]

**Esther’s viral article about cultural differences in attitudes towards sex**: [Erotic Intelligence: Reconciling Sensuality and Domesticity](https://web.archive.org/web/20141021042018/http:/www.estherperel.com/wp-content/uploads/2011/01/networker_perel.pdf) *Psychotherapy Networker* (May/Jun 2003) | reprinted as [In Search of Erotic Intelligence](https://www.utne.com/community/in-search-of-erotic-intelligence/) *Utne Reader* | [43:15]

**Book that influenced Esther**: [The Double Flame: Love and Eroticism](https://www.amazon.com/Double-Flame-Love-Eroticism/dp/0151001030/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Octavio Paz (1995) | [46:15]

**Book showing how attitudes about sexuality are a lens into culture**: [The History of Sexuality](https://en.wikipedia.org/wiki/The_History_of_Sexuality) by Michel Foucault (four volumes published 1976-2018) | [53:00]

**Book whose author talked to Esther about self-esteem parenting**: [Happiness: Lessons from a New Science](https://www.amazon.com/Happiness-Lessons-Science-Richard-Layard/dp/1594200394/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Richard Layard (2005) | [57:45]

**Susan David’s TED Talk**: [The gift and power of emotional courage](https://www.youtube.com/watch?v=NDQ1Mi5I4rg) Susan David, TED (February 2018) | [1:46:00]

**Peter’s podcast with Terry Real**: [#119 – Terry Real: Breaking the cycle of shame, anger, and depression](https://peterattiamd.com/terryreal/) [*The Drive*](https://peterattiamd.com/podcast/), Peter Attia (July 13, 2020) | [1:45:15]

§

## People Mentioned

- [Victor Frankl](https://en.wikipedia.org/wiki/Viktor_Frankl) [30:30]
- [Bruno Bettelheim](https://en.wikipedia.org/wiki/Bruno_Bettelheim) [30:30]
- [R.D. Laing](https://en.wikipedia.org/wiki/R._D._Laing) [30:30]
- [A.S. Neill](https://en.wikipedia.org/wiki/A._S._Neill) [30:30]
- [Jack Saul](https://ac4link.ei.columbia.edu/profiles/detail/43) [33:15]
- [Salvador Minuchin](https://en.wikipedia.org/wiki/Salvador_Minuchin) [41:15]
- [Octavio Paz](https://en.wikipedia.org/wiki/Octavio_Paz) [46:15]
- [Katharine McCormick](https://en.wikipedia.org/wiki/Katharine_McCormick) [49:00]
- [Gregory Pincus](https://en.wikipedia.org/wiki/Gregory_Goodwin_Pincus) [49:00, 49:45]
- [Michel Foucault](https://en.wikipedia.org/wiki/Michel_Foucault) [53:00, 49:45]
- [Felix Adler](https://en.wikipedia.org/wiki/Felix_Adler_(professor)) [56:30]
- [Richard Layard](https://en.wikipedia.org/wiki/Richard_Layard,_Baron_Layard) [58:00]
- [Benjamin Spock](https://en.wikipedia.org/wiki/Benjamin_Spock) [1:07:45]
- [Jean-Jacques Rousseau](https://en.wikipedia.org/wiki/Jean-Jacques_Rousseau) [1:08:00]
- [Terry Real](https://terryreal.com/about/) [1:45:15]
- [Susan David](https://en.wikipedia.org/wiki/Susan_David) [1:45:45, 1:46:30]
- [Jim Kochalka](https://www.oncourseinternational.com/jim-kochalka/) [1:50:00, 1:50:30]

§

![](https://peterattiamd.com/wp-content/uploads/2021/08/1x1-estherperel-500x500.jpg)

##### Esther Perel

Esther Perel is a psychotherapist and *New York Times* bestselling author who is an expert on modern relationships.  A child of Holocaust survivors who is fluent in nine languages, she has been in private practice in NYC for more than 35 years and works as an organizational consultant for Fortune 500 companies globally. Her popular TED Talks have been viewed more than 30 million times and she is the host of two podcasts, *Where Should We Begin?* and [*How’s Work?*](https://howswork.estherperel.com/)

Website: [estherperel.com](https://www.estherperel.com/)

Twitter: [@EstherPerel](https://twitter.com/EstherPerel)

Instagram: [@estherperelofficial](https://www.instagram.com/estherperelofficial/?hl=en)