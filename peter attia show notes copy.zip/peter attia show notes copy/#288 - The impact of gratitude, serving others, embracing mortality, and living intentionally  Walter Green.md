# #288 ‒ The impact of gratitude, serving others, embracing mortality, and living intentionally | Walter Green

**Source:** [https://peterattiamd.com/waltergreen/](https://peterattiamd.com/waltergreen/)

---

Walter Green is a remarkable philanthropist, mentor, author of [This Is the Moment!](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1), and founder of the impactful “[Say It Now](https://www.justsayitnow.org/)” movement. In this episode, Walter delves into the unique insights gained from his challenging upbringing, discusses embracing mortality, and highlights the mindset of “finishing strong.” He shares insights on intentionality, thinking in reverse, saying “no,” prioritizing relationships, and the essence of focusing on others. The conversation focuses on the “Say It Now” movement, which stresses the importance of expressing sentiments to loved ones well before the end of life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/waltergreen/the_Drive_public.png)

Play

#288 ‒ The impact of gratitude, serving others, embracing mortality, and living intentionally | Walter Green

#288 ‒ The impact of gratitude, serving others, embracing mortality, and living intentionally | Walter Green

1x15s30s

0:001:32:21

## We discuss:

- How Peter and Walter met through Ric Elias [2:45];
- The unique perspectives and life lessons provided by Walter’s challenging childhood [5:30];
- Walter’s harrowing experience with a sudden mental breakdown and his subsequent recovery with the help of therapy [11:15];
- A diverse professional journey ending in great success [18:15];
- The birth of a movement: celebrating friendships through public tributes and expressing gratitude to those who have shaped your life’s journey [22:30];
- Intentionality, thinking in reverse, saying “no”, and other guiding principles for Walter [30:00];
- Walter’s global journey of gratitude on his 70th birthday, visiting friends, and creating memorable experiences [39:15];
- The profound impact of acknowledging and expressing gratitude for the people who contribute to our lives [46:15];
- The key elements for creating meaningful connections and cultivating deep, authentic friendships [52:15];
- The “Say It Now” movement: the inspiration behind the remarkably impactful initiative [58:30];
- What “finishing strong” means to Walter [1:07:30];
- Finding peace at the end of life through expressing gratitude and finding purpose in serving others [1:16:00];
- Resources to learn about “Say It Now” [1:26:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Walter Green is a philanthropist, mentor to many, and teacher
- He is the founder of the “Say It Now” movement and the author of [*This Is the Moment!: How One Man’s Yearlong Journey Captured the Power of Extraordinary Gratitude*](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1)
- Walter is the former chairman and CEO of Harrison Conference Services, where he created the country’s leading network of executive conference centers
  - But that’s not what we’re here to talk about today
- Peter met Walter about 2 years ago at an event curated by a close friend ([Ric Elias](https://www.ted.com/speakers/ric_elias), a previous guest on the podcast)
- The things that Walter spoke about that evening really stood out to Peter
  - A little while after that, Peter told him that he really wanted to sit down with him and share his story
- In the conversation today, we talk about his background and upbringing, and how it shaped him
- We discuss coming to grips with death, having peace at the end of life, and the mindset of finishing strong
- We cover the value of time, the importance of saying “no,” focusing on relationships over success, and why it’s important to focus on others instead of ourselves
- Walter speaks about his “Say It Now” movement, and why he believes it’s so important that we say things to people that matter to us long before the end of life
  - In particular, this is something that really struck Peter
- This is obviously not an episode that deals with a scientific topic, but nevertheless, it is a very important part of the emotional health/ mental health journey that is equally important to many of the typical things that we discuss on this podcast

## How Peter and Walter met through Ric Elias [2:45]

- Peter met Walter at the home party of a very close mutual friend, [Ric Elias](https://www.ted.com/speakers/ric_elias) (whose also been a guest on this [podcast](https://peterattiamd.com/ricelias2/))
  - Ric held a very special 2-day event where he brought together a handful of his closest friends for no other reason than to let them meet each other
- Exactly as Ric planned, Peter is still in touch with a number of people he met there
- Walter agrees, “*If you can give the gift of a special relationship to people you care about, there is no more beautiful gift.*”
- Everybody knew each other because we all knew Ric
- It was a very intimate setting where they shared many meals over 30 hours, and Peter sat next to Walter for one of the meals
- Walter’s son and Ric’s son went to business school together
- Their conversation pivoted from that connection to what Walter is really passionate about, which is what we will talk about today

## The unique perspectives and life lessons provided by Walter’s challenging childhood [5:30]

**Walter divides his life into 3 stages of 28-29 years**

- Walter is in a very reflective mood at this age and has been thinking about his life
- He’ll be 85 next month
- 1 – The first 28-29 years were spent finding himself, just big picture
- 2 – The next 29 years were making himself
- 3 – The last 29 years he has spent becoming himself
- Peter remarks, “*We’re talking a lot about the insights that have come in the 3rd phase, but I suspect the seeds of those were sown in the 1st phase*.”

**What was your childhood like and where was it?**

- Walter was born in 1938 at the tail end of the depression, before the war
- He came of age when the baby boomers were being born

> “*When I think about it, I think what doesn’t break you makes you*.”‒ Walter Green

- His childhood was challenging
- His father was a dreamer
- When he was 1 year old and his brother was 2, his father found a place in the Adirondacks that he thought would make a great dude ranch
- He had been relatively successful, and he had saved $40,000 back then, which was a lot of money
- It was a chicken farm that didn’t work out as a chicken farm and was converted it to a dude ranch
- The third year after it opened, there was a big flood that wiped out the bridge and the family essentially went bankrupt
- His father at the time was in his 40s, and so they had to move back to Bronx in New York in a two bedroom with his grandparents who didn’t speak English

***In that 1st stage, Walter lived in 16 different cities, so he won’t go into all the details except to say that it really did set the stage for his life***

- It wasn’t just the movement from the Adirondacks to the Bronx, to Elizabeth, New Jersey; to Albany, Schenectady, New York; New York; Coral Gables, Florida; Jacksonville, Florida

**It wasn’t the cities…**

- It was that his mother got cancer when he was 9
  - She recovered
  - Back then they were doing major mastectomies for breast cancer
- They went on their first vacation as a family, the 4 of them (their father was going to join them a couple of days later)
  - To Florida when they were living in Albany, New York
- During this vacation, his mother got a call that their father had a heart attack
  - He was 47 at the time
- So she had to fly home
  - Which was never easy from Florida to New York as it is today
- Walter explains, “*And so began a very different way of life… that was a game changer.*”
- Walter was 11 years old and was reminded that we needed to make sure our dad was okay

**2 things Walter remembers specifically**

- 1 – All this movement preempted any chance to have a relationship
  - He didn’t have any friends
  - It made no sense to have a friend
  - He was going to be moving in a year or 2

***Walter has always found in life that people who are really motivated are people who haven’t had it***

- When you have had it, it’s a little bit more difficult to be motivated
- So this absence of a relationship
- Not ever having a friend really, he had a few in high school, but prior to that, none

- 2 – The combination of no relationships and a fear [of losing his mother]
  - Back then with breast cancer, 5 years was a long time
  - He got very lucky that she lived a long life
    - She had cancer again, but survived that as well

**He went off to school at University of Michigan**

- 2 months later he got that phone call that his father had died from a fatal heart attack
  - He was 53, and his brother died at 53
- His dad was a little older as a father, and so he and Walter didn’t have much in common
- Most of Walter’s concern was about his welfare and trying to provide for the family

> “*The gift that I got was this incredible branding that life is short, it’s unpredictable, you never know. And from then on, I’ve been walking up escalators.*”‒ Walter Green

- That’s the way Walter lives: he’s very intentional, and he doesn’t take anything for granted
  - That was the major gift from his father
- That was a tough period
- It was a struggle to graduate from the University of Michigan
  - Because academically that was really tough for him, but he managed to get through

## Walter’s harrowing experience with a sudden mental breakdown and his subsequent recovery with the help of therapy [11:15]

**Then after a short stint in the army, Walter took a job with a fraternity brother**

- He had no place to go
- He wasn’t going back to Jacksonville, Florida
- His friend’s father was in the industrial textile business and Walter got assigned to Pittsburgh
- Industrial textiles is another word for shop towels or rags, it depends on how glamorous you want to make it
- That was probably his 11th or 12th job
  - He was selling women’s shoes when he was a teenager
  - He had been working ever since he could get qualified to get a job
- Walter was always afraid that he’d be on his own
- In any case, he didn’t have many options so he went to sell rags in Pittsburgh
- 2 months after he started, he came back to Ohio to the corporate offices and was told that he was doing a really good job
- The man who had been training him was an older man
  - Walter thought he was a really nice guy
- But at that sales meeting, he got this message, “*Walter, you’re doing so well. Just as soon as you could learn that job, we’re going to let that man go*.”

**When Walter went back to Pittsburgh, he couldn’t get out of his bed**

- There was no mental illness his family
- Nobody really understood because they couldn’t see it, so he ended up being hospitalized
- He didn’t talk about that for 40 years because back then it was a real stigma
  - He thought it would influence getting into a profession, relationships
  - Being in a mental hospital was not something that you told people about
- Walter was 22 at this point, and home for him was an apartment with 3 guys
  - Previously he had live at a YMCA for a couple nights trying to figure out where he was going to live, and that’s how he came to room with 3 strangers
  - He had been living with them for 2 months
- So he came back from the corporate meeting from Ohio to where he was living
- He didn’t call it home

***This experience had never happened before and never had it since, but what happened was he essentially became catatonic***

- He just froze; he could not move
- Somehow they got him on a plane to Florida
- When he got to Miami, then they said he’d be best off in a hospital in Massachusetts
  - So he flew up

**What was the length of time from when you returned to Pittsburgh to when you wound up in that institute in Massachusetts?**

- Less than 2 weeks

**Your mom was still alive. What was her reaction and what did you say to her?**

- They had no idea
- They just knew that this young boy who was president of his high school fraternity and president of his college fraternity, this very mature young man was incapable of moving
- To show you how things were at that time, his uncle who was very close to the family, when he saw Walter in bed and he said, “*Walter, just get up. Just get up. You’re fine*.”
  - No comprehension of what being mentally sick was

**What happened when you got to the hospital?**

- It was a series of treatments, mostly dialogue and medication
- It was very difficult when he arrived there because he saw others that really looked sick
- He really couldn’t do anything on his own
- From there he moved to Cambridge
  - He always laughs about that because when he tells people he graduated from University of Michigan and then spent some time in Cambridge, they always think: oh, this guy is really smart and he’s a really modest, man
    - They think that he went to that little school back east just outside of Boston
    - That wasn’t what brought him to Cambridge, but it was a terrific experience
- He learned so much about himself

***He spent 2 years in therapy and learned a lot about himself: he was so afraid of failing, and he failed and he survived***

**How long were you hospitalized?**

- 2-3 months

*Do you remember what types of medications were used in that era?*

- Presumably antidepressants
- He didn’t have any shock therapy
- It was a great learning opportunity for him

**How did you know when you were ready to leave?**

*That’s a funny story*

- He was seeing a therapist a couple times a week and it was inconvenient
- At the time he was in public accounting and selling mutual funds on the weekends
  - He was really busy and having to go to this therapist wasn’t convenient
- Finally after 2 years, he said, “*When do I finish?*”
  - He replied, “*I think you’re done,*” and that was it

*What prompted you to leave the hospital after 2-3 months?*

- When he felt okay to return to society

*How frightening was that?*

- It wasn’t frightening
- He felt like he was in a pretty good place
- It was just for that 2-3 months, he completely lost it
  - It might’ve been an accumulation of losing his dad in freshman year, never really dealing with that
  - Feeling the pressure of, “*Oh my God, what am I going to do?*”
  - Then finally getting a job, and now if he’s successful, his employer will let this guy go
  - It was just more than he could handle
- Peter responds, “*It seems that one of the real challenges of getting over an episode so traumatic would be the fear of not knowing if it could happen again.*”

**Did you feel that through the experience of speaking with the therapist while you were an inpatient, you had sufficient resolution of that such that you weren’t worried that you were an accident waiting to happen, an emotional train wreck that you couldn’t anticipate?**

- That was present, but he was sufficiently back to who he was
  - This guy who had been in a pretty good place for all but 3 months of his life, and he had dealt with a lot of challenges
    - A lot of moving
    - A lot of unknowns in his parents’ health
    - Challenges at school that were really tough

***So you can’t say it’ll never happen again because that’s just being a little naive, but he never feared that it would happen again***

## A diverse professional journey ending in great success [18:15]

**You didn’t go back to the textile company when you got out of the hospital?**

- No
- He was in public accounting for 3 years
  - He got certified as a public accountant
  - In the evenings, he was selling mutual funds because he wasn’t paid enough in public accounting at that time to survive on his own
  - He had two jobs
- His brother Ray called from Florida and said he had just made $1,000 in his part-time job, and Walter replied, “*That’s more money than I’m making from my other two jobs. What’d you do?*”
- He described he was involved in a multi-level marketing for a fellow by the name of Bob Cummings
  - It had to do with health, nutrition through biochemistry
  - It was a sale of vitamins and minerals
- Bob Cummings had 7 kids and he looked half his age
- Walter was anxious to make $1,000, so he became a distributor
  - That was his 3rd job
- He put a little card up in the laundromat near where he was living and the first person had said, “*If you want to earn money in your part-time, please give me a call*.”
  - You wouldn’t get away with that today, but back then that was okay
- The first person called him and Walter had his little audiovisual kit and the slides and everything, and she seemed really interested in selling the vitamins
- As it turned out, Bob Cummings said it solved arthritis, and they shut him down 3 weeks later

***Walter lost his $500, which is all he had, but his first salesperson became his wife. So it was the best thing that ever happened to him, and that was at 22.***

- They were married at 24

**What did you continue to do professionally?**

- He then went into the hotel field
- He and his wife moved to New Orleans, another move
- He decided hotels weren’t for him
- A search firm called and said there’s a large food service company in New York, would he like to be the vice president of administration?
- Lola (his wife) and he would call themselves single since they didn’t have any children at the time
- But right prior to the move, she became pregnant
- She delivered twins when they moved to New York for his other job
- He decided the restaurant field wasn’t for him either
- So now he’s with twin boys in a field that still didn’t work for him

**He had really developed a lot of competencies, and when he mentors people and mentors young people as he does today, those competencies were transferable**

- He was contacted by someone who had a startup company in a new niche of an existing industry, which is the development of high-end executive conference centers for corporations
  - Mainly Fortune 500 companies, as an alternative to meeting in hotels
- There were specially designed facilities with guest rooms and fitness and dining and recreation instead of the folding walls and the bad acoustics
  - That was a startup company
- Walter put the $10,000 that he had into a very, very, very small percentage of the company
- It was funny; it wasn’t until he did this that he began to think with more compassion about his dad who had taken his $40,000 (his life savings) when he had a 1 and 2-year-old
  - Walter had twin 1-year-olds and he was doing the same thing in a very unestablished brand new niche of the hospitality business
- As it turned out, the company almost went bankrupt in 3 years

**Same pattern: the founders were asked to leave and Walter was given the opportunity to become president**

- Walter was 32 years old, had 400 employees and over the next 25 years became the major shareholder
- We had 10 centers, ran about 6,000 conferences a year with 150,000 executives, and that was his main event

***It became a company that was owned by Walter and some key executives***

## The birth of a movement: celebrating friendships through public tributes and expressing gratitude to those who have shaped your life’s journey [22:30]

**Where in this journey does the thesis [say it now] emerge for what became your 50th birthday?**

*You did something special at your 50th birthday, which in many ways became the central theme of what we’re talking about*

- This gets us into act 2 (the 2nd 29 years)
- What Walter never had in act 1 were really good friends
- Now he was in his same home and was going to live there for an extended period of time, and so he began to make friends
  - Not acquaintances, but people who he had authentic conversations with
- He was so joyful when he had his 50th birthday that he wanted to celebrate those friends
- He invited 5 of them with their spouses and his family (17 of them in all)
- He remembers it like it was yesterday: it was the opening weekend of *Phantom of the Opera*
  - Even though at that time Walter had limited cash, he spoiled these people for a whole weekend
    - It was important for him to celebrate those friends
  - At the reception, he paid tribute to each of them in front of everybody about how they enriched his life, what they had meant to him
- Like Ric’s affair, some of these people didn’t know each other, but they became connected through Walter

***That was really his first iteration of paying profound tribute to people while he was alive***

- Peter points out that many people could invite some friends over for their birthday and make a toast to them, but this isn’t exactly what Walter is talking about here
  - This is a bit more profound

**How deliberate were you in this first rendition of “Say It Now,” and how much preparation did you put into what you would do with your 5 closest friends for that celebration?**

- It began with the invitation and Walter mailed out a carton of apples and in each apple he planted a flag, and each flag was a representation of another activity during that weekend
- Everybody appreciated the invitation except his son who was going to school (at Dartmouth), and he said it was quite something carrying that crate of apples in the snow
  - But everybody else seemed to like the idea
- In any case, his twin sons played the role of the Phantom
  - They came in off of the platform outside the room before with the smoke and prior to the reception
- We had some wonderful dinners, wonderful show, rides on the carriage
  - It was a life event that everybody really thought was extra special
- Walter also created for each of them a memento (a picture and then a summary), and he distributed that memento at the end
  - Which he still has to this day
  - It’s 2 sentences about what each person meant to him

**How surprised do you think they were by what you said and how much you made this day?**

- Peter remarks that Walter seemed to make this more about his friends than his 50th birthday
- This was Walter’s first experience seeing how much people appreciate being appreciated, and made more so when you do it publicly
- He received within a couple months a leather-bound book that he still reads to this day of what that weekend meant to his friends
  - His friends collectively put this together as a gift back to Walter

**Did you think at that point that this was a movement that could be larger than just something you did at your birthday?**

- No
- This was at a time where he was thinking about his life
- He never won any academic awards ever, yet when he looks back on it, he seems to lead most groups; and he began to wonder why that is
  - He’s never the smartest in the room
  - He began to realize that he is an **experiential learner**: he watches what’s going on and learns from that experience
- This event left an indelible impression, but he was still locked into the fear that, “*53 may be done for me*”
  - It had no longer-term view than that

*He’d never had a longer-term view of his life*

- He remembers attending a seminar when he was in a [Young Presidents Organization](https://www.ypo.org/) when he was in his late 40s
- The woman led an experience where she said, “*I’d like you to close your eyes… picture what an ideal future would look like.*”
- Walter closed his eyes and it was black
  - Tears ran down his face
- He went up to her because she was a psychologist and said, “*I don’t understand. I assumed this was a positive experience for everybody. This was painful*.”
  - She replied, “*Does that have anything to do with how long you think you might live?*”
    - Of course that was what it related to

***To Peter’s question, this was never the beginning of what happened later on; there were 2 more***

- It seems like things happen in 3s, and this was the 1st act
- There was a 2nd act when Walter was 70, and that was a different story

**You alluded to the idea that a part of the magic of this experience was that you didn’t just tell these five people how much they meant to you, you did it publicly. Why did you decide to do that?**

*Was it just intuition or did you have a stronger belief set that it was more meaningful to do it that way as opposed to telling each of them privately the exact same things that you would’ve said?*

- By that time, Walter had spent 20 years in the conference business, and one of the focuses that he had that was transferable was that he always saw the power of expressing something in a group
  - So that if 10 people told you individually something, it was not as powerful as 10 people gathering to tell that person

*In the positive and the negative?*

- Both for sure
- For Walter, it’s always generally been the positive

> “*The life experience is Walter, there’s power in a group, there’s power there. And so it seemed quite natural to me.*”‒ Walter Green

## Intentionality, thinking in reverse, saying “no”, and other guiding principles for Walter [30:00]

**There is a fear of not existing and understanding that life is finite. How did you come to grips with that as with each passing year, you found yourself alive?**

- Peter points out that mortality is 100% guaranteed, so this idea that we’re afraid of dying is a bit misguided
- In some ways, it’s we’re afraid we don’t know *when* we’re going to die

*At some point, you’re 54 and you realize you did it*

- It was a gift that kept on giving because Walter always had his foot down on the pedal
  - Not to the metal, but down on the pedal

***He acquired an innate intentionality***

- People to this day say, “*How do you do what you do?*”
  - And they said, one of the big reasons is Walter is really good at deciding what he doesn’t do
    - It’s guided his life

***Walter knew however long he would have, he was just going to make the most of it***

- He was very grateful for every year

**At what stage in your career did you go from always incoming, receiving, taking every opportunity that comes your way to this more deliberate focus on saying no?**

- Peter points out, “*At some point as a person matures and becomes more successful and they have more and more obligations, the ‘no button’ becomes a very important button.*”
  - He wonders how Walter discovered that and what were his guiding principles
- Walter was always concerned with how much time
  - But that doesn’t give you focus
  - That’s just a concern for time
- He attended a program at this Center for Constructive Change when he was in his 30s
  - It was taught by [Fred Jarvis](https://en.wikipedia.org/wiki/Fred_Jarvis) (may he rest in peace), and it was a process of thinking that has changed every day of Walter’s life
    - He does not think in the traditional ways that Walter thought before that, he always **thinks in reverse**
- For example, when he’s thinking he’s going to have the pleasure of spending time with you, he never would ask you, “*What will we do?*”
  - **Instead, he would specifically say, “*****If this conversation is really successful, what would’ve happened by the end of it for us to know that our time was well spent?*****”**
  - Walter asks that question for everything important that he does every day
    - Including personal interactions

**Peter thinks this makes a lot of sense in some contexts, at a meeting; on the other hand, he has a hard time wrapping his head around that**

- For example, Peter is going aways with one of his kids for the weekend
  - Is Walter saying that instead of thinking through the activities you’re going to do

*Walk me through what you’re thinking*

- Walter gives a real life example where he was mentoring one of his son (Jason’s) friends
  - This friend was in his 30s, and he came down to see if he could get some coaching
- Walter asked him to tell him some situations he’s dealing with
- He said, “*Walter, I work so hard during the day and then I go home and I spend all my energy with my kids from morning to night. At the end of it, they don’t seem very fulfilled and I’m exhausted, and then I start all over again.*”
  - The kids were ages 9 and 11
- Walter asked him, “*When you get home Friday night, why don’t you ask them a question to each of them, ‘If this were a really a fantastic weekend, what would you like to have happen over the weekend?’*”
  - They gave him specifics, and he was able to do it in ⅓ of the time
  - The kids had a fantastic time, and he had ⅔ of his time to relax

Peter asks, “*Do you always need the input of someone else when you’re thinking through that?*”

- No
- If Walter was even meeting a friend or meeting a mentee, he’d say, “*Well, if this were a really successful experience, what would’ve happened by the end of it?*”
- To him, it’s like saying good morning
  - It’s just so intuitive
  - There’s not a formality
  - It’s a freeing, it is not a limitation
- It may sound like too much structure, but it’s the ultimate of being free because he doesn’t ask himself, “*What will I do?*”
  - He asks, “*What is it that I’d like to have happen?*”
- If he’s meeting with a friend who’s going through a difficult time, when he’s done he would like to figure out sometime during that time that he will help him lighten that load
  - He’s not sure when, but when he leaves, he wants to be able to do that

> “*To me, it’s very natural, very powerful, very intentional, very focused and very gratifying.*”‒ Walter Green

**Say a little bit more about what you learned or how you developed your palette around saying no to things**

- This process of asking about what success would be for an individual (one), for probably over 40 years, Walter asked himself the question, “*If my life is successful over the next 3 years, (used to be 5, now it’s down to 1, but it’s far enough out that I’m not thinking about what I did last year. If I had an ideal life in the next 3 years, how would I know it? What would be happening?”*
  - And he would go from his personal relationships, his family relationships, his financial relationships, his health
    - Every key area of his life would have an indicator, and that would be his ideal outcomes
  - And then he thinks backwards
- For example, if he wants his cholesterol at under 100 and he’s at 110, what would it be each 6 month period?
  - Each one of them has benchmarks
  - Each benchmark is powerful because it says to him at six month intervals, “*If I make it, I’m on track*.”
    - If he doesn’t, he hasn’t failed; instead, whatever he’s doing isn’t sufficient
    - So what will he do differently
- Walter explains, “*Wow , is that powerful? That’s how I’ve been leading my life.*”

***It’s easy for him to say “no” when it isn’t consistent with the outcomes and the indicators that he’s been committed to***

**Does it take a bit of discipline?**

- The first time, it’ll seem awkward
- After 44 years, it’s awkward not to do it
- Peter thinks the discipline is in the ability to contemplate something that in the moment seems enticing
- People talk and are familiar with this idea of fear of missing out
  - Someone comes to you and says, “*Walter, I’ve got this great opportunity for you and dah, dah, dah, dah*”, and on the surface it sounds pretty interesting, but then you have to say, “*Wait, how is that aligned with the goals that I have?*”

**Peter has practiced never saying yes immediately**

- One of the tools that Peter has learned for that, and it’s been very helpful for him, he’s been in a very concerted effort for the past 5 years of trying to be more disciplined about that
- Forcing himself to **never say “*****Yes*****”** to anything when asked
  - So even if he’s really leaning towards doing it, ***just asking for a couple of days to think about it***
  - And if he just commits to that **one rule**, that’s literally the only rule that is absolutely black and white, which is, “*This sounds very interesting, Walter. Let me think about it for a couple of days and get back to you*.”
  - This buys him time to try and do his own version of what Walter is explaining
- Peter thinks he probably still says yes to more than he should, but that 1 step has probably saved him 80%
- For Walter, his structure [of thinking in reverse] provides freedom
  - It provides a built-in discipline, and it allows for a lot of creativity because he never talks about how he’s going to do it, so he is completely free to figure out how

## Walter’s global journey of gratitude on his 70th birthday, visiting friends, and creating memorable experiences [39:15]

**Say more about the 2nd phase of insight; you mentioned something at 70**

- Walter had this experience when he was 15, so still being sensitized to the 50s thinking
- His father never worked out [exercised] and Walter has been working out since about age 30
  - So he’s got a few more years over him
  - So his adjusted age is 58, 59, 60
- It was at [Tim Russert’s](https://en.wikipedia.org/wiki/Tim_Russert) funeral that Walter saw it
  - Tim died in his 50s in 2008
  - Walter thought he was brilliant with [*Meet the Press*](https://en.wikipedia.org/wiki/Meet_the_Press)

***At Tim’s funeral the tributes were unbelievable, and it occurred to Walter that he’s never going to hear a word of it***

- Walter thought that didn’t makes sense
- Walter has a reading challenge ‒ reading books are very difficult unless they can be done in small chapters with no recall of the previous chapter
- Walter was able to read [*Tuesdays with Morrie*](https://www.amazon.com/Tuesdays-Morrie-Greatest-Lesson-Anniversary/dp/076790592X/ref=sr_1_1?crid=8ET64QXE5EOB&keywords=tuesdays+with+morrie+book&qid=1703099239&sprefix=tuesday%2Caps%2C102&sr=8-1) that had been written where in his final years Morrie got very authentic and very deliberate
  - He remembers reading part of the last lecture, which a professor at Carnegie Mellon [Morrie] wanted to do one last lecture because he was dying from cancer and he wanted to leave a message for his kids
    - Walter thought, “*Wow.*”
- Then the KPMG chairman in his 50s got brain cancer and had 4 months to live, and he wrote a book called [*Chasing Daylight*](https://www.amazon.com/Chasing-Daylight-Forthcoming-Death-Transformed/dp/0071471723/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1703099458&sr=8-1) about what he wanted to do in the last 4 months
  - Experiences, experiences, experiences

***It’s either too late or it’s almost too late, and Walter didn’t want that to be his life***

- That may be customary, but sometimes customary is not good
  - It’s just usual and common, but not smart

**In Walter’s late 50s he had 4 or more impacts that motivated him to do it differently, and he made a commitment**

- When he was coming on 70, he thought about what he did for his 50th birthday
- He asked his wife (Lola), he said, **“*****I have an idea for a gift for my 70th… I want to spend as much time as I need in the coming year to sit down with everybody who has been important in my life.*****”**
  - He wanted to go visit with them
  - He wanted to have an experience with them
  - He wants each one of them to know how important they’ve been in his life
- Lola, who has been either the creator or the supporter of everything important in his life, said, “*If that’s the gift you want, you should take it*.”
- And that’s what Walter did for the following 11 months

***After he turned 70, he visited with 44 people***

- It brought him to Kenya, Mexico, Canada, and to many places in the United States
- Walter explains, “*It was a remarkable moment of my life*.”

**Give an example of what such a meeting was like**

- Peter does the math and realizes that if he’s seeing 44 people across the globe in 11 months, we’re only talking about days that he’s spending with each person
  - Literally a day
- Most of them were domestic trips, and sometimes he was able to do 2 or 3 in a single trip
  - If he had a few in Florida, he would combine them
  - It wasn’t like he had 44 trips somewhere from Southern California (where he lives)

*Walter highlights the simplicity of this plan*

- First, he hesitates to tell this story about 44 people because listeners will probably say, “*Oh, I don’t have 44 people.*”
  - But you have at least 1, and that’s all Walter is trying to inspire

> “*For me, the journey was my personal journey. It had nothing to do with inspiring anybody for anything.*”‒ Walter Green

- Walter took out a legal pad and wrote the question, “*What difference did this person make in my life?*”
  - And he would put bullet points down underneath it
    - Sometimes it could be 2 pages, but typically 1
- The he would go and see him or her by the product of that process

**He took that legal pad with him and had 4 bases he covered in every conversation**

- This was some systemization to this, but each one was so different, yet they followed a similar pattern
- 1 – How he had the good fortune of meeting this person
- 2 – The shared experiences they had
- 3 – Walter had his pad in his lab and said, “*This is for me to express to you how important you’ve been in my life, and I want to tell you why.*”
  - This was the major one
  - It focused on the specificity of how important they have been
    - The richness of the conversation wasn’t, “*I love you,*” even though he did tell them that
- 4 – He had known these people a long time and felt this was his only opportunity to acknowledge them and speak his appreciation
- Walter recorded every conversation
- Because it’s so hard to take in acknowledgement and appreciation at the end of the year, he mailed to each person: a picture, a 120 word letter summarizing it, and the CD (which summarized their conversation and framed them)
  - He mailed this to 44 people
- 5 – The last piece of it was that Walter wanted to learn something about himself

- He asked each person to give one piece he could use to create a mosaic about who Walter is
  - He asked them to share what that piece has been from their perspective

## The profound impact of acknowledging and expressing gratitude for the people who contribute to our lives [46:15]

**What was the most interesting thing you learned in that year about life? Not necessarily about yourself, but just about life and the richness of it?**

- First was how blessed he was
- Relationships are interesting in the sense that Walter equates it,  “*Like I put a flashlight in a dark room.*”
  - Those qualities of the friends were always there, but he just brought them to light
  - And when you bring them to light, it’s an extraordinary feeling
- It doesn’t matter if you had 1 or 2 or 3
  - This coming from a guy who never had a friend until he went to high school
- Walter felt such a richness from the experience
- Actually towards the end, he was in Kenya on another mission, building a school over there
- And the founder of this nonprofit heard what he was doing and in fact was on the journey and he said, “*Well, would you tell the story at dinner about what you’re doing?*”
- And they all broke into applause at the end
- Walter realized, “*Maybe this story has to be told more. Maybe it shouldn’t just be a personal story.*”

**During this time Lola had lunch with an acquaintance and told them what Walter was doing**

- She said she’d like to hear the story
- Turns out, she was the editorial director of [Hay House](https://www.hayhouse.com/), and 3 days later he had a contract to write the **book**
  - And that became another platform
  - It’s called, [*This Is the Moment! How One Man’s Yearlong Journey Captured the Power of*](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1)

**Peter points out that Walter’s list was pretty selective**

- These 44 people were not acquaintances
- These are very close friends
- He continues, “*The fact that it’s 44 for you is probably not surprising to anyone who’s listening to this conversation or to anybody who knows you. And it probably speaks to how deliberate you are at cultivating relationships. I think it’s a cliche, but it’s a cliche for a reason that richness in life is much more about relationships than other successes. Whether it be success in victory, success in material, or monetary means.*”

**How much of a role did the pain that you experienced in the 1st 29 years of your life paradoxically become the greatest asset to allow the 2nd and 3rd 29 year periods to have this degree of richness?**

- Walter thinks he was at an advantage because of his deprivation
- But there’s a level of consciousness and that there have been thousands of people who have since acted on this message and there’ve been
- Remember, Walter knew it was going to be good because an acquaintance (a motorcycle, cigar smoking, really tough dude) had said, “*That’s a hell of a message… There are some people I need to speak to*.”
- A wide range of people that realize we are not self-made (everybody really knows that), ***the question is are we going to acknowledge those people that help make us while they’re here?***
  - It’s not complicated

**What Walter finds incredible and why he’s really excited about this latest movement**

- When he thinks of his contemporaries and even people in their 40s and 50s, they’ve been so focused on the traditional measures of success that relationships don’t have the focus
- Walter read a couple chapters of a book called [*How Will You Measure Your Life?*](https://www.amazon.com/How-Will-Measure-Your-Life/dp/0062102419/ref=sr_1_1?hvadid=580650917415&hvdev=c&hvlocphy=9005495&hvnetw=g&hvqmt=e&hvrand=358498887730473062&hvtargid=kwd-48517363189&hydadcr=21906_13324133&keywords=how+will+measure+your+life&qid=1703175306&sr=8-1) written by a professor at Harvard
  - These are all bright guys who graduate from the business school, go out and become financial who was, and in 5-10 years they’ve made a fortune
  - They come back for a reunion and they’re miserable
  - Walter’s take: there’s something wrong with this picture

***The solution: a change in focus to have them look at what successful life looks like***

- Not how much success you may have in business

**Walter thinks there is an enormous missed opportunity in really placing education around what’s really important**

- For him, there’s nothing more important than his marriage: 60 years over 20,000 days
- His children (twins) are grown
- His good friends, Walter adds, “*What did they ever teach me about that?*”

*Walter asks important questions*

- Where did I ever learn about what it is to be a compassionate loving caring husband or a father or a friend?
- What do you do when your friends are struggling?
- How are you helpful?
- How do you show compassion?

## The key elements for creating meaningful connections and cultivating deep, authentic friendships [52:15]

- Peter knows a lot of people who are surrounded by people that are supposedly friends, and they have world-class experiences constantly but deep down they don’t seem particularly enriched by them
  - He doesn’t want to sound judgmental because one can never know from the outside
  - By appearance both these so-called friendships seem superficial and the experiences maybe seem too hedonic and not relationally rich
- It’s also clear that when Walter talks about these 44 people that that’s not what it was about
  - Peter suspects that when Walter talked about the experiences he shared with them, it wasn’t when we went to Vegas that weekend and gambled all this money away and partied really hard or something like that
  - He suspects that some of the experiences Walter talked about sharing were very subtle

**Peter asks, “*****How do you think that you naturally gravitated towards that, and why do you think that is not necessarily a natural thing for people to do?*****”**

- Walter thinks lots has to do with our life experience, and he doesn’t have much time to waste

*Is this urgency from literally the fear of death?*

- He doesn’t know if it’s a fear of death, it’s a realization
- Somebody wasted an hour of his time this week; it was a pure waste
  - He really resented it
  - They didn’t do it intentionally, it just turned out to be a wasted hour
  - He would’ve rather written out a check
  - He can’t get that hour back so he tends to not have a lot of time
- Walter explains that he’s been in these groups, groups of 10 or 12 presidents
  - He’s been in for 37 years, one for 20 years, another one for 22 years
  - He’s been to about 800 of these sessions
  - While they’re all authentic, they’re all about life, he’s spent probably 4,000 hours talking about president’s issues as deep as you could be
    - That’s where he spends a fair amount of time
- All of his mentoring is about real life issues
  - It’s not about entertainment
- The friends that he hangs with are typically ones where he can have meaningful conversations
- Walter continues, “*So I really think it’s how you normally relate in your life. I think it’s getting to the point where people are more comfortable being open.*”
- He finds when people get older, they get a little bit more comfortable
  - He was very secretive in his twenties, but he’s not secretive now
    - They’re all lessons
- In these men’s groups, he would not be the smartest for sure
  - Walter says, “*I would not be the first one I would call to go have a beer with.*”
    - He doesn’t drink it, but they wouldn’t ask him anyway
    - He’s not the bantering kind of person
  - But the moderator of the group said, “*Walter I don’t know if you know it… of all the members of the group, you’d either be the 1st or 2nd person that everyone would come to if they had an issue*.”
- Peter asks, “***Why do you think that is?***”
  - Is that innate?
  - Is that deliberate?
    - Meaning is that a skill you are cultivating?
  - Is it simply part of your personality?
- Peter thinks it’s interesting that the straw that broke the camel’s back in Walter’s mental breakdown was one born of empathy
  - It was that he couldn’t stand to take this older man’s job
    - And while Peter is sure many people would be disheartened by that proposition, and even if someone just chose to say, well I’m not going to go back to work, it impacted you in a way that was so much deeper
- If someone’s listening to this thinking, “*I would like to be a person that at a minimum my friends could come to when there’s a problem*.”
  - Not necessarily everyone would feel that way who knew me, but those who know me well, but it’s not happening
    - I can’t tell you the last time someone came to me because they have a problem

**What do they need to do to cultivate that skill? And why should one want to have that?**

- Walter thinks that skill is based on authenticity and empathy and compassion, and he thinks we all have it
  - He doesn’t know that we all use it
- In deep relationships, Peter mentioned earlier that people who have these wide range of friendships
- About the 44 people on Walter’s list, he didn’t want to correct, but these were not all good friends of his that were on the list
  - These were all people who had significantly impacted his life
  - That doesn’t necessarily mean that they were my good friends
  - Many of them were good friends
- Peter clarifies, “*And some of them might’ve been a professor in college who you hadn’t been…*”
  - Exactly
- The he blind man in New Hampshire who taught Walter how to think, he might’ve seen him 30 times in his life
  - He would not be someone who is a friend

**In terms of why would someone want to be more authentic?**

- That’s an individual choice
- There’s a natural aptitude to show and tell, and for Walter authenticity transcends show and tell
  - He finds it very rich
- He finds a lot of these apparent friendships were really just that we were in the same organization together and they were very friendly
  - You leave the organization and you don’t see them again
    - That’s not a friend, that’s just an association and sometimes it gets confusing
- Sometimes as you elevate yourself in the world, people will befriend you in ways that you actually think they’re a friend, but they’re really in some cases just because of an association

## The “Say It Now” movement: the inspiration behind the remarkably impactful initiative [58:30]

**The profound effect Tim Russert’s death (circa 2008) had on Walter**

- Walter saw all of these people coming to say the most amazing things to him that he never got to hear

*What else crystallizes for you there?*

- That was one of 3 or 4 that came right at him, and it followed a real remembrance of his 50th and the thought, “*Oh my God I’m going to make 70*”
  - Those compounded
- At the 70th experience in which he wrote the [book](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1), and people wrote him about what the message had meant to them because the book was structured in 3 ways

**How did Walter come up with this idea? Where did it come from?**

- We’re seeing more and more research come out about gratitude because mental health is becoming more of an issue
  - It’s absolutely unbelievable to Walte
  - They’re now coming out with studies that were done 5 and 10 years ago about the power of gratitude
  - Gratitude  makes you feel better, less depressed
- None of Walter’s insights were based on any study
  - It was all experiences

***The feedback he got from speaking on the subject matter really elevated his appreciation of the power of the message***

- It has been gaining and then really a decade after the book was published, it still had legs
- He heard from a girl in the Philippines who had picked the book up in the library, and she wrote him an email and said, “*I just wanted you to know I was thinking of killing myself. I had been abused in my family and I was so angry I wanted to end it. But I saw it and I read your book and I realized there are a number of people who have actually helped me in my life, and how can I forget that at this moment?*”
  - Walter had no idea how the book was in a library in the Philippines
  - They had 1 or 2 exchanges
  - A decade later, he heard from her, she’s married living in Denmark or Sweden
- There are many of these stories

**These stories elevated to Walter the importance of thinking about maybe there’s a more powerful way to do it**

- Most of his life has been spent one-on-one in small group
  - All his mentoring is one-on-one
- All his small groups are 12 people or less
- His conference business was typically 25 people or less
- The book was the first time that he’d influenced thousands of people, and during the pandemic he thought, “*Oh this is going to make this group get together*.”
- His son suggested they could do it by Zoom

***3 days later, they did the first of the living tributes, and his son insisted on using Walter and brought his mentees together, and that evolved into what became the “Say It Now” movement today, and that may be Walter’s biggest legacy***

**How does a person go about doing this?**

- This is *not* a business that Walter invests in, there are no royalties, no rewards, nothing
- He wants to make it really simple
  - This is not complicated
- Of the thousands of stories Walter has heard over the years, he’s never heard one that the person said, “*I’m sorry*.”
- He got a card from someone this past week that said, “*I just want you to know you inspired this.*”
  - The card was printed, “*70 for 70*,” and the person explained that he had written to 70 people on his 70th birthday
- Walter explains, “*He outdid me so I dropped him a note, asked him what the experience was like.*”
  - He had a very similar experience to Walter’s
  - It was so easy to do
  - It felt so good
  - It reconnected him with people at levels he hadn’t been at
  - It’s not complicated
    - These were short notes to each of those people

> “*I say it doesn’t matter how, but it does matter now.*”‒ Walter Green

**Walter came across an interview by Hadly Vlahos**

- She is a hospice nurse and she just wrote a book called [*In-Between*](https://www.amazon.com/Between-Unforgettable-Encounters-During-Moments/dp/059349993X/ref=sr_1_1?crid=21QJ31PRHBODT&keywords=book+by+hadley+vlahos&qid=1703179799&sprefix=book+by+hadley+vlahos%2Caps%2C109&sr=8-1) and in it, they asked her the question, “*If you had an ideal death what would it be like after you see these people who have had these for months before they die*?”
  - She said, “*Well for me, I would want people to come to me and tell me that I mattered before I died. Right when I was dying, I’d like to hear that*.”
  - **She said, “*****I was with these people for 6 months before they died, their central word was, ‘I don’t matter to anybody.’*****”**
  - Then she would go to the funerals of these people and hear the tributes that are paid to the person who’s dying who feels unloved, unappreciated, unacknowledged

**What Walter decided was in some ways we have to unlearn this idea of what is customary**

- You have to unlearn celebrations of life are great for some things

***Memorial services are great, but they’re not for paying tribute to somebody who’s been important in your life ‒ those are not the moments for that***

**Why do you think we do that?**

- Custom

*When you say it this way it’s so obvious, but is there some level of discomfort that we have?*

- Walter recalls being with a limousine driver and being asked, “*What do you do?*”
  - He told him the story
  - The limo driver who was in his 40s said, “*Oh my God, my immediate thought goes to my basketball coach. That guy taught me so much about life and about playing and it wasn’t about the game*.”
  - Walter suggested that he connect with him
  - The next time he picked Walter up to go to the airport, he told him he called up his basketball coach and said he’d like to see him
    - The coach said, “*Sure, I’ll see you on the basketball court.*”
    - The limo driver replied that he didn’t come to play basketball, he explained, “*I need to have you sit down on the bench. I want to tell you what you mean to me*.”
  - It changed their lives

> “*The reason that I think it’s a little hard is because not too many people are modeling that this is the way to do it.*”‒ Walter Green

**Walter thought strategically about how to teach younger people to do this**

- They don’t have to unlearn anything
- His major thrust this past year has been to educate young people
  - There are teaching materials now
  - We are in 38,500 classrooms around the world in 75 different countries (so it is a global movement)
  - They’re primarily 5th through the 12th grades and they all have materials on practicing “Say It Now”
- It’s starting in schools and kids are going to go home and tell their parents
- Walter got a note from Joanne in Ontario Canada (a fellow Canadian and kindergarten teacher) who had been so committed to her profession but during the pandemic it was so tough
  - Then when she went back to school with these kindergartens where it was their first experience she introduced “Say It Now” to kindergartens
  - She wrote, “*One child chose to express what I meant to her by doing a drawing and she told me what the drawing meant and why she appreciated me in the drawing and how she helped me learn how to sing and why that made a difference.*”

***Walter’s hope: he set a goal for a million expressions of gratitude by his 85th birthday (next month)***

- We’ve [crossed 1,000,004](https://finance.yahoo.com/news/now-movement-surpasses-goal-ignite-130000721.html?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAD-HWWh2_IyLc7VW7mvGMqzFy6rc-1tbKAd2mo_alornTwV1n_Kx0uRWxjz-6dTArXTBqIi-IpJXyFNkp6cdD4Ep6cBbQYEVpZ58OpSRy7r5Ed00F4xuj6g_pE_Tax4nZRJJElmVR8DSuKnu0LYkjEwSOkDMSF3HaWBvgUZCRI5N) and we’re just beginning

## What “finishing strong” means to Walter [1:07:30]

**What does finishing strong mean to you?**

- Walter recently thought about this when he had a medical scare

*He detailed key results of how he could ideally finish strong; and achieved each of those in the last year*

- 1 – He has 2 homes and he thinks that would be a lot for his wife to manage when he is gone
  - Last week they moved into a place that would provide a good lifestyle for her
  - They still have their primary home, but this is a place they are starting to transition to so she would feel comfortable
- 2 – Walter is very current with his relationships
  - His friendships are up to date
  - He makes sure he’s circled the block with all his mentees that have been important
    - Most of them came to his [TEDx talk](https://youtu.be/eCGd7ya7sUw?si=mqiu6KNxdaezdm-x) which gave him a chance once again to publicly acknowledge how they each had changed his life
    - So much as he enjoyed his TEDx talk, the dinner following was so significant for him
- 3 – He had 1 investment that required some work
  - It’s not an operating company
  - He doesn’t want his wife to have to think about that
  - He finished liquidating that so everything is easy for his wife
- 4 – He gave his wife a list of 15 things to do from a financial point of view if something happens to him
  - His financial affairs are up to date
- He is still working out
- He got some good news: the cancer he had a year ago is in remission
- He adds, “*Somebody up there thinks I got some more work to do.*”

**When do you think people should be thinking about this?**

- Walter has been doing this for 35 years
- He always had his estates in order and provided life insurance, homes, and things for their [his family’s] comfort
- This recent one was a little grander

> “*I think we wait too long to give*”‒ Walter Green

**Walter’s thoughts on giving**

- Walter has spent the last 30 years in philanthropy
- He accelerated that program not just for nonprofits, but for people who have been important to him but haven’t been as successful
- Is it normal? No.
- Is he worried about giving people money? A little, but he’s worried more about not
- He understands that it’s not customary,and one person said it’s difficult
- Of all the people, one person said, “*I just can’t do it.*”
  - They couldn’t accept the money
  - Walter explained to them, “*I really understand and I appreciate you being so honest about it, but let me tell you a little story, and that is you are keeping me from the pleasure of giving a gift so give some thought to it.*”
  - She couldn’t keep that pleasure from him and accepted

**How much of this do you think your twins have naturally been infused with through the osmosis of your example?**

- Walter has had evidence that the modeling is more important than the speaking
- He’s very proud of them
- They got the message and they’ll do it in their own way with their own approach

**Do you have a different way in which you communicate that to family?**

- Peter looks at his wife and kids and acknowledges that without them he’d be in a pretty rough situation
  - He wouldn’t be the person he is today

*Walter recalls being asked how his children model some of what they may have learned from him and how does he learn that they in fact get it?*

- Walter remembers one of his kids (Jonathan) writing to him at Father’s day, “*When I think back over our life together, you always gave me footsteps to follow when I needed someone to lead. You always walked behind me when I needed encouragement, and you always have been by my side when I needed a friend.*”
  - He has read that a thousand times
- Hi son Jason wrote to him at his 80th birthday and the most recent Father’s day all of the messages that he got from him over the years in his own way
  - That means a lot to Walter

**One of the things Walter wants to highlight is when he was going through this [medical scare], what he learned in the past year, he never knew beforehand**

- When he was thinking that this could be the final year
- At the end of the day he has a portrait of the 44 people on his journey in his office
  - Next to that are pictures of his mentees
  - He will turn on Bruch’s Violin Concerto (which he loves), and he goes one to one
  - There are probably almost 60 lives that he touches during it
  - Reminding himself what they have given him
- He feels so blessed, he has so much oxygen

***He has never been in a better place than in the toughest year of his life, this past year***

- Peter finds this amazing and thinks that is a very counterintuitive way to describe what could have easily been the last year of his life

## Finding peace at the end of life through expressing gratitude and finding purpose in serving others [1:16:00]

**What is driving that sense of peace?**

- Peter wants to understand this because as he tries to imaging this being the last year of his life, he wouldn’t take a positive thought from it
  - He’s be very sad
- There are also a lot of 85-year-olds who wouldn’t have much peace knowing that they are at the end

*How do you reconcile the peace that you can have at the end of your life with the fact that you undoubtedly have more to do?*

- First, Walter thinks there is a difference between being 50 and being 85
- When Walter was 60, he was on a cruise at the island of Corsica and had to be taken off to a clinic for an immediate operation
  - He thought, “*Just give me a little more time and I promise I’ll be of service*.”
- He’s been of service, had no intention of doing anything else
  - He hasn’t done any business in the last 30 years
  - It was a natural commitment, and he bought more time
- Walter explains, “*I think if we don’t turn on the flashlight to bring light on what we’ve been blessed with, there is no opportunity to get much fulfillment at the end for the gratitude that these blessings have provided.*”

**An analogy to understand the importance of starting early**

- It relates to whether you’re saving money for your kids’ college, if you wait until they’re junior in high school it’s tough and not much time
- If you want to save for retirement and if you wait until your 60s, it’s really tough

***If you want to start being grateful and you want to wait until your 80s, it’s really tough***

- But if you can build that… Walter hopes he’s building in millions of young people this awareness and expression of gratitude

**It’s not just awareness, it’s an expression of gratitude because they will be enriched by expressing it, and the person receiving it will also be**

- Walter’s dream and hope is when he says, “*Pay it forward*,” most people know what he’s talking about
  - They know the concept of “pay it forward” means if somebody does something nice for you, you in turn will do something nice for three people
    - Not necessarily for the person who’s nice to you

***Walter wants “Say It Now” to become as ubiquitous (as common)  as “pay it forward”***

- He believes that will elevate our own sense of value

**Walter came to 2 conclusions during the last “finishing strong” exercise**

- 1 – He never wanted to leave his wife a widow
  - They’ve been married for 60 years
  - He exercises almost every day because he wanted to outlive her, but he realizes that is not for him to decide
- He realized that if she’s a widow, he wants to take care of her
- 2 – He wanted to finish the project
  - But he’s been doing projects for the last 30 years, and he’s not going to stop doing projects
  - By definition, he will die with an unfinished symphony
  - The nature of life doesn’t stop just so he could finish

**People who continue to have purpose in life**

- Peter thinks back to one of the other friends that Ric introduced to them at the event
  - He was a little over 100 years old and is still working on deals
  - He still talks to Ric about business ideas like he’s 50 years old
- Peter remarks, “*We’ll never truly know the causative nature of having a purpose in longevity, but it’s very hard for me to believe that there isn’t causality there.*”
  - ***People who continue to have some sense of purpose that is far beyond themselves and their own joy and pleasure undoubtedly seem to live longer***
- Walter was thinking today of the phrase “pass time” as in, “*Well, it helps pass time.*”
  - This takes his breath away when someone says that
- For him, it’s purpose time, and he can’t imagine *not* living that way
  - It has given him an extraordinary life, and it didn’t start when he was 80
  - It started when he was in his 20s

***Peter doesn’t want to suggest that the purpose of a person’s life needs to be as grand as Walter’s ambition or stating a new business ‒ it can be simply taking care of another person***

**One of the things Peter does with all of his patients is take a detailed family history**

- He can’t tell you the number of times that he’s heard someone’s grandparents died from some disease and the other one died very shortly thereafter despite being completely healthy
  - They just lost interest in life
  - They died of a broken heart, or they just stopped thriving
  - That’s an extension of this ‒ having that other person there is part of purpose

**Walter acknowledges Peter**

- Walter remarks that Peter is making keen and important observations, and he works really hard on this
- Walter read one chapter from Peter’s book [[*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=3H7LZXIVSMPY1&keywords=outlive+the+science+and+art+of+longevity+book&qid=1704209335&sprefix=outlive+the+%2Caps%2C95&sr=8-1)], the one on emotional health
  - He’s only a one chapter guy
  - But this was the door to understanding Peter
  - It proved to Walter that Peter was really authentic and a person he wanted to connect with
- He thinks Peter is enriching the lives of millions of people through his writings, podcasts, and good work

**We have no training for the most important decisions in life**

- After 60 years of  marriage (the best decision he ever made) he realized that nobody ever helped him be a good husband
- He didn’t have many great models (his father died)
- The same goes for kids

*One of the things that is amazing is why so many marriages don’t last, and there are so many stages*

- Earlier Walter described the 3 stages of his life
- In marriage you’ve got: dating, marriage with no kids, with kids, when the kids leave the house, and then you retire
  - The last chapter is where you slow down a little bit
- Walter explains that he’s married to an energizer bunny who’s slowing down a little
- During the pandemic, he got a chance to love her in a way he never did before

***That’s another thing you never know: you always know you love the person you married, the question is can you always love the person equally or more when they’re not quite the same person you married?***

- Walter loves caring for her when she needs it
- That story Peter just mentioned illustrates that we are so **self-focused**
  - Walter doesn’t know if you can die from it, but you won’t live from it

***Walter explains, “It’s the focus on others that provides me with my energy”***

- During his recent challenge [medical scare] he realized, “*Don’t take anything away from me that’ll prevent me from helping others. I’ll refuse that treatment.*”
  - He just wants to be helpful to others

## Resources to learn about “Say It Now” [1:26:15]

**If someone is listening to this conversation and hearing about this idea of saying it now for the first time and it resonates with them, where do you recommend they start?**

- The website [justsayitnow.org](https://www.justsayitnow.org/) will give you the concept
- There is also his [TED talk](https://youtu.be/eCGd7ya7sUw?si=mqiu6KNxdaezdm-x)

- He has a [theme song](https://youtu.be/KWf07y1k768?si=NE8nImqnJMinBsq1) for “Say It Now”
- In the coming months, there will be a book to explain how to do this
- There are tools right on that website that could help
- Whether it’s a note, a phone call, it is very uncomplicated

**To come back to the story of the fellow who Walter had dinner with a few years ago Walter**

- He asked Walter, “*Well, what do you do?*”
- And Walter said, “*It doesn’t really matter. You can call them and you can do all these things and so the website will help you with that.*”
- This man called Walter about a month later and he said, “*I want to come tell you what happened*.”
  - Walter loves these stories and he always encourages people tell him about it because that is his psychic income in this transaction
- He told Walter that he wrote 17 letters
  - One was to his sister who he hadn’t spoken to in 10 years, and he realized she was a great sister
  - What she did that ended the relationship always bothered him, but when he looked at their life, he realized she’d made a real difference and it rekindled their relationship

> “*It’s easy to do, the outcomes are sometimes very surprising and always rewarding.*”‒ Walter Green

§

## Selected Links / Related Material

**Walter’s new book:** [The Gratitude Express: A Story Inspired by the Say It Now Movement by Walter Green (2026)](https://www.amazon.com/Gratitude-Express-Walter-Green/dp/B0FV228NTD/ref=sr_1_1?crid=PSIV0T5CVIBB&dib=eyJ2IjoiMSJ9.QZ1YNv7k6_FanVznmz2xRw.CFaL490CquA7o_UV70COVHW6juGz4cgXoz9DMS7oF3k&dib_tag=se&keywords=9798891385252&qid=1762879646&sprefix=9798891385252%2Caps%2C146&sr=8-1)
 **Walter’s book**: [This Is the Moment!: How One Man’s Yearlong Journey Captured the Power of Extraordinary Gratitude](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1) by Walter Green (2017) | [1:15, 48:00, 59:00]

**Walter’s Documentary:** [The Say It Now Documentary](https://www.youtube.com/watch?v=mogvN4IVAdQ)

**Previous episodes of** ***The Drive*** **with Ric Elias**: [1:30, 3:00]

- [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) (November 11, 2019)
- [#241 ‒ Living intentionally, valuing time, prioritizing relationships, and more keys to a rich life](https://peterattiamd.com/ricelias2/) | Ric Elias (Part 2) (February 6, 2023)

**Books that inspired Walter**: [keep in format in show notes with more details]

- [Tuesdays with Morrie](https://www.amazon.com/Tuesdays-Morrie-Greatest-Lesson-Anniversary/dp/076790592X/ref=sr_1_1?crid=8ET64QXE5EOB&keywords=tuesdays+with+morrie+book&qid=1703099239&sprefix=tuesday%2Caps%2C102&sr=8-1) by Mitch Albom (2002) | [41:30]
- [Chasing Daylight: How My Forthcoming Death Transformed](https://www.amazon.com/Chasing-Daylight-Forthcoming-Death-Transformed/dp/0071471723/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1703099458&sr=8-1) by Life by Eugene O’Kelly and Corinne O’Kelly (2005) | [42:15]

**Book about what a successful life looks like**: [How Will You Measure Your Life?](https://www.amazon.com/How-Will-Measure-Your-Life/dp/0062102419/ref=sr_1_1?hvadid=580650917415&hvdev=c&hvlocphy=9005495&hvnetw=g&hvqmt=e&hvrand=358498887730473062&hvtargid=kwd-48517363189&hydadcr=21906_13324133&keywords=how+will+measure+your+life&qid=1703175306&sr=8-1) By Clayton Christensen, James Allworth, & Karen Dillon (2012) | [50:45]

**Book written by a hospice nurse**: [The In-Between: Unforgettable Encounters During Life’s Final Moments](https://www.amazon.com/Between-Unforgettable-Encounters-During-Moments/dp/059349993X/ref=sr_1_1?crid=21QJ31PRHBODT&keywords=book+by+hadley+vlahos&qid=1703179799&sprefix=book+by+hadley+vlahos%2Caps%2C109&sr=8-1) by Hadley Vlahos (2023) | [1:03:30]

**Walter’s TEDx talk**: [Why we should eulogize the living](https://youtu.be/eCGd7ya7sUw?si=mqiu6KNxdaezdm-x) | Walter Green TEDxSanDiego (September 21, 2023) | [1:09:00, 1:26:30]

**Website for“Say It Now”**: [Say It Now](https://www.justsayitnow.org/) (2023) | [1:26:30]

**Theme song for “Say It Now”**: [Say It Now](https://youtu.be/KWf07y1k768?si=NE8nImqnJMinBsq1) | YouTube (2023) | [1:26:30]

§

## People Mentioned

- [Ric Elias](https://www.ted.com/speakers/ric_elias) (Peter’s friend, CEO and cofounder of Red Ventures) [1:30, 3:00]
- [Fred Jarvis](https://en.wikipedia.org/wiki/Fred_Jarvis) (1924-2020, British trade union leader) [32:00]
- [Tim Russert](https://en.wikipedia.org/wiki/Tim_Russert) (1950-2008, American television journalist, moderator of NBC’s *Meet the Press*) [39:45, 58:15]

§

![](https://peterattiamd.com/wp-content/uploads/2024/02/bio-waltergreen-500x500.png)

##### Walter Green

Walter Green was Chairman of the Board and CEO of Harrison Conference Services for 25 years. During this time, it grew into the leading conference center management company in the United States. He is a frequent lecturer at the Wharton Graduate School of Business, and Hofstra and Long Island universities. Walter has also been featured as an expert on the topic of effective meetings in numerous national publications. He was associated for years with the Young Presidents’ Organization and the World Presidents’ Organization, and he’s presently a member of the Chief Executives Organization. Since selling his company, he has mentored young adults and is actively involved in several non-profit organizations.

Walter started the Say It Now movement after two pivotal experiences left an indelible mark on his life. The first was a year-long journey to visit 44 people who significantly impacted his life. From this experience, he wrote the book [*This is the Moment*](https://www.amazon.com/This-Moment-Yearlong-Extraordinary-Gratitude/dp/0692981888/ref=sr_1_1?crid=12BPOJ21R0WQZ&keywords=books+by+walter+green&qid=1703096344&sprefix=books+by+walter+green%2Caps%2C97&sr=8-1) where he explains the importance of expressing our feelings for others. The second experience occurred when a friend asked him to organize a celebration of life after his passing, and Walter declined. Instead, he convinced him to have a living tribute for his next birthday, where he would gather those nearest and dearest to him and celebrate how much he’d meant in their lives. The event was so enriching for everyone that it affirmed Walter’s commitment to making living tributes a normal part of our daily lives. Expressing gratitude solidifies relationships and eliminates the prospect of having regrets for things you might have said. It releases warmth. It can even change lives. [[justsayitnow.org](https://www.justsayitnow.org/about)]

Website: [justsayitnow.org](https://www.justsayitnow.org/)