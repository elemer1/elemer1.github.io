# 328 – AMA #66: Optimizing nutrition for health and longevity: myth of a “best” diet, complexities of nutrition science, and practical steps for building a sustainable diet

**Source:** [https://peterattiamd.com/ama66/](https://peterattiamd.com/ama66/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into one of the most frequently discussed and often misunderstood topics: nutrition. From weight loss and maintenance to the intricate relationship between nutrition and exercise and body composition, Peter addresses the complexities of nutrition research and explores the perennial question of whether there is a “best diet.” He provides practical insights on how to choose the right diet for your unique needs, discusses the role of protein and processed foods, and outlines the key questions to help you optimize your approach to eating.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #66 show notes page](https://peterattiamd.com/ama66/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The key nutrition-related topics to be discussed [1:30];
- Why Peter is not fond of discussing nutrition: limitations of nutrition research, the pitfalls of extreme certainty in dietary discussions, and the body’s adaptability to varied diets [3:30];
- Key health metrics to monitor to evaluate the effects of nutrition [9:30];
- The relationship between nutrition and exercise as they relate to weight loss, maintenance, and gain [12:30];
- How increased muscle mass from resistance training impacts calorie burn, body composition, glucose metabolism, and overall health benefits [19:45];
- Comparing the impact of fitness and nutrition on lifespan and healthspan: data showing fitness to be a more significant predictor of mortality than nutrition [23:30];
- The myth of a “best diet,” factors that determine the effectiveness of a diet, and data suggesting benefits of the Mediterranean diet [39:00];
- How long to trial a new diet, the importance of measurable goals, and the appropriate timescales for observing meaningful changes [48:30];
- The inherent challenges in nutrition research: variability in dietary exposures, limitations in study design, the body’s adaptive nature which dampen the effects, and more [51:15];
- Nutritional approaches for chronic diseases like cardiovascular disease and type 2 diabetes [58:45];
- Emerging studies on dietary interventions for non-alcoholic fatty liver disease (NAFLD) and metabolic dysfunction-associated steatotic liver disease (MASLD) [1:02:45];
- Practical considerations for individuals to identify the best diet for them: protein intake, energy balance, macronutrient adjustments, and micronutrient levels [1:06:00];
- Understanding processed vs. ultra-processed foods [1:09:15];
- The effects of ultra-processed foods on health [1:12:30];
- Questions that someone should ask themselves if they’re looking to fine-tune their diet [1:18:15]; and
- More.

---

The Peter Attia Drive

328 – AMA #66: Optimizing nutrition for health and longevity: myth of a “best” diet, complexities of nutrition science, and practical steps for building a sustainable diet

---

## Show Notes


---

## The key nutrition-related topics to be discussed [1:30]

For today, we are covering nutrition, pulling out the most common questions/themes that we get asked about

- Nutrition’s relationship with weight loss and weight management
- How Peter thinks about nutrition compared to exercise
- The complexities of nutrition research
- How Peter responds when asked what is the “best diet”
- How dietary strategies might change for managing chronic diseases
- How people can think about choosing the best diet for themselves
- Protein intake
- The impact of processed foods
- And much more

## Why Peter is not fond of discussing nutrition: limitations of nutrition research, the pitfalls of extreme certainty in dietary discussions, and the body’s adaptability to varied diets [3:30]

**Early Passion for Nutrition**

- Peter began his public career in 2011 blogging about nutrition and initially enjoyed the topic.

**Challenges in Nutrition Research**

- Food research lacks the rigor of medicine, which studies consistent single molecules.
  - See article “[Food Can’t Be Medicine Until We Can Research it Like Medicine.](https://www.linkedin.com/pulse/food-cannot-medicine-until-we-research-like-emily-dhurandhar-zjzjc/)“
- Variability in food composition makes controlled studies nearly impossible compared to drug studies.

*High Certainty vs. Low Data Quality*

- Nutrition discussions often show high confidence despite poor-quality evidence.
- Nutrition stands out as a field where confidence vastly outweighs data reliability.

> “*There is no discipline of science or engineering for which our magnitude of certainty is so high relative to such poor quality data*.” —Peter Attia

*Cult-Like Behavior in Dietary Advocacy*

- Extreme advocates of diets (e.g., vegan, carnivore) speak with unwarranted certainty.
- Peter finds the dogmatic zealotry in diet discussions off-putting.

**Peter’s Gradual Shift in Perspective on Nutrition**

Clinical Experience and Variability

- In  his clinic, Peter observed wide differences in individual responses to the same diet.
- This highlighted the complexity and heterogeneity of human metabolism.

The Body’s Dampening Effects

- Peter explains that the body attenuates dietary inputs, reducing their impact.
  - If you think of an engineering system, there are some systems where when you put a signal into the box, the box amplifies the signal
  - But then you have the opposite is true where you put something in and it dampens the signal—And in many ways the body is that way with nutrition.
    - A lot of the things that people pontificate about on the margins end up being really not that important
- Nutrition effects are often minor once minimum energy and nutrient needs are met.

Foundational Principles vs. Marginal Adjustments

- Core factors like energy balance, protein, and essential nutrients matter most.
- Once you get beyond total energy consumption, our total energy content of the food, total calories, protein content and the essentials within minerals and nutrients, most of the rest doesn’t matter that much—the body’s pretty resilient.
  - You have to hit certain minimums on fat to avoid severe malnutrition and problems that occur there
  - Carbohydrate tolerance is staggeringly variable—You can get away without eating any carbs and still function and you can get away with eating a ton of carbs and still function
  - But beyond those big principles, there’s very little that can be said with high certainty

**Key Takeaway**: Most dietary details beyond the basics fall into low-priority concerns (“fourth and fifth-order terms”) and have little effect on health outcomes compared to the foundational elements.

## Key health metrics to monitor to evaluate the effects of nutrition [9:30]

***What measures of health that relate to nutrition can an individual monitor on their own to kind of understand where they’re at, health-wise?***

Body composition

- Nutrition plays a huge role in anthropometric data/body composition.
- Tools like DEXA scans can measure:
  - Lean mass.
  - Body fat percentage.
  - Visceral fat (if the scan is calibrated correctly).
  - These metrics provide a comprehensive nutritional readout.

Liver Fat Scans

- Specific scans can assess liver fat levels.
  - Liver fat is a direct and detailed nutritional indicator.

Biomarkers of Metabolic Health

- Indicators related to glucose regulation and glucose homeostasis:
  - Continuous Glucose Monitor (CGM) data.
  - Hemoglobin A1C.
  - Uric acid levels.
  - Liver function tests.
  - Oral glucose tolerance tests.
- These biomarkers reflect nutrition’s impact but also capture effects of sleep and exercise.

Inflammatory Markers

- Unexplained inflammation may signal nutritional issues.
  - Example: Intolerance to wheat can cause subtle inflammation detectable in assays.
- Measured through:
  - C-reactive protein (CRP).
  - White blood cell count changes.
- Empirical elimination diets, selective elimination, and reintroduction of these things (e.g., removing wheat or dairy) can reveal how food affects inflammation.

Micronutrient Deficiencies and Excesses

- Blood, urine, or hair testing can detect imbalances:
  - Deficiencies:
    - Common examples include B12 deficiency in individuals who avoid meat.
  - Excesses:
    - Example: Mercury toxicity from consuming large amounts of seafood, especially predatory fish high on the food chain.

Key Categories of Nutritional Health Measurements

- Peter summarizes these measures into four categories:
  - 1 Body composition (anthropometric data).
  - 2 Liver health (liver fat scans).
  - 3 Metabolic health (glucose-related biomarkers).
  - 4 Micronutrient status (deficiencies and excesses).

## The relationship between nutrition and exercise as they relate to weight loss, maintenance, and gain [12:30]

***What about the relationship, or the difference, between nutrition and exercise, as it relates to weight loss, weight maintenance, or gaining weight? What do we know about those two things, nutrition and exercise, as it relates to weight?***

**Nutrition’s Predominance in Weight Loss**

- Peter emphasizes that nutrition plays a far greater role in weight loss than exercise, citing that caloric intake is the primary determinant of energy balance.
  - While some believe exercise can “outdo” a poor diet, this is rarely true for most people.
  - He acknowledges certain exceptions, such as Olympic-level athletes, who may be able to out-exercise a poor diet temporarily, but this does not apply to the general population.
- Caloric deficit remains the gold standard for weight reduction.
  - Calorie restriction can be achieved through direct methods (eating less) or indirect methods (time-restricted feeding or dietary restriction).

**Exercise’s Role in Weight Maintenance**

- Exercise is shown to be effective for weight maintenance, even though it plays a lesser role in weight loss.
  - [Meta-analyses](https://pubmed.ncbi.nlm.nih.gov/17904936/) of randomized trials suggest that individuals who exercise post-weight loss have better success maintaining their weight than those who do not.

![](https://peterattiamd.com/wp-content/uploads/2024/12/f1-ama66-1024x503.png)

**Figure 1.** Source: [Franz et al. Journal of the American Dietetic Association Oct. 2007.](https://pubmed.ncbi.nlm.nih.gov/17904936/)

- Peter references [GLP-1 agonist trials](https://peterattiamd.com/ama64/) to highlight the dominance of caloric restriction for weight loss:
  - GLP-1 agonists, like tirzepatide (Mounjaro), suppress appetite and lead to significant weight loss (e.g., 50 pounds in clinical trials) without affecting energy expenditure or exercise.
  - This underscores how caloric intake, rather than energy expenditure, drives weight changes.

**Case Study: Diet Obesity and Genes Trial (**[**DiOGenes**](https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2021.683369/full)**)**

- Peter discusses a study across eight European countries examining the effects of a super low-calorie diet (800–1,000 kcal/day) followed by randomized maintenance phases:
  - Subjects losing ≥8% of their body weight were assigned one of five diet compositions for maintenance.
  - Findings:
    - Baseline physical activity was not associated with weight loss during the initial phase.
    - Higher physical activity during the maintenance phase correlated with smaller weight regain or additional weight loss.
  - He notes limitations in the study, such as its non-randomized exercise component and reliance on diet intervention.

**Balancing Nutrition and Exercise for Health Goals**

- While Peter argues that exercise receives less attention than warranted for lifespan and healthspan improvements, nutrition dominates the conversation around aesthetics and weight management.
  - For individuals aiming for specific physiques (e.g., bodybuilders), managing nutrition is the bigger challenge than managing exercise.
- If the focus shifts to long-term health, exercise becomes paramount:
  - Preventing chronic diseases like cardiovascular disease and Alzheimer’s.
  - Maintaining physical robustness in later life.
- Despite this, diet cannot be ignored. Consuming excessive calories and gaining substantial weight negates the health benefits of exercise.

**Practical Lessons from Bodybuilders**

- Peter reflects on insights from bodybuilders, who excel at manipulating nutrition for aesthetics:
  - Managing nutrition is universally regarded as harder than managing exercise.
  - While few people aim to look like bodybuilders, many share their goal of having more muscle and less fat, making their approach to nutrition a valuable reference.

## How increased muscle mass from resistance training impacts calorie burn, body composition, glucose metabolism, and overall health benefits [19:45]

Calorie Burn from Increased Muscle Mass

- Peter explains the caloric impact of adding skeletal muscle mass compared to adipose tissue:
  - Basal Metabolic Rate (BMR):
    - Skeletal muscle burns approximately [12–13 kcal per kilogram per day at rest](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2980962/).
    - Adipose tissue burns about 4–5 kcal per kilogram per day.
    - The difference, or “skeletal muscle-fat arbitrage,” is roughly 8 kcal per kilogram per day.
  - Practical Example:
    - Swapping 3 kg of fat for 3 kg of muscle would result in an additional 25 kcal burned per day.
    - A more substantial change, like a 10 kg swap, would lead to an extra 80 kcal burned daily.
      - While this increase is notable, it is unlikely to dramatically alter total energy expenditure for most individuals.
      - Over time, however, this difference could contribute meaningfully to weight maintenance.

Metabolic Benefits of Increased Muscle Mass

- Beyond the slight increase in BMR, muscle mass provides substantial metabolic benefits:
  - Glucose Disposal:
    - The primary site for glucose disposal is skeletal muscle, with some occurring in the liver.
    - Adding 10 kg of muscle significantly increases the body’s capacity to store glucose, improving overall glucose metabolism.
    - Insulin Sensitivity is critical for effective glucose utilization, which tends to improve with muscle-building exercise.
  - Myokines and Endocrine Function:
    - Skeletal muscle acts as an endocrine organ, secreting myokines that contribute to systemic health.
    - These effects promote overall metabolic health and reduce the risk of metabolic diseases.

Feasibility of Significant Body Composition Changes

- Peter emphasizes the time and effort required to build significant muscle mass:
  - Achieving a 10 kg gain in muscle could take years for most people, even with consistent resistance training.
  - Rapid muscle gain is typically only possible with the use of anabolic steroids, which carry significant health risks.

Takeaway

- While increasing muscle mass provides a small caloric bonus (approximately 8 kcal/kg/day), its true value lies in its metabolic benefits.
- These include enhanced glucose storage, improved insulin sensitivity, and systemic health benefits from myokines.
- The caloric advantage should be seen as a secondary bonus to the broader health advantages.

## Comparing the impact of fitness and nutrition on lifespan and healthspan: data showing fitness to be a more significant predictor of mortality than nutrition [23:30]

***When comparing nutrition and exercise, the follow-up question should always be, “For what purpose?”***

- For aesthetic performance (e.g., bodybuilding):
  - Effort allocation is about 70% nutrition and 30% exercise, reflecting the intense focus required on diet to achieve extreme low body fat percentages.
  - For general health and longevity: The balance shifts depending on the goal, with exercise often being the stronger predictor of overall health outcomes.

**Assessing the Extremes of Nutrition and Exercise**

- Peter advocates evaluating the extremes of each domain (nutrition gone bad vs. exercise absence) to understand their impacts on lifespan.
  - Nutrition gone bad:
    - Examples include type 2 diabetes, morbid obesity, and malnutrition.
    - These conditions have a clear and measurable association with increased all-cause mortality.
  - Exercise absence:
    - Assessing fitness levels using objective metrics such as VO2 max, muscle mass, and strength provides a clear readout of the importance of physical activity.

**Hazard Ratios for Poor Nutrition**

- Type 2 Diabetes:
  - Associated with significantly higher mortality risk:
    - [2013 meta-analysis](https://journals.sagepub.com/doi/10.1177/1474651413495703): 85% higher risk (hazard ratio of 1.85).
    - [2015 study in the NEJM](https://www.nejm.org/doi/full/10.1056/NEJMoa1504347) looking at the Swedish National Diabetes Registrar: only a 15% increase in all-cause mortality (hazard ratio of 1.15)
    - [UK Biobank Study](https://pubmed.ncbi.nlm.nih.gov/16681560/) (2006): 93% higher risk (hazard ratio of 1.93).
    - [Emerging Risk Factor Collaboration](https://jamanetwork.com/journals/jama/fullarticle/2382980) (2015, JAMA): 80% higher risk (hazard ratio of 1.80).
  - Consistent findings across studies indicate the robust association between diabetes and increased mortality.
- Obesity without diabetes:
  - Hazard ratios vary due to obesity’s heterogeneity:
    - BMI >30: Approximately 20% increased risk of all-cause mortality.
    - BMI 35–40: Around 40% increased risk.
    - BMI >40 (morbid obesity): A 100% increase (doubling risk).

![](https://peterattiamd.com/wp-content/uploads/2024/12/f2-ama66-1024x826.png)

**Figure 2.** Source: [Visaria and Setoguchi. PloS one Jul. 2023.](https://pubmed.ncbi.nlm.nih.gov/37405977/)

- This chart looks at the hazard ratio for all-cause mortality (ACM) in a large population, and then it further stratifies it as just everybody versus people who have never smoked
- There’s two things that really stand out here
  - One is that smoking plays a bigger role in people who are underweight, and a lower role in people who are overweight
  - And despite that, in both groups you see a really clear pattern, which is at a BMI somewhere between about 22.5 and even up to 30, it’s all the same
  - There’s no real difference from as low as call it 22 up to 30, but then above 30 it starts to rise monotonically
- And similarly, as you go down from 22.5, it also rises monotonically—
  - Why the association on the low end?
  - Why would mortality risk rise as much on the underweight side as it does on the overweight side?
  - Well, there’s lots of things
    - So in that group you’re obviously capturing people who are sick. So a lot of illnesses are associated with weight loss
    - The most notable of these is cancer. But again, that’s not clearly going to explain all of it because we’re specifically looking at people that might not have cancer.
    - You’re looking at other diseases like kidney disease, you might even be looking at things like HIV, things of that nature
    - You’re also looking at frailty. So as a person becomes really, really light, you’re seeing different causes of mortality on the left of this curve than the right of the curve
    - You’re probably seeing fewer people dying of heart disease and dementia, but you’re probably seeing more people dying of cancer and accidents and falls and things of that nature.
- And then at the other end of the spectrum, you see this monotonic rise as weight is going up
- The real point of this figure is just to anchor everybody to the hazard ratios
  - BMI >30: Approximately 20% increased risk of all-cause mortality.
  - BMI 35–40: Around 40% increased risk.
  - BMI >40 (morbid obesity): A 100% increase (doubling risk).
- Quick point on the “obesity paradox”:
  - In other [analyses](https://jamanetwork.com/journals/jama/article-abstract/1555137) when you’re able to tease out metabolic health here, you start to realize that adiposity per se, not really the problem
  - In other words, when you look at people who are overweight but metabolically healthy, they have no increase in their hazard ratios for death
  - So let’s say you compare:
    - A lean person who’s metabolically healthy (BMI of 25, they’re metabolically healthy, they’re insulin sensitive)
    - And then a person with a BMI of 30 who is also metabolically healthy
    - There is no difference in mortality between these 2 people
  - Conversely, say you compare:
    - A person with a BMI of 25 who’s metabolically healthy
    - And another person with a BMI of 25 who’s metabolically unhealthy
    - There will be a big difference in their mortality
  - “*All roads point to metabolic health or poor health being the primary issue, which is heavily related to energy balance, but there are times when it uncouples at both ends of that spectrum*.” says Peter
- Malnutrition in older populations:
- People over 60 with malnutrition face a [hazard ratio of 2.6 to 2.8](https://pubmed.ncbi.nlm.nih.gov/32988726/#:~:text=Similar%20associations%20between%20severe%20malnutrition,malnutrition%20with%20all%2Dcause%20mortality.), indicating a 160–180% increase in all-cause mortality compared to people of that age who are not malnourished

**Hazard Ratios for Poor Fitness**

- [Strength](https://journals.lww.com/acsm-msse/Fulltext/2018/03000/Associations_of_Muscle_Mass_and_Strength_with.8.aspx) (top quartile vs. bottom quartile):
  - Hazard ratios: 2.3 to 2.4 (~130–140% increased mortality risk for low strength).
- VO2 Max:
  - Largest predictor of mortality among all metrics.
  - Bottom 25% vs. top 2.5%:
    - [Hazard ratio](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428): 5.04 (~400% higher mortality risk in the least fit individuals).
  - Bottom 25% vs. top 25%:
    - Hazard ratio: 2.4 (~140% higher mortality risk).
  - Bottom 20% vs. top 20%
    - [Hazard ratio](https://www.sciencedirect.com/science/article/pii/S0735109722052603?via%3Dihub): 4.1

**Key Insights**

- Poor fitness, especially measured by VO2 max, is a much stronger predictor of mortality than poor nutrition.
- While metabolic health issues like diabetes and obesity are important, maintaining high fitness levels has an outsized impact on longevity.

> “*Lack of fitness is a way, way, way bigger predictor of mortality than lack of correct nutrition. Full stop*.” —Peter Attia

## The myth of a “best diet,” factors that determine the effectiveness of a diet, and data suggesting benefits of the Mediterranean diet [39:00]

***Framing the Question: Is there a “best diet”?***

- Peter differentiates between two approaches to the question:
  - Efficacy question (lab setting): Focuses on diets under isocaloric and controlled conditions, titrated to perfect energy balance.
  - Effectiveness question (real-world setting): Addresses how diets work in practical, everyday scenarios for individuals trying to make choices.
- The Real-World Answer
  - The best diet is one you can stick to on most days, maintaining energy balance and avoiding malnutrition.
    - This advice might seem bland but reflects the fundamental truth: adherence matters more than theoretical optimization.
    - Discussions around high-order benefits (e.g., antioxidants or specific properties of a diet) are less important if a person cannot maintain the diet.
- Eliminating Extreme Examples
  - Diets like consuming 2,400 calories a day of KitKats are not sustainable because:
    - They fail to provide satiety.
    - They lead to malnutrition, lacking adequate protein, vitamins, and minerals.
- For the Disciplined Individual
  - For those disciplined enough to adhere strictly to a specific diet:
    - Peter considers the Mediterranean diet a strong candidate for the “best diet.”
      - Conviction level: Not high, not because it’s a bad diet, but because of the variability in individual responses.
    - The Mediterranean diet consistently outperforms diets like low-fat diets in studies, offering:
      - Higher monounsaturated fats from olive oil.
      - Fewer processed grains.
      - A more balanced and enjoyable eating experience for most people.
- Mediterranean Diet Superiority
  - Evidence for the Mediterranean diet’s benefits:
    - Comparisons often made with low-fat diets:
      - Mediterranean diets are superior in nutrient profile and palatability.
      - Easier to adhere to for 99% of individuals.
    - Supported by studies like the [Predimed Trial](https://www.nejm.org/doi/full/10.1056/nejmoa1200303) and [Predimed Plus](https://www.predimedplus.com/en/project/) (ongoing study that compares the control—original PREDIMED intervention—with a 30% CR Mediterranean diet supplemented with EVOO and nuts as well as physical activity), which demonstrate its advantages over low-fat and even low-carb diets.
- Other Named Diets
  - Many popular diets exist, including:
    - Keto diet: High fat, very low carb.
    - Paleo diet: Focuses on whole foods.
    - Atkins diet: A type of low-carb diet.
    - Zone diet: Low glycemic index carbs and lean proteins.
    - South Beach diet: Low carb, avoids vegetable oils.
    - Carnivore diet: Animal products only.
    - Whole30: An elimination diet.
  - The key question for individuals considering these diets:
    - Purpose: Are you aiming for short-term weight loss or long-term maintenance?
    - If the goal is weight loss, caloric restriction is crucial, regardless of the diet type.
    - For maintenance, adherence and lifestyle compatibility are paramount.
- Practical Considerations for Choosing a Diet
  - Sustainability:
    - Does the diet fit your lifestyle (e.g., frequent travel, family meals)?
    - Can you stick to it long-term?
    - Diets that fail during specific scenarios (e.g., 10 days of travel) are unlikely to yield consistent progress.
  - Flexibility with Family:
    - Can you eat from the same foods as others in your household?
    - Shared meals can be adapted selectively without requiring completely separate diets.

**What Is a Mediterranean Diet?**

- General components include:
  - High emphasis on fruits, vegetables, whole grains (not refined), beans, nuts, and extra virgin olive oil.
  - Seafood is a major protein source, with modest amounts of lean meat (e.g., poultry over red meat).
- Challenges:
  - No uniform definition exists for a Mediterranean diet, complicating research.
  - Variability across studies:
    - The “Mediterranean diet” definition often depends on the study or region.

**Analogy with Medicine**

- Peter compares dietary studies to pharmaceutical research:
  - In medicine, drugs have a standardized molecule and dosage.
  - In nutrition, variability in definitions and food composition introduces heterogeneity, akin to studying inconsistent versions of a drug like Lipitor.

## How long to trial a new diet, the importance of measurable goals, and the appropriate timescales for observing meaningful changes [48:30]

**Start with Defining the Reason for Change**

- Before starting a diet, identify why you’re making the change:
  - A measurable reason is critical; otherwise, it’s a leap of faith without actionable feedback.
  - Common goals:
    - Weight loss: Straightforward to measure.
    - Body composition changes: Focused on shifting fat and lean mass, independent of overall weight.
    - Reducing inflammation: Use objective markers such as CRP (C-reactive protein) or white blood cell counts.
    - Improving metabolic health: Target markers like fatty liver disease or insulin resistance, which can be assessed via caloric intake reductions and related measurements.

The Importance of Measurable Outcomes

- A new diet must tie to specific, measurable metrics:
  - Weight: Simple but sometimes overly relied upon.
  - Body composition: Assessed through tools like DEXA scans or body fat percentages.
  - Inflammation: Identified via elimination diets for specific foods (e.g., wheat or dairy) and monitoring inflammatory biomarkers.
  - Metabolic health: Evaluated using metrics such as glucose levels, liver function tests, or insulin sensitivity.

Recommended Timeframes

- Initial changes: Expect noticeable differences within 2–3 months.
  - This timeframe allows for measurable shifts in key health markers.
- Continued improvements: Progress can persist over a year or more, especially for significant metabolic or body composition goals.
- Avoid over-measurement:
  - Frequent assessments (e.g., daily measurements) introduce noise and can create unnecessary stress.
  - Focus on identifying trends rather than moment-to-moment fluctuations.

## The inherent challenges in nutrition research: variability in dietary exposures, limitations in study design, the body’s adaptive nature which dampen the effects, and more [51:15]

**Challenges of Studying Diets Compared to Drugs**

- Unlike drugs, which involve testing a single molecule under controlled conditions, diets involve:
  - Multiple exposures of multiple molecules that vary significantly between individuals and meals.
  - Continuous variables that are interrelated and difficult to isolate in studies.
- Controlled studies in nutrition, even randomized controlled trials (RCTs), often face high variability in participants’ dietary adherence and consumption.

*The* [*Predimed Study*](https://www.nejm.org/doi/full/10.1056/nejmoa1200303) *as a Case Study*

- Overview of the Study:
  - Aimed to assess the effect of diet on all-cause mortality and major adverse cardiac events in a high-risk population with metabolic syndrome.
  - Divided participants into three groups:
    - Mediterranean diet with extra virgin olive oil (EVOO).
    - Mediterranean diet with nuts.
    - Low-fat diet.
  - Each Mediterranean group received free weekly supplies of their focus ingredient (EVOO or nuts) to drive compliance, while the low-fat group only received counseling.
- Key Findings:
  - The study was stopped early due to a large difference in mortality between groups, favoring the Mediterranean diets.
  - Mediterranean diets generally showed superior health outcomes compared to the low-fat diet.
- Criticisms:
  - Performance bias: Compliance differences arose due to incentives provided to the Mediterranean groups (free EVOO/nuts) versus the low-fat group (only counseling).
  - Food frequency questionnaires: Used to assess dietary adherence, but these are prone to recall bias and lack precision.
- Despite these limitations, the study is still considered one of the most rigorous in nutrition research.

**General Limitations of Nutrition Research**

- Recall Bias and Confounding Variables:
  - Epidemiological studies rely heavily on self-reported data (e.g., food frequency questionnaires), leading to inaccuracies.
  - Many confounding variables, such as socioeconomic factors, physical activity, and smoking, make it hard to isolate the effects of diet.
- Lag Between Dietary Input and Outcomes:
  - Many health outcomes (e.g., cancer, chronic disease) take years or decades to manifest, making it hard to establish clear cause-effect relationships.
- Dampening Effects of the Body:
  - Human metabolism is robust and adaptive, capable of tolerating wide variations in:
    - Nutrient quality and density.
    - Caloric intake.
  - This adaptability dampens the effects of specific dietary changes, making it harder to detect clear signals.
- Population Averages vs. Individual Variability:
  - Most studies report average results, which may not reflect individual responses to dietary interventions.
  - Individual variability highlights the need for an empirical approach to personalized nutrition.

Comparison with Exercise Research

- Exercise outcomes are more consistent across individuals:
  - Zone 2 training reliably improves aerobic capacity.
  - Interval training consistently increases VO2 max.
  - Strength training predictably leads to muscle growth and increased strength.
- Nutrition lacks this uniformity, as dietary interventions often produce highly variable responses across different people.

**Conclusion on Nutrition Research**

- Nutrition science is inherently complex and often considered “sloppy” compared to other fields, not due to poor methodology but due to:
  - The biological complexity of diets.
  - The adaptive nature of human metabolism.
  - The challenge of drawing clear causal relationships in highly variable systems.

## Nutritional approaches for chronic diseases like cardiovascular disease and type 2 diabetes [58:45]

**General Principles for Diet and Chronic Disease**

- Most principles previously discussed still apply when managing chronic diseases, but specific strategies may differ based on the condition.
- The goal is to choose a diet that supports metabolic health, weight management, and blood pressure control, rather than focusing solely on improving lipid profiles.

*Cardiovascular Disease (CVD)*

- A patient example highlighted dietary changes to lower apoB levels (a marker for cardiovascular risk):
  - Suggested a low-fat, high-carb diet (20% fat) with no saturated fats to potentially lower apoB.
  - While this approach could improve lipid profiles, diet alone is not the preferred solution in modern times for managing dyslipidemia.
- Modern Approach:
  - In the 1980s, dietary management was critical due to a lack of effective drugs for dyslipidemia (e.g., bile acid sequestrants with poor efficacy and severe side effects).
  - Today, pharmacological options are abundant, highly effective, and typically have minimal side effects. Examples include:
    - Statins (some side effects reported).
    - Ezetimibe, Bempedoic acid, Inclisiran, and Repatha (minimal to no significant side effects).
  - Drugs can safely manage lipid levels, allowing patients to adopt diets that support overall metabolic health without compromising other aspects of health.
- Summary:
  - The ideal diet for cardiovascular health is one that optimizes weight, blood pressure, and metabolic health, rather than targeting lipid management alone.
  - Pharmacological interventions are preferred for managing elevated lipids when necessary.

*Type 2 Diabetes*

- Primary Approach:
  - A carbohydrate-restricted diet is often the first recommendation.
  - Reducing carbohydrate intake is effective for weight loss and addressing the underlying biochemical cause of type 2 diabetes: dysregulated glucose metabolism.
- Rationale:
  - Lowering carbohydrate intake reduces the glucose burden, helping to:
    - Decrease intramuscular fat.
    - Decrease intrapancreatic fat.
    - Reduce the stress on the pancreas.
  - This approach can lead to better blood glucose control and improved insulin sensitivity.
- Role of Exercise:
  - Essential in type 2 diabetes management as it:
    - Enhances insulin sensitivity in muscle tissue.
    - Improves the body’s ability to dispose of glucose into skeletal muscle.

## Emerging studies on dietary interventions for non-alcoholic fatty liver disease (NAFLD) and metabolic dysfunction-associated steatotic liver disease (MASLD) [1:02:45]

**Overview of MASLD and Recent Research**

- MASLD, formerly known as non-alcoholic fatty liver disease (NAFLD), is a metabolic condition linked to liver fat accumulation and dysfunction.
  - *See* [*episode #302 with Julia Wattacheril*](https://peterattiamd.com/juliawattacheril/) *for more on MASLD*
- Peter highlights a [recent study](https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2024.1439473/full) that examined the effects of intermittent fasting (5:2 pattern) versus caloric restriction (CR) on liver fat reduction.
- The study was small, involving 54 participants over 12 weeks, and provides interesting but preliminary insights.

[Study](https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2024.1439473/full) Design

- Two groups were compared:
  - Caloric Restriction (CR) group:
    - Men: 1,500–1,800 kcal/day.
    - Women: 1,200–1,500 kcal/day.
  - 5:2 Intermittent Fasting (IF) group:
    - Men: 800 kcal/day for 2 days per week; slightly higher than CR intake on the remaining 5 days.
    - Women: 600 kcal/day for 2 days per week; slightly higher than CR intake on the remaining 5 days.
- Caloric intake disparity: The total caloric intake for the groups did not perfectly match, which could influence results.

Key Findings

- Both groups achieved similar weight loss:
  - ~4 kg (~9 lbs) over 12 weeks.
- Improvements were observed in biomarkers across both groups:
  - Liver enzymes (ALT, AST) improved significantly, nearing normal levels.
  - Lipid profiles and glycemic indices showed similar improvements.

Unique Benefit of Intermittent Fasting

- Reduction in hepatic steatosis (liver fat):
  - CR group: Moderate-to-severe liver fat decreased from 93% to 60%.
  - 5:2 IF group: Moderate-to-severe liver fat decreased from 82% to 30%.
  - The reduction in liver fat in the 5:2 group was both statistically significant and more pronounced than in the CR group.

Potential Mechanism

- The greater benefit seen in the 5:2 group may be attributed to:
  - Liver glycogen depletion: The intermittent fasting pattern might reduce liver glycogen more effectively, potentially influencing liver fat mobilization and metabolism.

Challenges and Future Research

- The small sample size and short study duration limit the generalizability of the findings.
- Larger, longer-term studies are needed to confirm the benefits of intermittent fasting for MASLD and to identify specific mechanisms.

**Current Therapeutic Context**

- MASLD lacks directly effective pharmacological treatments:
  - Drugs like GLP-1 agonists can indirectly improve metabolic health and liver fat but are not direct treatments for MASLD.
- The findings from this study suggest a promising role for dietary interventions, particularly intermittent fasting, as a therapeutic option.

## Practical considerations for individuals to identify the best diet for them: protein intake, energy balance, macronutrient adjustments, and micronutrient levels [1:06:00]

**Key Priorities in Choosing a Diet**

- Energy Balance:
  - The most critical aspect of any diet is its sustainability for achieving and maintaining energy balance.
  - A diet that creates the right caloric deficit (for weight loss) or surplus (for weight gain) is foundational.
- Protein Intake:
  - Protein is the second priority after energy balance.
  - Recommended protein intake is 1.6 to 2 grams per kilogram of body weight per day (roughly 2x or more than the RDA).
    - Example: For someone heavier, this could amount to about 700 calories from protein daily.
  - Protein contributes minimally to total caloric intake but is vital for satiety, muscle preservation, and metabolic health.

*Macronutrient Decisions*

- Macronutrient Focus:
  - Decide whether to restrict one macronutrient (fat or carbohydrates) based on individual metabolic needs or goals.
  - Example:
    - For individuals with insulin resistance, carbohydrate restriction might be the focus.
    - Use tools like a Continuous Glucose Monitor (CGM) to track and manage carbohydrate quality, quantity, and timing.
    - Set measurable goals, such as lowering average blood glucose from 120 mg/dL to 110 mg/dL.
  - Filling Remaining Calories:
    - Balance fat and carbohydrates around the chosen focus.
    - Avoid reducing fat intake below 20% of total calories to prevent deficiencies.

*Micronutrient Considerations*

- Balanced Diets:
  - Eating a well-rounded diet typically ensures adequate intake of essential vitamins and minerals.
- Dietary Restrictions:
  - If avoiding certain food groups (e.g., meat, vegetables, fruits), be proactive about potential deficiencies.
  - Supplements like B12, zinc, folate, etc., may be necessary for nutrient balance.

*Risks of Extreme Diets*

- Fat Restriction:
  - Diets with less than 20% of calories from fat can lead to deficiencies and are generally not recommended, even for lipid control.
- Balanced Approach:
  - Aim for diversity and moderation rather than extreme exclusion of major food groups.

Additional Resources

- For more details on protein recommendations and why higher-than-RDA intake is beneficial, refer to linked resources covering this topic in-depth.
  - [#299](https://peterattiamd.com/lucvanloon/) with Luc van Loon
  - [#227](https://peterattiamd.com/ama40/) – AMA #40
  - [#224](https://peterattiamd.com/donlayman/) with Don Layman
  - For more episodes and articles, search “[protein](https://peterattiamd.com/?s=protein)” on peterattiamd.com

## Understanding processed vs. ultra-processed foods [1:09:15]

**NOVA Classification Overview**

- Definition: The [NOVA classification system](https://en.wikipedia.org/wiki/Nova_classification) categorizes foods into four groups based on the extent of processing. It is often used by nutritional epidemiologists to assess the level of food processing.
  - Factors considered include number of ingredients and recognizability of those ingredients.

Group 1: Minimally Processed Foods

- Characteristics:
  - Foods with minimal alterations to remove unwanted parts.
  - Processes include crushing, drying, or fractioning.
- Examples:
  - Frozen fruits and vegetables.
  - Pasteurized dairy products.
  - Fresh meat, dried beans, and grains.

Group 2: Processed Culinary Ingredients

- Characteristics:
  - Ingredients made through processes like pressing, refining, grinding, or milling.
  - Typically used in cooking or preparing meals.
- Examples:
  - Oils (e.g., olive oil).
  - Salt, sugar, vinegar.
  - Starches, honey, syrups.

Group 3: Processed Foods

- Characteristics:
  - Foods created by combining minimally processed foods (Group 1) with processed culinary ingredients (Group 2).
  - Includes methods like preserving, baking, boiling, or canning.
- Examples:
  - Salted nuts, cheese, bread.
  - Most canned foods.

Group 4: Ultra-Processed Foods

- Characteristics:
  - Industrially manufactured food products with multiple ingredients.
  - Typically include higher levels of sugars, oils, fats, and salts compared to processed foods.
  - Often contain additional substances for flavor, texture, and shelf life, such as additives and preservatives.
  - Group 1 foods (minimally processed) are usually absent or make up a small proportion of ingredients.
- Obvious Examples:
  - Sugary breakfast cereals.
  - Packaged snacks like chips and cookies.
  - Sodas, energy drinks, candy.
  - Ready-to-eat meals (e.g., Hot Pockets).
  - Protein bars, processed meats, jerky.
- Less Obvious Examples:
  - Ice cream: While the ingredient list may appear simple, it is categorized as ultra-processed due to the manufacturing methods.
  - Pre-shredded cheese: Includes additives to prevent clumping and mold growth.
  - Flavored yogurts, packaged sliced bread, and shelf-stable condiments: Additives and extensive processing move these items into the ultra-processed category.

**Conclusion**

- The NOVA classification provides a framework to evaluate the extent of food processing.
- While obvious ultra-processed foods like chips and candy are widely recognized, less obvious examples such as pre-shredded cheese and ice cream highlight the nuances of categorization.

## The effects of ultra-processed foods on health [1:12:30]

**Key Characteristics of Ultra-Processed Foods**

- Palatability and Nutrient Density:
  - Ultra-processed foods generally taste better and have lower nutrient density than less-processed foods.
  - On average, they are less protein-dense, which may lead to overeating as the body seeks adequate protein intake.
- Examples and Variability:
  - Not all ultra-processed foods have the same health impacts.
    - Examples like protein bars or venison sticks differ significantly from foods like Doritos or sodas, even though they fall under the same category.

**Evidence from a Large** [**Umbrella Review**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10899807/)

- Study Overview:
  - A review of 59 pooled and meta-analyses with nearly 10 million participants explored the health outcomes associated with ultra-processed food consumption.
  - Most data were epidemiologic, leading to inherent limitations.
- Key Findings:
  - Type 2 Diabetes:
    - A 12% increase in the risk of type 2 diabetes was associated with increased ultra-processed food consumption.
    - Evidence showed a dose-response relationship, with higher consumption linked to greater risk.
  - Caveats:
    - Studies used the NOVA classification and stratified ultra-processed food by servings rather than total caloric intake.
    - This methodology makes it unclear whether the negative health outcomes are due to caloric overconsumption or the processing itself.
  - Biases:
    - Socioeconomic and behavioral factors complicate interpretations.
    - Ultra-processed foods are often cheaper and associated with other unhealthy lifestyle behaviors.

**The Heuristic vs. the Nuance**

- Simplistic View:
  - Avoiding ultra-processed foods entirely is an effective, broad-stroke heuristic to reduce health risks.
  - Soda, chips, and similar ultra-processed products offer no nutritional upside and should be minimized.
- Nuanced View:
  - Not all processed foods are inherently harmful.
    - Examples of benign or even beneficial processed foods:
      - Canned tuna, high-quality jerky, tofu, pickles.
  - Processing itself is not the issue; the problems arise when nutrients are stripped, or hyper-palatable foods lead to overeating.

**Broader Considerations and Policy Implications**

- Taxes on Ultra-Processed Foods:
  - Proposals for excise taxes on ultra-processed foods are controversial.
  - Evidence suggests such taxes have limited effectiveness, as seen with soda taxes.
  - The gray area within ultra-processed foods makes blanket policies even more challenging to implement fairly or successfully.

**Conclusion**

- Ultra-processed foods generally pose health risks due to lower nutrient density and increased energy density, but the degree of harm depends on the specific food and individual consumption patterns.
- A nuanced approach that identifies and avoids the worst offenders (e.g., sodas and chips) while recognizing the potential acceptability of certain processed foods is a more sophisticated strategy.

## Questions that someone should ask themselves if they’re looking to fine-tune their diet [1:18:15]

Establishing the Foundation

- Preferred Diet and Sustainability:
  - Start by asking: *Do I have a preferred diet?*
  - Evaluate if this dietary pattern is something you can stick to over time.
  - Consider how to make modifications to align it with your goals:
    - Eating less overall.
    - Adjusting the timing of meals.
    - Restricting or tweaking certain elements.

Protein Intake

- Focus on Protein:
  - Identify your primary sources of protein.
  - Ensure you’re consuming enough protein on most days.

Nutritional Framework

- Nourishment and Calories:
  - Ask yourself: *Am I over, under, or adequately nourished?*
  - Use this question to set your target for total caloric intake.

Metabolic Health and Macronutrients

- Macronutrient Adjustments:
  - Assess your metabolic health:
    - Do you need to restrict carbohydrates, or is energy restriction sufficient?
  - Decide if your preferred diet aligns with your macronutrient needs.

Micronutrient Deficiencies

- Address Deficiencies:
  - Determine if your chosen diet may lead to predictable deficiencies (e.g., a vegan diet might lack B12).
  - Develop a plan to correct deficiencies through supplements or dietary changes.

Overarching Takeaways

- No One-Size-Fits-All:
  - Accept that there isn’t a universally “best” diet.
  - Focus on what works best for your individual preferences, health status, and goals.
- Consistency Over Perfection:
  - Avoid overthinking and stressing about the perfect diet.
  - Prioritize adherence to your chosen approach over seeking the “perfect” solution.

---

## Selected Links / Related Material

**Article Peter recommended**: [Food cannot be medicine until we research it like medicine.](https://www.linkedin.com/pulse/food-cannot-medicine-until-we-research-like-emily-dhurandhar-zjzjc/) | Emily Dhurandhar (linkedin.com) [4:00]

**Meta-analyses of randomized trials suggest that individuals who exercise post-weight loss have better success maintaining their weight than those who do not**: [Weight-loss outcomes: a systematic review and meta-analysis of weight-loss clinical trials with a minimum 1-year follow-up](https://pubmed.ncbi.nlm.nih.gov/17904936/) (Franz et al., 2007) [14:00]

**Case Study: Diet Obesity and Genes Trial**: [Physical Activity, Weight Loss, and Weight Maintenance in the DiOGenes Multicenter Trial](https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2021.683369/full) (van Baak et al., 2021) [16:00]

**2013 meta-analysis finding that type 2 diabetes is associated with significantly higher mortality risk (1.85 hazard ratio)**: [Mortality in type 2 diabetes mellitus: magnitude of the evidence from a systematic review and meta-analysis](https://journals.sagepub.com/doi/10.1177/1474651413495703) (Nwaneri et al., 2013) [28:30]

**2015 NEJM looking at the Swedish National Diabetes Registrar found only a 15% increase in all-cause mortality associated with T2D**: [Excess Mortality among Persons with Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa1504347) (Tancredi et al., 2015) [30:00]

**UK Biobank study from 2006 found a 93% increase in mortality risk associated with T2D**: [Mortality in people with type 2 diabetes in the UK](https://pubmed.ncbi.nlm.nih.gov/16681560/) (Mulnier et al., 2006) [30:00]

**2015 JAMA found a 80% higher risk associated with T2D**: [Association of Cardiometabolic Multimorbidity With Mortality](https://jamanetwork.com/journals/jama/fullarticle/2382980) (The Emerging Risk Factors Collaboration 2015) [30:15]

**Hazard ratios based on obesity without diabetes**: [Body mass index and all-cause mortality in a 21st century U.S. population: A National Health Interview Survey analysis](https://pubmed.ncbi.nlm.nih.gov/37405977/) (Visaria and Setoguchi. PloS one Jul. 2023) [31:00]

**In other analyses when you’re able to tease out metabolic health, you start to realize that adiposity itself is not really the problem**: [Association of All-Cause Mortality With Overweight and Obesity Using Standard Body Mass Index Categories](https://jamanetwork.com/journals/jama/article-abstract/1555137) (Flegal et al., 2013) [31:15]

**Looking at the top quartile vs. bottom quartile of strength, a 130-140% higher mortality risk in the low strength individuals was found:** [Associations of Muscle Mass and Strength with All-Cause Mortality among US Older Adults](https://journals.lww.com/acsm-msse/Fulltext/2018/03000/Associations_of_Muscle_Mass_and_Strength_with.8.aspx) (Li et al., 2018) [37:00]

**Looking at the top 2.5% vs. bottom 25% of VO2 max, a 400% higher mortality risk in the least fit individuals was found**: [Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) (Mandsager et al., 2018) [38:00]

**Looking at the top 20% vs. bottom 20% of VO2 max, a 4.1 hazard ratio was found in the bottom 20%**: [Cardiorespiratory Fitness and Mortality Risk Across the Spectra of Age, Race, and Sex](https://www.sciencedirect.com/science/article/pii/S0735109722052603?via%3Dihub) (Kokkinos et al., 2022) [38:00]

**Peter’s book**: [Outlive](https://peterattiamd.com/outlive/) by Peter Attia (peterattiamd.com) [38:00]

**Studies looking at the Mediterranean diet**: [44:00]

- *Predimed Trial*: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet](https://www.nejm.org/doi/full/10.1056/nejmoa1200303) (Estruch et al., 2013)
- *Predimed Plus (ongoing study)*: [Predimed-Plus clinical trial](https://www.predimedplus.com/en/project/) (predimedplus.com)

**Episode of The Drive about MASLD**: [#302 – Confronting a metabolic epidemic: understanding liver health and how to prevent, diagnose, and manage MAFLD and liver disease | Julia Wattacheril, M.D., M.P.H.](https://peterattiamd.com/juliawattacheril/) | Peter Attia (peterattiamd.com) [1:02:45]

**Small study that showed a 5:2 pattern of intermittent fasting had additional benefits on liver fat than did an equivalent amount of weight loss via caloric restriction**: [Effect of 5:2 intermittent fasting diet versus daily calorie restriction eating on metabolic-associated fatty liver disease—a randomized controlled trial](https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2024.1439473/full) (Wang et al., 2024) [1:02:45]

**Some of the resources from Peter on protein**: [1:09]

- [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) | Peter Attia (peterattiamd.com)
- [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/)  Peter Attia (peterattiamd.com)
- [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) | Peter Attia (peterattiamd.com)
- For more episodes and articles, search “[protein](https://peterattiamd.com/?s=protein)” on peterattiamd.com

**Large umbrella review that looked at the strength of evidence with respect to the outcomes of what happens when you consume ultra-processed food**: [Ultra-processed food exposure and adverse health outcomes: umbrella review of epidemiological meta-analyses](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10899807/) (Lane et al., 2024) [1:14:00]

---

## People Mentioned

[Julia Wattacheril](https://www.giving.cuimc.columbia.edu/profile/julia-j-wattacheril-md) [1:02:45]