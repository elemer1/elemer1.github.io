# #339 – Unpacking trauma: How early wounds shape behavior and the path toward healing | Jeff English

**Source:** [https://peterattiamd.com/jeffenglish/](https://peterattiamd.com/jeffenglish/)

---

Jeff English is a trauma-focused clinical counselor with extensive experience working with adults, teens, families, and groups across various settings, including career counseling, life coaching, addiction recovery, professional workshops, and private practice. In this episode, Jeff shares insights from his work as a trauma therapist, exploring how moments of perceived helplessness shape behaviors and how adaptive strategies can become maladaptive over time. He discusses the concept of the “trauma tree,” examining its roots (causes) and branches (consequences), and highlights a powerful framework used at the Bridge to Recovery, a residential workshop where Jeff operated for over 8 years. Jeff reflects on the transformative power of group therapy, the role of vulnerability in fostering connection, and the challenges of letting go of control. He also offers practical advice on finding a great trauma therapist, balancing personal growth within relationships, and recognizing when it’s time to seek help.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/jeffenglish/the_Drive_public.png)

Play

#339 - Unpacking trauma: How early wounds shape behavior and the path toward healing | Jeff English

#339 - Unpacking trauma: How early wounds shape behavior and the path toward healing | Jeff English

1x15s30s

0:002:02:11

## We discuss:

- Defining trauma—a loaded word [3:00];
- The therapeutic process at The Bridge to Recovery: confronting discomfort, embracing vulnerability, and reframing one’s story [5:45];
- The roots of the trauma tree: the foundational wounding experiences that shape adaptive survival behaviors [11:30];
- The branches of the trauma tree: how trauma manifests through co-dependency, addictive patterns, insecure attachments, and more [17:30];
- The connection between trauma manifestations and underlying wounding experiences, trauma triggers, and the importance of surrender in the healing process [24:00];
- How surrendering control, eliminating distractions, and practicing vulnerability are essential components of the healing process [32:45];
- How adaptive behaviors developed during childhood in response to trauma can become maladaptive in adulthood [43:30];
- The difference between shame and guilt, and recognizing and addressing toxic shame and shame-driven behaviors [49:15];
- The unique rules at The Bridge to Recovery that support the healing process [53:15];
- Internal resistance to healing due to the fear of losing positive traits associated with trauma [58:15];
- The structured storytelling process at The Bridge, and the role of peer feedback in healing [1:05:00];
- The differences between immersive residential therapy and individual therapy, and how to determine the right approach for different individuals [1:09:30];
- Jeff’s personal journey as a client and therapist at The Bridge [1:22:00];
- The generational transmission of trauma, and breaking the cycle [1:25:45];
- The challenge of addressing socially acceptable maladaptive behaviors like workaholism, perfectionism, and overachievement [1:28:45];
- How to determine whether struggles stem from deep-seated trauma or just bad habits, and how rewiring maladaptive behaviors requires addressing the underlying emotional wounds [1:32:30];
- Breakthroughs that shatter beliefs and allows change to occur, and the process that creates this opportunity [1:39:15];
- Jeff’s advice on finding a therapist for trauma work [1:46:45];
- The importance of connection and vulnerability [1:52:45];
- How to encourage a resistant partner to seek healing [1:57:30];
- Jeff’s advice for those facing emotional struggles [1:59:15]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Jeff English is a trauma focused clinical counselor with extensive experience working with adults, teens, families, and groups
- He’s worked in multiple settings, including career counseling, life coaching, addiction recovery, professional workshops, and private practice
- He’s a licensed professional clinical counselor, a nationally certified counselor, and a certified clinical trauma professional
- He’s an outreach specialist at [*The Bridge to Recovery*](https://www.thebridgetorecovery.com/), a residential workshop for individuals suffering from the effects of trauma
- Peter met Jeff in 2017 when he attended *The Bridge to Recovery* as a client, and they’ve stayed in close touch ever since
- In this episode, we discuss the profound impact of trauma
- Jeff shares insights from his experience as a trauma therapist
  - Diving into how moments of perceived helplessness shape our behaviors
  - And how adaptive strategies can become maladaptive behaviors over time
- We explore the concept of the trauma tree, examining its roots and its branches
  - It’s a great framework that they use at *The Bridge to Recovery* that Peter still finds to be the most helpful in explaining what trauma is and how it manifests
- Jeff reflects on the transformative power of group therapy, in particular at *The Bridge to Recovery*
  - We discuss some of the challenges and breakthroughs that can occur in that setting
- We speak about the role of vulnerability in fostering connection, and the challenges in letting go of control
- We speak about the path from understanding to action in trauma integration
- Jeff offers advice on how to find a great trauma therapist
  - Balancing personal growth within relationships, and recognizing when it’s time to seek help
- This is a heartfelt and deeply insightful conversation for anyone grappling with disconnection or seeking to better understand the complexities of their own experience and their own journey of healing

## Defining trauma—a loaded word [3:00]

**Talk a little bit about this loaded word of “trauma”**

- When Peter was first introduced to this idea of trauma, he didn’t know what that meant
- Today it’s become such a catchy buzzword, that everybody is traumatized by something

*How do you describe trauma as a trauma therapist and as someone who’s been doing trauma therapy for many years?*

- The **big traumas (“big T”)** are being in war: Vietnam, 9/11 attack, etc.

***Within the spirit of the work, really embracing a definition: moments of perceived helplessness, that’s what’s going to activate the limbic system***

**⇒** Who is to say what one [limbic system](https://en.wikipedia.org/wiki/Limbic_system) evaluates as helplessness versus another?

- That’s when we get into this discovery most people have made of, “*Wow, I think I did experience trauma*.”
- Jeff works with clients individually and in groups
- He thinks we often make things too complex
- A lot of what he does is try to depolarize for folks
  - Getting into these situations to where we live in this world of “get-over-it, it doesn’t matter”
  - Versus, like Peter mentioned, perhaps we stay stuck in it

**⇒** Moments of perceived helplessness activate the limbic system

*Wounding events ‒ one of those would be a tragic event*

- Life seems to be going one way before this thing happens, and then this thing happens, and life changes and everything is different on the other side of that “big T” event
- Versus someone who maybe you could describe it as “a thousand paper cuts” [“little t” events]
  - Someone growing up, going through childhood, daily being limbically activated, but moments of perceived helplessness
  - That stuck for Jeff, and it stuck for a lot of clients

## The therapeutic process at The Bridge to Recovery: confronting discomfort, embracing vulnerability, and reframing one’s story [5:45]

- Peter met Jeff at a place called [*The Bridge to Recovery*](https://www.thebridgetorecovery.com/) in December of 2017 (7 years ago)
  - Peter wrote about it somewhat reluctantly in [*Outlive*, but without that chapter, the book was incomplete](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=332XL09X5KVN8&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZdGttk3nhLTMuCT6AR1kYNaeU4g3JqQyyTVOqy9epPTjYWTWFg_EpTFIfS29BvAlqV-MGCKIOqwjbeEAmLPaIGB2_d1ac-8gztqTmClOGjOdh0g9qzez_2iEHDS3mBXluOAyfhjl7ww5K-mJr20WA31zcbOEAXzzwxzXihIPtXeKhr611IGY9DXac-NIL5oj3tg1LdEIgb2ITtnkjd2QYi4.SMtKtq3vHiesLISMUOS27rLtIjvbwxbsoJQqyCrgwsI&dib_tag=se&keywords=outlive+peter+attia&qid=1735824744&sprefix=outlive%2Caps%2C95&sr=8-1)

**How a place like** ***The Bridge to Recovery*** **comes to exist, and how therapists like Jeff come to work at places like that**

- It might be shocking to some, how much group therapy is done at a place like that
- When Peter looks back through his journal, it’s amazing how complex it was for him to be able to open up in front of a group
  - He spent the first few days saying virtually nothing, largely because of that discomfort
- In his book, Peter described *The Bridge* as this wonderful, horrible place in the woods of Bowling Green, Kentucky

*Some folks call it residential treatment; some people call it trauma camp*

- Other names Peter wrote down: Camp Misery, The Sadness Factory, and The Tree of Pain
  - Jeff couldn’t argue with any of those

***Jeff describes it as residential treatment for disconnection***

- Most folks think disconnection sounds vague
- When many think of residential treatment, they tend to jump to substance abuse (where people go to get sober)

Jeff explains, “*Disconnection is just the concept that’s used at The Bridge, and one way of disconnecting is substance abuse, but also screens, sex, relationships, ego, anger. So you just take away the substance, take away the word alcohol, and plug in whatever word you want to.*”

**The group process**

- You might have a group of 8 folks, and there might be 3 folks who identify as substance abusers and 2 as workaholics

> “*You may disconnect differently than I do, Peter, but the commonality is that, especially when life throws us a curveball, this disconnected version of me seems to come out, jump in my driver’s seat, if you will*.”‒ Jeff English

- There’s a big part of Jeff that doesn’t want to give away the secrets ‒ let the magic happen
- But you can know everything that’s going to happen, and then you start going through the process, and **discomfort** is what it’s all about
  - That’s when stuff comes up
  - That’s the whole idea
- Monday is admissions day, and counselors would usually meet the groups by Tuesday

*Countless times Jeff has tried to help talk folks off the ledge of leaving*

- In summary, their reasons are an increase in anxiety (the details differ)
  - They may say, “*I came to The Bridge and my anxiety was at a 7. Right now I think it’s a 9. I need to get the heck out of here. This place ain’t for me.*”
  - This is the evidence that *The Bridge* is exactly the right place for them
- Peter remembers that first day (Monday) is a very unpleasant day

**Explain the objectives of phase 1: The telling of one’s life story**

- Getting your history straight
- Many folks have done it before, but here it’s through the lens of what the counselors introduce as “the trauma tree”
  - It’s the “what happened to me” story
  - So many of us for years (sometimes decades) have been telling the story of what’s wrong with me
- From the very beginning, the shift, the hope is to move a little bit closer to what happened to me
  - Not within the spirit of an excuse, but an explanation
  - It makes sense that I do this thing that I do now
- The group process brings up the stuff Jeff calls **“the guards”**
  - Parts therapist will call them protective parts (this isn’t new)
  - It’s “ego states” (new terminology)

**⇒** Guard refers to the protective side of a person that comes up when they get vulnerable

*When does someone get vulnerable?*

- When they get dropped into a different situation
- The first week they’re going to live with new people and share deep information about themself
- The objective, is to start within the technical thing that’s happening therapeutically
- There’s a window of tolerance, and we don’t want to drop into week 2 work (when we start doing experimental therapies)
- Within the spirit of a window of tolerance and experiential therapy, telling your life story is experiential therapy
  - The content is important
  - But so many times, the way the story is told is as important (or more so) than the content of the life story

## The roots of the trauma tree: the foundational wounding experiences that shape adaptive survival behaviors [11:30]

**The trauma tree: describe the roots and branches of that tree**

- This is the meta structure of how the story gets told
- Peter came to understand it as the cause and effect piece of trauma
- Peter has seen many different ways trauma is described and is personally very interested in it for himself and for patients
- He thinks this structure is the best one he’s seen because causality means so much in his world
- He likes the idea that even though it’s not one-to-one mapping where everyone who experiences “this trauma” will have “this manifestation”
  - But if you accept a little bit of randomness in the system, it’s pretty powerful

*The 5 roots of the trauma tree: what tragic (or highly stressful) event happened to me?*

![](https://peterattiamd.com/wp-content/uploads/2025/03/f1-jeffenglish.png)

**Figure 1. The five roots of the trauma tree**.

*1 – Abuse*

- Abuse tends to be the one that is talked about the least at *The Bridge* because that’s the one folks tend to know the most about
  - This doesn’t mean they minimize it
  - There are so many different forms of abuse: physical, emotional, abject, social

*2 – Neglect*

- This is tricky and eye-opening because while abuse is something that happened to me, neglect is something that failed to happen for me
- To see that through the lens of high stress or pain, so many different ways one can be neglected

Example of neglect

- There is the little boy that is going to school and he’s being bullied, and he’s got these parents who are professionals and they’re successful and they’re busy, and they’ve got the best of intentions, but they’re missing it
  - They’re missing the look on this kid’s face when he comes in every day, and before he gets on that bus every morning
  - That question’s not being asked, “*What’s happening?*”
- And so every day, this little person’s being required to go to this place where this thing’s going to happen
  - And evidently these folks at my house don’t have time

**⇒** It’s important to emphasize the word intention, because intention is not required

- So many times Jeff has heard, “*Well, they had the best of intentions.*”
- It still happened (or in the case of neglect, it failed to happen)

*3 – Enmeshment*

- That’s a wounding experience where you’ve got a boundary violation

Example

- That can happen within the spirit of what we call “emotional incest,” where a child is put in an age-inappropriate position
- Maybe the child becomes best friend, counselor and confidant for mom or dad
- And then you’ve just got this engulfing enmeshment, which happens a lot in successful families, where outcomes and expectations are celebrated and not so much the journey
  - That engulfing enmeshment can be one of those situations where this is the way to be more of a “mini-me” relationship between a parent and a child instead of that “I-thou” relationship
- And in those situations with enmeshment, what typically happens is we either drink the Kool-Aid and get on board with it, or we rebel (and I’m not going to do anything that looks anything like this)
  - Neither of those things is probably who I was meant to develop into

*4 – Abandonment is the umbrella wound when we’re talking about the roots of the tree*

Types of abandonment

- 1 – Physical desertion or abandonment (when somebody leaves) is the low-hanging fruit
- 2 – Permanent abandonment: there’s death
- 3 – There’s seasonal abandonment: folks leave for work, military deployment, folks go to prison, parents get separated, parents leave and come back
- 4 – Emotional abandonment, that’s that situation where someone’s there but they’re really not there
  - And this emotional-self gets denied
- And a lot of times when you’re emotionally abandoned, it can be a situation where it’s emotionally cut back
- Meaning the house I grew up in, we did anger
  - It wasn’t okay to be sad, it wasn’t okay to be scared, but we did anger
  - So it wasn’t like we were emotion-free
  - It was just we were cut back to that one
- Then sometimes it’s just the situation where it’s cut off and it’s blank and no emotion
- 5 – Tragic event, that’s another root of the trauma tree (mentioned earlier)

> “*What I mean by the abandonment for me being this umbrella wound is, when you abuse me, you abandon me.*”‒ Jeff English

- Jeff keeps going to parents because those are the folks we spend the most of our time with in our formative years
- But any of these wounds can happen with anybody in our life, and they can also happen anytime in life
  - It’s not limited to childhood
- When you get something happening when the brain and the body’s developing, it gets concrete (gets cemented, gets burnt in)

**⇒** How I adapted to the trauma gets burnt in

- Jeff mentioned that the question is, “*What happened to me?*” but he believes the most important discovery is, “*How I adapted.*”

## The branches of the trauma tree: how trauma manifests through co-dependency, addictive patterns, insecure attachments, and more [17:30]

***When you talk about that tree, we’re talking about the roots being the wounding experiences, and then that top of that tree is the manifestations (if you will) of the woundedness***

- The top of the tree is how I survived

**The branches of the trauma tree are manifestations of the woundedness; these are** ***survival strategies***

- You have codependence, you have addictive patterns, you have attachment issues, and a whole slew of maladaptive survival strategies
- As Jeff says that word “maladaptive,” he wants to wash his mouth out with soap, because they are ingenious damage control strategies

Jeff describes them, “*It’s an old friend that served me well and perhaps now it’s making life hard.*”

![](https://peterattiamd.com/wp-content/uploads/2025/03/f2-jeffenglish.png)

**Figure 2. Four branches of the trauma tree**.

Example

- A 4-year-old boy spending a lot of time in his bedroom playing with the door closed, playing loud so that he doesn’t have to hear what’s going on in the rest of the house
- And then one particular day he hears his mother, in a voice he has never heard before, tell his father that she thinks her arm’s going to be broken
- And the body has to open the door
- And when he opens the door, he sees his mother up against the refrigerator and the boy’s father has got her in a hammer lock, arms behind her, and the little boy’s got to do something, and he’s really outgunned, because let’s say dad’s 35 and he’s 4
- So he starts walking towards them, and the first room on the right is the bathroom
- He goes into the bathroom and he lifts the lid on the toilet and he acts as if he’s vomiting
- And the next thing he hears is, “*Do you hear that? Your son’s getting sick*,” and dad lets mom go
- Now, does the boy go back into his bedroom and get out a little journal and write down, “*Manipulation and deception are very effective in life?*” (probably not)
- But he learned a powerful lesson that day about deception and manipulation
  - It got him out of trouble
  - It got his mom out of trouble that day
- An old friend that served him well, but perhaps is making life hard
- Because healthy folks in adult relationships don’t dig deception and manipulation

***That’s where my “old friend” can get in my driver’s seat and make life hard for me, but it’s a very adaptive skill***

- Some folks would use the language of “a character defect,” and Jeff is not against that language, he just prefers “a skill”

**Peter’s takeaway** ‒ [maladaptive strategies] that’s a really powerful bucket, because it has enough breadth to include things that don’t easily pathologize

**Go back and talk about the codependencies, addictions, and attachment issues**

- Everybody’s familiar with the terminology, but just as within abuse, there are things that people don’t quite think
  - Everybody thinks of sexual and physical abuse
  - Very few people think of emotional abuse or religious abuse

*Codependency*

- An old definition and the one Jeff prefers: codependency is an outer reach for inner security

- I can’t draw that thing from inside of me; I have to get that from something or someone else
- You let Jeff know he’s okay, I can be okay, but if you’re not okay with Jeff, it’s hard for me to be okay with Jeff

*Addiction*

- Addictive patterns: these can be substances, these can be process
- When Jeff talks about **“ego states,”** the parts, my guards, those parts of me that jump in my driver’s seat, he looks at those through the lens of addictive patterns

**⇒** Because it’s that concept of powerlessness

- You’ll hear folks that are in the programs, such as twelve-step programs, they talk about being powerless to something
  - To get into the surrender of being powerless
- You can just take the word alcohol, remove it, and replace it with whatever that behavior is
  - It’s the thing that I do
  - It’s not a bad thing that I can do it sometimes
  - The problem is I can’t not do it

***This could be work, this could be ambition, this could be anger, this could be many things***

**⇒** Usually these things are there for a reason

**We’re back to vulnerability is the enemy**

- The goal of all of these maladaptive coping skills, patterns, whatever we want to call them, is we’ve got to keep Jeff from being vulnerable
- We’ve got to keep that little boy [safe] that had that situation with his mother and that refrigerator
  - We’ve had a bad experience with vulnerability

***So all these parts of me that step in to my driver’s seat, they’ve got a goal ‒ they do their job in different ways, but the goal is to keep me from being vulnerable***

**Attachment styles**

- You get 4 books, and you’re probably going to get 4 different numbers of attachment styles
- Jeff likes simplicity, and the 3 most popular attachment styles are:
- 1 – Anxious attachment
  - It can be clingy, it can be charming, it can look a lot of different ways
  - But the more of me I give to you, the more of you I expect from you
  - That’s going to be the best chance to keep this thing going
- 2 – Avoidant attachment
  - The distance, I can be in a relationship and still not give you all of me
  - I can be with a person but still have distance
- 3 – Disorganized attachment
  - Which is a mixed bag of, “*Come here, come here, come here. Now get away*.”
  - Get you close; now I need you to get back

***Unfortunately, that’s what happened with these wounding situations: the thing what we were created for (belonging and connection) often gets coupled with fear***

- That’s a powerful thing when you get fear (the intensity of that) coupled with belonging

**⇒** You can have 10 different unhealthy attachment styles, but the common denominator is going to be insecurity (that may play out differently behaviorally)

**What does secure attachment look like?**

- Those folks have trust

**⇒** The wounds or roots of the trauma tree are really the story of broken trust, and here are all these things that I do ingeniously to handle that

## The connection between trauma manifestations and underlying wounding experiences, trauma triggers, and the importance of surrender in the healing process [24:00]

**When we examine (in ourselves or others) where one (or more) branches of the trauma tree , is it your belief that that automatically implies there is at least one tie to a root?**

*In other words, is there a scenario whereby these manifestations exist minus the injuring events?*

- With the folks Jeff’s worked with, typically, there’s always a connection
- It gets tricky because it doesn’t need to be A + B = C
- The science of this undoes itself ‒ when you bring this question up, it brings up a stumbling block that Jeff has witnessed with a lot of clients
  - They say, “*Nothing happened to me, I don’t think about that, why do I need to talk about that?*”
  - Jeff honors that as someone’s truth
  - The answer therapeutically within the setting of somewhere like *The Bridge* is, “*Okay, I believe you, so you won’t have any trouble telling your story. It’ll be a breeze for you*.”(you got to roll with that resistance)

*This is where we get into implicit and explicit memory*

A good example is flashbacks

- What comes to mind for most folks is an image ‒  I see this thing
- Then back to this other person who says, “*I don’t think about this stuff anymore. I don’t go into the room and think about my dad cheating on my mother. I don’t even remember that stuff.*”
- Oftentimes, they do ‒ you remember through your **anxiety** perhaps
  - Maybe it’s not an image, maybe it’s not a sound, maybe it’s not a smell
  - But that thing, that **discomfort** that you’re experiencing, maybe that’s the way you remember it

***This example is within the spirit of making the implicit explicit***

The process at *The Bridge*

- After the group is over in the evenings, we usually have meetings where the folks can experience some type of a twelve-step meeting
  - It’s a mandatory part of the curriculum
- We’ve had clients have panic attacks
- The next day when you’re in group trying to unravel something that happened on the previous night
  - We’re talking about this same client that had a panic attack
- And they think they need to see a medical doctor.
- Jeff agrees to try to work it at both ends to unravel this process
- Let’s say this client had control issues
- It’s one of the things we ask you to do at *The Bridge* is give up control
- Client X agrees
- They’re sitting there, they know the exits, they know the people in the room, but for some reason they’re anxious
- That anxiety is building to the point to where they experience a panic attack
- They say they don’t need to talk about any of this stuff everyone is talking about
- Jeff asks them to play along and asks, “*Who’s the most controlling person in your life?*”
- Their grandmother
- Jeff asks them to share one of the most controlling things their grandmother may have done
- The client shares that they lived with her for 3-4 years during childhood, and there was a deal with the basement when they were in trouble
  - They would get locked in the basement
- Jeff asks for how long
- They don’t know, it was dark

***Back to implicit with explicit***

**Jeff thinks about this like files**

- There’s this “loss of control” file in the traumatized brain
- Can he prove that A plus B equals C? No
  - There’s not going to be anything evidence-based that says that was a situation based on that grandmother’s control and abuse in childhood
  - To say that is why that panic attack happened
- But it certainly gives us something to look at
- It’s like coordinates on this war board
- For this client, there’s a part of them that really gets activated when they seemingly don’t have control and can’t leave a situation
- The hope that can come out of that, to see someone who could have been described as resistant to the process, who all of a sudden starts to think, “*Maybe something did happen to me*.”

**There are so many hurdles for people to get over when they begin to entertain the idea that this is something they should look at**

**⇒** The first one is, there’s something wrong

- Peter thinks that as a species, we have so many remarkable layers of protection that we have to be suffering quite a bit to go through this [residential treatment]

*Peter reflects on some amazing lines in his journal*

- “No one can show up here on a winning streak.”
- When Peter thinks back to the 12 of his group sitting in therapy, what a collection of losers
  - They were all on the outs
  - They had lost everything
- They were not there because they wanted to be but because they had no choice

**How often do you see people show up on the basis of pure introspection?**

- As opposed to, “*If I don’t do this, I’m going to lose my family… my job… my life.*”
- Jeff explains that this second choice is the status quo (usually how folks arrive at *The Bridge*)

***Every now and then someone may come in who Jeff would call a “tourist,” but that doesn’t happen much***

- This is hard work and uncomfortable
- If it wasn’t, there’d be a line of people all the way up the hill trying to get into *The Bridge*
- But there’s no line to get in
- There’s also no gate at *The Bridge*, meaning you’re free to go
- It’s usually 7 or 8 folks in a room, and just about every group has somebody in it who has surrendered and realized that their way doesn’t work
  - They’re willing to try Jeff’s way for a couple weeks

***That surrender is a wonderful place to get to and most people don’t get there***

**In Jeff’s many decades as a therapist**

- He often hears people saying their life is pretty bad, but they still know what’s best for them

**⇒** This is where he thinks most of us spend a lot of time

- But when you get in that group circle, that [line of thinking] never mattered because you had your chance
- You’re in group therapy to get a different perspective
- Nearly every group Jeff has worked with had at least one person who was there simply to get somebody off their ass
  - So they could go back and say, “ *I tried your thing and it didn’t work*.”
- But there’s still a chance for something to happen within the group dynamic
- If Jeff tells a client they’re an asshole, they might think he’s saying that from “therapy hill”
- But if a group member tells this person they’re an asshole, there’s this uncomfortable thing they do that makes them an asshone, now they might think
  - Maybe their spouse isn’t the only one who thinks they’re an asshole
- Now they have a chance to examine this and think about doing something different
  - A chance to pinpoint the explanation for why it is hard for them not to do that

***This can be so fruitful, even with folks who are there with less than healthy intentions***

## How surrendering control, eliminating distractions, and practicing vulnerability are essential components of the healing process [32:45]

**One of the huge impediments to people making the journey to a place like** ***The Bridge*****, is that you have to completely cede control**

- When you show up, you hand over your phone and go to your room
- It’s literally a room from a camp
  - You’re sharing a room with somebody else
  - Sleeping on a cot that’s not comfortable
  - There’s no luxury
  - You’re sharing bathrooms with a bunch of other people
- Staff rummage through your books, and they sign off on everything
- It was very limited in what you could bring
  - Basically, you didn’t want anything there that would distract you
  - Peter doesn’t think he could have brought books about F1 and sports or whatever
- For many people who have gone to *The Bridge*, giving up control was the thing that made it almost impossible for them to go
- They had to fall to a certain level of pain before they would go
- Peter knows other people who just haven’t been able to pull the trigger
  - He almost put himself into that situation, thinking it wasn’t possible to go off the grid for 2, 4, or 6 weeks

**Talk a little bit about control ‒ surely you must have a very strong conviction for why it’s required**

- It’s true, some folks can’t do it
- Jeff keeps going back to the word vulnerability
- Within the residential process, they don’t try to induce suffering
- They want to take away as many distractions as possible
- They don’t pretend to know what you need to happen, but they know they have a lot better chance of it happening if you don’t have your phone, your cigarettes, all of these things that help you disconnect

**⇒** They need you to be present, and for some of us, that the vulnerability

*Peter recalls that they didn’t take away exercise*

- If they had, he’s not sure he could have gone
- He was still able to run at 5:30 in the morning in the woods, and do some pushups, etc.
- Had he not been permitted to do that, he might’ve lost his mine

*Has ever been questioned ‒ is exercise a numbing distraction for some people?*

- Excellent point

***Each case is different; there’s no one-size-fits-all***

Often clients will come up to Jeff when the group breaks and ask, “*What do I need to do on breaks or in the evenings? What am I going to do with this downtime?*”

- Some folks need to get serious and might want to read some of the books in the library there
- Some people need to play ping pong
- Peter did a lot of coloring and dot to dot
  - They had super elaborate dot to dots, like a thousand dot puzzles that would actually make beautiful pictures
  - He never thought he could enjoy that

Jeff explains, “*One might say you had to disconnect and come to the hills of Kentucky to find the space to even discover that or rediscover that.*”

- That control thing, it’s not just a client thing, it’s a human thing
- Everyone wants to have a certain sense of control

***Most of the folks who have a hysterical reaction to losing a piece of control, there’s probably a precipitating event and there could be something that needs to be healed***

> “*Most folks who have a hysterical reaction, as we say, ‘If it’s hysterical, it’s historical,’ to the sense of a lost piece of control.*”‒ Jeff English

**⇒** Healing versus integration is tricky: how can we integrate this trauma (this thing that happened)?

***With control, it’s a case study because everything is so connected to the trauma***

**Consider another client**

- This client comes into the group room and is getting ready to check-in
- Jeff says something to start the day, then everything gets quiet until somebody gets nervous enough that they can’t stand the silence and starts checking-in

*Describe what a check-in is*

***Counselors try to let folks experience or start practicing letting their outside match their inside***

- That sounds like a simple goal (it is), but it’s a complex scenario
- Some of us have paid a price for letting our outside match our inside
- The spirit of check-in is to get some rigorous practice with as much honesty as possible
  - How am I starting this day
  - Where am I at right now
  - What on my heart

**⇒** Bringing the heart and head together

- For some folks it’s very personal
- Sometimes it’s the group dynamics

**⇒** Honesty is the beautiful thing about group

- If you can’t get honest with a group member at *The Bridge*
  - Where you’ll never have to see these people again
- How can you get honest with the people who are closest to your heart?

**⇒** Our biggest trauma triggers are the people that are closest to our heart

- The idea is to build some muscle memory in being vulnerable in the group

For example, there may be a client that is rocking back and forth

- It’s Jeff’s job to notice something like that, and Jeff will suggest that this client checks-in first
- They haven’t said a cross word (like hell) in the 1st 3-4 days of their journey
- They start with, “*That was a bunch of bullshit last night. A bunch of bullshit. Nobody told us that we were going to that place. I had to sit out there. I wasn’t going. Nobody told us anything about that.*”
- One of their calling cards when they approached *The Bridge* was that they were thrilled about mentioning nobody on a winning streak
- One of their wins is that their anxiety medication management was finally dialed in
- This thing happened, and 18 hours later Jeff is looking at this person having this response to the fact that Jeff didn’t write on the board every detail that was going to happen that particular day (especially in the evening)
  - When they went to a 12-step program offsite
- Now it’s 16 hours later
- In this scenario, maybe Jeff rolls the dice if he has the rapport and says, “*Well, at least the medications are dialed in*.”
- Perhaps there’s 5 seconds of uncomfortable silence
- Maybe this pissed-off client smiles and laughs a little, and we all sigh in relief
- Maybe a day later, this client tells their story
  - They tell a story about spending a significant amount of time with a spouse who was controlling and emotionally abusive and the spirit of their relationship sounded like, “*Get in the car, you’ll know when you get there*.”

*Back to flashbacks*

- There seems to be “a file” based on this trauma (based on this wounding experience), that was able to push through the medication
- Jeff doesn’t say that the medication is going the wrong way (he doesn’t argue to up the dosage)

***In this example, the discovery inspires hope in a situation where there seems to be so little hope, and maybe there’s something to look at here***

**Peter’s take away**

- He thinks that’s profound because you could argue from this experience that this client needs to up the dose of their mediation
- But at some point, you’re going to become comatose ‒ there is probably a dose at which there will never be a breakthrough, but then you’re also not alive
- So maybe we’re better off taking this as a gift, saying “*Wow, the fact that I got hysterical is now going to point me to something historical that I still need to go and resolve.*”
  - Maybe there’s some work that can be done

***Maybe medication is helpful to get stabilized enough to build the window of tolerance they need to do this type of historical work; but there’s also some work that can be done and we’re not just treating symptoms***

**Day 2 of Peter’s journal, “*****I can’t help but feel like it’s a mistake to be here.*****”**

- How could this place, this experience possibly make a meaningful difference in his life?
- He will try to “*Trust the process…surrender to it*”’
- Peter didn’t journal until he got to *The Bridge*, and now it’s reams and reams of journals that have been filled since

**What fraction of folks show up at** ***The Bridge*** **with a journal?**

- 20% and that number oftentimes go up as Peter described it
- Finding out something different, a different way to do your day
- Being at *The Bridge* is an artificial environment and also a metaphor for real life

**⇒** It’s not just these therapeutic interventions, or what a group member says, or what a therapist says

- All of those things can be powerful
- It’s what are the things that you added to your day, and how can you take that back with you (doing your day differently)
- Checking in with, “*Which me is in the driver’s seat?*”
  - Journaling is an excellent way to do that
- Adding some simple mindfulness, some meditation

**⇒** Life is busy, but when we take a minute to ask, “*Which me is in the driver’s seat?*” (that’s the question)

## How adaptive behaviors developed during childhood in response to trauma can become maladaptive in adulthood [43:30]

**The different versions of “the kid”**

- 1 – The kid that’s born (the unwounded inner child, the original me, the authentic me)
- 2 – The wounded child that goes through this experience (or experiences)
- It’s very important to remind everybody, this could be a bunch of “little t’s,” no of which look like much
- It’s too easy to say, “*I don’t have a big T*.”
- Could be that the sum of the “little t’s” actually matters more than a “big T” in some individuals
- 3 – The adaptive child
  - For example, the kid who figured out that by being deceptive, he could protect his mom (which was clearly the right thing to do)

**⇒** The more time it’s done successfully [adaptive strategies], the more power it takes on

*Other examples of adaptations that occur to trauma are valuable but then they start to become a net negative*

- This is the Darwinian nature of trauma: we’re such resilient, adaptive creatures
  - The case of this kid, that’s brilliant, that’s adaptive, that’s great
  - All the things we do to not succumb

**Other clinical examples**

*So people get a sense of how insidious this can be*

- For example, why when this kid is 30 and he’s in a relationship, and he’s misbehaving and manipulating his spouse (who’s not his father), it starts to backfire

*The concept this brings up for Jeff is “grit”*

- Grit is something we all have, we’re born all born with
- For a lot of us, when a wounding event happens, our grit gets covered up
- So many people survive by submitting and losing their voice (becoming compliant)
  - They may spend decades trying to find their grit
- Other people, out of their woundedness may have survived from grit and lived from it, and the question becomes, “*At what cost? When is it enough?*”
- It’s not the thing that’s bad
- It’s not the fact that I can do it, it’s the fact that *I can’t not do it* (this gets to the utility of it)
- Comparing the “big T” and the “little t”
  - Those thousand paper cuts being an example of a “little t”
- It brings up complex post-traumatic stress
- Jeff doesn’t want to minimize “big T” traumas, those tragic, one-time events

In the spirit of unraveling things in the healing journey and integration, there’s that thing that the client needs to work on and there are several interventions that have been very successful

*The example of a neglected child who was bullied at school*

- Going to school, every day for 3 years, knowing that he was going to be bullied, and knowing that no one was noticing
- They had to develop something to survive that, living in limbic activation
- How many years that muscle memory created “the guard” of that adaptive child
  - It’s repetitive
  - Going back to the “parts” language
- Unraveling something like that is a whole nother ballgame
- In these limbic systems, we only know what we experience

*Examples of abject abuse (horrible stories)*

- A child that knows that when mom gets home, because of what’s happened, her ear is going to be held to the burner on the stove
- Another child that knows there are portions laid out on their plate that will be eaten in a certain way, in a certain manner, at a certain speed
- And after that meal they will be weighed, and their side will be pinched
- And should things not be as expected, there will be a lecture

Who’s to say which one of those humans are more limbically activated?

- The one doesn’t know the experience of the other
- It’s **helplessness**, “*I can’t get out of this thing, this thing I’m getting ready to have to do. So again, how can I survive it?*”
- And how many times does that happen?
- How many years does that take place?
- Then we get frustrated and we have the **shame** bug that goes along with it because we’re back to the, “*What’s wrong with me? Why can I not do this thing? I know this thing’s not serving me well now, but I just can’t not do it*.”
- This is about the utility of the behavior

## The difference between shame and guilt, and recognizing and addressing toxic shame and shame-driven behaviors [49:15]

**How do you differentiate for folks the difference between shame and guilt?**

- For many people, there’s a component of something that you’ve done that’s wrong
- You’ve hurt people along the way, and that’s part of hitting rock bottom that gets you to a place like *The Bridge*
  - It’s not just that you’ve hurt yourself, you’ve hurt others
  - That’s part of this maladaptive behavior that spiraling out of being adaptive

***Guilt is about making a mistake, shame is about being a mistake***

- **Guilt**: I did something that I wish I hadn’t have done
  - I made a mistake
  - I need to make an apology
  - There’s a way back from that

Classic [John Bradshaw](https://en.wikipedia.org/wiki/John_Bradshaw_(author)) talks about “healthy shame” versus “toxic shame”

- **Toxic shame**: there’s a flawed defective core in my identity (there’s something wrong with me)
- There is a way back from guilt, but shame registers differently
- Somebody once told Jeff that their father never had to get sober because he had them and his mother and sister to carry his shame for him

**⇒** Shame can be a generations thing where it comes from somewhere else

*Shame can play out in 2 different ways*

- 1 – Grandiose shame: some of us, when we’re living from our shame, we live out of superiority
  - They are seen from the outside as: I control, I perfect, I judge, I criticize out of my woundedness, out of my shame
- 2 – Inferiority shame: they see themselves as broken and worthless

Peter asks, “*Why do you think one chooses preferentially one of those?*”

- Peter knows that his tendency is always more toward grandiosity than inferiority
- He knows that when his inner monologue becomes more judgmental, that’s a great “yellow light” for him
  - To think about the black and white thinking that permeates what he’s saying
- Jeff thinks Peter has identified it ‒ the conversation that one has with themselves
- Peter has done the work, and is still doing the work
- His journal is just a portion of the work

**⇒** That work and developing that voice is where the hope is

- Folks will think that there will come a time through their healing that they will never get triggered again, but the bad news is, “*You will be triggered again*.”

**The whole integration game is about starting to live a life where you tell stories that go like this**

- I *noticed* that I was starting to be really judgmental
- I *noticed* I was getting triggered
- I had this little short, subtle thought conversation (whatever that looked like)
  - Maybe there was something somatic that happened with my body that I did

***I had this thing that I cultivated, this new muscle that gave me enough space to choose my next step***

- So many of us out of our shame, out of our trauma, have lived a life telling so many stories that go like this: I got triggered and then I did this

***That’s the reaction versus the response. It’s a simple goal, but a complex process***

## The unique rules at The Bridge to Recovery that support the healing process [53:15]

**There were a lot of rules at** ***The Bridge***

- No minimizing
- You’ve got to stand up to get your own Kleenex

1 – Trying to create an emotionally safe place

> “*If we can create a space where folks feel like they can let their outside match their inside, then we got a chance for the magic to happen.*”‒ Jeff English

2 – Learning a new language of “I statements”

- So many of us want to make statements for the world
  - It’s a lot easier to address someone else’s behavior when, “*We’re tired of you doing that*.”
- For example, someone may say, “*When is somebody going to say something to Peter about being 10 minutes late to group?*”
- The appropriate answer is, “*We were wondering the same thing*.”
- Because if I say it weights 10 lbs, within that group process, another peer may say it tends to weight a little bit more

3 – That “Kleenex rule”

- How hard it is for some clients not to give somebody a Kleenex
  - You can have the best of intentions in the world, but out of our woundedness, our trauma, our shame, so many of us, the commonality is professional feeling stuffers (a lot of muscle memory in stuffing emotions, especially sadness)
  - And so the very act of handing someone a Kleenex can cut off something that maybe had been 25 years in the making
- There’s so much more that can come out of that because for the person who’s having the emotion
- Jeff thinks about his healing journey that he’s still on
- And out of his co-dependence, he expected a lot of people to read his mind
  - He doesn’t ask for what he needs
- Maybe he’s sitting there thinking, “*Why the hell isn’t somebody giving me a Kleenex? Can’t they see I’m crying?*”
- And the answer is, “*Because you’re a grown man, you need to ask for them or go get them yourself, Jeff.*”
- And is the person rescuing him from his pain or are they rescuing themselves?

**The importance of language**

- Language that feels guilty
- Learning how to have those “I statements”
- It’s about group dynamics
- Jeff is not crazy about the word “confrontation”

> “*I need to let my outside match my inside. So how can I tell another human being that I’ve got issue with this thing.*”‒ Jeff English

- Learning how to say, “*I get angry when you check-in every day, as if you love this place; and then on our walks in the afternoon, you’re making fun of the process, making fun of the therapist, and you’re talking about the sick behaviors you’re going to do as soon as you get back home.*”
- Jeff didn’t grow up in a house where they talked like that: “When you, I feel”

**⇒** It feels clumsy to say, “*When you, I feel*.”

***The goal is to create some new muscle memory, and to be able to listen to somebody***

4 – We ask for folks to be present

- Present and supportive sounds like the easiest rule
- It’s hard to be present when you’re not in the room
- That’s why we take breaks as a group
  - We try to take them every hour
  - But we always encourage the clients to let them know if they need to “answer the call of nature” before then, let us know and we’ll take a break
  - Because it can be also really handy to go and use the restroom when Jane checks in, because Jane gets underneath my skin every day and brings up something for me that I need to say out loud

***The rules are there with the hope of creating safety so that the magic can happen, and also to give folks a chance at developing some new muscle memory***

- Jeff encourages clients in these scenarios to start off by acknowledging that they’re taking a risk
  - Say, “*I’m getting ready to take a risk*”

5 – Minimizing was a very interesting rule

- It’s an ingenious damage control strategy, back to the utility of behaviors
- The idea is that if it wasn’t that bad, then I don’t need to address it
- But my behaviors also affect other folks
- So when I minimize and say, “*It doesn’t matter. I got abused. So what? A lot of people get abused, you get over it. It didn’t have any effect on me.*”
- Another client will say, “*When you speak as if child abuse, especially physical child abuse doesn’t affect the child, I feel sad and I feel angry. Because you’ve got a right to your own truth, but I know how much that abuse affected me.*”
- That minimizing is very adaptive
- If none of this stuff matters, then I just am, and it proves the theory that something is wrong with me

***It goes back to either something is wrong with me or nothing is wrong with me (superiority or inferiority)***

## Internal resistance to healing due to the fear of losing positive traits associated with trauma [58:15]

**How many folks find themselves in a situation where there is almost a reluctance to get better because there’s also a belief that, “*****Yeah, I get it. My life’s a bit messy right now, and my response is spilling out into bad areas. But look at all the good.*****”**

- Peter felt this way
- He remembers one of the rants that went on about how much good has come from his trauma, and he doesn’t want to erase the good stuff
  - He thinks in telling his life story, it was virtually all good things that came from his trauma
- It sounds ridiculous because on the one hand there’s clearly a bunch of things that are not good, but maybe they think it’s a reasonable price to pay in exchange for all this other [good] stuff

*How do you help people think through that process and what the tradeoffs are?*

- Jeff explains that when Peter described that scenario, it’s like it was his fuel
- He’s using the language of “parts” or “guards” (these protective adaptive behaviors)
- For Peter’s example:
  - Thank God he’s got ambition
  - Thank God he’s got grit
  - Thank God he can get angry and he’s got a voice
  - Jeff doesn’t think he would have met him if he didn’t have these things
- Jeff would say the same thing to an alcoholic, “*Thank God you had that then. I don’t think I would’ve met you should you not have had that.*”

**⇒** But now can we look at this thing and can we just at least look through the lens of is it making life hard?

- An important thing for folks to remember going into:
  - Am I going to do the work
  - Do I need to do the work
  - Am I working on part of me
- These **guards**, these protective parts of self, we’re not necessarily trying to retire them
  - Even though a lot of folks think (and fear) this, like “*How do I exist? Does that mean that ambitious (at times), perfectionist Peter has to go away?*”

**Many folks go through life out of their woundedness always waiting for the the “other shoe to drop”**

- It’s not *if* it’s going to drop, it’s *when and how loud*
- So they are really good and detailed at finding negativity, at finding danger
  - They’d be a hell of a good person to have along a walk in a bad side of town
  - They’d be a great building inspector

***But can you not do that thing when you go home and sit on your couch? (back to the process and vulnerability)***

**Vulnerability can get brought up so many different ways**

- In the group process, the common denominator is the vulnerability is what triggers this protective side, this protective behavior to step in
- And when that happens, we can work on it in real time (should that person consider doing something different)

**Every time Jeff sees Peter reading his journal, he thinks, “*****What must that be like?*****”**

- It’s surreal

*Peter is looking at a note from day 5*

- “We went to 12 step meetings every night and I found it very difficult and awkward. I didn’t understand why we were doing it. I don’t have a drinking problem. Why am I at an AA meeting? I don’t have a sex addiction problem. Why am I at an SA meeting? I don’t have a drug problem. Why am I at the Narcotics Anonymous meeting? It just kept going from one, to the next, to the next, to the next.”
- “The SA meeting last night was amazing. Three men shared painful, shameful stories. One of them said that… he was losing his family, he was losing his wife, he was losing his kids, and he was so upset.”
- “But his sponsor told him that he had no right to complain about how his wife feels. I found that very powerful, and it was like he was taking responsibility for his action.”
- Peter remembers walking into that meeting thinking it was just another meeting he would have to sit through
- These meetings were in a part of town where you’re seeing people on the wrong side of the tracks (not the affluent part of society)
- People are really hurting beyond a “dirty little secret”

**How many people have the same initial reaction, which is, “*****I’m not a fill-in the blank addict. Why do you keep making me go to these meetings every night? By the way, I’ve already done 12 hours of group therapy. Can’t I just go to sleep?*****”**

- 100% of folks whose survival strategy is not substances
- In those meetings, you’re going to take alcohol and put in caretaking
  - Put in control
  - Fill in the blank with your word
- It’s helping folks wrap their brain around having an area of powerlessness
- It’s not always well received at first

Example

- Let’s say a client is there because he’s married to an addict
- Within the spirit of sharing, maybe not in the group, maybe it was overhead, the information comes out that this husband found birth control pills while going through their teenage daughter’s laundry
- The first words out of his mouth, “*What if the people at church find out?*”
- Using a different lens, Jeff would say this person is no less powerless to his image management than his wife is to alcohol
- Because you can’t get into couples therapy, he’s not going to not go to church and tell people that he’s married to an alcoholic

**⇒** The area of powerlessness is image management

***To tell someone that they’ve got an area of powerlessness is not always well received initially, but it can be an “aha moment”***

## The structured storytelling process at The Bridge, and the role of peer feedback in healing [1:05:00]

**The end of week 1 was when we tell our story**

*Talk about what the instruction set was for each of us and we went off and prepared to do that*

- We always suggest that the clients write something out (bullet point it)
- We’d ask that the story be told within the framework of the trauma tree

![](https://peterattiamd.com/wp-content/uploads/2025/03/f3-jeffenglish.png)

**Figure 3. The roots and branches of the trauma tree**.

- These stories don’t need to be void of success and great moments
  - And if it wasn’t for my grandfather and that stuff
- There’s a thing we’re here to focus on: it’s the “what happened to me”
- You’d be given 45 minutes to tell your story, and we try to stay out of the way as much as possible unless it’s therapeutically necessary
- For some folks, “rescue” would be the wrong word, but some folks can get going down the rabbit hole of dysregulation with their emotions and going into detail, so that client may need a little help moving forward
- Whereas another client may machine gun through a story
  - That’s ingenious too: I don’t have to feel it if I don’t stop
  - We might need to slow that client down

**⇒** Tell the “what happened to me,” and the real magic can happen during the feedback

- You get 45 minutes to use your mouth
- Then we ask you to use your ears
- We ask folks to play by **one more rule**: please do not give feedback to the feedback
  - [once you tell your story, you listen to the feedback without saying anything]
- This gets back to the **control** word
  - Because I’ve got this thing, I’m ready to present and perhaps I’ve presented it 10 times, and I’ve got it written out so I feel good about it
  - For example, when I was talking about my dad and what he did, and you start telling me how you felt and what came up for you
  - I don’t know how that’s going to feel for me

**⇒** Almost 100% of the time within the spirit of not giving feedback to feedback is feedback equates to: I’m going to throw some love on you

- Maybe I didn’t have anything in the world in common with you, but when you talked about that thing at 8-years-old, I felt myself getting angry and that’s how somebody lets somebody know I was listening to you
  - I was there with you, 90% of the time at least
- It’s so hard for folks to not give, to just sit there and let somebody share from the heart and to not give feedback to that feedback
- But so many times it’s like, “*Well, my brother had it a lot worse*.”

***It’s like when somebody throws some love on you, it’s almost like out of my shame and my woundedness, I need to remind you that I’m a piece of shit (it happens so often)***

Peter asks, “*How do you break that cycle? It’s very, very difficult.*”

- A lot of folks think that change is about announcing they know what they’re about to do
- This is going to sound co-dependent, if you’re firing on all pistons as a therapist, the response should be, “*Then don’t say it.*”
  - Because there’s enough muscle memory there

***We need to practice the uncomfortable thing of not saying the thing you’ve been saying for years***

- Jeff is the last person to be “black and white” about things
  - Much of his work with clients is finding the “gray area”

**⇒** When it comes to compulsive behaviors, complex post-traumatic stress, and these things we’ve doing doing for years (decades): I’m either strengthening an old connection or I’m building a new one

**When clients ask, “*****What should I do when I leave this group room?*****”**

> “*Do something different and experience what it’s like to do something different.*”‒ Jeff English

- Many times it’s *not* doing something
- He’s taken the vacuum cleaner away from clients before, and it’s an ingenious damage control strategy
- At *The Bridge*, we talk about some deep stuff and you’re expected to talk about your stuff
- He’s encouraged clients to break the rules
- Sometimes you need to take some coffee into the morning meeting, and you’ve been a rule-follower your whole life
  - You were only allowed 1 coffee a day, and it’s not the strongest coffee

## The differences between immersive residential therapy and individual therapy, and how to determine the right approach for different individuals [1:09:30]

**The impact of residential treatment**

- Peter has recommended a number of people go to [*The Bridge*](https://www.thebridgetorecovery.com/) and also to [*PCS*](https://www.thebridgetorecovery.com/) (a place he went to 3 years later)
  - Those 2 places changed his life

*People ask if it’s worth the huge time commitment*

- For Peter, it could not have been done any other way
  - He had to have immersion
- It’s not unlike learning a new language
  - Where if he wanted to learn Portuguese and he’s willing to take lessons 2 hours a week, he’ll get there
  - But if I moved to Brazil and no one speaks English to him for a month, he’s going to get there a lot faster
- It’s not just the sum of the hours, there’s something accretive about the total and utter immersion in the experience that changes it

**How do you think about the work you do and have done at** ***The Bridge*** **(immersive residential treatment) versus working with clients individually for 1-2 hours a week?**

*How would you give somebody the way to think about whether or not they could find some success in individual therapy versus hardcore residential treatment?*

- The answer to can I do this or can I do that is yes, because it’s not a linear path
  - Whatever it takes
  - Whatever works
- Before Jeff found *The Bridge*, he never thought about doing anything residential when it came to being a mental health professional
- Later, he couldn’t imagine doing it any other way
  - He couldn’t imagine doing it without the group process because of all of the things he’s been talking about
  - There’s so much access to vulnerability
- Some folks can’t do something like residential treatment
- Jeff has changed in how he approaches individual therapy ‒ he’s more efficient (but not rushed)
- Working for years within the group process, seeing how that works, synthesizing that into his individual assessments
- The **discovery phase** doesn’t have to be as long as sometimes it plays out to be
- In the individual process, there comes a point where he can present the next level
- On the other side of that coin, a client may choose to go to a residential program, and then they find out all this stuff they can take and integrate into individual therapy

Jeff explains, “*Practicing individually would’ve looked so different 10 years ago because of how the trauma, it’s no one size fits all. And so to think that this intervention needs to be used because it’s my specialty or this has to happen, or this is exactly how long it takes for someone to have a window of tolerance. Every human being is different.*”

**Jeff has met a lot of people that are high functioning, but there’s something missing**

- There’s a hole there

Peter asks, “*Why are they with you? Meaning from their end, from their standpoint, why are they seeking therapy if it seems all right?*

- It could be that they’ve been exposed to something that let them know maybe they’re not all right
- Oftentimes a client comes to see him to get somebody off their back, somebody who says, “*You need to go do some work, you need to go get some help, you need to get to go help.*”
- It becomes pretty evident whether the person is there for that reason or for something more authentic and for self

“*I think part of my paperwork should also include” ‘Jeff English cannot fit a square peg into a round hole,’ which oftentimes translates into I can’t change somebody else’s behavior in your life.*”

- So often, Jeff is seeing people who have gotten to the point of being willing to talk to somebody

**One of the things that is remarkable to Peter about** ***The Bridge*** **is that everybody who worked there had been a client there**

- This is true for all of the clinicians and some of the staff members
- Jeff can’t imagine working there without having done that
- That honesty has been the reason why some folks won’t work at *The Bridge*
  - They don’t operate from “therapy hill” ‒ they’re on their own journey too
- To be able to look at a client like yourself and say, “*I’m literally not going to ask you to do anything that I haven’t done.*”
  - And to be able to say that from the heart
  - That’s an amazing feature
- Peter agrees, people are right to be frustrated when they have a doctor who’s asking them to take care of themselves when the doctor clearly doesn’t take care of themself
  - How is it that you can tell me that I need to eat better and exercise when looking at you, it’s clear you’re not doing those things?
- It doesn’t mean that the advice is incorrect or that you shouldn’t listen to it
- It’s you’re asking me to do something you won’t do
- Whereas at *The Bridge* we can talk about some of the other things that are very difficult to do
  - Such as in the second week when you’re beating the shit out of things, those are not easy things to do
  - But to know that when Jeff and Julie are asking you to do it, they did it

*The journey at The Bridge starts with counselors disclosing and showing a piece of their soul*

- Some professionals are very careful about self-disclosure
- Counselors tell a little about themselves to start building that rapport early
  - They want the clients to trust that they can lead them
- That is one way of doing **experiential therapy** ‒ the somatic part of what they do

*Within the spirit of that process, Jeff loves that Peter described it using the analogy of learning a new language*

- You are immersed in that
- It’s being able to experience the emotion, hijacking the emotional brain
- Jeff likens it to walking you down to the edge of the river and putting your foot into the water
  - The water being your past, your pain
  - He wants you to feel a little bit of the temperature
- The counselors are going to stand beside you and their job is to keep you in the present

***Dual awareness, that’s the integrative part***

- Some people need to learn that they’ve yelled and they were able to not get lost in it
- Everybody’s journey is different and befriending
- Sometimes we’re activating your limbic system so that you could do something different while activated

**⇒** Learning how to get space from your emotional brain

- For many clients (especially clients with trauma), learning coping skills with therapists in safe offices, they do beautifully within that environment, but it’s really hard to recreate that back at home or at work when triggered

> “*My coping skills live in a part of the brain that gets hijacked when the emotional brain takes over, and this doesn’t always have to be about trauma*.”‒ Jeff English

**Jeff shares his personal example**

- His mother is 87 and has dementia, she lives in a nursing home
  - All the irrationality that goes along with that
- When Jeff visits he starts noticing that each visit starts with his mother talking about someone stealing her blue ink pens and her “old lady” blue jeans
- He asked her, “*Are you kidding me? Who would want your blue ink pens? Think about this rationally Mom. Who wants these old blue jeans?*”
- This is how the visits started, and it just went downhill from there
- He would sit in his truck outside before a visit thinking, “*Brain, give me what needs to happen here*.”
- Jeff shares that so many times as a clinician, he takes off the “therapist hat,” but he realized he needed to put it on
  - Because Jeff the son is sitting in front of his mother who is facing the reality that it’s not his mother anymore (and that’s very sad)
  - It’s more comfortable to be in anger or frustration and argue with his Mom about how irrational this though is
    - He doesn’t want her to think people are stealing her blue ink pens
    - He wants her to change
- But he’s forgetting one of the **golden rules of change** when it comes to therapy: rolling with resistance
  - [he needs to be Jeff the therapist]

**⇒** One of the golden rules of change: the more Jeff fights for change, the more this other person is going to fight for the status quo

- It happens 99% of the time

***But when you sell crazy back to somebody ten-fold, they start to suggest rationality***

Example

- One day in that truck, Jeff realized he had to do something different, so he went in there with his executive function
  - He went in there from the prefrontal cortex
- When his Mom started talking about her blue jeans and her blue ink pens, his response was, “*You know what? You’re right, and I think I know exactly the lady that’s doing it. I’m going to give her a piece of my mind*.”
- What did his Mom say? “*Jeff, sit down. Be sensible.*”
- [Visiting his mom, Jeff] didn’t have access to those counselor skills
  - Access to something he does all the time with clients: selling crazy back to them
- He would tell clients, “*You go home, you’ll get your cigarettes back, you’ll get your phone back, you’ll go back home, you’ll go back to your perfect girlfriend, and life will be okay.*”
  - They say, “*Well, I didn’t say life is okay*.” (we have something to talk about)
  - Jeff didn’t say, “*You got to stay here. You’re going to die if you don’t change.*” because they just fight for the status quo
- In that nursing home with his Mom, there’s all the baggage of being the son trauma related to Mom

***But to be able to get access to what some folks call “the bill-paying brain”***

## Jeff’s personal journey as a client and therapist at The Bridge [1:22:00]

**Jeff was a client at** ***The Bridge*** **in 2016**

- A year before Peter
- But he had been a therapist for many years before

Peter asks, “*How did you find The Bridge?*”

- One of Jeff’s mentors sent him an email and said, “*I know your story. I know your background. I think you ought to check this place out*.”
- To grow up in Bowling Green, Kentucky and not know this place that’s existed now for 50 years, it says something
- Jeff had a certain mindset about what residential therapy would look like and residential treatment, so he was just blown away and privileged to be able to do the work (it’s a gift)
- Some folks don’t want to do it and that can be the reason that they won’t join the team
- Jeff wasn’t crazy about doing residential treatment either
- He knew there was stuff that he was still working on and will still be working on, and it was going to be very vulnerable
- In one way he thought of it like, “*This is an audition. You want to know all my crazy?*” and they’re like, “*Yes, we do*.”

**What attracted you to this field?**

- Jeff has done a lot of different things: sales, marketing, building fences
- He studied psychology as an undergraduate, and then there was a gap between him realizing this is what he needs to do
  - The self-discovery part
- It began with him doing his own work
- Then to see someone get a taste of hope and be a part of that ‒ it’s a privilege
- He tells clients, “*You’ve got it in you. Maybe I can create a space where it can come out.*”
- Jeff doesn’t take what he does lightly, nor what clients trust him with

Peter asks, “*I think you have a really special talent for it, Jeff, and I just wonder, is that something that only comes because you’ve experienced the pain as well? Does someone have to have necessarily been through this journey to be able to guide someone through it?*”

- Jeff doesn’t think it’s necessary, but it sure as hell helps
- The depth of the connection with the heart and the work
- It’s one thing to say I’ve got a purpose in my profession, I do something that matters
- But does that thing matter to me? It does
- For Jeff personally, the weight of that purpose is from the pain, in addition to the hope
  - Having that type of impact to where he feels like he heals a little bit each time he helps somebody integrate their trauma

**Jeff has had some amazing things happen in the group room**

- He doesn’t need to be doing his therapy while he’s leading a group
- But certain things he would do on an art therapy
  - He uses the same scene on the board time after time because that’s something he’s tried to unpack and process and he doesn’t need to do anything new
- Then to be sitting there and because of something that happened in the group room, he realizes that he looked at that scene and drew it on the board differently, and it’s personal

**We talk about with trauma how it’s shame**

- It’s something that has touched Jeff’s family
- Unfortunately, not much of his family is left ‒ his sister passed away in 2014

## The generational transmission of trauma, and breaking the cycle [1:25:45]

- Jeff alluded to the generational nature of trauma
- [Terry Real](https://terryreal.com/embrace-intimacy/reactivity-and-trauma-tr/#:~:text=Terry%20Real%2C%20LICSW%2C%20is%20an%20internationally%20recognized%20family%20therapist%2C%20bestselling%20author%2C%20and%20sought%2Dafter%20speaker.%C2%A0) has written about this in some of the most eloquent ways Peter has seen
- For some people that can be the motivation to change once they realize that there’s a pattern and that it’s not linear
- If you have a belief that it’s linear, then it’s really easy to say, “*Well, I’ve already stopped it.*”
  - For example, if your parents were alcoholics and you’re not, the story’s over and I don’t need any help regardless of whatever other behaviors I’m manifesting
- But if a person can accept that, no, that’s not how it works
- There could be this type of trauma in generation G minus 2, that manifested as a different trauma in G minus 1, and now here in G 0 where you are
  - And you have this blind spot to what’s going on
- For Peter, that was among the most powerful motivations to stop the cycle as Terry described it

**How much do you think that factors into people’s willingness to endure the challenges and discomfort of the journey?**

- Oftentimes, it becomes pivotal in willingness and in that surrender game that Jeff mentioned
- As a parent, the most important job is in my opinion, that my children go to bed and wake up safe
  - They don’t grow up in fear
  - The parent a lot to do with that

> “*But like they tell you on the airplanes about your oxygen mask, you’ve got to have yours on first.*”‒ Jeff English

- They discussed why Jeff does this job and what he gets out of it
- To know clients on a different level because doing the work is hard
- Sometimes at the end of the day when you need to have that hard discussion with somebody
  - When a boundary needs to be set
  - When conflict resolution in a relationship needs to happen
- At the end of the day, being a parent, when people finally go to bed and the house is quiet, you just want to watch Netflix
- To understand what can happen when you put off these things, and things start to build and build
- Then when the levy breaks, he’s the worst version of Jeff

***If he lets that happen, what about the next generation? It’s a responsibility on a whole different level, but a gift too***

**The misconception mentioned earlier: at least I’m not an alcoholic, that means that I’m not as bad as my parents and there’s no work to be done**

- There’s so many ways you can have an unhealthy impact on the next generation

***To be in a place where this is it: you have the opportunity to change this thing, to reverse the cycle***

## The challenge of addressing socially acceptable maladaptive behaviors like workaholism, perfectionism, and overachievement [1:28:45]

**You must encounter a lot of people who have these socially acceptable maladaptive behaviors**

- In many ways, it makes it even more difficult to reconcile because society is externally sort of patting you on the back for your workaholism, your perfectionism, your achievements and all of those things

*Is one pattern in your view, harder to address than the other, or is it all about the individual?*

- In other words, if you think about the individual characteristics, the manifestation of the trauma, and the nature of the injuries?
  - Those are 3 things that are all blended
  - Do you try to disentangle those when you’re working with people and pattern recognition
- Or do you just say, “*No, every person’s a clean slate and we’re just trying to figure out how those three things fit together?*”
- This second one is the place Jeff tries to operate from (out of his humanity as a clinician)
- There are client files and sometimes it needs to be said, “*You know, I’ve seen you before, right?*”
  - It’s not always appreciated
  - But sometimes it lands
- For Peter, that’s a very calming message to hear, “*You know what, Peter, you’re not unique here. There are lot of people like you out here.*”

> “*It’s really easy to think you’re the only one.*”‒ Peter Attia

- There’s certain interventions that tend to go along with certain personalities or certain maladaptive behaviors
- But to the best of his ability, Jeff approaches each client as a clean slate
  - What is this person telling me, how are they telling me?

**Peter has seen examples where everything they are talking about has been taken too far**

- There’s a [story](https://www.amazon.com/Bad-Therapy-Kids-Arent-Growing/dp/0593542924) about a teacher who started every day with her schoolchildren, basically trying to get them each to talk about what was making them sad
- The story digressed so much
- One kid would say, “*Well, I’m sad about the fact that something happened*.” ‒ and it was legitimate
  - It sounded actually quite traumatic in that kid’s life
  - They were getting yelled at all the time at home or locked in a room and it sort of derailed their ability to do anything
- This is a group of kindergarten kids that ought to be learning how to write and color and stuff like that

***Everything was being pathologized for them***

*What do you say to the person listening who says, “We’ve gone too far”*

- Who think that some of the people Jeff works with have genuinely been abused and deserve to be there
- But aren’t we just coddling people too much, and don’t people just need to buckle up?
- Isn’t this what makes us who we are?

***Yes and no***

- Jeff is certain those things are happening
- He would not be comfortable painting a broad brush and saying we are going too far
- Jeff is back to depolarizing things
- Most of the folks he meets through therapeutic work grew up in much more of an environment of, “*Get over it, buck up*” than the other end of the continuum where everything is trauma
  - Let’s not box ourselves in

*Jeff worries about the example Peter gave*

- Kids can be mean, and is that the space for that?
- It can be powerful for children to learn about their emotions, but to be guided by them, that’s a tricky statement
- Jeff would hope the spirit of guiding is learning what the behaviors are
  - Learning when the time and place for emotional attention is
  - And the time and place that it’s not for

***Jeff’s experience comes from individuals typically who are from the far other end of that [spectrum]***

## How to determine whether struggles stem from deep-seated trauma or just bad habits, and how rewiring maladaptive behaviors requires addressing the underlying emotional wounds [1:32:30]

**What would you say to a person listening who is trying to understand if they’ve experienced trauma?**

For example

- A person who’s either introspective enough to realize that some of those things we described as the 4 branches of the trauma tree
  - Whether it be codependency, attachment disorders, some sort of maladaptive behavior, maybe addiction
- If they’re honest they might say they’re not flying on a perfect level
  - Their spouse has complained about X, Y, & Z and there does seem to be a bit of interpersonal discontent in this relationship
- They may look at the 5 roots of the tree, but they can’t make the leap to say does any of that stuff rise to the level of trauma (even “little t” trauma)
- Is the answer that they need to get their act together and drink a little less, and try to be more present with the kids?
- It doesn’t matter what the fix is, but they’re just not sure that going back and stirring the pot of what happened to them during the first 10 years of their life is going to be an exercise worth engaging in

*How would you help that person decide that it’s probably not worth stirring that up? Let’s work on some behavioral tools to address the behavior, versus I don’t think you’re ever going to truly fix these things until you go back to the root?*

- Starting with the behavioral tools is a perfect way to approach it
  - Put together a plan to do this less and do this more
- He’s coaching the client in goal setting and not doing a therapeutic intervention
  - And if it happens, it happens
- For folks who realize already they they have trauma (or have been wounded significantly), sometimes the word just trips them up

**We call them “wounded survivors,” and they have a really hard time putting knowing into action**

- Jeff spent many years as a very well-informed prisoner

***Jeff knows all this stuff about why it is he does the things he does, but putting that into action is hard***

- What Peter said about not doing ‒ that’s where we get to realize and admit to self when they go back to their therapist that the goal is still failing (if that’s the fact)
- Perhaps there is something significant connected to this, and maybe something needs to be integrated
  - The part of you that is unwilling to do this thing that you say is the goal and the plan, that’s the part we need to work with

Peter asks, “*How do you begin to do that integration?*”

**Back to the tragic example of the 4-year-old boy that learned how to manipulate and deceive to protect his mom, who now carried that behavior into his marriage**

- 1 – Step 1 is getting to the point where we uncover that story and make the connection
  - Which was, an inner child is wounded, that inner child adapted with a strategy that was very positive
  - Everything about that strategy made sense, but guess what? Your dad isn’t hurting your mom anymore because luckily she got a divorce and he’s gone
  - You’re now applying that same behavior pattern in relationships that have nothing to do with the relationship in which that was developed to be protective

*How do I go from the understanding of that, to creating a new pattern of behavior?*

- Because this is really wired ‒ these paths are heavily, heavily myelinated at this point
- 2 – We’re going to have to expand their window of tolerance to vulnerability
  - With that protective behavior, the enemy is vulnerability
  - They need to create some muscle memory doing something different when vulnerable
- The exercise at *The Bridge* of simply sitting still for some folks is a very vulnerable experience
- To create an environment where that person can experience the discomfort
- Within Jeff’s work (and many professionals), he’s looking at individuals from a “parts” perspective
  - There’s different systems, different theories: internal family systems, structural dissociation
  - This original self, this wounded self, this adapted self

**⇒** The adapted self tends to have some really hard line beliefs

- Safety equals control
- Safety equals distance
- Safety equals self-abandonment
- Safety equals somebody else
- And as long as that part of self has that core belief: I believe it’s going to be damn near impossible to do those things that I know I should do

***So to know that there are interventions that will fit that process, the first question is, do you have an issue with this?***

- A client at *The Bridge* is there because their spouse is fed up and is going to leave them
  - They’ve come to *The Bridge* because their spouse said they needed to go to a place like this
  - But they don’t think they have a problem at all
- Jeff’s response: what do you mean? You can keep being you
  - You’ve just got somebody telling you now that they’re not going to deal with it (maybe they are the biggest controlling jerk in the world)
  - All you need to do is go find another doormat
  - I’m just hearing you say your spouse is not, so you decide whether there’s a problem there or not

***This behavior, that’s become the problematic behavior, how difficult it is to unravel and stop doing that behavior, again [that is] tied into the trauma***

- Tied into it being an ingenious damage control strategy at a time in life perhaps
- And perhaps done multiple times successfully
- So there’s a part of self that says, “*Why not do this? We’ve been doing pretty well like this for a long time*.”

## Breakthroughs that shatter beliefs and allows change to occur, and the process that creates this opportunity [1:39:15]

**Peter had moments along this journey of really significant breakthroughs in beliefs**

- He assumes he’s not unique in this
- It’s mostly that a belief gets shattered
- This is one of the real joys of having a journal ‒ you can go back and read what that was like
  - Read on this day, through this exercise, this really profound thing happened
- Peter wrote about 2 of them in the last chapter of his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=248CIB1H26QA4&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZdGttk3nhLTMuCT6AR1kYNaeU4g3JqQyyTVOqy9epPTjoQrN-GM5OR5wnjsDW0qHCREIlf1QCh-YXGtalJ7hMlEAu3wyXkdxyx1IN0-rclo7m9Y88ZN3GXLAj1NGGiL_zVrEyN6oQEG6qk0XBaMa5--ohQhTlbqd8Jy14oetanWZNtpo3qDAcJAtKzOiJS7v_t0FwRl7ru1Bkkit1hl91vw.0RJO0u9ciiWx1lhjsRB8zxccbgiGD87gdKMU0mG2kHI&dib_tag=se&keywords=outlive+peter+attia&qid=1736345796&sprefix=outlive%2Caps%2C98&sr=8-1)
  - He wrote about one of the at [*The Bridge*](https://www.thebridgetorecovery.com/) and one at [*PCS*](https://pcsintensive.com/)
  - These were undoubtedly 2 of the biggest breakthroughs in beliefs he’s ever had, and they happened in an instant

> “*They’ve had a far greater impact on anything in my world… They were huge step-function changes in a radical belief system*.”‒ Peter Attia

- What is interesting is how much easier it became to make change after this
- He never wants to represent that he’s better ‒ we’re all in recovery
- But when he thinks about December 2017 or April/May 2020, on those days when this happened within an instant ‒ he doesn’t understand the neurobiology of how it happens, but something really switches
- And he never looked at the world the same way he did before

***The shattering of the belief system, is the acceptance of something that is more honest and more close to the innate child that we all were***

*Is it common that people have these major life-changing appreciations of something? Secondly, is that by itself sufficient sometimes to drive change?*

- Jeff would be careful with the word common, but it happens a lot
- He hears about it the way Peter described it ‒ months (sometimes years) later
  - It hit me one day
  - I was incredibly compelled to do it the old way and I heard something so-and-so said in my ear (something against that belief system)
- That’s what’s so tricky about experiential journeys using experiential therapies (like the process at *The Bridge*)
  - Going to a group therapy process, residential treatment is an experiential intervention
  - To be able to put your finger on what exactly was it? [is difficult]
  - And can I prove that it was the thing?

*Back to Peter’s experience*

- In both cases for Peter, a therapist was pushing very hard (but kindly) against a set of assumptions
  - Peter was offering up the same answer, and the therapist was asking, “*What about this?*”
  - Peter would describe it as a loving confrontation, that when fully backed into a corner, in an unthreatening way, collapsed the scaffolding of a mental model
- Jeff knows these moments and they are common
- He’s got so much gratitude sitting here, hearing Peter describe this
- The spirit of Peter’s example, putting himself in a position for this to happen
  - There being a process to get this guarded version of self out of the way enough to allow something like that to happen

***There’s a lot going on to cultivate that possibility***

**That is the lesson Peter wants people to learn from this**

- In science, there’s a quote from [Louis Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur) that says, “*Chance favors the prepared mind*.”
  - The idea is that great scientific breakthroughs don’t just happen, they happen to people who are toiling in the lab
  - Failing, failing, failing, trying again, trying again, constantly thinking about the problem
  - Usually something lucky happens that trips them in the direction of a discovery ‒ it’s often very much an accident
  - But that accident can’t happen if you’re not on the field (the accident doesn’t happen if you’re in the stands)

***You’re very unlikely to have that eureka moment if you’re not mired in the trenches of going through the painful work of figuring out your story***

- Understanding and trying to create the map of what’s happening

**⇒** It’s unlikely to happen when you’re continuing the distractions or the numbing behaviors

**The frustration with individual, one-on-one therapy**

- Jeff has heard many therapists ask why somebody would go to a residential program that wasn’t an addict of alcoholic
- This gets to the frustration of not being able to put goals into action
  - Having a great 55 minute session then 6 days later they come back and Jeff is like, who the hell is this? (what happened to them?)
- What likely happened is they went back and lived underneath the same roof with their biggest trauma trigger

***Jeff finds that having the ability to get that season of separation [in a residential treatment program] is needed to make change possible***

- Not the only way, but one way to make it possible
- He doesn’t want people to paint themselves into a hole where if they can’t go to a residential program, they can’t heal

**Do you view your work with individual clients as something you prefer to do only with people once they’re coming out of a residential program?**

*Or do you take clients who are saying they need help but are not ready to fully commit to something as intensive as residential care?*

- Either one
- Because a journey [to] healed (past tense) isn’t a reality
- We’re all on a healing journey
- We can have these lightning bolt moments, get this momentum, make this progress; and also know that the work continues

**Back to the language of maladaptive behaviors and muscle memory**

- To have a eureka moment just completely wipe that out
- But when he talks to a client that has been to a residential program, and to have an idea of what they did, because he has familiarity with where they were at, then Jeff can do a certain thing with that
- The fire that it lights for that person is finally getting to place of needing to look at something
  - They realize they have a lot of good, but something is just not right
- This is the point of the journey that is non linear

**⇒** The group experiential process provides a system that is a different way of making that one-on-one relationship ‒ it’s trauma efficiency

- Trauma efficiency: being able to recognize the what and the when
  - Making sure we’re using our time wisely

## Jeff’s advice on finding a therapist for trauma work [1:46:45]

**What are the attributes someone should look for when trying to find a therapist?**

- A personal referral is good
- You want input from a seasoned professional

*Is there a certification that people should be aware of that says you’re a true trauma-based therapist?*

- There are several
- Jeff would be more interested in looking at a therapist’s bio
  - He gets more concerned about the more specialties he sees: seeing a list that covers every class someone takes during a graduate program for counseling
    - This troubles Jeff
    - It looks great, it covers all these different things, but there’s no depth
- He wants to know: how much muscle memory do you have as a clinician working with a certain population the way you do it?
  - Where did that muscle memory come from?
- A big part of what Jeff does is helping folks make sure they are with the right person
- The efficiency of it: learning the story, getting that eye-opening moment, and then that hint that someone wants something different
  - To be a part of that process
  - Or point them in the right direction

**When a person finds somebody, how should they evaluate if they’re on the right path, within a month, for example?**

*What are the signs that things are going well?*

- How challenged do you feel going into a session?
- How challenged do you feel after the session?
- Going in apprehensive and coming out exhausted is a good sign

*What are the signs that things are not going well?*

- It’s not good when you can’t wait to talk to your therapist because you’re going to get to gripe for 55 minutes
- If this is where you want to put your anger at for an hour, you can do that
  - But call it what it is
  - You’re not working on change
- What is happening with that?
  - What is being illuminated?
- They wouldn’t call it a “blind spot” if you could see it

***What’s happening within that back and forth? What did I not know? What made me pause and think?***

> “*But the main thing is what’s different?*”‒ Jeff English

- Not all therapeutic relationships are a good match

**⇒** Give yourself permission after an adequate amount of time, that if something isn’t working, let’s not keep doing this

**Peter is looking at his last journal entry before he left** ***The Bridge***

- He sees a couple of great lines
- One of his favorite co-residents said, “*I asked God why he beat me down this year. He said, ‘He broke me open.’*”
  - Peter thought that was very powerful
- On Peter’s way out, Jeff said, “*The more you cry here, the more you win here.*”

***There’s no escaping it ‒ it’s very, very difficult***

**If the name of the game is: I have to become vulnerable to become connected**

**⇒** [the problem is] I am disconnected, and I am using something to stay disconnected

- Sometimes those are obviously bad ‒ like drugs and alcohol
- Sometimes they are not that obviously bad ‒ like work and perfectionism
  - Or cleanliness
  - Depending on the extent of it

***I have to get vulnerable to be connected, and being vulnerable feels like getting broken down, and you’re going to shed some tears***

- Jeff agrees, and the sheer factor thought of shedding the tears might amplify the vulnerability through the roof
- The group rooms in *The Bridge* have emotion words on the walls
- To have clinicians sit in that room as guests and refer to them as negative emotions makes Jef squirm in his seat

> “*Maybe they’re not as comfortable, but there’s a utility to all of these emotions*.”‒ Jeff English

**Jeff likens stuffing emotions to tightening strings on a guitar**

- Think about how many times you’ve stuffed that emotion and what happens
- That was an old way of doing things

**A lot of folks have been misinformed**

- A lot of folks think they’ve got to have this explosion with their emotions for the thing to happen
  - And if being lost in their emotion, if drowning in a pool of tears is what trauma integration is, then they want no part of it
- If dysregulated emotions is what comes out of the work, then their **guards** (their protective parts) have more reason than ever to do their job
- You just introduced them to vulnerability and it is overwhelming

***When Jeff is working with the client (regardless of the setting), it’s befriending vulnerability***

- To introduce vulnerability as overwhelming is counterproductive

## The importance of connection and vulnerability [1:52:45]

**Human connection is vulnerable**

- It’s not something that’s meant to be controlled
- There are unknowns
- There’s another person, and we really don’t know what they’re going to do
  - What they’re going to say
  - How we’re going to be received
  - That’s vulnerable

***If you look through the lens of “these protective parts” (my guards) ‒ the irony is the means by which they do their job typically brings me the thing I most fear***

**Another example**

- This client has trauma around betrayals
- They’re in a relationship, and one day their partner comes home and tells them that their ex is back working at the hospital where they work at
  - Nobody wants to hear that
  - But it’s going to be especially bad news for somebody with a “betrayal file”
  - It’s going to be very vulnerable

***Introduce vulnerability into the equation, this is where the disconnected self shows up***

**The client has to do something to take care of that vulnerability**

- Maybe it’s an avoidant part, “too cool for school”
- He was born out of hearing, “*What kind of man is he going to be?*” (a lot)
- In other words, this part of them doesn’t believe that a man say something like, “*I’m scared, I’m vulnerable*.”
- Part of them doesn’t care that your ex is back at work, it’s 5 years ago
- But when that partner is on their 7 to 7 shift, it hard for them to be connected

*Stuff starts going on through insecurities and betrayals, and they need something to step in and take them away ‒ that’s where disconnection comes in*

- For some folks it would be drinking or whatnot
- The irony of this example is: the problem is not having the [protective] parts
  - It’s how they do their job
  - And the relationship between those parts
- Let’s say the thing they do [to disconnect] is drinking
- Eventually what happens is they get to a point where they’re not thinking that much about what might be going on at the hospital, they’re watching a ball game with their buddy
- Their buddy leaves, and now they start thinking about what might be going on at the hospital where their partner is at
- Then when the phone rings, it’s not the connected person that answers, it’s their disconnected version
  - “*You having fun? While the night’s so young, maybe you guys will have time to go at it again. Right?*”
  - All this woundedness starts coming out
- Eventually, if this partner is healthy, this person is going to find a  note one day that says, “*I wasn’t created to save you. I can’t do this. You need some help.*”
- Now, have they ever been any sadder than they are now?

> “*It’s a triangle of vulnerability: sad, shame, and fear.*”‒ Jeff English

***All these guarded parts of self are there to protect us against that***

*Do you see the means by which the protected/disconnected self did its work actually played out?*

**⇒** It brought them the thing they feared the most

- Now they’re in therapy and realize how it happened

**Back to the disconnection connection**

- What does the connected person say: it’s a reminder that I’ve got work to do
- [They tell their partner,] I’ve got to be honest, what you just told me about this person being back working with you, it bothers me
  - That’s a very vulnerable thing to say

Peter points out, “*You can only really say that if your partner is equally vulnerable. Because if your partner is not vulnerable, that message isn’t going to land, and that’s going to be triggering to that person*.”

**⇒** You have to have 2 healthy people to make a relationship work; you can’t just have 1

**That emotional, vulnerable self might not be welcomed, and that’s information that is necessary about your partner**

- In that example, this person is not asking their partner to do anything (to quit their job or anything like that), they just need them to know their truth
- They have work to do around this
- But it bothers them; it scares them to death

Jeff adds, “*Probably the bravest words I’ve ever said to another human being in my life is, it scares me to death. I spent so many years trying to act like it didn’t.*”

## How to encourage a resistant partner to seek healing [1:57:30]

**If you’re in a relationship where you feel you can be vulnerable but it’s not being reciprocated, what are tips for helping your spouse?**

*Thinking about a marriage, what can the vulnerable member of the relationship do to help the other one?*

- It’s not going to be tenable indefinitely

*How do you lovingly get that person to come to a place where they want to get help?*

- Jeff explains that a lot of folks have wasted years trying to pull and push people into help
- You just have to be the agent of change in the relationship
- You have to break the dance
- In this particular dance is it’s: I’m wanting to be vulnerable and you’re not having anything of it

***Something’s got to change: you got to sharpen your skills with the boundaries***

- Boundaries ‒ sometimes it’s a worn out word, but it’s a hell of a skill to be able to utilize
- To be able to set a healthy boundary

**Top tier boundary setting oftentimes doesn’t include the word “you”**

- It blows folks away when you just talk about me

*For example*

- I realize when this behavior happens (fill-in the blank), that it’s affecting me
  - I’m building resentment, and this isn’t good for me
- When this happens again, I’m going to choose to do (blank)
  - Whatever that blank is; whatever that change might look like
- It might be, I want to be able to share my heart with you, but evidently I can’t
  - So I’ll be taking it to my best friend

***To be able to set the boundary, and set a boundary where there’s a consequence***

- It’s something that I can hold
- It’s something that I can do

**⇒** Because a boundary without a consequence is useless

## Jeff’s advice for those facing emotional struggles [1:59:15]

**Peter’s gratitude for Jeff**

- For coming today
- For being a really important part of his life
- He owes Jeff a great debt of gratitude as he does a number of therapists who he’s been really lucky to work with

Peter explains, “*I will forever reflect on what can only be described as just an unbelievably difficult experience that, I’m so glad I had no idea how bad it was going to be when I reluctantly agreed to go, because I just don’t think I ever would’ve done it.*”

- He’s had the privilege of encouraging many people to go since then
- And it’s helped them
  - He can’t think of an exception where it hasn’t

**Peter asks Jeff’s advice for listeners thinking about seeking therapy**

- If someone is listening and they’re contemplating either dipping their toe in by working with a therapist and trying to probe some of these things
- Or they’re thinking about jumping in the lake and going to a residential place like *The Bridge*

Jeff replies, “*If there’s a voice saying it, listen… even if it’s a whisper, it’s there for a reason*.”

> “*You’re either going to deal with it, or it’s going to deal with you*.”‒ Jeff English

- Jeff hopes that people deal with this (emotional health), “grab the bull by the horns”
- It’s an honor for him to be a part of Peter’s journey
  - Congrats on everything
  - Keep up the good work

---

## Selected Links / Related Material

**The Bridge to Recovery, residential treatment center**: [The Bridge to Recovery](https://www.thebridgetorecovery.com/) | [1:15]

**PCS**: [PCS Psychological Counseling Services](https://pcsintensive.com/) | [1:09:45, 1:39:45]

---

## People Mentioned

- [John Bradshaw](https://en.wikipedia.org/wiki/John_Bradshaw_(author)) (1933-2016, counselor and self-help author) [50:00]
- [Terry Real](https://terryreal.com/embrace-intimacy/reactivity-and-trauma-tr/#:~:text=Terry%20Real%2C%20LICSW%2C%20is%20an%20internationally%20recognized%20family%20therapist%2C%20bestselling%20author%2C%20and%20sought%2Dafter%20speaker.%C2%A0) (family therapist and bestselling author) [1:25:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/03/jeff-english.png)

##### Jeff English

Jeff English studied at Western Kentucky University where he earned a Bachelor’s in Psychology, a Masters of Arts in Education, and completed graduate studies in Clinical Mental Health Counseling. He spent over 11 years in post-secondary education as a career counselor. During that time, he realized his passion for working with individuals challenged by traumatic stress and dysfunctional family systems. He also worked on recovery from his personal experience (family of origin) with addiction, codependence, and trauma. This led him to *The Bridge To Recovery* where he worked as a lead therapist. Past credentials include LPCC (Licensed Professional Clinical Counselor), NCC (Nationally Certified Counselor), and CCTP-II (Certified Clinical Trauma Professional Level 2). Recently, he has shifted his clinical focus to work with individuals, providing life and relationship consulting. He has extensive experience as a helping professional and is currently offering his services as a healing guide via [jeffenglishgrit.com](http://jeffenglishgrit.com/).  [[The Bridge to Recovery](https://www.thebridgetorecovery.com/jeff-english/)]