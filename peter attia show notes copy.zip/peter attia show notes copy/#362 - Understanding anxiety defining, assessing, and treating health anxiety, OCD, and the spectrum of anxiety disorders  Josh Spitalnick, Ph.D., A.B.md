# #362 ‒ Understanding anxiety: defining, assessing, and treating health anxiety, OCD, and the spectrum of anxiety disorders | Josh Spitalnick, Ph.D., A.B.P.P.

**Source:** [https://peterattiamd.com/joshspitalnick/](https://peterattiamd.com/joshspitalnick/)

---

Josh Spitalnick is a clinical and research psychologist with expertise in treating a variety of anxiety conditions with cognitive-behavioral therapy (CBT) and other evidence-based approaches. In this episode, Josh unpacks the four layers of anxiety—psychological, emotional, cognitive, and behavioral—highlighting why avoidance is the key feature that transforms ordinary worry into disorder. He explains why he continues to treat OCD and PTSD as anxiety conditions despite their DSM-5 reclassification, and he draws important distinctions between worries versus worrying and thoughts versus thinking. The discussion explores health anxiety, illness anxiety, and the impact of modern contributors such as wearables, social media, and the COVID era, while weaving in real-world case studies and Josh’s structured assessment approach. Josh also breaks down evidence-based treatments, from exposure therapy and cognitive-behavioral therapy (CBT) to acceptance and commitment therapy (ACT), along with the role of medication, lifestyle factors, and how shifting from avoidance to committed action can build long-term resilience.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/joshspitalnick/the_Drive_public.png)

Play

#362 ‒ Understanding anxiety: defining, assessing, and treating health anxiety, OCD, and the spectrum of anxiety disorders | Josh Spitalnick, Ph.D., A.B.P.P.

#362 ‒ Understanding anxiety: defining, assessing, and treating health anxiety, OCD, and the spectrum of anxiety disorders | Josh Spitalnick, Ph.D., A.B.P.P.

1x15s30s

0:002:15:15

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Josh’s professional background and his holistic approach to treating anxiety [A: 3:00, V: 1:19];
- Definition of anxiety and changes in the DSM-5 [A: 5:00, V: 3:19];
- The psychological and cognitive aspects of anxiety [A: 10:45, V: 9:25];
- Breaking down anxiety symptoms: triggers, fears, and hidden mental rituals [A: 17:00, V: 16:20];
- Thoughts versus thinking and worries versus worrying: what constitutes dysfunction [A: 20:15, V: 19:49];
- Health anxiety and the limits of medical reassurance: understanding illness anxiety and somatic symptom disorder [A: 24:30, V: 24:24];
- Triggering events for health anxiety, symptom fixation, heritability, and the role of nature versus nurture [A: 36:30, V: 37:30];
- Historical and modern shifts in health anxiety, from HIV/AIDS in the 1980s to today’s heightened fears of cancer [A: 45:30, V: 47:05];
- Modern factors and recent events that have amplified societal anxiety levels [A: 47:15, V: 48:59];
- Josh’s approach to patients with excessive health-related rituals and/or OCD using CBT and exposure therapy [A: 54:30, V: 56:41];
- Hypothetical example of treating a person with a fear of flying: assessment, panic disorder, and the role of medication and exposure therapy [A: 1:03:15, V: 1:05:52];
- The four types of exposure therapy and the shift from habituation to inhibitory learning [A: 1:14:00, V: 1:17:30];
- Treating people with OCD that manifests in disturbing and intrusive thoughts, and why therapy focuses on values over reassurance [A: 1:21:00, V: 1:24:48];
- Acceptance and commitment therapy (ACT): reorienting patients toward values-driven living rather than symptom elimination [A: 1:31:45, V: 1:36:03];
- Mindfulness as a tool to cultivate presence, awareness, and healthy engagement with life [A: 1:36:30, V: 1:41:22];
- Hallmarks of successful therapy and red-flags that therapy is not going well [A: 1:38:15, V: 1:43:13];
- The relationship between anxiety and substance use, and the therapeutic challenges it creates [A: 1:44:45, V: 1:50:07];
- Anxiety’s overlap with ADHD, OCD, autism, and physical health conditions [A: 1:49:45, V: 1:55:30];
- Debunking the harmful myth that health anxiety is a “made up” condition [A: 1:51:30, V: 1:57:29];
- Prevalence, severity, and evolving treatments for health anxiety and OCD [A: 1:54:45, V: 2:00:57];
- Treating health anxiety is about providing patients with skills to improve quality of life—a discussion on how to address symptoms often attributed to long COVID [A: 2:01:30, V: 2:08:21];
- Balancing the benefits of abundant health information with the risks of fueling health anxiety [A: 2:06:30, V: 2:13:52];
- Advice for finding a telehealth provider with expertise in health anxiety [A: 2:11:00, V: 2:18:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Josh Spitalnick is a licensed clinical psychologist who is board certified in behavioral and cognitive psychology and the founder of [Anxiety Specialists of Atlanta](https://www.anxietyspecialistsofatlanta.com/)
- Anxiety is one of the most common and misunderstood challenges impacting both mental and physical health, and understanding how to treat these two effectively is essential for long term wellbeing and resilience
- It’s also something that comes up quite a bit when we think about some of the challenges of medicine 3.0, which requires doing a little bit more testing and early screening than one might otherwise do
- The result of this itself can be anxiety

In this episode, we discuss

- The 4 layers of anxiety: psychological, emotional, cognitive, and behavioral
- Why avoidance is the unifying symptom that turns everyday worry into a disorder
- How the DSM-5 reshuffled OCD and PTSD out of the anxiety chapter, and why Josh still treats them as anxiety conditions driven by the same mechanisms
- The crucial difference between worries and worrying
  - Between thoughts and thinking
  - And the hidden mental rituals that make anxiety self-perpetuating
- A deep dive on health anxiety
  - Illness anxiety versus somatic symptom disorder
  - Doctor shopping
  - Josh’s medical, physical, and psychological symptom triad
  - Genetics, trauma, and environmental contributors including social media, wearables, and the COVID era
- Real-world case studies: mask wearing, fear of flying, intrusive harm, and sexual thoughts
  - Josh’s step-by-step assessment model for each
- How exposure therapy works
- Integrating cognitive behavioral therapy (CBT) with acceptance and commitment therapy (ACT)
- Cognitive defusion ‒ clarifying values and shifting from avoidance to committed action
- How medication fits into the treatment
  - SSRIs, benzos
  - How alcohol and cannabis can quietly undermine the process

## Josh’s professional background and his holistic approach to treating anxiety [A: 3:00, V: 1:19]

- We’re going to talk about anxiety broadly and probably get into a specific subset of anxiety, which is around health anxiety, something that people like Peter are probably contributing to in some form or another
- It’s not something Peter wants to be doing, but inevitably it becomes a two-edged sword
  - As you probe deeper into health, you end up doing this
- The term anxiety is so broad, but before we talk about that let’s start with your background

**What is it that you do in your practice? Who do you work with?**

- Josh is a licensed psychologist
- He’s board certified in behavioral and cognitive psychology
  - He spends a significant amount of time focusing on how people think, how people act
  - This includes how we can address their deficits and improve them to make their lives better
  - At the end of the day, he’s a therapist
- His career has had many stages, and he’s spent most of the last 15 years focusing on anxiety conditions

*Anxiety has many layers*

- It’s a very physical experience, very physical, physiological
- It’s an emotional experience
- There are cognitive elements to it (how we think)
- Ultimately, the way we judge each other and how we see each other is the behavioral experience, so we see what people do and don’t do

***An anxiety specialist is someone who really addresses all of those domains of functioning: how we physically, emotionally, cognitively, and behaviorally act in our own world and in relation to others***

## Definition of anxiety and changes in the DSM-5 [A: 5:00, V: 3:19]

**Changes in the DSM-5 around anxiety disorders**

*Is there a DSM-5 criteria that you refer to or do you think about something that goes deeper and/or broader than what the DSM would have to say about anxiety?*

- The [DSM-5](https://en.wikipedia.org/wiki/DSM-5) altered anxiety disorders
- We’re probably going to be seeing the DSM-6 in a few years, and it’ll be interesting to see what it does.
- In the last iteration of the DSM, it actually pulled 2 pretty prominent anxiety disorders out of the anxiety disorders
  - It moved [PTSD](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) out of the anxiety disorders and it moved [OCD](https://en.wikipedia.org/wiki/Obsessive%E2%80%93compulsive_disorder) out of the anxiety disorders

Josh shares, “*I don’t believe for one second that they’re not anxiety disorders. They’re anxiety disorders, but because of some special elements about them, some people much wiser than me and you decided that they should be in their own special categories*.”

- Those 2 disorders specifically have some interesting elements to them and he understands why you’d want to separate them out

**When Josh thinks about interventions**

- The intervention sometimes dictates the disorder
  - This is maybe a reverse order for how physicians are trained or how even some therapists are trained
  - That may not be the most popular thing to say
- Most of the interventions we’re going to probably talk about today are going to be some version of [cognitive behavioral therapy (CBT)](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy) and some version of [exposure-based therapy](https://en.wikipedia.org/wiki/Exposure_therapy)
  - Those are 2 of the leading interventions
  - They are gold standard or first-line treatments of choice for almost any anxiety disorder of the 8-9 [types] that he likes to refer to

**Anxiety is a loose category**

**⇒** For Josh, anxiety simply means that someone is emotionally, physically, cognitively, behaviorally, internally preoccupied with something that’s concerning them, and then undeniably they’re doing something about it (often doing the wrong thing)

- As an anxiety specialist and as someone who runs a large practice (he gets 1000s of referrals a year), he’s always tickled that his practice thrives because amongst all the anxiety disorders, they share one common symptom: **avoidance**
  - He’ll talk about their different symptoms and criteria later
- Avoidance is the thread between all of them that identifies when we have someone who has worries, physiological anxiety, cognitive anxiety, behavioral anxiety

***When Josh starts seeing avoidance, we’re now going from someone that has a worry state to something that’s probably more problematic***

**⇒** There’s many versions of **avoidance**, but avoidance is a behavioral coping tool that’s highly effective in the moment for the anxiety, but ineffective long-term for functioning, that is shared amongst almost all the anxiety disorders

**⇒** **Anxiety** is how people are thinking mostly about the future, how they’re feeling about their future, how they’re anticipating the future

- We start talking about anticipatory anxiety, risk calculations, worrying about something that’s going to happen (catastrophizing, plotting and planning), and then acting in advance of that
- Josh points out that Peter has built an amazing career in medicine around planning 30, 40 years in advance
- But the anxious person is using that in a way, they’re weaponizing that fortune-telling in a very unhealthy way, and it’s ruining their lives

**If avoidance, which you’re describing as an action, is the** ***sine qua non*** **of all forms of anxiety, is the corollary of that a worry or distressed thought about the future absent a behavioral avoidance doesn’t cross the threshold of anxiety and therefore is not necessarily “pathologic”?**

- The short answer is yes

**⇒** The DSM at its core is about dysfunction

- In every category of disorder in the DSM, from schizophrenia to medically-induced disorders, cancer-induced depression to post-traumatic stress and OCD, *if there’s no dysfunction in life* (that’s usually relationships, occupational functioning, social functioning, educational functioning), if we don’t see problematic behaviors in someone’s life → then they have worries, they have sadness
- So someone who is sad, who’s not feeling great, but they’re not acting in ways aligned with depression, it’s hard to diagnose them with some version of a depressive disorder
- If someone is not engaging in behaviors in advance of trying to eliminate the distress, the uncertainty, the concerns about what’s up ahead, then Josh has a hard time diagnosing someone with a disorder
- Josh is a national [OCD specialist](https://iocdf.org/providers/spitalnick-josh/), he’s a national OCD treater and trainer for the [International OCD Foundation](https://iocdf.org/)
- He’s a national [health anxiety specialist](https://adaa.org/webinar/consumer-professional/ask-authors-q-complete-guide-overcoming-health-anxiety)
- If someone is not evidencing **compulsions or rituals** (which is one part of OCD, the other part is **obsessions**), it’s hard for him to diagnose someone who’s doing nothing to mitigate or manage those distressing thoughts, if what they’re doing in turn is living their fullest life

**Updates from the DSM-4 to DSM-5 changed that “dysfunction” criteria**

- In the DSM-5, OCD is moved out of the anxiety disorders to a category called the “Obsessive Compulsive and Related Disorders”
  - It’s focused on mostly rituals and repetitive behaviors
- The criteria changed where it used to be, you have to have obsessions and compulsions (that was DSM-4)
- In the DSM-5 and [DSM-5-TR](https://en.wikipedia.org/wiki/DSM-5#Revisions_and_updates), it now says: you have to have one or the other
- Josh shares, “*So I’m talking to both sides of my mouth.*”

***Current diagnostic criteria says, if you have obsessions or obtrusive thoughts and you do nothing about it, we can still diagnose you***

- Josh doesn’t know if he believes that
- Because if you’re doing nothing aligned with that anxiety (in Josh’s view, if you’re aligned with it, it’s shrinking your life), and you’re having these horrible thoughts and feelings, and you don’t really engage with them and no one really knows, and you’re out there living your fullest life, Josh doesn’t define that as being someone who is impaired or dysfunctional

***The problem is Josh has never met someone who has intrusive thoughts and obsessions and who does nothing***

## The psychological and cognitive aspects of anxiety [A: 10:45, V: 9:25]

**Now we’re getting into the next layer of what anxiety is**

- Earlier he mentioned the word **behavioral avoidance**
- Anxiety has 2 kinds of coping, and some of them we can see (we call those “overt rituals” or behaviors, and some of them are more covert
- So right now in this room, Josh is using his hands and talking with Peter
  - He’s doing stuff to engage with Peter and he’s answering Peter’s question
- But in his head, you may not know that he’s second guessing what he just said
  - Wondering if Peter believes what he said
  - Wondering if he sounds good
  - Questioning if he should even be here
  - Wondering if this is going to be a good podcast
- If someone’s in that state of thinking about all those things, though we can’t see that ‒ Josh is starting to talk about a concept called a **“mental ritual”**

**In the last 10 to 15 years, in the anxiety space we’ve seen anxiety specialists not just focusing on what people do behaviorally, but also what they’re doing in their head and their mind**

- Now we start doing the difference between **thoughts** (which are passive experiences) and **thinking** (thoughts I don’t control)
  - Josh calls those the burps, farts, and hiccups of anxiety
  - They just happen to us
- But when you start thinking about those thoughts and trying to neutralize those thoughts and acting in advance of those thoughts, and analyzing them and looking them up online and questioning them, that’s a **mental action**

> “*Now we just opened up Pandora’s box, Anxiety just got bigger*.”‒ Josh Spitalnick

- Anxiety went from a condition where you’re having these unwanted thoughts and feelings
  - And avoiding maybe using substances
  - Maybe trying to avoid a situation
  - Not showing up to a presentation
  - Staying in bed long or doing things to not deal with it
  - In certain conditions you’re washing your hands extra
  - Maybe doing certain things to your body, those are behavioral actions or rituals
- Now we have a whole other space of actions or reactions, and those **mental rituals** are, if not as problematic, sometimes worse because the person with lived experience with anxiety often doesn’t know their mental rituals
- They just think they’re obsessing all day long
  - Josh hears that a lot, “*I obsess all day long*.”
  - He replies, “*Are you obsessing all day long, or do you have obsessions, or are you sitting there stewing on it? Oh, you’re stewing on it. That’s a rumination. Yeah, that’s an obsession*.”
  - No, no, you’re **ruminating**
    - You’re fixated on it; you’re trying to quantify it, you’re trying to solve it ‒  that’s a mental action
    - Why? Because you’re trying to diffuse the bomb
    - You’re trying to deal with uncertainty; you can’t tolerate uncertainty, you can’t tolerate the distress
    - You’re trying to solve this Rubik’s Cube that’s missing a puzzle piece
- Most therapists can’t see that, and that person with lived experience just thinks they’re just worrying all day long

**So we start separating the difference between worries and worrying, thoughts and thinking**

- The first one is on the house
- The first one is your body doing exactly what it’s supposed to do

***The second one is you trying to solve a puzzle that you probably won’t be able to solve, and you’re going to keep doing it and keep doing it and dig deeper and deeper into a hole until you can’t get out of it***

- Most of us are familiar with behavioral manifestations of coping, but **mental rituals** are equally as destructive, and worse, hard to identify and see if you don’t know what you’re asking

**Thoughts vs thinking**

Peter relates, “*Anybody who’s spent any time meditating will be very familiar with what you just said about the difference between thoughts and thinking*.”

**Peter was just talking about this with somebody this morning as it pertained to mindfulness**

- The idea for folks may be not as familiar with the idea that if you practice a form of mindfulness meditation, very quickly you’re almost blown away at the torrent of thoughts that exist in your brain and how you can’t turn them off
- If you sit there and try to practice a ritual of paying attention to your breath and figuring out how many milliseconds you can go focusing on your breath and nothing else, you realize that the answer is a very short period of time (maybe unless you’ve reached some state of enlightenment that Peter will never reach)
- What’s basically happening is you are sitting there focusing on your breath, and immediately you’re going to be thinking about what you want for breakfast, and then you lovingly bring yourself back to thinking about the breath, and about a millisecond later you realize you’ve got to do that thing after
  - It is just a nonstop ping pong match back and forth

**For the individual who has not practiced this highly uncomfortable exercise of mindfulness meditation, help people understand what you mean about the distinction between thoughts and thinking**

- Peter thinks this will be uniquely important when we talk about anxiety

*Josh likes to talk about* ***the Ws of that level-2 thinking****:* ***w****ho,* ***w****hat,* ***w****here,* ***w****hen,* ***w****hy, ho****w*** *(ends in a W), and* ***w****hat if*

- He’s going to break it into 3 categories

When Josh hears someone asking a question that starts with a W and whatever the statement is ends with a question mark, in his work if it’s about their anxiety core issue, **it is an attempt to resolve uncertainty**

- So if someone has social anxiety, the fear of public speaking, if someone has a fear of snakes, the fear of being bitten by a snake
- When they’re asking questions about is that snake going to be there? Does that garden have snakes?
- Or is it a public speaking event tomorrow, and what am I going to do about it and what if they laugh at me?
- When he hears those questions, most of us just think that someone’s worried, but that looks productive, it looks like you’re trying to figure something out
  - And for most of us, we just move on with our day
- For the anxiety sufferer, it is an attempt to resolve uncertainty
  - It is an attempt to figure out something that you don’t have the chance to figure out because that time has not happened yet
  - It’s a fortune-telling mindset of mental action
- **Worrying (the verb)** is an activity, and most of us do it and move on with our lives
  - It’s like Teflon, it slides off of us
- But *for the anxiety sufferer*, worrying looks like they’re trying to solve something
  - The problem is when they get their answer, they’re not done

The epidemic of anxiety is whether you do a ritual that looks more behavioral

- For example: scrubbing your hands
- Praying excessively
- Asking the police officer if they got a report, if anyone got run over in the intersection, (which is called hit-and-run OCD)
- Rereading your email 17 times or wondering about your email, questioning, “*Did I send that out? Was there a typo in there? Are they judging me? What if they say something back to me?*”

***Those don’t look like rituals or compulsions, but it’s our ability to resolve angst, to solve uncertainty, to deal with this inner feeling that is killing us on the inside, and it is its own designation of symptoms***

## Breaking down anxiety symptoms: triggers, fears, and hidden mental rituals [A: 17:00, V: 16:20]

**The first thing Josh does in therapy with almost anyone he works with is to break down symptoms into 3 categories**

- It’s category 1, category 2, and category 3

Acronyms

- If he’s dealing with **OCD**: **T**s stand for triggers, **O**s for obsessions, and **C**s for compulsions
- For almost any other **anxiety disorder**: **T**s stand for triggers, **F**s for fears, and **SB**s for safety behaviors

***Every anxiety specialist and anyone who battles anxiety should know those 3 levels of symptoms***

**⇒** **Triggers** are the things that bother you, the events, the people, the places, the things that are out of your control

- Sometimes you can just be sitting around a a thought pops into your mind and that can be a trigger
- Sometimes a physical symptom can be a trigger
- The middle column (which Josh uses the letter O for obsession, F for fear), is the internal experiences you’re having
  - Notice he uses the word “having,” not “doing,” ‒ that’s out of your control
- Breathing, heart rate, yucky thoughts, upset tummy, a twitch, a feeling, an aura
  - For most of us, we call those worries or fears or obsessions
  - Sometimes it’s an urge
  - Those are not up to us
  - That means your body’s working
  - Sometimes it’s working in overdrive
  - Sometimes it means your prefrontal cortex in your limbic region is not communicating properly
  - That means that something went off in your body as a signal of uh-oh, there might be danger, and so it’s happening to you

**In the most basic behavioral paradigm, there is a stimulus and a response**

> “*What happens between stimulus and response is where all the magic happens. One’s ability to make decisions effectively between stimulus and response is where therapy really takes action.*”‒ Josh Spitalnick

**⇒** That response in all the anxiety disorders is avoidance and rituals (behavioral or mental)

- It’s a therapist’s job to figure out those symptoms, the Ts, Os, and Cs, to educate the patient on what they are
- Because most patients (and honestly probably most therapists) confuse worries from worrying, thoughts from thinking
- Most therapists are going to put anything between your ears in **category 2** [fears and obsessions]

**In the last 10-15 years online, there’s been language and descriptions of something called “Pure O OCD”**

- What people are thinking: I just have obsessions, I’m a purely **obsessional subcategory of OCD**
- Josh has [more about] Pure O OCD on his [website](https://www.anxietyspecialistsofatlanta.com/pure-o-ocd-blog/)
- He writes about it because he wants people who think they have that to find his website and reverse engineer what they think is going on
- They think they’re just having obsessions because it’s all happening “up here”
- What’s really going on is they’re having obsessions and then spending all day long “up here” trying to solve an existential crisis, which Josh would call a **“mental ritual”**

## Thoughts versus thinking and worries versus worrying: what constitutes dysfunction [A: 20:15, V: 19:49]

**Peter would like to use both thoughts versus thinking and worry versus worrying to help people understand when they’ve crossed that threshold**

*Pick a real world example that you might experience in your practice*

Josh wants to talk about health and medical stuff

- If someone’s having a bunch of physical symptoms and they’re afraid that they might have cancer
- If they’re afraid that they might have cancer, that’s a worry
- If they’re afraid that these might be symptoms of a heart attack (of an MI event), that’s a worry
- What if I’m having a heart attack?
  - All of a sudden you’re trying to figure it out
  - By the way, asking that doesn’t figure it out and Googling it doesn’t figure it out, and calling your cardiologist who hasn’t seen you doesn’t figure it out
  - But when you go, what if this is a heart attack symptom? You’re beyond worrying about it
    - The worry is, “*I might be sick*,” (in this case having a medical event) and you’re trying to figure out what if this is the thing?
    - When you’re trying to figure it out, that’s no different than Googling it
    - That’s no different than looking it up online, calling your nurse or doctor friend or in-law saying, “*Do you think this is what it is?*”
    - Most people would call that **reassurance seeking**, which is a classic ritual (it’s a behavioral thing)
- Me asking you, “*Hey, you haven’t evaluated me, you’re my brother-in-law, do you think this is a medical event?*”
- But when you ask yourself that, how is it any different?
  - We haven’t evaluated you, there’s no lab work
  - We’re not really going to get the answer

***You’re really just looking for one answer, you’re fine***

- The dilemma is when you go from that worry state to, “*Oh my gosh, I’m terrified I might be sick, to what if I’m sick? What if this is the event?*”

***People can spend not that little moment but all day wondering, is that another thing?***

- Wondering: Is that a heart issue? Is that a symptom of stroke?
  - My eye twitching, does that mean I’m having a seizure?
- The worry is just I’m scared something’s wrong, I’m scared something bad’s going to happen

***When they start asking themselves a litany of questions, that’s not the worry ‒ [that’s worrying] that person is ritualizing***

- When you sit there and start questioning it all, it’s no different than just sitting there and Googling all day long, “*What are these symptoms?*”
- When you do it inside, it’s the same mechanism
  - It’s you trying to get to the end of the story
  - You’re using your crystal ball or time machine to get to the end of that story sooner than you actually need to
- In the case that you’re having a real medical event, I’d go to the doctor, I’d actually go see a physician
- But sitting there questioning it doesn’t solve anything

***So you went from a state of having worries (I’m afraid I’m sick, I’m afraid something’s wrong) to sitting there, ruminating on it ‒ it looks functional, but it’s actually quite dysfunctional***

Peter asks, “*Is it dysfunctional because of the duration, is it dysfunctional because it comes at the expense of doing something else, or is it dysfunctional because if an objective person were to evaluate it on its face, it doesn’t make any sense?*”

- Yes, it’s dysfunctional because it’s taking away from your life
- It’s dysfunctional because the duration or intensity of it doesn’t match the thing
- Meaning that if you’re spending all your time doing that and not going to the doctor, this is not going to solve anything

Josh clarifies, “*In a single moment, anyone freaking out, I don’t think that’s dysfunctional. That’s what any one of us would do.*”

- You sent an email and go, “*Oh shoot, did I just do that?*” We all do that
- Oh man, this feels tight in my chest, what is that? We all do that
- Even the DSM criteria for something like health anxiety requires 6 months of being concerned about, whether it’s about symptoms or diseases
- So in a singular moment, it’s nothing more than you being inquisitive and curious

***The point is, that’s not going to solve whether it’s a medical event or not; going to your doctor is, getting an EKG is***

- Asking your nurse sister if you’re having a stroke, what does she know?
  - It doesn’t solve the problem and it’s trying to get to the end of the story or resolve some uncertainty or some ambiguity in a way that’s not actually going to solve it
- So it’s just not a functional way to process
- In a singular moment, the first time, I don’t care, you don’t care. It’s what someone does.

***When you’re doing that multiple times a day, multiple times a week, or for months on end, that’s the disease***

## Health anxiety and the limits of medical reassurance: understanding illness anxiety and somatic symptom disorder [A: 24:30, V: 24:24]

**What about the individual who goes out to seek medical attention for something but the pattern is so illogical**

- They keep having unexplained symptoms and they create a story that says, this is cancer, or this is heart disease, or this is whatever
- And they follow through with the medical checkup, as they should, and the medical checkup keeps coming back crystal clear: you’re fine, you’re fine, you’re fine
  - The goalpost keeps moving: it’s I think I’ve got this, I think I’ve got that, I think I’ve got this, I think I’ve got that
  - Everything they get checked up for is fine

*Is that health anxiety?*

- That’s possibly health anxiety

> “*First of all, health anxiety is not a disorder. It’s a class of disorders. It’s a buzzword online*.”‒ Josh Spitalnick

- Health anxiety is something you can Google, but the disorders within them breakdown into really 2, sometimes 3 disorders
- 1 – One is called **illness anxiety disorder** (which used to be called [hypochondriasis](https://en.wikipedia.org/wiki/Hypochondriasis))
- 2 – One is called **somatic symptom disorder** (which used to be called [somatoform disorder](https://en.wikipedia.org/wiki/Somatic_symptom_disorder))
- 3 – There’s a third one that’s a bit curious, which is **conversion disorders** (or [functional neurological disorders](https://en.wikipedia.org/wiki/Functional_neurological_symptom_disorder#))
- In this example, someone has some set of symptoms, and whether the symptoms stay or change, they’re going to doctor after doctor
  - They’ve had all the appropriate medical workups and every doctor said, “*Negative result, negative result, negative result.*”
- Josh has to be careful how he talks about this
  - He’s done other podcasts where he’s said a story like this and he’s triggered some people
  - He not trying to upset people or trigger people

***In this situation, it sounds a lot like a health anxiety kind of disorder that would most commonly be diagnosed as somatic symptom disorder***

- There are anecdotal stories of someone getting a breast exam, going for their annual, going for a pap smear, they’ve had all the medical clearance, and all of a sudden a month later they find a pea size shape under their armpit, and oh my goodness, they have breast cancer

**Josh shares a personal story about his wife**

- A decade ago, he was almost a widow
- His was having radiating discomfort and pain going up her right abdomen and backside
- She’s thin, healthy, and had no history of medical issues
- She went to a primary care doctor who she trusted dearly, and he said, “*You might have a tiny umbilical hernia. You’re young, you’re healthy, you’re thin. Don’t worry about it.*”
- They decided to wait and see what happens
- A week later, she’s still complaining
- She goes to her OB, and the OB did a full exam and found absolutely nothing
- Next she goes to a surgeon who the OB recommended, just to make sure
- The surgeon did an ultrasound and a CT and said, “*I would not do an umbilical surgical right now. You’re fine. You’re young. Let’s wait on it. Nothing’s going on.*”
- 3 doctors gave her a clean bill of health with some superficial observation and some very basic, non-invasive procedures
- A week later, she said, “*Josh, it’s not going away and something’s not right and it’s radiating up my back.*”
- They checked for gallstones, they checked for kidney stones and all the standard stuff
- Blood work, urinalysis, all of it
- Someone recommended for her to see a GI specialist
- She went there and she had a mass on her liver that was compromised over 50% that required immediate surgery
  - If that had ruptured or bled out, she would’ve possibly died
- She had a significant resection liver surgery and is doing well today
  - The liver is the only organ that regenerates itself, so we got very lucky
- If we waited on that and took those 3 “nos” as take some ibuprofen, stretch, maybe it’s gas, figure it out, Josh doesn’t want to know the answer to that end of that story

***The problem is that sometimes we have to trust our own bodies and sometimes we can’t trust the doctor***

**Back to the example Peter brought up and the 3 types of health anxiety**

- If you’re chasing symptoms and have been to multiple doctors with multiple workups and everyone’s saying, “*It’s nothing we can diagnose,*” for most of us, we’re describing that you have some physical anomalies going on that maybe don’t require medical intervention

**⇒** In the health anxiety spectrum, we’re now starting to describe symptoms in three categories: symptoms that are medical, symptoms that are physical, and symptoms that are psychological

- In all the health anxiety spectrums, we break those symptoms into three categories
- If they’re medical and require medical intervention and you worry about them (we all do)
  - You can call that an adjustment reaction or something else
  - They don’t require a therapist or medication for that unless that’s something that you want
- If you’re having physical symptoms that are not deemed medical, the worry associated with that, we would typically describe as **somatic symptom disorder** [#2 listed above]
  - Either because the lab reports are not back yet or because the doctor hasn’t talked to you yet or because the lab results are negative
  - At some point we have to admit maybe there’s nothing medical here (unless we’re waiting for lab results)
  - You don’t know what you have yet, you may have nothing, and you’re worrying about it and not leaving the house, you’re doctor shopping and going online and checking your labs, and wearing a pulse oximeter
  - You’re constantly monitor physical symptoms
  - At some point your quality of life is going down
  - Could something medical come from that? Absolutely
- The other category is when it’s all psychological [#3 listed above]
- A long time ago it was someone is afraid they’re going to get AIDS (we don’t see that that much anymore),
- Someone is afraid they’re going to have a stroke, a brain tumor
  - No symptoms to support it, they’re just worried about getting an illness or disease
- Back in the day, people would call that person a [hypochondriacal](https://en.wikipedia.org/wiki/Hypochondriasis) (the disorder was called hypochondriasis) and today we call that illness anxiety disorder [#1 listed above]
- People can have all three
  - They can have A) medical issues, B) they can have physical issues that are not medical and worry about them, and C) they can also worry about getting other diseases, which we would call illness anxiety disorder

*The most common presentation Josh sees in his practice and that people reach out to him for is when someone has a combination of physical things and they’re convinced it’s something, (and usually by the time they’re reaching out to him, they’ve been to multiple doctors)*

**⇒** When someone reaches out to an anxiety specialist with physical things, the first thing Josh tells them is, “*Go get a workup.*”

- He’s never going to get in the way of medical care
- But at some point, if every doctor who is of quality and competence has ruled out whatever you think is going on
- And even then people go to great lengths
  - Josh has had patients get spinal taps, off the record, for cash, to determine if they have a leaking CSF because they think they’re having a stroke or having early-onset Alzheimer’s

**Peter adds one thing that makes that playbook challenging: you have more and more quacks out there that are going to come up with every reason under the sun for your symptoms**

- You’ll find somebody who will come up with an explanation for your symptoms
  - It’ll be the mold in your house, it’ll be the slight elevation of cadmium in your blood, radon, cat litter, go down the list
- Now we’ve opened a Pandora’s box: this individual is feeling a little fatigued and can’t figure out why
  - Something’s wrong with them, they’re fatigued
  - Maybe it’s, fill in the blank.
- The first doctor they see does a traditional workup and says, “*All your hormones look great, everything that I can see.*”

***But you’re going to find that person within the first 3 who’s going to come up with an explanation, and they’re typically going to have a solution for you that’s pretty off the beaten path***

Josh’s analogy: you’re car is squeaking

- If you go to a car mechanic and say your car is squeaking in the engine, they’re going to have a wonderful solution for your engine, even if it’s not required
- If you go to a psychiatrist and say, “*I think I need meds*.” Guess what they’re going to give you? Medication

***If you go to enough doctors, they’re going to find some problem and recommend some intervention, whether it’s homeopathic, whether it’s diagnostic, whether it’s a prescription something, they’ll give you something because they want you to feel better***

Peter thinks part of it is, “*When you’re a hammer and everything is a nail syndrome… which is truly there are just a lot of real charlatans out there that are just not practicing any form of reasonable medicine, not even evidence-informed.*”

- Peter understands that evidence-based has its limitations, but there is at least still a threshold of evidence-informed medicine
- When you start saying that the answer to your slightly elevated cesium level
  - Which no lab has ever documented what the upper limit of that should be
  - But let’s just assume that my arbitrary level is too high and you’re slightly above it
  - So that’s clearly the explanation of everything that’s going wrong with you, and the doctor going to hand you some supplement that by the way, he happens to also sell
    - He just happened to sell
    - How lucky are you
    - It’s right here too, by the way. It’s in the office.
- This is the challenge that both Peter and Josh have

Josh explains, “*You’re asking me as a non-medical person to make sure that someone is getting advocated for, spoken for, and referred to by providers. They’re going to go to find anyone. It’s above my pay grade to know whether that doctor knows what they’re doing, whether they’re recommending medications, or off-label things that are… How am I going to argue against that?*”

Most anxiety specialists like Josh who work in the space of a lot of health and medical

- Josh has a career he hasn’t talked about where he’s done lots of medical training, medical work in my career, he’s informed, he’s knowledgeable
  - He also has medical people in his family
- Josh can ask the right things, but he’s trusting the medical people around him
- He’s an [adjunct faculty](https://med.emory.edu/directory/profile/?u=JSPITAL) at a university in Atlanta, he’s got colleagues there, he’s got medical people around him
- He surrounds himself with people that are sharp psychiatrists, physicians, oncologists, just in case, and still his patients are going to go to other doctors because they’re just looking for the answer

***When patients continue to go to other doctors looking for answers, that’s within that health anxiety spectrum***

- If every doctor you’ve gone to that Josh trusts has given you the best medicine possible or the best assessment possible, and you’re getting no answer and you go to the next person
- You don’t need the DSM to go, “*Maybe this is more than just a medical issue*.”
- Josh is still going to advocate for the medical needs, he’s still going to support them and join them, and he’s still going to help them see that your physical symptoms are real

**⇒** Physical symptoms are real, that doesn’t mean they’re indicative of or prognosticate a medical condition

- Half the battle Josh is doing is education around that topic

> “*I think it’s worth stating that again. If a person says, ‘I’m experiencing this pain,’ that’s real.*”‒ Peter Attia

***Your pain is read, but don’t assume necessarily that means there is an underlying medical reason for that or that you would find something with the best diagnostics***

**For the people that Josh sees, more often than not, there’s not a great medical diagnosis for them**

- He doesn’t specialize in [FND](https://en.wikipedia.org/wiki/Functional_neurological_symptom_disorder): that functional neurological space of pseudoseizures, or tingling arms, or body parts that can go numb
  - That’s a whole nother space of conversion disorders
- Josh is talking about people that have chronic headaches, tummy issues, leg cramps, bones that feel sore
  - They’ve had every workup you could imagine that would be considerate for someone who has bones that are sore
  - There’s about 3 or 4 conditions most of us are going to jump to when you say your bones are sore
- When that’s all been ruled out, and they’re trying to convince you, “*But my thigh, I can feel the bone, I can feel the marrow, it feels like it’s tearing itself up.*”
- We’re talking about pain conditions, we’re talking about neuropathic conditions

***At some point the intervention (which is them doctor shopping) becomes worse than the pain itself***

- At some point, someone will prescribe you something (hopefully not opiates)
- What scares Josh? That they have the magical cure to fix your distress, your pain
- Josh’s job is to sit with patients and say, “*The pain is real, the sensation is real, the symptom is real, but it may not really be indicative of the thing that you think it could be. And by the way, going on WebMD or Google, because a social media influencer said, ‘If you have this, this is probably what it is,’ does not diagnose you.*”

## Triggering events for health anxiety, symptom fixation, heritability, and the role of nature versus nurture [A: 36:30, V: 37:30]

**Health anxiety: the downside of health tracking wearables, social media and influencers, doctor shopping, and access to medical records**

- There’s really this wonderful space of social media, wearable devices, and the access that we all have to our medical records scares the hell out of Josh
  - And he’s a big believer in wearable devices
- Because we are now patients being our own advocates and showing up to doctors saying, “*This is what I found out online and I think I have this*.”
- Or, “*This is what this person said, and I think I have this. I’m looking at my watch here, my heart rate’s been up all week. Doesn’t that mean something?*”
- Yeah, it means your heart rate’s up, period
  - That doesn’t have to mean anything else except your heart rate is up
  - Most people would assume that means you’re at risk for a heart attack or a stroke
  - Or it means if you stare at your watch long enough, you don’t have hair on your head like I do
- If we talk about lice, guess what’s going to happen in a few seconds? [itchy]
- If Josh mentions your left pinky toe, “*Peter, have you thought about your left pinky toe this entire time we’ve been together? Because you are now. How’s the toe next to it doing? And by the way, now, how’s the right pinky toe going?*”
- Now we get to think about that stuff

***If you think about that long enough, you’re going to feel your left pinky toe, it’s going to be tactile, and sticky, and maybe sensory***

- It was there the whole time. Your brain didn’t have to think about it.

Josh asks, “*How’s your breathing right now?*”

- We don’t think about breathing
- Josh treats people who get fixated on swallowing, breathing, “*There’s got to be something in here. I have thyroid cancer. I have esophageal cancer because I feel something in there*.”
- You probably do feel something in there
- And by the way, if you do this all day long and you create some bruising, you’re going to feel a whole bunch of more stuff in there
- To convince someone that there may not be something in there because they’ve been scoped, and tested, and blood checked, and there’s no signs of anything that’s anatomical or physical in their throat, but they can feel it

***It’s not Josh’s job to say it’s fake. It’s his job to say, “You’re struggling with something, and what are we going to do about that?”***

Peter asks, “*Do you go one step further and say, ‘You’re creating this’? Or are you saying, ‘No, I don’t need to go that far. I just need to get them to understand that there’s another explanation for this’?”*

- There’s no need to do that
- If Josh takes that stance, he’s now the next person who’s the naysayer
  - He’s the next one who’s invalidating them
- No therapist would ever basically weaponize that or blame them for that kind of thing
- What Josh can say is: you may not have created it, you probably didn’t create it, leg pain’s not being created; but if you sit there and focus on your left pinky toe, or if you talk about lice long enough, it’s going to create head sensations of itch

***That’s how it works: when you focus on something long enough, you pay attention to it. And if you pay attention to it, you’re more aware of it. And if you’re more aware of it and your brain actually works, it’ll feel it.***

[Phantom limb syndrome](https://en.wikipedia.org/wiki/Phantom_limb) research has demonstrated that

- People putting a dummy arm and a fake arm in a mirror and whacking an arm, we can feel that in our nerve endings because our brain’s processing information
- So do we have a dead arm that’s not connected to that’s actually causing pain? No
- Do we have a pain reception or an information processing thing going on? Probably
- That’s fascinating research

***Josh doesn’t have to tell patients, “It’s your fault,” or that, “You’re creating it;” but he can tell them that, “The thing you’re doing is keeping it active, it’s keeping it prominent in your focus. And as long as you focus on that, you’re not focusing on anything else. And if you’re not focusing on anything else, we have a whole nother disease.”***

- Disease #1: there’s something wrong with your thigh (maybe not medical)
- Disease #2: you’re fixated on it, you won’t leave the house, you’re demanding opiates, you’re complaining to people
  - Your husband doesn’t want to hear it anymore
  - Your doctors have cut you off
- Josh has worked with patients in Atlanta that have been blacklisted from 2 of the 3 major hospital medical systems, because they’ve done so much doctor shopping and so much fighting with their doctors that it’s a stress on the system
- But they have the wearables, and the social media, and the online, and access to their patient portal that proves that something’s wrong

**What’s a symptom that’s a real world example? What types of things would they be doctor shopping for?**

The ones Josh sees the most are:

- Memory loss or memory slipups, which some people would actually put into the functional neurological disorder spectrum
- A lot of chest pain that has had every EKG and medical workup you can imagine
- Sensations like ants crawling, or physical pain, neuropathic pain, for which it has no explanation

**What would be the triggering events?**

*What are the genetic factors that would predispose a person to this, versus the environmental factors that would predispose a person to this*

- Peter has had a number of folks on the podcast talk at length about the heritability of various psychiatric illnesses
  - [in episodes [#268](https://peterattiamd.com/wendychung/), [#280](https://peterattiamd.com/arthurbrooks2/), and [#330](https://peterattiamd.com/trennasutcliffe/)]
- Using concordant and discordant twin studies we can get a pretty good sense of how these things work

***With health anxiety, the heritability is about 30-40% (it’s on the lower side)***

- Schizophrenia and autism are very high, 70-80% sometimes
- When Peter hears 30% heritability, he hears environmental trigger

In the [diathesis-stress model](https://en.wikipedia.org/wiki/Diathesis%E2%80%93stress_model), you have the diathesis there, it’s low, but it just takes that right context to make it come alive [illustrated in the diagram below]

![](https://peterattiamd.com/wp-content/uploads/2025/08/f1-joshspitalnick-1024x767.png)

**Figure 1. Schematic of the diathesis-stress model**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Diathesis%E2%80%93stress_model)

- For some populations, **trauma** can induce this

**⇒** Trauma can cause all sorts of physical manifestations of discomfort, and distress, and pain (whether that’s a physical or sexual trauma, or an emotional trauma or loss)

- There’s enough research in large scale studies to demonstrate, even with seizures ([PNES, psychogenic nonepileptic seizures](https://en.wikipedia.org/wiki/Psychogenic_non-epileptic_seizure)), emotional and physical traumas can demonstrate bodily reactions that are not explained
  - Which we used to call [conversion disorder](https://en.wikipedia.org/wiki/Conversion_disorder)
- Family history of trauma where parents are complaining and describing similar symptoms
  - Josh sees that quite a bit.
  - He sees that both with OCD and health anxiety
    - [OCD](https://en.wikipedia.org/wiki/Obsessive%E2%80%93compulsive_disorder) has a heritability rate of about 40-50%
    - Health anxiety is a little bit lower
- General anxiety probably has a heritability in the 30-40% range
- Josh doesn’t know of any other disorder outside of OCD that has a higher heritability rate
  - There are 9 anxiety disorders he usually refers to and OCD has the highest heritability at 40-50%
  - It’s very atypical for him to meet a child or a teen with OCD, and to not have a first degree relative who has it

Peter asks, “*Do you think that it is a learned behavior in that sense?*”

- We cannot deny that there’s a genetic component to it, but when you are in a household where someone is doing things in a very hypervigilant way constantly, or always washing down the counters, or always doing things on repeat (like tapping the door, or asking you to say something over, and over, and over again), at some point social learning kicks in
- They won’t necessarily be the same
  - If mom washes her hands a hundred times a day
  - Johnny could easily manifest clothing folding or ruminating on some other
  - This is describing a lot of the subcontinent areas of OCD
- Josh doesn’t know if there is any research study out there that has demonstrated that parents subclassification of OCD mimics child’s
- But at a macro OCD falls down to the next generation; it’s pretty well documented

Josh adds, “*If I’ve seen a hundred people in the last year with OCD (and I haven’t seen that many in the last year), I’d be shocked if more than 15 didn’t have a first degree relative that had OCD. It’d be very atypical.*”

- A relative that they live with or have lived with

***It’s very difficult to know nature versus nurture***

**Josh views health anxiety (illness anxiety disorder) as a subcategory of OCD**

- 20 years ago people viewed the [HIV](https://en.wikipedia.org/wiki/HIV/AIDS) focus much more as an OCD condition
- Today we would call it **illness anxiety disorder**
- Most of the colleagues Josh works with, the people he’s done research with, the people that he talks about stuff with, view health anxiety as a subcategory
- Academically, illness anxiety disorder is its own special category in the DSM, but Josh sees the exact same things that Peter is asking about
  - Which is that it’s very rare for him to see someone who has health anxiety for which a first degree relative doesn’t also have health anxiety
- OCD for most populations usually starts around age 7, 8, 9 (prepubescent)
- Health anxiety usually starts around the teenage years
  - Epidemiological research would support that health anxiety typically starts in teenage years and young adulthood
- Josh sees kids with [emetophobia](https://en.wikipedia.org/wiki/Emetophobia) (fear of throw-up), kids that complain of tummy aches because they’re afraid to go to school
  - Josh thinks they’re more focused on situational symptoms in response to situations, than what you and I would think about more existential dread about health anxiety
- It’d be a little bit unconventional for a kid to be thinking about morbidity and mortality and things like that, because kids are not developed to worry about that in general (though it can be the case)
- It’d be very unconventional for Josh to see someone who has health anxiety where they wouldn’t say, “*Yeah, my mom also worried about that*.”
- Emetophobia is no different (fear of throw-up): it’s very common in family dynamics
  - The first question he asks of these patients is, “*Which one of your family members also has that fear?*”

***It’s both biological and behavioral***

## Historical and modern shifts in health anxiety, from HIV/AIDS in the 1980s to today’s heightened fears of cancer [A: 45:30, V: 47:05]

**Is** [**HIV and AIDS**](https://en.wikipedia.org/wiki/HIV/AIDS) **really the first big landmark introduction of widespread health anxiety, or is it just the most recent one?**

- It’s probably the loudest
- In ancient Grecian times, people focused on this stuff and did brain mapping
  - All sorts of crazy psychobrain surgeries to help people alleviate stuff
- The HIV epidemic probably became the most prominent thing in the last 30 to 40 years that got people’s awareness of, “*What if I get that terrible disease?*”
  - Because we don’t know enough about it, the treatments weren’t available at the time, the life expectancy was short, and that scared everyone
- You could look at trends in the last 10 years, and when Josh gets together with all his colleagues and they nerd out about this stuff
- You can see trends during [Black Lives Matter](https://en.wikipedia.org/wiki/Black_Lives_Matter) movement a few years ago, and the [#MeToo](https://en.wikipedia.org/wiki/MeToo_movement) movement
- When you see people coming in fearful of things like, “*What if I say a racial slur? What if I get accused of sexually assaulting someone in the past?*”
- You see those socio-driven moments where you see spikes of people coming in concerned about that, COVID lit that on fire literally
  - And there’s still lingering effects of that that we can discuss

***Josh hasn’t heard of someone concerned about getting HIV in the last 10-15 years, but he’s worked with patients concerned about stroke, heart attack, Alzheimer’s, Parkinson’s, every kind of cancer***

- He’s done a lot of work in HIV and [STD](https://en.wikipedia.org/wiki/Sexually_transmitted_infection) prevention
  - He’s worked in HIV clinics
  - He did an NIH research fellowship on HIV and STD
  - He’s been in the HIV space for about 20 years

Josh adds, “*I’m a weird psychologist, I’ve done lots of medically-based research and clinical work.*”

> “*Cancer is the most notorious, it’s the loudest, it’s the scariest, it’s what everyone talks about.*”‒ Josh Spitalnick

## Modern factors and recent events that have amplified societal anxiety levels [A: 47:15, V: 48:59]

**Let’s now go over the 3 things you alluded to earlier, social media, wearables, and access to medical records. Is there anything else that you think is contributing to that?**

- Let’s assume genetic drift is not increasing the genetic predisposition to that, so that the increase that you see in the incidence is environmental or triggered
- Those things are research-based

*What Josh has seen on a personal anecdotal level*

- In the last 5 years, since the pandemic, we’ve seen a shift in culture around medical access, and insurance, and people getting proper care, and political things, and turmoil
- We’ve seen a significant increase in mental health awareness, a significant increase in people coming to therapy for the first time, a significant increase in people staying in therapy longer and longer
- And we’ve seen a significant spike in general anxiety since 2020
  - Almost a 2-fold spike in most research studies

Josh explains, “*I just feel like we’re hitting this unfortunate, perfect, terrible storm of people being more vigilant about their medical and mental health needs in good ways, trying to be advocates and trying to seek services. But also I think we are, at least in the United States, there’s just a general sense of increased anxiety and stress on all of us.*”

**⇒** And as you know, stress and anxiety turn somatic, turns biologic

***Those 3 big areas (social media, wearables, and access to healthcare) are big players, but COVID got all of us to think about this stuff***

- Josh was joking with some of Peter’s team earlier that even on the flight here, someone was coughing in the row behind him and he thought, “*Crap, what am I going to come home with?*”
- In 2019, he ever would have thought that, honestly
- He has kids (a kid going to college and a 14-year-old), and in 2018 [and earlier] when they were kids, they had snots, and boogers, and gross, and diarrhea, and you pumped them up of meds and sent them to preschool (you just didn’t care)
- Today when your kid’s sick, you’re thinking, “*How many days of work am I going to miss?*”
- Josh doesn’t battle health anxiety; he doesn’t get too caught up on that
  - He thinks about it more than he wants to because of the work he does

**Somewhere in the last few years, we’ve all become more in tune to our upper respiratory stuff**

- People are wearing masks, before they never did
- In other countries in China and Japan, we saw people wearing masks before the pandemic
- We see this all over the United States now
  - Josh was at a restaurant just a few minutes before he came over and 3 people were wearing masks
    - Do they have it? Are they trying to prevent me from getting it?
    - Are they afraid of them getting it?
  - But five years ago, he didn’t see any restaurant person wearing a mask

**Would there be any pathology there in a person wearing a mask for fear of getting sick?**

If a person’s walking through an airport wearing a mask and you knew that they were not sick, so they were doing it for fear of getting sick, is there any reason to say, “*That person’s not psychologically functioning on all cylinders at the moment*”?

- It depends on their situation; if she’s battling cancer

*Let’s say it’s a 40-year-old perfectly healthy person who’s not undergoing chemo, doesn’t live with someone who’s undergoing chemo; it’a person who pre-COVID would’ve never thought of wearing a mask, but they haven’t escaped the COVID mindset*

- There is possibly a maladaptive behavior there if that mask is being used as a cover to avoid social interactions, as a way to get out of other events

***Josh doesn’t think there’s anything pathological about just wearing a mask because you’re a little bit extra cautious and don’t want to get sick***

- It’s no different than someone taking a vitamin C packet before they get on a plane
  - People do that all the time
  - Does Josh think that stuff works? Not really
- We all take our own approaches for homeopathics, and Josh would put the mask in that category of people who are taking over-the-counter kind of things or supplements to boost their immunity
  - Or to prevent themselves from catching something that would compromise their immunity
- Good for them, he doesn’t think anything about it

*What about driving with a mask on?*

- That blows Josh’s mind if you’re the only person in the car
  - If you’re not an Uber driver
  - That’s confusing
- The other day, Peter saw someone driving down the freeway, they were the only person in their car, and they were driving with a mask on
  - If it wasn’t a rental car
- Josh is not a medical provider and is careful about what he says, but he knows enough about the science that that’s not how you’re going to get some kind of disease
- It baffles him
- Maybe they’re going to the next place and they forgot to take it off, maybe they’re immunocompromised
  - He doesn’t know what their situation is

***To Peter’s point, if someone doesn’t have an illness, is not immunocompromised, and they’re wearing a mask ‒ it seems off***

**Should the majority of people who are not wearing masks look at that person with empathy as opposed to disdain (which is probably how most people look at that individual)?**

- We should look at someone with empathy, with compassion and think, “*That’s not my situation, and I hope that whatever they’re going through is okay.*”

**⇒** We start talking about what you can see and what you can’t see

- Josh has never had someone ask what he thinks about people taking [emergen-C](https://www.emergenc.com/products/everyday-products/#view-all) (vitamin C powder)
- Is that any different than wearing a mask? (not to Josh)
- But we can see the mask

**What about in an environment where nobody else is wearing a mask?**

- They’re focused on it more than the rest of us
- And one might argue, well then maybe the rest of us should be focused on it as well
- Josh just feels that he doesn’t have to do that

## Josh’s approach to patients with excessive health-related rituals and/or OCD using CBT and exposure therapy [A: 54:30, V: 56:41]

*How would you talk to the person who can’t stop wearing a mask everywhere they go?*

- Their rationale is they don’t want to get sick, they don’t want the downtime
- But you want to see them and not their mask

**Josh sees this with romantic partners all the time (it’s not the mask)**

- He runs a [free national romantic partner support group](https://iocdf.org/support-groups/spouse-romantic-partner-ocd-support-group/)  where he sees this all the time, just on different topics

*Examples of a romantic partner’s excessive behavior that causes disruption to people around them*

- My partner never comes to events
- My partner is constantly scrubbing down the counter
- My partner makes sure that we have to have our shoes off before we walk in
- My partner makes me say, “*I love you*,” 17 different ways before we go to bed because the version I said wasn’t good enough
- The point is the partner has a “lived experience”, which is a colloquial common phrase for a mental health person to say that someone has something

***A person with “lived experience” is doing excessive behaviors that is causing impairment and disruption to the people around them***

Another example: you’re wife can’t take off her mask

- You can’t even see her face at dinner

**If this person comes to Josh for therapy, how would he engage them?**

*In the first meeting, Josh is trying to figure out*

- What’s wrong with that, and why can’t you get over it?
- Trying to understand the wife’s perspective
  - What is it doing for her life?
  - What is she solving?
  - Trying to hear her story to figure out, “*Do I have any end inroads in here to figure out how rational this is really getting, how functional it really is?*”
- In the interventions for health anxiety or OCD, you’re starting to talk about **cognitive behavioral interventions**
- Josh is using motivational interviewing techniques, and Socratic questioning, with a lot of compassion and kindness, to try and hear her story, hear her concerns
- The husband is sick and tired of it
  - He’s lived with it
  - He’s coming in with a short fuse
- Josh’s job is to help her figure out, “*Is there any wiggle room in wearing this?*”
- He may not do that in the first meeting, but he’s going to start assessing other areas of her life that she’s not doing that are probably more protective
- Every person who does Josh’s work knows (the research is undeniable): not getting on a plane is the funniest thing in the world
  - Because if you drive a car, you’re not paying at all to statistics, because driving in a car within 5 miles of the radius of your house is the most likely place you’re going to get into, maybe not a fatal car accident, but a car accident
  - Airplanes, despite all the stuff in the last 6 months to 2 years, is still by far statistically the safest form of transportation by the millions and millions of people that fly
  - But it feels terrifying when we start seeing planes colliding, and things happening, and changes with the FAA and stuff
  - But no one looks at that and goes, “*I’m going to change my situation. I’m just not going to get in an airplane*.” But they drive.

Josh is trying to find those moments with the wife, trying to figure out:

- What is the value for her?
- Does she see that it’s impacting her husband and her friendships?
- Does she see that it’s limiting opportunities in her life?”
- What’s the cost, and is there any way for that cost to outweigh the benefit of what she is not being immunocompromised for?
- What other curious behaviors is she doing that look like the mask as well?
  - Is she washing her hands a little bit extra?
  - Does she keep hand sanitizer on her?
  - Does she refuse to shake hands?
  - Does she make sure she brings her own straw?

**How often do you see a person show up for one chief complaint, but upon further probing there’s a series of concentric circles they’re building out from it?**

- All the time
- It’s the whole point of the success of therapy

***It’s very, very rare that Josh will see a single anomalous symptom, behavior, or action being the only thing that is worthy of attention or treatment***

*You can go as far as to play this out in substance abuse and eating disorders*

- There might be the primary substance or eating behavior someone’s engaging in
- Trust me, there are other characterological and other tendencies that someone’s engaging in that may not look as dysfunctional or impairing, but they’re there, they’re under the surface, and a lot of them are probably happening

*Back to the hypothetical wife who wears a mask when she’s out in public places*

- Josh is assuming that she’s spending time at the restaurant also scanning who’s coughing
- Also seeing when the waiter brought the credit card machine, the fold, out of their butt back pocket
  - How disgusting is that? The waitresses stick that in their butt back pocket (or in their pants), and they pull it out and ask us to pay for it? That’s foul
  - Does that make you stop from paying?
  - No. Most of us don’t care about that, but that’s pretty messed up
  - Do you really think that a person didn’t go to the bathroom and do you think they washed their hands every single time? Of course not
  - But if you don’t see it, you don’t think it

***Josh is starting to assess in her this “out-of-sight, out-of-mind” concept***

- What other things is your wife paying attention to that she’s aware of?
- What other things (and this gets a little fun) should she be paying attention to that she probably doesn’t want to?
  - And now she’s thinking, “*Great. Thanks, therapist. Now you’re making me worry about all the other stuff out there*.”

***Josh’s point is: maybe the mask is a bit of an overreach, maybe it can be sometimes modified***

- If someone is completely vigilant about doing said behavior (in this case the mask), and she can’t take it off with you, with her beau, at a restaurant, in the corner, I think we have something to work on there
- If she’s like, “*Well, okay, I can do it at least when I’m with my husband.*” Okay, we’ve broken some ground, we have some wiggle room there

***But often someone has no wiggle room, and they’re not willing to give up whatever that thing is; and that’s where we start talking about doing various interventions***

**⇒** Interventions for this are a combination of addressing cognitive flaws, understanding the behaviors (mental and behavioral) that he or she is doing that are way more pervasive than just the mask

- Start by asking them to make minor modifications to those behaviors, which we typically call **“ritual prevention”**
- Then, if we’re lucky enough, we actually get into a place called **“exposure therapy”**
  - Real anxiety therapists are going to give you some version of exposure therapy

**⇒** Exposure therapy is an intervention that helps someone approximate their fear, facing it head on, in a safe, ethical, compassionate way, without putting them in any ethical, legal or medical risk

- Going back to the ‘60s, exposure therapy is the leading intervention for things like PTSD, phobias, social anxiety, OCD, and health anxiety

***To get someone into exposure therapy means you have to get them across this proces***s of readiness for change, this model of pre-contemplation to contemplation, to ready to take action

- If the wife is like, “*I’m never going to take off this mask*.” she is pre-contemplation
- Then Josh has to figure out what concessions or changes she can make
  - Maybe she goes with her husband to a restaurant with outside seating that’s completely aerated and tries to take off the mask for 5 minutes
  - If she can do that, we’re breaking ground ‒ we’re putting some wiggle room between a dogmatic, anxiolytic (no way wiggle room) action
- Now you’re going to start picking cafes that are outside more than inside restaurants to slowly start building some resistance or strength, bravery, for her to try removing the mask in different locations

***The goal is to starting to break ground and find other things she can modify or change slowly that meets her pace and makes the husband happy ‒ that’s all a good anxiety therapist is going to do***

**Is the idea that you use cognitive behavioral therapy to bridge the gap until they’re ready for exposure therapy?**

- Sometimes
- If someone is so pre-contemplation or so wedded in their rituals
- Josh sees people who are literally scrubbing walls with Lysol and bleach, where the walls are down to the studs
  - That’s more for things like contamination-based OCD
  - People are doing behaviors that require almost hospital-level care
  - Some of them are not ready for exposure-based therapy
  - In that case he’d probably recommend someone, if they’re not on medication, to seriously consider medication

***Exposure therapy is the first line treatment for almost everything to do with OCD and health anxiety***

*Once you get them ready for the exposure?*

- Any of Josh’s clients with OCD or health anxiety are going to get some version of exposure therapy

## Hypothetical example of treating a person with a fear of flying: assessment, panic disorder, and the role of medication and exposure therapy [A: 1:03:15, V: 1:05:52]

**Hypothetical patient**

- They travel a lot for work, but with all this news news around air traffic controllers losing sight of airplanes, they don’t know if they can fly anymore
- This now actually poses a real risk to their career
  - Their career depends on them being able to get on a plane every week to go and meet clients or whatever it is they do
- Josh confirms this is a real world scenario
- The **environmental trigger** is there has been a rash of airplane crashes coupled with objective data that say: air traffic controllers are overworked, and the system is failing, and something bad is going to happen
- This person will basically lose their job if they’re not willing to get on a plane every Monday and come back every Thursday
- They’ve got 2 weeks of PTO, a little bit of medical leave, but they’re running out of options

**How are you going to help this person get on a plane?**

- First, that person is trying to figure out values
- They’re trying to figure out what’s more important
- The belief that I’m going to die in a plane crash versus my job and my livelihood
- They’re in the trenches in that, so Josh wants to join them there

*Before he does anything, Josh is going to do an assessment*

- We’re going to have that first meeting or two
- The initial intake evaluation is gathering a lot of information that they have filled out in advance
  - Going through that and then interviewing them for usually between 60-90 minutes to really better understand their story, what they’re coming to treatment for, what their history of treatment is
  - In situations like this, have they had other moments of fear of flying, fear of driving, other significant avoidant behaviors?

***Ultimately, the goal of an intake evaluation, a first meeting, is trying to figure out diagnostically what’s going on***

- Once you know what that diagnosis is, treatment commences from there
- By the end of intake, the first meeting, they have filled out generic survey forms
  - Some forms that we would describe as evidence-based assessments that have been demonstrated in research to be the best for specificity and sensitivity of getting to symptoms of a diagnosis
  - And in each sub-disorder, depression, social anxiety, OCD, everyone sort of has their tried and true that are research grade that we all sort of know are standard in the field
  - They’re going to fill out some general packets about their life and medical history
- And Josh is going to meet with them to try and help understand their story, to try and build rapport, to try and connect with them
- Because ultimately, he wants to have them run through that brick wall with him at some point in therapy
  - For this person, it’ll eventually be getting back into flying
  - Is that 5 sessions or 50 sessions? Josh doesn’t know right away, and it’s based on a lot of factors

***In the first meeting or two, he’s gathering a lot of raw data to put together a story, which we would call a “case formulation” that explains their diagnosis (or diagnoses), and tell them what the treatment options are***

- In a case like this, it’s likely that someone is coming in saying, “*Do you prescribe* [*benzos*](https://en.wikipedia.org/wiki/Benzodiazepine)*?*”
  - And Josh doesn’t prescribe ‒  he’s not a fan of medication in general that has a high addiction potential (though he knows it helps people and it definitely saves lives)
- If they have to get on a flight right away and they don’t want to mess up travel and PTO, unfortunately, what people usually do is they drink heavily or take benzos to get at least through the flight
- What happens on the other side?
  - They’re now inebriated
  - They got through the flight by white-knuckling it and getting under the influence, but now they can barely get off the plane
  - That’s not a great solution, but it does end up being what people often do with fear of flying because that’s the only way they can get through their flight to get through TSA, and to get in the plane, is going to be some sort of pharmacological (whether it’s alcohol or pills or a combination)

*What about alternative medications?*

[SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) or [SNRIs](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor) have a bad rap as antidepressants, but do medications like that have a role in being part of the tip of the spear to create some increase in psychological resilience?

- In a story like this, probably not
- If the story is that this person has never really seen a therapist before, has never really struggled with things like anxiety or depression, have never taken a medication, and this is N of 1 kind of situation where they’re like, “*Yeah, I’m terrified of flying and it’s ruining my life*.”

**⇒** An SSRI is going to take or an SNRI is going to take several weeks to take action

- Josh is trying to be careful not speaking out of turn
  - As a PhD, he doesn’t usually speak too much about medication, but he’s speaking the way almost anyone who knows about it knows

***SSRIs don’t treat the tip of the peak of anxiety***

- Someone who’s having a panic attack, SSRIs, have been on them for 6 months; it doesn’t help with the panic attack

Josh explains, “*It [SSRIs] can help long-term reduce chronic anxiety, which itself can reduce panic attacks, but if you’re in the throes of a panic episode (which is what often fear of flyers experience), an SSRI in that moment acutely does not solve that issue.*”

Do SSRI’s help you as a therapist by increasing the emotional resilience that then makes them more open to therapy?

- If this is just about fear flying in this unique situation, probably not
- But if someone has a multitude of symptoms and problem areas and this has been going on for a while, then an SSRI in this situation might be a good thing to at least help calm some of the things that we’re talking about
  - So if this gentleman has missed a few meetings because he doesn’t love public speaking, he has to sit around a table and present stuff and he doesn’t love going to parties because he just doesn’t do well unless he drinks at parties
  - And he’s kind of becoming a little bit more of a recluse recently socially in the last few years, maybe because of medical issues or health issues or he’s just in a funk of life
  - And there’s also this flying issue

***An SSRI basically results in an increase in serotonin availability in the brain, but it’s really just a medication for us to actually get to the real tools Josh wants to teach him***

- Because if this is much more of a long-standing issue, an SSRI might help him
- But Josh wants to teach him skills where he can basically have his own tools, his own skills, where long-term he’s both off the SSRI and doesn’t need a therapist anymore

***In this flying situation, if Josh was involving a medical person, he’s probably recommend nothing more than a benzo to get them through the flight into the other side***

- It’s a bandaid ‒ a tiny dose of [Xanax](https://en.wikipedia.org/wiki/Alprazolam) that gets them on the plane and not freaking out

**What is your ongoing CBT exposure therapy to get this person 6 months from now, to be feeling like their old self?**

- A fear of flying is a hard one to ultimately do the real exposure therapy
- Josh used to have a flight simulator
  - In the 2000s, after graduate school, he worked for 6 years in a virtual reality company that actually pioneered virtual reality interventions for fear of flying, fear of public speaking, fear of heights
  - He was on the faculty at a university in Atlanta for a few years (he’s still an adjunct there)
  - He left research and a clinical career working in a hospital to work for a startup, and he worked in private practice
- He used a fear of flying simulator that had virtual reality goggles, a platform that would vibrate, an olfactory system where you could click buttons and make the smell of diesel fuel and a stinky ham sandwich and perfume
  - A full sensory experience to have that suffocating, horrible fear flying experience
  - It’s kind of a clunky system
  - There’s not many clinics around the country that still use these kind of things
  - Most of us who treat fear flying don’t have access to simulators
- Prior to 9/11, many people would actually take short flights with their clients and patients because you could afford it
  - In Atlanta, Josh could fly to Savannah and back in an afternoon and it wasn’t very costly
- Today, it’s almost impossible, shy of him going to the airport, maybe getting up to TSA, having the person buy a plane ticket that’s refundable to go through TSA to sit by the terminal, to then leave the airport and then get their money back
  - That’s probably the closest real world exposure

***What Josh is doing is addressing all the cognitive distortions or faulty logic associated with the fears of flying***

- He has a 30 tip handout he often gives to people about:
  - Understanding what flights are like
  - That air pockets in the flights are not real things
  - That people feel things, and that the wings can go in each direction
    - When we see wings sort of wobbling, they can go almost 7 feet in each direction;  so 14 feet worth of movements
    - When you see the wing doing this, it’s not breaking off
  - There’s all these mechanisms in place when the pilots are flying to keep things safe
  - That flights going one direction or a certain altitude and flights going the other direction or at different altitudes, they don’t have head-on collisions in air
  - Basic facts to teach people stuff that sometimes helps people

Peter asks, “*How much is their fear based on facts that your sheet is addressing?*”

- Sometimes

**In this fictional situation, am I afraid of a midair collision? Am I afraid of the landing because the air traffic controller loses us? Am I afraid of something as vague as turbulence, because I don’t understand what turbulence is?**

- It’s almost none of those

***The most common aspect of fear flying is having a full on panic attack on the flight inside of a metal tube that you can’t get out of***

- Ironically, when people have a fear of dying and a fear of crashing and a fear of midair collisions, what they’re really afraid of is having that feeling of losing their mind on the plane and that they’re stuck on it
- So yes, there are some real elements of teaching people the basics

*Then the treatment gets focused much more on panic disorder*

**⇒** When we’re treating fear of flying, you’re almost inevitably treating panic disorder, which is highly responsive to exposure therapy

- [Exposure therapy](https://www.anxietyspecialistsofatlanta.com/services/exposure-therapy/) is the leading intervention for panic disorder, unless you go back to my scenario where you have to give someone a benzo (which Josh doesn’t prescribe)
  - In those acute moments just to get through a singular moment, and usually if a psychiatrist would prescribe that, they wouldn’t have them take their first dose on the flight
  - You’d usually try a low dose of Xanax a few days before just to see how your body responds ‒ that would be a pretty standard medical care
- Treating kind of conditions like panic disorder, something called “**interoceptive exposure**,” or treating someone to their interoceptives (or bodily sensations) is of all the things out there, the undeniable grand champion of interventions

*Interoceptive exposure is super effective, it is highly compassionate*

- It is not hard to learn as a therapist

***Interoceptive exposure teaches someone that they don’t have to respond to respond to these bodily sensations that they think are going to lead to a full on panic attack***

- It would be very rare for Josh to be treating a fear of flying, a fear of being in a car, a fear of being in these sort situations by also not treating some version of a fear of panic reaction
  - Where you feel like you’re going to lose your mind, you’re going to hyperventilate, you’re going to pass out
- That pretty much goes along with whether you diagnose both conditions: panic disorder and fear of flying
  - The DSM would say you wouldn’t, but in this situation, Josh is treating both situations

## The four types of exposure therapy and the shift from habituation to inhibitory learning [A: 1:14:00, V: 1:17:30]

**What is the exposure therapy for fear of flying specifically?**

*Exposure therapy again is 1 of usually 4 techniques*

1 – One of them is called ***in vivo*** **exposure**, and that is Latin for in life, meaning you’re actually doing real things with real objects

- If I had a fear of podcasting and public speaking, coming in here would be a great *in vivo* exposure

2 – There’s something called **imaginal exposure** which is actually writing a narrative down or a story

- This sometimes we do it with trauma, sometimes we do it with imaginal situations that have never happened
  - Those are 2 different kinds of imaginal exposure
- You’re essentially coming up with a story that you’re going to write down and record and listen to
- This is just the first part of exposure therapy
- There’s a second part that’s even more important to Josh

3 – The third kind of exposure is **interoceptive exposure** where we’re actually inducing real low grade physical symptoms like eye blurriness, rapid breathing, sweating, tummy aches, arm soreness

- While you and I sit here and do a two-minute plank, my arms are going to be wobbly
- So I’m inducing things that people experience in the real world that immediately make them freak out, think they’re having a panic attack, think they’re having a stroke
- This is commonly used for people who have health anxiety, physical symptoms, or panic disorder

Peter asks, “*You’re saying if somebody is worried about eye blurriness, you’re going to put eye drops in their eye?*”

- He’s not going to use eye drops
- Instead, we’re going to look at an iPad that has these cool visuals (optical illusions) that’s going to make their eyes…

Peter asks, “*What about the tummy aches? How do you induce that?*”

- You have someone spin in a chair
- You have someone sort of do some cardiovascular exercise in your office, like sitting up and down, sitting up and down very quickly
- You have someone spin on a baseball bat
- Creating nauseousness and queasiness is not hard to induce
- We’re not having someone eat something or ingest something, because that’s going one step further than you need to
- You can create any sort of physical symptom from leg soreness to a headache kind of symptom, to a tummy ache, to tight shoulders, to cotton mouth
- People who have a fear of swallowing, fear of letting something getting clogged in their throat

***You can recreate almost any physical (not medical) symptom safely***

- If you and I were to go on a treadmill and workout, we’re going to create 95% of the symptoms that people experience when they have a panic attack
  - If you go to a really high level of a treadmill or an elliptical
  - Josh is not going to bring exercise equipment to his office
- Josh is helping people bring real world physical symptoms to light and in his safe laboratory, in a safe place

***This first part of exposure therapy allows patients to experience the thing that they’re terrified to experience***

- But they already experienced it out there ‒ there’s nothing Josh does in exposure therapy that they have not already experienced

4 – The fourth kind of exposure is just called **media augmented or virtual reality exposure therapy**

- People who are using either 3D goggles, virtual reality goggles, videos, audio clips, to use AV audiovisual tools that are kind of mimicking the *in vivo* and imaginal and interoceptive experience
- That can be something as elaborate as real world simulators, virtual reality goggles, or even watching flight land on YouTube 20 times a row to see what happens when the flight comes down
- We treat people who have audio and tactile things like misophonia, which is a high sensitivity to sounds or people who are afraid of hearing something.
- Anything that brings that tool into the place using audio-video

***Part 1 of exposure therapy is you and a patient come up with an elaborate hierarchy ladder ‒ a list of easy, medium, and hard scenarios in their mind that they think they could do at some point***

**⇒** Most people think they can never do the hard ones and they almost always do it successfully

- You’re coming up with this hierarchy based on what you asked about at that first  session, that second session
  - Where Josh is collecting a lot of raw data to figure out: what are the things in their life that are triggering them that he can recreate to help them face their fears head on and come up with new learning? A

**Back in the ’60s and ’70s, we thought that habituation or just getting used to it was the** ***crème de la crème*** **of exposure therapy, and we found out that that wasn’t really solving it**

- Then we started shifting more towards cognitive models, not just habituation and being in a distressed moment
- We are actually now coming up with new meaning about it, which is called **inhibitory learning**
- That was really started at a [seminal article](https://psycnet.apa.org/record/1986-15090-001) in 1986 by Michael Kozak and Edna Foa
  - [Edna Foa](https://psychology.sas.upenn.edu/people/edna-foa) is one of the pioneers of exposure therapy, both in PTSD and OCD, has done amazing work out of U Penn
  - [Marty Franklin](https://rogersbh.org/staff/martin-e-franklin/), a bunch of people at U Penn were the pioneers of exposure therapy
- This article taught us that habituation or just getting used to symptoms, it helps, but it’s not really getting people moving further

***You start having these corrective experiences, when you start unlearning what you thought was going to happen***

- Which anxiety is all about anticipating something and being colossally wrong, thank God
- We need to get people to experience being wrong in a situation that mimics what they actually experience

**Exposure therapy has shifted from just a behavioral physiological model to a cognitive model, and that cognitive model is helping people process that information after the exposure**

- You just did some weird stuff for 20-45 minutes
  - Whether you’re huffing and puffing, practicing giving a speech to a screen, putting yucky things on your hands if you have germ OCD
  - If you’re afraid of bugs and spiders, maybe going to a local pet shop and looking at spiders behind a glass tank or putting spiders that are in resin, fake spiders that are dead on your arms
- All sorts of things that start whatever it is that you can create that sense of fight, flight or freeze, that sense of fear, that sense of dread
  - So your amygdala starts producing the chemicals that you experience in your own life, in my private safe place
- Sometimes we go out in the community, we go to restaurants and shops and do odd, weird things, and so we’re doing that to have people experience that stuff, but also not engage in rituals and compulsions.

**⇒** Exposure therapy is a combination of doing things that bring on a sense of safe, predictable, but uncomfortable emotional physical feelings, while also not doing the mental and behavioral things that bring it back down

***And if you can stay in that state for 30-45 minutes and do that multiple times a week, you start learning real distress tolerance, real resiliency skills, you start disproving that the thing that I thought I had to do either to avoid it altogether or to undo this sense of dread***

- Or feeling, if I don’t undo that and I sit with it, maybe just maybe when it happens in the real world, I don’t have to pop a pill
  - I don’t have to run home
  - I don’t have to wash my hands
  - I don’t have to wear the mask
- We’re combining inducing a sense of arousal, psychophysiological arousal, cognitive interpretations that are usually faulty, not doing things to bring it down and stay with that
- Doing a few different interactive things through 30-45 minute experiences, and then afterwards, processing those lessons learned, making meaning out of these weird situations
- Finding out that you’re stronger than you thought
  - You were finding out that no one died
  - Finding out that in that moment you didn’t do that horrible thing you were wondering if you were going to do

## Treating people with OCD that manifests in disturbing and intrusive thoughts, and why therapy focuses on values over reassurance [A: 1:21:00, V: 1:24:48]

**Josh is treating things like**

- People are afraid of being pedophiles
- People are afraid of getting horrible diseases
- People are afraid of killing themselves or killing other people
- People are afraid of contaminating things and ruining someone down the road
- Some things are imminent and some things are, you won’t know for a few years from now

Josh explains, “*We’re really tapping into this* ***intolerance of uncertainty****, this belief that I can’t deal with the fact that something terrible is going to happen. So I’ve created this fabricated world around me wearing the mask to make sure it doesn’t happen.*”

**You gave an interesting example there. You said people have a fear of being a pedophile**

- Yes

*Let’s posit that this is a person who’s never acted out any such?*

- Absolutely not
- They don’t fantasize about pedophilia, but they have thoughts and feelings about it
- Just like you and I have thoughts and feelings about driving off the bridge
  - Thoughts and feelings of robbing a bank every time you see an armored truck
  - I’m thinking, that’d be fun to take those $4 million, but what do I do? Move on with my day

***Everyone has intrusive thoughts. 99.9% of us have thoughts about sex, drugs, rock and roll, horrible things, and for 93-94% of us they just Teflon right off of us***

**⇒** 4-6% of the population battles OCD

- A thought about punching someone at a restaurant
- A thought about stabbing them in the eye, and moving on
- Road rage, I have a thought of tailing that person and doing something back to them, and I just move on

***But for the person who has OCD, that thought doesn’t go away so easily, and then they start thinking about it, and then they start wondering about it***

- Again, if Josh starts making you think about your left pinky toe, you’re going to feel your left pinky toe
- If you have these unwanted, intrusive thoughts about a kid or her body parts or doing horrible things, guess what’s going to get lit up if we did a brain scan on you?
  - The parts of the brain that regulate sex and arousal
  - And guess what happens when that part of the brain gets lit up?
  - Things down there start getting lit up because your brain’s working

 Josh’s friends and colleagues have been attacked on social media

- These are evidence-based, science-backed amazing clinicians who use their advocacy and knowledge for good to help people to destigmatize (really wonderful people
- They’ve been attacked by some creepy people out there saying, “*You’re endorsing pedophilia*.” ‒ absolutely not

**Egosyntonic versus egodystonic experiences**

- When we talk about OCD and these kinds of conditions, we talk about people who have egosyntonic versus egodystonic experiences
- [Egosyntonic](https://en.wikipedia.org/wiki/Egosyntonicity) is, I want to be here on this podcast
  - I want to be a little bit nervous coming in here because it matters to me
  - It matters whether you like me, it matters if I sound good
  - That means this is aligned with my values
  - I want to put information out there
  - I want to be a voice of reason, and I want to educate your community about all these sort of anxiety conditions
  - That’s aligned with my values
- [Egodystonic](https://en.wikipedia.org/wiki/Egosyntonicity#:~:text=self%2Dimage.-,Egodystonic,-(or%20ego%20alien) means you’re having thoughts and feelings that are not aligned with your values

**⇒** In OCD, it’s epidemic that the things you’re afraid of do not align with your values

- Whether it’s about hurting someone accidentally because you didn’t wash your hands from chicken, or stabbing someone, or killing someone, or molesting someone, or getting punished by God

***There’s all sorts of topics that people get really fixated on accidentally, and they get terrified by that and they spend time thinking about it because they’re trying to get rid of it, or doing something about it (like not going to the park)***

**Does that mean that an egodystonic person rarely, if ever, will act on the impulse, because it is creating so much internal tension?**

- Not only will they not act on the impulse, they don’t even want to talk about it, they don’t want to think about it

Josh adds, “*I don’t want to be gross or offensive here, but I don’t care about saying the word pedophilia. It doesn’t phase me at all because they don’t think about it, it doesn’t bother me.*”

- To someone who has what’s acronym as [POCD (pedophilia OCD)](https://en.wikipedia.org/wiki/Obsessive%E2%80%93compulsive_disorder#Pedophilia-themed_OCD), they don’t even want to hear the word
  - They don’t even want to see it on a checklist

**How does that differ from a pedophile? A pedophile is completely at peace with the fact that they think about it?**

- Whether they’re at peace or not, whether they ever eventually actually hurt a child
- They think about it, they’re turned on by it, and they want to pursue it

We’re starting to talk about the difference between **ideation** (which is just a clinical word for thought) versus **want** (intent, and action)

- Someone who is a pedophile or someone who wants to hurt someone else, someone who wants to rob a bank, thinks about it, plots it
- Whether they’re lucky enough to do it or not, robbing a bank, maybe they do, maybe they don’t, but they have full intent on it
- Maybe they don’t have the guts to rob a bank, but they want to
- That’s someone who’s aligned with that value

People who have OCD are not aligned with anything associated with hurting other people, wanting to bother other people

- It’s a common knowledge in Josh’s work: those are usually the gentlest and kindness of souls
- They’re tortured by the notion of having the most impure thoughts, thoughts of harm

**Is your goal to help those people understand they’re not bad people? And you want to reinforce, you are not going to be acting out on this impulse?**

- No, Josh won’t do that
- Because that’s therapeutic reassurance giving
- In the first meeting, Josh will probably say, “*I know who you are. I know what’s going on here. Welcome home. We have groups, we have podcasts, we have meetings. You’re in a safe place. And I know this is not aligned with your values.*”
  - He will also tell them that if he sees them for 15-20 sessions, this might be the last time he will ever say to them, “*I know you’re not a pedophile, or I know you don’t want to hurt a kid.*”
- They will be confused because in therapy and in life, **reassurance seeking** is one of the most insidious classic symptoms in OCD
- We see it in health anxiety as well

***Reassurance seeking is asking for clarity and for permission and for confession and wanting to get that back***

- If a therapist does that, this is for Josh one of the best litmus tests for an anxiety specialist that wasn’t trained by someone like him
  - If an anxiety specialist does reassurance: he says, “*You’re going to be fine. I’m sure you don’t have cancer.*”
  - Josh has never said to someone, “*I’m sure you don’t have cancer.*” (He doesn’t know if you have cancer)
- A therapist that provides this reassurance is weaponizing that certainty principle, which is all the anxiety sufferer wants

Josh explains, “*I can’t promise you’re not going to die in a plane crash, Peter, and I can’t promise if your wife takes off her mask, she’s not going to get sick at the restaurant. What I can promise is, is if she takes it off, her husband gets to enjoy her more. I can promise if she takes it off, she may be able to do other things that feel risky and scary, but actually add to her life… maybe she’ll have more opportunities. But I can guarantee you if she keeps it on, she’s losing her husband, her friendships*.”

- If she doesn’t care and reiterates, “*I just don’t want to get sick*.” Now she’s choosing her own values here
- This is exactly where Josh needs to get people
  - That is the risk calculation
  - There is not risk-free asset here
- The only thing Josh can promise is that they’re not going to live at some point (which sounds morbid and terrible)
- Josh is earring a bracelet that one of his patients gave him that says, “*You’re not dead yet.*”

> “*The only thing I know in this world is that at some point, we’re both not going to be here. Between now and that data point, what do you want to do to have the biggest and best life?*”‒ Josh Spitalnick

***If Josh promises them that they’re going to be okay, it’s 14 sessions, Prozac is going to work for you ‒ he’s selling them a false sense of hope***

- He hopes it works
- He’s assuming you’re not going to molest someone, but that’s not his job here

**Josh’s job is to help you understand:**

1 – What are your values?

2 – What are you doing aligned with them?

- Trying to not think about stuff and trying to be the best person possible
  - He already knew that

3 – What things are you missing out on because you’re so scared that your values could get compromised?

- I can’t go to birthday parties
- I can’t see my aunt and uncle because the niece and nephew are
- How do we start approaching those situations if you believe that you don’t want to hurt anyone and you want to approach them?
- What things are going on in the inside in your body and your mind that are preventing you from going there?
- How do we start that process?

***Before we’re doing exposure therapy, we’re trying to figure out, how do we start chipping away some of those rituals, some of those avoidant tendencies that you’re doing?***

**Peter’s takeaway**

- Josh said something about this could be fixed in 14, 15 sessions
- He’s only going to reassure them once, in the first session

**Could this person be fine in 6 months potentially?**

- Most likely
- Pre-pandemic, Josh was consistently seeing people for 10-15 sessions
  - This is very evidence-based
- Post-pandemic, people want to talk about everything and it’s his job to figure out how to get to the core of what we’re working on
- Today, he’s seeing people for way more than 15 sessions
  - He doesn’t love that, and he never thought he would be doing that
- Most of Josh’s colleagues agree that we have now elongated the length of therapy
  - Not because we want to
  - Because people have more stuff they want to unpack, more things they want to discuss

**When that person leaves your care, whether it’s 15 or 20 sessions later, do they have just as many thoughts about children as they did when they came in?**

- In general, Josh finds that people have many less of those accidental, internal, unwanted symptoms in general

Josh explains,***“You and I are not defined by our thoughts. We’re not defined by our physiology… or what we think, until you say them or act on them. We are judged by our outward objective, or when we avoid actions, and inactions.”***

**⇒** We are judged by our outward objective or when we avoid, actions and inactions

- And that’s why when people were not taking anti-racist actions, he understands why people were judged for that, because that’s still inaction
- If you chose not to vote, you voted for whoever won

> “*I tell this to my clients, I don’t care what you think and feel, I care what you do next*.”‒ Josh Spitalnick

- Josh explains to clients, “*What you’re doing next is shrinking your life, and I know who you are and I know what you want, but you’re not pursuing that because you’re so afraid that that bad thing might happen.*”
- In any situation: fear of flying, fear of contamination, fear that you might hurt someone, fear that you might have a disease
- Josh knows you don’t want to die, but all the things you’re doing to prevent cancer are costing you financially
  - You can’t see doctors
  - Your family doesn’t want to talk to you
  - You think you’re trying to prevent dying
  - You’re dying right now

Josh explains, “*I call health anxiety the cancer of psychiatry, which is what it is to me. It’s eating you from the inside. It’s its own pathology, it’s killing you and spreading everything around you.*”

- You think you’re trying to prevent this horrible disease down the road

***Josh is trying to help people not eat away at what’s happening right in front of them; and so their value system is mission-critical***

## Acceptance and commitment therapy (ACT): reorienting patients toward values-driven living rather than symptom elimination [A: 1:31:45, V: 1:36:03]

- The biggest change in the field of psychiatry to help people find evidence-based, randomized controlled trial interventions that are research grade that really help people
  - This is [cognitive behavioral therapy](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy)
- The next wave (still under cognitive behavioral therapy when we talk about exposure) is [ACT, Acceptance and Commitment Therapy](https://en.wikipedia.org/wiki/Acceptance_and_commitment_therapy) [Josh explains more on his [website](https://www.anxietyspecialistsofatlanta.com/services/acceptance-and-commitment-therapy-act/)]
- Historically, CBT did not talk about these kinds of things like values
  - What do you really want in this world?
  - Who are you on the inside?

**ACT is an extension of doing CBT**

- CBT is the umbrella, exposure therapy is underneath that, and ACT underneath CBT
- [ACT](https://www.anxietyspecialistsofatlanta.com/services/acceptance-and-commitment-therapy-act/) was pioneered by [Steven Hayes](https://stevenchayes.com/about/) and other wonderful researchers and therapists

***Central to ACT is this 6 construct called the*** [***Hexaflex***](https://en.wikipedia.org/wiki/Acceptance_and_commitment_therapy#Core_principles) ***(this six construct paradigm) that identifies your ability to accept things that are happening inside of you, thoughts and feelings, without it defining who you are***

- Your ability to be present in moments, even if you’re having a toothache
  - If you had a medical pain right now going on, your ability to be present in the moment
- To be able to use yourself as a self-concept: that I’m not defined by my thoughts and feelings, I just have thoughts and feelings
- We teach people to identify when they’re having a thought, to look at thought as a process rather than an object
  - This creates some space between you and your thought
  - That’s a powerful skill
- This is what Josh teaches people when they have thoughts like:
  - God, what if I kill someone?
  - What if I’m gay?
    - There’s something called sexual orientation, OCD, which we haven’t talked about
  - What if I get cancer?
- You can shift that to: I’m having the thought, what if I have cancer?
  - I’m having the thought, what if I kill someone?

**⇒** There’s a bunch of techniques out there called [cognitive defusion](https://cogbtherapy.com/cbt-blog/cognitive-defusion-techniques-and-exercises) that help people separate themselves from their content of their thought

- Within that ACT Hexaflex is values

**Values are mission-critical because for the work Josh does with anxiety**

- Also for the work that Peter does, Josh and Peter kind of have the same goal
- We have the goal of people today living their healthiest and richest lives, and elongating that as much as possible so when we get to the end, the end doesn’t happen as rapidly and as destructively as it sometimes does

**⇒** When psychiatry and anxiety come together, values fall apart: people’s values become focused on intolerance of uncertainty

- Josh uses the word “yucky” a lot with 3-year-olds and 50-year-olds: making yucky go away
  - Not feeling, not thinking

***Your values shift to a negative reinforcement process of doing things or not doing things to remove some bad outcome***

*Josh’s position is: doing things that increase good outcomes*

- He’s trying to shift people
- He has this sheet he uses in his office all the time from the right side of the paper: doing (or not doing) to remove some bad thing that’s going to happen (which is called negative reinforcement) → to doing (or not doing) for the possibility of increasing your lifespan, increasing your marriage, increasing your sex life, increasing your health, increasing your cardiovascular functioning
  - Increasing your ability to go to the doctor and hear the results, and if you have questions, ask them appropriately
  - And if you don’t believe them, go to one more doctor
  - And after that, move on with your life if you can

Because at some point, all of the fact-finding that you’re doing, it’s like the worst puzzle ever

- I gave you a 1,000-piece black puzzle with no corners and I took one piece away and I snuck it my pocket and I just haven’t told you that yet
- And you’re trying to solve this puzzle and you’re never going to solve it

And your value is solving the puzzle at all costs

- I’m not leaving the house, I’m not going anywhere, I’m going to quit my job
- I’m not even going to eat until I solve this puzzle that’s not solvable
- Your value shifted from doing a puzzle to *only* solving the puzzle
- And the problem is, in Josh’s work, most of his patients can’t solve the puzzle
- They have to drop the rope and pick a different game, and that’s the game of life: values, people, love, health

***Therapy is about getting people to see that cognitive shift, that paradigm shift from removing uncomfort, removing ambiguity, removing uncertainty → to doing things that make your life bigger and better***

- There’s no guarantee for that, but that’s a much more exciting life to support someone in, than just making symptoms go away
- So Josh doesn’t care if they stop having thoughts
  - That’s ideal, and we often see that with medication and talk therapy
  - He doesn’t care if they feel less or more

***He cares that when those insidious and uncomfortable symptoms show up, they choose a healthy action that gives them life***

- They do that, he’s done seeing them
  - He doesn’t care what the topic is, what the disorder is

Josh emphasizes, “*If they have the skill of stepping back from their internal symptomatology and choosing a healthy action that increases their world, they’re their own therapist*.”

## Mindfulness as a tool to cultivate presence, awareness, and healthy engagement with life [A: 1:36:30, V: 1:41:22]

**Is mindfulness meditation as a formal practice a part of this therapy with anxiety?**

- Absolutely
- Josh doesn’t typically teach breath work or meditation per se, but anyone who has the capacity to cognitively or physiologically be present with themselves and with the world around them and stay in control
  - It’s a winning intervention
- Meditation has a place in this, mindfulness has a place in this, relaxation training has a place in this
- If taking a cold plunge or going into a sauna is going to ***get you to a place of recognition of what your needs and values are in this world***, that has a place for it
- Josh finds exercise to be the best form of meditation and mindfulness
  - Even though he’s a therapist who does cognitive behavioral therapy
  - He’s a pickleball fanatic; he’s an amateur; he plays pickleball with people at a local community center
- He likes to play pretty intensely, and you can’t do that and not be both mindful of what’s happening around you and in the state of almost euphoria (which he views meditation to be)

Josh explains, “*That’s why paddle sports are always viewed as some of the best sports for longevity of life, for cognitive functioning, for hand-eye coordination, for staying present, and obviously for cardiovascular functioning (if you don’t break a hip or break a leg, which some people do).*”

***Any of those interventions or activities that increase your sense of awareness, your sense of how your body operates, and that encourage you to do things that are healthy and increase healthy actions, all of those have a place, as does extracurricular activities***

- Prayer, knitting, clay, drawing, painting, all of those
- None of those suck away your life
- None of those keep you away from loved ones
  - Unless they become an obsession or an addiction in a bad way

## Hallmarks of successful therapy and red-flags that therapy is not going well [A: 1:38:15, V: 1:43:13]

**What is the success rate of the type of therapy Josh has been talking about?**

- Peter is defining success as a person who after some finite number of sessions gets to the point where actions and behaviors are remediated, independent of thoughts?
- There’s a lot of controversy in the field of psychotherapy research, and even in Josh’s world of OCD and anxiety researchers about what research is and what real outcomes are
  - The medical field does not debate this
  - Josh wishes the psychotherapy field of research didn’t debate this either

**⇒** It’s not just about when you’re doing better after therapy, which is not that hard to achieve; it’s doing better after months of no therapy

- Josh knows his patients are doing better when he doesn’t hear back from them, when they truly become their own therapist

***The best research in psychotherapy and the best RCTs show that when there is 6 months, 12 months, 8 months of follow-up that is demonstrating continued symptom remittance or sub-diagostic gain***

**What are some signs or things that you see in therapy that give you concern that a person is not going to recover?**

- 1 – When someone is therapist shopping, and they’ve been to 5-7 therapists in a short amount of time, that scares Josh
  - That tells him they’re looking for a certain answer or a certain kind of therapist, and no therapist is matching their needs
- That’s no different than finding a romantic partner
  - When someone has been through multiple partners in a short amount of time, it’s the consistency in that that concerns him
- 2 – When someone is a “*Yeah, but*” in therapy, that really scares him because that means that they know all the answers

***They’re struggling with what we call cognitive flexibility and in acceptance and commitment therapy and in CBT, cognitive flexibility is mission-critical***

- Josh is going to be teaching you that maybe you’re wrong
  - This goes back to the [Foa and Kozak 1986 article](https://psycnet.apa.org/record/1986-15090-001) about corrective information
- 3 – And when someone is characterologically unwilling to be wrong, you’re not going to do well in therapy. It’s just a fact.

*How soon would you figure that out?*

- Most therapists have a general sense within the first 2, 3 sessions
- Within the first 2, 3 dates, someone knows whether there’s an attraction
- Josh has a mega practice: he’s in a team of 25
  - He has therapists in 3 states (Georgia mostly)
  - They see people in 40 states
- At this state in his career, he sees the sickest of the sick
  - He enjoys that intellectually
  - He can treat dog phobia
  - He can treat someone who’s having weird eating issues
  - He can treat panic attacks (he did that years ago)
  - He’s seeing people who are very ill, who have been to hospitals, who have failed medication trials, who have tried TMS and ketamine
- Josh is not perfect at it, he’s not getting 100% results here, but he’s seeing people who think that they have no chance to get better, but they want to and they’re desperate for information and they’re desperate for someone who can see them and understand what’s going on

***His success rate is probably not better than the other people he saw that were easier to treat, but he’s seeing people who shouldn’t be getting better and they still get better***

**Patients get better because they want it**

- They’re willing and they’re trying everything they can
  - Even if they’re stubborn
  - Even if they’re hopeless
  - Even if they’re not doing well
- There are these sort of intrinsic cognitive states that people are in where they just can’t see anything but what’s in front of them, and if Josh can’t push them beyond that, he’s going to be the next therapist that they fire

**Other red flags that therapy is not going well**

- [It’s a good sign] when people are open and willing to new ideas, to weird interventions

- If someone’s never had exposure therapy
  - Josh sees plenty of people who have been to multiple therapists who’ve never even had exposure therapy, and to him, that’s like you treating someone for [ASCVD] and not giving them cholesterol medication (well, that’s the no-brainer)
- He sees people who have a condition that the only intervention they should get is some version at least of cognitive behavioral therapy and they haven’t had that
  - It blows Josh’s mind that they’re seeing a supportive therapist, an analyst, or they’re doing soft therapy

***When he sees someone who is not willing to hear his ideas***

- Someone who, when he shares with them videos or clips, they’re not willing to watch them
- He’s watching that resistance play out and he’s like, “*How do I connect with them?*”

*Another major factor is the in-between session experience*

- This has been proven in psychotherapy research across psychotherapies
- Josh sees most people weekly
- When he’s seeing someone that needs a high level of care, sometimes I’m seeing them 2-3 times a week
- There are in-session interventions, things he’s doing with the person, funny moments we have, light bulb moments and techniques we practice
- And then there’s homework ‒ Josh doesn’t like to use the word homework

**⇒** The research is undeniable [about the success of] a homework-driven structured kind of therapy like cognitive behavioral therapy, dialectical behavioral therapy, acceptance and commitment therapy, mindfulness-based CBT ‒ all the interventions that utilize skills between sessions

- This is no different than working out with the trainer
  - If you go with the trainer and don’t work out for the rest of the week, guess what happens in week 2? You’ve gained nothing
- If you practice through a golf instructor in week 1 and you did no practicing in the course between the next appointment, your stroke’s not going to be any better
- And psychotherapy is no different

***If you’re not doing the assignments between sessions, you’re not learning and messing up***

- Josh loves when people mess up their assignments
  - He doesn’t care if they do them right
  - He just cares that they try them
  - Because if they mess up, guess what he gets to do? Correct information
  - That’s a critical ingredient

> “*This is all about learning and messing up, learning and messing up, and learning from that and building from that*.”‒ Josh Spitalnick

- When he sees someone who didn’t do the assignment between sessions he wonders, “*Okay, am I going to give them the right assignment or are they just going to block me as well?*”
- This falls under the category of them needing more cognitive flexibility or they think they know the right way

***Interventions between sessions is where we gain mastery of skills, and then they come back and Josh refines them, we practice them, and then they practice them and Josh gives feedback***

- That in between stuff is pretty important
- When someone doesn’t do work between sessions (if there’s work to be done) Josh is having “Groundhog day”
- He’s having the session of, “*Well, let’s talk about what we talked about last time and what got in the way and did I not assign it right? Did you not understand it?*”
  - And we’re having a little bit of playback, which can be defeating in therapy when you think you know what’s best for them
  - And sometimes we’re wrong and then you try something else
- But if they’re not trying it, Josh can’t learn from their mistakes

## The relationship between anxiety and substance use, and the therapeutic challenges it creates [A: 1:44:45, V: 1:50:07]

**Does anxiety, whether it be health anxiety or any of the subsets that we’ve talked about today, does it tend to traffic with other comorbidities, either health comorbidities directly or more importantly, psychiatric comorbidities?**

- The most common symptom seen in anxiety is avoidance
- Josh sees people dabbling in the use of: alcohol, marijuana, opiates, and stimulates to feel better
  - Not full on abuse
- Low-grade substance use is a common co-occurrence

*Is the causality “I am using the substance to medicate the anxiety,” or is it the other way around?*

- Both; it’s probably bidirectional
- There is definitely an element of “*I’m self-medicating because I don’t want to deal with my stuff*”
- This can be a problem when Josh is doing exposure therapy
  - When someone is muting their anxiety response, muting their sympathetic/parasympathetic activation
  - If he can’t tap into that to have their amygdala and limbic region light up
  - He needs to have them feel that to teach them some corrections
  - If they’re numbed out, he can’t make those changes

*How do you manage that then?*

- When you realize somebody is coming to see you high, and they’re high every single day
- Sometimes he says, “*Listen, I can’t really help you until we get you off this, because I need to experience you in your native state*”
- If you’re at this level of usage, even if it’s not impairing our lives completely, Josh may tell them, “*I may not be the right therapist for you*.”
- Josh comes from a **harm-reduction model**
  - He’s worked in abstinence-only models and he’s a believer that if we can reduce this and get it into a moderate state of whatever it is you’re using as a starting point
- This is the concept of **working at the hierarchy of exposure therapy**
  - He can’t ask them just to quit ‒ that’s not even a concept to him
  - We’re taking baby steps if someone’s willing to make a concession or two

*What if they say, “But doctor, listen, I have to use. This is actually helping me.*”

- They’ll say that on Banzos, on marijuana
- They will say it reducing their anxiety and they don’t want to cut back
- Josh has seen patients who use weed chronically but are functioning in most areas of their life in general, occupationally
  - Their partner smokes with them or their partner doesn’t care
- But they’re coming with anxiety issues, and it can create a real dilemma
- Josh needs pockets of time where they’re not just always feeling “numb”
  - He wants them to feel the stress in small doses
  - He wants them to have these hiccups where they can feel and have differentiation

***Ultimately, the short answer is: if someone is wedded to using a substance and it’s just going to get in the way of my work, Josh will probably refer them to someone who’s more likely to work with them***

- Josh doesn’t always know who that person is because most therapists don’t want to work with someone who is chronically using a substance that’s causing impairment and they’re not willing to give it up
- And if they’re not willing to go for treatment for that, then we have a different issue
- More often what Josh is finding is in the first three sessions, he’s going to discuss this
  - He’s going to ask if there’s any way for us to change it and to see again, if there’s any wiggle room, there’s any flexibility in there to make changes anywhere in your life
  - Can we just give it up on Tuesdays?
  - Can you just make sure you don’t smell weed when you walk into my office?
- In Georgia, it’s not legal, but people still smoke it like everywhere else
- But if you’re smoking and driving, that’s DWI, and that concerns Josh

Josh’s main point:

- In general, he’s in a harm-reduction model, “*How can we do things that bring less harm to your life and open up your life more?*”
- If someone is wedded to anything in their life that Josh finds to be destructive and he thinks it’s going to get in the way of our therapy, he’s not the right therapist for them

*There is a sub-area of research in the exposure literature for which exposure therapists won’t do exposures for people who are under the influence*

- They won’t do exposures on the day where someone has taken a [benzo](https://en.wikipedia.org/wiki/Benzodiazepine)

*If you think about* [*PTSD*](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) *populations, polypharmacy is usually the baseline*

- People are sometimes taking an SSRI, 1 or 2 benzos (1 long acting, 1 short acting), maybe a stimulant, and maybe even a low dose antipsychotic
- If someone is taking a benzo on the day of exposure, you can’t tap into the things we’re trying to tap into
  - Into that bulb of the [amygdal](https://en.wikipedia.org/wiki/Amygdala), that bulb of emotional centeredness to have that lit up so we can have some corrective experiences
- You’ll see in research studies, whether people noted, “*People were not allowed to take benzos on the day of exposures*,” and so that becomes a challenge

Josh explains, “*When I’m doing anxiety work and someone’s doing something, I don’t view it as a legal or ethical issue, but it’s muting my ability to tap into real presence, talk about presence. I may not be the right therapist.*”

- It’s not a judgement, it’s simply an efficacy question

***What the patient wants from Josh and what he is able to offer them is attenuated by the fact that they’re not going to remember this conversation the same way (that’s not good)***

## Anxiety’s overlap with ADHD, OCD, autism, and physical health conditions [A: 1:49:45, V: 1:55:30]

- [ADHD](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder) or attention issues are pervasive
- Lots of kids are seen at Josh’s clinic, but he can’t tell you the chicken and the egg of: do you have ADHD or anxiety or both or neither half the time
- And even the best diagnosticians can’t tell you because if you have pervasive, intrusive thoughts, Peter, how the heck are you not constantly interrupted in your prefrontal cortex?
- If you’re thinking about raping and killing or health or disease or dying or morbid topics, how can you possibly be attending to all the things in the room?

***People who have anxiety have these attentional biases and disruptions, OCD, and health anxiety related conditions***

**⇒** We don’t know all the mechanisms, but there’s a breakdown between executive function operation and the emotional or limbic region

- There’s a disruption there; and so attention is pervasive

*In the OCD community*

- We’re seeing higher rates of co-occurrence of autism and OCD
- And then when you get into the molecularity of OCD, we see a lot of people that have these interesting areas like tics, body-focused, repetitive behavior, something called “[trichotillomania](https://en.wikipedia.org/wiki/Trichotillomania),” (which is hair pulling of different parts of your body) or [dermatillomania](https://en.wikipedia.org/wiki/Excoriation_disorder), (which is skin picking)
- We see co-occurrences of tics
- Trichotillomania and derm

***There is a lot of co-occurrence of tics,*** [***BFRBs***](https://en.wikipedia.org/wiki/Body-focused_repetitive_behavior)***, chronic medical issues (like IBS, restless leg syndrome) with people that have chronic anxiety, ADHD, autism***

- At the [Anxiety Center](https://www.anxietyspecialistsofatlanta.com/), they treat all the primary 9 anxiety disorders and also dabble in autism, ADHD, mood disorders, relationship and emotional dysregulation

Josh adds, “*You have to know the science and molecularity of anxiety to understand that. And if you’re not the right person to treat that, we’ll make a referral out or referral within our team*.”

## Debunking the harmful myth that health anxiety is a “made up” condition [A: 1:51:30, V: 1:57:29]

**What do you think is the biggest myth about health anxiety?**

- That someone’s making it up
- That someone’s looking for attention
- That there is secondary gain

**⇒** It is disheartening and sad to see a medical professional or loved one tell the person that they’re just drug seeking or seeking attention

- Josh knows that’s the case on an occasion, but nobody wants to have OCD or health anxiety
  - It is not functional
  - It is not fun
  - It is not enjoyable
  - It is not adaptive
- When someone says, “*Oh, my OCD helps me be better at work*,” that’s not OCD
  - You’re talking about something else there
  - Whether we’re talking about perfectionism or OCPD, obsessive compulsive personality disorder or something else
  - There is not an ounce of functionality with OCD in anyone wJosh has worked with
- No one believes that OCD has any adaptive healthy aspects to it

Josh explains, “*Health anxiety for me is terrible because you and I are in different professions, but we’re trying to help people live their best quality of lives, live their fullest lives, and it breaks my heart when I see someone who has health anxiety, who is convinced (and I’m not talking like they’re wondering) something is wrong*.”

- Despite Josh’s loving, compassionate guidance, 5-7 doctors have told them they’re crazy and they’re 100% convinced that there’s something wrong with them
- It’s heartbreaking to see that
- And until you can get them to shift that needle and be a little more flexible, they’re stuck and they’re losing their quality of life and the thing they’re trying to preserve is the exact same thing they’re killing

***The sense of I’m making it up, I’m fabricating it, I’m looking for attention, or I’m just looking for drugs is just not the case***

- These people don’t want to be this way
- They don’t want to be seeing doctors
- They don’t want needles
- They don’t want all the exams they go through, but they’re willing to do it
- Josh has written about this and he put out a [book](https://www.amazon.com/Complete-Guide-Overcoming-Health-Anxiety/dp/B0CQK52RKC/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.PpBssnzYkAbVI85-2zjLkQ.PiftBx6O09Bs6F6XwQIGd8W9pqOHEl_FSVEY6cmTyMo) a year and a half ago [shown below]

[see also the companion [website](https://www.overcominghealthanxiety.com/)]

![](https://peterattiamd.com/wp-content/uploads/2025/08/f2-joshspitalnick-706x1024.png)

**Figure 2. Josh’s recent book**. Image credit: [Amazon](https://www.amazon.com/Complete-Guide-Overcoming-Health-Anxiety/dp/B0CQK52RKC/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.PpBssnzYkAbVI85-2zjLkQ.PiftBx6O09Bs6F6XwQIGd8W9pqOHEl_FSVEY6cmTyMo)

- He has a health anxiety online platform [[Wednesdays](https://www.anxietyspecialistsofatlanta.com/events/health-anxiety-support-group-ohacommunity-wednesday/) and [1st Thursdays](https://www.anxietyspecialistsofatlanta.com/events/health-anxiety-support-group-ohacommunity-thursday/)] that people come to for support groups and information and cool challenges and weird stuff
- Josh hears this unfortunate story all the time, “*I’d rather just have cancer. I’d rather have my arm amputated. I think I have an osteosarcoma in here. I’d rather just have that nerve clipped. I’d actually rather be paralyzed so I don’t feel my leg pain anymore*.”
- And you’re thinking, “*Did you just say that? You’d rather have the finality of impairment or disease that every physician has told you you don’t have, rather than a different approach that I’m trying to offer you*.”
- And whether that’s some medication, talk therapy or something else, you’d rather be impaired or a quadriplegic or have the diagnosis of cancer that you don’t have just so you stop worrying about it
  - Wow, that’s another level of willingness to get answers

***That’s how insidious and how disgusting and how horrible these sticky, tricky conditions are, which (Josh is mostly referring to OCD and health anxiety)***

**⇒** They have these thoughts and belief systems that are so entrenched and so believable and it’s the biggest ruse in the world

- If Josh can get them to hear that, if he can get them to realize that maybe if we can drop the rope and come back and try it a different way
- Maybe just maybe trying to figure out whether you have cancer or not is *not* the most important thing you do today

## Prevalence, severity, and evolving treatments for health anxiety and OCD [A: 1:54:45, V: 2:00:57]

**Do you have a sense of what the prevalence is today of people that are as ill as you just described?**

- Research in the last 10, 15 years is pretty consistent

***About 4-8% of the population has some version of health anxiety in their life; and over 30% of people who have chronic illnesses (Crohn’s, cancer, diabetes, sickle cell, etc.) have some version of health anxiety***

- 20-30% of us have some subclinical health anxiety notable preoccupations
- As we get older, it obviously increases because we have more health and medical issues
- There was an interesting [study](https://pmc.ncbi.nlm.nih.gov/articles/PMC7578938/) that came out a year or two ago, and then a 2024 big Swedish [study](https://pubmed.ncbi.nlm.nih.gov/37728316/) post-pandemic that health anxiety has skyrocketed in the last 4 years just because of whatever the pandemic has done to the world and people’s hyper focus on stuff
- In the OCD and health anxiety community, if we’re saying that 6-8% of the population has OCD or health anxiety, probably over a third of them are at that severity level where you start wondering about insight, you start wondering about their ability to reality test
- And that’s why medication in this case is fundamentally critical

**The role of medication in treatment**

- It is pretty rare for Josh to see someone with severe OCD or health anxiety who would not benefit from an [SSRI](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) or an [SNRI](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor) of some kind
- Often you’ll see psychiatrists add a low dose of an atypical antipsychotic for a lot of mood instability
  - Such as [Thorazine](https://en.wikipedia.org/wiki/Chlorpromazine), [Zyprexa](https://en.wikipedia.org/wiki/Olanzapine), [Seroquel](https://en.wikipedia.org/wiki/Quetiapine)
  - Thorazine’s a little bit older, but [Abilify](https://en.wikipedia.org/wiki/Aripiprazole) is in that mixed class just to help with the mood issue

***At least a third of the patients that come to Josh’s clinic (and they see a wide range of everything) are at that severe level, and there’s not enough providers out there***

*Is the medication temporary to get them through the therapy?*

- It’s necessary to get them through the therapy

*How many of them can get off the medication?*

- Josh would roughly estimate ⅓ or ½
- A lot of people are afraid to come off medication if they are stable
- Josh is a believer that if you’re on medication, doing well, and you want to stay on it, great for you
- Some people try and come off and it creates a spike in symptoms, and we immediately get back on
- That’s why most people will taper down and not just go off medication

**Treatment-resistant health anxiety**

- Josh’s bigger concern is when someone is unfortunately treatment resistant, not because they’re trying to be
  - There are treatment non-responders
  - They’re not responding to the normal pharmacology
- Josh has very little knowledge of the science and mechanics of this
- This is why we see people today getting deep brain stimulation, ketamine, and other kind of pretty new age medication interventions or device interventions
- In the last few years there’s been research looking at things like [MDMA](https://en.wikipedia.org/wiki/MDMA) and other hallucinogens
- Sometimes with veteran populations, they’re trying to figure out what other medications out there, what other poorly controlled medications out there can help people
- That scares Josh because people go, “*Oh, I can take low dose psilocybin and get better*.”
  - You’re not taking regulated low dose psilocybin, you’re experimenting with mushrooms (that’s not the same thing)
  - You’re trying ecstasy, that’s not controlled MDMA

***All these new age technologies and medications are important because unfortunately, there’s going to be a population out there that doesn’t respond to CBT***

**⇒** With the best studies, these kinds of interventions are 60-65% effective

- There’s other interventions out there, like other [metacognitive therapies](https://en.wikipedia.org/wiki/Metacognitive_therapy) and an intervention called [inference-based CBT](https://en.wikipedia.org/wiki/Inference-based_therapy), but their success is still in the CBT range (around 60%)
  - These are other cognitive-based interventions that people have been developing and refining and improving

***60% is not enough, and so Josh excited to see next wave genetic research and testing and medication research to figure out what are the ways can we find a way to fix where the brain is falling apart and where genetics kick in***

**You mentioned** [**TMS**](https://en.wikipedia.org/wiki/Transcranial_magnetic_stimulation) **briefly, where do you see the promise there?**

- It’s still in experimental phases
- There’s people that have short-term memory losses
- Josh’s anecdotal experience is that people have an initial improvement early on and then it fades
  - He’s known 15-20 patients in Atlanta
- Atlanta has a few TMS centers and ketamine and infusion centers
- More psychiatrists in private practice (not even at the universities Josh belongs to) are now offering [ketamine](https://en.wikipedia.org/wiki/Ketamine) infusions in private practice
  - This is brand new kind of thinking
- They’re trying everything they can to offer patients stuff

***Josh doesn’t know enough about the research and the science behind TMS and ketamine to speak to it at a large scale and then whether people should try it***

**Treatment success rates**

- These are options that researchers and psychiatrists are looking into because we know that CBT is 60% effective
- SSRIs on a good day are 40-60% effective

***For most studies, the combination of an SSRI or SNRI and CBT is usually the best outcome, but they’re still not treating everyone and not everyone can access them***

**Josh loves being a therapist**

- He has trained a lot
- He disseminates information and makes it as available and accessible and affordable to the people that come to our clinic
- He’s in a Facebook group of about 5, 000 specialists (a very closed, private Facebook group only for practitioners)
  - This is all we discuss, this kind of stuff, 24/7
  - It’s an amazing Facebook group that’s been around for about 8 or 9 year
- There’s tons of Facebook groups and social media platforms out there
- Josh is on 20 other Facebook groups, but he’s in this one special one out there that two of his colleagues launched in 2017, 2018
  - Right now it has almost 5,000 OCD [BFRB](https://en.wikipedia.org/wiki/Body-focused_repetitive_behavior) specialists comprised of junior trainees to as senior and seasoned as they get
- We have all these discussions:
  - We debate what are the medication options?
  - What are the alternative interventions?
  - What’d you think about this thing that someone podcasted about?
  - And we’re all trying to figure out how do we get another 5-10 percent efficacy with these populations who are just not getting better

**Hospitals in the last 10 years have changed**

- There were more hospital centers willing to take on residential patients, and right now there’s only about 5 that Josh knows in the country that he would view as the best OCD centers
- There’s tons that pop up every day and things that IOP and PHP centers that sort of show up, and Josh is always supportive of them, ***but they’re not doing evidence-based practices***

> “*There’s not enough of what I do out there, Peter, to meet the needs.*”‒ Josh Spitalnick

- Hopefully other biologies and genetic testing and other interventions increase this

Josh summarizes, “*At the end of the day, the kind of work that Josh and his staff does for cognitive behaviorally-based, exposure-based work for how anxiety and OCD sometimes with and without medication seems to be the most effective, the most available, and the most that gives people their life back afterwards, that excites me. I love that*.”

## Treating health anxiety is about providing patients with skills to improve quality of life—a discussion on how to address symptoms often attributed to long COVID [A: 2:01:30, V: 2:08:21]

**How much are you guys seeing** [**long COVID**](https://en.wikipedia.org/wiki/Long_COVID) **that may or may not be long COVID?**

- Peter’s intuition is there is undoubtedly a subset of people who had COVID who are having an ongoing issue as a result of it, and also a lot of people who think they have that
- In reality, they either don’t have anything medically wrong with them or maybe they have something else medically wrong with them
- Josh joins Peter in the ignorance and humility of, “*I don’t know enough about it to say anything major*.”

***Josh thinks prior to COVID, people described identical symptoms that they’re describing now, are now attributing it too long COVID***

- Josh has been practicing for almost 25 years
- You can look at it and go, “*Well, if it wasn’t long COVID then because that word didn’t exist, that phrase didn’t exist, how could it be so high today?*”
- He doesn’t know the answer, but he sees people coming in with a set of head fog, fuzziness, inattentive stuff, low grade depression, not feeling great, having a hard time articulating
  - Patients say, “*I had COVID a few times. I’m wondering if it’s that.*”
- Josh is joining them thinking, “*I’m wondering if it’s that too, but I have no idea.*”

Josh points out about that line of thinking, “*That doesn’t serve my needs. How do I help you be adaptive? How do I help you function?*”

- He thinks long COVID is an easy thing to latch onto
- People have gotten on disability for this
- People have sought out medication treatments for this when in the past they just assumed that they had ADD or headaches or they had some head stuff going on

Peter points out a benefit in that situation of saying everything Josh just said, which is, “*Actually, I don’t know what it is, but I want to help you. I want to help you adapt to it*.”

**Can you take the next step and say, “*****Let’s assume for example, that whatever you’re feeling, which is real, we’re going to acknowledge that it’s real, let’s assume it’s not attributable to a biologic symptom.*****” And then we go down the same pathway. Is that a helpful framing?**

- Remove that second part: let’s assume it is or is *not* a byproduct of biologic
- You don’t have a solution for it if it is biologic
- Josh has solutions for it, whether it is or isn’t
- Josh really does stay in that gray space of, “*I don’t know if you have cancer*,”
- In Josh’s [book](https://www.amazon.com/Complete-Guide-Overcoming-Health-Anxiety/dp/B0CQK52RKC/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.PpBssnzYkAbVI85-2zjLkQ.PiftBx6O09Bs6F6XwQIGd8W9pqOHEl_FSVEY6cmTyMo), he has a case report (that a kind person allowed him to share) where he treated her for health anxiety of GI tract esophageal issues
  - It was very successful and went great
  - She was starving herself and losing weight and losing her life to a new medical conditions
  - A year and change later she writes Josh and says, “*By the way, I have thyroid cancer.*”
  - Now did we miss that? And the answer is no, because she was being followed by a thyroid specialist and was on [Synthroid](https://en.wikipedia.org/wiki/Levothyroxine) and other stuff
  - It’s tricky because I don’t take away from the work that we did

> “*I don’t know what I don’t know. What I do know is your life is not as good as it could be. Can we try some stuff?*”‒ Josh Spitalnick

- Josh doesn’t know whether you’re going to get cancer or not
- 33% of us are going to get cancer
- Josh has patients that don’t know that we’re born with cancer cells
  - Boy, does that piss them off when he tells them that, “*By the way, I don’t know if it’s going to express itself or not, but we all have cancer cells*.”

***Josh doesn’t know which people he’s going to see that are eventually going to have that thing that they were terrified of***

- He doesn’t know which people he’s seeing right now that have something that’s been unassessed and undiagnosed

**What Josh knows is there are things that he can teach someone of mind and body**

- Peter is not doing anything much different, he’s just doing much more in the medicalized space, that can give you better life today
  - That can elongate your life today
  - That can have you more present in your life today
- And if you die tomorrow or 6 years from now, will you regret the things that we did to improve your life?
- Like Josh’s bracelet says, “*You’re not dead yet*.” So what do you want to do about it now?

Josh explains, “*The other stuff you’re concerned about, go to a doctor or not, go to an immunologist or not, go to your ENT or not. That’s your space. Here’s what I can offer you. I’m a believer of mind over matter and you are what you think and you are what you do. And there are so many things that we don’t tap into in our physical and mental capabilities. I love that part of my work as a CBT specialist. It’s why I got board certified.*”

**CBT is called behavioral and cognitive**

- Because there’s so much that we can teach people about diet, nutrition, exercise (healthy lifestyle habits)
  - These are things that are bigger for Peter than they are for Josh
- About not getting fixated on thoughts like greed and regret and guilt that really eat at people alive
  - They’re poisons to us and they manifest semantically
  - Those things come out of us

**Josh’s playbook when someone comes to him and says, “*****I think I have this condition*****”**

- Whether it’s seizure disorder, cancer or long COVID, Josh gets to play, “*I don’t know anything about that*.”
- What he does know: here are a set of skills he can teach you
  - If you want to join him in that process, he can make your life a little bit better or a lot better (What do you want to do?)
- Now you have agency; now you get to choose
- And you might have that thing, go do that thing, go follow up with that doctor
- But ultimately, at the end of the day, people are going to make decisions for themselves

***They’re either going to be about removing discomfort, ambiguity and uncertainty, negative reinforcement, and or (and it’s not just or) doing things that give them a chance to improve their quality of life, relationships, romance, financial status, whatever it is***

- Josh likes to help people do that build rather than just remove bad
- People come to someone like Peter and Josh and say, “*Can you help me get rid of my symptoms?*”
- Josh’s response is, “*I can, but can we also add to your life?*” And that’s what **positive reinforcement is**
  - That’s what living the fullest life is

## Balancing the benefits of abundant health information with the risks of fueling health anxiety [A: 2:06:30, V: 2:13:52]

**Where do you think the balance lies between the abundance of information we have today about health and triggering health anxiety?**

- Peter is sure he directly (but inadvertently) is contributing to health anxiety
  - But of course he contributes to a lot of good things as well (far more net positive)

*What steps could someone like Peter take  to reduce the bad without diminishing the good?*

- Josh appreciates Peter asking him that because the work that Peter is doing is having people go to unbelievable lengths with biomarkers and physical things for now and in the future
- Josh’s career and the things he focuses on are about letting go of the future and focusing on the now
- There’s a little bit of tension there
- 1- One of the nicest and kindest things you can do is making sure that people are not absolutely dogmatic looking for a singular answer or a singular diagnosis or a singular cure
- Josh would get concerned if someone was going to great lengths because they believe that there’s only one fuel, one vitamin, one diagnosis, one biomarker that answers everything
  - He knows Peter is not doing this
  - And people who think that way are set up for failure because nothing is 100%
- For example, the work Peter does is to not purport the belief that if we just solve that one genetic anomaly or if you just build more muscle mass, you’re set
- Because people hear that and your word is God, they’re going to do that and they’re not going to be able to fulfill that
- 2 – Teaching cognitive flexibility is critical
  - You’re asking people to take on a lot of new ideas
  - You’re asking people to try new things, explore new things, and that cognitive flexibility includes, “*Hey, let’s try something different than the thing you wanted to try*.”
- Exposure therapists are funny cats ‒ we do weird stuff
  - If you came to Josh’s office, you’d see: fake dead stumps, fake blood, fake semen, needles, animal skulls, band-aids, weird outfits we wear, all sorts of…
  - We are disrupting a lot, and disruption’s a good idea, especially when someone’s not expecting it (and they get better for it)
- **Josh’s advice for Peter’s space**: if you can continue to do what you’re doing, but adding elements of surprise and disruption where it’s not linear and it’s not a silver bullet and you thought it was this, and then you publicly say, “*Well, we thought it was this. We’re changing our course.*”

***That level of disruption and flexibility just promotes that we’re all trying to achieve this final linear option, but we’re never going to get to linearity***

- There’s going to be so many paths that we’re all unique on and keeping people curious and flexible and not believing that if I take this shake and do this thing and find this biomarker, I’m going to live the best life possible
  - Because even you know that’s not true
  - But people want that

**People want one solution and we need to promote flexibility**

- We have these wonderful medications right now that are **helping people lose weight**
- That’s fantastic, but that’s one of a thousand other options out there
- It’s the quickest and maybe the easiest for certain people (with and without side effects)
- But those are not the only options
- When we start looking at these sort of medical and biologics that are so effective and so efficient and so quick ‒ Josh thinks the medical industry sells that a little bit too much
- That’s why people don’t want to come see someone like Josh because they don’t want to do therapy
  - They don’t want to do this for 15 to 20 sessions
  - They don’t have to learn stuff

***People just want you to give them the pill or the laser and they’ll be great***

**Josh always gets worried when physicians or medical people are selling wonderful, lovely ideas that make your life better**

- This is like Jurassic Park: you’ve jumped science and learning and knowledge and have you not learned from your past mistakes

***That curiosity and that flexibility should be built into anything that you’re doing, anything that Josh is doing***

**With patients, Josh is trying to be curious**

- He’s not right about everything
- He’s probably wrong about half the things he’s telling them, but he’s going to keep trying and keep learning
- We’re going to have this relationship that is collaborative (we call it **collaborative and empiricism**), and we’re going to learn together and hopefully we’re a net positive (more right than we are wrong)

**Those with health anxiety**

- But inevitably, a small percentage of the people that follow what Peter and other people put out there about living your best healthiest life are going to take it one degree too far and believe that that is all they can do

***Unfortunately, that’s a percentage of any population out there that’s going to get trapped into looking for the single solution or the single medicine or the single biomarker, and they’re going to go to great lengths to solve that***

- In Josh’s work, that ruins people’s lives

Back to Peter’s question, Josh explains, “*It doesn’t discredit all the amazing things you do, it’s just staying flexible and curious, and not believing that any one thing solves anything is all I would ask of you.*”

## Advice for finding a telehealth provider with expertise in health anxiety [A: 2:11:00, V: 2:18:45]

- Josh’s practice takes care of patients in 40 states
- Telemedicine is a big part of what he does
- Prior to the pandemic, Josh already did telehealth in the state of Georgia
- There’s plenty of rural pockets or people that just don’t want [to see a provider in person]; Atlanta traffic sucks
- Prior to the pandemic, a lot of states for psychologists came together and developed a jurisdiction approval called [PSYPACT](https://psypact.gov/), which was very innovative
- Then in the pandemic, it has just exploded where therapists can become a PSYPACT eligible provider
  - They get approved by going through a few check boxes, probably paid a few fees, and filling out your credentials and history (provinged you have no bad stuff)
- Being a PSYPACT provider means Josh can see people in the 40 states that have agreed interstate jurisprudence
  - That has expanded our ability to do telehealth

***PSYPACT has allowed providers who have doctorate level degrees to be approved to see people in those many states***

Peter asks, “*What are the 10 [states] that don’t?*”

- 2 of them want to hold on to their money and regulations: California and New York
  - Those 2 are probably never going to agree because of all the reasons that are just so wrong, unfortunately
  - Unless you’re licensed in that state, you cannot do telemedicine with people in that state sadly
  - There’s no good reason for that
- The other 8, Josh doesn’t care about
  - Josh couldn’t tell you what they are, but it’s probably just because they haven’t addressed it or approved it yet
- Currently, there’s an equivalent thing called [COMPACT](https://counselingcompact.gov/) for the master’s level providers out there that are trying to do the same level of interstate access
- Peter asks because he knows that people listening to this are going to want to have an opportunity to reach out and work with you

---

## Selected Links / Related Material

**Josh’s practice**: [Anxiety Specialists of Atlanta](https://www.anxietyspecialistsofatlanta.com/) (2025) | [1:00]

**Josh’s blog on Pure O OCD**: [“Pure O” OCD: Why are there quotation marks around it?](https://www.anxietyspecialistsofatlanta.com/pure-o-ocd-blog/) | Anxiety Specialists of Atlanta (J Spitalnick 2020) | [19:45]

**National romantic partner support group run by Josh**: [Spouse/Romantic Partner OCD Support Group](https://iocdf.org/support-groups/spouse-romantic-partner-ocd-support-group/) | International OCD Foundation (2025) | [55:15]

**Exposure therapy**: [Exposure Therapy](https://www.anxietyspecialistsofatlanta.com/services/exposure-therapy/) | Anxiety Specialists of Atlanta (2025) | [58:30]

**Seminal article about inhibitory learning**: [Emotional processing of fear: Exposure to corrective information](https://psycnet.apa.org/record/1986-15090-001) | *Psychological Bulletin* (E Foa, M Kozak 1986) | [1:18:30, 1:40:30]

**Acceptance and commitment therapy (ACT)**: [Acceptance and Commitment Therapy (ACT) | Anxiety Specialists of Atlanta](https://www.anxietyspecialistsofatlanta.com/services/acceptance-and-commitment-therapy-act/) | [1:31:00]

**Cognitive defusion**: [Cognitive Defusion Techniques and Exercises](https://cogbtherapy.com/cbt-blog/cognitive-defusion-techniques-and-exercises) | Cognitive Behavioral Therapy Los Angeles (2022) | [1:33:30]

**Josh’s book**: [The Complete Guide to Overcoming Health Anxiety: How to Live Life to the Fullest…Because You’re Not Dead (Yet)](https://www.amazon.com/Complete-Guide-Overcoming-Health-Anxiety/dp/B0CQK52RKC/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.PpBssnzYkAbVI85-2zjLkQ.PiftBx6O09Bs6F6XwQIGd8W9pqOHEl_FSVEY6cmTyMo) by Josh Spitalnick and Michael Stier, forward by Patrick McGrath (2023) | [1:53:45]

**Companion website to Josh’s book**: [Overcoming Health Anxiety](https://www.overcominghealthanxiety.com/) (2025)

**Health anxiety online platform**: [1:53:45]

- [Overcoming Health Anxiety (OHA) Community Support Group-Wednesdays 8pm](https://www.anxietyspecialistsofatlanta.com/events/health-anxiety-support-group-ohacommunity-wednesday/) | Anxiety Specialists of Atlanta (2025)
- [Overcoming Health Anxiety (OHA) Community Support Group (1st Thursday, 4pm EST)](https://www.anxietyspecialistsofatlanta.com/events/health-anxiety-support-group-ohacommunity-thursday/) | Anxiety Specialists of Atlanta (2025)

**Health anxiety increased after COVID**: [1:05:45]

- [Emotional and Behavioral Consequences of the COVID-19 Pandemic: The Role of Health Anxiety, Intolerance of Uncertainty, and Distress (In)Tolerance](https://pmc.ncbi.nlm.nih.gov/articles/PMC7578938/) | *International Journal of Environmental Research and Public Health* (K Sauer, S Jungmann, M Witthoft 2020)
- [Mental health, stress, and well-being measured before (2019) and during (2020) COVID-19: a Swedish socioeconomic population-based study](https://pubmed.ncbi.nlm.nih.gov/37728316/) | *Psychology and Health* (A Lindqvist Bagge et al. 2024)

**PSYPACT**: [PSYPACT: ADVANCING THE INTERJURISDICTIONAL PRACTICE OF PSYCHOLOGY®](https://psypact.gov/) (2025) | [2:11:30]

**COMPACT**: [Counseling Compact](https://counselingcompact.gov/) (2025) | [2:12:45]

**Josh’s tips for parents of children with anxiety**: [Raising Resilience: 25 Tips for Parenting Your Child with Anxiety or OCD](https://iocdf.org/expert-opinions/raising-resilience/) | International OCD Foundation (2022)

---

## People Mentioned

- [Edna Foa](https://psychology.sas.upenn.edu/people/edna-foa) (Professor of Clinical Psychology and Director of the Center for the Treatment and Study of Anxiety at the University of Pennsylvania) [1:18:30]
- [Martin (Marty) Franklin](https://rogersbh.org/staff/martin-e-franklin/) (Executive Clinical Director of OCD and Anxiety Services at Rogers Behavioral Health and Emeritus Associate Professor CE of Psychiatry at the [University of Pennsylvania](https://www.med.upenn.edu/apps/faculty/index.php/g332/p8356)) [1:18:45]
- [Steven Hayes](https://stevenchayes.com/about/) (Emeritus Professor of Psychology at the University of Nevada, Rheno and President of the Institute for Better Health; originator of Acceptance and Commitment Therapy, Relational Frame Theory, and co-developer of Process-Based Therapy) [1:32:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/08/Josh-Spitalnick-headshot_0.png)

##### Josh Spitalnick, Ph.D., A.B.P.P.

Josh Spitalnick earned his Bachelor’s, Master’s, and Ph.D. from the University of Georgia, Athens. Dr. Spitalnick is a Licensed Psychologist, Board Certified in Behavioral and Cognitive Psychology (ABPP) and CEO/Practice Owner of [Anxiety Specialists of Atlanta](https://www.anxietyspecialistsofatlanta.com/), an outpatient clinic in Dunwoody, GA. He also serves on the training faculty of the [International OCD Foundation’s Behavior Therapy Training Institute (BTTI)](https://iocdf.org/providers/spitalnick-josh/). In his clinical practice, Dr. Spitalnick specializes in the delivery of evidence-based interventions, including Cognitive-Behavioral Therapy (CBT) and Acceptance and Commitment Therapy (ACT) to treat many different anxiety disorders. His clinical practice includes [The Center for Emotional Health (CEH](https://thecenterforemotionalhealth.com/staff/dr-josh-spitalnick/)), which provides telehealth services nationwide. He also serves as an Adjunct Assistant Professor of Psychiatry and Behavioral Sciences at [Emory University](https://med.emory.edu/directory/profile/?u=JSPITAL) and has participated in multiple federal funded studies on anxiety.

Dr. Spitalnick is the co-author of two recent publications, including [*The Complete Guide to Overcoming Health Anxiety*](https://www.amazon.com/Complete-Guide-Overcoming-Health-Anxiety/dp/B0CQK52RKC/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.PpBssnzYkAbVI85-2zjLkQ.PiftBx6O09Bs6F6XwQIGd8W9pqOHEl_FSVEY6cmTyMo). This book has a corresponding [website](https://www.overcominghealthanxiety.com/) all about health anxiety. He is also the co-author of [*Raising Resilience: 25 Tips for Parenting Your Child with Anxiety or OCD*](https://iocdf.org/expert-opinions/raising-resilience/), a parenting guide that has received international recognition and has been published and disseminated by the International OCD Foundation. [[Anxiety Specialists of Atlanta](https://www.anxietyspecialistsofatlanta.com/clinical-staff/dr-josh-spitalnick/)]

Facebook: [Dr. Josh Spitalnick](https://www.facebook.com/drjoshspitalnick/)

Instagram: [anxietyatldoc](https://www.instagram.com/anxietyatldoc/?hl=en)

LinkedIn: [Josh Spitalnick, Ph.D., ABPP](https://www.linkedin.com/in/joshspitalnick/)

X: [@drspitalnick](https://x.com/drspitalnick)