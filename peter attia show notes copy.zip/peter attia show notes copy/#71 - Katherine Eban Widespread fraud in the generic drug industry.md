# #71 – Katherine Eban: Widespread fraud in the generic drug industry

**Source:** [https://peterattiamd.com/katherineeban/](https://peterattiamd.com/katherineeban/)

---

In this episode, Katherine Eban, investigative journalist and author of [Bottle of Lies](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781), illuminates the prevalence of fraud in generic drug manufacturing which brings into question the idea that generics are identical to brand-name drug as we are lead to believe. Katherine walks us through how this widespread corruption came to be, including the shocking story of one particularly egregious (and unfortunately not uncommon) example of an Indian drug company, Ranbaxy, whose business model was completely dependent on falsifying data in their drug applications to the FDA. We then discuss the subsequent investigation into Indian and Chinese drug manufacturing plants which revealed that nearly 80% of them are tainted with fraud. We conclude this discussion on a positive note with i) how individuals can investigate their own drugs to protect themselves ii) an innovative pharmacy attempting to disrupt the market and iii) some ideas on how to reform to the regulations around generic drugs, the FDA, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/katherineeban/the_Drive_public.png)

Play

#71 - Katherine Eban: Widespread fraud in the generic drug industry

#71 - Katherine Eban: Widespread fraud in the generic drug industry

1x15s30s

0:002:41:33

## We discuss:

- How Peter found Katherine’s book, and what convinced her to investigate the generic drug industry [5:45];
- Branded vs. generic drugs: Why they aren’t the same thing [11:15];
- The Food and Drug Administration: Why it was originally created and what it does today [20:45];
- How the generic drug industry really got its start in the U.S., and the flaw of the Hatch-Waxman Act [28:20];
- PEPFAR: How a well-intentioned plan to help Africa with the AIDS epidemic laid the groundwork for corruption [36:30];
- The story of Ranbaxy: An Indian drug company whose business model was fraud and deceit [40:45];
- How the FDA approves drugs, the impact of “first to file”, and Peter’s tangent on moral corruption [47:30];
- A booming generic drug market and the FDA struggling to keep up [57:15];
- Dinesh’s internal investigation finds widespread fraud and falsified data inside Ranbaxy [1:00:15];
- Presenting the famous SAR document to Ranbaxy’s board of directors which spells out the company-wide fraud [1:09:15];
- Dinesh blows the whistle on Ranbaxy which leads to a raid on their US plant [1:19:45];
- Formal investigation of Ranbaxy is launched, but the FDA keeps approving Ranbaxy drug applications [1:33:30];
- What role does the culture in India play in the high prevalence of fraud in the drug industry? [1:41:00];
- The extreme prevalence of data fraud/manipulation in foreign generic drug factories [1:52:30];
- Concluding the Ranbaxy story [2:06:15];
- How concerned should you be when buying a generic drug from your local pharmacy? [2:11:15];
- How to investigate your own drugs for quality to ensure you are getting what you need [2:18:30];
- An innovative pharmacy that tests all its drugs for quality [2:24:45];
- Reforming the FDA and generic drug industry: Why we need reform and ideas on how to do it [2:27:45];
- The importance of taking individual ownership and not waiting for Congress to bail us out [2:34:00];
- Closing thoughts from Katherine [2:36:50]; and
- More.

§

## Show Notes

## How Peter found Katherine’s book, and what convinced her to investigate the generic drug industry [5:45]

*How did Peter come upon Katherine’s work?*

- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) recommended Katherine’s book, Bottle of Lies, to Peter
- Sam found the content infuriating which got Peter intrigued (since he views Sam as someone who never gets mad)

Katherine’s book: [Bottle of Lies: The Inside Story of the Generic Drug Boom](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781)

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-1-bottle-of-lies-cover-670x1024.png)

**Figure 1. Cover of Bottle of Lies by Katherine Eban.** Image credit: [katherineeban.com](https://www.katherineeban.com/)

*What got her into the topic of generic drug manufacturing?*

- “*Before I started with this project, I thought about generics the way I think most people do, which is we need them, they’re affordable, nobody can afford their brand name drugs and they’re sort of an engine that makes government health programs run.*”
- In 2008, however, Katherine got a call from [Joe Graydon](https://en.wikipedia.org/wiki/Joe_Graydon) (runs an NPR podcast called [The People’s Pharmacy](https://www.npr.org/podcasts/381444414/the-people-s-pharmacy-radio-program))
- He informed her that he had been getting sent a ton of messages from listeners who were complaining about side effects from their generic drugs and/or that they weren’t working the same way that their brand name drugs had been
- Joe took the complaints to the FDA who shrugged it off as all in the patients heads since the drugs had a different name and color, “but the drugs are fine.”

*What made Katherine think there was something to this situation that made her want to dig into it?*

- As an experienced investigative journalist, Katherine said you develop a sense, a “tingle”, when something seems like a legitimate issue

## Branded vs. generic drugs: Why they aren’t the same thing [11:15]

**Analogy**: Kleenex (brand) vs. facial tissue paper (generic)

\***Misconception about generic drugs**: Most people *believe* (because the FDA told them so) that generic drugs are identical to the brand name (just at a lower price point)

*How to generics come to be?*

-A generic is a version of a brand name drug that is made either after a brand name drug has

1. gone off patent so it’s no longer legally protected, or
2. if the generic company has successfully challenged the brand patent in court and then the FDA gives them permission to make a generic

*But is it identical?*

- No
- In fact, if you make two batches of drugs in the same manufacturing plant using the same ingredients, those two batches will be a little bit different

**Steps to making a generic (and why it can be different from the brand name)**:

- A drug company has reverse engineered the brand drug
- So they have broken it down in a lab
- tried to figure out how to put it together
- maybe with a different set of manufacturing steps
- They have then concocted the drug
- However, they might have used additional ingredients as long as the central molecule which has already been tested for safety and efficacy is present
- Then they have to present data to the FDA
- The FDA recognizes there’s going to be differences, so they’ve provided a range
- The range is measured in terms of the absorption of the drug into the blood
- The generic drug company has to present data to the FDA showing through their testing that they’ve hit within that range
- And if so, the drug is considered bioequivalent

*But wait…why do the generic companies have to reverse engineer the drugs? Don’t they get the blueprint once the patent expires?*

- Turns out, brand drug companies have multiple patents not only on the molecules but also on the manufacturing process
- They “surround” their product with patents
- This leads to the generic companies having to “reverse engineer” to the best of their ability

*Do the manufacturing steps matter?*

- Turns out they matter a lot
- Just like cooking a nice steak, it’s more than just the ingredients involved, it’s the order in which you cook it, the temperature, etc. that will produce wild variations in the final product
- Generic companies can “get around” patented manufacturing processes by instead of doing steps A, B, C, D, E… they will do A, E, D, C, B (for example)
  - Indian drug companies are doing exactly this in many cases
  - And this can explain some of the big variations in efficacy and safety of generic vs. brand name

## The Food and Drug Administration: Why it was originally created and what it does today [20:45]

*Where did the* [*FDA*](https://en.wikipedia.org/wiki/Food_and_Drug_Administration) *come from? How were they created and why were they created?*

- Was born from public health disasters
  - E.g., after numerous children died from taking cough syrup in the 1930s
- Modern day FDA stemmed from a crucial moment in US history when [Frances Kelsey](https://en.wikipedia.org/wiki/Frances_Oldham_Kelsey) (a reviewer at the fledgling FDA) [refused to approve a drug called thalidomide](https://www.theglobeandmail.com/news/national/canadian-doctor-averted-disaster-by-keeping-thalidomide-out-of-the-us/article21721337/)
- This began the evolution of the FDA to start focusing on the manufacturing process
- Because while it’s not really practical to test every single pill in every batch, the FDA decided to put standards around the process of making the product
- “*…the key change in how public health enforcement evolved was that basically you have to be able to document and prove that your process is under control.*”

**What is under the purview of the modern day FDA?**

Through the lens of approving new drugs

- Someone files an application for a new drug with an indication (an IND application)
- The FDA then follows along through a phase one, phase two, and a phase three approval

Embedded within those processes are two things that are absolutely necessary:

1. Safety
2. Efficacy

Safety

- primarily in phase one
- but the safety monitoring continues into phase two and phase three and even beyond into postmarketing

With efficacy/effectiveness

- This actually wasn’t always part of the FDA’s scope of duty
- But now efficacy is tested in phase 2 and mostly in phase 3
- The modern FDA now has a very heavy role in asking, “*Does this thing do what it’s supposed to do and does it not hurt people?*“

## How the generic drug industry really got its start in the U.S., and the flaw of the Hatch-Waxman Act [28:20]

Up until about the 1980s…

- it was almost impossible for a generic company to compete with a branded pharma company based on the regulatory environment
- To create a new drug, it costs about $1 billion
- Very few companies have that deep of pockets
- Also, generic drugs had to go through the same billion dollar phase 1, 2 and 3 process
- And since generics didn’t have the same projected revenue as a patented, branded drug, very little companies found it worth the risk to bring a generic to market

*So what changed?*

- Investigative journalist named [William Haddad](https://qz.com/india/1666032/how-indian-pharma-giant-cipla-made-aids-drugs-affordable/) did an investigative series on “cartel-like” pricing practices in the antibiotic market of branded companies
- In the wake of that, he became very interested in generic drugs and the fact that there was no good pathway for generic drug makers to market their drugs
- Before Haddad, generics existed but they were created and largely consumed **outside of the US**
- Haddad’s work led to what was called the [Hatch-Waxman Act of 1984](https://en.wikipedia.org/wiki/Drug_Price_Competition_and_Patent_Term_Restoration_Act)

**Hatch-Waxman Act**

- This law created pathway at the FDA for generic drug makers to apply for approval without having to reprove the safety and efficacy
- All you had to prove was that your drug is [bioequivalent](https://en.wikipedia.org/wiki/Bioequivalence) to the branded product
- To do that you’d have to submit data that shows that your drug:
  - Falls into a range of absorption into the blood
  - That it remains stable at certain temperatures
  - That it dissolves properly in the body
- Then you could ask for approval
- But even after that there was still an uphill battle…
- The generic drug maker would almost certainly have to litigate against the brand name companies and they might not end up getting approved by the FDA

*A well-intentioned piece of the  Hatch-Waxman Act that produced perverse incentives…*

- So there was a really crucial little deal sweetener in Hatch-Waxman
- What it said was if you are **first to file** your application and you get approved, you will get 6 months of exclusivity on the market without any generic competitors
- This 6 month window with no generic competitor meant they could price their drug at about 80% of the brand name drug price and make huge profits
  - E.g., The first generic Lipitor that came on the market was worth about $600 million in that first 6 months
- As we will learn later in this episode, this lead to FDA agents being paid off to get hopeful generic companies to the front of the line

## PEPFAR: How a well-intentioned plan to help Africa with the AIDS epidemic laid the groundwork for corruption [36:30]

**President’s Emergency Plan for AIDS Relief (PEPFAR)**

- [PEPFAR](https://en.wikipedia.org/wiki/President%27s_Emergency_Plan_for_AIDS_Relief) was introduced George W. Bush presidency in 2003
- It was a well-intentioned idea where developed nations could help underdeveloped nations, specifically the AIDS crisis in Africa
- The idea is that we could use **taxpayer dollars** to buy low cost generics (AIDS drugs had dropped down to a dollar a day) from India and send it to Africa to address the AIDS crisis

But then the question inside the administration was… *how do you guarantee the quality?*

- [Scott Gottlieb](https://en.wikipedia.org/wiki/Scott_Gottlieb) at that point was in the Bush White House
- He was a skeptic of Indian generics and actually referred to them as counterfeits
- The idea was then created to send the FDA to do an expedited review and approve companies to sell PEPFAR drugs

However, this concept push forward the idea that if the FDA was approving these lost cost generics for PEPFAR, shouldn’t Americans get access to them, too?

- This idea coincided with the rising cost of health care and drugs in the US
- Indian companies were huge proponents of this idea given that the US was such a huge market

> “You had Indian companies who had long been regarded as just fakers and counterfeiters who were suddenly cleared by the US FDA. . .they wanted to get into our market because. . .we’re the biggest, most profitable market.”

## The story of Ranbaxy: An Indian drug company whose business model was fraud and deceit [40:45]

[Ranbaxy Laboratories](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories)

- Ranbaxy was India’s largest drug company in 2003 located in [Gurgaon](https://en.wikipedia.org/wiki/Gurgaon) in India (outside of New Delhi)
- They were one of the first to get approved for the [PEPFAR](https://en.wikipedia.org/wiki/President%27s_Emergency_Plan_for_AIDS_Relief) program
- Ranbaxy, a very ambitious company, were closing in on $1 billion in global sales

Recruiting Dinesh Thakur

- In 2003, Ranbaxy hired [Dinesh Thakur](https://twitter.com/d_s_thakur)
- Dinesh had been working at US drug company, [Bristol-Myers Squibb](https://en.wikipedia.org/wiki/Bristol-Myers_Squibb), which was a highly regimented corporate culture
- He moves his whole family to Gurgaon (to be fair, returning to India was a sort of patriotic pride from many Indians working in the US)

Dinesh walks into chaos

- When Dinesh arrives, he finds the company culture of Ranbaxy to be total chaos (the exact opposite of culture of US drug companies closely regulated by the FDA)
- His job was to help standardize and track all the information in this company
- they didn’t even have any standardized financial reporting in their presentations and in their bookkeeping
- Dinesh hired a team of people to “bring this company into the 21st century”

## How the FDA approves drugs, the impact of “first to file”, and Peter’s tangent on moral corruption [47:30]

The FDA has 2 tools to figure out whether a generic drug should be on the market

1. **The review of all data** showing the company can make a bioequivalent (which the company submit in what’s called an ANDA, an abbreviated new drug application)
2. **Pre-approval inspection**=After you submit your ANDA, the FDA will inspect the actual physical plant to make sure you’re not going to be manufacturing these drugs in your garage or in an out house
   1. They will also come back in 2 years to make sure you are following the plan

The impact of “first to file”

- A massive scandal hit the generic drug industry in the late 1980s once the Hatch-Waxman law was passed
- Within the Hatch-Waxman law there was a “first to file” stipulation that said the first company to apply will have 6 months to be the exclusive generic provider which results in big profits
- This lead to every generic drug company desperate to be first
- Literally had generic companies camping out in parking lots waiting to petition the FDA on the nanosecond the patent expired
- This led to literal fist fight fights in the parking lot and people pushing each other out of the way to be the first in the door
- It was “true mayhem”

Changes to “first to file” clause

- A company called [Mylan](https://en.wikipedia.org/wiki/Mylan) noticed they were no longer getting drug approvals and so they hired private investigators who found evidence that members of the FDA were being bribed by sketchy generic drug companies in exchange for being “first to file”
- Drug company executives were literally [walking the halls of FDA dropping envelopes of cash on people’s desks](https://www.washingtonpost.com/archive/politics/1990/03/31/drug-firm-admits-payoffs-to-fda-regulators/c97e0c83-3ff9-40ae-97a9-1bb41058e92e/) (many of these FDA agents were prosecuted)
- This scandal led to more stringent inspections by the FDA such as:
  - Pre-approval inspections, and
  - An application integrity policy which allowed the FDA to pull applications if they found a company was falsifying data
- These new enforcement mechanisms gave off the impression that everything was “fine” after that

Peter’s tangent on the topic of moral corruption:

- “Create a rule, the scum of the earth will always, even if they start out with well intentions, the scummiest of the scum will always figure out a way to cheat the system.”
- Peter highly **recommends the book,** [**Mistakes Were Made (But Not By Me)**](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/1491514132) by Carol Tavris
  - See [Peter’s interview with Carol Tavris (and Avrum Bluming)](https://peterattiamd.com/caroltavris-avrumbluming/)
- Peter admits that it’s very easy to put yourself on the moral high ground,
  - “*I could never have been that FDA officer that would have been corrupted by the bribe. I could never have been that executive that would have pushed the other guy out of the way to get in line or that would have dropped the cash in this situation*.”
- “But the way Carol writes about this, you realize that the first infractions are never these big ones. They’re very minor infractions, and they often come with a reasonable rationalization.”
- Katherine adds the following to further complicate the situation: “*But now put 7,000 miles between them. There is this whole question about integrity in a globalized world, and different actors in different cultures who are supposed to be following one set of rules and it becomes way more complicated.*”

## A booming generic drug market and the FDA struggling to keep up [57:15]

The booming overseas generic drug market

- It became a crucial player in PEPFAR, a sort of lifesaving player
- As brand name drug prices rose and rose, generic drug industry was ever more important until it came to be 90% of our drug supply.

FDA struggling to keep up

- Starting in around 2005, as generic drugs are growing in our market, the FDA is hit by this wave of globalization
- Suddenly it’s got way more plants to inspect overseas than it does within the US.
- We’ve got many more applications for drugs coming in from overseas than in from the US.
- The FDA is tasked suddenly with becoming a global agency almost overnight.

The current state of the FDA and the generic drug market

- Right now, 80% of the active ingredients in all our drugs, brand or generic, are coming from overseas
- 90% of our drug supply is generic (the majority of those drugs are being made overseas)
- 40% of our generics alone are coming from India
- We make almost none of our own antibiotics anymore
- If you go to a pharmacy and fill an antibiotic prescription for your kid, it’s coming from India or China

> “Suddenly, we’re in this whole new world where the FDA, which has in the past struggled to inspect plants that are driving distance from their headquarters, is now having to send inspectors 7,000 miles away.”

## Dinesh’s internal investigation finds widespread fraud and falsified data inside Ranbaxy [1:00:15]

When Dinesh first gets to Ranbaxy…

- Rashmi Barbhaiya, the man who recruited Dinesh to Ranbaxy, leaves the company bitterly shortly after Dinesh arrives (apparently with a settlement)
- Dinesh’s new boss is [Raj Kumar](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories#Controversies), a very ethical guy who came from GlaxoSmithKline in London
- Raj finds out that the WHO went and inspected a contract research organization (CRO) that was doing some testing for Ranbaxy and it turned out that the **tests were fake** (the “patients” didn’t even really exist)
- He then tasks Dinesh with investigating all of the global drug filings of Ranbaxy to see if there were other cases of faking and fraud going back 20 years

**Dinesh’s investigation of Ranbaxy**

- The questions were…
  - What was the data that was filed with different countries?
  - What was the raw data connected to that data?
  - Did the raw data exist
  - How were the studies done?
  - Where were the studies done at what manufacturing plant?
  - What were the processes and procedures that led to the creation of that data?
- Dinesh was a very ethical, single-minded person. He didn’t step back and say, “Well, wait a minute here folks, I’m investigating my own company.” So what are the possible ramifications of that? He didn’t really stop and think about that. He was just intent on getting the right answers.

*What did Dinesh find?*

- Ranbaxy had basically fabricated data for more than 200 drug products in 40 countries
- Some of the data, they just completely made up, some of it they manipulated or altered.
- In some cases they were using brand name drugs, which they would just crush up and test in order to generate data that showed bioequivalence

*What was Ranbaxy actually shipping out after approval of their fraudulent applications?*

- They were making generic drugs but they were either totally untested or did not meet specifications
- For example: Stability testing on drugs…
  - You put them in special chambers that replicate conditions of heat and cold
  - And you’re supposed to test three months, six months, nine months, 18 months
  - But they would test them all on the same day… and they would alter the data and then make it appear as though it was three months, six months, etc.

*Were any of the drugs that Ranbaxy made legit?*

- No

> “The business model was fraud and everyone in the company was in on it in that people were given orders to swap out ingredients, to replace higher quality ingredients with lower quality, to do all the stability testing on the same day, to use the brand name drugs. And that was just how the whole company rolled.”

## Presenting the famous SAR document to Ranbaxy’s board of directors which spells out the company-wide fraud [1:09:15]

**Self Assessment Report (SAR)**

- After Dinesh and Raj Kumar uncover the plethora of fraud within Ranbaxy, they put together a PowerPoint presentation that Raj then presented to the Ranbaxy’s board of directors
- The document contained a whole bunch of incriminating information, it basically says…
  - We have falsified data in every market where we sell drugs in every product that we sell
  - And we have done it simply for the purpose of facilitating our business needs
  - There is only one solution, which is to notify every regulator in every country where we sell our drugs, pull all our drugs off the market and fly right

![](https://peterattiamd.com/wp-content/uploads/2019/09/SAR-doc-slide-1024x735.png)

**Figure 2. Slide from the SAR document that Katherine posted on twitter**. Image credit: [@KatherineEban – Jul 9, 2019](https://twitter.com/KatherineEban/status/1148796419219906567)

Peter points out how silly this seems…

- Did it never dawn on Raj and Dinesh that they were presenting this information to a group of people who were already fully aware of (and actively covering up) the fraudulent info and data?
- Katherine says that they may have been a little naive but Raj Kumar tells Dinesh, “*I’m a little bit hopeful that I’m going to present this to a subcommittee, the board of the directors, and they’re going to let me fix it.*”
- Peter says that that **had** to understand that they might be in danger of losing their job (or worse) after making this presentation
- The boardroom was the scientific subcommittee of the board of directors
  - So you’ve got a guy like [Tejendra Khanna](https://en.wikipedia.org/wiki/Tejendra_Khanna), who’s Lieutenant Governor of Delhi
  - You’ve got a super high profile surgeon in India

*How did the board of directors take it?*

- You could hear a pin drop
- And then one of the board members asks, “*Well, can we not bury the data?*“
- Peter is shocked at this response… and offers some advice for these “incompetent criminals”
  - Shouldn’t the board’s response have been Raj, “This is exactly the kind of stuff we are looking for our lieutenants in the field to bring us. Thank you. We will take action immediately. By the way, can we borrow your laptop? We want to make sure we have more copies of this.” And then they let him leave, and then they destroy the laptop and then they unceremoniously

*Culture of impunity*

- It’s important to know the mentality comes in part from being in a culture of impunity
- They’re not afraid of their own regulators b/c they can easily buy them off
- India may be a democracy but the press presumably doesn’t have the same influence as the US

*What happens to Raj Kumar after the presentation?*

- [Brian Tempest](https://www.briantempest.com/), the acting president of Ranbaxy, tells him to leave his laptop behind which they break down piece by piece

- Raj tells Dinesh what happened in the meeting
- Two days later, Raj submits his resignation (sources tell Katherine it came with a sizeable settlement)
- Dinesh, who is basically the architect of this investigation, is now alone without protection in the company
- And he doesn’t fully understand how much trouble he’s really in just yet

## Dinesh blows the whistle on Ranbaxy which leads to a raid on their US plant [1:19:45]

Ranbaxy’s auditors begin looking for dirt on Dinesh

- They can’t find any, so that plant dirt on him by putting searches for porn on his work IP address (a fireable offense)
- Peter points out how ridiculous this is… search porn and get fired… “*Lie, falsify data, jeopardize the lives of millions of people. That’s standard operating procedure. We’ll promote you for that. But don’t you ever look at porn around here.*”
- This is an incredibly frightening, isolating experience for him

Dinesh eventually resigns in 2005

- But he can’t stop thinking about what he had uncovered
- And the thing that he really focuses on is the AIDS drugs that the company is already sending to Africa for PEPFAR which are not going to cure people, and might even harm people

Contacting regulators around the world

- Dinesh then decides to create a pseudonym and emails the FDA and other regulators around the world
- He pretends to be a bench scientist at the company, and writes, “I am being forced to falsify data against my will, very dangerous, etc.”
- Almost every regulator around the world blows him off
- But he keeps writing and pleading and eventually he gets a response from an FDA deputy
- The FDA wants to talk to him in person but Dinesh hasn’t revealed himself yet and is unsure whether it’s safe to meet with them
- But he starts to send them more and more incriminating data such as company emails implicating officials at Ranbaxy

**Raiding Ranbaxy on Feb 14, 2007**

- Dinesh eventually hands over the SAR presentation to the FDA
- This leads to a raid on Ranbaxy’s plant in the United States on February 14, 2007
- *Why the US?* ⇒ The FDA has no authority in India, plus it’s where they are launching all their drug applications into the US market

⇒ Quick rant on the lack of authority of the FDA: “*We are completely dependent on [non-US] countries manufacturing lifesaving drugs. We have no authority, no real legal authority, on the ground. We have no U.S. attorneys in India. We can’t serve a search warrant.*”

*What did the FDA find in their raid?*

- A lot.
- Here is one egregious example..
- Sotret, or [Isotretinoin](https://en.wikipedia.org/wiki/Isotretinoin), is the generic version of Accutane which is a drug that targets adolescent acne largely
- But it’s a dangerous drug ⇒ Leads to miscarriages and suicidal ideation
- Ranbaxy was the first to launch generic Accutane in the US market, but they knew that the drug was completely defective
- They had an internal document that basically said ‘*We know this drug is failing, we’re marketing it anyway’*, and the cover page on this document said in big letters, “**Do not share with FDA.**“

\*Now armed with the SAR document, and this info on Sotret, a formal investigation is officially launched in 2007

## Formal investigation of Ranbaxy is launched, but the FDA keeps approving Ranbaxy drug applications [1:33:30]

An investigation is launched in 2007

- What are the next steps after so much proof of fraud has already been uncovered?
- Well, the FDA has no subpoena authority so they have to make a case to the US attorney in Maryland (where Ranbaxy’s US plant was located)
- But the whole case grinds down to slow motion

- Ranbaxy is moving all it’s people back to India so they can’t be interviewed
- The FDA investigators are battling US attorneys about who to interview, what documents to pursue.
- They’re fighting with Ranbaxy’s lawyers.
- They are trying to sort of track the frauds and what they’re trying to figure out, what are we going to charge this company with?
- What do the frauds mean for the quality of the drugs?

*Why didn’t the FDA just suspend US sales of Ranbaxy drugs?*

- FDA investigators were trying to figure out sort of each permutation of the fraud
- Revelations were like…
  - They’re doing all of their stability testing for six, nine, 18 months, all on the same day
  - Everybody in the company appears to be in on this
- But as this is unfolding, the other side of the FDA, which is the sort of regulatory approval side of the FDA, **keeps on approving the company’s drugs**
  - In other words, the FDA has enough silo in it that the people that are dealing with this company from a drug approval standpoint are not the same people that are investigating them

*Eventually, the investigators are ready to take action*

- Ranbaxy enforcement team that’s 30 people large
- And then people start saying to each other, “*Why are we working so hard to keep this company in business? Why don’t we shut it down? Why don’t we just take all these applications offline, which would have the effect of shutting the company down. Why aren’t we doing that?*“

**Approving generic Lipitor**

- Meanwhile, in parallel with this investigation, Ranbaxy had the “first to file” for the biggest generic drug launch in history ⇒ [Atorvastatin](https://en.wikipedia.org/wiki/Atorvastatin) (generic Lipitor)
- The FDA bureaucrats decided to look at this application in isolation from the known fraud of Ranbaxy’s other drugs
- They couldn’t find direct evidence of fraud in that application so it was approved
- Why would they do this??
  - Congress was really pushing the FDA to approve generic Lipitor knowing that it would save Americans tons of money
  - But you can’t really blame congress since they were looking out for the US taxpayer… and congress was not fully up to speed on the level of fraud going on at Ranbaxy so in their mind *Atorvastatin was Lipitor (but a fraction of the price)*

\*Ranbaxy eventually had to [recall its generic Lipitor](https://www.bostonglobe.com/business/2012/11/24/ranbaxy-recalls-generic-lipitor-doses/iRsoUYfYzHStRzIe82LFCK/story.html) when glass particles were found the drugs\*

## What role does the culture in India play in the high prevalence of fraud in the drug industry? [1:41:00]

Cultural damnation?

- Peter points out that the story of Ranbaxy is a cultural damnation of India
- Katherine says ever since the book was released in India she has been under fire

Individuals in India are not the problem, says Peter

- Peter says that in his many interactions with India (such as during his time at McKinsey & Company) the people were exceptional
- Which tells you that the problem is not the people per se, but something within the hierarchy of companies that somehow slowly can corrupt a subset of people

How to reconcile these two things?

1. There’s an amazing system of education in India that produces amazingly bright people, who are incredibly hardworking
2. And yet there is a systemic problem, at least with respect to one industry (and what’s to say the same thing isn’t happening in petroleum, textiles, etc.)

**“Jugaad”**: Katherine highlights a cultural aspect that may explain it

- In May 2013, Katherine wrote an [article about the Ranbaxy story](https://fortune.com/2013/05/15/dirty-medicine/)
- A commenter on the article kept mentioning the concept of “Jugaad”
- Turns out jugaad can be a positive thing but can also carry a very dark connotation ⇒ it’s basically eliminating all obstacles and getting to the desired goal by any means necessary
- Jugaad, Katherine says, is “*something that is really prized in Indian companies. And it’s a kind of, the rules don’t matter, the regulations don’t matter. What matters is the goal.*”
- Ranbaxy, in particular, was a company that told its employees what mattered which was a $15 billion goal for 2015
- So basically it was a financial goal that mattered… *“and that sort of began to explain why this company behaved the way it did*”
- Unfortunately, Katherine says Ranbaxy isn’t an outlier

> “I began to report and expose that Ranbaxy really was not an outlier in the Indian generic industry. And that in a number of companies, I don’t know to the degree of Ranbaxy, but this is how you did business.”

**Contrasting fraud in India to cases of fraud in the US**

The US is no stranger to fraud

- [WorldCom accounting scandals](https://en.wikipedia.org/wiki/MCI_Inc.#Accounting_scandals)
- [Enron](https://en.wikipedia.org/wiki/Enron)
- [Theranos](https://en.wikipedia.org/wiki/Theranos)
- [Volkswagen emissions scandal](https://en.wikipedia.org/wiki/Volkswagen_emissions_scandal)

A culture of compliance in the US

- The US is so closely regulated that a US company must instill a culture of compliance into each of its employees
- There could still be bad actors within the company but it’s unlikely that a whole company could be in on the fraud
- In India, by contrast, they are not worried about their own regulators, they can easily pay them off
- And so you don’t have the same culture of compliance, meaning it’s not something that is organic to a company

⇒ *Side note*: [Novartis scandal](https://www.nytimes.com/2019/08/06/health/novartis-fda-gene-therapy.html): admitted to the FDA that there was data manipulation in some of the animal studies for a new gene therapy drug called Zolgensma

Systemic versus non-systemic

- Ranbaxy was a company that seemed to completely lawless, where employees across the board were directed to violate regulations
- This would be very, very hard to have as a situation in the U.S., where you have anybody could go run to the FDA since whistleblowers are legally protected here
- Fundamentally the difference between US and India/China is the systemic versus non systemic corruption

## The extreme prevalence of data fraud/manipulation in foreign generic drug factories [1:52:30]

- Katherine’s reporting on Ranbaxy lead her to the question of whether it was an outlier or just the tip of the iceberg
- Her investigation lead her deep into the FDA and to an inspector named [Peter Baker](https://www.linkedin.com/in/peter-baker-5624412b/)

**Peter Baker**

- 32 years old
- Agrees to take the job of inspecting Indian drug companies (not a highly coveted position)
- In the past, most of these inspections were BS
- The company would be informed of their plan to inspect, and they would greet them and give them gifts and show them a presentation and the inspector would go home
- Peter made it his mission to take a hard look at these companies

*A new method of inspection*

- He pioneers this new method of inspection where he goes to the manufacturing plants
- He starts by going to what’s called the “quality control laboratories”, the areas off of the manufacturing floor that audit the manufacturing because if you’re a corrupt drug company, you might be using the quality control laboratory to figure out how to manipulate the test results
- Peter gets onto their computers himself and he begins to track the metadata in these systems where they have **deleted evidence**
- Over 5 years, Peter inspected 86 drug plants in India and China
- He found **evidence of data fraud or manipulation of 80% of those plants**

*What is the implication of what Peter found?*

- “The implication of what Peter found is that fraud, and particularly data fraud, that is the manipulation of quality data, to make failing products sellable, is endemic.”
- There is really endemic fraud in *both Indian and Chinese* manufacturing plants

## Concluding the Ranbaxy story [2:06:15]

Acquisition

- While all the FDA investigations are going on, Ranbaxy is being looked at for [purchase by Daiichi Sankyo](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories#Acquisition_by_Daiichi-Sankyo), which was Japan’s second largest drug company
- Ranbaxy, of course, was hiding the investigation from Daiichi Sankyo during their due diligence
- They end up paying [Malvinder Singh](https://en.wikipedia.org/wiki/Malvinder_Mohan_Singh) (Ranbaxy CEO) and his brother $2 billion for their shares in Ranbaxy
- Several years in they realize they’re on the hook for $500 million, which is the fine that Ranbaxy ends up having to [pay to the justice department to settle the case against them](https://www.justice.gov/opa/pr/generic-drug-manufacturer-ranbaxy-pleads-guilty-and-agrees-pay-500-million-resolve-false)
- Daiichi Sankyo eventually [sold off to Sun Pharma](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories#Acquisition_by_Sun_Pharmaceutical)

As for Dinesh…

- He becomes a formal whistleblower under what’s called the [Qui tam lawsuits](https://www.phillipsandcohen.com/what-is-a-qui-tam-case/)
- So his identity was secret
- They reach a settlement and he ends up with $48 million, but his life really unraveled
- He and his wife break up. He’s had a very difficult road to hoe.

> “It’s quite extraordinary, because whistleblowers are routinely killed in India. So when he was thinking about blowing the whistle on Ranbaxy, that was a sort of central calculation was the danger to himself. And he ended up really rolling the dice on that. And he’s become an ongoing antagonist to the industry, because he’s now an activist and an advocate for safe drugs. He has just decided that that’s how he’s going to live, but he has survived this ordeal. But emotionally I think it’s been very scarring.”

## How concerned should you be when buying a generic drug from your local pharmacy? [2:11:15]

*If you go into your local pharmacy and buy a drug that comes from a company that is Indian or Chinese (assuming you can figure that out), you wouldn’t be overly paranoid to assume there’s an 80% chance that there’s some misinformation in what you’re taking?*

- It is hard to know for certain, and it’s hard to put a number on it
- But here’s some things that Katherine can say:
- We know that because of the kinds of frauds exposed in the book, Americans have gotten drugs that:
  - In some cases are not bioequivalent
  - Have foreign particulate matter in it or toxic impurities or are not as represented

⇒ For example,

- Millions of Americans were taking blood pressure medication, Valsartan, Losartan, Irbesartan [which were recalled](https://www.webmd.com/hypertension-high-blood-pressure/valsartan-losatran-bp-med-recalls-2018-19) because they it was found that the active ingredient contained carcinogens
- Those carcinogens were in the drugs for ~six years before they were recalled
- These generic drugs came from Chinese and Indian manufacturing plants

**Peter’s personal story**:

- Sometimes you prescribe drugs for which they have a predictable measured response (such as lipid lowering drugs)
- With lipid lowering drugs, it’s really clear what’s supposed to happen and when it’s working or not working
- Now there’s a gradation, so we might be missing things that are underworking.
- But on three occasions, Peter prescribed a patient [Crestor](https://www.webmd.com/drugs/2/drug-76704/crestor-oral/details) and that patient was substituted with [Rosuvastatin](https://en.wikipedia.org/wiki/Rosuvastatin) (generic equivalent of Crestor)
- In these three particular examples, **there was zero change in the LDL cholesterol**
- Now when a patient is on 10 milligrams of Crestor for three months and there is zero change in the LDL cholesterol, there are only two explanations that I can think of
  - 1) The patient’s not taking the drug
  - 2) Or the drug doesn’t work
- Peter decided to switch them to [atorvastatin](https://en.wikipedia.org/wiki/Atorvastatin) and it lowered their lipids

*Another example*: generic extended release Metformin

- Tons of patients complain that generic extended release Metformin, which is a drug I prescribed with some regularity, doesn’t work as well as the true Glucophage XR does

> “But I’ve seen this issue, there’s no question I’ve seen it and I suspect I’m not seeing it to its full extent because I’m only seeing it for drugs in which the measured response is so clear and so objective. You think of, as you said, all the drugs that we would miss this on.” —Peter Attia

**Katherine offers examples from the book:**

- Two doctors at the Cleveland Clinic who began to piece together that some of their patients and these are cardiac drugs were stabilized on the brand and then became unstable when they were switched to the generic
- And in some cases heart transplant patients were suffering organ rejection from a generic (Tacrolimus)

⇒ Check out her article about this in the Boston Globe: [These pills could kill you](https://www.bostonglobe.com/ideas/2019/05/24/ideas-katherine-eban-these-pills-could-kill-you/d4gYXkoMR24n1uoLUkbnqJ/story.html)

> “For doctors, once they become aware of this as a category of thought as a possibility, some of them begin to diagnose the drug supply, not just their patients.”

## How to investigate your own drugs for quality to ensure you are getting what you need [2:18:30]

On her [website](https://www.katherineeban.com/), Katherine created a [guide to investigating your own drugs](https://static1.squarespace.com/static/5c815b4aa568279ce62b0865/t/5cf52e3744f8e100014dfa29/1559572023959/BOTTLE+OF+LIES_GUIDE.pdf) which basically leads people step by step including to figure out who manufactured your drug

⇒ [A Guide To Investigating Your Own Drugs](https://static1.squarespace.com/static/5c815b4aa568279ce62b0865/t/5cf52e3744f8e100014dfa29/1559572023959/BOTTLE+OF+LIES_GUIDE.pdf)

*Is the drug manufacturer readily available on the front of the bottle?*

- It should be but it varies from state to state. . .**but if you’re not getting that information on dispensing label, you need to ask your pharmacist who is the manufacturer**
  - You can always switch from one generic to another

*Is the pharmacy willing to do this without your physician’s intervention?*

- Yes, when you go to an independent pharmacy
- I think for the big chain pharmacies it’s harder (e.g., CVS)

**The optimal thing to do**:

- Go to a brick and mortar pharmacy and have an exchange with a human being. That is ideal.
- Pharmacists, some don’t really know about this issue, but some know a lot.

⇒ GoodRX

- Peter recommends [GoodRX](https://www.goodrx.com/) as a place you can search and compare drugs at local pharmacies
- You can easily find the best price and then you could couple the price with the manufacturer information
- Katherine points out that the lower the price generally correlates with the worst manufacturers in India

*Do drugstore typically carry more than one generic?*

- If they don’t carry more than one, they often can order one generic or another one from their wholesalers

## An innovative pharmacy that tests all its drugs for quality [2:24:45]

**Valisure Pharmacy**

- *Katherine presents an idea*: Imagine if there was a pharmacy chain that would test every drug that they dispense to ensure quality (Not every pill, but do a random sampling)
- There’s this small, mail order pharmacy called [Valisure](https://www.valisure.com/?src=google_webppc_1630546518_valisure_%7Bcontent%7D_e_g_%7Bquerystring%7D&jpow=aa_1630546518_bb_65821690241_cc_valisure_dd_e_ee_g_ff_1t1_gg_c_hh__ii__jj_9027599_kk__ll__mm__nn_kwd-566231173346_oo_367329025339_pp_1556962644272178872_qq__rr_%7Badid%7D_ss_%7Borderitemid%7D&gclid=CjwKCAjwnrjrBRAMEiwAXsCc46iNyubVfBA7tAFWnWWwYq3YrvzdCtSdMonqmM3H2Sj32KNWdUqy-hoCINwQAvD_BwE) that does just this, it’s their business model

⇒ Valisure actually identified a carcinogen in a medication that the FDA missed

*How does Valisure afford to do this?*

- They are currently a startup with funding so this is all baked into the business model

## Reforming the FDA and generic drug industry: Why we need reform and ideas on how to do it [2:27:45]

*A story highlighting the need for reform of the FDA*:

- The FDA does these pre-announced inspections overseas
- Their inspector went to one of these plants in China and the investigator found that the company was not investigating impurity spikes in its own drugs as required
- So the inspector recommended that this plant be officially sanctioned and forced to take action
- But back in Maryland, FDA officials downgraded it to ‘voluntary action’
- One year later this plant is in the middle of this worldwide recall of drugs because there were impurities in the drugs
- So the FDA actually found this, did nothing about it.

⇒ Check out this article for more on this story: [How a Tainted Heart Drug Made in China Slipped Past the FDA](https://www.bloomberg.com/news/features/2019-01-30/chinese-heart-drug-valsartan-recall-shows-fda-inspection-limits)

*If Katherine could go back in time and amend the Hatch-Waxman Act, what changes would she make?*

- The key thing would be to reform the “first to file” deal sweetener
- And it has been reformed since then because now it’s not which **minute** you file, but which **day** you file
  - This takes a little bit of heat out of the market, gets rid of that “Lord of the Flies” environment in the parking lot that we talked about

**Reforming the FDA**

> “I think the biggest reform wouldn’t be to the Hatch Waxman Act, it would be to the FDA.”

- First of all, overhauling their foreign inspection program
  - No more “pre-announced” inspection
- How do you get more Peter Bakers at the FDA?
  - Well, Peter Baker proposed that very thing…
  - He wanted to run a training program and train all of the inspectors to do these kinds of inspections, and the FDA said no thanks so Peter left the FDA
- “The book really exposes to some extent that **the FDA does not really want to know what’s going on in these plants**.”

**Peter has a disruptive idea regarding regulation**:

- Extended the patent protection for the primary drug maker
- But in exchange for that you are now transferring **all of them know-how to the generics**
- You could make it such that the NPV is the same to them (i.e., You will make the same amount of money on this drug)
- But basically the generics now have nothing to do except assume full manufacturing and production capacity.

*⇒ Authorized generics*

- Katherine says there is something called [authorized generics](https://en.wikipedia.org/wiki/Authorized_generics)
- Branded companies partner with a generic company and they will retain a piece of the profit basically through some sort of licensing agreement
- Peter offers a way to make authorized generics even better…
  - The parent company remains on the hook to determine the authenticity of the product
    - I.e., If your authenticated, generic producer goes rogue, you’re paying for it.
  - So don’t have the FDA exclusively be the one that has to police them, have them all policed from the parent.

## The importance of taking individual ownership and not waiting for Congress to bail us out [2:34:00]

The current state of drug regulations and prices is not good:

- We can’t come to any agreement over drug pricing.
- Brand name drug prices continue to rise.
- Our drug supply is really in a free fall.
- We’ve got drug shortages, there’s no incentive for quality here.
- A lot of these companies are really getting away with it.
- FDA investigators are walking into these plants finding egregious conditions and the FDA is downgrading their findings.
- So it’s hard to say what can practically be made to happen.

Congress, for whatever it’s worth, is looking into it, says Katherine

- What’s sad is that the people that will suffer these consequences the most are those will less education, less financial means to pay for branded drugs, etc.
- Congress exists first and foremost to make sure that it’s that floor that doesn’t fall any lower so we can’t wait for Congress to solve this

**Importance of taking individual ownership**

- “It’s important for patients to realize…if they go to a pharmacy, they get dispensed drugs. They don’t think about who makes it, they don’t even think about it. They may be switched from a brand to generic, not realize it. They may be switched between generics. They don’t realize it.”
- Peter said it wasn’t until recently that he started paying attention to this… so how can we expect anyone else to?
- “Most people don’t pay attention to it because the FDA has told us that it’s all equivalent. There’s nothing to pay attention to. They’ve got it. There’s no difference between brand and generic, generic and generic. It’s all the same.”
- “So the **first step is for everybody to pay attention to who’s making the drug** and how it works.”

## Closing thoughts from Katherine [2:36:50]

> “Generics are supposed to be this great leveler. It’s like the democratization of drugs that the rich and the poor alike can have access to for these great cures. To find out…that the companies cashing in on that image are really selling that short in a very devious way, is painful to realize. It’s a real great public health hope that has a very dark underbelly.”

Where to follow Katherine’s work?

- Book: [Bottle of Lies: The Inside Story of the Generic Drug Boom](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781)
- Twitter: [@KatherineEban](https://twitter.com/KatherineEban?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
- Linked In: [Katherine Eban](https://www.linkedin.com/in/katherineeban/)

Website: [Katherineeban.com](https://www.katherineeban.com/)

§

## Selected Links / Related Material

**Katherine’s book, the content of which is the subject of this episode of The Drive**: [Bottle of Lies: The Inside Story of the Generic Drug Boom](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781) by Katherine Eban | (amazon.com) [4:15, 6:45, 20:15, 38:30, 43:30, 49:45, 56:00, 1:38:00, 1:41:45, 1:50:00, 1:55:45, 1:59:30, 2:05:00, 2:13:00, 2:17:45, 2:30:30]

**NPR podcast hosted by Joe Graydon (the person who piqued Katherine’s interest in the generic drug industry)**: [The People’s Pharmacy Radio Program](https://www.npr.org/podcasts/381444414/the-people-s-pharmacy-radio-program) | (npr.org) [8:45]

**Crucial moment in the FDA history when Frances Kelsey (a reviewer at the FDA) refused to approve a drug called thalidomide helping to avoid the terrible side effects such as horrible birth defects**: [Canadian doctor averted disaster by keeping thalidomide out of the U.S.](https://www.theglobeandmail.com/news/national/canadian-doctor-averted-disaster-by-keeping-thalidomide-out-of-the-us/article21721337/) | INGRID PERITZ (theglobeandmail.com) [21:00]

**Law that launched the US generic drug industry that inadvertently encouraged fraud and bribes due to the “first to file” stipulation**: [Hatch-Waxman Act of 1984](https://en.wikipedia.org/wiki/Drug_Price_Competition_and_Patent_Term_Restoration_Act)  | (wikipedia.org) [32:00, 2:28:45]

**Indian drug company that was the example of not so uncommon fraudulant practices in foreign drug companies:** [Ranbaxy Laboratories](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories) | (wikipedia.org) [35:15, 40:45]

**George W. Bush’s good intention plan started in 2003 to help Africa with the AIDS epidemic:** [PEPFAR- President’s Emergency Plan for AIDS Relief](https://en.wikipedia.org/wiki/President%27s_Emergency_Plan_for_AIDS_Relief) | (wikipedia.org) [36:45]

**Where Dinesh Thakur worked in the US before moving to Ranbaxy:** [Bristol-Myers Squibb](https://en.wikipedia.org/wiki/Bristol-Myers_Squibb) | (wikipedia.org) [42:00]

**Massive FDA scandal where agents were being paid bribes to push wishful generic drug companies to the front of the line**: [Generic drug scandal – Food and Drug Administration](https://en.wikipedia.org/wiki/Food_and_Drug_Administration#Generic_drug_scandal) | (wikipedia.org) [49:15]

**Washington Post 1990 article about the FDA taking bribes from drug companies**: [DRUG FIRM ADMITS PAYOFFS TO FDA REGULATORS](https://www.washingtonpost.com/archive/politics/1990/03/31/drug-firm-admits-payoffs-to-fda-regulators/c97e0c83-3ff9-40ae-97a9-1bb41058e92e/) | Paul W. Valentine (washingtonpost.com) [49:15]

**Book that Peter highly recommended to Katherine which touches on how people justify their own moral corruption**: [Mistakes Were Made (But Not By Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/1491514132) by Carol Tavris | (amazon.com) [53:15]

**Episode of The Drive where Peter interviews Carol Tavris and Avrum Bluming**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [53:30]

**Where Raj Kumar worked in London before coming over to Ranbaxy**: [GlaxoSmithKline](https://en.wikipedia.org/wiki/GlaxoSmithKline) | (wikipedia.org) [1:01:00]

**Slide from the SAR document that Katherine posted on twitter**: [@KatherineEban – Jul 9, 2019](https://twitter.com/KatherineEban/status/1148796419219906567) | (twitter.com) [1:09:30]

**The Atlantic Magazine article which Katherine appeared in which asked a number of journalists about the biggest scams of all time**: [The Big Question: What is the greatest scam of all time?](https://www.theatlantic.com/magazine/archive/2014/10/what-is-the-greatest-scam-of-all-time/379349/) **|** (theatlantic.com) [1:09:45]

**Ranbaxy gets approved to sell generic Lipitor while they are still under investigation by the FDA**: [Generic availability – Atorvastatin](https://en.wikipedia.org/wiki/Atorvastatin) | (wikipedia.org) [1:39:15]

- **And eventually is forced to recall it**: [Ranbaxy recalls generic version of Lipitor](https://www.bostonglobe.com/business/2012/11/24/ranbaxy-recalls-generic-lipitor-doses/iRsoUYfYzHStRzIe82LFCK/story.html) | Linda A. Johnson (bostonglobe.com)

**Where Peter worked in risk and had pleasant interactions with people from India**: [McKinsey & Company](https://en.wikipedia.org/wiki/McKinsey_%26_Company) | (wikipedia.org) [1:42:00]

**Katherine’s magazine article on Ranbaxy before in May of 2013**: [Dirty medicine](https://fortune.com/2013/05/15/dirty-medicine/) | Katherine Eban (fortune.com) [1:43:30]

**Major examples of big company fraud in the US**: [1:45:45]

- [WorldCom accounting scandals](https://en.wikipedia.org/wiki/MCI_Inc.#Accounting_scandals) | (wikipedia.org)
- [Enron](https://en.wikipedia.org/wiki/Enron) | (wikipedia.org)
- [Theranos](https://en.wikipedia.org/wiki/Theranos) | (wikipedia.org)
- [Volkswagen emissions scandal](https://en.wikipedia.org/wiki/Volkswagen_emissions_scandal) | (wikipedia.org)

**Novartis admits data manipulation in application for approval of new gene therapy drug**: [Novartis Hid Manipulated Data While Seeking Approval for $2.1 Million Treatment](https://www.nytimes.com/2019/08/06/health/novartis-fda-gene-therapy.html) | Katie Thomas (nytimes.com) [1:49:30]

**Japanese company that bought Ranbaxy**: [Daiichi Sankyo](https://en.wikipedia.org/wiki/Daiichi_Sankyo) | (wikipedia.org) [2:06:45]

**The acquisition of Ranbaxy that pays Malvinder Singh and his brother $2 billion for their shares in Ranbaxy**: [Acquisition by Daiichi-Sankyo – Ranbaxy Laboratories](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories#Acquisition_by_Daiichi-Sankyo) | (wikipedia.org)  [2:06:45]

**A court awards Daiichi Sankyo $500 million to be paid by Malvinder Singh to resolve the false claims allegations**: [Generic Drug Manufacturer Ranbaxy Pleads Guilty and Agrees to Pay $500 Million to Resolve False Claims Allegations, cGMP Violations and False Statements to the FDA](https://www.justice.gov/opa/pr/generic-drug-manufacturer-ranbaxy-pleads-guilty-and-agrees-pay-500-million-resolve-false) | (justice.gov) [2:08:45]

**Daiichi Sankyo then offloaded the company to Sun Pharma**: [Acquisition by Sun Pharmaceutical – Ranbaxy Laboratories](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories#Acquisition_by_Sun_Pharmaceutical) | (wikipedia.org) [2:09:45]

**Blood pressure medications made in China and India that were recalled after it was found that the active ingredient contained carcinogens**: [Valsartan, Losartan & Other BP Med Recalls 2018-19](https://www.webmd.com/hypertension-high-blood-pressure/valsartan-losatran-bp-med-recalls-2018-19) | (webmd.com) [2:13:40, 2:26:45]

**Katherine’s article about two doctors at the Cleveland clinic who noticed patients on cardiac drugs were stabilized on the brand and then became unstable when they were switched to the generic and in some cases heart transplant patients were suffering organ rejection from a generic**: [These pills could kill you](https://www.bostonglobe.com/ideas/2019/05/24/ideas-katherine-eban-these-pills-could-kill-you/d4gYXkoMR24n1uoLUkbnqJ/story.html) | Katherine Eban (bostonglobe.com) [2:18:00]

**Katherine’s step by step guide for investigating your prescription drugs to figure out quality**: [A Guide To Investigating Your Own Drugs](https://static1.squarespace.com/static/5c815b4aa568279ce62b0865/t/5cf52e3744f8e100014dfa29/1559572023959/BOTTLE+OF+LIES_GUIDE.pdf) | (katherineeban.com) [2:20:00]

**Website/mobile app that allows you to price check drugs in your area**: [GoodRX](https://www.goodrx.com/) | (goodrx.com) [2:23:00]

**Innovative mail-order pharmacy that tests every drug for quality**: [Valisure](https://www.valisure.com/?src=google_webppc_1630546518_valisure_%7Bcontent%7D_e_g_%7Bquerystring%7D&jpow=aa_1630546518_bb_65821690241_cc_valisure_dd_e_ee_g_ff_1t1_gg_c_hh__ii__jj_9027599_kk__ll__mm__nn_kwd-566231173346_oo_367329025339_pp_1556962644272178872_qq__rr_%7Badid%7D_ss_%7Borderitemid%7D&gclid=CjwKCAjwnrjrBRAMEiwAXsCc46iNyubVfBA7tAFWnWWwYq3YrvzdCtSdMonqmM3H2Sj32KNWdUqy-hoCINwQAvD_BwE) | (valisure.com) [2:26:15]

**A story highlighting the need for reform of the FDA**: [How a Tainted Heart Drug Made in China Slipped Past the FDA](https://www.bloomberg.com/news/features/2019-01-30/chinese-heart-drug-valsartan-recall-shows-fda-inspection-limits) | Anna Edney (bloomberg.com) [2:27:45]

§

## People Mentioned

- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (recommended Katherine’s book to Peter) [6:30, 2:38:15]
- [Joe Graydon](https://en.wikipedia.org/wiki/Joe_Graydon) (NPR program called The People’s Pharmacy, got Katherine to look deeper into the generic drug industry) [8:45]
- [Frances Kelsey](https://en.wikipedia.org/wiki/Frances_Oldham_Kelsey) (reviewer at the fledgling FDA who refused to approve a drug called thalidomide in the 1980s) [21:00]
- [FDR](https://en.wikipedia.org/wiki/Franklin_D._Roosevelt) [22:45]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) [27:15]
- [Scott Gottlieb](https://en.wikipedia.org/wiki/Scott_Gottlieb) (former FDA commissioner who was rightfully skeptical of generic drugs) [28:00, 38:15]
- [Orrin Hatch](https://en.wikipedia.org/wiki/Orrin_Hatch) (Hatch-Waxman law) [31:00]
- [William Haddad](https://qz.com/india/1666032/how-indian-pharma-giant-cipla-made-aids-drugs-affordable/) (“the generic industry owes a lot” to him per Katherine, he did an investigative series on cartel-like pricing practices in the antibiotic market of branded companies which lead him to an interest in the generic drug market) [31:15]
- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) (signed the Hatch-Waxman Act of 1984 into law) [32:15]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) (PEPFAR program) [36:45]
- [Dinesh Thakur](https://dineshthakur.com/about-2/) (Dinesh on [twitter](https://twitter.com/d_s_thakur), Ranbaxy whistleblower)  [41:45, 1:00:20]
- [Carol Tavris](https://en.wikipedia.org/wiki/Carol_Tavris) (wrote [Mistakes Were Made (But Not By Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/1491514132)) [53:15, 2:04:15]
- [Avrum Bluming](https://peterattiamd.com/caroltavris-avrumbluming/) (co-author of Estrogen Matters and previous guest on The Drive) [53:30]
- [Mark Fuhrman](https://en.wikipedia.org/wiki/Mark_Fuhrman) (famous officer who got caught planting evidence) [55:00]
- [Raj Kumar](https://en.wikipedia.org/wiki/Ranbaxy_Laboratories#Controversies) (former Ranbaxy employee who helped Dinesh uncover the fraud) [1:00:45]
- [Tejendra Khanna](https://en.wikipedia.org/wiki/Tejendra_Khanna) (was on Ranbaxy’s board, Lieutenant Governor of Delhi) [1:16:00]
- [Brian Tempest](https://www.briantempest.com/) (temporary president of Ranbaxy when Dinesh was there) [1:18:15]
- [Malvinder Singh](https://en.wikipedia.org/wiki/Malvinder_Mohan_Singh) (CEO of Ranbaxy when Dinesh was blowing the whistle to the FDA) [1:25:15, 2:06:45]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) [1:25:30]
- [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) [1:25:30]
- [Lester Crawford](https://en.wikipedia.org/wiki/Lester_Crawford) (former FDA commissioner who finally responded to Dinesh’s emails) [1:26:45]
- [Andy Fastow](https://en.wikipedia.org/wiki/Andrew_Fastow) (Enron scandal) [1:51:30]
- [Ken Lay](https://en.wikipedia.org/wiki/Kenneth_Lay) (Enron scandal) [1:51:30]
- [Jeff Skilling](https://en.wikipedia.org/wiki/Jeffrey_Skilling) (Enron scandal) [1:51:30]
- [Peter Baker](https://www.linkedin.com/in/peter-baker-5624412b/) (FDA inspector who uncovered the widespread fraud in Indian and Chinese drug companies) [1:52:30, 2:30:00]
- [Matt Damon](https://en.wikipedia.org/wiki/Matt_Damon) (actor that Katherine thinks could play Peter Baker in a movie based on her book) [1:55:45]
- [Michael Lewis](https://en.wikipedia.org/wiki/Michael_Lewis) (author who has written several books related to fraud) [2:31:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/09/headshot-katherine-eban-500x500.png)

##### Katherine Eban

Katherine Eban, an investigative journalist, is a Fortune magazine contributor and Andrew Carnegie fellow. Her articles on pharmaceutical counterfeiting, gun trafficking, and coercive interrogations by the CIA, have won international attention and numerous awards. She has also written for Vanity Fair, the New York Times, Self, The Nation, the New York Observer and other publications. Her work has been featured on 60 Minutes, Nightline, NPR, and other national news programs. She lectures frequently on the topic of pharmaceutical integrity.

Her first book, Dangerous Doses: a True Story of Cops, Counterfeiters and the Contamination of America’s Drug Supply, was named one of the Best Books of 2005 by Kirkus Reviews and was a Barnes & Noble Discover Great New Writers pick. Her account of reporting on 9/11 was anthologized in At Ground Zero: 25 Stories From Young Reporters Who Were There. Her work has also been awarded grants from the Alfred P. Sloan Foundation, the Fund for Investigative Journalism, the Alicia Patterson Foundation and the McGraw Center for Business Journalism at CUNY’s Craig Newmark Graduate School of Journalism. Educated at Brown University and Oxford, where she was a Rhodes Scholar, she lives in Brooklyn with her husband, two daughters and Newfoundland dog Romeo. [katherineeban.com]