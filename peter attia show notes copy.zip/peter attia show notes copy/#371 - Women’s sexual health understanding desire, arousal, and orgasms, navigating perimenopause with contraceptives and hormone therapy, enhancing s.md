# #371 ‒ Women’s sexual health: understanding desire, arousal, and orgasms, navigating perimenopause with contraceptives and hormone therapy, enhancing sexual comfort and satisfaction, and more | Sally Greenwald, M.D., M.P.H.

**Source:** [https://peterattiamd.com/sallygreenwald/](https://peterattiamd.com/sallygreenwald/)

---

Sally Greenwald is an OB-GYN who specializes in women’s sexual health from a hormonal and physiologic perspective, with expertise spanning desire, arousal, pelvic floor function, contraception, and menopause care. In this episode, she explains why sexual health is a vital component of overall well-being, exploring topics such as the drivers of desire, the anatomy of sexual function, myths and realities around orgasm, and the role of hormones in perimenopause and menopause. She also covers vaginal and pelvic health, pain with sex, evidence-based therapies for low desire and arousal, how contraception and medications can affect sexual function, and practical strategies for enhancing sexual satisfaction and maintaining intimacy across life stages. This episode offers a comprehensive, evidence-based discussion with immediate real-world relevance for women as well as for men who want to better understand their partners.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/sallygreenwald/the_Drive_public.png)

Play

#371 – Women's sexual health: desire, arousal, and orgasms, navigating perimenopause, and enhancing satisfaction | Sally Greenwald, M.D., M.P.H.

#371 – Women's sexual health: desire, arousal, and orgasms, navigating perimenopause, and enhancing satisfaction | Sally Greenwald, M.D., M.P.H.

1x15s30s

0:001:52:21

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- How sexual health influences physical health, emotional well-being, and relationships [A: 3:15, V: 0:11];
- Understanding the physiology of the female orgasm, sexual comfort and satisfaction, and the disparity between men and women [A: 12:45, V: 10:21];
- Foreplay, the science of desire, and methods to help women cultivate arousal and connection [A: 19:00, V: 16:57];
- The physiology and sources of female lubrication, the role of clitoral nerve anatomy in pleasure, and the use of lubricants and vibrators to enhance comfort and sexual health [A: 23:45, V: 22:10];
- Understanding female anatomy and what is needed for orgasm [A: 31:15, V: 30:19];
- Understanding sexual desire, how to cultivate it, the role of hormones, and testosterone therapy in women [A: 41:15, V: 41:40];
- Personalizing perimenopause care: how desire for ovulation guides the choice between contraception and menopausal hormone therapy [A: 49:30, V: 50:48];
- Considerations for choosing contraceptives and hormonal therapies during perimenopause [A: 59:45, V: 1:02:13];
- Factors negatively affecting desire, and why female libido persists with age and fluctuates across the menstrual cycle [A: 1:11:00, V: 1:15:11];
- How sexual trauma and physical pain can affect sexual health, and evidence-based strategies for recovery [A: 1:15:15, V: 1:19:48];
- Vaginal care routine: lubricants, moisturizers, topical hormones, and other approaches for vaginal health [A: 1:19:15, V: 1:24:29];
- Tips for sexually satisfying your female partner [A: 1:25:45, V: 1:32:05];
- The pharmacology of arousal: various treatments for low sexual desire in women [A: 1:30:30, V: 1:37:15];
- Sex during and after pregnancy: impact on arousal, safety of sex, and how to manage postpartum recovery and pain [A: 1:37:45, V: 1:45:31];
- How Sally would redesign sex education [A: 1:42:15, V: 1:50:24];
- Sally’s optimism about a new era in women’s sexual health [A: 1:49:00, V: 1:58:22]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Sally Greenwald is an OB-GYN who specializes in women’s sexual health from a hormonal and physiologic perspective
  - With a clinical focus that spans desire, arousal, pelvic floor function, contraception, menopause and perimenopause care, and evidence-based strategies to improve sexual well-being

In this episode, we discuss:

- Why sexual health is a core part of overall health and life quality for both men and women
- A practical framework for desire, the accelerator and brake model, and how patterns change across life
- Anatomy for sexual function, the clitoral complex and vaginal anatomy, and why understanding it matters both for men and women
- Orgasm realities and myths, and varied pathways to orgasm beyond penetrative sex
- Vaginal tissue health, lubrication, moisturizers, and when local estrogen is helpful
- Pain with sex: the common causes, evaluation, and a multidisciplinary approach to treating it
- Perimenopause and menopause: symptom patterns and the roles of estradiol, progesterone, progestins, and testosterone
- Contraception across the reproductive years and how different methods interact with hormones and sexual function
- Medications and adjuncts for low desire or arousal, including the FDA-approved options and the realistic expectations around them
- The use of vibrators and other devices as therapeutic tools both solo and with partners
- When medications and substances help or hinder arousal and orgasm such as cannabis, THC, SSRIs
  - And practical strategies for use
- Pregnancy and postpartum sexual health considerations
- Safer sex practices and STI screening
- Plus communication and sexual health education around how to talk to your kids about sex
- This podcast will have an immediate and obvious application and interest to women

Peter adds, “*I can tell you guys, if you’re listening, this is something you will want to understand greatly. I learned an enormous amount during this interview with Sally, and if you want to understand your partners better, this is definitely the podcast for you.*”

## How sexual health influences physical health, emotional well-being, and relationships [A: 3:15, V: 0:11]

- This is a topic that on the surface might seem somewhat directed towards 50% of the population, but it’s safe to say it’s probably going to be directed towards a 100% of the population

**Sally is an OB-GYN, but her focus is not just on the standard OB-GYN things, but really around women’s sexual health**

*Is that a fair assessment?*

- From a hormonal and physiologic perspective, yes
- Peter was introduced to Sally through a mutual friend/patient who had listened to the [Rachel Rubin podcast](https://peterattiamd.com/rachelrubin/), and was super impressed by it and said, “*You have got to speak with Sally*.”

**Why would a podcast that focuses on health, longevity, all of these things that pertain to living longer and better?**

*Why would sex be an important part of that discussion?*

- Sally is having a hard time understanding how sex couldn’t be a part of that conversation
- First of all, this is a performance driven podcast, and so for the 50% of listeners who are male, if you want to improve your performance, Sally is going to give you facts and anatomical descriptions and describe some pathophysiology so that you can improve your performance
- Clearly sexual health is health, and when you look at your longevity levers and you think about your centenarian decathlon and what you want to do when you’re a hundred, for many people, this is on the list
  - Sally wants to talk about how to structure your life and get you ready to do that
- She also thinks that there’s probably a small group of listeners similar to herself who always thought that *The Drive* was supposed to be about sex drive and that you just had a branding era when you named it the drive
  - For those people as well, we’re finally going to talk about the drive that you actually care about, which is sex drive

**Peter wants to talk a little bit about the actual health component of this**

- If you look at this through the lens of evolution, everybody clearly understands why sex is important and it’s the single most important thing in the propagation of our species
- Peter doesn’t just mean emotional and mental health where he thinks we could easily make that connection

*Is there any evidence whatsoever that a healthy sex life plays a direct role in health as it pertains to disease?*

Sally begins with 2 caveats

- 1 – This is an understudied, under-investigated area of our health
  - Many of the studies that she will reference are not going to be robust in volume
- 2 – This is an incredibly heteronormative conversation
  - For that reason, this is a data-driven podcast and Sally doesn’t have a lot of data on non-heteronormative
  - Meaning [she will focus on] men who identify as men, having sex with women who identify as women
  - So that should alarm you as well that we don’t have that data
  - But that’s the space in which we have a data-rich zone, and that’s where we have to stay

**⇒** The discrepancy when you look at sexual health is greatest among those 2 participants [men and women]

- When we look at sexual health and we try to make the argument that sexual health is a part of health, we can use Peter’s longevity framework

If we start with **sleep**, there is great data

- We know that when you are sexually active with or without orgasm (just participation in a sexual activity), you switch from [sympathetic](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) to [parasympathetic](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system)
- Post-orgasm, you have a great activation of the parasympathetic nervous system
  - You release neurotransmitters, dopamine, oxytocin ‒ these are relaxing neurotransmitters

***When we study it either via diary or via great studies that look at resting heart rate, sleep latency (many of the measurements that we look to in terms of looking at sleep efficiency and quality) sleep subjectively and objectively improve with intercourse***

- There was a great [trial](https://pubmed.ncbi.nlm.nih.gov/36646500/) that looked at how women slept after an orgasm with themselves and they slept better
  - And then it looked at women being intimate with a man and they slept better
  - But women being intimate with a man and having an orgasm with that man synergistically improved their sleep
  - You’re getting a dual benefit of that neuropharmacology that you’re releasing from your brain, improving your biometrics, but also there’s a connection and intimacy, a partnership that we know fosters better sleep

There is limited data on **cardiovascular health**

- We know that sex can mimic a lot of the pathophysiology that we experienced during exercise
  - There’s been arguments over the decades about is it low intensity, is it moderate intensity? (it depends on the couple)
  - Studies have tried to measure the [MET](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task) (or the metabolic equivalents) or essentially the energy output: for women, on average it’s around 6-7 metabolic units for every sexual encounter
  - It’s about 60-70 calories used during sexual activity
- There’s a great [study](https://pubmed.ncbi.nlm.nih.gov/24205382/) that compared this to walking slowly on a treadmill for the same amount of time
  - They said that although sex was slightly lower in your energy export than walking on the treadmill
  - Many of the participants reported that they had a much better time having sex than they did walking on the treadmill, and that’s something to consider
- We know sex is tapping into the body’s natural pharmacology, and that’s really interesting to think about from a relationship perspective
  - Thinking about neurotransmitters and positive impact on mood and relationships

Sally adds, “*What I don’t want to say, what I don’t believe is that everyone has to have lots of sex and that there’s a number that we’re trying to target.*”

- Is there a number needed to treat [NNT]?
- Is there a dose that we’re trying to go for?
- No, there’s no studies on that
- Realize that every person, every couple is different

**When you look at couples, Sally likes to look at who is having sex and by what frequency**

- About 20% of couples ages 30-60, are having sex twice a week or more
- About 10% of couples are what we call never having sex, and that means in the last year
- About 70% of couples are having sex between those, meaning once a month, twice a month, around that number

When you look at risk factor for divorce

- It’s the same across all numbers in the sense that it doesn’t matter how much sex you’re having
  - You could never have sex, you could have lots of sex
- The divorce risk factor is what we call **sexual desire discordance**: where one partner wants more and one partner wants less
  - Identifying that as the risk factor, Sally hopes it gives people affirmation or interest in the fact that if you want to work on it, she will help you, but not everyone has to

***This is not a podcast about everyone needs to go work on their sex drive, but if you do, she’ll go through the normal path of physiology and some additional tips and tricks to help you have a healthier sex life***

**Peter’s takeaways**

- 1 – The discordance of desire is a much bigger risk factor than anywhere you lie on the distribution of [sex frequency]
  - 10% of people are basically asexual, 20% of couples are at twice a week or greater, and basically 2/3 of couples are somewhere in between
- 2 – Peter can’t resist coming back to the [Centenarian Decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/), and he’s glad Sally brought it up because it is one of the items on our list on the framework that we hand to patients
- When we ask patients to pick the 10 most important things that they want to be able to do in their marginal decade in the last decade of their life, and about ⅔ of our patients select having sex as one of those 10 activities
  - That says something, given that we’re giving people a list of about 150 things to choose from, all of which are quite tempting
- To go back to the point about [METs](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task), if 7 METs is what is required energetically to have sex, we can convert that into VO2, and that translates to about a VO2 of 25 mL/kg/min
  - Which means if you want to be able to have sex in your marginal decade, you need to have a [VO2 max](https://en.wikipedia.org/wiki/VO2_max) of probably about 30 mL/kg/min
  - Why? Because it would be pretty tough to have sex if you were doing it right at your maximum VO2 ‒ that would be like asking you to do the fastest 800 meter run you’ve ever done and bring that level of exertion to sex
  - You got to be a little bit below your limit
  - While most adults can easily muster a VO2 max of 30 mL/kg/min, if you want to be able to achieve that in your 80s or 90s, when your 50, you need to be probably north of 45 or 50

> “*If I could just make one more shameless plug for having a high VO2 max, it’s going to allow you to be sexually active in the last decade of your life*.”‒ Peter Attia

## Understanding the physiology of the female orgasm, sexual comfort and satisfaction, and the disparity between men and women [A: 12:45, V: 10:21]

- When it comes to understanding what an orgasm means for a man, it seems relatively straightforward in that it’s tied to ejaculation
- And while there are examples where a man can have a [retrograde ejaculation](https://en.wikipedia.org/wiki/Retrograde_ejaculation) due to exemplary use of medication and he can still have an orgasm, but you’re not actually witnessing an ejaculation

**With women, how is an orgasm actually defined?**

*Is it a biochemical response in the brain? Is it a muscular contraction in the body?*

- We are going to talk about “normal” things, and there are a lot of pathophysiology and deviations from what’s normal

***What’s normal in most women is a rhythmic contraction of the pelvic floor muscles***

There’s 4 stages to an orgasm

- 1 –  It starts with the excitement phase, which is an engorgement of the pelvic tissues, there’s increased blood flow, there’s lubrication released by the skeins glands and other glands of the vaginal canal
- 2 – Then there’s a plateau phase that is predominantly a neurotransmitter phase and a hormone release phase
  - You can stay in that for a variety of time periods (person and partnership dependent)
- 3 – There’s the orgasm
- 4 – Then there’s the resolution phase

Sally emphasizes, “*These 4 stages, understanding how they work and where you are in that stage can allow for the introduction of interventions that can improve your sexual life or help you foster a healthier life in general.*”

**What is the period of time in which a woman will go from those first to fourth phases?**

- Peter understands there’s going to be a lot of variation, and is interested in what would be considered the interquartile range
- It really depends
- When women are on their own, the average time to orgasm is <4 minutes
- When women are with a partner, it’s upwards of 21-25 minutes

Peter asks, “*With a partner, you could still have it manual, it to be oral, it could be intercourse, so how much does that…*”

- That really skews the data and Sally doesn’t have the numbers on that
- Women are actually individually so different as well

***An interesting takeaway: when foreplay lasts longer than 21 minutes, over 90% of women orgasm***

- It’s really interesting and enlightening to think that time actually does matter in that stage

**Why do we care about foreplay? What’s happening during that time?**

- That’s when you’re in the excitement phase building up towards orgasm
  - Blood is flowing to the area
  - The anatomy changes:the vagina (usually 3.5-inches wide x 9-inches deep) will actually get longer and wider
- And why do we care? 30% of women will experience **pain** with intercourse

**⇒** Appropriate foreplay causes the vagina to not only gets wider and longer, but it actually changes the angle of the vagina

- This is something Sally loves talking to couples about
- She has many women who will say, “*My partner loves this position, and often it’s a deep penetration position, but it really hurts me.*” (most commonly called doggy style)
  - [Sally recommends a [depth-limiting device](https://thepelvicpeople.com/collections/all-products/products/ohnut-depth-limiting-rings) for use after addressing pain]
- Sally will ask how much foreplay is going on

***If there’s not enough foreplay, you don’t change the angle of the vagina (or the angle of the canal), and so you will experience more pain***

**⇒** Tightness of the pelvic floor muscles will foster pain

> “*I hope I’ve proven to you that sexual health pleasure orgasms are a part of health.*”‒ Sally Greenwald

**What can you tell us about the differences in ability to achieve orgasm, the so-called orgasm gap?**

- When we look at the dispararities and how different parties will participate or receive enjoyment out of these activities, it highlights how important it is that we work on this

Sally asks Peter, “*What percent of men when they’re having sex with a woman report that they almost every time have an orgasm?*”95% [Sally agrees and [studies](https://pubmed.ncbi.nlm.nih.gov/28213723/) support this, as shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f1-sallygreenwald.png)

**Figure 1. Reports of orgasm frequency**. Image credit: [*Archives of Sexual Behavior* 2017](https://digitalcommons.chapman.edu/psychology_articles/74/)

Peter asks Sally, “*What percentage of women would report always being able to have an orgasm with a male partner?*”

- Peter guesses 50%
- Sally reports 30%
  - [see links to [surveys](https://yougov.co.uk/society/articles/40941-orgasm-gap-61-men-only-30-women-say-they-orgasm-ev?utm_source=chatgpt.com) (shown in the figure below), [studies](https://pubmed.ncbi.nlm.nih.gov/29079939/), and [summaries](https://news.iu.edu/kinseyinstitute/live/news/45749-how-often-do-women-orgasm-during-sex) in the “selected links” section at the end of these notes]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f2-sallygreenwald.png)

**Figure 2. Self-report of orgasm**. Image credit: [You.gov UK 2022](http://you.gov)

- For a one-night-stand, 12% of women report orgasm
  - For men, it’s 90%

Orgasm is one metric that we can use, but it’s not the end all and be all

- There’s satisfaction, intimacy, connection, pleasure, benefits that women get out of intercourse
- But orgasm is one numeric finding that we can track

***This disparity or this discrepancy is a big deal; and this disparity in how women experience pleasure becomes a health disparity***

- Because if sexual health is health, and women are not experiencing it with the same amount of pleasure that men are, this is a health disparity

**Within women, does orgasm at all correlate with underlying health?**

- Yes
- We know that orgasm is related to strength of the pelvic floor, vascular blood supply
- There’s a lot of bidirectional issues
  - If you’re healthy enough to be able to have an orgasm, then you can have an orgasm
  - And if you’re having orgasms, you’re likely healthier

**Sally puts this in perspective**

- We classically think about sexual health as an afterthought
- When we think about longevity, we think about cancer screening and prevention and chronic diseases and now sleep and exercise
  - And once we’ve addressed all of those, we now have the luxury of addressing sexual health
- Sally thinks we should put sexual health a little higher on the list

## Foreplay, the science of desire, and methods to help women cultivate arousal and connection [A: 19:00, V: 16:57]

**How do we define foreplay?**

*When most people hear foreplay, they assume what? Anything that is sexual shy of intercourse?*

- There’s medical and social definitions of foreplay
- Social definitions tend to say anything outside of penetrative intercourse
- Medical definitions rely more on the physiologic changes that are happening in your body: increased blood flow, recruitment of swelling of the clitoral nerve, physiologic signals from your brain that prepare you emotionally to participate in this interaction

Let’s start with desire

- We think about socially men’s desire, we think more of **spontaneous desire**

**⇒** Spontaneous desire is more common in men; spontaneous desire is only present in about 15% of women

- Women have what we call **responsive desire**
- An example of **spontaneous desire**: you’ve been married for 20 years, you see your partner get out of the shower for the 8,845th time, and you think to yourself, “*Gosh, I would love to be intimate with this person.*”
  - That’s desire in anticipation of intimacy
- [In this example, what’s happening with] **responsive desire**: you see your partner get out of the shower for the 8,645th time and you think, “*Did I sign up for the right treadmill tomorrow morning at 6:00 AM?*”
  - That’s because your brain’s just not there; it’s not in the same place as your partner
  - But if your partner comes over and starts to rub your shoulders and rub your feet or maybe has made dinner (what we call chore play, which is where emotional investments in the relationship), that can sometimes lead to responsive desire

Other things that can create responsive desire

- Using lubrication (we’ll talk about how to use lube later)
- Using a vibrator
- Creating an environment in which you are capable of being aroused
- Thinking about what’s happening in that circumstance can be really helpful and validating for women, and it can help their partners get them there too, with the ultimate goal of being aligned in your sexual desire from a frequency perspective

Peter asks, “*You’re saying it’s more typical that men experience spontaneous desire where arousal comes on in a moment?*”

- In anticipation and often based on a visual cue ‒ correct
- For women, that is less common but not implausible

**And acknowledging that, there’s a few lessons we can take from that**

- If you want to work on your desire, if you’re waiting for your husband to get a new shirt or or anything, the visual stimulus is not evidence-based (stop waiting for that)

Sally explains, “*I want you to think about how you get responsive desire in response to arousal. And how we do that is lubrication*.”

- Most of us know how to use lube
- You’re in the act, you take some lubricant, you put it on the penis, you put it on the vagina, you have intercourse

Sally’s recommendation

- She wants to encourage you to think about lube, potentially using it 30 minutes prior to intercourse
  - Take a silicone-based lube and a lube shooter put a little droplet higher up in the vaginal canal
  - Then read a book, drink a cup of tea, wash your face

**Women are less visually stimulated into desire, but there are other approaches**

- There’s great data that women like to read **erotic literature**, and there’s great apps for that: [Meet Rosy](https://meetrosy.com/erotica) and [Dipsea](https://www.dipseastories.com/) are great companies that have auditory or literature porn for women
- There’s great data that **mindfulness** can work for women
- Lori Brotto wrote a book called [*Better Sex Through Mindfulness*](https://www.amazon.com/dp/1771642351/?bestFormat=true&k=better%20sex%20through%20mindfulness%20lori%20brotto&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_k1_1_11_de&crid=4UW7QCAPFE61&sprefix=better%20sex%20), thinking about breathing techniques, staying present in the moment
- Sally’s favorite strategy for this is to describe to yourself in your head (not out loud), “*What’s happening? Breathing is relaxing. My vagina feels wet.*”
  - Talking yourself through what’s happening from a pathophysiologic perspective to bring yourself into the moment

Sally’s advice, “*When we think about how to curate that arousal, essentially what you’re doing is showing up at the party and then seeing what happens. And there’s no expectations [around] what happens at the party*.”

- Emily Nagoski wrote, [*Come As You Are*](https://www.amazon.com/Come-You-Are-Surprising-Transform/dp/1982165316/ref=tmm_pap_swatch_0), talks about [an analogy]
  - It’s Friday night and you really want to put on your bathrobe and watch Love Island, but instead you’re going to go to a party with your friends because you said you would
  - And you get there and it’s actually kind of fun
  - So you stay, you have a good time, you have a drink, you actually like it when you’re there

***That’s the idea behind curating your own desire through arousal, which is use a vibrator, use some lubricant, relax, get in the moment, start to participate***

- And if you don’t want to, obviously consent is of utmost importance and stop
- But if you start participating and decide that you’re happy that you’re there and you like it, please stay and have a good time

## The physiology and sources of female lubrication, the role of clitoral nerve anatomy in pleasure, and the use of lubricants and vibrators to enhance comfort and sexual health [A: 23:45, V: 22:10]

**The need for lubrication**

- Peter very naively assumes that women who are young enough (so not even approaching estrogen withdrawal), are not having an issue with lubrication
  - That clearly must be incorrect or Sally wouldn’t be stating this

*What can you say about perhaps the differences in the amount of lubricant, and maybe even just talk a little bit physiologically about what is the lube that is naturally made, where is it coming from?*

*And what drives variability both across women and within a given woman’s life, let’s not even talk about it within her life, within a given month or something like that?*

- Women will have different levels of lubrication throughout the month
- Medications can impact lubrication, as can life, age, life cycle
- There’s so many factors that go into your ability to have the amount of lubrication that you need in order to have a comfortable sexual encounter

> “*This idea that we just need lube as we age, I want to completely dispel. I think the majority of women need lubrication and should use it*.”‒ Sally Greenwald

The physiology

- The way that we naturally get lube in our vagina is from a variety of different glands that work better or worse
- There’s the [skenes glands](https://en.wikipedia.org/wiki/Skene%27s_gland) that support the vagina
  - They’re right on either side of the urethra
- Fun fact about this, many people will have more prolific skeins glands in the sense that they can shoot the lubrication a little bit stronger
  - When we talk about women who, what we call squirt, it’s actually the skeins glands releasing lubrication in a more aggressive form
- There’s [Bartholin’s glands](https://en.wikipedia.org/wiki/Bartholin%27s_gland) that produce lubrication that are commonly known for their likelihood to sometimes get clogged and to cause pain
- There’s so much that goes into lubrication, and it’s so important throughout the life stages that the WHO (World Health Organization) actually has [guidelines](https://www.who.int/publications/i/item/who-srh-23.4) in terms of how to pick out your lube
  - They care about HIV transmission and picking the appropriate lube decreases microabrasions, less friction, less tearing, less HIV transmission

*Isn’t there a min-max optimization problem around lube?*

- Peter is asking because friction is part of what is necessary to have an orgasm (at least for the male)

**⇒** Friction matters less so to women

**Let’s talk about the clitoral nerve anatomy to answer that question**

- Typically, we talk about the tip of the iceberg or the clitoris
- There’s the **crus** of the [clitoris](https://en.wikipedia.org/wiki/Clitoris) and there’s the **vestibule** (which is an engorgement structure when blood comes to the area) [illustrated below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f3-sallygreenwald.png)

**Figure 3. Anatomy of the clitoris**. Image credit: [*International Society for the Study of Women’s Sexual Health* 2025](https://www.isswsh.org/images/PDF/Feb%2011%202025%20Webinar%20Slides.pdf)

- Sally points out the labia minora, labia majora, and vulva [see more [here](https://www.nva.org/what-is-vulvodynia/vulvar-anatomy/)]
- When we think about the clitoral nerve, it actually has 2 types of nerve fibers in it: one is a [type A nerve fiber](https://en.wikipedia.org/wiki/Group_A_nerve_fiber), and one is [type C](https://en.wikipedia.org/wiki/Group_C_nerve_fiber)

**⇒** Type A responds to vibration and it responds to deep pressure; and type C responds to heat and light touching

Sally explains, “*What’s really interesting about using this to answer your question is that friction is not a requirement to hit any of those 4 metrics and actually is so significantly associated with microtearing and pain (with the 30% of women experiencing pain with intercourse), I would argue that women need no friction.*”

**How that nerve changes over time (and what Sally recommends)**

- Type A fibers respond to vibration and deep pressure
- They have a myelin sheath around them, and so they age better
  - Nerves protected by a myelin sheath are more resistant to degradation
- Women come into the clinic and say, “*I’ve been with my partner for 35 years. We do this position for six minutes. It always works. It’s not working*.”
- Sally suggests: introducing a vibrator into your sex life
  - She explains, “*This is an evidence-based intervention, understanding the science of myelin sheaths and nerve degradation. This has nothing to do with your husband and nothing to do with your relationship.*”

Peter asks, “*When you’re saying introduce a vibrator, do you mean use it after or before?*”

- Or during
- Use the vibrator externally
- There’s different types of vibrators, some are internal
- But if you’re trying to pick a vibrator that you want to use when you’re with a partner, buying something like a wand is long enough that you can reach the structure in a variety of positions
  - [JIMMYJANE](https://jimmyjane.com/products/chroma) makes a nice wands
  - [Goop makes](https://goop.com/goop-wellness-double-sided-wand-vibrator/p/?Size=No+Size) a great product as well
- There are [air pulse vibrators](https://www.lelo.com/sona) that you can put on the clitoris
- These are sort of all external vibrators that you can bring into a partnered encounter to have an evidence-based way to continue to achieve orgasm because that is one of your greatest ways in which you can continue to maintain a healthy sex life

Peter asks, “*Not to get too graphic… If you’re talking about a sexual position where the man is on top of the woman and she’s using an external vibrator, does the man also receive some pleasure from that?*”

- He might, and there are more strategic ways that you can try to do that if the man likes that
- But there’s ways that the man can angle his pelvis that he doesn’t have to feel it

**Back to the female ejaculation. All of that ejaculatory material seems to be external**

- Some is and some isn’t

*How is the vagina being lubricated inside?*

- The Kinsey Institute has great studies where they put cameras inside the vagina and they actually watched
- The vagina essentially sweats
  - The cells of the vaginal canal release water molecules
- There’s cervical mucus that also serves as a lubricant as well
- All of these things vary dependent upon hydration and medications and things like that

*For women who do experience that ejaculation, that’s perfectly normal. Do they have control over that?*

- Most people think they do not
- It doesn’t imply a better orgasm
- Sally doesn’t have statistics on the frequency of women who achieve this

## Understanding female anatomy and what is needed for orgasm [A: 31:15, V: 30:19]

**When a woman comes into your clinic and you’re taking care of her, what are you most surprised by in terms of her lack of knowledge about her own body?**

- Anatomical lack of education (where was the sex education?)
  - Referring to the vagina as the vaginal
- The vaginal canal is the vagina, the vulva is the outside of the vagina
- There’s labia majora and menorah all the way down to the clitoral nerve and the fact that it has different nerve roots
- If we think about looking at this model, this is if a female is lying down on her back, that’s the angle that you’re looking at
- There was a great [study](https://www.theurologyfoundation.org/about-us/media/press-releases/sexual-wellbeing-is-still-a-mystery-for-many-uk-men-survey-reveals/#:~:text=61%25%20of%20men%20could%20correctly,the%20clitoris%20than%20the%20prostate.) that was done recently that said that only 41% of Gen Z men could accurately identify the clitoris on a pictorial

> > “*I take from that sex education needs to get better*.”‒ Sally Greenwald

- There is a need for better sex education that’s actually anatomical and not fear based
- Most women (not all) do know about the **clitoral hood**, which is the clitoris or the bulb
  - That’s what we think about in terms of the tip of the iceberg
- But what women often don’t know is that they have what we call the **vestibule** of the clitoris, which are these bulb-like structures that can receive engorgement when there’s an increase in blood flow [labeled bulb in the diagram below]
- And then there’s the **crus** of the clitoris, which is these nerve structures that go on either side of the labia minora
  - It’s a wishbone-like structure

![](https://peterattiamd.com/wp-content/uploads/2025/10/f4-sallygreenwald.png)

**Figure 4. Diagram of the clitoris**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Clitoris)

- What’s really fascinating is to normalize that: anatomy can and should look different
- There’s a great website called the [Labia Library](https://www.labialibrary.org.au/) [explicit images] that normalizes all different types and sizes of labia minora and majora
- The wishbone structures are often asymmetric as well; and so it is quite common for a woman to experience greater pleasure on one side of the vagina versus the other
  - Meaning that this nerve root of the clitoris may be thicker or more sensitive [on one side]
- There’s over 8,000 nerve roots as a part of the clitoris, and they can be more focused on one side versus the next

Sally adds, “*I hope that half of your listeners are thinking, I always wondered why I was a righty or hey, I’m a lefty. I also hope the other 50% are wondering, if you’ve been with your partner for a long enough time, I hope you know if your partner is a righty or a lefty.*”

> “*I hope you know if your partner is a righty or a lefty, because there’s asymmetry in how we experience pleasure*.”‒ Sally Greenwald

- Interestingly, if you’re looking at the tip of the clitoris, there’s a nerve root

**There’s a part that goes inside the vagina and that’s what we talk about in social terms, we talk about the G-spot**

- It’s a branch of the clitoris that runs along the anterior or the front part of the vagina
- It’s about a third into the vagina
- The best way to find it is if a woman is trying to find it on herself is to take her dominant hand, middle finger, stick it as far in as you can and do a come hither movement or movement of the finger towards the top part of the vaginal wall
- It’s easier to find when you’re aroused because there’s engorgement of the tissues
- It feels a little more rugated and you’ll know that you’re there if you feel a sensation to urinate, but if you relax into that, you won’t

**⇒** Only about 10% of women now are able to orgasm from stimulation of that internal branch of the clitoral nerve

- There’s some data that shows that with education that can go up
- So talking to women about how they can find the anterior branch of their clitoral nerve not only allows them different ways to orgasm, but also gives them a sense of empowerment and sort of ownership to sort of talk their partner through how to maintain pleasure

**⇒** But for those people who can’t have orgasms from the inner part of their vagina, the other 90% are having orgasms from external stimulation of the clitoral nerve

- [Dr. Lauren Streicher](https://www.drstreicher.com/about) says, for the 10% of women who can orgasm via the G-spot or the anterior branch, that’s great, and she diagnoses the other 90% who can’t orgasm from stimulation of the internal nerve as normal

***It’s totally normal if you can’t have an orgasm from that part of the clitoral nerve, but after hearing this podcast, Sally hopes women and their partner should try***

**⇒** This branch of the clitoral nerve has better blood supply than the tip of the iceberg

One of Sally’s favorite techniques for women in the perimenopausal/menopausal period [is to target the G-spot/anterior branch of the clitoral nerve]

- As hormones change, the nerve fiber degrades a little bit

***Teaching women how to have orgasms from this part of the nerve [the G-spot] that has better blood supply can help maintain pleasure and help maintain interest in sexual activity as we age***

**When a woman is having intercourse, and maybe for the percentage of guys who might not be familiar, can you point out where the entry to the vagina is on this model?**

- There are some statistics that talk about what percentage of women can orgasm simply by having penetrative intercourse

- What’s interesting is that the distance of the clitoris to the vaginal opening is variable
  - They tend to <1-inch
- The shorter the distance of the clitoris to the vaginal opening, the more likely you are to be able to orgasm during penetrative intercourse, and that’s because the distance is so short that the angle of the man’s body is able to stimulate that area
- If that distance is greater, you’re less likely to be able to orgasm simply from penetrative intercourse
  - Cue introducing a vibrator, manual stimulation, etc.

**What percentage of women are able to orgasm without any stimulatory vibrator (or anything like that) from intercourse?**

**⇒** Less than 10%

> “*Those grave statistics are without any external manipulation of the clitoris.*”‒ Sally Greenwald

Peter’s reaction, “*Wow. So it’s the same number that you have from the G-spot*.”

**Peter’s takeaway ‒** ***so if a woman is listening to this and she’s never had an orgasm through intercourse, she is in the 90%. There’s nothing wrong with her, she would be diagnosed as normal***

- And for those women out there who are regularly achieving an orgasm through intercourse, you’re in the minority
  - More likely they’re adding external stimulation of the clitoris

Sally explains, “*Women who are achieving orgasm with a partner, [it’s] is because they’ve identified positions with their partners, they’re using manual stimulation, they’re introducing vibrators, they’ve figured out regardless of distance of clitoris to vaginal opening, how to stimulate the clitoris, the external part of the clitoris*.”

**Sally likes to talk about anatomy so patients can think about their own individual anatomy**

- She encourages women to talk to their partners about it
- And think about if there’s someone who needs to introduce that external stimulation
- Or think about if they as a couple could try to find the anterior branch of the clitoral nerve
- There’s lots you can do as a part of that

**How often do you have men in your practice who are there with their female partners who you’re trying to educate?**

- For a sexual health consult, 20% of the time

**What is the most common thing that you appreciate about men when you’re helping them in terms of their lack of understanding about their partner’s anatomy?**

- Giving men a road map, being very descriptive
- Most partners want their partners to be happy
- There’s the selfish aspect of performance and there’s the sexual empathy component where they care about their partner and they want their partner to feel well

***Giving them a road map to explore around and find the anterior branch and think about the wishbone structures is really exciting to them***

- Thinking through spontaneous desire [versus responsive desire] is very exciting for them
  - How they tap into that, how they can curate that with their partner

***Thinking about their partner’s arousal and then supporting/curating that with their partner is exciting to them***

There’s a communication component

- When we think about sexual dysfunction, we tend to break it down into a **biopsychosocial model**
- Sally likes to talk mostly about bio
- She’s a clinical physician, a gynecologist, and so she thinks a lot about anatomy and pathophysiology and neurotransmitters and hormones

***But there’s a lot of other people in this field that are helping with the psychosocial aspect: sex therapists, communication***

- There’s a great book called [*Sex Talks*](https://www.amazon.com/Sex-Talks-Five-Conversations-Transform/dp/1668000016/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Fd8XOCdHAPcjyD4mk2HZQOnMkzWGfYybiCXMH6eMUjLoIIhYQcGzeDVy98m5iLGQHswfbib8CZcfTMtZsBT_m4gwCED94WD0SGybSmLFc1Ea7dEjnx4B9q2Avg6NgVqL.54RQfdaQxziVH_C7YJ1MHezfntPgnXweUHtqHews33M&qid=1758638362&sr=8-1) by Venessa Marin [pictured below], which talks about how to communicate with your partner

![](https://peterattiamd.com/wp-content/uploads/2025/10/f5-sallygreenwald.png)

**Figure 5. Book cover for** ***Sex Talks***. Image credit: [Amazon.com](https://www.amazon.com/Sex-Talks-Five-Conversations-Transform/dp/1668000016/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Fd8XOCdHAPcjyD4mk2HZQOnMkzWGfYybiCXMH6eMUjLoIIhYQcGzeDVy98m5iLGQHswfbib8CZcfTMtZsBT_m4gwCED94WD0SGybSmLFc1Ea7dEjnx4B9q2Avg6NgVqL.54RQfdaQxziVH_C7YJ1MHezfntPgnXweUHtqHews33M&qid=1758638362&sr=8-1)

- Also, [*Cliterate*](https://www.amazon.com/Becoming-Cliterate-Orgasm-Equality-Matters/dp/0062484389/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ww5LLIoMpqmsMagq7qNTzXzbUYw37tiMYHeJekCyWnp7X-FsTXISavTqvuiIljg1icKujuhl3e92OJ_oDzi6OQ.s7s90o_OxhE0rNm0DeXP-JiV7ktMnW7tVTxs-iyXfVM&qid=1758638509&sr=8-1) is a great book to think through different ways that you can improve your communication about what pleasures you and how to investigate that
- There’s really good websites now: [OMGYES.com](http://omgyes.com) is a website that talks about your anatomy and how to find it and how to find your pleasure spots
- There’s a lot out there; Sally is not alone in this space by any means, but she likes to think about it from a very biologic, physiologic perspective

**How much does a woman control her ability to have an orgasm by the way she positions her pelvis?**

- Earlier, Sally mentioned that a number of women are able to have an orgasm during intercourse, but it requires them using their own hand for example
- This is dependent upon her own anatomy
  - Thinking about how far her clitoral hood is from the vaginal opening
  - Thinking about if she’s a lefty or a righty

***Understanding your anatomy, exploring your anatomy can help you sort of figure this out and talk to your partner about it. So yes, there is a good amount of control that women can have over this, but the first step is understanding their own anatomy.***

**Is it a myth that if a woman uses a vibrator regularly on her own, it makes it harder for her to have an orgasm with her male partner unless she becomes dependent on using it as well?**

- It is a myth in the sense that there is data on either side
- There is some data that talks about if you acclimate to sexual practices that you cannot bring into a partnered model, then it may be harder to have orgasms in a partner situation
- But if you are comfortable using whatever technique you find upon your own time and you can bring that into your relationship, then you’re more likely to have orgasms

***Thinking about whatever it is that you’re doing and however it is that you’re doing it, if you can inject that into your life with your partner, you are more likely to have orgasms***

**⇒** There is really good data that orgasms beget orgasms, meaning the more orgasms you have, the easier it is to have an orgasm in terms of training the system, learning your body’s response to stimuli can be trained, your body’s response to things can be trained

## Understanding sexual desire, how to cultivate it, the role of hormones, and testosterone therapy in women [A: 41:15, V: 41:40]

**How we could use this from a desire perspective**

- There is good data that sex begets sex
  - Meaning the more sex that you have, the more sex that you want
- Sally talks to her patients about **scheduled sex** as a way to work on your desire
- When she brings this up, most of her patients are like, “*Oh my god, another thing I have to do. What a hassle*.”
- She points out the fact that you’ve always scheduled sex
  - When you met your partner and your partner said, “*What are you doing Friday?*” He was scheduling sex with you
  - And when you said, “*Sushi sounds good*,” and you shaved your armpits and put on a nice t-shirt, you were planning for sex
  - You were prioritizing your sex life in a way

> “*Scheduling sex is a great technique that we use*.”‒ Sally Greenwald

- How that rolls out depends on the patient and what frequency they’re going for

**Sally has her patients do what she calls, “Fuck It February”**

- She has patients scheduling sex 2-3 times a week for the month of February
- It’s a romantic month, it’s the shortest month of the year
- This takes pressure off the person who’s been the initiator; they get to relax and not have to worry about rejection
- And the person who has been less interested knows that they’re working through an arousal pathway
  - They’re working on responsive desire and scheduling just means that you’ll show up

***You don’t have to have sex, but you just show up and you try it***

**⇒** There’s great data that after a month, women will have that maintenance of their increased desire and they can ride on that for a couple of months

**Discordance of desire: How often is the discordance such that the male wants more than the female and visa versa?**

- Anecdotally it is most often the male has a higher desire than the female
- [discussed in the [position statement](https://pmc.ncbi.nlm.nih.gov/articles/PMC7261674/?utm_source=chatgpt.com) of the European Society for Sexual Medicine]

*Does it say anything about the couple if it’s the reverse?*

- Sally has seen the reverse as well

***There’s so much that goes into this in terms of the partner’s health status and chronic diseases and stressors at work (so there’s a lot to think through and it can go both ways), but by far and large it is predominantly the male with the stronger sexual desire***

**What’s the throttle and what’s the brake pedal on sexual desire for men and for women?**

*Peter assumes it’s different*

- Sally is not an expert in men’s sex lives (so she never talks about men)
- When we think about women, we think about accelerators and brakes
  - It’s a common framework that we use from a social behavioral perspective
  - What helps you feel relaxed and what turns you off
- But from a pathophysiologic perspective, we think about neurotransmitters

**⇒** **Accelerators from a neurotransmitter perspective** would be things like estrogen and testosterone, nitric oxide, dopamine, and oxytocin

- Those 5 neurotransmitters are in a complex interplay to tell our brain and our body through a variety of different pathways, “*I’d like to participate in intercourse.*”
- [Estrogen](https://en.wikipedia.org/wiki/Estrogen) is very interesting because although we know there’s [different](https://en.wikipedia.org/wiki/Estrogen_receptor) types of estrogen receptors throughout the body, but when it comes to sex drive, we think about [alpha receptors](https://en.wikipedia.org/wiki/Estrogen_receptor_alpha) (which stimulates sex drive) and [beta receptors](https://en.wikipedia.org/wiki/Estrogen_receptor_beta) (which decreases anxiety and inhibition)
- But it’s not as clear cut when we replace estrogen

Sally explains, “*It’s not a slam dunk and you cannot make the connection that, ‘Oh, so if I replace estrogen as it’s dropping, I fixed my sex drive. All is well.’*”

- [Testosterone](https://en.wikipedia.org/wiki/Testosterone) has a little bit more of a direct link to that
- When we think about, for example, the postmenopausal female, and Sally will use the term “[menopause hormone therapy](https://en.wikipedia.org/wiki/Hormone_replacement_therapy)” over “hormone replacement therapy”
- When we think about postmenopausal women, we think about menopause hormone therapy replacing estrogen: ***we sometimes do see an improvement in sex drive, but that’s usually through an indirect pathway***
  - You’re sleeping better, you have more energy, you’re not having as many hot flashes
  - So we’ll see an indirect improvement in sex drive
- Testosterone is well-studied for [hypoactive sexual desire disorder](https://en.wikipedia.org/wiki/Hypoactive_sexual_desire_disorder) or a decrease in your sex drive

**⇒** To meet the diagnosis for **hypoactive sexual desire disorder**, you have to have a low sex drive for more than 6 months and you have to care (not your partner cares, but you have to care)

***If you meet that diagnosis, testosterone is very well studied in terms of its benefits on your sex drive***

- [what acts as “brakes” for sexual desire is discussed later, after 1:10:45]

**What is your preferred method for administering testosterone to women?**

- Sally prefers a cream
- She also prescribes [Testim](https://www.rxlist.com/testim-drug.htm), which is an oil
  - She will get resealable packets and put into it an empty syringe (the kind used to give children Tylenol, not an actual needle syringe)

***Her favorite way to administer it: rub 0.5 cc on the inner thigh***

She does a lot of compounding cream using [Koshland pharmacy](https://www.koshlandpharm.com/)

- They have a pretty standard, well mixed formula
- Sally will prescribe a testosterone cream where the patient will use a pump a day when they get out of the shower
  - They’ll let it dry for 20 minutes and then they can get dressed

*Do you think the oil is more efficacious and consistent in its absorption than the cream?*

- She does not
- She follows labs when prescribing testosterone
- Anecdotally and from a lab perspective, she doesn’t find a difference
- She goes based more on patient preference
  - If they want an FDA approved product (although it’s not FDA approved for women), then we’ll go ahead and use the [Testim](https://www.rxlist.com/testim-drug.htm)
  - If they don’t, Sally much prefers to just compound it: it’s cleaner, it’s less messy, it’s easier to dose
  - [With Testim,] there’s so many dosing issues with the oil in terms of how we dispense it when it’s not supposed to be dispensed for women
  - Sally much prefers the cream
- Peter typically uses a cream more
- Sally doesn’t use the intranasal [[Natesto®](https://www.natesto.com/)]
- She uses intra-vaginal, but in the form of [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone)
- She uses a lot of [Intrarosa](https://us.intrarosa.com/what-is-intrarosa)
  - Intrarosa (or [Prasterone](https://www.rxlist.com/intrarosa-drug.htm)) is a metabolite that can ultimately come down the testosterone estrogen pathway
  - That’s for pain of the vagina

***When it comes to sex drive and desire, Sally administers testosterone, mostly cream***

**Do you target a specific level for total testosterone or free testosterone? Or are you just basically saying, I want to get it above a certain floor and then symptoms determine where we end up?**

**⇒** Sally wants to get total testosterone above 20

Peter reacts, “*Wow, that’s a low floor.* ”

- Sally agrees that it’s very, very low
- Then she uses symptoms to gauge dose

***She’s interested in a testosterone range of 20-80***

- The guidelines in terms of how to titrate it are not clear
- Anecdotally, she’ll have patients at 80 who have no benefit to their sex drive, while she’ll have other patients at 20 see a great benefit
- She wants to see some modest improvement in their testosterone and then interview (see how they’re doing)

**Peter’s take on testosterone levels and androgen receptor density**

- Given how much variability there is in men with [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor) density, Peter thinks we have a pretty clear sense that in men, levels don’t tell you much unless you’re below 350, 400
  - If you’re below that level, you’re really going to be hypogonadal

***But men can be replete at 600 and other men might not be replete till they’re at 1000, and again, it just comes down to*** [***AR***](https://en.wikipedia.org/wiki/Androgen_receptor) ***density***

**Do you have any sense of how that works in women?**

- Other than it’s incredibly complicated as Peter alluded to, but more so in women

**⇒** Because most women who are on testosterone are also on estrogen, and we know that estrogen increases your sex hormone binding globulin quite significantly

- [Sex hormone-binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) is a protein that runs around and gobbles up free androgens or testosterone
- Sally is prescribing estrogen and progestin
- And [progestins](https://en.wikipedia.org/wiki/Progestogen_(medication)) actually have the ability to blunt or mitigate that increase in the sex hormone-binding globulin
  - The more androgenic the progestin, the more mitigating effect on that increase in sex hormone-binding globulin

> “*This is my true passion in thinking about hormones and contraceptive and menopause hormone therapy and tinkering with hormones because some of what you do will help the sex drive, some of what you do will hurt.*”‒ Sally Greenwald

***The addition of the 2 variables of estrogen and progestin make this incredibly more challenging***

## Personalizing perimenopause care: how desire for ovulation guides the choice between contraception and menopausal hormone therapy [A: 49:30, V: 50:48]

**How do you like to initiate estrogen, progesterone, and testosterone use in a perimenopausal woman?**

- Peter points out that this group is obviously one of the most difficult to treat because she still has waxing and waning natural levels of all of those hormones
- But during her nadirs is typically pretty debilitated by the symptoms
- We talked about this at length with [Rachel Rubin](https://www.rachelrubinmd.com/drrubin) [[episode #348](https://peterattiamd.com/rachelrubin/)]

Sally loves this topic because it’s so different for each woman in terms of how she responds

- The first question that she tries to answer in her interview with perimenopausal patients is: **Do you like ovulating or not?**
- That’s the first branch point at which she decides how she’s going to approach this patient
- Peter never really thought of that questions

*Tell me why that question matters and why would a woman know the answer to that question?*

- First, from a sexual health perspective ‒ some people love it when their sex drive is higher around ovulation (that feels good)
- Similarly, the first half of your cycle when estrogen is climbing right before ovulation is a high performance part of your cycle
- So these women who like to cycle, feel good the first part of their cycle, they feel great right before ovulation

**⇒** Sally has a few Olympic athletes in her practice and we will figure out when their events are and we will try to figure out their ovulation so that they are competing around day 9, 10, 11, 12 to 15 of their cycle

- Because right before ovulation is where they can lift the heaviest, they can run the fastest
- Sally for love for Peter to do a study on VO2 max throughout the cycle

***There are a lot of biometrics that peak right before ovulation: your memory is stronger, your energy is stronger, athletic performance is stronger***

Peter asks, “*Just to be clear, at that moment in time, her estrogen is pretty much at her highest, progesterone is low, testosterone is high?*”

- Correct

Peter asks, “*Does that mean progesterone is a performance inhibiting hormone or does it mean that estrogen… Because obviously testosterone is a performance enhancing hormone… Because in the luteal phase you would also see high estrogen, but you now have high progesterone*.”

- [the figure below shows hormone fluctuations that occur during the menstrual cycle with estrogen shown in red and progesterone shown in blue, explained further in [episode #256](https://peterattiamd.com/endocrinesystem/) after (27:00)]
- [ovulation takes place mid cycle, after which begins the luteal phase]
- [estradiol peaks just before ovulation]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f6-sallygreenwald.png)

**Figure 6. Hormone changes that occur during the menstrual cycle**.

- In the luteal phase progesterone is high but not as high as estrogen
- To get a little more academic about it, you’re really talking about a [progestogen](https://en.wikipedia.org/wiki/Progestogen)
  - There’s estrogen and there’s progestogen
  - Within progestogen, there’s progestins and there’s progesterone
- Now, **natural progesterone** we know is what’s in your body is progesterone
  - Yes, it is a “rest and digest,” a low energy phase, a preparation in case [of pregnancy]
  - It helps with sleep
  - It prepares for implantation, for pregnancy
- In terms of the progestins, which are **a synthetic class of progestins**, we then think about what is the family that this was derived from?

**⇒** The side effects from progestins can be very, very, very different

- This is where a patient can really advocate for herself
- Doctors, we’ve worked our butts off to get here
  - We deeply care about helping you (all doctors do)
- When patients come in with great symptom tracking and timelines and relations to bleeds and things like that, it can really help us understand through interview: **Whether you’re someone who feels great because of ovulating or whether you’re someone who really suffers from PMS (premenstrual syndrome)**
- Has it turned into [premenstrual dysphoric disorder](https://en.wikipedia.org/wiki/Premenstrual_dysphoric_disorder) where it’s PMS, but now it’s impacting your life?
- There’s so many reasons by which you would say, “*I actually feel terrible cycling. I would prefer not to,*” but that’s the first branch point when Sally has a perimenopausal woman

**What percentage of women who are, let’s just call it 44 years old, 45 years old, will respond to that first question as, yep, I really enjoy ovulating. Let’s keep it up. Versus let’s make this go away.**

***70-80% of her patients prefer not to ovulate***

- This is the 45-year-old who used to be really short tempered with her kids the day before her periods, and now the whole week before she’s really short tempered
- All of the symptoms of low estrogen: hot flashes, vaginal dryness

> “*Perimenopause is, your brain is yelling at your ovaries to please do one last ovulation. Listen up.*”‒ Sally Greenwald

- In perimenopause, you have this hyper-stimulation of signaling
- A hyper-responsive [FSH (follicle stimulating hormone)](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) ‒  so much so that you can get a **loop event**
  - Which is a luteal out of phase event where essentially you ovulate twice
- Your FSH is so high, it’s so busy yelling at your ovaries that your ovaries are like, “*I heard you and I heard you again*.” And they essentially double ovulate
  - And that’s when you’ll have a long cycle and then a short cycle and then a long cycle

***These are all clues that you don’t like to ovulate***

**Peter points out that Sally is the first person beside him who he’s heard use the yelling analogy**

- He’ll never forget, 10 years ago he was sitting down with a male patient
- He came in and had a pretty high testosterone: it was probably 700 or 800, which for his age was actually pretty high
- And his FSH and his LH were 2x normal and he wasn’t taking anything
- Peter was like, this is really interesting; and he’s like, “*Why?*”
- Peter drew him a picture and I said, “*Basically your pituitary gland is yelling. It’s screaming at your nuts. And they’re really responding*.”
- Peter forgot about that statement, then 6 months later, a year later, 2 years later, he kept coming back with that
- At some point, Peter started taking care of one of his friends
- His friends told Peter about it, “*He’s really been bragging about this.*”
- Peter is sure women do not go and brag to their other friends that their pituitary glands are screaming at their ovaries
- But that’s a guy thing, a guy would brag about that

Sally explains what women do

- Women are walking around the block with their protein shakes, they’re doing their thing, and you have one 46-year-old (average age of perimenopause being 46) saying, “*Gosh, I feel so great. I’m on a birth control pill and I just feel so great.*”
- And the other 46-year-old is like, “*Me too. I’m on menopause hormone therapy. I just feel so great.*”
- Then they look at each other, “*Why are you on that?*”

***The heart of this for Sally is: Who likes to ovulate and who doesn’t?***

- From a sexual health perspective, understanding: Do you want to ovulate?
  - This is important for your sex drive and all the other things that make you happy and feel good (which ultimately go into your sex drive)
- And if you do want to ovulate, then we can think about: Do you need contraception?

**Sally just made a distinction that Peter doesn’t know that every listener will understand This is important for your sex drive and all the other things that make you happy and feel good (which ultimately go into your sex drive) ‒ she just talked about oral contraceptives (which are hormones) and then menopausal therapy (which are also hormones)**

*Can you explain why that branch point is different in response to your question?*

- With **menopause hormone therapy**, the dosages do not suppress the gonadotropin pathway, and so when you are on menopause hormone therapy, **you still ovulate**
  - If you’re going to ovulate, you still ovulate
- Whereas many forms of **contraception suppress ovulation**, but not all forms

Sally emphasizes, “*To be clear, when talking about contraception and how it affects your* ***sex drive****, we talk about ovulation and how women’s sex drive can be ovulation dependent.*”

- Remember though that we’ve looked at how suppressing ovulation impacts your sex drive
- The [data shows](https://pubmed.ncbi.nlm.nih.gov/23320933/), a great meta-analysis of 32 trials looked at over 14,000 women shows
  - 20% of women who suppressed ovulation still had an increase in their sex drive
  - 65% had no change in their sex drive
  - 15% had a decrease in their sex drive

***Sally doesn’t want you to think that by choosing some form of contraception that suppresses ovulation will absolutely have an impact on your sex drive ‒ it’s so multi-factorial***

- Safety from pregnancy can be so reassuring for patients
- When we think about how hormone pills can impact your sex drive, we think about the 2-fold suppression of the hypothalamic-pituitary access
  - In terms of suppressing your hormones downstream and your therefore ovulation
  - Also going through ovaries and shutting them down, when then decreases their production of testosterone

Sally explains, “*Even though, yes, we have biologic plausibility for how contraception impacts your sex drive, there’s so much going into this from a biopsychosocial perspective that we don’t see the equal number of changes in terms of how it actually impacts your sex drive.*”

**Once Sally identifies that a patient doesn’t want to ovulate, then we can determine if they need contraception**

- 1 – Do we need to do contraception, but that continues to allow you to ovulate?
  - Things like a [Paragard](https://en.wikipedia.org/wiki/Copper_IUD) IUD, [spermicides](https://en.wikipedia.org/wiki/Spermicide), there’s [vaginal pH modifiers](https://hcp-phexxi.com/moa)
  - There’s many ways that we can provide contraception without impacting your ovulation
- 2 – Or if contraception is not an issue and you like to ovulate, then we go down the [menopause hormone therapy](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) route

**You said that 70% of women would be fine without ovulating anymore, does that imply that 70% of perimenopausal women would be better off on oral contraceptives than on estradiol and progesterone?**

***Yes, in Sally’s patient panel, they are happier on that***

- What’s really interesting is when we think about **menopause hormone therapy**, we’re thinking about **17-beta estradiol**
  - Which is this estrogen, it’s an [E2](https://en.wikipedia.org/wiki/Estradiol)
  - It’s the predominant estrogen when we’re in our reproductive years
- And there’s so many benefits to this estrogen
- There are some new birth control pills on the market that have this 17-beta estradiol [[Zoely](https://en.wikipedia.org/wiki/Nomegestrol_acetate) and [Natazia](https://en.wikipedia.org/wiki/Estradiol_valerate/dienogest)]
  - It’s a fascinating mix where you’re suppressing ovulation, you have contraception, but you’re potentially still getting the health benefits of being on a 17-beta estradiol (or an estradiol valerate, which is metabolized into 17-beta estradiol)

***For perimenopausal patients, once we establish: Do you want to ovulate, yes or no? Do you need contraception, yes or no? Then we can think through how we pick a pill***

## Considerations for choosing contraceptives and hormonal therapies during perimenopause [A: 59:45, V: 1:02:13]

**Peter’s concern with an oral contraceptive as a bridge through menopause is they’re missing out on real estrogen and progesterone**

- He thinks we have pretty good evidence that the benefits you accrue later in life, especially with respect to **bone density**, but probably with respect to **other metrics of health**, are heavily dependent on getting real 17-beta estradiol and real progesterone right away
  - Never having an interruption in those hormones
- Sally agrees

***If what we believe on that front is correct, then it means any woman who’s going to go down the oral contraceptive route would be best receiving that oral contraception in the form of what you just described, which is a real 17-beta estradiol***

**What is the cost of that type of oral contraceptive, and how often are insurance companies covering that?**

- They rarely cover it

*Out-of-pocket monthly cost on that pill would be how much?*

- $100-ish a month
- It’s incredibly costly (prohibitive)

**If you were to think about: I’m perimenopausal and I don’t want to ovulate, I want to be on a birth control pill**

1 – The first question is do I want to be on estrogen?

- Sally and Peter are alluding to the fact, “*Yes, I want to be on estrogen, but a certain kind of estrogen.*”

**⇒** Remember, some people are not candidates for estrogen: [migraines](https://en.wikipedia.org/wiki/Migraine) with aura, [blood clot](https://en.wikipedia.org/wiki/Thrombosis_prevention#General_risks_and_indications_for_blood_clot_prevention:~:text=Estrogen%2Dbased%20oral%20contraceptive), family history, but we still want to suppress ovulation

- The newest progesterone on the market is something called [drospirenone](https://en.wikipedia.org/wiki/Drospirenone) (the pill is called [Slynd](https://slynd.com/)), and it suppresses ovulation in about 98% of women
  - Whereas previous progesterone-only pills suppressed ovulation 50-70% of the time
  - So you’re getting a huge mood benefit for these women who cannot take estrogen, but really don’t want to feel the ups and downs of perimenopause cycling (which can be wild)
- Drospirenone being a derivative of spironolactone, there’s a [diuretic](https://en.wikipedia.org/wiki/Diuretic) component to it, and it’s really well tolerated, really exciting

***Sally hopes she can convey how excited she is about this progestin because having drospirenone means that we can mitigate some of the other side effects like water retention***

**⇒** For patients who’ve decided they don’t want estrogen,Sally will use Slynd, this drospirenone-only, but ovulation suppressant medication

**For patients who do want estrogen**

2 – Then, the branch point is: Do I want something synthetic (said very few people ever), or do I want something more natural?

- The people who do end up on a synthetic estrogen, your insurance covers it
  - It’s available at all pharmacies

There’s an access issue here that we would be remiss to ignore

- Within that category [of synthetic estrogens), Sally still has pills that she likes
- Historically, if you interview patients, they may be able to tell you, “*Oh, I did well on this synthetic estrogen*.”
- As we get into the later 40s, Sally cares more in terms of getting them back on a more natural estrogen for the reasons Peter mentioned in terms of **bone prevention** and things like that

**When you’re talking to a 28-year-old woman who just needs birth control, you don’t have a concern with putting her on a synthetic estrogen?**

- She doesn’t
- One favorite is [Lo Loestrin](https://www.rxlist.com/lo-loestrin-fe-drug.htm)
  - That’s Peter’s favorite too
  - It’s a [norethindrone progestin](https://en.wikipedia.org/wiki/Norethisterone)

**⇒** The reason why Sally likes norethindrone is it’s a little bit more androgenic: it has the ability to blunt or mitigate the increase in sex hormone-binding globulin

- She’s talking about pills from a sexual health perspective
  - There’s lots of other ways you could view this, but today this is her angle
- When you think about super low-dose ethanol estradiol, low side effects, plus a slightly more androgenic progestin, you then can have a blunting of the increase in sex hormone-binding globulin
  - It’s less likely to gobble up all those extra androgens and patients tolerate it really well
- Side effects are there’s more bleeding because of the low ethanol estradiol
- So sometimes Sally goes up to [Alesse](https://www.rxlist.com/alesse-drug.htm), which is a 20 microgram ethanol estradiol, and this has a levonorgestrel progestin to it
  - And this progestin is similarly, a little bit more androgenic, less likely to impact your sex hormone-binding globulin
- Then, her last 2 very popular: [Yaz](https://www.rxlist.com/yaz-drug.htm) and [Yasmin](https://www.rxlist.com/yasmin-drug.htm)
  - The reason why those are so popular is the progestin in them is [drospirenone](https://en.wikipedia.org/wiki/Drospirenone) ‒ it’s a little more of a diuretic

Sally wants to step out of professionalism for a moment and ask her father-in-law to tune-in because he’s a nephrologist, and he would be excited to her that she’s going to talk about [angiotensinogen](https://en.wikipedia.org/wiki/Angiotensin#Angiotensinogen)

- [Ethinyl estradiol](https://en.wikipedia.org/wiki/Ethinylestradiol) [a synthetic estrogen] goes to the kidneys, and some 17-beta estradiol goes to the kidneys and causes sodium retention, water retention
- When we think about estrogen and how it impacts our bodies, our PMS: our breasts feeling heavy and painful, bloating, slight weight gain ‒ **this is estrogen effects**
- [Drospirenone](https://en.wikipedia.org/wiki/Drospirenone) [a progestin,] being a derivative of [spironolactone](https://en.wikipedia.org/wiki/Spironolactone) can have a mitigating or a diuretic blunting effect on that water retention

Sally cautions, “*Dave, if you could tune out now, I might say orgasm soon.*”

- Using this counteracting principle in these newer medications can help Sally pick a really good synthetic form of contraception

**Sally’s recommendations for oral contraceptives**

- If we’re going to go to the **natural form**, there’s a few combinations that she’s using now that her patients are tolerating really well

1 – The first is to go back to that progesterone progestin-only pill (which is [Slynd](https://www.rxlist.com/slynd-drug.htm), drospirenone) and adding a 17-beta estradiol patch to it

- You’re essentially taking an ovulation-suppressive component of contraception, but adding in menopause hormone therapy estrogen
  - And that’s where the benefits are: **you get the bone protection**

Peter asks, “*The progestin alone will help with suppression?*”

- Of ovulation [yes], which equals contraception

Peter asks, “*So you can use physiologic 17-beta estradiol?*”

- Correct

> “*That’s super interesting. I’m ashamed to admit I didn’t know that*.”‒ Peter Attia

- It’s a great in-between step, because you can provide contraception, you can provide drospirenone, which is a diuretic, which 17-beta estradiol does have some water retention components to it
- The **downsides** to it, although these work very well throughout the body, at the level of the endometrium or the lining inside the uterus, you have a little bit more breakthrough bleeding, because the 17-beta estradiol does not stabilize the endometrium as much
  - Many patients won’t be happy on this if they’re having breakthrough bleeding

2 – The next medication that we think about is [Nextstellis](https://www.rxlist.com/nextstellis-drug.htm)

- Nextstellis is drospirenone, which is the spironolactone derivative, the diuretic with estetrol, or E4
  - It’s a natural estrogen
  - It’s typically produced by the fetal liver, but this has a longer half-life than 17-beta estradiol
- You get less breakthrough bleeding, less spotting
- We don’t know but we think that with natural estrogens, you must get **bone protection** and bone benefit, it’s currently being studied
- It’s only made by the fetal liver so you have none of this in your body right now (unless you’re taking this)

**We understand how E1, E2 and E3, estrone, estradiol, estriol move between each other, and do we understand how E4 fits into that pathway?**

*Does E4 have any conversion back to E2, or is it acting as an independent agent?*

- [[estrogen metabolism](https://en.wikipedia.org/wiki/Estrogen#Metabolism)]
- We don’t totally know, we think it’s independent
- Something we do know about [E4](https://en.wikipedia.org/wiki/Estetrol), is that it does *not* activate the angiotensinogen pathway
  - So you don’t get water retention and bloating
- You have that [E4] plus drospirenone [with Nextstellis], and patients feel really good (remember, drospirenone is so good for bloating and PMS)

*Until we know if this is going to be protective of bones and all these other things, wouldn’t there be a risk that we’re solving one problem without addressing the jugular problem?*

- Yes, currently being studied, the benefits of drospirenone: less spotting or breakthrough bleeding than the drospirenone plus menopause hormone therapy-level estrogen

3 – The newest medication on the market is called [Natazia](https://www.rxlist.com/natazia-drug.htm)

- Sally thanks that Peter asking this question, it shows a dedication to making sure we’re on a studied 17-beta ethinylestradiol
- And Natazia is a progestin with [estradiol valerate](https://en.wikipedia.org/wiki/Estradiol_valerate#) (which essentially is 17-beta-ethinylestradiol), and this is a hugely important contraceptive option for a few reasons
- The first is it’s the only contraceptive pill that’s been approved by the FDA t**o treat heavy menstrual bleeding**
  - And this is a huge issue in perimenopause, and contributes greatly to sex drive and desire

Peter asks, “*But this is once you’ve ruled out* [*fibroids*](https://en.wikipedia.org/wiki/Uterine_fibroid) *and things that otherwise can’t…*”

- Sally is going to stay in the normal pathology for this podcast
- A luteal out of phase even when you’re double ovulating and having heavy bleeding of perimenopause, still falls in the realm of normal

***Natzia is great because it’s great for heavy menstrual bleeding, but the estradiol valerate (or the 17-beta estradiol) provides: the hot flash benefit, the bone benefit, you get the benefits of menopause hormone therapy, with something that can also help bleeding and prevent pregnancy***

**Just to close the loop on progesterone, if you’re using micronized progesterone, even at 200 mg (which would probably be the upper limit of what we would use), that’s not enough to suppress ovulation, obviously. 300 is?**

**⇒** 300+ mg progesterone is what you would need to predictably, reliably suppress ovulation; but most women can’t tolerate that because it’s too sedating

**Other options for contraception for women in perimenopause**

4 – Menopause hormone therapy plus an [IUD](https://en.wikipedia.org/wiki/Intrauterine_device)

5 – Menopause hormone therapy plus a [salpingectomy](https://en.wikipedia.org/wiki/Salpingectomy) (removal of the fallopian tubes)

- Sally points out, “*There’s other ways to get at this, but I think that’s why I really start at the branch point. Those points do not block ovulation.*”

> “*That’s why to me, I really care how you feel in relation to ovulation; that’s the branch point in how I decide how to treat my patients*.”‒ Sally Greenwald

- Peter realizes that a lot of what we just talked about probably went over the heads of a lot of people
  - Which is understandable; it is pretty complicated stuff

**Peter’s takeaway, if you’re a woman**

- You’ve got to show up with a point of view on what you’re trying to optimize around
- A point of view around preferences, around the question, “***Do I like ovulating or not?’ is important***
- That’s something that regardless of how young a woman is listening to this
  - There is a 25-year-old out there listening; this is something she could be paying attention to right now
  - She’s 20 years away from having to deal with what we’re talking about, but she can still be pretty receptive to the idea of: How do I feel during my cycle?

Sally agrees, that is her biggest takeaway and adds

- She wants to make sure women are aware that ovulation changes the way we feel in the **second part of our cycle** as estrogen decline
  - As we age, that can become more and more dramatic
  - So this is a very important question for her perimenopausal patients

As women age, ovulation changes the way one feels in the second part of the menstrual cycle (as estrogen declines)…

**How much does that change based on children and the number of children a woman has or any other factor like that?**

- Sally would feel a little theoretical going into that
- We don’t have great data
- There’s some [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC5547084/) talking about the later you have your last child, the earlier you’ll go into perimenopause

## Factors negatively affecting desire, and why female libido persists with age and fluctuates across the menstrual cycle [A: 1:11:00, V: 1:15:11]

- Back to a neurotransmitter perspective and the discussion about the accelerators, we launched into a discussion about hormones, but we didn’t talk about the brakes

**⇒** The **brakes [for sexual desire]** are [serotonin](https://en.wikipedia.org/wiki/Serotonin), [prolactin](https://en.wikipedia.org/wiki/Prolactin)

- We know how [SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) can impact our sex drive and can think about what to do about that
- But [prolactin](https://en.wikipedia.org/wiki/Prolactin) is a brake, and it’s really interesting because when in our lives is prolactin high? Breastfeeding postpartum
  - Women can find this very validating
- But from a biologic perspective, we know that pregnancies spaced 18 months apart are healthier
  - The ACOG (American College of Obstetrics and Gynecology) recommend 18 months between pregnancies because that second pregnancy will be healthier
  - The baby will be bigger; it’s more likely to make it to term
- We know that spacing pregnancies is healthy, and so having a high prolactin postpartum and keeping you from being interested in sexual intercourse is your body’s natural way of spacing out pregnancies for the better

**What explains changes in a woman’s sex drive?**

- While we’re on the topic of **evolution**, there’s something Peter has always wondered that seems a bit at odds with a pure natural selection (and this is going to expose how naive his thinking might be)
- It’s not a surprise that men would have a high sex drive for as long as they are capable of reproducing, which is seemingly indefinitely
- But you could make an argument maybe theoretically that women’s sex drive should decline after a certain age, call it 30-ish, when evolutionarily their probability of producing healthy offspring goes down
- But Peter doesn’t think we believe that to be true at all
- He doesn’t think we see that women’s sex drive goes down as they age
  - Which flies in the face of maybe at least one naive interpretation of what natural selection might interpret

*Is there a smarter explanation for why a woman’s sex drive goes up or maybe to phrase it more accurately, it doesn’t go down?*

- There are many explanations
- This is hard to study
- Potentially the most popular one, which we can tangent on the theory for a bit is something called **women’s dual sexuality**

***It basically talks about a woman’s motivation to participate in intercourse being different at different parts of the cycle***

- Sally points out that the European Society of Sexual Medicine gives a grade two level B rating
  - So not super high rating, meaning case control studies
- This theory means that **mid-cycle, when you are able to get pregnant**, you are fertile, you are more likely to want to participate in intercourse for purposes of reproduction
- And the **mates that you are more likely to select** during that time will have features of genetic dominance such as a very symmetric face, more masculine features
  - We talk about the [histocompatibility complex](https://en.wikipedia.org/wiki/Major_histocompatibility_complex), and there’s dissimilarity that we look for at this time because we know that mixing of genes is better than not
- And then, there’s **other times of the cycle** when you are interested in participating in intercourse and you’re seeking out things such as partnership, shelter, companionship, protection
  - You’re not optimizing around genetic features
  - You end up with a less attractive or less symmetric or less masculine partner, but your partner may have better communication skills, the ability to provide better shelter, protection
  - It’s very interesting
- People take this and run with it online and they talk about in your 20s, what form of contraception should you be on when choosing a mate?

This goes back to that question of do you want to ovulate or not?

- Because there’s so much
- This is not an anti-ovulation, anti-contraception discussion

> “*Your sex drive is so multifactorial and being protected from pregnancy for many can be such a positive contributor to their sex life.*”‒ Sally Greenwald

- But if you believe in this evolutionary hypothesis and if you believe that you would rather pick your future mate when you’re still ovulating versus being on something like a contraceptive pill that blocks ovulation, ***there is some data to show that you may pick a different partnership***
- The discussion section is you may want to pick a partner that has a less symmetric face but is more likely to have a partnership and communication skills
  - Sally will excuse herself from that and you can decide for yourself
- Peter finds this super fascinating, and honestly, here’s more to explore there than the simple and obvious stuff he proposed

## How sexual trauma and physical pain can affect sexual health, and evidence-based strategies for recovery [A: 1:15:15, V: 1:19:48]

**Back to desire, how much do adverse sexual experiences during the early part of a woman’s life negatively impact her ability to have a healthy sexual life later on?**

- They didn’t touch on this earlier, but this must be a very important topic that Sally deals with
- We could talk about this across the entire spectrum
  - We could take the most egregious example would be sexual assault, rape, things of that nature
  - But then we can also fan this out into things, which is just, the first time I had sex, it was awful
    - It was in a car in the back seat with a guy that I didn’t really know that well, and we were both drunk and yeah, I was consenting, but it was awful
  - It’s hard to imagine that many women can’t relate to that type of experience

*How does that play forward?*

- Sally sees it incredibly often in her patient panel

***Unfortunately, if you’re listening to this and you have a history of sexual trauma, you are not at all alone and there are things we can do about it***

- Yes it plays a part, and yes, there are things we can do about it
- Sally hopes that patients are in therapy and they have the right support team around them

Sally recommends, “*Sex therapists are a great contributor in this area and thinking about how your experiences are brought into the bedroom, and how do we use a trauma-informed approach when talking about how to curate arousal and bringing yourself to the encounter when you’re not quite ready.*”

**There are lots of different approaches to improving sexual health**

1 – Sex therapists were discussed earlier

2 – The [Sensate Focus exercise](https://www.smsna.org/patients/did-you-know/what-is-sensate-focus-and-how-does-it-work)

- This is really evidence-based for survivors of trauma, but can also be very applicable to patients who, for example, are listening to this podcast and it’s been a year or it’s been six months and they want to think about how to become intimate again
- It’s a 4-step program that can be done over a month, over 4 months
  - You can pick how long each stage you want it to last
- [Dr. Leah Millheiser](https://www.linkedin.com/in/leah-millheiser-md-mscp-717299133/), who’s done a ton of work in sexual health from a gynecologic perspective, talks about this
- Essentially **step #1** is to spend 20 minutes a couple of times a week (if you want this stage to last a week) is to be intimate with your partner, no touching of the breasts, no touching of the genitals
- Next, **step #2** would be it’s okay to touch breasts and genitals, but orgasm off the table.
- Then, **step #3**, the orgasm’s on the table, but no penetrative sex
- And **step #4** is penetrative intercourse is allowed

***This is an evidence-based way in which you can create a safe space to start to find yourself back in your body***

3 – Mindfulness

- There is a book called [*The Body Keeps Score*](https://www.amazon.com/Body-Keeps-Score-Healing-Trauma/dp/0670785938/ref=tmm_hrd_swatch_0), which talks about how to bring your mindfulness back into your body when you are a trauma survivor
- And [Emily Nagoski](https://www.emilynagoski.com/the-facts) talks a lot about it in her [book](https://www.amazon.com/Come-You-Are-Surprising-Transform/dp/1982165316/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.757wsObp5-56MiURcR1wqPZCcrSaU0Lv5YHCZPyd3WLdpmYLqvbZDEsaSZGB8irQZALtOXLHhtl3VQaYU2SVbaSXX8QTU7SDa6Cg_ow95Yfq7UgBQUInDfhcfI_F9cDOeCurRHhjX2yC1f2MtOc9TdpjxRsPn-KWyENW06hbdbo_C_C7C_GMbk6WrqrGOa2pioSOWsfSl4vC_mdyj_Q6v0n5WcQWeq23YXrlrXohLtQ.V-XyL6lgLsYmFMqriPUvW-YpgXi5WbZLkvhKPqHKE0E&qid=1760710135&sr=8-1) as well

For some women, pain can present itself in sexual encounters (it just hurts)

- This is potentially less traumatic, but still
- Sally sees this a lot in her cancer survivors
- Cancer can be a sort of 2-fold hit
  - There is this psychosocial of: I’m mad at my body and there’s all those complex feelings
  - And then there’s this physiologic aspect of chemotherapy, radiation and how that impacts pain and lubrication of the vagina and comfort of hormone use

**⇒** Although we really feel quite confident that local estrogen treatment of the vagina is completely safe for almost all cancer survivors

4 – Local estrogen topical cream used vaginally]

- [Dr. Tami Rowen](https://profiles.ucsf.edu/tami.rowen) talks a lot about this with ISSWSH and Menopause Society, encouraging not only patients, but also doctors to feel comfortable **prescribing local estrogen** in this patient population
- [Dr. Rachel Rubin talked about the use of [Estrace](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/) after 1:41:00 in [episode #348](https://peterattiamd.com/rachelrubin/#:~:text=urinary%20tract%20infections-,The%20benefits%20of%20vaginal%20estrogen%20(or%20DHEA)%20for%20preventing%20UTIs%2C%20improving%20sexual%20health%2C%20and%20more%20%5B1%3A41%3A00%5D,-A%20large%20amount)]

5 – Physical therapy with a pelvic floor therapist

- Pelvic floor physical therapists can be incredibly helpful

Sally adds, “*I think every woman, if you’re making a centenarian plan and you’re seeing a physical therapist to keep your posture and your muscles healthy, I think you should see a pelvic floor physical therapist*.”

- They’re great in terms of increasing the tone of the pelvic floor
- [[link](https://pelvicrehab.com/) to find a pelvic floor physical therapist]

**⇒** We know that the strength of contraction can lead to better quality orgasms

- Sally often gets emails like, “*Oh, I just had the best sex. Thanks for sending me to the pelvic floor physical therapist.*”
- But it also is good for hypertonicity where your pelvic floor is too tight, where you carry stress and trauma and pain

## Vaginal care routine: lubricants, moisturizers, topical hormones, and other approaches for vaginal health [A: 1:19:15, V: 1:24:29]

> “*In terms of thinking about how we take care of the vagina, I would like to encourage you to think about taking care of the vagina like you take care of your face*.”‒ Sally Greenwald

- Peter reacts, “*You listened to my recent podcast.*” [[episode #355](https://peterattiamd.com/tanujnakraandsuzanobagi/) on skincare and aging]
- Sally did and she makes the comparison
  - You are going to go out in the sun, you put sunscreen on your face
  - If you’re going to have intercourse, you should use lube

Peter asks, “*Even if a woman says, ‘I’ve never had any difficulty with lubrication, I don’t have any discomfort with sex,’ you still think a woman should be using lubricant?*”

**-Use a lubricant every time you have sex**

- Yes, the data shows less micro abrasions when women use a lubricant before intercourse
- Micro abrasions lead to pain
- And once we get into a pain signaling process, you can get… this is a common cause of what we call [vaginismus](https://en.wikipedia.org/wiki/Vaginismus) or a tightening of the pelvic floor, which then leads to more pain
  - Breaking a vaginismus cycle takes a lot of work (it is possible)

***Part of this recommendation that almost everyone should use lube is this idea that we’re trying to avoid pain – even for young women***

Sally shares, “*This is one of my favorite things to talk to young teens about. When we think about sexual education, and there’s a great* [*study*](https://www.jahonline.org/article/S1054-139X(23)00438-X/fulltext) *looking at 1,200 high school students and it asks them about what we call sexual debut or their first sexual encounter… (penetrative intercourse)*”

**⇒** 70% of boys gave responses related to pleasure, and 70% of girls gave responses related to pain (that’s a big deal) [[2024 survey](https://www.jahonline.org/article/S1054-139X(23)00438-X/fulltext#:~:text=Gender%20differences%20in%20responses) of high school students]

- Talking about foreplay and lubrication, even for young women who have an adequately lubricated vagina and decreasing the likelihood that they’ll get into pain, that they’ll clench up the pelvic floor, it will then hurt more
- Breaking out of that cycle is incredibly important
- Lube if you’re going to have sex

**-Use a vaginal moisturizer**

- Going back to the face, Sally asks Peter, “*You are putting moisturizer on your face?*”
- Only recently
- Sally points out that only recently are there vaginal moisturizers

Sally shares this advice, “*If you want to use your vagina when you’re older use a vaginal moisturizer, there’s good ones on the market.*”

- There’s [Revaree](https://www.amazon.com/Bonafide-Revaree-Hyaluronic-Non-Hormonal-Paraben-Free/dp/B07GX73BH1/ref=sr_1_1?crid=2E6F312PVJSG3&dib=eyJ2IjoiMSJ9.l-0tomZbajqn4AUhvI8V0cDNOrpwVb7Zzuk3nI-Pu8xLll3YrAwqM8p96v7h8vfi9TUWvs4744gZ65Gcmzck67s0bHaYNChZ2xP2_UgmujsW_OnmatcPXjyE4u1VGKdccG7eaflas--PJN_LRzusr7WtDA0-bNpTieQhOOtUbkFl1nuuk5H7w4JTV2UKhQ_TMNZx8NPCAUGEtXfxK59-E85nPaQxgfpQ2owtS2ugldrYLQ_6kltc69Wt7xTW9CM8KyKwiusW0XWlqA4WOJuLwYvzkaLYOQJmTOAcltNWaTQ.OBA8wZeqJHlqIetn2gkShwCKfOtdRSFbN8Zy0w63kGw&dib_tag=se&keywords=reverie%2Bvaginal%2Bmoisturizer&qid=1755643897&rdc=1&sprefix=revaree%2Bvaginal%2Bmoisturize%2Caps%2C167&sr=8-1&th=1), which is a hyaluronic acid suppository
  - It lowers the pH of the vagina and brings water molecules with it
- There’s [Replens](https://www.amazon.com/Restores-vaginal-moisture-Long-lasting-Moisturizer/dp/B00BISP1TS/ref=sr_1_1?crid=1VIVURQ7I6HM6&dib=eyJ2IjoiMSJ9.zonJ2_j_2I1nYxakSynRavwAbO3Hn1gTkXcqO1Ex-oom5zgz-NyzuH70dX8urIw5d-1r-S78My0V4FcBpydfk9GixiyZVwZT0Xkmu4b9oDNnud4y2F6614XqSOflN4Emq7jRHeqr4oHxQacTf-bMYaOsX4XGkmC99f9GF-aOvOvL5R7jiNM9PsvRfGutQ3lbUHnuNKp7Hc1WGx46NB3Q-axLI7D9thyXayOaOjDjIGhFbxyEYNqOrBnTrFWpNitEBmRtfCdQq3MF8mhg4GBw8KGSiN3jUAqtlPgziiIiz1w._RJiCWGNp5-tCjJNYgDsifcyg8-CxLCeIVo3pdmhkWY&dib_tag=se&keywords=replens+vaginal+moisturizer&qid=1755643943&sprefix=replens+vaginal+moisturizer%2Caps%2C144&sr=8-1), which is a polycarbophil suppository that also recruits water molecules you’re moisturizing your vagina

*Explain how this is used. Is this part of your nightly routine?*

- Yeah, put on your eye cream, moisturize your vagina
- Most people like to use it in the evening

Peter asks, “*Then what if you’re having sex after?*”

- Whether you’re using a vaginal moisturizer or whether you’re using a hormone (which will be the third part of this facial analogy recommendation), if you put it in and you decide you want to have intercourse, please do
  - She wouldn’t use it for the purpose of it
- It’s you’re playing the long game
  - So if you think about step 3 with your face, you’re using a vitamin C serum or a DNA repair enzyme or an exosome or whatever [skincare was discussed in detail in [episode #355](https://peterattiamd.com/tanujnakraandsuzanobagi/)]
  - That’s the long game in terms of collagen and overall tone of the face

***Hormones would be this counterpart from a vaginal perspective***

**-Use a topical estrogen cream**

- Intravaginal, topical hormones
- 30-40% of Sally’s patients who are on menopause hormone therapy use [estrogen cream](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/) intravaginally

Sally clarifies, “*We treat local vaginal conditions with local treatment for women who don’t respond from a vaginal health perspective to systemic hormones.*”

**A recap of the skincare routine analogy with vaginal care: the equivalent of sunscreen was lubrication**

*Should the lubricant be silicone-based?*

- Silicone-based, it lasts longer
- Water-based lubricant doesn’t last as long
- And so, in order to make a water-based lubricant work, they have to add a lot of additives
  - You add additives, you get hyperosmolar lubricants, which then if you go back to high school chemistry means that you’re actually long game is water molecules are going from the vagina into the lubricant because of the osmolality
  - And it’s drying you out in the long term
- This is why Sally likes a silicone-based lube

**Sally’s recommendations for lubricants**

- [Uberlube](https://uberlube.com/products/uberlube-glass-bottle), the osmolality is about 280-300
  - [it’s a silicon-based lube with low osmolality]
- [Good Clean Love Almost Naked](https://www.amazon.com/Good-Clean-Love-Lubricant-Aloe-Based/dp/B07KZPQCCP?th=1)
  - Its osmolality is about 280 to 300
  - The osmolality of the vagina is 300
- [by email Sally recommends transferring lube to a [bottle](https://www.amazon.com/AOZITA-Dropper-Bottles-Stainless-Funnels/dp/B0BGH3VNXB/ref=sr_1_2_sspa?crid=MCFX8LEGOS3&dib=eyJ2IjoiMSJ9.8DBcl-f2HcP1Oca_Tl_niH3Yy8-gnJyUmxwP5dYr01AXtQMdvoVIe_MGlngd7uzNDETQUPBB0n1fzWlSP4OEvLExkTIcWpW2ap7fuHrVADrMog1E0ntehyBOLo8dxcklYJOXrZcj5Uli5hJzUP29NAdeonsb3ONqMIhO0xoRIIVRu7cgdMLqGrj82jGUQBdSIqRjvX1sx-8hoRzlFuwGhJNgq_ZTObGGP8-QzxqWNHY.Z2djjjc1eedCnMzdCSestJWkrY-SNllp1GgAAz65VxI&dib_tag=se&keywords=glass%2Bdroppers&qid=1755608137&sprefix=glass%2Bdroper%2Caps%2C223&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1) and using it to shoot the lube higher up in the canal]

Many lubes in the drugstore shouldn’t be sold

- It’s really quite shocking to me when you go to a drugstore and you pick up, let’s say Astroglide ‒ the osmolality of Astroglide is 8,000
  - They have a gentler one that’s lower (most people don’t know about that)
  - Don’t buy it
- If you look at KY, the osmolality is around 4,000 to 6,000
  - These things shouldn’t be sold

Peter asks, “*Why are they the most ubiquitous lubes out there?*”

- They taste good or they smell good, or they have a cool package

Peter asks, “*Do these lubes say the osmolarity on the package?*”

- If you look on the back, they should say it

**⇒** You want a lubricant with an osmolality as close to 300 as you can get

**The equivalent of a facial moisturizer is a vaginal moisturizer**

- A [Revaree](https://www.amazon.com/Bonafide-Revaree-Hyaluronic-Non-Hormonal-Paraben-Free/dp/B07GX73BH1/ref=sr_1_1?crid=2E6F312PVJSG3&dib=eyJ2IjoiMSJ9.l-0tomZbajqn4AUhvI8V0cDNOrpwVb7Zzuk3nI-Pu8xLll3YrAwqM8p96v7h8vfi9TUWvs4744gZ65Gcmzck67s0bHaYNChZ2xP2_UgmujsW_OnmatcPXjyE4u1VGKdccG7eaflas--PJN_LRzusr7WtDA0-bNpTieQhOOtUbkFl1nuuk5H7w4JTV2UKhQ_TMNZx8NPCAUGEtXfxK59-E85nPaQxgfpQ2owtS2ugldrYLQ_6kltc69Wt7xTW9CM8KyKwiusW0XWlqA4WOJuLwYvzkaLYOQJmTOAcltNWaTQ.OBA8wZeqJHlqIetn2gkShwCKfOtdRSFbN8Zy0w63kGw&dib_tag=se&keywords=reverie%2Bvaginal%2Bmoisturizer&qid=1755643897&rdc=1&sprefix=revaree%2Bvaginal%2Bmoisturize%2Caps%2C167&sr=8-1&th=1) or a [Replens](https://www.amazon.com/Restores-vaginal-moisture-Long-lasting-Moisturizer/dp/B00BISP1TS/ref=sr_1_1?crid=1VIVURQ7I6HM6&dib=eyJ2IjoiMSJ9.zonJ2_j_2I1nYxakSynRavwAbO3Hn1gTkXcqO1Ex-oom5zgz-NyzuH70dX8urIw5d-1r-S78My0V4FcBpydfk9GixiyZVwZT0Xkmu4b9oDNnud4y2F6614XqSOflN4Emq7jRHeqr4oHxQacTf-bMYaOsX4XGkmC99f9GF-aOvOvL5R7jiNM9PsvRfGutQ3lbUHnuNKp7Hc1WGx46NB3Q-axLI7D9thyXayOaOjDjIGhFbxyEYNqOrBnTrFWpNitEBmRtfCdQq3MF8mhg4GBw8KGSiN3jUAqtlPgziiIiz1w._RJiCWGNp5-tCjJNYgDsifcyg8-CxLCeIVo3pdmhkWY&dib_tag=se&keywords=replens+vaginal+moisturizer&qid=1755643943&sprefix=replens+vaginal+moisturizer%2Caps%2C144&sr=8-1), and these are suppositories that you can put in the vagina, nightly
- It is recruiting water molecules into the cells
- And the [Revaree](https://www.amazon.com/Bonafide-Revaree-Hyaluronic-Non-Hormonal-Paraben-Free/dp/B07GX73BH1/ref=sr_1_1?crid=2E6F312PVJSG3&dib=eyJ2IjoiMSJ9.l-0tomZbajqn4AUhvI8V0cDNOrpwVb7Zzuk3nI-Pu8xLll3YrAwqM8p96v7h8vfi9TUWvs4744gZ65Gcmzck67s0bHaYNChZ2xP2_UgmujsW_OnmatcPXjyE4u1VGKdccG7eaflas--PJN_LRzusr7WtDA0-bNpTieQhOOtUbkFl1nuuk5H7w4JTV2UKhQ_TMNZx8NPCAUGEtXfxK59-E85nPaQxgfpQ2owtS2ugldrYLQ_6kltc69Wt7xTW9CM8KyKwiusW0XWlqA4WOJuLwYvzkaLYOQJmTOAcltNWaTQ.OBA8wZeqJHlqIetn2gkShwCKfOtdRSFbN8Zy0w63kGw&dib_tag=se&keywords=reverie%2Bvaginal%2Bmoisturizer&qid=1755643897&rdc=1&sprefix=revaree%2Bvaginal%2Bmoisturize%2Caps%2C167&sr=8-1&th=1) is also slightly lowering the pH of the vagina
  - The lower the pH of the vagina or as close is a natural, desirable outcome

**How does a woman know if her systemic hormone therapy is insufficient and therefore she requires topical as the third part of this playbook?**

- If you are going to respond to systemic hormone therapy in terms of improvement of pain, you’ll respond by about 6-8 weeks
- The pain (or dyspareunia, we call it) feels like a sandpaper canal
  - There’s a rubbing raw feeling to the vagina
- So give it a start and see if things get better
- If you weren’t having pain and nothing gets better, you were probably fine

This strikes Peter as a great example of something that a male who’s listening to this podcast whose female partner is not, could actually bring home and talk about over dinner

- Half our audience is men, half our audience is women
- So there’s a guy who’s listening to this episode whose partner is not, and if Peter was in his shoes, he’s thinking, “*What am I bringing back to the table?*”
- And this would be one of those things which is, “*Hey, let’s have a discussion about these 3 things.*” [lubricants, vaginal moisturizers, and hormone therapy]

## Tips for sexually satisfying your female partner [A: 1:25:45, V: 1:32:05]

**What percentage of women are regularly receiving oral sex?**

- [this is unclear but surveys related to oral sex are listed in the “selected links” section at the end of these notes]

***When you look at orgasm frequency with any intimate encounter, it is one of the highest likelihood to be able to achieve orgasm acts that a man and a woman can participate in together***

- There’s a great book called [*She Comes First*](https://www.amazon.com/She-Comes-First-Thinking-Pleasuring/dp/0060538252/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.UlMW9wN5n3eCDZnTuSxMURDcfQqvTK8GpJ6Slk1-iuFMvgtHEDcXx7M8pT9jy5v-lwFN9w3FFuHV3SAU_U7Yxs87rvTF3BqSOmuAQ2zZjTHNwtLsJ4tcxT1sq_zTp6PAo7aMiKt_gzZ-TkMlREH8g229rQsCNDiGRedNX_kLZKdH8Ke20hSxdWQ8FIhCPubgfSoTpcBeQwuvGxeEFDGMod2n-zEvcDDU3lacHElm4qE.Hjt5_-4doBq21RYwixlZl-jHYuTrsa9xGyyDO1kSlwk&qid=1755608520&sr=8-1)by Ian Kerner [pictured below] that has diagrams and tips and tricks and talks about essentially how to do that

![](https://peterattiamd.com/wp-content/uploads/2025/10/f7-sallygreenwald.png)

**Figure 7. Book cover for** ***She Comes First***. Image credit: [Amazon.com](https://www.amazon.com/She-Comes-First-Thinking-Pleasuring/dp/0060538252/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.UlMW9wN5n3eCDZnTuSxMURDcfQqvTK8GpJ6Slk1-iuFMvgtHEDcXx7M8pT9jy5v-lwFN9w3FFuHV3SAU_U7Yxs87rvTF3BqSOmuAQ2zZjTHNwtLsJ4tcxT1sq_zTp6PAo7aMiKt_gzZ-TkMlREH8g229rQsCNDiGRedNX_kLZKdH8Ke20hSxdWQ8FIhCPubgfSoTpcBeQwuvGxeEFDGMod2n-zEvcDDU3lacHElm4qE.Hjt5_-4doBq21RYwixlZl-jHYuTrsa9xGyyDO1kSlwk&qid=1755608520&sr=8-1)

- Sally’s advice is to go back to the stages of orgasm that she talked about earlier: the excitation, plateau, orgasm, and resolution

When you think about the plateau phase, that’s the hormone cascade that’s happening in the woman

- There’s 2 different ideas that are relevant here
- 1 – The first is something called **the approach**, and the approach is the seconds or moments just prior to orgasm

**⇒** When surveyed, 2/3 of women report that whatever’s happening when the approach starts, that it should just keep happening exactly as it is ‒ whatever you’re doing, just keep doing it

- No change in temperature, pressure, speed, depth, nothing
- Understanding that as a key component for most women (but not all) can be something that can help you from a performance perspective
- The onus is on both the woman and the man
  - The woman needs to recognize she’s there and have a cue to her partner that says, “*Don’t change a thing*.”
  - The guy needs to not try to be a hero and needs to know when she taps my head or whatever it is, ***don’t change a thing***
- That’s a strategy to help women have more of a guaranteed orgasm
- 2 – And then the contrary is something called **edging**, which is where you do stop what you’re doing
  - You bring your partner close to orgasm, and then you stop what you’re doing
  - And then you can bring your partner close again and then you stop

***The edging technique is for women to be able to achieve more of an intense orgasm***

**If you were to give a guy a few pieces of advice on how to be more successful at helping his partner achieve orgasm using oral sex and penetration, what would be your advice?**

1 – Lube

- Get over it. It’s evidence-based. It’s for friction.
- It has nothing to do with how interested your partner is in you

2 – Anatomical awareness

- Understanding that there’s these 2 wishbone nerve pieces enjoy being massaged
- Try to explore with your finger two thirds of the way into the vagina on the anterior or the front wall, where the G-spot is (find that rugated area)

3 – What does foreplay look like for you as a couple?

- What does it look like outside of the bedroom?
- Is it you made dinner or you put the kids down?
- What is your chore play?
- What chores did you do as a part of foreplay?
- What nice text messages?
- There’s so much contextual going on
- There’s really funny research pieces that talk about people who are in the military who are traveling around and there’s bombs everywhere and it’s really dangerous, and men are still ready to have sex and women are feared for their lives

> “*A lot more that goes into women’s sexuality that I want you to be aware of*.”‒ Sally Greenwald

A summary of concepts discussed today

- There’s no need to take this personally, but Sally hopes the discussion today around understanding arousal versus desire
- Responsive desire [versus spontaneous desire]…
- Anatomically thinking about not just the tip of the clitoris (although many men haven’t even thought of that) but in addition to the tip of the clitoris, the wishbone structures that go down the anterior wall of the vagina
- Thinking about what phase of orgasm your partner’s in
  - Is she in the excitement phase?
  - Is she in the plateau phase?
  - Or is she in the orgasm phase? And what does that look like?

**What about little details like, for example, if you’re stimulating the clitoris, is it just very individual variation? Up and down, side to side, around?**

- Individual variation

*Is this something where a guy should just ask a woman and say, ‘Hey, how do you like this done?’ Or is a woman put off by a guy asking that?*

- In Sally’s dream world, these conversations would take place
- There’s books that walk you through how to have these conversations
  - The [Sex Talks](https://www.amazon.com/Sex-Talks-Five-Conversations-Transform/dp/1668000016/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Fd8XOCdHAPcjyD4mk2HZQOnMkzWGfYybiCXMH6eMUjLoIIhYQcGzeDVy98m5iLGQHswfbib8CZcfTMtZsBT_m4gwCED94WD0SGybSmLFc1Ea7dEjnx4B9q2Avg6NgVqL.54RQfdaQxziVH_C7YJ1MHezfntPgnXweUHtqHews33M&qid=1758638362&sr=8-1) book that I mentioned by Vanessa Marin, she writes it with her husband, so you get both perspectives.
- That website, [OMGYES](https://www.omgyes.com/join), actually teaches women how to find the different techniques
  - They go over a hard stroke, a round stroke, a gentle touch, an internal touch
  - They actually teach women
  - Sally has a dream that women would go to this website and learn for themselves how to do it and talk to their partners about it
  - Men can also go to the website
  - It’s a one-time flat fee website, and then you have access to all of their content
  - And it walks you through different techniques so you can actually learn and talk about with your partner what she likes

## The pharmacology of arousal: various treatments for low sexual desire in women [A: 1:30:30, V: 1:37:15]

- We’ve talked a little bit about it through a hormone perspective and we’ve obviously talked about how testosterone in particular, but also estrogen and progesterone play a role in the arousal of a woman
- But there are also drugs that are specifically used to target this

**What can you tell us about drugs that target arousal?**

- Using that accelerator and break analogy, many of the medications will work on one or both of those pathways

The 2 most common medications and the only two that are FDA-approved for women are [Addyi](https://www.rxlist.com/addyi-drug.htm) (which is a pill) and [Vyleesi](https://www.rxlist.com/vyleesi-drug.htm) (which is an injection)

- They work along the [MAOI](https://en.wikipedia.org/wiki/Monoamine_oxidase_inhibitor) pathway on increasing norepinephrine and dopamine and decreasing serotonin
- If you go back to those neurotransmitters, thinking about serotonin as a brake, and they decrease that
- They increase norepinephrine and dopamine to the reward center of the brain
- Sally doesn’t use these a ton in her practice
- They are not studied for postmenopausal women

Addyi is a nightly pill that you take for 6 weeks

- Well, you take it forever, but after it takes about 6 weeks before you can see the benefit to it
- In the trial for which it was FDA-approved, it increased your number of satisfying sexual encounters by one

***Women taking Addy went from having 2-ish satisfying sexual encounters a month to 3-ish satisfying sexual encounters***

- You can’t drink alcohol on it
- It can cause nausea for some people
- It can interact with antidepressants and mood-stabilizing drugs ‒ it’s not a contraindication, but can change the way in which they work
- Sally doesn’t use it very much
- She doesn’t know how much it costs

Peter asks, “*Why do you think this drug was approved with such limited efficacy?*”

- It’s statistically significant to go from, let’s say 2-ish to 3-ish satisfying sexual encounters
- But there was a social movement at the time
  - There was frustration about how easy it was for [Viagra](https://en.wikipedia.org/wiki/Sildenafil) to be approved
  - The data for Viagra in men is much more clear and easy to see

***Women’s sex drive is very complex and this potentially one angle at improving it***

- Peter thinks it’s a bad analogy because Viagra is not really a drive drug, it’s a performance drug
- Sally adds, “*It’s a performance drug that ultimately can impact drive as well.*”

**Are there any data that show that Viagra or Cialis or any phosphodiesterase inhibitor improve orgasm quality in women?**

- They’ve looked at Viagra a great deal
- The studies do not show for women across the population level that it impacts drive or orgasm quality, except when looking at **a specific patient population**
  - So, when you look at [Viagra](https://www.rxlist.com/viagra-drug.htm), the patients who had an improvement in their quality of sex, be it dry or orgasm quality, etc. were women diabetics, MS, multiple sclerosis, spinal cord patients and SSRIs
  - These are women who we think that the vasodilation of the nitric oxide and the physiologic response that they have to Viagra dosed at 25 to 50 1-2 hours prior to anticipated intercourse can be helpful
- Back to [Addyi](https://www.rxlist.com/addyi-drug.htm) (the pill), when Sally talks about 1 satisfying sexual encounter improved per month, remember that that’s compared to placebo
  - So, there is still a great [placebo benefit](https://en.wikipedia.org/wiki/Placebo#Effects) here
  - And for many, that’s exciting and fine to introduce into their life

[Vyleesi](https://www.rxlist.com/vyleesi-drug.htm) is an injection ([bremelanotide](https://en.wikipedia.org/wiki/Bremelanotide))

- You may get questions about it from your patient panel because it’s similar to the **peptide PT-141 Melanotan**
- This has the street name as the **Barbie drug** because it works through the [MCR4](https://en.wikipedia.org/wiki/Melanocortin_4_receptor) or the melanocortin pathway
  - So, you get tan and pretty happy and horny is what they say, so they call the Barbie drug for that reason
- There’s a significant amount of nausea
  - You inject yourself and for the first 2  hours 40% of women will have nausea
  - Sally often prescribes [Zofran](https://en.wikipedia.org/wiki/Ondansetron), an anti-nausea medicine, when she prescribes this drug
  - After 2-ish, 3-ish hours, the nausea can go away, and then the drug lasts for up to 6 hours
- You can’t use it more than twice a week

***This had similar efficacy to Addyi in terms of improving your sex drive***

- When Peter hears that a drug causes that much nausea and you can only use it twice a week, he worries that it’s doing something unhelpful as a side effect beyond what you just said

*Do you have a concern with long-term use of Vyleesi?*

- It’s been out since 2019
- We don’t have particularly long-term data on it
- Sally has the same questions as Peter about it
- People anecdotally do like it, but she thinks there’s a great [placebo effect](https://en.wikipedia.org/wiki/Placebo#Effects) going on here

*Do you think one is better than the other?*

- It’s really hard for Sally to convince patients to inject themselves with a shot an hour or so prior to intercourse
  - It doesn’t really feel psychosocially sexy
- Peter guesses it speaks to obviously the magnitude of the problem

*Have these drugs been compared head-to-head to testosterone?*

- She doesn’t think so, no

**Testosterone**

- Peter would assume it would be prudent to make sure a woman’s testosterone has been pushed to the physiologic limits before you would engage with any of those drugs?
- Sally prefers testosterone

**⇒** To be clear, from a guideline perspective, testosterone is recommended only in the postmenopausal woman (from the FDA perspective)

- We are talking about premenopausal women
- But there’s a lot of behavioral interventions (that Sally has already mentioned)

**Off-label drugs include cannabis**

- There is some pretty good [data](https://pmc.ncbi.nlm.nih.gov/articles/PMC11071449/) now that we have in some states legal [THC](https://en.wikipedia.org/wiki/Tetrahydrocannabinol)
  - That opens up for researchers to study and investigate, and there’s really good trials talking about cannabis and your ability to have more satisfying sexual encounters
- But it is dose-dependent and a U-shaped curve
  - Specifically THC, around 1-3 mg is the recommended dose
  - Anything higher for some can be sedating (to speak to your inverse relationship) which adversely affects your sexual experience and desire to participate
- At around 1-2 mg, patients report that they have more satisfying orgasms or have a hyper-awareness of their senses
  - Sex drive is higher
  - It’s quite significant in the data, much more significant than the medications that Sally has already talked about

*1-2 mg, is that in any form? Edible? Inhaled?*

- If this is an illegal substance where you live, it is not a recommendation
- If it is legal, there are safer ways to ingest THC
  - Smoking, vaping obviously have a great impact on the lung ‒ we’re incredibly worried about that
  - One of the best ways to dose-adjust is to get name brand THC
  - There are brands out there that have unregulated but arguably quite **standardized dosing of gummies**, and you can get a 1 mg or a 2 mg or a 5 mg

Peter asks, “*Is 1 mg altering of senses at all? Seems pretty low.*”

- Yeah, it’s pretty low for most people
- It’s a heightened sense response in terms of physical sensibility to appreciate orgasms, stay in the moment, but not enough to cause paranoia, munchies, or things like that

*Is this true for men and women or just women?*

- Both

## Sex during and after pregnancy: impact on arousal, safety of sex, and how to manage postpartum recovery and pain [A: 1:37:45, V: 1:45:31]

**What is happening to a woman’s arousal during pregnancy?**

Peter’s naive evolutionary view

- Now he can modify his view
- Previously, his view would’ve been that a pregnant woman should not want to have sex at all because any amount of penetration puts the fetus at risk
- However, based on what Sally taught him a few minutes ago, there’s another reason for her to have sex during pregnancy, which is to keep her male partner around to protect her and hopefully their child
- He assumes it’s a balancing act of those things, so how does that shake out in the real world?

*What do we actually observe about a woman’s sexual desire during pregnancy?*

*And what are the dos and don’ts?*

- It’s complex, as you can imagine
- Sally agrees, that would be the evolutionary approach
- From a medical perspective, in a healthy pregnancy in the absence of a contraindication (a low-lying placenta, a low-lying blood vessel or a cervical insufficiency, which we would pick up on in routine ultrasound), sexual health, ***sex during pregnancy is completely safe***
  - It’s totally fine, and has a lot of relationship and psychosocial benefits

*Is there a point late enough in the pregnancy where you would recommend a woman not have intercourse? (in the absence of any of those things)*

- Absolutely not

**⇒** We know that for many women, sex during pregnancy can be quite intense in the pleasurable category

- The reasons for this are the neurotransmitters
  - You have super high levels of estrogen and [oxytocin](https://en.wikipedia.org/wiki/Oxytocin), so that can make for a more pleasurable experience
- There’s more blood flow to the genital area, so the contractions of the muscles are more intense
  - The blood vessels are bringing more heat to the area
- And then for some women, to feel safe and supported and bonding with a partner in pregnancy
  - But that’s not the case for all

**Post-pregnancy, what do you advise your women?**

*If a woman has had a C-section, what do you think is the right time for her to go back to sexual activity pending her desire?*

- We don’t change the recommendation for when to resume sexual activity post-vaginal birth or C-section

**⇒** It’s 6 weeks across the board

- That’s the time when you go see your doctor, they check you out, they make sure everything is well-healed
- It fits uneasy for a lot of people to say, “*Well, gosh, why is it the same recovery time for both? A C-section is so much bigger.*”
- The thought process is that by 6 weeks, you should have complete healing from the C-section in the absence of complications
- From a hormonal physiologic perspective, making sure that the uterus has shrunk down a significant amount, that you’re not at increased risk of infection by having things in the vagina
- You’re a good candidate to have contraception at that time, so we can provide you with protection from future pregnancies

Sally adds, “*From a postpartum perspective, reason number 15 why I loved your podcast and why I love* [*Rachel Rubin*](https://www.rachelrubinmd.com/drrubin)*, she recently* [*published*](https://pubmed.ncbi.nlm.nih.gov/40373318/) *on the genitourinary syndrome of lactation, which basically talks about the hypoestrogenic or the low estrogen state of the vagina postpartum and how that mimics the pathophysiology of women in menopause.*”

- For a lot of Sally’s patients who are breastfeeding (who have high [prolactin](https://en.wikipedia.org/wiki/Prolactin) and low estrogen), she’s prescribing them the same [estrogen cream](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/) that she’s prescribing postmenopausal women to keep the vagina as healthy and moisturized as possible

**Does an episiotomy affect the ability to resume intercourse after pregnancy or is that usually healed by six weeks as well?**

- The hope is that it’s healed
- Unfortunately, pain from tearing in general or [episiotomies](https://en.wikipedia.org/wiki/Episiotomy) can lead to pain
  - Which can lead to [dyspareunia pain with sex](https://en.wikipedia.org/wiki/Dyspareunia), and therefore we have drive issues and sexual health issues as well

Sally points out, “*To be clear, [episiotomies are] out of fashion in the absence of an emergency. We don’t do routine episiotomies. The data is clear against those, but we do see that any sort of tearing or cutting that happens in the vagina can lead to pain.*”

- Another thing to think about from a postpartum perspective is how these insults of pain can manifest into something bigger than they are

***Participating in sex before you’re ready and having a painful sexual experience can cause tightening of the pelvic floor, rigidity in the muscles, and can set into motion a pain cycle that then takes future pelvic floor physical therapy to break that pain cycle***

## How Sally would redesign sex education [A: 1:42:15, V: 1:50:24]

- Peter is a little naive, he doesn’t really know what’s being taught in sex ed
- He doesn’t even remember what he learned in sex ed
  - Although he remembers watching these really embarrassing movies on a VCR (that’s about the extent of it

**If you were sex ed czar appointed from atop the mountain, how would you design the curriculum?**

*How would it differ for boys versus girls?*

*When would you initiate it?*

- She would get away from the fear-based don’t get pregnant, don’t get an STD, you’re going to get HIV fear-based counseling

Peter asks, “*Aren’t those things important, though?*”

- They are important, but there has to be some actual education in terms of pleasure and anatomy and pathophysiology
- This is not a podcast talking about the plight of women

Sally shares, “*As a mom to four boys, I am equally committed that boys are as educated as girls are, and I care that my boys care about the experience that their potential future partners might have with them.*”

> “*Women’s sexuality is complex. It’s the anatomy you cannot see as well as you can see with men*.”‒ Sally Greenwald

- Just the nature of the fact that when a bunch of boys are in a locker room, they can see other boys’ anatomy
- They see the differences, they understand that that’s healthy
- Girls don’t often see other girls’ vaginas as clearly as boys see other penises

Topics Sally would cover include

- 1 – Normalizing through the [Labia Library](https://www.labialibrary.org.au/) [explicit images] and realizing what’s normal
- 2 – Understanding the clitoral nerve for both boys and girls
- 3 – Thinking about safe ways to explore intimacy
- If you don’t provide them with informational content, such as [OMGYES](https://www.omgyes.com/join), and teaching them about how to explore their anatomy, they will turn to **porn**
- And we have great [data](https://journals.sagepub.com/doi/10.1177/26318318231153984) that almost all of the porn is not healthy for teens in terms of setting expectations that are unrealistic, both anatomical and describing penetrative penis and vagina sex as the way that women have screaming orgasms
  - That’s just not accurate
  - And so it sets expectations for encounters that are just not obtainable and leads to disappointment and self-confidence issues

***Sally would love for sexual education to be informative from an anatomical, physiologic, accurate, pleasure-based perspective and talk them through how to have safer encounters***

**What is the way in which you’re going to communicate with your boys about this in an environment where they’re growing up in a world that you, me, your husband, we just can’t relate to?**

- Peter made this point with Rachel Rubin on the [podcast](https://peterattiamd.com/rachelrubin/), when he was growing up, porn was a black-and-white Playboy or something (it’s a totally different thing)

*What are you going to do? And what is your advice for other parents out there who have growing boys, and girls for that matter?*

- Sally doesn’t distinguish the genders as much
- She thinks education about all bodies should be provided to all people

1 – Use the correct verbiage and anatomical nomenclature

- Calling a penis a penis and calling a vulva a vulva and normalizing this as a part of your health

2 – Masturbation is incredibly healthy

- It should be done in a private setting, and it’s healthy
- There’s a lot about shaming masturbation and how that can put your child at higher risk for issues in the future if you shame their exploration of their body
- It’s normal, it’s healthy, it’s a part of your health, orgasm is healthy, but it should be done in a private place

3 – How you interact. What is consent?

- What are the components to consent?
- What does that look like?
  - Is it specific?
  - Is it enthusiastic?
  - Does it persist as the activity changes?
  - Is there a timeline on it?
- Thinking about all the different ways that we think about consent

4 – Safe sex

- And then changing the way that society allows its perceptions to trickle into what we think of in terms of safety
  - For example, as a culture, we tend to say penetrative sex, penis and vagina, is the end-all, top of the pyramid, most intimate act you can do with someone
  - But condoms are quite effective at preventing sexually transmitted diseases when used in a penetrative sexual encounter
  - People don’t really use protection when performing oral sex, either women on men or men on women, and so as we see the rise of [herpes](https://en.wikipedia.org/wiki/Herpes_simplex_virus_2) across college campuses, ***this is an intervention that we really need to talk about***

**⇒** If you’re at a party and you’re with someone and you want to be intimate with them, having penetrative intercourse with a condom on is safer and less likely to transmit a sexually transmitted disease than if you’re going to perform oral sex on each other

> “*Thinking about it from a safety perspective and not a cultural perspective would be another key foundational change that I think needs to happen*.”‒ Sally Greenwald

Sex education needs to change

- Did you have sex education in college?
- What about grad school?
- What about perimenopause and menopause?
- There needs to be an evolving door in terms of different providers coming in and talking and educating because our bodies change, our physiology changes, and our needs change

***This is not a 8th grade one-hour split the boys and girls talk about it kind of a thing***

**Coming back to this specific issue, how much of an issue is pornography for young boys? And what is the solution?**

- Peter thinks it’s not going to get regulated away
  - Although there are some states where at least age verification is required (a step in the right direction)

Sally’s strategy in general, when thinking about don’t do this

- Is always, “*Do this*.” (don’t do this, do this)

***Introduce what you should do instead of what you shouldn’t ‒ let’s introduce something healthy (what does a healthy sexual life look like?)***

- The porn industry, there are parts of it that have evolved
  - There are healthier informational videos that you can watch if you’re looking for arousal
- There are healthy ways to have an orgasm and to interact with another human being
- And talking about how you bring someone into your life that’s healthy and what frequency is healthy for both of you
  - And if you’re not getting that, to what ends do we go to get it elsewhere?
- And what are you searching for?
  - Is it a dopamine release?
  - What can we add and replace of that neurotransmitter release that you’re looking for?

**Is there a crisis of intimacy in young people?**

- Peter has heard this a lot, but he doesn’t know the data
- He keeps hearing that people in their 20s today are becoming less and less intimate over time relative to a decade ago, two decades ago
- Sally doesn’t know this data either
- She has the same anecdotal experience in her clinical practice where she has very lonely, less intimate 20-year-old women in her practice ask, “*When I take a sexual health history, which I always do, there’s a lot lacking there*,” and it would be a whole nother podcast to talk about AI and how that’s going to replace intimacy and how we can use that for arousal and things like that
- It’s something to think about

## Sally’s optimism about a new era in women’s sexual health [A: 1:49:00, V: 1:58:22]

**What are you most concerned with right now as you think about your professional world? And what are you most excited about?**

- Sally is most excited about the new information that we have coming in about hormone options in terms of how we provide menopause hormone therapy and how we treat perimenopause
  - The new types of estrogen and progestin
  - How we tinker with those and moderate those to optimize women and how they feel
  - This is super personalized, super individualized medicine
- The more research that’s coming out and the more drugs available make it really fun to be a part of

In terms of concerns

- The world is changing and Sally thinks people are ready for it
- She’s ready to push it there
  - She notices that Peter is pushing it there

> “*I think it’s really exciting to think about sexual health as a part of your health and talking about it in a various generic safe place from a physiologic perspective*.”‒ Sally Greenwald

- Think about all the people you can get on your team to help you
  - Sex therapists and pelvic floor physical therapists
  - And how to tinker with your hormones and behavioral interventions

***Sally loves thinking about couples listening to this podcast together and trying different things and seeing this as potentially orgasm as another biometric or sexual satisfaction as another longevity lever that we pull when improving the happiness and health of our lives***

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Rachel Rubin**: [#348 ‒ Women’s sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.](https://peterattiamd.com/rachelrubin/) (May 12, 2025) | [4:00, 49:30, 1:44:45]

**Orgasm linked to better sleep**: [The influence of sexual activity on sleep: A diary study](https://pubmed.ncbi.nlm.nih.gov/36646500/) | *Journal of Sleep Research* (C Oesterling et al. 2023) | [7:30]

**Study comparing sex to walking on a treadmill**: [Energy expenditure during sexual activity in young healthy couples](https://pubmed.ncbi.nlm.nih.gov/24205382/) | *PLoS One* (J Frappier et al. 2013) | [8:30]

**Statistics on orgasm in women**: [17:00]

- [The Orgasm Gap](https://yougov.co.uk/society/articles/40941-orgasm-gap-61-men-only-30-women-say-they-orgasm-ev?utm_source=chatgpt.com) | *YouGov UK* (M Smith, E Nolsoe 2022)
- [Women’s Experience of Orgasm During Intercourse: Question Semantics Affect Women’s Reports and Men’s Estimates of Orgasm Occurrence](https://pubmed.ncbi.nlm.nih.gov/29079939/) | *Archives of Sexual Behavior* (T Shirazi et al. 2018)
- [How often do women orgasm during sex?](https://news.iu.edu/kinseyinstitute/live/news/45749-how-often-do-women-orgasm-during-sex) | *Kinsey Institute Indiana University* (2019)

**Statistics on orgasm in men**: [Differences in Orgasm Frequency Among Gay, Lesbian, Bisexual, and Heterosexual Men and Women in a U.S. National Sample](https://pubmed.ncbi.nlm.nih.gov/28213723/) | *Archives of Sexual Behavior* (D Frederick et al. 2018) | [17:15]

**Apps for erotic literature**: [22:30]

- [Meet Rosy](https://meetrosy.com/erotica) | Erotica: Reconnect With Your Sexuality
- [Dipsea](https://www.dipseastories.com/) | Romance, reimagined

**Book on the benefits of mindfulness for arousal**: [Better Sex Through Mindfulness: How Women Can Cultivate Desire](https://www.amazon.com/dp/1771642351/?bestFormat=true&k=better%20sex%20through%20mindfulness%20lori%20brotto&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_k1_1_11_de&crid=4UW7QCAPFE61&sprefix=better%20sex%20) by Lori Brotto, forward by Emily Nagoski (2018) | [22:30]

**Book about curating arousal**: [Come As You Are: Revised and Updated: The Surprising New Science That Will Transform Your Sex Life](https://www.amazon.com/Come-You-Are-Surprising-Transform/dp/1982165316/ref=tmm_pap_swatch_0) by Emily Nagoski (2021)

**WHO guidelines on lubrication**: [WHO recommendations on self-care interventions: availability of lubricants during sexual activity](https://www.who.int/publications/i/item/who-srh-23.4) (2024) | [25:30]

**Recommended vibrators**: [28:45]

- [JIMMYJANE Bullet](https://jimmyjane.com/products/chroma)
- [Goop double-sided wand](https://goop.com/goop-wellness-double-sided-wand-vibrator/p/?Size=No+Size)

**Air pulse vibrator**: [Lelo Sona](https://www.lelo.com/sona) | [29:15]

**Depth-limiting device for use after addressing pain**: [Ohnut](https://thepelvicpeople.com/collections/all-products/products/ohnut-depth-limiting-rings) | The Pelvic People

**Survey of gen Z men ask them to identify the clitoris**: [Sexual wellbeing is still a mystery for many UK men – survey reveals](https://www.theurologyfoundation.org/about-us/media/press-releases/sexual-wellbeing-is-still-a-mystery-for-many-uk-men-survey-reveals/#:~:text=61%25%20of%20men%20could%20correctly,the%20clitoris%20than%20the%20prostate.) | *The Urology Foundation* (2024) | [32:15]

**Labia library**: [The Labia Library](https://www.labialibrary.org.au/) (explicit images) | [33:15, 1:43:45]

**Book for better communication with your partner**: [39:15, 1:30:00]

- [Sex Talks: The Five Conversations That Will Transform Your Love Life](https://www.amazon.com/Sex-Talks-Five-Conversations-Transform/dp/1668000016/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Fd8XOCdHAPcjyD4mk2HZQOnMkzWGfYybiCXMH6eMUjLoIIhYQcGzeDVy98m5iLGQHswfbib8CZcfTMtZsBT_m4gwCED94WD0SGybSmLFc1Ea7dEjnx4B9q2Avg6NgVqL.54RQfdaQxziVH_C7YJ1MHezfntPgnXweUHtqHews33M&qid=1758638362&sr=8-1) by Vanessa Marin and Xander Marin (2023)
- [Becoming Cliterate: Why Orgasm Equality Matters–And How to Get It](https://www.amazon.com/Becoming-Cliterate-Orgasm-Equality-Matters/dp/0062484389/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ww5LLIoMpqmsMagq7qNTzXzbUYw37tiMYHeJekCyWnp7X-FsTXISavTqvuiIljg1icKujuhl3e92OJ_oDzi6OQ.s7s90o_OxhE0rNm0DeXP-JiV7ktMnW7tVTxs-iyXfVM&qid=1758638509&sr=8-1) by Dr. Laurie Mintz (2017)

**Website about anatomy and how to find pleasure spots**: [OMGYES](https://www.omgyes.com/join) | [39:30]

**Discordance in desire between men and women**: [Sexual Desire Discrepancy: A Position Statement of the European Society for Sexual Medicine](https://pmc.ncbi.nlm.nih.gov/articles/PMC7261674/?utm_source=chatgpt.com) | *Sexual Medicine* (D Marieke et al. 2020) | [43:00]

**Effect of suppressing ovulation on sex drive**: [The influence of combined oral contraceptives on female sexual desire: a systematic review](https://pubmed.ncbi.nlm.nih.gov/23320933/) | *European Journal of Contraception and Health Care* (Z Pastor, K Holla, R Chmel 2013) | [57:15]

**Sensate Focus exercise**: [What Is Sensate Focus and How Does It Work?](https://www.smsna.org/patients/did-you-know/what-is-sensate-focus-and-how-does-it-work) | SMSNA for patients | [1:16:45]

**Books about the benefits of mindfulness for trauma survivors**: [1:17:45]

- [The Body Keeps the Score: Brain, Mind, and Body in the Healing of Trauma](https://www.amazon.com/Body-Keeps-Score-Healing-Trauma/dp/0670785938/ref=tmm_hrd_swatch_0) by Bessel van der Kolk (2014)
- [Come As You Are: Revised and Updated: The Surprising New Science That Will Transform Your Sex Life](https://www.amazon.com/Come-You-Are-Surprising-Transform/dp/1982165316/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.757wsObp5-56MiURcR1wqPZCcrSaU0Lv5YHCZPyd3WLdpmYLqvbZDEsaSZGB8irQZALtOXLHhtl3VQaYU2SVbaSXX8QTU7SDa6Cg_ow95Yfq7UgBQUInDfhcfI_F9cDOeCurRHhjX2yC1f2MtOc9TdpjxRsPn-KWyENW06hbdbo_C_C7C_GMbk6WrqrGOa2pioSOWsfSl4vC_mdyj_Q6v0n5WcQWeq23YXrlrXohLtQ.V-XyL6lgLsYmFMqriPUvW-YpgXi5WbZLkvhKPqHKE0E&qid=1760710135&sr=8-1) by Emily Nagoski (2021)
- [Healing Sex: A Mind-Body Approach to Healing Sexual Trauma](https://www.amazon.com/Healing-Sex-Mind-Body-Approach-Sexual/dp/1573442933/ref=sr_1_1?crid=1MYYGPF0CZQJQ&dib=eyJ2IjoiMSJ9.Q3uQjJyFr-_mxj9S5BnTG9GV-midkPBISe7t2AtdYA1babBRtO1hObGRLRw2zkopb9RPpBo4bzeSw4b0PPl51y5z-O974Kkw0GK_6HOadW0.CTg65o7HqVisdXX7RtUgJrjo8ySoELvsOXv18e38WP8&dib_tag=se&keywords=Healing+Sex%3A+Staci+Haines&qid=1755608910&sprefix=healing+sex+staci+haines%2Caps%2C130&sr=8-1) by Staci Haines (2007)

**Topic estrogen cream for vaginal use (local hormone therapy)**: [Estradiol Vaginal Estrogen Cream (Generic for Estrace)](https://www.costplusdrugs.com/medications/estradiol-0_01-tubeofcream42_5g/) | CostPlus Drugs [1:18:45, 1:22:30, 1:41:00]

**Survey of high school students about pleasure and pain during sex and discordance between males and females**: [What’s Something You’ve Heard About Sex, But Are Unsure If It’s True?”: Assessing Middle and High School Students’ Sex Education Questions](https://pubmed.ncbi.nlm.nih.gov/37804300/) | *The Journal of Adolescent Health* (G Wetzel, D Sanchez 2024) [[full text](https://www.jahonline.org/article/S1054-139X(23)00438-X/fulltext)] | [1:20:30]

**Recommended vaginal moisturizers**: [1:21:15]

- [Revaree](https://www.amazon.com/Bonafide-Revaree-Hyaluronic-Non-Hormonal-Paraben-Free/dp/B07GX73BH1/ref=sr_1_1?crid=2E6F312PVJSG3&dib=eyJ2IjoiMSJ9.l-0tomZbajqn4AUhvI8V0cDNOrpwVb7Zzuk3nI-Pu8xLll3YrAwqM8p96v7h8vfi9TUWvs4744gZ65Gcmzck67s0bHaYNChZ2xP2_UgmujsW_OnmatcPXjyE4u1VGKdccG7eaflas--PJN_LRzusr7WtDA0-bNpTieQhOOtUbkFl1nuuk5H7w4JTV2UKhQ_TMNZx8NPCAUGEtXfxK59-E85nPaQxgfpQ2owtS2ugldrYLQ_6kltc69Wt7xTW9CM8KyKwiusW0XWlqA4WOJuLwYvzkaLYOQJmTOAcltNWaTQ.OBA8wZeqJHlqIetn2gkShwCKfOtdRSFbN8Zy0w63kGw&dib_tag=se&keywords=reverie%2Bvaginal%2Bmoisturizer&qid=1755643897&rdc=1&sprefix=revaree%2Bvaginal%2Bmoisturize%2Caps%2C167&sr=8-1&th=1)
- [Replens](https://www.amazon.com/Restores-vaginal-moisture-Long-lasting-Moisturizer/dp/B00BISP1TS/ref=sr_1_1?crid=1VIVURQ7I6HM6&dib=eyJ2IjoiMSJ9.zonJ2_j_2I1nYxakSynRavwAbO3Hn1gTkXcqO1Ex-oom5zgz-NyzuH70dX8urIw5d-1r-S78My0V4FcBpydfk9GixiyZVwZT0Xkmu4b9oDNnud4y2F6614XqSOflN4Emq7jRHeqr4oHxQacTf-bMYaOsX4XGkmC99f9GF-aOvOvL5R7jiNM9PsvRfGutQ3lbUHnuNKp7Hc1WGx46NB3Q-axLI7D9thyXayOaOjDjIGhFbxyEYNqOrBnTrFWpNitEBmRtfCdQq3MF8mhg4GBw8KGSiN3jUAqtlPgziiIiz1w._RJiCWGNp5-tCjJNYgDsifcyg8-CxLCeIVo3pdmhkWY&dib_tag=se&keywords=replens+vaginal+moisturizer&qid=1755643943&sprefix=replens+vaginal+moisturizer%2Caps%2C144&sr=8-1)

**Recommended lubricants**: [1:23:00]

- [Uberlube](https://uberlube.com/products/uberlube-glass-bottle)
- [Good Clean Love Almost Naked](https://www.amazon.com/Good-Clean-Love-Lubricant-Aloe-Based/dp/B07KZPQCCP?th=1)

**Recommended bottle for lube, can be used as a lube shooter**: [Glass dropper bottle](https://www.amazon.com/AOZITA-Dropper-Bottles-Stainless-Funnels/dp/B0BGH3VNXB/ref=sr_1_2_sspa?crid=MCFX8LEGOS3&dib=eyJ2IjoiMSJ9.8DBcl-f2HcP1Oca_Tl_niH3Yy8-gnJyUmxwP5dYr01AXtQMdvoVIe_MGlngd7uzNDETQUPBB0n1fzWlSP4OEvLExkTIcWpW2ap7fuHrVADrMog1E0ntehyBOLo8dxcklYJOXrZcj5Uli5hJzUP29NAdeonsb3ONqMIhO0xoRIIVRu7cgdMLqGrj82jGUQBdSIqRjvX1sx-8hoRzlFuwGhJNgq_ZTObGGP8-QzxqWNHY.Z2djjjc1eedCnMzdCSestJWkrY-SNllp1GgAAz65VxI&dib_tag=se&keywords=glass%2Bdroppers&qid=1755608137&sprefix=glass%2Bdroper%2Caps%2C223&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1)

**Statistics around oral sex**: [1:25:45]

- [Changes in Oral and Anal Sex With Opposite-Sex Partners Among Sexually Active Females and Males Aged 15 to 44 Years in the United States: National Survey of Family Growth, 2011–2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC10581427/) | *Sexually Transmitted Diseases* (Katz et al. 2023)
- [Heterosexual Anal and Oral Sex in Adolescents and Adults in the United States, 2011–2015](https://pmc.ncbi.nlm.nih.gov/articles/PMC6753934/) | *Sexually Transmitted Diseases* (M Habel et al. 2018)
- [Oral Sex and Condom Use in a U.S. National Sample of Adolescents and Young Adults](https://pubmed.ncbi.nlm.nih.gov/29174873/) | *The Journal of Adolescent Health* (G Holway, S Hernandez 2018)
- [Differences in Oral Sexual Behaviors by Gender, Age, and Race Explain Observed Differences in Prevalence of Oral Human Papillomavirus Infection](https://pmc.ncbi.nlm.nih.gov/articles/PMC3901667/) | *PLoS One* (G D’Souza et al. 2014)
- [Prevalence and timing of oral sex with opposite-sex partners among females and males aged 15-24 years: United States, 2007-2010](https://pubmed.ncbi.nlm.nih.gov/24979976/) | *National Health Statistics Reports* (C Copen, A Chandra, G Martinez 2012) [[pdf](https://www.cdc.gov/nchs/data/nhsr/nhsr056.pdf)]
- [Prevalence and correlates of heterosexual anal and oral sex in adolescents and adults in the United States](https://pubmed.ncbi.nlm.nih.gov/18190267/) | *Journal of Infectious Diseases* (J Leichliter et al. 2007)
- [Predictors of early initiation of vaginal and oral sex among urban young adults in Baltimore, Maryland](https://pubmed.ncbi.nlm.nih.gov/16502153/) | *Archives of Sexual Behavior* (D Ompad et al. 2006)

**Book with tips, tricks, and diagrams to aid in female orgasm**: [She Comes First: The Thinking Man’s Guide to Pleasuring a Woman](https://www.amazon.com/She-Comes-First-Thinking-Pleasuring/dp/0060538252/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.UlMW9wN5n3eCDZnTuSxMURDcfQqvTK8GpJ6Slk1-iuFMvgtHEDcXx7M8pT9jy5v-lwFN9w3FFuHV3SAU_U7Yxs87rvTF3BqSOmuAQ2zZjTHNwtLsJ4tcxT1sq_zTp6PAo7aMiKt_gzZ-TkMlREH8g229rQsCNDiGRedNX_kLZKdH8Ke20hSxdWQ8FIhCPubgfSoTpcBeQwuvGxeEFDGMod2n-zEvcDDU3lacHElm4qE.Hjt5_-4doBq21RYwixlZl-jHYuTrsa9xGyyDO1kSlwk&qid=1755608520&sr=8-1) by Ian Kerner (2004) | [1:26:15]

**Cannabis use and the ability to have more satisfying sexual encounters**: [1:36:15]

- [Assessment of the effect of cannabis use before partnered sex on women with and without orgasm difficulty](https://pmc.ncbi.nlm.nih.gov/articles/PMC11071449/) | *Sexual Medicine* (S Mulvehill, J Tishler 2024)
- [Update on cannabis in human sexuality](https://pmc.ncbi.nlm.nih.gov/articles/PMC11339138/#Sec8) | *Psychopharmacology* (D Lissitsa et al. 2024)
- [Cannabis Use in Women and Sexual Dysfunction](https://www.mdpi.com/2411-5118/6/3/31) | *Sexes* (B Lynn et al. 2025)

**Genitourinary syndrome of lactation (last author, Rachel Rubin)**: [1:40:45]

- [Genitourinary syndrome of lactation: a new perspective on postpartum and lactation-related genitourinary symptoms](https://pubmed.ncbi.nlm.nih.gov/38757214/) | *Sexual Medicine Reviews* (S Perelmuter et al. 2024)
- [Postpartum and Lactation-Related Genitourinary Symptoms: A Systematic Review](https://pubmed.ncbi.nlm.nih.gov/40373318/) | *Obstetrics and Gynecology* (S Perelmuter et al. 2025)

**Porn is not healthy for teens**: [1:44:00]

- [Psychological and Forensic Challenges Regarding Youth Consumption of Pornography: A Narrative Review](https://www.mdpi.com/2673-7051/1/2/9) | *Adolescents* (A Gasso, A Bruch-Granados 2021)
- [Pornography and Its Impact on Adolescent/Teenage Sexuality](https://journals.sagepub.com/doi/10.1177/26318318231153984) | *Journal of Psychosexual Health* (H Adarsh, S Sahoo 2023)

**Find a menopause certified practitioner**: [Find a Menopause Practitioner](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx) | The Menopause Society

**Find a pelvic floor physical therapist**: [Find a pelvic rehab practitioner](https://pelvicrehab.com/) | Pelvic Rehab

---

## People Mentioned

- [Rachel Rubin](https://www.rachelrubinmd.com/drrubin) (Urologist and sexual medicine specialist, Director-at-Large for the International Society for the Study of Women’s Sexual Health) [4:00, 49:30, 1:40:45]
- [Lauren Streicher](https://www.drstreicher.com/about) (Clinical Professor of Obstetrics and Gynecology at Northwestern University’s Feinberg School of Medicine and founding Medical Director of the Northwestern Medicine Center for Sexual Medicine and Menopause) [35:15]
- [Leah Millheiser](https://www.linkedin.com/in/leah-millheiser-md-mscp-717299133/) (Gynecologist and women’s health advocate who [practices](https://leahmillheiser.dr-leonardo.com/about-us.html) in Palo Alto and at [Sutter Health](https://www.sutterhealth.org/find-provider/dr-leah-s-millheiser-1078057689), expert in sexual health and menopause) [1:17:15]
- [Emily Nagoski](https://www.emilynagoski.com/the-facts) (Author, educator, expert in women’s sexual wellbeing and healthy relationships) [1:18:00]
- [Tami Rowen](https://profiles.ucsf.edu/tami.rowen) (Associate Professor of Ob/Gyn, Reproductive Sciences at UCSF, clinical and research expertise on sexual health as well as care for women with disabilities and cancer) [1:18:45]

---

##### Sally Greenwald, M.D., M.P.H.

Dr. Sally Greenwald earned her medical degree at Tufts University School of Medicine, and she completed her residency in obstetrics and gynecology at UCSF. She is a board certified OB GYN, a certified menopause practitioner of The Menopause Society, and a member of the International Society for the Study of Women’s Sexual Health. Dr Greenwald is an Adjunct Clinical Assistant Professor (Affiliated) in Obstetrics & Gynecology – General GYN at [Stanford University](https://med.stanford.edu/profiles/sally-greenwald#bio). She also has a gynecology practice in Palo Alto, California.

Dr Greenwald’s clinical passion lies in helping women navigate the complexities of perimenopause and menopause, focusing on hormone-related health and personalized solutions. She believes in taking the time to truly understand each patient’s experience, offering thoughtful care for both common and less commonly recognized symptoms of hormonal changes and sexual health issues. She is passionate about empowering patients with information and honest guidance to value their health and be their best selves. [[Sally Greenwald](https://www.sallygreenwald.com/)]

LinkedIn: [Sally Greenwald, MD MPH](https://www.linkedin.com/in/sally-greenwald-md-mph-bb3317b8/)